

# Generated at 2022-06-21 17:35:28.167729
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.transformer import source_to_node, node_to_source
    transformer = MetaclassTransformer()

    # Test with metaclass
    metaclass = ast.Name(id='B', ctx=ast.Load())
    bases = [ast.Name(id='C', ctx=ast.Load())]
    class_node = ast.ClassDef(name='A', bases=bases, keywords=[ast.keyword(arg='metaclass', value=metaclass)],
                              body=[], decorator_list=[])
    transformer.visit_ClassDef(class_node)

# Generated at 2022-06-21 17:35:33.388141
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_visitor import run_on_examples
    from ..utils.ast_helpers import cst_to_ast, ast_to_cst, dump_ast
    import ast


# Generated at 2022-06-21 17:35:41.875385
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import check_transform

    class_def = ast.ClassDef(name="A", bases=[ast.Name(id="object", ctx=ast.Load())],
                             keywords=[ast.keyword(arg="metaclass", value=ast.Name(id="B", ctx=ast.Load()))])
    expected_class_def = ast.ClassDef(name="A",
                                      bases=[class_bases.get_body(ast.Name(id="B", ctx=ast.Load()), [ast.Name(id="object", ctx=ast.Load())])])

    module = ast.Module(body=[class_def])
    expected_module = ast.Module(body=[module_body.get_body(), expected_class_def])


# Generated at 2022-06-21 17:35:43.504535
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:35:51.651809
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys
    sys.dont_write_bytecode = True
    from py2c import py2c
    from py2c import AssertTransformed
    test_source = '''
        class A(metaclass=B):
            pass
    '''
    expected_source = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    AssertTransformed(test_source, expected_source)

# Generated at 2022-06-21 17:35:56.276239
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_sourcecode
    # should remove body

# Generated at 2022-06-21 17:36:00.113053
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse('class A(type): pass')
    transformer = MetaclassTransformer()
    result = transformer.visit_Module(module)
    expected = ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(type): pass')
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-21 17:36:03.114749
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..parse import parse
    from .test_base import BaseTestTransformer, transform


# Generated at 2022-06-21 17:36:11.922380
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast

    snippet = """
    class A(metaclass=B):
        pass
    """
    node = ast.parse(snippet)

    # Test: Without metaclass keyword
    node = MetaclassTransformer.run_on_node(node)
    assert ast.dump(node) == "Module(body=[ClassDef(name='A', bases=[Name(id='_py_backwards_six_withmetaclass', ctx=Load())], keywords=[], body=[Pass()], decorator_list=[])])"

    # Test: With metaclass keyword
    snippet = """
    class A(metaclass=B):
        pass
    """
    node = ast.parse(snippet)
    node = MetaclassTransformer.run_on_node(node)
    assert ast.dump(node)

# Generated at 2022-06-21 17:36:22.406048
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse("""
    class A(metaclass=B):
        pass
    """)

    a = module.body[0]

    expected_module = ast.parse("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_with_metaclass(B)):
        pass
    """)

    expected_a = expected_module.body[1]

    transformer = MetaclassTransformer()
    module_transformed = transformer.visit(module)
    a_transformed = module_transformed.body[1]

    assert ast.dump(module_transformed) == ast.dump(expected_module)
    assert ast.dump(a_transformed) == ast.dump(expected_a)

# Unit test

# Generated at 2022-06-21 17:36:26.545296
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .test_utils import assert_equal_ast
    from .six_to_py3 import SixToPy3
    import ast


# Generated at 2022-06-21 17:36:28.046735
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys

    import typing
    import typed_ast.ast3 as ast

    import py_backwards.transformers as transformers
    import py_backwards.utils as utils


# Generated at 2022-06-21 17:36:30.111464
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor


# Generated at 2022-06-21 17:36:39.018370
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclass = ast.Name(id='B', ctx=ast.Load())
    bases = ast.List(elts=[], ctx=ast.Load())
    node = ast.ClassDef(name='A',
                        bases=bases,
                        keywords=[ast.keyword(arg='metaclass', value=metaclass)],
                        body=[], decorator_list=[])
    node = MetaclassTransformer().visit(node)
    assert node.bases[0].left.args[0].id == 'B'
    assert node.keywords == []

# Generated at 2022-06-21 17:36:51.701010
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import get_ast, compare_asts
    from .six import SixTransformer
    transformer = MetaclassTransformer()
    compare_asts(transformer,
                 get_ast("""
                 class A(metaclass=B):
                     pass
                 """),
                 get_ast("""
                 from six import with_metaclass as _py_backwards_six_with_metaclass
                 class A(_py_backwards_six_with_metaclass(B)):
                     pass
                 """)
                 )


# Generated at 2022-06-21 17:37:01.148646
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..env import env
    from ..utils.source import source_to_unicode

    import typed_astunparse

    body = ['class MyClass(metaclass=MyMeta): pass']
    expected = ['class MyClass(_py_backwards_six_withmetaclass(MyMeta)): pass']
    tree = env.parse('\n'.join(body))

    m = MetaclassTransformer(env)
    new = m.visit(tree)
    assert typed_astunparse.unparse(new).strip() == '\n'.join(expected)

    assert m.dependencies == ['six']


# Generated at 2022-06-21 17:37:11.706192
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    src = '''
        class A(metaclass=B):
            pass
    '''
    tree = ast.parse(src)
    new_tree = MetaclassTransformer.run_pipeline(tree)
    assert new_tree.body[0].__class__ == ast.ClassDef
    assert new_tree.body[0].bases[0].__class__ == ast.Call
    assert new_tree.body[0].bases[0].func.__class__ == ast.Name
    assert new_tree.body[0].bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert new_tree.body[0].bases[0].args[0].__class__ == ast.Name

# Generated at 2022-06-21 17:37:17.382400
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    py_source = """
    
    class A(metaclass=B):
        pass
    
    """
    c = MetaclassTransformer()
    c.visit(ast.parse(py_source))
    result = ast.dump(c.root)
    expected = """Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0), ClassDef(name='A', bases=[_py_backwards_six_withmetaclass(B)], keywords=[], body=[], decorator_list=[])])"""  # noqa
    assert result == expected

# Generated at 2022-06-21 17:37:23.081673
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transform = MetaclassTransformer()
    sample_code = """
    class A:
        pass
    """
    tree = ast.parse(sample_code)
    sample_code = """
    class A(_py_backwards_six_withmetaclass(object)):
        pass
    """
    correct = ast.parse(sample_code)
    test = transform.visit(tree)
    assert ast.dump(test) == ast.dump(correct)

# Generated at 2022-06-21 17:37:34.615441
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    from ..utils.test import run_test_node_transformer

    class A(object):
        def test(self):
            pass

    class B(metaclass=A):
        pass

    assert B.test == A.test

    node = ast.parse('''class B(metaclass=A):
        pass''')  # type: ignore

    changed, new_node = run_test_node_transformer(MetaclassTransformer, node,
                                                  include=['six'])

    assert changed
    assert type(new_node) is ast.Module
    assert len(new_node.body) == 2
    assert type(new_node.body[0]) is ast.ImportFrom
    assert type(new_node.body[1]) is ast.ClassDef
   

# Generated at 2022-06-21 17:37:46.007067
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..test_utils import run_transformer_test

# Generated at 2022-06-21 17:37:47.893712
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert(MetaclassTransformer().target==(2, 7))

# Generated at 2022-06-21 17:37:51.702897
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    snippet.test_snippet(six_import, '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    ''')

    snippet.test_snippet(class_bases, '''
    _py_backwards_six_withmetaclass(metaclass, *bases)
    ''')

# Generated at 2022-06-21 17:38:00.517564
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # Arrange
    from typed_ast import ast3 as ast
    node = ast.ClassDef(name='A',
                        bases=[ast.Name(id='B', ctx=ast.Load())],
                        keywords=[ast.keyword(arg='metaclass',
                                              value=ast.Name(id='C', ctx=ast.Load()))])
    expected = ast.ClassDef(name='A',
                            bases=[ast.Call(func=ast.Name(id='_py_backwards_six_with_metaclass', ctx=ast.Load()),
                                            args=[ast.Name(id='C', ctx=ast.Load()),
                                                  ast.Name(id='B', ctx=ast.Load())],
                                            keywords=[])],
                            keywords=[])

# Generated at 2022-06-21 17:38:08.012419
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor

    class B:
        pass

    class C(metaclass=B):
        pass

    source = astor.code_to_ast(C)
    metaclass_transformer = MetaclassTransformer()
    result = metaclass_transformer.visit(source)
    expected = astor.code_to_ast("class C(_py_backwards_six_with_metaclass(B))")  # type: ignore
    assert ast.dump(result, include_attributes=False) == ast.dump(expected, include_attributes=False)

# Generated at 2022-06-21 17:38:18.338210
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3
    from py_backwards.parsing.exceptions import ParseError

    with pytest.raises(ParseError):
        ast3.parse('class Foo(metaclass=int): pass')

    with pytest.raises(ParseError):
        ast3.parse('class Foo(metaclass=1): pass')

    with pytest.raises(ParseError):
        ast3.parse('class Foo(metaclass=1): pass')

    with pytest.raises(ParseError):
        MetaclassTransformer(2, 7, ['foo']).visit(ast3.parse('class Foo(metaclass=int): pass'))


# Generated at 2022-06-21 17:38:18.869213
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:38:26.393353
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_utils import make_tree
    from .test_utils import make_ancestor_tree
    from .test_utils import compare_source

    tree = make_tree(
        'class A(metaclass=B):',
        '    pass'
    )
    assert tree == make_ancestor_tree(tree)

    mt = MetaclassTransformer()
    mt.visit(tree)
    assert compare_source(tree,
                          ('from six import with_metaclass as _py_backwards_six_withmetaclass',
                           'class A(_py_backwards_six_withmetaclass(B)):',
                           '    pass'))
    assert mt._tree_changed

# Generated at 2022-06-21 17:38:29.380974
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .base import BaseNodeTransformerTester
    from .six_import import ImportSixTransformer
    import sys

    from six import with_metaclass

    class TestModuleTransformer(BaseNodeTransformerTester):
        transformer = MetaclassTransformer()
        target = (2, 7)

# Generated at 2022-06-21 17:38:30.739062
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:38:42.123581
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    t = MetaclassTransformer()
    t.visit(ast.parse(b"""
    class A(metaclass=B):
        pass
    """))
    assert t._tree_changed
    assert b"""
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B))
        pass
    """ in t._b.getvalue()

# Generated at 2022-06-21 17:38:54.214643
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...testing import loop_until
    from ... import test

    class A(object):
        pass

    class B(type):
        pass

    class C(A, metaclass=B):
        def __init__(self):
            pass

    tree = test.parse_snippet(C)

    assert len(tree.body[1].keywords) == 1
    assert tree.body[1].body[0].lineno == 8

    new_tree, changed = loop_until(MetaclassTransformer, tree)
    assert changed

    assert new_tree.body[0].lineno == 1
    assert len(new_tree.body[1].bases[2].args) == 4
    assert new_tree.body[1].bases[2].args[1].lineno == 7
    assert new_tree.body

# Generated at 2022-06-21 17:39:00.587425
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a = ast.parse("class A(metaclass=B): pass")
    t = MetaclassTransformer()
    a1 = t.visit(a)
    assert six_import.get_body() == a1.body[0]
    assert ast.ClassDef("A", ast.List(elts=[class_bases.get_body()],
                                      ctx=ast.Load()), [], [], []) == a1.body[1]


# Generated at 2022-06-21 17:39:06.781362
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()
    node = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    transformer.visit(node)
    assert ast.dump(node) == "Module(body=[ClassDef(name='A', bases=[_py_backwards_six_with_metaclass(B)], keywords=[], body=[Pass()], decorator_list=[])])"

# Generated at 2022-06-21 17:39:14.060784
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = '''
    class A(metaclass=B): 
        pass
    '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert(ast.dump(tree) == ast.dump(ast.parse(expected)))

    # Test class with more than one base class
    source = '''
    class A(B, metaclass=C): 
        pass
    '''

# Generated at 2022-06-21 17:39:23.250896
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Test with import added.
    input_code = """
    class A(metaclass=B):
        pass
    """
    output_code = """
    from six import with_metaclass as _py_backwards_six_with_metaclass

    class A(_py_backwards_six_with_metaclass(B)):
        pass
    """
    node = ast.parse(input_code)
    node = MetaclassTransformer().visit(node)  # type: ignore
    assert ast.dump(node) == output_code


# Generated at 2022-06-21 17:39:24.625947
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

# Generated at 2022-06-21 17:39:33.036620
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..parsers import parse_classdef
    from ..utils.tree import ast_to_str
    from ..utils.ast_wrapper import AstWrapper
    import textwrap
    source = textwrap.dedent('''\
        class A():
            pass
        class B(metaclass=A):
            pass
        class C(A, metaclass=B):
            pass
    ''')
    expected_source = textwrap.dedent('''\
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A():
                pass
            class B(_py_backwards_six_withmetaclass(A)):
                pass
            class C(_py_backwards_six_withmetaclass(B), A):
                pass
    ''')

    tree

# Generated at 2022-06-21 17:39:39.260343
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3
    # Setup test
    source = ast3.parse("""
    class A(object):
        pass
    """)
    module = source
    transformer = MetaclassTransformer()

    # Run test
    result = transformer.visit_Module(module)
    # Assert result
    assert_source(result, """
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class A(object):
        pass
    """)



# Generated at 2022-06-21 17:39:50.134428
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .test_utils import generate_test
    snippet_setup = six_import.get_body()
    transform = MetaclassTransformer()

    def test(module: ast.Module) -> ast.Module:
        node = transform.visit(module)
        assert isinstance(node, ast.Module)
        
        assert isinstance(node.body[0], ast.Import)
        assert node.body[0].names[0].name == 'six'
        assert node.body[0].names[0].asname == '_py_backwards_six'
        assert len(node.body[0].names) == 1

        return node
    
    generate_test(test, 
                  '''
                    class A(B):
                        pass
                  ''',
                  snippet_setup)



# Generated at 2022-06-21 17:40:04.915022
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # import ast
    # class_def_node = ast.parse('class A(metaclass=B): pass').body[0]
    # class_def_node.bases
    # class_def_node.bases.elts
    # class_def_node.keywords
    # metaclass_node = class_def_node.keywords[0].value
    # metaclass_node
    # MetaclassTransformer.visit_ClassDef
    pass

# Generated at 2022-06-21 17:40:11.498666
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.syntax import check_syntax

    check_syntax(MetaclassTransformer, """
    class A(metaclass=B):
        pass
    """, """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)


# Generated at 2022-06-21 17:40:18.748435
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = """
        class A(B, metaclass=C):
            pass
        """
    target = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(C, B)):
            pass
        """
    tree = ast.parse(source)
    xformer = MetaclassTransformer()
    tree = xformer.visit(tree)
    assert xformer._tree_changed
    transformed = ast.dump(tree)
    assert transformed == target

# Generated at 2022-06-21 17:40:25.512645
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast
    from astunparse import unparse
    node = ast.parse('class A(metaclass=B): pass')
    mt = MetaclassTransformer()
    mt.visit(node)
    print(unparse(node))
    assert unparse(node).strip() == 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass'

if __name__ == "__main__":
    test_MetaclassTransformer()

# Generated at 2022-06-21 17:40:32.073863
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .test_utils import roundtrip
    from .. import ast27
    from ..utils.source_gen import to_source

    node = ast27.parse('''class A(metaclass=B):
    pass''')
    node = roundtrip(node, [MetaclassTransformer])
    node = ast.Module(body=[node])

# Generated at 2022-06-21 17:40:40.006617
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import six
    import astor
    class Foo:
        pass
    class Bar(metaclass=Foo):
        pass

    class Boo(six.with_metaclass(Foo)):
        pass
    src_code = '''class Bar(metaclass=Foo):
        pass
    '''
    mt = MetaclassTransformer()
    expected_code = astor.to_source(mt.visit(ast.parse(src_code)))
    assert expected_code == astor.to_source(ast.parse(astor.to_source(ast.parse('class Boo(six.with_metaclass(Foo)):\n    pass\n'))))

# Generated at 2022-06-21 17:40:49.717423
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = "class A1(metaclass=B):\n    pass\n"
    tree = ast.parse(code)
    visitor = MetaclassTransformer()
    node = tree.body[0]
    assert isinstance(node, ast.ClassDef)
    visitor.visit(node)
    assert isinstance(node.bases[0], ast.Call)
    assert node.bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert node.bases[0].args[0].id == 'B'
    assert not node.keywords
    assert visitor.tree_changed

# Generated at 2022-06-21 17:40:59.998385
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import six
    if six.PY2:
        criteria = {
            'from six import with_metaclass as _py_backwards_six_withmetaclass':
                lambda node: any([isinstance(node, ast.ImportFrom),
                                  isinstance(node, ast.Import),
                                  isinstance(node, ast.Assign)])
        }
    else:
        criteria = {
            'from six import with_metaclass as _py_backwards_six_withmetaclass':
                lambda node: isinstance(node, ast.ImportFrom)
        }
    MetaclassTransformer.test(__file__, criteria)


# Generated at 2022-06-21 17:41:09.405778
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse(
        """class A(metaclass=B):
    pass"""
    )
    transformer = MetaclassTransformer()
    transformed = transformer.visit(node)
    assert (ast.dump(transformed) ==
        "Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0), ClassDef(name='A', bases=[Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), args=[Name(id='B', ctx=Load())], keywords=[])], body=[], decorator_list=[])])"
    )



# Generated at 2022-06-21 17:41:13.972950
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    t: MetaclassTransformer = MetaclassTransformer()   # type: ignore
    m: ast.Module = ast.Module([])
    m = t.visit(m)
    assert len(m.body) == 1

# Generated at 2022-06-21 17:41:38.517210
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    modul = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    transformer = MetaclassTransformer()
    transformer.visit(modul)
    assert modul, '\n'.join(['import six',
                             'class A(_py_backwards_six_withmetaclass(B)):',
                             '    pass'])


# Generated at 2022-06-21 17:41:39.138161
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:41:40.691485
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast


# Generated at 2022-06-21 17:41:44.580808
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class Foo(object):
        def __init__(self):
            super().__init__()

    class Bar(Foo, metaclass=type):
        pass

    assert MetaclassTransformer(Bar).run() == [Foo]

# Generated at 2022-06-21 17:41:45.426852
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:41:46.977411
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .test_utils import transform, check_equal


# Generated at 2022-06-21 17:41:59.499563
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source
    from .six import SixImporter
    from .unpacking import UnpackingTransformer

    source = source('''
    from six import add_metaclass
    class A():
        pass
    ''')
    expected_source = source('''
    class A():
        pass
    ''')
    expected_dependencies = {'six'}
    tree = ast.parse(source)
    importer = SixImporter()
    importer.visit(tree)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    unpacking_transformer = UnpackingTransformer()
    unpacking_transformer.visit(tree)

    assert expected_source == unpacking_transformer.get_source()
    assert transformer.dependencies == expected_dependencies




# Generated at 2022-06-21 17:42:08.670114
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import unittest

    class TestMetaclassTransformer(unittest.TestCase):
        file = "foo.py"
        line = 1

        def test_class_name(self):
            code = """
            class A(object):
                pass
            """
            node = ast.parse(code, TestMetaclassTransformer.file, TestMetaclassTransformer.line)
            tree = MetaclassTransformer().visit(node)
            m = ast.Module(body=tree.body, type_ignores=[])
            self.assertIsInstance(tree, ast.ClassDef)
            self.assertEqual(tree.name, "A")
            self.assertIsInstance(tree.bases[0], ast.Call)
            self.assertIsInstance(tree.bases[0].func, ast.Name)


# Generated at 2022-06-21 17:42:16.282736
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    tree = ast.parse("class A(metaclass=B): pass")
    transformer = MetaclassTransformer()
    result = transformer.visit(tree)


# Generated at 2022-06-21 17:42:24.571557
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from itertools import chain
    from typed_ast.ast3 import AST, parse, fix_missing_locations, Module
    import typed_ast.ast3 as ast3
    def transform(suite: AST) -> AST:
        tree = Module(body=suite)
        tree = fix_missing_locations(tree)
        return MetaclassTransformer().visit(tree)

# Generated at 2022-06-21 17:43:11.431063
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from . import compile_to_ast, assert_equal_ast
    src =MetaclassTransformer.__doc__
    tree = compile_to_ast(src)
    node = tree.body[1]
    node = MetaclassTransformer().visit(node)
    result = compile_to_ast("""
    class A(_py_backwards_six_with_metaclass(B)):
        pass
    """)
    assert_equal_ast(result, node)

# Generated at 2022-06-21 17:43:23.891880
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.mock import MockNode, MockNodeTransformer

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='C', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])


# Generated at 2022-06-21 17:43:26.342345
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ast import parse


# Generated at 2022-06-21 17:43:31.135265
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = """class A(metaclass=B): pass"""
    c = MetaclassTransformer()
    tree = parser.parse(source)
    c.visit(tree)
    assert compile(tree, '', 'exec') == compile(source, '', 'exec')



# Generated at 2022-06-21 17:43:37.550211
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    assert MetaclassTransformer().visit(ast.parse("""
        class A(metaclass=B):
            pass
     """)) == ast.parse("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        
        class A(_py_backwards_six_withmetaclass(B)):
            pass
     """)

# Generated at 2022-06-21 17:43:47.927751
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Given
    class_ = ast.ClassDef(name='Test', bases=[], keywords=[])
    module = ast.Module(body=[class_])
    transformer = MetaclassTransformer()

    # When
    transformer.visit_Module(module)

    # Then
    assert transformer._tree_changed
    assert module.body[0].__class__ == ast.ClassDef
    assert module.body[1].__class__ == ast.ImportFrom
    assert module.body[1].module == 'six'
    assert module.body[1].names[0].name == 'with_metaclass'
    assert module.body[1].names[0].asname == '_py_backwards_six_withmetaclass'



# Generated at 2022-06-21 17:43:55.109330
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import six
    import astor
    assert bool(six.PY2)

    tree = astor.parse_file(__file__)
    for statement in tree.body:
        if isinstance(statement, ast.ClassDef):
            if statement.name == 'MetaclassTransformer':
                break
    else:
        raise ValueError("Could not find class MetaclassTransformer")
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed

# Generated at 2022-06-21 17:44:02.114898
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast27 as ast
    from ..utils.meta import get_first_arg
    from ..utils.tree import to_source

    node = ast.parse('class A(metaclass=B): pass')
    trans = MetaclassTransformer()
    trans.visit(node)
    node = get_first_arg(node.body[0].bases[0])
    assert node.id == '_py_backwards_six_withmetaclass'
    print(to_source(node))

# Generated at 2022-06-21 17:44:09.989343
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.node_util import compare_nodes, ast_parse
    code = '''
    class C(metaclass=A):
        pass
    '''

    tree = ast_parse(code)
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class C(_py_backwards_six_withmetaclass(A)):
        pass
    '''

    trans = MetaclassTransformer()
    tree = trans.visit(tree)
    compare_nodes(tree, expected)

# Generated at 2022-06-21 17:44:19.518063
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = textwrap.dedent('''\
        class A(metaclass=B):
            pass
        ''')
    result = textwrap.dedent('''\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        ''')
    tree = ast.parse(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)  # type: ignore
    result = ast.dump(tree, include_attributes=True)  # type: ignore
    assert result == result, result