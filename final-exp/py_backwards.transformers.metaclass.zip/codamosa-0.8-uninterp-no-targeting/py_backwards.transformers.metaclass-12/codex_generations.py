

# Generated at 2022-06-21 17:35:21.360710
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3 as ast

    class Source(ast.AST):
        _fields = ('name', 'keywords')
        _attributes = ()

    class Source2(ast.AST):
        _fields = ('keywords',)
        _attributes = ()

    class Source3(ast.AST):
        _fields = ('name', 'keywords', 'bases')
        _attributes = ()

    import six
    from ..utils.tree import NodeTransformer

    class MetaclassTransformer(NodeTransformer):
        """Compiles:
            class A(metaclass=B):
                pass
        To:
            class A(_py_backwards_six_with_metaclass(B))
        
        """
        target = (2, 7)
        dependencies = ['six']


# Generated at 2022-06-21 17:35:22.531564
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:35:29.390617
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = """class A(metaclass=type):
                pass"""
    tree = ast.parse(code)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert(ast.dump(tree) == "Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0), ClassDef(name='A', bases=[Call(args=[Name(id='type', ctx=Load())], func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), keywords=[], starargs=None, kwargs=None)], keywords=[], body=[], decorator_list=[])])")

# Generated at 2022-06-21 17:35:39.679522
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Given
    node, expected = ast.parse('''
    class A(metaclass=int):
        pass
    '''), ast.parse('''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(int)):
        pass
    ''')

    # When
    tree_transformer = MetaclassTransformer()
    result = tree_transformer.visit(node)

    # Then
    assert_ast_equal(result, expected)


# Generated at 2022-06-21 17:35:50.085114
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..testing import make_visitor_test, parse_ast

    make_visitor_test(MetaclassTransformer, 'test_MetaclassTransformer', 'class A(metaclass=B): pass', ast.Module(body=[ast.ClassDef(name='A', bases=[ast.Call(func=ast.Name(id='_py_backwards_six_withmetaclass', ctx=ast.Load()), args=[ast.Name(id='B', ctx=ast.Load())], keywords=[])], body=[], decorator_list=[])]))


# Generated at 2022-06-21 17:36:00.436315
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Assert that visit_ClassDef of MetaclassTransformer compile:
    #   class A(metaclass=B):
    #       pass
    # To:
    #   from six import with_metaclass as _py_backwards_six_withmetaclass
    #   class A(_py_backwards_six_with_metaclass(B)):
    #       pass
    metaclass_node = ast.Name(id='B',
                              ctx=ast.Load())
    metaclass_keyword = ast.keyword(arg='metaclass',
                                    value=metaclass_node)

# Generated at 2022-06-21 17:36:11.065252
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # type: () -> None
    from ..utils.source import source_to_function
    py2_source = """
    class A(object):
        pass
    """
    py2_dest = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(object, A)):
        pass
    """
    transform = MetaclassTransformer()
    assert transform.visit(ast.parse(py2_source)) == ast.parse(py2_dest)
    assert source_to_function(py2_dest, 'A')() == source_to_function(py2_source, 'A')()

# Generated at 2022-06-21 17:36:22.049259
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .base import BaseTestTransformer
    from ..utils.source import source

    class Test(BaseTestTransformer):

        def test(self):
            self.assert_transformation(
                MetaclassTransformer,
                source('''
                class A: pass
                '''),
                source('''
                class A: pass
                ''')
            )
            self.assert_transformation(
                MetaclassTransformer,
                source('''
                class A(metaclass=B): pass
                '''),
                source('''
                from six import with_metaclass as _py_backwards_six_withmetaclass
                class A(_py_backwards_six_withmetaclass(B)): pass
                ''')
            )

    test = Test()
    test.test()

# Generated at 2022-06-21 17:36:23.864657
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    pass


# Generated at 2022-06-21 17:36:24.695382
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    pass

# Generated at 2022-06-21 17:36:38.909370
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import sys
    import six
    from python_modernize import transform  # noqa

    module_str = """
        class MyClass(object):
            pass
    """

    # Python 2.6:
    if sys.version_info < (2, 7):
        assert transform(module_str, MetaclassTransformer) == """
            from six import with_metaclass as _py_backwards_six_withmetaclass


            class MyClass(_py_backwards_six_withmetaclass(object)):
                pass
        """
    else:
        assert transform(module_str, MetaclassTransformer) == """
            class MyClass(object):
                pass
        """

# Generated at 2022-06-21 17:36:40.336479
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast


# Generated at 2022-06-21 17:36:52.250466
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from . import test_utils
    from unittest.mock import MagicMock
    from igraph.python_backward import set_and_check_version_compatibility

    set_and_check_version_compatibility(2, 7)

    # given
    cls = MetaclassTransformer()
    cls.update_tree = MagicMock()

    # when
    cls.visit_ClassDef(
        ast.parse(
            textwrap.dedent("""
            class A(metaclass=B):
                pass
            """)
        ).body[0]
    )

    # then
    cls.update_tree.assert_called_once()
    tree_changed = cls.update_tree.call_args[0][0]
    assert tree_changed

    generated = test_utils.get

# Generated at 2022-06-21 17:36:57.246806
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    with assert_snippet(six_import, 'from six import with_metaclass as _py_backwards_six_withmetaclass') as content:
        node = ast.parse(content)
        new_node = MetaclassTransformer.visit_Module(None, node)

        assert new_node
        assert new_node == node


# Generated at 2022-06-21 17:36:59.885331
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    ast.parse('class A():pass\nclass B(C, metaclass=D):pass\nclass F(E, metaclass=D, is_dumb=True):pass')

# Generated at 2022-06-21 17:37:11.338311
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .six import six_import, class_bases

    class X(ast.NodeVisitor):
        pass

    class A(X):
        def visit_ClassDef(self, node):
            self.assertEqual(
                node.bases,
                class_bases.get_body(metaclass=ast.Name(id='B', ctx=ast.Load()),
                                     bases=ast.List(elts=[ast.Name(id='object', ctx=ast.Load())],
                                                    ctx=ast.Load())))
            self.assertEqual(node.keywords, [])

    six_import_body = six_import.get_body()[0]

# Generated at 2022-06-21 17:37:23.509851
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # type: () -> None
    """Compiles:
        class A(metaclass=B):
            pass
    To:
        class A(_py_backwards_six_with_metaclass(B))
    """
    node = ast_parse("""
    class A(metaclass=B):
        pass
    """)
    transformed = MetaclassTransformer().visit(node)
    assert ast_parse("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """) == transformed

    node = ast_parse("""
    class A(B, metaclass=C):
        pass
    """)

# Generated at 2022-06-21 17:37:27.342358
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    src = """class A(metaclass=B):
                pass"""

# Generated at 2022-06-21 17:37:35.227995
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import parso_interface
    from ..utils.source import source_to_code
    from ..utils.tree import tree_to_str

    source = """class A(metaclass=B):
    pass"""
    expected = """class A(_py_backwards_six_withmetaclass(B)):
    pass"""
    tree = parso_interface.parse(source)
    code = source_to_code(tree)
    assert code == source
    MetaclassTransformer().visit(tree)
    code = source_to_code(tree)
    assert code == expected

# vim: et sw=4 sts=4

# Generated at 2022-06-21 17:37:40.629473
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    mt = MetaclassTransformer()
    mt.visit_Module(ast.parse("class A(metaclass=B):\n    pass"))
    assert mt._tree_changed == 'class A(_py_backwards_six_withmetaclass(B)):\n    pass\n'

# Generated at 2022-06-21 17:37:53.195038
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from tt.errors import TreeTransformationError
    from .base import BaseNodeTransformer


# Generated at 2022-06-21 17:37:57.385523
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse('class C(metaclass=X)')
    MetaclassTransformer().visit(node)
    assert MetaclassTransformer.last_tree == ast.parse('from six import with_metaclass as _py_backwards_six_with_metaclass; class C(_py_backwards_six_with_metaclass(X))')


# Generated at 2022-06-21 17:38:00.481445
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.test_utils import transform_and_compile_snippet

    transform_and_compile_snippet(MetaclassTransformer, """
        class A(metaclass=B):
            pass
        """)



# Generated at 2022-06-21 17:38:04.397292
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast
    source = 'class A(metaclass=B): pass'
    expected = ("from six import with_metaclass as _py_backwards_six_withmetaclass\n"
                "\nclass A(_py_backwards_six_withmetaclass(B)):\n"
                "    pass")
    tree = ast.parse(source)
    MetaclassTransformer(tree).visit(tree)
    got = ast.unparse(tree).strip()
    assert got == expected

# Generated at 2022-06-21 17:38:05.384621
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:38:14.019095
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """Unit test for method visit_Module of class MetaclassTransformer"""
    import astor
    from astor.code_gen import to_source
    source = '''class A(metaclass=B):
        pass'''
    source_expected = six_import.get_source() + '\n' + source
    node = ast.parse(source)
    node_expected = ast.parse(source_expected)
    MetaclassTransformer().visit(node)
    assert to_source(node) == to_source(node_expected)



# Generated at 2022-06-21 17:38:18.443878
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.test_utils import transform

    snippet = """
    class A(metaclass=type):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(type)):
        pass
    """
    transform(snippet, MetaclassTransformer, expected)

# Generated at 2022-06-21 17:38:26.131128
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    for version in ('2.7', '3.4'):
        mt = MetaclassTransformer()
        block = ast.parse('class A(metaclass=B):', version)
        mt.visit(block)
        assert mt.tree_changed  # TODO: remove once PR #122 is merged
        assert len(block.body) == 2
        assert isinstance(block.body[0], ast.Expr)
        assert isinstance(block.body[1], ast.ClassDef)
        assert block.body[1].bases[0].args[0].id == 'B'
        assert block.body[1].bases[0].func.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-21 17:38:32.474095
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from textwrap import dedent
    import unittest
    import astor
    class TestMetaclassTransformer(unittest.TestCase):

        def testConstructor(self):
            t = MetaclassTransformer()

        def test_visit_Module(self):
            source = dedent("""\
                import py_backwards
                class Foo(metaclass=Meta):
                    pass
                """)
            expected = dedent("""\
                from six import with_metaclass as _py_backwards_six_withmetaclass
                import py_backwards
                class Foo(_py_backwards_six_withmetaclass(Meta))
                    pass
                """)
            tree = astor.parse_file(source)
            #print(astor.to_source(tree))
            transformer = Metaclass

# Generated at 2022-06-21 17:38:36.172245
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

    with open('tests/fixtures/metaclass_2.7.py', 'r') as reader:
        code: str = reader.read()
    tree: ast.Module = ast.parse(code)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    print(astor.to_source(tree))

# Generated at 2022-06-21 17:38:52.109376
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_metaclass = ast.ClassDef(name='class_metaclass',
                                   bases=[],
                                   keywords=[],
                                   body=[],
                                   decorator_list=[])
    class_with_metaclass = ast.ClassDef(name='class_with_metaclass',
                                        bases=[],
                                        keywords=[ast.keyword(arg='metaclass',
                                                              value=class_metaclass)],
                                        body=[],
                                        decorator_list=[])
    module = ast.Module(body=[class_with_metaclass, class_metaclass])

# Generated at 2022-06-21 17:38:58.542474
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module: ast.Module = ast.parse('class A(metaclass=B): pass')
    # No need to compile into code since we are only testing parsing
    expected: ast.Module = ast.parse('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)): pass
    ''')
    assert MetaclassTransformer(None).visit_Module(module) == expected


# Generated at 2022-06-21 17:39:09.557314
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..parser import parse
    from ..visitors.filter_visitor import filter_visitor, skip_visitor
    from ..utils.context import Context
    module = parse("class A(B, metaclass=C): pass")
    visitor = MetaclassTransformer(Context(target=(2, 7)))
    skip_visitor(visitor, module)
    assert str(module) == "from six import with_metaclass as _py_backwards_six_withmetaclass\n" \
                          "class A(_py_backwards_six_withmetaclass(metaclass=C, *[B])):\n" \
                          "    pass"

    filter_visitor(visitor, module)

# Generated at 2022-06-21 17:39:20.002666
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Test for creating a snippet for a class definition with a metaclass keyword
    class_with_metaclass = ast.ClassDef(name='A',
                                        bases=[ast.Name(id='object', ctx=ast.Load())],
                                        keywords=[ast.keyword(arg='metaclass',
                                                              value=ast.Name(id='B', ctx=ast.Load()))],
                                        body=[ast.Pass()],
                                        decorator_list=[])

    # Test for creating a snippet for a class definition with a metaclass keyword and bases

# Generated at 2022-06-21 17:39:30.207197
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # 1. Module with class named `A` with metaclass `B`
    metaclass_transformer = MetaclassTransformer()
    class_def = ast.parse(
        "class A(metaclass=B):"
        "    pass"
    )
    class_def = metaclass_transformer.visit(class_def)
    # 2. Class named `A` with _py_backwards_six_with_metaclass
    assert str(class_def) == "class A(_py_backwards_six_withmetaclass(B)): pass"
    # 3. Check if `six` import is added
    assert str(class_def.body[0]) == "from six import with_metaclass as _py_backwards_six_withmetaclass"

# Generated at 2022-06-21 17:39:33.380052
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # Arrange
    # act
    six_t = MetaclassTransformer()

    # Assert
    assert isinstance(six_t, MetaclassTransformer)

# Generated at 2022-06-21 17:39:41.157494
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class_body = [ast.Pass()]
    func_body = [ast.ClassDef(name='B', bases=[ast.Name(id='object', ctx=ast.Load())], keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='type', ctx=ast.Load()))], body=class_body)]
    func_body.append(ast.Expr(value=ast.Name(id='B', ctx=ast.Load())))
    func_body.append(ast.Expr(value=ast.Num(n=42)))
    func_body.append(ast.Expr(value=ast.Name(id='x', ctx=ast.Load())))
    func_body.append(ast.Expr(value=ast.Name(id='y', ctx=ast.Load())))

# Generated at 2022-06-21 17:39:46.723692
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # Test old style class definition
    class A(object):
        """Test old style class
        """
        pass
    # Test new style class defintion
    class C(metaclass=type):
        """Test new style class
        """
        pass
    # Test class definition with metaclass
    class B(object, metaclass=type):
        """Test class with metaclass
        """
        pass

# Generated at 2022-06-21 17:39:56.706683
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from textwrap import dedent
    from ..typing import module_visit
    from ..utils.tree import parse
    m = parse(dedent('''
    class A(metaclass=type):
        pass
    class B(metaclass=B):
        pass'''))
    m, _t = MetaclassTransformer.visit_Module(m)
    assert m == module_visit(dedent('''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(type))
        pass
    class B(_py_backwards_six_withmetaclass(B))
        pass'''), ast.parse)

# Generated at 2022-06-21 17:39:57.331952
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:40:08.897327
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import textwrap
    code = textwrap.dedent("""
    class A(metaclass=B):
        pass
    """)
    result = textwrap.dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    assert MetaclassTransformer().visit(ast.parse(code)) == ast.parse(result)

# Generated at 2022-06-21 17:40:12.290203
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..common import CompilerResult

    source = """
        import six
        class A(metaclass=B):
            pass
        """

    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """

    c = MetaclassTransformer()
    assert expected == c.transform_source(source)



# Generated at 2022-06-21 17:40:16.485010
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    assert MetaclassTransformer(result=dict()).visit_Module(ast.parse('class A(object): pass')) == \
           ast.Module(body=[six_import.get_body()[0], ast.ClassDef(name='A',
                                                                   bases=[ast.Name(id='object',
                                                                                   ctx=ast.Load())],
                                                                   keywords=[],
                                                                   body=[],
                                                                   decorator_list=[])])


# Generated at 2022-06-21 17:40:18.606312
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:40:24.453175
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import check_node_against_source
    assert check_node_against_source(
        MetaclassTransformer,
        r'''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(metaclass=B): pass
        ''',
        r'''
        class A(_py_backwards_six_withmetaclass(B)): pass
        ''',)


# Generated at 2022-06-21 17:40:35.317269
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class_def_module = ast.parse("""
        class X:
            pass
    """)
    class_def = class_def_module.body[0]
    assert isinstance(class_def, ast.ClassDef)
    
    assert '_py_backwards_six_with_metaclass' not in [node.id for node in class_def_module.body]
    ast.fix_missing_locations(class_def_module)
    code = compile(class_def_module, '', 'exec')
    exec(code)
    assert '_py_backwards_six_with_metaclass' not in globals()
    
    class_def_module = ast.parse("""
        class X(metaclass=type):
            pass
    """)
    class_def = class_def_module

# Generated at 2022-06-21 17:40:41.366912
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast

    with six_import.inserted():
        node = ast.parse('''
        class A(metaclass=B):
            pass
        ''')

    with class_bases.inserted():
        MetaclassTransformer().visit(node)

    assert ast.dump(node) == '''\
Module(body=[
    ClassDef(name='A', bases=[
        Call(func=Name(id='_py_backwards_six_with_metaclass', ctx=Load()), args=[
            Name(id='B', ctx=Load())], keywords=[], starargs=None, kwargs=None)], keywords=[], body=[
        Pass()], decorator_list=[])])\
'''
    six_import.remove()
    class_bases.remove()


# Unit test

# Generated at 2022-06-21 17:40:49.777042
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """Unit test for constructor of class MetaclassTransformer
    """
    # setup
    test_input = textwrap.dedent("""
    import six

    class C(metaclass=six.with_metaclass(C)):
        pass
    """)

    # run the test
    test_output = textwrap.dedent("""
    class C(_py_backwards_six_withmetaclass(six.with_metaclass(C))):
        pass
    """)

    assert MetaclassTransformer({2: 7}).transform(test_input) == test_output

# Generated at 2022-06-21 17:41:00.688664
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    class MockTransformer(MetaclassTransformer):
        def __init__(self, before: ast.AST, after: ast.AST) -> None:
            super(MockTransformer, self).__init__()
            self.before = before
            self.after = after
            self.visited = False

        def check_transformed(self, node) -> None:
            self.visited = True
            assert(ast.dump(node) == ast.dump(self.after))

    # No change, no metaclass
    class MyClass:
        pass

    before = ast.parse(inspect.getsource(MyClass))
    after = before
    MockTransformer(before, after).visit(before)

    # Change, metaclass is defined via keyword
    class MyClass(metaclass=type):
        pass



# Generated at 2022-06-21 17:41:09.491360
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    from . import TreeCompareMixin
    from .test_utils import transform

    class TestMetaclassTransformer(TreeCompareMixin):
        transformer = MetaclassTransformer()
        target_tree = astor.parse("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        
        class A(_py_backwards_six_withmetaclass(B, Foo)):
            pass
        """)

        node = astor.parse("""
        class A(metaclass=B, Foo):
            pass
        """).body[0]

    TestMetaclassTransformer().test(transform(TestMetaclassTransformer.node))

# Generated at 2022-06-21 17:41:32.157738
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    
    mt = MetaclassTransformer()
    node = ast.ClassDef(name='Test',
                       bases=[],
                       keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='metaclass'))],
                       body=[])
    assert mt.visit_ClassDef(node)
    assert not mt._tree_changed
    
    expected = ast.ClassDef(name='Test',
                       bases=[ast.Call(func=ast.Name(id='_py_backwards_six_withmetaclass'),
                                       args=[ast.Name(id='metaclass')], keywords=[], starargs=None, kwargs=None)],
                       keywords=[],
                       body=[])
    assert node == expected

    mt = MetaclassTransformer()
   

# Generated at 2022-06-21 17:41:38.069294
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys
    import ast as _ast
    sys.version_info = (3, 6)

    source = '''class C:
    def __init__(self):
        self.class_name = __class__.__name__
'''

# Generated at 2022-06-21 17:41:44.394437
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ...tests.support.asserts import assert_node
    from ..py3_utils import SourceLoader
    from .. import sources
    from .. import codegen

    tr = MetaclassTransformer()


# Generated at 2022-06-21 17:41:45.204956
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:41:51.069067
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import sys

    from typed_ast.ast3 import Module
    from py_backwards.transformers.six import MetaclassTransformer
    from py_backwards.utils.snippet import snippet

    @snippet
    def simple_module():
        from six import with_metaclass as _py_backwards_six_with_metaclass
        class A(metaclass=int):
            pass


# Generated at 2022-06-21 17:41:56.163586
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .test_utils import assert_equal_ignore_ws
    from .test_utils import transform

    node = ast.parse('''
        class A(metaclass=int):
            pass
    ''')

    transformed = transform(MetaclassTransformer, node)

    assert_equal_ignore_ws(transformed, '''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(int)):
            pass
    ''')

# Generated at 2022-06-21 17:41:57.442143
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer(tree=None, filename='')

# Generated at 2022-06-21 17:42:01.325665
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    metaclass_transformer = MetaclassTransformer()

# Generated at 2022-06-21 17:42:10.633527
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Test with keyword arguments
    six_import_snippet = six_import.get_body()
    class_bases_snippet = class_bases.get_body(metaclass="ABC",
                                               bases=ast.List(elts=[]))
    module = ast.parse("class A(object, metaclass=ABC): pass")
    class_keyword = module.body[0].keywords[0]
    class_keyword.value = ast.Name(id="ABC", ctx=ast.Load())
    # Test with no keyword arguments
    no_args_module = ast.parse("class A(object): pass")

    # Test with keyword arguments
    transformer = MetaclassTransformer()
    transformer.visit(module)
    assert len(module.body) == 2

# Generated at 2022-06-21 17:42:12.030781
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:42:51.869112
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    m = ast.parse('class A(metaclass=B): pass')
    s = six_import.get_body()[0]
    a = ast.parse('A')
    assert MetaclassTransformer(m).visit(m) == ast.Module(body=[s,
        ast.ClassDef(name='A',
        bases=[ast.Call(func=ast.Name(id='_py_backwards_six_withmetaclass', ctx=ast.Load()),
        args=[ast.Name(id='B', ctx=ast.Load()), ast.Name(id='A', ctx=ast.Load())], keywords=[], starargs=None, kwargs=None)],
        keywords=[],
        body=[ast.Pass()],
        decorator_list=[])])

# Generated at 2022-06-21 17:43:03.264692
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclass_transformer = MetaclassTransformer()
    class_def = ast.parse("""
    class A(B, metaclass=C):
        pass
    """).body[0]
    clsdef = metaclass_transformer.visit(class_def)
    assert isinstance(clsdef, ast.ClassDef)

# Generated at 2022-06-21 17:43:05.575958
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert str(MetaclassTransformer) == str(MetaclassTransformer())

# Generated at 2022-06-21 17:43:12.934432
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ast import parse
    from .module_renamer import ModuleRenamer
    from ...utils.snippet import snippet
    
    target = (2, 7)
    m = parse('''
    class A(metaclass=B): pass 
    ''')
    n = parse('''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)): pass
    ''')
    transformer = MetaclassTransformer(target_version=target)
    transformer.visit(m)
    ModuleRenamer().visit(m)
    assert m == n


# Generated at 2022-06-21 17:43:20.424401
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from textwrap import dedent
    from typed_ast.ast3 import parse
    from typing import List
    from .base import BaseNodeTestCase
    from .base import NodeTestCase, NodeTransformerTestCase, GenericNodeTestCase
    from six import assertRaisesRegex
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    from .base import BaseNodeTestCase
    from .base import NodeTestCase, NodeTransformerTestCase, GenericNodeTestCase
    from six import assertRaisesRegex
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-21 17:43:21.100734
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:43:25.449196
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3

# Generated at 2022-06-21 17:43:26.958103
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:43:30.634738
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source

    module = source("""
    class A(metaclass=B):
        pass
    """)
    assert module == MetaclassTransformer().visit(module)

# Generated at 2022-06-21 17:43:37.551805
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    input = """class A(metaclass=B): pass"""
    expected = """class A(_py_backwards_six_withmetaclass(B)): pass"""
    transformer = MetaclassTransformer()
    tree = ast.parse(input)
    transformer.visit(tree)
    result = astor.to_source(tree).strip()
    print(result)
    assert result == expected

# Generated at 2022-06-21 17:44:39.378614
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-21 17:44:43.203932
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse("class A():pass\nclass B():pass")
    expected_module = ast.parse("from six import with_metaclass as _py_backwards_six_withmetaclass\n\n\nclass A():\n    pass\n\n\nclass B():\n    pass")
    MetaclassTransformer().visit(module)
    assert ast.dump(module, False) == ast.dump(expected_module, False)


# Generated at 2022-06-21 17:44:50.820439
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import types
    import astor
    import six
    node = """
        class Test(metaclass=type):
            pass
        """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class Test(_py_backwards_six_withmetaclass(type)):
            pass
        """

    module = ast.parse(node)
    MetaclassTransformer().visit(module)
    assert astor.to_source(module) == expected

# Generated at 2022-06-21 17:44:57.435321
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import textwrap
    source = textwrap.dedent("""
    class B(metaclass=type):
        pass
    """).lstrip()
    expected = textwrap.dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class B(_py_backwards_six_withmetaclass(type)):
        pass
    """).lstrip()
    node = ast.parse(source)
    metaclass_transformer = MetaclassTransformer()
    new_node = metaclass_transformer.visit(node)
    assert ast.dump(new_node) == expected


# Generated at 2022-06-21 17:45:07.560821
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    node = astor.parse_file(__file__)
    assert isinstance(node, ast.Module)
    assert len(node.body) > 10
    mt = MetaclassTransformer()
    mt.visit(node)
    mt.visit(node)
    assert mt._tree_changed == False
    
    # Test that visit_Module works
    six_import_body = six_import.get_body()
    node = astor.parse_file(__file__)
    assert isinstance(node, ast.Module)
    assert len(node.body) > 10
    mt = MetaclassTransformer()
    mt.visit(node)
    assert len(node.body) > 10
    assert node.body[0] == six_import_body[0]
    assert node.body