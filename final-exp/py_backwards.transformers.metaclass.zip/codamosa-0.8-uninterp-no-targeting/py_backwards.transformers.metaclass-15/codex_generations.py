

# Generated at 2022-06-21 17:35:25.443035
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    input = \
    """
    class A:
        pass
    """
    output = \
    """
    class A(_py_backwards_six_withmetaclass(object, *())):
        pass
    """
    tree = ast.parse(input)
    tree = MetaclassTransformer().visit(tree)
    assert astor.to_source(tree).strip() == output.strip()

# Generated at 2022-06-21 17:35:27.960188
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:35:39.217417
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from _fixtures.metaclass import module
    from .test_utils import NodeAssertionHelper

    NodeAssertionHelper.compare_source(MetaclassTransformer().visit(module),
                                       '''
                                       from six import with_metaclass as _py_backwards_six_withmetaclass
                                       
                                       
                                       class A:
                                           pass
                                       class B(object):
                                           pass
                                       class C(object):
                                           pass
                                       class D(A, B, C, metaclass=C):
                                           pass
                                       ''')

# Generated at 2022-06-21 17:35:43.399902
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..testing import check_in, check_out
    check_in("import sys",
             MetaclassTransformer(2, 7, 'six').visit(ast.parse("import sys")))
    check_out("from six import with_metaclass as _py_backwards_six_withmetaclass\nimport sys",
              MetaclassTransformer(2, 7, 'six').visit(ast.parse("import sys")))


# Generated at 2022-06-21 17:35:51.912851
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = textwrap.dedent("""
    class MyClass(metaclass=Meta):
        pass
    """)
    module = ast.parse(code)
    node = MetaclassTransformer().visit(module)
    assert isinstance(node, ast.Module)
    assert len(six_import.get_body()) == len(node.body)
    assert ast.dump(six_import.get_body()[0]) == ast.dump(node.body[0])
    assert ast.dump(six_import.get_body()[1]) == ast.dump(node.body[1])



# Generated at 2022-06-21 17:35:57.883481
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .transform import transform
    import astunparse
    input = """
        class A(metaclass=B):
            pass
        """
    expected = """
        import six
        class A(six.with_metaclass(B)):
            pass
        """
    expected_ast = ast.parse(expected)

    node = ast.parse(input)
    new_node = transform(node, MetaclassTransformer)

    assert astunparse.unparse(expected_ast) == astunparse.unparse(new_node)


# Generated at 2022-06-21 17:35:59.175261
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    import textwrap

# Generated at 2022-06-21 17:36:05.165377
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils import parse

    code = 'class A(metaclass=B): pass'

# Generated at 2022-06-21 17:36:12.337416
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import os
    import sys

    sys.path.insert(0, os.path.dirname(__file__))

    from . import snippet

    metaclass_transformer = MetaclassTransformer()

    code = snippet.class_with_metaclass_def.dedent()
    node = ast.parse(code)

    node = metaclass_transformer.transform(node)

    ref_code = snippet.class_with_metaclass_def_2_to_3.dedent()
    ref_node = ast.parse(ref_code)

    assert ast.dump(node) == ast.dump(ref_node)

# Generated at 2022-06-21 17:36:14.924684
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    from . import get_test_ast

    # Given

# Generated at 2022-06-21 17:36:23.183028
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .utils import round_trip
    code = """
    class C(metaclass=A):
        pass
    """
    tree = ast.parse(code)
    tr = MetaclassTransformer()
    transformed_tree = tr.visit(tree)
    transformed_code = round_trip(transformed_tree)
    assert transformed_code == """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class C(_py_backwards_six_withmetaclass(A)):
        pass
    """

# Generated at 2022-06-21 17:36:26.332057
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse('''class A(metaclass=B): pass''')
    visitor = MetaclassTransformer()
    visitor.visit(node)
    expected = ast.parse('''\
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass''')
    assert(ast.dump(node) == ast.dump(expected))


# Generated at 2022-06-21 17:36:34.037292
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    six_module = six_import.get_module()
    with_metaclass_func = six_module.body[0].value
    class_bases_module = class_bases.get_module(metaclass=with_metaclass_func,
                                                bases=ast.List(elts=[]))
    """
    original_tree = ast.parse('class Foo(object): pass')

    compiled_tree = MetaclassTransformer().visit(original_tree)

    assert compiled_tree == class_bases_module
    """
    import sys
    if sys.version_info > (3, 4):
        # ast.parse(str) is only available in 3.4+
        original_tree = ast.parse('class Foo(object): pass')


# Generated at 2022-06-21 17:36:40.213026
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse('class A(metaclass=B):\n    pass')
    assert str(module) == 'class A(metaclass=B):\n    pass\n'
    with MetaclassTransformer() as transform:
        transform(module)
    assert str(module) == 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass\n'

# Generated at 2022-06-21 17:36:48.288301
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("class A(metaclass=B): pass")
    q = MetaclassTransformer()
    new_code = q.visit(node)
    assert ast.dump(new_code) == "from six import with_metaclass as _py_backwards_six_withmetaclass\n\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass"

# Generated at 2022-06-21 17:36:54.817174
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()
    node = ast.parse("class A(metaclass=B): pass")
    result = transformer.visit(node)

# Generated at 2022-06-21 17:37:02.735627
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from six import with_metaclass

    # Here is the code:
    class MyMeta(type):
        pass
    class MyClass(object, metaclass=MyMeta):
        pass

    # Here is the above code represented as an AST
    class_def = ast.ClassDef(name='MyClass',
                             bases=[ast.Name(id='object', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='MyMeta',
                                                                  ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

    # Here is the above code transformed with our transformer
    transformed = MetaclassTransformer().visit(class_def)

# Generated at 2022-06-21 17:37:13.245014
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.visitor import dump


# Generated at 2022-06-21 17:37:23.360508
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..._compat import IS_PY3, IS_PY38_PLUS
    if not IS_PY3:
        # skip test when python2
        return
    if IS_PY38_PLUS:
        # skip test when python >= 3.8
        return
    import inspect
    import ast
    # Assert that we are testing the correct method
    assert 'visit_ClassDef' == inspect.currentframe().f_code.co_name
    module_ast = ast.parse('class A(metaclass=B):\n    pass\n')

# Generated at 2022-06-21 17:37:24.818943
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:37:39.911196
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Create module object, and call the method to test.
    node = ast.parse('''
        class A(metaclass=B):
            pass
        ''')
    t = MetaclassTransformer()
    t.visit(node)
    # Compare the result.
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    assert node == ast.parse(expected)


# Generated at 2022-06-21 17:37:50.840974
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import parse
    from ..instructions import patch_ast
    from ..utils.transform import Transformer
    import ast
    import six

    tree = parse('class A(metaclass = None): pass')  # type: ignore
    assert isinstance(tree.body[0].keywords[0].value, ast.NameConstant)
    six.add_move(tree)
    transformer = Transformer([MetaclassTransformer])
    patched = patch_ast(tree, transformer)
    assert isinstance(patched.body[0].bases[0], ast.Call)
    assert patched.body[0].bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert patched.body[0].keywords == []


# Generated at 2022-06-21 17:37:55.358510
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    from ..utils.tree import node2str

    class A(metaclass=type):
        pass

    node = ast.parse(inspect.getsource(A))

    m = MetaclassTransformer()
    result = m.visit(node)

# Generated at 2022-06-21 17:38:02.906374
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.compile import make_function
    from .base import BaseNodeTransformerTestCase
    
    class TestMetaclassTransformer(BaseNodeTransformerTestCase):
        transformer = MetaclassTransformer
        # Method visit_ClassDef of class MetaclassTransformer
        def test_ClassDef_has_metaclass(self):
            code = """
                class A(metaclass=B):
                    pass"""
            module = ast.parse(code)
            expected_code = """
                from six import with_metaclass as _py_backwards_six_withmetaclass
                class A(_py_backwards_six_withmetaclass(B, object)):
                    pass"""
            expected_module = ast.parse(expected_code)
            module = self._

# Generated at 2022-06-21 17:38:04.168007
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:38:06.007998
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.testing import assert_source


# Generated at 2022-06-21 17:38:06.982018
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:38:14.391434
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast27 as ast
    from ..utils.compiler import compile_to_str

    module = ast.parse("""
    class A(metaclass=B, object):
        pass
    """)  # type: ast.Module

    res = compile_to_str(module,
                         transformers=[MetaclassTransformer])

    print(res)

    assert '_py_backwards_six_with_metaclass(B)' in res

# Generated at 2022-06-21 17:38:24.938086
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    '''
        class B:
            pass
        class A(metaclass=B):
            pass
    '''
    test_classDef_B = ast.ClassDef(name='B', bases=[], keywords=[],
                                  body=[], decorator_list=[], starargs=None, kwargs=None)
    test_classDef_A = ast.ClassDef(name='A', bases=[], keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
                                  body=[], decorator_list=[], starargs=None, kwargs=None)
    test_module = ast.Module(body=[test_classDef_B, test_classDef_A])
    metaclass_transformer = MetaclassTransformer()

    # check ClassDef

# Generated at 2022-06-21 17:38:32.808566
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    import os

    def test(in_lines, out_lines):
        in_ast = astor.parse_file(os.linesep.join(in_lines))
        class_idx = None
        for idx, node in enumerate(in_ast.body):
            if isinstance(node, ast.ClassDef):
                class_idx = idx
                break

        assert class_idx is not None

        transformer = MetaclassTransformer()
        class_def: ast.ClassDef = transformer.visit(in_ast)
        assert transformer._tree_changed == True
        out_ast = ast.Module(body=[class_def])
        assert astor.to_source(out_ast) == os.linesep.join(out_lines)


# Generated at 2022-06-21 17:38:54.727997
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast.ast3 import parse
    tree = parse("""
    class A(metaclass=B):
        pass
    """)

    transformer = MetaclassTransformer()
    new = transformer.visit(tree)
    assert transformer._tree_changed

    # Ensure that we have the import statement
    import_statement = new.body[0]
    assert isinstance(import_statement, ast.ImportFrom)
    assert import_statement.module == 'six'
    assert import_statement.names[0].name == 'with_metaclass'
    assert import_statement.names[0].asname == '_py_backwards_six_withmetaclass'

    # Ensure that the class definition has been modified
    class_definition = new.body[1]
    assert isinstance(class_definition, ast.ClassDef)

# Generated at 2022-06-21 17:39:06.000521
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    node = ast.parse('class T(metaclass=type, base=int): pass')
    MetaclassTransformer().visit(node)

# Generated at 2022-06-21 17:39:13.676585
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import Source
    from ..utils.ast import get_ast, get_code
    from ..utils import namespace

    src = """
    class A(metaclass=B):
        pass
    """

    ast_ = get_ast(src)
    m = MetaclassTransformer()
    res = namespace(**m.visit(ast_))

    expected_src = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    expected_ast = get_ast(expected_src)

    assert get_code(res.body[1]) == get_code(expected_ast.body[1])

# Generated at 2022-06-21 17:39:18.366313
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from six import with_metaclass
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from .parser import parse
    from ..utils.code_data import Snippets

    snippets = Snippets()
    snippet = snippets.add_snippet

# Generated at 2022-06-21 17:39:29.590552
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert six_import.get_code() == 'from six import with_metaclass as _py_backwards_six_withmetaclass'
    assert class_bases.get_code() == '_py_backwards_six_withmetaclass(metaclass, *bases)'
    snippet_globals = {'_py_backwards_six_withmetaclass': six_import.get_body()[0],
                       'metaclass': ast.Name(id='B', ctx=ast.Load()),
                       'bases': ast.List(elts=[ast.Name(id='Parent', ctx=ast.Load())])}

# Generated at 2022-06-21 17:39:36.704988
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class_example = ast.parse("""
                             class A(metaclass=B):
                                 pass
                         """, mode='exec')


    result = MetaclassTransformer().visit(class_example)
    expected_result = ast.Module(
        body=[ast.ImportFrom(module='six', names=[ast.alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')],
                             level=0)], type_ignores=[])

    assert result == expected_result

# Generated at 2022-06-21 17:39:41.552655
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = 'class A(metaclass=B): pass'
    module = ast.parse(code)
    transformed = MetaclassTransformer(make_tree_changed=True).visit(module)
    expected = ast.parse("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    assert ast.dump(expected, include_attributes=True) == ast.dump(transformed, include_attributes=True)

# Generated at 2022-06-21 17:39:46.811167
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast.parse("""
        class A(metaclass=B):
            pass
        """)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    compiled = compile(tree, '<test>', 'exec')
    assert '_py_backwards_six_withmetaclass' in compiled.co_names

# Generated at 2022-06-21 17:39:53.388245
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast
    from astunparse import unparse
    from targets import targets
    from backwards.transformers import MetaclassTransformer
    from backwards.compat import ast_parse

    code = 'class A(metaclass=B): pass'
    tree = MetaclassTransformer(targets['2.7']).visit(ast_parse(code))

    assert ast.dump(tree) == ast.dump(ast_parse(unparse(tree)))

# Generated at 2022-06-21 17:39:54.569489
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast.ast3 import parse

# Generated at 2022-06-21 17:40:19.235092
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    snippet._template_white_space_mode = 'strip'
    t = MetaclassTransformer()

    node = ast.parse(six_import)

    result = t.visit_Module(node)

    assert ast.dump(result, include_attributes=False) == ast.dump(six_import.get_tree(), include_attributes=False)


# Generated at 2022-06-21 17:40:22.622058
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3
    from .util import Checker

    checker = Checker()
    checker.add_transformer(MetaclassTransformer)


# Generated at 2022-06-21 17:40:34.369280
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # type: () -> None
    from six.moves import reload_module
    import astor
    import astunparse
    reload_module(six_import)
    class ClassWriter(ast.NodeVisitor):
        def __init__(self):
            # type: () -> None
            self.__nodes = []

        def generic_visit(self, node):
            # type: (ast.AST) -> None
            self.__nodes.append(node)
            ast.NodeVisitor.generic_visit(self, node)

        @property
        def nodes(self):
            # type: () -> List[ast.AST]
            return self.__nodes

    x = ast.parse('class A(metaclass=B): pass', mode='exec')
    f = ast.Module(body=x)
   

# Generated at 2022-06-21 17:40:35.689474
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast


# Generated at 2022-06-21 17:40:44.798899
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    src = """
        class A(metaclass=B):
            pass
    """

    module = ast.parse(src)
    visitor = MetaclassTransformer(module)
    visitor.visit(module)

    assert module._fields == ('body',)
    assert len(module.body) == 2
    assert isinstance(module.body[0], ast.FunctionDef)
    assert module.body[0].name == '_py_backwards_six_withmetaclass'
    assert module.body[0].args.a

# Generated at 2022-06-21 17:40:47.935206
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.get_code import get_code

    assert get_code(ast.parse('class A(metaclass=B): pass')) == 'class A: pass'

# Generated at 2022-06-21 17:40:57.880598
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    code = "class A(metaclass=int, object=3):\n    pass"
    expected = "from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(int, object=3)):\n    pass"
    root = ast.parse(code)
    MetaclassTransformer(None).visit(root)
    result = astor.to_source(root)
    assert result == expected

# Generated at 2022-06-21 17:41:06.966895
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = """
       class A(metaclass=type):
            pass
       """
    expected = """
       from six import with_metaclass as _py_backwards_six_withmetaclass
       class A(_py_backwards_six_withmetaclass(type, object)):
            pass
       """
    tree = ast.parse(code)
    mt = MetaclassTransformer()
    mt.visit(tree)
    assert mt.is_changed()
    assert astunparse.unparse(tree).strip() == expected.strip()

# Generated at 2022-06-21 17:41:14.934717
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import unparsed

    source = """
        class A(object):
            x = 1
    """
    tree = MetaclassTransformer.run(source)
    assert tree == unparsed("""
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(object)):
            x = 1
    """)

# Generated at 2022-06-21 17:41:19.782943
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as typed_ast
    tree = '''class A(metaclass=type):
    pass'''
    tree = typed_ast.parse(tree)
    transformer = MetaclassTransformer()
    tree = transformer.visit(tree)
    assert typed_ast.dump(tree) == '''_py_backwards_six_with_metaclass(type)
'''

# Generated at 2022-06-21 17:41:38.765259
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-21 17:41:39.966731
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()

# Generated at 2022-06-21 17:41:46.818694
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Create an instance of a parser and parse some Python code
    parser = ast.Python2Parser()
    node = parser.parse('''
        class A(object):
            __metaclass__ = abc.ABCMeta
            pass
        class B(object):
            pass
    ''')

    # Optimize the AST
    mt = MetaclassTransformer()
    mt.visit(node)

    # Here is the modified AST in Python syntax
    print(ast.dump(node, include_attributes=True))

# Generated at 2022-06-21 17:41:50.673070
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-21 17:41:52.042264
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:41:59.442498
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .utils import transform
    from ..utils.tree import get_tree_string
    import ast
    code = 'class X(metaclass=Foo):\n    pass'
    tree = ast.parse(code)
    assert get_tree_string(tree) == code

    tree = transform(MetaclassTransformer, tree)
    assert isinstance(tree.body[0], ast.ImportFrom)

# Generated at 2022-06-21 17:42:07.283732
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert (MetaclassTransformer.construct().visit(
        ast.parse('''
            class A(metaclass=B):
                pass
            ''')
    ) == ast.parse('''
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A(_py_backwards_six_withmetaclass(B, )):
                pass
            '''))

# Generated at 2022-06-21 17:42:18.034894
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Tests the method `visit_ClassDef` of the class MetaclassTransformer."""
    # The metaclass is explicitly given as keyword argument.
    tree = ast.parse("class A(object, metaclass=B): pass")
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert str(tree) == "class A(_py_backwards_six_withmetaclass(B, object)): pass"

    # The metaclass is explicitly given as positional argument.
    tree = ast.parse("class A(B): pass")
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert str(tree) == "class A(_py_backwards_six_withmetaclass(B)): pass"

    # The class does not have a metaclass.


# Generated at 2022-06-21 17:42:25.239027
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    ast_nodes = """
    class A(object):
        def __init__(self):
            pass

    class B(metaclass=A):
        pass
    """.split('\n')  # type: ignore
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(object):
        def __init__(self):
            pass


    class B(_py_backwards_six_withmetaclass(A, )):
        pass
    """.split('\n')  # type: ignore
    expected = '\n'.join([i for i in expected if i.strip()])
    ast_nodes = [i for i in ast_nodes if i.strip()]
    ast_nodes = astor.parse

# Generated at 2022-06-21 17:42:28.198658
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-21 17:43:16.136735
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils import ctx
    from .base import BaseNodeTransformer
    from .metaclass import MetaclassTransformer
    from ..utils.tree import parse


# Generated at 2022-06-21 17:43:24.483750
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import sys
    from .base import BaseNodeTransformer
    from ... import compile
    source = '''
        class A(metaclass=B):
            pass
    '''
    result = compile(source, BaseNodeTransformer.target)
    assert sys.version_info < BaseNodeTransformer.target, "This should only run on Python 2.7"
    assert result == '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    '''
    return result


# Generated at 2022-06-21 17:43:31.433616
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .fake_ast import parse_ast_tree, ast_tree_to_str

    print(
'''class A(metaclass=int):
    pass
''')
    tree = parse_ast_tree(
'''class A(metaclass=int):
    pass
''')

# Generated at 2022-06-21 17:43:36.661667
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    class ret(BaseNodeTransformer):
        def visit_ClassDef(self, node):
            return node

# Generated at 2022-06-21 17:43:47.713065
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from nose.tools import assert_equal
    from typed_ast import ast3 as ast
    t = MetaclassTransformer()
    tree = ast.parse('class A(metaclass=B): pass')
    t.visit(tree)

# Generated at 2022-06-21 17:43:53.352716
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """Test that 'class A(metaclass=B):' is transformed to
    'class A(_py_backwards_six_with_metaclass(B))'
    """
    from ...testing.utils import build_visitor_test

# Generated at 2022-06-21 17:44:04.268472
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing_utils import test_transformer_visit
    from typed_ast import ast3
    from . import helpers
    from .helpers import make_class

    class Example(ast3.AST):
        _fields = ('keywords', 'bases')

        def __init__(self, keywords=[], bases=None):
            self.keywords = keywords
            self.bases = bases

    keywords = [ast3.keyword(arg='metaclass', value=ast3.Name(id='B', ctx=ast3.Load()))]

    bases = [ast3.Name(id='object', ctx=ast3.Load())]

    example_with_metaclass = Example(keywords=keywords, bases=bases)


# Generated at 2022-06-21 17:44:09.230959
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    t = MetaclassTransformer(None, ast.parse('pass'), 'pass', '<test>')
    node = ast.Module(body=['test'])
    t.visit_Module(node)
    assert node.body == [ast.Expr(value=six_import.get_body()[0]), 'test']


# Generated at 2022-06-21 17:44:16.334027
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("class A(metaclass=B): pass")
    transformer = MetaclassTransformer(node)
    simple_node = transformer.visit(node)
    assert transformer._tree_changed
    code = compile(simple_node, filename='', mode='exec')
    exec(code)
    assert 'A' in globals()
    assert A.__bases__ == (B,)

# Generated at 2022-06-21 17:44:24.454523
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_in, assert_equal_ast, assert_not_in
    from typed_ast import ast3 as ast

    class MockNode(ast.AST):
        _fields = ()

    import typing
    assert_in('six', {x.__name__ for x in typing.get_type_hints(MockNode).values()})

    code = """
    class A(object):
        pass
    """
    tree = ast.parse(code)  # type: ast.Module
    new_tree = MetaclassTransformer().visit(tree)
    assert_equal_ast(new_tree, ast.parse(code))

    code = """
    class A(metaclass=B):
        pass
    """
    tree = ast.parse(code)  # type: ast.Module
   