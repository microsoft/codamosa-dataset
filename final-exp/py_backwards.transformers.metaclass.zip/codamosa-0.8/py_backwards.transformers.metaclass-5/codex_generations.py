

# Generated at 2022-06-12 03:39:59.030421
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.snippet import snippet
    from ..utils.sample import sample

    @snippet
    def input_code():
        class A(metaclass=B):
            pass

    output_code = astor.to_source(six_import.get_body()) + '\n' + astor.to_source(class_bases.get_body()) + '\n' + astor.to_source(sample.get_body())

    mt = MetaclassTransformer()
    assert astor.to_source(mt.visit(input_code.get_ast())) == output_code

# Generated at 2022-06-12 03:40:00.147714
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:40:04.323801
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
    class A(metaclass=B):
        pass
    """
    node = ast.parse(code)
    MetaclassTransformer().visit(node)
    assert str(node) == """\
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

# Generated at 2022-06-12 03:40:08.190877
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = """class A(metaclass=int):
        pass
    """

# Generated at 2022-06-12 03:40:17.688901
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.fixtures import six_import, class_bases
    from ..utils.test_utils import check_in, check_not_in, check_equal
    from .fixtures import metaclass_transformer, metaclass_transformer_with_six

    for transformer in metaclass_transformer_with_six, metaclass_transformer:
        check_in(transformer, '_py_backwards_six_with_metaclass')
        check_equal(transformer, class_bases.get_ast('class_bases'))

    check_equal(metaclass_transformer_with_six, six_import.get_ast('six_import'))
    check_not_in(metaclass_transformer, '_py_backwards_six_with_metaclass')

    check_equal

# Generated at 2022-06-12 03:40:18.732434
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-12 03:40:19.555227
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:40:29.483768
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.unparse import Unparser
    from ..utils.source import source
    from ..utils.parse import parse
    import six
    node = parse(source)
    metaclass_transformer = MetaclassTransformer(six_ast=six.moves.builtins.__dict__["__import__"]("typed_ast"), version=(2, 7))
    metaclass_transformer.visit(node)
    unparser = Unparser(node)
    print(unparser.unparse())
    assert "\n".join(unparser.unparse().split("\n")[:6]) == "from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass"

# Unit test

# Generated at 2022-06-12 03:40:35.440483
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """MetaclassTransformer does not change a class definition without metaclass"""
    
    from ..utils.syntax import equals
    original_case = """
    class A():
        pass
    """
    transformer = MetaclassTransformer()
    module = transformer.visit(ast.parse(original_case))
    
    assert equals(module, original_case) is True
    assert transformer.tree_changed is False


# Generated at 2022-06-12 03:40:39.866069
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = ("""class A(metaclass=B, arg=val):\n""")
    module = ast.parse(code)
    node = module.body[0]

    # When
    transformer = MetaclassTransformer()
    transformer.visit(module)

    # Then
    assert module.body[0].bases[0].args[0].id == 'B'

# Generated at 2022-06-12 03:40:48.030973
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code_lines_before = [
        "class A(metaclass=B):",
        "    pass",
    ]
    code_lines_after = [
        "from six import with_metaclass as _py_backwards_six_withmetaclass",
        "class A(_py_backwards_six_withmetaclass(B)):",
        "    pass",
    ]
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(ast.parse('\n'.join(code_lines_before)))
    assert not metaclass_transformer._tree_changed
    metaclass_transformer.dependencies.clear()
    metaclass_transformer.visit(ast.parse('\n'.join(code_lines_before)))
    assert metaclass_

# Generated at 2022-06-12 03:40:56.429084
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node_ClassDef = ast.ClassDef(name='A',
                                 args=ast.arguments(
                                     args=[],
                                     vararg=None,
                                     kwonlyargs=[],
                                     kw_defaults=[],
                                     kwarg=None,
                                     defaults=[]),
                                 body=[],
                                 decorator_list=[],
                                 keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B',
                                                                                       ctx=ast.Load()))])
    node_ClassDef = MetaclassTransformer().visit(node_ClassDef)
    assert isinstance(node_ClassDef, ast.ClassDef)
    assert str(node_ClassDef.bases) == '_py_backwards_six_withmetaclass(B, )'

# Generated at 2022-06-12 03:41:03.237959
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = 'class A(metaclass=B): pass'
    expected_code = 'from six import with_metaclass as _py_backwards_six_with_metaclass\nclass A(_py_backwards_six_with_metaclass(B)): pass'
    transformer = MetaclassTransformer()
    node = ast.parse(code)
    new_node = transformer.visit(node)
    assert transformer._tree_changed
    assert ast.dump(new_node) == ast.dump(ast.parse(expected_code))

# Generated at 2022-06-12 03:41:06.059112
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3 as ast
    from ast_helpers import dump_ast, assert_ast_equal


# Generated at 2022-06-12 03:41:13.993471
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import check_node_changed, check_node_not_changed
    check_node_changed(MetaclassTransformer, """
    class A(metaclass=B):
        pass
    """, """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)

    check_node_not_changed(MetaclassTransformer, """
    class A:
        pass
    """)

# Generated at 2022-06-12 03:41:19.037935
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = """class Level(metaclass=Meta): pass"""
    expected = """class Level(_py_backwards_six_withmetaclass(Meta)): pass"""

    tree = ast.parse(source)
    visitor = MetaclassTransformer()
    for node in ast.walk(tree):
        visitor.visit(node)

    assert ast.dump(tree) == expected



# Generated at 2022-06-12 03:41:20.698792
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_nodes
    

# Generated at 2022-06-12 03:41:30.024254
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclass = ast.Name(id='B')
    bases = ast.List(elts=[ast.Name(id='C'), ast.Name(id='D')])

    class_def = ast.ClassDef(name='A',
                             bases=[metaclass],
                             keywords=[ast.keyword(arg='metaclass', value=metaclass)],
                             body=[ast.Pass()],
                             decorator_list=[])

    at_class_def = ast.ClassDef(name='A',
                                bases=[bases],
                                keywords=[],
                                body=[ast.Pass()],
                                decorator_list=[])


# Generated at 2022-06-12 03:41:36.201122
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast

    class TestMetaclassTransformer(MetaclassTransformer):
        def visit_ClassDef(self, node):
            return super().visit_ClassDef(node)

    tree = ast.parse('class a(metaclass=b): pass')
    tree = MetaclassTransformer().visit(tree)
    assert 'from six import with_metaclass as _py_backwards_six_withmetaclass' in ast.dump(tree)
    assert '_py_backwards_six_withmetaclass(b,)' in ast.dump(tree)

# Generated at 2022-06-12 03:41:42.726071
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.snippet import snippet
    snippet_1 = snippet('''\
    class A(metaclass=B):
        pass
    ''')
    snippet_2 = snippet('''\
    class A(_py_backwards_six_with_metaclass(B, object)):
        pass
    ''')
    assert MetaclassTransformer(2, 7)(snippet_1.get_ast()).as_string() == snippet_2.get_body()

# Generated at 2022-06-12 03:41:55.770529
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.ClassDef(name='A',
                        bases=[ast.Name(id='object', ctx=ast.Load())],
                        keywords=[ast.keyword(arg='metaclass',
                                              value=ast.Name(id='B', ctx=ast.Load()))],
                        body=[ast.Pass()],
                        decorator_list=[])
    expected_node = ast.ClassDef(name='A',
                                 bases=class_bases.get_body(metaclass=ast.Name(id='B', ctx=ast.Load()),
                                                            bases=ast.List(elts=[ast.Name(id='object', ctx=ast.Load())])),
                                 keywords=[],
                                 body=[ast.Pass()],
                                 decorator_list=[])

    visitor = Metaclass

# Generated at 2022-06-12 03:42:05.853988
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import Assign, ClassDef, Expr, If, Load, Module, Name, NameConstant, Num, Pass, Str, Tuple, With
    import unittest

    class Test(unittest.TestCase):
        def test_a(self):
            mt = MetaclassTransformer()
            input = Module(body=[ClassDef(name='A',
                                          bases=[Name(id='B', ctx=Load())],
                                          keywords=[],
                                          body=[Pass()],
                                          decorator_list=[])])

# Generated at 2022-06-12 03:42:10.460628
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """
    Test visit_ClassDef method of class MetaclassTransformer.
    """
    MetaclassTransformer().visit(
        ast.parse(
            """
            class A(metaclass=B):
                pass
            """
        )
    ) == """
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

# Generated at 2022-06-12 03:42:20.676080
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test import test_transformer
    from ..utils.test import assert_source
    from ..utils.test import assert_node

    source = '''\
    from six import with_metaclass
    class A(metaclass=type):
        pass'''

    expected = '''\
    from six import with_metaclass
    class A(with_metaclass(type)):
        pass'''

    transformer = MetaclassTransformer
    tree = test_transformer(transformer, source)

    assert_source(expected, tree)

# Generated at 2022-06-12 03:42:22.602566
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tr = MetaclassTransformer()
    assert six_import.get_body() == tr.visit(six_import.get_ast())


# Generated at 2022-06-12 03:42:29.912508
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    def do_test(class_def, expected):
        mct = MetaclassTransformer()
        assert mct.visit_ClassDef(class_def) == expected
    

# Generated at 2022-06-12 03:42:33.632816
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class A(object):
        pass

    class B(metaclass=A):
        pass

    node = ast.parse(inspect.getsource(B))
    MetaclassTransformer().visit(node)
    exec(compile(node, '<test>', 'exec'))

# Generated at 2022-06-12 03:42:37.208482
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = """class A(metaclass=Type):pass"""
    compiled = """class A(_py_backwards_six_with_metaclass(Type)):pass"""
    code = transform_code(source, MetaclassTransformer)
    assert(code == compiled)

# Generated at 2022-06-12 03:42:46.816521
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test import transform_code
    from . import six

    from typed_ast import ast3 as ast

    code = six.dedent("""\
    class A(metaclass=B):
        pass
    """)

    tree = transform_code(code, MetaclassTransformer)

    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.ClassDef)

    classdef = tree.body[0]
    assert classdef.keywords == []
    assert len(classdef.bases) == 1
    assert isinstance(classdef.bases[0], ast.Call)

    call = classdef.bases[0]
    assert isinstance(call.func, ast.Name)

# Generated at 2022-06-12 03:42:49.725933
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    from typed_ast import ast3 as ast
    
    
    class TestTransformer(MetaclassTransformer):
        def __init__(self):
            self._tree_changed = False
    

# Generated at 2022-06-12 03:43:03.793960
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from collections.abc import MutableSequence
    import typed_astunparse
    import astunparse

    code = '''
    class A(metaclass=MutableSequence):
        pass
    '''
    module = ast.parse(code)
    mt = MetaclassTransformer()
    mt.visit(module)
    output = typed_astunparse.unparse(module)
    expected = six_import.get_body() + class_bases.get_body().strip()
    assert output == astunparse.unparse(ast.parse(expected)) + '\n'

# Generated at 2022-06-12 03:43:04.663494
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:43:13.464526
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.snippet import snippet
    from ..utils.fixtures import ast_tree

    class_def = ast.ClassDef(name='A', bases=[ast.Name(id='object', ctx=ast.Load())], keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))], body=[], decorator_list=[])

    class_def_expected = snippet.get_body(cls=class_def,
                                          bases=class_bases.get_body(metaclass=ast.Name(id='B', ctx=ast.Load()),
                                                                     bases=ast.List(elts=[ast.Name(id='object', ctx=ast.Load())], ctx=ast.Load())))

    class_

# Generated at 2022-06-12 03:43:21.268139
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Unit test for method visit_ClassDef of class MetaclassTransformer """
    code = """class A(metaclass=B): pass"""
    tree = ast.parse(code)

    # Executes the transformer
    transformer = MetaclassTransformer()
    new_tree = transformer.visit(tree)

    # The transformer leaves the tree unchanged
    assert tree == new_tree
    assert transformer.tree_changed is False

    # Tests that the tree was not changed by the transformer
    expected = ast.parse("""class A(_py_backwards_six_with_metaclass(B)): pass""")
    assert tree == expected

# Generated at 2022-06-12 03:43:25.522104
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    m = ast.parse("""
    class A(abc.ABCMeta):
        pass
    """)
    t = MetaclassTransformer()
    t.visit(m)
    assert ast.dump(m) == dedent("""
    class A(_py_backwards_six_withmetaclass(abc.ABCMeta)):
        pass
    """)

# Generated at 2022-06-12 03:43:28.231040
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # If
    class A(metaclass=type):
        pass

    # Then
    class A(_py_backwards_six_withmetaclass(type)):
        pass

# Generated at 2022-06-12 03:43:35.262248
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import parse

    tree = parse("""
    class A(metaclass=B):
        pass
    
    """.lstrip())
    MetaclassTransformer().visit(tree)

    assert tree.body[0].value.bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert tree.body[0].value.bases[0].args[0].id == 'B'



# Generated at 2022-06-12 03:43:44.000384
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    print("Test visit_ClassDef")
    class Test(ast.NodeTransformer):
        def __init__(self, node):
            self.node = node
            self.new_node = None

        def visit(self, node):
            self.new_node = node
            self.generic_visit(node)
            return self.new_node

    # Case with no metaclass
    before = ast.parse("""class A(object):
                    pass""")
    after = Test(before).visit(before)
    assert(ast.dump(after) == ast.dump(before))

    # Case with a metaclass
    before = ast.parse("""class A(object, metaclass=B):
                    pass""")
    after = Test(before).visit(before)

# Generated at 2022-06-12 03:43:54.361003
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    trans = MetaclassTransformer()
    node = ast.ClassDef(name='A',
                        bases=[ast.Name(id='B', ctx=ast.Load())],
                        keywords=[ast.arg(arg='metaclass', value=ast.Name(id='C', ctx=ast.Load()))])
    # When
    actual = trans.visit(node)

    # Then

# Generated at 2022-06-12 03:43:57.477324
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    import six
    mt = MetaclassTransformer(target=(2, 7))

# Generated at 2022-06-12 03:44:17.776114
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_ = ast.parse("""
    class A(metaclass=B):
        pass
    """).body[0]
    metaclass = class_.keywords[0].value
    assert class_.bases == []
    MetaclassTransformer().visit_ClassDef(class_)
    assert class_.bases == [class_bases.get_body(metaclass=metaclass,
                                                 bases=ast.List(elts=[]))[0]]
    assert class_.keywords == []

# Generated at 2022-06-12 03:44:22.632451
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    node = parse(code).body[0]
    result = MetaclassTransformer().visit(node)
    assert clean(dump(result)) == clean(expected)

# Generated at 2022-06-12 03:44:27.660676
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .base import BaseTestTransformer
    BaseTestTransformer(MetaclassTransformer).test(
        """
        class A(metaclass=B):
            pass
        """,
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    )

# Generated at 2022-06-12 03:44:33.975592
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .testutils import round_trip, make_module
    from typed_ast import ast3 as ast
    
    # Testing only one case
    code = 'class X(metaclass=Y): pass'
    expected = 'class X(_py_backwards_six_with_metaclass(Y)): pass'
    mod = make_module(code)
    MetaclassTransformer().visit(mod)
    assert mod == make_module(expected)
    assert round_trip(mod) == make_module(expected)

# Generated at 2022-06-12 03:44:42.758859
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclass = ast.Name(id='abc', ctx=ast.Load())
    clas = ast.ClassDef(name='name', bases=[], keywords=[ast.keyword(arg='metaclass', value=metaclass)], body=[])
    expected = ast.ClassDef(name='name', 
                            bases=ast_literal_eval('[_py_backwards_six_withmetaclass(abc)]'),
                            keywords=[],
                            body=[])
    # I do not know why ast_literal_eval is not working here.
    # clas = ast_literal_eval(ast_literal_eval(code))
    t = MetaclassTransformer()
    t.visit(clas)
    assert clas == expected

# Generated at 2022-06-12 03:44:51.576938
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    from typed_ast import ast3 as ast
    from .test_BaseNodeTransformer import BaseNodeTransformer
    from .test_BaseNodeTransformer import _BaseNodeTransformerTest
    class MockedMetaclassTransformer(MetaclassTransformer, BaseNodeTransformer):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._tree_changed = False
            self._imports_added = set()

        def add_import(self, mod_name):
            self._imports_added.add(mod_name)

    # no metaclass
    node = ast.ClassDef(name='A',
                        bases=[],
                        keywords=[],
                        body=[],
                        decorator_list=[])
    mocked_transformer = MockedMetaclassTransformer

# Generated at 2022-06-12 03:44:53.421404
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .utils import round_trip, round_trip_dump


# Generated at 2022-06-12 03:45:01.348509
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.ast_builder import build_ast

    class C(object):
        class B(metaclass=type):
            pass
        class B2(object, metaclass=type):
            pass
        class B3(B2, object, metaclass=type):
            pass

    mt = MetaclassTransformer()
    mt.visit(build_ast(C))

    assert 'from six import with_metaclass as _py_backwards_six_withmetaclass' in mt.output()  # noqa
    assert '_py_backwards_six_withmetaclass(type)' in mt.output()  # noqa
    assert '_py_backwards_six_withmetaclass(type, *[object])' in mt.output()  # noqa

# Generated at 2022-06-12 03:45:04.576894
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    #! python3
    #! range(3, 7)
    class A(metaclass=B):
        pass
    #! python2,python3
    class A(_py_backwards_six_withmetaclass(B)):
        pass

# Generated at 2022-06-12 03:45:10.910576
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class TestMetaclassTransformer(MetaclassTransformer):
        def visit_ClassDef(self, node):
            return MetaclassTransformer.visit_ClassDef(self, node)

    module = ast.parse("""class A(metaclass=B):\n    pass""")
    TestMetaclassTransformer().visit(module)

    import six

    assert(
        inspect.getsource(six.with_metaclass) in
        inspect.getsource(module)
    )

# Generated at 2022-06-12 03:45:49.752431
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ast import parse
    from ..utils.snippet import snippet_to_tree
    six_import_tree = snippet_to_tree(six_import)
    mt = MetaclassTransformer()
    assert isinstance(mt.visit(parse("class A(metaclass=B): pass")), ast.Module)
    assert mt.visited_classes == []
    assert mt.visited_functions == []
    assert mt.visited_methods == []
    assert mt.visited_scripts == []
    assert mt.visited_testcases == []
    assert mt.changed_nodes == []
    assert mt.changed_files == []
    assert mt.visited_files == []
    assert mt._tree_changed is False

# Generated at 2022-06-12 03:45:52.125854
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class A(metaclass=type):
        pass

    actual_python_code = astunparse.unparse(ast.parse(inspect.getsource(A)))


# Generated at 2022-06-12 03:45:53.054414
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:46:01.089277
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_ = ast.ClassDef(name='A',
                          bases=ast.List(elts=[ast.Name(id='C')]),
                          keywords=[ast.keyword(arg='metaclass',
                                                value=ast.Name(id='B'))],
                          body=[],
                          decorator_list=[])

# Generated at 2022-06-12 03:46:08.118215
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    ast_node = ast.parse('''class A(metaclass=B):
            pass''')
    transformer = MetaclassTransformer()

    result = transformer.visit(ast_node)

    assert ast.dump(result) == textwrap.dedent('''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass''').strip()


# Generated at 2022-06-12 03:46:13.938350
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.unparse import Unparser
    node = source("""
        class A(metaclass=type):
            pass
    """)
    assert Unparser(node)
    metaclass_transformer = MetaclassTransformer()

# Generated at 2022-06-12 03:46:22.117654
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tests = [
        _make_test(
            substr=r"class A(metaclass=B):\n"
                    r"    pass",

            expected=r"from six import with_metaclass as _py_backwards_six_withmetaclass\n"
                     r"class A(_py_backwards_six_withmetaclass(B)):\n"
                     r"    pass",
        ),
    ]

    for test in tests:
        tree = ast.parse(test.substr)
        transformer = MetaclassTransformer(tree)
        transformed = transformer.visit(tree)
        assert_code_equal(compile(transformed, "<string>", "exec"), test.expected)

# =====


# Generated at 2022-06-12 03:46:23.452158
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast as pyast

# Generated at 2022-06-12 03:46:32.189899
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from pathlib import Path
    from ..utils.test_fixtures import load_test_code_ast_tree
    from ..utils.test_fixtures import load_test_code_str
    source = Path('test/test_code/test_metaclass.py')
    source_code = load_test_code_str(source)
    source_tree = load_test_code_ast_tree(source)
    tree = MetaclassTransformer().visit(source_tree)  # type: ignore
    code = compile(tree, source.as_posix(), 'exec')
    namespace = {}
    exec(code, namespace)

    def check_instance():
        # When compiled, this function is automatically added to namespace
        instance = namespace['test'].Test()
        assert instance.test == 1

    # Test with backwards six import


# Generated at 2022-06-12 03:46:40.125946
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    m = ast.parse('class A(object):\n    """docstring"""\n    pass')
    t = MetaclassTransformer()
    new_m = t.visit(m)
    assert ast.dump(m.body[0]) == ast.dump(new_m.body[0])

    m = ast.parse('class A(metaclass=B):\n    """docstring"""\n    pass')
    t = MetaclassTransformer()
    new_m = t.visit(m)
    assert ast.dump(m.body[0]) != ast.dump(new_m.body[0])

# Generated at 2022-06-12 03:48:03.046082
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..test_utils import assert_equal_ast
    assert_equal_ast(MetaclassTransformer().visit('''
    class Test(metaclass=str):
        pass
    '''), '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class Test(_py_backwards_six_withmetaclass(str)):
        pass
    ''')


# Generated at 2022-06-12 03:48:11.216840
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.testutils import source, source_ast
    from .indentation import IndentationTransformer
    from .pep8 import Pep8Transformer

    source = source('class A(metaclass=B): pass')
    expected = source_ast('import six; from six import '
                          'with_metaclass as _py_backwards_six_withmetaclass; '
                          'class A(_py_backwards_six_withmetaclass(B)): pass')

    tree_orig = ast.parse(source)
    tree_mod = MetaclassTransformer().visit(tree_orig)
    tree_mod = Pep8Transformer().visit(tree_mod)
    tree_mod = IndentationTransformer().visit(tree_mod)
    assert astor.to_

# Generated at 2022-06-12 03:48:19.010454
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a = ast.parse('class A(object, metaclass=list):\n pass')
    result = MetaclassTransformer().visit(a)
    res = ast.dump(result)
    print(res)

# Generated at 2022-06-12 03:48:21.286268
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astunparse
    import sys
    from .test_utils import round_trip_visit


# Generated at 2022-06-12 03:48:25.315425
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from six.moves import builtins
    from ..utils.testing import assert_source
    tree = ast.parse('class A(metaclass=B): pass', mode='exec')
    node = tree.body[0]
    assert isinstance(node, ast.ClassDef)
    assert_source(node, 'class A(metaclass=B): pass')
    result = MetaclassTransformer().visit_ClassDef(node)

# Generated at 2022-06-12 03:48:27.133682
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class Str(str):
        pass

    class A(metaclass=Str):
        pass

    assert A.__bases__ == (Str,)

# Generated at 2022-06-12 03:48:35.741291
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Setup
    input = ast.parse(
        '''
        class A(metaclass=B):
            pass
        '''
    )

    # Exercise
    transformer = MetaclassTransformer()
    output = transformer.visit(input)

    # Verify

# Generated at 2022-06-12 03:48:36.851864
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class A:
        pass

# Generated at 2022-06-12 03:48:43.168383
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...tests.testing_utils import assert_source_equal

    source = """class Foo(metaclass=type, bar=True):
                pass"""
    expected = """
                from six import with_metaclass as _py_backwards_six_withmetaclass
                class Foo(_py_backwards_six_withmetaclass(type, bar=True)):
                    pass"""

    assert_source_equal(MetaclassTransformer, source, expected)

# Generated at 2022-06-12 03:48:49.580770
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import unittest

    from typed_ast import ast3
    from ..utils.ast_utils import compile_ast

    class MetaclassTransformerTest(unittest.TestCase):
        def test_has_metaclass(self):
            node = ast3.parse("class A(metaclass=B): pass")
            actual = MetaclassTransformer().visit(node)
            expected = ast3.parse("from six import with_metaclass as _py_backwards_six_withmetaclass \n\nclass A(_py_backwards_six_withmetaclass(B))\n    pass")
            self.assertEqual(compile_ast(actual), compile_ast(expected))

    unittest.main()