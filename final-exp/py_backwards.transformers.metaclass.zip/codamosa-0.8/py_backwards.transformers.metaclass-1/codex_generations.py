

# Generated at 2022-06-12 03:39:58.350272
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
            class A(B, metaclass=C):
                pass
            """

    node = ast.parse(code)
    MetaclassTransformer().visit(node)

    expected_code = """
        from six import with_metaclass as _py_backwards_six_with_metaclass
        
        class A(_py_backwards_six_with_metaclass(C), B):
            pass
    """

    assert ast.dump(node) == ast.dump(ast.parse(expected_code))

# Generated at 2022-06-12 03:40:07.101452
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astunparse
    from ..utils import ast3

    # test with one keyword and one base
    tree = ast3.parse("""
        class A(metaclass=B, object):
            pass
    """)

    transformer = MetaclassTransformer()
    transformer.visit(tree)

    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    assert astunparse.unparse(tree) == expected

    # test with one keyword and two bases
    tree = ast3.parse("""
        class A(metaclass=B, object, newobject):
            pass
    """)

    transformer = MetaclassTransformer()
    transformer.visit

# Generated at 2022-06-12 03:40:13.159859
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    class C(ast.NodeTransformer):
        def visit_ClassDef(self, node):
            node.bases = [ast.Name(id="Foo", ctx=ast.Load())]
            return node
    M = type("M", (), dict(visit=C().visit))
    transformer = MetaclassTransformer(2,7,M())

    class_def = ast.ClassDef(name="A",
                             bases=[ast.Name(id="object", ctx=ast.Load())],
                             keywords=[ast.keyword(arg="metaclass", value=ast.Name(id="B", ctx=ast.Load()))])
    six_import_node = six_import.get_ast()
    class_bases_node = class_bases.get

# Generated at 2022-06-12 03:40:19.549736
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor, astunparse
    from .test_BaseNodeTransformer import run_visitor
    visitor = MetaclassTransformer()
    src = """
        class A(object, metaclass=B):
            pass
        """
    expected = """
        class A(object, _py_backwards_six_withmetaclass(B)):
            pass
        """
    res = run_visitor(visitor, src)
    print(astunparse.unparse(res))
    assert astor.to_source(res).strip() == expected.strip()
# end unit test

# Generated at 2022-06-12 03:40:26.402576
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_string = """
    class A(metaclass=B):
        pass
    """
    expected_string = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B, *[])):
        pass
    """
    tr = MetaclassTransformer()
    tree = ast.parse(test_string)
    new_tree = tr.visit(tree)
    assert ast.dump(new_tree) == expected_string

# Generated at 2022-06-12 03:40:31.633323
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from textwrap import dedent

    code = dedent("""
        class A(object, metaclass=B):
            pass
        """)
    t = MetaclassTransformer()
    assert str(t.visit(ast.parse(code))) == dedent("""
        class A(_py_backwards_six_withmetaclass(B, object)):
            pass
        """)

# Generated at 2022-06-12 03:40:38.455397
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Should compile the six import when visited
    tree = ast.parse('class A(metaclass=B):\n    pass')
    transformer = MetaclassTransformer()
    node = transformer.visit(tree)
    result = ast.dump(node)
    expected = ast.dump(ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass\n\n\nclass A(metaclass=B):\n    pass'))
    assert result == expected


# Generated at 2022-06-12 03:40:45.982940
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """
    This test checks that a class definition with a metaclass argument is
    correctly parsed by the `MetaclassTransformer` class.
    """
    class_def = textwrap.dedent(
        """\
        class A(metaclass=B):
            pass
        """)
    expected_class_def = textwrap.dedent(
        """\
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    )
    tree = ast.parse(class_def)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    print(ast.dump(tree))
    assert ast.dump(tree) == expected_class_def



# Generated at 2022-06-12 03:40:54.347271
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    test_data = '''
        class A(metaclass=B):
            pass
    '''
    expected = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B))
            pass
    '''
    mod = astor.parse_file(open('test_data.py'))
    metaclass_transform = MetaclassTransformer()
    metaclass_transform.visit(mod)
    updated = astor.to_source(mod)
    assert updated.strip() == expected.strip(), 'Did not import six'


# Generated at 2022-06-12 03:40:58.168317
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..transformer import to_source
    from ..utils.snippet import (
        snippet_of,
        module_of
    )
    from ..utils.tree import (
        ast_eq,
        compare_nodes
    )
    
    import astor
    

# Generated at 2022-06-12 03:41:06.467075
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
        class A(metaclass=B):
            pass
    """
    expected_code = """
        class A(_py_backwards_six_withmetaclass(B))
    """
    tree = ast.parse(code)
    MetaclassTransformer(tree).visit(tree)
    tree_code = astor.to_source(tree)
    assert tree_code.strip() + "\n" == expected_code.strip()

# Generated at 2022-06-12 03:41:08.024207
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import assert_node
    from .. import parse


# Generated at 2022-06-12 03:41:09.393181
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ast import parse
    from typed_ast import ast27

# Generated at 2022-06-12 03:41:12.899500
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse('''
    import six
    class X(metaclass=six.with_metaclass):
        pass
    ''')
    MetaclassTransformer().visit(node)
    print(ast.dump(node))


# Generated at 2022-06-12 03:41:21.914033
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()
    tree = ast.parse('class A(object, metaclass=B): pass')
    tree = transformer.visit(tree)
    assert transformer._tree_changed
    assert transformer.missing_dependencies == {'six'}

# Generated at 2022-06-12 03:41:23.416083
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    transformer = MetaclassTransformer(None)

# Generated at 2022-06-12 03:41:33.366819
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    parser = ast.parse("class A(metaclass=object): pass")
    node = parser.body[0]
    assert isinstance(node, ast.ClassDef)
    assert not node.bases
    assert len(node.keywords) == 1
    assert node.keywords[0].arg == "metaclass"

    transformer = MetaclassTransformer()
    transformer.visit(parser)

    assert not node.keywords
    assert node.bases
    assert len(node.bases) == 1
    assert isinstance(node.bases[0], ast.Call)
    assert isinstance(node.bases[0].func, ast.Name)
    assert node.bases[0].func.id == "_py_backwards_six_withmetaclass"

# Generated at 2022-06-12 03:41:42.403399
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # yapf: disable
    source = ast.parse(dedent('''
        class A(metaclass=B):
            pass

        class C(metaclass=B,):
            pass

        class D(E, metaclass=B):
            pass
    '''))
    # yapf: enable

    tree = MetaclassTransformer().visit(source)
    print(ast.dump(tree))  # pragma: no cover

    # yapf: disable

# Generated at 2022-06-12 03:41:43.584427
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-12 03:41:48.218490
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test import transform
    assert transform(MetaclassTransformer,
                     """
                     class C(metaclass=object):
                         pass
                     """,
                     """
                     from six import with_metaclass as _py_backwards_six_withmetaclass
                     class C(_py_backwards_six_withmetaclass(object)):
                         pass
                     """)

# Generated at 2022-06-12 03:42:01.239080
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    from ..utils.python import tree
    from ..utils.python import version  # type: ignore
    code = """
        class A(object, metaclass=B):
            pass
    """
    # When
    result = tree(MetaclassTransformer(version).visit(tree(code)))  # type: ignore
    # Then
    assert result == """
        class A(_py_backwards_six_withmetaclass(B, object)):
            pass
    """.lstrip()

# Generated at 2022-06-12 03:42:03.364528
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..test.test_utils import assert_equal_source
    from ..test.test_utils import assert_equal_ast


# Generated at 2022-06-12 03:42:04.313997
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:08.839505
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import astor
    # code = "class A(metaclass=type, b=True):\n    pass"
    # tree = ast.parse(code)
    # mt = MetaclassTransformer()
    # mt.visit(tree)
    # print(astor.to_source(tree))


# Generated at 2022-06-12 03:42:15.248593
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import assert_parsed

    source = dedent('''\
        class A(object, metaclass=B):
            pass
        ''')

    expected = dedent('''\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B, object)):
            pass
        ''')

    assert_parsed(MetaclassTransformer, source, expected)

# Generated at 2022-06-12 03:42:24.785634
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class TestClassDef(unittest.TestCase):
        def test_no_change(self):
            transformer = MetaclassTransformer() # type: ignore
            classdef = ast.ClassDef(name='A', bases=[])
            self.assertEqual(transformer.visit(classdef), classdef)

        def test_new_bases(self):
            transformer = MetaclassTransformer()
            classdef = ast.ClassDef(name='A', bases=[],
                                    keywords=[ast.keyword(arg='metaclass',
                                                          value=ast.Name(id='B',
                                                                         ctx=ast.Load()))])

# Generated at 2022-06-12 03:42:30.966903
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap
    tree = ast.parse(textwrap.dedent(
        """\
        class A(B, metaclass=C):
            pass"""))
    MetaclassTransformer(None).visit(tree)

# Generated at 2022-06-12 03:42:35.143245
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    node = ast.parse('class A(metaclass=B, c=d):\n    pass', mode="exec")

# Generated at 2022-06-12 03:42:36.087547
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:41.973694
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast as _ast


# Generated at 2022-06-12 03:42:57.714698
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    import textwrap

    src1 = source_to_ast(textwrap.dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    class A(metaclass=B):
        pass
    """))

    src2 = source_to_ast(textwrap.dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """))

    transformer = MetaclassTransformer()
    transformer.visit(src1)

    assert compare_ast(src1, src2)


# Generated at 2022-06-12 03:42:59.968001
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_input = "class Foo(metaclass=metaclass, object): pass"

# Generated at 2022-06-12 03:43:09.983105
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    import ast
    import six
    import pickle
    from io import StringIO, BytesIO
    from test.test_backwards import parse, compare_source

    ast_module = str(ast.__name__)
    ast_version = tuple([int(i) for i in ast.__version__.split('.')])

    class DummySys(object):
        version_info = (3, 5)
        version = '3.5'
        hexversion = sys.hexversion
        maxsize = sys.maxsize
        maxunicode = sys.maxunicode
        byteorder = sys.byteorder
        stdin = sys.stdin
        stdout = sys.stdout
        stderr = sys.stderr
        modules = sys.modules.copy()
        path = sys.path
        meta_

# Generated at 2022-06-12 03:43:10.281455
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:43:18.586963
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_node = compile("class A(metaclass=B,c=d): pass\n", "<ast>", "exec", ast.PyCF_ONLY_AST)
    MetaclassTransformer().visit(module_node)
    assert str(module_node).startswith('Module(body=[ImportFrom(module="six", names=[alias(name="with_metaclass", asname=None)], level=0)')

# Generated at 2022-06-12 03:43:20.871773
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:43:25.952027
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class A(object):
        __metaclass__ = B

    # Check if the transformation is supported
    check_tree(A, MetaclassTransformer)

    # Check the new syntax tree
    tree = MetaclassTransformer().visit(ast.parse(six_import.format() +
                                                  class_bases.format(metaclass=B, bases=[])))
    eval(compile(tree, '<string>', 'exec'))
    assert isinstance(A, B)

# Generated at 2022-06-12 03:43:36.432451
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given: Some code containing a class with metaclass
    code = '''
        class BaseMetaclass(type):
            pass

        class Class1(metaclass=BaseMetaclass):
            pass
    '''

    # When: We run the MetaclassTransformer on it
    result = MetaclassTransformer().run_on_code(code)

    # Then: The metaclass keyword is removed, and the metaclass is added to the bases
    # FIXME: the resulting code works but is ugly, no need to add a comma before the metaclass

# Generated at 2022-06-12 03:43:43.569586
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    import textwrap
    classdef = textwrap.dedent('''\
        class A(metaclass=type):
            pass
    ''')
    expected = textwrap.dedent('''\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(type)):
            pass
    ''')
    transformer = MetaclassTransformer()
    classdef = ast.parse(classdef)
    classdef = transformer.visit(classdef)
    assert astor.to_source(classdef) == expected

# Generated at 2022-06-12 03:43:50.274377
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """
    Test method visit_ClassDef of class MetaclassTransformer
    """
    module = ast.parse("""class A(object, metaclass=B):\n pass""")
    visitor = MetaclassTransformer()
    module = visitor.visit_Module(module)
    # Comparing ast.dump(module) to expected string is not a very good test,
    # because order of dict keys may change in different versions of Python.
    assert 'class A(B, object)' == ast.dump(module.body[1])

# Generated at 2022-06-12 03:44:10.162634
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..autotest import do_test
    source = """\
        class A(B):
            pass
    """
    expected = """\
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B, )):
            pass
    """
    do_test(MetaclassTransformer, source, expected)



# Generated at 2022-06-12 03:44:16.671735
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    mt = MetaclassTransformer()

    # test a clas without metaclass
    node = ast.parse('class A: pass')
    mt.visit(node)
    assert mt._tree_changed == False
    assert ast_str(node) == 'class A: pass'

    # test a class with a metaclass
    node = ast.parse('class A(metaclass=B): pass')
    mt.visit(node)
    assert mt._tree_changed == True
    assert ast_str(node) == 'class A(_py_backwards_six_withmetaclass(B)): pass'

# Generated at 2022-06-12 03:44:22.068854
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    from .base import BaseTestTransformer
    from .base import run_test_node
    from .base import transform_test
    class A:
        pass
    transform_test(A, 'class A(object): pass',
                   'class A(_py_backwards_six_withmetaclass(object)): pass')
    transform_test(A, 'class A(object, metaclass=B): pass',
                   'class A(_py_backwards_six_withmetaclass(B, object)): pass')



# Generated at 2022-06-12 03:44:29.529708
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import AST
    from _py_backwards.tests.test_compat_2to3.test_fixers import base
    from _py_backwards.transforms.metaclass import MetaclassTransformer

    node = AST(body=[
        base.EmptyClass,
        base.MetaclassClass,
        base.EmptyClass,
    ])

    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert transformer.tree_changed == True
    assert node.body == [
        base.FixedMetaclassClass,
        base.EmptyClass,
    ]

# Generated at 2022-06-12 03:44:36.010588
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_in = ast.parse('''
    class A(metaclass=B):
        def foo(self):
            pass
    ''')
    class_def_out = ast.parse('''
    class A(_py_backwards_six_withmetaclass(B)):
        def foo(self):
            pass
    ''')

    transformer = MetaclassTransformer()
    result = transformer.visit(class_def_in)

    assert result == class_def_out, 'Class definition node not transformed.'

# Generated at 2022-06-12 03:44:39.265663
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3
    from . import CodegenVisitor
    from .utils import parse_code, CodegenState as Cgs, insert_ast
    from .six_compat import six_import


# Generated at 2022-06-12 03:44:40.770045
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_source_equal

# Generated at 2022-06-12 03:44:45.608200
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    m = ast.parse("""
        class A(B, metaclass=C, **args):
            pass
    """)
    Meta = MetaclassTransformer()
    res = Meta.visit(m)
    print(astor.to_source(res))

# Generated at 2022-06-12 03:44:52.057458
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    snippet = """
        import typing
        class A(metaclass=typing.Sequence[int]):
            pass
    """
    expected = """
        import typing
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(typing.Sequence[int], object)):
            pass
    """
    node = ast.parse(snippet)
    node = MetaclassTransformer().visit(node)
    assert ast.dump(node) == expected

# Generated at 2022-06-12 03:45:00.272363
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
    assert True
    """

    six_import_ = six_import.get_body()
    class_bases_ = class_bases.get_body(metaclass=ast.Name(id='metaclass', ctx=ast.Load()),
                                        bases=ast.List(elts=[ast.Name(id='base1', ctx=ast.Load()),  # type: ignore
                                                             ast.Name(id='base2', ctx=ast.Load())],
                                                       ctx=ast.Load()))  # type: ignore
    code_expected = """
    %s
    assert True
    """ % (str(six_import_[0]) + '\n' +
           str(class_bases_[0]))


# Generated at 2022-06-12 03:45:33.889148
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...tests.transformer_test import TransformerTestCase
    class TestMetaclassTransformer_visit_ClassDef(TransformerTestCase):
        transformer = MetaclassTransformer

# Generated at 2022-06-12 03:45:45.105685
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse('class Foo(bar, metaclass=baz): pass').body[0]
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)

# Generated at 2022-06-12 03:45:45.817744
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:45:47.023320
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 # type: ignore
    from .utils import transform


# Generated at 2022-06-12 03:45:54.085192
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3
    class A(ast3.AST):
        _fields = ('test',)
    class B(ast3.AST):
        _fields = ('test',)

    code = "class A(metaclass=B):\n pass"

    tree = ast3.parse(code)
    tree = MetaclassTransformer().visit(tree)

    expected_result_tree = ast3.parse("class A(with_metaclass(B)):\n pass")
    assert ast3.dump(tree) == ast3.dump(expected_result_tree)

# Generated at 2022-06-12 03:45:58.459957
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    cls = ast.ClassDef(name='X', bases=[], keywords=[ast.arg(arg='metaclass', value=ast.Name(id='Y'))],
                       body=[ast.Pass()], decorator_list=[])

# Generated at 2022-06-12 03:46:07.963762
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from . import metaclass_transformer_test  # pylint: disable=import-outside-toplevel
    stmt = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass


    
    
    
    
    
    
    
    
    
    
    
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = ast.parse(stmt)
    actual = tree_to_str(MetaclassTransformer().visit(tree))
    assert actual == expected
    assert not MetaclassTransformer._tree_changed  # pylint: disable=protected-access

# Generated at 2022-06-12 03:46:16.168836
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    expected = ast.parse(textwrap.dedent('''\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        '''))
    
    class B(object): pass
    source = ast.ClassDef(name='A', 
                          bases=[], 
                          keywords=[ast.arg(arg='metaclass', annotation=None, value=B())],
                          body=[],
                          decorator_list=[])
    
    transformer = MetaclassTransformer()
    
    result = transformer.visit(source)
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-12 03:46:24.189110
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    class A(object):
        pass

    class B(object, metaclass=A):
        def __init__(self):
            pass

    source = ast.parse(inspect.getsource(B))  # type: ignore
    fixed = MetaclassTransformer().visit(source)  # type: ignore

    expected = "from six import with_metaclass as _py_backwards_six_withmetaclass\n\n\nclass B(_py_backwards_six_withmetaclass(A)):\n    def __init__(self):\n        pass\n"  # noqa
    assert ast.dump(fixed) == expected



# Generated at 2022-06-12 03:46:28.533282
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = 'class A(metaclass=B): pass'
    tree = ast.parse(code)
    assert tree.body[0].bases[0] == 'B'

    res = MetaclassTransformer().visit(tree)
    assert res.body[0].bases[0].args[0].args[1] == 'B'


# Generated at 2022-06-12 03:47:42.053968
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..module import get_module
    from ..compat import module_name
    from ..utils import ast_to_source
    module = get_module('tests.samples.for-future.metaclass')
    module = MetaclassTransformer(module).visit(module)
    name = module_name(module)
    assert name == 'tests.samples.for-future.metaclass'

# Generated at 2022-06-12 03:47:43.020010
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast

# Generated at 2022-06-12 03:47:44.254156
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from cStringIO import StringIO
    from ..utils.cst import parse_module


# Generated at 2022-06-12 03:47:51.053631
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse("class A(): pass")
    transformer = MetaclassTransformer()
    node = transformer.visit(node)
    assert node == ast.parse("class A(): pass")

    node = ast.parse("class A(object): pass")
    node = transformer.visit(node)
    assert node == ast.parse("class A(object): pass")

    node = ast.parse("class A(metaclass=B): pass")
    node = transformer.visit(node)

# Generated at 2022-06-12 03:48:00.082923
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class MetaclassTransformerTest(unittest.TestCase):
        def test_visit_ClassDef_with_keywords(self):
            class_def = ast.parse('class A(metaclass=B): pass').body[0]
            node_transformer = MetaclassTransformer()

            new_class_def = node_transformer.visit(class_def)

            self.assertEqual(
                'class A(_py_backwards_six_with_metaclass(B)): pass',
                astor.to_source(new_class_def)
            )

        def test_visit_ClassDef_without_keywords(self):
            class_def = ast.parse('class A(object): pass').body[0]
            node_transformer = MetaclassTransformer()

            new_class

# Generated at 2022-06-12 03:48:06.784612
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .visitor import compile_source
    from .visitor import ExpressionTransformer

    class TestTransformer(ExpressionTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return node

    class TestClass(metaclass=TestTransformer):
        pass

    node = ast.parse(TestClass.__module__)

    from ..utils.tree import dump

    dump_before = dump(node)

    MetaclassTransformer(node)  # type: ignore
    TestTransformer(node)  # type: ignore

    dump_after = dump(node)

    source_after = compile_source(node)

    assert dump_before == dump_after
    assert source_after == TestClass.__module__

# Generated at 2022-06-12 03:48:10.207510
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astunparse
    from .base import CodeTransformer

    s_input = '''class Foo(metaclass=type):
    pass'''


# Generated at 2022-06-12 03:48:11.728295
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typing import cast

    from typed_ast import ast3 as ast

    from .transformers import tree_has_changed


# Generated at 2022-06-12 03:48:13.921954
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3 as ast
    from typing import List, Tuple
    from ast_tools.transformers import MetaclassTransformer
    import six


# Generated at 2022-06-12 03:48:19.067180
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.testing import assert_code_equal, check

    check(MetaclassTransformer,
          "class A(metaclass=B, c=D): pass",
          "class A(_py_backwards_six_withmetaclass(B), c=D): pass")

    check(MetaclassTransformer,
          "class A(B, metaclass=C, c=D): pass",
          "class A(B, _py_backwards_six_withmetaclass(C), c=D): pass")
