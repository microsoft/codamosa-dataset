

# Generated at 2022-06-12 03:39:53.535853
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .util import source_to_ast as to_ast
    from .util import ast_to_source as to_source

    ast.fix_missing_locations = lambda node: None


# Generated at 2022-06-12 03:40:03.773285
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """It should compile:
        class A(metaclass=B):
            pass
    To:
        class A(_py_backwards_six_with_metaclass(B))
    
    """
    code = """
        class A(metaclass=B):
            pass
    """
    # Fixture
    t = MetaclassTransformer()
    tree = ast.parse(code)
    # Call
    tree = t.visit(tree)
    # Assert
    assert t._tree_changed
    expected = '\n'.join(six_import.splitlines()[1:]) + "\n\n\n" + '\n'.join(class_bases.splitlines()[1:])
    assert '\n'.join(ast.dump(tree).splitlines()[-5:]) == expected

# Generated at 2022-06-12 03:40:11.523768
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class MetaclassTransformerStub(MetaclassTransformer):
        def __init__(self, node: ast.Module) -> None:
            self._target = ast.Module()
            self.generic_visit(node)

        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            self._target.body.append(node)
            return node

    # build an AST for:
    # def func(): pass
    source = ast.FunctionDef(name='func',
                             body=[],
                             decorator_list=[])

    target = ast.Module()
    target.body.append(six_import.get_body()[0])
    target.body.append(source)

    ast.fix_missing_locations(target)  # type: ignore
    ast.copy_location

# Generated at 2022-06-12 03:40:16.654143
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import parse
    
    code = '''
        class A(metaclass=B):
            pass
        '''
    tree = parse(code)
    node = tree.body[0]
    MetaclassTransformer().visit(node)
    assert node.bases[0].elts[0].func.attr == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-12 03:40:25.873595
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    from .base import BaseNodeTest

    class Test(BaseNodeTest):
        target_versions = (2, 7)

        def test_replace_metaclass(self):
            source = """
            class A(metaclass=B):
                pass
            """

            tree = self.parse(source)

            t = MetaclassTransformer(self.target_version)
            tree = t.visit(tree)
            self.assert_source(tree, """
            from six import with_metaclass as _py_backwards_six_withmetaclass

            class A(_py_backwards_six_withmetaclass(B)):
                pass
            """)

        def test_add_metaclass(self):
            source = """
            class A:
                pass
            """

            tree = self

# Generated at 2022-06-12 03:40:35.960259
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor  # type: ignore
    node = ast.parse('class A(metaclass=B, c=d): pass')  # type: ignore
    module = MetaclassTransformer().visit(node)  # type: ignore
    assert isinstance(module, ast.Module)  # type: ignore
    assert isinstance(module.body[0], ast.Expr)  # type: ignore
    class_def = module.body[1]
    assert isinstance(class_def, ast.ClassDef)  # type: ignore
    assert class_def.name == 'A'  # type: ignore
    assert len(class_def.bases) == 1  # type: ignore
    assert isinstance(class_def.bases[0], ast.Call)  # type: ignore

# Generated at 2022-06-12 03:40:44.670058
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from _py2to3_test_support.parse_module import parse_module
    from _py2to3_test_support.fixtures import two_to_three_test_case

    input = """
        class A(metaclass=B):
            pass

    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass


        class A(_py_backwards_six_with_metaclass(B))
    
    """
    six_import.set_body(six_import.get_body())
    class_bases.set_body(class_bases.get_body())
    m, _ = parse_module(input)
    node_transformer = MetaclassTransformer()
    actual = node_transformer.visit(m)
   

# Generated at 2022-06-12 03:40:45.177385
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:40:52.412179
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    class A:
        def __init__(self):
            pass
    class B(A):
        def __init__(self):
            pass
    class C(B):
        def __init__(self):
            pass
    class D(C, metaclass=B):
        def __init__(self):
            pass
    class E(D, metaclass=A):
        def __init__(self):
            pass

# Generated at 2022-06-12 03:40:53.093605
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor

# Generated at 2022-06-12 03:41:05.236332
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    mt = MetaclassTransformer()
    node = ast.parse('class A(object, metaclass=B): pass')
    mt.visit(node)
    assert ast.dump(node) == '''Module(body=[
    ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0),
    ClassDef(name='A', bases=[Expr(value=Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), args=[Name(id='B', ctx=Load())], keywords=[], starargs=None, kwargs=None), ctx=Load())], body=[Pass()], decorator_list=[], keywords=[])])'''


# Generated at 2022-06-12 03:41:05.837990
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-12 03:41:11.068252
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    input_ast = ast.parse('class A(metaclass=B):\n    pass', '', 'exec')
    expected_ast = ast.parse('class A(_py_backwards_six_withmetaclass(B)):\n    pass', '', 'exec')
    transformer = MetaclassTransformer()
    assert transformer.visit(input_ast) == expected_ast

# Generated at 2022-06-12 03:41:12.030292
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor

# Generated at 2022-06-12 03:41:15.930610
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import six
    import astor

# Generated at 2022-06-12 03:41:19.962080
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = """
        class A(metaclass=B):
            pass
    """
    tree = ast.parse(source)
    node = tree.body[0]

    expected = ast.parse(six_import.get_source() + source)

    assert MetaclassTransformer().visit_Module(tree) == expected


# Generated at 2022-06-12 03:41:26.376972
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    ast = parser.parse("""
    class A(metaclass=B, type1=C):
        pass
    """)

    main_transformer = MetaclassTransformer()
    main_transformer(ast)
    output = main_transformer.output()

    assert output == """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
    class A(_py_backwards_six_withmetaclass(B, *[type1=C])):
        pass
    
    
    """


# Generated at 2022-06-12 03:41:26.949355
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-12 03:41:28.449031
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor


# Generated at 2022-06-12 03:41:34.821534
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    input_code = inspect.cleandoc(
        """
        class A(B, metaclass=C):
            pass
        """
    )
    expected_output = inspect.cleandoc(
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(C, *[B])):
            pass
        """
    )
    assert MetaclassTransformer.run_print(input_code) == expected_output



# Generated at 2022-06-12 03:41:41.308506
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import fix_py2_test_code
    from sharing.parser import parse_str
    from sharing.intra_transformer import IntraTransformer
    from sharing.utils.tree import node_to_str


# Generated at 2022-06-12 03:41:44.020171
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor

    class Foo(metaclass=type):
        pass


# Generated at 2022-06-12 03:41:50.208235
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from textwrap import dedent
    from typed_ast import ast3
    from .utils import parse, round_trip, dump

    source = dedent("""
    class A(metaclass=B):
        pass
    """)
    tree = MetaclassTransformer().visit(parse(source))
    assert dump(tree) == dedent("""
    import six
    
    
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)

# Generated at 2022-06-12 03:41:51.439287
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    wrapper = MetaclassTransformer.wrap_tree

# Generated at 2022-06-12 03:41:58.716614
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = dedent("""\
    class A(object):
        pass
    """)
    expected = dedent("""\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
    class A(object):
        pass
    """)
    tree = ast.parse(source)
    transformer = MetaclassTransformer()
    tree = transformer.visit(tree)
    
    # Test transformer changes the AST
    assert transformer._tree_changed
    
    # Test AST is as expected
    assert ast.dump(tree) == expected


# Generated at 2022-06-12 03:41:59.648822
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-12 03:42:06.094354
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_utils import generate_equivalent_code

    from .. import settings
    from .sample_code import sample_code

    code = sample_code.metaclass_class
    tree = ast.parse(code, mode='exec')

    transformed_tree = MetaclassTransformer(settings).visit(tree)
    generated_code = generate_equivalent_code(transformed_tree)

    assert code != generated_code
    assert generated_code == sample_code.metaclass_class_transformed

# Generated at 2022-06-12 03:42:06.923292
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:17.016547
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_ = ast.ClassDef()
    class_.keywords = [ast.keyword(arg='metaclass', value=ast.Str(s='B'))]
    class_.bases = [ast.Name(id='D', ctx=ast.Load())]
    class_.body = [ast.Pass()]
    transformer = MetaclassTransformer()
    result = transformer.visit_ClassDef(class_)
    assert isinstance(result, ast.ClassDef)
    assert not result.keywords
    assert isinstance(result.bases[0], ast.Call)
    assert isinstance(result.bases[0].func, ast.Name)
    assert result.bases[0].func.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-12 03:42:26.166757
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    class Test(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.maxDiff = None

        def test_it(self):
            source = """
            class A():
                pass
            """
            expected = """
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A(_py_backwards_six_withmetaclass(None, *())):
                pass
            """
            transformer = MetaclassTransformer()
            tree = ast.parse(source)
            transformer.visit(tree)

            tree = ast.fix_missing_locations(tree)
            print(ast.dump(tree))

# Generated at 2022-06-12 03:42:40.804357
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:50.201529
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    metaclass = ast.Name(id='metaclass', ctx=ast.Load())
    bases = ast.List(elts=[])
    keywords = [ast.keyword(arg='metaclass', value=metaclass)]
    class_def = ast.ClassDef(name='A', bases=bases, keywords=keywords,
                             body=[], decorator_list=[])
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(class_def)
    assert class_def.keywords == []
    assert class_def.bases == class_bases.get_body(metaclass=metaclass,
                                                   bases=bases)

# Generated at 2022-06-12 03:42:51.389427
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..upytest import upytest


# Generated at 2022-06-12 03:42:57.613255
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import get_node

    """
    class A(object, metaclass=type):
        pass
    """
    node = get_node(MetaclassTransformer, test_MetaclassTransformer_visit_ClassDef.__doc__)
    assert node.bases == [
        ast.Attribute(value=ast.Name(id='six', ctx=ast.Load()), attr='with_metaclass'),
        ast.Name(id='type', ctx=ast.Load()),
        ast.Name(id='object', ctx=ast.Load()),
    ]

# Generated at 2022-06-12 03:43:07.282784
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    import six
    import unittest

    class TestMetaclassTransformerVisitClassDef(unittest.TestCase):
        def test_01_empty_class_metaclass(self):
            """Compile:
                class A(metaclass=B):
                    pass
            To:
                class A(_py_backwards_six_with_metaclass(B))
            """
            class A(metaclass=six.with_metaclass):
                pass

            module = ast.parse(six.u(compile(
                A,
                '<string>',
                'exec')))
            transformer = MetaclassTransformer()
            transformer.visit(module)
            code = compile(module, '<string>', 'exec')
            context = {}
            exec

# Generated at 2022-06-12 03:43:14.812907
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..six_unicode import SixUnicodeTransformer
    from ..utils.source import source_to_nodes
    from ..utils.tree import print_tree
    from .six import SixTransformer

    source = r"""
        class A(metaclass=B):
            pass
    """
    tree = source_to_nodes(source)
    tree = SixTransformer().visit(tree)
    tree = SixUnicodeTransformer().visit(tree)
    tree = MetaclassTransformer().visit(tree)
    assert print_tree(tree) == r"""
        from six import with_metaclass as _py_backwards_six_withmetaclass


        class A(_py_backwards_six_withmetaclass(B))
            pass
    """.lstrip()

# Generated at 2022-06-12 03:43:20.998184
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    tree = ast.parse('''class A(metaclass=B): pass''')
    tree = MetaclassTransformer().visit(tree)
    assert astor.to_source(tree).strip() == six_import.get_src()
    assert astor.to_source(tree.body[1]).strip() == astor.to_source(class_bases.get_body(metaclass=ast.Name(id='B'), bases=ast.List(elts=[]))).strip()

# Generated at 2022-06-12 03:43:21.583040
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:43:27.962685
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from . import fix_missing_locations
    from .six_transformer import SixTransformer

    code = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(metaclass=B):
        pass
    '''
    expected_code = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    tree = ast.parse(code)
    fix_missing_locations(tree)
    new_tree = SixTransformer().visit(tree)
    new_tree = MetaclassTransformer().visit(new_tree)

# Generated at 2022-06-12 03:43:36.431366
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .transform_test import run_transform_test
    from ..utils.patched_ast import dump_python_source, Module

    source = """
    class C(metaclass=None):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class C(_py_backwards_six_withmetaclass(None)):
        pass
    """

    tree = run_transform_test(MetaclassTransformer, source)
    dump_python_source(tree, Module)
    assert dump_python_source(tree, Module) == expected

# Generated at 2022-06-12 03:43:57.822428
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal

    def test_class(code):
        node = ast.parse(code)
        MetaclassTransformer().visit(node)
        return node

    assert_equal('class Bar(metaclass = Foo):\n    pass',
                 'class Bar(_py_backwards_six_withmetaclass(Foo)):\n    pass',
                 test_class)
    assert_equal('class Foo():\n    pass',
                 'class Foo():\n    pass',
                 test_class)

# Generated at 2022-06-12 03:44:04.094879
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
 
    class MClassDef(ast.ClassDef): pass
    class MStr(ast.Str): pass
    class MList(ast.List): pass
    class MName(ast.Name): pass
    class Mkeyword(ast.keyword): pass
    class MetaclassTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node):
            if node.keywords:
                metaclass = node.keywords[0].value
                node.bases = ('_py_backwards_six_with_metaclass(%(metaclass)s)' % vars()).ast
                node.keywords = []
            return node
    
    node = MClassDef(body=[], keywords=[Mkeyword(arg='metaclass', value=MStr(s='B'))], name='A')
    expect

# Generated at 2022-06-12 03:44:08.424416
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..transpile_test_case import TranspileTestCase

    ttc = TranspileTestCase()

# Generated at 2022-06-12 03:44:17.073435
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3 as a
    import textwrap
    ###################################
    # Tests if we can translate classes
    ###################################
    src = textwrap.dedent("""\
        class A(metaclass=B):
            pass
        class A(object, metaclass=B):
            pass
        class A(object, some_thing, metaclass=B):
            pass
        class A(object, some_thing, *args, **kwargs, metaclass=B):
            pass
        class A(object, some_thing, **kwargs, **kwargs, metaclass=B):
            pass
        class A(some_thing, **kwargs, **kwargs, metaclass=B, weird=True):
            pass
        """)

# Generated at 2022-06-12 03:44:20.125034
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast.parse('class Test(metaclass=int): pass')
    MetaclassTransformer().visit(tree)
    assert tree.body[1] == ast.parse('class Test(_py_backwards_six_withmetaclass(int)): pass').body[0]

# Generated at 2022-06-12 03:44:29.321596
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_code
    from .base import BaseNodeTransformerTest
    from .six_withmetaclass import SixWithMetaclassTransformerTest
    suite = unittest.TestSuite()
    suite.addTest(BaseNodeTransformerTest(MetaclassTransformer,
                                        source_to_code,
                                        '''
                                        class A(metaclass=int):
                                            pass
                                        class B(object, metaclass=type):
                                            pass
                                        class C(D, E, F, metaclass=type):
                                            pass
                                        class G():
                                            pass
                                        '''
                                        ))

# Generated at 2022-06-12 03:44:38.871902
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    class Dummy:
        pass

    from ..utils.context import Context
    from ..utils.source import source_to_ast
    class_node = source_to_ast("""class MyClass(metaclass=type):
    pass
""").body[0]
    dummy_context = Context(namespace=Dummy(), import_names=['type'])
    class_node.context = dummy_context
    node_transformer = MetaclassTransformer()
    # When
    class_node = node_transformer.visit_ClassDef(class_node)
    # Then
    assert len(class_node.bases) == 1
    assert class_node.bases[0].func.attr == 'get_body'
    assert class_node.bases[0].args[0].id == 'type'


# Generated at 2022-06-12 03:44:40.090748
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    import inspect
    import six
    import astunparse


# Generated at 2022-06-12 03:44:48.717840
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_utils import make_test_function
    from typing import List
    from ..six_utils import six_import
    from ..six_utils import class_bases

    ast_module, expected_source = make_test_function(
        "class A(object): pass",
        "from six import with_metaclass as _py_backwards_six_withmetaclass; "
        "class A(_py_backwards_six_withmetaclass(object, )): pass")

    # Add expected imports to the expected source
    expected_source = six_import.get_source() + "\n" + expected_source

    # Add expected imports to the expected source
    expected_source = (
        class_bases.get_source() + "\n" + expected_source
    )

    # Add expected class_bases call to

# Generated at 2022-06-12 03:44:55.699186
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from textwrap import dedent
    code = dedent('''
        import six
        class A(metaclass=B):
            pass
        ''')
    res = dedent('''
        import six
        class A((six.with_metaclass(B))):
            pass
        ''')
    m = ast.parse(code)
    mt = MetaclassTransformer()
    mt.visit(m)
    res_str = astor.to_source(m).strip()
    assert res_str == res, f'result:\n{res_str}\nexpected:\n{res}'

# Generated at 2022-06-12 03:45:30.629186
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class AssertNode(ast.AST):
        def assert_equal(self, other: ast.AST, msg=None):
            if not ast.dump(self) == ast.dump(other):
                raise AssertionError(msg or '%s != %s' % (self, other))

    node = ast.ClassDef(
        name='Test',
        bases=[
            ast.Name(id='object', ctx=ast.Load())
        ],
        keywords=[
            ast.keyword(arg='metaclass', value=ast.Name(id='type', ctx=ast.Load())),
        ]
    )

# Generated at 2022-06-12 03:45:39.718299
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap

    m=ast.parse(textwrap.dedent('''
    class Base(object):
        pass

    class A(Base, metaclass=Base):
        pass
    '''))

    res=ast.parse(textwrap.dedent('''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class Base(object):
        pass

    class A(_py_backwards_six_withmetaclass(Base, *[Base])):
        pass
    '''))

    t=MetaclassTransformer()
    t.visit(m)
    print(t.warnings)
    assert m==res, m

# Generated at 2022-06-12 03:45:46.735005
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap
    code = textwrap.dedent(r'''
    class A(metaclass=B): pass
    ''')
    module = ast.parse(code)
    transformer = MetaclassTransformer()
    new_module = transformer.visit(module)
    assert transformer._tree_changed
    transformer._tree_changed = False
    new_module = transformer.visit(new_module)
    assert not transformer._tree_changed
    result = ast.fix_missing_locations(new_module)
    print(compile(result, '', 'exec'))

# Generated at 2022-06-12 03:45:55.507486
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    classdef = ast.ClassDef(name='Foo')
    classdef.keywords = [ast.keyword(arg='metaclass', value=ast.Name(id='Bar', ctx=ast.Load()))]
    classdef.bases = [ast.Name(id='Base1', ctx=ast.Load()), ast.Name(id='Base2', ctx=ast.Load())]

    # Test the transformer
    transformer = MetaclassTransformer()
    classdef = transformer.visit_ClassDef(node=classdef)

    # Test the result of the transformation
    expected = ast.ClassDef(name='Foo')

# Generated at 2022-06-12 03:46:04.098988
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Test case 1
    def python_code_1():
        class A(metaclass=B):
            pass
    
    module_1 = ast.parse(python_code_1.__code__)
    module_1 = MetaclassTransformer().visit(module_1)  # type: ignore
    expected_result_1 = ast.parse('''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B, object)):
        pass
    ''')

    assert ast.dump(module_1) == ast.dump(expected_result_1)

    # Test case 2
    def python_code_2():
        class A(B, metaclass=C):
            pass
    
    module

# Generated at 2022-06-12 03:46:10.344173
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import python_ta

    stmt = 'class A(metaclass=B):\n    pass'
    tree = ast.parse(stmt)

    MetaclassTransformer(tree).visit(tree)

    assert str(tree) == 'class A(_py_backwards_six_withmetaclass(B)):\n    pass'

    python_ta.check_all(stmt, blacklist=['raise-missing-from'])



# Generated at 2022-06-12 03:46:13.482661
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    import sys


# Generated at 2022-06-12 03:46:17.675425
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import configparser as cfg # NOQA
    node = ast.parse('class A(metaclass=B, configparser=cfg.RawConfigParser): pass') # NOQA
    t = MetaclassTransformer()
    t.visit(node)

# Generated at 2022-06-12 03:46:26.823913
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.tst_visitor import run_visitor, make_module
    from ..utils.tst_node import NodeFactory
    Node = NodeFactory(ast)
    module = make_module('class A(metaclass=object): pass')
    transformer = MetaclassTransformer()
    new_module = run_visitor(transformer, module)
    assert new_module.body[0]._fields == ('body',)
    body = new_module.body[0].body
    # assert body == [
    #     Node.ImportFrom('six', [('with_metaclass', '_py_backwards_six_withmetaclass')], 0),
    #     Node.ClassDef('A', [Node.Call(Node.Name('_py_backwards_six_withmetaclass',
    #                                            

# Generated at 2022-06-12 03:46:32.864920
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.syntax_tree import parse
    from ..utils.source import source

    with_metaclass = parse("""
        class A(metaclass=int):
             pass
    """)
    expected = parse("""
        class A(_py_backwards_six_withmetaclass(int)):
            pass
    """)

    metaclassTransformer = MetaclassTransformer()
    result = metaclassTransformer.visit(with_metaclass)
    assert source(result) == source(expected)

# Generated at 2022-06-12 03:46:57.697030
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typing import TYPE_CHECKING
    import astor
    from ..ast_converter import generate_ast
    if TYPE_CHECKING:
        from typing import List


# Generated at 2022-06-12 03:46:58.148815
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-12 03:47:05.675583
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from ..utils.tree import insert_at, remove_at
    from ..utils.snippet import snippet


    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass


    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)


    class MetaclassTransformer(BaseNodeTransformer):
        """Compiles:
            class A(metaclass=B):
                pass
        To:
            class A(_py_backwards_six_with_metaclass(B))
        
        """

# Generated at 2022-06-12 03:47:13.648729
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # type: () -> None
    """Test that visit_Module works as expected."""
    module = ast.parse("""
        class A(metaclass=B):
            pass
        """)
    MetaclassTransformer().visit(module)
    assert ast.dump(module) == "Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0), ClassDef(name='A', bases=_py_backwards_six_withmetaclass(B)), Pass()])"


# Generated at 2022-06-12 03:47:19.031749
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert compile(source=six_import.get_text(),  # type: ignore
                   filename="<test>",
                   mode="exec",
                   flags=ast.PyCF_ONLY_AST) == ast.fix_missing_locations(
                       six_import.get_body())

    assert compile(source=class_bases.get_text(metaclass=ast.Name("B", ast.Load()),  # type: ignore
                                                bases=[]),
                   filename="<test>",
                   mode="exec",
                   flags=ast.PyCF_ONLY_AST) == ast.fix_missing_locations(
                       class_bases.get_body(metaclass=ast.Name("B", ast.Load()),  # type: ignore
                                            bases=[]))


# Generated at 2022-06-12 03:47:21.482161
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor  # noqa

    code = "class A(metaclass=B): pass"

# Generated at 2022-06-12 03:47:26.403450
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from astunparse import unparse
    from ..utils.test_utils import assert_compiled
    from .test_utils import compile_test_case, get_test_case
    test_case = get_test_case(__file__, 
                              'test_MetaclassTransformer_visit_Module')
    expected_ast, compiled_ast = compile_test_case(test_case, 
                                                   MetaclassTransformer)
    print(expected_ast)
    print(compiled_ast)

# Generated at 2022-06-12 03:47:27.722142
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Test for method visit_ClassDef of class MetaclassTransformer"""
    pass

# Generated at 2022-06-12 03:47:33.311609
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.source import source_from_snippets

    source = source_from_snippets("""
        class A(object):
            pass
    """)

    transformer = MetaclassTransformer()
    transformed = transformer.visit(source)

    source_from_snippets("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(object)):
            pass
    """)

    assert source.equals(transformed)


# Generated at 2022-06-12 03:47:37.934353
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Set up test case
    moduleCode = 'class A(metaclass=B):\n    pass'
    expectedCode = 'from six import with_metaclass as _py_backwards_six_with_metaclass\nclass A(_py_backwards_six_with_metaclass(B))'

    # Set up transformer and perform transformation
    tree = ast.parse(moduleCode)
    transformer = MetaclassTransformer()
    newTree = transformer.visit(tree)

    # Check that results are equal
    assert ast.dump(newTree) == ast.dump(ast.parse(expectedCode))

# Generated at 2022-06-12 03:48:47.022238
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_node_equals, assert_tree_changed, assert_tree_unchanged
    from typed_ast import ast3 as ast, parse


# Generated at 2022-06-12 03:48:52.671188
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    given = ast.parse("""
    class A(m):
        pass
    """)

    expected = ast.parse("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(m)):
        pass
    """)

    node = MetaclassTransformer.run_visitor(given, return_node=True)
    assert ast.dump(node) == ast.dump(expected)



# Generated at 2022-06-12 03:48:54.749377
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef(): # noqa
    from .six_import import SixImportTransformer
    from ..ast_util import ast_eq


# Generated at 2022-06-12 03:49:02.680594
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.test_utils import assert_equal_source, assert_equal_ast
    assert_equal_source(
        MetaclassTransformer().visit(ast.parse("""
            class A(metaclass=B):
                pass
        """)),
        """
            from six import with_metaclass as _py_backwards_six_withmetaclass
    
            class A(_py_backwards_six_withmetaclass(B)):
                pass
        """
    )


# Generated at 2022-06-12 03:49:06.380514
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast.parse('class Foo(metaclass=int, bar=baz):\n    pass')
    trans = MetaclassTransformer()
    trans.visit(tree)
    assert tree.body[0].keywords == []

# Generated at 2022-06-12 03:49:07.158073
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert type(MetaclassTransformer())

# Generated at 2022-06-12 03:49:15.953958
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # type: () -> None
    import ast
    import typed_ast.ast3 as typed_ast
    from typed_ast import ast3
    from ..utils.ast import generate_code
    from ..utils.snippet import snippet
    
    @snippet
    def module():
        """
        def six_import():
            from six import with_metaclass as _py_backwards_six_withmetaclass
        """
        class A(object, metaclass=B):
            pass
        
    module_ast = ast.parse(module.get_ast().body[0].value.id)  # type: ignore
    typed_module_ast = typed_ast.ast3.Module(body=[typed_ast.ast3.parse(module.get_ast().body[0].value.id).body[0]])

# Generated at 2022-06-12 03:49:24.396014
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    from .six_import_transformer import six_import

    #@snippet
    #def class_bases(metaclass, bases):
    #    _py_backwards_six_withmetaclass(metaclass, *bases)

    class A(metaclass=type):
        pass
    a = ast.parse(inspect.getsource(A))

    transformer = MetaclassTransformer()
    transformer.visit(a)

    # assert transformer transformed
    assert transformer._tree_changed == True

    a = transformer.visit(a)

    assert six_import.get_source() in a.body[0]
    # assert method visit_ClassDef didn't change bases
    # of class A(object):
   

# Generated at 2022-06-12 03:49:32.640534
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .six import SixTransformer
    from .utils.environment import Environment
    from .base import BaseNodeTransformer
    from .constants import Constants
    from .typehints import TypeHints
    from .comments import Comments
    from .aliasing import Aliasing
    from .variables import Variables
    from .stringformatting import StringFormatting
    from .namespace import Namespace
    from .exceptions import Exceptions
    from .iterators import Iterators
    from .types import Types
    from .functions import Functions
    from .patterns import Patterns
    from .contextmanagers import ContextManagers
    from .expressions import Expressions
    from .lambdas import Lambdas
    from .operators import Operators

# Generated at 2022-06-12 03:49:35.033563
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """Tests the constructor of class MetaclassTransformer"""
    transformer = MetaclassTransformer()
    assert transformer.target == (2, 7)
    assert transformer.dependencies == ['six']

