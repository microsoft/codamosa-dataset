

# Generated at 2022-06-12 03:40:02.111091
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_utils import round_trip
    from typed_ast import ast3 as ast

    tree = ast.parse("""
        class A(metaclass=B):
            pass
    """, feature_version=(2, 7))
    assert MetaclassTransformer().visit(tree) == \
        ast.ClassDef(name='A',
                     bases=[ast.Call(func=ast.Name(id='_py_backwards_six_withmetaclass', ctx=ast.Load(lineno=2, col_offset=8)),
                                     args=[ast.Name(id='B', ctx=ast.Load(lineno=2, col_offset=27))],
                                     keywords=[], starargs=None, kwargs=None)],
                     keywords=[], body=[], decorator_list=[])

    # Check that

# Generated at 2022-06-12 03:40:06.726751
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.testing import check_node_transformation, six_import, class_bases
    check_node_transformation(MetaclassTransformer,
                              'class Foo(metaclass=Bar): pass',
                              'class Foo(Bar): pass',
                              six_import=six_import,
                              class_bases=class_bases,
                              process_module_level=True)


# Generated at 2022-06-12 03:40:07.313813
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:40:08.456487
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 03:40:09.816464
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 03:40:15.034187
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = """
    class A(B):
        pass
    """
    node = ast.parse(code)
    t = MetaclassTransformer()
    t.visit(node)
    assert ast.dump(node) == """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B))
        pass
    """

# Generated at 2022-06-12 03:40:21.717365
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-12 03:40:31.858248
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    import astor
    from ...utils.tree import ast_to_str
    from ...utils.snippet import snippet
    from .base import test_transformer

    transformer = MetaclassTransformer(target=MetaclassTransformer.target)

    with_metaclass = snippet(
        """
        class A(metaclass=B):
            pass
        """
    )

    expected = snippet(
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    )

    module = with_metaclass.get_ast_module()
    module = transformer.visit(module)
    module_str = ast_to

# Generated at 2022-06-12 03:40:39.718242
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast
    from .base import BaseNodeTransformer

    class Visitor(BaseNodeTransformer):
        def visit_Name(self, node: ast.Name) -> ast.Name:
            node.id = "test"
            return self.generic_visit(node)  # type: ignore

    visitor = Visitor()

    module = ast.parse("from six import with_metaclass as _py_backwards_six_withmetaclass")
    module = visitor.visit(module)
    assert ast.dump(module) == "from six import with_metaclass as _py_backwards_six_withmetaclass\n"


# Generated at 2022-06-12 03:40:43.701253
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    tree = ast.parse('''
        class Test(object):
            pass
    ''')
    node = tree.body[0]
    transformer = MetaclassTransformer()
    transformer.visit_Module(node)
    assert transformer._tree_changed is True
    assert len(transformer.dependencies) == 0



# Generated at 2022-06-12 03:40:46.838245
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-12 03:40:52.374159
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    def do_test(source: str, expected: str) -> None:
        node = ast.parse(source)
        node = MetaclassTransformer().visit(node)
        ret = ast.dump(node)
        assert ret == expected, ret

    do_test(snippet.strip(six_import), snippet.strip(six_import))



# Generated at 2022-06-12 03:40:59.918322
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    m = ast.parse('class Foo(metaclass=Bar): pass')
    v = MetaclassTransformer()
    v.visit(m)
    assert ast.dump(m) == "Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0), ClassDef(name='Foo', bases=[Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), args=[Name(id='Bar', ctx=Load())], keywords=[])], body=[], decorator_list=[], keywords=[])])"



# Generated at 2022-06-12 03:41:06.058532
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    inp = ast.parse(six_import.get_source() +
                    """
                    class A(metaclass=B):
                        pass
                    """)

    out = ast.parse(six_import.get_source() +
                    """
                    class A(_py_backwards_six_withmetaclass(B, )):
                        pass
                    """)

    assert MetaclassTransformer().visit(inp) == out

# Generated at 2022-06-12 03:41:07.610209
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    tr = MetaclassTransformer()

# Generated at 2022-06-12 03:41:17.878104
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Arrange
    metaclass = ast.Name(id='B', ctx=ast.Load())
    bases = [
        ast.Name(id='object', ctx=ast.Load())
    ]

    class_def = ast.ClassDef(name='A', bases=bases, keywords=[ast.keyword(arg='metaclass', value=metaclass)], body=[], decorator_list=[])

    cleaned_class_def = ast.ClassDef(name='A', bases=class_bases.get_body(metaclass=metaclass, bases=ast.List(elts=bases)), body=[], decorator_list=[])

    transformer = MetaclassTransformer()

    # Act
    result = transformer.visit_ClassDef(class_def)

    # Assert
    assert result == cleaned_class

# Generated at 2022-06-12 03:41:24.835039
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..doc_test import BackwardsTransformerTester
    from typed_ast import ast3 as ast

    tester = BackwardsTransformerTester(MetaclassTransformer, version=(2, 7))

    tester.test(
        """
        class A(metaclass=B):
            def __init__(self):
                super(A, self).__init__()
        """,
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            def __init__(self):
                super(A, self).__init__()
        """
    )



# Generated at 2022-06-12 03:41:25.776126
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:41:27.134358
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..compile import compile_snippet


# Generated at 2022-06-12 03:41:28.550642
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    module = ast.Module()
    transformer = MetaclassTransformer()
    transformer.visit(module)
    expected = six_import.get_source()
    result = astor.to_source(module)
    assert result == expected



# Generated at 2022-06-12 03:41:42.362652
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    ast_tree = ast.parse("""
    class A(object, metaclass=B):
        pass
    """)
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(ast_tree)
    assert metaclass_transformer.tree_changed
    assert astor.to_source(ast_tree) == """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
    class A(_py_backwards_six_withmetaclass(B, object)):
        pass
    """

# Generated at 2022-06-12 03:41:48.997547
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source_ast = ast.parse("""
    class A(metaclass=B, bar=True):
        pass
    """)
    transformer = MetaclassTransformer(source_ast)
    tree = transformer.visit(source_ast)
    expected_ast = ast.parse("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B), bar=True):
        pass
    """)
    assert ast.dump(tree) == ast.dump(expected_ast)

# Generated at 2022-06-12 03:41:50.000447
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:41:58.987481
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.examples import example_python_module
    from ..transpile import Transpiler

    # Arrange
    source = example_python_module('''
        class A(metaclass=B):
            pass
    ''')
    expected = example_python_module("""\
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)
    transpiler = Transpiler()
    # Act
    actual_module = transpiler.transpile_module(source)
    # Assert

# Generated at 2022-06-12 03:42:05.271333
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    with open(__file__.replace('.py', '.input.py'), 'r') as f:
        source = f.read()

    source_tree = ast.parse(source)
    transformer = MetaclassTransformer()
    transformer.visit(source_tree)

    with open(__file__.replace('.py', '.output.py'), 'r') as f:
        expected_output = f.read()

    assert ast.dump(source_tree) == expected_output

# Generated at 2022-06-12 03:42:14.927413
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """
        class A(metaclass=B):
            pass
    """
    class_def = ast.ClassDef(name='A',
                             bases=[],
                             keywords=[
                                 ast.keyword(arg="metaclass", value=ast.Name(id="B"))
                             ],
                             body=[
                                 ast.Pass()
                             ],
                             decorator_list=[])
    none = ast.Name(id="None")

# Generated at 2022-06-12 03:42:24.494757
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = """class A(metaclass=B): pass"""
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    print(ast.dump(tree))
    #class A(_py_backwards_six_with_metaclass(B, )):
    #    pass

# Generated at 2022-06-12 03:42:27.775821
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class Test(unittest.TestCase):
        def test_visit_ClassDef(self):
            sources = [
                '''class C(): pass''',
                '''class C(B): pass''',
                '''class C(metaclass=M): pass''',
                '''class C(B, metaclass=M): pass''',
                '''class C(B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z, metaclass=metaclass): pass''',
            ]

# Generated at 2022-06-12 03:42:34.086765
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from textwrap import dedent
    from ..transform import parse_transform

    code = dedent('''
    class a(metaclass=B):
        pass
    ''')

    expected = dedent('''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class a(_py_backwards_six_withmetaclass(B)):
        pass
    ''')

    assert expected == parse_transform(MetaclassTransformer, code)

# Generated at 2022-06-12 03:42:37.926911
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_six_module import six_module
    from .test_six_module import all_six
    from .test_six_module import none_six
    from .test_six_module import import_six
    from .test_six_module import print_six

# Generated at 2022-06-12 03:42:48.554357
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:54.273762
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.visitor import NodeVisitor
    import ast
    import io
    import os

    class TestVisitor(NodeVisitor):
        def visit_Module(self, node: ast.Module) -> None:
            self._test('%s' % ast.dump(node))

    module_src = '''from six import with_metaclass'''
    assert module_src == six_import.get_source()
    module = ast.parse(module_src)


# Generated at 2022-06-12 03:43:00.459496
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # When
    node = ast.ClassDef(name="A",
                        bases=[ast.Name(id="object", ctx=ast.Load())],
                        keywords=[ast.keyword(arg="metaclass",
                                              value=ast.Name(id="B", ctx=ast.Load()))])
    assert _compile(node) == "class A(metaclass=B, object): pass"

    # When
    node = ast.ClassDef(name="A",
                        bases=[ast.Name(id="object", ctx=ast.Load())],
                        keywords=[ast.keyword(arg="metaclass", value=ast.Name(id="B", ctx=ast.Load()))])

# Generated at 2022-06-12 03:43:10.460613
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

    a = ast.parse('''
        class A(object, metaclass=B):
            pass
        ''').body[0]
    assert a.keywords[0].arg == 'metaclass'

    mt = MetaclassTransformer()
    a = mt.visit(a)
    assert mt.tree_changed is True

    assert a.bases[0].value.func.id == '_py_backwards_six_withmetaclass'
    assert a.bases[0].value.args[0].id == 'B'
    assert a.bases[0].value.args[1].id == 'object'

# Generated at 2022-06-12 03:43:14.294077
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    n = ast.parse("class A(metaclass=B): pass")

    MetaclassTransformer(n).visit(n)

    assert ast.dump(n) == textwrap.dedent("""\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)

# Generated at 2022-06-12 03:43:14.930792
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    pass

# Generated at 2022-06-12 03:43:23.312851
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class A(object):
        pass
    module = ast.parse('class A(metaclass=object):\n    pass')
    transformer = MetaclassTransformer()
    module = transformer.visit(module)
    assert transformer._tree_changed
    assert module
    assert isinstance(module.body[0].bases[0], ast.Call)
    assert isinstance(module.body[0].bases[0].func, ast.Name)
    assert module.body[0].bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert module.body[0].bases[0].args[0].id == 'object'


# Generated at 2022-06-12 03:43:32.680065
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import assert_code_equal
    from .base import BaseNodeTransformerTestCase

    class_def = ast.parse('''
    class A(B, metaclass=C):
        pass
    ''')
    expected_class_def = ast.parse('''
    class A(_py_backwards_six_withmetaclass(C, *[B])):
        pass
    ''')

    class Test(BaseNodeTransformerTestCase):
        transformer = MetaclassTransformer

        def test_method(self, tree):
            assert_code_equal(ast.dump(tree), ast.dump(expected_class_def))

    Test().run(class_def)

# Generated at 2022-06-12 03:43:34.137816
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:43:38.678882
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ... import compile, version

    sub = compile(
        '''
        class A(metaclass=B):
            pass
        ''',
        from_version=version.parse('2.7'))
    assert type(sub).__module__ == '_py_backwards'
    assert sub._code.co_consts[-1] == "six"
    assert sub._body[0] is six_import
    assert sub._body[2] is class_bases
    assert sub._body[2].metaclass == ast.Name(id="B")


# Test on module import

# Generated at 2022-06-12 03:43:55.794549
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .base import BaseTestTransformer
    import astor
    import ast
    class Foo(metaclass=type): pass

    class Test(BaseTestTransformer):
        transformer = MetaclassTransformer
        expected_output = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class Foo(_py_backwards_six_withmetaclass(type)):
            pass
        """
        code = astor.to_source(ast.parse(inspect.getsource(Foo)))
        tree = ast.parse(code)
    Test().test()

# Generated at 2022-06-12 03:44:00.494195
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast
    import astunparse
    mod = ast.parse('''class A(metaclass=B):
        pass''')

    mod.body[0].keywords[0].value = ast.Name(id='B', ctx=ast.Load())


# Generated at 2022-06-12 03:44:09.689555
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import numpy as np
    from six import with_metaclass

    class Foo:
        pass

    class Bar(metaclass=with_metaclass(type, int)):
        pass

    class Test:
        def __init__(self):
            self.x = np.array([0, 1, 2])

        def run(self):
            Foo(self.x)
            Bar(self.x)

    import astor
    import ast
    module = ast.parse(astor.to_source(Test))
    transformer = MetaclassTransformer()
    module = transformer.visit(module)

    out = astor.to_source(module)
    print(out)
    ns = {}
    exec(out, ns)
    Test = ns['Test']
    test = Test()
    test.run()

# Generated at 2022-06-12 03:44:17.701552
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # Arrange
    code = """
        class X():
            pass
        class C(metaclass=X):
            pass
    """

    # Act
    result = MetaclassTransformer().visit_Module(ast.parse(code))
    module = re.sub(r'\s+', '', result.body[0].body[0].bases[0].right.args[0].s)
    assert module == 'fromsiximportwith_metaclass_as_py_backwards_six_withmetaclass'
    result = MetaclassTransformer().visit_Module(ast.parse(code))
    class_name = re.sub(r'\s+', '', result.body[0].body[1].bases[0].func.args[0].id)

# Generated at 2022-06-12 03:44:26.286500
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import FunctionDef
    from .test_base import to_str, TestBase
    from .test_remove_coding_comment import RemoveCodingComment

    ast_ = ast.parse('class A(metaclass=B):\n    pass')
    RemoveCodingComment.visit(ast_)
    t = MetaclassTransformer()
    t.visit(ast_)

    assert to_str(ast_.body[0]) == 'class A(_py_backwards_six_withmetaclass(B)):'
    t.visit(ast_)  # second time to make sure the class is not modified
    assert to_str(ast_.body[0]) == 'class A(_py_backwards_six_withmetaclass(B)):'

# Generated at 2022-06-12 03:44:35.964494
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..tests.test_base import BaseTransformerTestCase
    import unittest

    class TestMetaclassTransformer(BaseTransformerTestCase, unittest.TestCase):
        TRANSFORMER = MetaclassTransformer
        FILES = {'test1.py': ('class A(object, metaclass=type):\n'
                              '    def __init__(self):\n'
                              '        pass')}
        EXPECTED_FILES = {'test1.py': ('from six import with_metaclass as _py_backwards_six_withmetaclass\n\n'
                                       'class A(_py_backwards_six_withmetaclass(type, object)):\n'
                                       '    def __init__(self):\n'
                                       '        pass\n')}

# Generated at 2022-06-12 03:44:37.278060
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys
    from ast import dump

# Generated at 2022-06-12 03:44:41.684752
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse('class A(object): pass')
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert ast.dump(node) == dedent('''\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
    class A(object):
        pass''')



# Generated at 2022-06-12 03:44:43.240594
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    # This code sample needs to be compiled by Python 3.5+

# Generated at 2022-06-12 03:44:44.196122
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    pass



# Generated at 2022-06-12 03:45:11.434529
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='metaclass', ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])

# Generated at 2022-06-12 03:45:19.045340
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .base import BaseTestTransformer
    from .base import BaseTestNodeTransformer
    module = BaseTestTransformer.get_ast_module(six_import)

    class T(BaseTestNodeTransformer):
        def visit_ClassDef(self, node):
            node.keywords.append(ast.keyword('metaclass', ast.Name(id='list', ctx=ast.Load())))

    transform = T().visit(module)
    print(ast.dump(transform))
    transform = MetaclassTransformer().visit(transform)
    print(ast.dump(transform))
    exec(compile(transform, filename="<ast>", mode="exec"))
    assert str(A) == "<class '__main__.A'>"

# Generated at 2022-06-12 03:45:20.398385
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:45:29.030350
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.source import source_to_unicode
    from ..modules.six import six
    from .test_six import mock_six
    from ..utils.snippet import get_source_of_snippet
    from py_meta_utils import UnicodeLiterals
    from textwrap import dedent
    from typed_ast import ast3 as ast

    source = dedent("""
    class A(metaclass=type):
        pass
    """)

    source_six = source_to_unicode(six.source)
    with mock_six():
        tree = ast.parse(source)
        transformer = MetaclassTransformer(target_tree=tree)
        tree = transformer.visit(tree)
        new_source = get_source_of_snippet(tree).strip()


# Generated at 2022-06-12 03:45:29.993125
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-12 03:45:31.256189
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    testee = MetaclassTransformer()

# Generated at 2022-06-12 03:45:32.174818
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:45:37.128555
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    node = ast.parse('''class A(metaclass=B):
    pass''')
    xformer = MetaclassTransformer()
    xformer.visit(node)
    assert six_import.get_body() == node.body[:2]
    assert b'''class A(six.with_metaclass(B)):
    pass''' == ast.dump(node)

# Generated at 2022-06-12 03:45:47.322824
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import unittest
    import sys
    sys.path.insert(0, './tests')
    from utils import get_module
    class Test(unittest.TestCase):
        def test(self):
            module = get_module(lambda: 1, MetaclassTransformer)
            self.assertEqual(module.body[1].body[0].args[0].func.id, '_py_backwards_six_with_metaclass')
            self.assertEqual(module.body[1].body[0].args[0].func.attr, None)
            self.assertEqual(module.body[1].body[0].args[0].args[0].id, 'Int')

# Generated at 2022-06-12 03:45:53.254326
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .base import round_trip
    sample = '''class A(object, metaclass=type): pass'''
    tree = ast.parse(sample)
    transformer = MetaclassTransformer()
    tree = transformer.visit(tree)
    assert transformer.tree_changed()
    assert round_trip(tree) == '''class A(_py_backwards_six_withmetaclass(type), object):
    pass'''


# Generated at 2022-06-12 03:46:39.390809
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast as pyast
    from ast_tools.transformers import MetaclassTransformer
    from ast_tools.utils.compare import compare_asts
    test_ast_1 = pyast.parse("""class MyClass(object, metaclass=ListMeta): pass""")
    test_ast_2 = pyast.parse("""class MyClass(_py_backwards_six_with_metaclass(ListMeta, object)): pass""")
    test_ast_1_transformed = MetaclassTransformer().visit(test_ast_1)
    assert compare_asts(test_ast_2, test_ast_1_transformed)

# Generated at 2022-06-12 03:46:42.406720
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse('x = 1')
    MetaclassTransformer().visit(module)
    assert ast.dump(module) == ast.dump(ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass\nx = 1'))


# Generated at 2022-06-12 03:46:47.822873
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.visitor import compare_ast
    source = '''
    class A(metaclass=B):
        pass
    '''
    module = ast.parse(source)
    transformer = MetaclassTransformer()
    transformed = transformer.visit(module)
    assert compare_ast(transformed, '''
        import six

        class A(six.with_metaclass(B)):
            pass
    ''')

# Generated at 2022-06-12 03:46:51.011078
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import transform
    from typed_ast import ast3 as ast

    code = """class A(metaclass=B): pass"""


# Generated at 2022-06-12 03:46:59.899255
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from textwrap import dedent
    from ..utils.ast3 import dump
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            insert_at(0, node, six_import.get_body())
            return self.generic_visit(node)  # type: ignore

        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            if node.keywords:
                metaclass = node.keywords[0].value
                node.bases = class_bases.get_body(metaclass=metaclass,  # type: ignore
                                                  bases=ast.List(elts=node.bases))
               

# Generated at 2022-06-12 03:47:06.338220
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    test = '''
        class A(metaclass=B):
            pass
        '''
    expected = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        '''
    transformer = MetaclassTransformer()
    tree = ast.parse(test)
    tree = transformer.visit(tree)
    assert transformer.tree_changed
    assert transformer.get_code(tree) == expected
    transformer.reset()
    tree = ast.parse(test)
    tree = transformer.visit(tree)
    assert not transformer.tree_changed

test_MetaclassTransformer()

# Generated at 2022-06-12 03:47:15.580476
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .base import BaseNodeTransformerTestCase
    from ..utils.fake import FakeBuiltin, FakeModule, FakeFile

    class TestMetaclassTransformer(BaseNodeTransformerTestCase):
        transformer = MetaclassTransformer
        target_version = (2, 7)

        def test_class(self):
            builtins = FakeBuiltin()
            six = FakeModule(name='six', builtins=builtins)

# Generated at 2022-06-12 03:47:24.274942
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import Module, ClassDef, Name, NameConstant, Str, Call, keyword, Attribute
    from typed_ast.ast3 import parse
    import astor
    from backports.typing import TYPE_CHECKING
    from ..utils.testing import raises_if_not_installed

    if TYPE_CHECKING:  # pragma: no cover
        from ..utils.testing import EqualToAst

    module = parse('''
    class A(metaclass=B):
        pass
    ''')

    transformer = MetaclassTransformer()
    module = transformer.visit(module)

    assert transformer.dependencies == {'six'}
    assert transformer.tree_changed is True

# Generated at 2022-06-12 03:47:26.712854
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = '''class A(metaclass=B):
    pass'''


# Generated at 2022-06-12 03:47:34.455104
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from textwrap import dedent
    from ..utils import parse

    result = MetaclassTransformer().visit(parse(dedent('''
        class A(metaclass=B):
            pass
    ''')))
    six_import_expected = dedent('''
        def _py_backwards_six_withmetaclass(cls, *bases):
            return cls.__new__(cls, 'tempclassname', bases, {})
    ''') # noqa
    class_bases_expected = dedent('''
        _py_backwards_six_withmetaclass(metaclass, tuple())
    ''') # noqa

# Generated at 2022-06-12 03:49:22.271722
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class A(metaclass=type):
        pass

    node = ast.parse(inspect.getsource(A))
    node = MetaclassTransformer().visit(node)

# Generated at 2022-06-12 03:49:31.519924
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    ast_tree = ast.parse('class Node(metaclass=abc.ABCMeta):\n pass')
    MetaclassTransformer().visit(ast_tree)
    assert ast.dump(ast_tree) == 'Module(body=[ImportFrom(module="six", names=[alias(name="with_metaclass", asname="_py_backwards_six_withmetaclass")], level=0), ClassDef(name="Node", bases=[Call(func=Name(id="_py_backwards_six_withmetaclass", ctx=Load()), args=[Name(id="abc", ctx=Load()), Attribute(value=Name(id="abc", ctx=Load()), attr="ABCMeta", ctx=Load())], keywords=[])], body=[Pass()], decorator_list=[])])'

# Generated at 2022-06-12 03:49:37.939483
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import compile
    from . import dedent
    from .test_six_import import test_six_import

    src = dedent('''
        import six
        class A(metaclass=B):
            pass
    ''')
    expected = dedent('''
        import six
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

    with test_six_import(expected):
        tree = compile(src, '<string>', 'exec')
        assert src != tree.body[1]
        assert tree.body[1].bases[0].func.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-12 03:49:38.614601
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor

# Generated at 2022-06-12 03:49:40.558776
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .test_utils import make_test_tree
    from ..utils.tree import dump_tree, loads_tree
    from ..utils.test_utils import generate_test


# Generated at 2022-06-12 03:49:42.000584
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ast import dump
    from . import compile_src


# Generated at 2022-06-12 03:49:43.486628
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()

# Generated at 2022-06-12 03:49:48.255126
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = """class A(metaclass=B):
    pass"""
    expected = dedent(six_import.get_source() + "\n" + code)
    tree = ast.parse(code)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    print(astunparse.unparse(tree))
    assert expected == astunparse.unparse(tree)