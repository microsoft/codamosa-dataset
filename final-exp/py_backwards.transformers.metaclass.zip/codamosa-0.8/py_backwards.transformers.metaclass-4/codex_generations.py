

# Generated at 2022-06-12 03:39:52.157786
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    #
    # test without metaclass
    #
    node = ast.parse("class A: pass")
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)
    assert ast.dump(new_node, annotate_fields=False) == ast.dump(node,
        annotate_fields=False)

    #
    # test with metaclass
    #
    node = ast.parse("class A(metaclass=B): pass")
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)

# Generated at 2022-06-12 03:39:58.892582
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import run_transformer_test

    source = """
    import six
    class A(metaclass=B):
        pass
    """

    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    transformer = MetaclassTransformer()

    run_transformer_test(transformer, source, expected)

# Generated at 2022-06-12 03:40:05.565441
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from . import util
    source = """class A(metaclass=B):\n    pass\n"""
    expected = """from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass\n"""
    node = ast.parse(source)
    m = MetaclassTransformer()
    new_node = m.visit(node)
    util.assert_equivalent_node(new_node, expected)

# Generated at 2022-06-12 03:40:10.183306
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    class_def = astor.parse_file(
        """
        class A(object, metaclass=B):
            pass
        """).body[0]
    transformer = MetaclassTransformer([])

# Generated at 2022-06-12 03:40:11.726489
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 03:40:20.228166
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..test_utils import transform_on
    def test_with_metaclass(metaclass, bases):  # type: ignore
        return metaclass, bases
    six_import._py_backwards_six_with_metaclass = test_with_metaclass

    for text in [
        '''
        class A:
            pass
        ''',
        '''
        class A(metaclass=B):
            pass
        '''
    ]:
        transformed = transform_on(MetaclassTransformer, text)

        assert transformed.ast_tree.body[1].keywords == []
        assert transformed.ast_tree.body[1].bases[0].func.id == '_py_backwards_six_with_metaclass'
        assert transformed.ast_tree.body[1].bases

# Generated at 2022-06-12 03:40:21.117011
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:40:22.017237
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:40:32.165324
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    import os
    import tempfile
    from jinja2 import Template
    from typed_ast import ast3 as ast

    import astor

    sys.path.append(os.path.dirname(os.path.realpath(__file__)))

    # Get source code of six.py and write to a temporary file
    source_code = six_import.render() + "\n" + class_bases.render()
    with tempfile.NamedTemporaryFile('w', suffix='.py', delete=False) as tmpf:
        tmpf.write(source_code)
    sys.path.append(tmpf.name)

    # Compile AST and get source code

# Generated at 2022-06-12 03:40:41.973002
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Tests for `MetaclassTransformer.visit_ClassDef`
    # This method does not mutates the ClassDef node, so we do not need to test that.
    # What we test is that the node is visited and the right changes in nodes.
    code = """
        class A():
            pass
        class A(metaclass=B):
            pass
    """
    root = ast.parse(code)
    metaclass_transformer = MetaclassTransformer()
    root = metaclass_transformer.visit(root)
    assert_code_equal(code, root)
    assert metaclass_transformer._tree_changed == True
    assert_code_equal(six_import.get_code(), root.body[0])

# Generated at 2022-06-12 03:40:53.857013
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import parse
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeVisitorTestCase

    class TestCase(BaseNodeTransformerTestCase,
                   BaseNodeVisitorTestCase):
        target_version = '2.7'
        transformer = MetaclassTransformer
        dependencies = ['six']

        def test_metaclass(self):
            tree = parse('class A(metaclass=B): pass')
            tree = self.transform_to_target(tree)
            self.assertEqual(len(tree.body), 1)
            self.assertIsInstance(tree.body[0], ast.ClassDef)
            self.assertEqual(tree.body[0].bases[0].func.id, '_py_backwards_six_withmetaclass')
           

# Generated at 2022-06-12 03:41:01.217519
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def = ast.parse("class A(metaclass=B): pass").body[0]
    transformer = MetaclassTransformer()
    transformer.visit(class_def)
    assert class_def._fields == ('name', 'bases', 'keywords',
                                 'body', 'decorator_list')
    assert class_def.name == "A"
    assert class_def.bases[0].func.id == "_py_backwards_six_withmetaclass"
    assert class_def.bases[0].args[0].id == "B"


# Generated at 2022-06-12 03:41:09.765618
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six

    ast_before = '''
        class A(metaclass=B):
            pass
    '''
    ast_after  = '''
        class A(_py_backwards_six_with_metaclass(B))
            pass
    '''
    node = ast.parse(ast_before)
    node = MetaclassTransformer().visit(node)
    assert ast.dump(node) == ast_after
    six.exec_(compile(node, '<string>', 'exec'))
    assert A.__class__ is _py_backwards_six_with_metaclass(B)

# Generated at 2022-06-12 03:41:19.745458
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()
    node = ast.ClassDef(name='A',
                        bases=[ast.Name(id='B', ctx=ast.Load())],
                        keywords=[ast.keyword(arg='metaclass',
                                              value=ast.Name(id='C',
                                                             ctx=ast.Load()))])
    actual = transformer.visit_ClassDef(node)

# Generated at 2022-06-12 03:41:26.042736
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    # Given
    module = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    # When
    transformer = MetaclassTransformer()
    new_module = transformer.visit(module)

    # Then
    assert astor.to_source(new_module).strip() == """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """.strip()

# Generated at 2022-06-12 03:41:35.404282
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    class Source(object):
        def foo(self, a: int, b: str) -> float:
            pass

    # Testing case when no metaclass specified
    source_node = ast.parse(inspect.getsource(Source.foo))
    transformer_visit_method = MetaclassTransformer().visit_ClassDef
    inserted_node = transformer_visit_method(source_node.body[0])
    assert inserted_node == source_node.body[0]

    # Testing case when metaclass specified
    source_node = ast.parse(
        inspect.getsource(Source).replace(':', ': \n    __metaclass__ = object'))
    transformer_visit_method = MetaclassTransformer().visit_ClassDef

# Generated at 2022-06-12 03:41:36.115402
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:41:44.705677
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import prepare_code
    from ..utils import evaluate_ast as eval

    code = """
    class A(metaclass=type):
        pass

    class B:
        pass
    """
    code = prepare_code(code)

    node = MetaclassTransformer.run_pipeline(code, ast.fix_missing_locations, MetaclassTransformer)
    globals_, locals_ = eval(node)
    assert sorted(globals_) == ['A', 'B', 'type']  # '_py_backwards_six_with_metaclass' removed after cleanup
    assert locals_ == {}
    assert isinstance(globals_['A'], type)

# Generated at 2022-06-12 03:41:48.781567
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import unittest.mock
    from typed_ast import ast3 as ast

    m = unittest.mock.mock_open()

    with unittest.mock.patch('__main__.six.__file__', m):
        transformer = MetaclassTransformer()

        # Tests the case where the class doesn't have a metaclass
        class_no_metaclass = ast.ClassDef(name='Foo',
                                          bases=[ast.Name(id='object', ctx=ast.Load())],  # type: ignore
                                          body=[],  # type: ignore
                                          decorator_list=[],  # type: ignore
                                          keywords=[])
        transformer.visit(class_no_metaclass)


# Generated at 2022-06-12 03:41:54.891569
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from py_backwards.transformers.visitors.metaclass import MetaclassTransformer
    transformer = MetaclassTransformer()
    node: ast.ClassDef = ast.parse('class A(metaclass=B): pass').body[0]
    new_node = transformer.visit_ClassDef(node)
    assert transformer._tree_changed
    assert new_node.bases[0].value.func.value.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-12 03:42:07.702882
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from six import with_metaclass as _py_backwards_six_withmetaclass

    source = """
    class A(metaclass=int):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(int)):
        pass
    """

    node = ast.parse(source)
    MetaclassTransformer().visit(node)
    module = ast.Module(body=[
        six_import.get_body()[0],
        ast.ClassDef(name='A',
                     bases=[class_bases.get_body()[0].value],
                     body=[],
                     decorator_list=[],
                     keywords=[])
    ])


# Generated at 2022-06-12 03:42:16.329675
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import run_transformer_on_single_file

    from pyrevit import framework
    metadata = framework.load_revit_type_metadata(framework.types.Document)
    # returns the class metadata of Document
    # Document(uidoc.Document)
    #   <class 'pyrevit.framework.Document'>
    Document = metadata.py_type
    # returns the class meta class of Document
    # PyRevitLiteDocumentMeta(pyrevit.framework._internal.DocumentMeta)
    #   <class 'pyrevit.framework.PyRevitLiteDocumentMeta'>
    DocumentMeta = Document.__class__


# Generated at 2022-06-12 03:42:25.597311
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import parse_ast, round_trip_load
    from ..compiler import compile

    # Test class `A` with metaclass `B` is transformed
    node_a = round_trip_load('class A(metaclass=B): pass')
    node_c = compile(node_a)
    assert len(node_c.body) == 3
    assert node_c.body[0].body[0].value.args[0] == ast.Name(id='B', ctx=ast.Load()), node_c.body[0].body[0].value.args[0]

# Generated at 2022-06-12 03:42:31.600446
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import assert_transformation, assert_source
    from ..testing.file_fixture import FileFixture

    assert_transformation(
        MetaclassTransformer,
        FileFixture('metaclass.py'),
        FileFixture('metaclass.py').expected,
    )
    # Hack to make mypy happy
    assert_source(
        MetaclassTransformer,
        FileFixture('metaclass.py').expected,
        FileFixture('metaclass.py'),
    )


# Generated at 2022-06-12 03:42:39.428521
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    # Parse a string containing a single class definition
    node = ast.parse('class A(metaclass=B): pass')

    # Create the transformer and try to transform the node
    transformer = MetaclassTransformer()
    node = transformer.visit(node)

    # Check that the node has been transformed
    assert transformer._tree_changed == True

    # Check the result of the transformation
    assert node.body[0].bases.elts == [
        ast.Name(id='_py_backwards_six_withmetaclass', ctx=ast.Load()),
        ast.Name(id='B', ctx=ast.Load())
    ]

# Generated at 2022-06-12 03:42:40.345656
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:41.205186
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:50.760463
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import unittest
    import typing
    import astor
    import ast
    import six

    class TestMetaclassTransformerVisitClassDef(unittest.TestCase):
        """Unit test for method visit_ClassDef of class MetaclassTransformer"""

        class Module(ast.Module):
            pass

        class ClassDef(ast.ClassDef):
            pass

        class Name(ast.Name):
            pass

        class Keyword(ast.keyword):
            pass

        class Expr(ast.Expr):
            pass

        class Str(ast.Str):
            pass

        class ImportFrom(ast.ImportFrom):
            pass

        class FunctionDef(ast.FunctionDef):
            pass

        class arguments(ast.arguments):
            pass

        class Call(ast.Call):
            pass


# Generated at 2022-06-12 03:42:51.312667
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:57.814601
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a = ast.parse("class A(metaclass=B): pass")
    b = ast.parse("class A(_py_backwards_six_withmetaclass(B)): pass")
    transformer = MetaclassTransformer()
    res = transformer.visit(a)
    # print("".join(list(map(repr, res.body))))
    # print("".join(list(map(repr, a.body))))
    # print("".join(list(map(repr, b.body))))
    assert "".join(list(map(repr, res.body))) == "".join(list(map(repr, b.body)))

# Generated at 2022-06-12 03:43:11.194578
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # type: () -> None
    transformer = MetaclassTransformer(target_version=(2, 7))

    class_def = ast.parse(textwrap.dedent("""\
        class A(metaclass=B):
            pass
    """))
    transformed_class_def = transformer.visit(class_def)

    assert transformed_class_def.body[0].bases[0].func.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-12 03:43:16.774744
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.example import ClassDef, Name, Module, Num
    # Just for testing, we need to mock the six import
    inject_globals(six_import)
    # Test for class definitions with metaclass

# Generated at 2022-06-12 03:43:19.472844
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from ..utils.ast_inspector import assert_source_equal


# Generated at 2022-06-12 03:43:22.733165
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.symbols import SymbolTable
    from ..utils.source import Source
    from ..utils.unparser import Unparser
    from ..utils.compare_ast import compare_ast, assert_equivalent_ast


# Generated at 2022-06-12 03:43:23.438909
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:43:23.872273
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:43:35.119740
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six
    import unittest
    from textwrap import dedent
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import ClassDef
    from typed_ast.ast3 import Name
    from typed_ast.ast3 import Call
    from typed_ast.ast3 import arguments
    from typed_ast.ast3 import arguments
    from typed_ast.ast3 import Load
    from typed_ast.ast3 import List
    from typed_ast.py23 import cmp
    from typing import List as _List

    class MetaclassTransformerTestCase(unittest.TestCase):
        def setUp(self):
            self.transform = MetaclassTransformer()


# Generated at 2022-06-12 03:43:36.009543
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:43:45.013654
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    if sys.version_info < (3, 6):
        import ast
        import six
        import typing
        # type: typing.Callable[[ast.AST], ast.AST]
        class TestMetaclassTransformer(MetaclassTransformer):
            _tree_changed = False
            _tree_visited = False
        tr = TestMetaclassTransformer()
        a = ast.ClassDef(name='A')
        a.bases = list()
        a.keywords = [ast.keyword(arg='metaclass', value=ast.Name(id='B'))]
        r = tr.visit(a)

# Generated at 2022-06-12 03:43:50.143794
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ... import run_transformer

    node1 = ast.parse("""\
    class NewClass(object, metaclass=type):
        pass
    """)
    node2 = run_transformer(MetaclassTransformer, node1)
    assert str(node2) == """\
    class NewClass(_py_backwards_six_withmetaclass(type, object)):
        pass"""

# Generated at 2022-06-12 03:44:09.166111
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    m = ast.parse('''class baz(metaclass=foo): pass''')
    mt = MetaclassTransformer()
    m = mt.visit(m)

# Generated at 2022-06-12 03:44:17.390679
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    class Module_Mock(object):
        def __init__(self, *args):
            pass

    class ClassDef_Mock(object):
        def __init__(self, *args):
            pass

    class Name_Mock(object):
        def __init__(self, *args):
            pass

    class List_Mock(object):
        def __init__(self, *args):
            pass

    class Keyword_Mock(object):
        def __init__(self, *args):
            pass

    class Attribute_Mock(object):
        def __init__(self, *args):
            pass

    class NameConstant_Mock(object):
        def __init__(self, *args):
            pass


# Generated at 2022-06-12 03:44:25.905855
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.location import Location
    from ..utils.source import source
    from textx import metamodel_from_str

    metamodel_src = """
    Module:
        classes*=ClassDef
    ;

    ClassDef:
        'class' name=ID '(' bases+=Expr (',' bases+=Expr)* ')' ':'
            body=Suite
    ;

    Expr:
        'metaclass' '=' type=ID
    ;

    Suite:
        'pass'
    ;
    """
    metamodel = metamodel_from_str(metamodel_src)

    module_src = """
    class A(metaclass=B):
        pass
    """
    module = metamodel.model_from_str(module_src)


# Generated at 2022-06-12 03:44:35.051718
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source

    assert source(MetaclassTransformer, '''
        class A(metaclass=B):
            pass
    ''') == source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

    assert source(MetaclassTransformer, '''
        class A(object,metaclass=B):
            pass
    ''') == source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B),object):
            pass
    ''')

# Generated at 2022-06-12 03:44:44.154368
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    
    # Input data
    # ========================================================================
    # Test for case: class A(metaclass=B): pass
    input_tree = """
    class A(metaclass=B):
        pass
    """
    
    # Expected output
    # ========================================================================
    # Test for case: class A(metaclass=B): pass
    expected_tree = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    
    # Remarks on the expected output
    # ========================================================================
    # Test for case: class A(metaclass=B): pass

# Generated at 2022-06-12 03:44:52.825260
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..parser import parse
    from ..transformer import TransformerPipeline
    
    from six import add_metaclass
    from ..utils.source import source

    pipeline = TransformerPipeline([
        MetaclassTransformer,
    ])
    module = parse(source('''
    class A:
        pass
        
    @add_metaclass(object)
    class B:
        pass
    '''))
    module = pipeline.run_pipeline(module)

# Generated at 2022-06-12 03:44:54.368964
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .visitor_test_template import _test_template
    _test_template(MetaclassTransformer)

# Generated at 2022-06-12 03:45:00.533006
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from textwrap import dedent
    from ..utils.compiler import compile_snippet
    from ..utils.test_utils import is_equal_code

    snippet = dedent('''
        class A(metaclass=B):
            pass
    ''')
    expected_result = dedent('''
        class A(_py_backwards_six_with_metaclass(B)):
            pass
    ''')
    result = compile_snippet(snippet, python_version='2.7')
    assert is_equal_code(result, expected_result)



# Generated at 2022-06-12 03:45:01.836190
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    node = ast.parse("class A(): pass")

# Generated at 2022-06-12 03:45:06.953212
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..tests.test_utils import assert_source
    node = ast.parse("""
    class A(object, metaclass=type):
        pass
    """)
    MetaclassTransformer().visit(node)
    assert_source(node, """
    class A(_py_backwards_six_withmetaclass(type, object)):
        pass
    """)

# Generated at 2022-06-12 03:45:42.898621
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:45:46.523545
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    ast_tree = ast.parse("class A(metaclass=B):\n    pass")
    transformer = MetaclassTransformer()
    transformer.visit(ast_tree)
    expected = ("from six import with_metaclass as _py_backwards_six_withmetaclass\n"
                "class A(_py_backwards_six_withmetaclass(B)):\n"
                "    pass")

    assert astor.to_source(ast_tree) == expected

# Generated at 2022-06-12 03:45:48.770544
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:45:57.049324
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typing import List
    from typed_ast import ast3 as ast

    import typed_astunparse
    from ..utils.tree import parse_tree, get_mod_node

    source = """
    class A(metaclass=B):
        pass
    """
    target = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    tree = parse_tree(source)
    transformer = MetaclassTransformer('2.7')
    new_tree = transformer.visit(tree)
    assert typed_astunparse.unparse(new_tree) == target
    assert new_tree is not tree

    # Check that the transpiled tree is valid
    new_mod_

# Generated at 2022-06-12 03:46:00.911425
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    text = 'class A(metaclass=B): pass'
    expected_text = 'class A(_py_backwards_six_withmetaclass(B)): pass'
    node = ast.parse(text)
    node = MetaclassTransformer().visit(node)
    assert astor.to_source(node).strip() == expected_text

# Generated at 2022-06-12 03:46:11.350596
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

    six_import_nodes = six_import.get_body()
    class_bases_nodes = class_bases.get_body(metaclass=ast.Name(id='metaclass', ctx=ast.Load()),
                                             # type: ignore
                                             bases=ast.List(elts=[], ctx=ast.Load()))
    node_to_test = ast.ClassDef(name='A',
                                bases=[],
                                keywords=[ast.arg(arg='metaclass', annotation=None, value=ast.Name(id='m', ctx=ast.Load()))],
                                body=[],
                                decorator_list=[])

    all_nodes = six_import_nodes + class_bases_nodes + [node_to_test]

   

# Generated at 2022-06-12 03:46:15.285279
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = "class A(metaclass=B, **kwargs): pass"
    module = parse(code, mode='exec')
    node = MetaclassTransformer().visit(module)
    expected = "class A(_py_backwards_six_withmetaclass(B, *[])): pass"
    assert_code_equal(node, expected)

# Generated at 2022-06-12 03:46:23.835470
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_ = ast.ClassDef(name="MetaclassTransformerTest",
                          bases=[],
                          keywords=[],
                          body=[],
                          decorator_list=[])
    expected_class_ast = ast.ClassDef(name="MetaclassTransformerTest",
                                      bases=[ast.Call(func=ast.Name(id="_py_backwards_six_withmetaclass", ctx=ast.Load()),
                                                      args=[],
                                                      keywords=[], starargs=None, kwargs=None)],
                                      keywords=[],
                                      body=[],
                                      decorator_list=[])
    __actual_class_ast = MetaclassTransformer().visit(class_)
    assert __actual_class_ast == expected_class_ast

# Generated at 2022-06-12 03:46:26.142217
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_astunparse
    from ..utils.node_tools import node_equals
    
    transformer = MetaclassTransformer()

# Generated at 2022-06-12 03:46:35.057961
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    import astor
    from six import PY3
    with MetaclassTransformer() as mt:
        result = mt.visit(ast.parse('class A(object, metaclass=type): pass'))
        assert result.body[0].bases[0].value.__class__ == ast.Call

    with MetaclassTransformer() as mt:
        result = mt.visit(ast.parse('class A(metaclass=type): pass'))
        assert result.body[0].bases[0].value.__class__ == ast.Call

    if PY3:
        with MetaclassTransformer() as mt:
            result = mt.visit(ast.parse('class A(metaclass=type, object): pass'))
            assert result.body[0].bases[0].value

# Generated at 2022-06-12 03:47:54.015059
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef(): 
    from ..testing.utils import to_source
    from .. import transform
    from typed_ast import ast3


# Generated at 2022-06-12 03:48:03.731085
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import os
    import astor
    from ..utils.tree_compare import tree_equal

    # Test file test_class_def.py
    filename = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'test_resources', 'test_class_def.py'))
    with open(filename) as f:
        testfile_tree = ast.parse(f.read())

    # Expected file expected_class_def.py
    filename = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'test_resources', 'expected_class_def.py'))
    with open(filename) as f:
        expected_tree = ast.parse(f.read())

    # Let the transformer run on the

# Generated at 2022-06-12 03:48:04.796350
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six

# Generated at 2022-06-12 03:48:06.635486
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-12 03:48:07.461188
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:48:13.219811
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse("""
        class A(metaclass=B):
            pass
        """)
    MetaclassTransformer._transform_tree(module)
    # Since the compilation is fairly complicated, an exhaustive test
    # would be quite complicated. But a global test can give an idea.
    assert str(module) == """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
        
        """

# Generated at 2022-06-12 03:48:21.112348
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node1 = ast.parse('''
    class MyMeta(type):
        pass
    class A:
        pass
    class B(metaclass=MyMeta):
        pass
    ''')

    node2 = ast.parse('''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class MyMeta(type):
        pass
    class A:
        pass
    class B(*[MyMeta], A):
        pass
    ''')

    node1 = MetaclassTransformer().visit(node1)
    assert ast.dump(node1, annotate_fields=False, include_attributes=False) == ast.dump(node2, annotate_fields=False, include_attributes=False)

# Generated at 2022-06-12 03:48:22.590171
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:48:23.456924
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ... import parse
    from ... import transform


# Generated at 2022-06-12 03:48:25.579430
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ... import code_to_ast
    from .test_base import BaseNodeTransformerTestCase
