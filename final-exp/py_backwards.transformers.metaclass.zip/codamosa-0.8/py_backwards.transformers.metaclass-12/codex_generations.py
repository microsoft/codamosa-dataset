

# Generated at 2022-06-12 03:39:52.678526
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-12 03:40:03.118698
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    import astor
    from .clean_python2 import CleanPython2Transformer
    from utils.snippet import snippet


    # A(metaclass=type)
    m = ast.parse(snippet(lambda: A(metaclass=type)))
    assert isinstance(m, ast.Module) and len(m.body) == 1

    c = m.body[0]
    assert isinstance(c, ast.ClassDef)
    assert c.name == 'A' and len(c.bases) == 1
    assert isinstance(c.bases[0], ast.Name) and c.bases[0].id == 'type' and len(c.keywords) == 1


# Generated at 2022-06-12 03:40:11.093206
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import six
    import sys

    src = """
    class A(metaclass=B):
        pass
    """

    mod = ast.parse(src)
    mod = MetaclassTransformer(sys.version_info, six).visit(mod)
    assert ast.dump(mod) == """\
Module(
    body=[ImportFrom(
        module='six',
        names=[alias(
            name='with_metaclass',
            asname='_py_backwards_six_withmetaclass')],
        level=0)],
    type_ignores=[])"""

    mod = ast.parse(src)
    mod = MetaclassTransformer(sys.version_info, six).visit(mod)

# Generated at 2022-06-12 03:40:19.793374
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # set up test data
    classdef = ast.ClassDef(name="A", bases=[ast.Name(id="object", ctx=ast.Load())], keywords=[ast.keyword(arg="metaclass", value=ast.Name(id="B", ctx=ast.Load()))])
    metaclass_transformer = MetaclassTransformer()

    # actual test
    classdef = metaclass_transformer.visit_ClassDef(classdef)

    # assert expected result
    assert hasattr(metaclass_transformer, '_tree_changed')
    assert metaclass_transformer._tree_changed == True
    assert isinstance(classdef, ast.ClassDef)
    assert isinstance(classdef.bases[0], ast.Call)

# Generated at 2022-06-12 03:40:28.696308
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    mt = MetaclassTransformer()
    node = ast.parse('class A(metaclass=B, c=d):\n    pass')
    expected = six_import.get_body() + class_bases.get_body(metaclass=ast.Name(id='B', ctx=ast.Load()), bases=ast.List(elts=[], ctx=ast.Load()), sep='')
    expected = ast.Module(body=expected)
    expected = ast.fix_missing_locations(expected)
    result = mt.visit(node)
    assert ast.dump(result, include_attributes=False) == ast.dump(expected, include_attributes=False)

# Generated at 2022-06-12 03:40:33.917738
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    import ast
    # Create AST
    root = ast.parse('class A(metaclass=B):\n    pass')
    # Apply transformer
    MetaclassTransformer.run_visitor(root)
    # Save modified AST
    exec(compile(root, "<ast>", "exec"), sys.modules[__name__].__dict__)

# Generated at 2022-06-12 03:40:42.961063
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Test cases
    tests = (
        # Test case 1
        {
            # Input
            'input':
                '''
                class A(metaclass=B):
                    pass
                ''',
            # Expected output
            'expected':
                '''
                from six import with_metaclass as _py_backwards_six_withmetaclass

                class A(_py_backwards_six_withmetaclass(B)):
                    pass
                '''
        }
    )

    for i, test in enumerate(tests):
        # Print test case title
        print(f'Test case #{i+1}')
        print('=' * 40)

        # Test code transformation
        result = MetaclassTransformer().transform(test['input'])

        # Print test case description

# Generated at 2022-06-12 03:40:47.528184
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # type: () -> None
    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
  
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    node = ast.parse(source)
    mt = MetaclassTransformer()
    mt.visit(node)
    actual = astor.to_source(node)
    print(actual)
    assert actual == expected



# Generated at 2022-06-12 03:40:56.139134
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse("""
        class A(metaclass=B): pass
    """)
    MetaclassTransformer().visit(node)

# Generated at 2022-06-12 03:41:06.011017
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap
    import typed_ast.ast3

    source = textwrap.dedent(
        """\
        class A(metaclass=B):
            pass
        """)
    expected_source = textwrap.dedent(
        """\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """)

    transformer = MetaclassTransformer()
    tree = typed_ast.ast3.parse(source)
    new_tree = transformer.visit(tree)
    source = typed_ast.ast3.unparse(new_tree)

    assert source == expected_source


# Generated at 2022-06-12 03:41:13.990643
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    node = ast.parse('class A(metaclass=B): pass')
    MetaclassTransformer().visit(node)
    assert astor.to_source(node) == 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\n\nclass A(_py_backwards_six_withmetaclass(B))\n    pass\n'

# Generated at 2022-06-12 03:41:22.219540
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astunparse
    from ast import ClassDef
    t = MetaclassTransformer()
    node = ast.parse("class A(B): pass").body[0]
    node = t.visit_ClassDef(node)
    assert astunparse.unparse(node) == "class A(_py_backwards_six_withmetaclass(B)): pass"

    node = ast.parse("class A(): pass").body[0]
    node = t.visit_ClassDef(node)
    assert astunparse.unparse(node) == "class A(): pass"

    node = ast.parse("class A(object=C): pass").body[0]
    node = t.visit_ClassDef(node)
    assert astunparse.unparse(node) == "class A(object=C): pass"



# Generated at 2022-06-12 03:41:27.517151
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.testutils import (
        parse_to_ast_node as p,
        assert_equal_ignoring_whitespace as assert_equal)
    assert_equal(MetaclassTransformer().visit(p("""
        class A(metaclass=B):
            pass
    """)), """
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)

# Generated at 2022-06-12 03:41:28.647611
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-12 03:41:36.957492
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..transformers.base import NodeTransformerTestCase
    from ..transformers.base import run_local_tests

    try:
        from six import with_metaclass
    except ImportError:
        with_metaclass = None

    class test(NodeTransformerTestCase):
        target_versions = (2, 7, )
        transformer = MetaclassTransformer

# Generated at 2022-06-12 03:41:46.728806
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..test_utils import round_trip
    from .class_transformer import ClassTransformer
    from .fix_imports import FixImportsTransformer
    from .fix_unpacking import FixUnpackingTransformer
    from .fix_xrange import FixXrangeTransformer
    from .fix_metaclass import FixMetaclassTransformer
    from .fix_bases import FixBasesTransformer
    from .fix_unpacking_ex import FixUnpackingTransformerEx
    from .fix_paren import FixParenTransformer
    from .fix_division import FixDivisionTransformer
    from .fix_ne import FixNeTransformer

    src = "class A(metaclass=type): pass"

# Generated at 2022-06-12 03:41:49.910787
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_astunparse import dump, unparse
    from typed_ast import ast3 as ast
    from ..utils.tree import to_source

    t = MetaclassTransformer()

# Generated at 2022-06-12 03:41:59.252773
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import os
    import unittest
    from typed_ast import ast3 as ast
    from typed_ast import parse

    from py_backwards.transformers import MetaclassTransformer

    class TestMetaclassTransformer(unittest.TestCase):
        def setUp(self):
            self.transformer = MetaclassTransformer()

        def test_metaclass(self):
            source = '''
                class A(metaclass=B):
                    pass
            '''
            expected = '''
                from six import with_metaclass as _py_backwards_six_withmetaclass


                class A(_py_backwards_six_withmetaclass(B)):
                    pass
            '''
            tree = parse(source)
            new_tree = self.transformer.visit(tree)


# Generated at 2022-06-12 03:42:07.972911
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.ast_builders import build_ast_from_snippet
    expected_output = build_ast_from_snippet(class_bases.get_body(metaclass=ast.Name(id='Object', ctx=ast.Load()),  # type: ignore
                                                                  bases=ast.List(elts=[], ctx=ast.Load())),  # type: ignore
                                             mode='eval')

    class Node(ast.AST):
        pass

    class NodeTransformer(MetaclassTransformer):
        def generic_visit(self, node: ast.AST) -> ast.AST:
            return Node()

    tree = astor.code_to_ast(six_import.get_body() + 'class A(metaclass=object): pass')
    transformer = Node

# Generated at 2022-06-12 03:42:17.971517
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap
    import six
    import astunparse
    import ast
    import textwrap
    metaclass = 'type'
    inp = textwrap.dedent('''
    class A(metaclass=type):
        pass
    ''')

    a = ast.parse(inp)
    a = MetaclassTransformer().visit(a)

    out = astunparse.unparse(a)
    out = textwrap.dedent(out)

    expected = textwrap.dedent('''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(type)):
        pass
    ''')
    six.assertCountEqual(expected, out)

# Generated at 2022-06-12 03:42:25.000612
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
        class A(metaclass=abc.ABCMeta):
            pass
    """
    expected = """
        class A(_py_backwards_six_with_metaclass(abc.ABCMeta)):
            pass
    """
    tree = ast.parse(code)
    MetaclassTransformer.run_pipeline(tree)
    assert_ast_not_equal(code, tree)
    assert_source_equal(tree, expected)


# Generated at 2022-06-12 03:42:29.935896
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
    class A:
        pass
    class B(metaclass=type):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A:
        pass
    class B(_py_backwards_six_withmetaclass(type)):
        pass
    """
    with_metaclass = MetaclassTransformer()
    out = with_metaclass.visit(ast.parse(code))
    assert astor.to_source(out) == expected

# Generated at 2022-06-12 03:42:39.042628
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typing as t
    from typed_ast import ast3 as ast

    node = ast.ClassDef(name='A',
                        bases=[ast.Name(id='B', ctx=ast.Load())],
                        keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='C', ctx=ast.Load()))],
                        body=[],
                        decorator_list=[])

    transformer = MetaclassTransformer(None)
    result = transformer.visit_ClassDef(node)


# Generated at 2022-06-12 03:42:41.514166
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    global _py_backwards_six_with_metaclass
    _py_backwards_six_with_metaclass = lambda metaclass, *bases: bases

# Generated at 2022-06-12 03:42:47.748063
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import compile
    assert compile(
        src='''
        class A(metaclass=B):
            pass
        ''',
        version=(2, 7),
        patch=[MetaclassTransformer],
    ) == '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        '''

# Generated at 2022-06-12 03:42:50.331961
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ast import parse

    six_import_ast = parse(six_import.get_body())
    class_bases_ast = parse(class_bases.get_body())


# Generated at 2022-06-12 03:42:55.803299
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    # test the code "class A():"
    input_code = 'class A():\n\tpass'
    input_tree = ast.parse(input_code)
    output_code = 'class A(_py_backwards_six_withmetaclass(object))\n\tpass\n'
    transformer = MetaclassTransformer()
    output_tree = transformer.visit(input_tree)
    assert astor.to_source(output_tree) == output_code

# Generated at 2022-06-12 03:42:58.300445
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import ast_parse
    class_def = ast_parse(
'''class C(metaclass=type):
    pass''')
    assert type(class_def.bases[0]) is ast.Call


# Generated at 2022-06-12 03:43:04.860454
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    b = ast.parse("""
                class A(metaclass=B):
                    pass
                """)
    b.body[0].keywords[0].value = ast.Name(id='B', ctx=ast.Load())
    t = MetaclassTransformer()
    res = t.visit(b)
    assert ast.dump(res) == ast.dump(b)
    t = MetaclassTransformer()
    _ = t.visit(b)
    assert t._tree_changed == True



# Generated at 2022-06-12 03:43:13.366887
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap
    from ..utils.snippet import snippet
    from ..compat import ParseError
    
    snippet = snippet(textwrap.dedent(
        """
        from abc import ABCMeta
        from six import with_metaclass as _py_backwards_six_with_metaclass
        
        class A(metaclass=ABCMeta):
            pass
        """
    ))

    assert snippet.compile(MetaclassTransformer) == textwrap.dedent(
        """
        from abc import ABCMeta
        from six import with_metaclass as _py_backwards_six_withmetaclass
        
        class A(_py_backwards_six_withmetaclass(ABCMeta)):
            pass
        """
    )


# Generated at 2022-06-12 03:43:23.752356
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_six import assert_transform


# Generated at 2022-06-12 03:43:33.295464
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import astunparse
    node = ast.ClassDef(name='A',
                        bases=[],
                        keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
                        body=[],
                        decorator_list=[])
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)
    assert transformer.tree_changed == True
    assert astunparse.unparse(new_node) == (
        "class A(_py_backwards_six_withmetaclass(B)):\n"
        "    pass"
    )


# Generated at 2022-06-12 03:43:34.855292
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:43:39.492850
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """
    assert MetaclassTransformer().visit_ClassDef(
            ast.parse(
                'class A(metaclass=abc.ABCMeta):'
                '    pass').body[0]) == \
        ast.parse(
            'class A(_py_backwards_six_withmetaclass(abc.ABCMeta)):'
            '    pass').body[0]
    """
    pass

# Generated at 2022-06-12 03:43:46.442370
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .fixtures import transformer_test
    from .utils import pretty_source

    class A: pass
    class B: pass
    class C(B, metaclass=A): pass

    tree = ast.parse(pretty_source(C), mode='exec')
    with transformer_test(MetaclassTransformer, tree) as result:
        assert not hasattr(result, 'metaclass')
        assert result.__bases__ == (_py_backwards_six_withmetaclass(A, B),)


# Generated at 2022-06-12 03:43:54.444432
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = """
    class B(object):
        pass
    class A(metaclass=B):
        pass"""
    expected_result = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class B(object):
        pass
    class A(_py_backwards_six_withmetaclass(B)):
        pass"""
    module = ast.parse(source)
    MetaclassTransformer.run_transform(module)
    assert ast.dump(module) == ast.dump(ast.parse(expected_result))



# Generated at 2022-06-12 03:44:02.322722
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import ClassDef, Str, Num, parse, FunctionDef, Module
    from ..utils.tree_compare import assert_equals

    class TestClass(MetaclassTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return node

    module = parse('''
    class A(metaclass=B):
        pass

    def func():
        pass
    ''')

    expected = parse('''
    _py_backwards_six_withmetaclass(B, *[])

    def func():
        pass
    ''')

    assert_equals(TestClass().visit(module), expected)

# Generated at 2022-06-12 03:44:07.325571
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import assert_node_transformed

    assert_node_transformed(
        MetaclassTransformer,
        """
        class C(metaclass=type):
            pass
        """,
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class C(_py_backwards_six_withmetaclass(type)):
            pass
        """
    )



# Generated at 2022-06-12 03:44:16.329116
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class Test(MetaclassTransformer):
        _tree_changed = False

    node = ast.ClassDef(name='A',
                        bases=[ast.Name(id='B', ctx=ast.Load())],
                        keywords=[ast.keyword(arg='metaclass',
                                              value=ast.Name(id='C', ctx=ast.Load()))])


# Generated at 2022-06-12 03:44:18.285786
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Test the visit_ClassDef method of the MetaclassTransformer (the class tranformer)"""
    fut = MetaclassTransformer()


# Generated at 2022-06-12 03:44:42.934296
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3 as ast

    t = MetaclassTransformer()
    source = 'class A(object, metaclass=type): pass'
    expected = 'class A(_py_backwards_six_withmetaclass(type, object)): pass'

    node = ast.parse(source)
    node = t.visit(node)
    result = ast.unparse(node)
    assert expected == result

# Generated at 2022-06-12 03:44:47.491795
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert compile(ast.parse('''
        class A(metaclass=B):
            pass
    '''),
                   '',
                   mode='exec').co_consts == \
        compile(ast.parse('''
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    '''),
                '',
                mode='exec').co_consts

# Generated at 2022-06-12 03:44:56.166896
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    import six
    import textwrap

    source = textwrap.dedent('''
    class A(object):
        class B(metaclass=C):
            pass
    ''')
    module = parse(source)
    node = module.body[0]
    assert isinstance(node, ast.ClassDef)

    if six.PY3:
        expected = textwrap.dedent('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(object):
            class B(_py_backwards_six_withmetaclass(C)):
                pass
        ''')

# Generated at 2022-06-12 03:45:01.889586
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = dedent("""
    class Foo(metaclass=class_name):
        pass
    class Foo(object):
        pass
    class Foo(metaclass=class_name):
        pass
    class Foo():
        pass
    class Foo(metaclass=class_name):
        pass
    """)

# Generated at 2022-06-12 03:45:08.114443
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from py_backwards.transformers.six import MetaclassTransformer
    t = MetaclassTransformer()
    node = ast.parse('class A(metaclass=B): pass')
    assert astor.to_source(node).strip() == 'class A(metaclass=B): pass'
    t.visit(node)

# Generated at 2022-06-12 03:45:16.519546
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..transpile import Transpiler
    from .util import generate_code

    class TestTranspiler(Transpiler):
        node_transformer_classes = [MetaclassTransformer]

    code = '''
    class A(metaclass=B):
        pass
    '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    tree = ast.parse(code)
    new_tree = TestTranspiler().visit(tree)
    assert generate_code(new_tree) == expected

# Generated at 2022-06-12 03:45:25.554574
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from .ast_helpers import parse

    class TestTransformer:
        test_should_transform = [
            # Test 1
            """
            class Test(object):
                pass
            """,

            # Test 2
            """
            class Test(object,
                       metaclass=abc.A):
                pass
            """,

            # Test 3
            """
            class Test(metaclass=abc.A):
                pass
            """,
        ]

        test_should_not_transform = [
            # Test 1
            """
            class Test(object):
                pass
            """,

            # Test 2
            """
            class Test(object):
                pass
            """,

            # Test 3
            """
            class Test(object):
                pass
            """,
        ]

    # Perform

# Generated at 2022-06-12 03:45:29.144983
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Test case 1
    test_tree = """C(P, metaclass=CMeta)"""  # Test case 1
    test_tree = ast.parse(test_tree)
    parent_tree = ast.parse("""A = 1""")
    parent_tree.body.append(test_tree.body[0])

# Generated at 2022-06-12 03:45:35.325004
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from typed_ast import convert
    from ..utils.test_utils import snippet_to_test_case
    from . import fix_test_cases

    test_cases = snippet_to_test_case(__file__, 'test_MetaclassTransformer_visit_ClassDef')
    fix_test_cases(test_cases, MetaclassTransformer)

    for test_case in test_cases:
        assert test_case.ast_node == convert(test_case.expected_ast, to_py2=False)

# Generated at 2022-06-12 03:45:43.483881
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.ClassDef(
        name='A',
        bases=[],
        keywords=[ast.keyword(arg='metaclass',
                              value=ast.Name(id='B'))],
        body=[],
        decorator_list=[]
    )
    transformer = MetaclassTransformer('')
    node = transformer.visit(node)
    assert transformer._tree_changed
    assert node.bases == [class_bases.get_body()]
    assert node.keywords == []



# Generated at 2022-06-12 03:46:36.646587
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typing import Dict, List, Tuple, Union
    from typed_ast import ast3 as ast

    import_six = ast.Import(names=[ast.alias(
        name='six', asname=None
    )])
    import_six.lineno = 1
    import_six.col_offset = 0

    from_six_import_withmetaclass = ast.FromImport(
        module='six',
        names=[ast.alias(
            name='with_metaclass', asname='_py_backwards_six_withmetaclass'
        )]
    )
    from_six_import_withmetaclass.lineno = 2
    from_six_import_withmetaclass.col_offset = 4


# Generated at 2022-06-12 03:46:43.142805
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    expected = six_import.get_ast()
    expected.body.extend([
        ast.ClassDef(
            name='A',
            bases=[
                ast.Call(
                    func=ast.Attribute(
                        value=ast.Name(id='_py_backwards_six_withmetaclass'),
                        attr='_py_backwards_six_with_metaclass',
                    ), args=[ast.Name(id='y'), ast.Name(id='z')], keywords=[], starargs=None,
                    kwargs=None
                )
            ], body=[], decorator_list=[], keywords=[]
        )
    ])

# Generated at 2022-06-12 03:46:49.102104
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    x = ast.parse('class Foo(metaclass=Bar, baz=qux): pass')
    mt = MetaclassTransformer()
    mt.visit(x)

    assert mt.has_changed()
    assert mt.tree_changed()

    from ..utils.codegen import to_source
    print(to_source(x))


# Generated at 2022-06-12 03:46:54.711729
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
    class Foo(object, metaclass=type):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class Foo(_py_backwards_six_withmetaclass(type, object)):
        pass
    """
    tr = MetaclassTransformer()
    tree = ast.parse(code)
    tr.visit(tree)
    assert astor.to_source(tree) == expected

# Generated at 2022-06-12 03:47:00.848877
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from .asserts import assert_one_error
    from .test_base import TestBase
    source = source('''
    class X(metaclass=Y):
        pass
    ''')
    assert_one_error(MetaclassTransformer, source)
    output = TestBase.compile_and_run(source)
    assert 'class X(object' in output
    assert '_py_backwards_six_withmetaclass(Y' in output
    assert 'pass' in output

# Generated at 2022-06-12 03:47:05.285005
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import compile
    from .class_bases import ClassBasesTransformer
    from .inline import InlineTransformer

    class Metaclass_MetaclassTransformer_visit_ClassDef(object):
        class Test(object):
            pass

    code = compile(Metaclass_MetaclassTransformer_visit_ClassDef.Test, [
        MetaclassTransformer, ClassBasesTransformer, InlineTransformer])
    exec(code, {})



# Generated at 2022-06-12 03:47:07.008706
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()

# Generated at 2022-06-12 03:47:14.870090
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

    class A(metaclass=object):
        pass

    node = ast.parse(dedent(inspect.getsource(A)))

    t = MetaclassTransformer()
    node = t.visit(node)

    assert t._tree_changed
    assert astor.to_source(node) == \
        'import sys\n' \
        '\n' \
        '\n' \
        'from six import with_metaclass as _py_backwards_six_withmetaclass\n' \
        'class A(_py_backwards_six_withmetaclass(object())):\n' \
        '    pass'

# Generated at 2022-06-12 03:47:23.441760
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys, ast, textwrap

    class_name = 'TestClass'

    with_metaclass_class_def = ast.ClassDef(
        name=class_name,
        bases=[
            ast.Name(id='object', ctx=ast.Load())
        ],
        keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='six.with_metaclass', ctx=ast.Load()))],
        body=[],
        decorator_list=[]
    )
    with_metaclass_code = textwrap.dedent(
        """
        class {class_name}(object, metaclass=six.with_metaclass):
            pass
        """.format(
            class_name=class_name
        ))
    with_metaclass_ast = ast.parse

# Generated at 2022-06-12 03:47:24.309491
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:49:25.322024
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap
    from ..utils.python import load_ast, load_srun_ast
    from ..compiler.transformer import compile_ast

    ast_ = load_ast(textwrap.dedent('''\
        class A(metaclass=object):
            pass
    '''))

    ast_expected = load_srun_ast(textwrap.dedent('''\
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(object, *[])):
            pass
    '''))

    ast_actual = MetaclassTransformer().visit(ast_)
    assert compile_ast(ast_actual) == compile_ast(ast_expected)

# Generated at 2022-06-12 03:49:26.100034
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:49:30.109549
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import unittest
    import sys
    import contextlib
    import io
    import unittest.mock
    # Used to manage a fake output stream, as this is not compatible with mocking sys.stdout
    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
  

# Generated at 2022-06-12 03:49:32.779496
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import test_utils as utils

    module = utils.get_tests_modules(__file__, ['test_metaclass.py'])['test_metaclass']
    assert module.test() == "test_metaclass"

# Generated at 2022-06-12 03:49:34.896595
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.compiler import compile_snippet, compile_and_decompile


# Generated at 2022-06-12 03:49:40.501855
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a = ast.ClassDef(name='A', bases=[ast.Name(id='B', ctx=ast.Load())], keywords=[ast.arg(arg='metaclass', value=ast.Name(id='C', ctx=ast.Load()))])

    m = MetaclassTransformer()
    a = m.visit(a)  # type: ignore

    assert ast.dump(a) == "ClassDef(name='A', bases=[_py_backwards_six_withmetaclass(metaclass=Name(id='C', ctx=Load()), *[Name(id='B', ctx=Load())])], keywords=[], body=[])"


# Generated at 2022-06-12 03:49:49.038354
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class MetaclassTransformerTestCase(unittest.TestCase):
        def assertTransformedSourceEquals(self, given: str, expected: str):
            tree = compile(given, '', 'exec', ast.PyCF_ONLY_AST)
            transformer = MetaclassTransformer(tree)
            result = ast.fix_missing_locations(transformer.visit(tree))
            self.assertEqual(ast.dump(result), expected)

    tc = MetaclassTransformerTestCase()
    # Case 1
    tc.assertTransformedSourceEquals(
        "class C: pass",
        "class C: pass")

    # Case 2: