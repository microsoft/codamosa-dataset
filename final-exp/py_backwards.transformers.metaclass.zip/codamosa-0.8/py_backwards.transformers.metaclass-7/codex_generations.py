

# Generated at 2022-06-12 03:39:56.962842
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import run_on_lines
    from .. import tree
    src = '''
    class A(metaclass=B):
        pass
    '''
    assert run_on_lines(MetaclassTransformer, src) == tree('''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    ''')

# Generated at 2022-06-12 03:39:59.840956
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()
    code = 'class A(metaclass=B): pass'
    assert transformer.transform_string(code, 'Example.py') == code

# Generated at 2022-06-12 03:40:07.221664
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse('class A(metaclass=B): pass')
    klass = module.body[0]
    assert [k.value for k in klass.keywords]
    MetaclassTransformer().visit(module)
    assert not klass.keywords
    assert isinstance(klass.bases[0], ast.Call)
    assert klass.bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert len(klass.bases[0].args) == 1
    assert isinstance(klass.bases[0].args[0], ast.Name)
    assert klass.bases[0].args[0].id == 'B'

# Generated at 2022-06-12 03:40:12.802269
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor

    class A(metaclass=type):
        pass
    
    module = ast.Module([ast.ClassDef("A", [], [], [], [], ast.List([ast.Name("type", ast.Load())], ast.Load()))])

    expected = ast.Module([ast.ImportFrom("six", [ast.alias("with_metaclass", "_py_backwards_six_withmetaclass")], 0)])
    expected.body += module.body
    expected = astor.to_source(expected)
    transformer = MetaclassTransformer()
    module_ = transformer.visit(module)
    assert astor.to_source(module_) == expected


# Generated at 2022-06-12 03:40:18.464224
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .codegen import CodeGen
    codegen = CodeGen()
    transformer = MetaclassTransformer()
    node = ast.parse('class A(metaclass=B): pass')
    transformer.visit(node)
    assert codegen.visit(node) == 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass'



# Generated at 2022-06-12 03:40:25.917624
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = """
    # a comment

    class A(metaclass=int):
        pass
    """
    tree = ast.parse(source)
    transformer = MetaclassTransformer(tree)
    expected = """
    # a comment
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(int, )):
        pass
    """
    transformer.visit(tree)
    assert transformer._tree_changed is True
    assert transformer._get_source() == expected


# Generated at 2022-06-12 03:40:35.999719
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    import six

    class A(six.with_metaclass(object)):
        def __init__(self):
            self.bar = 3
            self.baz = 4

    sample = "class A(metaclass=object):\n    def __init__(self):\n        self.bar = 3\n        self.baz = 4\n"
    expected = "class A(_py_backwards_six_withmetaclass(object)):\n    def __init__(self):\n        self.bar = 3\n        self.baz = 4\n"
    # sample = astor.code_to_ast(sample)
    sample = ast.parse(sample)
    transformer = MetaclassTransformer()
    transformer.visit(sample)
    expected = astor.code_

# Generated at 2022-06-12 03:40:43.259402
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from . import test_utils
    import astor

    class_def = ast.parse('''
    class A(metaclass=B):
        pass
    ''')

    transformer = MetaclassTransformer()
    class_def = transformer.visit(class_def)  # type: ignore
    assert astor.to_source(class_def) == '''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    assert transformer.dependencies == ['six']



# Generated at 2022-06-12 03:40:52.373160
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_1 = ast.parse("""\
        class A(): pass
        class B(object): pass
        class C(metaclass=type): pass
        class D(metaclass=type, object): pass
    """)
    expected = ast.parse("""\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(): pass
        class B(_py_backwards_six_withmetaclass(object)): pass
        class C(_py_backwards_six_withmetaclass(type)): pass
        class D(_py_backwards_six_withmetaclass(type, object)): pass
    """)
    result = MetaclassTransformer().visit(module_1)

# Generated at 2022-06-12 03:40:55.232638
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    t = MetaclassTransformer()
    class_ = ast.parse('class A(metaclass=B): pass')

    t.visit(class_)
    assert str(class_) == 'class A(_py_backwards_six_withmetaclass(B)): pass'

# Generated at 2022-06-12 03:40:57.850194
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:41:08.705321
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_visitor import TestVisitor
    from ..utils.test_node import TestNode

    import_six = ast.Import(
        names=[ast.alias(name='six', asname=None)], lineno=2, col_offset=0
    )
    import_six_str = 'from six import with_metaclass as _py_backwards_six_withmetaclass'
    six_import_body = ast.Module(
        body=[ast.ImportFrom(module='six', names=[ast.alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0, lineno=2, col_offset=0)])

# Generated at 2022-06-12 03:41:16.330365
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import six
    from ..tests.utils import node_equals
    
    class A(six.with_metaclass(type)):
        pass
        
    src = six.b('class A(metaclass=type): pass')
    node = ast.parse(src)
    node = MetaclassTransformer().visit(node)  # type: ignore
    code = compile(node, '<test>', 'exec')
    globs = {}
    exec(code, globs)
    assert node_equals(globs['A'],A)

# Generated at 2022-06-12 03:41:21.590920
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..parser import parse
    from ..transformer import TransformerSequence

    source = """
    class A(metaclass=B):
        pass
    """
    module = parse(source)

    transformer_sequence = TransformerSequence(
        transformers=[
            MetaclassTransformer,
        ])
    module = transformer_sequence.visit(module)

    assert module.body[0].value.bases[0].args[0].id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-12 03:41:31.173186
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    import six
    class A:
        pass
    class B(metaclass=six.with_metaclass):
        pass
    class C(A, metaclass=six.with_metaclass):
        pass
    class D(A, B):
        pass
    class E(D, metaclass=six.with_metaclass):
        pass
    class F(A, B, C):
        pass
    class G(A, B, C, metaclass=six.with_metaclass):
        pass
    class H(A, B, C, metaclass=six.with_metaclass, d=1):
        pass

# Generated at 2022-06-12 03:41:38.191159
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3
    from ..testing.visit import assert_visits
    from ..testing.dump import dump, Dump

    node = typed_ast.ast3.ClassDef(name='Foo',
                                   bases=[],
                                   keywords=[typed_ast.ast3.keyword(
                                       arg='metaclass',
                                       value=typed_ast.ast3.Name(id='Bar')
                                   )])

# Generated at 2022-06-12 03:41:47.450829
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import py_backwards.transformers
    import six
    class NodeVisitor(ast.NodeVisitor):
        def __init__(self, tree_changed: bool=False):
            self._tree_changed = tree_changed
            self._depth = 0
            self._current_node = None
            self._elements = []
        def visit(self, node):
            if self._depth == 0:
                self.generic_visit(node)
                return node
            self._elements.append((self._depth, self._current_node, node))
            try:
                self._depth += 1
                return self.generic_visit(node)
            finally:
                self._depth -= 1
        def generic_visit(self, node):
            self._current_node = node
            super().generic_visit

# Generated at 2022-06-12 03:41:54.969453
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    node = ast.ClassDef(
        name='A',
        bases=[],
        keywords=[ast.keyword(arg='metaclass',
                              value=ast.Name(id='B', ctx=ast.Load()))],
        body=[],
        decorator_list=[])
    trans = MetaclassTransformer()
    trans.visit(node)
    assert isinstance(node.bases[0], ast.Call)
    assert node.bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert node.bases[0].args[0].id == 'B'

# Generated at 2022-06-12 03:42:05.235143
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    snippet_from = """\
        class A(object, metaclass=B):
            pass
        """
    snippet_to = """\
        class A(object, _py_backwards_six_withmetaclass(B)):
            pass
        """
    snippet_from_with_multibases = """\
        class A(object, __, metaclass=B):
            pass
        """
    snippet_to_with_multibases = """\
        class A(object, *(_py_backwards_six_withmetaclass(B),), ):
            pass
        """
    ctx = Context()
    nt = MetaclassTransformer()
    assert nt.prerequisites == ['six']

    old_tree = ast.parse(snippet_from)

# Generated at 2022-06-12 03:42:13.798574
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    module = ast.Module(body=[ast.ClassDef(name='A',
                           bases=[ast.Name(id='B', ctx=ast.Load())],
                           keywords=[ast.keyword(arg='metaclass',
                                                 value=ast.Name(id='C', ctx=ast.Load()))],
                           body=[])])

    m = MetaclassTransformer()
    module = m.visit(module)

    assert m._tree_changed

    assert module.body[0].bases[0].func.value.id == '_py_backwards_six_withmetaclass'
    assert module.body[0].keywords == []

# Generated at 2022-06-12 03:42:23.782245
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import parse, ClassDef, Assign, Name, Load, Store

    metaclass = Assign(targets=[Name(id='metaclass',ctx=Store())], value=Name(id='typing',ctx=Load()))
    klass = parse('class A(metaclass=metaclass): pass').body[0]
    classnode = ClassDef(name='A', bases=[], body=[], keywords=[metaclass])
    node = MetaclassTransformer.visit_ClassDef(None, classnode)
    assert node == klass

if __name__ == '__main__':
    test_MetaclassTransformer_visit_ClassDef()

# Generated at 2022-06-12 03:42:28.509930
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_code = contents(__file__).split('# Unit test for method visit_ClassDef of class MetaclassTransformer')[1]
    transformer = MetaclassTransformer(object, {'six': six})  # type: ignore
    assert transformer.visit(ast.parse(test_code)) == ast.parse(test_code.replace('class A(metaclass=B):\n    pass', 'class A(_py_backwards_six_withmetaclass(B))'))

# Generated at 2022-06-12 03:42:37.253142
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = '''class A(object):
    pass'''
    expected = '''class A(_py_backwards_six_with_metaclass(object)):
    pass'''
    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # Trigger a warning.
        result = MetaclassTransformer().visit(ast.parse(source))
        assert len(w) == 1
        assert issubclass(w[-1].category, DeprecationWarning)
        assert "some modules could not be imported" in str(w[-1].message)
        assert ast.dump(result) == expected



# Generated at 2022-06-12 03:42:38.248068
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor  # type: ignore

# Generated at 2022-06-12 03:42:45.136980
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .base import BaseTestTransformer
    from ..utils.snippet import snippet
    
    class Test(BaseTestTransformer):
        target = (2, 7)
        dependencies = ['six']

        @snippet
        def before(metaclass):
            class A(metaclass=metaclass):
                pass

        @snippet
        def after():
            class A(_py_backwards_six_withmetaclass(metaclass)):
                pass

    Test.test_transform()


# Generated at 2022-06-12 03:42:49.621017
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..tests.test_utils.snippet import snippets
    from ..utils.source import source

    tree = snippets['method']['with_metaclass']
    transformer = MetaclassTransformer()
    transformer.visit(tree)

    assert not tree.body[0].keywords
    assert source(tree) == snippets['method']['with_metaclass']['fixed']

# Generated at 2022-06-12 03:42:51.233456
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .base import BaseNodeTransformerTest
    from ..utils.tree import build_ast_tree


# Generated at 2022-06-12 03:42:58.881300
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # type: () -> None
    import textwrap
    from typing import Callable
    import unittest
    import sys
    import astor
    from six import exec_

    # type: () -> None
    class TestMetaclassTransformer(unittest.TestCase):
        # type: () -> None
        def assert_unchanged(self, code, *args, **kwargs):
            # type: (str, *Any, **Any) -> None
            self._assert_code(code, code, *args, **kwargs)

        def _assert_code(self, expected, code, *args, **kwargs):
            # type: (str, str, *Any, **Any) -> None
            tree = ast.parse(code)
            transformer = MetaclassTransformer(*args, **kwargs)
            transformer.visit

# Generated at 2022-06-12 03:43:04.820568
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.syntax import to_source
    expected = 'class A(_py_backwards_six_withmetaclass(B)):\n    pass\n'
    expected = expected.lstrip()
    
    tree = ast.parse('class A(metaclass=B): pass')
    metaclass = MetaclassTransformer()
    metaclass.visit(tree)
    actual = to_source(tree).strip()
    assert expected == actual

# Generated at 2022-06-12 03:43:12.766562
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from six import with_metaclass as _py_backwards_six_withmetaclass
    from typed_ast import ast3 as ast
    tr = MetaclassTransformer()
    r = tr.visit(ast.parse('''
        class A(metaclass=B):
            pass
    '''))
    assert(r.body[0].body[0].bases[0] == ast.Call(
        func=ast.Name(id='_py_backwards_six_withmetaclass', ctx=ast.Load()),
        args=[ast.Name(id='B', ctx=ast.Load())],
        keywords=[],
        starargs=None,
        kwargs=None))

# Generated at 2022-06-12 03:43:24.849757
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    print('Test: visit_ClassDef()')
    module = ast.parse('class A(metaclass=B): pass')
    node = module.body[0]
    assert type(node) is ast.ClassDef
    meth = MetaclassTransformer()
    meth.visit(node)
    assert node.bases == [ast.Call(func=ast.Name(id='_py_backwards_six_withmetaclass', ctx=ast.Load()),
                                   args=[ast.Name(id='B', ctx=ast.Load())], keywords=[],
                                   starargs=None, kwargs=None)]
    assert node.keywords == []
    assert meth._tree_changed is True

# Generated at 2022-06-12 03:43:26.033930
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-12 03:43:32.470029
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # This is a doctest.
    # >>> t = MetaclassTransformer()
    # >>> tree = ast.parse("class A(metaclass=int):pass", 'foo.py', 'exec')
    # >>> t.visit(tree)
    # <_ast.Module object at 0x...>
    # >>> t._tree_changed
    # True
    # >>> tree
    # <_ast.Module object at 0x...>
    pass

# Generated at 2022-06-12 03:43:39.093158
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import sys
    import six

    expected = """class MetaclassTransformer(BaseNodeTransformer):
    """

    if six.PY2:
        node = ast.parse(expected)
        tree_changed = False
        transformer = MetaclassTransformer(sys.modules[__name__], sys.modules[six.__name__])
        actual = ast.fix_missing_locations(transformer.visit(node))
        assert transformer.tree_changed == tree_changed
        assert ast.dump(actual) == ast.dump(node)
    else:
        expected = """class MetaclassTransformer(BaseNodeTransformer):
    """
        node = ast.parse(expected)
        tree_changed = False

# Generated at 2022-06-12 03:43:41.093720
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import unittest.mock
    from ..utils import fake

    t = MetaclassTransformer()


# Generated at 2022-06-12 03:43:41.660185
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:43:47.196842
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import transform
    from .. import versioning

    data = """class A(metaclass=B): pass"""
    expect = """class A(_py_backwards_six_with_metaclass(B)): pass"""
    tree = ast.parse(data)
    tr = transform.Transformer(MetaclassTransformer)
    new_tree = versioning.apply_transformer(tr, tree)
    assert ast.dump(new_tree) == expect

# Generated at 2022-06-12 03:43:58.300196
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import assert_transformed_code_is
    assert_transformed_code_is(MetaclassTransformer, """
        class A:
            pass
    """, """
        class A:
            pass
    """)
    assert_transformed_code_is(MetaclassTransformer, """
        class A(metaclass=B):
            pass
    """, """
        from six import with_metaclass
        class A(with_metaclass(B)):
            pass
    """)
    assert_transformed_code_is(MetaclassTransformer, """
        class A(B, metaclass=C):
            pass
    """, """
        from six import with_metaclass
        class A(with_metaclass(C), B):
            pass
    """)
    assert_

# Generated at 2022-06-12 03:44:04.229965
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_str, get_ast

    run_test = MetaclassTransformer().visit(get_ast(
        '''
        from six.moves import UserDict
        class MyList(list, metaclass=UserDict):
            ...
        '''
    ))
    assert ast_str(run_test) == '''
    from six.moves import UserDict
    class MyList(_py_backwards_six_withmetaclass(UserDict, list)):
        pass
    '''

    run_test = MetaclassTransformer().visit(get_ast(
        '''
        class MyList(list):
            ...
        '''
    ))

# Generated at 2022-06-12 03:44:13.350763
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class Dummy:
        pass

    expected_result = ast.Module(body=[
        class_bases.get_body(metaclass=ast.Name(id='a', ctx=ast.Load()),
                             bases=ast.List()),
        ast.Expr(value=ast.Call(func=ast.Name(id='print', ctx=ast.Load()),
                                args=[ast.Name(id='a', ctx=ast.Load())],
                                keywords=[])),
        ast.Expr(
            value=ast.Call(func=ast.Name(id='print', ctx=ast.Load()),
                           args=[ast.Call(func=ast.Name(id='a', ctx=ast.Load()),
                                          args=[], keywords=[])],
                           keywords=[]))])

# Generated at 2022-06-12 03:44:24.744982
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_astunparse
    import astunparse
    import textwrap
    source = "class A(metaclass=A): pass"
    module = typed_ast.ast3.parse(textwrap.dedent(source))
    module = MetaclassTransformer().visit(module)
    assert typed_astunparse.unparse(module) == astunparse.unparse(module)

# Generated at 2022-06-12 03:44:31.915287
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...testing import assert_string_arrays
    from typed_ast import ast3 as ast

    node = ast.ClassDef(name="Foo",  # type: ignore
                        keywords=[ast.Keyword(arg="metaclass", value=ast.Name(id="A"))],
                        bases=[ast.Name(id="B")],
                        body=[],
                        decorator_list=[])
    assert_string_arrays(MetaclassTransformer().visit(node), '''
        class Foo(_py_backwards_six_withmetaclass(A)):
            pass
    ''')

# Generated at 2022-06-12 03:44:38.961699
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node_ClassDef = ast.parse('''class A(B, metaclass=C): pass''').body[0]
    node_ClassDef_expected = ast.parse('''
        class A(_py_backwards_six_withmetaclass(C, B)): pass
        ''').body[0]

    transformer = MetaclassTransformer(source_version=(2, 7))
    node_ClassDef_actual = transformer.visit(node_ClassDef)
    assert ast.dump(node_ClassDef_actual) == ast.dump(node_ClassDef_expected)

# Generated at 2022-06-12 03:44:40.170996
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typing import List

# Generated at 2022-06-12 03:44:47.730973
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    input_code = "class X(metaclass=A):\n" \
                 "    pass"

    expected_code = "from six import with_metaclass as _py_backwards_six_withmetaclass\n" \
                    "\n" \
                    "class X(_py_backwards_six_withmetaclass(A)):\n" \
                    "    pass\n"

    result = compile(input_code, f'<string>', 'exec')
    module = MetaclassTransformer().visit(ast.parse(input_code))
    compiled_module = compile(module, f'<string>', 'exec')

    assert eval(compiled_module) == eval(expected_code)

# Generated at 2022-06-12 03:44:51.457980
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    map = {}
    code = """
    class MyClass(metaclass=Foo):
        pass
    """
    tree = ast.parse(code)
    mt = MetaclassTransformer()
    mt.visit(tree)
    assert mt._tree_changed is True

# Generated at 2022-06-12 03:44:52.295072
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:44:57.694706
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from typed_ast import ast3
    node = ast.parse('class A(metaclass=B): pass')
    MetaclassTransformer().visit(node)
    expected = astor.to_source(ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass; class A(_py_backwards_six_withmetaclass(B)): pass'))
    assert astor.to_source(node) == expected



# Generated at 2022-06-12 03:45:03.849223
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .utils import round_trip
    from .visitor import Python3Visitor
    from .utils import parse

    metaclass = ast.Name(id="object", ctx=ast.Load())
    base = ast.Name(id="Base", ctx=ast.Load())
    classdef = parse("""
        class A(metaclass=object, Base):
            pass
        """)  # type: ast.FunctionDef

    assert Python3Visitor().visit(classdef) == parse("""
        class A(_py_backwards_six_with_metaclass(object, Base)):
            pass
        """)

    # Test round trip

# Generated at 2022-06-12 03:45:07.450774
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse("""class A(metaclass=B, c=d): pass""")
    mt = MetaclassTransformer()
    mt.visit(node)
    print(ast.dump(node))



# Generated at 2022-06-12 03:45:24.834073
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

# Generated at 2022-06-12 03:45:30.964408
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse("""
        class A(object):
            pass
    """)
    # Apply MetaclassTransformer
    module = MetaclassTransformer().visit(module)
    # Assert
    assert isinstance(module.body[0].bases[0], ast.Call)
    assert isinstance(module.body[0].bases[0].func, ast.Name)
    assert module.body[0].bases[0].func.id == '_py_backwards_six_with_metaclass'
    assert module.body[0].bases[0].keywords[0].arg == 'metaclass'
    assert isinstance(module.body[0].bases[0].keywords[0].value, ast.Name)

# Generated at 2022-06-12 03:45:38.219615
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Setup
    test_case = {
        2: {
            7: {
                'class': {
                    'body': [
                        'class A(metaclass=B):',
                        '    pass',
                    ],
                    'indent': 0,
                }
            }
        }
    }

    # Exercise
    node = MetaclassTransformer()(ast3.parse(test_case[2][7]['class']['body'][0]))

    # Verify
    assert_equal(node.body[0].bases[0].args[0].id, 'B')

# Generated at 2022-06-12 03:45:47.407764
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..helpers import assert_equal

    metaclass = ast.Str('metaclass')
    bases = [ast.Name(id='B', ctx=ast.Load())]
    node = ast.ClassDef(name='A', 
                        bases=bases, 
                        keywords=[ast.keyword(arg='metaclass', value=metaclass)])

    expected = ast.ClassDef(name='A',
                            bases=class_bases.get_body(metaclass=metaclass,  # type: ignore
                                                       bases=ast.List(elts=bases)))

    transformer = MetaclassTransformer()
    actual = transformer.visit(node)

    assert_equal(actual, expected)

# Generated at 2022-06-12 03:45:53.375548
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # type: () -> None
    source = '''
    class A(metaclass=B):
        pass
    '''

    # Create node
    node = ast.parse(source)

    # Execute transformer
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)

    # Compare node tree
    assert ast.dump(new_node) == ast.dump(ast.parse('class A(_py_backwards_six_with_metaclass(B)): pass'))

# Generated at 2022-06-12 03:45:58.827683
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    
    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    node = ast.parse(source)
    MetaclassTransformer().visit(node)
    assert ast.dump(node) == expected


# Generated at 2022-06-12 03:46:08.703872
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class Node:
        def __init__(self, string: str):
            self.string = string

        def __repr__(self) -> str:
            return '<py_backwards Node: %s>' % self.string

        def __eq__(self, other) -> bool:
            return isinstance(other, Node) and self.string == other.string

        def __hash__(self) -> int:
            return hash(self.string)

    def test_case(before, after):
        before = ast.parse(before)
        after = ast.parse(after)
        MetaclassTransformer().visit(before)
        assert before == after

    def make_node(string):
        node = Node(string)
        return ast.Name(id=string, ctx=ast.Load(), annotation=None)


# Generated at 2022-06-12 03:46:15.404649
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ._test_utils import round_trip
    test_source = source('''
            class A(metaclass=B):
                pass
            ''')

    # Basic Test
    assert round_trip(test_source,
                      MetaclassTransformer,
                      target=(2, 7)) == source('''
            from six import with_metaclass as _py_backwards_six_withmetaclass

            class A(_py_backwards_six_withmetaclass(B)):
                pass
            ''')

# Generated at 2022-06-12 03:46:20.413928
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    def transform(r):
        module = ast.parse(r)
        transformer = MetaclassTransformer()
        transformer.visit(module)
        return module

    module = transform(r'''
        class A(metaclass=int):
            pass
    ''')

    assert module.body[0].bases[0].func.value.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-12 03:46:29.092074
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    args: tuple = ()
    keywords: list = [
        ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))
    ]
    body: list = [
        ast.Expr(value=ast.Name(id='pass', ctx=ast.Load()))
    ]
    classdef: ast.ClassDef = ast.ClassDef(name='A', args=args, keywords=keywords,
                                          body=body, decorator_list=[])
    classdef: ast.ClassDef = MetaclassTransformer().visit(classdef)
    assert classdef.bases == class_bases.get_body(metaclass=None, bases=None)
    assert classdef.keywords == []

# Generated at 2022-06-12 03:47:05.699121
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..test import transform_and_compare

    from .._test_utils import tr

    with_metaclass = tr('''
        class A(with_metaclass=B):
            pass

        class B:
            pass
    ''')

    plain = tr('''
        class A(B):
            pass

        class B:
            pass
    ''')

    six_with_metaclass = tr('''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

        class B:
            pass
    ''')

    transform_and_compare(MetaclassTransformer(), with_metaclass, plain)

# Generated at 2022-06-12 03:47:15.306421
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import assert_text_transformation

    # class A(metaclass=B):
    #     pass
    # ->
    # class A(_py_backwards_six_with_metaclass(B))
    assert_text_transformation(
        """
        class A(metaclass=B):
            pass
        """,
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """,
        [MetaclassTransformer],
        target=(2, 7)
    )

    # class A(B, metaclass=C):
    #     pass
    # ->
    # class A(_py_backwards_six_with_metaclass(C

# Generated at 2022-06-12 03:47:21.299458
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_equal
    import astor

    snippet = """
    class Foo(metaclass=Bar):
        pass
    """

    expected = """
    class Foo(_py_backwards_six_withmetaclass(Bar)):
        pass
    """

    module = ast.parse(snippet)
    module: ast.Module
    MetaclassTransformer().visit(module)
    result = astor.to_source(module)
    assert_equal(result, expected)

# Generated at 2022-06-12 03:47:29.632952
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    import sys

    class A(metaclass=int):
        pass

    expected_ast = ast.Module(body=[
        ast.ImportFrom(module='six', names=[
            ast.alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')
        ], level=0),
        ast.ClassDef(name='A', bases=[
            ast.Call(func=ast.Name(id='_py_backwards_six_withmetaclass', ctx=ast.Load()),
                     args=[ast.Num(n=int), ast.Name(id='object', ctx=ast.Load())], keywords=[])
        ], keywords=[], body=[], decorator_list=[])
    ])


# Generated at 2022-06-12 03:47:32.850630
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = MetaclassTransformer
        target = (2, 7)
        dependencies = ['six']

# Generated at 2022-06-12 03:47:34.241552
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Test that ClassDef nodes are visited and the
    metaclass keyword is moved to the class bases.
    """

# Generated at 2022-06-12 03:47:39.136054
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap
    module = textwrap.dedent('''
        class A(metaclass=B):
            pass
    ''')
    tree = ast.parse(module)
    t = MetaclassTransformer()
    t.visit(tree)
    expected = textwrap.dedent('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B, )):
            pass
    ''')
    actual = compile(tree, '<test>', 'exec').co_consts[1]
    assert actual == expected

# Generated at 2022-06-12 03:47:43.620283
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def = ast.ClassDef(
        name='A',
        bases=[],
        keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B'))],
        body=[],
        decorator_list=[]
    )
    node = MetaclassTransformer().visit(class_def)
    assert node == ast.ClassDef(
        name='A',
        bases=[ast.Call(
            func=ast.Name(id='_py_backwards_six_withmetaclass'),
            args=[ast.Name(id='B')],
            keywords=[], starargs=None, kwargs=None
        )],
        keywords=[],
        body=[],
        decorator_list=[]
    )


# Generated at 2022-06-12 03:47:51.847062
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import sys
    from test.backport_test_util import MetaTestCase

    class MetaclassTransformerTest(MetaTestCase):
        transformer = MetaclassTransformer
        target = (2, 7)
        dependencies = ['six']

        def test_class_with_metaclass(self):
            class Foo(metaclass=object):
                pass

            class Foo2(metaclass=Foo):
                pass

            tree = ast.parse(self.transform())

# Generated at 2022-06-12 03:48:00.658433
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3 as ast

    code = '''
            class A(metaclass=B):
                pass
            '''

    expected = '''
            from six import with_metaclass as _py_backwards_six_withmetaclass

            class A(_py_backwards_six_withmetaclass(B))
                pass
            '''

    from .base import BaseNodeTransformerTest
    from ..utils.cst import parse_module

    class Test(BaseNodeTransformerTest):
        Transformer = MetaclassTransformer

        def test_simple_one(self, transform):
            module = parse_module(code)
            module = transform(module)
            self.assertEqual(ast.dump(module), expected)

    Test().test_simple_one()

# Generated at 2022-06-12 03:49:23.445118
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from astor.code_gen import to_source
    from ..utils.test_utils import source_to_ast, compare_source

    source = """class Test(metaclass=abc.ABCMeta):
    pass
    """
    ast_tree = source_to_ast(source)

# Generated at 2022-06-12 03:49:31.797209
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

    class B:
        pass

    @six.add_metaclass(B)
    class A:
        pass

    source = dedent("""
    class A(metaclass=B):
        pass
    """)

    tree = ast.parse(source)
    transformer = MetaclassTransformer()
    new_tree = transformer.visit(tree)
    result = astor.to_source(new_tree)
    expect = dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B, ())):
        pass
    """)

    assert result == expect

    # this is a extra test added to ensure the ClassDef is properly
    # skipeed in the generic_vis

# Generated at 2022-06-12 03:49:38.688598
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from . import compile_source

    from .six_import import six_import
    from .class_bases import class_bases

    tree = compile_source("""
        class A(metaclass=B):
            pass
    """)

    tree = MetaclassTransformer().visit(tree)

    assert [n.name for n in tree.body] == ['_py_backwards_six_with_metaclass', 'A']
    assert six_import in tree.body  # type: ignore
    assert class_bases(metaclass=ast.Name(id='B', ctx=ast.Load()),  # type: ignore
                       bases=ast.List(elts=[], ctx=ast.Load())) in tree.body[1].bases  # type: ignore

# Generated at 2022-06-12 03:49:43.755460
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_utils import make_test, round_trip


# Generated at 2022-06-12 03:49:51.565993
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse("""
        class A:
            pass
    """)
    exp_ast = ast.parse("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)

    class_def = module.body[0]
    exp_class_def = exp_ast.body[1]
    class_def.keywords = [ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))]

    trans = MetaclassTransformer(2, 7)
    res = trans.visit_ClassDef(class_def)
