

# Generated at 2022-06-12 03:39:52.598091
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import dump_b, dump_d
    import unittest
    
    
    
    
    
    
    
    class Test(unittest.TestCase):
        def test_1(self):
            source = """
            class A(metaclass=B):
                pass
            """
            expected_source = """
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A(_py_backwards_six_withmetaclass(B)):
                pass
            """
            
            # Compile the module
            module = ast.parse(source)
            
            # Apply the transform
            transformer = MetaclassTransformer()
            new_module = transformer.visit(module)  #

# Generated at 2022-06-12 03:39:53.190515
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-12 03:39:59.301470
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
    class A(metaclass=B):
        pass
    """
    correct_result = """
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    test_module = ast.parse(code)
    transformer = MetaclassTransformer()
    transformed_module = transformer.visit(test_module)
    assert_source_equal(correct_result, transformed_module)

# Generated at 2022-06-12 03:40:06.142553
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    tree_string = inspect.cleandoc("""
    class A(metaclass=str):
        pass
    """)
    tree = ast.parse(tree_string)
    expected_string = inspect.cleandoc("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
    class A(_py_backwards_six_withmetaclass(str)):
        pass
    """)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert astunparse.unparse(tree) == expected_string



# Generated at 2022-06-12 03:40:08.751153
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_docstring, get_names, get_docstring_from_annotation


# Generated at 2022-06-12 03:40:12.497949
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import assert_source

    assert_source(MetaclassTransformer, "class A(metaclass=B): pass", """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)

# Generated at 2022-06-12 03:40:19.126112
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()
    module = ast.parse(
        '''
        class A(metaclass=MyMeta):
            pass
        '''
    )
    result = transformer.visit(module)
    expected = ast.parse(
        '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(MyMeta)):
            pass
        '''
    )
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-12 03:40:28.998118
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3
    from textwrap import dedent

    class DummyMeta(ast3.stmt):
        _fields = ("name",)
        def __init__(self, name, **kwargs):
            self.name = name
    dummymeta = DummyMeta("DummyMeta")

    node = ast3.parse(dedent("""
        class A(metaclass=DummyMeta):
            pass
    """))

    transformer = MetaclassTransformer()
    newnode = transformer.visit(node)

    assert newnode is not node
    # Check that the node has been transformed
    assert len(newnode.body) == 3
    assert isinstance(newnode.body[0], ast3.ImportFrom)
    assert isinstance(newnode.body[1], ast3.FunctionDef)

# Generated at 2022-06-12 03:40:31.148927
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.testutils import check_transformer

# Generated at 2022-06-12 03:40:40.869890
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("""
    class A(metaclass=B):
        pass
    class B(metaclass=C):
        pass
    class C(metaclass=D):
        pass
    """)

    metaclass_transformer = MetaclassTransformer(tree=node, import_rewriter=MagicMock())
    transformed_node = metaclass_transformer.visit(node)

# Generated at 2022-06-12 03:40:54.253411
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast2ast import parse_to_ast, parse_to_expr
    from ..utils.ast_builder import AstList
    from ..utils.tree import eval_expr
    import contextlib
    import sys

    class FakeNode(ast.AST):
        _fields = []

    def get_keywords(metaclass: ast.AST) -> AstList:
        metaclass_kw = ast.keyword(arg="metaclass", value=metaclass)
        return AstList(metaclass_kw)

    class M(metaclass=type):
        pass


# Generated at 2022-06-12 03:41:02.583416
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_utils import round_trip
    from typed_ast import ast3 as ast
    from textwrap import dedent
    source = dedent('''\
    class A(metaclass=B):
        pass''')
    tree = ast.parse(source)
    target = dedent('''\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
    class A(_py_backwards_six_withmetaclass(B, )):
        pass''')
    expected_tree = ast.parse(target)
    check_tree = round_trip(tree, MetaclassTransformer)
    assert check_tree == expected_tree

# Generated at 2022-06-12 03:41:03.781315
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:41:08.614432
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3
    from .six_import_transformer import SixImportTransformer
    import sys
    import six
    if sys.version_info[:2] >= (2, 7):
        return

    class MyMeta(type): pass


# Generated at 2022-06-12 03:41:14.275518
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    def compile(string):
        return compile(string, '<string>', 'exec')

    def transform(string):
        tree = ast.parse(string)
        tree = MetaclassTransformer().visit(tree)
        return compile(tree, '<string>', 'exec')

    assert transform('class A(metaclass=type): pass') ==\
            transform('class A: pass')

# Generated at 2022-06-12 03:41:22.377367
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class Person(object):
        def __init__(self, name):
            self.name = name

# Generated at 2022-06-12 03:41:27.645195
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typing import List
    from typed_ast import ast3 as ast

    text = '''class A(metaclass=B):\n    pass'''
    tree = ast.parse(text)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed


# Generated at 2022-06-12 03:41:32.404966
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    st = ast.parse("class A(metaclass=B): pass")
    target = ast.parse("class A(_py_backwards_six_with_metaclass(B)): pass")
    result = MetaclassTransformer().visit(st)

    assert ast.dump(target) == ast.dump(result)


# Generated at 2022-06-12 03:41:38.695171
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast as pyast
    from typed_ast import ast3 as typed_pyast
    from .util import transform
    from typing import List, Type

    def visit_ClassDef(node: typed_pyast.ClassDef) -> List[pyast.stmt]:
        transformer = MetaclassTransformer(2, 7, 'foobar')
        transformer.visit(node)
        return [typed_pyast.parse(transformer.code(), mode='exec')]

    node = pyast.parse("""class A(metaclass=B): pass""")

    transformed = transform(node, visit_ClassDef)

    assert """class A(_py_backwards_six_with_metaclass(B)):
    pass
""" in transformed


# Generated at 2022-06-12 03:41:44.594157
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_visitor import dump
    import astor
    tree = ast.parse('class Foo(metaclass=type): pass')
    t = MetaclassTransformer()
    res = t.visit(tree)
    dump(res)
    assert astor.to_source(res) == """from six import with_metaclass as _py_backwards_six_withmetaclass

_py_backwards_six_withmetaclass(type, object)"""


# Generated at 2022-06-12 03:41:49.774853
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:41:51.733966
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from astunparse import unparse


# Generated at 2022-06-12 03:41:59.740002
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import compile
    from ..utils.compare_ast import compare_ast
    from ..utils import cst as CST

    # --------- TEST: ---------------------------------------
    classdef = CST.parse_statement("""\
        class A(metaclass=B):
            pass
        """)

    expected_classdef = CST.parse_statement("""\
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """)

    # --------- CODE UNDER TEST: ----------------------------
    tree = MetaclassTransformer.run_pipeline(classdef)

    # --------- ASSERTIONS AFTER TEST: ---------------------
    compare_ast(tree, expected_classdef)

# Generated at 2022-06-12 03:42:07.189718
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from tests.utils import render_to_python

    code = """
    class A(B):
        pass
    """
    assert render_to_python(code) == render_to_python(MetaclassTransformer, code)

    code = """
    class A(metaclass=B):
        pass
    """
    assert render_to_python(code) == render_to_python(MetaclassTransformer, code)

    code = """
    class A(metaclass=B, x, y):
        pass
    """
    assert render_to_python(code) == render_to_python(MetaclassTransformer, code)

# Generated at 2022-06-12 03:42:16.190621
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap
    from ..replacer import Replacer

    source = textwrap.dedent("""\
        class A:
            pass
        
        class B(C):
            pass
            """)

    tree = ast.parse(source)
    r = Replacer(tree)
    transformer = MetaclassTransformer()
    transformer.visit(tree)

    expected = textwrap.dedent("""\
        from six import with_metaclass as _py_backwards_six_withmetaclass


        class A:
            pass


        class B(_py_backwards_six_withmetaclass(C), *[])):
            pass
            """)

    assert tree == ast.parse(expected)

# Generated at 2022-06-12 03:42:25.429134
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from six import with_metaclass
    from ..transformers.metaclass import MetaclassTransformer, six_import, class_bases
    trans = MetaclassTransformer()
    ast_node = ast.parse("""
        class A(metaclass=B):
            pass
        class C(object):
            pass
        class D(metaclass=E):
            pass
        class F(metaclass=G):
            pass
    """)
    trans.visit(ast_node)
    assert trans._tree_changed

# Generated at 2022-06-12 03:42:34.741989
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class Mock(MetaclassTransformer):
        def __init__(self, code, expected_code):
            self._expected_code = expected_code
            super(Mock, self).__init__(code, ())

        def write(self, code):
            assert self._expected_code == code
            print('Test OK')
    
    import os, sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    
    assert not hasattr(ast, 'metaclass')
    old_value = ast.ClassDef.keywords
    ast.ClassDef.keywords = [ast.arg('metaclass', None)]

# Generated at 2022-06-12 03:42:40.439323
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as typed_ast
    code = 'class A(metaclass=B):'
    tree = typed_ast.parse(code)
    transformed_tree = MetaclassTransformer().visit(tree)
    expected_code = 'from six import with_metaclass as _py_backwards_six_withmetaclass; class A(_py_backwards_six_withmetaclass(B)): pass'
    expected_tree = typed_ast.parse(expected_code)
    assert typed_ast.dump(transformed_tree) == typed_ast.dump(expected_tree)

# Generated at 2022-06-12 03:42:50.168613
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.syntax import check_syntax

    class_def = ast.ClassDef(name='A',
                             bases=[],
                             keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
                             decorator_list=[],
                             body=[])
    node = ast.Module(body=[class_def])
    node = MetaclassTransformer().visit(node)


# Generated at 2022-06-12 03:42:55.686000
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    from typed_ast import ast3 as ast
    transformer = MetaclassTransformer()
    module = ast.parse(textwrap.dedent('''
        class Test(metaclass=type): pass
    '''))

    # When
    module = transformer.visit(module)  # type: ignore

    # Then
    assert 'class Test(_py_backwards_six_withmetaclass(type)):\n    pass' in \
           ast.dump(module)



# Generated at 2022-06-12 03:43:10.419960
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...utils import ast_parse
    snippet = ast_parse('''
    class Test(metaclass=int):
        pass
    ''')
    fix = snippet.fix(MetaclassTransformer)
    assert str(fix[0]) == 'from six import with_metaclass as _py_backwards_six_withmetaclass'
    assert str(fix[1]) == 'class Test(_py_backwards_six_withmetaclass(int))'
    assert len(fix) == 2



# Generated at 2022-06-12 03:43:18.917664
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    import six
    from ..utils.transform import compile_transform


    @six.add_metaclass(type)
    class A():
        pass

    class B():
        pass

    env = {}
    code = "class A(metaclass=type):\n    pass\n"
    transform = compile_transform(MetaclassTransformer, "test_MetaclassTransformer_visit_ClassDef")
    expected = compile(code, "<string>", "exec")
    output = compile(transform(code), "<test>", "exec")
    exec(expected, env)
    assert env['A'].__class__.__name__ == 'A'
    assert env['A'].__name__ == 'A'
    exec(output, env)
    assert env['A'].__class__.__name

# Generated at 2022-06-12 03:43:26.823832
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3
    from typed_ast.ast3 import Module, ClassDef, Name, Str, arguments, keyword, Num, Subscript, Expr, List, Compare, If, Attribute, Name as Name1
    class A(typed_ast.ast3.NodeTransformer):
        def generic_visit(self, node):
            """ Called if no explicit visitor function exists for a
                node. Implements preorder visiting of the node.
            """
            for field, old_value in typed_ast.iter_fields(node):
                if isinstance(old_value, list):
                    new_values = []
                    for value in old_value:
                        if isinstance(value, typed_ast.AST):
                            value = self.visit(value)
                            if value is None:
                                continue
                            el

# Generated at 2022-06-12 03:43:35.944977
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from unittest import TestCase
    from typed_ast import ast3 as ast
    from ..utils.testing import fix_whitespace
    input = ast.parse('class A(metaclass=B): pass')
    expected = ast.parse(fix_whitespace('''
    from six import with_metaclass as _py_backwards_six_withmetaclass 
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''))
    transformer = MetaclassTransformer()
    actual = transformer.visit(input)
    assert ast.dump(actual) == ast.dump(expected)



# Generated at 2022-06-12 03:43:42.736552
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.unparse import Unparser
    import textwrap

    source = textwrap.dedent("""
    class A(metaclass=B):
        pass
    """)
    code = ast.parse(source)

    t = MetaclassTransformer(code)
    result = t.visit(code)
    assert Unparser(result) == textwrap.dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)



# Generated at 2022-06-12 03:43:43.607309
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:43:46.921934
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor   # type: ignore
    source = '''class A(metaclass = B):
    pass'''

# Generated at 2022-06-12 03:43:57.913582
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    from typed_ast import ast3 as ast
    from ..utils.meta import get_nodes_of_class

    source = """
            class A(B, C, D, metaclass=E):
                pass
            """
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)

    source = """
            class A(_py_backwards_six_withmetaclass(E, B, C, D)):
                pass
            """
    expected_tree = ast.parse(source)

    assert len(get_nodes_of_class(tree, ast.ImportFrom)) == 1
    assert len(get_nodes_of_class(expected_tree, ast.ImportFrom)) == 1


# Generated at 2022-06-12 03:43:59.144211
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.builder import build


# Generated at 2022-06-12 03:44:04.555310
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class TestVisitor1(ast.NodeVisitor):
        def visit_ClassDef(self, node: ast.ClassDef) -> None:
            assert node.keywords == []

    class TestVisitor2(ast.NodeVisitor):
        def visit_Call(self, node: ast.Call) -> None:
            assert node.args[0].id == "B"

    module = ast.parse(textwrap.dedent("""
        class A(metaclass=B):
            pass
    """))
    expected = ast.parse(textwrap.dedent("""
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """))
    MetaclassTransformer().visit(module)
    TestVisitor1().visit(module)

# Generated at 2022-06-12 03:44:31.638622
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()
    source = """class A():
        pass"""
    expected = """class A():
        pass"""
    with mock.patch.object(transformer, '_tree_changed', False):
        source_ast = ast.parse(source)
        transformer.visit(source_ast)
        assert ast.dump(source_ast) == expected
        assert transformer._tree_changed is False

    source = """class A(metaclass=ABCMeta):
        pass"""
    expected = """class A(_py_backwards_six_withmetaclass(ABCMeta)):
        pass"""
    with mock.patch.object(transformer, '_tree_changed', False):
        source_ast = ast.parse(source)
        transformer.visit(source_ast)

# Generated at 2022-06-12 03:44:34.781370
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_transformer_util import do_test
    actual = do_test(MetaclassTransformer)

# Generated at 2022-06-12 03:44:43.929707
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..lexer import lex, py_literal
    from ..parser import parse
    from ..utils.patternmatching import Match

    class TestTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node):
            if (len(node.keywords) == 1 and
                isinstance(node.keywords[0], ast.keyword) and  # type: ignore
                    node.keywords[0].arg == 'metaclass'):
                self._tree_changed = True
                node.keywords = []
                def _py_backwards_six_with_metaclass(metaclass, *bases):
                    return type(str('_py_backwards_six_with_metaclass'),
                                bases, {'__metaclass__': metaclass})
                node.bases = _py_back

# Generated at 2022-06-12 03:44:49.942128
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    module_node = ast.parse('class Foo(metaclass=Bar): pass')  # type: ignore

    m = MetaclassTransformer()
    m.visit(module_node)

    expected_module_node = ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass Foo(_py_backwards_six_withmetaclass(Bar)):\n    pass')  # type: ignore

    assert ast_equal(module_node, expected_module_node)

# Generated at 2022-06-12 03:44:58.311680
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class NodeTransformerTester(ast.NodeTransformer):
        def generic_visit(self, node: ast.AST) -> ast.AST:
            return node
    
    transformer = MetaclassTransformer()
    transformer.visit = NodeTransformerTester().generic_visit
    
    class_def = ast.parse('class A(metaclass=B):\n'
                          '    pass')

    class_expected = ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass\n'
                               '\n'
                               '\n'
                               'class A(_py_backwards_six_withmetaclass(B)):\n'
                               '    pass\n')
    
    assert transformer.visit(class_def) == class_expected

# Generated at 2022-06-12 03:45:03.120060
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    code = """
    class Foo(metaclass=type):
        pass
    """

    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class Foo(_py_backwards_six_withmetaclass(type, )):
        pass
    """

    transformer = MetaclassTransformer()
    tree = ast.parse(code)
    new_tree = transformer.visit(tree)

    assert expected == to_source(new_tree)


# Generated at 2022-06-12 03:45:09.351483
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import generate_code, random_identifier

    class_body: List[ast.AST] = [
        ast.Assign(
            targets=[ast.Name(id=random_identifier.get(), ctx=ast.Store())],
            value=ast.Num(n=random.randint(-10 ** 10, 10 ** 10))
        )
        for _ in range(5)
    ]


# Generated at 2022-06-12 03:45:18.063201
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class Fixture(unittest.TestCase):
        def test_single_metaclass(self):
            in_ = ast.parse(
                inspect.cleandoc("""
                class A(metaclass=B):
                    pass
                """))
            expected = ast.parse(
                inspect.cleandoc("""
                from six import with_metaclass as _py_backwards_six_withmetaclass
                class A(_py_backwards_six_withmetaclass(B))
                    pass
                """))
            expected = ast.fix_missing_locations(expected)
            actual = MetaclassTransformer().visit(in_)
            assert dump_ast(expected) == dump_ast(actual)


# Generated at 2022-06-12 03:45:18.679415
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:45:27.544385
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import random

    class TestNode(object):
        def __init__(self):
            pass

        def __str__(self):
            return __name__
    #
    # Create a dummy AST node
    node = TestNode()

    # Create a random list of keyword arguments
    keywords_list = []
    # Create up to 5 keyword arguments
    num_keywords = random.randint(0,5)
    for _ in range(num_keywords):
        keywords_list.append(TestNode())

    # Create an arbitrary number of base classes
    bases = []
    num_bases = random.randint(0,5)
    for _ in range(num_bases):
        bases.append(TestNode())

    # Create a mock node that represents a class
    node.keywords = keywords_list
    node.b

# Generated at 2022-06-12 03:46:07.297899
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-12 03:46:15.995412
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import lib2to3.pygram
    import lib2to3.pytree as pytree
    import libfuturize.fixer_util
    import ast as _ast
    _tree_changed = None
    _m = None
    _w = None
    _node = None
    def _create_node(kind):
        nonlocal _node
        _node = _ast.parse(
            """
            class A(metaclass=B):
                pass
            """
        ).body[0]
        return _node
    def _check_node():
        nonlocal _node

# Generated at 2022-06-12 03:46:25.057840
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import dump_tree
    from ..utils.transformer import TransformerTestCase

    @snippet
    def before():
        class A(metaclass=C):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass

# Generated at 2022-06-12 03:46:33.964699
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Test for method visit_ClassDef"""
    # Test case where node.keywords is empty
    # 
    node = ast.ClassDef()
    node.keywords = []
    node.bases = []
    node.body = []
    transformer = MetaclassTransformer()
    assert transformer.visit_ClassDef(node) == node

    # Test case where keyword is not `metaclass`
    # 
    node = ast.ClassDef()
    node.keywords = [ast.keyword(arg='metaclass', value=42)]
    node.bases = []
    node.body = []
    transformer = MetaclassTransformer()
    assert transformer.visit_ClassDef(node) == node

    # Test case where node.keywords is not empty
    # 
    node = ast.ClassDef()

# Generated at 2022-06-12 03:46:39.345370
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = """class A(metaclass=B): pass"""
    expect = """class A(_py_backwards_six_withmetaclass(B, )): pass"""
    tree = ast.parse(source)
    m = MetaclassTransformer()
    m.visit(tree)
    compile(tree, '<test>', 'exec')
    assert ast.dump(tree) == expect

# Generated at 2022-06-12 03:46:40.198282
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 03:46:41.088257
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:46:48.813603
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse('class A(metaclass=B): pass')
    cls = module.body[0]
    assert cls.keywords[0].value.id == 'B'
    assert len(cls.bases) == 0
    assert len(module.body) == 1

    transformer = MetaclassTransformer()
    new_module = transformer.visit(module)
    cls = new_module.body[0]
    assert isinstance(cls.bases[0], ast.Call)
    assert isinstance(module.body[1], ast.ImportFrom)
    assert module.body[1].module == 'six'
    assert len(module.body) == 2

# Generated at 2022-06-12 03:46:57.940259
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast.parse("class Test_class(metaclass=B, x=1):\n\tpass")
    tree = MetaclassTransformer().visit(tree)

# Generated at 2022-06-12 03:47:04.800172
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import parse
    from .test_BaseNodeTransformer import BaseNodeTransformerTest
    from ...utils.source import source_to_unicode as u

    source = u("""
    class A(metaclass=B):
        pass
    """)

    expected = u("""
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)

    tree = parse(source)
    tree = MetaclassTransformer().visit(tree)
    BaseNodeTransformerTest.generic_visit_test(tree, expected)

# Generated at 2022-06-12 03:48:49.077996
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    # Test for class A(metaclass=B)
    cls_node = ast.ClassDef(name='A',
                            bases=[ast.Name(id='B',
                                            ctx=ast.Load())],
                            keywords=[ast.keyword(arg='metaclass',
                                                  value=ast.Name(id='B',
                                                                 ctx=ast.Load()))],
                            body=[])
    mt = MetaclassTransformer()
    new_cls_node = mt.visit(cls_node)
    assert new_cls_node.bases[0].value.__class__.__name__ == 'Call'

# Generated at 2022-06-12 03:48:50.830517
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing.utils import build_visitor_test_method
    return build_visitor_test_method(MetaclassTransformer)

# Generated at 2022-06-12 03:48:56.970481
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .base import BaseTestTransformer

    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):  # type: ignore
            pass

    o = BaseTestTransformer(MetaclassTransformer)
    o.test(before.get_ast(), after.get_ast())

# Generated at 2022-06-12 03:49:05.604951
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Arrange
    source = source_info(
        file_name='test.py',
        source_code="""
            class Class(metaclass=type):
                pass
        """.strip(),
    )
    expected_source = source_info(
        file_name='test.py',
        source_code="""
            from six import with_metaclass as _py_backwards_six_withmetaclass

            class Class(_py_backwards_six_withmetaclass(type)):
                pass
        """.strip(),
    )

    # Act
    actual_node = MetaclassTransformer().visit(source.ast_tree)

    # Assert
    assert verify_ast(actual_node) is True
    assert to_source(actual_node) == expected_source.source_code

# Generated at 2022-06-12 03:49:13.934979
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class Test:
        target = (2, 7)
        dependencies = ['six']

        def _test(self):
            class A(metaclass=B):
                pass

    test_case = Test()
    test_case.test_name = 'visit_ClassDef'
    # insert_at(0, node, six_import.get_body())
    # return self.generic_visit(node)  # type: ignore
    # metaclass = node.keywords[0].value
    # node.bases = class_bases.get_body(metaclass=metaclass,  # type: ignore
    #                                   bases=ast.List(elts=node.bases))
    # node.keywords = []
    # self._tree_changed = True
    # return self.generic_visit(node

# Generated at 2022-06-12 03:49:14.996796
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast


# Generated at 2022-06-12 03:49:15.559556
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:49:24.131116
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import os
    import typed_ast.ast3 as ast
    from .base import BaseNodeTransformerTest

    paths = os.path.dirname(os.path.abspath(__file__)).split('/')
    paths[-1] = '37_with_metaclass.py'
    path = '/'.join(paths)

    class Test(BaseNodeTransformerTest):
        target = MetaclassTransformer
        path = path
        target_versions = ('2.7', )

    test = Test()
    test.test()

    with open(MetaclassTransformer.dependencies[0] + '.py', 'r') as dependency_file:
        dependency_body = dependency_file.read()

# Generated at 2022-06-12 03:49:32.388834
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from logging import warning
    from textwrap import dedent
    from typed_ast import ast3 as ast
    from .utils import make_test_transformer_testcase
    from .utils import parse
    from .utils import round_trip
    from .utils import round_trip_load
    from .utils.tree_builder import build

    with warnings.catch_warnings(record=True) as w:
        transformer = MetaclassTransformer(threshold=None,
                                           always=False,
                                           inject_dependencies=True,
                                           remove_dependencies=True)

        tree = parse("""
        class A(metaclass=B):
            pass
        """)

        transformer.visit(tree)

        assert transformer.changes == 1
        assert transformer.transformed
        assert not transformer.dependencies_changed


# Generated at 2022-06-12 03:49:36.693788
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    node = ast.parse("class A(metaclass=B): pass", "<string>", "exec")
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert astor.to_source(node) == "from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)) :\n    pass"