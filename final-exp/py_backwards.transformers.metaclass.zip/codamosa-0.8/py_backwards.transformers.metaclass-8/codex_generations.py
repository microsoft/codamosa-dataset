

# Generated at 2022-06-12 03:39:59.214309
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclass = ast.Name(id='metaclass')
    bases = [ast.Name(id='base'), ast.Name(id='base2')]
    classdef = ast.ClassDef(name='A',
                            bases=bases,
                            keywords=[ast.keyword(arg='metaclass', value=metaclass)],
                            body=[])
    classdef = MetaclassTransformer().visit(classdef)
    assert classdef.bases == ast.List(elts=class_bases.get_body(metaclass=metaclass,
                                                                bases=ast.List(elts=bases)))
    assert classdef.keywords == []

# Generated at 2022-06-12 03:40:07.667411
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_visitor import TestVisitor
    from ..utils.type_examples import type_examples
    from astunparse import unparse
    from .metaclass import MetaclassTransformer

    tx = TestVisitor(MetaclassTransformer)

    # test_ClassDef_no_keywords
    node = ast.parse("""
        class A:
            pass
    """)
    tx.test(node, """
        class A:
            pass
    """)

    # test_class_def_with_metaclass
    node = ast.parse("""
        class A(metaclass=B):
            pass
    """)

# Generated at 2022-06-12 03:40:09.284162
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-12 03:40:09.786473
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-12 03:40:15.770710
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import parse
    from . import transform
    from six import PY2

    code = """
    class A(metaclass=B):
        pass
    """
    module = parse(code)
    MetaclassTransformer().visit(module)
    code = source(module)

# Generated at 2022-06-12 03:40:20.556017
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.tester import NodeTester
    from ..utils import ast2code

    tester = NodeTester(MetaclassTransformer)
    assert ast2code(tester.transform("class A(metaclass=B): pass")) == (
        'from six import with_metaclass as _py_backwards_six_withmetaclass\n\n'
        'class A(_py_backwards_six_withmetaclass(B), []):\n    pass')

# Generated at 2022-06-12 03:40:21.798748
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()

# Generated at 2022-06-12 03:40:26.937810
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3
    import six
    import sys
    from ._python_2_7_tests.transformer_test_cases import MetaclassTestCaseBase
    import unittest

    class MetaclassTransformerTestCase(MetaclassTestCaseBase, unittest.TestCase):
        transformer = MetaclassTransformer

# Generated at 2022-06-12 03:40:28.771747
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    t = MetaclassTransformer()

# Generated at 2022-06-12 03:40:34.699848
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six
    import ast
    import astor
    from astor.code_gen import to_source

    source = """class A(metaclass=B): pass"""
    tree = ast.parse(source)

    t = MetaclassTransformer()
    result = t.visit(tree)

# Generated at 2022-06-12 03:40:44.773944
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.compare import compare_ast
    from .. import settings

    ast1 = sta('''\
        class A(metaclass=B):
            pass
        ''')
    ast2 = sta('''\
        from six import with_metaclass as _py_backwards_six_withmetaclass


        class A(_py_backwards_six_withmetaclass(B)):
            pass
        ''')

    with settings(max_line_length=40):
        outdated_ast = MetaclassTransformer(ast1).visit(ast1)

    assert compare_ast(outdated_ast, ast2)


# Generated at 2022-06-12 03:40:50.542347
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import compile

    code = '''
    class A(metaclass=B):
        pass
    '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    assert compile(code, minimum_python_version=(2, 7)) == expected



# Generated at 2022-06-12 03:40:54.441563
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = 'class a(metaclass=b): pass'

    expected = 'class a(_py_backwards_six_withmetaclass(b)): pass'

    tree = ast.parse(source)
    metaclass_compiler = MetaclassTransformer()
    metaclass_compiler.visit(tree)
    assert astor.to_source(tree) == expected

# Generated at 2022-06-12 03:41:01.720383
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclass_transformer = MetaclassTransformer()
    class_name = 'TestClass'
    args = (ast.Name(id=class_name), [ast.Name(id='object')], [], [], None, [])
    class_def = ast.ClassDef(name=class_name, *args)
    results = metaclass_transformer.visit_ClassDef(class_def)
    assert isinstance(results, ast.ClassDef)
    assert results.name == class_name
    assert results.bases[0].elts[0].value.id == class_name

# Generated at 2022-06-12 03:41:07.430690
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils import parse
    from .six import SixTransformer
    from .base import Context
    from .base import get_namespace, get_code
    from .base import NodeTransformer

    # we can't just use node.body[0] for the six import statement.
    # It could have been added by another transformer

# Generated at 2022-06-12 03:41:17.791291
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    unittest = MetaclassTransformer()
    # Declare class Test(num=1, metaclass=2):
    node_ = ast.ClassDef(name='Test', body=[], decorator_list=[],
                         keywords=[ast.keyword(arg='metaclass',
                                               value=ast.Num(n=2))],
                         lineno=1, col_offset=0)
    # Expect node with bases=class_bases.get_body(metaclass=2, bases=[])

# Generated at 2022-06-12 03:41:18.227961
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:41:21.562259
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse("""
    class A(metaclass=B):
        pass
    """)

    MetaclassTransformer.run_on(module)


# Generated at 2022-06-12 03:41:22.713068
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

# Generated at 2022-06-12 03:41:32.589666
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    trans = MetaclassTransformer(target_version=(2, 7))

    # Test if ast tree below is changed
    ast_tree = ast.parse('''
    class A():
        pass
    ''')
    trans.visit(ast_tree)
    assert ast.dump(ast_tree) == '''
    Module(body=[ClassDef(name='A', bases=[], 
        body=[Pass()], keywords=[])])
    '''

    # Test if ast.List is inserted correctly
    ast_tree = ast.parse('''
    class A(metaclass=B):
        pass
    ''')
    trans.visit(ast_tree)

# Generated at 2022-06-12 03:41:37.926601
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from . import unparse

# Generated at 2022-06-12 03:41:43.863866
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    input_src = """
    class A(metaclass=B, x=y):
        pass
    """
    expected_src = """
    class A(_py_backwards_six_with_metaclass(B,object)):
        pass
    """
    src = _make_tree(input_src).body[0]
    metaclass_transformer = MetaclassTransformer().visit(src)
    assert metaclass_transformer.as_string() == expected_src


# Generated at 2022-06-12 03:41:47.404161
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_conversion

    assert_conversion(MetaclassTransformer,
                      'class A(metaclass=B): pass',
                      'class A(_py_backwards_six_withmetaclass(B)): pass')



# Generated at 2022-06-12 03:41:56.539110
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .helper import make_testcase
    from .test_six_import import test_six_import
    from ..utils.tree import dump

    class A(metaclass=type):
        pass
    class B(object, metaclass=type):
        pass
    class C(object, metaclass=type):
        class D(metaclass=type):
            pass
        d = D()


# Generated at 2022-06-12 03:42:05.271880
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as to_ast
    from ..utils.source import source_to_code as to_code
    from ..utils.source import ast_to_source as to_source

    source = """
             class A(metaclass=B):
                 pass
             """
    expected = """
             from six import with_metaclass as _py_backwards_six_withmetaclass
             class A(_py_backwards_six_withmetaclass(B))
                 pass
             """
    node = to_ast(source)
    MetaclassTransformer().visit(node)
    assert to_code(node) == to_source(expected)

# Generated at 2022-06-12 03:42:11.317382
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, assert_ast_empty, assert_ast_equal
    tree = transform(MetaclassTransformer, '''
    class A(metaclass=int):
        pass
    ''')
    assert_ast_equal(tree, '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(int,[])):
        pass
    ''')

# Generated at 2022-06-12 03:42:12.421275
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:17.744991
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..tests.test_visitor import assert_visitor

    assert_visitor("""
    class A(metaclass=B):
        pass
    """, MetaclassTransformer, """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)

# Generated at 2022-06-12 03:42:20.814660
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
    class A(object, metaclass=int):
        pass
    """

# Generated at 2022-06-12 03:42:27.772996
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = textwrap.dedent(
        '''
        class A(metaclass=B):
            pass
        '''
    )
    tree = ast.parse(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    expected_tree = textwrap.dedent(
        '''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
        '''
    )
    expected_tree = ast.parse(expected_tree)

    assert_ast_eq(tree, expected_tree)

# Generated at 2022-06-12 03:42:40.246598
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class MyMeta(type):
        pass
    class A(metaclass=MyMeta, arg1='myarg1'):
        pass
    tree = ast.parse(dedent('''\
        class MyMeta(type):
            pass
        class A(metaclass=MyMeta, arg1='myarg1'):
            pass'''))
    result = MetaclassTransformer().run_pipeline(tree)
    test_tree = ast.parse(dedent('''\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class MyMeta(type):
            pass
        class A(_py_backwards_six_withmetaclass(MyMeta), arg1='myarg1'):
            pass'''))
    compare_ast(result, test_tree)

# Generated at 2022-06-12 03:42:46.328881
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    node = ast.parse('''
        class A(metaclass=type):
            pass
    ''')
    MetaclassTransformer(2, 7, []).visit_ClassDef(node.body[0])
    assert astor.to_source(node) == '''
        class A(_py_backwards_six_withmetaclass(type))
            pass
    '''


# Generated at 2022-06-12 03:42:53.156950
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_function
    from .. import compile

    def test():
        class C:
            pass

    test_function = source_to_function("test", test)
    test_function = compile(test_function, 2, 7)

    assert test_function() is None

    def test(metaclass):
        class C(metaclass=metaclass):
            pass

    test_function = source_to_function("test", test)
    test_function = compile(test_function, 2, 7)

    class M(type):
        pass

    assert test_function(M) is None

    def test(metaclass):
        class C(metaclass=metaclass):
            pass

    test_function = source_to_function("test", test)

# Generated at 2022-06-12 03:42:53.771184
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:59.190207
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    nodes = ast.parse("""class A(metaclass=B):
                            pass""")
    tr = MetaclassTransformer()
    tr.visit(nodes)
    assert repr(nodes).replace(" ", "") == (
        "Module(body=[ImportFrom(module='six',names=[alias(name='with_metaclass',asname='_py_backwards_six_with_metaclass')],level=0),ClassDef(name='A',bases=[_py_backwards_six_with_metaclass(B)],keywords=[],body=[Pass()])])"
    )

# Generated at 2022-06-12 03:43:07.459986
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.python_2_3 import Ast3
    classdef_str = "class A(metaclass=B): pass"
    node = Ast3().parse(classdef_str)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert classdef_str not in astor.to_source(node)
    assert "class A(_py_backwards_six_withmetaclass(B)): pass" in astor.to_source(node)
    assert "from six import with_metaclass as _py_backwards_six_withmetaclass" in astor.to_source(node)

# Generated at 2022-06-12 03:43:11.308075
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    source_ = source(MetaclassTransformer)
    # assert source_ == {'body': [], 'decorator_list': [], 'bases': [], 'keywords': []}
    class A: pass
    assert MetaclassTransformer.visit_ClassDef(MetaclassTransformer, A) == A

# Generated at 2022-06-12 03:43:20.871348
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    ast_tree = ast.parse('class A(metaclass=type):\n    pass')
    transformer = MetaclassTransformer()
    transformer.visit(ast_tree)

# Generated at 2022-06-12 03:43:27.676511
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    # test when there's no keyword argument
    node = ast.parse('''class A(B, C): pass''')
    MetaclassTransformer().visit(node)
    assert astor.to_source(node).strip() == 'class A(B, C): pass'

    # test when there's a keyword argument
    node = ast.parse('''class A(B, C, metaclass=D): pass''')
    MetaclassTransformer().visit(node)
    assert astor.to_source(node).strip() == 'class A(_py_backwards_six_withmetaclass(D), *[B, C]): pass'

    # test when there's a keyword argument and bases are also passed in

# Generated at 2022-06-12 03:43:37.411540
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import MetaclassTransformer
    import ast
    test_node = ast.ClassDef(name="Foo",
                             bases=[ast.Name(id="Bar")],
                             keywords=[ast.keyword(arg="metaclass",
                                                   value=ast.Name(id="Meta"))],
                             body=[])
    expected_node = ast.ClassDef(name="Foo",
                                 bases=[ast.Call(func=ast.Name(id="_py_backwards_six_withmetaclass"),
                                                 args=[ast.Name(id="Meta"),
                                                       ast.Name(id="Bar")])],
                                 body=[])
    transformer = MetaclassTransformer()
    result = transformer.visit(test_node)
    assert result == expected_node, "Result does not match expectation"

# Generated at 2022-06-12 03:43:50.700940
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astunparse
    source = "class A(metaclass=B): pass"
    node = ast.parse(source)
    MetaclassTransformer().visit(node)
    assert astunparse.unparse(node).strip() == "from six import with_metaclass as _py_backwards_six_withmetaclass; class A(_py_backwards_six_withmetaclass(B)): pass"

# Generated at 2022-06-12 03:43:56.058316
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse('class A(metaclass=int): pass')
    transformer = MetaclassTransformer()
    transformer.visit(module)
    assert transformer.tree_changed
    assert module.body[0].bases[0].func.id == '_py_backwards_six_withmetaclass'



# Generated at 2022-06-12 03:43:58.613385
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..tests.test_compile import compile_text
    from ..tests.test_utils import remove_whitespace

# Generated at 2022-06-12 03:43:59.781997
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()


# Generated at 2022-06-12 03:44:01.155850
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import asttools
    from ..compat import ast_parse


# Generated at 2022-06-12 03:44:08.388726
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import unittest
    from ..testing import transforms_to
    class Test(unittest.TestCase):
        def test_metaclass(self):
            self.assertTrue(
                transforms_to(source="""
                class A(metaclass=B):
                    pass""",
                              transformer=MetaclassTransformer,
                              expected_source="""
                from six import with_metaclass as _py_backwards_six_withmetaclass
                class A(_py_backwards_six_withmetaclass(B)):
                    pass
                """))
    return Test


__transformer__ = MetaclassTransformer

# Generated at 2022-06-12 03:44:09.865230
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from .test_setup import setup

# Generated at 2022-06-12 03:44:11.105651
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:44:13.437537
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    AST = ast.parse('class A(metaclass=B): pass')
    node = AST.body[0]

    assert node == MetaclassTransformer.visit(node)

# Generated at 2022-06-12 03:44:19.424098
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    transformer = MetaclassTransformer()
    metaclass = ast.Name('A')
    bases = [ast.Name(id='B'), ast.Name(id='C')]

    classdef = ast.ClassDef(name='MyClass', bases=bases)
    node = transformer.visit(classdef)

    assert node == classdef

    classdef = ast.ClassDef(name='MyClass', bases=bases, keywords=[ast.keyword(arg='metaclass', value=metaclass)])
    node = transformer.visit(classdef)


# Generated at 2022-06-12 03:44:45.337721
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Basic case
    node = ast.ClassDef(name="A",
                        bases=[ast.Name(id="object", ctx=ast.Load())],
                        keywords=[ast.keyword(arg="metaclass", value=ast.Name(id="B", ctx=ast.Load()))])
    transformer = MetaclassTransformer()
    result = transformer.visit(node)

    assert result.bases == [ast.Call(func=ast.Name(id="_py_backwards_six_withmetaclass", ctx=ast.Load()),
                                     args=[ast.Name(id="B", ctx=ast.Load())],
                                     keywords=[],
                                     starargs=None,
                                     kwargs=None)]

    # No keywords

# Generated at 2022-06-12 03:44:54.069983
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from typed_ast import have_ast_unparse

    class DummyClass:
        pass

    class DummyVisitor(ast.NodeVisitor):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node

    tree = ast.parse(dedent("""
    class A(metaclass=M, more_stuff=1):
        pass
    """))
    transformer = MetaclassTransformer()
    new_tree = transformer.visit(tree)

# Generated at 2022-06-12 03:44:56.294639
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import ClassDef, Name, keyword, Str
    from typed_ast.ast3 import parse as parse3


# Generated at 2022-06-12 03:45:02.013132
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    '''
    >>> from typed_ast import ast3 as ast
    >>> from typed_ast.ast3 import parse, Module, Num
    >>> from typed_ast.transforms.backwards_compatibility.classes import MetaclassTransformer
    >>> from typed_ast.transforms.backwards_compatibility.tests.backport_test_case import BackportTestCase
    >>> cls_def = parse('''

# Generated at 2022-06-12 03:45:11.826021
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class CustomClassDef(ast.ClassDef):
        def __init__(self, metaclass, bases):
            super().__init__()
            self.keywords = [ast.keyword(arg='metaclass', value=metaclass)]
            self.bases = bases

    transformer = MetaclassTransformer()

# Generated at 2022-06-12 03:45:17.790219
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from py_backwards.transformers.metaclass import MetaclassTransformer
    from py_backwards.utils.snippet import snippet

    @snippet
    def before():
        class A(metaclass=int):
            pass

    @snippet
    def after():
        class A(_py_backwards_six_withmetaclass(int)):
            pass

    assert MetaclassTransformer.check_output(before.get_ast(),
                                             after.get_ast())



# Generated at 2022-06-12 03:45:18.883093
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:45:24.480969
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_ast = ast.parse("""
        class A(metaclass=B):
            pass
    """)
    assert_string_ast(MetaclassTransformer.run_pipeline(test_ast), """
        from six import with_metaclass as _py_backwards_six_with_metaclass

        class A(_py_backwards_six_with_metaclass(B)):
            pass
    """)

# Generated at 2022-06-12 03:45:26.199105
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3, parse
    from ..transformers import MetaclassTransformer
    import inspect


# Generated at 2022-06-12 03:45:33.929067
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from itertools import permutations
    from .utils import transform, compare_source
    for permutation in permutations([
        'class A(metaclass=B): pass',
        'class C(B): pass',
        'class D(E, F): pass',
        'class G(metaclass=H, I): pass',
        'class J(metaclass=K, *L): pass',
        'class M(metaclass=N, **O): pass',
        'class P(Q, metaclass=R, *S): pass',
        'class T(U, V, metaclass=W, **X): pass',
    ]):
        source = '\n'.join(permutation)
        tree = ast.parse(source)
        transform(tree, MetaclassTransformer())

# Generated at 2022-06-12 03:46:17.346644
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .base import BaseTreeTester
    from typed_ast import ast3 as ast

    body = """
        class A(metaclass=B):
            pass
    """
    expected_body = """
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """

    @BaseTreeTester.wrap
    def do(self, node: ast.Module) -> None:
        node = self.transformer.visit(node)
        self.check_module(node, six_import.get_body() + expected_body)

    BaseTreeTester.test(do, body)



# Generated at 2022-06-12 03:46:19.489622
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing.utils import expect_transformed
    from ..testing.mock import MockTreeBuilder



# Generated at 2022-06-12 03:46:21.092511
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    from ..parser import parse
    from .six import SixTransformer


# Generated at 2022-06-12 03:46:30.092466
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import (assert_equal, assert_file_contents, assert_file_contents_unchanged,
                         get_file_contents, get_tree, DataProvider, parse)

    class_bases_tests = DataProvider(class_bases)
    class_bases_tests.add_default_tests()

    tests = [
        DataProvider('with_metaclass', 'withmetaclass'),
        DataProvider('metaclass', 'metaclass'),
        DataProvider('bases_are_not_changed', 'bases_are_not_changed'),
    ]

    tests.extend(class_bases_tests.generate_tests())


# Generated at 2022-06-12 03:46:38.423829
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing_utils import assert_equal_ast
    import astor
    source = """class Foo(metaclass=BaseClass):
        def test(self):
            return self.x
    """
    expected = """class Foo(_py_backwards_six_withmetaclass(BaseClass)):
    def test(self):
        return self.x
"""
    mt = MetaclassTransformer(parse_ast(source))
    astor.codegen.to_source(mt.visit())
    assert_equal_ast(mt.visit(), parse_ast(expected))


# Generated at 2022-06-12 03:46:42.079676
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .fixtures import class_def_fixture
    from ..utils.source import Source
    from ..utils.compiler import compile_snippet

    source = Source(class_def_fixture)
    tree = compile_snippet(source, MetaclassTransformer)
    assert source.get_code() == tree_to_str(tree)

# Generated at 2022-06-12 03:46:47.745904
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    import sys

    class A(type):
        pass

    class B(object, metaclass=A):
        pass

    tree = ast.parse(inspect.getsource(sys.modules[__name__]))
    MetaclassTransformer().visit(tree)
    s = astor.to_source(tree)

# Generated at 2022-06-12 03:46:56.919017
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """
    This method tests whether the visit_ClassDef method of the Metaclass transformer
    properly transforms metaclasses into the six.withmetaclass syntax.

    Expects:
    A class definition with a metaclass in its syntax tree.
    The code for the six.withmetaclass syntax is in the code snippet called `six_import`.
    The six.withmetaclass function is called by the code snippet called `class_bases`
    with the given arguments.
    """
    from typed_ast import ast3 as ast
    from .six_withmetaclass_test_data import expected_tree

    # Transforming input tree
    MetaclassTransformer().visit(expected_tree)

    # Checking if the transformation worked
    assert not expected_tree.body[0].elts

    assert expected_tree.body[1].name

# Generated at 2022-06-12 03:46:57.696705
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astunparse


# Generated at 2022-06-12 03:47:05.284588
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    print("Test: MetaclassTransformer.visit_ClassDef")
    metaclass_transformer = MetaclassTransformer([])
    metaclass_def = ast.ClassDef('XXX', ['B'],
                                 [ast.Keyword(arg='metaclass', value=ast.Name('B', ast.Load()))],
                                 [ast.Pass()], [])
    assert len(metaclass_def.bases) == 1
    assert len(metaclass_def.keywords) == 1
    assert isinstance(metaclass_def.keywords[0], ast.keyword)
    print("metaclass_def:")
    print(ast.dump(metaclass_def))
    metaclass_transformer.visit(metaclass_def)

# Generated at 2022-06-12 03:48:47.776364
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .examples import class_metaclass
    from ...testing_utils import test_print_output
    output = test_print_output(class_metaclass, MetaclassTransformer)

    expected = (
        "# -*- coding: utf-8 -*-\n"
        "from six import with_metaclass as _py_backwards_six_with_metaclass\n"
        "\n"
        "class A(_py_backwards_six_with_metaclass(B)):\n"
        "    pass\n"
    )
    assert output == expected

# Generated at 2022-06-12 03:48:49.086582
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:48:57.034996
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...testing import assert_code_equal
    result = MetaclassTransformer.run_pipeline('''
        class A:
            pass
    ''')
    expected = '''
        class A():
            pass
    '''
    assert_code_equal(result, expected)
    result = MetaclassTransformer.run_pipeline('''
        class A(metaclass=B):
            pass
    ''')
    expected = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    '''
    assert_code_equal(result, expected)

# Generated at 2022-06-12 03:49:00.086853
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astunparse

    example = "class A(): pass"
    tree = ast.parse(example)
    MetaclassTransformer().visit(tree)
    assert astunparse.unparse(tree) == 'class A(): pass'  # type: ignore


# Generated at 2022-06-12 03:49:01.409797
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:49:04.483230
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    m = ast.parse("""class A(metaclass=B):
      pass""")
    MetaclassTransformer(debug=True).visit(m)


# Generated at 2022-06-12 03:49:06.678764
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.transform_test import make_transform_test

# Generated at 2022-06-12 03:49:15.381514
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import compile_str
    code = '''
        class A:
            pass
        class B(C):
            pass
        class D(metaclass=E):
            pass
        class F(G, metaclass=H):
            pass
        class I(J, K, metaclass=L):
            pass
        class M(N, O, P, metaclass=Q):
            pass
        class R(S, T, U, V, metaclass=W):
            pass
        '''

    comp_res = compile_str(code, '<test>', 'exec', 2.7)

# Generated at 2022-06-12 03:49:21.372563
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(metaclass=B, *[])):
        pass
    """
    tranformer = MetaclassTransformer()
    result = tranformer.visit(parse(source))
    assert to_source(result) == expected

# Generated at 2022-06-12 03:49:26.664941
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...utils.convert import to_python
    from ...utils.compat import IS_PY35
    src = "class A(metaclass=B, other=42):\n    pass"
    expected = "\n".join([
        "from six import with_metaclass as _py_backwards_six_withmetaclass",
        "class A(_py_backwards_six_withmetaclass(B), *(), **{'other': 42}):",
        "    pass"
    ])
    node = ast.parse(src)
    node = MetaclassTransformer().visit(node)
    assert to_python(node) == expected

