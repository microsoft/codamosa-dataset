

# Generated at 2022-06-12 03:40:01.241028
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_fixup as sfixup
    from ..utils.compare import compare_ast as cmpa
    # TODO: what if there are more than one keyword?
    source = """
    class A(B, metaclass=C):
        pass
    """
    expected_source = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
    {}
    
    
    
    
    
    
    
    class A(_py_backwards_six_withmetaclass(C, *[B])):
        pass
    """
    _, fixer = MetaclassTransformer.get_transformer_fixer()
    

# Generated at 2022-06-12 03:40:05.856229
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # variables
    snippet = ("class A(metaclass=B): pass")
    expected = ("from six import with_metaclass as _py_backwards_six_withmetaclass\n"
                "class A(_py_backwards_six_withmetaclass(B)): pass")

    # tests
    result = MetaclassTransformer.run_test(snippet, expected)

    assert result

# Generated at 2022-06-12 03:40:10.952374
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
    class A(metaclass=B):
        pass
    """
    node = ast.parse(code)
    # Assert null transformer works as intended
    new_node = MetaclassTransformer()(node)
    assert_source_equal(ast.unparse(new_node), """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)

# Generated at 2022-06-12 03:40:19.701422
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class MyMeta(type):
        pass

    class Foo(with_metaclass(MyMeta)):
        pass

    tree = ast.parse(inspect.getsource(Foo))  # type: ignore
    MetaclassTransformer().visit(tree)

    foo_class = tree.body[1]
    assert len(foo_class.decorator_list) == 0
    assert foo_class.name == 'Foo'
    assert foo_class.bases[0].elts[0].func.attr == 'with_metaclass'
    assert foo_class.bases[0].elts[0].func.value.id == '_py_backwards_six_withmetaclass'
    assert foo_class

# Generated at 2022-06-12 03:40:28.611155
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.unparse import Unparser
    from ..utils.source_generator import generate_source
    from ..utils.source_generator import get_ast

    source = generate_source(
        class_bases.get_body(metaclass=ast.Name(id="metaclass", ctx=ast.Load()),
                             bases=ast.List(
                                 elts=[ast.Name(id="bases", ctx=ast.Load())],
                                 ctx=ast.Load())))
    expected = '_py_backwards_six_withmetaclass(metaclass, *bases)'

    assert Unparser().unparse(get_ast(source)).strip() == expected



# Generated at 2022-06-12 03:40:29.570715
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-12 03:40:35.528043
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """\
        class A(metaclass=B):
            pass
    """
    expected = """\
        class A(_py_backwards_six_with_metaclass(B)):
            pass
    """
    node = ast.parse(code)
    node = MetaclassTransformer('2.7').visit(node)
    assert ast.dump(node, include_attributes=False) == expected



# Generated at 2022-06-12 03:40:44.317416
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast as pyast
    t = MetaclassTransformer()
    assert ast.dump(t.visit(pyast.parse('class A(object): pass'))) ==\
           ast.dump(pyast.parse('class A(object): pass'))
    assert ast.dump(t.visit(pyast.parse('class A(object): pass')), include_attributes=True) ==\
           ast.dump(pyast.parse('class A(object): pass'), include_attributes=True)
    assert ast.dump(t.visit(pyast.parse('class A(metaclass=type): pass'))) ==\
           ast.dump(pyast.parse('class A(_py_backwards_six_withmetaclass(type)): pass'))

# Generated at 2022-06-12 03:40:45.176734
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:40:45.906203
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:40:56.673073
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from textwrap import dedent
    from ..mock_tree import mock_tree
    from .. import transpile

    source = dedent('''
        class A(metaclass=object, object):
            pass
    ''').strip()

    root_node = ast.parse(source)
    mock_tree(root_node)

    transformer = MetaclassTransformer()
    transformed_root = transformer.visit(root_node)
    code = transpile(transformed_root)

    assert code == dedent('''
        from six import with_metaclass as _py_backwards_six_with_metaclass

        class A(_py_backwards_six_with_metaclass(object, object)):
            pass
    ''').strip()

# Generated at 2022-06-12 03:41:02.225605
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = """class Foo(metaclass=A): pass"""
    expected = """class Foo(_py_backwards_six_withmetaclass(A)): pass"""
    node = ast.parse(source)
    node = MetaclassTransformer().visit(node)
    actual = compile(node, '<string>', mode='exec')
    exec(actual)
    assert globals()['Foo'].__bases__ == (A,)

# Generated at 2022-06-12 03:41:04.378850
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.syntax import parse
    from ..utils.unparse import unparse


# Generated at 2022-06-12 03:41:08.339179
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_astunparse, ast
    
    source = """class Base(metaclass=B):
    pass"""

# Generated at 2022-06-12 03:41:14.768597
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.testing_utils import normalize, compare_ast
    import six
    from astor.code_gen import to_source

    code = """class A(metaclass=B):
    pass"""
    tree = ast.parse(code)
    MetaclassTransformer().visit(tree)


# Generated at 2022-06-12 03:41:21.018072
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = '''
        class A(metaclass=B):
            pass
    '''
    expected = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    '''
    node = ast.parse(source)  # type: ignore
    visitor = MetaclassTransformer()
    node = visitor.visit(node)
    assert ast.dump(node, include_attributes=True) == expected

# Generated at 2022-06-12 03:41:29.978990
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ast_unparse import unparse

    class Dummy(ast.NodeVisitor):
        def visit_Module(self, node):
            return node, False

        def visit_ClassDef(self, node):
            return node, True

        def __default__(self, node):
            return node, False

    visitor = Dummy()
    transformer = MetaclassTransformer()
    transformer.generic_visit = visitor.visit

    code = 'class A(metaclass=abc.ABCMeta): pass'

    node = ast.parse(code, mode='exec')
    transformer.visit(node)
    print(unparse(node))

    assert visitor.visit(node)[1] is True
    assert transformer._tree_changed is True



# Generated at 2022-06-12 03:41:37.661219
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    class_def_node = ast.ClassDef(
        name='A',
        bases=[],
        keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
        body=[],
        decorator_list=[],
        lineno=0,
        col_offset=0
    )


# Generated at 2022-06-12 03:41:41.112949
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert snippet(MetaclassTransformer.visit_ClassDef, """
        class A(metaclass=B):
            pass
        """
    ) == snippet("""
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    )

# Generated at 2022-06-12 03:41:47.906444
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.ast_builder import ast_from_str, ast_to_source
    from ..utils.test_utils import transform
    source = "class A(metaclass=B):\n" \
             "    pass\n"
    expected = "class A(_py_backwards_six_withmetaclass(B)):\n" \
               "    pass\n"
    node = ast_from_str(source)
    transformer = transform(MetaclassTransformer, node)
    assert ast_to_source(transformer.visit(node)) == expected

# Generated at 2022-06-12 03:42:01.405081
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    mt = MetaclassTransformer()


# Generated at 2022-06-12 03:42:03.139875
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..compiler import Compiler
    from ..parser import Parser


# Generated at 2022-06-12 03:42:08.869174
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    original_code = 'class A(metaclass=B): pass'
    original_tree = astor.parse_file(original_code)

    desired_code = 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\n' \
                   'class A(_py_backwards_six_withmetaclass(B)):\n    pass'
    desired_tree = astor.parse_file(desired_code)

    transformer = MetaclassTransformer()
    new_tree = transformer.visit(original_tree)

    assert astor.to_source(new_tree) == desired_code
    assert transformer.dependencies == ['six']

# Generated at 2022-06-12 03:42:12.045821
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astunparse

    source = """class A(metaclass=C, b=1):
        pass"""

# Generated at 2022-06-12 03:42:22.100137
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert (
        MetaclassTransformer(2, 7)(
            ast.parse("""
                class A(metaclass=B):
                    pass
            """)
        ) ==
        ast.parse("""
            from six import with_metaclass as _py_backwards_six_with_metaclass

            class A(_py_backwards_six_with_metaclass(B)):
                pass
        """)
    )


# Generated at 2022-06-12 03:42:22.981553
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-12 03:42:28.405253
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils import ct_parse, compare_ast
    from ..fixer_util import token

    c = """
        class A(metaclass=B):
            pass
    """
    expected = """
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = ct_parse(c)
    new_tree = MetaclassTransformer().visit(tree)
    assert compare_ast(ast, new_tree, expected)


# Generated at 2022-06-12 03:42:37.819525
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.testing import assert_node

    ast_node = ast.Module(
        body=[
            ast.ClassDef(
                name='A',
                bases=[
                    ast.Name(id='object', ctx=ast.Load()),
                ],
                keywords=[
                    ast.keyword(arg='metaclass',
                                value=ast.Name(id='B', ctx=ast.Load())),
                ],
                body=[
                    ast.Pass(),
                ],
                decorator_list=[],
            ),
        ],
    )


# Generated at 2022-06-12 03:42:47.760657
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse('class A(type): pass')
    MetaclassTransformer().visit(module)

# Generated at 2022-06-12 03:42:53.417366
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..parser.parser import parse
    from ..parser.util import dump
    from ..parser.util import dump_tree

    # Given
    source = "class A(metaclass=B): pass"
    expected = "from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B, )): pass"
    tree = parse(source)
    transformer = MetaclassTransformer()

    # When
    transformed_tree = transformer.visit(tree)
    transformed_tree = transformer.generic_visit(transformed_tree)
    transformed_source = dump(transformed_tree)

    # Then
    assert expected == transformed_source


# Generated at 2022-06-12 03:43:05.996123
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:43:12.948301
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert str(MetaclassTransformer(ast.parse('''
    class A(metaclass=B):
        pass
    ''')).visit(ast.parse('''
    from six import with_metaclass as _py_backwards_six_with_metaclass

    class A(_py_backwards_six_with_metaclass(B)):
        pass
    ''')).body[1]) == str(ast.parse('''
    class A(_py_backwards_six_with_metaclass(B)):
        pass
    ''').body[0])

# Generated at 2022-06-12 03:43:22.656048
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import_node = six_import.get_ast()
    tree = ast.parse("""
    from collections import defaultdict
    class A(defaultdict):
        pass
    """)

    source = compile(tree, "", "exec")
    ns = {}
    exec(source, ns)
    expected = compile(ast.Module(body=[import_node,
                                       ast.ClassDef(name='A',
                                                    bases=[class_bases.get_ast(metaclass=ast.Name(id='defaultdict', ctx=ast.Load()),  # type: ignore
                                                                                                       bases=ast.List(elts=[], ctx=ast.Load()))])]), "", "exec")
    ns = {}
    exec(expected, ns)
    transformer = MetaclassTransformer()
    new_tree

# Generated at 2022-06-12 03:43:33.301969
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    tree = ast.Module(
        body=[
            ast.ClassDef(
                name='A',
                bases=[ast.Attribute(
                    value=ast.Name(
                        id='B',
                        ctx=ast.Load()
                    ),
                    attr='C',
                    ctx=ast.Load()
                )],
                body=[
                    ast.Pass()
                ],
                keywords=[
                    ast.keyword(
                        arg='metaclass',
                        value=ast.Name(
                            id='B',
                            ctx=ast.Load()
                        )
                    ),
                ],
                decorator_list=[],
                returns=None
            )
        ],
        type_ignores=[]
    )

    mt = MetaclassTransformer()

# Generated at 2022-06-12 03:43:34.854169
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    

# Generated at 2022-06-12 03:43:40.535735
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import metaclass, ClassDef
    assert MetaclassTransformer.visit_ClassDef(
        ClassDef(name='A', bases=[metaclass], keywords=[], body=[], decorator_list=[])) == \
        ClassDef(name='A', bases=[class_bases.get_body(metaclass=metaclass, 
                                                       bases=ast.List(elts=[]))], keywords=[], body=[], decorator_list=[])


# Generated at 2022-06-12 03:43:50.102112
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class Test:

        def __repr__(self):
            return f'{self.__class__.__name__}({"; ".join(f"{k}={v!r}" for k,v in self.__dict__.items())})'

        def __eq__(self, other):
            if self.__class__ != other.__class__:
                return False
            return self.__dict__ == other.__dict__

        def item_list(self, field):
            return [self.__dict__[field][i] for i in sorted(self.__dict__[field])] if self.__dict__[field] else None

    class Module(Test):
        pass

    class ClassDef(Test):
        pass

    class Assign(Test):
        pass

    class Expr(Test):
        pass



# Generated at 2022-06-12 03:43:56.568560
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.testutils import compile_source
    from ..utils.testutils import assert_source
    source = 'class A(metaclass=B): pass'
    expected = 'class A(_py_backwards_six_withmetaclass(B)): pass'
    tree = compile_source(source, 'exec')
    metaclass = MetaclassTransformer()
    metaclass.visit(tree)
    assert_source(expected, tree)

# Generated at 2022-06-12 03:44:01.869058
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from .test_utils import parse
    a = parse("""
        class A(object):
            pass
    """)
    b = parse("""
        from six import with_metaclass as _py_backwards_six_with_metaclass

        class A(_py_backwards_six_with_metaclass(object)):
            pass
    """)
    assert MetaclassTransformer().visit(a) == b



# Generated at 2022-06-12 03:44:09.592135
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    input_code = """
    class A(metaclass=B):
        pass
    """
    expected_code = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    # TODO: remove the ignore line below once mypy issue #6742 gets resolved:
    # https://github.com/python/mypy/issues/6742
    transformer = MetaclassTransformer().visit  # type: ignore
    assert transformer(ast.parse(input_code)) == ast.parse(expected_code)


# Generated at 2022-06-12 03:44:41.723954
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    ex = ast.ClassDef(name='MyClass',
                      bases=[ast.Name(id='base', ctx=ast.Load())],
                      keywords=[
                          ast.keyword(arg='metaclass',
                                      value=ast.Name(id='metaclass', ctx=ast.Load()))
                      ],
                      body=[],
                      decorator_list=[])


# Generated at 2022-06-12 03:44:42.564142
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:44:51.377620
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class MyClass(metaclass=str):
        pass

    code = 'class MyClass(metaclass=str):\n    pass'
    output = "from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass MyClass(_py_backwards_six_withmetaclass(str)):\n    pass"
    gt = six_generator.compile(code, target_version=MetaclassTransformer.target)
    assert str(gt) == output
    print('compiled code:', gt)

    code = 'class MyClass(metaclass=int):\n    pass'

# Generated at 2022-06-12 03:44:52.542068
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-12 03:44:58.740196
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    src = """
    from abc import ABCMeta

    class A(metaclass=ABCMeta):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    from abc import ABCMeta
    
    
    class A(_py_backwards_six_withmetaclass(ABCMeta)):
        pass
    """
    t = MetaclassTransformer()
    t.visit(ast.parse(src))
    assert expected == astunparse.unparse(t.get_tree())

# Generated at 2022-06-12 03:45:04.150022
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = '''
    class A(metaclass=B):
        pass
    '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    node = ast.parse(source)
    node_transformed = MetaclassTransformer.run_pipeline(node)
    assert ast.dump(node_transformed) == expected

# Generated at 2022-06-12 03:45:05.100845
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:45:06.101269
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:45:15.534948
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    import six
    import astor
    metaclass = ast.Name(id="type", ctx=ast.Load())
    class_def = ast.ClassDef(name="MyClass", bases=[ast.Name(id="object", ctx=ast.Load())],
                             keywords=[ast.keyword(arg=six.u("metaclass"), value=metaclass)],
                             decorator_list=[], body=[])

# Generated at 2022-06-12 03:45:20.250240
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ast import parse
    from .transformer import Transformer

    ast_in = parse("""\
        import six

        class Foo(metaclass=six.with_metaclass):
            pass
    """)
    ast_out = parse("""\
        import six

        class Foo(_py_backwards_six_with_metaclass(six.with_metaclass)):
            pass
    """)

    transformer = Transformer()
    transformer.transform(ast_in, [MetaclassTransformer])

    assert ast_out == ast_in

# Generated at 2022-06-12 03:46:14.412299
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.fake_ast import make_fake_ast

    make_fake_ast('''
        class A(metaclass=A):
            pass

        class A(metaclass=A, __slots__=()):
            pass

        class A(metaclass=A, **kwargs):
            pass
    ''')

# Generated at 2022-06-12 03:46:19.528421
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # type: () -> None
    import typed_ast.ast3 as ast

    class_node = ast.ClassDef(
        name="A", bases=[], keywords=[
            ast.keyword(arg="metaclass", value=ast.Str(s="B"))],
        body=[], decorator_list=[])

    visitor = MetaclassTransformer()
    visitor.visit(class_node)

    assert visitor._tree_changed is True

# Generated at 2022-06-12 03:46:28.447267
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ast import ClassDef as _ast_ClassDef
    from ast import Expr as _ast_Expr
    from ast import keyword as _ast_keyword

    def _build_MetaclassTransformer_visit_ClassDef(metaclass, bases = [], kwonlyargs = [], kw_defaults = [], defaults = [], vararg = None, kwarg = None, body = [], keywords = [], decorator_list = []):
        expected_metaclass = metaclass
        expected_bases = bases
        expected_kwonlyargs = kwonlyargs
        expected_kw_defaults = kw_defaults
        expected_defaults = defaults
        expected_vararg = vararg
        expected_kwarg = kwarg
        expected_body = body

# Generated at 2022-06-12 03:46:32.037092
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast as pyast
    import typed_ast.ast3 as ast

    code = r"""class A(object, metaclass=B, **kwargs):
    pass
"""
    tree = pyast.parse(code)
    tree = MetaclassTransformer().visit(tree)

# Generated at 2022-06-12 03:46:33.766405
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_parser.test_import_helper import assert_node

# Generated at 2022-06-12 03:46:42.548243
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
    class C(metaclass=int):
        pass
    """
    tree = ast.parse(code)
    mc = MetaclassTransformer()
    mc.visit(tree)
    result = ast.dump(tree)
    expected = (
        "Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0), ClassDef(name='C', bases=[Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), args=[Num(n=int)], keywords=[])], keywords=[], starargs=None, kwargs=None, body=[Pass()])])"
    )
    assert result == expected

# Generated at 2022-06-12 03:46:51.510643
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    body = [
        ast.ClassDef(
            name='A',
            bases=[ast.Name(id='object', ctx=ast.Load())],
            body=[
                ast.Pass()
            ],
            decorator_list=[],
            keywords=[
                ast.keyword(
                    arg='metaclass',
                    value=ast.Name(id='A', ctx=ast.Load()),
                )
            ],
        ),
    ]

    node = ast.Module(body=body)

    result = MetaclassTransformer().visit(node)
    assert len(result.body) == 2
    class_def = result.body[1]
    assert class_def.bases[0].func.value.id == '_py_backwards_six_withmetaclass'



# Generated at 2022-06-12 03:46:52.260280
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-12 03:46:53.386570
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-12 03:46:54.582407
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import parse

# Generated at 2022-06-12 03:49:06.035242
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.ast import get_ast
    from ..utils.compare import expect_equal
    from . import NodeTransformerTest

    t = NodeTransformerTest(MetaclassTransformer,
                            source('', 'class A(object, metaclass=C): pass'),
                            source('', "from six import with_metaclass as _py_backwards_six_withmetaclass\n"
                                    "class A(_py_backwards_six_withmetaclass(C, object))"))
    t.test()

# Generated at 2022-06-12 03:49:06.824835
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-12 03:49:14.871975
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert_equal(ast.dump(MetaclassTransformer.run_pipeline(
        """
        class A(metaclass=B, factory=C, name=abc):
            pass
        """
    )),
    """
    Module(body=[
        ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0),
        ClassDef(name='A', bases=[Call(_py_backwards_six_withmetaclass, args=[Name(id='B')], keywords=[], starargs=None, kwargs=None)], body=[], decorator_list=[]),
    ])
    """)



# Generated at 2022-06-12 03:49:17.767199
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ast_tools.utils.tree import parse

    code = '''class A(metaclass=B):
        pass'''

# Generated at 2022-06-12 03:49:23.685047
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_env import test_env

    source = '''class A(metaclass=B):
            pass'''

    node = test_env.get_ast(source)
    MetaclassTransformer().visit(node)
    result = test_env.compile(node, source)
    assert result == 'from six import with_metaclass as _py_backwards_six_with_metaclass;class A(_py_backwards_six_with_metaclass(B)):\n    pass\n'

# Generated at 2022-06-12 03:49:25.776740
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    snippet_class_bases = class_bases.get_body # type: ignore
    snippet_six_import = six_import.get_body # type: ignore

# Generated at 2022-06-12 03:49:33.898395
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from six import with_metaclass
    from typing import cast
    transformer = MetaclassTransformer()
    tree = ast.parse("""
        class A(object):
            pass
        class B(metaclass=A):
            pass
    """, mode='exec')
    expected = ast.parse("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(object):
            pass
        class B(_py_backwards_six_withmetaclass(A)):
            pass
    """, mode='exec')
    class A:
        pass
    class B(with_metaclass(A)):
        pass
    assert transformer.visit(tree) == expected

# Generated at 2022-06-12 03:49:38.472760
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = "class A(metaclass=B, n=4):\n        pass"
    expected = "class A(_py_backwards_six_with_metaclass(B, n=4)):\n        pass"

    t = MetaclassTransformer()
    node = ast.parse(code)

    new_node = t.visit(node)
    new_code = compile(new_node, "<ast>", "exec").co_consts[0]
    assert new_code == expected

# Generated at 2022-06-12 03:49:43.056452
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...testing import assert_transformed_ast
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    _py_backwards_six_withmetaclass(B, *[A])
    """
    assert_transformed_ast(
        source="""
        class A(A, metaclass=B):
            pass
        """,
        transformer=MetaclassTransformer,
        expected=expected
    )

    assert_transformed_ast(
        source="""
        class A(metaclass=B):
            pass
        """,
        transformer=MetaclassTransformer,
        expected=expected
    )

# Generated at 2022-06-12 03:49:49.370173
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import parse as astparse
    from ..utils import unparse as astunparse
   
    code = """
        class A(metaclass=B):
            pass
    """
    node = astparse(code)
    MetaclassTransformer().visit(node)

    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    assert astunparse(node) == expected
