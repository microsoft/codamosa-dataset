

# Generated at 2022-06-12 03:39:49.246139
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    def test(code):
        node = ast.parse(code).body[0]
        expected = ast.parse(expected)
        result = MetaclassTransformer().visit(node)
        assert ast.dump(result, include_attributes=False) == ast.dump(expected, include_attributes=False)


# Generated at 2022-06-12 03:39:56.071750
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    expected_output = """class Foo(object):
    pass
"""
    input_code = """class Foo(metaclass=type):
    pass
"""
    tree = ast.parse(input_code)
    transformer = MetaclassTransformer()
    tree = transformer.visit(tree)
    assert transformer._tree_changed
    assert expected_output == astunparse.unparse(tree)


# Generated at 2022-06-12 03:40:00.796719
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # class A(B, C):
    tree = ast.parse("class A(B, C): pass")

    # expected = class A(_py_backwards_six_metaclass_with(B)):

# Generated at 2022-06-12 03:40:03.325680
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import AssertSnippetImplementation

    AssertSnippetImplementation(MetaclassTransformer, 'six')


# Generated at 2022-06-12 03:40:09.719697
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse('class A(metaclass=int): pass')
    MetaclassTransformer(verbose=0).visit(module)
    expected = ast.parse(
        'from six import with_metaclass as _py_backwards_six_withmetaclass\n'
        'class A(_py_backwards_six_withmetaclass(int, object)): pass')
    # we cannot compare directly the ast of the module, since the first node
    # will be a Module(body=[]) node, so we have to compare the body of the
    # module.
    assert module.body == expected.body

# Generated at 2022-06-12 03:40:17.839748
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast
    from ..snippet import _code

    node = ast.parse(_code(r'''
        class C(metaclass=type):
            def __init__(self):
                pass
        '''))  # type: ast.Module

    visitor = MetaclassTransformer()
    visitor.visit(node)
    expected = _code(r'''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class C(_py_backwards_six_withmetaclass(type, )):
        def __init__(self):
            pass
    ''')
    actual = ast.unparse(node)
    assert actual == expected, (actual, expected)

# Generated at 2022-06-12 03:40:27.267810
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import sys
    import unittest

    from six import assertRaisesRegex
    from py_backwards.transformers.metaclass import MetaclassTransformer
    from py_backwards.utils.snippet import snippet

    @snippet
    def code():
        class A:
            pass

        class B(metaclass=A):
            pass

    metaclass = snippet(
        '''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A:
            pass

        class B(_py_backwards_six_withmetaclass(A)):
            pass
        '''
    )


# Generated at 2022-06-12 03:40:29.129587
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_python.compiler.typed_codegen import OneOf

# Generated at 2022-06-12 03:40:37.181054
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3
    from .utils.comparators import compare_ast

    LINES = (
        'from six import with_metaclass as _py_backwards_six_withmetaclass\n'
        'class A(_py_backwards_six_withmetaclass(B)):\n'
        '    pass\n'
    )

    for line in LINES.splitlines():
        tree = ast.parse(line)
        metaclass = MetaclassTransformer()
        metaclass.visit(tree)
        tree_ = ast.parse(line)
        compare_ast(tree, tree_)

# Generated at 2022-06-12 03:40:39.069837
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from astor import dump
    from astor.code_gen import to_source
    import ast


# Generated at 2022-06-12 03:40:46.042094
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from typing import Any
    from ..utils.testing import assert_parsed

    code = "class C(metaclass=object): pass"
    expected = "from six import with_metaclass as _py_backwards_six_withmetaclass\nclass C(_py_backwards_six_withmetaclass(object)): pass"
    assert_parsed(code, expected, MetaclassTransformer)

# Generated at 2022-06-12 03:40:52.784452
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import parse

    source = """
        class A(metaclass=B):
            pass
        """
    expected = """
        class A(_py_backwards_six_withmetaclass(B, )):
            pass
        """
    tree = parse(source)
    assert tree.body[0].bases[0].args[0].id == 'B'
    tree = MetaclassTransformer().visit(tree)  # type: ignore
    assert expected == str(tree)


# Generated at 2022-06-12 03:41:01.995537
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import typing as t

    class TestTransformer(MetaclassTransformer):
        def __init__(self) -> None:
            super().__init__()
            self.classes: t.List[ast.ClassDef] = []
            self.visit_ClassDef_called: int = 0

        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            self.visit_ClassDef_called += 1
            self.classes.append(node)
            return super().visit_ClassDef(node)

    s = """
    class A(metaclass=B):
        pass
    """
    t = TestTransformer()
    tree = ast.parse(s)
    t.visit(tree)


# Generated at 2022-06-12 03:41:12.775712
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...tests.lib.utils import assert_code_equal
    from typed_ast import parse

    with_metaclass = 'class A(metaclass=B):\n    pass'
    expected_result = 'class A(_py_backwards_six_with_metaclass(B)):\n    pass'
    assert_code_equal(MetaclassTransformer.run(with_metaclass),
                      expected_result)

    # Test that the order is preserved
    original_class = 'class A(b, metaclass=B):\n    pass'
    expected = 'class A(_py_backwards_six_with_metaclass(B), b):\n    pass'
    node = parse(original_class)
    for visitor in MetaclassTransformer.get_visitors():
        node = visitor.vis

# Generated at 2022-06-12 03:41:14.767705
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:41:19.338332
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = source_from("""
    class Base(metaclass=B):
        pass
    """)

    expected = expected_from("""
    class Base(_py_backwards_six_with_metaclass(B)):
        pass
    """)

    result = MetaclassTransformer(source).visit()
    assert_equal(expected, result)

# Generated at 2022-06-12 03:41:23.424517
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import skillbridge
    from ..utils.source import source
    source = source(skillbridge)
    tree = ast.parse(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    code = compile(tree, '<test>', 'exec')
    exec(code, {}, {})
    assert 'SkillBridge' in globals()

# Generated at 2022-06-12 03:41:33.367960
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import Module
    from typed_ast.ast3 import ClassDef
    from typed_ast.ast3 import Name
    from typed_ast.ast3 import If
    from typed_ast.ast3 import FunctionDef
    from typed_ast.ast3 import Pass
    from typed_ast.ast3 import Call
    from typed_ast.ast3 import Load
    from typed_ast.ast3 import Return

# Generated at 2022-06-12 03:41:34.457274
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-12 03:41:41.993768
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap
    in_code = textwrap.dedent('''\
        class A(metaclass=B, c=d):
            pass
    ''')
    out_code = textwrap.dedent('''\
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B, *[])):
            pass
    ''')
    node = ast.parse(in_code)
    node = MetaclassTransformer().visit(node)
    assert ast.dump(node) == out_code

# Generated at 2022-06-12 03:41:47.906550
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from six import with_metaclass as _py_backwards_six_withmetaclass


# Generated at 2022-06-12 03:41:53.944090
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # type: () -> None
    class_def = ast.ClassDef(name='A',
                             bases=[],
                             keywords=[
                                 ast.keyword(arg='metaclass',
                                             value=ast.Name(id='B'))
                             ],
                             body=[],
                             decorator_list=[])
    output = ast_string(class_def, MetaclassTransformer())
    assert output == "class A(py_backwards_six_withmetaclass(B)):\n    pass"

# Generated at 2022-06-12 03:41:57.218203
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...testing import assert_code_equal
    from ...testing import write_and_parse
    from ...testing.data import snippet_with_future_import
    from ...testing.data import snippet_with_six
    

# Generated at 2022-06-12 03:41:59.517347
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.test_utils import source_to_nodes, assert_equal_ast

# Generated at 2022-06-12 03:42:08.110519
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import inspect
    import textwrap
    from ..utils.tree import tree_to_str

    test_template = textwrap.dedent("""
    class Test(metaclass=A):
        pass
    """)

    class_template = textwrap.dedent("""
    class Test(_py_backwards_six_withmetaclass(A)):
        pass
    """)

    class_template2 = textwrap.dedent("""
    class Test(_py_backwards_six_withmetaclass(C, B)):
        pass
    """)

    class_template3 = textwrap.dedent("""
    class Test(_py_backwards_six_withmetaclass(B, C, D)):
        pass
    """)


# Generated at 2022-06-12 03:42:12.655617
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import unit_test

    class Parent(metaclass=type):
        pass

    class Child(Parent):
        pass

    before_tree = ast.parse(inspect.getsource(Child))

    after_tree = MetaclassTransformer().visit(before_tree)

    assert unit_test(Child, after_tree)

# Generated at 2022-06-12 03:42:22.562025
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:28.844486
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse("""
    class A(metaclass=str):
        pass
    """)
    instance = MetaclassTransformer()
    instance.visit_ClassDef(node.body[0])
    assert instance._tree_changed is True

    # Old:
    # class A(metaclass=str):
    # New:
    # class A(_py_backwards_six_with_metaclass(str))
    # assert node.body[0].bases[0].value.args[0].value.value == 'str'
    assert node.body[0].bases[0].value.args[0].id == 'str'

# Generated at 2022-06-12 03:42:38.204609
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from . import semantic_analysis
    from .six_import import SixImportTransformer
    from .with_metaclass import WithMetaclassTransformer
    from .. import tree
    from ..py23 import ast23
    from ..py26 import ast26
    
    ############################################
    # VERIFY THAT THE VISIT METHOD IS WORKING #
    ############################################
    def _verify(cls):
        tree.tree_to_str(cls)
        tree.dump_tree(cls)

        cls = semantic_analysis.SemanticAnalyzer.run(cls)
        cls = SixImportTransformer.run(cls)
        cls = MetaclassTransformer.run(cls)
        cls = WithMetaclassTransformer.run(cls)

        tree.tree_to_str

# Generated at 2022-06-12 03:42:46.671146
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six
    import astor

    class A(metaclass=six.with_metaclass(A)):
        pass
    node = ast.parse(astor.to_source(A))
    expected_node = ast.parse(six_import.get_source() + class_bases.get_source())
    expected_node.body[1].name = 'A'
    expected_node.body[1].body = [ast.Pass()]
    transformer = MetaclassTransformer()
    node = transformer.visit(node)
    assert transformer._tree_changed
    assert astor.to_source(node) == astor.to_source(expected_node)



# Generated at 2022-06-12 03:42:58.341203
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    tree = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    MetaclassTransformer().visit(tree)
    exec(compile(tree, '<string>', 'exec'), locals())
    assert locals()['A'].__bases__ == (six.with_metaclass(B),)



# Generated at 2022-06-12 03:43:07.101042
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six
    from ..transpile import Transpiler
    from ..utils.inputsource import fakesource
    from ..utils.testing import assertCodeEqual

    source = """
        class A(metaclass=B):
            pass
    """
    tree = ast.parse(source)
    Transpiler().visit(tree)
    assertCodeEqual(source, six.text_type(fakesource(tree)))

    source = """
        class A(B, metaclass=C):
            pass
    """
    tree = ast.parse(source)
    Transpiler().visit(tree)
    assertCodeEqual(source, six.text_type(fakesource(tree)))

# Generated at 2022-06-12 03:43:13.859615
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..visitors.formatting import NoopTransformer
    from ..utils.source import source

    class MetaclassTest(ast.NodeVisitor, NoopTransformer):
        target = (2, 7)

        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.keywords = [ast.keyword(arg='metaclass',
                                         value=ast.Name(id='Foo',
                                                        ctx=ast.Load()))]
            return node

    mt = MetaclassTest()

# Generated at 2022-06-12 03:43:23.387962
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import parse, dump
    from .test_utils import check_transforms_to, check_tree_unchanged

    # With keyword arg
    c = check_transforms_to(MetaclassTransformer,
                            parse("""class Foo(FooBar): pass""").body[0],
                            parse("""class Foo(_py_backwards_six_withmetaclass(FooBar))""").body[0])

    # With multiple bases
    c = check_transforms_to(MetaclassTransformer,
                            parse("""class Foo(metaclass=FooBar, BarBaz): pass""").body[0],
                            parse("""class Foo(_py_backwards_six_withmetaclass(FooBar, BarBaz))""").body[0])

    # Without keyword arg
    check

# Generated at 2022-06-12 03:43:34.453178
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import textwrap
    from . import unparse

    six_mod = ast.parse(six_import.get_code())
    with_metaclass_stmt = six_mod.body[0]
    with_metaclass = with_metaclass_stmt.value.value
    with_metaclass_name = with_metaclass.id

    expected_stmts = [with_metaclass_stmt]
    expected_stmts.extend([ast.parse(textwrap.dedent(f"""
        class A({with_metaclass_name}(_py_backwards_six_withmetaclass)):
            pass
    """))])


# Generated at 2022-06-12 03:43:39.591027
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Imports six
    node = ast.parse('class X(metaclass=y): pass')
    transformer = MetaclassTransformer()
    transformer.visit(node)
    expected = ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass\nclass X(_py_backwards_six_with_metaclass(y)): pass')
    assert ast.dump(node) == ast.dump(expected)

    # Remove metaclass keyword
    node = ast.parse('class X(metaclass=y): pass')
    transformer = MetaclassTransformer()
    transformer.visit(node)

# Generated at 2022-06-12 03:43:48.845477
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.testing import get_assert_equality_string, run_transform_test
    from typed_ast import ast3 as ast

    code = '''
    class A(metaclass=B):
        pass
    '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_with_metaclass


    class A(_py_backwards_six_with_metaclass(B)):
        pass
    '''
    tree = ast.parse(code)
    result = tree.body[0]
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert get_assert_equality_string(expected, result) == ''

    run_transform_test(MetaclassTransformer, expected, code)

# Generated at 2022-06-12 03:43:58.378577
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast, textwrap
    from py_backwards.transformers.metaclass import MetaclassTransformer
    from py_backwards.utils.tree import merge
    # Given
    node = ast.parse(textwrap.dedent("""
        class A(metaclass=B):
            pass
    """)[1:])
    transformer = MetaclassTransformer()

    # When
    transformer.visit(node)

    # Then
    expected_output = ast.parse(textwrap.dedent("""
        class A(_py_backwards_six_withmetaclass(B))
    """))
    assert merge(node) == merge(expected_output)



# Generated at 2022-06-12 03:44:02.806613
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.testing import target_and_dependencies__
    tree = ast.parse("""
        class A(metaclass=B):
            pass
    """)
    result = ast.dump(tree)
    expected = ast.dump(ast.parse("""
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """))
    assert result == expected
    assert target_and_dependencies__(MetaclassTransformer, tree) == (2, 7, ['six'])

# Generated at 2022-06-12 03:44:11.853439
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_node, source_to_code
    from ... import target
    def test_func(a, b, *args, **kwargs):
        with target(*(2, 7)):
            class A(object):
                def __init__(self, x):
                    self.x = x
            class B(metaclass=abc.ABCMeta):
                @abc.abstractmethod
                def f(self):
                    pass
            class C(metaclass=int):
                pass
        with target(*(3, 0)):
            class A(object):
                def __init__(self, x):
                    self.x = x
            class B(metaclass=abc.ABCMeta):
                @abc.abstractmethod
                def f(self):
                    pass

# Generated at 2022-06-12 03:44:37.705381
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """It transforms `class A(metaclass=B): ...` to `class A(_py_backwards_six_withmetaclass(B)): ...`"""
    transformer = MetaclassTransformer()
    tree = ast.parse('class A(metaclass=B):\n    pass')
    transformer.visit(tree)

# Generated at 2022-06-12 03:44:46.400620
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_compiled_to_equal

    assert_compiled_to_equal(
        MetaclassTransformer,
        """
        class A:
            pass
        """,
        """
        class A:
            pass
        """)

    assert_compiled_to_equal(
        MetaclassTransformer,
        """
        class A(metaclass=B):
            pass
        """,
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """)


# Generated at 2022-06-12 03:44:52.098135
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap
    from ..testing_utils import transform

    source = textwrap.dedent('''
        class A(metaclass=B):
            pass
    ''')

    expect = textwrap.dedent('''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

    assert transform(MetaclassTransformer, source) == expect

# Generated at 2022-06-12 03:45:00.306005
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    from typed_ast import ast3 as ast
    from typed_ast.pprint import pprint
    from .test_BaseNodeTransformer import BaseNodeTransformerTestCase
    from ..utils.six.moves import StringIO

    class TestCase(BaseNodeTransformerTestCase):
        transformer = MetaclassTransformer
        target_version = (2, 7)
        dependencies = ('six',)

        def test_visit_ClassDef(self):
            code = """\
                class A(metaclass=B):
                    pass
            """
            tree = ast.parse(code)
            result = self.transform(tree)


# Generated at 2022-06-12 03:45:08.531141
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils import helpers  # type: ignore
    from ..utils.py_backwards_test_helper import TestCase

    code = 'class A(metaclass=B):\n    pass'
    expected_code = 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass'
    tree = ast.parse(code)
    tree = MetaclassTransformer().visit(tree)  # type: ignore
    self = TestCase()
    self.assertEqual(helpers.to_source(tree), expected_code)

# Generated at 2022-06-12 03:45:17.485955
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six
    import textwrap
    import unittest
    from typed_ast import ast3 as ast
    from ..types import typing
    from ..utils.snippet import strip_body
    from ..utils.source import Source

    class TestCase(unittest.TestCase):

        def test_option_true(self):
            source = textwrap.dedent("""
                '''doc'''
                import typing

                class Base(metaclass=typing.Type):
                    pass

                class A(Base):
                    pass
            """)
            source = Source(source)
            node = source.get_ast().body
            transformer = MetaclassTransformer()
            transformer.visit(node)
            source = source.set_ast(node)
            source.add_future_import('typing_extensions')
           

# Generated at 2022-06-12 03:45:23.599356
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from six import with_metaclass as _py_backwards_six_with_metaclass
    h = ast.parse("""class A(metaclass=type):
                        pass""")
    m = MetaclassTransformer()
    import typed_ast.ast3 as ast
    assert m.visit(h) == ast.parse("""class A(_py_backwards_six_with_metaclass(type)):
                                           pass""")


# Generated at 2022-06-12 03:45:28.973875
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    input_ast = ast.parse("""
    class Matrix(metaclass=ABCMeta):
        pass
    """)
    expected_ast = ast.parse("""
    from six import with_metaclass as _py_backwards_six_with_metaclass
    class Matrix(_py_backwards_six_with_metaclass(ABCMeta)):
        pass
    """)
    with_metaclass = MetaclassTransformer()
    with_metaclass.visit(input_ast)
    assert ast.dump(input_ast) == ast.dump(expected_ast)

# Generated at 2022-06-12 03:45:35.725946
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    snippet = """
        class A(B, metaclass=C):
            pass
        class B(metaclass=C):
            pass
        class C(object):
            pass
        """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(C, B)):
            pass
        class B(_py_backwards_six_withmetaclass(C)):
            pass
        class C(object):
            pass
        """
    assert_compile(snippet, expected)

# Generated at 2022-06-12 03:45:45.177051
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    def check(node, expected):
        transformer = MetaclassTransformer()
        transformer.visit(node)
        assert transformer._tree_changed == expected

    node = ast.parse('class A(metaclass=B): pass')
    check(node, True)
    expected = ast.parse("""
        import six
        class A(six.with_metaclass(B)): pass
    """)
    assert ast.dump(node) == ast.dump(expected)

    node = ast.parse('class A(): pass')
    check(node, False)
    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-12 03:46:28.790855
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.syntax_tree import parse
    ast = parse('class A(metaclass=B): pass')
    transformer = MetaclassTransformer(parse('from six import with_metaclass as _py_backwards_six_withmetaclass'))
    transformer.visit(ast)
    assert ast.body[0].bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert ast.body[0].bases[0].args[0].id == 'B'

# Generated at 2022-06-12 03:46:32.677064
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    mod = ast.parse("""
        class B(metaclass=A):
            pass
        """)
    MetaclassTransformer(mod).run()
    assert mod.body[0].value.bases[0].value.args[0].id == 'A'
    assert mod.body[0].value.bases[1].id == 'B'

# Generated at 2022-06-12 03:46:40.536159
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast.parse('class A: pass')
    transformer = MetaclassTransformer()
    new_tree = transformer.visit(tree)
    assert transformer._tree_changed is False
    assert ast.dump(new_tree) == ast.dump(tree)

    tree = ast.parse('class A(metaclass=B): pass')
    transformer = MetaclassTransformer()
    new_tree = transformer.visit(tree)
    assert transformer._tree_changed is True
    assert ast.dump(new_tree) == ast.dump(ast.parse('class A(_py_backwards_six_withmetaclass(B)): pass'))

# Generated at 2022-06-12 03:46:49.183575
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six  # type: ignore
    from typed_ast import ast3 as ast
    from py_backwards.transformers.metaclass import MetaclassTransformer

    snippet = """
    class A(metaclass=int):
        pass
    class B(object):
        pass
    """
    before = ast.parse(snippet)
    transformer = MetaclassTransformer()
    after = transformer.visit(before)

    # These are the same class
    assert type(before) is type(after)
    assert type(before.body) is type(after.body)
    assert type(before.body[0]) is type(after.body[0])
    assert type(before.body[1]) is type(after.body[1])

    # We have changed the first class definition
    # import six
    # class

# Generated at 2022-06-12 03:46:58.289177
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astunparse
    from ..utils.test_transformer import test_transform
    test_transform(MetaclassTransformer,
                   """
            class A(metaclass=B):
                pass
        """,
        """
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A(_py_backwards_six_withmetaclass(B)):
                pass
        """)
    test_transform(MetaclassTransformer,
                   """
            class A(B, metaclass=C):
                pass
        """,
        """
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A(_py_backwards_six_withmetaclass(C), B):
                pass
        """)

# Generated at 2022-06-12 03:47:05.056945
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = "class A(metaclass=B):\n    pass"
    tree = ast.parse(code)
    transformer = MetaclassTransformer()
    transformed_tree = transformer.visit(tree)
    #
    assert transformer.tree_changed is True
    module_code = compile(transformed_tree, '<string>', 'exec')
    global_dict = {}
    global_dict['B'] = object
    exec(module_code, global_dict)
    A = global_dict['A']
    assert A.__bases__ == (object,)
    assert A.__mro__ == (A, object)
    assert A.__class__ == type


# Generated at 2022-06-12 03:47:07.031560
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:47:11.625809
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import compile
    node = ast.parse('class Foo(metaclass=Bar): pass').body[0]
    MetaclassTransformer(None).visit(node)
    assert compile(ast.Module(body=[node]), '<test>', 'exec') == \
        "class Foo(_py_backwards_six_withmetaclass(Bar), ):\n    pass"



# Generated at 2022-06-12 03:47:18.445103
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import ClassDef, Keyword, Name, Load, Call, Tuple, NameConstant, Assign, Attribute, Expr
    from .base import BaseNodeTransformer
    from ..utils.tree import get_name
    node = ast.ClassDef(name='Test',
                bases=[],
                keywords=[ast.Keyword(arg="metaclass", value=ast.Name(id="abc", ctx=ast.Load()))])
    class example_visit_ClassDef_MetaclassTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node):
            return node
    assert isinstance(\
        example_visit_ClassDef_MetaclassTransformer().visit(node), ClassDef)

# Generated at 2022-06-12 03:47:25.100521
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import _six_withmetaclass

    import ast as pyast
    import typed_ast.ast3 as typed_ast
    from textwrap import dedent

    source = dedent("""
        class A(metaclass=B):
            pass
    """)

    expected = typed_ast.parse(dedent("""
        class A(_six_withmetaclass(B)):
            pass
    """))

    tree = pyast.parse(source)
    tree = MetaclassTransformer().visit(tree)

    assert typed_ast.dump(tree) == typed_ast.dump(expected)

# Generated at 2022-06-12 03:48:11.280385
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ...dependencies import Package

    code = """
        class A:
            pass
        class B(metaclass=type):
            pass
        class C(x, metaclass=type):
            pass
    """
    package = Package('test')
    package.add_class(
        MetaclassTransformer().transform_code(code)
    )
    assert package.name == 'test'
    assert len(package.classes) == 3
    assert package.classes[0].name == 'A'
    assert package.classes[0].bases == ()
    assert package.classes[1].name == 'B'
    assert package.classes[1].bases == ('type',)
    assert package.classes[2].name == 'C'
    assert package.classes[2].bases == ('x', 'type')

# Generated at 2022-06-12 03:48:19.067552
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import os
    from pathlib import Path
    from .base import BaseNodeTransformer

    class PythonFileSnippet(BaseNodeTransformer):
        def __init__(self):
            self._nodes = None
            self._class_def = None

        def get_snippet(self):
            return '\n'.join(self._nodes)

        def visit_Module(self, node):
            self._nodes = []
            self._class_def = None
            return self.generic_visit(node)

        def visit_ClassDef(self, node):
            if self._class_def is None:
                self._class_def = node

            return self.generic_visit(node)

        def generic_visit(self, node):
            self._nodes.append(node)

    test_dir = Path

# Generated at 2022-06-12 03:48:24.311793
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..analyses.importfinders import ImportFinderPass

    tf = MetaclassTransformer(target=MetaclassTransformer.target)
    tree = tf.run(six_import.get_ast())
    finder = ImportFinderPass()
    finder.visit(tree)

    assert finder.names == dict()

    tree = tf.run(class_bases.get_ast())
    finder = ImportFinderPass()
    finder.visit(tree)

    assert finder.names == dict(six=1)

# Generated at 2022-06-12 03:48:25.667919
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    print(MetaclassTransformer.__doc__)  # type: ignore

# Generated at 2022-06-12 03:48:30.944261
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    class Dummy(ast.AST):
        pass

    mt = MetaclassTransformer()
    mt.visit_ClassDef(ast.ClassDef(bases=[], body=[Dummy()],
                      decorator_list=[], keywords=[ast.keyword(arg='metaclass',
                                                               value=ast.Name())],
                      name='A'))
    assert mt.tree_changed == True


# Generated at 2022-06-12 03:48:33.418192
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..compiler import compile_string

# Generated at 2022-06-12 03:48:35.005030
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-12 03:48:37.150422
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    src = """class A(metaclass=B): pass"""

# Generated at 2022-06-12 03:48:38.944718
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

# Generated at 2022-06-12 03:48:47.896954
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # type: () -> None
    from .test_utils import load_example_snippet
    from ..utils.snippet import make_snippet
    from ..utils.code_blocks import newlines, list_to_block

    code_block = newlines(["class TestClass(metaclass=type):",
                           "    pass"])
    tree = load_example_snippet(code_block, py_version=(2, 7))
    assert next(tree.body).name == 'TestClass'
    tree = MetaclassTransformer().visit(tree)
    assert next(tree.body).name == 'TestClass'