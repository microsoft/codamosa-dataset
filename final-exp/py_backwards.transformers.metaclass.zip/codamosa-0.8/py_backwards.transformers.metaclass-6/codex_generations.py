

# Generated at 2022-06-12 03:39:58.256232
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from mixt.contrib.typing import typing as typed_ast
    from .base import BaseNodeTransformer

    class Result(typed_ast.AST):
        pass

    class_def = typed_ast.parse(
        """
        class A(metaclass=six.with_metaclass):
            pass
        """, mode='exec').body[0]

    transformer = MetaclassTransformer(minimum=3)
    assert transformer.visit(class_def) == Result()

# Generated at 2022-06-12 03:40:07.039251
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_setup import setup_test_logging
    from .test_setup import get_test_codecontext
    from ..utils.source import source

    setup_test_logging()
    codecontext = get_test_codecontext()

    six_import_source = six_import.get_sourcecode()
    class_bases_source = class_bases.get_sourcecode()
    expected_source = textwrap.dedent("""\
        {six_import_source}
        class A({class_bases_source}):
            pass
        """).format(six_import_source=six_import_source, class_bases_source=class_bases_source)

    transformer = MetaclassTransformer(target=(3, 7))
    transformer.visit(codecontext)
   

# Generated at 2022-06-12 03:40:10.941050
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    @snippet
    def code():
        class A(metaclass=B):
            pass

    tree = compile(code.get_ast(), '<string>', 'exec')
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit_Module(tree)
    assert code.get_body() == metaclass_transformer.to_source()

# Generated at 2022-06-12 03:40:17.436962
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class Mock(ast.AST):
        def __eq__(self, other):
            return type(self) == type(other)

    n = ast.Name("n", ast.Load())
    kw = ast.arg("metaclass", n)
    cdef = ast.ClassDef("A", [kw], [], [], [])
    l = ast.List([Mock()])
    m = Mock()
    # naive implementation (always returns True for equality):
    return cdef.bases == l and cdef.keywords[0].value == m

# Generated at 2022-06-12 03:40:22.572119
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .trampoline import run_visitor
    from .class_ import assert_equal_source

    class Foo(metaclass=type):
        pass

    source = inspect.getsource(Foo)
    source = source.replace('type', 'type_metaclass')
    module = run_visitor(source, MetaclassTransformer)
    Foo_ = getattr(module, 'Foo')
    assert_equal_source(Foo, Foo_)

# Generated at 2022-06-12 03:40:32.561259
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse("""
        import six
        class A(metaclass=int):
            pass
        class B(metaclass=six.with_metaclass):
            pass
        class C():
            pass
    """)

    transformer = MetaclassTransformer(None, None)
    transformer.visit(module)
    assert transformer.tree_changed

    expected = ast.parse("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(int)):
            pass
        class B(_py_backwards_six_withmetaclass(six.with_metaclass)):
            pass
        class C():
            pass
    """)

# Generated at 2022-06-12 03:40:39.308169
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_base import TreeTransformTestCase
    from typed_ast import ast3 as ast

    code = "class A(metaclass=B): pass"
    result = "class A(_py_backwards_six_withmetaclass(B)): pass"
    tree = ast.parse(code)
    translator = MetaclassTransformer()
    expected_tree = ast.parse(result)
    translated_tree = translator.visit(tree)
    TreeTransformTestCase().assertEqual(translated_tree, expected_tree)

# Generated at 2022-06-12 03:40:40.328531
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:40:47.483630
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    import unittest
    import unittest.mock
    import io

    class TestMetaclassTransformer_visit_ClassDef(unittest.TestCase):
        def setUp(self):
            self.out = io.StringIO()
            self.saved_stdout = sys.stdout
            sys.stdout = self.out

        def tearDown(self):
            sys.stdout = self.saved_stdout


# Generated at 2022-06-12 03:40:51.140950
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import unittest
    import ast
    from ..utils.viper_ast import parse

# Generated at 2022-06-12 03:41:02.268323
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import compile
    import typing

    class A(metaclass=typing.TypeVar):
        pass

    tree = compile(A)
    assert type(tree.body[0]) == ast.ClassDef
    assert tree.body[0].keywords == []
    assert type(tree.body[0].bases[0]) == ast.Call
    assert tree.body[0].bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert type(tree.body[0].bases[0].args[0]) == ast.Name
    assert tree.body[0].bases[0].args[0].id == 'typing.TypeVar'


# Generated at 2022-06-12 03:41:13.613610
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import _ast
    node = _ast.Module()
    node.body = [
        _ast.ClassDef(
            name="A",
            bases=[],
            keywords=[
                _ast.keyword(arg="metaclass", value=_ast.Name(id="B"))
            ],
            body=[],
            decorator_list=[]
        )
    ]
    m = MetaclassTransformer()
    m.visit(node)
    assert node.body[0].body == six_import.get_body()
    assert node.body[1].bases == [_ast.Call(
        func=_ast.Name(id="_py_backwards_six_withmetaclass"),
        args=[_ast.Name(id="B"), _ast.List(elts=[])],
        keywords=[])]

# Generated at 2022-06-12 03:41:20.551356
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import assert_transformation, parse_ast
    from .six import insert_six_import

    source = """
        class A(metaclass=B):
            pass
        """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """

    module = parse_ast(source)
    insert_six_import(module)
    assert_transformation(
        MetaclassTransformer,
        module,
        expected
    )

# Generated at 2022-06-12 03:41:25.557740
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = """
                class A(metaclass=B):
                    pass
            """
    expected = """
                from six import with_metaclass as _py_backwards_six_withmetaclass
                class A(_py_backwards_six_withmetaclass(B)):
                    pass
            """
    result = compile_snippet(source, target=(2, 7), transform=MetaclassTransformer)
    assert result == expected

# Generated at 2022-06-12 03:41:35.029011
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    import six
    import inspect

    class TestNode(ast.ClassDef):
        """Test node used instead of ast.ClassDef"""

        _attributes = ("_fields", "_attributes", "_py_backwards_six_withmetaclass")

        def __init__(self, metaclass, *bases):
            self._py_backwards_six_withmetaclass = six.with_metaclass
            self.name = "A"
            self.keywords = [ast.keyword(arg="metaclass", value=metaclass)]
            self.bases = bases
            self.body = [ast.Pass()]
            self.decorator_list = []

        def __setstate__(self, state):
            self.__dict__ = state


# Generated at 2022-06-12 03:41:40.785095
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    expected = dedent('''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(object):

            pass
        ''').lstrip()
    tree = ast.parse(dedent('''
        class A(metaclass=object):
            pass
        ''').lstrip())
    MetaclassTransformer().visit(tree)

    assert ast.dump(tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-12 03:41:41.814122
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:41:51.025900
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    class Test(ast.NodeVisitor):
        def generic_visit(self, node):
            return node

    t = MetaclassTransformer()
    b = Test()

    for n in [1, 2, 3]:
        for i in [0, 1, 2]:
            node = ast.ClassDef(name='A', keywords=[ast.keyword(
                arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
                body=[ast.Pass()],
                decorator_list=[ast.Name(id='a', ctx=ast.Load())], lineno=n)
            insert_at(i, node.decorator_list, ast.Name(id='b', ctx=ast.Load()))

# Generated at 2022-06-12 03:42:01.043847
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..pygram import python_symbols as syms
    from ..utils.context import Context
    class Test:
        # Test for:
        # class Foo(bar=Baz):
        #     pass
        def test_class_with_metaclass(self):
            node = ast.ClassDef(name='Foo',
                                body=[],
                                keywords=[ast.keyword(arg='bar', value=ast.Name(id='Baz', ctx=ast.Param()))])

# Generated at 2022-06-12 03:42:06.094912
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    classdefnode = ast.parse('''
        class A(metaclass=B, object):
            pass
    ''').body[0]
    trans = MetaclassTransformer()
    trans.visit(classdefnode)

# Generated at 2022-06-12 03:42:11.272028
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:21.388568
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Patch the snippet imports
    import sys
    sys.modules['six'] = mock.MagicMock()
    from six import with_metaclass

    import ast
    from typed_ast import ast3 as ast3
    from py_backwards.transformers.metaclass import MetaclassTransformer

    node = ast.ClassDef(
        name='TestClass',
        bases=[],
        keywords=[ast.keyword(arg='metaclass', value=ast.Name('TestMeta'))],
        body=[],
        decorator_list=[]
    )
    node = MetaclassTransformer().visit(node)

    assert isinstance(node, ast.ClassDef)
    assert len(node.bases) == 1
    assert isinstance(node.bases[0], ast.Call)

# Generated at 2022-06-12 03:42:29.176962
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import inspect

    test_snippet = '''
    class Base(metaclass=type):
        pass
    '''

    expected_snippet = '''
    class Base(_py_backwards_six_with_metaclass(type)):
        pass
    '''

    class MetaclassTransformerMock(MetaclassTransformer):
        __qualname__ = 'MetaclassTransformerMock'

        def __init__(self):
            super().__init__()
            self.generic_visit_called = False

        def generic_visit(self, node):
            self.generic_visit_called = True
            return super().generic_visit(node)

    ast_tree = ast.parse(test_snippet)
    transform = MetaclassTransformerMock()

# Generated at 2022-06-12 03:42:35.468941
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    t = MetaclassTransformer()
    class_def = ast.parse('class A(metaclass=B): pass').body[0]
    class_def.bases = [ast.Name(id='X', ctx=ast.Load())]
    processed = t.visit(class_def)

    exp_class_def = ast.parse('class A(_py_backwards_six_withmetaclass(B, X)): pass').body[0]
    assert processed == exp_class_def



# Generated at 2022-06-12 03:42:37.548353
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ast import parse
    from six import with_metaclass

    transformer = MetaclassTransformer()

# Generated at 2022-06-12 03:42:47.224215
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """
    Generate a piece of code with the following structure:
    class A(metaclass=B, other=True):
        pass
    and checks, whether the keyword argument meta is removed and the
    bases are replaced with the six function
    _py_backwards_six_with_metaclass(metaclass=B, *bases)
    """
    code = "".join([
        "class A(metaclass=B, other=True):",
        "    pass"
    ])
    tree = ast.parse(code)
    assert tree.body[0].keywords[0].arg == 'metaclass'

    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed()
    assert not tree.body[0].keywords

# Generated at 2022-06-12 03:42:52.829952
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import textwrap
    source = textwrap.dedent('''\
        class A(metaclass = B):
            pass
        ''')

    result = textwrap.dedent('''\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        ''')

    node = ast.parse(source)
    result_node = ast.parse(result)

    transformer = MetaclassTransformer()
    transformer.visit(node)

    assert ast.dump(result_node) == ast.dump(node)

# Generated at 2022-06-12 03:42:59.622788
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    string_ = 'class A(metaclass=B): pass'
    node = ast.parse(string_, mode='exec')
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert ast.dump(node) == \
r"""Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass', lineno=1, col_offset=0)], level=0), ClassDef(name='A', bases=[_py_backwards_six_withmetaclass(B, )], keywords=[], body=[Pass(lineno=1, col_offset=30)], decorator_list=[], lineno=1, col_offset=0)])"""

# Generated at 2022-06-12 03:43:00.454841
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:43:10.470868
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    import ast
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '../../support'))
    import py_backwards_six_withmetaclass as six_withmetaclass
    import py_backwards_six_module as six_module

    # six_withmetaclass source:
    #    12:    import sys
    #    13:    from six import with_metaclass as _py_backwards_six_withmetaclass
    #    16:    def with_metaclass(metaclass, *bases):
    #    17:        return _py_backwards_six_withmetaclass(metaclass, *bases)
    #    18:
    #    19:    sys.modules[__name__] =

# Generated at 2022-06-12 03:43:24.648278
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    source = ast.parse('class A(metaclass=B): pass')
    tree = MetaclassTransformer().visit(source)
    expected = ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)): pass')
    assert astor.to_source(tree) == astor.to_source(expected)

# Generated at 2022-06-12 03:43:27.207918
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = 'class Hello(metaclass=Meta, object): pass'
    assert code in MetaclassTransformer.transform_snippet(code)

# Generated at 2022-06-12 03:43:37.166483
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import os
    import astor
    from .base import parse

    class_def = parse('''
        class A(object, metaclass=B):
            pass
    '''
    ).body[0]

    new_tree = MetaclassTransformer().visit(class_def)
    import six
    import sys

    # The code should not depend on six or typed_ast
    sys.modules['six'] = object()
    sys.modules['typed_ast'] = object()
    sys.modules['typed_ast.ast3'] = object()
    exec(compile(astor.to_source(new_tree), '<string>', 'exec'))
    del sys.modules['six']
    del sys.modules['typed_ast']
    del sys.modules['typed_ast.ast3']



# Generated at 2022-06-12 03:43:46.391324
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six
    from typed_ast import ast3 as ast

    if six.PY3:
        node = ast.parse('class A(metaclass=B): pass')
        ts = MetaclassTransformer()
        result = ts.visit(node)
        assert result.body[0].keywords == []
        assert result.body[0].bases == \
            ast.List(
                elts=[ast.Call(
                    func=ast.Name(id='_py_backwards_six_withmetaclass', ctx=ast.Load()),
                    args=[ast.Name(id='B', ctx=ast.Load())],
                    keywords=[],
                    starargs=None,
                    kwargs=None)],
                ctx=ast.Load())

# Generated at 2022-06-12 03:43:47.377804
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:43:53.078552
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """\
        from six import with_metaclass
        
        class A():
            pass
        """
    expected = """\
        from six import with_metaclass
        
        class A(_py_backwards_six_with_metaclass(object, object)):
            pass
        """
    tree = ast.parse(code)
    MetaclassTransformer().visit(tree)
    assert expected == astor.to_source(tree)

# Generated at 2022-06-12 03:44:00.628391
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    transformer = MetaclassTransformer()
    node = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    transformer.visit(node)
    actual = astor.to_source(node)
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
    class A(_py_backwards_six_withmetaclass(B, object)):
        pass
    """
    assert actual == expected

# Generated at 2022-06-12 03:44:04.439246
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import inspect
    import ast
    t = MetaclassTransformer()
    tree = ast.parse(inspect.getsource(MetaclassTransformer))
    new_tree = t.visit(tree)
    exec(compile(new_tree, filename="<ast>", mode="exec"))

# Generated at 2022-06-12 03:44:13.565414
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from collections import deque
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 03:44:19.214888
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import six
    import sys
    from ...utils.source import source_to_code
    from ..base import BaseNodeTransformer
    from .base import BaseTestTransformed

    # Test
    class base(metaclass=type):
        pass

    class metaclass_transformer_py_backwards_six_withmetaclass_test(base):
        pass

    code = source_to_code(metaclass_transformer_py_backwards_six_withmetaclass_test)
    assert 'from six import with_metaclass as _py_backwards_six_withmetaclass' in code
    assert '_py_backwards_six_withmetaclass(type' in code



# Generated at 2022-06-12 03:44:38.695629
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_setup import setup


# Generated at 2022-06-12 03:44:47.206174
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

# Generated at 2022-06-12 03:44:55.974929
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.visitor import visit
    
    from typed_ast import ast3 as ast
    from .six import six_import
    from .six import class_bases

    code = 'class B(metaclass=C): pass'
    expected = six_import.get_body() + \
               [ast.ClassDef(name='B',
                             bases=class_bases.get_body(metaclass=ast.Name(id='C', ctx=ast.Load()),
                                                        bases=[ast.Name(id='object', ctx=ast.Load())]),
                             keywords=[], body=[], decorator_list=[])]
    node = ast.parse(code)
    node = visit(node, MetaclassTransformer)

# Generated at 2022-06-12 03:45:02.379383
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import parse
    from .base import BaseNodeTransformerTestCase
    class Test(BaseNodeTransformerTestCase):
        def setUp(self):
            self.transformer = MetaclassTransformer(None)

        def test_class_with_metaclass(self):
            body = parse('class A(metaclass=B): pass')
            with self.assertNodeChanged(self.transformer.visit(body)):
                self.assertEqual(body.body[0].bases[0].args[0].id, 'B')
                self.assertEqual(body.body[0].bases[0].func.id, '_py_backwards_six_withmetaclass')

# Generated at 2022-06-12 03:45:11.751824
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .util import source_to_ast as sta
    from .util import ast_to_source as ats
    from .util import roundtrip_visit as rtv
    import textwrap

    cls = """\
    import six

    class Foo(metaclass=six.with_metaclass(Bar)):
        pass
    """
    ast_cls = sta(cls)

    # Test 1
    expected = textwrap.dedent(r"""\
    class Foo(six.with_metaclass(Bar, object)):
        pass
    """)
    tfmr = MetaclassTransformer()
    rtv(ast_cls, tfmr)
    assert tfmr.tree_changed is True
    assert ats(ast_cls) == expected

# Generated at 2022-06-12 03:45:16.895933
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    node = ast.parse('class A(B, metaclass=C):\n'
                     '    pass')

    # When
    actual = MetaclassTransformer().visit(node)

    # Then
    expected = ast.parse('class A(_py_backwards_six_withmetaclass(C, B)):\n'
                         '    pass')
    assert ast.dump(expected) == ast.dump(actual)

# Generated at 2022-06-12 03:45:26.011139
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..test_utils import transform

    code = ""
    transform(MetaclassTransformer, code, expected=code)

    code = "class C(object): pass"
    expected = code
    transform(MetaclassTransformer, code, expected=expected)

    code = "class C(metaclass=type): pass"
    expected = ("class C(_py_backwards_six_withmetaclass(type)): pass")
    transform(MetaclassTransformer, code, expected=expected)

    code = "class C(b, metaclass=type): pass"
    expected = ("class C(_py_backwards_six_withmetaclass(type, "
                "b)): pass")
    transform(MetaclassTransformer, code, expected=expected)


# Generated at 2022-06-12 03:45:32.585687
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    global _py_backwards_six_withmetaclass
    test_tree = ast.parse('''class A(metaclass=B):\n    pass''')
    MetaclassTransformer.run_visitor(test_tree)
    assert len(test_tree.body) == 1
    assert test_tree.body[0].__class__ == ast.ClassDef
    assert test_tree.body[0].name == 'A'
    assert test_tree.body[0].bases[0].__class__ == ast.Call
    assert test_tree.body[0].bases[0].func == _py_backwards_six_withmetaclass

# Generated at 2022-06-12 03:45:34.347972
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import gast as ast
    from py_backwards.transformers.metaclass import MetaclassTransformer


# Generated at 2022-06-12 03:45:45.497809
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    module = ast.parse('class A(metaclass=object): pass')
    transformer = MetaclassTransformer(None)
    node = module.body[0]
    visit = lambda node: transformer.visit(node)
    new_node = visit(node)
    assert new_node.__class__ is ast.ClassDef
    assert new_node.bases.__class__ is ast.Call
    assert new_node.bases.func.__class__ is ast.Attribute
    assert new_node.bases.func.value.__class__ is ast.Name
    assert new_node.bases.func.attr == '_py_backwards_six_withmetaclass'
    assert new_node.bases.args[0].__class__ is ast.Name

# Generated at 2022-06-12 03:46:26.145283
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    pass

# Generated at 2022-06-12 03:46:35.057937
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    def test(code: str) -> str:
        stmt = parse(code)
        metaclass_transformer = MetaclassTransformer()
        metaclass_transformer.visit(stmt)
        if metaclass_transformer._tree_changed:
            return to_source(stmt)
        else:
            return None

    assert test('class A(object):\n pass') is None

    assert test('class A(metaclass=B):\n pass') == \
        "from six import with_metaclass as _py_backwards_six_withmetaclass\n" \
        "class A(_py_backwards_six_withmetaclass(B)):\n" \
        "    pass\n"

    assert test('class A(metaclass=B, object):\n pass')

# Generated at 2022-06-12 03:46:43.250034
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
        class A(metaclass=B):
            pass
    """

    node = ast.parse(code)
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(node)

# Generated at 2022-06-12 03:46:52.092955
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    FOO = ast.Name(id='FOO', ctx=ast.Load())
    BAR = ast.Name(id='BAR', ctx=ast.Load())
    BAZ = ast.Name(id='BAZ', ctx=ast.Load())
    node = ast.ClassDef(
        name='A',
        bases=[BAR, BAZ],
        keywords=[ast.arg(arg='metaclass', annotation=None, value=FOO)],
        body=[],
        decorator_list=[])

    res = MetaclassTransformer().visit_ClassDef(node)
    assert isinstance(res, ast.ClassDef)
    res = ast.AugAssign(
        target=ast.Name(id='res', ctx=ast.Store()),
        op=ast.Assign(),
        value=res)

# Generated at 2022-06-12 03:47:01.228251
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from py_backwards.transformers.metaclass import MetaclassTransformer
    from typed_ast import ast3 as ast
    from ..utils.example_asts import class_def_with_metaclass_dict, class_def_without_metaclass_dict
    mt = MetaclassTransformer()
    node = ast.parse(class_def_with_metaclass_dict)
    mt.visit(node)
    assert mt._tree_changed is True
    assert node.body[0].bases[0].func.id == "_py_backwards_six_withmetaclass"
    node = ast.parse(class_def_without_metaclass_dict)
    mt.visit(node)
    assert mt._tree_changed is False
    assert len(node.body[0].bases) == 1


# Generated at 2022-06-12 03:47:04.735001
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
  node = ast.parse("""class A(metaclass=B): pass""")
  node = MetaclassTransformer().visit(node)
  assert(node.body[1].bases[0].func.id == '_py_backwards_six_withmetaclass')
  assert(node.body[1].bases[0].args[0].id == 'B')

# Generated at 2022-06-12 03:47:09.903525
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import roundtrip

    node = ast.parse('class A(object, metaclass=B): pass')

    result = roundtrip(node, MetaclassTransformer)
    assert result == 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass'

# Generated at 2022-06-12 03:47:17.211680
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Unit test for method visit_ClassDef of class MetaclassTransformer"""
    lines = (
        "class A(e, f, metaclass=B):",
        "    pass"
        )
    node = ast.parse('\n'.join(lines))
    target = (
        "from six import with_metaclass as _py_backwards_six_withmetaclass",
        "",
        "class A(_py_backwards_six_withmetaclass(B)):",
        "    pass"
        )
    test_node = MetaclassTransformer.run_pipeline(node)
    assert(ast.dump(test_node) == ast.dump(ast.parse('\n'.join(target))))

# Generated at 2022-06-12 03:47:21.810655
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Test duplication of class A
    a = ast.parse('''
        class A(metaclass=B):
            pass
    ''')
    MetaclassTransformer().visit(a)
    assert ast.dump(a) == ast.dump(ast.parse('''
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    '''))


# Generated at 2022-06-12 03:47:22.593740
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:49:06.936269
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

# Generated at 2022-06-12 03:49:15.692592
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    tree = ast.parse(
        dedent(
            """\
            class A(metaclass=B):
                pass
            """
        )
    )  # type: ast.Module

    # ## Unmodified module
    assert tree == ast.parse(
        dedent(
            """\
            class A(metaclass=B):
                pass
            """
        )
    )  # type: ast.Module

    # ## Run transform
    mt = MetaclassTransformer()
    mt.visit(tree)

    # ## Modified module

# Generated at 2022-06-12 03:49:23.719093
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # type: () -> None
    code_str = 'class A(metaclass=B, dict): pass'

    module = ast.parse(code_str)
    node = module.body[0]
    assert isinstance(node, ast.ClassDef)

    transformer = MetaclassTransformer()
    transformer.visit(module)
    assert node.bases == [
        ast.Call(
            func=ast.Name(id='_py_backwards_six_withmetaclass', ctx=ast.Load()),
            args=[
                ast.Name(id='B', ctx=ast.Load()),
                ast.Name(id='dict', ctx=ast.Load()),
            ],
            keywords=[],
        ),
    ]

# Generated at 2022-06-12 03:49:25.521498
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_helpers import call_visit
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 03:49:31.414321
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    from ..utils import compile_source
    from .. import fixer_log

    transformer = MetaclassTransformer(fixer_log, None)

    for text in ('class A(metaclass=B): pass',
                 'class A(foo, bar, metaclass=B): pass'):
        t = compile_source(text, '<test>', 'exec')
        transformer.visit(t)
        assert transformer._tree_changed is True     # pylint: disable=protected-access
        assert transformer.log.getvalue() == ''

# Generated at 2022-06-12 03:49:32.177842
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:49:32.954714
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:49:40.019295
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typing import Generator
    from typed_ast import ast3 as ast
    from .test_pgen2 import test_load_grammar, test_parse_string

    def test_module(s: str) -> Generator[None, None, None]:
        from .transformers.base import BaseNodeTransformer

        grammar = test_load_grammar()
        for stmt in test_parse_string(grammar, s):
            tree = ast.parse(s, '', 'exec')
            transformed_node: ast.AST = stmt.accept(MetaclassTransformer())
            insert_at(0, tree, six_import.get_body())
            insert_at(-1, tree, transformed_node)
            res = compile(tree, '', 'exec')

# Generated at 2022-06-12 03:49:42.561281
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.tst_utils import assert_exact_ast
    expected = ast.parse("class A(_py_backwards_six_with_metaclass(B)): pass")
    actual = MetaclassTransformer().visit(ast.parse("class A(metaclass=B): pass"))
    assert_exact_ast(expected=expected, actual=actual)

# Generated at 2022-06-12 03:49:50.827101
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
  from typed_ast import ast3 as ast
  from ..utils.tree import ast_print
  transformer = class_bases.replace_ctx
  kwargs = {"metaclass":ast.Attribute(value=ast.Name(id="oauthlib", ctx=ast.Load()),
                                        attr="common", ctx=ast.Load()),
            "bases":ast.List(elts=[ast.Name(id="OAuthlibClient", ctx=ast.Load())],
                              ctx=ast.Load())}
  ast_print(class_bases.get_body(**kwargs))
  #class A(metaclass=B):
  #  pass
  #
  #class A(_py_backwards_six_with_metaclass(B))