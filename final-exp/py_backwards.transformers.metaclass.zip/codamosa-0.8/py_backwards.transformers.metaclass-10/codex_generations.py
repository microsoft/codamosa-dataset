

# Generated at 2022-06-12 03:39:52.678589
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-12 03:39:54.470170
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import parse
    from .check_transformation import check_transformation


# Generated at 2022-06-12 03:39:57.856612
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_utils import check_visitor
    from .six import six_import, class_bases
    assert 'six' in MetaclassTransformer.dependencies

# Generated at 2022-06-12 03:40:03.812760
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module
    module: Module
    module = ast.parse('''
    def f():
        pass
    class A(metaclass=B):
        pass
    ''')
    MetaclassTransformer().visit(module)

# Generated at 2022-06-12 03:40:10.118085
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class Codegen(object):
        def __init__(self):
            self.code = ""

        def add_line(self, line):
            if line.startswith("#"):
                self.code += "\n%s\n" % line
            else:
                self.code += "    %s\n" % line

        def indent(self):
            self.code += "    "

        def dedent(self):
            self.code = self.code[:-4]

    codegen = Codegen()

    from typed_ast.ast3 import parse

# Generated at 2022-06-12 03:40:19.061311
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3
    from ..testing.visit import assert_visit

    # No metaclass
    ast1 = ast3.ClassDef(name='A', bases=[ast3.Name(id='B', ctx=ast3.Load())], body=[], keywords=[])
    ast1_ = ast3.ClassDef(name='A', bases=[ast3.Name(id='B', ctx=ast3.Load())], body=[], keywords=[])
    assert_visit(MetaclassTransformer, ast1, ast1_)

    # Metaclass

# Generated at 2022-06-12 03:40:23.241222
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..code_gen import to_source
    source = '''class A(metaclass=B): pass'''  # noqa
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)

# Generated at 2022-06-12 03:40:28.471712
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    c = ast.parse("class Foo(metaclass=Bar): pass")
    c = MetaclassTransformer().visit(c)
    assert c.body[0].name == "Foo"
    assert c.body[0].bases[0].func.id == "_py_backwards_six_withmetaclass"


# Generated at 2022-06-12 03:40:30.975706
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import astunparse
    import sys
    import six

    # Python 3.7 source code

# Generated at 2022-06-12 03:40:40.710272
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .base import compile_function

    def test_compile(src):
        method = compile_function(MetaclassTransformer, src)
        method()

    def test_compile_fail(src):
        with pytest.raises(AttributeError):
            compile_function(MetaclassTransformer, src)

    # Basic
    test_compile('''
        class A(metaclass=B):
            pass
    ''')
    # More than one metaclass
    test_compile_fail('''
        class A(metaclass=B, metaclass=C):
            pass
    ''')
    test_compile_fail('''
        class A(metaclass=B, metaclass=C, foo=bar):
            pass
    ''')
    # More than one

# Generated at 2022-06-12 03:40:44.064860
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclassTransformer = MetaclassTransformer()

# Generated at 2022-06-12 03:40:53.280544
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    tree = ast.parse(code)

    transformer = MetaclassTransformer()
    transformer.visit(tree)

    assert transformer._tree_changed is True
    code_actual = compile(tree, '<test>', 'exec')
    six_import_actual = code_actual.co_consts[0]
    assert six_import_actual.co_code.co_filename == '<test>'
    assert six_import_actual.co_code.co_name == '<module>'

# Generated at 2022-06-12 03:40:59.192702
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse("class A(metaclass=B):\n    pass", mode='exec')
    trans = MetaclassTransformer()
    trans.visit(node)
    exp = ast.parse(dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class A(_py_backwards_six_withmetaclass(B)):
        pass"""), mode='exec')

    assert ast.dump(node) == ast.dump(exp)

# Generated at 2022-06-12 03:41:10.085591
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import compile_snippet
    from ..utils.sanity import generate_equivalent_ast
    from ..utils.source import generate_code

    code = 'class A(metaclass=B): pass'
    root = compile_snippet(code, 'six', 'MetaclassTransformer')
    assert generate_code(root) == ('from six import with_metaclass as _py_backwards_six_withmetaclass\n\n'
                                   'class A(_py_backwards_six_withmetaclass(B, object)):\n'
                                   '    pass\n')
    root = compile_snippet(code, 'six', 'MetaclassTransformer')

# Generated at 2022-06-12 03:41:19.998388
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typing import List
    from ..utils.fake import ast_parse, fake_future_annotations, fake_metaclass
    
    source = six_import + '\n\n' + fake_future_annotations + class_bases + '\n\n' + fake_metaclass
    expected = six_import + '\n\nclass fake_metaclass_A_with_metaclass(_py_backwards_six_withmetaclass(fake_metaclass_B)):\n    pass\n'

    tree = ast_parse(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)

    assert transformer._tree_changed, 'Visit of MetaclassTransformer should change the tree'

# Generated at 2022-06-12 03:41:27.553567
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    def test_func(x):
        class A(metaclass=type):
            pass
    actual = MetaclassTransformer().visit_Module(ast.parse(test_func))
    expected = ast.Module(body=[six_import.get_ast(),
                                ast.ClassDef(name='A',
                                             bases=[class_bases.get_ast()],
                                             body=[],
                                             decorator_list=[],
                                             keywords=[])])
    actual = ast.fix_missing_locations(actual)
    ast.increment_lineno(actual, 1)
    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-12 03:41:36.418725
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.tester import assert_code_equal
    from . import Python2to3TreeBuilder

    builder = Python2to3TreeBuilder()
    node = builder.module([
        builder.classdef('_py_backwards_six_with_metaclass', lambda n: n.body.insert(0, builder.expr_stmt(builder.call('print', ['Hello'])))),
        builder.classdef('A', bases=['_py_backwards_six_with_metaclass'], body=[
            builder.stmt('pass')
        ])
    ])

    tree = MetaclassTransformer().visit(node)

# Generated at 2022-06-12 03:41:39.344277
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = """class A(metaclass=B): pass"""

# Generated at 2022-06-12 03:41:48.612291
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils import test_utils  # type: ignore
    from .base import BaseTestTransformer

    class TestTransformer(BaseTestTransformer):
        transformer = MetaclassTransformer

        def test_one_keyword_in_class(self):
            s = '''
                class A(metaclass=B):
                    pass
            '''
            expect = '''
                from six import with_metaclass as _py_backwards_six_withmetaclass
                class A(_py_backwards_six_withmetaclass(B)):
                    pass
            '''
            node = ast.parse(s)
            new_node = self.transformer(node)
            self.assertTrue(test_utils.compare_ast(expect, new_node))

       

# Generated at 2022-06-12 03:41:54.692651
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from textwrap import dedent
    from ..utils.compiler import compile_function


# Generated at 2022-06-12 03:42:03.366161
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import ClassDef, Name, Module, Load, Tuple, keyword
    transformer = MetaclassTransformer()

# Generated at 2022-06-12 03:42:04.314700
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-12 03:42:10.640990
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import parse, compare_ast

    old_tree = parse("""
        class A(metaclass=B):
            pass
    """)
    new_tree = parse("""
        from six import with_metaclass as _py_backwards_six_withmetaclass


        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)

    transformer = MetaclassTransformer()
    transformer.visit(old_tree)
    compare_ast(old_tree, new_tree, transformer)

# Generated at 2022-06-12 03:42:18.765612
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .utils import make_fixture_with_imports

    code = """
    class S(metaclass=type):
        pass
    """
    code_expected = """
    class S(_py_backwards_six_withmetaclass(type)):
        pass
    """
    tree = ast.parse(code)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    code_actual = compile(tree,  '<string>', 'exec')
    code_actual = make_fixture_with_imports(code_actual)
    assert code_expected == code_actual

# Generated at 2022-06-12 03:42:20.675716
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typing
    from typed_ast import ast3
    from ...utils.source import source


# Generated at 2022-06-12 03:42:26.204436
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.tree import parse, dump, compare_ast
    from ..utils.fake import FakeFile

    example = """class Foo(metaclass=type): pass"""
    node = parse(example)
    ref = parse("""
    class Foo(_py_backwards_six_with_metaclass(type)):
        pass
    """)

    with FakeFile(example, 'six') as f:
        node = MetaclassTransformer().visit(node)
        assert compare_ast(node, ref)

# Generated at 2022-06-12 03:42:27.654928
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.snippet import to_module


# Generated at 2022-06-12 03:42:28.688673
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:33.104592
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_file = "class A(metaclass=B): pass"
    node = ast.parse(test_file)
    expected_node = ast.parse("class A(_py_backwards_six_withmetaclass(B)): pass")
    MetaclassTransformer.transform_to_target(node)
    assert ast.dump(node) == ast.dump(expected_node)

# Generated at 2022-06-12 03:42:33.865357
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:47.704285
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..tools import codegen
    from ..tools.testing import print_ast

    print_ast(codegen.ast_module('''
    class A(metaclass=B):
        pass
    '''))

    print_ast(codegen.ast_module(MetaclassTransformer.transform_code('''
    class A(metaclass=B):
        pass
    ''')))

# Generated at 2022-06-12 03:42:53.692253
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    # `class A(abc.ABC, metaclass=B): pass` -> `class A(_py_backwards_six_with_metaclass(B), abc.ABC): pass`
    cdef = ast.ClassDef(name='A', bases=[ast.Name(id='abc.ABC')], keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B'))])
    tr = MetaclassTransformer()
    tr.visit(cdef)
    assert '_py_backwards_six_with_metaclass(B), abc.ABC' in ast.dump(cdef, include_attributes=False, annotate_fields=False)
    # `class A(metaclass=B): pass` -> `class A(_py_backwards_six_with_metac

# Generated at 2022-06-12 03:42:58.757609
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    ast_tree = ast.parse("""class A(metaclass=42): pass""")

    MetaclassTransformer().visit(ast_tree)
    MetaclassTransformer().visit(ast_tree)  # test to make sure it is idempotent

    gen = ast.get_source_segment(ast_tree)
    assert next(gen) == 'class A(_py_backwards_six_withmetaclass(42))'
    assert next(gen) == '    pass'



# Generated at 2022-06-12 03:43:06.320635
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    with open('test.py', 'rb') as f:
        source = f.read()
    tree = ast.parse(source)

    class MyTransformer(MetaclassTransformer):
        def generic_visit(self, node: ast.AST) -> ast.AST:
            return node

    tree = MyTransformer().visit(tree)

    assert tree.body[0].value.bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert tree.body[0].value.bases[0].args[0].id == 'TraceMeta'

# Generated at 2022-06-12 03:43:14.610680
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class TestClass1(object):
        ''' Comment '''
        pass
    class TestClass2(metaclass=ClassA):
        ''' Comment '''
        pass


# Generated at 2022-06-12 03:43:23.906192
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import assert_equal_source
    from mypy_extensions import DefaultArg

    node = ast.ClassDef(name='A',  # type: ignore
                        bases=[ast.Name(id='B', ctx=ast.Load(), lineno=1, col_offset=7)],  # type: ignore
                        keywords=[ast.keyword(arg='metaclass',  # type: ignore
                                              value=ast.Name(id='C', ctx=ast.Load(), lineno=1, col_offset=15))],  # type: ignore
                        body=[], decorator_list=[], lineno=1, col_offset=0)

# Generated at 2022-06-12 03:43:32.978117
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    import astunparse
    transformer = MetaclassTransformer(target_major=3, target_minor=6)

    code = """\
            class A(metaclass=B, c=3):
                pass
            """
    expected = """\
            class A(_py_backwards_six_withmetaclass(B, *[], **{'c': 3})):
                pass
            """

    tree = ast.parse(code)
    new_tree = transformer.visit(tree)
    result = astunparse.unparse(new_tree)

    assert expected == result


# Generated at 2022-06-12 03:43:35.506671
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import ClassDef

    class Dummy:
        pass


# Generated at 2022-06-12 03:43:42.991336
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """ Test visit_ClassDef of class MetaclassTransformer"""
    from typed_ast import ast3 as ast
    from ..utils.compile import compile_object

    module = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    t = MetaclassTransformer()
    t.visit_Module(module)
    code = compile_object(module)
    assert code == "from six import with_metaclass as _py_backwards_six_withmetaclass\n" \
                    "class A(_py_backwards_six_withmetaclass(B)):\n" \
                    "    pass"



# Generated at 2022-06-12 03:43:48.890534
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = astor.parse_file(__file__)
    MetaclassTransformer(tree).run()

# Generated at 2022-06-12 03:44:15.941453
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.example import example
    from ..utils.ast_builder import ast_from_code, build_ast

    source_code = example("""
    class A(metaclass=B):
        pass
    """)

    with_metaclass, six_import = build_ast([
        ('six_import', six_import.get_source()),
        ('with_metaclass', class_bases.get_source())
    ])

    expected_source = example("""
    six_import

    with_metaclass(B)
    """)


# Generated at 2022-06-12 03:44:20.379951
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class Test(unittest.TestCase):
        def test_method_is_callable(self):
            try:
                MetaclassTransformer.visit_ClassDef(x=None, y=None)
            except TypeError:
                pytest.fail("Method 'visit_ClassDef' of class "
                            "'MetaclassTransformer' needs more arguments")
    
    unittest.main(module=__name__, verbosity=2)

# Generated at 2022-06-12 03:44:29.613674
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    import ast
    import textwrap
    from ..utils.ast_helper import ast_contains_node_type, copy_location
    from ..utils.tree import insert_at
    from .metaclass import MetaclassTransformer

    metaclass = ast.Name(id='type')
    bases = [ast.Name(id='C'), ast.Name(id='D')]
    bases = ast.List(elts=bases)
    keywords = [ast.keyword('metaclass', metaclass)]
    class_node = ast.ClassDef(name='A',
                              bases=bases,
                              keywords=keywords,
                              body=[],
                              decorator_list=None)


# Generated at 2022-06-12 03:44:31.336220
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import assert_transformation


# Generated at 2022-06-12 03:44:40.731200
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse("""
    class A(object, metaclass=B):
        pass
    """).body[0]

    six_import()
    with_metaclass = class_bases.get_body(metaclass=ast.Name(id='B', ctx=ast.Load()),
                                          bases=ast.List(elts=[ast.Name(id='object', ctx=ast.Load()), ast.Name(id='object', ctx=ast.Load())]))[0]

    transformer = MetaclassTransformer()
    transformed = transformer.visit(node)

    assert '_py_backwards_six_withmetaclass' in str(transformed)

    import six
    import sys

# Generated at 2022-06-12 03:44:47.641568
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six
    from typed_ast.ast3 import parse
    source = """class A(metaclass=B): pass"""

    expected = """class A(_py_backwards_six_withmetaclass(B)): pass"""
    expected_six = """from six import with_metaclass as _py_backwards_six_withmetaclass"""

    tree = parse(source)
    tree = MetaclassTransformer().visit(tree)
    assert six.PY2
    assert expected == astunparse.unparse(tree).strip()
    assert expected_six == astunparse.unparse(tree.body[0]).strip()

# Generated at 2022-06-12 03:44:52.017845
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

    code = 'class A(metaclass=B): pass'
    expected = 'class A(_py_backwards_six_withmetaclass(B)): pass'

    module = ast.parse(code)
    module = MetaclassTransformer(module).visit(module)
    code = astor.to_source(module)

    assert code == expected

# Generated at 2022-06-12 03:44:57.733524
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap
    source = textwrap.dedent("""\
        class A(B, metaclass=C):
            pass
    """)

    expected = textwrap.dedent("""\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        
        class A(_py_backwards_six_withmetaclass(C, B)):
            pass
    """)

    assert str(MetaclassTransformer().visit(ast.parse(source))) == expected


# Generated at 2022-06-12 03:45:00.663575
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse('class A(metaclass=B): pass')  # type: ignore
    transformer = MetaclassTransformer()
    transformer.visit(module)
    assert '_py_backwards_six_with_metaclass(B)' in text_type(module)

# Generated at 2022-06-12 03:45:09.100898
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import unittest

    from typed_ast.ast3 import parse

    class TestMetaclassTransformer_visit_ClassDef(unittest.TestCase):
        def test_simple(self):
            transformer = MetaclassTransformer()
            sample_code = parse("class A(metaclass=B):\n    pass")
            expected_code = parse("from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass")
            transformer.visit(sample_code)
            self.assertEqual(sample_code, expected_code)
   
    unittest.main()

# Generated at 2022-06-12 03:45:27.107358
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source

    source = source(MetaclassTransformer)
    assert ('_py_backwards_six_withmetaclass' in source) is True


# Generated at 2022-06-12 03:45:27.732997
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:45:29.485518
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typing
    if typing.TYPE_CHECKING:
        from ..testing.utils import TreeAssertions
    from ..validation import ValidationContext


# Generated at 2022-06-12 03:45:39.230077
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast.ast3 import parse
    from .six import SixTransformer
    from .metaclass import MetaclassTransformer
    from .with_statement import WithTransformer
    from ..utils.tree import ast_to_program
    from .no_paren_call_transformer import NoParenCallTransformer

    code = """
        class A(object):
            pass
        
        class B(object, metaclass=type):
            pass
        
        class C(metaclass=type):
            pass
        
        class D(object, metaclass=type):
            pass
        """
    tree = parse(code)
    transformers = [WithTransformer, NoParenCallTransformer, SixTransformer, MetaclassTransformer]
    result = ast_to_program(tree, [])

# Generated at 2022-06-12 03:45:48.091061
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast.ast3 import parse
    from ..utils.ast_pattern import pattern_match as match
    from ..utils.expr import Expr

    # Basic

    code = """
        class A(B):
            pass
        """
    node = parse(code, mode='exec')
    assert not match(node, """classdef <id(id)>(): pass""")
    mt = MetaclassTransformer()
    mt.generic_visit(node)
    assert match(node, """classdef <id(id)>: pass""", compat=True)

    # With metaclass

    node = parse(code, mode='exec')
    code = """
        class A(metaclass=B):
            pass
        """
    node = parse(code, mode='exec')

# Generated at 2022-06-12 03:45:55.574691
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert '_py_backwards_six_withmetaclass' not in six_import.get_body()
    source = """
    class A(metaclass=B):
        pass
    """
    tree = ast.parse(source)
    result = MetaclassTransformer().visit(tree)
    assert snippet().get_source() == source
    assert snippet(result).get_source() == """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    assert '_py_backwards_six_withmetaclass' in snippet(result).get_body()

# Generated at 2022-06-12 03:45:57.385228
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer(None)
    assert transformer.target == (2, 7)
    assert transformer.dependencies == ['six']

# Generated at 2022-06-12 03:46:01.887837
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
        class A(metaclass=B):
            pass
    """
    tree = ast.parse(code)
    transformer = MetaclassTransformer(tree)
    transformer.visit(tree)
    assert transformer.changed == True
    new_code = compile(tree, '', 'exec')
    assert '_py_backwards_six_with_metaclass(B)' in new_code

# Generated at 2022-06-12 03:46:08.277322
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    six_import.get_body()  # ensure the snippet is ready
    classdef = ast.parse('class A(metaclass=B):\n    pass')
    newclassdef = MetaclassTransformer().visit_ClassDef(classdef.body[0])
    newmodule = ast.Module(body=[newclassdef])
    assert astor.to_source(classdef) == astor.to_source(newmodule)



# Generated at 2022-06-12 03:46:10.229632
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    mtt = MetaclassTransformer(2.7, 'six')

# Generated at 2022-06-12 03:46:50.338071
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Test with no keywords
    node = ast.ClassDef(name="TestClass",
                        bases=[ast.Name("object", ast.Load())],
                        keywords=[],
                        body=[ast.Pass()],
                        decorator_list=[],
                        lineno=1,
                        col_offset=0)

    d = MetaclassTransformer()
    assert ast.dump(d.visit(node)) == ast.dump(node)
    assert not d.tree_changed

    # Test with keyword

# Generated at 2022-06-12 03:46:55.862863
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..parser import Parser
    from ..utils.source import source
    from ..utils.compiler import compile_snippet

    parser = Parser()
    transformer = MetaclassTransformer(parser)
    snippet_ = snippet(source_=source("""
    class Foo(metaclass=Bar):
        pass
    """))
    snippet_.visit(transformer)

    compile_snippet(snippet_.root)

# Generated at 2022-06-12 03:47:01.110552
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """It should add an import statement"""
    # Given
    node = ast.parse('class A(metaclass=B): pass')
    transformer = MetaclassTransformer()

    # When
    transformer.visit(node)

    # Then
    assert transformer._tree_changed
    assert ast.dump(node) == "from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(metaclass=B):\n    pass"



# Generated at 2022-06-12 03:47:02.573456
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.ast import parse
    from ..utils.asserts import assert_equal


# Generated at 2022-06-12 03:47:04.330261
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
  code = '''class MyClass(object):
    pass
'''

# Generated at 2022-06-12 03:47:13.903417
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    snippet_six_import = six_import.get_body()
    snippet_six_import_expected = \
        "from six import with_metaclass as _py_backwards_six_withmetaclass\n"
    snippet_six_import_expected = snippet_six_import_expected+"\n"
    snippet_six_import_expected = ast.parse(snippet_six_import_expected)
    snippet_six_import_expected = snippet_six_import_expected.body[0]

    snippet_class_bases = class_bases.get_body(metaclass=ast.Name(id='B'),
                                               bases=ast.List(elts=[ast.Name(id='A')]))

# Generated at 2022-06-12 03:47:22.741609
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from six import assertCountEqual
    from ...utils import dump_ast

    node = ast.Module(body=[
        ast.ClassDef(name="TestClass",
                     bases=[],
                     keywords=[],
                     body=[
                         ast.Pass()
                     ])
    ])


# Generated at 2022-06-12 03:47:25.653829
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("""
        class A(metaclass=B):
            pass
        """)
    tree = MetaclassTransformer().visit(node)
    assert six_import.get_source() in ast.dump(tree)



# Generated at 2022-06-12 03:47:32.997599
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    cls = ast.ClassDef(name="A",
                       bases=[],
                       keywords=[ast.keyword(arg="metaclass", value=ast.Name(id="B", ctx=ast.Load()))],
                       body=[],
                       decorator_list=[])
    module = ast.Module(body=[cls])
    mod = MetaclassTransformer().visit(module)
    assert mod.body[0].value.name == "six"
    assert mod.body[1].value.name == "_py_backwards_six_withmetaclass"
    assert mod.body[2].value.name == "Module"
    assert mod.body[3].value.name == "ClassDef"

# Generated at 2022-06-12 03:47:35.171571
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    input_code = "class A(metaclass=B, *args, **kwargs): pass"

# Generated at 2022-06-12 03:49:02.417104
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    six_import_text = six_import.get_text()
    code_text = """class A(metaclass=B):
    pass"""

# Generated at 2022-06-12 03:49:07.304780
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import transform
    code = '''\
    class A(metaclass=B):
        pass
    '''
    expected = '''\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    assert transform(code, MetaclassTransformer) == expected

# Generated at 2022-06-12 03:49:16.109852
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast.ast3 import Module, ClassDef
    from ast import Name, Store, Attribute, Load, Str, keyword, ClassDef
    from ..utils.testing import assert_ast_eq
    src = """
    class A(metaclass=B):
        pass
    """
    expected = Module(body=[
        ClassDef(name='A', bases=[
            Name(id='_py_backwards_six_with_metaclass', ctx=Load()),
            List(elts=[Name(id='B', ctx=Load())], ctx=Load())],
            keywords=[keyword(arg='metaclass', value=Name(id='B', ctx=Load()))],
            body=[], decorator_list=[])],
        type_ignores=[]
    )

# Generated at 2022-06-12 03:49:17.371766
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.syntax import compile_source


# Generated at 2022-06-12 03:49:25.322616
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    base_class = ast.ClassDef(name='A',
                              bases=[],
                              keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
                              body=[],
                              decorator_list=[])
    MetaclassTransformer().visit(base_class)


# Generated at 2022-06-12 03:49:33.485251
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typing import List, Dict, Union, Optional, Tuple
    from typed_ast import ast3 as ast
    from ..node_util import NodeTransformer
    
    class ProfileNodeTransformer(NodeTransformer):
        def __init__(self):
            self.node_counts = {}
    
        def generic_visit(self, node):
            if type(node) not in self.node_counts:
                self.node_counts[type(node)] = 0
            self.node_counts[type(node)] += 1
            return super().generic_visit(node)
    
    def profile_transform(transformer, program):
        visitor_a = ProfileNodeTransformer()
        visitor_b = transformer()
        visitor_a.visit(visitor_b.visit(program))

# Generated at 2022-06-12 03:49:35.578036
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..bake import bake

    code = "class A(object):\n    pass"
    assert bake(MetaclassTransformer, code) == code



# Generated at 2022-06-12 03:49:41.806129
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .base import BaseTestTransformer

    class TestMetaclassTransformer(BaseTestTransformer):
        transformer = MetaclassTransformer


# Generated at 2022-06-12 03:49:45.721419
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .builtins_transformer import BuiltinsTransformer
    from .relative_import_transformer import RelativeImportTransformer
    from ..parser import Parser
    from ..utils.source import Source
    # Build IRC

# Generated at 2022-06-12 03:49:46.848901
# Unit test for method visit_ClassDef of class MetaclassTransformer