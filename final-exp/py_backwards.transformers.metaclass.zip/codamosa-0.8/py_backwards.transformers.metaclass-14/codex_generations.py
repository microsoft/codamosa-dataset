

# Generated at 2022-06-12 03:40:00.280458
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    # import code
    # import sys
    # sys.modules[__name__].__dict__.update(locals())

    node = ast.parse('class A(metaclass=B): pass ')
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert astor.to_source(node) == 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass\n'
    # code.interact(local={**locals(), **globals()})

# Generated at 2022-06-12 03:40:05.043296
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    mod = ast.parse(dedent(
        """
        class A(metaclass=B):
            pass
        """
    ))
    mctor = MetaclassTransformer()
    mctor.visit(mod)
    code = compile(mod, "<string>", "exec")
    ns = {}
    exec(code, ns)
    assert "B" in ns
    assert ns["A"]

# Generated at 2022-06-12 03:40:06.064274
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:40:12.278415
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    import ast
    import unittest
    from ast_tools import ast_pprint
    from py_backwards.transformers import MetaclassTransformer

    class MetaclassTransformerTestCase(unittest.TestCase):
        def _test(self, before, expected):
            transformer = MetaclassTransformer()
            node = ast.parse(before)
            node = transformer.visit(node)
            if transformer._tree_changed:
                self.assertEqual(ast_pprint(node), expected)
            else:
                self.assertEqual(before, expected)
                self.assertIsNone(node)


# Generated at 2022-06-12 03:40:20.580143
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 03:40:30.713100
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ast import parse as ast_parse
    from ..utils.ast_factory import ast_call
    from ..utils.tree import get_body
    from .transformer_test import TransformerTest

    t = TransformerTest(
        transformer_cls=MetaclassTransformer,
        input_src='''
        class A(metaclass=B):
            pass
        ''',
        expected_src='''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B,object)):
            pass
        '''
    )
    t.test()


# Generated at 2022-06-12 03:40:40.335377
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_utils import load_and_parse

    class_with_metaclass = load_and_parse(
        """class A(metaclass=B):  #@
            pass
        """)
    class_without_metaclass = load_and_parse(
        """class A(B):  #@
            pass
        """)

    # Tests if the metaclass is removed
    class_with_metaclass = MetaclassTransformer().visit(class_with_metaclass)
    assert len(class_with_metaclass.body[0].keywords) == 0
    assert type(class_with_metaclass.body[0].bases[0]) == ast.Call

# Generated at 2022-06-12 03:40:47.482528
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    class TestTransformer(MetaclassTransformer):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.output = None

        def generic_visit(self, node: ast.AST) -> ast.AST:
            self.output = node
            return node

    class NodeAssertions:
        def assertHasBases(self, bases: list):
            for base in bases:
                assert base in self.output.bases
            
            assert len(bases) == len(self.output.bases)

        def assertHasNoKeywords(self):
            assert not self.output.keywords

        def assertHasNoArgs(self):
            if hasattr(self.output, 'args'):
                assert not self.output.args

# Generated at 2022-06-12 03:40:56.113983
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from typed_ast import ast3 as ast

    # Test when there are no keywords
    classdef = ast.ClassDef(name="foo",
                            bases=[ast.Name(id="bar")],
                            keywords=[],
                            body=[])
    mct = MetaclassTransformer()
    classdef2 = mct.visit_ClassDef(classdef)
    expected = 'class foo(_py_backwards_six_withmetaclass(None, bar))\n'
    assert astor.to_source(classdef2).strip() == expected.strip()
    assert mct._tree_changed is True

    # Reset the tree_changed flag
    mct._tree_changed = False

    # Test when there are keywords

# Generated at 2022-06-12 03:41:06.972257
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3
    import sys
    t = MetaclassTransformer(sys.version_info)

    # Class has no bases, should do nothing
    ast_node = ast3.parse("""class A: pass""").body[0]
    assert t.visit(ast_node) == ast_node

    # Class has no metaclass
    ast_node = ast3.parse("""class A(B, C, metaclass=D, **args): pass""").body[0]
    assert t.visit(ast_node) == ast3.parse("""class A(_py_backwards_six_withmetaclass(D, B, C), **args): pass""").body[0]

    # Class has no bases and metaclass

# Generated at 2022-06-12 03:41:10.039422
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:41:17.230386
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import run_transformer_on_single_file

    # Arrange
    sample_code = """class Test(metaclass=TypeVar('Test')):
    pass"""
    expected_output = """class Test(_py_backwards_six_withmetaclass(TypeVar('Test'))):
    pass"""
    transformer = MetaclassTransformer()

    # Act - Assert
    run_transformer_on_single_file(transformer,
                                   sample_code,
                                   expected_output)


# Generated at 2022-06-12 03:41:22.734599
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six
    import sys
    code = """
    class A(object, metaclass=B):
        pass
    """

    t = MetaclassTransformer(target=tuple(sys.version_info[:2]))
    tree = ast.parse(code)
    tree = t.visit(tree)
    assert t._tree_changed
    assert '\n' + code in repr(tree)
    assert repr(tree).index(six.text_type) >= 0


if __name__ == '__main__':
    test_MetaclassTransformer_visit_ClassDef()

# Generated at 2022-06-12 03:41:24.746912
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.ten import get_ast as _get_ast
    from asttokens import ASTTokens

# Generated at 2022-06-12 03:41:26.481942
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import parse
    from .utils import round_trip, my_ast_dump

# Generated at 2022-06-12 03:41:33.711256
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    from typed_ast import ast3 as ast
    from .utils import roundtrip, setUp

    tree = setUp(
        """
        class MyMeta(type):
            pass
        class MyClass(metaclass=MyMeta):
            pass
        """
    )

    assert roundtrip(tree) == """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class MyMeta(type):
        pass
    class MyClass(_py_backwards_six_withmetaclass(MyMeta)):
        pass
    """

# Generated at 2022-06-12 03:41:35.042657
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Test visit_ClassDef method of class MetaclassTransformer."""
    # FIXME: No tests yet
    pass

# Generated at 2022-06-12 03:41:39.696481
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    mt = MetaclassTransformer(target_versions=[(2, 7)])
    tree = ast.parse("class Foo(Bar, metaclass=baz): pass")
    mt.visit(tree)
    tree = ast.parse("class Foo(Bar, Baz, metaclass=baz): pass")
    mt.visit(tree)


# Generated at 2022-06-12 03:41:47.543712
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    A = ast.Name(id='A', ctx=ast.Load())
    metaclass = ast.Name(id='metaclass', ctx=ast.Load())
    node = ast.ClassDef(name='A', bases=[metaclass], keywords=[ast.keyword(arg='metaclass', value=metaclass)])
    class_bases_body = class_bases.get_body(metaclass=metaclass, bases=ast.List(elts=[A]))
    assert MetaclassTransformer().visit_ClassDef(node) == ast.ClassDef(name='A', bases=class_bases_body)


# Generated at 2022-06-12 03:41:56.693726
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.fixtures import function_with_metaclass
    from ..utils.source import source_to_code
    from ..utils.visitor import copy_tree
    import ast
    import six

    # Given
    source = function_with_metaclass.dedent()
    tree = ast.parse(source)
    transformer = MetaclassTransformer()

    # When
    transformer.visit(tree)
    code = source_to_code(tree)

    # Then
    assert transformer._tree_changed is True
    assert code.count('six.with_metaclass') == 2

    # When
    six_with_metaclass = six.with_metaclass
    tree = copy_tree(tree)
    transformer.visit(tree)
    code = source_to_code(tree)

    # Then

# Generated at 2022-06-12 03:42:08.422020
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    import ast
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer

    class SourceToDest(BaseNodeTransformer):
        def visit_ClassDef(self, node): return node

    class DummyMeta(type): pass

    class DummyBases(object): pass

    # With meta class
    src = ast.parse('class A(metaclass=DummyMeta, object): pass', mode='exec')
    dest = ast.parse('class A(DummyMeta, object): pass', mode='exec')
    transformer = MetaclassTransformer(src, target=sys.version_info)
    transformer.visit(src)
    assert SourceToDest().visit(src) == dest

    # With bases

# Generated at 2022-06-12 03:42:11.598723
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast.parse("""
        class A(metaclass=B):
            pass
    """)
    transformer = MetaclassTransformer(tree)
    print(ast.dump(transformer.result))



# Generated at 2022-06-12 03:42:20.613299
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import inspect

    # Arrange
    node = ast.parse("class A(metaclass=B):\n    def __init__(self):\n        pass")
    transformer = MetaclassTransformer()

    # Act
    result = transformer.visit(node)

    # Assert
    assert result == ast.parse("\n".join([
        "from six import with_metaclass as _py_backwards_six_withmetaclass",
        "class A(_py_backwards_six_withmetaclass(metaclass=B, *[])):",
        "    def __init__(self):",
        "        pass"
    ]))

    assert transformer._tree_changed


# Generated at 2022-06-12 03:42:28.698660
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tests import assert_source

    class_def = ast.ClassDef(
        name='A',
        bases=[
            ast.Name(id='B', ctx=ast.Load())
        ],
        keywords=[
            ast.arg(arg='metaclass', value=ast.Name(id='C', ctx=ast.Load()))
        ],
        body=[
            ast.Pass()
        ],
        decorator_list=[]
    )

# Generated at 2022-06-12 03:42:38.101798
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typing
    import textwrap
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast_tree
    from ..compilers.py27 import Py27Compiler

    code = textwrap.dedent('''
        class A(metaclass=B):
            pass
    ''')

    tree = build_ast_tree(code, __name__)
    tree = Py27Compiler(tree).node
    tree = MetaclassTransformer(tree).node

    # Check that there is only one ClassDef
    assert isinstance(tree.body[1], ast.ClassDef)

    # Check that the ClassDef has bases set to a call to the 6.withmetaclass
    assert isinstance(tree.body[1].bases[0], ast.Call)

    # Check that it has the

# Generated at 2022-06-12 03:42:45.704287
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from typed_ast import ast3 as ast

    # Build AST
    bases = ast.List(elts=[], ctx=ast.Load())
    keywords = [ast.keyword(arg='metaclass',
                            value=ast.Name(id='B', ctx=ast.Load())),]
    node = ast.ClassDef(name='A',
                        bases=bases,
                        keywords=keywords,
                        body=[],
                        decorator_list=[])

    # Test

# Generated at 2022-06-12 03:42:52.903105
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six
    import unittest

    from typed_ast import ast3 as ast

    from typed_astunparse import unparse
    from ..compat import python_version
    from ..mutations import MutatingVisitor
    from ..utils.codegen import generate
    from ..utils import tree, snippets

    class TestMetaclassTransformer(unittest.TestCase):
        target = (2, 7)
        expected_local_import = {
            'six': six,
        }

        def test_function(self):
            source = u'six_import()'
            tree = ast.parse(source)
            self.assertEqual(tree.body[0].type, 'Expr')
            meta = MetaclassTransformer()
            node = meta.visit(tree)

# Generated at 2022-06-12 03:42:59.669131
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import assert_transform, assert_transform_first_only
    assert_transform(MetaclassTransformer, """
        class Klass(object):
            pass
    """, """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class Klass(_py_backwards_six_withmetaclass(object)):
            pass
    """)
    assert_transform(MetaclassTransformer, """
        class Klass(a, metaclass=b):
            pass
    """, """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class Klass(_py_backwards_six_withmetaclass(b, a)):
            pass
    """)

# Generated at 2022-06-12 03:43:01.328753
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:43:02.672248
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    t = MetaclassTransformer()

# Generated at 2022-06-12 03:43:15.264380
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compiler import compile
    node = source.get_ast(source="""
    class A(meta_class=B):
        pass
    """)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    module = compile(node=node)
    from six import with_metaclass  # type: ignore
    cls = module.A
    assert cls.__class__ == with_metaclass(B)

# Generated at 2022-06-12 03:43:21.133381
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import parse

    module = parse(
        """
        class A(metaclass=B):
            pass
        """
    )

    result = MetaclassTransformer.run(module)
    assert result == parse(
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    )


# Generated at 2022-06-12 03:43:27.791141
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    sys.path.append('../../')
    import main
    from typed_ast import ast3 as ast
    from typed_ast import ast27 as ast27
    from typed_ast import codegen
    from unittest.mock import Mock

    # Test case 1
    # ===========
    source = """
        from six import with_metaclass
        
        class A(metaclass=B):
            pass
    """
    code = compile(source, '<string>', 'exec',
                   flags=ast.PyCF_ONLY_AST,
                   dont_inherit=True)
    module = ast.parse(source)
    # print('source:', source)
    # print('code:', code)
    # print('module:', ast.dump(module))
    
    transformer = Metac

# Generated at 2022-06-12 03:43:29.124946
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Test case for method visit_ClassDef of class MetaclassTransformer"""
    pass

# Generated at 2022-06-12 03:43:38.083757
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.mock_target import MockTarget

    class Foo(object):
        def __init__(self, a, b, c, d):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    target = MockTarget()
    transformer = MetaclassTransformer(target=target)
    node = ast.parse('class Foo(metaclass=typing.TypeVar(str, int), int, str, metaclass=typing.TypeVar(str, int)): pass')
    result = transformer.visit(node)
    print('Before:\n', ast.dump(node))
    print('After:\n', ast.dump(result))

# Generated at 2022-06-12 03:43:47.424831
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...utils.testing import assert_ast, assert_source
    from .base import BaseNodeTransformer
    from .function_signature import FunctionSignatureTransformer
    from .function_returns import FunctionReturnsTransformer

    m = MetaclassTransformer()
    f = FunctionSignatureTransformer()
    r = FunctionReturnsTransformer()

    class_def = ast.ClassDef(name='Foo', bases=[], keywords=[
        ast.keyword(arg='metaclass', value=ast.Name(id='Bar', ctx=ast.Load()))
    ], body=[ast.Expr(value=ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[]))], decorator_list=[])

    # With metaclass:

# Generated at 2022-06-12 03:43:55.277145
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .base import BaseTestTransformer, nodes_equal

    class Test(BaseTestTransformer):
        Transformer = MetaclassTransformer

        def _internal_test(self, code_before, code_after):
            self.assertTrue(nodes_equal(code_after, super()._internal_test(code_before, code_after)))

    Test.test(unittest_prefix="test_MetaclassTransformer_visit_ClassDef",
              unittest_suffix="")


if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-12 03:44:01.239638
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast as pyast
    from ast_tools.sugar import ast_print
    from ast_tools.sugar import Name as Name
    from ast_tools.sugar import Num as Num
    node = pyast.parse('''
    class A(metaclass=B):
        pass
    ''')
    node = MetaclassTransformer().visit(node)

# Generated at 2022-06-12 03:44:10.523741
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_tree
    from .statement_insertion import StatementInsertionTransformer
    import itertools
    import ast

    # build AST
    class_defs = itertools.product( ('M1',), ('Base1', 'Base2'), ('S1', 'S2'), ('M2',) )
    classes = ['class {name}({bases}):\n    {super}    class {metaclass}:\n        pass\n'.format(name=name, bases=bases, super=super, metaclass=metaclass)
               for name, bases, super, metaclass in class_defs]
    classes = '\n'.join(classes)

    source = """{classes}""".format(classes=classes)
    node = source_to_tree(source)
    node

# Generated at 2022-06-12 03:44:17.150279
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Setup
    node = ast.parse('class A(metaclass=B, xy=z):\n    pass\n')
    node = node.body[0]

    expected_output = ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B, *[])):\n    pass\n').body[0]

    # Run
    transformer = MetaclassTransformer()
    actual_output = transformer.visit(node)

    # Compare
    assert ast.dump(expected_output) == ast.dump(actual_output)

# Generated at 2022-06-12 03:44:43.460537
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from astor.code_gen import to_source, unparse
    from typing import List

    class TestBackportMetaclassTransformer(MetaclassTransformer):
        def __init__(self):
            self.failed: List[str] = []
            super().__init__()

        def assertion(self, test: ast.Module, expected: ast.Module):
            if not test == expected:
                self.failed.append(unparse(test))
                self.failed.append(unparse(expected))

        def _do_assert(self, test_input: str, expected: str):
            test = ast.parse(test_input)
            expected = ast.parse(expected)
            self.visit(test)
            self.assertion(test, expected)

    t = TestBackportMetaclassTrans

# Generated at 2022-06-12 03:44:45.609620
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    for python_version in (2, 7):
        for t in tests_MetaclassTransformer_visit_ClassDef(python_version):
            yield t


# Generated at 2022-06-12 03:44:54.369310
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Success case
    node = ast.parse("""
        class A(object, metaclass=B):
            pass""")
    # node.body[0] is a class definition
    trans = MetaclassTransformer()
    res = trans.visit(node.body[0])
    assert res.bases == [
        ast.Call(
            func=ast.Name(id='_py_backwards_six_withmetaclass', ctx=ast.Load()),
            args=[ast.Name(id='B', ctx=ast.Load())],
            keywords=[],
            starargs=None,
            kwargs=None
        )
    ]
    assert res.keywords == []

    # Failure cases
    # Test that we correctly ignore non meta class

# Generated at 2022-06-12 03:44:56.562852
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3 as ast
    from ..converter import convert
    from running_coderunner import code_runner


# Generated at 2022-06-12 03:44:59.504672
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast3.parse("""
    class Named(metaclass=abc.ABCMeta):
        name = 'test'
    """)
    node = tree.body[0]

    ref = ast3.parse("""
    class Named(_py_backwards_six_withmetaclass(abc.ABCMeta)):
        name = 'test'
    """)

    assert node == MetaclassTransformer().visit(tree) == ref

# Generated at 2022-06-12 03:45:08.449819
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
        class A(metaclass=B):
            pass
        """
    ast_module = ast.parse(code)
    mt = MetaclassTransformer()
    mt.visit(ast_module)

# Generated at 2022-06-12 03:45:17.416300
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    from ..utils.tree import parse_tree, build_tree


# Generated at 2022-06-12 03:45:18.162289
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:45:21.986879
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse('class A(metaclass=type): pass')
    node = MetaclassTransformer().visit(node)
    assert node.body[0].bases[0].args[0].arg == 'type'
    assert len(node.body[0].bases[0].args[0].keywords) == 0



# Generated at 2022-06-12 03:45:29.843864
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast27 as ast
    from .test_BaseNodeTransformer import BaseNodeTransformerTest
    from .test_utils import build_visitor_test

    # Original tree
    node = ast.ClassDef(
        name='A',
        bases=[],
        keywords=[
            ast.keyword(
                arg='metaclass',
                value=ast.Name(
                    id='B',
                    ctx=ast.Load()
                )
            )
        ],
        body=[],
        decorator_list=[]
    )

    # Expected tree

# Generated at 2022-06-12 03:46:15.942704
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()
    node = ast.parse("""class X(metaclass=Foo): pass""")
    transformer.visit(node)
    assert ast.dump(node) == (
        "Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass' "
        "as name)], level=0), Expr(value=ClassDef(name='X', bases=[Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), args=[Name(id='Foo', ctx=Load())], keywords=[])], body=[], decorator_list=[]))])"
    )



# Generated at 2022-06-12 03:46:16.772014
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-12 03:46:24.831827
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def = ast.ClassDef(
        name='A',
        bases=[],
        keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B'))],
        body=[],
        decorator_list=[],
    )
    class_def_expected = ast.ClassDef(
        name='A',
        bases=class_bases.get_body(metaclass=ast.Name(id='B'), bases=ast.List(elts=[])),
        keywords=[],
        body=[],
        decorator_list=[],
    )
    transformer = MetaclassTransformer()
    assert transformer.visit(class_def) == class_def_expected

# Generated at 2022-06-12 03:46:32.189885
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import typing
    from ..utils.location import Location
    from ..utils.tree import tree_to_str

    source = '''
        class B(metaclass=A):
            pass
    '''
    expected = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
 
        class B(_py_backwards_six_withmetaclass(A))
            pass
    '''
    node = ast.parse(source)
    t = MetaclassTransformer(Location(filename='<string>'), node, source)
    t.run()
    assert tree_to_str(node) == expected  # type: ignore

# Generated at 2022-06-12 03:46:32.754169
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:46:34.120687
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()

# Generated at 2022-06-12 03:46:42.765857
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import compile_snippet, strip_tree
    from ..utils.test_utils import assert_ast
    from ..utils.test_utils import run_in_context

    with run_in_context(__file__):
        snippet = compile_snippet('''
        class A(metaclass=B):
            pass
        ''')
    expected = six_import.get_body() + class_bases.get_body(bases=snippet.body[0].bases, metaclass=snippet.body[0].keywords[0].value)

    result = MetaclassTransformer().visit_ClassDef(snippet.body[0])

    assert_ast(expected, strip_tree(result.bases))
    assert len(result.keywords) == 0


# Generated at 2022-06-12 03:46:51.717508
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from six import PY3
    from compiler import compile

    test_sources = (
        '''
            class A(B, C):
                pass
        ''',
        '''
            class A(B, C, metaclass=D):
                pass
        ''',
        '''
            class A(B, C, metaclass=D, **F):
                pass
        ''',
        '''
            class A(B, C, **F):
                pass
        ''',
        '''
            class A(metaclass=D):
                pass
        ''',
    )

    for test_source in test_sources:
        tree = ast.parse(test_source)
        transformer = MetaclassTransformer()
        tree = transformer.visit(tree)

# Generated at 2022-06-12 03:47:00.490269
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # test_visit_ClassDef_simple
    code = """\
        class Foo(metaclass=type):
            pass
        """
    global_namespace = {}
    exec(MetaclassTransformer(target=(2, 7)).visit(ast.parse(code)), global_namespace)
    assert global_namespace['Foo'].__class__ == type

    # test_visit_ClassDef_no_metaclass
    code = """\
        class Foo(BarModule.Bar, quux='baz'):
            pass
        """
    global_namespace = {}
    exec(MetaclassTransformer(target=(2, 7)).visit(ast.parse(code)), global_namespace)
    assert global_namespace['Foo'].__class__ == type

# Generated at 2022-06-12 03:47:01.413973
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:48:44.307008
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class C(metaclass=type):
        pass

# Generated at 2022-06-12 03:48:45.120553
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:48:50.251681
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    code = "class A(metaclass=B):\n    pass\n"
    node = ast.parse(code)
    MetaclassTransformer(node).run()
    converted_code = astor.to_source(node).rstrip()
    expected_code = "from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass"
    assert converted_code == expected_code

# Generated at 2022-06-12 03:48:58.907873
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class TestClass:
        def test_normal(self):
            n = ast.parse("class A(metaclass=B): pass")
            inserted_nodes_number = len(six_import.get_body())
            mt = MetaclassTransformer()
            mt.visit(n)
            assert mt.tree_changed()
            assert len(n.body) == inserted_nodes_number + 1
            assert isinstance(n.body[inserted_nodes_number], ast.ClassDef)
            assert len(n.body[inserted_nodes_number].bases) == 1
            assert isinstance(n.body[inserted_nodes_number].bases[0], ast.Call)

# Generated at 2022-06-12 03:49:00.262923
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()

# Generated at 2022-06-12 03:49:03.933124
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    
    test_import = snippet(six_import)
    test_with_metaclass = snippet(class_bases)
    metaclass_transformer = MetaclassTransformer()


# Generated at 2022-06-12 03:49:09.331134
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import astunparse
    node = ast.ClassDef(name='A',
                        bases=[],
                        keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B'))])
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert astunparse.unparse(node).strip() == ("Base = _py_backwards_six_withmetaclass(B)\nclass A(Base):    pass")


# Generated at 2022-06-12 03:49:10.201431
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astunparse

# Generated at 2022-06-12 03:49:17.336819
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_utils import make_snippet, make_module
    snippet = make_snippet("""
    class A(object): pass
    class B(metaclass=A): pass
    class C(A): pass
    class D(metaclass=C): pass
    class E(metaclass=D): pass
    """)
    module = make_module(snippet)
    transformer = MetaclassTransformer()
    module = transformer.visit(module)
    import typed_astunparse
    astunparse.unparse(module)
    # FIXME: add a unit test

# Generated at 2022-06-12 03:49:23.944881
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.syntax_tree import SyntaxTree
    from ..utils.visitor import Visitor
    with open('data/metaclass_visit_ClassDef_in.py') as f:
        tree = SyntaxTree.build_from_source_code(f.read())
    m = MetaclassTransformer()
    tree = Visitor.visit(m, tree.root)
    with open('data/metaclass_visit_ClassDef_out.py') as f:
        expected = SyntaxTree.build_from_source_code(f.read())
    assert tree == expected