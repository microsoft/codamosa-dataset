

# Generated at 2022-06-12 03:40:01.250053
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils import typed_exec
    from ..utils.fake_six import FakeSixModule
    from ..utils.tree import ast_equal

# Generated at 2022-06-12 03:40:03.409471
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..parser import Parser
    from .transformer import Transformer
    from ..utils import ast_equal


# Generated at 2022-06-12 03:40:08.343018
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import compile_

    source = snippet('''
    class A(metaclass=B):
        pass
    ''')
    
    result = snippet('''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    ''')

    assert compile_(source, '/') == result

# Generated at 2022-06-12 03:40:12.073127
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import typing

    def x(a: '__module__.A', b: '__module__.B') -> None:
        pass

    assert isinstance(x.__annotations__, dict)
    assert isinstance(x.__annotations__['a'], str)


# Generated at 2022-06-12 03:40:16.130822
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse("""
    class A(metaclass=B):
        pass
    """)

    remover = MetaclassTransformer()
    remover.visit(module)

    assert 'class A(_py_backwards_six_withmetaclass(B)):' in ast.dump(module)

# Generated at 2022-06-12 03:40:22.088944
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class TestClassMeta(type):
        def __init__(cls, name, bases, dct):
            super(TestClassMeta, cls).__init__(name, bases, dct)
        def __new__(cls, name, bases, dct):
            return super(TestClassMeta, cls).__new__(cls, name, bases, dct)

    class TestClassOne(object):
        __metaclass__ = TestClassMeta

    module = ast.parse(inspect.getsource(TestClassOne))
    transformer = MetaclassTransformer()
    new_module = transformer.visit(module)
    result = ast.fix_missing_locations(new_module)
    codeobj = compile(result, '<string>', 'exec')
    result = {}
    exec(codeobj, result)

# Generated at 2022-06-12 03:40:31.149867
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import os
    import sys
    this_dir = os.path.dirname(os.path.abspath(__file__))
    to_visit_dir = os.path.join(this_dir, "to_visit_classdef.py")
    sys.path.insert(0, to_visit_dir)
    from to_visit_classdef import *  # noqa

    transformer = MetaclassTransformer()
    transformer.visit(module)

    expected_file = os.path.join(this_dir, "expected_visit_classdef.py")
    expected_module = load_module(expected_file, 'expected_visit_classdef')
    assert module == expected_module

# Generated at 2022-06-12 03:40:38.993603
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import os
    import sys
    import tempfile
    import unittest
    import astor

    from ..utils.tree import ast_repr

    from py_backwards.transformers.six import MetaclassTransformer

    from .test_transformers_base import BaseTestTransformer

    class TestMetaclassTransformer(BaseTestTransformer, unittest.TestCase):
        transformer = MetaclassTransformer

        def test_simple(self):
            src = '''class A(metaclass=type): pass'''

# Generated at 2022-06-12 03:40:46.779773
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    m = ast.parse('class Foo(metaclass=Bar, object): pass')
    node = m.body[0]
    assert isinstance(node, ast.ClassDef)
    assert len(node.keywords) == 1
    assert node.keywords[0].arg == 'metaclass'
    mt = MetaclassTransformer()
    mt.visit(m)
    assert len(node.keywords) == 0
    assert isinstance(node.bases[0], ast.Call)
    assert isinstance(node.bases[0].func, ast.Name)
    assert isinstance(node.bases[0].args[0], ast.Name)
    assert node.bases[0].args[0].id == 'Bar'

# Generated at 2022-06-12 03:40:48.108836
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    visitor = MetaclassTransformer()

# Generated at 2022-06-12 03:40:52.078388
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import run_transformer
    from ..utils.ast_checker import check_tree


# Generated at 2022-06-12 03:41:00.948750
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3 as ast
    from .base import BaseNodeTransformerTest, transform

    class Test(BaseNodeTransformerTest):
        target_transformer = MetaclassTransformer
        target_version = (2, 7)
        transform_source = True
        __test__ = True

        def test_simple(self):
            code = '''
            class C(metaclass=type):
                pass
            '''
            node = ast.parse(code)

            self.check_visitor(node, node, code)
            self.assertEqual(node.body[0].bases[0], ast.Call(func=ast.Name('_py_backwards_six_with_metaclass'),
                                                             args=[ast.Name('type', ast.Load())],
                                                             keywords=[]))

# Generated at 2022-06-12 03:41:08.705342
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from py_backwards.tests.test_utils import assert_equal_source

    src = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """

    tree = ast.parse(src)
    MetaclassTransformer().visit(tree)
    assert_equal_source(tree, expected)

# Generated at 2022-06-12 03:41:16.692089
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse(textwrap.dedent("""
    class A(metaclass=B):
        pass
    """))
    module_expected_result = ast.parse(textwrap.dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """))

    module_transformed = MetaclassTransformer(module).visit(module)

    assert ast.dump(module_expected_result) == ast.dump(module_transformed)

# Generated at 2022-06-12 03:41:22.474494
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = snippet('''
        class Foo(metaclass=Bar):
            pass
    ''')
    tree = ast.parse(source)
    transformer = MetaclassTransformer(tree, {})
    assert 0 == len(transformer.errors)
    transformer.visit(tree)
    transformed = ast.dump(tree)
    expected = snippet('''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class Foo(_py_backwards_six_withmetaclass(Bar, object)):
        pass
    ''')
    assert expected == transformed

# Generated at 2022-06-12 03:41:24.082113
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import parse
    from .utils import check_transformer

# Generated at 2022-06-12 03:41:33.634503
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    class_node = ast.parse('''
        class A(metaclass=B):
            pass
        ''').body[0]

    assert class_node.keywords[0].arg == 'metaclass'
    assert class_node.keywords[0].value.id == 'B'

    transformer = MetaclassTransformer()
    class_node = transformer.visit(class_node)

    assert class_node.bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert len(class_node.bases[0].args) == 2
    assert class_node.bases[0].args[0].id == 'B'
    assert class_node.bases[0].args[1].elts == []

# Generated at 2022-06-12 03:41:42.647345
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Setup the AST
    module = ast.Module()
    body = module.body = [
        ast.ClassDef(name='C',
                     bases=[],
                     keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B'))],
                     body=[],
                     decorator_list=[])
    ]
    # Call the method under test
    transformer = MetaclassTransformer()
    result = transformer.visit_Module(module)
    # Check the result
    assert result.body[0] == ast.ClassDef(name='C',
                                          bases=[],
                                          keywords=[],
                                          body=[],
                                          decorator_list=[])


# Generated at 2022-06-12 03:41:43.861855
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-12 03:41:48.523818
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .test_utils import get_node
    from .test_visitor import TestTransformer

    code = 'class x(metaclass=a.b.c): pass'

    tree = ast.parse(code, mode='exec')
    TestTransformer(MetaclassTransformer).visit(tree)


# Generated at 2022-06-12 03:42:01.894922
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .test_base import BaseNodeTransformerTest
    from .test_base import transform
    from typing import Union, List

    class DummyClass(object):
        def __init__(self, x):
            self.x = x

    class DummyMetaclass(type):
        pass

    class Dummy(object):
        pass

    class TestMetaclassTransformer_visit_ClassDef(BaseNodeTransformerTest):
        target = (2, 7)
        transform = staticmethod(transform)
        transformer = MetaclassTransformer
        _tree_changed = True

# Generated at 2022-06-12 03:42:05.310656
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse('class Foo(metaclass=type): pass')
    node = MetaclassTransformer().visit(node)
    assert pythonize(node) == 'class Foo(_py_backwards_six_withmetaclass(type)):\n    pass'

# Generated at 2022-06-12 03:42:11.767432
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = dedent('''
    class A(metaclass=B):
        pass
    ''')
    output = dedent('''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    ''')
    tree = ast.parse(code)
    assert ast.dump(MetaclassTransformer(tree).visit(tree), extend_line=False) == output



# Generated at 2022-06-12 03:42:17.561543
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse("class A(metaclass=B, c='foo'): pass")
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert transformer._tree_changed is True
    assert transformer._dependencies == set(['six'])
    assert astunparse.unparse(node).strip() == 'class A(_py_backwards_six_withmetaclass(B), c="foo"): pass'

# Generated at 2022-06-12 03:42:26.012879
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import generate_source
    from ..utils.test_utils import compare_source

    source = """
        class A(metaclass=B, c=d):
            pass
        class E(F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z):
            pass
    """
    expected = """
        class A(_py_backwards_six_withmetaclass(B))
        class E(_py_backwards_six_withmetaclass(F))
    """

    module, tree = generate_source(source)
    MetaclassTransformer().visit(tree)
    compare_source(expected, tree)

# Generated at 2022-06-12 03:42:26.946368
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:36.132021
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Compiles:
    #     class A(B, metaclass=C):
    #         pass
    # To:
    #     class A(_py_backwards_six_with_metaclass(C), B):
    #         pass
    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='B', ctx=ast.Load()),
                                    ast.keyword(arg='metaclass',
                                                value=ast.Name(id='C', ctx=ast.Load()))],
                             keywords=[],
                             body=[],
                             decorator_list=[])

# Generated at 2022-06-12 03:42:37.162407
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast


# Generated at 2022-06-12 03:42:46.729624
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast3.parse(
        """class Test(metaclass=m):
                  pass"""
    )
    # Test that everything goes well if the class is defined with a metaclass
    result = MetaclassTransformer().visit(tree)
    assert ast3.dump(result) == "from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass Test(_py_backwards_six_withmetaclass(m)):\n    pass\n"
    # Test that everything goes well if there isn't a metaclass
    tree = ast3.parse(
        """class Test():
                  pass"""
    )
    result = MetaclassTransformer().visit(tree)
    assert ast3.dump(result) == "class Test():\n    pass\n"




# Generated at 2022-06-12 03:42:53.339474
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typing

    class Codegen(object):
        def __init__(self, transformer: typing.Type[MetaclassTransformer]) -> None:
            self.transformer = transformer()

        def __call__(self, code: str) -> ast.AST:
            return self.transformer.visit(ast.parse(code))

    codegen = Codegen(MetaclassTransformer)

    # with metaclass
    assert codegen("""
        class A(metaclass=B):
            pass
    """) == ast.parse("""
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)

    # with bases, single base

# Generated at 2022-06-12 03:43:09.698071
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast, typed_ast.ast3
    class Def(ast.AST):
        _fields = ('name',)
    class Name(ast.AST):
        _fields = ('id',)
    class Str(ast.AST):
        _fields = ('s',)
    class ClassDef(ast.AST):
        _fields = ('name', 'bases', 'keywords', 'decorator_list', 'body', 'lineno', 'col_offset')
    class Keyword(ast.AST):
        _fields = ('arg', 'value')
    class BinOp(ast.AST):
        _fields = ('left', 'op', 'right')
    class Call(ast.AST):
        _fields = ('func', 'args', 'keywords', 'starargs', 'kwargs')
    class Starred(ast.AST):
        _

# Generated at 2022-06-12 03:43:14.009821
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:43:15.040423
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:43:24.298395
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = "class Foo(metaclass=type('Bar', (type,), {})): pass"
    tree = ast.parse(code)

    class Meta(ast.NodeTransformer):
        def visit_Str(self, node: ast.Str) -> ast.Str:
            return ast.Str("'Bar'")

    class Bases(ast.NodeTransformer):
        def visit_Tuple(self, node: ast.Tuple) -> ast.Tuple:
            return ast.Tuple(elts=[ast.Name("type", ast.Load()), ast.Name("type", ast.Load())])

    transformer = MetaclassTransformer()
    result = transformer.visit(Meta().visit(Bases().visit(tree)))

# Generated at 2022-06-12 03:43:35.480508
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...utils.python import python

    @python('2.7')
    def test():
        class A(metaclass=B):
            pass
    result = test()

    assert isinstance(result, ast.Module)

    class_def = result.body[1]
    assert isinstance(class_def, ast.ClassDef)
    assert class_def.name == 'A'

    assert len(class_def.bases) == 1
    call_bases = class_def.bases[0]
    assert isinstance(call_bases, ast.Call)
    assert call_bases.func.id == '_py_backwards_six_withmetaclass'
    assert len(call_bases.args) == 2
    assert call_bases.args[0].id == 'B'

# Generated at 2022-06-12 03:43:39.610273
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3
    node = ast3.ClassDef(name='A', bases=[],
                         keywords=[ast3.keyword(arg='metaclass', value=ast3.Name(id='B'))],
                         body=[], decorator_list=[])
    MetaclassTransformer().visit(node)

# Generated at 2022-06-12 03:43:43.160184
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    t = MetaclassTransformer()
    node = ast.parse("""class A(object): pass""")
    t.visit(node)
    assert str(node) == """class A(_py_backwards_six_withmetaclass(object, )):
    pass"""

# Generated at 2022-06-12 03:43:45.639052
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    _test_MetaclassTransformer_visit_ClassDef(False)
    _test_MetaclassTransformer_visit_ClassDef(True)



# Generated at 2022-06-12 03:43:56.279937
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    def create_sample_tree():
        class_def = ast.ClassDef(name='A', body=[], keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B'))])

        tree = ast.parse(six_import.get_code())
        insert_at(0, tree, class_bases.get_body(metaclass=ast.Name(id='metaclass'), bases=ast.List(elts=[])))
        insert_at(0, tree, class_def)

        return tree

    def get_expected_result():
        return ast.ClassDef(name='A', body=[], bases=ast.List(elts=ast.List(elts=[], ctx=ast.Load())))

    class_def = MetaclassTransformer().visit(create_sample_tree())

# Generated at 2022-06-12 03:44:03.115428
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    t = MetaclassTransformer()
    source = 'class A(metaclass=B, **kw): pass'
    node = ast.parse(source)
    new_node = t.visit(node)
    assert ast.dump(new_node) == "Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0), ClassDef(name='A', bases=[Call(_py_backwards_six_withmetaclass, args=[Name(id='B', ctx=Load()), List(elts=[])], keywords=[])], body=[], decorator_list=[])])"


# Generated at 2022-06-12 03:44:25.330812
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast.parse("""\
    class A(metaclass=B, *a):
        pass""")

    MetaclassTransformer.run_single(tree)


# Generated at 2022-06-12 03:44:31.146486
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Asserts that MetaclassTransformer.visit_ClassDef works properly:
    transformer = MetaclassTransformer()
    class_node = ast.parse("""
    class A(metaclass=B):
        pass
    """).body[0]
    transformer.visit(class_node)
    assert str(class_node.bases[0]) == """_py_backwards_six_withmetaclass(B)"""


# Generated at 2022-06-12 03:44:33.594506
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    '''
    Test MetaclassTransformer.visit_ClassDef method
    '''
    ############################################################################
    # Setup
    import six


# Generated at 2022-06-12 03:44:34.554125
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:44:41.329530
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap
    from ..utils.test_utils import translate
    code = textwrap.dedent('''
        class A(metaclass=B):
            pass
    ''')
    expected = textwrap.dedent('''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

    tree = translate(code, [MetaclassTransformer])
    assert tree == expected



# Generated at 2022-06-12 03:44:50.069383
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    # Setup
    class B:
        pass

    # Test and verify
    node = ast.ClassDef(
        name='A',
        keywords=[],
        bases=[],
        body=[],
        decorator_list=[],
    )
    node = MetaclassTransformer.run(node)
    assert node.__class__.__name__ == 'ClassDef'
    assert node.bases == []

    node = ast.ClassDef(
        name='A',
        keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B'))],
        bases=[],
        body=[],
        decorator_list=[],
    )
    node = MetaclassTransformer.run(node)

# Generated at 2022-06-12 03:44:58.411932
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Create an AST that represents the following code:
    #     class A(metaclass=B):
    #         pass
    #
    # where the value of the metaclass keyword argument is 'B'
    class_def_node = ast.ClassDef(
        name='A',
        bases=[ast.Name(id='B', ctx=ast.Load())],
        keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))]
    )

    # The method visit_ClassDef should make the following transformation:
    #     class A(metaclass=B):
    #         pass
    #     becomes:
    #     class A(_py_backwards_six_with_metaclass(B)):
    #         pass
    #
    # To

# Generated at 2022-06-12 03:45:06.907230
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3

    node = compile('class A(metaclass=B): pass', '<string>', 'exec', ast3.PyCF_ONLY_AST)
    transformer = MetaclassTransformer()
    
    # init_node = node.body[0]
    assert isinstance(node.body[0], ast3.ClassDef)
    class_node = transformer.visit_ClassDef(node.body[0])
    assert isinstance(class_node, ast3.ClassDef)

    # Check the class name
    assert class_node.name == 'A'

    # Check that the metaclass keyword argument has been stripped
    assert not class_node.keywords

    # Check that the metaclass has been replaced by _py_backwards_six_with_metaclass

# Generated at 2022-06-12 03:45:13.761622
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_astunparse
    import textwrap
    sourced = textwrap.dedent('''
        class Foo(metaclass=FooMeta):
            pass
    ''')
    expected = textwrap.dedent('''
        class Foo(_py_backwards_six_withmetaclass(FooMeta)):
            pass
    ''')
    class FooMeta:
        pass
    node = typed_astunparse.ast3.parse(sourced)
    result = MetaclassTransformer().visit(node)
    assert typed_astunparse.unparse(result) == expected



# Generated at 2022-06-12 03:45:15.880435
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-12 03:45:47.229678
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    meta_class_transformer = MetaclassTransformer()
    code = 'class A(object, foo=1, metaclass=A): pass'
    expected_code = 'class A(object, foo=1, _py_backwards_six_withmetaclass(A)): pass'
    result_code = meta_class_transformer.visit_ClassDef(parse_ast(code).body[0]).body[0]
    assert str(result_code) == expected_code



# Generated at 2022-06-12 03:45:56.127887
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import ast
    from .. import parse

    class TypedastAst(ast.Ast):

        def __init__(self):
            import typed_ast.ast3 as ast3
            self.ast3 = ast3
            super().__init__()

        def parse(self, code):
            return parse(code, "__main__", "exec")

        def unparse(self, node, indent="    "):
            import astunparse
            return astunparse.unparse(node)

        def build_class(self, name, bases, body, metaclass=None):
            tpl = """
            class {name}({bases}):
                {body}
            """
            return self.parse(tpl.format(name=name,
                                         bases=bases,
                                         body=body))

    typed_

# Generated at 2022-06-12 03:46:04.639265
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclass = ast.Name(id='B', lineno=2)
    bases = [ast.Name(id='object', lineno=2)]
    class_def_inner = ast.ClassDef(name='A', lineno=1, col_offset=4,
                                   keywords=[ast.keyword(arg='metaclass', value=metaclass, lineno=2, col_offset=14)],
                                   bases=bases, body=[])
    module = ast.Module(body=[class_def_inner])
    class_def_inner = MetaclassTransformer().visit(class_def_inner)
    assert class_def_inner.bases == class_bases.get_body(metaclass=metaclass,
                                                         bases=ast.List(elts=bases))
    assert class_def

# Generated at 2022-06-12 03:46:06.431794
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_generic import code_to_ast


# Generated at 2022-06-12 03:46:08.963776
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Unit test for method visit_ClassDef of class MetaclassTransformer"""
    metaclass_transformer = MetaclassTransformer()

# Generated at 2022-06-12 03:46:16.886962
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    class _MockClassDef(object):
        def __init__(self, bases, keywords):
            self.bases = bases
            self.keywords = keywords

    class _MockName(object):
        def __init__(self, id):
            self.id = id

    class _MockKeyword(object):
        def __init__(self, arg, value):
            self.arg = arg
            self.value = value

    class _MockList(object):
        def __init__(self, elts):
            self.elts = elts

    def _visit_ClassDef(mt, node):
        mt.visit_ClassDef(node)


# Generated at 2022-06-12 03:46:22.514331
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = dedent("""
        class A(metaclass=B):
            pass
    """)
    expected = dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    mt = MetaclassTransformer()
    mt.visit(ast.parse(code))
    assert mt.result() == expected

# Generated at 2022-06-12 03:46:28.278875
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    example = snippet('''
    class A(metaclass=B):
        pass
    ''')
    before, _ = MetaclassTransformer.run_on_single_file(example)
    after = snippet('''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    ''')
    assert before.strip() == after.strip()

# Generated at 2022-06-12 03:46:33.440669
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse(
        """class A(metaclass=type):
                pass""")  # type: ast.Module
    transformer = MetaclassTransformer()
    result = transformer.visit(node)
    expected = ast.parse(
        """class A(_py_backwards_six_withmetaclass(type)):
                pass""")  # type: ast.Module
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-12 03:46:42.332919
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import parse
    from .scrambler import get_scrambled_ast, get_unscrambled_ast

    # This is the simple case where there's a single node in the module
    # with a single keyword
    tree = parse("""
    class A(metaclass=B):
        pass""")

    scramble = get_scrambled_ast(tree)
    unscramble = get_unscrambled_ast(scramble)
    assert tree == unscramble

    # Now let's test with other nodes in the module
    tree = parse("""
    def a():
        pass

    class A(metaclass=B):
        pass

    class B(C):
        pass

    class C(metaclass=F):
        pass""")

    scramble = get_scrambled

# Generated at 2022-06-12 03:47:49.211772
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:47:58.808312
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import parse
    from typed_ast.transforms.metaclass import MetaclassTransformer

    source = textwrap.dedent(
        """
        class A(metaclass=B):
            pass
        class C(X):
            pass
        """
    )

    tree = parse(source)

    transformer = MetaclassTransformer()
    transformer.visit(tree)

    source = textwrap.dedent(
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        class C(X):
            pass
        """
    )

# Generated at 2022-06-12 03:48:02.150592
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast, source_to_node
    from .six import SixTransformer
    six_tr = SixTransformer()
    
    # six module import

# Generated at 2022-06-12 03:48:08.009852
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import generates
    from typed_ast import ast3 as ast

    source = 'class A(metaclass=B): pass'
    actual = generates(source, MetaclassTransformer)
    expected = ast.Module(body=[ast.ImportFrom(module='six', names=[
        ast.alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')],
        level=0)], type_ignores=[])

# Generated at 2022-06-12 03:48:09.611098
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.syntaxtree import SyntaxTree
    from ..utils.visitor import dump


# Generated at 2022-06-12 03:48:13.180849
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    input = """
    class A(object):
        pass
    """
    output = """
    class A(_py_backwards_six_withmetaclass(object)):
        pass
    """
    node = ast.parse(input)
    MetaclassTransformer().visit(node)
    assert astor.to_source(node) == output

# Generated at 2022-06-12 03:48:21.286357
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    ns = {'six': six_import,
          '_py_backwards_six_with_metaclass': class_bases}

    orig = """
        class A(metaclass=B):
            pass
    """
    expected = """
        class A(_py_backwards_six_with_metaclass(B, object)):
            pass
    """
    tree = compile_ast(orig, '<test>', 'exec', pyversion=(2, 7))
    tree = MetaclassTransformer().visit(tree)
    assert ast(expected, ns).body[0] == tree.body[0]

    orig = """
        class A(B, metaclass=C, D):
            pass
    """

# Generated at 2022-06-12 03:48:25.490406
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import unittest
    import astor

    class MetaclassTransformer_visit_ClassDef(unittest.TestCase):

        def test_1(self):
            inp="""class A(metaclass=B): pass"""

            exp="""class A(_py_backwards_six_withmetaclass(B), ):
    pass"""
            node = astor.parse_stme(inp)
            MetaclassTransformer().visit(node)
            self.assertEqual(exp, astor.to_source(node))

    unittest.main()

# Generated at 2022-06-12 03:48:27.593452
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Setup
    class X(object):
        pass

    # Exercise
    class A(X):
        class Meta:
            pass

    # Verify
    assert A.__class__ == X

# Generated at 2022-06-12 03:48:33.030309
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import run_transformer
    input_code = """
    class A(metaclass=B):
        pass
    """
    expected_code = """
    from six import with_methaclass as _py_backwards_six_with_metaclass
    class A(_py_backwards_six_with_metaclass(B)):
        pass
    """
    run_transformer(input_code, expected_code, MetaclassTransformer, 2)