

# Generated at 2022-06-12 03:39:56.473175
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astunparse
    node = ast.parse("class C(metaclass=B): pass")
    MetaclassTransformer().visit(node)
    assert astunparse.unparse(node) == 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\n\nclass C(_py_backwards_six_withmetaclass(B)):\n    pass'



# Generated at 2022-06-12 03:40:03.505487
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    snippet = """
    class Test(metaclass=ab):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class Test(_py_backwards_six_withmetaclass(ab)):
        pass
    """
    transformer = MetaclassTransformer()
    transformer.transform_source(snippet, filename='<test>')
    assert transformer._tree_changed
    assert expected == transformer._get_transformed_src()


# Generated at 2022-06-12 03:40:04.592069
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    t = MetaclassTransformer()

# Generated at 2022-06-12 03:40:12.537346
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_utils import patch_node, make_visitor_tester
    from typing import Any
    from typed_ast import ast3 as ast

    node = patch_node(ast.Module,
        [patch_node(ast.ClassDef, 'Cls', 
            [], 
            [], 
            [],
            [patch_node(ast.keyword, 'metaclass',
                ast.Name('Foo', ast.Load()))],
            patch_node(ast.Pass, []))])
    actual = make_visitor_tester(MetaclassTransformer, node)


# Generated at 2022-06-12 03:40:19.125654
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.examples import snippet_classdef_bases_metaclass
    from ..utils.examples import snippet_classdef_bases_metaclass_expected

    transformer = MetaclassTransformer()
    source = snippet_classdef_bases_metaclass.get_source()
    tree = ast.parse(source)
    transformer.visit(tree)
    assert transformer.tree_changed

    expected = snippet_classdef_bases_metaclass_expected.get_source()
    actual = astor.to_source(tree).strip()
    assert actual == expected

# Generated at 2022-06-12 03:40:24.074762
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compiler import compile_snippet
    node = source.of("""
        class X(metaclass=Y):
            pass
    """)
    module = compile_snippet(node, MetaclassTransformer)
    assert module.body[0].bases[0].value.elts[0].id == 'Y'

# Generated at 2022-06-12 03:40:34.219575
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tests = []
    tests.append(ClassDef(name="DummyName",
                          bases=[],
                          decorator_list=[],
                          keywords=[],
                          body=[],
                          lineno=0,
                          col_offset=0))
    tests.append(ClassDef(name="DummyName",
                          bases=[Name(id="DummyBaseName0",
                                      ctx=Load())],
                          decorator_list=[],
                          keywords=[],
                          body=[],
                          lineno=0,
                          col_offset=0))

# Generated at 2022-06-12 03:40:43.223493
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    original_code = """class A(metaclass=B):'{}'"""
    expected_code = """class A(_py_backwards_six_withmetaclass(B),'{}'): pass"""
    c = MetaclassTransformer()
    c.visit(ast.parse(original_code.format('')))
    assert c.get_tree_code() == expected_code.format('')
    c.visit(ast.parse(original_code.format('pass')))
    assert c.get_tree_code() == expected_code.format('pass')
    c.visit(ast.parse(original_code.format('pass # comment')))
    assert c.get_tree_code() == expected_code.format('pass # comment')

# Generated at 2022-06-12 03:40:52.374285
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import textwrap
    source = textwrap.dedent("""
        class A(metaclass=B):
            pass
    """)
    node = ast.parse(source)
    MetaclassTransformer().visit(node)
    print(ast.dump(node))
    expected = textwrap.dedent("""
        Module(body=[From(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0), ClassDef(name='A', bases=[Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), args=[Name(id='B', ctx=Load())], keywords=[])], body=[], decorator_list=[])])
    """).strip()

# Generated at 2022-06-12 03:41:01.444555
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import unittest
    import sys
    import astor

    class Test(unittest.TestCase):
        def test_metaclass_transformer_visit_classdef(self):
            def compare(source: str, target: str) -> None:
                test_module: ast.Module = ast.parse(source)
                MetaclassTransformer().visit(test_module)
                tree = astor.to_source(test_module)
                self.assertEqual(target, tree)

            compare('class A(metaclass=B):\n    pass',
                    'from six import with_metaclass as _py_backwards_six_with_metaclass\nclass A(_py_backwards_six_with_metaclass(B))')

    suite = unittest.TestLoader().loadTestsFrom

# Generated at 2022-06-12 03:41:07.203788
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    snippet = """class A(metaclass=B, *C, **D):
        pass"""

# Generated at 2022-06-12 03:41:14.599679
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_utils import node_to_str

    transformer = MetaclassTransformer()
    assert node_to_str(transformer.visit(ast.parse(  # type: ignore
        '''class A(metaclass=type):
            pass'''))) == "from six import with_metaclass as _py_backwards_six_withmetaclass\n\n" \
                         "class A(_py_backwards_six_withmetaclass(type)):\n" \
                         "    pass"



# Generated at 2022-06-12 03:41:18.465885
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_utils import transform_and_compare_signatures
    transform_and_compare_signatures(MetaclassTransformer,
                                     'class Foo(metaclass=Bar): pass',
                                     'class Foo(_py_backwards_six_withmetaclass(Bar)): pass')

# Generated at 2022-06-12 03:41:19.529102
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:41:28.492232
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..transformers.parent import ParentNodeTransformer
    from test.test_utils import round_trip
    from typed_ast.ast3 import Module, ClassDef, Name, Load, Tuple, Num, List, Keyword

    node = Module(
        body=[
            ClassDef(
                name='Blah',
                bases=[
                    Tuple(
                        elts=[
                            Name(id='object', ctx=Load())
                        ],
                        ctx=Load()
                    )
                ],
                keywords=[
                    Keyword(
                        arg='metaclass',
                        value=Name(id='int', ctx=Load())
                    )
                ],
                body=[
                    Pass()
                ],
                decorator_list=[]
            )
        ]
    )
    # print

# Generated at 2022-06-12 03:41:35.177180
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3 as ast
    from .utils import round_trip
    tree = ast.parse("""
        class A(B, metaclass=C):
            pass
    """)

    with_metaclass = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(C, (B,))):
            pass
    """

    assert round_trip(tree, MetaclassTransformer) == with_metaclass.strip()



# Generated at 2022-06-12 03:41:44.506433
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.ast import ast_equal
    from .. import compile
    from ..visitor import print_ast
    from .six_bases import SixBasesTransformer

    with open("tests/data/six_metaclass.py", 'r') as f:
        source = f.read()

    expected_tree = compile.parse(source)
    expected_tree = SixBasesTransformer()\
                           .visit(expected_tree) # type: ignore
    class_body = expected_tree.body[0]
    expected_bases = class_body.bases.elts

    tree = compile.parse(source)
    tree = MetaclassTransformer()\
               .visit(tree) # type: ignore
    class_body = tree.body[0]
   

# Generated at 2022-06-12 03:41:52.299302
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert compile(source='''
        class A(metaclass=B):
            pass
    ''',
    filename='',
    mode='exec').co_firstlineno == 2

    assert MetaclassTransformer.visit_ClassDef(
        MetaclassTransformer(),
        ast.parse(source='''
            class A(metaclass=B):
                pass
        ''',
        filename='',
        mode='exec').body[0]
    ) == ast.parse(source='''
            class A(_py_backwards_six_with_metaclass(B)):
                pass
    ''',
    filename='',
    mode='exec').body[0]

# Generated at 2022-06-12 03:42:02.549656
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    # Setup
    from typed_ast import parse
    from ..utils.snippet import assign
    from ..utils.tree import find_all

    cases = [
        ('class A(metaclass=type): pass',
         'class A(_py_backwards_six_with_metaclass(type)): pass'),
        ('class A(object, metaclass=type): pass',
         'class A(_py_backwards_six_with_metaclass(type), object): pass'),
        ('class A(object, meta=1, metaclass=type): pass',
         'class A(_py_backwards_six_with_metaclass(type), object, meta=1): pass'),
    ]

    # Run
    for (case, expected) in cases:
        _globals = {}
        _locals = {}

# Generated at 2022-06-12 03:42:07.996829
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import assert_source

    @assert_source(six_import)
    def test_MultiLineClassDef():
        class C(object, metaclass=type):
            pass


# Generated at 2022-06-12 03:42:11.364216
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:20.081667
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class TestMetadata(unittest.TestCase):
        maxDiff = None
        source = """
            import six
            class A(metaclass=B):
                pass
        """
        target = """
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A(_py_backwards_six_withmetaclass(B))
        """

    tree = ast.parse(TestMetadata.source)
    MetaclassTransformer().visit(tree)
    parsed_target = ast.parse(TestMetadata.target)
    self.assertEqual(ast.dump(tree), ast.dump(parsed_target))

# Generated at 2022-06-12 03:42:26.934140
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    
    node = ast.ClassDef(
        name='A',
        bases=[],
        keywords=[
            ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))
        ],
        body=[ast.Pass()],
        decorator_list=[],
        starargs=None,
        kwargs=None
    )
    
    xformer = MetaclassTransformer()
    node = xformer.visit(node)
    assert node.bases and node.bases[0].elts[0].id == 'B'



# Generated at 2022-06-12 03:42:27.375743
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:28.326347
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:29.109612
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:35.009656
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

    # Given
    class_def = ast.parse("""
        class A(metaclass=B):
            pass
    """).body[0]

    # When
    MetaclassTransformer().visit(class_def)

    # Then
    assert astor.to_source(class_def).strip() == """
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """.strip()


# Generated at 2022-06-12 03:42:41.552026
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from six import PY3
    from ..utils.visitor import visit_tree

    six_import_node = six_import.get_tree()
    assert isinstance(six_import_node, ast.Module)
    assert len(six_import_node.body) == 1
    assert isinstance(six_import_node.body[0], ast.ImportFrom)
    tree = ast.parse("""
        class A(metaclass=B, **kwargs):
            pass
        class C(metaclass=D, bases=E, **kwargs2):
            pass
        class F(metaclass=G):
            pass
    """)
    tree.body[0].bases = [ast.Name(id='B')]

# Generated at 2022-06-12 03:42:43.017630
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:44.121077
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:52.991471
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = '''
    class A(metaclass=B):
        pass
    '''
    node = ast.parse(source, mode='eval')
    transformer = MetaclassTransformer()
    transformer.visit(node)
    result = ast.fix_missing_locations(node)

    assert node.body[0].bases[0].func.id == '_py_backwards_six_with_metaclass'

# Generated at 2022-06-12 03:42:53.938520
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:42:58.697976
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.helpers import parse, stringify

    class_def_node = parse('''
    class A(metaclass=B):
        pass
    ''')

    expected_node = parse('''
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    ''')

    MetaclassTransformer().visit_ClassDef(class_def_node)
    assert stringify(class_def_node) == stringify(expected_node)

# Generated at 2022-06-12 03:42:59.471459
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-12 03:43:09.065826
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils.mocks import MockTree
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import transform_and_compare_with_file

    node = MockTree(ast.ClassDef(name="Foo", bases=[ast.Name(id="Bar")],
                                 keywords=[], body=[]))
    result = MetaclassTransformer().visit(node)
    transformed = astor.to_source(result)
    expected = "class Foo(_py_backwards_six_withmetaclass(Bar)): ..."
    assert transformed == expected, transformed

    transform_and_compare_with_file(MetaclassTransformer,
                                    "test/python2.7/fixtures/metaclass.py")

# Generated at 2022-06-12 03:43:14.104243
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import unittest
    import typed_ast.ast3 as ast
    from py_backwards.transformers.metaclass import MetaclassTransformer

    class TestCase(unittest.TestCase):
        def test(self):
            source = '''
            class A(metaclass=B):
                pass
            '''
            expected_source = '''
            class A(_py_backwards_six_withmetaclass(B)):
                pass
            '''
            tree = ast.parse(source)
            MetaclassTransformer().visit(tree)
            self.assertEqual(ast.dump(tree), ast.dump(ast.parse(expected_source)))

    unittest.main()

# Generated at 2022-06-12 03:43:21.133247
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import astor
    from py_backwards.transformers.metaclass import MetaclassTransformer

    node = ast.parse('class A(metaclass=B): x=1')
    trans = MetaclassTransformer()
    trans.visit(node)
    assert astor.to_source(node).replace('\n', '').strip() == "from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)): x = 1"



# Generated at 2022-06-12 03:43:22.570041
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_astunparse

# Generated at 2022-06-12 03:43:27.509128
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
    class A(metaclass=B):
        pass 
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    _py_backwards_six_withmetaclass(B)
    """
    before_after = MetaclassTransformer.before_after(code)
    assert before_after == (code, expected)

# Generated at 2022-06-12 03:43:37.325916
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six
    # Tests that method visit_ClassDef of class MetaclassTransformer works as
    # expected for class A(metaclass=B).

    # note: This is the code snippet
    @snippet
    def orig_node():
        class A(metaclass=B):
            pass
    # endnote

    orig_node = orig_node.get_ast()
    xformer = MetaclassTransformer()

    # note: This is the expected result of transforming the code snippet
    @snippet
    def expected_node():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    # endnote

    expected_node = expected_node.get_ast()
    expected

# Generated at 2022-06-12 03:43:56.008881
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six
    import os
    import ast
    import astunparse
    from ..utils.snippet import snippet

    with open(os.path.join(os.path.dirname(__file__), 'test_files', 'MetaclassTransformer_visit_ClassDef.py')) as fd:
        test_code = fd.read()

    test_tree = ast.parse(test_code)
    MetaclassTransformer().visit(test_tree)
    code = astunparse.unparse(test_tree)

    @snippet
    def expected_code():
        from six import with_metaclass as _py_backwards_six_with_metaclass

        class A(_py_backwards_six_with_metaclass(B)):
            pass
    six_code = expected_

# Generated at 2022-06-12 03:44:01.931794
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    node = ast.parse("class A(metaclass=B): pass")
    transformer = MetaclassTransformer()

    # When
    transformer.visit(node)

    # Then
    assert node.body[0].bases == [ast.Call(func=ast.Name(id='_py_backwards_six_withmetaclass'),
                                           args=[ast.Name(id='B')],
                                           keywords=[],
                                           starargs=None, kwargs=None, star2args=None)]

# Generated at 2022-06-12 03:44:06.647930
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert MetaclassTransformer().visit(ast.parse(
    """
    class A(metaclass=B):
        pass
    """
    )) == ast.parse(
    """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    )

# Generated at 2022-06-12 03:44:15.755151
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Visit a ClassDef node with a metaclass keyword
    tree = ast.parse("class A(metaclass=Foo): pass")
    transformer = MetaclassTransformer(tree)
    transformer.visit(tree)
    assert ast.dump(tree) == "class A(_py_backwards_six_withmetaclass(Foo)):\n    pass\n"

    # Visit a ClassDef with bases and a metaclass
    tree = ast.parse("class A(Foo, metaclass=Bar): pass")
    transformer = MetaclassTransformer(tree)
    transformer.visit(tree)
    assert ast.dump(tree) == "class A(_py_backwards_six_withmetaclass(Bar, Foo)):\n    pass\n"
    assert not transformer.tree_changed()

# Generated at 2022-06-12 03:44:16.994677
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()

    # new

# Generated at 2022-06-12 03:44:25.255723
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import ClassDef, Assign, Keyword
    node = ast.parse('class A(metaclass=B): pass').body[0]
    assert type(node) == ClassDef
    assert node.keywords[0].arg == 'metaclass'
    node = MetaclassTransformer().visit(node)
    assert type(node.bases[0]) == Assign
    assert type(node.bases[0].value) == ast.Call
    assert type(node.bases[0].value.func) == ast.Name
    assert node.bases[0].value.func.id == '_py_backwards_six_withmetaclass'
    assert node.keywords == []


# Generated at 2022-06-12 03:44:29.928931
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast, parse
    node = parse("class A(metaclass=B, object): pass")
    assert node.body[0].keywords
    MetaclassTransformer().visit(node)
    assert not node.body[0].keywords

test_MetaclassTransformer_visit_ClassDef()



# Generated at 2022-06-12 03:44:39.094252
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import unittest
    import typed_astunparse

    class TestMetaclassTransformerVisitClassDef(unittest.TestCase):
        def test(self):
            node = typed_ast.ast3.parse("""
            class A(metaclass=B):
                pass
            """)[0]

            transformer = MetaclassTransformer()
            new_node = transformer.visit(node)
            new_source = typed_astunparse.unparse(new_node)
            self.assertEqual("""
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A(_py_backwards_six_withmetaclass(B)):
                pass
            """, new_source)
    unittest.main()

# Generated at 2022-06-12 03:44:47.642619
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...testing import assertions
    from ...testing import transformations

    class Test(transformations.CompilerTest):
        __test__ = True
        transform = MetaclassTransformer

        @assertions.reset_module(__name__)
        def test_class(self):
            self.module.from_import('six', 'with_metaclass')

            self.assert_compile(
                'class A(metaclass=B): pass',
                'class A(_py_backwards_six_with_metaclass(B)): pass',
            )

        @assertions.reset_module(__name__)
        def test_class_with_base(self):
            self.module.from_import('six', 'with_metaclass')


# Generated at 2022-06-12 03:44:56.013499
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..ast_transformer_generator import AstTransformerGenerator
    import inspect
    import os


    class TestTransformer(MetaclassTransformer):
        def __init__(self, tree: ast.Module, filename: str) -> None:
            super().__init__(tree, filename)
            self._tree_changed = False


    test_module_path = os.path.dirname(inspect.getfile(inspect.currentframe()))
    test_module = TestTransformer.gen_module(test_module_path, "six_input.py")
    compare_ast(
        metaclass_input_ast,
        test_module,
        "MetaclassTransformer",
    )



# Generated at 2022-06-12 03:45:13.557687
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import typing
    import astor
    import ast

    class TestCase(typing.NamedTuple):
        before: str
        after: str

    test_cases = [
        TestCase(
            'class A(object): pass',
            'class A(object): pass',
        ),
        TestCase(
            'class A(metaclass=object): pass',
            'class A(_py_backwards_six_withmetaclass(object)): pass',
        ),
    ]

    for case in test_cases:
        tree: ast.Module = ast.parse(case.before)
        transformer = MetaclassTransformer()
        transformer.visit(tree)
        actual = astor.to_source(tree)
        print('\ncase =', case)
        print('actual =', actual)

# Generated at 2022-06-12 03:45:20.798027
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class Module(ast.Module):
        def __init__(self, body):
            self.body = body

    class ClassDef(ast.ClassDef):
        def __init__(self, name, bases, keywords, body):
            self.name = name
            self.bases = bases
            self.keywords = keywords
            self.body = body

    class Name(ast.Name):
        def __init__(self, id):
            self.id = id

    class Keyword(ast.keyword):
        def __init__(self, arg, value):
            self.arg = arg
            self.value = value

    class Str(ast.Str):
        def __init__(self, s):
            self.s = s


# Generated at 2022-06-12 03:45:25.028911
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code_before = "class A(Q, metaclass=B): pass"
    code_after = "class A(_py_backwards_six_with_metaclass(B, Q)): pass"
    assert MetaclassTransformer(code_before).code() == code_after

# Generated at 2022-06-12 03:45:31.054183
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    from ..compiler import compile_ast, to_ast
    from ..utils.source import source

    code = '''
        class A(metaclass=B):
            pass
        class C(metaclass=D, arg=D.a):
            pass
        class D(metaclass=D, arg=D.a, arg2=D.a):
            pass
        class E(metaclass=D, arg=D.a, arg2=D.a, arg3=D.a):
            pass
    '''

    # Compile to the lowest Python version
    tree = compile_ast(to_ast(code), sys.version_info[:2])

    # Transform with MetaclassTransformer
    transformer = MetaclassTransformer()
    transformer.visit(tree)

    # Check that the

# Generated at 2022-06-12 03:45:33.888970
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    target_source = 'class A(metaclass=B):\n    pass'

# Generated at 2022-06-12 03:45:35.268525
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typing import List

    import ast_helpers


# Generated at 2022-06-12 03:45:41.447095
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """It should insert the `from six import with_metaclass as _py_backwards_six_withmetaclass`
    to the top of the module.
    """
    tree = ast.parse("")
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    assert tree.body == six_import.get_body()



# Generated at 2022-06-12 03:45:48.467371
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils import reindent
    from ..main import main_single as main
    from unittest import TestCase
    
    class Test(TestCase):
        def test_example(self):
            src = reindent(3, '''
                class A(metaclass=B):
                    pass
            ''')
            expect = reindent(2, '''
                from six import with_metaclass as _py_backwards_six_withmetaclass
                
                class A(_py_backwards_six_withmetaclass(B)):
                    pass
            ''')
            self.assertEqual(main(src), expect)
    
    return Test



# Generated at 2022-06-12 03:45:55.163188
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Compiles:
        class A(metaclass=B):
            pass
    To:
        class A(_py_backwards_six_with_metaclass(B))
    """
    assert MetaclassTransformer().visit(ast.parse(
        """
        class A(metaclass=B, C):
            pass
        """
    )) == ast.parse(
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B, C)):
            pass
        """
    )

# Generated at 2022-06-12 03:45:59.976293
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

    code = 'class A(B, metaclass=C):\n pass\n'
    tree = ast.parse(code)
    MetaclassTransformer().visit(tree)
    assert astor.to_source(tree).strip() == 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(C, B)):\n    pass'


# Generated at 2022-06-12 03:46:20.532617
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.snippet import snippet_compile
    from ..utils.compat import parse
    from ..utils.trees import print_tree
    from typed_ast import ast3


# Generated at 2022-06-12 03:46:23.337184
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.testing import assert_transform
    text = """class A(metaclass=type): pass"""

# Generated at 2022-06-12 03:46:30.486707
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = '''class A(metaclass=B):\n    pass'''
    assert MetaclassTransformer().visit(ast.parse(code)).body[0].bases == ast.parse('''_py_backwards_six_withmetaclass(B)''').body[0]
    assert MetaclassTransformer().visit(ast.parse(code)).body[0].keywords == []
    assert len(MetaclassTransformer().visit(ast.parse(code)).body) == 2
    assert isinstance(MetaclassTransformer().visit(ast.parse(code)).body[1], ast.Expr)

# Generated at 2022-06-12 03:46:35.418854
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("""
    class x(object, metaclass=type):
        pass
    """)
    MetaclassTransformer().visit(node)
    assert str(node) == """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class x(_py_backwards_six_withmetaclass(type, object)):
        pass"""


# Generated at 2022-06-12 03:46:36.814068
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

# Generated at 2022-06-12 03:46:43.388292
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse('class A(metaclass=B): pass')
    transformer = MetaclassTransformer()
    new_node = transformer.visit(module)
    nodes = [node for node in ast.walk(new_node) if isinstance(node, ast.Expr)]
    assert len(nodes) == 1
    expr = nodes[0].value
    assert isinstance(expr, ast.Call)
    assert expr.func.id == '_py_backwards_six_withmetaclass'
    assert expr.args[0].id == 'B'
    assert isinstance(expr.args[1], ast.Name)
    assert expr.args[1].id == 'A'

# Generated at 2022-06-12 03:46:52.197470
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..unparse import Unparser

    expr1 = '''
    class A(metaclass=B):
        pass
    '''
    expected1 = '''
    class A(_py_backwards_six_with_metaclass(B)):
        pass
    '''

    expr2 = '''
    class A(B, metaclass=C, X=Y):
        pass
    '''
    expected2 = '''
    class A(_py_backwards_six_with_metaclass(C, B), X=Y):
        pass
    '''

    mt = MetaclassTransformer()
    for expr, expected in zip((expr1, expr2), (expected1, expected2)):
        node = ast.parse(expr)
        mt.visit(node)
        Unparser(node)


# Generated at 2022-06-12 03:46:59.434393
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..testing.utils import transform
    module = transform('class B(A):\n    pass')
    module = transform('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class B(_py_backwards_six_withmetaclass(A, object)):
            pass''', module=module)

    assert module == transform('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class B(_py_backwards_six_withmetaclass(A)):
            pass''')

# Generated at 2022-06-12 03:47:05.618928
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast as pyast

    # Test for visit_ClassDef()
    class_def_old_text = "class A(b, metaclass=B): pass"
    class_def_old_ast = pyast.parse(class_def_old_text)
    class_def_old = class_def_old_ast.body[0]
    class_def_new = MetaclassTransformer.visit(class_def_old_ast)

    assert class_def_old != class_def_new.body[0]
    assert class_def_new.body[0].bases[0].func.value == class_def_new.body[0].name

# Generated at 2022-06-12 03:47:15.221727
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ...utils import cst_to_ast
    from ...utils.compat import ast_parse, dump
    import ast
    # Given
    source = '''
    class A(metaclass=B):
        pass
    '''
    expected_ast = '''
Module(body=[
    ImportFrom(
        module='six',
        names=[alias(
            name='with_metaclass',
            asname='_py_backwards_six_withmetaclass')],
        level=0)],
    type_ignores=[])
    '''
    # When
    node = ast_parse(source)
    MetaclassTransformer(target=[2, 7]).visit(cst_to_ast(node))
    actual_ast = dump(node)
    # Then
    assert actual_ast == expected_ast

# Generated at 2022-06-12 03:48:05.581934
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transform = MetaclassTransformer()
    module = ast.parse("""
        class A(metaclass=B, q=C):
            pass
    """)
    transformed = transform.visit(module)
    print(ast.dump(transformed))

# Generated at 2022-06-12 03:48:06.718029
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    MetaclassTransformer().visit(parse_ast('class A(metaclass=B): pass'))

# Generated at 2022-06-12 03:48:13.777880
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.fixtures import ast_module
    from .base import BaseNodeTransformer
    from .six_import import SixImportTransformer
    import six

    source = """
    class A(metaclass=B):
        pass
    """
    expected = f"from six import with_metaclass as _py_backwards_six_withmetaclass\n\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass\n"

    assert expected == MetaclassTransformer(ast_module(source),
                                            {'six': six}).result()


# Generated at 2022-06-12 03:48:18.976852
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.test_utils import assert_equal_code  # type: ignore
    assert_equal_code(MetaclassTransformer().visit(six_import.get_ast()), six_import.code)
    # can only test the snippet, since it is a module-level transformer
    assert_equal_code(MetaclassTransformer().visit(six_import.get_ast()), six_import.code)
    assert_equal_code(MetaclassTransformer().visit(class_bases.get_ast()), class_bases.code)

# Generated at 2022-06-12 03:48:25.615677
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.tester import make_wrapped_test

    source = """
            class A:
                pass
        """
    expected = """
            class A:
                pass
        """
    make_wrapped_test(MetaclassTransformer, source, expected)

    source = """
            class A(object):
                pass
        """
    expected = """
            class A(object):
                pass
        """
    make_wrapped_test(MetaclassTransformer, source, expected)

    source = """
            class A(object, metaclass=B):
                pass
        """
    expected = """
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A(_py_backwards_six_withmetaclass(B)):
                pass
        """


# Generated at 2022-06-12 03:48:29.269961
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    test_program = compile("""
        class C(metaclass=type):
            pass
        """, filename='', mode='exec')
    transformer = MetaclassTransformer()
    transformer.visit(test_program)
    compiled = compile(test_program, filename='', mode='exec')
    exec(compiled)

# Generated at 2022-06-12 03:48:31.094292
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """Unit test for constructor of class MetaclassTransformer"""
    assert MetaclassTransformer.__name__ == "MetaclassTransformer"

# Generated at 2022-06-12 03:48:40.083311
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3
    from ..utils.source import source

    code = """
      class A(): pass
      class B(): pass
      class C(metaclass=A): pass
      class D(metaclass=B): pass
      class E(A, metaclass=A): pass
    """
    source_tree = source.from_string(code, python_version=2.7)
    target_tree = source.from_string(code, python_version=3.7)

# Generated at 2022-06-12 03:48:48.632334
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """

    def test():
        class A(metaclass=type):
            class B(metaclass=type):
                pass
    
    """
    m = ast.parse(test_MetaclassTransformer.__doc__)
    MetaclassTransformer(m).visit(m)

# Generated at 2022-06-12 03:48:51.259342
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = """
    class A(object):
        pass
    """
    tree = ast.parse(code)
    MetaclassTransformer().visit(tree)
    assert compile(tree, '<test>', 'exec')