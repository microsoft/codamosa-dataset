

# Generated at 2022-06-25 22:07:27.071229
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    ast_node_0 = None
    metaclass_transformer_0.visit_Module(ast_node_0)


# Generated at 2022-06-25 22:07:27.837862
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():

    # Procedure body
    pass
    

# Generated at 2022-06-25 22:07:31.575708
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

    # call the method
    result = metaclass_transformer_0.visit_Module()

    # Verifying the result



# Generated at 2022-06-25 22:07:32.445005
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-25 22:07:36.839835
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_1 = None
    module_0 = ast.Module(body=[])
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_1)
    module_1 = metaclass_transformer_0.visit_Module(module_0)
    assert len(module_1.body) == 1


# Generated at 2022-06-25 22:07:41.590525
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    six_import_0 = None
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_0 = ast.Module([], [])
    module_0.body = []
    module_0 = metaclass_transformer_0.visit_Module(module_0)


# Generated at 2022-06-25 22:07:43.985233
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_0 = None
    metaclass_transformer_0.visit_Module(module_0)


# Generated at 2022-06-25 22:07:49.743042
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Import the module under test
    import py_backwards.tricks.six.with_metaclass

    # Setup
    a_s_t_0 = None
    metaclass_transformer_0 = py_backwards.tricks.six.with_metaclass.MetaclassTransformer(a_s_t_0)

    # Variant input arguments
    metaclass_transformer_0.visit_ClassDef(None)


# Generated at 2022-06-25 22:07:53.650204
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

    class_def_0 = None
    metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:07:57.421165
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = None
    metaclass_transformer_0.visit_ClassDef(a_s_t_1)


# Generated at 2022-06-25 22:08:07.544751
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert callable(MetaclassTransformer.visit_ClassDef)

class_d_e_f_0 = module_0.ClassDef()
a_s_t_0 = module_0.AST()
metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
class_d_e_f_1 = metaclass_transformer_0.visit_ClassDef(class_d_e_f_0)

if __name__ == '__main__':
    import pytest
    import inspect
    pytest.main('-qq -s %s -k %s' % (__file__, inspect.stack()[0][3]))

# Generated at 2022-06-25 22:08:12.634554
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert class_def_1 is None


# Generated at 2022-06-25 22:08:14.128423
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = module_0
    test_case_0()

# Generated at 2022-06-25 22:08:14.999054
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()


# Generated at 2022-06-25 22:08:19.506810
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:08:27.958158
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Test for method visit_ClassDef
    # Setup
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # Call
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    # Assert result
    assert class_def_1 is class_def_0


# Generated at 2022-06-25 22:08:32.304393
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:08:33.267014
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Case 0
    test_case_0()

# Generated at 2022-06-25 22:08:37.438417
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    # assertFalse(metaclass_transformer_0._tree_changed)

# Generated at 2022-06-25 22:08:40.379866
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_ = module_0.ClassDef()
    a_s_t_ = module_0.AST()
    metaclass_transformer = MetaclassTransformer(a_s_t_)
    class__ = metaclass_transformer.visit_ClassDef

# Generated at 2022-06-25 22:08:47.358170
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = module_0
    class_def = module_0.ClassDef()

    mt = MetaclassTransformer(module_0.AST())
    out = mt.visit_ClassDef(class_def)
    assert out == class_def

# Generated at 2022-06-25 22:08:50.786512
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    metaclass_transformer_0 = MetaclassTransformer(module_0.AST())
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:08:59.247605
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    module_0.ClassDef = lambda: class_def_0
    module_0.AST = lambda: a_s_t_0
    class_def_0.bases = lambda: list_0
    class_def_0.keywords = lambda: list_1
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    assert type(metaclass_transformer_0.visit_ClassDef(class_def_0)) == module_0.ClassDef

# Generated at 2022-06-25 22:09:02.346270
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    def test_ClassDef(metaclass_transformer):
        obj = module_0.ClassDef()
        ret_val_0 = metaclass_transformer.visit_ClassDef(obj)
        assert isinstance(ret_val_0, module_0.ClassDef)


# Generated at 2022-06-25 22:09:03.517695
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()

# Generated at 2022-06-25 22:09:05.467829
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()

if __name__ == '__main__':
    test_MetaclassTransformer_visit_ClassDef()

# Generated at 2022-06-25 22:09:06.725710
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert True

# Generated at 2022-06-25 22:09:11.036427
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    module_0.ClassDef()

# Generated at 2022-06-25 22:09:17.020814
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:09:20.509756
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert class_def_1 is class_def_0


# Generated at 2022-06-25 22:09:35.314454
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert class_def_1 == class_def_0


# Generated at 2022-06-25 22:09:38.729048
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from six import with_metaclass as _py_backwards_six_withmetaclass  # line: 0
    class A(_py_backwards_six_withmetaclass(B)):  # line: 1
        pass  # line: 2


# Generated at 2022-06-25 22:09:43.259845
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_2 = module_0.ClassDef()
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    class_def_3 = metaclass_transformer_1.visit_ClassDef(class_def_2)

import ast as module_1


# Generated at 2022-06-25 22:09:53.146471
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_bases_0 = module_0.ClassDef()
    module_0.AssignName()
    module_0.Str()
    metaclass_0 = metaclass_transformer_0.generic_visit(class_def_1)
    class_bases_1 = metaclass_transformer_0.generic_visit(metaclass_0)
    module_0.Module()
    class_def_2 = metaclass_transformer_0

# Generated at 2022-06-25 22:09:57.094705
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:10:01.140407
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    try:
        class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
        assert True
    except:
        assert False


# Generated at 2022-06-25 22:10:04.924145
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    metaclass_transformer_0 = MetaclassTransformer(class_def_0)
    module_0.ClassDef()
    metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:10:10.737659
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = module_0
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:10:20.024022
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef(name='foo', body=[], decorator_list=[], keywords=[module_0.keyword(arg='bar', value=module_0.Name('foo', module_0.Load()))])
    module_1 = module_0.Module(body=[class_def_0])
    a_s_t_0 = module_0.AST(node=module_1)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_Module(module_1)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:10:22.627188
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:10:40.314824
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    try:
        test_case_0()
    except:
        print('Expected and caught')
    else:
        assert False

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:10:47.474007
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    arg_null_0 = None
    module_0.ClassDef(body=[], decorator_list=[], name="test", bases=arg_null_0)
    assert class_def_1 == module_0.ClassDef(body=[], decorator_list=[], name="test", bases=arg_null_0)
    module_0.arguments()
    module_0.Name(ctx=module_0.Store, id="func")

# Generated at 2022-06-25 22:10:49.166003
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    try:
        test_case_0()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-25 22:10:54.709393
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert isinstance(class_def_1, module_0.ClassDef)


# Generated at 2022-06-25 22:10:58.550424
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:11:04.712572
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert isinstance(class_def_1, module_0.ClassDef)
    assert class_def_1.keywords == []


# Generated at 2022-06-25 22:11:08.743617
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)



# Generated at 2022-06-25 22:11:20.185260
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = ast.parse("class A(metaclass=B):pass")
    class_def_0 = module_0.body[0]
    a_s_t_0 = ast.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert type(class_def_1) == ast.ClassDef
    assert class_def_1.keywords == []
    assert type(class_def_1.bases[0]) == ast.Call
    assert type(class_def_1.bases[0].args[0]) == ast.Name
    assert type(class_def_1.bases[0].args[1]) == ast

# Generated at 2022-06-25 22:11:24.603945
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:11:30.092222
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

if __name__ == '__main__':
    test_case_0()
    test_MetaclassTransformer_visit_ClassDef()

# Generated at 2022-06-25 22:11:46.732380
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module_1 = module_0.Module()
    metaclass_transformer_1 = MetaclassTransformer(module_1)
    module_2 = metaclass_transformer_1.visit_Module(module_1)

# Generated at 2022-06-25 22:11:51.756441
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    module_1 = metaclass_transformer_0.visit_Module(module_0_0)

# Generated at 2022-06-25 22:11:53.110119
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer(a_s_t_0)
    # TODO: Test for exceptions


# Generated at 2022-06-25 22:11:56.054359
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = metaclass_transformer_0.visit_Module(module_0)

# Generated at 2022-06-25 22:12:02.778405
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Tests for the metaclass transformation
    class_def_0 = module_0.ClassDef(name='py_backwards_six_withmetaclass', bases=[], keywords=[], body=[], decorator_list=[])
    module_1 = module_0.Module(body=[class_def_0])
    a_s_t_0 = module_0.AST(node=module_1)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    

# Generated at 2022-06-25 22:12:06.262486
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:12:10.693331
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = metaclass_transformer_0.visit_Module(module_0)
    assert module_1 == module_0


# Generated at 2022-06-25 22:12:14.076527
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)
    assert isinstance(metaclass_transformer_1, MetaclassTransformer)


# Generated at 2022-06-25 22:12:23.859182
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    module_0.arguments()
    module_0.Attribute()
    module_0.BinOp()
    module_0.Call()
    module_0.Compare()
    module_0.Eq()
    module_0.Expr()
    module_0.FloorDiv()
    module_0.For()
    module_0.FunctionDef()
    module_0.GeneratorExp()
    module_0.If()
    module_0.ImportFrom()
    module_0.In()
    module_0.LShift()
    module_0.Load()
    module_

# Generated at 2022-06-25 22:12:32.981732
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    # assert if MetaclassTransformer constructor is called with correct arguments
    try:
        MetaclassTransformer(a_s_t_0)
    except:
        raise Exception("Failed to construct MetaclassTransformer with correct arguments")

    # assert if MetaclassTransformer constructor is called other than two arguments
    try:
        MetaclassTransformer()
        raise Exception("Failed to raise error when construct MetaclassTransformer with incorrect arguments")
    except:
        pass

    # assert if MetaclassTransformer constructor is called for other than AST
    try:
        MetaclassTransformer(int())
        raise Exception("Failed to raise error when construct MetaclassTransformer with incorrect arguments")
    except:
        pass


# Generated at 2022-06-25 22:13:01.924781
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = metaclass_transformer_0.visit_Module(module_0)
    assert (module_1.body[0] == six_import.get_body()[0])


# Generated at 2022-06-25 22:13:05.947017
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module_0 = module_0.Module()
    module_0.body = [module_0.ClassDef()]
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = metaclass_transformer_0.visit_Module(module_0)

# Generated at 2022-06-25 22:13:10.103624
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    passwd = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(passwd)
    assert metaclass_transformer_0._tree_changed == False
    assert metaclass_transformer_0.target == (2, 7)
    assert metaclass_transformer_0.dependencies == ['six']


# Generated at 2022-06-25 22:13:11.552033
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    pass

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:13:16.223302
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typing
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert isinstance(class_def_1, module_0.ClassDef)


# Generated at 2022-06-25 22:13:19.652686
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast
    # FIXME: inline function
    module = module = ast.Module()
    m = MetaclassTransformer(module)
    m.visit_Module(module)

# Generated at 2022-06-25 22:13:24.862949
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = metaclass_transformer_0.visit_Module(module_0)


# Generated at 2022-06-25 22:13:31.987957
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class_def_0 = module_0.ClassDef()
    module_1 = module_0.Module()
    module_1.body = [class_def_0]
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_Module(module_1)



# Generated at 2022-06-25 22:13:37.956528
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import typed_ast._ast3 as module_0
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # assert constructor of class MetaclassTransformer
    assert metaclass_transformer_0._tree is a_s_t_0
    assert metaclass_transformer_0._tree_changed is False


# Generated at 2022-06-25 22:13:44.416197
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # Test method of class MetaclassTransformer
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    # Test method of class Transformer
    metaclass_transformer_0.is_changed()
    # Test method of class Transformer
    metaclass_transformer_0.log_changes()

# Generated at 2022-06-25 22:14:48.971287
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # simple test
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:14:52.925465
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    assert metaclass_transformer_0.visit_Module(module_0) == module_0


# Generated at 2022-06-25 22:14:53.758260
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()


# Generated at 2022-06-25 22:14:54.576714
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()


# Generated at 2022-06-25 22:15:01.848196
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # assert metaclass_transformer_0.target == (2, 7), 'Expect <2, 7> but get <%s>' % str(metaclass_transformer_0.target)
    # assert metaclass_transformer_0.dependencies == ['six'], 'Expect <six> but get <%s>' % str(metaclass_transformer_0.dependencies)
    assert metaclass_transformer_0.tree is a_s_t_0, 'Expect <a_s_t_0> but get <%s>' % str(metaclass_transformer_0.tree)


# Generated at 2022-06-25 22:15:07.086377
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = metaclass_transformer_0.visit_Module(module_0)
    assert module_1 == module_0


# Generated at 2022-06-25 22:15:11.071992
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:15:16.495419
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # Test case where: module_1.body = []
    module_2 = module_0.Module()
    module_2.body = []
    module_3 = metaclass_transformer_0.visit_Module(module_2)
    assert module_3.body == [module_0.Expr(value=module_0.Str(s='six'))]


# Generated at 2022-06-25 22:15:16.903072
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    pass

# Generated at 2022-06-25 22:15:19.615902
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert class_def_1 == class_def_0
