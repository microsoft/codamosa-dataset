

# Generated at 2022-06-25 22:07:20.092098
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_code = """
    class A(metaclass=B):
        pass
    """

    assert MetaclassTransformer().visit(ast.parse(test_code)) == \
        ast.parse("""
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)

# Generated at 2022-06-25 22:07:22.809600
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_0 = None
    metaclass_transformer_0.visit_Module(module_0)


# Generated at 2022-06-25 22:07:23.729440
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 22:07:28.465771
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = None
    metaclass_transformer_0 : MetaclassTransformer = MetaclassTransformer(a_s_t_0)
    module_0: ast.Module = metaclass_transformer_0.visit(ast.parse("""def foo(): pass"""))
    assert inspect.getsource(module_0) == """import six\ndef foo(): pass"""


# Generated at 2022-06-25 22:07:32.279105
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    try:
        metaclass_transformer_0.visit_Module(a_s_t_0)
    except:
        pass


# Generated at 2022-06-25 22:07:37.010728
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    expected_0 = None
    metaclass_transformer_0.visit_ClassDef(expected_0)
    actual_0 = metaclass_transformer_0._tree_changed

    assert actual_0 == expected_0


# Generated at 2022-06-25 22:07:42.406559
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    #
    module_1 = None
    #
    # Invocation of method visit_Module of MetaclassTransformer
    method_invocation_result_2 = metaclass_transformer_0.visit_Module(module_1)
    assert method_invocation_result_2 is not None


# Generated at 2022-06-25 22:07:48.000830
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = set()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_0 = ast.ClassDef(name='A',
                           bases=[],
                           keywords=[],
                           body=[],
                           decorator_list=[])
    a_s_t_1 = metaclass_transformer_0.visit_ClassDef(a_s_t_0)


# Generated at 2022-06-25 22:07:51.826880
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_0 = None
    metaclass_transformer_0.visit_Module(module_0)


# Generated at 2022-06-25 22:07:59.373871
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
  import ast

  a_s_t_1 = ast.ClassDef()
  a_s_t_1.keywords = [ ast.keyword() ]
  a_s_t_1.keywords[0].arg = "metaclass"
  a_s_t_1.keywords[0].value = ast.Name()
  a_s_t_1.keywords[0].value.id = "B"

  metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
  assert(type(metaclass_transformer_1.visit_ClassDef(a_s_t_1)) == ast.ClassDef)

# Generated at 2022-06-25 22:08:06.836341
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_2 = 'class A(object, metaclass=B): pass'
    var_3 = module_1.parse(str_2)
    metaclass_transformer_1 = MetaclassTransformer(var_3)
    var_4 = metaclass_transformer_1.visit(var_3)
    var_5 = 'class A(_py_backwards_six_withmetaclass(B)): pass'
    assert str(var_4) == var_5


# Generated at 2022-06-25 22:08:11.008025
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'class A(): pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)


# Generated at 2022-06-25 22:08:20.673089
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    class A:
        def __init__(self):
            self._tree_changed = False

        def visit(self, node: ast.AST) -> ast.AST:
            node = self.generic_visit(node)
            if self._tree_changed:
                return ast.fix_missing_locations(node)
            return node

        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            if node.keywords:
                metaclass = node.keywords[0].value
                node.bases = class_bases.get_body(metaclass=metaclass,  # type: ignore
                                                  bases=ast.List(elts=node.bases))
                node.keywords = []
                self._tree_changed = True


# Generated at 2022-06-25 22:08:32.145092
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    print("test_MetaclassTransformer_visit_ClassDef")
    # Declare the test tree
    left_paren_0 = None
    right_paren_0 = None
    const_0 = None
    arg_0 = None
    args_0 = None
    left_paren_1 = None
    right_paren_1 = None
    const_1 = None
    arg_1 = None
    args_1 = None
    left_paren_2 = None
    right_paren_2 = None
    const_2 = None
    arg_2 = None
    args_2 = None
    left_paren_3 = None
    right_paren_3 = None
    const_3 = None
    arg_3 = None
    args_3 = None
    left_paren_4 = None
    right_paren_4 = None

# Generated at 2022-06-25 22:08:37.972501
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'class A(metaclass=B): pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)

    str_1 = '_py_backwards_six_withmetaclass(B, *[])'
    var_3 = module_1.parse(str_1)
    assert var_2.body[0].bases == var_3.body[0].value.args


# Generated at 2022-06-25 22:08:46.966204
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3 as module_1
    from pkg_resources import parse_version, resource_string
    from backward_typed_ast import __version__ as package_version
    mod = module_1.parse('class A(metaclass=B):\n    pass')
    cls = mod.body[0]
    transformer = MetaclassTransformer()
    transformer.visit(cls)
    expected = module_1.parse(resource_string(__name__, "../resources/classdef_2.7.txt").decode())
    assert transformer._tree_changed
    assert transformer._dependencies == ["six"]
    assert transformer._changed == {parse_version("2.7")}
    assert cls.bases[0].func.id == "_py_backwards_six_withmetaclass"
   

# Generated at 2022-06-25 22:08:55.951253
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B, object): pass\n'
    var_0 = module_1.parse(str_0)
    var_1 = module_1.ClassDef(name='A', bases=[module_1.Name(id='B', ctx=module_1.Param())], keywords=[module_1.keyword(arg='object', value=module_1.NameConstant(value=True))], body=[module_1.Pass()])
    metaclassTransformer = MetaclassTransformer(None)
    var_2 = metaclassTransformer.visit_ClassDef(var_0.body[0])
    assert var_0.body[0] == var_1
    assert var_2 == var_1

# Generated at 2022-06-25 22:09:03.493710
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_1 = typed_ast.ast3
    metaclass_transformer_0 = MetaclassTransformer(typed_ast.ast3.Module())
    str_0 = 'class A(dict): pass'
    class_body_0 = [module_1.Expr(value=module_1.Call(func=module_1.Name(id='foo', ctx=module_1.Load()), args=[], keywords=[])), module_1.Expr(value=module_1.Call(func=module_1.Name(id='bar', ctx=module_1.Load()), args=[], keywords=[]))]

# Generated at 2022-06-25 22:09:12.205323
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclass_transformer_0 = MetaclassTransformer('2.7', 'six')
    module_0 = ast.parse('hello')
    module_1 = ast.parse('world')
    try:
        var_0 = ast.ClassDef(name='A', body=[ast.Pass()], keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))])
        class_def_0 = metaclass_transformer_0.visit(var_0)
    except Exception as e:
        print('Exception caught: ', e)

# Generated at 2022-06-25 22:09:18.111626
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_1.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(module_1.Module())
    metaclass_transformer_0.visit(var_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:09:22.546094
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_0 = MetaclassTransformer(None)
    assert var_0 is not None
    assert var_0.dependencies == ['six']
    assert var_0.target == (2, 7)


# Generated at 2022-06-25 22:09:29.999117
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    var_0 = 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass'
    expected_0 = module_1.parse(var_0)
    var_1 = module_1.parse('class A(B):\n    pass')
    var_2 = MetaclassTransformer(None)
    var_3 = var_2.visit_ClassDef(var_1.body[0])
    assert_ast_equal(var_3, expected_0.body[0])


# Generated at 2022-06-25 22:09:31.388336
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_0 = None
    var_1 = MetaclassTransformer(var_0)


# Generated at 2022-06-25 22:09:33.512586
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-25 22:09:35.194654
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_0 = None
    obj_0 = MetaclassTransformer(var_0)


# Generated at 2022-06-25 22:09:39.263669
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'def foo(): pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)


# Generated at 2022-06-25 22:09:48.246168
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'def foo(): pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)
    assert_equal(var_2.body, [module_1.FunctionDef(name='foo', args=module_1.arguments(posonlyargs=[], args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[], return_annotation=None), body=[module_1.Pass()], decorator_list=[], returns=None)])


# Generated at 2022-06-25 22:09:51.893888
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = module_1.parse('class Test1(object): pass')
    var_2 = metaclass_transformer_0.visit(var_1)


# Generated at 2022-06-25 22:09:53.629349
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_0 = None
    var_1 = MetaclassTransformer(var_0)


# Generated at 2022-06-25 22:09:54.515986
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    pass


# Generated at 2022-06-25 22:09:57.916593
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    pass



# Generated at 2022-06-25 22:10:08.351351
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = '@deco\ndef foo(): pass'
    var_1 = module_1.parse(str_0)
    str_1 = 'def foo():\n    pass'
    var_2 = module_1.parse(str_1)
    var_3 = isinstance(var_1, module_1.Module)
    var_4 = isinstance(var_2, module_1.Module)
    var_5 = isinstance(var_1.body, list)
    var_6 = isinstance(var_2.body, list)
    var_7 = isinstance(var_1.body[0], module_1.FunctionDef)

# Generated at 2022-06-25 22:10:14.761009
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'class A(metaclass=B): pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)
    var_3 = var_2.body[0].bases[0]
    assert var_3.func.id == '_py_backwards_six_with_metaclass'
    

# Generated at 2022-06-25 22:10:20.268927
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3 as module_0
    var_0 = module_0.parse('class A:\n    pass')
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = var_0.body[0]
    var_2 = metaclass_transformer_0.visit_ClassDef(var_1)
    assert var_2.__class__ == module_0.ClassDef

# Generated at 2022-06-25 22:10:25.118088
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'class A(metaclass=B): pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)
    assert isinstance(var_2.body[0].bases[0], module_1.Call)
    assert isinstance(var_2.body[0].bases[0].func, module_1.Name)
    assert var_2.body[0].bases[0].func.id == '_py_backwards_six_withmetaclass'


# Generated at 2022-06-25 22:10:35.147419
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    var_3 = None
    metaclass_transformer_1 = MetaclassTransformer(var_3)

    def func_0():
        var_4 = None
        var_5 = None
        var_6 = module_1.ClassDef(name_0='Foo', bases_0=[var_4], keywords_0=[], starargs_0=None, kwargs_0=None, body_0=[var_5], decorator_list_0=[])
        return var_6

    var_7 = None
    var_8 = func_0()
    var_9 = metaclass_transformer_1.visit_ClassDef(var_8)
    var_10 = var_9 is None
    var_11 = (var_10 is not None) and var_10
    assert var_11

# Unit

# Generated at 2022-06-25 22:10:40.392974
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'def foo(): pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)


# Generated at 2022-06-25 22:10:44.582210
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_1.parse
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'class A(metaclass=B): pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)


# Generated at 2022-06-25 22:10:51.889904
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    str_0 = 'def foo(): pass'
    var_0 = module_1.parse(str_0)
    var_1 = MetaclassTransformer(var_0)

from unittest import main
from typed_ast import ast3 as module_3
from re import match
from six import with_metaclass
from ..transformer import py_2_6_transformer as module_4
from re import compile
from ..transformer import py_2_7_transformer as module_9
from ..utils.tree import create_tree

# Tests for MetaclassTransformer

# Generated at 2022-06-25 22:10:53.392712
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_0 = None
    var_1 = MetaclassTransformer(var_0)


# Generated at 2022-06-25 22:10:59.981840
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert True

# Generated at 2022-06-25 22:11:04.300127
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'def foo(): pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)


# Generated at 2022-06-25 22:11:07.428432
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_3 = None
    var_4 = MetaclassTransformer(var_3)
    var_5 = isinstance(var_4, MetaclassTransformer)
    var_6 = isinstance(var_4, BaseNodeTransformer)


# Generated at 2022-06-25 22:11:14.458194
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'class Foo(metaclass=str):\n    pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)


# Generated at 2022-06-25 22:11:20.793234
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    metaclass_transformer_0 = MetaclassTransformer.__new__(MetaclassTransformer)
    metaclass_transformer_0.excluded = None
    metaclass_transformer_0.dependencies = None
    metaclass_transformer_0.target = None
    metaclass_transformer_0._tree_changed = False
    str_0 = 'class Foo(metaclass=object):'
    var_0 = ast.parse(str_0)
    var_1 = var_0.body[0]
    var_2 = metaclass_transformer_0.visit_ClassDef(var_1)
    str_1 = '_'

# Generated at 2022-06-25 22:11:22.542970
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_0 = None
    MetaclassTransformer(var_0)


# Generated at 2022-06-25 22:11:24.164038
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)

# Generated at 2022-06-25 22:11:27.692895
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module_1 = MetaclassTransformer()
    str_0 = 'def foo(): pass'
    var_0 = module_1.ast.parse(str_0)
    var_1 = module_1.visit_Module(var_0)


# Generated at 2022-06-25 22:11:30.193219
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    test_case_0()

if __name__ == '__main__':
    test_MetaclassTransformer()

# Generated at 2022-06-25 22:11:37.106214
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'def foo(): pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)


# Generated at 2022-06-25 22:11:53.413918
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'class A(metaclass=B): pass'
    var_1 = module_1.parse(str_0)
    var_2 = var_1.body[0]
    var_3 = metaclass_transformer_0.visit_ClassDef(var_2)


# Generated at 2022-06-25 22:11:54.622634
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_0 = None
    var_1 = MetaclassTransformer(var_0)


# Generated at 2022-06-25 22:11:56.019017
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_0 = None
    var_1 = MetaclassTransformer(var_0)


# Generated at 2022-06-25 22:12:03.637184
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'class A(metaclass=abc.ABCMeta): pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)
    str_1 = 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(abc.ABCMeta)):\n    pass'
    var_3 = module_1.dump(var_2)
    assert (var_3 == str_1)


# Generated at 2022-06-25 22:12:12.040457
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Setup
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    # Assertions
    # AssertionError: visit_ClassDef was not called for test_MetaclassTransformer_visit_ClassDef
    # assert metaclass_transformer_0.visit_ClassDef_called == 1, 'visit_ClassDef was not called for test_MetaclassTransformer_visit_ClassDef'
    var_3 = 'def foo(): pass'
    var_4 = module_1.parse(var_3)
    var_5 = metaclass_transformer_0.visit(var_4)
    var_6 = 'class Foo: pass'
    var_7 = module_1.parse(var_6)
    var_8 = metac

# Generated at 2022-06-25 22:12:13.805352
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_0 = None
    MetaclassTransformer(var_0)


# Generated at 2022-06-25 22:12:16.852491
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = (metaclass_transformer_0._module is None)
    test_case_0()

# Generated at 2022-06-25 22:12:26.334901
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'class A(metaclass=type): pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)

# Generated at 2022-06-25 22:12:33.541507
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Create a simple class and parse it with ast
    code = '''class Test:
    pass'''
    tree = ast.parse(code)

    # Apply the transformations
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    if not transformer._tree_changed:
        assert False, 'Transformation failed'
    else:
        # Check whether the metaclass was extracted properly
        # The metaclass was not specified, so we expect an error here
        exec(compile(tree, 'test', 'exec'))
        assert False, 'No error, although an error was expected'


# Generated at 2022-06-25 22:12:40.630976
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = module_1.ClassDef(name='A',  # type: ignore
                              bases=[],  # type: ignore
                              keywords=[module_1.keyword(arg='metaclass',  # type: ignore
                                                         value=module_1.Name(id='B',  # type: ignore
                                                                             ctx=module_1.Load()))],  # type: ignore
                              body=[module_1.Pass()],  # type: ignore
                              decorator_list=[])  # type: ignore
    var_2 = metaclass_transformer_0.visit_ClassDef(var_1)
    assert var_2.bases == class_bases.get_

# Generated at 2022-06-25 22:13:06.931112
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    var_0 = test_case_0()
    var_1 = 'def foo(): pass'
    var_2 = var_0.to_source()
    var_3 = (var_1 == (var_2))
    assert var_3


# Generated at 2022-06-25 22:13:12.340416
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'class Foo(metaclass=Foo): pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)
    assert type(var_2.body[0].bases[0]) == module_1.Call


# Generated at 2022-06-25 22:13:13.232110
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    test_case_0()

# Generated at 2022-06-25 22:13:14.222655
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    pass


# Generated at 2022-06-25 22:13:19.328933
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'def foo(): pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)


# Generated at 2022-06-25 22:13:27.295955
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # Found 3 tests for MetaclassTransformer.__init__
    # Test 1: Call with no argument
    try:
        MetaclassTransformer()
    except TypeError:
        pass
    else:
        assert False, 'ExpectedTypeError'
    # Test 2: Call with 1 argument
    try:
        MetaclassTransformer('foo')
    except TypeError:
        pass
    else:
        assert False, 'ExpectedTypeError'
    # Test 3: Call with a lot of arguments
    try:
        MetaclassTransformer('foo', 'bar', 'baz')
    except TypeError:
        pass
    else:
        assert False, 'ExpectedTypeError'


# Generated at 2022-06-25 22:13:30.512215
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_42 = None
    metaclass_transformer_42 = MetaclassTransformer(var_42)
    assert metaclass_transformer_42 is not None
    test_case_0()
test_MetaclassTransformer()

# Generated at 2022-06-25 22:13:34.648228
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'def foo(): pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)


# Generated at 2022-06-25 22:13:39.135008
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'def foo(): pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)


# Generated at 2022-06-25 22:13:42.648116
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'def foo(): pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)
    

# Generated at 2022-06-25 22:14:40.976490
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'def foo(): pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)


# Generated at 2022-06-25 22:14:42.818253
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_3 = None
    var_4 = MetaclassTransformer(var_3)


# Generated at 2022-06-25 22:14:47.117384
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_1.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = var_0.body[0]
    var_2 = metaclass_transformer_0.visit_ClassDef(var_1)


# Generated at 2022-06-25 22:14:48.896642
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_421 = None
    metaclass_transformer_421 = MetaclassTransformer(var_421)


# Generated at 2022-06-25 22:14:55.272158
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    print(123)

    var_0 = module_1.parse('class Foo(metaclass=int): pass')
    metaclass_transformer_0 = MetaclassTransformer(target=None, dependencies=None)
    var_1 = metaclass_transformer_0.visit(var_0)
    var_2 = metaclass_transformer_0.visit(var_0)
    var_3 = module_1.parse('class Foo(metaclass=int): pass')
    var_4 = module_1.parse('class Foo(metaclass=int): pass')

# Generated at 2022-06-25 22:14:57.397352
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    tree = ast.parse('def foo(): pass')

    transformer = MetaclassTransformer(tree)
    tree = transformer.visit(tree)
    assert transformer.warnings == transformer.errors == ()

# Generated at 2022-06-25 22:15:02.555932
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'class A(object, metaclass=type): pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)
    var_3 = metaclass_transformer_0.result()

# Generated at 2022-06-25 22:15:08.358122
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_0 = 'class A(metaclass=B): pass'
    var_1 = module_1.parse(str_0)
    var_2 = metaclass_transformer_0.visit(var_1)
    assert(var_2.body[0].bases[0].args[0].id == 'B')

# Generated at 2022-06-25 22:15:10.968954
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    assert metaclass_transformer_0 is not None


# Generated at 2022-06-25 22:15:14.440690
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    var_0 = None
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    # var_1 = ???
    # var_2 = metaclass_transformer_0.visit_Module(var_1)
    # assert var_2 == ???
