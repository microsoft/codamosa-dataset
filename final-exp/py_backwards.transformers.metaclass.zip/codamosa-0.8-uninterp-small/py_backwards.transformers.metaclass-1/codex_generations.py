

# Generated at 2022-06-25 22:07:23.699807
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_2 = metaclass_transformer_0.visit_Module(module_1)
    assert module_1 is module_2


# Generated at 2022-06-25 22:07:32.402527
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():

    test_MetaclassTransformer_visit_Module_test_0(
        arg_0=(
            module_0.Module(
                body=[]
            )
        )
    )
    test_MetaclassTransformer_visit_Module_test_1(
        arg_0=(
            module_0.Module(
                body=[
                    module_0.ClassDef(
                        name='Foo',
                        bases=[],
                        keywords=[],
                        body=[],
                        decorator_list=[]
                    ),
                    module_0.ClassDef(
                        name='Foo',
                        bases=[],
                        keywords=[],
                        body=[],
                        decorator_list=[]
                    )
                ]
            )
        )
    )


# Generated at 2022-06-25 22:07:41.347658
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    a_s_t_2 = module_0.Module()
    a_s_t_3 = module_0.ClassDef()
    a_s_t_4 = module_0.arguments()
    a_s_t_3.args = a_s_t_4
    a_s_t_5 = module_0.arg()
    a_s_t_4.args.append(a_s_t_5)
    a_s_t_5.arg = "a"
    a_s_t_2.body.append(a_s_t_3)

    a_s_t_3.decorator_list

# Generated at 2022-06-25 22:07:49.910115
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclass_transformer_0 = MetaclassTransformer(None)
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.Module(body=[])
    a_s_t_1.body.append(module_0.ClassDef(name='C', body=[], keywords=[module_0.keyword(arg='metaclass', value=module_0.Name(id='M', ctx=module_0.Load()))], decorator_list=[]))
    metaclass_transformer_0.visit_ClassDef(a_s_t_1.body[0])
    assert metaclass_transformer_0._transformed
    assert metaclass_transformer_0._tree_changed

# Generated at 2022-06-25 22:07:53.808838
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    with pytest.raises(TypeError, match='arg 1'):
        metaclass_transformer_0.visit_ClassDef()

# Generated at 2022-06-25 22:07:58.632412
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef()
    metaclass_transformer_0._target_version = (2, 7)
    metaclass_transformer_0.visit_ClassDef(classdef_0)

# Generated at 2022-06-25 22:08:07.312177
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # [classdef]
    a_s_t_1 = module_0.ClassDef()
    a_s_t_1.name = "A"
    a_s_t_1.decorator_list = []
    a_s_t_1.keywords.append(module_0.keyword(arg="metaclass", value=module_0.Name(id="B", ctx=module_0.Load())))
    a_s_t_1.bases.append(module_0.Name(id="B", ctx=module_0.Load()))

# Generated at 2022-06-25 22:08:11.618881
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module = ""
    visiting_result = metaclass_transformer_0.visit_Module(module)
    assert visiting_result == module


# Generated at 2022-06-25 22:08:22.261400
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    ast_node_0 = module_0.Module()
    ast_node_1 = module_0.ClassDef()
    ast_node_2 = module_0.Name()
    ast_node_3 = module_0.Name()
    ast_node_4 = module_0.Name()
    ast_node_2.ctx = module_0.Load()
    ast_node_2.id = 'FIXME'
    ast_node_1.name = 'FIXME'
    ast_node_1.keywords = [module_0.keyword(arg='FIXME', value=ast_node_2)]
    ast_node_1.bases = [ast_node_3]
    ast_node_1.body = [ast_node_4]
    ast_node_1.decorator_list = []
    ast

# Generated at 2022-06-25 22:08:32.658751
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    classdef_0 = module_0.ClassDef(
        name='A',
        body=[],
        decorator_list=[],
        keywords=[],
        lineno=0,
        col_offset=0
    )
    metaclass_transformer_1.visit_ClassDef(classdef_0)

from typing import Iterator
from typing import Type
from typing import TypeVar
from typing import Union
from typing import Generic
from typing import Optional
from typing import Any
from typing import cast
from typing import overload
from typing import get_type_hints
import typing
from typing import _type_vars
from typing import _promote
from typing import _

# Generated at 2022-06-25 22:08:43.509372
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    classDef_0 = module_0.ClassDef()
    metaclass_transformer_0 = MetaclassTransformer()
    metaclass_transformer_0.visit_ClassDef(classDef_0)

# Generated at 2022-06-25 22:08:52.135488
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

    class_def_1 = module_0.ClassDef(
        name='A',
        bases=[],
        keywords=[],
        body=[],
        decorator_list=[])

    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)

    assert class_def_1 is class_def_2


# Generated at 2022-06-25 22:08:57.623602
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = module_0.ClassDef(name='A', bases=[], keywords=[], body=[], decorator_list=[])
    metaclass_transformer_0.visit(class_def_1)
    print('Done')

# Generated at 2022-06-25 22:09:04.332939
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    sample_0 = \
        module_0.ClassDef(name='MyClass', bases=[], keywords=[], 
            body=[], decorator_list=[])
    sample_1 = \
        module_0.ClassDef(name='MyClass', bases=[], keywords=[
            module_0.keyword(arg='metaclass', value=module_0.Name(id='MyMeta', ctx=module_0.Load()))], body=[], 
            decorator_list=[])

# Generated at 2022-06-25 22:09:12.734907
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .modulenode import Module
    from .classnode import Class
    from .functionnode import Function
    from .argument import Argument
    from .decorator import Decorator
    from .unaryoperator import UnaryOperator
    from .num import Num
    from .str import Str
    from .name import Name
    from .keyword import Keyword
    from .subscript import Subscript
    from .expr import Expr
    from .int import Int
    from .tuple import Tuple

# Generated at 2022-06-25 22:09:19.305679
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_1 = module_0.ClassDef(name='asd',
                                   bases=[],
                                   keywords=[],
                                   body=[],
                                   decorator_list=[])
    result_0 = metaclass_transformer_0.visit_ClassDef(classdef_1)




# Generated at 2022-06-25 22:09:29.018959
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_0.body = [module_0.ClassDef(
        name='A',
        keywords=[module_0.keyword(
            arg='metaclass',
            value=module_0.Name(
                id='B',
                ctx=module_0.Load()
            )
        )],
        bases=[],
        body=[module_0.Pass()],
        decorator_list=[]
    )]
    a_s_t_1 = module_0.AST()

# Generated at 2022-06-25 22:09:39.304337
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_0 = module_0.ClassDef()
    a_0.body = [module_0.Pass()]
    a_0.bases = []
    a_0.decorator_list = []
    a_0.keywords = [module_0.keyword(arg='metaclass', value=module_0.NameConstant(value=None))]
    a_0.name = 'A'
    a_0.lineno = 1
    a_0.col_offset = 0
    result = metaclass_transformer_0.visit_ClassDef(a_0)
    assert len(result.bases) == 2
   

# Generated at 2022-06-25 22:09:49.053700
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # TODO: refactor?

    class Statement(Enum):
        NORMAL = 1
        EXCEPT = 2
        FINALLY = 3
        ELSE = 4
        TRY_FINALLY = 5
        WITH = 6

    def visit_module(node):
        # type: (ast.Module) -> ModuleData
        data = ModuleData()

        for child in node.body:
            data.accumulate(visit(child))
        return data

    def visit_try(node, state=Statement.NORMAL):
        # type: (ast.Try, Statement) -> ModuleData
        data = ModuleData()
        data.accumulate(visit_all(node.body, state))
        for handler in node.handlers:
            data.accumulate(visit(handler))

# Generated at 2022-06-25 22:09:57.861329
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    import ast
    import astor
    l_0 = ast.LineBlock(l_0=ast.LineNumber(n=1))
    l_1 = ast.LineBlock(l_0=ast.LineNumber(n=2))
    l_2 = ast.LineBlock(l_0=ast.LineNumber(n=3))
    l_3 = ast.LineBlock(l_0=ast.LineNumber(n=4))
    l_4 = ast.LineBlock(l_0=ast.LineNumber(n=5))
    l_5 = ast.LineBlock(l_0=ast.LineNumber(n=6))
    l_6 = ast.LineBlock(l_0=ast.LineNumber(n=7))
    l_7 = ast

# Generated at 2022-06-25 22:10:09.007627
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)


# Generated at 2022-06-25 22:10:12.451946
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:10:13.827198
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    pass_ = True
    if pass_:
        print("passed")


# Generated at 2022-06-25 22:10:22.827211
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    try:
        test_case_0()
    except Exception as inst:
        if hasattr(inst, '__name__'):
            if inst.__name__ == "NameError":
                raise Exception("UnboundLocalError")
            elif inst.__name__ == "AssertionError":
                raise Exception("AssertionError")
            elif inst.__name__ == "AttributeError":
                raise Exception("AttributeError")
            elif inst.__name__ == "TypeError":
                raise Exception("TypeError")
            elif inst.__name__ == "KeyError":
                raise Exception("KeyError")
        else:
            print(type(inst))
            print(inst)
            print(inst.args)
            print(inst.args[0])
            print(type(inst.args))

# Generated at 2022-06-25 22:10:27.873838
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert class_def_1 is None
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)
    class_def_2 = None
    class_def_3 = metaclass_transformer_1.visit_ClassDef(class_def_2)
    assert class_def_3 is None
    metaclass_transformer_2 = MetaclassTransformer(a_s_t_0)
    class_def_4 = None
    class_

# Generated at 2022-06-25 22:10:32.950410
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)



# Generated at 2022-06-25 22:10:34.347578
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    pass

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:10:41.359945
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Setup
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

    # Test
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

    # Verify
    assert class_def_1 is class_def_0
    assert isinstance(class_def_1, ast.ClassDef)


# Generated at 2022-06-25 22:10:42.479557
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = test_case_0()


# Generated at 2022-06-25 22:10:47.025309
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:11:01.342867
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_2 = None
    metaclass_transformer_2 = MetaclassTransformer(a_s_t_0)
    class_def_3 = metaclass_transformer_2.visit_ClassDef(class_def_2)
    metaclass_transformer_3 = MetaclassTransformer(a_s_t_0)
    assert(class_def_3 is None)


# Generated at 2022-06-25 22:11:09.663813
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert class_def_1 is None
    class_def_2 = module_0.ClassDef(
        name='A',
        args=module_0.arguments(args=[], vararg=None, kwarg=None, defaults=[]),
        body=[],
        decorator_list=[],
        keywords=[
            module_0.keyword(arg='metaclass', value=module_0.Name(id='B', ctx=module_0.Load()))
        ])
    metac

# Generated at 2022-06-25 22:11:19.399927
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


if __name__ == '__main__':
    import os
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + '/..')
    from tests.run_tests import run_tests
    run_tests(__file__)

# Generated at 2022-06-25 22:11:23.244798
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)
    module_1 = metaclass_transformer_1.visit(module_0)

if __name__ == '__main__':
    test_case_0()
    test_MetaclassTransformer_visit_ClassDef()

# Generated at 2022-06-25 22:11:26.636347
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    metaclass_transformer_0 = MetaclassTransformer(None)
    metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:11:27.470695
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_1 = typi

# Generated at 2022-06-25 22:11:30.504259
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:11:39.646231
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_1 = module_0.AST()
    class_def_2 = None
    metaclass_transformer_2 = MetaclassTransformer(a_s_t_1)
    class_def_3 = metaclass_transformer_2.visit_ClassDef(class_def_2)
    metaclass_transformer_3 = MetaclassTransformer(a_s_t_1)
    class_def_4 = metaclass_transformer_3.visit_ClassDef(class_def_3)


# Generated at 2022-06-25 22:11:41.951165
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert hasattr(MetaclassTransformer, 'visit_ClassDef')
    assert callable(getattr(MetaclassTransformer, 'visit_ClassDef'))

# Generated at 2022-06-25 22:11:46.935585
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    try:
        class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    except Exception:
        assert False


# Generated at 2022-06-25 22:12:07.269549
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:12:12.014154
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert class_def_1 is class_def_0


# Generated at 2022-06-25 22:12:16.349198
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Raise exception if not subclass
    class RaisingMeta(type):
        def __instancecheck__(self, instance):
            raise Exception("Invalid class type")
    class A(metaclass=RaisingMeta):
        pass

    a_s_t_0 = module_0.AST()

# Generated at 2022-06-25 22:12:19.876084
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:12:24.479385
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:12:29.957833
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)

# Generated at 2022-06-25 22:12:38.179678
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)

if __name__ == '__main__':
    import sys

    test_names = [
        'test_case_0',
        'test_MetaclassTransformer_visit_ClassDef',
    ]


# Generated at 2022-06-25 22:12:43.059159
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)



# Generated at 2022-06-25 22:12:47.220432
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None

    # TEST START
    with pytest.raises(NotImplementedError):
        metaclass_transformer_0 = MetaclassTransformer(a_s_t_0).visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:12:55.972056
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    from typed_ast import ast3 as ast

    a_s_t = ast.AST()

    metaclass = ast.Name(id='A')

    class_def = ast.ClassDef(
        name='C',
        bases=[ast.Name(id='B')],
        keywords=[ast.keyword(arg='metaclass', value=metaclass)],
        body=[],
        decorator_list=[]
    )

    metaclass_transformer = MetaclassTransformer(a_s_t)
    new_class_def = metaclass_transformer.visit_ClassDef(class_def)
    print(new_class_def)

    from six import with_metaclass as _py_backwards_six_withmetaclass

# Generated at 2022-06-25 22:13:40.368856
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert type(class_def_1) == module_0.Assign
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)
    class_def_2 = metaclass_transformer_1.visit_ClassDef(class_def_0)
    assert type(class_def_2) == module_0.Assign
    class_def_3 = None

# Generated at 2022-06-25 22:13:42.321564
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-25 22:13:47.527256
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)


import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:13:52.495127
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert isinstance(class_def_1, module_0.ClassDef)
    assert class_def_1.keywords == []
    assert class_def_1.decorator_lis

# Generated at 2022-06-25 22:13:55.923321
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:14:00.776738
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)


# Generated at 2022-06-25 22:14:03.548203
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node_0 = None
    metaclass_transformer_2 = MetaclassTransformer(None)
    class_def_2 = metaclass_transformer_2.visit_ClassDef(node_0)


# Generated at 2022-06-25 22:14:05.060039
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    pass  # FIXME: implement your test here

# Generated at 2022-06-25 22:14:12.652518
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    try:
        class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    except Exception as raised_exception_0:
        print('Exception when calling MetaclassTransformer.visit_ClassDef with parameters:\n\tclass_def: {}, \nraised exception:\n{}'.format(class_def_0, raised_exception_0))
    else:
        print('No exception when calling MetaclassTransformer.visit_ClassDef with parameters:\n\tclass_def: {}'.format(class_def_0))


# Generated at 2022-06-25 22:14:16.171564
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    method_name = 'visit_ClassDef'
    class_name = 'MetaclassTransformer'
    unit_test_name = '{}.{}'.format(class_name, method_name)
    print('Running {}...'.format(unit_test_name))

    test_case_0()
    print('Done')

# Generated at 2022-06-25 22:15:40.109661
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)


# Generated at 2022-06-25 22:15:40.998100
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()

# Unit tests for class MetaclassTransformer

# Generated at 2022-06-25 22:15:50.998939
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0_0 = module_0.Module()
    metaclass_0 = module_0.NameConstant(None)
    module_0_0.body.append(metaclass_0)
    class_def_0 = module_0.ClassDef(name='A', body=[], bases=[], keywords=[], decorator_list=[])
    module_0_0.body.append(class_def_0)
    a_s_t_0 = module_0.AST()
    class_def_1 = class_def_0.body
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1) # This should raise a TypeError


# Generated at 2022-06-25 22:15:56.005623
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert not hasattr(class_def_1, 'keywords')

# Generated at 2022-06-25 22:15:58.949616
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:16:07.114811
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    stmt_0 = module_0.Module(body=[], type_ignores=[])
    class_def_0 = module_0.ClassDef(name='A', bases=[], keywords=[], body=[], decorator_list=[])
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = metaclass_transformer_0.visit_Module(stmt_0)
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_1.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:16:10.424354
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:16:15.110628
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    try:
        class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    except Exception as returned:
        raised = returned
    assert raised is None

import typing as module_2


# Generated at 2022-06-25 22:16:15.900069
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()

# Generated at 2022-06-25 22:16:20.684140
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)
