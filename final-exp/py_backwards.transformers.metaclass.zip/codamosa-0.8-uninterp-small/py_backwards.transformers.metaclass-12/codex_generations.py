

# Generated at 2022-06-25 22:07:33.004355
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_1.body = [ module_0.FunctionDef(name='a', args=module_0.arguments(args=[]), body=[module_0.Return(value=None)], decorator_list=[], returns=None), module_0.ClassDef(name='b', bases=[], keywords=[], body=[], decorator_list=[]) ]
    module_0_value_0 = metaclass_transformer_0.visit_Module(module_1)
    print(module_0_value_0.body)


# Generated at 2022-06-25 22:07:35.877884
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module_0_0 = module_0.Module()

    metaclass_transformer_0 = MetaclassTransformer(module_0_0)
    metaclass_transformer_0.visit(module_0_0)


# Generated at 2022-06-25 22:07:41.185333
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    node_0 = module_0.Module()
    module_0.Module()
    node_0.body = []
    module_0.Module()
    result_0 = metaclass_transformer_0.visit_Module(node_0)


# Generated at 2022-06-25 22:07:50.088923
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef(name='', bases=[], keywords=[], starargs=None, kwargs=None, decorator_list=[], body=[])
    result_0 = metaclass_transformer_0.visit_ClassDef(class_def_0)

    assert result_0 == class_def_0

    class_def_0 = module_0.ClassDef(name='', bases=[], keywords=[module_0.keyword(arg='', value='')], starargs=None, kwargs=None, decorator_list=[], body=[])
    result_0 = metaclass_transformer_0.visit_

# Generated at 2022-06-25 22:07:56.517282
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    class_def_0 = module_0.ClassDef(name='A', bases=[], keywords=[module_0.keyword(arg='metaclass', value=module_0.Name(id='B', ctx=module_0.Load()))], body=[], decorator_list=[])
    assert metaclass_transformer_1.visit_ClassDef(class_def_0) is None


# Generated at 2022-06-25 22:08:05.501772
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    l_g_0 = module_0.Module([])
    l_g_1 = module_0.ClassDef()
    l_g_2 = module_0.Call()
    l_g_3 = module_0.Name(id="Foo")
    l_g_4 = module_0.List(elts=[])
    l_g_5 = module_0.Name(id="Bar")
    l_g_6 = module_0.NameConstant(value="True")
    l_g_7 = module_0.Name(id="baz")
    l_g_8 = module_0.NameConstant(value="False")
    l_g_9 = module_0.Name(id="quux")

# Generated at 2022-06-25 22:08:14.958129
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    # Class node, no keywords
    a_s_t_2 = module_0.ClassDef(name='A', bases=[], keywords=[], body=[module_0.Pass()], decorator_list=[module_0.Name(id='abc', ctx=module_0.Load())])
    a_s_t_3 = metaclass_transformer_1.visit_ClassDef(node=a_s_t_2)
    assert isinstance(a_s_t_3, module_0.ClassDef)
    assert a_s_t_3.keywords == []

# Generated at 2022-06-25 22:08:19.463864
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_2 = metaclass_transformer_0.visit_Module(module_1)


# Generated at 2022-06-25 22:08:24.256262
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.Module()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    assert metaclass_transformer_0 is not None


# Generated at 2022-06-25 22:08:31.368987
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_0 = module_0.ClassDef()
    module_0.Module(body=[class_0])
    class_0.__class__ = module_0.ClassDef
    assert metaclass_transformer_0.visit_Module(module_0.Module(body=[class_0])) == module_0.Module(body=[class_0])


# Generated at 2022-06-25 22:08:37.527046
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = module_0.Module(body=[])
    metaclass_transformer_0.visit_Module(module_1)
    assert metaclass_transformer_0._tree_changed == False


# Generated at 2022-06-25 22:08:46.341373
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from types import ModuleType
    from typed_ast import ast3 as module_ast3, ast27 as module_ast27
    for sub_module in (module_ast27, module_ast3):
        module_type_0 = ModuleType(sub_module.__name__)
        module_type_0.__package__ = sub_module.__package__
        module_type_0.__file__ = sub_module.__file__
        module_type_0.__loader__ = sub_module.__loader__
        module_type_0.__spec__ = sub_module.__spec__
        module_type_0.__cached__ = sub_module.__cached__
        module_type_0.__doc__ = sub_module.__doc__
        module_type_0.__initializing__ = True
        module_

# Generated at 2022-06-25 22:08:50.536296
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

    module_1 = module_0.Module(body=[])
    metaclass_transformer_0.visit_Module(module_1)


# Generated at 2022-06-25 22:09:00.020920
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = module_0.ClassDef(name='A', bases=[], keywords=[module_0.keyword(arg='metaclass', value=module_0.Name(id='B', ctx=module_0.Load()))], body=[module_0.Pass()])

# Generated at 2022-06-25 22:09:09.692444
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_ast_0 = module_0.Module()
    module_ast_1 = metaclass_transformer_0.visit_Module(module_ast_0)

# Generated at 2022-06-25 22:09:14.553623
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    node_0 = module_0.Module(body=[])
    metaclass_transformer_0.visit_Module(node_0)


# Generated at 2022-06-25 22:09:23.076125
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_0_0 = module_0.Module([])
    module_0.Module()
    return_value_0 = metaclass_transformer_0.visit_Module(module_0_0)
    return_value_0 = return_value_0
    assert (isinstance(return_value_0, module_0.Module))


# Generated at 2022-06-25 22:09:30.492871
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = module_0.ClassDef()
    a_s_t_2 = module_0.Name()
    a_s_t_2._id = "B"
    a_s_t_3 = module_0.Keyword()
    a_s_t_3.arg = "metaclass"
    a_s_t_3.value = a_s_t_2
    a_s_t_2 = []
    a_s_t_2.append(a_s_t_3)
    a_s_t_1.keywords = a_s_t_2
    a_s_t

# Generated at 2022-06-25 22:09:35.674245
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module()
    metaclass_transformer_0.visit_Module(a_s_t_1)


# Generated at 2022-06-25 22:09:41.762234
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_0.ClassDef(name='', bases=[], keywords=[], body=[], decorator_list=[], lineno=0, col_offset=0)
    module_0.ClassDef(name='', bases=[], keywords=[module_0.keyword(arg='', value='')], body=[], decorator_list=[], lineno=0, col_offset=0)

# Generated at 2022-06-25 22:09:50.098719
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:09:58.857671
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_0_comp_0 = "class Kls(metaclass=type):\n    pass"
    module_0_source_0 = module_0.parse(module_0_comp_0)
    module_0_source_1 = module_0.parse(six_import.get_text())
    module_0_source_2 = module_0.parse(class_bases.get_text())
    module_0_source_3 = module_0.Module(body=[module_0_source_1, module_0_source_2, module_0_source_0])
    module_0_source_4 = module_0_source_3


# Generated at 2022-06-25 22:10:08.115754
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
  a_s_t_0 = module_0.AST()
  metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
  classdef_0 = module_0.ClassDef(name = 'name0', body = module_0.Expr(value = module_0.Num(n = 0)), decorator_list = [], keywords = [module_0.keyword(arg = 'arg0', value = module_0.Expr(value = module_0.Num(n = 0)))])
  classdef_0 = metaclass_transformer_0.visit_ClassDef(classdef_0)


# Generated at 2022-06-25 22:10:16.017048
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    token_0 = module_0.Name(id='int', ctx=module_0.Load())
    keyword_0 = module_0.keyword(arg='metaclass', value=token_0)
    a_s_t_0 = module_0.ClassDef(name='A', keywords=[keyword_0], decorator_list=[], body=[], lineno=1, col_offset=0)
    metaclass_transformer_0.visit(a_s_t_0)

# Generated at 2022-06-25 22:10:21.422676
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    a_s_t_2 = module_0.AST()
    random_order_0 = a_s_t_2.parse("""
        class A(object):
            pass
    """).body
    metaclass_transformer_1.visit(random_order_0[0])


# Generated at 2022-06-25 22:10:27.190612
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Generate input...
    line_1 = 'class Foo(metaclass=Bar):'
    file_contents_0 = line_1 + '\n\n'
    # Parse file
    a_s_t_0 = ast.parse(file_contents_0)
    a_s_t_1 = copy.deepcopy(a_s_t_0)
    # Create instance of class to be tested
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # Produce output...
    metaclass_transformer_0.visit(a_s_t_0)
    # Write output to file and compare with expected output
    file_name_0 = 'tests/out/test_MetaclassTransformer_visit_ClassDef_0.txt'

# Generated at 2022-06-25 22:10:38.709489
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

# Generated at 2022-06-25 22:10:46.379454
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    import typed_ast._ast3 as module_1
    arg_0 = module_1.Module(body=[])
    metaclass_transformer_1 = metaclass_transformer_0.visit_Module(arg_0)
    module_0_body_0 = (metaclass_transformer_0._transformer[-1].body[-1])
    module_0_body_1 = (module_0_body_0.elts[0])
    module_0_body_2 = (module_0_body_1.value)

# Generated at 2022-06-25 22:10:48.748215
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)


# Generated at 2022-06-25 22:10:58.031885
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    string_repr_0 = "<class 'typed_ast._ast3.Module'>"
    assert repr(module_0.Module) == string_repr_0
    module_1 = module_0.Module()
    module_1.body = [module_0.ClassDef(
        name='A',
        bases=[module_0.Name(id=None, ctx=None)],
        keywords=[module_0.keyword(arg=None, value=module_0.Name(
            id=None, ctx=None))],
        body=None,
        decorator_list=None)
    ]

# Generated at 2022-06-25 22:11:17.261343
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    ast.Module(body=[])
    metaclass_transformer_0.visit(ast.Module(body=[]))
    'class foo(metaclass=bar): pass'
    metaclass_transformer_0.visit(ast.ClassDef(name='foo', bases=[], keywords=[], body=[], decorator_list=[]))
    'class foo(metaclass=bar): pass'
    metaclass_transformer_0.visit(ast.ClassDef(name='foo', bases=[ast.Name(id='bar', ctx=ast.Load())], keywords=[], body=[], decorator_list=[]))

# Generated at 2022-06-25 22:11:26.510228
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = module_0.ClassDef('A', [], [], [], [])
    a_s_t_2 = module_0.Name('B')
    a_s_t_3 = module_0.Keyword('metaclass', a_s_t_2)
    try:
        a_s_t_4 = metaclass_transformer_0.visit_ClassDef(a_s_t_1)
    except TypeError as raised_exc:
        exc_info_0 = sys.exc_info()

# Generated at 2022-06-25 22:11:35.245256
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = module_0.ClassDef()
    a_s_t_1.name = "A"
    a_s_t_1.bases = [module_0.Name()]
    a_s_t_1.keywords = [module_0.keyword()]
    a_s_t_1.bases[0].id = "B"
    a_s_t_1.keywords[0].arg = "metaclass"
    a_s_t_1.keywords[0].value = module_0.Name()

# Generated at 2022-06-25 22:11:36.451632
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    pass


# Generated at 2022-06-25 22:11:45.284025
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    a_s_t_0 = ast.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

    a_s_t_1 = ast.AST()
    body_0 = [
        ast.ClassDef(name='A',
                     bases=[],
                     keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
                     body=[],
                     decorator_list=[]),
    ]
    module_0 = ast.Module(body=body_0)

    a_s_t_2 = ast.AST()

# Generated at 2022-06-25 22:11:47.855942
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer()
    module_1 = metaclass_transformer_0._generic_visit()

# Generated at 2022-06-25 22:11:55.338412
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    
    
    a_s_t_1 = module_0.ClassDef() # type: module_0.ClassDef
    metaclass_kwarg_0 = module_0.keyword() # type: module_0.keyword
    metaclass_kwarg_0.arg = 'metaclass'
    metaclass_kwarg_0.value = module_0.Name() # type: module_0.Name
    metaclass_kwarg_0.value.id = 'object'
    a_s_t_1.keywords = [metaclass_kwarg_0]
    
    result_0 = metaclass_transformer_0

# Generated at 2022-06-25 22:11:57.363273
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)


# Generated at 2022-06-25 22:12:01.288145
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    metaclass_transformer_0.visit_ClassDef(class_def_0)
    return metaclass_transformer_0

# Generated at 2022-06-25 22:12:04.881327
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    test_case_0()

if __name__ == '__main__':
    test_MetaclassTransformer_visit_ClassDef()

# Generated at 2022-06-25 22:12:18.863226
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    try:
        class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    except:
        pass


# Generated at 2022-06-25 22:12:26.257168
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_a_s_t_0 = None
    class_def_a_s_t_1 = metaclass_transformer_0.visit_ClassDef(class_def_a_s_t_0)

if __name__ == "__main__":
    test_case_0()
    test_MetaclassTransformer_visit_ClassDef()

# Generated at 2022-06-25 22:12:32.160323
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_Module(module_x_var_0)
    class_x_var_0 = None
    metaclass_transformer_0.visit_ClassDef(class_x_var_0)


# Generated at 2022-06-25 22:12:35.849661
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:12:41.694856
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_Module(module_x_var_0)
    module_x_var_1 = None
    class_def_0 = module_0.ClassDef()
    class_def_0.name = 'A'
    module_x_var_2 = ['B']
    module_x_var_3 = module_0.Name()
    module_x_var_3.id = 'B'
    module_x_var_3.ctx = module_0.Load()
    module_x_var_2[0] = module_x_var_3
    module

# Generated at 2022-06-25 22:12:45.996026
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:12:47.143488
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0.ClassDef()

# Generated at 2022-06-25 22:12:53.135723
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = a_s_t_0.ClassDef(name='A', bases=[], keywords=[], body=[], decorator_list=[])
    class_def_var_0 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:12:57.235174
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast._ast3 as module_0
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_ClassDef(module_x_var_0)


# Generated at 2022-06-25 22:13:01.538370
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_s_t_0 = None
    metaclass_transformer_0.visit_ClassDef(class_def_s_t_0)

# Generated at 2022-06-25 22:13:24.580920
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    module_x_var_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:13:31.045979
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from . import MetaclassTransformer
    module_0 = None
    a_s_t_0 = ast.AST()
    metaclass_transformer_0 = MetaclassTransformer.MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_ClassDef(module_0)

# Generated at 2022-06-25 22:13:35.847015
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = None
    assert_equal(metaclass_transformer_0.visit_ClassDef(classdef_0) is None, True)


# Generated at 2022-06-25 22:13:40.328426
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_ClassDef(module_x_var_0)

# Generated at 2022-06-25 22:13:44.044362
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_ClassDef(module_x_var_0)

# Generated at 2022-06-25 22:13:47.768802
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    module_x_var_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:13:51.856421
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = None
    module_x_var_1 =\
            metaclass_transformer_0.visit_ClassDef(classdef_0)


# Generated at 2022-06-25 22:13:55.622817
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    module_x_var_0 = None
    metaclass_transformer_1 = MetaclassTransformer()
    module_x_var_1 = metaclass_transformer_1.visit_ClassDef(module_x_var_0)

test_MetaclassTransformer_visit_ClassDef()


# Generated at 2022-06-25 22:14:01.559984
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    try:
        class_def_x_var_0 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    except:
        class_def_x_var_0 = None
    assert class_def_x_var_0 is None


# Generated at 2022-06-25 22:14:07.052220
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef(name='', bases=[], keywords=[], body=[], decorator_list=[])
    module_x_var_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:14:47.768776
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:14:52.888360
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    module_x_var_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert type(module_x_var_1) is module_0.ClassDef

# Generated at 2022-06-25 22:14:53.710450
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    pass


# Generated at 2022-06-25 22:15:01.064942
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-25 22:15:06.532784
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_x_var_0
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:15:14.914228
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef(name="A", bases=[], keywords=[], body=[module_0.Pass()], decorator_list=[])
    module_x_var_1 = metaclass_transformer_0.visit_ClassDef(classdef_0)

# Generated at 2022-06-25 22:15:26.122326
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0.AST()
    MetaclassTransformer(module_0.AST())
    class_def_0 = module_0.ClassDef(name="A",
                                    bases=[
                                        module_0.Name(id='object', ctx=module_0.Load())
                                    ],
                                    keywords=[
                                        module_0.keyword(arg='metaclass',
                                                         value=module_0.Name(id='B', ctx=module_0.Load()))
                                    ],
                                    body=[
                                    ],
                                    decorator_list=[
                                    ])
    metaclass_transformer_0 = MetaclassTransformer(module_0.AST())
    class_def_0 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:15:30.787355
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    module_x_var_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:15:37.739375
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)
    
    assert module_x_var_1 == None, "Expected: {}, Actual: {}".format(None, assert_var_1)

# Generated at 2022-06-25 22:15:41.435414
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    # Assigning value to a variable
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # Method call to visit_ClassDef with arguments
    module_x_var_1 = metaclass_transformer_0.visit_ClassDef(module_x_var_0)

# Generated at 2022-06-25 22:17:15.619915
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:17:18.420197
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_1 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_ClassDef(module_x_var_1)


# Generated at 2022-06-25 22:17:22.585874
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    module_x_var_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    module_x_var_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)