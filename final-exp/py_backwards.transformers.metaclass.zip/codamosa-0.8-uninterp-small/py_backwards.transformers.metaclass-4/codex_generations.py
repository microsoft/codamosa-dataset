

# Generated at 2022-06-25 22:07:26.587217
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_0 = None
    metaclass_transformer_0.visit_Module(module_0)


# Generated at 2022-06-25 22:07:34.964539
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = None

# Generated at 2022-06-25 22:07:39.193595
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = ast.Module(body=[ast.ClassDef(name='A')])
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_ClassDef(a_s_t_0.body[0])


# Generated at 2022-06-25 22:07:45.075240
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = None
    try:
        assert_equal(metaclass_transformer_0.visit_ClassDef(a_s_t_1), None)
        #assert_equal(metaclass_transformer_0._tree_changed, False)
    except:
        raise AssertionError()


# Generated at 2022-06-25 22:07:50.329241
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    sample_file_0 = "tests/samples/2.7/metaclass.py"
    a_s_t_0 = ast.parse(open(sample_file_0, 'r').read())
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    assert metaclass_transformer_0.visit_ClassDef(a_s_t_0)


# Generated at 2022-06-25 22:07:57.459601
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

    # Test 1: Calling without parameters
    # Expecting Exception because not all
    # required parameters are provided
    with pytest.raises(Exception):
        metaclass_transformer_0.visit_ClassDef()

    # Test 2: Calling with parameters x#1 of type AST
    # Expecting No exceptions to be thrown
    x#1 = None

# Generated at 2022-06-25 22:08:01.814753
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Setup
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    node = None
    expected_result = None

    # Invocation
    result = metaclass_transformer_0.visit_Module(node)

    # Verification
    assert result is None


# Generated at 2022-06-25 22:08:07.388899
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    cls = (2, 7)
    mod = Module(body=[ImportFrom(module='six',
                                  names=[alias(name='with_metaclass',
                                               asname='_py_backwards_six_withmetaclass')],
                                  level=0)])
    a = MetaclassTransformer(mod)

    assert a.visit_Module(mod).body[0] == mod.body[0]
    assert a.dependencies == ['six']



# Generated at 2022-06-25 22:08:13.728475
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    # Setup:
    a_s_t_0 = ast.parse('class A(B): pass')

    # Exercise:
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = metaclass_transformer_0.visit_ClassDef(a_s_t_0.body[0])

    # Verify:
    assert isinstance(a_s_t_1.body[0], ast.ClassDef)



# Generated at 2022-06-25 22:08:16.810807
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_1 = ast.parse("class A:\n    pass")
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)



# Generated at 2022-06-25 22:08:30.174715
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = None
    char_0 = chr(97)
    str_0 = str(char_0)
    name_1 = str_0
    a_s_t_2 = None
    a_s_t_3 = []
    list_0 = [a_s_t_2]
    ast_list_0 = ast.List(elts=list_0)
    keyword_0 = ast.keyword(arg=None, value=ast_list_0)
    keywords_0 = [keyword_0]

# Generated at 2022-06-25 22:08:33.207066
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node_0 = None
    metaclass_transformer_0 = MetaclassTransformer(node_0)
    assert metaclass_transformer_0.visit_Module(node_0) is None


# Generated at 2022-06-25 22:08:39.091818
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
  module_0 = Module(body = [ClassDef(name = 'A', body = [], decorator_list = [], keywords = [], starargs = None, kwargs = None)])
  metaclass_transformer_0 = MetaclassTransformer(module_0)
  classdef_0 = ClassDef(name='A', body=[], decorator_list=[], keywords=[], starargs=None, kwargs=None)
  expected_0 = ClassDef(name='A', body=[], decorator_list=[], keywords=[], starargs=None, kwargs=None)

  assert(metaclass_transformer_0.visit_ClassDef(classdef_0) == expected_0)

# Generated at 2022-06-25 22:08:43.467621
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    obj_0 = MetaclassTransformer()
    ast_literal_0 = ast.parse("class A(metaclass=B): pass")
    ast_literal_0 = ast_literal_0.body[0]
    obj_0.visit(ast_literal_0)

# Generated at 2022-06-25 22:08:52.097401
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = ast.Module(body=[])
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_Module(a_s_t_0)
    assert len(a_s_t_0.body) > 0
    assert isinstance(a_s_t_0.body[0], ast.ImportFrom)
    assert a_s_t_0.body[0].module == 'six'
    assert len(a_s_t_0.body[0].names) > 0
    assert a_s_t_0.body[0].names[0].name == 'with_metaclass'

# Generated at 2022-06-25 22:09:01.365759
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typing
    import ast
    class_def_0 = ast.ClassDef(name="A",
                               bases=[],
                               body=[],
                               decorator_list=[],
                               keywords=[ast.keyword(arg="metaclass",
                                                      value=ast.Name(id="B",
                                                                     ctx=ast.Load()))])

# Generated at 2022-06-25 22:09:02.256969
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()

# Generated at 2022-06-25 22:09:03.389519
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert True


# Generated at 2022-06-25 22:09:12.148469
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import sys
    import six
    metaclass_transformer_0 = MetaclassTransformer(None)
    ast_Module_0 = ast.Module(body=[ast.ClassDef(name='A', bases=[ast.Name(id='B', ctx=ast.Load())], keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='C', ctx=ast.Load()))], body=[], decorator_list=[])])
    body = ast_Module_0.body
    # if node.keywords:
    if len(body[0].keywords) > 0:
        metaclass = body[0].keywords[0].value
        # node.bases = class_bases.get_body(metaclass=metaclass,  # type: ignore
        ast_List

# Generated at 2022-06-25 22:09:21.069273
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = None
    a_s_t_2 = None
    a_s_t_3 = None
    a_s_t_4 = None
    a_s_t_5 = None
    a_s_t_6 = None
    a_s_t_7 = None
    a_s_t_8 = None
    a_s_t_9 = None
    a_s_t_10 = None
    a_s_t_11 = None
    a_s_t_12 = None
    a_s_t_13 = None
    a_s_t_14 = None

# Generated at 2022-06-25 22:09:34.754422
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    str_0 = ''
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_0.body.append(module_0.Expr(value=module_0.Name(id='', ctx=module_0.Load())))
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)
    module_1 = metaclass_transformer_1.visit_Module(module_x_var_0)
    classdef_0 = module_0.ClassDef

# Generated at 2022-06-25 22:09:44.443677
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = ast.Module()
    class_0 = ast.ClassDef(body=[ast.Pass()], keywords=[
        ast.keyword(
            arg='metaclass',
            value=ast.Name(
                id='arg',  # type: ignore
                ctx=(ast.Load())))],
        name='a',
        bases=[])
    module_1 = MetaclassTransformer(module_0).visit_ClassDef(class_0)

# Generated at 2022-06-25 22:09:46.975111
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    str_0 = 'urllib.request'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:09:51.226978
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    str_0 = 'urllib.request'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_var_0 = module_0.ClassDef()
    classdef_x_var_0 = metaclass_transformer_0.visit_ClassDef(classdef_var_0)


# Generated at 2022-06-25 22:09:52.229311
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()


# Generated at 2022-06-25 22:09:58.748578
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    class_def_0 = module_0.ClassDef(name='A', lineno=1, col_offset=0, end_lineno=1, end_col_offset=0, decorator_list=[], keywords=[], body=[], bases=[], starargs=None, kwargs=None)
    metaclass_transformer_0 = MetaclassTransformer(module_x_var_0)
    module_x_var_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:10:09.856132
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = __import__('typed_ast._ast3', fromlist=['typed_ast._ast3'])
    module_0 = module_0._ast3
    module_x_var_0 = module_0.Module()
    module_x_var_1 = module_0.ClassDef()
    module_x_var_1 = module_x_var_0.body
    module_x_var_1.append(module_x_var_1)
    str_0 = 'typed_ast._ast3'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)


# Generated at 2022-06-25 22:10:17.488936
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    str_0 = 'urllib.request'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)
    class_def_var_0 = module_0.ClassDef(name='A')
    class_def_var_1 = metaclass_transformer_1.visit_ClassDef(class_def_var_0)


# Generated at 2022-06-25 22:10:25.262810
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    str_0 = 'urllib.request'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef('ClassDef')
    list_0 = [module_0.ClassDef('ClassDef')]
    list_1 = [module_0.ClassDef('ClassDef')]
    list_2 = [module_0.ClassDef('ClassDef')]
    list_3 = [module_0.ClassDef('ClassDef')]

# Generated at 2022-06-25 22:10:35.329970
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast._ast3 as module_0
    str_0 = 'Argument'
    str_1 = 'Keyword'
    int_0 = 0
    str_2 = 'metaclass'
    a_s_t_0 = module_0.AST()
    metaclass_2 = module_0.Name(id=str_2, ctx=module_0.Load())
    metaclass_5 = module_0.Name(id=str_2, ctx=module_0.Load())
    metaclass_3 = module_0.Call(func=metaclass_5, args=[], keywords=[])
    metaclass_1 = module_0.Name(id=str_2, ctx=module_0.Load())

# Generated at 2022-06-25 22:10:45.578597
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_2 = module_0.Module()
    str_1 = 'urllib.request'
    dict_1 = {str_1: str_1, str_1: str_1}
    a_s_t_1 = module_0.AST(**dict_1)
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    classdef_0 = module_0.ClassDef(name='A', bases=[], keywords=[], body=[], decorator_list=[])
    module_x_var_3 = metaclass_transformer_1.visit_ClassDef(classdef_0)


# Generated at 2022-06-25 22:10:55.417053
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_1 = module_0.Module()
    str_0 = 'urllib.request'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef(name='Test')
    str_1 = 'metaclass'
    str_2 = 'Test'
    keyword_0 = module_0.Keyword(arg=str_1, value=str_2)
    list_0 = [keyword_0]
    class_def_0.keywords = list_0
    class_def_1 = metaclass_

# Generated at 2022-06-25 22:10:56.286700
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()

# Generated at 2022-06-25 22:11:05.404459
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_2 = module_0.Module()
    str_1 = 'urllib.request'
    dict_1 = {str_1: str_1, str_1: str_1}
    a_s_t_1 = module_0.AST(**dict_1)
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    class_def_0 = module_0.ClassDef(
        name='name_of_ClassDef',
        keyword_args={},
        body=[],
        decorator_list=[],
        lineno=1,
        col_offset=0,
        keywords=[module_0.keyword(arg='metaclass', value='MyMeta')]
    )
    _0 = metaclass_transformer_1.vis

# Generated at 2022-06-25 22:11:16.608392
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    str_0 = 'urllib.request'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef()
    classdef_0.decorator_list = [module_0.Name()]
    classdef_0.keywords = [module_0.keyword()]
    classdef_0.bases = [module_0.Name()]
    module_x_var_1 = metaclass_transformer_0.visit_ClassDef(classdef_0)

# Generated at 2022-06-25 22:11:25.829603
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    str_0 = 'test_tree'
    attribute_0 = module_0.Attribute(**{'attr': str_0, 'ctx': module_0.Load()})
    str_1 = 'test_tree'
    attribute_1 = module_0.Attribute(**{'attr': str_1, 'ctx': module_0.Load()})
    list_0 = module_0.list([attribute_0, attribute_1])
    module_x_var_0.body.append(list_0)
    node_var_0 = module_0.ClassDef()
    str_2 = 'List'
    node_var_0.name = str_2
    str_3 = 'metaclass'
    str_4 = 'B'
    keyword_0

# Generated at 2022-06-25 22:11:32.093626
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    str_0 = 'urllib.request'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef(name='', bases=[], keywords=[], body=[], decorator_list=[])
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert class_def_1.bases == []
    assert class_def_1.keywords == []


# Generated at 2022-06-25 22:11:35.918804
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()


# Generated at 2022-06-25 22:11:42.028538
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    str_0 = 'urllib.request'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:11:49.050931
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_0 = module_0.ClassDef(name='A', keywords=[], **{'body':[]})
    str_1 = 'urllib.request'
    dict_1 = {str_1: str_1, str_1: str_1}
    a_s_t_1 = module_0.AST(**dict_1)
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    module_0.ClassDef = metaclass_transformer_1.visit_ClassDef(class_0)


# Generated at 2022-06-25 22:12:04.770265
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
  # No assertions. For code coverage only.
  module_x_var_0 = module_0.Module()
  str_0 = 'urllib.request'
  dict_0 = {str_0: str_0, str_0: str_0}
  a_s_t_0 = module_0.AST(**dict_0)
  metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
  module_0.ClassDef(name='t', bases=[], keywords=[], body=[], decorator_list=[])
  metaclass_transformer_0.visit_Module(module_x_var_0)
  # No assertions. For code coverage only.
  module_x_var_0 = module_0.Module()

# Generated at 2022-06-25 22:12:13.144839
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class ClassDef(object):
        def __init__(self, arg0, arg1, arg2, arg3, arg4):
            self.arg0 = arg0
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3
            self.arg4 = arg4
            self.col_offset = None
            self.keywords = None
            self.lineno = None
            self.name = None
            self.bases = None
            self.body = None

    dict_0 = {'keywords': [], 'arg3': None}
    classdef_0 = ClassDef(1, 2, 3, **dict_0)
    metaclass_transformer_0 = MetaclassTransformer(None)

# Generated at 2022-06-25 22:12:23.327434
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    dict_0 = {'docstring': None, 'body': [module_0.ClassDef(name='object', bases=[], keywords=[module_0.keyword(arg='metaclass', value=module_0.Name(id='type', ctx=module_0.Load()))], body=[], decorator_list=[])], 'type_ignores': [], 'lineno': 1, 'col_offset': 0}
    module_x_var_1 = module_0.Module(**dict_0)
    str_0 = 'urllib.request'
    dict_1 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)

# Generated at 2022-06-25 22:12:32.400831
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import ClassDef, Name, Call
    from ..utils import cst

    c = cst.CSTNode.from_str('class A(metaclass=B): pass')
    assert isinstance(c, ClassDef)

    t = MetaclassTransformer(c)
    assert isinstance(t.visit(c), ClassDef)
    assert t.visit(c).bases[0] == Call(Name('_py_backwards_six_withmetaclass'), [Name('B'), Name('object')], [])

    # Don't transform if there's no metaclass
    c = cst.CSTNode.from_str('class A: pass')
    assert isinstance(c, ClassDef)

    t = MetaclassTransformer(c)

# Generated at 2022-06-25 22:12:39.938637
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = __import__('typed_ast._ast3', fromlist=('Module',), level=0)
    class_0 = module_0.ClassDef()
    module_1 = __import__('typed_ast._ast3', fromlist=('Module',), level=0)
    metaclass_transformer_0 = MetaclassTransformer(module_1.AST(**{'urllib.request': 'urllib.request', 'urllib.request': 'urllib.request'}))
    module_2 = __import__('typed_ast._ast3', fromlist=('Module',), level=0)
    metaclass_transformer_0.generic_visit(class_0)
    metaclass_transformer_0.visit_ClassDef(class_0)
    metac

# Generated at 2022-06-25 22:12:48.769626
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    str_0 = 'urllib.request'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)
    module_x_var_1 = module_0.Module()
    module_x_var_2 = module_0.Name()
    module_x_var_2.id = 'A'
    module_x_var

# Generated at 2022-06-25 22:12:56.931770
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Setup
    module_x_var_0 = module_0.Module()
    str_0 = 'urllib.request'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef('', [], [], [], [])
    # Exercise
    try:
        metaclass_transformer_0.visit_ClassDef(class_def_0)
    except Exception as ex:
        type_ex = type(ex)
        # Verify
        assert type_ex is NotImplementedError

# Generated at 2022-06-25 22:12:57.827614
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()


# Generated at 2022-06-25 22:13:06.399360
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    dict_0 = {'name': '', 'args': module_0.arguments()}
    classdef_0 = module_0.ClassDef(**dict_0)
    dict_1 = {'name': '', 'args': module_0.arguments()}
    classdef_1 = module_0.ClassDef(**dict_1)
    str_0 = 'urllib.request'
    dict_2 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_2)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_2 = metaclass_transformer_0.visit_ClassDef(classdef_0)

# Generated at 2022-06-25 22:13:15.121763
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import random
    import ast as module_0
    import logging as module_1
    import typing as module_2
    import ast as module_3
    import sys as module_4
    import ast as module_5
    import six as module_6

# Generated at 2022-06-25 22:13:40.031827
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Create an instance of class MetaclassTransformer
    module_0_var_0 = module_0.Module()
    dict_0 = {'_fields': [], '_attributes': [], '_module': None, '_lineno': None, '_col_offset': None, '_ctx': module_0.Load()}
    dict_1 = {'_fields': [], '_attributes': [], '_module': None, '_lineno': None, '_col_offset': None, '_ctx': module_0.Load()}
    dict_2 = {'_fields': [], '_attributes': [], '_module': None, '_lineno': None, '_col_offset': None, '_ctx': module_0.Load()}

# Generated at 2022-06-25 22:13:47.906621
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = ast.Module()
    metaclass_1 = ast.Name(id='C', ctx=ast.Load())
    bases_2 = []
    keywords_3 = [ast.keyword(arg='metaclass', value=metaclass_1)]
    class_def_4 = ast.ClassDef(name='A', bases=bases_2, keywords=keywords_3, body=[])
    module_x_var_8 = module_0
    list_0 = []
    dict_1 = {'body': list_0}
    module_x_var_9 = ast.Module(**dict_1)
    str_0 = 'urllib.request'
    dict_2 = {str_0: str_0, str_0: str_0}
    a_s_t_4 = ast

# Generated at 2022-06-25 22:13:48.665425
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert False


# Generated at 2022-06-25 22:13:56.623688
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    str_0 = 'urllib.request'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)
    metaclass_x_var_0 = module_0.Name(id='B', ctx=module_0.Load())
    metaclass_x_var_1 = module_0.Keyword(arg='metaclass', value=metaclass_x_var_0)
   

# Generated at 2022-06-25 22:14:02.627184
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    str_0 = 'urllib.request'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:14:09.545345
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    str_0 = 'urllib.request'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef(name='Test', bases=[module_0.Name(id='Base', ctx=module_0.Load())])
    metaclass_transformer_0.visit_ClassDef(classdef_0)


# Generated at 2022-06-25 22:14:12.232453
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast as module_0
    module_x_var_0 = module_0.ClassDef()
    instance_0 = MetaclassTransformer()
    assert instance_0.visit_ClassDef(module_x_var_0) == module_x_var_0


# Generated at 2022-06-25 22:14:20.109248
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    str_0 = '__targets__'
    str_1 = '__metaclass__'
    str_2 = 'six'
    dict_0 = {str_0: str_0, str_1: str_1, str_2: str_2}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:14:28.900582
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    module_0.Module(body=[module_x_var_0])
    str_0 = 'urllib.request'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_0.Module(body=[metaclass_transformer_0.visit_Module(module_x_var_0)])

# Generated at 2022-06-25 22:14:35.210008
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    str_0 = 'urllib.request'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef()
    classdef_0.keywords = [module_0.keyword(arg=None, value=None)]
    return_0 = metaclass_transformer_0.visit_ClassDef(classdef_0)


# Generated at 2022-06-25 22:15:11.002717
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = ast.Module()
    str_0 = 'urllib.request'
    dict_0 = {str_0: str_0, str_0: str_0}
    ast_0 = ast.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(ast_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:15:17.816373
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclass_transformer_0 = MetaclassTransformer()
    classdef_0 = module_0.ClassDef(body=[], decs={}, name='', keywords=[], starargs=None, kwargs=None, bases=None, lineno=255, col_offset=255)
    a_s_t_0 = module_0.AST()
    classdef_1 = metaclass_transformer_0.visit_ClassDef(classdef_0, a_s_t_0)
    classdef_1 = metaclass_transformer_0.visit_ClassDef(classdef_0, a_s_t_0)
    classdef_1 = metaclass_transformer_0.visit_ClassDef(classdef_0, a_s_t_0)
    classdef_1 = metac

# Generated at 2022-06-25 22:15:26.252041
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    str_0 = 'urllib.request'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    name_0 = 'a'
    list_0 = []
    list_1 = []
    list_2 = []
    keyword_0 = module_0.keyword('a', 1)
    list_3 = [keyword_0]
    a_s_t_1 = module_0.AST(**dict_0)
    keyword_1 = module_0.keyword('b', 1)
    list_4

# Generated at 2022-06-25 22:15:35.011908
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_2 = module_0.Module()
    str_1 = 'urllib.request'
    dict_1 = {str_1: str_1, str_1: str_1}
    a_s_t_1 = module_0.AST(**dict_1)
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    parent_0 = module_x_var_2

# Generated at 2022-06-25 22:15:41.763593
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    class_def_0 = module_0.ClassDef(None, None, None, None)
    dict_0 = {class_def_0: class_def_0, class_def_0: class_def_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:15:50.547053
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'urllib.request'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = module_0.ClassDef(name='O_O', bases=list(), keywords=[], body=list(), decorator_list=[])
    class_def_0 = metaclass_transformer_0.visit_ClassDef(class_def_1)
    return (class_def_0, metaclass_transformer_0)


# Generated at 2022-06-25 22:15:58.541876
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    str_0 = 'urllib.request'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    str_1 = 'A'
    str_2 = 'B'
    dict_1 = {str_2: str_2}

# Generated at 2022-06-25 22:16:02.920395
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    dict_0 = {'a': 'a', 'a': 'a'}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:16:10.560103
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    str_0 = 'urllib.request'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    str_1 = 'ClassDef'
    dict_1 = {str_0: str_0, str_1: str_1}
    classdef_0 = module_0.ClassDef(**dict_1)
    node_0 = metaclass_transformer_0.visit_ClassDef(classdef_0)


# Generated at 2022-06-25 22:16:18.427062
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_2 = module_0.Module()
    module_x_var_3 = module_0.ClassDef('A', ())
    str_1 = 'metaclass'
    list_0 = ()
    module_x_var_4 = module_0.List(elts=list_0)
    module_x_var_5 = module_0.Keyword(arg=str_1, value=module_x_var_4)
    list_1 = (module_x_var_5,)
    module_x_var_3.keywords = list_1
    module_x_var_3.bases = ()
    list_2 = (module_x_var_3,)
    module_x_var_2.body = list_2
    metaclass_transformer_1 = MetaclassTrans