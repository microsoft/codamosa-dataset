

# Generated at 2022-06-25 22:07:22.895284
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # unit test for class MetaclassTransformer
    # Local variables
    body_0 = [
    ]
    classdef_0 = module_0.ClassDef(
        name='B',
        bases=[
        ],
        keywords=[
        ],
        body=body_0,
        decorator_list=[
        ],
    )
    module_1 = module_0.Module(
        body=[
            classdef_0,
        ],
    )
    a_s_t_1 = module_0.AST()
    # unit test for method MetaclassTransformer.visit_ClassDef
    # Local variables
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    metaclass_transformer_1.visit(module_1)

# Generated at 2022-06-25 22:07:28.388762
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = module_0.ClassDef()
    metaclass_transformer_0.visit_ClassDef(a_s_t_1)
    a_s_t_2 = module_0.ClassDef()
    metaclass_transformer_0.visit_ClassDef(a_s_t_2)

# Generated at 2022-06-25 22:07:36.588093
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef(name='A',
                                   body=[ ],
                                   decorator_list=[ ],
                                   keywords=[ ],
                                   starargs=None,
                                   kwargs=None,
                                   lineno=1,
                                   col_offset=0)
    classdef_0 = metaclass_transformer_0.visit_ClassDef(classdef_0)
    assert(classdef_0.name == 'A')
    assert(len(classdef_0.body) == 0)


# Generated at 2022-06-25 22:07:44.616701
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import _ast as ast
    from ..utils.ast_factory import ast_factory

    module = compile(
        """
        import six
        class A(metaclass=B):
            pass
        """,
        filename='', mode='exec')

    ast_module = ast.parse(
        """
        class A(_py_backwards_six_with_metaclass(B))
        """
    )

    metaclass_transformer = MetaclassTransformer(ast_factory(module))

    metaclass_transformer.visit(module)

    assert metaclass_transformer._tree_changed, "Tree should have been changed"

    assert ast.dump(module) == ast.dump(ast_module)


# Generated at 2022-06-25 22:07:48.899696
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_0_0 = module_0.Module(body=[])
    assert_raises(RuntimeError, metaclass_transformer_0.visit_Module, module_0_0)


# Generated at 2022-06-25 22:07:53.331745
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef()
    metaclass_transformer_0.visit_ClassDef(classdef_0)


# Generated at 2022-06-25 22:08:00.154654
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    print('test_MetaclassTransformer_visit_ClassDef:')
    module_1 = module_0.parse('''class A(metaclass=type):
    pass
''')
    module_0.fix_missing_locations(module_1)
    a_s_t_1 = module_0.AST(parse=False)
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    node_0 = metaclass_transformer_1.visit(module_1)
    print(module_0.dump(node_0))


# Generated at 2022-06-25 22:08:08.783279
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # Test normal case
    # Input:
    classDef_0 = module_0.ClassDef(name='_',
                                   bases=[],
                                   keywords=[module_0.keyword(arg='metaclass',
                                                              value=module_0.Call(func=module_0.Name(id='B',
                                                                                                     ctx=module_0.Load()),
                                                                                   args=[], keywords=[]))],
                                   body=[], decorator_list=[])
    classDef_1 = classDef_0
    # Expectation:

# Generated at 2022-06-25 22:08:18.750081
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
  input_0 = module_0.Module(body=[module_0.ClassDef(name='A',
                          bases=[module_0.Name(id='object', ctx=module_0.Load())],
                          keywords=[module_0.keyword(arg='metaclass', value=module_0.Name(id='B', ctx=module_0.Load()))],
                          body=[module_0.Pass()], decorator_list=[], lineno=1, col_offset=0)])

# Generated at 2022-06-25 22:08:30.176024
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    module_0_1 = module_0_0
    try:
        int(module_0_1)
    except Exception:
        module_0_1 = None
    module_0_0 = module_0_1
    module_0_1 = module_0_0
    try:
        module_0_1 = metaclass_transformer_0.visit_Module(module_0_0)
    except Exception:
        import sys
        import traceback
        _, _, exc_tb = sys.exc_info()
        traceback.print_tb(exc_tb)

# Generated at 2022-06-25 22:08:33.410032
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():

    # Instantiation
    a_s_t_0 = module_0.AST()
    

    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

    # Input
    a_s_t_0.Module(body=[])

    # Example use
    metaclass_transformer_0.visit_Module(module_0.Module())



# Generated at 2022-06-25 22:08:39.777783
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    class_def_0 = module_0.ClassDef(name='A',bases=[module_0.Name(id='B',ctx=module_0.Load())],keywords=[module_0.keyword(arg='metaclass',value=module_0.Name(id='C',ctx=module_0.Load()))],body=[module_0.Pass()])
    metaclass_transformer_0._tree_changed = False
    metaclass_transformer_0._visit_

# Generated at 2022-06-25 22:08:48.378326
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = module_0.ClassDef(name='A', bases=[], keywords=[], body=[], decorator_list=[])
    a_s_t_0.body = [class_def_0]
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_ClassDef(class_def_0)

a_s_t_1 = module_0.AST()
metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
metaclass_transformer_1.visit_Module(module_0.Module(body=[]))

# Generated at 2022-06-25 22:08:50.705785
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)



# Generated at 2022-06-25 22:08:54.393585
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0_test_0 = metaclass_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:09:01.804716
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

# Testing method visit_ClassDef in class MetaclassTransformer

# Generated at 2022-06-25 22:09:05.744636
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef()
    metaclass_transformer_0.visit_ClassDef(classdef_0)

# Generated at 2022-06-25 22:09:13.556268
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Prepare data
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0._tree_changed = False
    node = module_0.ClassDef(name='A', bases=[], keywords=[a_s_t_0.Keyword(arg='metaclass', value=a_s_t_0.Name(id='B', ctx=module_0.Load()))], body=[], decorator_list=[])
    # Run the test
    result = metaclass_transformer_0.visit_ClassDef(node)
    # Validate the result
    assert isinstance(result, module_0.ClassDef)
    assert result.name == 'A'

# Generated at 2022-06-25 22:09:21.878672
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    name_0 = a_s_t_2.Name("foo", module_0.Store())
    class_def_0 = a_s_t_3.ClassDef(name_0, suite=(), keywords=(), decorator_list=(), lineno=0, col_offset=0)
    metaclass_transformer_1.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:09:24.728403
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef(name='', bases=[], keywords=[], body=[], decorator_list=[])
    result = metaclass_transformer_0.visit_ClassDef(classdef_0)

# Generated at 2022-06-25 22:09:32.204937
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    metaclass_transformer_0_0 = metaclass_transformer_0.visit_Module(module_0_0)
    try:
        assert metaclass_transformer_0_0 is None
    except AssertionError:
        raise AssertionError()


# Generated at 2022-06-25 22:09:37.963546
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_1_visit_result = metaclass_transformer_0.visit_Module(module_1)
    assert module_1_visit_result is module_1


# Generated at 2022-06-25 22:09:46.463728
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    assert hasattr(snippet, 'string')
    assert hasattr(six_import, 'string')
    assert hasattr(class_bases, 'string')
    assert hasattr(snippet, 'get_body')
    assert isinstance(six_import, snippet)
    assert isinstance(class_bases, snippet)
    assert metaclass_transformer_0.target == (2, 7)
    assert metaclass_transformer_0.dependencies == ['six']


# Generated at 2022-06-25 22:09:50.662742
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    module_0_1 = metaclass_transformer_0.visit_Module(module_0_0)


# Generated at 2022-06-25 22:09:53.233363
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)


# Generated at 2022-06-25 22:09:55.951237
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Tests for the version of Python being compiled
    import sys

# Generated at 2022-06-25 22:09:58.052646
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)


# Generated at 2022-06-25 22:09:58.850838
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # TODO: Implement test
    pass


# Generated at 2022-06-25 22:10:09.947453
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    #
    # from six import with_metaclass as _py_backwards_six_withmetaclass
    # class A(metaclass=B):
    #     pass
    body = [ast.ImportFrom('six', [ast.alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], 0)]
    body.append(ast.ClassDef('A', [ast.Tuple([ast.Name('B', ast.Load())], ast.Load())], [], [], []))
    module_node = ast.Module(body)
    metaclass_transformer_0 = MetaclassTransformer(module_node)
    metaclass_transformer_0.visit_Module(module_node)
    assert metaclass_transformer_0._tree_changed == True


# Generated at 2022-06-25 22:10:13.875931
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_2 = metaclass_transformer_0.visit(module_1)


# Generated at 2022-06-25 22:10:24.573959
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    str_0 = module_0.Str()
    str_0.s = 'a'
    expr_0 = module_0.Expr()
    expr_0.value = str_0
    module_x_var_0.body.append(expr_0)
    module_x_var_0.body.append(expr_0)
    module_x_var_0.body.append(expr_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:10:33.960688
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
  a_s_t_1 = module_0.AST()
  metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
  module_x_var_2 = module_0.Module()
  class_x_var_1 = module_0.ClassDef(
    name='Ax',
    bases=[],
    keywords=[module_0.keyword(
      arg='metaclass',
      value=module_0.Name(
        id='Bx',
        ctx=module_0.Load()
      )
    )],
    body=[],
    decorator_list=[]
  )
  module_x_var_3 = metaclass_transformer_1.visit_ClassDef(class_x_var_1)

# Generated at 2022-06-25 22:10:40.036223
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_2 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_2)
    classdef_x_var_0 = module_0.ClassDef()
    classdef_x_var_1 = metaclass_transformer_1.visit_ClassDef(classdef_x_var_0)


# Generated at 2022-06-25 22:10:41.901796
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert True


if __name__ == "__main__":
    test_case_0()
    test_MetaclassTransformer()

# Generated at 2022-06-25 22:10:45.279624
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)
    check_result_is_not_none(metaclass_transformer_1)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 22:10:50.648277
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:10:54.217997
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    try:
        assert 1 == 1
        a_s_t_1 = module_0.AST()
        metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    except Exception:
        assert False


# Generated at 2022-06-25 22:10:58.442269
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_2 = module_0.Module()
    module_x_var_3 = metaclass_transformer_0.visit_Module(module_x_var_2)


# Generated at 2022-06-25 22:11:03.428408
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_x_var_0 = module_0.ClassDef()
    metaclass_transformer_0.visit_ClassDef(class_def_x_var_0)


# Generated at 2022-06-25 22:11:04.465483
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer


# Generated at 2022-06-25 22:11:14.004819
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():

    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)


# Generated at 2022-06-25 22:11:22.811048
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    expect = typed_ast.ast3.Module(body=[typed_ast.ast3.ImportFrom(module='six', names=[typed_ast.ast3.alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0)])
    a_s_t_0 = typed_ast.ast3.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_0 = typed_ast.ast3.Module(body=[])
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:11:26.859178
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_1 = MetaclassTransformer.__new__(MetaclassTransformer)


# Generated at 2022-06-25 22:11:30.464895
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)
    

# Generated at 2022-06-25 22:11:36.156649
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    module_a_s_t_var_0 = module_0.AST()
    metaclass_transformer_1_var_0 = MetaclassTransformer(module_a_s_t_var_0)


# Generated at 2022-06-25 22:11:39.452929
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    assert isinstance(metaclass_transformer_0, MetaclassTransformer)


# Generated at 2022-06-25 22:11:43.004936
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    assert(isinstance(metaclass_transformer_0, MetaclassTransformer))


# Generated at 2022-06-25 22:11:47.074761
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    test_case_0()

    args = (2, 7)
    target = metaclass_transformer_0.target
    assert target == args


# Generated at 2022-06-25 22:11:48.097927
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:11:51.307638
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    assert metaclass_transformer_0 is not None


# Generated at 2022-06-25 22:12:06.264264
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_x_var_0 = module_0.ClassDef()
    classdef_x_var_0.keywords = [module_0.keyword()]
    classdef_x_var_2 = metaclass_transformer_0.visit_ClassDef(classdef_x_var_0)

# Generated at 2022-06-25 22:12:11.347792
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    assert metaclass_transformer_0 is not None
    module_x_var_0 = module_0.Module()
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:12:13.718406
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)


# Generated at 2022-06-25 22:12:18.900488
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    class_def_x_var_0 = module_0.ClassDef()
    class_def_x_var_1 = metaclass_transformer_1.visit_ClassDef(class_def_x_var_0)

import six as module_1


# Generated at 2022-06-25 22:12:24.090059
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # Test 1, both args provided
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    assert metaclass_transformer_0.target == (2, 7) and metaclass_transformer_0.dependencies == ['six']


# Generated at 2022-06-25 22:12:25.513197
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert type(MetaclassTransformer(None)) == MetaclassTransformer


# Generated at 2022-06-25 22:12:26.411176
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    pass


# Generated at 2022-06-25 22:12:34.604443
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = module_0.ClassDef()
    module_x_var_3 = metaclass_transformer_0.visit_ClassDef(module_x_var_2)
    print( "module.x.3: %s" % (module_x_var_3,) )


# Generated at 2022-06-25 22:12:41.136204
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_2 = module_0.Module()
    module_x_var_3 = metaclass_transformer_0.visit_Module(module_x_var_2)
    class_def_0 = module_0.ClassDef(name='A', bases=None, keywords=[], body=[], decorator_list=[])
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:12:48.410919
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_x_var_0 = module_0.ClassDef(name = module_0.Name(),
                                          bases = [],
                                          body = [],
                                          keywords = [],
                                          decorator_list = [])
    metaclass_transformer_0.visit_ClassDef(class_def_x_var_0)
    assert type(class_def_x_var_0) == module_0.ClassDef

# Generated at 2022-06-25 22:13:10.319801
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    assert isinstance(metaclass_transformer_0, MetaclassTransformer)

# Generated at 2022-06-25 22:13:15.827494
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)

# Are we running this file directly, rather than being imported?
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:13:20.870325
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    module_x_var_2 = module_0.Module()
    module_x_var_3 = metaclass_transformer_1.visit_Module(module_x_var_2)


# Generated at 2022-06-25 22:13:26.035921
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    constructor_object_0 = MetaclassTransformer(a_s_t_0)
    assert ('type(constructor_object_0)' == "<type 'instance'>" and
            'constructor_object_0.__dict__ == {}' == 'True')


# Generated at 2022-06-25 22:13:31.119367
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:13:36.927029
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_x_var_0 = module_0.ClassDef()
    class_def_x_var_0.keywords = [module_0.keyword()]
    class_def_x_var_1 = metaclass_transformer_0.visit_ClassDef(class_def_x_var_0)

# Generated at 2022-06-25 22:13:45.668690
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_x_var_0 = module_0.ClassDef()
    class_def_x_var_3 = metaclass_transformer_0.visit_ClassDef(class_def_x_var_0)
    class_def_x_var_1 = module_0.ClassDef(keywords=[
        module_0.keyword(arg='metaclass', value=module_0.Name('int'))
    ])
    class_def_x_var_4 = metaclass_transformer_0.visit_ClassDef(class_def_x_var_1)
    class_def_x_var_1 = module_0

# Generated at 2022-06-25 22:13:46.163681
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert True


# Generated at 2022-06-25 22:13:52.571604
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)
    class_def_var_0 = module_0.ClassDef(name='test_MetaclassTransformer_visit_ClassDef',bases=[],decorator_list=[],body=[],keywords=[module_0.keyword(arg='metaclass',value=module_0.Str(s='test_MetaclassTransformer_visit_ClassDef'))])
    class_def_var_1 = metaclass_transformer_1.visit_ClassDef(class_def_var_0)

# Generated at 2022-06-25 22:14:00.915967
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_keywords_var_0 = module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])
    class_keywords_var_1 = module_0.arg(arg='metaclass', annotation=None)
    class_keywords_var_2 = module_0.Name(id='B', ctx=module_0.Load())
    class_keywords_var_3 = module_0.keyword(arg='metaclass', value=class_keywords_var_2)

# Generated at 2022-06-25 22:14:52.194926
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Create instance of class
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

    # Create variable of type AST
    a_s_t_1 = module_0.AST()

    # Create variable of type AST
    a_s_t_2 = module_0.AST()

    # Create variable of type List
    list_var_0 = module_0.List()

    # Create variable of type ClassDef
    class_def_var_0 = module_0.ClassDef()
    class_def_var_0.bases = list_var_0
    class_def_var_0.name = 'name_var_0'

    # Invoke method on class

# Generated at 2022-06-25 22:14:56.465567
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef(name="", body=[], decorator_list=[], keywords=[])
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert(False)

# Generated at 2022-06-25 22:15:01.485913
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef(
        '_x_var', 
        [module_0.Name('_metaclass', module_0.Load())], 
        [module_0.Pass()], 
        [])
    classdef_0 = metaclass_transformer_0.visit_ClassDef(classdef_0)

# Generated at 2022-06-25 22:15:11.103559
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef(name_0=module_0.Name(id='A'),
                                   bases_0=[],
                                   keywords_0=[module_0.keyword(arg='metaclass',
                                                                value=module_0.Name(id='B')),
                                              ])
    classdef_x_var_0 = metaclass_transformer_0.visit_ClassDef(classdef_0)

if __name__ == "__main__":
    import sys
    import inspect
    import json
    import argparse
    from .test_utils.test_ast import json_ast

# Generated at 2022-06-25 22:15:15.161618
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:15:21.091947
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_var_0 = module_0.AST()
    metaclass_transformer_var_0 = MetaclassTransformer(a_s_t_var_0)


# Generated at 2022-06-25 22:15:27.929071
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    assert(metaclass_transformer_0._tree_changed == False)
    assert(metaclass_transformer_0._changed_helper == False)
    assert(isinstance(metaclass_transformer_0._ast, module_0.AST) == True)
    module_x_var_2 = module_0.Module()
    module_x_var_3 = metaclass_transformer_0.visit_Module(module_x_var_2)
    module_x_var_4 = module_0.Module()

# Generated at 2022-06-25 22:15:33.589230
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import typed_ast.ast3 as module_0
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:15:40.427596
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_classdef_x_var_0 = module_0.ClassDef("Foo", [], [], None, module_0.Name("Bar", module_0.Load()))
    classdef_x_var_1 = metaclass_transformer_0.visit_ClassDef(a_classdef_x_var_0)

# Generated at 2022-06-25 22:15:45.016916
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    assert metaclass_transformer_0._tree_changed == False