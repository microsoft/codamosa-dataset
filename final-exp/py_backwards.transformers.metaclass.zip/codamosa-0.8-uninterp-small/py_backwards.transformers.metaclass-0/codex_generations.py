

# Generated at 2022-06-25 22:07:34.690767
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typing

    import astroid
    from astroid import InferenceError
    from astroid.scoped_nodes import ClassDef
    from astroid import test_utils

    a_s_t_0 = astroid.builder.MANAGER.astroid
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)


    node_1 = a_s_t_0.extract_node('\n                       class A(metaclass=B):\n                           pass\n                   ')
    assert isinstance(node_1, ClassDef)
    assert len(node_1.bases) == 1
    assert typing.get_type_hints(node_1.bases[0]) == {}

# Generated at 2022-06-25 22:07:41.791861
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from py_backwards._compat import BytesIO
    from six import PY3
    from six import StringIO
    if PY3:
        import io as cStringIO
    else:
        import cStringIO
    module_0 = ast.parse("class A(object):\n    pass")
    metaclass_transformer_0 = MetaclassTransformer()
    classdef_1 = module_0.body[0]
    classdef_2 = metaclass_transformer_0.visit_ClassDef(classdef_1)
    

# Generated at 2022-06-25 22:07:50.723820
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

    ctx_0 = module_0.Load()
    obj_0 = module_0.Name(id="B", ctx=ctx_0)
    keyword_0 = module_0.arg(arg="metaclass", value=obj_0)
    arg_0 = (keyword_0, )
    call_0 = module_0.Call(func=module_0.Name(id="class", ctx=ctx_0), args=[], keywords=arg_0)
    expr_0 = module_0.ClassDef(name="A", bases=[], body=[], decorator_list=[], keywords=[call_0])
    module_1 = module_0.Module

# Generated at 2022-06-25 22:07:54.553822
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = ast.parse("class A: pass")
    metaclass_transformer_0 = MetaclassTransformer(ast)
    with pytest.raises(AttributeError):
        metaclass_transformer_0.visit_ClassDef(module_0.body[0])


# Generated at 2022-06-25 22:08:03.516453
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

    module_0_0 = module_0.Module()
    class_def_0 = module_0.ClassDef(name="A", bases=[], keywords=[], body=[], decorator_list=[])
    module_0_0.body.append(class_def_0)
    assert module_0.dump(module_0_0) == module_0.parse("class A:\n\tpass")
    module_0_0_0 = metaclass_transformer_0.visit(module_0_0)
    assert module_0.dump(module_0_0_0) == module_0.parse("class A:\n\tpass")

    module

# Generated at 2022-06-25 22:08:06.622347
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = module_0.ClassDef(name='A', bases=[], keywords=[])
    a_s_t_2 = metaclass_transformer_0.visit_ClassDef(a_s_t_1)
    assert(a_s_t_2 == a_s_t_1)


# Generated at 2022-06-25 22:08:13.301036
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = module_0.ClassDef(name='Test', body={}, decorator_list={}, keywords={}, lineno=0, col_offset=0)
    metaclass_transformer_0.visit_ClassDef(a_s_t_1)
    metaclass_transformer_0.visit_ClassDef(a_s_t_1)

# Generated at 2022-06-25 22:08:16.597382
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    #TODO: handle module_0.AST()


# Generated at 2022-06-25 22:08:27.865812
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    ast_module_0 = module_0.Module()
    metaclass_transformer_0.visit_Module(ast_module_0)
    ast_classdef_0 = module_0.ClassDef(name='A', body=list(), decorator_list=list(), keywords=list())
    assert (metaclass_transformer_0.visit_ClassDef(ast_classdef_0) == ast_classdef_0)
    ast_classdef_1 = module_0.ClassDef(name='A', body=list(), decorator_list=list(), keywords=[module_0.keyword(arg='metaclass', value=None)])

# Generated at 2022-06-25 22:08:28.818827
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()



# Generated at 2022-06-25 22:08:32.486982
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    try:
        assert True
    except:
        print("AssertionError")


# Generated at 2022-06-25 22:08:36.297787
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_10 = module_0.AST()
    a_s_t_10._fields = ["elts"]
    a_s_t_4 = module_0.List()
    a_s_t_4.ctx = None
    a_s_t_4.lineno = 4
    a_s_t_4.col_offset = 0
    a_s_t_4.elts = []
    a_s_t_4.end_lineno = 4
    a_s_t_4.end_col_offset = 6
    a_s_t_4.name = "List"
    a_s_t

# Generated at 2022-06-25 22:08:40.083715
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = ast.parse('class A(metaclass=b): pass')
    assert module_0.body[0].keywords[0].value.id == "b"
    MetaclassTransformer().visit(module_0)
    assert module_0.body[0].keywords == []
    assert module_0.body[0].bases[0].func.id == "_py_backwards_six_withmetaclass"
    assert module_0.body[0].bases[0].args[0].id == "b"

# Generated at 2022-06-25 22:08:49.347722
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = module_0.Module()
    class_def_0 = module_0.ClassDef(name='A',
                                    bases=[],
                                    keywords=[module_0.keyword(arg='metaclass',
                                                               value=module_0.Name(id='B',
                                                                                  ctx=module_0.Load()))],
                                    body=[],
                                    decorator_list=[])
    insert_at(0, module_1, class_def_0)
    module_0 = metaclass_transformer_0.visit_Module(module_1)
    assert module_0.body[0].bases

# Generated at 2022-06-25 22:08:52.911969
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef()
    metaclass_transformer_0.visit_ClassDef(classdef_0)

# Generated at 2022-06-25 22:09:01.543726
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Arrange
    a_s_t_0 = module_0.AST()
    body_0 = module_0.parse(input_0)
    body_1 = module_0.parse(input_1)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0._tree_changed = True
    node_0 = body_0.body[0]
    # Act
    metaclass_transformer_0.visit_ClassDef(node_0)
    # Assert
    assert a_s_t_0.dump(body_0) == a_s_t_0.dump(body_1)


# Generated at 2022-06-25 22:09:11.012255
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef(name='A', bases=[], keywords=[module_0.keyword(arg='metaclass', value=module_0.Name(id='B', ctx=module_0.Load()))], body=[], decorator_list=[])
    classdef_1 = metaclass_transformer_0.visit_ClassDef(classdef_0)
    assert isinstance(classdef_1, module_0.ClassDef)
    assert classdef_1.name == 'A'
    assert isinstance(classdef_1.bases, list)

# Generated at 2022-06-25 22:09:12.809012
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()

# Generated at 2022-06-25 22:09:13.313544
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert 0 == 1

# Generated at 2022-06-25 22:09:21.726301
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

    class _ast3_ClassDef(object):
        def __init__(self, name, bases, keywords, body, decorator_list, lineno, col_offset, end_lineno, end_col_offset):
            self.name = name
            self.bases = bases
            self.keywords = keywords
            self.body = body
            self.decorator_list = decorator_list
            self.lineno = lineno
            self.col_offset = col_offset
            self.end_lineno = end_lineno
            self.end_col_offset = end_col_offset

        def visited(self):
            return metaclass_trans

# Generated at 2022-06-25 22:09:29.646510
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_x_var_0 = module_0.ClassDef('A', [], [], [], module_0.Name('object', module_0.Load()))
    classdef_x_var_1 = metaclass_transformer_0.visit_ClassDef(classdef_x_var_0)

# Generated at 2022-06-25 22:09:34.912629
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_var_0 = module_0.ClassDef()
    metaclass_transformer_0.visit_ClassDef(classdef_var_0)


# Generated at 2022-06-25 22:09:40.633367
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef(name='A', bases=[], keywords=[], body=[], decorator_list=[])
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert not hasattr(class_def_1, 'keywords')


# Generated at 2022-06-25 22:09:48.112605
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_2 = module_0.Module()
    module_x_var_3 = metaclass_transformer_0.visit_Module(module_x_var_2)
    module_x_var_4 = module_0.ClassDef()
    module_x_var_5 = metaclass_transformer_0.visit_ClassDef(module_x_var_4)



# Generated at 2022-06-25 22:09:55.664427
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_x_var_0 = ast.ClassDef(name='A',
                                     bases=[ast.Name(id='B', ctx=ast.Load())],
                                     keywords=[ast.keyword(arg='metaclass',
                                                           value=ast.Name(id='B', ctx=ast.Load()))],
                                     body=[],
                                     decorator_list=[])
    metaclass_transformer_0 = MetaclassTransformer(ast.AST())
    metaclass_transformer_0._tree_changed = False
    metaclass_transformer_0.visit_ClassDef(class_def_x_var_0)

# Generated at 2022-06-25 22:10:01.297455
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_x_var_0 = module_0.ClassDef()
    class_x_var_1 = module_0.ClassDef()
    class_x_var_1.keywords = [module_0.keyword(arg="metaclass", value=module_0.Name())]
    class_x_var_2 = metaclass_transformer_0.visit_ClassDef(class_x_var_1)

# Generated at 2022-06-25 22:10:07.363003
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = ast.ClassDef()
    classdef_1 = metaclass_transformer_0.visit_ClassDef(classdef_0)


# Generated at 2022-06-25 22:10:13.266806
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast._ast3 as module_0
    import typed_ast._ast3 as module_1
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_x_var_0 = module_1.ClassDef()
    classdef_x_var_1 = metaclass_transformer_0.visit_ClassDef(classdef_x_var_0)


# Generated at 2022-06-25 22:10:15.603039
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ast import parse
    from .six import with_metaclass as _py_backwards_six_withmetaclass


# Generated at 2022-06-25 22:10:24.002328
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Test with keyword arg
    a_s_t_1 = module_0.AST()
    class_def_var_0 = module_0.ClassDef()
    class_def_var_1 = module_0.arguments  # type: module_0.arguments
    node_var_0 = ast.arguments(args=ast.List(elts=[]), vararg=None, kwonlyargs=ast.List(elts=[]), kw_defaults=[], kwarg=None, defaults=[])
    node_var_1 = ast.Keyword(arg='metaclass', value=ast.Num(n=3))
    node_var_2 = ast.List(elts=[])
    class_def_var_0.name = "Foo"
    class_def_var_0.args = node_

# Generated at 2022-06-25 22:10:39.177038
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_x_var_0 = module_0.ClassDef(name='test',
                                          bases=[],
                                          keywords=[],
                                          body=[],
                                          decorator_list=[],
                                          lineno=1,
                                          col_offset=0)
    module_x_var_0 = module_0.Module()
    module_x_var_0.body.append(class_def_x_var_0)
    metaclass_transformer_0.visit_Module(module_x_var_0)
    class_x_var_1 = metaclass_transformer_0.visit_

# Generated at 2022-06-25 22:10:42.592433
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    classdef_0 = module_0.ClassDef()
    metaclass_transformer_0 = MetaclassTransformer(module_0.AST())
    metaclass_transformer_0.visit_ClassDef(classdef_0)
    assert metaclass_transformer_0._tree_changed == False

# Generated at 2022-06-25 22:10:47.475842
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Instantiating AST instance
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # Instantiating ClassDef instance
    classdef_x_var_0 = module_0.ClassDef()
    classdef_x_var_1 = metaclass_transformer_0.visit_ClassDef(classdef_x_var_0)
    assert type(classdef_x_var_1) == module_0.ClassDef


# Generated at 2022-06-25 22:10:56.663086
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_bases_0 = module_0.List()
    class_bases_0_elts_var_0 = module_0.Name()
    class_bases_0_elts_var_0_id_var_0 = 1
    class_bases_0_elts_var_0_ctx_var_0 = module_0.Load()

# Generated at 2022-06-25 22:11:01.915930
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = metaclass_transformer_0.visit_ClassDef(module_x_var_0)


# Generated at 2022-06-25 22:11:06.636483
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    node_x_var_0 = module_0.ClassDef()
    node_x_var_1 = metaclass_transformer_0.visit_ClassDef(node_x_var_0)


# Generated at 2022-06-25 22:11:17.272719
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Make sure we don't get a ClassDef with keywords as children, we need to
    # fully replace it.
    module_x_var_0 = metaclass_transformer_0.visit_ClassDef(module_0.ClassDef(name='A', bases=[module_0.Name(id='B', ctx=module_0.Load())], keywords=[module_0.keyword(arg='metaclass', value=module_0.Name(id='C', ctx=module_0.Load()))], body=[module_0.Pass()], decorator_list=[]))

# Generated at 2022-06-25 22:11:26.549708
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef(name='A',
                                    bases=[module_0.Name(id='B', ctx=module_0.Load())],
                                    keywords=[module_0.keyword(arg='metaclass',
                                                                value=module_0.Name(id='M',
                                                                                    ctx=module_0.Load()))],
                                    body=[module_0.Pass()],
                                    decorator_list=[])
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert class_def_1.keywords == []

# Generated at 2022-06-25 22:11:30.226227
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:11:41.831322
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = module_0.ClassDef()
    module_x_var_2.keywords = [module_0.keyword(module_0.arg('metaclass'), module_0.Name(module_0.Load(), 'B'))]
    module_x_var_2.name = 'A'
    module_x_var_2.body = [module_0.Pass()]
    module_x_var_2.b

# Generated at 2022-06-25 22:11:51.610052
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_1.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:11:57.723035
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Setup
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)

    # Test
    class_def_var_0 = module_0.ClassDef()
    class_def_var_1 = metaclass_transformer_0.visit_ClassDef(class_def_var_0)


# Generated at 2022-06-25 22:12:05.790420
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    keyword_0 = module_0.Keyword(arg=None, value=None)
    setattr(keyword_0, 'arg', 'metaclass')
    setattr(keyword_0, 'value', 'B')
    setattr(class_def_0, 'keywords', (keyword_0,))
    setattr(class_def_0, 'bases', ('obj',))
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert metaclass_transformer_0._tree_changed

# Generated at 2022-06-25 22:12:12.993060
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_x_var_0 = module_0.ClassDef()
    module_x_var_0 = module_0.Module()
    module_x_var_0.body = [class_def_x_var_0]
    metaclass_transformer_0.visit_Module(module_x_var_0)
    class_def_x_var_1 = metaclass_transformer_0.visit_ClassDef(class_def_x_var_0)


# Generated at 2022-06-25 22:12:23.174434
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef(name='Var0', body=[])
    classdef_1 = module_0.ClassDef(name='Var1', body=[])
    classdef_2 = module_0.ClassDef(name='Var2', body=[])
    classdef_3 = module_0.ClassDef(name='Var3', body=[])
    classdef_4 = module_0.ClassDef(name='Var4', body=[])
    classdef_5 = module_0.ClassDef(name='Var5', body=[])
    classdef_6 = module_0.ClassDef(name='Var6', body=[])
    classdef_

# Generated at 2022-06-25 22:12:32.239347
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef()
    classdef_0.args = module_0.arguments()
    classdef_0.args.defaults = []
    classdef_0.args.kwarg = None
    classdef_0.args.kw_defaults = []
    classdef_0.args.vararg = None
    keyword_0 = module_0.keyword()
    keyword_0.arg = 'metaclass'
    keyword_0.value = module_0.Name()
    classdef_0.keywords = [keyword_0]
    expected_0 = classdef_0
    actual_0 = metaclass

# Generated at 2022-06-25 22:12:39.788740
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef()
    classdef_0.keywords = [module_0.keyword()]
    metaclass_transformer_0.visit_ClassDef(classdef_0)
    module_x_var_0 = module_0.Module()
    module_x_var_0.body = [module_0.Expr()]
    module_x_var_0.body[0].value = classdef_0
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:12:48.087523
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef(name='A', bases=[module_0.Name(id='abc', ctx=module_0.Load())], keywords=[module_0.keyword(arg='metaclass', value=module_0.Name(id='abc_metaclass', ctx=module_0.Load()))], body=[], decorator_list=[])
    classdef_1 = metaclass_transformer_0.visit_ClassDef(classdef_0)
    assert (len(classdef_1.keywords) == 0)


# Generated at 2022-06-25 22:12:56.614182
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclass_transformer_1 = MetaclassTransformer(module_0.AST())
    classdef_2 = module_0.ClassDef()
    classdef_2.bases = [
        module_0.Name()]
    classdef_2.keywords = [
        module_0.keyword()]
    classdef_2.keywords[0].arg = "metaclass"
    classdef_2.keywords[0].value = module_0.Name()
    classdef_2.keywords[0].value.id = "B"
    classdef_3 = metaclass_transformer_1.visit_ClassDef(classdef_2)
    assert classdef_3.bases[0].args[0].func.value.id == "B"

# Generated at 2022-06-25 22:13:00.478635
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_2 = module_0.AST()
    metaclass_transformer_2 = MetaclassTransformer(a_s_t_2)
    class_def_3 = module_0.ClassDef()
    class_def_4 = metaclass_transformer_2.visit_ClassDef(class_def_3)


# Generated at 2022-06-25 22:13:21.394085
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_var_0 = module_0.ClassDef(name='A', body=[])
    class_x_var_0 = metaclass_transformer_0.visit_ClassDef(class_def_var_0)


# Generated at 2022-06-25 22:13:26.468660
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_0 = Module()
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:13:32.692824
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    a_s_t_0 = ast.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_var_0 = ast.ClassDef()
    class_def_var_1 = metaclass_transformer_0.visit_ClassDef(class_def_var_0)
    assert class_def_var_1 == class_def_var_0


# Generated at 2022-06-25 22:13:41.504797
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_var_0 = module_0.Name(id='foo.bar.Baz')
    metaclass_var_1 = module_0.Keyword()
    metaclass_var_2 = module_0.Name(id='Bar')
    metaclass_var_1.value = metaclass_var_2
    metaclass_var_1.arg = 'metaclass'
    metaclass_var_3 = module_0.ClassDef()
    metaclass_var_3.bases = []
    metaclass_var_3.keywords = [metaclass_var_1]
    class_y_var_

# Generated at 2022-06-25 22:13:45.528264
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:13:53.199018
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    print("test function: MetaclassTransformer::visit_ClassDef")

    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # Test 1:
    classdef_x_var_0 = module_0.ClassDef(name="class_name", bases=[], body=[], decorator_list=[], keywords=[module_0.keyword(arg="metaclass", value=module_0.Name(id="metaclass_name"))])
    classdef_x_var_1 = metaclass_transformer_0.visit_ClassDef(classdef_x_var_0)

# Generated at 2022-06-25 22:14:00.915627
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)
    classdef_x_var_0 = module_0.ClassDef(name='x', body=[], keywords=[], lineno=1, col_offset=0)
    classdef_x_var_1 = metaclass_transformer_0.visit_ClassDef(classdef_x_var_0)
    classdef_x_var_1.keywords == []

# Generated at 2022-06-25 22:14:06.075253
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    arg_0 = module_0.ClassDef()
    metaclass_transformer_0.visit_ClassDef(arg_0)

if __name__ == '__main__':
    import pytest
    import __main__
    pytest.main(__main__)

# Generated at 2022-06-25 22:14:10.006041
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    metaclass_transformer_0 = MetaclassTransformer(None)
    classdef_var_0 = module_0.ClassDef(name='TestClass', bases=[], keywords=[], body=[], decorator_list=[])
    class_var_0 = metaclass_transformer_0.visit_ClassDef(classdef_var_0)

# Generated at 2022-06-25 22:14:14.059916
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef(name='c')
    module_x_var_0 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:14:52.024675
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_var_0 = module_0.ClassDef(name='A', body=[])
    class_def_var_1 = metaclass_transformer_0.visit_ClassDef(class_def_var_0)
    assert class_def_var_1.body is not class_def_var_0.body


# Generated at 2022-06-25 22:14:58.138194
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    
    class_def_x_0_var_0 = module_0.ClassDef(name='A', bases=[], keywords=[], starargs=None, kwargs=None)
    class_def_x_0_var_1 = module_x_var_1.body[1]

    assert(class_def_x_0_var_1 is not None)

    assert(class_def_x_0_var_1.name == 'A')



# Generated at 2022-06-25 22:15:01.960724
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_var_0 = module_0.ClassDef()
    class_def_var_1 = metaclass_transformer_0.visit_ClassDef(class_def_var_0)


# Generated at 2022-06-25 22:15:10.970261
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from _ast import Name, ClassDef, Module
    from typed_ast.ast3 import ClassDef as ClassDefT

    m = Module([ClassDef('TestClass', [], [], [], [], [])])

    # No changes
    mt = MetaclassTransformer(m)
    mt.visit(m)
    assert mt.tree_changed is False

    # With changes
    m = Module([ClassDef('TestClass', [], [], [], [], [], keywords=[Name(id='metaclass', ctx=Name.Param())])])

    mt = MetaclassTransformer(m)
    mt.visit(m)
    assert mt.tree_changed is True
    assert isinstance(m.body[0], ClassDefT)

# Generated at 2022-06-25 22:15:15.299661
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_x_var_0 = module_0.ClassDef()
    classdef_x_var_1 = metaclass_transformer_0.visit_ClassDef(classdef_x_var_0)


# Generated at 2022-06-25 22:15:26.122053
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_0 = Module()
    node_0 = ClassDef()
    node_1 = metaclass_transformer_0.visit_ClassDef(node_0)
    assert node_0 is node_1
    node_2 = ClassDef()
    keyword_0 = Keyword()
    node_2.keywords = [keyword_0]
    node_3 = metaclass_transformer_0.visit_ClassDef(node_2)
    assert node_2 is node_3
    assert keyword_0 is not node_2.keywords[0]
    module_0.body = [node_2]
    module_1 = metaclass_transformer_

# Generated at 2022-06-25 22:15:31.166205
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_x_var_0 = module_0.ClassDef()
    classdef_x_var_1 = metaclass_transformer_0.visit_ClassDef(classdef_x_var_0)


# Generated at 2022-06-25 22:15:36.710469
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_var_0 = module_0.AST()
    metaclass_transformer_v_var_0 = MetaclassTransformer(a_s_t_var_0)
    classdef_var_0 = module_0.ClassDef()
    classdef_var_1 = metaclass_transformer_v_var_0.visit_ClassDef(classdef_var_0)


# Generated at 2022-06-25 22:15:46.728380
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_x_var_0 = module_0.ClassDef()
    classdef_x_var_1 = metaclass_transformer_0.visit_ClassDef(classdef_x_var_0)

# Generated at 2022-06-25 22:15:54.675587
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0.Module()
    module_0.ClassDef()
    module_0.Name()
    module_0.Load()
    module_0.Name()
    module_0.Load()
    module_0.Call()
    module_0.Load()
    module_0.Name()
    module_0.Load()
    module_0.Call()
    module_0.Load()
    module_0.Name()
    module_0.Load()
    module_0.Call()
    module_0.Load()
    module_0.Name()
    module_0.Load()
    module_0.List()
    module_0.Module()
    module_0.ClassDef()
    module_0.Name()
    module_0.Load()
    module_0.Name()

# Generated at 2022-06-25 22:17:21.770691
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef(name='A', bases=[], keywords=[], body=[], decorator_list=[])
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert(class_def_1 == class_def_0)


# Generated at 2022-06-25 22:17:27.510952
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)
    class_def_x_var_0 = module_0.ClassDef()
    class_def_x_var_1 = metaclass_transformer_0.visit_ClassDef(class_def_x_var_0)