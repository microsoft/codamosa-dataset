

# Generated at 2022-06-25 22:07:37.545539
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classDef_0 = ast.ClassDef(name='A', bases=[], keywords=[], starargs=None, kwargs=None, body=[], decorator_list=[])
    class_def_bases_0 = classDef_0.bases
    class_def_bases_1 = ast.List(elts=[])
    assert class_def_bases_0 is not class_def_bases_1
    classDef_0.bases = class_def_bases_1
    classDef_1 = metaclass_transformer_0.visit_ClassDef(classDef_0)
    class_def_bases_2 = classDef_1.bases


# Generated at 2022-06-25 22:07:41.308241
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    import ast
    class_def = ast.ClassDef()
    metaclass_transformer_0.visit_ClassDef(class_def)


# Generated at 2022-06-25 22:07:44.838274
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = MetaclassTransformer()
    class_def_0 = ast.ClassDef(name='A', body=[], keywords=[], decorator_list=[])
    a_s_t_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:07:52.764532
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_1 = None
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    # Test fixture 1
    a_s_t_2 = None
    class_def_0 = ast.ClassDef(name='A', bases=[], keywords=[], body=None, decorator_list=[])
    # Test fixture 2
    a_s_t_3 = None
    class_def_1 = ast.ClassDef(name='A', bases=[], keywords=[], body=None, decorator_list=[])
    metaclass_transformer_1.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:07:55.853305
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    node_0 = None
    metaclass_transformer_0.visit_ClassDef(node_0)

# Generated at 2022-06-25 22:08:03.557126
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from astunparse import unparse

    a_s_t_0 = ast.parse('class A(metaclass=B): pass')
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_0 = metaclass_transformer_0.visit(a_s_t_0)
    assert unparse(a_s_t_0) == 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass'


# Generated at 2022-06-25 22:08:06.147712
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclass_transformer_0 = MetaclassTransformer()
    ast_1 = None
    classdef_2 = ast_1.ClassDef()
    metaclass_0 = None
    classdef_2.keywords = [ast_1.keyword(arg="metaclass", value=metaclass_0)]
    metaclass_transformer_0.visit_ClassDef(classdef_2)

# Generated at 2022-06-25 22:08:09.151460
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclass_transformer_0 = None # type: MetaclassTransformer
    classdef_0 = None # type: ast.ClassDef
    metaclass_transformer_0.visit_ClassDef(classdef_0)


# Generated at 2022-06-25 22:08:10.687766
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-25 22:08:20.384554
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    # from typed_ast import ast3 as ast

    class_def_0 = ast.ClassDef(name='A',
                               bases=[],
                               keywords=[],
                               body=[],
                               decorator_list=[])

    class_def_1 = ast.ClassDef(name='A',
                               bases=[ast.Name(id='object',
                                               ctx=ast.Load())],
                               keywords=[],
                               body=[],
                               decorator_list=[])

    metaclass_transformer_0 = MetaclassTransformer(ast.AST())

    try:
        metaclass_transformer_0.visit_ClassDef(class_def_0)
    except Exception as e:
        assert type(e) == AttributeError

# Generated at 2022-06-25 22:08:27.137100
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = metaclass_transformer_0.visit_Module(a_s_t_0)


# Generated at 2022-06-25 22:08:35.958536
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():

    # Unit test for visit_Module(self, node: ast.Module) -> ast.Module
    def test_MetaclassTransformer_visit_Module_0():
        a_s_t_0_0 = ast.Module(body=[])
        six_import_0_1 = None
        test_case_0_2 = MetaclassTransformer(six_import_0_1)

        # Unit test for visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef
        def test_MetaclassTransformer_visit_ClassDef_0():
            a_s_t_0_0 = ast.ClassDef(name='A', bases=[], body=[], keywords=[])
            metaclass_transformer_0_1 = None

# Generated at 2022-06-25 22:08:44.002599
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_0 = None
    node_0 = ast.ClassDef(name='', bases=[], keywords=[ast.keyword(arg='', value=metaclass_0)], body=[], decorator_list=[])
    a_s_t_0 = node_0
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_0 = metaclass_transformer_0.visit_ClassDef(node_0)
    assert_true(isinstance(a_s_t_0, ast.ClassDef), 'isinstance(a_s_t_0, ast.ClassDef)')

#

# Generated at 2022-06-25 22:08:49.264557
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = ast.parse('class A(metaclass=B):\n    pass', '<string>', 'exec')
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit(a_s_t_0)
    # assert a_s_t_0 == ast.parse(astor.to_source(a_s_t_0))

# Generated at 2022-06-25 22:08:51.567182
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    metaclass_transformer_0 = MetaclassTransformer(None)
    assert metaclass_transformer_0.visit_Module(None) == None


# Generated at 2022-06-25 22:08:54.589351
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = None
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)
    module_0 = None
    metaclass_transformer_1.visit_Module(module_0)



# Generated at 2022-06-25 22:09:01.264117
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)


# Generated at 2022-06-25 22:09:02.495886
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 22:09:07.914009
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_mod_1 = ast.parse('class A (metaclass=B): pass')
    metaclass_transformer_1 = MetaclassTransformer(a_mod_1)
    metaclass_transformer_1.visit_ClassDef(ast.ClassDef(name='A', keywords=[ast.keyword(arg='metaclass', value=1)], bases=[], body=[]))


# Generated at 2022-06-25 22:09:11.315833
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    test_case_0()

from typing import List, Tuple, Dict, Any
import builtins
from inspect import signature, Parameter
from enum import Enum
from types import FunctionType, LambdaType
from ..abc.base_test import BaseTest
from ..utils.logging_helper import LoggingHelper



# Generated at 2022-06-25 22:09:17.715472
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    metaclass_transformer_0 = MetaclassTransformer(var_1)
    metaclass_transformer_0.tree_changed
    metaclass_transformer_0.visit(var_1)


# Generated at 2022-06-25 22:09:18.837303
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    assert True == True


# Generated at 2022-06-25 22:09:27.988736
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = module_0.ClassDef()
    var_2 = module_0.Name()
    var_2.id = "B"
    var_1.bases = [var_2]
    var_1.keywords = [module_0.keyword(arg="metaclass", value=var_2)]
    var_3 = metaclass_transformer_0.visit_ClassDef(var_1)
    var_4 = module_0.List(elts=[var_2])
    var_4.ctx = module_0.Load()
    var_4.elts

# Generated at 2022-06-25 22:09:39.191166
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from string import Template

    assert_equal = _check_equal(MetaclassTransformer)

    assert_equal(
        'class A(metaclass=B): pass',
        'from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B))'
    )
    assert_equal(
        "class A(C, metaclass=B): pass",
        Template('from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A($_py_backwards_six_withmetaclass(B), C)').substitute(
            '_py_backwards_six_withmetaclass(B), '
        )
    )

# Generated at 2022-06-25 22:09:43.051402
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_0 = metaclass_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:09:45.049607
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()

# Generated at 2022-06-25 22:09:50.580450
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)
    var_2 = var_1.body[0].bases
    str_1 = '()'
    assert str(module_0.unparse(var_2)) == str_1

# Generated at 2022-06-25 22:09:59.289645
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    var_0 = MetaclassTransformer()
    var_1 = module_0.ClassDef(name='A',
                              bases=[],
                              keywords=[module_0.keyword(arg='metaclass',
                                                          value=module_0.Name(id='B', ctx=module_0.Load()))],
                              body=[module_0.Pass()],
                              decorator_list=[])
    try:
        var_2 = var_0.visit_ClassDef(var_1)
    except Exception as var_3:
        var_4 = None
    else:
        var_4 = var_2

# Generated at 2022-06-25 22:10:03.807366
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit_Module(var_0)


# Generated at 2022-06-25 22:10:09.681300
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_2 = 'class A(metaclass=B): pass'
    var_2 = module_0.parse(str_2)
    metaclass_transformer_1 = MetaclassTransformer(var_2)
    var_3 = metaclass_transformer_1.visit_Module(var_2)


# Generated at 2022-06-25 22:10:14.321046
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:10:18.889504
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    assert metaclass_transformer_0.visit_ClassDef == metaclass_transformer_0._visit_ClassDef


# Generated at 2022-06-25 22:10:22.033649
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit_ClassDef(var_0.body[0])
    str_1 = module_0.unparse(var_1)
    str_2 = 'class A(_py_backwards_six_withmetaclass(B))'
    assert str_1 == str_2

# Generated at 2022-06-25 22:10:24.917347
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_1 = module_0.parse(str_0)
    var_2 = MetaclassTransformer(var_1)
    var_3 = var_2.visit(var_1)
    assert str(var_3) == '\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass'

# Generated at 2022-06-25 22:10:26.974278
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a = MetaclassTransformer(None)
    b = "fadsfasdf"
    c = a.visit_Module(b)


# Generated at 2022-06-25 22:10:30.677958
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'def f(): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit_Module(var_0)


# Generated at 2022-06-25 22:10:35.235393
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_2 = module_0.parse("class A(metaclass=B): pass")
    metaclass_transformer_0 = MetaclassTransformer(var_2)
    var_3 = hasattr(metaclass_transformer_0, "visit")


# Generated at 2022-06-25 22:10:38.870699
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer.__init__(MetaclassTransformer(module_0.parse('class A(metaclass=B): pass')))


# Generated at 2022-06-25 22:10:41.669232
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)


# Generated at 2022-06-25 22:10:48.142202
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    try:
        module_0.mod('')
    except RuntimeError:
        module_0.mod
    else:
        try:
            assert nnn
        except AssertionError:
            try:
                module_0.mod
            except RuntimeError:
                module_0.mod
            else:
                try:
                    assert nnn
                except AssertionError:
                    try:
                        module_0.mod
                    except RuntimeError:
                        module_0.mod
                    else:
                        try:
                            assert nnn
                        except AssertionError:
                            try:
                                module_0.mod
                            except RuntimeError:
                                module_0.mod

# Generated at 2022-06-25 22:11:02.532099
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)
    str_1 = str(var_1)
    str_2 = 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass\n'
    assert(str_1 == str_2)

# Generated at 2022-06-25 22:11:06.876764
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    def test_case_0():
        str_0 = 'class A(metaclass=B): pass'
        var_0 = module_0.parse(str_0)
        metaclass_transformer_0 = MetaclassTransformer(var_0)
        var_1 = metaclass_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:11:17.393847
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit_Module(var_0)
    var_2 = module_0.Module(body=[
        module_0.Expr(value=module_0.Call(
            func=module_0.Name(id='six_import', ctx=module_0.Load()),
            args=[],
            keywords=[],
            starargs=None,
            kwargs=None))
        ],
        type_ignores=[])

# Generated at 2022-06-25 22:11:21.189017
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:11:22.590497
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    test_case_0()
    test_case_1()

# Generated at 2022-06-25 22:11:24.198363
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_0 = MetaclassTransformer(target=() , dependencies=())


# Generated at 2022-06-25 22:11:28.318080
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:11:29.962896
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    l_0 = MetaclassTransformer(ast.Assign(),  (2, 7), ['six'], {})


# Generated at 2022-06-25 22:11:36.770582
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:11:40.142372
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_1 = 'class A(metaclass=B): pass'
    var_2 = module_0.parse(str_1)
    metaclass_transformer_1 = MetaclassTransformer(var_2)
    var_3 = metaclass_transformer_1.visit_Module(var_2)
    var_4 = var_3.body[0].body[0]
    assert isinstance(var_4, module_0.ImportFrom)


# Generated at 2022-06-25 22:11:55.950105
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)


# Generated at 2022-06-25 22:11:56.731470
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    test_case_0()


# Generated at 2022-06-25 22:11:57.721864
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert True


# Generated at 2022-06-25 22:12:05.791916
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclass_transformer_0 = MetaclassTransformer(None)
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    var_1 = module_0.ClassDef(name = 'A',
                              bases = [],
                              keywords = [module_0.keyword(arg = 'metaclass',
                                                           value = module_0.Name(id = 'B',
                                                                                ctx = module_0.Load()))],
                              body = [],
                              decorator_list = [])
    var_2 = metaclass_transformer_0.visit_ClassDef(var_1)
    var_3 = var_2.bases[0]

# Generated at 2022-06-25 22:12:09.404442
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:12:10.422350
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    test_case_0()

# Generated at 2022-06-25 22:12:18.443241
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    str_1 = 'six'
    var_1 = str_1
    var_2 = [var_1]
    var_3 = metaclass_transformer_0.set_dependencies(var_2)
    str_2 = 'test_case_0'
    var_4 = str_2
    var_5 = metaclass_transformer_0.visit(var_0)
    var_6 = metaclass_transformer_0.transformed()


# Generated at 2022-06-25 22:12:25.739271
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():

    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    assert type(var_0) == module_0.Module

    metaclass_transformer_0 = MetaclassTransformer(var_0)
    assert type(metaclass_transformer_0) == MetaclassTransformer
    assert type(metaclass_transformer_0.tree) == module_0.Module

    var_1 = metaclass_transformer_0.visit(var_0)
    assert type(var_1) == module_0.Module

# Generated at 2022-06-25 22:12:27.816149
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert(hasattr(MetaclassTransformer, '__init__'))
    assert(hasattr(MetaclassTransformer, 'visit_ClassDef'))

# Generated at 2022-06-25 22:12:32.077413
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:13:04.211418
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:13:10.139249
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)
    str_1 = module_0.unparse(var_1)
    str_2 = 'class A(_py_backwards_six_withmetaclass(B))\n    pass'
    assert str_1 in str_2
    

# Generated at 2022-06-25 22:13:14.442446
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit_Module(var_0)


# Generated at 2022-06-25 22:13:19.368415
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)



# Generated at 2022-06-25 22:13:20.163237
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    test_case_0()


# Generated at 2022-06-25 22:13:21.288022
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_0 = MetaclassTransformer()


# Generated at 2022-06-25 22:13:27.392163
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    metaclass_transformer_0.visit(var_0)
    var_1 = metaclass_transformer_0._tree_changed
    str_1 = 'True'
    var_2 = str(var_1) == str_1


# Generated at 2022-06-25 22:13:32.135949
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit_Module(var_0)
    assert var_1 == var_0


# Generated at 2022-06-25 22:13:41.133296
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    six_import_0 = six_import()
    assert six_import_0.get_file_text() == "from six import with_metaclass as _py_backwards_six_withmetaclass"
    class_bases_0 = class_bases(a, b)
    assert class_bases_0.get_file_text() == "from six import with_metaclass as _py_backwards_six_withmetaclass"
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:13:47.563262
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)
    module_0.fix_missing_locations(var_1)
    assert_equal(str(var_1), 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)):\n\tpass')


# Generated at 2022-06-25 22:14:54.576479
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit_Module(var_0)
    # assert not contains_call(var_1.body, '_py_backwards_six_with_metaclass')


# Generated at 2022-06-25 22:15:01.583342
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = module_0.Module(body=[six_import.get_body(), module_0.ClassDef(name='A', bases=[class_bases.get_body(metaclass=var_0.body[0].body[0].keywords[0].value, bases=var_0.body[0].body[0].bases)], body=[], decorator_list=[])])
    var_2 = metaclass_transformer_0.visit_Module(var_0)
    assert var_2 == var_1


# Generated at 2022-06-25 22:15:11.164329
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    var_1 = MetaclassTransformer(var_0)
    var_2 = var_1.visit_Module(var_1.node)
    def check_0(body):
        assert body[0] == module_0.ImportFrom(
            module='six',
            names=[module_0.alias(
                asname='_py_backwards_six_withmetaclass',
                name='with_metaclass')],
            level=0)

# Generated at 2022-06-25 22:15:11.912475
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    pass


# Generated at 2022-06-25 22:15:15.455076
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:15:22.631119
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_1 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_1)
    var_2 = metaclass_transformer_0.visit_ClassDef(var_0.body[0])


# Generated at 2022-06-25 22:15:23.695948
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    test_case_0()
    test_MetaclassTransformer_0()


# Generated at 2022-06-25 22:15:32.057656
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    var_2 = module_0.ClassDef(name = 'test0', bases = [], body = [], decorator_list = [])
    var_3 = module_0.ClassDef(name = 'test1', bases = [], body = [], decorator_list = [], keywords = [module_0.keyword(arg = 'metaclass', value = module_0.Name(id = 'v0'))])
    str_1 = 'class test(metaclass=v): pass'
    var_4 = module_0.parse(str_1)
    var_5 = var_4.body[0]
    var_6 = module_0.parse('v0')
    var_7 = var_6.body[0]
    var_8 = module_0.parse('v')
    var_9 = var_

# Generated at 2022-06-25 22:15:37.055561
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:15:39.472750
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_2 = module_0.parse('class A(metaclass=B): pass')
    metaclass_transformer_1 = MetaclassTransformer(var_2)
