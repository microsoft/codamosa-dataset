

# Generated at 2022-06-25 22:07:34.782513
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

    a_s_t_1 = module_0.ClassDef(name='A', bases=[], keywords=[], body=[], decorator_list=[])
    a_s_t_2 = metaclass_transformer_0.visit_ClassDef(a_s_t_1)

    if True:
        assert isinstance(a_s_t_2, module_0.ClassDef)
        assert a_s_t_2.name == 'A'
        assert a_s_t_2.bases == []
        assert a_s_t_2.keywords == []
        assert a_s_t_2.body == []
        assert a

# Generated at 2022-06-25 22:07:42.213905
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    source_0 = """
    class A(metaclass=B):
        pass
    """
    expected_0 = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    actual_0 = metaclass_transformer_0.visit(source_0)
    assert actual_0 == expected_0

# Generated at 2022-06-25 22:07:44.888725
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    classdef_2 = module_0.ClassDef()
    print(metaclass_transformer_1.visit_ClassDef(classdef_2))
    pass


# Generated at 2022-06-25 22:07:54.122776
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef(name='A', body=[module_0.Pass()], keywords=[module_0.keyword(arg='metaclass', value=module_0.Name(id='B', ctx=module_0.Load()))])
    classdef_1 = module_0.ClassDef(name='A', body=[module_0.Pass()], bases=[module_0.Call(func=module_0.Name(id='_py_backwards_six_withmetaclass', ctx=module_0.Load()), args=[module_0.Name(id='B', ctx=module_0.Load())], keywords=[])])

# Generated at 2022-06-25 22:08:03.069000
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module0 = ast.Module()
    module0.body = [ast.ClassDef(name='A', **{'bases': [], 'keywords': [ast.keyword(value=ast.Name(id='B', ctx=ast.Load()), arg='metaclass')]})]
    metaclass_transformer0 = MetaclassTransformer(ast3.Tree())
    metaclass_transformer0.visit_ClassDef(module0.body[0])
    ast3.fix_missing_locations(module0)

# Generated at 2022-06-25 22:08:12.145571
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef(name='class_name_0')
    metaclass_transformer_0 = MetaclassTransformer(module_0.AST())
    module_0.ClassDef(name='class_name_0')
    keywords_0 = [module_0.keyword(arg='metaclass_arg_0'), module_0.keyword(arg='metaclass_arg_1')]
    metaclass_transformer_0.visit(module_0.ClassDef(name='class_name_0', keywords=keywords_0))
    metaclass_transformer_0.visit(module_0.ClassDef(name='class_name_0'))
    metaclass_transformer_0.visit(class_def_0)



# Generated at 2022-06-25 22:08:12.724997
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    pass

# Generated at 2022-06-25 22:08:23.679246
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # See: https://mail.python.org/pipermail/python-ideas/2012-May/014969.html

    a_s_t_0 = ast.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_0 = ast.Module(body=[ast.ClassDef(name='A', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kwarg=None, defaults=[], kw_defaults=[]), body=[], decorator_list=[], keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))])])
    metaclass_transformer_0.visit(module_0)

# Generated at 2022-06-25 22:08:32.384894
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_0 = module_0.Name(id='metaclass', ctx=module_0.Load())
    keyword_0 = module_0.keyword(arg='metaclass', value=metaclass_0)
    class_def_0 = module_0.ClassDef(name='A', bases=[], keywords=[keyword_0], body=[], decorator_list=[])
    assert metaclass_transformer_0.visit_ClassDef(class_def_0) == class_def_0

# Generated at 2022-06-25 22:08:39.144152
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # Python:
    #     class A(metaclass=B):
    #         pass
    # 
    module_0_body_0 = (
        module_0.ClassDef(
            name='A',
            bases=(
                module_0.Name(
                    id='B',
                    ctx=module_0.Load(),
                ),
            ),
            keywords=(
            ),
            body=(
                module_0.Pass(),
            ),
            decorator_list=(
            ),
        ),
    )

# Generated at 2022-06-25 22:08:50.286829
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_1.lineno = class_def_0.lineno
    module_0.ClassDef.keywords = [module_0.keyword(arg='metaclass', value=None)]
    module_0.keyword.value = module_1.B()
    class_def_1.lineno = None
    class_def_1.keywords = []
    module_0.AST.find_global = module_2.find_global

# Generated at 2022-06-25 22:08:53.693091
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclass_transformer_0 = MetaclassTransformer()
    metaclass_transformer_0.visit_ClassDef()
    arg_0 = class_def_0
    res_0 = metaclass_transformer_0.visit_ClassDef(arg_0)



# Generated at 2022-06-25 22:08:58.989976
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:09:03.469837
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    class_def_0.keywords = [module_0.keyword(arg='metaclass',value=module_0.Num(n=1))]
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:09:06.817099
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Python 3 AST
    import ast
    import typed_ast.ast3 as ast3
    a = ast3.parse('pass')
    a_obj = MetaclassTransformer.visit_ClassDef(a)


# Generated at 2022-06-25 22:09:08.193867
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert True


import typed_ast.ast3 as module_1


# Generated at 2022-06-25 22:09:10.378663
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = MetaclassTransformer(module_0.AST())
    class_def_0 = module_0.visit_ClassDef(module_0.ClassDef())

# Generated at 2022-06-25 22:09:16.356224
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    MetaclassTransformer(a_s_t_0).visit_ClassDef(class_def_0)

if __name__ == '__main__':
    test_case_0()
    test_MetaclassTransformer_visit_ClassDef()

# Generated at 2022-06-25 22:09:17.861960
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert False, 'Not implemented'

import typed_ast.ast3 as module_1


# Generated at 2022-06-25 22:09:22.315473
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = metaclass_transformer_0.visit_ClassDef(module_0_0)

# Generated at 2022-06-25 22:09:31.748061
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # get input for test
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # execute method of object
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    # compare results
    assert class_def_1 == class_def_0


# Generated at 2022-06-25 22:09:40.101054
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


class_bases.set_body(
    _py_backwards_six_withmetaclass(metaclass, *bases)
)



# Generated at 2022-06-25 22:09:45.437439
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:09:46.302266
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()

# Generated at 2022-06-25 22:09:50.493501
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:09:54.714313
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:09:58.820116
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:10:03.572851
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:10:11.402677
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert isinstance(class_def_1, module_0.ClassDef)

if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 22:10:17.447990
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 22:10:33.223155
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

if __name__ == '__main__':
    module_0 = module_0
    metaclass_transformer_0 = metaclass_transformer_0
    a_s_t_0 = a_s_t_0
    class_def_0 = class_def_0
    class_def_1 = class_def_1

# Generated at 2022-06-25 22:10:37.386102
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def = module_0.ClassDef()
    metaclass_transformer = MetaclassTransformer(module_0.AST())
    class_def_0 = metaclass_transformer.visit_ClassDef(class_def)

# Generated at 2022-06-25 22:10:42.173780
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    # Imports

    # Setup
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

    # Testing
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:10:42.668733
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert True

# Generated at 2022-06-25 22:10:46.464723
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Test with keyword arguments
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:10:51.574324
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:10:59.115729
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import _ast
    import typed_astunparse

    class_def_0 = _ast.ClassDef(name='A',
                                bases=[],
                                keywords=[],
                                body=[],
                                decorator_list=[])
    a_s_t_0 = _ast.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert typed_astunparse.dump(class_def_1) == 'class A():\n    pass\n'


# Generated at 2022-06-25 22:11:03.835757
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:11:06.994328
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # TODO: Add expected result
    pass

# Generated at 2022-06-25 22:11:17.445553
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0_0_0=ast.Module()
    class_def_0_0_0=ast.ClassDef()
    class_def_0_0_0.name=ast.Name()
    class_def_0_0_0.name.ctx=ast.Load()
    class_def_0_0_0.name.id="A"
    class_def_0_0_0.bases=[ast.Name()]
    class_def_0_0_0.bases[0].ctx=ast.Load()
    class_def_0_0_0.bases[0].id="metaclass"
    class_def_0_0_0.bases[0].annotation=ast.Name()
    class_def_0_0_0.bases[0].annotation.ctx=ast

# Generated at 2022-06-25 22:11:39.247466
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:11:43.688846
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:11:50.679586
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = module_0
    module_0.ClassDef = module_0.ClassDef
    module_0.AST = module_0.AST

    # FIXME: Create instance of typed_ast.AST
    module_0.AST = module_0.AST
    module_0.AST = module_0.AST

    module_0.AST = module_0.AST
    visit_ClassDef = MetaclassTransformer.visit_ClassDef

    # FIXME: Create instance of typed_ast.ClassDef
    module_0.ClassDef = module_0.ClassDef

# Generated at 2022-06-25 22:11:54.674517
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


if __name__ == '__main__':
    from . import main
    main(__file__)

# Generated at 2022-06-25 22:11:55.486151
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()

# Generated at 2022-06-25 22:12:00.442849
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
  six_import_0 = snippet()
  class A(metaclass=B):
    pass
  class_def_0 = module_0.ClassDef()
  a_s_t_0 = module_0.AST()
  metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
  class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:12:06.299359
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Test target method
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()

    # Test parameters
    # a_s_t_0.
    # class_def_0.

    # Test assignment statements
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

    # Test method call statements
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert True


# Generated at 2022-06-25 22:12:13.881933
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast._ast3 as module_0
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = class_def_0
    try:
        assert class_def_1 == class_def_2
    except AssertionError:
        raise AssertionError(class_def_1 + " != " + class_def_2)


# Generated at 2022-06-25 22:12:19.667357
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Check the result of method visit_ClassDef on ClassDef objects
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert class_def_1.__class__ == module_0.ClassDef


# Generated at 2022-06-25 22:12:24.556370
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:12:57.828012
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:13:01.732096
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:13:05.565821
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:13:09.403054
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:13:10.467524
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()

import six as module_1


# Generated at 2022-06-25 22:13:11.216893
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert True

# Generated at 2022-06-25 22:13:15.180143
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:13:19.834859
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:13:25.421236
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:13:31.082966
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:14:41.207926
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert class_def_1 is None


# Generated at 2022-06-25 22:14:45.834259
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast._ast3 as module_0
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:14:52.631895
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Arrange
    class_def_0 = module_0.ClassDef()

    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # Act
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    # Assert
    try:
        assert class_def_1 == class_def_0
    except AssertionError as e:
        print(e)

test_case_0()
test_MetaclassTransformer_visit_ClassDef()

# Generated at 2022-06-25 22:14:53.456932
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert 1==1


# Generated at 2022-06-25 22:15:00.026472
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Method-call expected:
    # module_0.ClassDef()
    # module_0.AST()
    # MetaclassTransformer(module_0.AST())
    # MetaclassTransformer.visit_ClassDef(module_0.ClassDef())
    #
    #
    # Return value expected:
    # module_0.ClassDef()
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    test_case_0()
    assert class_def_1 == module_0.ClassDef()


# Generated at 2022-06-25 22:15:04.600394
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert class_def_1 is None


# Generated at 2022-06-25 22:15:09.939732
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Fixture:
    class_def_2 = module_0.ClassDef()
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    # Test:
    class_def_3 = metaclass_transformer_1.visit_ClassDef(class_def_2)

# Generated at 2022-06-25 22:15:13.396421
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:15:22.631612
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:15:23.994539
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = modul