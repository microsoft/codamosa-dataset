

# Generated at 2022-06-25 22:07:32.723960
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-25 22:07:41.673981
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_s_t_0 = module_0.Module(body=[])
    module_s_t_0.body.append(module_0.ClassDef(name='A', bases=[], body=[], keywords=[], starargs=None, kwargs=None, decorator_list=[]))
    expect_value_1 = module_0.Module(body=[module_0.ImportFrom(module='six', names=[module_0.alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=1, lineno=1, col_offset=0)])

# Generated at 2022-06-25 22:07:46.602245
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = module_0.ClassDef(name='A', body=[], decs=[])
    a_s_t_0.fix_missing_locations(a_s_t_1)
    assert(str(metaclass_transformer_0.visit(a_s_t_1)) == 'class A(): pass')
    a_s_t_2 = module_0.ClassDef(name='A', body=[], decs=[], keywords=[module_0.Keyword(arg='metaclass', value=module_0.Name(id='B', ctx=module_0.Load()))])
    a_s_t

# Generated at 2022-06-25 22:07:55.951193
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    classdef_0_0 = module_0.ClassDef()
    str_literal_0_0 = module_0.Str(s='McTest')
    classdef_0_0.name = str_literal_0_0
    module_0_0.body.append(classdef_0_0)
    metaclass_transformer_0.visit_Module(module_0_0)
    assert metaclass_transformer_0._tree_changed == True
    MetaclassTransformer(a_s_t_0).visit_Module(module_0_0)

# Generated at 2022-06-25 22:07:58.546898
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)


# Generated at 2022-06-25 22:08:07.232888
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Tree builder
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # Inject the original node into a tree that contains the expected modified node.
    # TODO: check the parent nodes of the original node.
    a_s_t_0.body = [module_0.Expr(value=six_import.get_body()), module_0.ClassDef(
        name='A', body=[], keywords=[module_0.keyword(arg='metaclass', value=module_0.Name(id='B', ctx=module_0.Load()))])]
    # Visit the node under test with the tree builder

# Generated at 2022-06-25 22:08:12.282832
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    module_0_1 = metaclass_transformer_0.visit_Module(module_0_0)
    assert module_0_1 is module_0_0


# Generated at 2022-06-25 22:08:15.898901
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_Module(module_0.Module())


# Generated at 2022-06-25 22:08:20.343336
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_2 = metaclass_transformer_0.visit_Module(module_1)


# Generated at 2022-06-25 22:08:31.944659
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    _slice_0 = slice(None, None, None)
    class_def_0 = module_0.ClassDef()
    class_def_0.keywords = [module_0.keyword(arg='metaclass', value=module_0.Name(id='B', ctx=module_0.Param()))]
    class_def_0.bases = [module_0.Name(id='a', ctx=module_0.Load()), module_0.Name(id='metaclass', ctx=module_0.Load())]
    class_def_0.name = 'A'

# Generated at 2022-06-25 22:08:40.026489
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    from typing import Optional
    a_s_t_0 = ast.parse("""class Foo(Bar):""")
    metaclass_transformer_0 = MetaclassTransformer()
    metaclass_transformer_0.visit(a_s_t_0)
    assert metaclass_transformer_0.modified == True


# Generated at 2022-06-25 22:08:49.306592
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-25 22:08:54.120881
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef(name='a0', bases=[], keywords=[], body=[], decorator_list=[])
    result = metaclass_transformer_0.visit_ClassDef(classdef_0)
    assert result == classdef_0


# Generated at 2022-06-25 22:09:03.019366
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code_0 = "'a'"
    code_1 = "'b'"
    code_2 = ""
    code_3 = ""
    code_4 = ""
    code_5 = ""
    code_6 = ""
    code_7 = ""
    code_8 = ""
    code_9 = ""
    code_10 = ""
    code_11 = ""
    code_12 = ""
    code_13 = ""
    code_14 = ""
    code_15 = ""
    code_16 = ""
    code_17 = ""
    code_18 = ""
    code_19 = ""
    code_20 = ""
    code_21 = ""
    code_22 = ""

# Generated at 2022-06-25 22:09:08.335312
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    node_0 = module_0.ClassDef(name='', bases=[], keywords=[], body=[])
    classdef_2 = metaclass_transformer_0.visit_ClassDef(node_0)


# Generated at 2022-06-25 22:09:10.323233
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # No vars.
    # No return.
    pass

# Generated at 2022-06-25 22:09:19.953266
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

    classdef_0 = module_0.ClassDef()
    classdef_0 = metaclass_transformer_0.visit_ClassDef(classdef_0)

    classdef_1 = module_0.ClassDef(name='classdef_1')
    classdef_1 = metaclass_transformer_0.visit_ClassDef(classdef_1)


# Generated at 2022-06-25 22:09:25.907462
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
  a_s_t_0 = module_0.AST()
  metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
  arg_0_1 = module_0.ClassDef(name="A", bases=[], keywords=[], body=[], decorator_list=[])
  arg_0_1.lineno = 0
  arg_0_1.col_offset = 0
  metaclass_transformer_0.visit_ClassDef(arg_0_1)


# Generated at 2022-06-25 22:09:33.281186
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.generic_visit = lambda node: node
    metaclass_transformer_0.visit_Module = lambda node: node
    module_0_0 = module_0.Module(body=[module_0.ClassDef(name='A', bases=[module_0.Name(id='B', ctx=module_0.Load())], keywords=[], body=[], decorator_list=[])])
    assert module_0_0 == metaclass_transformer_0.visit(module_0_0)

# Generated at 2022-06-25 22:09:34.466858
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-25 22:09:41.120319
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:09:45.437265
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Assert assertions
    assert False

    # Assert no exception was raised
    assert True


if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(args=['-v', __file__]))

# Generated at 2022-06-25 22:09:51.104340
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # default initialization to test method
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # default initialization to argument 0
    class_def_0 = None
    metaclass_transformer_0.visit_ClassDef(class_def_0)

if __name__ == '__main__':
    test_case_0()
    test_MetaclassTransformer_visit_ClassDef()

# Generated at 2022-06-25 22:09:54.832716
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:09:58.639327
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:10:01.374145
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:10:06.945668
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:10:12.452374
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Setup test data
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None

    # Invoke method
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

    # Verify method output
    assert class_def_1 == None


# Generated at 2022-06-25 22:10:17.862955
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    try:
        class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    except AttributeError as e:
        pass
    else:
        assert False

# Generated at 2022-06-25 22:10:22.567774
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = None
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)
    pass


# Generated at 2022-06-25 22:10:33.354333
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert class_def_1


# Generated at 2022-06-25 22:10:38.614704
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:10:42.367146
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:10:44.750241
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:10:47.874690
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t = module_0.AST()
    metaclass_transformer = MetaclassTransformer(a_s_t)
    # TODO: Add test cases


# Generated at 2022-06-25 22:10:52.740641
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Arrange
    tree = ast.parse('class A(metaclass=B):\n    pass')
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    node = tree
    # Act
    node = transformer.visit_ClassDef(node)
    # Assert
    #assert () == ('A(_py_backwards_six_withmetaclass(B))')

# Generated at 2022-06-25 22:10:57.022810
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:11:01.301815
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:11:07.897931
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = module_0.ClassDef()
    try:
        class_def_2 = module_0.ClassDef()
    except Exception as except_0:
        pass
    return (class_def_1, class_def_2)


# Generated at 2022-06-25 22:11:17.115369
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_0 = None
    module_1 = a_s_t_0.Module(body=[a_s_t_0.ClassDef(name='A', body=[], keywords=[], decorator_list=[], bases=[])])
    copy_0 = a_s_t_0.Module(body=[a_s_t_0.ClassDef(name='A', body=[], keywords=[], decorator_list=[], bases=[])])
    assert module_1 == copy_0

# Generated at 2022-06-25 22:11:29.831119
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:11:36.504451
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:11:44.057123
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # noinspection PyTypeChecker
    metaclass_transformer_0 = MetaclassTransformer(None)
    class_def_0 = None
    # try-except statement from typed_ast.ast3
    try:
        class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    except Exception as class_def_1:
        pass
    # try-except statement from typed_ast.ast3
    try:
        class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    except Exception as class_def_1:
        pass


# Generated at 2022-06-25 22:11:48.810510
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:11:53.746231
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = None
    class_def_3 = metaclass_transformer_0.visit_ClassDef(class_def_2)

# Generated at 2022-06-25 22:11:57.844030
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    try:
        class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
        assert False
    except:
        assert True



# Generated at 2022-06-25 22:12:01.396639
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = module_0.Module()
    metaclass_transformer_0 = MetaclassTransformer(module_0)
    class_def_0 = module_0.ClassDef()
    module_0.body.append(class_def_0)
    module_0.visit(metaclass_transformer_0)

# Generated at 2022-06-25 22:12:02.555247
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()

# Generated at 2022-06-25 22:12:05.790321
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:12:09.371129
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:12:35.152176
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = None
    class_def_3 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:12:35.727544
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()

# Generated at 2022-06-25 22:12:36.842953
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Arrange
    # Act
    test_case_0()

# Generated at 2022-06-25 22:12:42.101617
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import insert_at
    from .base import BaseNodeTransformer


    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass


    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)


    class MetaclassTransformer(BaseNodeTransformer):
        """Compiles:
            class A(metaclass=B):
                pass
        To:
            class A(_py_backwards_six_with_metaclass(B))
        
        """
        target = (2, 7)
        dependencies

# Generated at 2022-06-25 22:12:48.451842
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    
    # Try to call method 'visit_ClassDef' of class 'MetaclassTransformer'
    try:
        result_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    except Exception:
        print("Exception when executing 'visit_ClassDef' test case 1")


# Generated at 2022-06-25 22:12:52.069741
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_ClassDef(None)


# Generated at 2022-06-25 22:12:57.377231
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    # TODO:
    # print(str(class_def_1))
    assert class_def_1 is not None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:13:00.744440
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    # Test 1
    class_def_0 = None
    metaclass_transformer_0 = MetaclassTransformer(None)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert class_def_1 == class_def_0

# Generated at 2022-06-25 22:13:09.588268
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert isinstance(class_def_1, ast.ClassDef)
    fields = get_fields(class_def_1)
    assert fields['name'] == 'A'
    assert len(fields['bases']) == 1
    assert isinstance(fields['bases'][0], ast.Call)
    assert isinstance(fields['bases'][0].func, ast.Name)
    assert fields['bases'][0].func.id == '_py_backwards_six_with_metaclass'



# Generated at 2022-06-25 22:13:14.804807
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    with pytest.raises(TypeError):
        class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:14:06.585922
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    try:
        assert(class_def_1 is None)
    except AssertionError:
        print('Expected: {}, actual: {}'.format(None, class_def_1))
        raise


# Generated at 2022-06-25 22:14:10.732656
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef(name='A', body=[], decorator_list=[], keywords=[])
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:14:12.974963
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = MetaclassTransformer(None)
    class_def_0 = None
    class_def_1 = module_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:14:15.252143
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = None
    a_s_t_0 = None
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    print(class_def_1)

if __name__ == "__main__":
    test_MetaclassTransformer_visit_ClassDef()

# Generated at 2022-06-25 22:14:20.752858
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef(name="test_MethodTransformer_visit_ClassDef", lineno=None, col_offset=None)
    assert (metaclass_transformer_0.visit_ClassDef(class_def_0) is None)

# Generated at 2022-06-25 22:14:25.871805
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:14:29.627273
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:14:31.887755
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # FIXME (1 errors): No tests found for MetaclassTransformer.visit_ClassDef
    def test_case_0():
        test_case_0()

# Generated at 2022-06-25 22:14:37.228181
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert class_def_1 is class_def_0


# Generated at 2022-06-25 22:14:41.845357
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:16:28.175554
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = None
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:16:31.433215
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:16:35.263171
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = None
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:16:41.689158
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_name_0 = 'A'
    class_def_0 = module_0.ClassDef(name=class_name_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = module_0.ClassDef(name=class_name_0,
                                    bases=[module_0.Name(id='_py_backwards_six_withmetaclass',
                                                         ctx=module_0.Load())])

    class_def_1_name = None
    class_def_1_bases = None


# Generated at 2022-06-25 22:16:43.909347
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    try:
        test_case_0()
    except UnboundLocalError:
        print("Unit test for method visit_ClassDef of class MetaclassTransformer FAILED")

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:16:49.443508
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef(name_0='', bases_0=[], body=[module_0.Pass()], decorator_list=[], keywords=[module_0.keyword('', module_0.Num(0))])
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert(isinstance(class_def_1, module_0.ClassDef))
    assert(str(class_def_1.bases[0]) == '_py_backwards_six_withmetaclass(0)')

# Generated at 2022-06-25 22:16:55.338157
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = module_0
    metaclass_transformer_0 = MetaclassTransformer(module_0.AST())
    class_def_0 = ast.ClassDef(name='Test',
                               bases=[],
                               body=[])
    assert 'object' in [b.id for b in class_def_0.bases]
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert 'object' not in [b.id for b in class_def_1.bases]

    metaclass_transformer_0 = MetaclassTransformer(module_0.AST())

# Generated at 2022-06-25 22:16:58.145350
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_2 = module_0.Module([])
    module_3 = metaclass_transformer_0.visit_Module(module_2)

# Generated at 2022-06-25 22:17:03.639843
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Setup
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef(
        name='A',
        bases=[],
        keywords=[],
        starargs=None,
        kwargs=None,
        body=[],
        decorator_list=[]
    )

    # Assumptions
    assert class_def_0.keywords == []

    # Exercise
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

    # Verify
    assert class_def_1 is class_def_0
    assert class_def_1.keywords == []
    assert metaclass_transformer_

# Generated at 2022-06-25 22:17:06.276044
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
  a_s_t_0 = module_0.AST()
  metaclass_transformer = MetaclassTransformer(a_s_t_0)
  class_def = None # set to an actual value
  metaclass_transformer.visit_ClassDef(class_def)


import unittest
