

# Generated at 2022-06-25 22:07:26.169977
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    class1_classdef_0 = module_0.ClassDef(
        name='class1',
        bases=[],
        keywords=[],
        body=[],
        decorator_list=[],
        starargs=None,
        kwargs=None)
    classdef_2 = metaclass_transformer_1.visit_ClassDef(class1_classdef_0)
    assert classdef_2 == class1_classdef_0, f'Expected: {class1_classdef_0}, but got: {classdef_2}'

# Generated at 2022-06-25 22:07:34.586288
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3

    a_s_t_0 = ast3.parse("""
        class A(B):
            pass
    """
    )
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    if True:
        a_s_t_1 = metaclass_transformer_0.visit(a_s_t_0)
    else:
        a_s_t_1 = object()
    assert a_s_t_1 is a_s_t_0
    a_s_t_2 = ast3.parse("""
        class A(metaclass=B):
            pass
    """
    )
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_2)

# Generated at 2022-06-25 22:07:37.908919
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = ast.parse("""class A(metaclass=B): pass""")
    metaclass_transformer_0 = MetaclassTransformer(module_0)
    metaclass_transformer_0.visit(module_0)

# Generated at 2022-06-25 22:07:46.587770
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

    a_s_t_1 = module_0.AST()
    string_1 = module_0.Str(s='_py_backwards_six_with_metaclass')
    string_2 = module_0.Str(s='B')
    list_0 = module_0.List(elts=[], ctx=module_0.Load())
    call_0 = module_0.Call(func=module_0.Name(id=string_1.s, ctx=module_0.Load()), args=[string_2], keywords=[], starargs=None, kwargs=None)

# Generated at 2022-06-25 22:07:55.950624
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    s_8 = a_s_t_0.Str(s="B")
    a_s_t_0.ClassDef(name="A", bases=a_s_t_0.List(elts=[s_8], ctx=a_s_t_0.Load()), keywords=a_s_t_0.Keyword(arg=a_s_t_0.Str(s="metaclass"), value=s_8), body=[a_s_t_0.Pass()])

# Generated at 2022-06-25 22:07:59.880554
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    node = module_0.ClassDef()
    metaclass_transformer_0.visit_ClassDef(node)


# Generated at 2022-06-25 22:08:08.509081
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = module_0.Module([module_0.ClassDef('A', [module_0.Name('B', module_0.Load()), module_0.Name('C', module_0.Load())], [], [module_0.Keyword(arg='metaclass', value=module_0.Name('B', module_0.Load()))])])
    

# Generated at 2022-06-25 22:08:18.463696
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef(
        name='Transformer',
        bases=[],
        keywords=[module_0.keyword(arg='metaclass', value=module_0.Name(id='abc', ctx=module_0.Load()))],
        body=[module_0.Pass()],
        decorator_list=[],
        lineno=1,
        col_offset=1,
        end_lineno=2,
        end_col_offset=2
    )
    metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:08:21.490969
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)


# Generated at 2022-06-25 22:08:22.748688
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # TODO: add test
    pass

# Generated at 2022-06-25 22:08:34.161701
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclass_transformer_0 = MetaclassTransformer(None)
    var_2 = module_0.parse('class A(metaclass=B): pass')
    var_3 = module_0.ClassDef(name='A',
                              bases=[],
                              keywords=[],
                              body=[],
                              decorator_list=[])
    var_3.lineno = 1
    var_3.col_offset = 0
    var_4 = module_0.Name(id='metaclass',
                          ctx=module_0.Load(),
                          lineno=1,
                          col_offset=7)
    var_5 = module_0.Name(id='B',
                          ctx=module_0.Load(),
                          lineno=1,
                          col_offset=17)


# Generated at 2022-06-25 22:08:36.593684
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    module_0 = ast.parse('class A(metaclass=B): pass')
    metaclass_transformer_0 = MetaclassTransformer(module_0)
    module_1 = metaclass_transformer_0.visit(module_0)

# Generated at 2022-06-25 22:08:37.203188
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    pass


# Generated at 2022-06-25 22:08:40.843836
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit_Module(var_0)


# Generated at 2022-06-25 22:08:50.042010
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)
    assert not hasattr(var_1, '__name__')
    assert not hasattr(var_1, '__getitem__')
    assert not hasattr(var_1, '__setitem__')
    assert not hasattr(var_1, '__delitem__')
    assert not hasattr(var_1, '__iter__')
    assert not hasattr(var_1, '__init__')
    assert not hasattr(var_1, '__new__')

# Generated at 2022-06-25 22:08:59.285453
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    def function_0(arg_0, arg_1):
        module_0.ClassDef(arg_0, arg_1, [], [], [], None)
    class_def_0 = module_0.ClassDef('name', [], [], [], [], None)
    metaclass_transformer_0 = MetaclassTransformer(class_def_0)
    metaclass_transformer_0.generic_visit = function_0
    def function_1(arg_0):
        metaclass_transformer_0.generic_visit(arg_0)
    metaclass_transformer_0.visit = function_1
    metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:09:02.641296
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:09:11.799998
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_2 = MetaclassTransformer(module_0.Module(body=[module_0.ClassDef(name='A', bases=[module_0.Name(id='B', ctx=module_0.Load())], keywords=[module_0.keyword(arg='metaclass', value=module_0.Name(id='B', ctx=module_0.Load()))], body=[], decorator_list=[])]))
    assert isinstance(var_2, MetaclassTransformer)

# Generated at 2022-06-25 22:09:17.455717
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:09:18.607846
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    test_case_0()


# Generated at 2022-06-25 22:09:23.897388
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():

    # Normal case for instantiating MetaclassTransformer
    metaclass_transformer_0 = MetaclassTransformer(str_0)
    assert isinstance(metaclass_transformer_0, MetaclassTransformer)

# Generated at 2022-06-25 22:09:31.322071
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = module_0.Module(body=[module_0.Expr(value=module_0.Call(func=module_0.Attribute(value=module_0.Name(id='six', ctx=module_0.Load()), attr='with_metaclass', ctx=module_0.Load()), args=[module_0.Name(id='_py_backwards_six_withmetaclass', ctx=module_0.Load())], keywords=[]))], type_ignores=[])

# Generated at 2022-06-25 22:09:36.338541
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:09:46.164288
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit_ClassDef(var_0.body[0])
    assert isinstance(var_1, module_0.ClassDef) == True
    assert isinstance(var_1.name, str) == True
    assert var_1.name == 'A'
    assert isinstance(var_1.bases[0], module_0.Call) == True
    assert isinstance(var_1.bases[0].func, module_0.Name) == True
    assert isinstance(var_1.bases[0].func.id, str)

# Generated at 2022-06-25 22:09:55.030616
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = module_0.ClassDef(name = 'A', bases = module_0.List( elts = [], ctx = module_0.Load()), keywords = [module_0.keyword( arg = 'metaclass', value = module_0.Name( id = 'B', ctx = module_0.Load())),], body = [module_0.Pass()], decorator_list = [])
    var_2 = metaclass_transformer_0.visit_ClassDef(var_1)

    ast.fix_missing_locations(var_2)
    codeobj_0

# Generated at 2022-06-25 22:10:00.725974
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_2 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_2)
    var_3 = metaclass_transformer_0.visit(var_2)
    var_1 = module_0.parse(str_0)
    var_3.bases = var_1.body[0].bases
    var_3.keywords = var_1.body[0].keywords


# Generated at 2022-06-25 22:10:02.093953
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    test_case_0()


# Generated at 2022-06-25 22:10:03.114356
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    test_case_0()


# Generated at 2022-06-25 22:10:08.962904
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:10:10.542031
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    metaclass_transformer_0 = MetaclassTransformer(None)


# Generated at 2022-06-25 22:10:17.308985
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    pass


# Generated at 2022-06-25 22:10:25.127986
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)
    var_2 = var_1.body[0]
    var_3 = 'from six import with_metaclass as _py_backwards_six_withmetaclass'
    var_4 = module_0.parse(var_3)
    var_5 = module_0.Expr(var_4.body[0].value)
    var_6 = module_0.parse(var_3).body[0]
    assert(var_2 == var_5)

# Generated at 2022-06-25 22:10:27.690897
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class_0 = MetaclassTransformer(object)
    assert str(type(class_0)) == "<class 'tests.test_metaclass.MetaclassTransformer'>"


# Generated at 2022-06-25 22:10:34.629524
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit_ClassDef({'elts': [{'col_offset': 0, 'lineno': 1, 'end_lineno': 1, 'value': 'class A(metaclass=B): pass'}]})


# Generated at 2022-06-25 22:10:38.707972
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # var_0 = Module('class A(metaclass=B): pass')
    # metaclass_transformer_0 = MetaclassTransformer(var_0)
    pass


# Generated at 2022-06-25 22:10:46.378608
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)
    # AssertionError: expected:
    #    [<_ast.ImportFrom at 0x7f5de5a26450>, <_ast.Import at 0x7f5de5a26550>, <_ast.Assign at 0x7f5de5a26750>, <_ast.Assign at 0x7f5de5a26710>, <_ast.Expr at 0x7f5de5a267d0>, <_ast.ClassDef at 0x7f5de5a26690>]

# Generated at 2022-06-25 22:10:47.544675
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()


# Generated at 2022-06-25 22:10:48.937665
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Test method visit_ClassDef of class MetaclassTransformer"""
    test_case_0()

# Generated at 2022-06-25 22:10:53.179165
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:10:58.431954
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)
    assert '_py_backwards_six_withmetaclass' in str(var_1)


# Generated at 2022-06-25 22:11:17.152370
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(B): pass'
    var_0 = module_0.parse(str_0)
    var_1 = MetaclassTransformer(var_0)
    var_2 = var_1.visit(var_0)
    try:
        var_2.body[0].keywords
    except:
        pass
    else:
        assert False


# Generated at 2022-06-25 22:11:21.912381
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)
    assert isinstance(metaclass_transformer_0, MetaclassTransformer)


# Generated at 2022-06-25 22:11:30.092125
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # Ensure the transformed tree can be compiled
    # tree = MetaclassTransformer(six_import, 'six').visit(tree)
    # compile(tree, '<test>', 'exec')

    # Tests that the tree was changed
    # assert MetaclassTransformer().visit(ast.parse('class A(object): pass'))
    # assert not MetaclassTransformer().visit(ast.parse('class A(object): pass'))
    # assert MetaclassTransformer(six_import, 'six').visit(six_import)
    # assert MetaclassTransformer(six_import, 'six').visit(tree)
    pass


if __name__ == '__main__':
    test_case_0()
    test_MetaclassTransformer()

# Generated at 2022-06-25 22:11:35.611278
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclass_transformer_0 = MetaclassTransformer(module_0.AST())
    metaclass_transformer_0.visit_ClassDef(module_0.ClassDef('', [], [], [], []))


# Generated at 2022-06-25 22:11:40.471681
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)
    assert metaclass_transformer_0._tree_changed == True


# Generated at 2022-06-25 22:11:44.599659
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:11:49.402371
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    def test_metaclass_transformer_0():
        metaclass_transformer_0.visit(var_0)



# Generated at 2022-06-25 22:11:53.144408
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:11:56.331151
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)



# Generated at 2022-06-25 22:11:57.166730
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    test_case_0()


# Generated at 2022-06-25 22:12:25.399834
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:12:29.958604
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    module_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(module_0)
    module_1 = metaclass_transformer_0.visit_Module(module_0)


# Generated at 2022-06-25 22:12:32.861774
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    var_2 = module_0.Module(body=[])
    metaclass_transformer_1 = MetaclassTransformer(var_2)
    var_3 = metaclass_transformer_1.visit(var_2)


# Generated at 2022-06-25 22:12:40.197142
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Test to see if the transformer is working on a simple example
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)
    str_1 = module_0.dump(var_1)

# Generated at 2022-06-25 22:12:49.135433
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)
    assert type(var_1) is module_0.Module
    assert len(var_1.body) == 2
    assert type(var_1.body[0]) is module_0.ImportFrom
    assert var_1.body[0].lineno == 1
    assert var_1.body[0].col_offset == 0
    assert var_1.body[0].level == 0
    assert var_1.body[0].module == 'six'

# Generated at 2022-06-25 22:12:53.909985
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    assert metaclass_transformer_0.visit(var_0) == "\nimport six\nclass A(six.with_metaclass(B)):\n    pass"

# Generated at 2022-06-25 22:13:02.302245
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast as module_0
    import io as module_1
    import unittest as module_2
    import sys as module_3
    import os as module_4
    import six as module_5
    import itertools as module_6
    import collections as module_7
    import future.utils as module_8
    import sys as module_9
    import typing as module_10
    import enum as module_11
    import unittest.case as module_12
    import typing_extensions as module_13
    import textwrap as module_14
    import typing as module_15
    import six as module_16
    class UnwrappedClass_0(module_10.NamedTuple):
        __slots__ = ()

# Generated at 2022-06-25 22:13:06.285927
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)

test_case_0()
test_MetaclassTransformer()

# Generated at 2022-06-25 22:13:07.150775
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    pass


# Generated at 2022-06-25 22:13:08.796438
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    ast_0 = None
    metaclass_transformer_0 = MetaclassTransformer(ast_0)

# Generated at 2022-06-25 22:14:06.076410
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    str_1 = 'class A(_py_backwards_six_withmetaclass(B)): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)
    assert(module_0.unparse(var_1) == str_1)


# Generated at 2022-06-25 22:14:09.447957
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit_Module(var_0)


# Generated at 2022-06-25 22:14:09.908204
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    pass

# Generated at 2022-06-25 22:14:15.718281
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    six_import_body_0 = six_import.get_body()
    var_2 = module_0.ClassDef(name=module_0.Name(id='A', ctx=module_0.Load()), bases=[], keywords=[], body=[], decorator_list=[])
    ast_0 = module_0.parse(six_import_body_0)
    metaclass_transformer_1 = MetaclassTransformer(ast_0, var_2)
    metaclass_transformer_1.visit(ast_0)


# Generated at 2022-06-25 22:14:20.333701
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:14:21.864989
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    test_case_0()

implemented_snippets = [six_import, class_bases]

# Generated at 2022-06-25 22:14:22.686025
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    pass # TODO: Implement test


# Generated at 2022-06-25 22:14:29.425238
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    try:
        str_0 = 'class A(metaclass=B): pass'
        var_0 = module_0.parse(str_0)
        metaclass_transformer_0 = MetaclassTransformer(var_0)
        var_1 = metaclass_transformer_0.visit(var_0.body[0])
        assert isinstance(var_1, module_0.ClassDef)
    except Exception:
        var_2 = None
    else:
        var_2 = True
    finally:
        assert var_2



# Generated at 2022-06-25 22:14:32.788449
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:14:40.240126
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)

    with patch.object(metaclass_transformer_0, 'generic_visit', autospec=True) as mock_generic_visit:
        var_1 = metaclass_transformer_0.visit_Module(var_0)
        assert var_1 == var_0


# Generated at 2022-06-25 22:16:40.284405
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:16:41.149233
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    var_0 = MetaclassTransformer()


# Generated at 2022-06-25 22:16:47.052741
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:16:52.354687
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)
    assert metaclass_transformer_0._tree_changed == False
    assert metaclass_transformer_0._dependencies_changed == False
    assert class_bases.get_body(metaclass=var_0.body[0].keywords[0].value, bases=module_0.List(elts=[], ctx=module_0.Load())) == var_1.body[0].bases
    assert metaclass_transformer_0._tree_changed == True
    assert metaclass_

# Generated at 2022-06-25 22:16:53.181020
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer is MetaclassTransformer


# Generated at 2022-06-25 22:16:56.501969
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    metaclass_transformer_0.visit_Module(var_0)


# Generated at 2022-06-25 22:16:59.221607
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:17:01.923608
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit_ClassDef(module_0.parse(str_0).body[0])

# Generated at 2022-06-25 22:17:04.838726
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import typed_ast.ast3 as module_0
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:17:07.526142
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    str_0 = 'class A(metaclass=B): pass'
    var_0 = module_0.parse(str_0)
    metaclass_transformer_0 = MetaclassTransformer(var_0)
    var_1 = metaclass_transformer_0.visit(var_0)
