

# Generated at 2022-06-25 22:07:29.305769
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    module_1 = module_0.Module()
    module_1_0 = module_1.body

# Generated at 2022-06-25 22:07:33.215439
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()

    metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:07:38.232956
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    metaclass_transformer_0 = MetaclassTransformer(module_0.AST())
    metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:07:43.563109
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef(name='', bases=[], keywords=[], body=[], decorator_list=[])
    metaclass_transformer_0.visit_ClassDef(classdef_0)
    # a_s_t_0.dump(classdef_0)

# Generated at 2022-06-25 22:07:52.961765
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef(name='A', bases=[], keywords=[], body=[], decorator_list=[], lineno=0, col_offset=0)
    classdef_0.keywords.append(module_0.keyword(arg='metaclass', value=module_0.Load()))
    classdef_0_copy_0 = copy.deepcopy(classdef_0)
    result_0 = metaclass_transformer_0.visit_ClassDef(classdef_0)

# Generated at 2022-06-25 22:08:01.864992
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    required_module_0 = module_0.Name()
    required_module_0.id = 'six'
    required_module_0.ctx = module_0.Load()
    required_module_0.lineno = None
    required_module_0.col_offset = None
    required_module_1 = module_0.Name()
    required_module_1.id = 'six'
    required_module_1.ctx = module_0.Load()
    required_module_1.lineno = None
    required_module_1.col_offset = None
    required_module_2 = module_0.Name()
    required_module_2.id

# Generated at 2022-06-25 22:08:10.733501
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    node0 = module_0.ClassDef()
    node1 = module_0.Name()
    node2 = module_0.Name()
    node3 = module_0.Name()
    node4 = module_0.Name()
    node5 = module_0.arguments()
    node6 = module_0.arg()
    node7 = module_0.arg()
    node8 = module_0.Name()
    node9 = module_0.Name()
    node10 = module_0.Name()
    node11 = module_0.Name()
    node12 = module_0.Module()
    node13 = module_0.FunctionDef()
   

# Generated at 2022-06-25 22:08:18.380191
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module()
    a_s_t_2 = module_0.ClassDef()
    a_s_t_3 = module_0.arguments()
    a_s_t_1.body = [a_s_t_2]
    a_s_t_4 = metaclass_transformer_0.visit_Module(a_s_t_1)


# Generated at 2022-06-25 22:08:28.602778
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_0_0 = module_0.Module(body=[module_0.ClassDef(name='A', bases=[], keywords=[], body=[], decorator_list=[])])
    metaclass_transformer_0.visit_Module(module_0_0)
    assert (len(module_0_0.body) == 2)
    assert (module_0_0.body[0].__class__ == module_0.ImportFrom)
    assert (module_0_0.body[1].__class__ == module_0.ClassDef)

# Generated at 2022-06-25 22:08:34.122274
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef(name='A',
                                   bases=[],
                                   keywords=[],
                                   body=[],
                                   decorator_list=[])
    metaclass_transformer_0.visit_ClassDef(classdef_0)


# Generated at 2022-06-25 22:08:44.147337
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

# Generated at 2022-06-25 22:08:52.757942
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    import typed_ast._ast3 as module_0
    import typed_ast.ast3 as module_1

    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    testcase_0_ClassDef_0 = module_1.ClassDef(
        name='x',
        bases=[],
        keywords=[],
        body=[],
        decorator_list=[],
        lineno=0,
        col_offset=0
    )
    @jit
    def classdef_method_0():

        @jit
        def classdef_method_1():

            @jit
            def classdef_method_2():

                @jit
                def classdef_method_3():
                    pass
                testcase_5_ClassDef

# Generated at 2022-06-25 22:08:59.943803
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # TODO: fix this
    return True
    #a_s_t_0 = module_0.AST()
    #metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    #classdef_0 = module_0.ClassDef()
    #module.0.ClassDef(bases=[], body=[], decorator_list=[], keywords=[], name='A', starargs=None, kwargs=None)
    #assert_equal(metaclass_transformer_0.visit_ClassDef(classdef_0), None)


# Generated at 2022-06-25 22:09:00.950577
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Do nothing => pass
    pass


# Generated at 2022-06-25 22:09:10.416231
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    class_def_0 = module_0.ClassDef()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_1 = module_0.ClassDef()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_1.visit_ClassDef(class_def_1)
    class_def_2 = module_0.ClassDef()
    metaclass_transformer_2 = MetaclassTransformer(a_s_t_0)

# Generated at 2022-06-25 22:09:20.007972
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef(name='Foo', bases=[module_0.Name('object', module_0.Load())], keywords=[module_0.keyword(arg='metaclass', value=module_0.Name('Bar', module_0.Load()))], body=[], decorator_list=[])
    classdef_0 = metaclass_transformer_0.visit_ClassDef(classdef_0)
    assert len(classdef_0.bases) == 1

# Generated at 2022-06-25 22:09:29.654302
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    node_0 = module_0.ClassDef(0, 1, 2, 3, [], [])
    class_def_0.keywords = []
    class_def_1 = module_0.ClassDef()
    class_def_1.keywords = []
    assert metaclass_transformer_0.visit_ClassDef(node_0) == class_def_1
    node_0 = module_0.ClassDef(0, 1, 2, 3, [], [])
    class_def_0.bases = []
    class_def_1 = module_0.ClassDef()

# Generated at 2022-06-25 22:09:38.762904
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

    module_1 = module_0.Module()
    module_2 = module_0.Module()
    module_2.body.append((module_0.Expr(value=module_0.Call(func=module_0.Name(id='print', ctx=module_0.Load()), args=[module_0.Str(s='Hello, world!')], keywords=[]))))
    module_3 = metaclass_transformer_0.visit(module_2)
    return (module_1, module_2, module_3)


# Generated at 2022-06-25 22:09:48.511108
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    lineno_0 = 0
    col_offset_0 = 0
    metaclass_0 = None
    bases_0 = []
    keywords_0 = []
    body_0 = []
    decorator_list_0 = []
    classdef_0 = module_0.ClassDef(name='ClassDef',  # type: ignore
                                   bases=[],  # type: ignore
                                   keywords=[],  # type: ignore
                                   body=[],  # type: ignore
                                   decorator_list=[])  # type: ignore
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTrans

# Generated at 2022-06-25 22:09:55.574855
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    print("Testing visit_ClassDef")
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0._tree_changed = False
    classdef_0 = module_0.ClassDef()
    metaclass_transformer_0.visit_ClassDef(classdef_0)
    return

# Unit test execution
if __name__ == '__main__':
    test_case_0()
    test_MetaclassTransformer_visit_ClassDef()
    print("Unit tests completed successfully")

# Generated at 2022-06-25 22:10:01.848737
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert True

# Generated at 2022-06-25 22:10:08.397849
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef()
    classdef_1 = metaclass_transformer_0.visit_ClassDef(classdef_0)

# Generated at 2022-06-25 22:10:17.779493
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_a_0 = module_0.ClassDef(name='A',
                                  bases=[],
                                  keywords=[module_0.keyword(arg='metaclass',
                                                             value=module_0.Name(id='B', ctx=module_0.Load()))],
                                  body=[], decorator_list=[])
    module_x_var_0 = module_0.Module(
        body=[six_import.get_body(), class_a_0])
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:10:25.417568
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # NOTE: Auto-generated by Spyder - modifications may be lost
    from six import with_metaclass as _py_backwards_six_withmetaclass
    # NOTE: Auto-generated by Spyder - modifications may be lost
    _py_backwards_six_withmetaclass(metaclass_var, *bases_var)
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0._py_backwards_six_withmetaclass = _py_backwards_six_withmetaclass
    class_def_var_0 = module_0.ClassDef()
    class_def_var_0

# Generated at 2022-06-25 22:10:29.826660
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = ast.Module()
    class_def = ast.ClassDef(name='A', bases=[], metaclass=ast.Name(id='Test', ctx=ast.Load()), keywords=[], body=[], decorator_list=[])
    obj = MetaclassTransformer(module_0)
    obj.visit_ClassDef(class_def)

# Generated at 2022-06-25 22:10:31.093328
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # TODO: Implement tests
    raise NotImplementedError()


# Generated at 2022-06-25 22:10:41.979120
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_2 = module_0.Module([])
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    metaclass_transformer_1.visit_Module(module_x_var_2)
    e_0 = module_0.Expr()
    k_0 = module_0.keyword('metaclass', e_0)
    c_2 = module_0.ClassDef(body=[], keywords=[k_0])
    c_1 = metaclass_transformer_1.visit_ClassDef(c_2)
    assert type(c_1) == module_0.ClassDef


# Generated at 2022-06-25 22:10:48.901006
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_Module(module_x_var_0)
    module_x_var_1 = module_0.Module()
    module_x_var_2 = module_0.FunctionDef()
    module_x_var_3 = module_0.ClassDef()
    module_x_var_3.keywords = [module_0.keyword()]
    module_x_var_4 = module_0.ClassDef()
    module_x_var_4.keywords = []
    module_x_var_4.keywords = []
   

# Generated at 2022-06-25 22:10:53.460438
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:10:59.800231
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_s_t_0 = module_0.ClassDef(name='ClassDef', body=[], decorator_list=[], keywords=[])
    classdef_x_var_0 = metaclass_transformer_0.visit_ClassDef(classdef_s_t_0)


# Generated at 2022-06-25 22:11:17.115504
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_var_0 = module_0.ClassDef()
    classdef_var_1 = metaclass_transformer_0.visit_ClassDef(classdef_var_0)


    classdef_var_2 = module_0.ClassDef()
    classdef_var_2.keywords = [module_0.keyword(arg=module_0.Str(s='metaclass'), value=module_0.Str(s='B'))]
    classdef_var_3 = metaclass_transformer_0.visit_ClassDef(classdef_var_2)

# Generated at 2022-06-25 22:11:18.040203
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    pass


# Generated at 2022-06-25 22:11:27.167763
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    module_0_ClassDef_0 = module_0.ClassDef(name='foo', bases=[], keywords=[], body=[], decorator_list=[])
    setattr(module_0_ClassDef_0, 'lineno', 3)
    setattr(module_0_ClassDef_0, 'col_offset', 8)
    module_x_var_0.body.append(module_0_ClassDef_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:11:29.859702
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:11:41.379184
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Test for method visit_ClassDef of class MetaclassTransformer"""
    module_x_var_0 = module_0.Module()
    keywords_var_0 = module_0.keywords([module_0.keyword(arg='metaclass', value=module_0.Name(id='metaclass_var_0', ctx=module_0.Load()))])
    metaclass_transformer_var_0 = MetaclassTransformer(module_0.AST())
    module_x_var_1 = metaclass_transformer_var_0.visit_ClassDef(module_0.ClassDef(lineno=0, col_offset=0, name='a', bases=[], keywords=keywords_var_0, body=[], decorator_list=[]))


# Generated at 2022-06-25 22:11:45.972726
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:11:50.067619
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    class_def_0.keywords = [module_0.keyword()]
    metaclass_transformer_1 = MetaclassTransformer(None)
    metaclass_transformer_1.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:11:56.472024
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_x_var_0 = module_0.ClassDef()
    list_x_var_0 = module_0.List()
    string_x_var_0 = module_0.Str()
    class_def_x_var_0.bases = list_x_var_0
    class_def_x_var_0.decorator_list = [string_x_var_0]
    class_def_x_var_0.name = string_x_var_0

# Generated at 2022-06-25 22:12:01.980516
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef(name='Test', body=[], decorator_list=[], keywords=[])

    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:12:10.078005
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    module_x_var_1 = module_x_var_0
    module_x_var_2 = module_0.Module()
    module_x_var_3 = module_x_var_2
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_4 = metaclass_transformer_0.visit_Module(module_x_var_3)
    module_x_var_5 = module_0.ClassDef()
    module_x_var_6 = module_x_var_5
    module_x_var_7 = module_0.Module()
    module_x_var_8 = module

# Generated at 2022-06-25 22:12:33.021696
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    metaclass_transformer_0 = MetaclassTransformer(module_0.AST())
    a_class_def_0 = module_0.ClassDef(
        name='A',
        bases=module_0.List(elts=[module_0.Name(id='B', ctx=module_0.Load())], ctx=module_0.Load()),
        body=[],
        keywords=[module_0.keyword(arg='metaclass', value=module_0.Name(id='B', ctx=module_0.Load()))],
        decorator_list=[])
    a_class_def_1 = metaclass_transformer_0.visit_ClassDef(a_class_def_0)


# Generated at 2022-06-25 22:12:40.295383
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0_var = module_0.Module(body = [])

    class_def_1 = module_0.ClassDef(
        name = 'A',
        bases = [],
        keywords = [module_0.keyword(
            arg = 'metaclass',
            value = module_0.Name(
                id = 'B',
                ctx = module_0.Load()
            )
        )],
        body = [module_0.Pass()],
        decorator_list = []
    )
    name_2 = module_0.Name(
        id = 'metaclass',
        ctx = module_0.Load()
    )
    name_3 = module_0.Name(
        id = 'bases',
        ctx = module_0.Load()
    )

# Generated at 2022-06-25 22:12:46.753349
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    class_def_0 = module_0.ClassDef(name='a', bases=[], keywords=[], body=[], decorator_list=[])
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:12:52.739900
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_1 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef(name='A', bases=[], body=[], keywords=[], decorator_list=[])
    classdef_1 = metaclass_transformer_0.visit_ClassDef(classdef_0)


# Generated at 2022-06-25 22:13:00.255011
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_1 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0._tree_changed = True
    classdef_0 = module_0.ClassDef()
    classdef_0.keywords.append(module_0.keyword(arg=module_0.Str(), value=module_0.Name()))
    classdef_0.bases.append(module_0.Name(id='', ctx=module_0.Load()))
    metaclass_transformer_1 = metaclass_transformer_0.visit_ClassDef(classdef_0)

# Generated at 2022-06-25 22:13:04.882032
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:13:09.020387
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_1 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_2 = metaclass_transformer_0.visit_Module(module_x_var_1)

# Generated at 2022-06-25 22:13:15.062615
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclass_transformer_0 = MetaclassTransformer()
    classdef_0 = module_0.ClassDef()
    classdef_0.keywords = [module_0.keyword(arg='B', value=module_0.Name(id='B', ctx=module_0.Load()))]
    module_x_var_0 = metaclass_transformer_0.visit_ClassDef(classdef_0)
    # Test assertion #1
    assert module_x_var_0.keywords == []


# Generated at 2022-06-25 22:13:16.288851
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Test contains only python3 code.
    pass


# Generated at 2022-06-25 22:13:26.625105
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    module_x_var_1 = module_0.ClassDef(name='A',
                                       bases=[],
                                       keywords=[module_0.keyword(arg='metaclass',
                                                                 value=module_0.Name(id='B',
                                                                                    ctx=module_0.Load()))],
                                       body=[],
                                       decorator_list=[])
    module_x_var_0.body.append(module_x_var_1)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

# Generated at 2022-06-25 22:14:01.701118
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:14:03.375809
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0.ClassDef
    module_0.Keyword
    module_0.Name
    module_0.List
    module_0.Str

# Generated at 2022-06-25 22:14:08.084623
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef()
    classdef_1 = metaclass_transformer_0.visit_ClassDef(classdef_0)

# Generated at 2022-06-25 22:14:10.732713
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = module_0.ClassDef()
    metaclass_transformer_0 = MetaclassTransformer(module_0.AST())
    node_var_0 = metaclass_transformer_0.visit_ClassDef(node)


# Generated at 2022-06-25 22:14:16.315049
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)
    classdef_0 = module_0.ClassDef()
    module_x_var_2 = metaclass_transformer_0.visit_ClassDef(classdef_0)

# Generated at 2022-06-25 22:14:22.344476
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_s_t_0 = module_0.ClassDef()
    classdef_s_t_1 = metaclass_transformer_0.visit_ClassDef(classdef_s_t_0)


# Generated at 2022-06-25 22:14:31.412939
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    try:
        from typed_ast import ast3 as ast
    except ImportError:
        import ast
    from typed_ast.transforms.metaclass import MetaclassTransformer
    module_x_var_0 = ast.Module()
    a_s_t_0 = ast.AST()
    from six import with_metaclass as _py_backwards_six_withmetaclass
    name_0 = ast.Name(_id='with_metaclass', ctx=ast.Load())
    alias_0 = ast.alias(_name='with_metaclass', _asname='_py_backwards_six_withmetaclass')
    module_0 = ast.Module(body=[ast.ImportFrom(module='six', names=[alias_0], level=0)])
    metaclass_transformer_0 = Metac

# Generated at 2022-06-25 22:14:34.447716
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Assign values to variables
    metaclass_transformer_0 = MetaclassTransformer()
    node_0 = typed_ast.ClassDef()

    # Call the method
    result = metaclass_transformer_0.visit_ClassDef(node_0)

    # assert
    assert(result==node_0)


# Generated at 2022-06-25 22:14:44.174944
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Python code:
    #     class A(metaclass=B):
    #         pass
    module_0 = ast.Module(body=[
        ast.ClassDef(name='A',
                     bases=[ast.Name(id='B', ctx=ast.Load())],
                     keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
                     body=[ast.Pass()], decorator_list=[])
    ], type_ignores=[])
    module_1 = module_0

    # Unit test for method visit_ClassDef of class MetaclassTransformer
    a_s_t_0 = ast.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = metaclass

# Generated at 2022-06-25 22:14:52.491200
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_2 = module_0.Module()
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    module_x_var_3 = metaclass_transformer_1.visit_Module(module_x_var_2)
    classdef_0 = module_0.ClassDef()
    bases_0 = module_0.List()
    keywords_0 = module_0.List()
    keyword_0 = module_0.keyword()

# Generated at 2022-06-25 22:16:04.557593
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    pass


# Generated at 2022-06-25 22:16:12.581230
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_s_t_0 = module_0.ClassDef(name='A', bases=[], keywords=[module_0.keyword(arg='metaclass', value=module_0.Name(id='B', ctx=module_0.Load()))], body=[module_0.Pass()], decorator_list=[])
    module_x_var_1 = metaclass_transformer_0.visit_ClassDef(classdef_s_t_0)
    assert(isinstance(module_x_var_1, module_0.ClassDef))


# Generated at 2022-06-25 22:16:18.034772
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_2 = module_0.Module()
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    class_def_0 = module_0.ClassDef(name='A', bases=[], keywords=[], body=[], decorator_list=[])
    module_x_var_3 = metaclass_transformer_1.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:16:22.151628
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    module_x_var_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# unit test follows

# Generated at 2022-06-25 22:16:22.619376
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    pass

# Generated at 2022-06-25 22:16:27.165130
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    module_x_var_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:16:31.495850
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef(body=[], keywords=[], name='A',
                                    bases=[], decorator_list=[])
    metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:16:38.805868
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_2 = module_0.Module()
    classdef_s_t_0 = module_0.ClassDef(name='A', args=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kwarg=None, defaults=[], kw_defaults=[]), body=[], decorator_list=[], keywords=[], lineno=1, col_offset=0)
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    classdef_x_var_0 = metaclass_transformer_1.visit_ClassDef(classdef_s_t_0)


# Generated at 2022-06-25 22:16:43.775965
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_x_var_0 = MetaclassTransformer(a_s_t_0)
    class_def_x_var_0 = module_0.ClassDef(name='X', body=[], keywords=[], decorator_list=[], lineno=1, col_offset=0)
    class_def_x_var_1 = metaclass_transformer_x_var_0.visit_ClassDef(class_def_x_var_0)


# Generated at 2022-06-25 22:16:47.792044
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)
    class_def_var_0 = module_0.ClassDef()
    metaclass_transformer_2 = metaclass_transformer_0.visit_ClassDef(class_def_var_0)
