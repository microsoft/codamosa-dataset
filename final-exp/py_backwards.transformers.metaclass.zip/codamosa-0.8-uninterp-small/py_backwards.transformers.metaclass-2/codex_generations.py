

# Generated at 2022-06-25 22:07:23.440229
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # Not yet implemented
    pass


# Generated at 2022-06-25 22:07:24.448813
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    pass


# Generated at 2022-06-25 22:07:27.617221
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Input python code
    input_code_0="""class A(object):
    pass"""
    # Expected python code

# Generated at 2022-06-25 22:07:35.999907
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from textwrap import dedent
    from ..utils.codegen import to_source
    module = ast.parse(dedent('''\
    class Foo(metaclass=None):
        pass
    '''))
    expected = ast.parse(dedent('''\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class Foo(_py_backwards_six_withmetaclass(None)):
        pass
    '''))
    transformer = MetaclassTransformer(module)
    actual = transformer.visit(module)

    assert transformer.tree_changed is True
    assert to_source(actual).strip() == to_source(expected).strip()


# Generated at 2022-06-25 22:07:44.959088
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_classdef_s_t_0 = module_0.ClassDef()
    a_classdef_s_t_0.keywords = (module_0.keyword("metaclass", module_0.Name("B")),)
    a_classdef_s_t_0.name = "A"
    a_classdef_s_t_0.body = module_0.Pass()
    a_classdef_s_t_0.bases = [module_0.Name("B")]
    a_classdef_s_t_0.decorator_list = []
    metaclass_transformer_0.visit_ClassDef

# Generated at 2022-06-25 22:07:54.201130
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

    a_s_t_1 = module_0.ClassDef(name='A', key=None, bases=[], keywords=[], starargs=None, kwargs=None, body=[], decorator_list=[])
    metaclass_transformer_0.visit_ClassDef(node=a_s_t_1)


# Generated at 2022-06-25 22:08:03.150157
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_dir_path = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(test_dir_path, "test_cases/case_0.py")
    a_s_t_0 = module_0.parse(open(file_path, "r").read())
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_ClassDef(a_s_t_0)
    expected_code = 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass Foo(_py_backwards_six_withmetaclass(metaclass=type)):\n    pass\n'

# Generated at 2022-06-25 22:08:07.732382
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()

    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = module_0.ClassDef(
        name='A',
        bases=[],
        body=[],
        keywords=[module_0.keyword(arg='metaclass', value=None)],
        decorator_list=[],
        starargs=None,
        kwargs=None
    )

    try:
        metaclass_transformer_0.visit_ClassDef(a_s_t_1)
    except Exception as e:
        print(str(e))
        print(str(e.args))

    assert not metaclass_transformer_0._tree_changed
    assert metaclass_transformer

# Generated at 2022-06-25 22:08:17.675507
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = module_0.Module()
    source_0 = module_0.Str('from six import with_metaclass as _py_backwards_six_withmetaclass\n\n\n')
    module_1.body.append(source_0)

# Generated at 2022-06-25 22:08:28.942933
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_0 = module_0.ClassDef(name='A', keywords=[module_0.keyword(arg='metaclass', value=module_0.Name(id='B', ctx=module_0.Load()))], body=[module_0.Pass()])
    var_0 = metaclass_transformer_0.visit_ClassDef(a_s_t_0)
    assert var_0.name == 'A'
    assert var_0.keywords == []
    assert isinstance(var_0.body[0], module_0.Pass)

# Generated at 2022-06-25 22:08:35.029975
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:08:40.523163
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    metaclass_transformer_0.visit_ClassDef(class_def_1)
    metaclass_transformer_0.visit_ClassDef(class_def_1)
    metaclass_transformer_0.visit_ClassDef(class_def_1)
    metaclass_transformer_0.visit_ClassDef(class_def_1)
    metaclass_transformer_0.visit_ClassDef(class_def_1)

# Generated at 2022-06-25 22:08:41.520740
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    pass


# Generated at 2022-06-25 22:08:48.462065
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef(name='Foo')
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    module_0.ClassDef(name='Foo')
    assert(type(class_def_1) == module_0.ClassDef)
    assert(class_def_1.name == 'Foo');


# Generated at 2022-06-25 22:08:57.386296
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Create mock object for ClassDef
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0.keywords = [0]
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert class_def_1.keywords == []
    class_def_0.bases = [0]
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert class_def_1.bases == [0]

# Generated at 2022-06-25 22:08:58.952370
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    test_case_0()

import sys as module_0
import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:09:02.345870
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    metaclass_transformer_0 = MetaclassTransformer()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert class_def_1 == class_def_0


# Generated at 2022-06-25 22:09:03.837678
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert True == True


import typed_ast.ast3 as module_1


# Generated at 2022-06-25 22:09:04.405900
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert True == True

# Generated at 2022-06-25 22:09:12.760848
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_ClassDef(class_def_0)



from typed_ast import (ast3 as ast, parse)
from ..utils.python_source import python_source
from ..transform.metaclass import MetaclassTransformer
from .result import Result

from .test_transformer import test_transformer


# Generated at 2022-06-25 22:09:21.889808
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert metaclass_transformer_0.tree_changed == False

# Generated at 2022-06-25 22:09:29.444873
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0.bases = [1, 2, 3]
    class_def_0.keywords = [2]
    metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert module_0.dump(class_def_0) == "ClassDef(name=None, bases=[2], keywords=[], body=[], decorator_list=[])"


# Generated at 2022-06-25 22:09:34.754456
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:09:44.443213
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Test visit_ClassDef."""
#     global class_def_0, metaclass_transformer_0, class_def_1
#     test_case_0()
#     assert metaclass_transformer_0._tree_changed == False
#     assert class_def_1 is class_def_0
#     global module_0
#     class_def_2 = module_0.ClassDef()
#     Assign_0 = module_0.Assign()
#     Assign_0.value = class_def_2
#     class_def_0.keywords = [Assign_0]
#     test_case_0()
#     assert metaclass_transformer_0._tree_changed == True
#     assert class_def_1 is class_def_0
#     class_def_0.keywords

# Generated at 2022-06-25 22:09:48.404810
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:09:52.427456
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:09:57.136650
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast._ast3 as module_0
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:09:59.678232
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:10:03.519440
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_ClassDef(class_def_0)
    metaclass_transformer_0.visit_ClassDef(class_def_0)
    metaclass_transformer_0.visit_ClassDef(class_def_0)
    metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:10:05.301735
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # TODO: create test cases
    raise Exception('not yet')

# Generated at 2022-06-25 22:10:15.831769
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    metaclass_transformer_0 = MetaclassTransformer(module_0.AST())
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    pass


# Generated at 2022-06-25 22:10:24.175874
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Test class
    # Test ClassDef = ClassDef()
    # Test ClassDef = ClassDef()
    class_def_0 = module_0.ClassDef()
    # Test Module = Module()
    a_s_t_0 = module_0.AST()
    # Test MetaclassTransformer = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # Test void = metaclass_transformer_0.visit_ClassDef(class_def_0)
    metaclass_transformer_0.visit_ClassDef(class_def_0)
    # Test ClassDef = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_1 = met

# Generated at 2022-06-25 22:10:29.436548
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert isinstance(class_def_1, module_0.ClassDef)

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:10:35.689119
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert(class_def_1 == class_def_0)


# Generated at 2022-06-25 22:10:37.528398
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:10:39.641466
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = MetaclassTransformer(ast_0)
    module_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:10:43.625688
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:10:47.187549
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:10:51.373035
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:10:55.583488
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:11:15.633394
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:11:19.289264
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.generic_visit(class_def_0)

# Generated at 2022-06-25 22:11:22.808221
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    # assert class_def_1 == class_def_0
    # assert metaclass_transformer_0._tree_changed is False
    # assert metaclass_transformer_0._snippets == {}


# Generated at 2022-06-25 22:11:30.975927
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
  class_def_0 = module_0.ClassDef()
  module_0.ClassDef.keywords = []
  module_0.ClassDef.bases = []
  a_s_t_0 = module_0.AST()
  metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
  class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
  assert isinstance(class_def_1, module_0.ClassDef,)
  assert class_def_1.bases == []
  module_0.ClassDef.keywords = [module_0.keyword('metaclass', module_0.Name('B', module_0.Load()))]

# Generated at 2022-06-25 22:11:31.824365
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0()
    test_case_0()

# Generated at 2022-06-25 22:11:38.817983
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:11:39.959542
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 22:11:44.484075
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_5 = module_0.ClassDef()
    a_s_t_1 = module_0.AST()
    metaclass_transformer_2 = MetaclassTransformer(a_s_t_1)
    class_def_6 = metaclass_transformer_2.visit_ClassDef(class_def_5)


# Generated at 2022-06-25 22:11:49.281206
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:11:53.041657
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:12:26.992999
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert isinstance(class_def_1, module_0.ClassDef) == True
    assert isinstance(class_def_1, module_0.AST) == True


# Generated at 2022-06-25 22:12:31.953632
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:12:36.273234
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_4 = module_0.ClassDef()
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    class_def_5 = metaclass_transformer_1.visit_ClassDef(class_def_4)
    assert class_def_5 == class_def_4


# Generated at 2022-06-25 22:12:38.234891
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    import six
    assert False



# Generated at 2022-06-25 22:12:43.400416
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    pass

# Generated at 2022-06-25 22:12:52.744234
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast._ast3 as module_0

    #from six import with_metaclass as _py_backwards_six_withmetaclass

    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

    #_py_backwards_six_withmetaclass(metaclass, *bases)

    module_1 = module_0.Mod()
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)


# Generated at 2022-06-25 22:12:56.578130
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:13:04.249006
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    # Test that all variables are deleted

# Generated at 2022-06-25 22:13:12.827459
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef(name='A', bases=[])
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert(isinstance(class_def_1, module_0.ClassDef))
    assert(class_def_1.name == 'A')
    assert(class_def_1.bases == [])
    assert(not class_def_1.keywords)
    assert(not class_def_1.body)
    assert(not class_def_1.decorator_list)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:13:16.354511
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:14:19.765563
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)



if __name__ == '__main__':
    test_case_0()
    test_MetaclassTransformer_visit_ClassDef()

# Generated at 2022-06-25 22:14:23.463006
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:14:27.848464
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:14:31.776083
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:14:37.030501
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:14:41.649671
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:14:45.981731
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:14:54.323739
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Setup
    class_def_0 = module_0.ClassDef()

    # Instances must be hashable, so we alter the contents
    class_def_0.name = 'foo'

    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # Exercise
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    # Verify
    assert class_def_1 is class_def_0

    # Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-25 22:14:57.479000
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Test keyword arguments
    class_def_0 = module_0.ClassDef()
    metaclass_transformer_0 = MetaclassTransformer(module_0.AST())
    assert metaclass_transformer_0.visit_ClassDef(class_def_0) == class_def_0


# Generated at 2022-06-25 22:15:00.728746
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_ClassDef(class_def_0)
