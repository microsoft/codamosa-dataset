

# Generated at 2022-06-25 22:07:27.798418
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

# Generated at 2022-06-25 22:07:36.493405
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classDef_0 = module_0.ClassDef(name='A', body=[ module_0.Pass() ], decorator_list=[], keywords=[ module_0.keyword(arg='metaclass', value=module_0.Name(id='B', ctx=module_0.Load())) ], lineno=0, col_offset=0)

# Generated at 2022-06-25 22:07:45.397654
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    method_body_0_classdef_0 = module_0.ClassDef(
        name='class_def', bases=[module_0.Name(id='base_class')],
        keywords=[module_0.keyword(arg='metaclass', value=module_0.Num(n=0))],
        body=[], decorator_list=[])

# Generated at 2022-06-25 22:07:46.235108
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
  a_s_t_0 = modu

# Generated at 2022-06-25 22:07:55.500737
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    module_1 = module_0.Module(body=[module_0.ClassDef(name='A', 
        bases=[module_0.Name(id='object', ctx=module_0.Load())], 
        keywords=[module_0.keyword(arg='metaclass', 
        value=module_0.Name(id='B', ctx=module_0.Load()))], 
        body=[], decorator_list=[])], type_ignores=[])
    module_2 = module_0.Module(body=[], type_ignores=[])

# Generated at 2022-06-25 22:08:04.416220
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0._NAME__0_1 = module_0.Name(id='_NAME__0_1',
                                        ctx=module_0.Load())
    _NAME__0_1 = module_0._NAME__0_1
    module_0._NAME__0_2 = module_0.Name(id='_NAME__0_2',
                                        ctx=module_0.Load())
    _NAME__0_2 = module_0._NAME__0_2
    module_0._NAME__0_3 = module_0.Name(id='_NAME__0_3',
                                        ctx=module_0.Load())
    _NAME__0_3 = module_0._NAME__0_3

# Generated at 2022-06-25 22:08:13.852824
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = a_s_t_0.Module([a_s_t_0.ClassDef('A', [], [], [], [])])
    assert metaclass_transformer_0.visit(module_1) == module_1
    module_2 = a_s_t_0.Module([a_s_t_0.ClassDef('A', [], [a_s_t_0.Name('A')], [], [])])
    assert metaclass_transformer_0.visit(module_2) == module_2

# Generated at 2022-06-25 22:08:23.232276
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = module_0.ClassDef(lineno=0, col_offset=0, name='A', bases=[], keywords=[], body=[], decorator_list=[])
    a_s_t_1 = metaclass_transformer_0.visit(a_s_t_1)
    print(a_s_t_1)

if __name__ == '__main__':
    test_case_0()
    test_MetaclassTransformer_visit_ClassDef()

# Generated at 2022-06-25 22:08:29.718135
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module([])
    a_s_t_2 = metaclass_transformer_0.visit_Module(a_s_t_1)
    assert isinstance(a_s_t_2, module_0.Module)


# Generated at 2022-06-25 22:08:33.743415
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
  a_s_t_0 = module_0.AST()
  metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
  # TODO: test
  raise NotImplementedError("No test for method visit_ClassDef of class 'MetaclassTransformer'")


# Generated at 2022-06-25 22:08:44.955714
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    node_0 = a_s_t_0.ClassDef()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_ClassDef(node_0)

# Generated at 2022-06-25 22:08:53.577443
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import typed_ast._ast3 as module_0
    from automaty.transformers.metaclass import MetaclassTransformer
    metaclass_transformer_0 = MetaclassTransformer(module_0.AST())
    module_1 = ast.Module(body=[ast.ClassDef(name='A', bases=[ast.Name(id='list', ctx=ast.Load())], keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='type', ctx=ast.Load()))], body=[], decorator_list=[])])
    module_2 = metaclass_transformer_0.visit(module_1)
    assert module_2.body[0].bases[0].args[0].value == 'type'
    assert module_2.body[0].bases

# Generated at 2022-06-25 22:09:02.641535
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast as t
    class A(_py_backwards_six_withmetaclass(object)):
        def __init__(self, x):
            pass
    class B(metaclass=A):
        def __init__(self, x):
            pass
    ast_0 = t.ast3.parse('class D(metaclass=A):\n    def __init__(self, x):\n        pass')
    metaclass_transformer_0 = MetaclassTransformer()
    expected = t.ast3.parse('class D(_py_backwards_six_withmetaclass(A))\n    def __init__(self, x):\n        pass')
    actual = metaclass_transformer_0.visit(ast_0)

# Generated at 2022-06-25 22:09:11.283401
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

    module_0_0 = module_0.Module(body=[])
    result = metaclass_transformer_0.visit_Module(module_0_0)
    assert isinstance(result, module_0.Module), "Expected AST Type: 'Module' (type: <class 'typed_ast._ast3.Module'>), Got: %s (type: %s)" % (result, type(result))
    assert result.body == [], "Expected AST set item: %s, Got: %s" % ([], result.body)


# Generated at 2022-06-25 22:09:17.263102
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    module_2 = module_0.Module()
    classdef_3 = module_0.ClassDef()
    metaclass_transformer_1.visit_ClassDef(classdef_3)


# Generated at 2022-06-25 22:09:19.375782
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast._ast3 as a_s_t

# Generated at 2022-06-25 22:09:22.086237
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)


# Generated at 2022-06-25 22:09:25.866843
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    ast_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(ast_0)
    classdef_0 = module_0.ClassDef()
    classdef_0 = metaclass_transformer_0.visit_ClassDef(classdef_0)
    assert classdef_0 is not None


# Generated at 2022-06-25 22:09:29.258625
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)


# Generated at 2022-06-25 22:09:35.915159
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = module_0.Module(body=[])
    module_v_0 = metaclass_transformer_0.visit(module_1)
    assert isinstance(module_v_0, module_0.Module)


# Generated at 2022-06-25 22:09:41.323363
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()


# Generated at 2022-06-25 22:09:51.104046
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0 = module_0
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    assert (metaclass_transformer_0.visit_ClassDef(class_def_2) is not None), "Visit should return new an AST"
    class_def_3 = metaclass_transformer_0.visit_ClassDef(class_def_2)
    assert (metaclass_transformer_0.tree_changed is True), "Tree should be changed"
    metaclass_transformer_0.tree_changed = False
    assert (metaclass_transformer_0.visit_ClassDef(class_def_3) is not None), "Visit should return new an AST"


# Generated at 2022-06-25 22:09:58.458680
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)
    class_def_3 = metaclass_transformer_0.visit_ClassDef(class_def_2)



# Generated at 2022-06-25 22:10:08.302044
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)
    assert_equal(class_def_1, class_def_0)
    assert_equal(class_def_2, class_def_1)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:10:13.641940
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)

# Generated at 2022-06-25 22:10:20.503539
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)
    assert metaclass_transformer_0.tree_changed == False


# Generated at 2022-06-25 22:10:25.512885
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)


import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:10:35.639370
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import os
    import unittest
    from typed_ast import ast3 as ast
    from typed_ast import compile
    from ..utils.context import context
    from ..utils.python_source import python_source
    from ..utils.get_name import get_name
    from ..tests.visitors import GetUsedClasses
    from ..utils.visitor import visit_all_children

    source = """class A(metaclass=B):
                pass"""

    tree = compile(source, filename='<test>', mode='exec',
        flags=ast.PyCF_ONLY_AST,
        optimize=0)

    context.process_python_source(tree)
    tree = MetaclassTransformer.transform(tree)
    tree = GetUsedClasses.transform(tree, [MetaclassTransformer])

    # assert that the transformer

# Generated at 2022-06-25 22:10:39.097008
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0.ClassDef.body = []
    module_0.ClassDef.keywords = [module_0.keyword()]
    module_0.ClassDef.bases = [module_0.Name()]
    module_0.keyword.arg = ''
    module_0.keyword.value = module_0.Num()
    module_0.Num.n = 1
    module_0.Name.id = 'NameTest0'
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2

# Generated at 2022-06-25 22:10:43.408391
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert(class_def_1 is class_def_0)

# Generated at 2022-06-25 22:10:58.151896
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)

# Generated at 2022-06-25 22:11:03.475099
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert class_def_1 is class_def_0


# Generated at 2022-06-25 22:11:09.475463
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    try:
        class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    except:
        class_def_1 = module_0.ClassDef()
    class_def_2 = module_0.ClassDef()
    assert (class_def_1 == class_def_2)

# Generated at 2022-06-25 22:11:17.302130
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)


# Generated at 2022-06-25 22:11:24.759371
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    # Test missing parameters
    with pytest.raises(TypeError):
        MetaclassTransformer(a_s_t_0).visit_ClassDef()
    # Test invalid parameters (wrong type)
    with pytest.raises(TypeError):
        MetaclassTransformer(a_s_t_0).visit_ClassDef(1)
    # Test invalid parameters (missing attribute)
    with pytest.raises(AttributeError):
        MetaclassTransformer(a_s_t_0).visit_ClassDef(module_0.Expr())
    test_case_0()


# Generated at 2022-06-25 22:11:31.994778
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    metaclass_transformer_0.generic_visit = lambda ast_a: ast_a
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert (class_def_1 is not class_def_0)
    metaclass_transformer_0.generic_visit = lambda ast_a: ast_a
    class_keywords_0 = module_0.arguments()
    class_keywords_0.args = [module_0.arg()]

# Generated at 2022-06-25 22:11:38.042522
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_ClassDef()

# Generated at 2022-06-25 22:11:44.833563
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """metaclass=''"""
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)
    assert metaclass_transformer_0._tree_changed is False


# Generated at 2022-06-25 22:11:46.258562
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    pass

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:11:54.318991
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert(class_def_1 is class_def_0)
    
    class_def_0 = module_0.ClassDef()
    class_def_0.keywords = module_0.Keyword()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert(class_def_1 is class_def_0)
    pass
    return

# Generated at 2022-06-25 22:12:19.012632
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)


# Generated at 2022-06-25 22:12:24.479923
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert(False)


# Generated at 2022-06-25 22:12:30.389960
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)


# Generated at 2022-06-25 22:12:37.815432
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert(class_def_1 is not None)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)
    assert(class_def_2 is not None)

if __name__ == '__main__':
    test_case_0()
    test_MetaclassTransformer_visit_ClassDef()

# Generated at 2022-06-25 22:12:45.222964
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef(name='test',decorator_list=[],body=[])
    if  not hasattr(metaclass_transformer_0, '_called_visit_ClassDef_0'):
        metaclass_transformer_0._called_visit_ClassDef_0 = False

# Generated at 2022-06-25 22:12:49.925852
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:12:58.143454
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert (class_def_1 is class_def_0)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)
    assert (class_def_2 is class_def_0)
    class_def_3 = module_0.ClassDef()
    class_def_3.keywords = [module_0.keyword()]

# Generated at 2022-06-25 22:12:58.919328
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0.ClassDef()


# Generated at 2022-06-25 22:13:07.004756
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_0.name = "A"
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)
    assert(class_def_0 is not class_def_1)
    assert(class_def_1 is not class_def_2)
    assert(class_def_0 is not class_def_2)

# Generated at 2022-06-25 22:13:11.742784
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_2 = metaclass_transformer_1.visit_ClassDef(class_def_0)
    assert class_def_2 == class_def_0


# Generated at 2022-06-25 22:13:56.813776
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert isinstance(class_def_1, module_0.ClassDef)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)
    assert isinstance(class_def_2, module_0.ClassDef)


# Generated at 2022-06-25 22:14:00.375040
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    method = getattr(MetaclassTransformer, 'visit_ClassDef', None)
    assert(callable(method))
    c_0 = MetaclassTransformer(ast.Module())
    c_1 = c_0.visit_ClassDef(ast.ClassDef())


# Generated at 2022-06-25 22:14:06.551423
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:14:10.965476
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


import typed_ast.ast3 as module_1
import typed_ast._ast3 as module_2


# Generated at 2022-06-25 22:14:20.110807
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    kwarg_0 = module_0.keyword()
    argvalue_0 = module_0.Name()
    argvalue_0.arg = 'A'
    argvalue_0.ctx = module_0.Load()
    kwarg_0.arg = 'metaclass'
    kwarg_0.value = argvalue_0
    class_def_0.keywords = [kwarg_0]
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = metaclass_transformer

# Generated at 2022-06-25 22:14:24.700037
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:14:32.108502
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert metaclass_transformer_0._tree_changed==False
    assert metaclass_transformer_0._dependencies==['six']
    assert isinstance(class_def_1, module_0.ClassDef)
    assert metaclass_transformer_0._tree_changed==False

# Generated at 2022-06-25 22:14:38.381717
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)


# Generated at 2022-06-25 22:14:44.518598
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)


# Generated at 2022-06-25 22:14:48.477937
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
 

# Generated at 2022-06-25 22:16:25.909713
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    class_def_3 = module_0.ClassDef()
    class_def_4 = metaclass_transformer_1.visit_ClassDef(class_def_3)
    print()


# Generated at 2022-06-25 22:16:31.188753
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_0.bases = []
    class_def_0.keywords = []
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)

# Generated at 2022-06-25 22:16:37.109148
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)
    assert not hasattr(metaclass_transformer_0, "_visit_ClassDef")


# Generated at 2022-06-25 22:16:43.559227
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)
    metaclass_transformer_0.visit_ClassDef(class_def_2)
    class_def_3 = module_0.ClassDef()
    class_def_4 = metaclass_transformer_0.visit_ClassDef(class_def_3)
    class_def_5 = metaclass_transformer_0.visit

# Generated at 2022-06-25 22:16:49.187839
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_0.keywords = [module_0.keyword(arg=None, value=None)]
    class_def_0.args = module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])
    class_def_0.body = [module_0.Pass()]
    class_def_0.decorator_list = []
    class_def_0.name = 'A'

# Generated at 2022-06-25 22:16:52.276764
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def_2 = metaclass_transformer_0.visit_ClassDef(class_def_1)

# Generated at 2022-06-25 22:16:56.014428
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    assert class_def_1 != class_def_0

# Generated at 2022-06-25 22:16:57.370909
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:17:01.283602
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef()
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    module_0.copy_location(class_def_1, class_def_0)
    module_0.fix_missing_locations(class_def_1)
    assert class_def_1 is not None


# Generated at 2022-06-25 22:17:07.193373
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    import typed_ast._ast3 as module_0
    import ast as module_1
    
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_1.ClassDef(name='A', bases=[], body=[], keywords=[], decorator_list=[])
    class_def_1 = module_0.ClassDef(name='A', bases=[], body=[], keywords=[], decorator_list=[])
    class_def_2 = module_0.ClassDef(name='A', bases=[], body=[], keywords=[], decorator_list=[])
    class_def_3 = metaclass_transformer_0.visit_ClassDef(class_def_0)
    class_def