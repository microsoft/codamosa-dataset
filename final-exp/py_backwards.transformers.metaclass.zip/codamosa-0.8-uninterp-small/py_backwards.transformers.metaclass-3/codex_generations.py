

# Generated at 2022-06-25 22:07:31.939702
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_0.ClassDef(
        name='A',
        bases=[
            module_0.Name(
                id='B',
                ctx=module_0.Load()
            )
        ],
        keywords=[
            module_0.keyword(
                arg='metaclass',
                value=module_0.Name(
                    id='B',
                    ctx=module_0.Load()
                )
            )
        ],
        body=[
            module_0.Pass()
        ],
        decorator_list=[]
    )


# Generated at 2022-06-25 22:07:35.281266
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = metaclass_transformer_0.visit_Module(a_s_t_0)


# Generated at 2022-06-25 22:07:41.722682
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module_0 = ast.parse("class A(metaclass=B): pass")
    metaclass_transformer_0 = MetaclassTransformer()
    print(metaclass_transformer_0.visit(module_0))
    print(ast.dump(metaclass_transformer_0.visit(module_0)))
    assert ast.dump(metaclass_transformer_0.visit(module_0)) == "<_ast.Module object at 0x10e2fa278>\n"

import sys
sys.exit(0)

# Generated at 2022-06-25 22:07:45.557350
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # initializing here the arguments for init for AST
    a_s_t_0.init()
    cls_def_0 = module_0.ClassDef(name='', bases=[], keywords=[], body=[], decorator_list=[])
    compile_0 = metaclass_transformer_0.visit_ClassDef(cls_def_0)
    # TODO: add asserts

# Generated at 2022-06-25 22:07:52.130225
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # Call function visit_ClassDef of class MetaclassTransformer
    a_s_t_1 = module_0.ClassDef(name='foo', bases=[], keywords=[])
    module_0.ClassDef(name='foo', bases=[], keywords=[])
    result = metaclass_transformer_0.visit_ClassDef(a_s_t_1)
    # Check assertions

# Generated at 2022-06-25 22:08:01.062848
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    a_s_t_2 = module_0.ClassDef()
    assert metaclass_transformer_1.visit_ClassDef(a_s_t_2) == a_s_t_2
    a_s_t_3 = module_0.ClassDef(
        name='test'
    )
    assert metaclass_transformer_1.visit_ClassDef(a_s_t_3) == a_s_t_3
    a_s_t_4 = module_0.ClassDef(
        name='test',
        bases=[module_0.Name(
            id='test'
        )]
    )

# Generated at 2022-06-25 22:08:09.692972
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.tree import insert_at
    from .base import BaseNodeTransformer


    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass


    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)


    class MetaclassTransformer(BaseNodeTransformer):
        """Compiles:
            class A(metaclass=B):
                pass
        To:
            class A(_py_backwards_six_with_metaclass(B))

        """
        target = (2, 7)

# Generated at 2022-06-25 22:08:14.671557
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    with pytest.raises(AttributeError):
        metaclass_transformer_2 = metaclass_transformer_0.visit_ClassDef(a_s_t_0.ClassDef)


# Generated at 2022-06-25 22:08:25.479217
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = module_0.Module()
    classdef_2 = module_0.ClassDef(name='C', bases=[], keywords=[], body=[], decorator_list=[])
    assign_3 = module_0.Assign(targets=[], value=classdef_2)
    module_1.body.append(assign_3)
    module_2 = metaclass_transformer_0.visit_Module(module_1)
    assert len(module_2.body) == 2
    assert module_2.body[0].value == six_import.get_body()


# Generated at 2022-06-25 22:08:34.316749
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    class_def_0 = module_0.ClassDef(name='A', bases=module_0.List(elts=list(), ctx=module_0.Load()), keywords=[module_0.keyword(arg='metaclass', value=module_0.Name(id='B', ctx=module_0.Load()))], body=[module_0.Pass()], decorator_list=list())
    metaclass_transformer_0.visit_ClassDef(node=class_def_0)


# Generated at 2022-06-25 22:08:41.925069
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # We have to pass an instance of the node because visit_ClassDef expects
    # the first argument to be of type ClassDef.
    metaclass_transformer_0.visit_ClassDef(module_0.ClassDef())

# Generated at 2022-06-25 22:08:51.323011
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # Define a_s_t_1 for test of input node
    a_s_t_1 = module_0.Module(body=[module_0.ClassDef(name='A', decorator_list=[], args=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], keywords=[module_0.keyword(arg='metaclass', value=module_0.Name(id='B', ctx=module_0.Load()))], lineno=1, col_offset=0)])
    # Replace node with a_s_t_1 for

# Generated at 2022-06-25 22:08:58.839358
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_0_0 = module_0.Module([],  {})
    module_0_0 = metaclass_transformer_0.visit_Module(module_0_0)
    assert (isinstance(module_0_0,module_0.Module))
    assert (len(module_0_0.body) == 0)
    assert (module_0_0.type_ignores == {})


# Generated at 2022-06-25 22:09:03.923269
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    
    class_def_0 = module_0.ClassDef(
        name='A',
        bases=[],
        keywords=[],
        body=[],
        decorator_list=[],
        lineno=0,
        col_offset=0,
    )
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    metaclass_transformer_0.visit_ClassDef(class_def_0)

test_case_0()
test_MetaclassTransformer_visit_ClassDef()

# Generated at 2022-06-25 22:09:09.111042
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    # Retrieve elements from all_elements
    module0 = all_elements.get('module0')

    # Call visit_ClassDef
    metaclass_transformer0 = MetaclassTransformer()
    metaclass_transformer0.visit(module0)


if __name__ == '__main__':
    test_case_0()
    test_MetaclassTransformer_visit_ClassDef()

# Generated at 2022-06-25 22:09:16.677783
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef(name='module_0', bases=[], keywords=[])
    metaclass_transformer_0.visit_ClassDef(class_def_0)
    metaclass_transformer_0.visit_ClassDef(class_def_0)

# Generated at 2022-06-25 22:09:22.354930
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_0.copy_location(module_1, None)
    module_1.body = [None]
    metaclass_transformer_0.visit_Module(module_1)


# Generated at 2022-06-25 22:09:27.281928
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = module_0.ClassDef(name="A", body=[], decorator_list=[], keywords=[])
    metaclass_transformer_0.visit_ClassDef(a_s_t_1)


# Generated at 2022-06-25 22:09:29.170897
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # TODO: Add tests
    pass


# Generated at 2022-06-25 22:09:39.382347
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    a_s_t_1 = module_0.ClassDef()
    a_s_t_2 = module_0.Str()
    a_s_t_2.s = 'A'
    a_s_t_1.name = a_s_t_2
    a_s_t_3 = module_0.keyword()
    a_s_t_4 = module_0.Str()
    a_s_t_4.s = 'metaclass'
    a_s_t_3.arg = a_s_t_4
    a_s_t_5 = module_0.Name()
    a_s_t

# Generated at 2022-06-25 22:09:50.341046
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:09:57.290873
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:10:03.155402
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xa3A\xc3\x91\xcf\x97\x15"\x1c\xbe\xa0\x9d\xa9\xdct\xab\xee'
    bytes_1 = b'\x1bB\xe3c\x9fe\xb2\xfb\x8f\x83C\x17\x1f\xf5\xa0\xeb'
    bytes_2 = b'\xa4\xcd\xaf\xbc\x95\xc0\xef\x9e\xa9\x01\x8f\xd0\xcc\xad\xff\xc9'

# Generated at 2022-06-25 22:10:11.325062
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:10:12.174793
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:10:19.209693
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    bytes_0 = b"\xbcJ\xa54\"\x0ex>\xa7\xb13\xd2r"
    list_0 = [bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:10:25.670809
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    # Test that method visit_ClassDef does not raise exception NotImplementedError
    try:
        metaclass_transformer_0.visit_ClassDef(module_x_var_0)
    except NotImplementedError:
        assert False



# Generated at 2022-06-25 22:10:26.451762
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:10:35.282203
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_2 = module_0.Module(*list_0)
    a_s_t_1 = module_0.AST()
    metaclass_transformer_1 = MetaclassTransformer(a_s_t_1)
    module_x_var_3 = metaclass_transformer_1.visit_Module(module_x_var_2)
    assert module_x_var_3 == module_x_var_2

import unittest


# Generated at 2022-06-25 22:10:36.504002
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:10:56.416424
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b"\x8a\x92\x83@\xe5\xe3\x1e\x9c\x08\xc0\x17\xd3\x04\x7fE\x98u\xeb\x04\xca\x9b)L\xb0\xc6\xea\x88i\x8a\xe4\x1e\x9c\x08\xc0\x17\xd3\x04\x7fE\x98u\xeb\x04\xca\x9b)L\xb0\xc6\xea\x88i"
    str_0 = "A"
    str_1 = "b"
    str_2 = "class"
    str_3 = "metaclass"

# Generated at 2022-06-25 22:11:05.498603
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    b_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(b_s_t_0)
    metaclass_var_0 = module_0.Name(id="metaclass")
    b_s_t_1 = module_0.AST()
    metaclass_var_1 = module_0.Name(id="metaclass")
    bytes_0 = b'}\xcc\xac\x9d\x14\xd5\xad\xbf_'
    bytes_1 = b'@\x04\x1d\x9ec\x12\x01\x1cN\x82'

# Generated at 2022-06-25 22:11:16.684486
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-25 22:11:25.915297
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_x_var_0 = module_0.ClassDef(*list_0)
    class_def_0 = metaclass_transformer_0.visit_ClassDef(class_def_x_var_0)

if __name__ == '__main__':
    test_MetaclassTransformer_visit_ClassDef()

# Generated at 2022-06-25 22:11:31.832377
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    tuple_0 = (bytes_0, list_0)
    list_1 = [tuple_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:11:43.690821
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Testing the following code:
    # class A(metaclass=B):
    #     pass

    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    classdef_x_var_0 = module_0.ClassDef(*list_0)
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    dict_var_0

# Generated at 2022-06-25 22:11:50.982280
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:11:56.139538
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # This test case is derived from the test case test_case_0 in test_MetaclassTransformer.py.
    import ast
    import six
    import typing
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    classdef_0 = ast.ClassDef(*list_0)
    a_s_t_0 = ast.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_1 = metaclass_transformer_0.visit_ClassDef(classdef_0)


# Generated at 2022-06-25 22:12:02.253589
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:12:10.570044
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef(
        name=module_0.Name(
            id=bytes_0,
            ctx=module_0.Load()),
        bases=list_0,
        keywords=list_0,
        body=list_0,
        decorator_list=list_0)
    class_def_1 = metaclass_

# Generated at 2022-06-25 22:12:32.861335
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\x0f\xe4\xd8\xbf\xb1\x90\xd2\x0f\xab\xd3'
    bytes_1 = b'\x8d\x9a\x1e\xe7\x8e\x7f\xa6\xb2\x9e\x86'
    bytes_2 = b'\xaa\xd8\x0c\xd6\x96\x8a\xfc\x9b\xb0\x1a'
    module_0 = Module([])
    a_s_t_0 = AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)

# Generated at 2022-06-25 22:12:40.196873
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = module_0.Module()
    list_1 = [module_x_var_1]
    bytes_1 = b'\xaa'
    list_2 = [list_1, bytes_1]
    list_3 = [list_2, bytes_1]
    list_4 = [list_3, bytes_1]
    list_

# Generated at 2022-06-25 22:12:46.982174
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:12:55.750531
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    bytes_1 = b'\xbc\x19\xbc\x0c\x80\x927h\xaa\xf1'
    bytes_2 = b'\xbc\x19\xbc\x0c\x80\x927h\xaa\xf1'
    list_0 = [bytes_0, bytes_1, bytes_2]
    module_x_var_0 = module_0.Module(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    list_1 = [module_x_var_0]


# Generated at 2022-06-25 22:13:00.466486
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xc2H\xd9\x02\x1b\x8a\xf6\xd4\x85\xa4\x01\xe3\xfb'
    bytes_1 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'

# Generated at 2022-06-25 22:13:09.331962
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\x16\x8f\xfd\x81\xf3\x05\x8d\x91L\xdb\xe7\xa0\x8e\x1d\xc4|'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)
    class_def_0 = module_x_var_1.body[0]

# Generated at 2022-06-25 22:13:16.951058
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)
    class_x_var_0 = module_x_var_1.body[0]
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_x_var_1 = metaclass

# Generated at 2022-06-25 22:13:24.335197
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    list_0 = [None]
    list_1 = [None]
    list_0[0] = list_1
    ast_classdef_0 = module_0.ClassDef(None, None, list_0, [])
    ast_ast_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(ast_ast_0)
    ast_classdef_1 = metaclass_transformer_0.visit_ClassDef(ast_classdef_0)

# Generated at 2022-06-25 22:13:33.423824
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    class_def_0 = module_0.ClassDef(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_1 = metaclass_transformer_0.visit_ClassDef(class_def_0)


# Generated at 2022-06-25 22:13:40.411114
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:14:18.926490
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    class_def_x_var_0 = module_0.ClassDef(*list_0)
    class_def_x_var_1 = metaclass_transformer_0.visit_ClassDef(class_def_x_var_0)

# Generated at 2022-06-25 22:14:27.734588
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    list_0 = [b'import six\n']
    list_1 = [b'from six import with_metaclass as _py_backwards_six_withmetaclass']
    list_2 = [b'_py_backwards_six_withmetaclass(1,  *[2, 3])']
    list_3 = [b'A']
    tuple_0 = (list_3, list_2, list_0, list_1)
    list_4 = [b'from six import with_metaclass as _py_backwards_six_withmetaclass', b'_py_backwards_six_withmetaclass(1,  *[2, 3])']
    list_5 = [b'A']

# Generated at 2022-06-25 22:14:35.066319
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)
    bytes_1 = b'A'
    s_t_0 = module_0.Str(bytes_1)

# Generated at 2022-06-25 22:14:37.031755
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class Foo:
        class Bar:
            __metaclass__ = Baz
        unexpected_keyword_arg = 0


# Generated at 2022-06-25 22:14:45.499731
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)
    metaclass_transformer_0.visit_ClassDef(module_x_var_0.body[0])

# Generated at 2022-06-25 22:14:53.819934
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b"\xce'\xf0\xe4\x82\xf4\x00\x03\x83\xcd\x04\xcd\x04\xc0\x83\xcd\x04\xcd\x04\xcd\x04\xcd\x04\xcd\x04\xcd\x04\xcd\x04\xcd\x04\xcd\x04\xcd\x04\xcd\x04\xcd\x04\xcd\x04\xcd\x04\xcd\x04\xcd\x04"

# Generated at 2022-06-25 22:15:01.154384
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    expr_value_0 = module_0.Name(*list_0)
    argument_0 = module_0.arguments(*list_0)
    expr_value_1 = module_0.Name(*list_0)
    keyword_0 = module_0.keyword(arg=expr_value_1, value=expr_value_0)
    list_1 = [keyword_0]
    suite_0 = module_0.Suite()

# Generated at 2022-06-25 22:15:10.738972
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbd\xd1\xa2\xdd\x96w\x88\x94\xdc\x0e\x17\x8e'
    s_0 = str()
    n_0 = None
    list_0 = [bytes_0, s_0]
    module_x_var_0 = module_0.Assign(*list_0)
    bytes_1 = b'\x19G\xf7\xcd\x1b0\xae\x91^\xe1'
    s_1 = str()
    n_1 = None
    list_1 = [bytes_1, s_1]
    class_0 = module_0.ClassDef(*list_1)
    list_2 = [module_x_var_0, class_0]
    module_

# Generated at 2022-06-25 22:15:17.626445
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    bytes_1 = b'A'
    list_0 = [bytes_0, bytes_0, bytes_1]
    list_1 = []
    list_2 = []
    list_3 = [list_2]
    list_4 = [list_3]
    list_5 = [list_4]
    classdef_0 = module_0.ClassDef(*list_0, *list_5)
    list_6 = [classdef_0]
    list_7 = [list_6]
    module_x_var_0 = module_0.Module(*list_7)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0

# Generated at 2022-06-25 22:15:18.194115
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    test_case_0()

# Generated at 2022-06-25 22:16:36.128217
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_0_var_0 = module_0.Num(n=0)
    class_0_var_1 = module_0.Name(id='int', ctx=class_0_var_0)
    class_0_var_2 = module_0.keyword(arg='metaclass', value=class_0_var_1)
    class_0_var_3 = module_0.Name(id='Foo', ctx=class_0_var_0)
    class_0_var_4 = module_0.ClassDef(name='A', bases=[], keywords=[class_0_var_2], starargs=None, kwargs=None, body=[])

# Generated at 2022-06-25 22:16:41.066544
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:16:45.506446
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:16:50.845611
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-25 22:16:55.740534
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    classdef_x_var_6 = module_0.ClassDef(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    classdef_x_var_7 = metaclass_transformer_0.visit_ClassDef(classdef_x_var_6)


# Generated at 2022-06-25 22:17:00.742818
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'test_MetaclassTransformer'
    list_0 = [bytes_0]
    module_0 = ast.Module(*list_0)
    a_s_t_0 = ast.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_0 = ast.ClassDef(name='ClassName', bases=[], keywords=[], body=[], decorator_list=[])
    class_x_var_0 = metaclass_transformer_0.visit(module_x_var_0)
    assert class_x_var_0.bases == []


# Generated at 2022-06-25 22:17:06.561805
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module_x_var_0 = module_0.Module(body=[
        module_0.ClassDef(
            name='A',
            args=module_0.arguments(
                args=[],
                vararg=None,
                kwonlyargs=[],
                kw_defaults=[],
                kwarg=None,
                defaults=[]
            ),
            body=[module_0.Pass()],
            decorator_list=[],
            keywords=[module_0.keyword(
                arg='metaclass',
                value=module_0.Name(
                    id='B',
                    ctx=module_0.Load()
                )
            )]
        )
    ])
    a_s_t_0 = module_0.AST()

# Generated at 2022-06-25 22:17:13.330657
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    bytes_0 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_0 = [bytes_0, bytes_0]
    module_x_var_0 = module_0.Module(*list_0)
    a_s_t_0 = module_0.AST()
    metaclass_transformer_0 = MetaclassTransformer(a_s_t_0)
    module_x_var_1 = metaclass_transformer_0.visit_Module(module_x_var_0)
    bytes_1 = b'\xbcJ\xa54"\x0ex>\xa7\xb13\xd2r'
    list_1 = [bytes_1, bytes_1]
    class_def_0 = module_0.Class

# Generated at 2022-06-25 22:17:14.353935
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # TODO: Implement this test
    assert False


# Generated at 2022-06-25 22:17:20.144660
# Unit test for method visit_ClassDef of class MetaclassTransformer