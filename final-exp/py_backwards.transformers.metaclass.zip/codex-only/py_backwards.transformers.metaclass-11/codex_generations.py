

# Generated at 2022-06-23 22:37:31.552509
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = "class A(metaclass=B):\n    pass"
    node = ast.parse(code)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    output = astunparse.unparse(node)
    assert output == "from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass"

# Generated at 2022-06-23 22:37:32.111424
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:37:41.857647
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from . import test_py_to_ast, test_ast_to_py
    from . import test_py_to_tokens, test_tokens_to_py
    from .utils import compare_ast

    # test each line in the snippet
    for code in six_import.get_body():
        ast(_)  # type: ignore
    # test whole snippet
    ast_ = ast(six_import)  # type: ignore

    # test each line in the snippet
    for code in class_bases.get_body(metaclass=ast.Name(id='B'), bases=ast.List(elts=[ast.Name(id='object')])):
        ast(_)  # type: ignore
    # test whole snippet
    ast_ = ast(class_bases)  # type: ignore


# Generated at 2022-06-23 22:37:43.095243
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    from ..utils.ast_tools import parse


# Generated at 2022-06-23 22:37:53.594563
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

    tree = ast.parse('''
    class A(metaclass=B):
        pass
    ''')
    transformer = MetaclassTransformer()
    transformer.visit(tree)

    assert transformer.has_changes
    assert transformer.dependencies == set(['six'])
    assert transformer._tree_changed

    expected = ast.parse('''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    ''')

    assert ast.dump(tree, annotate_fields=False) == ast.dump(expected, annotate_fields=False)



# Generated at 2022-06-23 22:37:59.633350
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.Module(body=[])

    expected = ast.Module(
        body=[six_import.get_body()]
    )

    transformer = MetaclassTransformer()
    actual = transformer.visit(node)

    assert ast.dump(expected, include_attributes=False) == ast.dump(actual,
                                                                    include_attributes=False)



# Generated at 2022-06-23 22:38:01.157367
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.fake import FakeFile


# Generated at 2022-06-23 22:38:05.734279
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

    module = ast.parse("""class A(metaclass=B): pass""")
    t = MetaclassTransformer()
    t.visit(module)

# Generated at 2022-06-23 22:38:11.301585
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys
    import unittest
    from typed_ast.ast3 import parse
    from .._compat import PY_VERSION
    from .._compat import get_ast

    class TestMetaclassTransformer(unittest.TestCase):
        def test_metaclass_transformer(self):

            # Test the six import
            transformer = MetaclassTransformer(get_ast('', PY_VERSION))
            module = transformer.visit(parse('', version=PY_VERSION))
            self.assertEqual(
                module,
                parse('from six import with_metaclass as _py_backwards_six_withmetaclass',
                      version=PY_VERSION),
            )

            # Test the class bases
            transformer = MetaclassTransformer(get_ast('', PY_VERSION))
           

# Generated at 2022-06-23 22:38:18.378577
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    def check(before, after):
        tree = ast.parse(before)
        mt = MetaclassTransformer()
        new = mt.visit(tree)
        assert after == ast.dump(new)

    before = """
    class A(type):
        pass
    """
    after = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(type):
        pass
    """

    check(before, after)



# Generated at 2022-06-23 22:38:20.080153
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """Unit test for method visit_Module of class MetaclassTransformer
    """

# Generated at 2022-06-23 22:38:21.642838
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    mtt = MetaclassTransformer()
    assert isinstance(mtt, MetaclassTransformer)

# Generated at 2022-06-23 22:38:30.777004
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    
    from ..utils.tree import assert_equal_ast
    from .base import BaseNodeTransformer
    from .metaclass import MetaclassTransformer

    source = """class A:
        pass"""

    expect = """from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A:
    pass
"""

    node = ast.parse(source)
    MetaclassTransformer().visit(node)
    assert_equal_ast(node, expect)



# Generated at 2022-06-23 22:38:39.682148
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse("""
        class Foo(metaclass=FooMeta): pass
        """)

    transformer = MetaclassTransformer(module)
    transformer.visit(module)


# Generated at 2022-06-23 22:38:49.919301
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast
    from ..utils.source import source

    # Test for empty class
    tree = ast.parse(source(
        """
        class A(metaclass=ABCMeta):
            pass
        """
    ))
    tree = MetaclassTransformer().visit(tree)
    tree = ast.fix_missing_locations(tree)
    exec(compile(tree, filename="<ast>", mode="exec"))

    # Test for class with a base
    tree = ast.parse(source(
        """
        class A(B, metaclass=ABCMeta):
            pass
        """
    ))
    tree = MetaclassTransformer().visit(tree)
    tree = ast.fix_missing_locations(tree)
    exec(compile(tree, filename="<ast>", mode="exec"))

    #

# Generated at 2022-06-23 22:38:59.630571
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    import textwrap
    code = textwrap.dedent("""
        class A(metaclass=B):
            pass
        """)
    tree = ast.parse(code)

    # first patch the tree
    MetaclassTransformer(2, 7).visit(tree)

    # now the code should be patched
    patched_code = textwrap.dedent("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """)

    assert patched_code == astor.to_source(tree)

# Generated at 2022-06-23 22:39:08.629030
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast as py_ast
    from ..utils.ast import dump, round_trip
    import unittest

    class TestCase(unittest.TestCase):
        def test(self):
            node = py_ast.parse('class A(metaclass=B):\n    pass', '<string>', 'exec').body[0]
            expected_out = 'class A(_py_backwards_six_withmetaclass(B)):\n    pass'

            transformed = round_trip(node, MetaclassTransformer)
            self.assertEqual(expected_out, dump(transformed))

    unittest.TextTestRunner().run(unittest.TestLoader().loadTestsFromTestCase(TestCase))

# Generated at 2022-06-23 22:39:11.573071
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    Data = ast.Name(id='Data', ctx=ast.Load())
    m = ast.Module(body=[Data])
    mt = MetaclassTransformer()
    if mt.visit(m) is None:
        raise RuntimeError()


# Generated at 2022-06-23 22:39:17.211918
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    m = ast.parse("""
        class X(y, z, metaclass=x):
            pass
    """)

    new_m = ast.parse("""
        from six import with_metaclass
        class X(with_metaclass(x, y, z)):
            pass
    """)

    assert MetaclassTransformer().visit(m) == new_m

# Generated at 2022-06-23 22:39:20.916791
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    # FIXME: This tests should be improved.
    tree = ast.parse('class A(metaclass=type):pass')
    tree = MetaclassTransformer().visit(tree)

# Generated at 2022-06-23 22:39:26.525800
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    tree = ast.parse("""
        class Test(metaclass = TestMetaClass):
            pass
    """)

    newtree = MetaclassTransformer().visit(tree)  # type: ignore
    newcode = ast2.unparse(ast.Module(body=newtree.body))

    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class Test(_py_backwards_six_withmetaclass(TestMetaClass, )):
        pass
    """

    assert newcode == expected

# Generated at 2022-06-23 22:39:32.713298
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse(textwrap.dedent("""\
        class C(metaclass=M):
            pass
        """))
    assert MetaclassTransformer().visit(module) == ast.parse(textwrap.dedent("""\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class C(_py_backwards_six_withmetaclass(M))
            pass
        """))

# Generated at 2022-06-23 22:39:37.545696
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    mod = ast.parse("class A(metaclass=B): pass")
    tr = MetaclassTransformer()
    tr.visit(mod)
    assert six_import.get_body() == mod.body[0]
    assert six_import.get_body() == mod.body[0]



# Generated at 2022-06-23 22:39:45.105671
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from six import with_metaclass as _py_backwards_six_withmetaclass
    import ast
    import unittest

    class TestMetaclassTransformer(unittest.TestCase):
        def test_simple(self):
            code = """class MyClass():\n    pass"""
            expected = """from six import with_metaclass as _py_backwards_six_withmetaclass\nclass MyClass():\n    pass"""

            result = ast.parse(code)
            MetaclassTransformer().visit(result)
            self.assertEqual(ast.dump(result).split('\n'), expected.split('\n'))

        def test_simple_with_metaclass(self):
            code = """class MyClass(metaclass=int):\n    pass"""

# Generated at 2022-06-23 22:39:47.782180
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from . import test_base
    import astor
    import ast

# Generated at 2022-06-23 22:39:53.437981
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import compile_source as _compile_source
    from ..utils import source_to_ast as _source_to_ast

    source = ("from six import with_metaclass as _py_backwards_six_withmetaclass\n"
              "class A(metaclass=B): pass")

    ast_ = _source_to_ast.cache(source)
    assert MetaclassTransformer().visit(ast_) is None

    result = _compile_source.cache(source)
    assert result.get('__version__') == '2.7'

# Generated at 2022-06-23 22:40:00.397959
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.syntax import PythonSyntaxError
    from ..utils.source import source_to_module
    from .six import SixDetector
    from .six import SixExtractor
    from .six import SixTransformer
    from .six import SixImportInserter
    from .six import WithStatementTransformer
    from .metaclass import MetaclassDetector
    from .metaclass import MetaclassExtractor
    from .metaclass import MetaclassImportInserter
    from .metaclass import WithMetaclassDetector
    from .metaclass import WithMetaclassTransformer
    from ..utils.tree import print_tree, get_parent

    source = '''
    class MetaClass(type):
        pass

    class WithMetaclass(metaclass=MetaClass):
        pass
    '''
    module

# Generated at 2022-06-23 22:40:10.929142
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six
    n = ast.parse('class A(metaclass=B):pass')
    m = MetaclassTransformer()
    m.set_target_versions(2, 7, 3)
    n = m.visit(n)
    assert n.body[0].bases[0].func.id == '_py_backwards_six_with_metaclass'
    assert len(n.body[0].bases[0].keywords) == 2
    assert n.body[0].bases[0].keywords[0].arg == 'metaclass'
    assert n.body[0].bases[0].keywords[0].value.id == 'B'
    assert n.body[0].bases[0].keywords[1].arg == 'bases'

# Generated at 2022-06-23 22:40:13.314582
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-23 22:40:17.872763
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.test_fixtures import Snippet
    snippet = Snippet("class MyAwesomeClass(metaclass=MyAwesomeMetaClass):\n    pass")
    compiler = MetaclassTransformer()
    compiler.visit(snippet.ast())

# Generated at 2022-06-23 22:40:19.325739
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import typed_ast.ast3 as ast


# Generated at 2022-06-23 22:40:20.196544
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:40:27.066346
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.testutils import patched, transform
    from ..utils.mock_tree import build_module
    from ..utils.trees import get_node_of_class

    ast_1 = build_module("class A(object, metaclass=type):\n    pass")
    expected_1 = build_module("from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(type, object)):\n    pass")

    ast_2 = build_module("class B(object, metaclass=type[int]):\n    pass")

# Generated at 2022-06-23 22:40:31.790516
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typing import List
    import astor
    # Type info
    from ..test_utils import assert_equal_ast

    source = """
    class A(metaclass=B):
        pass
    """
    f = ast.parse(source)
    compiled_f = MetaclassTransformer().visit(f)

# Generated at 2022-06-23 22:40:39.551835
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # type: () -> None
    from ..utils.pytree import parse_module
    tree = parse_module('''
    class Foo(metaclass=type):
        pass
    ''')
    mt = MetaclassTransformer()
    mt.visit(tree)
    assert mt.visit(tree) == [
        six_import.get_body_ast(),
        ast.ClassDef(name='Foo',
            bases=[class_bases.get_body_ast()],
            body=[], decorator_list=[])]

# Generated at 2022-06-23 22:40:40.592989
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import unittest
    

# Generated at 2022-06-23 22:40:44.729098
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    src = '''class MyClass(metaclass=MyMetaClass): pass'''

# Generated at 2022-06-23 22:40:49.547499
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    node = six_import.get_ast()
    transformer = MetaclassTransformer()
    assert transformer.visit(node) == six_import.get_ast()

    node = class_bases.get_ast()
    transformer = MetaclassTransformer()
    assert transformer.visit(node) == class_bases.get_ast()

# Generated at 2022-06-23 22:40:58.005025
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # import six
    # from six import with_metaclass as _py_backwards_six_withmetaclass
    expected = 'from six import with_metaclass as _py_backwards_six_withmetaclass'
    actual = MetaclassTransformer(target_versions={}).visit(six_import.get_ast())
    assert str(actual) == expected

    # class Parent(object):
    #     pass

    # class Child(Parent, _py_backwards_six_withmetaclass(type)):
    #     pass

    expected = 'class Child(Parent, _py_backwards_six_withmetaclass(type)): pass'
    actual = MetaclassTransformer(target_versions={}).visit(class_bases.get_ast())
    assert str(actual) == expected

# Generated at 2022-06-23 22:41:05.946023
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Given
    class_node = ast.ClassDef(name='X',
                              bases=[],
                              keywords=[],
                              body=ast.Pass())
    module_node = ast.Module(body=[class_node])
    transformer = MetaclassTransformer()

    # When
    transformed_module_node = transformer.visit(module_node)

    # Then
    assert isinstance(transformed_module_node.body[0], ast.Expr)
    assert isinstance(transformed_module_node.body[1], ast.ClassDef)


# Generated at 2022-06-23 22:41:14.244095
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from . import _test_transformer
    import sys

    if sys.version_info < (2, 7):
        _test_transformer(MetaclassTransformer, """
        import six
        class Foo(object):
            pass
        """,
        """
        import six
        class Foo(_py_backwards_six_withmetaclass(object)):
            pass
        """)
    else:
        _test_transformer(MetaclassTransformer, """
        class Foo(object):
            pass
        """,
        """
        class Foo(object):
            pass
        """)

# Generated at 2022-06-23 22:41:19.226162
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    with six_import:
        assert {'six'} == set(six_import.get_imports())

    mt = MetaclassTransformer()
    mod = ast.parse('')
    mt.visit(mod)

    assert six_import.get_body() == mt.imports

    assert {'six'} == set(six_import.get_imports())



# Generated at 2022-06-23 22:41:21.811422
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source

    c = MetaclassTransformer().visit(ast.parse(source(
        """
        class A(metaclass=B):
            pass
        """
    )))

    import astor

    print(astor.to_source(c))

# Generated at 2022-06-23 22:41:25.288722
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # see: tests/fixtures/2.7/with_metaclass.py
    from ..utils.test_fixture import make_yield_code, make_snippet_code


# Generated at 2022-06-23 22:41:32.164795
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = six_import.dedent() + class_bases.dedent()
    code += "class A(metaclass=B): pass"
    expected_code = six_import.dedent() + class_bases.dedent()
    expected_code += "class A(_py_backwards_six_withmetaclass(B)): pass"
    tree = ast.parse(code)
    MetaclassTransformer().visit(tree)
    assert ast.dump(tree) == expected_code

# Generated at 2022-06-23 22:41:40.260582
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    node = ast.ClassDef(name='A', bases=[], keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
                        body=[], decorator_list=[])
    MetaclassTransformer().visit(node)
    assert ast.dump(node) == "ClassDef(name='A', bases=[Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), args=[Name(id='B', ctx=Load())], keywords=[])], keywords=[], body=[], decorator_list=[])"

# Generated at 2022-06-23 22:41:48.163309
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..transformer_test_case import TransformerTestCase
    from ..utils.ast_utils import ast_node_equals

    class TestMetaclassTransformer(TransformerTestCase):
        transformer = MetaclassTransformer

        def test_class_with_metaclass(self):
            source = '''class A(metaclass=B):
                pass'''

# Generated at 2022-06-23 22:41:54.464877
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = """\
        class A(metaclass=B):
            pass
    """
    expected = """\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_with_metaclass(B)):
            pass
    """
    tree = ast.parse(source)
    result = MetaclassTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-23 22:41:59.304763
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:42:06.421736
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = inspect.cleandoc("""
        class A(metaclass=B):
            pass
        class C(D, metaclass=E):
            pass
        class F(G, H, metaclass=I):
            pass
        class J(K, L, M, N, metaclass=O):
            pass
    """)

# Generated at 2022-06-23 22:42:14.024531
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    def do_test(test_input, expected_output):
        node = ast.parse(test_input) # type: ignore
        MetaclassTransformer().visit(node) # type: ignore
        output = astor.to_source(node).rstrip()
        assert output == expected_output

    do_test(
        '''
        class A(metaclass=B):
            pass
        ''',
        '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        ''')


# Generated at 2022-06-23 22:42:14.684948
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:42:21.115436
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    mt = MetaclassTransformer(None)

    assert not mt.tree_changed

    # Check that nothing is changed when there's no meta class.
    node = ast.ClassDef(name='A', bases=[ast.Name(id='B', ctx=ast.Load())],
                        keywords=[], body=[])
    mt.visit_ClassDef(node)

    assert not mt.tree_changed
    assert node.bases == [ast.Name(id='B', ctx=ast.Load())]

    # Check that the meta class is replaced by a call to six.with_metaclass

# Generated at 2022-06-23 22:42:23.795516
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    m = ast.parse('class B(type): pass')
    t = MetaclassTransformer()
    t.visit(m)
    assert get_source(m).startswith('from six import with_metaclass as')



# Generated at 2022-06-23 22:42:33.923624
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..registry import Registry
    import logging
    import sys
    
    class MockLoggingHandler(logging.Handler):
        """Mock logging handler to check for expected logs."""
    
        def __init__(self, *args, **kwargs):
            self.reset()
            logging.Handler.__init__(self, *args, **kwargs)
    
        def emit(self, record):
            self.messages[record.levelname.lower()].append(record.getMessage())
    
        def reset(self):
            self.messages = {
                'debug': [],
                'info': [],
                'warning': [],
                'error': [],
                'critical': [],
            }
    from py_backwards.transformers.six import MetaclassTransformer

# Generated at 2022-06-23 22:42:41.297245
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    tree = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    Transformer = MetaclassTransformer()
    Transformer.visit(tree)
    new_code = compile(tree, '', 'exec')
    scope = {'B': 'abc', '_py_backwards_six_withmetaclass': 'def'}
    exec(new_code, scope)
    assert scope['A'] == 'def(abc)'



# Generated at 2022-06-23 22:42:46.348253
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    assert astor.to_source(MetaclassTransformer().visit(ast.parse('''
    class A(metaclass=B):
        pass
    '''))) == '''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(
        _py_backwards_six_withmetaclass(B),
    ):
        pass
    '''

# Generated at 2022-06-23 22:42:52.929449
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six
    from ..utils.test_utils import unit_test_ast_builder as ast_builder

    node = ast_builder.build_ast("""\
    class A(metaclass=B):
        pass
    """)
    result = MetaclassTransformer().visit(node)
    expected_node_repr = """\
    Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0), ClassDef(name='A', bases=[Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), args=[Name(id='B', ctx=Load())], keywords=[])], body=[], decorator_list=[])])"""

    assert six.P

# Generated at 2022-06-23 22:43:02.653396
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Compiles:
        class A(metaclass=B):
            pass
    To:
        class A(_py_backwards_six_with_metaclass(B))
    
    """
    transformer = MetaclassTransformer()
    source = dedent("""\
    class A(metaclass=B):
        pass""")
    expected = dedent("""\
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass""")
    tree = ast.parse(source)
    tree = transformer.visit(tree)
    tree = ast.fix_missing_locations(tree)
    result = compile(tree, '', 'exec')
    print(result)

# Generated at 2022-06-23 22:43:10.270898
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..ast import parse_ast
    from ..utils.utils import dump_tree
    tree = parse_ast('class A(metaclass= B):\n    def __init__(self, x):\n        pass')

    tree = MetaclassTransformer().visit(tree)
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0],ast.ImportFrom)
    assert isinstance(tree.body[1], ast.ClassDef)
    assert tree.body[1].bases[0].args[0].id == 'B'

# Generated at 2022-06-23 22:43:11.598123
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Arrange
    import typed_ast.ast3

# Generated at 2022-06-23 22:43:15.298105
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    visitor = MetaclassTransformer()
    tree = ast.parse('''class MetaclassTransformer(BaseNodeTransformer):
        def visit_Module(self, node):
            return node.body[0].value.id
        ''')
    visitor.visit(tree)
    assert visitor.result() == 'ast3'


# Generated at 2022-06-23 22:43:20.698413
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    import textwrap
    module = textwrap.dedent('''\
        class A(metaclass=B): pass''')
    expected = textwrap.dedent('''\
        import six
        class A(six.with_metaclass(B)): pass
    ''')
    node = astor.parse_module(module)
    MetaclassTransformer().visit(node)
    assert astor.to_source(node) == expected

# Generated at 2022-06-23 22:43:28.248401
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3, parse
    from .base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        target_cls = MetaclassTransformer
        target_version = (2, 7)

        def test_empty_module(self):
            import six
            import os
            # type: (int, ) -> int
            source = "import six"

            mod = ast.parse(source)
            assert six in [i.module for i in mod.body]

            transformer = self.target_cls()
            new_mod = transformer.visit(mod)

            self.assertFalse(transformer._tree_changed)

            import_six = new_mod.body[0]
            self.assertIsInstance(import_six, ast.Import)


# Generated at 2022-06-23 22:43:32.778153
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import compile
    module = compile('''
    class A(metaclass=B):
        pass
    ''', 2.7)
    assert hasattr(module, 'A')
    assert module.A.__bases__ == (module._py_backwards_six_withmetaclass(module.B), )

# Generated at 2022-06-23 22:43:42.284249
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import sys
    sys.version_info = (2, 7)
    from nodes import Module
    node = Module([
        ('class', ('A', ('B',), [], [])),
        ('class', ('A', ('B',), [], [])),
        ('class', ('A', ('B',), [], []))
    ])
    transformer = MetaclassTransformer('six')
    res = transformer.visit_Module(node)

# Generated at 2022-06-23 22:43:53.306893
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code_before_transformation = '''
    class A(metaclass=B):
        def foo():
            return 'text'
    '''
    code_after_transformation = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        def foo():
            return 'text'
    '''
    tree_before_transformation = ast.parse(code_before_transformation)
    assert MetaclassTransformer().visit(tree_before_transformation)
    tree_after_transformation = ast.parse(code_after_transformation)
    assert ast.dump(tree_before_transformation) == ast.dump(tree_after_transformation)

# Generated at 2022-06-23 22:44:03.554608
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast as oast
    import astor
    import textwrap

    source = '''
        class A(metaclass=B, x=y):
            b = 1
        d = 2
        print(A)
    '''
    node = oast.parse(textwrap.dedent(source))
    node = MetaclassTransformer().visit(node)
    assert astor.to_source(node) == '''\
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class A(_py_backwards_six_withmetaclass(B), *[], **{}):
        b = 1
    d = 2
    print(A)
    '''

# Generated at 2022-06-23 22:44:09.498293
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    src = "class A(metaclass=B): pass"
    node = ast.parse(src)
    MetaclassTransformer.run_visitor(node)
    out = astor.to_source(node)

# Generated at 2022-06-23 22:44:15.440536
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """class A(metaclass=B):
    pass
"""
    expected = """class A(_py_backwards_six_withmetaclass(B)):
    pass
"""
    compiled_code = MetaclassTransformer(code).run()
    assert compiled_code.strip() == expected.strip()



# Generated at 2022-06-23 22:44:21.197389
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...tests import TestCase
    from typed_ast import ast3 as ast 
    from .six import six_import
    from .six.utils import with_metaclass

    class Test(TestCase):
        def setUp(self):
            self.metaclass = ast.Name(id='B', ctx=ast.Load())
            self.bases = [ast.Name(id='B', ctx=ast.Load()), ast.Name(id='C', ctx=ast.Load())]
            self.keyword = ast.keyword(arg='metaclass', value=self.metaclass)

# Generated at 2022-06-23 22:44:30.316608
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert compile(six_import.get_ast(), '/dev/null', 'exec')

    assert compile(class_bases.get_ast(metaclass=ast.Name(id='A'),  # type: ignore
                                       bases=[ast.Name(id='B')]),
                   '/dev/null', 'exec')

    assert compile(MetaclassTransformer().visit(six_import.get_ast()),
                   '/dev/null', 'exec')

    assert compile(MetaclassTransformer().visit(class_bases.get_ast(metaclass=ast.Name(id='A'),  # type: ignore
                                                                     bases=[ast.Name(id='B')])),  # type: ignore
                   '/dev/null', 'exec')

    tree: ast.Module
    tree = MetaclassTransformer().visit

# Generated at 2022-06-23 22:44:35.701870
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():

    source = """
        class A(B, metaclass=C):
            pass
        """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(C, B)):
            pass
        """
    assert compile_snippet(source, target=MetaclassTransformer.target) == expected

# Generated at 2022-06-23 22:44:37.049422
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.syntax import to_source


# Generated at 2022-06-23 22:44:46.359332
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import logging
    logger = logging.getLogger('py_backwards')
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.FileHandler('file.log'))

    from .ast_helpers import parse, dump

    input = """
        class A(metaclass=type):
            def __init__(self):
                pass
    """

    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(type)):
            def __init__(self):
                pass
    """

    t = MetaclassTransformer()
    result = dump(t.visit(parse(input)))

    assert result == expected

# Generated at 2022-06-23 22:44:56.249349
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six
    import pytest
    from typed_ast.compat import ccompiler

    if six.PY2:
        with pytest.raises(ImportError):
            from typed_ast import ast3, misc
    else:
        from typed_ast import ast3, misc

    from .metadata import Metadata

    Metadata().set_compiler(compiler='cc')  # type: ignore

    body = ast.parse("""
        class X(metaclass=A): pass
    """)

    optimizer = MetaclassTransformer()
    optimizer.visit(body)

    assert isinstance(body.body[0].bases[0], ast.Call) is True
    assert isinstance(body.body[0].bases[0].func, ast.Name) is True

# Generated at 2022-06-23 22:44:58.014060
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:45:01.877989
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = """
    class A:
        pass
    class B(metaclass=type):
        pass
    """
    tree = ast.parse(source, mode='exec')
    MetaclassTransformer().visit(tree)
    print(ast.dump(tree))

# Generated at 2022-06-23 22:45:11.707444
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..compat_configuration import CompatibilityConfiguration
    from ..compat_targets import PY27, PY36
    from ..scope import FileScope
    from ..utils.snippet import snippet
    from ..visitors import NodeSearcher
    import contextlib

    @snippet
    def x():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(metaclass=B):
            pass

    configuration = CompatibilityConfiguration.from_targets(PY36, PY27)
    scope = FileScope.from_tree(ast.parse(x.get_source()), configuration)

# Generated at 2022-06-23 22:45:12.726059
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:45:19.002083
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .fake_ast import parse, get_source

    test_case = 'class Test(): __metaclass__ = Test; pass'
    node = parse(test_case)
    trans = MetaclassTransformer()
    trans.visit(node)

    assert 'class Test' in get_source(node)
    assert '_py_backwards_six_withmetaclass' in get_source(node)
    assert '__metaclass__' not in get_source(node)

# Generated at 2022-06-23 22:45:29.429084
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.compat import print_function
    from ..transformer import Transformer
    
    class DummyTransformer(Transformer):
        def __init__(self):
            Transformer.__init__(self, target=(3, 4), dependencies=[])
    
    input_ = """
        class A(metaclass=B):
            pass
    """
    expected_output = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    node = ast.parse(input_)

    mt = MetaclassTransformer()
    mt.visit(node)
    dt = DummyTransformer()

# Generated at 2022-06-23 22:45:39.333398
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast.parse("class A(metaclass=type): pass")
    metaclass = MetaclassTransformer()
    metaclass.visit(tree)
    assert ast.dump(tree, annotate_fields=False, include_attributes=False) == \
        "Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0), ClassDef(name='A', bases=[Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), args=[Name(id='type', ctx=Load())], keywords=[])], body=[Pass()], decorator_list=[])])"



# Generated at 2022-06-23 22:45:45.100152
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .transforms import transform_module
    from .transformer import compile_for_py

    mod = compile_for_py(MetaclassTransformer, \
        six_import.get_ast() + class_bases.get_ast() + \
        "class A(metaclass=typing.TypeVar('T')): pass", target=3, tree=True)
    assert mod.body[2].bases[0].func.value.id == '_py_backwards_six_withmetaclass'
    
    mod = compile_for_py(MetaclassTransformer, \
        six_import.get_ast() + class_bases.get_ast() + \
        "class B(metaclass=typing.TypeVar('T')): pass", target=3, tree=True)
    assert mod.body

# Generated at 2022-06-23 22:45:52.269144
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.Module(body=[
        ast.ClassDef(name='A', bases=[
            ast.Name(id='B', ctx=ast.Load())
        ], body=[
        ], decorator_list=[],
        keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='C', ctx=ast.Load()))]
        )
    ])
    transformer = MetaclassTransformer()
    r = transformer.visit_Module(node)
    assert transformer._tree_changed == True
    assert r.body[1].bases[0].func.func.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-23 22:45:54.493788
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..codegen import to_source
    from ..transformers import TransformerSuite

# Generated at 2022-06-23 22:46:01.684292
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)) :
            pass

    m = MetaclassTransformer()
    m.visit(before.get_ast())
    assert str(after.get_ast()) == str(m.tree)

# Generated at 2022-06-23 22:46:10.638593
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astunparse
    from .six import SixImportInjector
    code = """
        class A(metaclass=B):
            pass
    """
    ast_tree = six_import.get_ast() + ast.parse(code)
    result = MetaclassTransformer().visit(ast_tree)

    expected_code = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    expected = six_import.get_ast() + ast.parse(expected_code)
    assert astunparse.unparse(result) == astunparse.unparse(expected)

    assert isinstance(result, ast.Module)
    assert len(result.body) == 2


# Generated at 2022-06-23 22:46:19.757868
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import os, sys

    file_path = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(file_path + '/../../')

    from pythran.tests import test_programs
    from pythran.passmanager import PassManager
    from pythran.analyses import PythranTypeError
    from pythran.intrinsic import IntrinsicFinder

    pm = PassManager("test_metaclass_transformer")
    pm.append(IntrinsicFinder)
    pm.append(MetaclassTransformer, 'test_metaclass_transformer')
    pm.append(PythranTypeError)

    source = test_programs.get('metaclass')
    ast = pm.gather(source, 'test.py')


# Generated at 2022-06-23 22:46:22.176020
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..tests import generate_transform_test
    generate_transform_test(MetaclassTransformer, 'six')


# Generated at 2022-06-23 22:46:27.727506
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    assert MetaclassTransformer._test_generic_visit(ast.parse('class A(metaclass=B):\n\tpass'),
                                                    ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)):\n\tpass'))



# Generated at 2022-06-23 22:46:34.792899
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..testing_utils import make_call_node
    from ..utils.base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        def test_class_metaclass_replace_get_body_used(self):
            tree = ast.parse(
                """class A(metaclass=B):
                    pass
                """
            )
            self.check_code_equal(
                tree,
                """
                class A(_py_backwards_six_withmetaclass(B)):
                    pass
                """
            )

    TestCase.do_test(MetaclassTransformer)

# Generated at 2022-06-23 22:46:41.335944
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Test with a simple class definition.
    source = '''
    class A(object):
        pass
    '''
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert tree.body[0].bases[0].func.id == '_py_backwards_six_withmetaclass'

    # Test with a class definition that uses a metaclass.
    source = '''
    class A(metaclass=type):
        pass
    '''
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert tree.body[0].bases[0].func.id == '_py_backwards_six_withmetaclass'

    # Test with a class definition that does not use a metaclass.

# Generated at 2022-06-23 22:46:52.440512
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from six import assertCountEqual
    from typing import TYPE_CHECKING
    import typed_ast.ast3 as ast

    from .utils import round_trip, parse

    if TYPE_CHECKING:
        from .base import BaseNodeTransformer

    class C(ast.AST):
        _fields = ('n',)

    class D(C):
        _fields = ('x',)

    class E(C):
        _fields = ('a', 'b')

    class F(C):
        _fields = ('node',)

    # Check that the keyword is removed
    src = """
        class C(metaclass=type):
            pass
    """

# Generated at 2022-06-23 22:46:53.516966
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:47:02.285382
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_tree
    from ..utils.tree import to_source
    tree = """
    class Meta(type):
        pass
    
    class A(metaclass=Meta):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    class Meta(type):
        pass
    
    class A(_py_backwards_six_withmetaclass(Meta)):
        pass
    """
    tree = parse_tree(tree)
    transformer = MetaclassTransformer()
    result = transformer.visit(tree)
    assert to_source(result) == expected

# Generated at 2022-06-23 22:47:12.538814
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import ast_builder

    module = ast_builder("""
    with_metaclass = _py_backwards_six_with_metaclass
    from six import with_metaclass as _py_backwards_six_with_metaclass
    
    class A(metaclass=B):
        pass
    """)

    class_a = module.body[2]
    assert isinstance(class_a, ast.ClassDef)
    assert isinstance(class_a.bases[0], ast.Call)
    assert len(class_a.bases) == 1
    assert class_a.keywords == []

# Generated at 2022-06-23 22:47:21.955790
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    input_tree = ast.parse(six_import.get_source()+"\n\n")

    input_tree = insert_at(1, input_tree, class_bases.get_body(metaclass=ast.Name(id="Meta", ctx=ast.Load()),
                                                               bases=ast.List(elts=[ast.Name(id="object", ctx=ast.Load())])))
    input_tree = insert_at(2, input_tree, ast.parse("\n\nclass A(metaclass=object):\n    pass"))
    assert ast.dump(input_tree) == six_import.get_source() + class_bases.get_source()+"\n\nclass A(metaclass=object):\n    pass"

    output_tree = metaclass_trans

# Generated at 2022-06-23 22:47:30.096963
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = """
    class A(object, metaclass=abc.ABCMeta):
        def get_data(self):
            return []
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(abc.ABCMeta, object)):
        def get_data(self):
            return []
    """
    check_modules(source, expected, MetaclassTransformer)
