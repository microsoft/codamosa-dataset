

# Generated at 2022-06-23 22:37:36.864700
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    six_import.test(MetaclassTransformer.visit_Module)
    class_bases.test(MetaclassTransformer.visit_ClassDef)

# Generated at 2022-06-23 22:37:37.420931
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:37:43.440627
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    mod = ast.parse('class A(metaclass=B): pass')
    _mod = MetaclassTransformer()(mod)
    assert _mod.body[0].name == 'six'
    assert _mod.body[1].name == 'A'
    assert _mod.body[1].bases[0].value.func.value.id == '_py_backwards_six_withmetaclass'
    assert _mod.body[1].bases[0].value.args[0].id == 'B'


# Generated at 2022-06-23 22:37:48.250701
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    snippet.test_snippets(six_import.get_body())
    snippet.test_snippets(class_bases.get_body(metaclass=ast.Name(id='B', ctx=ast.Load()),
                                               bases=ast.List(elts=[], ctx=ast.Load())))

# Generated at 2022-06-23 22:37:50.483238
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:37:54.604557
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    ast_module = ast.parse('class A(metaclass=B):\n pass')
    tree = MetaclassTransformer().visit(ast_module)
    assert 'class A(_py_backwards_six_withmetaclass(B)):\n pass' == astor.to_source(tree)

# Generated at 2022-06-23 22:38:00.475605
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    mt = MetaclassTransformer()
    assert mt.visit_Module(ast.parse('class A(metaclass=B): pass')) == ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)): pass')


# Generated at 2022-06-23 22:38:01.945667
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:38:03.390772
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-23 22:38:04.409634
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast

# Generated at 2022-06-23 22:38:05.469785
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys


# Generated at 2022-06-23 22:38:10.479045
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class C(object):
        class Meta(object):
            pass
        pass
    
    old_tree = ast.parse('''
    class A(metaclass=C.Meta):
        pass
    ''')
    
    new_tree = ast.parse('''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    class A(_py_backwards_six_withmetaclass(C.Meta)):
        pass
    ''')
    
    assert MetaclassTransformer().visit(old_tree) == new_tree

# Generated at 2022-06-23 22:38:19.618203
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys
    from .. import __main__ as py_backwards
    from .unittest_transformer_support import Source, run_transformer_test

    test_source = Source("""
            class Foo(metaclass=Bar):
                pass
                """)

    expected_source = Source("""
            from six import with_metaclass as _py_backwards_six_withmetaclass

            class Foo(_py_backwards_six_withmetaclass(Bar)):
                pass
                """)

    py_backwards.main(['--debug', __file__])
    run_transformer_test(sys.modules[__name__].MetaclassTransformer, test_source, expected_source)

# Generated at 2022-06-23 22:38:23.888113
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source

    src1 = """
    class Foo(Bar):
        pass
    """
    src2 = """
    class Foo(_py_backwards_six_withmetaclass(Bar)):
        pass
    """

    node = ast.parse(src1)  # type: ignore
    MetaclassTransformer().visit(node)

    assert source(node) == src2

# Generated at 2022-06-23 22:38:33.381914
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..six import six_import

    # If I have the following snippet:
    @snippet
    def before():
        class A:
            pass
    
    # it get compiled to:
    @snippet
    def after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A:
            pass
    
    assert six_import in MetaclassTransformer.dependencies

    # then the snippet before() should be compiled to the snippet after().
    assert MetaclassTransformer.visit(before.get_ast()) == after.get_ast()



# Generated at 2022-06-23 22:38:41.913495
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .base import BaseTestTransformer
    
    class TestMetaclassTransformer(BaseTestTransformer):
        transformer = MetaclassTransformer
        filename = __file__

        def test_class_def(self):
            input = """
            class A:
                pass 
            """
            output = """
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A:
                pass 
            """
            self.check_ast(input, output)

    test_MetaclassTransformer = TestMetaclassTransformer()
    test_MetaclassTransformer.test_class_def()


# Generated at 2022-06-23 22:38:48.948635
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    src = """
        class A(metaclass=B):
            pass
        """

    result = """
        from six import with_metaclass as _py_backwards_six_withmetaclass


        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """

    tree = ast.parse(src)
    tree = MetaclassTransformer().visit(tree)

    # TODO: we should ensure it is valid python, but for now we will just check generated code
    assert ast.dump(tree) == result

# Generated at 2022-06-23 22:38:50.286628
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:39:01.828496
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import textwrap
    code = textwrap.dedent("""
    class Meta(type):
        pass
    class Test(metaclass=Meta):
        pass

    """)
    expected = textwrap.dedent("""
    from six import with_metaclass

    class Test(with_metaclass(Meta)):
        pass
    """)

    class_node = ast.parse(textwrap.dedent("""
    class Test:
        pass
    """)).body[0]
    module_node = ast.parse(textwrap.dedent("""
    from six import with_metaclass

    """)).body + [class_node]

    node = ast.parse(code)
    node = MetaclassTransformer().visit(node)
    assert ast.dump(node, include_attributes=False)

# Generated at 2022-06-23 22:39:11.106432
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = six_import.get_source_code() + 'class A(metaclass=type):\n    pass'
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    six_import.assert_unchanged(tree)
    expected_tree = class_bases.get_ast(metaclass=ast.Name(id='type', ctx=ast.Load()),
                                        bases=ast.List(elts=[], ctx=ast.Load()))
    ast.fix_missing_locations(expected_tree)
    assert ast.dump(tree, include_attributes=False) == ast.dump(expected_tree, include_attributes=False)

# Generated at 2022-06-23 22:39:12.963965
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .utils import do_test_node
    from typed_ast import ast3 as ast

# Generated at 2022-06-23 22:39:14.139315
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:39:23.864334
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3
    source = """
    class A(metaclass=b):
        pass
    """
    tree = typed_ast.ast3.parse(source)
    MetaclassTransformer().visit(tree)

# Generated at 2022-06-23 22:39:34.506705
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()
    node = ast.parse('class A(metaclass=B, p=1): pass')
    node = transformer.visit(node)

# Generated at 2022-06-23 22:39:43.035291
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class TestMetaclassTransformer(unittest.TestCase):
        def test_code(self):
            test_code = """
            class A(metaclass=B, c="test"):
                pass
            """
            expected_code = """
            from six import with_metaclass as _py_backwards_six_withmetaclass
            
            class A(_py_backwards_six_withmetaclass(B, *[])):
                pass
            """
            node = ast.parse(test_code)
            transformer = MetaclassTransformer()
            transformer.visit(node)
            self.assertEqual(expected_code, astor.to_source(node))

    unittest.main(argv=[''], verbosity=2, exit=False)


# Generated at 2022-06-23 22:39:45.268262
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    t = MetaclassTransformer(target=(2, 7), dependencies=['six'])
    assert t


__all__ = ['MetaclassTransformer']

# Generated at 2022-06-23 22:39:47.556913
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_node


# Generated at 2022-06-23 22:39:55.150597
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast
    import six

    class X(six.with_metaclass(type)):
        pass

    assert ast.dump(ast.parse(six_import.get_body())) == ast.dump(ast.parse(six_import()))
    assert ast.dump(ast.parse(class_bases.get_body(metaclass=type,
                                                   bases=ast.parse("X").body[0].bases))) == ast.dump(ast.parse(class_bases(type,
                                                                                                                      X)))

    t = MetaclassTransformer()
    node = ast.parse("""
        class A:
            pass
        class B(metaclass=type):
            pass
        class C(metaclass=type, x=1):
            pass
    """)
    node = t

# Generated at 2022-06-23 22:39:58.251546
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from asttest import YieldFrom, assert_transform

    assert_transform(
        """class A(metaclass=B): pass""",
        """class A(_py_backwards_six_withmetaclass(B)): pass"""
    )

    assert_transform(
        """class A(C, D, metaclass=B): pass""",
        """class A(_py_backwards_six_withmetaclass(B)): pass"""
    )



# Generated at 2022-06-23 22:40:02.776565
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import typed_ast.ast3 as ast3
    node = ast3.ClassDef(
        name='A',
        keywords=[ast3.keyword(
            arg='metaclass',
            value=ast3.Name(
                id='B',
                ctx=ast3.Load()
            )
        )],
        bases=[ast3.Name(
            id='C',
            ctx=ast3.Load()
        )]
    )
    result = MetaclassTransformer.visit_ClassDef(MetaclassTransformer(), node)
    assert result.bases[0].func.id == '_py_backwards_six_withmetaclass'
    _, metaclass_value, bases = result.bases[0].args
    assert metaclass_value.id == 'B'


# Generated at 2022-06-23 22:40:10.386098
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = """
    class A():
        pass
    class B(metaclass=C):
        pass
    """
    module = ast.parse(source)
    compiler = MetaclassTransformer()
    compiler.visit(module)
    assert len(module.body) == 3
    assert module.body[0].value.id == '_py_backwards_six_with_metaclass'
    assert module.body[2].keywords == []
    assert module.body[2].bases[0].args[0].id == 'C'

# Generated at 2022-06-23 22:40:17.219683
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap
    from ..utils.parse_python import parse_python

    code = textwrap.dedent('''
        class Test(metaclass=int):
            pass
    ''')

    node = parse_python(code)
    res = MetaclassTransformer().visit(node)

    expected = textwrap.dedent('''
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class Test(_py_backwards_six_withmetaclass(int)):
        pass
    ''')

    assert res == parse_python(expected)

# Generated at 2022-06-23 22:40:18.078556
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:40:25.880777
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from copy import copy
    from itertools import product

    from ..utils.testing import assert_outcomes, TransformTestCase

    class Case(TransformTestCase):

        cases = list(product(*[(True, False)] * 4))
        cases.pop()
        cases = [product(i, (True, False)) for i in cases]
        cases = [item for sublist in cases for item in sublist]

        def transform(self, node):
            if self.mt:
                node = MetaclassTransformer(node).visit(node)
            if self.six:
                tree = node
                node = copy(node)
                tree = six_import.add_import(tree)
                node = six_import.add_import(node)
                node = MetaclassTransformer(node).visit(node)

                assert_

# Generated at 2022-06-23 22:40:26.926928
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor, six


# Generated at 2022-06-23 22:40:31.570768
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("class Test(): pass")
    actual = MetaclassTransformer().visit(node)
    expected = ast.parse("from six import with_metaclass as _py_backwards_six_withmetaclass\nclass Test(): pass")
    assert ast.dump(actual) == ast.dump(expected)



# Generated at 2022-06-23 22:40:42.404454
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from . import cst
    from .module_transformer import ModuleTransformer
    from ..config import Config
    from ..compilation import compile

    input = """
    class KW(object):
        pass
        
    class A(metaclass=KW):
        pass

    class B(A):
        pass

    class C(object, KW):
        pass
    """

    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    class KW(object):
        pass
        
    class A(_py_backwards_six_withmetaclass(KW)):
        pass

    class B(A):
        pass

    class C(object, _py_backwards_six_withmetaclass(KW)):
        pass
    """

# Generated at 2022-06-23 22:40:48.806575
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from . import to_source, parse
    source_code = 'class A(metaclass=int):pass'
    expected_code = 'class A(_py_backwards_six_withmetaclass(int)):pass'
    tree = parse(source_code)
    assert tree
    MetaclassTransformer().visit(tree)
    assert to_source(tree) == expected_code

# Generated at 2022-06-23 22:40:52.386473
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astunparse
    tree = ast.parse('class A(metaclass=B, x=1, y=2, z=3): pass')
    tree = MetaclassTransformer().visit(tree)
    print(astunparse.unparse(tree))

# Generated at 2022-06-23 22:40:53.560018
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys
    import six


# Generated at 2022-06-23 22:40:55.658414
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:40:57.653652
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer.get_name() == 'MetaclassTransformer'
    assert MetaclassTransformer.get_target_version() == (2,7)

# Generated at 2022-06-23 22:40:58.427039
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-23 22:41:09.164584
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.source import source_to_ast as to_ast
    from ..utils.source import source_to_ast_simple as to_simple_ast
    from ..utils.source import source_to_unparse as to_source
    from .six import six_import_transformer

    data = '''
    from six import with_metaclass
    class Object(object):
        pass

    class A(with_metaclass(Object)):
        pass
    '''
    node = to_ast(data)

    transformer = MetaclassTransformer()
    result = transformer.visit(node)
    source = to_source(result)
    result_simple = to_simple_ast(source)

    assert transformer._tree_changed is True

# Generated at 2022-06-23 22:41:14.851300
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    f = MetaclassTransformer()
    assert not f.tree_changed
    assert f.visit(ast.parse("""
    class a(b):
        pass
    """).body[0]) == ast.parse("""
    class a(_py_backwards_six_with_metaclass(b)):
        pass
    """).body[0]
    assert f.tree_changed

# Generated at 2022-06-23 22:41:15.837298
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:41:17.135233
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import typing
    import astunparse


# Generated at 2022-06-23 22:41:24.351170
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from .base import BaseNodeTransformer
    from .base import NodeTransformerVisitor
    
    
    
    class Dummy(MetaclassTransformer):
        """Dummy class for testing a NodeTransformer subclass"""
    
        def __init__(self, *args, **kwargs):
            super(Dummy, self).__init__(*args, **kwargs)
    
            self._tree_changed = False
    
        def visit(self, node):
            method = 'visit_' + node.__class__.__name__
            visitor = getattr(self, method, self.generic_visit)
            return visitor(node)
    
    @snippet
    def metaclass_usage():
        class A(metaclass=B):
            pass
    

# Generated at 2022-06-23 22:41:29.633567
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """Test if function ``visit_Module`` of class
    ``MetaclassTransformer`` works correctly.

    """
    from ast import Module, parse
    ast_tree = parse('import six')
    py_backwards = MetaclassTransformer()
    Module(body=six_import.get_body()) == py_backwards.visit(ast_tree)


# Generated at 2022-06-23 22:41:30.568590
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:41:36.094643
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = "class A(metaclass=B, arg=1): pass"
    tree = ast.parse(code)
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(tree)
    assert '_py_backwards_six_withmetaclass' in code
    assert 'B' not in code
    assert 'arg' not in code
    assert 'metaclass' not in code

# Generated at 2022-06-23 22:41:45.408367
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ast_tools.visitors import BaseNodeTransformer
    from ast_tools.visitors.unparse import Unparser
    from ast_tools.tests.utils import parse_compile_and_unparse
    from ast_tools.tests.visitors.test_base import BaseTest
    from ast_tools.transforms.metaclass import MetaclassTransformer
    from ast_tools.transforms.utils import insert_import

    class TestMetaclassTransformer(BaseTest):
        def test_metaclass_no_keywords(self):
            input_ast, output_ast = parse_compile_and_unparse('''
                class MyClass(object):
                    pass
            ''',
                parser=MetaclassTransformer,
                transformer=MetaclassTransformer,
            )

# Generated at 2022-06-23 22:41:52.339963
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor, six
    from typing import cast
    from .base import TransformerTestCase

    def do(source, expected):
        tree = ast.parse(source)
        transformer = MetaclassTransformer()
        transformed = transformer.visit(tree)
        self.assertEqual(astor.to_source(transformed), expected)
        # Check that the tree was changed
        self.assertTrue(transformer._tree_changed)

    # Test 1

# Generated at 2022-06-23 22:41:53.992961
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:42:02.042025
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

    def check(node):
        transformer = MetaclassTransformer()
        transformer.visit(node)

        module = node

        assert isinstance(module, ast.Module)
        assert len(module.body) == 2

        import_stmt = module.body[0]
        class_def = module.body[1]

        assert isinstance(import_stmt, ast.ImportFrom)
        assert isinstance(import_stmt.module, ast.Name)
        assert import_stmt.module.id == 'six'
        assert import_stmt.names == [
            ast.alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')
        ]

        assert isinstance(class_def, ast.ClassDef)

    check

# Generated at 2022-06-23 22:42:12.665845
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    class_A = ast.ClassDef(name="A",
                           bases=[ast.Name(id="B",
                                           ctx=ast.Load())],
                           keywords=[ast.keyword(arg="metaclass",
                                                 value=ast.Name(id="C",
                                                                ctx=ast.Load()))],
                           body=[],
                           decorator_list=[])
    t = MetaclassTransformer()
    t.visit(class_A)

# Generated at 2022-06-23 22:42:13.286095
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:42:18.244598
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = dedent('''
        class MyClass(metaclass=abc.ABCMeta, object):
            pass
    ''')
    expected = dedent('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class MyClass(_py_backwards_six_withmetaclass(abc.ABCMeta, object))
            pass
    ''')
    mt = MetaclassTransformer()
    assert mt.visit(ast.parse(code)) == ast.parse(expected)

# Generated at 2022-06-23 22:42:23.479348
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap
    code = textwrap.dedent("""\
        class MyClass(metaclass=ABCMeta):
            pass
        """)
    ast_tree = ast.parse(code)
    node = ast_tree.body[0]
    assert isinstance(node, ast.ClassDef)
    node_transformer = MetaclassTransformer()
    new_node = node_transformer.visit(node)
    assert isinstance(new_node, ast.ClassDef)
    assert new_node.bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert node.bases[0].id == 'ABCMeta'
    assert isinstance(node_transformer.tree_changed, bool)

# Generated at 2022-06-23 22:42:24.223869
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:42:34.680223
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .base import BaseTestTransformer
    class UnitTest(BaseTestTransformer.UnitTest):
        transformer = MetaclassTransformer()
        target_version = (2, 7)
        def test_import(self):
            with self._with_input('import x'):
                self._assert_output_equals(six_import.get_body() + ['import x'])

        def test_import_from(self):
            with self._with_input('from x import y'):
                self._assert_output_equals(six_import.get_body() + ['from x import y'])

        def test_import_as(self):
            with self._with_input('import x as y'):
                self._assert_output_equals(six_import.get_body() + ['import x as y'])

       

# Generated at 2022-06-23 22:42:45.023776
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .base import BaseTestTransformer
    from .base import compile_function
    from .base import function_ast
    from .base import module_ast
    from .base import transform

    class TestMetaclassTransformer(BaseTestTransformer):
        transformer = MetaclassTransformer()
        target = (2, 7)

    #Test for module ast
    @TestMetaclassTransformer(
        expected_output=module_ast("""
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A(_py_backwards_six_withmetaclass(B)):
                pass
        """)
    )
    def module_metaclass():
        class A(metaclass=B):
            pass

    module_metaclass()

    #Test for function ast

# Generated at 2022-06-23 22:42:51.933725
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import unittest.mock
    from ..utils.testing import capture_output

    class TestClass:
        def test_init_call(self):
            with capture_output() as out:
                MetaclassTransformer()

            lines = out.get_lines()
            assert len(lines) == 0

        def test_MetaTransformer_properties(self):
            with capture_output() as out:
                transformer = MetaclassTransformer()

            lines = out.get_lines()
            assert len(lines) == 0
            assert transformer.dependencies == ['six']

            with capture_output() as out:
                transformer.target = (2, 7)
            lines = out.get_lines()
            assert len(lines) == 0


# Generated at 2022-06-23 22:42:56.029034
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # type: () -> None
    """Test MetaclassTransformer.visit_ClassDef."""
    from .util import source_to_node, source_to_ast
    from .util import compare_source


# Generated at 2022-06-23 22:42:56.995181
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

# Generated at 2022-06-23 22:43:02.544429
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import outputs_from_inputs

    class_def = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    assert MetaclassTransformer.visit_ClassDef(class_def) == expected

# Generated at 2022-06-23 22:43:10.179389
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils import ast_parse
    from typed_ast import ast3
    from . import checker
    from ..utils import check_equal_ast

    src = 'class A(object, metaclass=type):\n\tpass'
    ast_root = ast_parse(src)
    root = MetaclassTransformer(target=(2, 7)).visit(ast_root)


# Generated at 2022-06-23 22:43:17.232452
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.test_utils import compile_snippet, assert_lines_equal
    from .six_imports import SixImportsTransformer
    from ..Transformer import Transformer
    
    
    class TestTransformer(Transformer):
        def __init__(self):
            super().__init__([MetaclassTransformer])
    
    transformer = TestTransformer()
    
    assert_lines_equal(transformer.visit(compile_snippet(six_import)), six_import)
    assert_lines_equal(transformer.visit(compile_snippet(class_bases)), class_bases)

# Generated at 2022-06-23 22:43:23.568690
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    cls = ast.ClassDef(name='TestClass',
                       bases=[],
                       keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='MetaClass'))],
                       body=[],
                       decorator_list=[],
                       lineno=1,
                       col_offset=0)

    cls.visit(MetaclassTransformer())

    assert cls.bases == class_bases.get_body(metaclass=ast.Name(id='MetaClass'), bases=ast.List(elts=[]))
    assert cls.keywords == []

# Generated at 2022-06-23 22:43:25.335857
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source

    source = source(MetaclassTransformer)
    assert MetaclassTransformer().visit(source) == source.tree

# Generated at 2022-06-23 22:43:35.998659
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.fixtures import make_fixtures, compile_snippets
    from ..utils.tree import get_node
    from astunparse import unparse

    ns = make_fixtures('metaclass', MetaclassTransformer)
    snippets = compile_snippets(ns)
    assert unparse(snippets['a'].body[0]) == unparse(six_import.get_body())
    node: ast.ClassDef = get_node(snippets['a'].body[1], ast.ClassDef)
    assert unparse(node.bases[0]) == unparse(class_bases.get_body(  # type: ignore
        metaclass=ns['B'],
        bases=ast.List(elts=[ast.Name(id='object', ctx=ast.Load())])))
   

# Generated at 2022-06-23 22:43:44.516242
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_source
    from ..utils.test_utils import get_node
    from ..utils.test_utils import parse_ast

    # Apply transformation
    new_node = MetaclassTransformer().visit(parse_ast('''
        class A(metaclass=B):
            pass
    '''))

    # Assert source
    assert_source(new_node, '''
        from six import with_metaclass as _py_backwards_six_withmetaclass


        class A(_py_backwards_six_withmetaclass(B))
            pass
    ''')

    # Assert that there is a single function definition
    assert len(new_node.body) == 2
    assert isinstance(new_node.body[0], ast.ImportFrom)

# Generated at 2022-06-23 22:43:46.901217
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    from sys import version_info
    from ast import parse

    tree = parse('class A(metaclass=B): pass')
    tree = MetaclassTransformer().visit(tree)

    assert tree.body[0].bases[0].func.value.func.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-23 22:43:52.392555
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module_node = ast.parse('class A: pass')
    expected = ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A: pass')
    
    # noinspection PyTypeChecker
    assert MetaclassTransformer().visit_Module(module_node) == expected


# Generated at 2022-06-23 22:44:03.640864
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..tests import transform

    with transform(MetaclassTransformer) as tx:
        l = tx.last_import
        assert tx.last_import > -1
        assert tx.last_class_bases > -1
        # twice to make sure we get the same reference
        assert tx.last_class_bases == tx.last_class_bases

        # second call to visit_ClassDef, has the same body as the first call
        tx.visit_ClassDef(ast.parse('class A(metaclass=B):pass').body[0])
        assert tx.last_class_bases == l

if __name__ == '__main__':
    import sys
    import os
    import unittest

# Generated at 2022-06-23 22:44:13.048701
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    import six
    from .six_transformer import SixTransformer
    from .base import BaseNodeTransformer

    six_import = """
from six import with_metaclass
"""
    class_bases = """
with_metaclass(C, *bases)
"""

    six_transformer = SixTransformer()
    six_transformer.visit(ast.parse(six_import))
    Transformer = BaseNodeTransformer.make_transformer_class(
        MetaclassTransformer, six_transformer)
    transformer = Transformer()


# Generated at 2022-06-23 22:44:14.847695
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    t = MetaclassTransformer('2.7', 'six')


# Generated at 2022-06-23 22:44:18.231403
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer({}).dependencies == ['six']
    assert MetaclassTransformer({}).target == (2, 7)
    assert MetaclassTransformer({}).__class__.__name__ == 'MetaclassTransformer'

# Generated at 2022-06-23 22:44:27.923777
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from six import with_metaclass as _py_backwards_six_withmetaclass
    src = """class A(metaclass=B):
        pass"""
    src_transformed = """class A(_py_backwards_six_withmetaclass(B)):
    pass"""

    transformer = MetaclassTransformer()
    assert isinstance(transformer, BaseNodeTransformer)
    transformer._tree_changed = False
    tree = ast.parse(src)
    transformer.visit(tree)
    trans_tree = ast.parse(src_transformed)
    transformer.visit(trans_tree)
    assert ast.dump(transformer.visit(tree)) == ast.dump(trans_tree)
    assert transformer._tree_changed is True


# Generated at 2022-06-23 22:44:32.838239
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    mod = ast.parse('class A(metaclass=B): pass')
    transpiler = MetaclassTransformer()
    new_module = transpiler.visit(mod)

# Generated at 2022-06-23 22:44:34.219075
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 22:44:36.438306
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.runner import run_code
    

# Generated at 2022-06-23 22:44:41.833792
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    expected = dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class myClass(_py_backwards_six_withmetaclass(int)):
        pass
    """)
    actual = dedent("""
    class myClass(metaclass=int):
        pass
    """)
    node = ast.parse(actual)
    transformed = MetaclassTransformer().visit(node)
    assert expected == astor.to_source(transformed)



# Generated at 2022-06-23 22:44:44.418073
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    module = '''class A(metaclass=int):\n    pass'''

# Generated at 2022-06-23 22:44:46.200623
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """
    Unit test for method visit_Module in class MetaclassTransformer
    """

# Generated at 2022-06-23 22:44:55.972166
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import Source
    from ..utils.driver import Driver
    
    source = Source("""
        class Metaclass(type):
            pass

        class A(object, metaclass=Metaclass):
            def __init__(self):
                self.name = "class A"
            
        print(A().name)
    """)
    tree = source.tree
    assert isinstance(tree, ast.Module)

    driver = Driver(tree, MetaclassTransformer)
    tree = driver.transformed_tree
    assert isinstance(tree, ast.Module)
    driver.assert_no_errors()

    try:
        import six
    except ImportError:
        assert driver.module_state.module_graph.module_refs == {'six'}
    else:
        assert driver.module_

# Generated at 2022-06-23 22:44:57.764386
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:44:59.656035
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3
    from typed_ast import py36 as typed_ast


# Generated at 2022-06-23 22:45:05.685974
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import parse_to_ast_node, ast_to_code
    ast_node = parse_to_ast_node('''
        class A(metaclass=B):
            pass
    ''')
    MetaclassTransformer().visit(ast_node)  # type: ignore
    assert ast_to_code(ast_node) == 'class A(_py_backwards_six_withmetaclass(B)):\n    pass'

# Generated at 2022-06-23 22:45:15.396381
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .base import BaseTestTransformer

    class TestMetaclassTransformer(BaseTestTransformer):
        transformer = MetaclassTransformer

        def test_convert_to_six(self):
            code = '''class A(object):\n    pass'''
            expected = '''from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(type)):\n    pass'''
            tree = self.transform_code(code)
            self.assertEqual(str(tree), expected)

        def test_convert_metaclass(self):
            code = '''class A(B):\n    pass'''

# Generated at 2022-06-23 22:45:26.443062
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    class_def = ast.ClassDef(name='A',  # type: ignore
                             bases=[ast.Name(id='object', ctx=ast.Load())],
                             keywords=[ast.keyword('metaclass', ast.Name(id='B', ctx=ast.Load()))])
    expected = ast.ClassDef(name='A',
                            bases=[ast.Call(func=ast.Name(id='_py_backwards_six_withmetaclass',
                                                          ctx=ast.Load()),
                                            args=[ast.Name(id='B', ctx=ast.Load())],
                                            keywords=[])],
                            keywords=[])
    mt = MetaclassTransformer()

    assert expected == mt.visit(class_def)



# Generated at 2022-06-23 22:45:32.239528
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Given
    from .sample_code import class_with_metaclass_in_module
    from .sample_code import class_with_metaclass_in_module_fixed

    # When
    module = MetaclassTransformer().visit(class_with_metaclass_in_module)

    # Then
    assert ast.dump(module, include_attributes=False) \
        == ast.dump(class_with_metaclass_in_module_fixed, include_attributes=False)



# Generated at 2022-06-23 22:45:38.353457
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    original = ast.parse("""\
    import six
    class A(metaclass=P):
        pass
    """)
    compiled = ast.parse("""\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(P)):
        pass
    """)
    assert MetaclassTransformer.compile(original) == compiled


# Generated at 2022-06-23 22:45:39.940936
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .base import BaseNodeTransformerTest
    BaseNodeTransformerTest(MetaclassTransformer)

# Generated at 2022-06-23 22:45:40.609126
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:45:49.321598
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

    node = ast.Module(
        body=[
            ast.ClassDef(
                name='A',
                bases=[ast.Name(id='B', ctx=ast.Load())],
                keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='C', ctx=ast.Load()))],
                body=[],
                decorator_list=[],
            )
        ]
    )

    result = MetaclassTransformer(node).result()
    assert isinstance(result, ast.Module)
    assert len(result.body) == 2
    # first assigned node should be a Name(id=_py_backwards_six_withmetaclass)
    # second assigned node should be a ClassDef

# Generated at 2022-06-23 22:45:52.903663
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import textwrap
    from typed_ast import ast3

    module = ast3.parse(textwrap.dedent("""
    class A(metaclass=int):
        pass
    """))
    MetaclassTransformer().visit(module)



# Generated at 2022-06-23 22:46:03.552011
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3 as ast
    from .base import BaseNodeTransformer
    from six import PY2
    import pickle
    """ Compiles:
        class A(metaclass=B):
            pass
    To:
        class A(_py_backwards_six_with_metaclass(B))

    """
    node = ast.ClassDef(name='A', bases=[], keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))], body=[])  # type: ignore

    result = MetaclassTransformer(min_python_version=(2, 7)).visit(node)

    assert isinstance(result, ast.ClassDef)
    assert result.name == 'A'

# Generated at 2022-06-23 22:46:09.769532
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = '''
    class A(metaclass=B):
        pass
    '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    tree = ast.parse(source)
    MetaclassTransformer(2, 7).visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-23 22:46:12.517661
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from asttokens import ASTTokens
    from ..utils import get_ast
    from ..utils.tree import findall_node, to_source


# Generated at 2022-06-23 22:46:19.116409
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ...tests.transpile_test import transpile_test
    from ... import transpile

    transpile_test(MetaclassTransformer, 'class A(metaclass=B): pass',
                   'class A(_py_backwards_six_withmetaclass(B)): pass',
                   dependencies=['six'])

    transpile_test(MetaclassTransformer, 'class A(B, metaclass=C): pass',
                   'class A(_py_backwards_six_withmetaclass(C), B): pass',
                   dependencies=['six'])

# Generated at 2022-06-23 22:46:20.607686
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast

# Generated at 2022-06-23 22:46:23.627360
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import assert_source


# Generated at 2022-06-23 22:46:32.557588
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet

    snippet_metaclass = snippet('''
        class A(metaclass=B):
            pass
    ''')

    module = snippet_metaclass.get_body()
    transformer = MetaclassTransformer()
    transformer.visit(module)

    snippet_metaclass = snippet('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

    assert snippet_metaclass.get_body() == module


# Generated at 2022-06-23 22:46:39.800745
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = snippet('''
        from six import with_metaclass as _py_backwards_six_with_metaclass

        class A(_py_backwards_six_with_metaclass(type)):
            pass
    ''')

    module = ast.parse(code)
    module.body[0] = (six_import.get_body())[0]
    module.body[2].bases = class_bases.get_body(metaclass=ast.Name(id="type"),  # type: ignore
                                                bases=ast.List(elts=[]))
    module.body[2].keywords = []

# Generated at 2022-06-23 22:46:42.078915
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    s = """class A(metaclass=B):
    pass
"""
    tree = ast.parse(s)

    a = MetaclassTransformer(True)
    a.visit(tree)

    assert compile(tree, '<string>', 'exec') == compile(six_import + s, '<string>', 'exec')


# Generated at 2022-06-23 22:46:48.274383
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    @snippet
    def before():
        class A(metaclass=B):
            pass

    @snippet
    def after():
        class A(_py_backwards_six_withmetaclass(B)):
            pass

    transformer = MetaclassTransformer()
    assert transformer.apply(before.get_ast()) == after.get_ast()
    assert transformer._tree_changed

# Generated at 2022-06-23 22:46:53.848231
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    s = "class A(metaclass=B, arg1):"
    parsed = ast.parse(s)
    expected = ast.ClassDef(name="A", bases=[ast.Call(func=ast.Name(id="_py_backwards_six_withmetaclass", ctx=ast.Load()),
                                                     args=[ast.Name(id="B", ctx=ast.Load()),
                                                           ast.Name(id="arg1", ctx=ast.Load()),
                                                           ])], keywords=[], body=[], decorator_list=[])

    assert MetaclassTransformer().visit(parsed).body[0] == expected


__all__ = ['MetaclassTransformer']

# Generated at 2022-06-23 22:46:55.332611
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import parse
    from .. import dump


# Generated at 2022-06-23 22:46:57.772396
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_base import BaseTestTransformer

    class MyTestTransformer(BaseTestTransformer):
        transformer = MetaclassTransformer


# Generated at 2022-06-23 22:47:05.446244
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()
    import_node = six_import.get_ast()
    visitor = MetaclassTransformer.visit_ClassDef
    metaclass = ast.Name(id='metaclass')
    bases = [ast.Name(id='B')]

    # Simple class
    node = ast.ClassDef(name='A',
                        bases=bases,
                        keywords=[ast.keyword(arg='metaclass', value=metaclass)])
    node = visitor(transformer, node)
    assert type(node) == ast.ClassDef
    assert node.bases == class_bases.get_ast(metaclass=metaclass, bases=bases)
    assert node.keywords == []
    assert transformer._tree_changed is True

    transformer._tree_changed = False
    #

# Generated at 2022-06-23 22:47:07.816065
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # type: () -> None

    from ..utils import get_ast

    metaclass_transformer = MetaclassTransformer()

# Generated at 2022-06-23 22:47:08.789872
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:47:09.391713
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:47:17.396478
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = '''
            class A(metaclass=B):
                pass
    '''
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    exec(compile(tree, filename="<ast>", mode="exec"))

    # Test that the class A is indeed constructed with the six metaclass
    assert A.__name__ == 'A'
    assert A.__bases__ == (object,)
    assert A.__class__ == six.create_bound_method(six.with_metaclass, type)
    assert issubclass(A, B)

# Generated at 2022-06-23 22:47:26.482388
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source
    from ..utils.compare_asts import compare_asts
    from ..visitor import BackportVisitor

    source = source('''
    class A(metaclass=MyMeta):
        pass
    ''')

    tree = BackportVisitor.parse(source=source)
    transformer = MetaclassTransformer()
    tree = transformer.visit(tree)

    result = (
        'def _py_backwards_six_withmetaclass(metaclass, *bases):\n'
        '    return metaclass(str(\'NewBase\'), bases, {})\n'
        'class A(_py_backwards_six_withmetaclass(MyMeta)):\n'
        '    pass\n'
    )

    assert compare_asts(tree, result)

# Generated at 2022-06-23 22:47:32.694988
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast27 as ast
    transformer = MetaclassTransformer()
    module = ast.parse('class A(metaclass=B): pass')
    module = transformer.visit(module)
    assert ast.dump(module) == \
        "Module(body=[ImportFrom(module='six',names=[alias(name='with_metaclass',asname='_py_backwards_six_withmetaclass')],level=0),ClassDef(name='A',bases=[_py_backwards_six_withmetaclass(_B__,())],body=[],decorator_list=[])])"

# Generated at 2022-06-23 22:47:39.022587
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .six import six_transform

    class test_MetaclassTransformer_visit_ClassDef(six_transform.MetaclassTransformer):
        def __init__(self):
            self.node = None

        def visit(self, node):
            assert node == self.node
            return super().visit(node)

        def generic_visit(self, node):
            assert node == self.node
            return node

    node = ast.parse('class X(metaclass=B, c=B): pass')
    metaclass_transform = test_MetaclassTransformer_visit_ClassDef()

    class_node = node.body[0]
    metaclass_transform.node = class_node
    assert metaclass_transform.visit(class_node) == class_node
    class_node.key