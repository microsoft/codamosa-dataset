

# Generated at 2022-06-23 22:37:35.316914
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ast import parse
    from . import unparse
    from ..utils import parse_file
    from .. import settings
    from typing import List

    settings.backport_target = (2, 7)

    module = parse(dedent("""
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(metaclass=B):
            pass
    """))  # type: ast.Module
    dunder_all = [item.name for item in module.body if isinstance(item, ast.Assign)]  # type: List[str]
    dunder_all.append('six')
    assert '_py_backwards_six_withmetaclass' not in dunder_all
    module = MetaclassTransformer().visit(module)
    assert module is not None
   

# Generated at 2022-06-23 22:37:35.818179
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:37:43.751656
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class TestMetaclassTransformerVisitorClassDef(MetaclassTransformer):
        def __init__(self):
            self.generic_visit = lambda node: node


    class DummyClassDef(ast.ClassDef):
        def __init__(self, metaclass: ast.object):
            self.keywords = [
                ast.keyword(arg='metaclass',
                            value=metaclass)
            ]
            self.bases = [
                ast.Name(id='testbase',
                         ctx=ast.Load())
            ]


    def DummyMetaclass(name: str) -> ast.object:
        return ast.Name(id=name,
                        ctx=ast.Load())



# Generated at 2022-06-23 22:37:53.448714
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import textwrap
    from typed_ast import ast3 as ast
    from ..utils.tests import assert_transformed_code_equals

    code = textwrap.dedent('''
    class A(metaclass=B):
        pass
    ''')
    expected = textwrap.dedent('''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    ''')

    tree = ast.parse(code)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert_transformed_code_equals(expected, tree)

# Generated at 2022-06-23 22:37:56.182856
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    t = MetaclassTransformer()
    assert t.visit(parse('class A(metaclass=B): pass')) == parse('class A(_py_backwards_six_withmetaclass(B)): pass')

# Generated at 2022-06-23 22:38:07.091679
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer.cons(
        ast.parse('1 + 1')
    ).code == '1 + 1'

    assert MetaclassTransformer.cons(
        ast.parse('class A: pass')
    ).code == 'class A:\n    pass'


# Generated at 2022-06-23 22:38:17.260978
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import textwrap, astor
    with open("tests/data/MetaclassTransformer/test_MetaclassTransformer.py") as f:
        text = f.read()
    text = textwrap.dedent(text)
    expected_ast = astor.code_to_ast.parse_file("tests/data/MetaclassTransformer/test_MetaclassTransformer.py")
    expected_str = astor.to_source(expected_ast, indent_with=' '*4)

    new_ast = astor.code_to_ast.parse_string(text)
    new_ast = MetaclassTransformer().visit(new_ast)
    new_str = astor.to_source(new_ast, indent_with=' '*4)
    print(new_str)

# Generated at 2022-06-23 22:38:23.558529
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer(source_version=(2, 7), target_version=(2, 6))
    source = "class A(metaclass=B):\n    pass\n"
    expected = "from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass\n"

    node = ast.parse(source)
    node = transformer.visit(node)
    result = astor.to_source(node)
    assert result == expected

# Generated at 2022-06-23 22:38:25.139928
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.codegen import to_source
    from .fake import FakeContext


# Generated at 2022-06-23 22:38:30.569346
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_nodes as stn
    from ..utils.source import source_to_code as stc
    from ..utils.tree import node_to_str


# Generated at 2022-06-23 22:38:40.711233
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module_content = ast.parse("""class Hello(metaclass=int): pass""")
    transformed_module = MetaclassTransformer().visit_Module(module_content)
    # check that six import has been added
    assert transformed_module.body[0] == six_import.get_body()
    # check that original class has been transformed
    class_def = transformed_module.body[1]
    assert isinstance(class_def, ast.ClassDef)
    assert class_def.bases[0] == class_bases.get_body(metaclass=ast.Num(n=int('int')), bases=[])

test_MetaclassTransformer_visit_Module()

# Generated at 2022-06-23 22:38:42.645082
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:38:47.661635
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    expected = """
    import sys
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    class A(metaclass=type):
        pass
    """
    node = ast.parse(expected)
    node = MetaclassTransformer().visit(node)
    assert astor.to_source(node) == expected



# Generated at 2022-06-23 22:38:56.182217
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .test_utils import make_test_function
    from .test_utils import make_test_class
    from .. import run_transformer
    from ..utils import safe_mkdir

    test_folder = 'test_output/metaclass_transformer'
    safe_mkdir(test_folder)

    test_func_ok = make_test_function('''
        def test(x):
            "Docstring"
            return x*2
    ''')

    test_func_ko = make_test_function('''
        def test(x):
            "Docstring"
            return x*2
    ''', expected_error=False)


# Generated at 2022-06-23 22:38:59.678681
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import sys
    import ast as _ast
    import astunparse as _astunparse
    if sys.version_info < (3, 0):
        import __future__
        sys.modules["__future__"] = __future__
        import six
        sys.modules["six"] = six


# Generated at 2022-06-23 22:39:03.039874
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    metaclass_transformer = MetaclassTransformer()
    assert hasattr(metaclass_transformer, 'visit_ClassDef')
    assert hasattr(metaclass_transformer, 'visit_Module')

# Generated at 2022-06-23 22:39:06.612495
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class_def = ast.parse('''
        class A(metaclass=B):
            pass
        ''')
    case = MetaclassTransformer()
    case.visit(class_def)
    assert case._tree_changed

# Generated at 2022-06-23 22:39:14.378634
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """
    Test case -  visit_Module of class MetaclassTransformer.
    """
    test_object = MetaclassTransformer()
    node = ast.parse("class A(metaclass=B):\n\tpass")  # type: ignore
    actual = test_object.visit_Module(node)

# Generated at 2022-06-23 22:39:22.321377
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Given
    class_def = ast.ClassDef(name='A', 
                             bases=[], 
                             keywords=[ast.keyword(arg='metaclass', 
                                                   value=ast.Name(id='B', 
                                                                  ctx=ast.Load()))], 
                             body=[], 
                             decorator_list=[])
    module = ast.Module(body=[class_def])

    # When
    MetaclassTransformer().visit(module)

    # Then
    assert module.body[0].name == 'A'
    assert len(module.body) == 2


# Generated at 2022-06-23 22:39:27.982249
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six
    import typed_astunparse
    import astor
    from ..test_utils import _get_node, get_node

    node = _get_node('class A(metaclass=B): pass')
    transformer = MetaclassTransformer(print_changes=True)
    transformer.visit(node)

# Generated at 2022-06-23 22:39:38.273190
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class EmptyClass:
        pass

    class EmptyMetaClass:
        pass

    class EmptyBase1:
        pass

    class EmptyBase2:
        pass

    class MetaClass(EmptyMetaClass):
        pass

    class Base1(EmptyBase1):
        pass

    class Base2(EmptyBase2):
        pass

    class Class(metaclass=MetaClass, base=Base1):
        pass

    class ClassWithInheritance(Base1, Base2, metaclass=MetaClass):
        pass

    class ClassWithoutMetaclass(base=Base1):
        pass

    class ClassWithoutKeywords:
        pass

    class ClassWithoutBases:
        pass

    class ClassWithBases(Base1, Base2):
        pass


# Generated at 2022-06-23 22:39:41.946372
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.ClassDef(
        name='Spam',
        bases=[
            ast.Name(
                id='Foo',
            ),
        ],
        keywords=[],
        body=[],
    )
    result = MetaclassTransformer().visit_ClassDef(node)
    assert type(result) == ast.ClassDef

# Generated at 2022-06-23 22:39:51.972360
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    class TestTransformer(MetaclassTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return super().visit_ClassDef(node)

    m = ast.parse('class A(B): pass')
    node = m.body[0]
    transformer = TestTransformer()
    transformer.visit(m)
    assert transformer._tree_changed
    assert node.bases == ast.List(
        elts=[ast.Call(func=ast.Name(id='_py_backwards_six_withmetaclass', ctx=ast.Load()),
                        args=[ast.Name(id='B', ctx=ast.Load())],
                        keywords=[])],
        ctx=ast.Load()
    )




# Generated at 2022-06-23 22:39:55.272210
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    from ..utils.ast_helpers import dump_ast

    class Foo(metaclass=type):
        pass

    module_node = ast.parse(inspect.getsource(Foo))
    assert dump_ast(module_node) == dump_ast(MetaclassTransformer().visit(module_node))

# Generated at 2022-06-23 22:40:01.887601
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.snippet import code_equal
    from ..transformer import Transformer

    code = """
        class A:
            def __init__(self, x):
                self.x = x
                return self
    """
    tree = source.get_ast(code)
    transformer = Transformer()
    transformer.visit(tree)
    assert not transformer.tree_changed
    assert code_equal(source.to_source(tree), code)

    code = """
        class A(metaclass=B):
            def __init__(self, x):
                self.x = x
                return self
    """
    tree = source.get_ast(code)
    transformer = Transformer()
    transformer.visit(tree)
    assert transformer.tree_changed

# Generated at 2022-06-23 22:40:03.426235
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()

# Generated at 2022-06-23 22:40:05.164747
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..visitor import wrap_visitor

# Generated at 2022-06-23 22:40:15.156541
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing.runner import test_ast
    from ..testing.visitor import assert_tree_contents

    class_bases_ast = ast.parse('''
    class Base(object):
        pass
    
    class Subclass(_py_backwards_six_withmetaclass(B, *(Base,))):
        pass
    ''')
    assert_tree_contents(class_bases_ast, class_bases.get_body(metaclass=ast.Name(id='B', ctx=ast.Load()),
                                                        bases=ast.Tuple(elts=[ast.Name(id='Base', ctx=ast.Load())],
                                                            ctx=ast.Load())))


# Generated at 2022-06-23 22:40:18.351623
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast
    from ..convert import to_source

    ast_module = MetaclassTransformer.run_pipeline('''
        class A(object, metaclass=B):
            pass
    ''')

# Generated at 2022-06-23 22:40:23.898888
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import from_version

    module = from_version((3, 4), examples.metaclass)
    module_transformed = from_version(MetaclassTransformer.target, module)
    assert module.body[0] == six_import.get_tree()
    assert module.body[1].keywords[0].value == ast.Name(id='B')
    assert module.body[2].keywords[0].value == ast.Name(id='B')
    assert module == module_transformed

# Generated at 2022-06-23 22:40:25.240395
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typing
    import astunparse

# Generated at 2022-06-23 22:40:27.874758
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    x = MetaclassTransformer()
    assert x.target_version == (2, 7)
    assert issubclass(x.__class__, BaseNodeTransformer)

# Generated at 2022-06-23 22:40:35.513250
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3 as ast
    metaclassTransformer = MetaclassTransformer()
    ast_node = ast.ClassDef(name='A',
            bases=[],
            keywords=[],
            body=[],
            decorator_list=[]
        )
    metaclassTransformer.visit(ast_node)
    assert len(metaclassTransformer._visit_log) == 1
    assert metaclassTransformer._visit_log[0] == (ast.ClassDef, ast_node)


# Generated at 2022-06-23 22:40:36.625301
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:40:37.247006
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:40:40.258205
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..transforms.six import six_import, class_bases
    from pprint import pprint
    from astunparse import unparse

    # The source code to translate

# Generated at 2022-06-23 22:40:47.928249
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typing import List, Union
    from typed_ast import ast3 as ast
    from ..utils.compiler import compile_function
    from ..utils.snippet import snippet
    from ..utils.tree import find_all

    transformer = MetaclassTransformer()
    code = snippet.load('metaclass_transformer.py').get_body()
    tree = ast.parse(code)
    transformer.visit(tree)

    node = find_all(tree, type=ast.ClassDef)[0]
    assert node.bases[0].func.func.id == '_py_backwards_six_withmetaclass'

    func = compile_function(tree, 'MyClass')
    A = func()
    assert A.__mro__ == (A, object)
    assert A.__class__ == A

# Generated at 2022-06-23 22:40:50.856454
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse(
        "class A(metaclass=B): pass")
    __tracebackhide__ = True
    assert module == MetaclassTransformer().visit(module)



# Generated at 2022-06-23 22:40:57.350666
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

    test_code = "class A(metaclass=B): pass"
    expected_result = "from six import with_metaclass as _py_backwards_six_withmetaclass; class A(_py_backwards_six_withmetaclass(B)): pass"

    module = ast.parse(test_code)
    class_def = module.body[0]

    MetaclassTransformer().visit(module)
    assert astor.to_source(module) == expected_result
    assert isinstance(class_def.bases[0], ast.Call)

# Generated at 2022-06-23 22:41:02.286938
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert (ast.parse(six_import.source),
            ast.parse(class_bases.source)) == MetaclassTransformer._code_snippets


if __name__ == '__main__':
    import pytest;
    pytest.main([__file__, '-v'])

# Generated at 2022-06-23 22:41:09.788458
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from six import with_metaclass as _py_backwards_six_withmetaclass
    import ast
    node = ast.parse('class A(metaclass=B): pass\n')
    want = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    assert MetaclassTransformer(ast.parse(want)).visit(node) == \
        ast.parse(want)


# Generated at 2022-06-23 22:41:19.722739
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..tokenize_test import tokenize_class
    from .test_base import BaseNodeTest
    from typing import Any, List

    class Test(BaseNodeTest):
        target = MetaclassTransformer.target
        transformer = MetaclassTransformer

        # noinspection PyPep8Naming
        @staticmethod
        def get_tree(code: str) -> ast.AST:
            return tokenize_class(code).body[0]

        @staticmethod
        def get_expected(code: str) -> ast.AST:
            from six import with_metaclass
            try:
                expected_tree = compile(code.replace('(metaclass=', '('), '', 'single')
            except SyntaxError:
                return  # ignore this test case
            else:
                expected_tree = ast.fix_missing

# Generated at 2022-06-23 22:41:25.786183
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    inp = "class A(object, metaclass = type): pass"
    t = ast.parse(inp)
    m = MetaclassTransformer()
    m.visit(t)
    assert m._tree_changed
    assert ast.dump(t) == "Module(body=[ClassDef(name='A', bases=[_py_backwards_six_withmetaclass(type, object)], keywords=[], body=[Pass()], decorator_list=[])])"


# Generated at 2022-06-23 22:41:29.143421
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """ Tests the constructor of the class MetaclassTransformer """
    obj = MetaclassTransformer()
    assert obj.target == (2, 7)
    assert obj.dependencies == ['six']

# Generated at 2022-06-23 22:41:33.821351
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast.parse('class A(object, metaclass=B, foo=bar): pass')
    expected = ast.parse('class A(_py_backwards_six_withmetaclass(B, object)): pass')
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert tree == expected

# Generated at 2022-06-23 22:41:43.740728
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import unittest
    from ...utils.snippet import snippet  # type: ignore

    transformer = MetaclassTransformer()

    def transform(code, bare=False):
        tree = ast.parse(code)
        if not bare:
            transformer.transform(tree)
        return compile(tree, '<string>', 'exec')

    with snippet(six_import, class_bases):
        code = """
            class A(metaclass=B):
                pass
        """
        expected = """
            class A(_py_backwards_six_with_metaclass(B)):
                pass
        """
        assert eval(transform(code)) == eval(expected)

        eval(transform('class A: pass'))


# Generated at 2022-06-23 22:41:46.831156
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    mt = MetaclassTransformer({})
    node = ast.parse('class A(metaclass=B):\n    pass')  # type: ast.Module

# Generated at 2022-06-23 22:41:48.300413
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import six
    import astor

# Generated at 2022-06-23 22:41:55.911058
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # When a class is defined with a given metaclass
    class A(metaclass=type):
        pass
    node = ast.parse(inspect.getsource(A))
    # We use the MetaclassTransformer
    actual = MetaclassTransformer().visit(node)
    # And check that it produces the expected result
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(type, )):
        pass
    """
    assert ast.dump(actual) == expected



# Generated at 2022-06-23 22:42:03.409615
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from py_backwards.transformers.six_with_metaclass import MetaclassTransformer
    node = ast.Module(body=[ast.ClassDef(name='A',
                                         bases=[ast.Name(id='object', ctx=ast.Load())],
                                         body=[],
                                         decorator_list=[],
                                         keywords=[ast.keyword(arg='metaclass',
                                                               value=ast.Name(id='B', ctx=ast.Load()))])])

# Generated at 2022-06-23 22:42:11.373092
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import transform_snippet, compare_ast
    from six import with_metaclass
    snippet = """
    class A(metaclass=B):
        pass
    """

    comparison = """
    from six import with_metaclass as _py_backwards_six_with_metaclass
    class A(_py_backwards_six_with_metaclass(B)):
        pass
    """
    result = transform_snippet(snippet, MetaclassTransformer)
    compare_ast(result, comparison)



# Generated at 2022-06-23 22:42:13.631149
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast
    from typed_ast import util
    from astunparse import unparse

# Generated at 2022-06-23 22:42:14.683734
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor


# Generated at 2022-06-23 22:42:24.101328
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class Module(ast.Module):
        def __init__(self, body: ast.stmt) -> None:
            self.body = body

    class ClassDef(ast.ClassDef):
        def __init__(self, name: str, bases: ast.List) -> None:
            self.name = name
            self.keywords = None
            self.bases = bases
            self.body = []

    class List(ast.List):
        def __init__(self, elts: ast.expr) -> None:
            self.elts = elts

    class Name(ast.Name):
        def __init__(self, id: str) -> None:
            self.id = id

    class Str(ast.Str):
        def __init__(self, s: str) -> None:
            self.s = s



# Generated at 2022-06-23 22:42:34.473348
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    context = Context(options=dict(target=(2, 7)),
                      tree=ast.parse('class A(): pass'))
    transformer = MetaclassTransformer(context=context)
    # No change
    assert transformer.tree == ast.parse('class A(): pass')

    context = Context(options=dict(target=(2, 7)),
                      tree=ast.parse('class A(metaclass=B): pass'))
    transformer = MetaclassTransformer(context=context)
    expected = ast.parse(
        textwrap.dedent('''
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A(_py_backwards_six_withmetaclass(B)):
                pass'''))
    assert transformer.tree == expected


# Generated at 2022-06-23 22:42:42.843984
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six
    assert six.with_metaclass
    source = '''class A:
        __metaclass__ = X
    '''
    expected = '''class A(_py_backwards_six_withmetaclass(X)):
        pass
    '''
    tree = ast.parse(source)
    assert compile(tree, '<test>', 'exec')
    transf = MetaclassTransformer()
    transf.visit(tree)
    assert compile(transf.tree, '<test>', 'exec')
    assert expected == transf.get_string_value()



# Generated at 2022-06-23 22:42:50.257956
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import random
    import textwrap

    snippet_code = textwrap.dedent(six_import.code)
    snippet_code += textwrap.dedent(class_bases.code)

    metaclass_names = [f'MetaClass{i}' for i in range(10)]
    class_names = [f'Class{i}' for i in range(10)]

    for _ in range(10):
        for class_name in class_names:
            for metaclass_name in metaclass_names:
                code = f'class {class_name}(metaclass={metaclass_name}): pass'
                class_bases_class_code = textwrap.dedent(class_bases.code)

# Generated at 2022-06-23 22:42:52.478135
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import compile
    nodes = compile("class C(metaclass=object): pass", '<test>')
    assert isinstance(nodes[0].body[0], ast.ClassDef)


# Generated at 2022-06-23 22:43:01.226645
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class TestMetaclassTransformer_visit_Module(unittest.TestCase):
        def test_simple(self):
            sources = ["class A(): pass"]
            expected = ["from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(): pass"]
            self.assertCodeEqual(sources, expected)

    # Code to run the unit test
    suite = unittest.TestLoader().loadTestsFromTestCase(TestMetaclassTransformer_visit_Module)
    runtime = unittest.TextTestRunner(verbosity=2).run(suite)
    if runtime.errors or runtime.failures:
        sys.exit(1)


# Generated at 2022-06-23 22:43:11.395976
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(metaclass=B):
            pass
    
    ''')
    assert len(list(module.body)) == 2
    _import, classdef = module.body
    assert isinstance(classdef, ast.ClassDef)
    assert len(classdef.bases) == 1
    assert isinstance(classdef.bases[0], ast.Call)
    assert len(classdef.bases[0].args) == 2

    assert MetaclassTransformer.has_changes(module)
    module = MetaclassTransformer.transform(module)
    assert len(list(module.body)) == 2
    _import, classdef = module.body

# Generated at 2022-06-23 22:43:18.873941
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast
    source = """\
            a = 'hello'
            class A(metaclass=A):
                '''A docstring'''
                def __init__(self, x):
                    self.x = x
            """
    tree = ast.parse(source)

# Generated at 2022-06-23 22:43:20.135702
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # TODO: implement
    raise Exception("Not implemented")


# Generated at 2022-06-23 22:43:21.391005
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import typed_astunparse

# Generated at 2022-06-23 22:43:25.624184
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    test_code = '''
    class A(metaclass=B):
        pass
    '''
    expected_code = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    assert expected_code == MetaclassTransformer.run_on_code(test_code)

# Generated at 2022-06-23 22:43:32.927787
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typing import cast
    s = '''class A(metaclass=B):
    pass'''
    tree = ast.parse(s)
    MetaclassTransformer().visit(tree)
    assert isinstance(tree.body[0].bases[0], ast.Call)
    assert tree.body[0].bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert cast(ast.Call, tree.body[0].bases[0]).args[0].id == 'B'

# Generated at 2022-06-23 22:43:42.393558
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # type: () -> None
    import ast

    class_def = ast.ClassDef(name='A',
                             bases=[],
                             keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
                             body=[])

    # class A(metaclass=B):
    #    pass

# Generated at 2022-06-23 22:43:44.663100
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import inspect
    assert inspect.isclass(MetaclassTransformer)


# Generated at 2022-06-23 22:43:54.538646
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    astor.set_writer(writer=astor.CodeWriter())

    # 2.7 supports metaclasses, but not keyword arguments for class definition
    # so transform should not occur
    assert astor.to_source(MetaclassTransformer().visit(
        ast.parse('''
        class A(metaclass=B):
            pass'''))) == '''
        class A(metaclass=B):
            pass'''

    # 3.6 does support keyword arguments for class definition

# Generated at 2022-06-23 22:44:04.964361
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    "MetaclassTransformer.visit_Module: Adds six import at the beginning"
    import ast
    import io
    
    from py_backwards.transformers.metaclass import MetaclassTransformer
    from py_backwards.utils.ast_builder import build_ast
    from py_backwards.utils.misc import run_source_code

    source = r'''
            
            class C(metaclass=type):
                pass
            
            def f():
                return 3
            
            '''

    expected = r'''
            from six import with_metaclass as _py_backwards_six_with_metaclass
            
            class C(_py_backwards_six_with_metaclass(type)):
                pass
            
            def f():
                return 3
            
            '''



# Generated at 2022-06-23 22:44:05.408611
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:44:12.113468
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.ClassDef(name='A',
                        bases=[ast.Name(id='object')],
                        keywords=[ast.keyword(arg='metaclass',
                                              value=ast.Name(id='B'))],
                        body=[])
    transformer = MetaclassTransformer()
    node = transformer.visit(node)  # type: ignore
    assert transformer._tree_changed is True
    assert isinstance(node, ast.ClassDef)
    assert isinstance(node.bases[0], ast.Call)
    assert len(node.keywords) == 0



# Generated at 2022-06-23 22:44:12.757431
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import compile


# Generated at 2022-06-23 22:44:18.190694
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..test_tools import assert_compiled

    assert_compiled(
        """
        class Foo(metaclass=Bar, x=None):
            pass
        """,
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class Foo(_py_backwards_six_withmetaclass(Bar, *[])):
            pass
        """
    )

# Generated at 2022-06-23 22:44:23.547294
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.testutil import run_transformer

    result = run_transformer(MetaclassTransformer, """
    class MyList(metaclass=type):
        pass
    """)
    assert result == """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class MyList(_py_backwards_six_withmetaclass(type)):
        pass
    """

# Generated at 2022-06-23 22:44:32.887937
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import textwrap
    from ..utils.test_utils import assert_equals
    from typed_ast import ast3 as ast

    # create AST from snippet
    source = textwrap.dedent("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(metaclass=object):pass
    """)
    tree = ast.parse(source)

    # transform AST
    t = MetaclassTransformer()
    t.visit(tree)

    # compile and test
    code = compile(tree, "<ast>", "exec")
    assert_equals(code.co_names, ('_py_backwards_six_withmetaclass',))



# Generated at 2022-06-23 22:44:41.580860
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

    class Module(ast.Module):
        _fields = ['body']

        def __init__(self, *args, **kwargs):
            for field, value in zip(self._fields, args):
                setattr(self, field, value)

    class ClassDef(ast.ClassDef):
        _fields = ['name', 'bases', 'keywords', 'body', 'decorator_list']

        def __init__(self, *args, **kwargs):
            for field, value in zip(self._fields, args):
                setattr(self, field, value)

    class Assign(ast.Assign):
        _fields = ['targets', 'value']


# Generated at 2022-06-23 22:44:42.413433
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:44:48.052863
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..btconfig import source_encoding
    from ..port_ast import parse

    def transform(source):
        tree = parse(source)
        transformer = MetaclassTransformer()
        transformer.visit(tree)
        return tree

    # simple test
    source = 'class A(metaclass=B, object): pass'
    tree = transform(source)
    assert_equal(tree.body[0].bases[0].func.id, '_py_backwards_six_withmetaclass')


# Generated at 2022-06-23 22:44:57.473193
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..backports.typing_inspect import get_args
    from ..backports.typing_inspect import get_origin
    import inspect

    class A(metaclass=type):
        pass


    snippet_A = 'class A(metaclass=type):\n    pass'
    visitor = MetaclassTransformer(target=MetaclassTransformer.target)
    visitor.visit(ast.parse(snippet_A))
    A_visitor = ast.parse(astor.to_source(visitor.tree)).body[0]
    assert A_visitor.name == 'A'
    assert A_visitor.bases[0].func.attr == '_py_backwards_six_with_metaclass'
    assert A_visitor.bases[0].args

# Generated at 2022-06-23 22:45:06.026000
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    t = MetaclassTransformer()
    node = ast.parse('class A(metaclass=B):\n  pass')
    t.visit(node)
    assert ast.dump(node) == "Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_with_metaclass')], level=0), ClassDef(name='A', bases=[Call(func=Name(id='_py_backwards_six_with_metaclass', ctx=Load()), args=[Name(id='B', ctx=Load())], keywords=[])], body=[], decorator_list=[])])"

# Generated at 2022-06-23 22:45:15.396461
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ....testing import assert_code_equal

    def _expect_node(**kwargs):
        return ast.parse(
            "import six\n"
            + kwargs['node'].strip(),
            '<string>', 'exec'
        ).body[0]

    node = ast.parse('from .utils import x')
    assert_code_equal(
        MetaclassTransformer().visit(node),
        _expect_node(node='''from .utils import x''')
    )

    node = ast.parse('from six import y')
    assert_code_equal(
        MetaclassTransformer().visit(node),
        _expect_node(node='''from six import y''')
    )



# Generated at 2022-06-23 22:45:20.779105
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import compare_ast

    node = ast.parse("class A(object, metaclass=B): pass")
    obj = MetaclassTransformer()
    result = obj.visit(node)
    compare_ast(result, "class A(_py_backwards_six_with_metaclass(B)): pass")
    assert obj._tree_changed is True

# Generated at 2022-06-23 22:45:26.140267
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """class A(metaclass = B, metaclass2 = C):
    pass
"""
    expected = """class A(_py_backwards_six_with_metaclass(B)):
    pass
"""
    tree = ast.parse(code)
    MetaclassTransformer().visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-23 22:45:28.312456
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    metaclass_transformer = MetaclassTransformer()
    assert isinstance(metaclass_transformer, BaseNodeTransformer)


snippet()

# Generated at 2022-06-23 22:45:29.937436
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    from .base import BaseNodeTransformer
    

# Generated at 2022-06-23 22:45:33.256034
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..codegen import CodeGen

    input = '''class A(metaclass=B): pass'''

# Generated at 2022-06-23 22:45:34.870696
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import os
    import astor

    # (2, 7)

# Generated at 2022-06-23 22:45:41.651088
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    code = 'class A(metaclass=B):\n    pass'
    expected = 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass'
    tree = ast.parse(code)
    new_tree = MetaclassTransformer().visit(tree)
    new_code = astor.to_source(new_tree)
    assert new_code == expected

# Generated at 2022-06-23 22:45:43.502647
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = 'class A(metaclass=B): pass'
    expected = six_import.get_source() + '\n' + source
    assert MetaclassTransformer(source).output == expected



# Generated at 2022-06-23 22:45:50.040176
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    class MetaclassTransformerTestCase(unittest.TestCase):
        def test_visit_ClassDef(self):
            code = '''class A(metaclass=B):\n    pass'''
            expected_code = '''from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass'''
            tree = ast.parse(code)
            node = MetaclassTransformer.run(tree)
            code = astor.to_source(node)
            self.assertEqual(code, expected_code)

# Generated at 2022-06-23 22:45:56.356201
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import assert_string_output
    from ..testing import make_example_code
    from ..testing import mutate_code

    source = make_example_code('''
    class A(metaclass=B):
        pass
    ''')

    with assert_string_output(mutate_code(source, MetaclassTransformer)) as output:
        class A(_py_backwards_six_with_metaclass(B)):
            pass

# Generated at 2022-06-23 22:46:00.437322
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    test_node = ast.Module(body=[ast.ClassDef(
        name="Foo",
        bases=[ast.Name(id="A")],
        keywords=[ast.keyword(
            arg="metaclass",
            value=ast.Name(id="B"))],
        body=[])])
    expected_node = ast.Module(body=six_import.get_body() + [ast.ClassDef(
        name="Foo",
        bases=class_bases.get_body(metaclass=ast.Name(id="B"),  # type: ignore
                                   bases=ast.List(elts=[ast.Name(id="A")])),
        keywords=[],
        body=[])])
    assert MetaclassTransformer.visit(test_node) == expected_node


# Generated at 2022-06-23 22:46:05.743244
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typing import cast
    from .test_utils import assert_source_equal

    module = ast.parse('import six\nclass A(metaclass=B): pass')
    module = cast(ast.Module, MetaclassTransformer().visit(module))

# Generated at 2022-06-23 22:46:08.340802
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    
    node = ast.Module(body=[])
    result = MetaclassTransformer.visit_Module(MetaclassTransformer(), node)
    assert result.body == six_import.get_body()



# Generated at 2022-06-23 22:46:14.474587
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Setup
    node = ast.parse('')
    obj = MetaclassTransformer(2, 7)
    # Exercise
    actual = obj.visit_Module(node)
    # Verify
    assert len(actual.body) == 2
    assert isinstance(actual.body[1], ast.Expr)
    assert actual.body[1].value.s == 'six'

# Generated at 2022-06-23 22:46:24.131907
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import warnings
    warnings.simplefilter('error', category=SyntaxWarning)
    from typing import Optional, TypeVar
    from ..utils.syntax import SyntaxError
    from ..utils.snippet import from_string
    from .base import BaseNodeTransformer
    from .six import SixTransformer

    T = TypeVar('T', bound=BaseNodeTransformer)

    # _py_backwards_six_withmetaclass is already imported
    with pytest.warns(SyntaxWarning):
        SixTransformer().transform(from_string(r'''
            class A(metaclass=object):
                pass

        ''')) == from_string(r'''
            class A(_py_backwards_six_withmetaclass(object)):
                pass

        ''')


# Generated at 2022-06-23 22:46:33.978712
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """It should transform the given module."""
    f_name = 'test_MetaclassTransformer_visit_Module'
    md = ast.Module()
    md.body = [
        ast.ClassDef(
            name='Mocked',
            bases=[],
            keywords=[
                ast.keyword(arg='metaclass', value=ast.Name(id='Mocked', ctx=ast.Load()))
            ],
            body=[],
            decorator_list=[])
    ]

    expect_md = ast.Module()

# Generated at 2022-06-23 22:46:42.533779
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from . import check_transformed_ast

    check_transformed_ast(
        MetaclassTransformer,
        'class A(metaclass=B):\n    pass',
        {
            'version': (3, 5),
            'dependencies': ['six'],
            'source': (
                'from six import with_metaclass as _py_backwards_six_withmetaclass\n'
                '\n'
                '\n'
                'class A(_py_backwards_six_withmetaclass(B)):\n    pass'
            )
        }
    )


# Generated at 2022-06-23 22:46:43.192719
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:46:47.706137
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    assert snippet(MetaclassTransformer().visit_Module(ast.parse('class A: pass'))) == \
            """
            from six import with_metaclass as _py_backwards_six_withmetaclass


            class A:
                pass
            """


# Generated at 2022-06-23 22:46:50.993776
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert_equal(MetaclassTransformer().visit(ast.parse('class A: pass')), ast.parse('class A: pass'))

# Generated at 2022-06-23 22:46:53.564952
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..transform_test_support import run_transform_test

    run_transform_test(MetaclassTransformer,
                       'class A(metaclass=B):\n    pass')

# Generated at 2022-06-23 22:46:55.459476
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Setup
    class X:
        pass

    # Exercise

# Generated at 2022-06-23 22:46:56.723255
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:47:02.397862
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast
    assert MetaclassTransformer.dependencies == ['six']
    assert MetaclassTransformer.target == (2, 7)
    assert MetaclassTransformer.get_node_class() == ast.ClassDef
    assert MetaclassTransformer.visit_Module.__name__ \
           == 'visit_Module'
    assert MetaclassTransformer.visit_ClassDef.__name__ \
           == 'visit_ClassDef'

# Generated at 2022-06-23 22:47:10.367309
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # type: () -> None
    """Test the method visit_ClassDef of class MetaclassTransformer."""
    msg = 'The method visit_ClassDef of the class MetaclassTransformer ' \
          'produces incorrect ast.'
    code = 'class A(metaclass=B): pass'
    expected_output = 'class A(_py_backwards_six_withmetaclass(B)): pass'

    node = ast.parse(code)
    MetaclassTransformer().visit(node)
    assert astor.to_source(node) == expected_output, msg

# Generated at 2022-06-23 22:47:16.096607
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import roundtrip_unparse
    from ..utils.sample_files import get_source

    src = get_source(__file__)
    tree = roundtrip_unparse(ast.parse(src))

    rv = MetaclassTransformer().visit(tree)
    assert str(rv) == src


# Generated at 2022-06-23 22:47:17.280272
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    # Case 1: no metaclass

# Generated at 2022-06-23 22:47:18.133705
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-23 22:47:25.336213
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    _code = '''
    class A(metaclass=int):
        pass
    '''
    _target = dedent('''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(int)):
        pass
    ''')
    _tree = ast.parse(_code)
    _transformer = MetaclassTransformer()
    _transformer.visit(_tree)
    assert ast.dump(_tree).strip() == _target.strip()
    
    
    
    
    

# Generated at 2022-06-23 22:47:31.183761
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
        class Test(metaclass=abc.ABCMeta):
            pass
    """
    tree = ast.parse(code)
    transformer = MetaclassTransformer()
    result = transformer.visit(tree)
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class Test(_py_backwards_six_withmetaclass(abc.ABCMeta)):
            pass
    """

    transformer.add_import(expected)
    assert astunparse.unparse(result) == expected