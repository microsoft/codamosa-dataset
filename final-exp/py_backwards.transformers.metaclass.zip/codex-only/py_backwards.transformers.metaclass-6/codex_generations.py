

# Generated at 2022-06-23 22:37:29.120596
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = """class A(metaclass=B):\n  pass"""
    expected = """class A(_py_backwards_six_withmetaclass(B)):\n    pass"""

    program = ast.parse(source)
    t = MetaclassTransformer()
    t.visit(program)

    assert_ast_equal(ast.parse(expected), program)

# Generated at 2022-06-23 22:37:36.816391
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from six import with_metaclass
    case = ast.parse("class A(B, C, metaclass=X):\n    pass")
    expected = ast.parse("class A(with_metaclass(X, B, C)):\n    pass")
    MetaclassTransformer(case).visit(case)
    if case != expected:
        print("\nGot:")
        print(ast.dump(case))
        print("\nExpected:")
        print(ast.dump(expected))
    assert expected == case


# Generated at 2022-06-23 22:37:42.620741
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..pytree import Node

    tree = """
    class A(metaclass=B):
        pass

    class C:
        pass
    """
    res = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass

    class C:
        pass
    """
    res_tree = Node.from_str(res)
    MetaclassTransformer.visit(Node.from_str(tree))
    assert res_tree == tree

# Generated at 2022-06-23 22:37:44.473921
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3
    from ..utils.tree import tree_to_str


# Generated at 2022-06-23 22:37:55.196020
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("class Foo(object): pass")
    actual = MetaclassTransformer().visit(node)


# Generated at 2022-06-23 22:37:57.199459
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .transformer_utils import AssertEqualTransformer

# Generated at 2022-06-23 22:37:58.362727
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:38:08.583105
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = 'class MyClass(metaclass=MyMeta, another=MyOther): pass'
    tree = ast.parse(code)
    transformer = MetaclassTransformer()
    expected = ast.ClassDef(
        name='MyClass',
        bases=ast.Call(
            args=[
                ast.Name(id='MyMeta'),
                ast.Name(id='MyOther')
            ],
            func=ast.Attribute(
                value=ast.Name(id='_py_backwards_six_withmetaclass'),
                attr='with_metaclass',
                ctx=ast.Load()
            ),
            keywords=[],
            starargs=None,
            kwargs=None
        ),
        keywords=[],
        body=[],
        decorator_list=[],
    )

# Generated at 2022-06-23 22:38:09.240457
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:38:13.371024
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .base import BaseNodeTransformer
    from ..utils.tree import ast_to_str, pretty_print_ast, ast_to_bytes
    from .utils import compile_and_load_ir, dump_and_load
    from ..utils.source import source_to_ast, source_to_str
    import six as _six
    import typing as _typing
    import ast as _ast

    metaclass_kwarg = _typing.Type[MetaclassTransformer.visit_ClassDef]

# Generated at 2022-06-23 22:38:18.331927
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ...utils.source import source

    source = """class Foo(metaclass=B): pass"""
    tree = source_to_ast(source)
    trans = MetaclassTransformer()
    tree = trans.visit(tree)

# Generated at 2022-06-23 22:38:25.210201
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = '''
        class Foo(Bar):
            pass
    '''
    expected_code = '''
        from six import with_metaclass as _py_backwards_six_with_metaclass
        class Foo(_py_backwards_six_with_metaclass(Bar)):
            pass
    '''
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(ast.parse(code, mode='exec'))
    assert metaclass_transformer._tree_changed == True
    assert astor.to_source(metaclass_transformer.root) == expected_code


# Generated at 2022-06-23 22:38:36.976407
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import ClassDef, Expr, Name, List, Str
    from ..compiler import Compiler
    from .. import TranspileError

    node = ClassDef(
        name='Foo',
        bases=[Expr(value=Name(id='Node', ctx=Load()))],
        keywords=[AugAssign(
            target=Name(id='metaclass', ctx=Store()),
            op=Sub,
            value=Expr(value=Name(id='Type', ctx=Load())))],
        body=[Expr(value=Str('test'))],
        decorator_list=[],
        lineno=1,
        col_offset=0)

# Generated at 2022-06-23 22:38:38.457829
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    x = MetaclassTransformer()

# Generated at 2022-06-23 22:38:39.829305
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:38:50.013924
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from textwrap import dedent
    from .testutils import check_node

    src = dedent('''\
    class A(metaclass=B):
        pass
    ''')
    expected = six_import.get_body() + [ast.ClassDef(name='A',
                                                     bases=class_bases.get_body(metaclass=ast.Name(id='B'),
                                                                                bases=ast.List(elts=[], ctx=ast.Load())),
                                                     body=[],
                                                     decorator_list=[],
                                                     keywords=[])]

    tree = compile_source(src, 'myfile.py', 'exec')
    check_node(tree, expected)
    tree = MetaclassTransformer.run_pipeline(tree)

# Generated at 2022-06-23 22:38:51.340591
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    pass



# Generated at 2022-06-23 22:39:02.611524
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.Module([
        ast.ClassDef(
            name='A',
            bases=[
                ast.Name(id='C', ctx=ast.Load())
            ],
            keywords=[
                ast.keyword(
                    arg='metaclass',
                    value=ast.Name(id='B', ctx=ast.Load())
                )
            ],
            body=[],
            decorator_list=[]
        )
    ])

    transformer = MetaclassTransformer()
    actual_node = transformer.visit(node)  # type: ast.AST


# Generated at 2022-06-23 22:39:04.106381
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    tt = MetaclassTransformer()

# Generated at 2022-06-23 22:39:09.638420
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..toolchain import toolchain

    class_def_test = """class Test(metaclass=TestMeta):

    def __init__(self):
        self.foo = 'bar'
"""


# Generated at 2022-06-23 22:39:15.164291
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(metaclass=B):pass')
    after_node = ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B,object,object)):pass')
    mt = MetaclassTransformer()
    mt.visit(node)
    assert ast.dump(mt.result) == ast.dump(after_node)

# Generated at 2022-06-23 22:39:21.432396
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    source = "class A(metaclass=B, **kw): pass"

    # When
    tree = ast.parse(source)
    transformer = MetaclassTransformer()
    tree = transformer.visit(tree)

    # Then
    expected = "class A(_py_backwards_six_withmetaclass(B, *())): pass"
    actual = astor.to_source(tree)
    assert expected == actual
    assert transformer._tree_changed is True

# Generated at 2022-06-23 22:39:26.680165
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ...walkers import Walker
    from ..utils.tree import get_preorder
    import astunparse
    
    # Test the case where class has metaclass
    node_class = ast.parse("""class A(metaclass=B): pass""").body[0]
    node = MetaclassTransformer().visit(node_class)
    assert astunparse.unparse(node) == "class A(_py_backwards_six_withmetaclass(B), metaclass=type): pass"


# Generated at 2022-06-23 22:39:32.908434
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .test_utils import round_trip

    code = """
    class A(metaclass=B):
        pass
    """
    node = ast.parse(code)
    node = node._replace(body=[MetaclassTransformer().visit(node)])  # type: ignore
    code = round_trip(node)

# Generated at 2022-06-23 22:39:34.694299
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:39:43.100871
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Setup
    from ..parser import parse
    from .six import SixImporter
    from .remove_metaclass import RemoveMetaclassTransformer

    node = parse("""
    class A(metaclass=B):
        pass
    """)

    # Run & check
    importer = SixImporter('six')
    node, changed = importer.visit(node)
    assert changed
    transformer = RemoveMetaclassTransformer()
    node, changed = transformer.visit(node)
    assert changed
    transformer = MetaclassTransformer()
    node, changed = transformer.visit(node)
    assert changed
    actual = compile(node, '', 'exec')

    # Postconditions
    from .six import six_import
    from .remove_metaclass import class_bases

# Generated at 2022-06-23 22:39:52.470250
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert_code_equal(r"""
    class Foo(object):
        bar = 'BAR'
    """,
    r"""
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class Foo(_py_backwards_six_withmetaclass(object)):
        bar = 'BAR'
    """)
    assert_code_equal(r"""
    class Foo(object, metaclass=Bar):
        bar = 'BAR'
    """,
    r"""
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class Foo(_py_backwards_six_withmetaclass(Bar, *[object])):
        bar = 'BAR'
    """)

# Generated at 2022-06-23 22:39:59.269057
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("class A(metaclass=B): pass"
                     "class C(metaclass=D, e=f): pass"
                     "class G(H, metaclass=I): pass"
                     "class J(K, L, metaclass=M): pass")
    metaclass_transformer = MetaclassTransformer()
    node = metaclass_transformer.visit(node)
    transformed_code = compile(node, '<string>', 'exec')
    code_context = {}

    assert not code_context
    exec(transformed_code, code_context)
    assert code_context['A'].__bases__ == (B,)
    assert code_context['C'].__bases__ == (D,)

# Generated at 2022-06-23 22:40:09.685020
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    from astor._six import with_metaclass as _py_backwards_six_with_metaclass
    from ..utils.fake import fake


# Generated at 2022-06-23 22:40:14.614222
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys
    import six
    sys.modules['six'] = six
    import astor

    code = """
    class A(metaclass=B):
        pass
    """
    tree = ast.parse(code)
    MetaclassTransformer.run_on(tree)
    # import ipdb; ipdb.set_trace()
    print(astor.to_source(tree))


# Generated at 2022-06-23 22:40:20.722200
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse('class Meta(type): pass\n'
                     'class Klass(metaclass=Meta): pass')
    expected = ast.parse(six_import.to_string()+'\n'
                         'class Meta(type): pass\n'
                         'class Klass(_py_backwards_six_withmetaclass(Meta))')

    mt = MetaclassTransformer()
    mt.visit(node)

    assert mt.changed == True
    assert ast.dump(node) == ast.dump(expected)



# Generated at 2022-06-23 22:40:27.401743
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    from .base import BaseNodeTransformerTest
    from ..utils.ast_factory import ast_call
    from ..utils.code_gen import (
        ast_classdef,
        ast_fun,
    )
    from typed_ast import ast3 as ast

    def test_metaclass(class_name, metaclass_name, metaclass_base, module_body):
        class_body = [
            ast_call(
                func='print',
                args=[
                    ast.Str(s=class_name)
                ],
                keywords=[],
            )
        ]

# Generated at 2022-06-23 22:40:35.480422
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class_def = ast.parse('class A(metaclass=B):\n    pass').body[0]
    trans = MetaclassTransformer()
    class_def = trans.visit(class_def)
    assert ast.dump(class_def) == "ClassDef(name='A', bases=[Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), args=[Name(id='B', ctx=Load())], keywords=[])], keywords=[], body=[Pass()], decorator_list=[])"

# Generated at 2022-06-23 22:40:41.792045
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = """
    class MyClass(metaclass=MyMeta, **kw):
        pass
    """
    module = ast.parse(code, filename="<test>")
    MetaclassTransformer().visit(module)
    assert not any(isinstance(n, ast.keyword)
                   for n in ast.walk(module))
    # TODO: check that node.bases contain one element that is a call to class_bases and it is first node in module

# Generated at 2022-06-23 22:40:50.888597
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import unittest.mock as mock
    import astor as astor
    visitor = MetaclassTransformer()

    cases = (
        ('''class A(metaclass=B): pass''',
         '''class A(_py_backwards_six_with_metaclass(B)): pass'''),
    )

    for code_input, code_output in cases:
        node = ast.parse(code_input)
        visitor.visit(node)
        output = astor.to_source(node).strip()
        assert(output == code_output)



# Generated at 2022-06-23 22:40:59.028932
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert six_import.get_body() == \
        ast.Module(
            body=[
                ast.ImportFrom(
                    module='six',
                    names=[ast.alias(
                        name='with_metaclass',
                        asname='_py_backwards_six_withmetaclass'
                    )],
                    level=0
                )
            ]
        )

# Generated at 2022-06-23 22:41:03.654999
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert check_ast("class A(metaclass=B): pass", 2, 7).is_subset_of(
        "from six import with_metaclass as _py_backwards_six_withmetaclass\n"
        "class A(_py_backwards_six_withmetaclass(B)): pass", 2, 7)

# Generated at 2022-06-23 22:41:13.860169
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    sample_input = textwrap.dedent("""
    import six
    class A(object):
        def __init__(self):
            self.a = 1
        def bar():
            return 5
    """)
    expected_output = textwrap.dedent("""
    class A(six.with_metaclass(object)):
        def __init__(self):
            self.a = 1
        def bar():
            return 5
    """)
    tree = ast.parse(sample_input)
    tree_changed = False
    transformer = MetaclassTransformer(tree, tree_changed)
    transformer.visit(tree)
    assert transformer._tree_changed
    assert ast.dump(tree) == ast.dump(ast.parse(expected_output))

# Generated at 2022-06-23 22:41:14.816095
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import _ast
    import six

# Generated at 2022-06-23 22:41:15.791926
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:41:17.798594
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    t = MetaclassTransformer('fake')
    assert t.target == (2, 7)
    assert t.dependencies == ['six']

# Generated at 2022-06-23 22:41:23.463580
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .visitor import CodeVisitor
    from .visitors import Module
    from .visitors.metaclass import MetaclassTransformer
    from .visitors.backwards_compat import BackwardsCompatTransformer
    from .visitors.six import SixTransformer
    import typing

    metaclass_transformer = MetaclassTransformer()
    backwards_transformer = BackwardsCompatTransformer()
    six_transformer = SixTransformer()

# Generated at 2022-06-23 22:41:31.060758
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast

    test_python_code = """class X(metaclass=X):
    pass"""
    expected_python_code = """class X(_py_backwards_six_with_metaclass(X)):
    pass"""

    tree = ast.parse(test_python_code)
    transformed_tree = MetaclassTransformer().visit(tree)
    transformed_python_code = compile(transformed_tree, '', 'exec')
    exec(transformed_python_code)
    assert(expected_python_code == test_python_code)



# Generated at 2022-06-23 22:41:40.217059
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    expected = ast.parse(
        'from six import with_metaclass as _py_backwards_six_withmetaclass\n'
        'class A(metaclass=B):\n'
        '    pass'
    )
    actual = ast.parse(
        'class A(metaclass=B):\n'
        '    pass'
    )
    transformed = MetaclassTransformer(actual).visit(actual)
    actual = ast.fix_missing_locations(actual)
    transformed = ast.fix_missing_locations(transformed)
    assert ast.dump(actual) == ast.dump(expected)
    assert ast.dump(transformed) == ast.dump(expected)


# Generated at 2022-06-23 22:41:48.133118
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import_node = ast.Import(names=[
        ast.alias(name='six', asname=None)])
    metaclass = ast.Name(id='B', ctx=ast.Load())
    bases = [ast.Name(id='Object', ctx=ast.Load())]
    class_node = ast.ClassDef(
        name='A',
        bases=[ast.Name(id='_py_backwards_six_withmetaclass', ctx=ast.Load())],
        keywords=[ast.keyword(arg='metaclass', value=metaclass)],
        body=[],
        decorator_list=[])

    module_node = ast.Module([import_node, class_node])
    transformer = MetaclassTransformer()
    transformer.visit_Module(module_node)
    assert transformer._tree

# Generated at 2022-06-23 22:41:57.389056
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    tree = ast.parse('class a(b): pass')
    trans = MetaclassTransformer()
    trans.visit(tree)
    assert ast.dump(tree) == (
        "Module(body=[Import(names=[alias(name='six', "
        "asname=None)]), "
        "Assign(targets=[Name(id='_py_backwards_six_withmetaclass', "
        "ctx=Store())], "
        "value=Attribute(value=Name(id='six', ctx=Load()), "
        "attr='with_metaclass', ctx=Load())), "
        "ClassDef(name='a', bases=[_py_backwards_six_withmetaclass(b)], "
        "body=[Pass()])])"
    )


# Generated at 2022-06-23 22:41:58.510726
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast.ast3 import Module, parse

# Generated at 2022-06-23 22:42:02.288118
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module_node = ast.parse('class A(B):\n pass')
    MetaclassTransformer().visit(module_node)
    module_node2 = ast.parse('import six\n'
                             'class A(B):\n pass')
    assert ast.dump(module_node) == ast.dump(module_node2)


# Generated at 2022-06-23 22:42:07.574662
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """Test method in class MetaclassTransformer"""
    import sys
    import astunparse
    # Testing:
    # class A(metaclass=B):
    #     pass
    #
    # Outputs:
    #
    # class A(_py_backwards_six_withmetaclass(B))
    #     pass

# Generated at 2022-06-23 22:42:14.107201
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast
    import astor
    # Unit test for method visit_Module of class MetaclassTransformer
    compiler = ast.parse('class A(metaclass=B): pass')
    visitor = MetaclassTransformer()
    visitor.visit(compiler)
    ast.fix_missing_locations(visitor.tree)
    print(astor.to_source(visitor.tree))
    assert (astor.to_source(visitor.tree) == 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B, object)):\n    pass\n')

# Generated at 2022-06-23 22:42:20.543169
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    _py_backwards_six_withmetaclass(B, *[])
    """
    tree = ast.parse(source)
    assert MetaclassTransformer().visit(tree).body[0].bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert astor.to_source(tree.body[0].bases[0]) == expected

# Generated at 2022-06-23 22:42:26.861794
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .base import BaseNodeTransformer
    from test import test
    from typed_ast import ast3 as ast

    test_tree = ast.parse("""
    class MetaA(type):
        pass


    class B(metaclass=MetaA):
        pass


    class C(object, metaclass=MetaA):
        pass
    """)

    result = BaseNodeTransformer(test_tree).visit(MetaclassTransformer())
    test_tree = ast.parse("""
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class B(_py_backwards_six_withmetaclass(MetaA)):
        pass


    class C(_py_backwards_six_withmetaclass(MetaA), object):
        pass
    """)
   

# Generated at 2022-06-23 22:42:38.259274
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import get_test_node

    node = get_test_node(
        """
        class A(metaclass=B):
            pass
        """
    )
    t = MetaclassTransformer()
    t.visit(node)

    class B(ast.NodeTransformer):
        def visit_Name(self, node: ast.Name):
            if node.id == 'A':
                return ast.Name('_py_backwards_six_withmetaclass(B)')  # type: ignore
            return node

    node = B().visit(node)


# Generated at 2022-06-23 22:42:44.117237
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Setup
    class_node = parse("class A(C, metaclass=D): pass")

    # Run
    # noinspection PyTypeChecker
    node = MetaclassTransformer().visit(class_node)

    # Assert
    # noinspection PyTypeChecker
    assert_code_equal("class A(_py_backwards_six_withmetaclass(D, C)): pass", node)



# Generated at 2022-06-23 22:42:45.892144
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """Should transform a class with a metaclass to _py_backwards_six_withmetaclass()."""

# Generated at 2022-06-23 22:42:52.728216
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys

    import typed_ast.ast3 as ast

    node = ast.parse("class A(metaclass=int): pass")
    node = MetaclassTransformer(sys.version_info).visit(node)
    assert ast.dump(node) == "Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0), ClassDef(name='A', bases=[Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), args=[Num(n=1)], keywords=[], starargs=None, kwargs=None)], body=[Pass()], decorator_list=[])])"

if __name__ == "__main__":
    import sys


# Generated at 2022-06-23 22:42:55.154602
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .test_helpers import check_node_transformer

# Generated at 2022-06-23 22:43:00.479335
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = Category().parse(textwrap.dedent("""
    class Foo():
        pass
    """))

    MetaclassTransformer().visit(node)

    assert MetaclassTransformer._tree_changed
    assert node_to_string(node) == textwrap.dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class Foo():
        pass
    """)


# Generated at 2022-06-23 22:43:06.081074
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class Transformer(ast.NodeTransformer):
        def generic_visit(self, node):
            if hasattr(node, 'lineno'):
                return node
            return ast.NodeTransformer.generic_visit(self, node)  # type: ignore

    inp = """class A(metaclass=B): pass\n"""
    expected_out = """class A(_py_backwards_six_withmetaclass(B))"""

    six_import()
    class_bases(1)
    tree = ast.parse(inp)
    new_tree = Transformer().visit(tree)
    out = ast.unparse(new_tree)
    print(out)
    assert out == expected_out



# Generated at 2022-06-23 22:43:07.550804
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()

# Generated at 2022-06-23 22:43:15.534776
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast
    from .base import BaseTestMetaclassTransformer, transform
    from .base import BaseTestNodeTransformer, NodeTransformerTestCase

    class TestMetaclassTransformer(BaseTestMetaclassTransformer):
        transformer = MetaclassTransformer
        expected_code = transform(  # noqa: WPS416
            metaclass_snippet,
            'six',
            six_import,
            class_bases,
        )

    class TestNodeTransformer(
        NodeTransformerTestCase,
        BaseTestNodeTransformer,
    ):
        transformer = MetaclassTransformer


# Generated at 2022-06-23 22:43:16.077513
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:43:21.856623
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = """
    class A(metaclass=B, foo=bar):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    module = ast.parse(source)
    mt = MetaclassTransformer()
    result = mt.visit(module)
    assert ast.dump(result) == expected

# Generated at 2022-06-23 22:43:26.854163
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast
    
    class TestNodeTransformer(ast.NodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.keywords.append(ast.keyword(arg="metaclass", value=ast.Name(id="B", ctx=ast.Load())))
            node.bases.append(ast.Name(id="C", ctx=ast.Load()))
            return node


# Generated at 2022-06-23 22:43:33.810367
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.mock_ast import parse, get_node
    from ..utils.generic_visit import GenericVisit

    node = parse('import six')
    transformer = MetaclassTransformer()
    GenericVisit(transformer).visit(node)
    assert transformer.tree_changed
    assert get_node(node, 'import six') is not None
    assert get_node(node, 'from six import with_metaclass as _py_backwards_six_withmetaclass') is not None


# Generated at 2022-06-23 22:43:41.221590
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    sample = """
    class Test(metaclass=ABC):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class Test(_py_backwards_six_withmetaclass(ABC)):
        pass
    """
    node = ast.parse(sample)
    transformer = MetaclassTransformer()
    result = transformer.visit(node)
    result = ast.fix_missing_locations(result)
    #print(ast.dump(result))
    assert ast.dump(result) == expected

# Generated at 2022-06-23 22:43:52.595389
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class TestClass:
        """Used for type annotation of test methods only"""
        @staticmethod
        @snippet
        def test1(code):
            class A(metaclass=abc.ABCMeta):
                def test(self):
                    pass

        @staticmethod
        @snippet
        def test2(code):
            class A(metaclass=abc.ABCMeta):
                def __test__(self):
                    pass

        @staticmethod
        @snippet
        def test3(code):
            class A(metaclass=abc.ABCMeta):
                @classmethod
                def __test__(cls):
                    pass


# Generated at 2022-06-23 22:43:58.053389
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import parse
    from ..utils.compare_ast import compare_ast
    source = '''class A(metaclass=B):
    pass
'''

# Generated at 2022-06-23 22:44:04.229801
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = '''class A(metaclass=B):\n    pass'''
    expected = dedent('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        ''')
    tree = ast.parse(source)
    tree = MetaclassTransformer().visit(tree)
    assert astor.to_source(tree) == expected

# Generated at 2022-06-23 22:44:13.327971
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    trans = MetaclassTransformer()
    class1 = ast.ClassDef(
        name='Test',
        bases=[],
        keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='A', ctx=ast.Load()))],
        body=[ast.Pass()],
        decorator_list=[]
    )
    class2 = ast.ClassDef(
        name='Test',
        bases=ast.List(elts=[], ctx=ast.Load()),
        keywords=[],
        body=[ast.Pass()],
        decorator_list=[]
    )

# Generated at 2022-06-23 22:44:14.365150
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:44:18.181330
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    tree = ast.parse('class A(metaclass=B): pass')
    tree = MetaclassTransformer().visit(tree)
    print(astor.to_source(tree))


__transformer__ = MetaclassTransformer

# Generated at 2022-06-23 22:44:22.801241
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """
    Test for class MetaclassTransformer against the following input and expected value
    """
    class A(object):
        def __init__(self, x):
            self.x = x
        def add(self, y):
            return self.x + y
    a1 = A(4)
    assert a1.add(16) == 20

# Generated at 2022-06-23 22:44:28.175307
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # type: () -> None
    module = ast.parse("class A(metaclass=B): pass")
    MetaclassTransformer().visit(module)
    code = astunparse.unparse(module)
    assert code == six_import.get_text() + "\n" + class_bases.get_text("B", "") + "\n"

# Generated at 2022-06-23 22:44:30.372930
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import parse
    from typed_ast.ast3 import parse as ast_parse

# Generated at 2022-06-23 22:44:38.283592
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast
    module_node = ast.parse("class A(metaclass=B): pass")
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(module_node)
    actual_code = ast.fix_missing_locations(module_node).body[0].body[0].name
    assert (
        actual_code == "_py_backwards_six_withmetaclass"
    ), "The metaclass should be patched to be visited"
    assert (
        metaclass_transformer._tree_changed == True
    ), "The tree should have changed after visit"


# Generated at 2022-06-23 22:44:45.213538
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import six
    import astor

    snippet1 = '''
    class A(metaclass=B):
        pass
    '''
    snippet2 = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    module = ast.parse(snippet1)

    module = MetaclassTransformer().visit(module)

    assert astor.to_source(module) == snippet2
    assert not hasattr(six, 'with_metaclass')

# Generated at 2022-06-23 22:44:46.667611
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()


# Generated at 2022-06-23 22:44:48.314143
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    mb = MetaclassTransformer(None)

# Generated at 2022-06-23 22:44:57.650894
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..transforms import six_metaclass
    from ..utils.tree import tree_to_str

    class Person:
        pass

    class Employee(Person, metaclass=type):
        pass

    expected_tree = ast.parse(
        'from six import with_metaclass as _py_backwards_six_withmetaclass\n'
        '\n'
        'class Employee(_py_backwards_six_withmetaclass(type, Person)):\n'
        '    pass\n'
    )

    assert tree_to_str(
        six_metaclass.MetaclassTransformer().visit(ast.parse(inspect.getsource(Employee)))) == tree_to_str(
        expected_tree)

# Generated at 2022-06-23 22:44:58.516379
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import ast_compare


# Generated at 2022-06-23 22:45:07.783507
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import ast_compare
    from six import with_metaclass as _py_backwards_six_withmetaclass

    code = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
    """ + six_import.get_template() + """

    class A(metaclass=B):
        pass

    class C:
        pass
    """
    expected = """
    """ + six_import.get_template() + """
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    mod = ast.parse(code)
    MetaclassTransformer(mod).visit(mod)
    assert ast_compare(mod, expected)

# Generated at 2022-06-23 22:45:16.021314
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ...testing import assert_node_unchanged

    @snippet
    def snippet_import_2_7(a, b):
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(b)):
            pass
        class B(metaclass=int):
            pass

    assert_node_unchanged(snippet_import_2_7.get_ast(a=1, b=1))
    assert_node_unchanged(snippet_import_2_7.get_ast(a=1, b=object))

# Generated at 2022-06-23 22:45:26.286218
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    assert (MetaclassTransformer.visit_Module(MetaclassTransformer(),
            ast.parse("""
                    def crap():
                        pass
                    """)).body[0].name == "crap")
    assert (MetaclassTransformer.visit_Module(MetaclassTransformer(),
            ast.parse("""
                    class crap():
                        pass
                    """)).body[0].name == "crap")
    assert (MetaclassTransformer.visit_Module(MetaclassTransformer(),
            ast.parse("""
                    class crap(metaclass=type):
                        pass
                    """)).body[0].bases[0].func.id == '_py_backwards_six_with_metaclass')


# Generated at 2022-06-23 22:45:32.665860
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def = ast.parse('class A(metaclass=int): pass')
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(class_def)
    assert ast.dump(class_def, annotate_fields=False) == 'ClassDef(name="A", bases=[Call(func=Name(id="_py_backwards_six_withmetaclass", ctx=Load()), args=[Name(id="int", ctx=Load())], keywords=[])], body=[Pass()], decorator_list=[])'

# Generated at 2022-06-23 22:45:36.802254
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.testutils import snapshot
    class_ast = ast.parse('class A(metaclass=B): pass')
    node = MetaclassTransformer().visit(class_ast)
    snapshot(node, 'tests/snapshots/transformed_MetaclassTransformer.snap.py')

# Generated at 2022-06-23 22:45:37.424113
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:45:45.965796
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast

    class DummyNodeTransformer(MetaclassTransformer):
        def __init__(self):
            pass

    class_ast = ast.parse(
        """
        class A(metaclass=B):
            pass
        """
    )
    transformer = DummyNodeTransformer()
    transformer.visit(class_ast)
    assert transformer._tree_changed == True

    module_ast = ast.parse(
        """
        import six
        class A(metaclass=B):
            pass
        """
    )
    transformer = DummyNodeTransformer()
    transformer.visit(module_ast)
    assert transformer._tree_changed == True

# Generated at 2022-06-23 22:45:52.106380
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .six_transformer import six_import
    from ..utils.snippet import snippet
    from ..utils.tree import insert_at, ast_to_str
    import textwrap
    src = textwrap.dedent(r'''
        class A(metaclass=int):
            pass
    ''')
    node_orig = ast.parse(src)
    node_transformed = MetaclassTransformer().visit(node_orig)
    #print(ast_to_str(node_transformed))
    

# Generated at 2022-06-23 22:45:58.920129
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """Test MetaclassTransformer by creating a transformer and running it.

    """
    trans = MetaclassTransformer()
    code = """
    class A(metaclass=B):
        pass
    """
    tree = ast.parse(code)
    trans.visit(tree)

# Generated at 2022-06-23 22:45:59.934602
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:46:03.799113
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("class Test(type): pass")
    node2 = MetaclassTransformer().visit(node)
    result = ast.parse(inspect.getsource(node2))


# Generated at 2022-06-23 22:46:07.851972
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("class Foo(metaclass=type): pass")
    transformer = MetaclassTransformer()
    result = transformer.visit(node)

    assert result.body[0].lineno == 0
    assert result.body[0].col_offset == 0
    assert isinstance(result.body[0], ast.ImportFrom)

# Generated at 2022-06-23 22:46:10.942986
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:46:16.280118
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..test_utils import transform, run_test_suite, raises
    from typed_ast import ast3 as ast

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    transform(MetaclassTransformer, source, expected,)



# Generated at 2022-06-23 22:46:23.277337
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class A(vex.Transformer): pass
    class B(vex.Transformer): pass

    node = ast.parse('''
    class A(metaclass=B):
        pass
    ''').body[0]
    expected = ast.parse('''
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class A(_py_backwards_six_withmetaclass(B)):
        pass
    ''')
    assert MetaclassTransformer().visit(node) == expected

# Generated at 2022-06-23 22:46:33.263548
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = '\n'.join([
        "class X:",
        "    pass",
        "",
        "class A(metaclass=type):",
        "    pass",
        "",
        "class A(metaclass=int):",
        "    pass",
        "",
        "class A(metaclass=B):",
        "    pass",
        "",
        "class A(metaclass=B, superclass=C):",
        "    pass",
    ])

# Generated at 2022-06-23 22:46:37.557758
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class_stmt = ast.parse("""
    class Foo(metaclass=Bar):
        pass
    """, mode='eval').body
    new_class = MetaclassTransformer().visit(class_stmt)
    assert new_class.bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert new_class.bases[0].keywords[0].value.id == 'Bar'

# Generated at 2022-06-23 22:46:38.821312
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor


# Generated at 2022-06-23 22:46:45.730653
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    input = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    mt = MetaclassTransformer()
    tree = ast.parse(input)
    mt.visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-23 22:46:50.591104
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    class Dummy(BaseNodeTransformer):
        def __init__(self):
            self.result = None
            self.generic_visit = lambda node: node

        def visit_ClassDef(self, node):
            self.result = node


# Generated at 2022-06-23 22:46:57.826894
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.node import parse_ast

    source = '''
        class A(metaclass=B):
            pass'''
    expected = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass'''
    node = parse_ast(source)
    transformer = MetaclassTransformer()
    node = transformer.visit(node)
    actual = ast.unparse(node).strip()
    assert actual == expected


# Generated at 2022-06-23 22:47:05.469884
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .six import _py_backwards_six_withmetaclass, import_six

    node = ast.ClassDef(keywords=[ast.keyword(arg='metaclass',
                                              value=ast.Name(id='object',
                                                             ctx=ast.Load()))],
                        name='Foo',
                        bases=[],
                        body=[],
                        decorator_list=[])


# Generated at 2022-06-23 22:47:06.035534
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    pass

# Generated at 2022-06-23 22:47:16.710781
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..ast_transformer import ast_transformer
    import ast
    import six
    import sys


    class print_visitor(ast.NodeVisitor):
        def visit(self, node):
            print (node._fields)
            super(print_visitor, self).generic_visit(node)

    class get_visitor(ast.NodeVisitor):
        def visit(self, node):
            print (node._fields)
            print (node.body[0].func.id)
            self.func = node.body[0].func.id
            super(get_visitor, self).generic_visit(node)
            return self.func

    class get_visitor1(ast.NodeVisitor):
        def visit(self, node):
            print (node._fields)

# Generated at 2022-06-23 22:47:25.827053
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class_def = ast.ClassDef(name='A',
                             bases=[ast.Name(id='metaclass',
                                             ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='B',
                                                                  ctx=ast.Load()))],
                             body=[ast.Pass()])

    module = ast.Module(body=[class_def])

    MetaclassTransformer().visit(module)
