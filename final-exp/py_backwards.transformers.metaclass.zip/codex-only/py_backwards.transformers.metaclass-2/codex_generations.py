

# Generated at 2022-06-23 22:37:36.374395
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = """
        class A(metaclass=B):
            pass
    """
    tree = ast.parse(code)
    tree = MetaclassTransformer().visit(tree)
    
    expected = expected_code = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B))
            pass
    """
    expected_tree = ast.parse(expected_code)
    
    assert ast.dump(tree) == ast.dump(expected_tree)


# Generated at 2022-06-23 22:37:42.061011
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from astunparse import unparse
    from ..utils.compatibility import metaclass, six_import
    import six
    import_six = six_import()
    body = [metaclass()]
    module = ast.Module(body=body)
    t = MetaclassTransformer()
    module = t.visit(module)
    assert unparse(module) == (import_six +
                               'class A(metaclass=type):\n'
                               '    pass')



# Generated at 2022-06-23 22:37:50.467285
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast
    from typing import List
    from six_py_backwards import MetaclassTransformer
    from six_py_backwards.transformers.metaclass import (
        six_import,
        class_bases,
    )

    # Given
    class_def = ast.ClassDef(name="A",
                             keywords=[ast.keyword(arg="metaclass",
                                                   value=ast.Name(id="B",
                                                                  ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])
    tree = ast.Module(body=[class_def])

    # When
    transformer = MetaclassTransformer()
    new_tree = transformer.visit(tree)

    # Then

# Generated at 2022-06-23 22:37:51.972725
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:37:58.450829
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import compile
    from .. import top_level
    from ..utils.source import source_from_source
    from .visit import to_code

    source = source_from_source(
        '''
        class A(metaclass=B):
            pass
        ''',
        target_version=MetaclassTransformer.target
    )
    tree = compile(source)
    transformer = MetaclassTransformer()
    tree = transformer.visit(tree)
    assert transformer._tree_changed

# Generated at 2022-06-23 22:38:03.238534
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import compile
    from . import six_meta
    import ast

    node = compile('class A(metaclass=B): pass')
    m = MetaclassTransformer()
    m.visit(node)
    assert ast.dump(node) == ast.dump(six_meta)

# Generated at 2022-06-23 22:38:10.185355
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import ClassDef, List, Name, Str

    class C:  # type: ignore
        __metaclass__ = str

    node = ClassDef(name=Str('C'),
                    bases=List(elts=[Name(id='A')], ctx=Load()),
                    body=[FunctionDef(name=Str('a'),
                                      args=arguments(args=[], vararg=None, kwarg=None, defaults=[]),
                                      body=[], decorator_list=[], returns=None)], decorator_list=[],
                    keywords=[Name(id='__metaclass__', ctx=Load()), Str('str')],
                    starargs=None, kwargs=None)
    compiler = MetaclassTransformer()
    query = '_py_backwards_six_withmetaclass'

# Generated at 2022-06-23 22:38:11.701018
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source_to_ast
    from ..utils.compat import parse


# Generated at 2022-06-23 22:38:21.992689
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from ..transpile import Transpiler
    from .base import BaseNodeTransformerTest
    import textwrap

    code = textwrap.dedent('''\
        class A(metaclass=B):
            pass''')

    expected = textwrap.dedent('''\
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass\
    ''')

    tree = ast.parse(code)
    transpiler = Transpiler()
    transpiler.add_transformer(MetaclassTransformer)
    transpiler.transpile_code(tree)

# Generated at 2022-06-23 22:38:30.459225
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from ..utils.source_transformer import SourceTransformer
    from typing import cast

    class A(metaclass=type):
        def hi(self):
            pass

    source = SourceTransformer(MetaclassTransformer).visit(ast.parse(A.__qualname__))
    expected = 'class A(_py_backwards_six_withmetaclass(type)):\n\tdef hi(self):\n\t\tpass\n'
    assert source == expected


# Generated at 2022-06-23 22:38:31.910468
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.source import source


# Generated at 2022-06-23 22:38:36.855616
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import parse

    transformer = MetaclassTransformer()

    assert transformer.visit(
        parse("class A(metaclass=B):\n    pass")) == parse(
            "from six import _py_backwards_six_withmetaclass\n"
            "class A(_py_backwards_six_withmetaclass(B)):\n    pass")

# Generated at 2022-06-23 22:38:44.819006
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import AST
    import ast
    import inspect
    import textwrap
    # Test when node.bases is None
    class_noclassbases = textwrap.dedent("""\
    class TestClass(metaclass=None):
        pass""").lstrip()
    ast_noclassbases = ast.parse(class_noclassbases)
    actual_ast_noclassbases = MetaclassTransformer().visit(ast_noclassbases)
    # Construct expected tree

# Generated at 2022-06-23 22:38:49.196615
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import typed_ast.ast3

    expected_ast = typed_ast.ast3.parse('from six import with_metaclass as _py_backwards_six_withmetaclass')

    actual_ast = MetaclassTransformer().visit(expected_ast)

    assert expected_ast == actual_ast


# Generated at 2022-06-23 22:38:53.379851
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse(
        '''class A(metaclass=B):
        pass
       ''')

# Generated at 2022-06-23 22:39:02.077175
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    '''
    Unit test for method visit_ClassDef of class MetaclassTransformer.
    '''

    code = '''
    class A(metaclass=B):
        pass
    '''
    tree = ast.parse(code)
    t = MetaclassTransformer()
    newtree = tree
    t.visit(newtree)
    assert str(newtree).strip() == '''
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class A(_py_backwards_six_withmetaclass(B))
        pass
    '''

# Generated at 2022-06-23 22:39:08.148105
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .base import BaseTestTransformer
    from .test_base import expect_equal_source
    class TestMetaclassTransformer(
        BaseTestTransformer,
        MetaclassTransformer
    ):
        pass
    obj = TestMetaclassTransformer()
    obj.setup_method(obj, '_test_')
    obj.targets = (2,7)
    obj.dependency = ['six']


# Generated at 2022-06-23 22:39:13.256751
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.compare_ast import compare_ast

    source = source('''
        class A(metaclass=B):
            pass
    ''')

    module, = MetaclassTransformer().visit(source)
    expected = source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')
    assert compare_ast(module, expected)

    source = source('''
        class A(B):
            pass
    ''')

    module, = MetaclassTransformer().visit(source)

# Generated at 2022-06-23 22:39:14.032214
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:39:16.794258
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    mt = MetaclassTransformer()
    assert mt.dependencies == ['six']
    assert mt.target == (2, 7)



# Generated at 2022-06-23 22:39:20.819709
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3
    from typed_ast.ast3 import Module, Name, Load, ClassDef, NameConstant, Pass
    from ..transformer import BackwardsTransformer
    from .six_transformer import SixTransformer
    from .six_import_transformer import SixImportTransformer
    from .decorator_transformer import DecoratorTransformer


# Generated at 2022-06-23 22:39:28.164256
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class_node = ast.parse("class A(__metaclass__ = B): pass").body[0]
    transformer = MetaclassTransformer()
    new_class = transformer.visit(class_node)


# Generated at 2022-06-23 22:39:33.036619
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.testutils import transform_and_compare
    from ..utils.testutils import get_tree_string
    tree = transform_and_compare(MetaclassTransformer, metaclass_tree)
    assert get_tree_string(tree) == get_tree_string(metaclass_tree_expected)


# Generated at 2022-06-23 22:39:37.152003
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .base import get_example_module_6, get_example_module_6_expected
    module = get_example_module_6()
    expected = get_example_module_6_expected()
    xformer = MetaclassTransformer()
    assert xformer.visit(module) == expected


# Generated at 2022-06-23 22:39:38.070195
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

# Generated at 2022-06-23 22:39:38.661466
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    MetaclassTransformer()

# Generated at 2022-06-23 22:39:48.225517
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import parse
    from .test_BaseNodeTransformer import roundtrip
    from ..utils.summary import get_summary
    from ..utils.source import get_source_code

    source = """
        class A(metaclass=B):
            pass
        """

    expected_source = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """

    node = parse(source)
    new_node = MetaclassTransformer().visit(node)
    roundtrip(new_node)
    assert get_source_code(new_node) == expected_source

# Generated at 2022-06-23 22:39:53.403340
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """Test case for
    method visit_Module of class MetaclassTransformer
    """
    # Set up parameters
    node = ast.Module(body=[])
    instance = MetaclassTransformer()
    expected_result = ast.Module(body=six_import.get_body())

    # Call method under test
    result = instance.visit_Module(node)  # type: ignore

    # Check the results
    assert ast.dump(expected_result) == ast.dump(result)


# Generated at 2022-06-23 22:39:54.713566
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    c = MetaclassTransformer()
    assert c
    assert c.dependencies == ['six']

# Generated at 2022-06-23 22:40:00.472102
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import tempfile
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import AST
    from typed_ast import parse
    import shutil
    from ..utils.ast_compare import ast_compare
    from ..utils.node_visitor import NodeVisitor
    from ..utils.ast_fixer import get_fixed

    tmp_folder = tempfile.mkdtemp()

    src = '''
    class A(metaclass=B):
        pass
    '''

    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''

    src = parse(src, mode='exec')
    expected = parse(expected, mode='exec')

# Generated at 2022-06-23 22:40:11.025754
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3
    from typed_ast.ast3 import parse
    from tests.utils import roundtrip_with_debug
    from .six_utils import add_six_import
    from .class_utils import add_six_with_metaclass

    def test(source: str, expected: str, debug: bool = False) -> None:
        tree = parse(source)
        add_six_import(tree)
        add_six_with_metaclass(tree)
        MetaclassTransformer().visit(tree)
        assert roundtrip_with_debug(tree, debug) == expected


# Generated at 2022-06-23 22:40:15.785342
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source_code = '''class A(metaclass=B):\npass'''
    node = ast.parse(source_code)
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(node)

# Generated at 2022-06-23 22:40:21.006737
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast.ast3 import parse, ClassDef, Assign, Name, Load, FunctionDef, Pass
    class_stmt = ClassDef(name='A', bases=[], keywords=[], body=[Pass()], decorator_list=[])
    with_metaclass_class_stmt = ClassDef(name='A', bases=[Name(id='metaclass', ctx=Load())],
                                         keywords=[], body=[Pass()], decorator_list=[])
    from_stmt = parse('from six import with_metaclass as _py_backwards_six_withmetaclass')

# Generated at 2022-06-23 22:40:21.442778
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    pass

# Generated at 2022-06-23 22:40:28.178074
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .test_utils import make_test, assert_code

    expected = 'class A(_py_backwards_six_with_metaclass(B)):\n    pass\n'

    make_test(MetaclassTransformer,
              'class A(metaclass=B): pass',
              expected,
              setup={'six': six_import})
    assert_code(six_import, 'from six import with_metaclass as _py_backwards_six_with_metaclass')

# Generated at 2022-06-23 22:40:33.880361
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..context import Context
    from .test_utils import make_test_context

    with make_test_context(__file__) as c:
        # Create a context for the test.
        ctx = Context(c.config, c.file_path, c.target)

        # Test if MetaclassTransformer can be instantiated.
        m = MetaclassTransformer(ctx)


# Generated at 2022-06-23 22:40:35.245101
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.fake_parser import get_parser


# Generated at 2022-06-23 22:40:41.935876
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class_def = ast.ClassDef(name='A',
                             bases=[],
                             body=[],
                             keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))])
    new_class_def = MetaclassTransformer().visit(class_def)
    assert str(new_class_def.bases[0]) == \
        '_py_backwards_six_withmetaclass(B, )'

# Generated at 2022-06-23 22:40:46.214308
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import run_transformer
    from .base import RetainNode
    from ..parsers import parse
    from ..utils.ast import dump_ast, serialize_ast


# Generated at 2022-06-23 22:40:54.491703
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_ = ast.parse("class Foo(metaclass=Bar):\n pass").body[0]
    node = MetaclassTransformer()

    StatementPatcher().visit(node.visit(class_))

    assert node._tree_changed is True
    assert node.visit(class_).bases == [
        ast.Expr(ast.Call(
            func=ast.Name(id='_py_backwards_six_withmetaclass', ctx=ast.Load()),
            args=[ast.Name(id='Bar', ctx=ast.Load()),
                  ast.List()],
            keywords=[]))
    ]
    assert node.visit(class_).keywords == []

# Generated at 2022-06-23 22:40:57.256794
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast as pyast
    from ..utils import ast_helpers

    node = pyast.parse("""
    class A(object, metaclass=C):
        pass
    """)
    node = ast_helpers.relocate_literals(node)

    transformer = MetaclassTransformer()
    transformer.visit(node)

    assert ast_helpers.dump(node) == """
    import six
    class A(six.with_metaclass(C, object)):
        pass
    """

# Generated at 2022-06-23 22:41:07.780135
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass

    @snippet
    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)

    class_bases: List[ast.AST] = class_bases.get_body(metaclass=ast.Name(id='metaclass', ctx=ast.Load()), bases=ast.List(elts=[], ctx=ast.Load())) 
    six_import: List[ast.AST] = six_import.get_body()


# Generated at 2022-06-23 22:41:09.884667
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    tr = MetaclassTransformer()
    

# Generated at 2022-06-23 22:41:12.351458
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import typing
    if typing.TYPE_CHECKING:
        from typed_ast import ast3 as ast

    class A(metaclass=type):
        pass

# Generated at 2022-06-23 22:41:19.235312
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class P(ast.NodeTransformer):
        def __init__(self, tree_changed, python_version, dependencies):
            self._tree_changed = tree_changed
            self._python_version = python_version
            self._dependencies = dependencies


# Generated at 2022-06-23 22:41:24.627267
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    text = """class A(metaclass=B):
    pass\n"""
    expected = """class A(_py_backwards_six_with_metaclass(B)):
    pass\n"""
    node = ast.parse(text)
    t = MetaclassTransformer()
    new_node = t.visit(node)
    print(ast.dump(new_node))
    text = astunparse.unparse(new_node)
    assert text == expected

# Generated at 2022-06-23 22:41:32.211433
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = """
    class A(metaclass=B):
        pass
    class C(B):
        pass
    """

    node = ast.parse(source)
    MetaclassTransformer().visit(node)
    assert codegen.to_source(node) == """\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    
    
    class C(B):
        pass
    
    """

# Generated at 2022-06-23 22:41:34.592718
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import PyTypeChecker
    assert PyTypeChecker.check_module(MetaclassTransformer)

if __name__ == '__main__':
    pass

# Generated at 2022-06-23 22:41:36.016695
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..unparse import Unparser

# Generated at 2022-06-23 22:41:44.790958
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast import parse

    module = (
        'class A(metaclass=B):\n'
        '    pass'
    )
    tree = parse(module)
    expected = (
        'from six import with_metaclass as _py_backwards_six_withmetaclass\n'
        '\n'
        'class A(_py_backwards_six_withmetaclass(B))\n'
        '    pass'
    )

    transformer = MetaclassTransformer()
    new_module = transformer.visit(tree)
    assert transformer._tree_changed

    assert ast.dump(new_module, include_attributes=True) == expected

# Generated at 2022-06-23 22:41:54.806558
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from python_backwards_compatibility.transformers.transformers.six_with_metaclass import MetaclassTransformer
    from typed_ast.ast3 import ClassDef, Load, Name, Module, NameConstant, Name as AstName, Assign, AssignName, AssignAttr, Attribute, AnnAssign, Subscript, Store, Tuple, List, Call, AugAssign, If, Return, UnaryOp, Compare, BinOp, IfExp, starargs_to_args, kwargs_to_args
    from typed_ast.ast3 import Str, Num, ListComp, Arg, keyword, Expr, FunctionDef, And, Not, Or, In, NotIn, Lt, Gt, Eq, NotEq, LtE, GtE, Is, IsNot, LShift, RShift, Add, Sub, Mult, Div, Floor

# Generated at 2022-06-23 22:41:59.797696
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # type: () -> None
    import ast as pyast
    from ast import ClassDef

    tree = ClassDef(name='A',
                    bases=[pyast.Name(id='object', ctx=pyast.Load())],
                    keywords=[pyast.keyword(arg='metaclass', value=pyast.Name(id='B', ctx=pyast.Load()))],
                    decorator_list=[],
                    body=[])

    mt = MetaclassTransformer()

# Generated at 2022-06-23 22:42:00.964580
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()


# Generated at 2022-06-23 22:42:10.565026
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class Source(ast.NodeTransformer):
        def visit_BinOp(self, node):
            return node.op

    class Destination(ast.NodeTransformer):
        def visit_BinOp(self, node):
            return node

    correct_bases = ast.Call(ast.Name(id='_py_backwards_six_withmetaclass'),
                             args=[ast.Name(id='MetaclassB')],
                             keywords=[])

    module = ast.Module(body=[ast.ClassDef(name='A', bases=[correct_bases], body=[], decorator_list=[])])
    source_module = Source().visit(module)
    destination_module = Destination().visit(module)
    assert source_module == destination_module

# Generated at 2022-06-23 22:42:16.852469
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast
    class_def = ast.ClassDef('MyClass', [], [], [], None, ast.Name('MyMetaclass', ast.Load()))
    module = ast.Module([class_def])
    transformed = MetaclassTransformer().visit(module)
    assert [c.value.func.value.id for c in transformed.body if isinstance(c, ast.Expr)] == ['_py_backwards_six_with_metaclass']


# Generated at 2022-06-23 22:42:17.858839
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:42:24.332371
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_fixture import check_transformation
    from ..utils.test_fixture import check_not_transformed

    check_transformation(
        """
            class Foo(metaclass=Bar):
                pass
        """,
        """
            from six import with_metaclass as _py_backwards_six_with_metaclass

            class Foo(_py_backwards_six_with_metaclass(Bar)):
                pass
        """,
        MetaclassTransformer
    )

    # test not transformed without metaclass
    check_not_transformed(
        """
            class Foo:
                pass
        """,
        MetaclassTransformer
    )

# Generated at 2022-06-23 22:42:32.412626
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .utils import parse

    src = '\n'.join([
        'class A(metaclass=B):',
        '    pass',
    ])
    expected = '\n'.join([
        six_import.get_source(),
        '',
        '',
        'class A(class_bases.get_call(metaclass=B, bases=[])):',
        '    pass',
    ])

    node = parse(src)
    MetaclassTransformer().visit(node)
    source = ast.unparse(node)
    assert source == expected

# Generated at 2022-06-23 22:42:40.267815
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    tree = astor.parse_file("""
    class A(metaclass=type):
        pass
    """)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    expected_tree = astor.parse_file("""
    import six as _py_backwards_six
    class A(_py_backwards_six.with_metaclass(type)):
        pass
    """)
    assert astor.to_source(tree) == astor.to_source(expected_tree)

# Generated at 2022-06-23 22:42:46.266380
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from six import with_metaclass

    test_code = """
    class A(metaclass=B, x=3):
        pass
    """
    expected_code = """
    class A(_py_backwards_six_with_metaclass(B, *[])):
        pass
    """
    tree = ast.parse(test_code)
    t = MetaclassTransformer()
    t.visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse(expected_code))


# Generated at 2022-06-23 22:42:51.152763
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = """class A(metaclass=str):pass"""

    x = MetaclassTransformer(code)
    assert 'six' in x.dependencies
    print(x.result())
    assert 'class A(_py_backwards_six_withmetaclass(str)):' in x.result()

# Generated at 2022-06-23 22:42:53.036791
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import get_node
    from ..tokenizer import tokenize
    import six


# Generated at 2022-06-23 22:43:01.830570
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..testing import assert_transformed
    assert_transformed(
        """class A(metaclass=B):
            pass
        """, """class A(_py_backwards_six_withmetaclass(B)):
            pass
        """,
        [six_import, class_bases],
    )

    assert_transformed(
        """class A(metaclass=B):
            pass

        class C(metaclass=D):
            pass
        """, """class A(_py_backwards_six_withmetaclass(B)):
            pass

        class C(_py_backwards_six_withmetaclass(D)):
            pass
        """,
        [six_import, class_bases],
    )

# Generated at 2022-06-23 22:43:07.997729
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    assert snippet(
        "class Foo(metaclass=Bar): pass",
        target=tuple(reversed([2, 7])),
        transformer=MetaclassTransformer,
    ) == snippet("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class Foo(_py_backwards_six_withmetaclass(Bar)): pass
    """)



# Generated at 2022-06-23 22:43:17.063303
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer(from_version=(2, 7))

# Generated at 2022-06-23 22:43:23.459308
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # make sure six is loaded
    from ..utils.imports import Import
    import six

    six_import_ = Import.from_module(six)  # type: ignore
    six_import_ = six_import_.with_alias('six', {'with_metaclass'})

    six_import_ = six_import_.get_tree()
    six_import_.name = 'six'
    six_import_.alias = 'six'
    six_import_.names = six_import_.alias.asname

    # make sure the class is loaded

# Generated at 2022-06-23 22:43:30.086086
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.testing import make_test, assert_equal

    test = make_test(MetaclassTransformer, 2, 7)

    src = """
    class A:
        pass
    class B(C, metaclass=D):
        pass
    class E(C, metaclass=D, F=G, H=I):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A:
        pass
    class B(_py_backwards_six_withmetaclass(D)):
        pass
    class E(_py_backwards_six_withmetaclass(D)):
        pass
    """
    result, msg = test(src, expected)
    assert_equal(result, expected, msg)




# Generated at 2022-06-23 22:43:31.098613
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:43:37.362186
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.codegen import to_source

    expected = six_import.get_body() + [ast.Module(body=[ast.Expr(value=ast.Name(id='M', ctx=ast.Load()))])]
    tree = ast.parse('M')
    mt = MetaclassTransformer()
    mt.visit(tree)
    assert to_source(tree) == to_source(expected)



# Generated at 2022-06-23 22:43:41.912075
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
 
    assert six_import.get_body() == [
        ast.ImportFrom(
            module='six',
            names=[ast.alias(
                name='with_metaclass',
                asname='_py_backwards_six_withmetaclass',
            )],
            level=0,
        )
    ]
 
 

# Generated at 2022-06-23 22:43:53.229514
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typing
    if typing.TYPE_CHECKING:
        import astor

    fix_asserts(globals(), 'tests.backports.test_metaclass.test_MetaclassTransformer_visit_ClassDef')

    class A(object):
        pass

    class B(metaclass=A):
        pass

    class C(metaclass=A, x=1):
        pass

    class D(object, metaclass=A, x=1):
        pass


    class E(type):
        pass

    class F(metaclass=E, x=1):
        pass


    class F2(type, metaclass=E, x=1):
        pass


    class G(type, x=1):
        pass


# Generated at 2022-06-23 22:44:02.785508
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    code = """
        class A(metaclass=B):
            pass
    """

    expected_code = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """

    tr = MetaclassTransformer()
    res = tr.visit(ast.parse(code))
    gen = ast.parse(expected_code)

    assert ast.dump(ast.Module(body=res), include_attributes=True) == \
    ast.dump(gen, include_attributes=True)

# Generated at 2022-06-23 22:44:12.502330
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from asttokens import ASTTokens
    from target_python.unparse import unparse
    from target_python.examples import metaclass
    from .test_helpers import normalize_code
    from ..tree_optimization import SimplifyImports

    before = ASTTokens(source=metaclass.before)
    node = before.tree
    assert isinstance(node, ast.Module)
    transformer = MetaclassTransformer()
    # The visit_Module method doesn't return a value, so we inspect the
    # transformer's _tree_changed attribute.
    assert not transformer._tree_changed
    transformer.visit(node)
    assert transformer._tree_changed
    after = unparse(node)
    assert normalize_code(after) == normalize_code(metaclass.after)
    # Run a simplifier to remove

# Generated at 2022-06-23 22:44:16.373250
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:44:17.268345
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    snippet.test_snippets(MetaclassTransformer)

# Generated at 2022-06-23 22:44:20.853479
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = '''
    class A(metaclass=B):
        pass
    '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass'''
    tree = ast.parse(source)
    transformer = MetaclassTransformer()
    tree = transformer.visit(tree)
    assert ast.dump(tree) == expected


# Generated at 2022-06-23 22:44:21.514381
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:44:26.334768
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    transformer = MetaclassTransformer()
    module_tree: ast.Module = ast.parse("class A(metaclass=B): pass")
    module_tree = transformer.visit(module_tree)


# Generated at 2022-06-23 22:44:31.755986
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer().visit_Module(ast.parse('''
        class A(B, metaclass=C):
            pass
    ''')) == ast.parse('''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(C, *[B])):
            pass
    ''')

# Generated at 2022-06-23 22:44:38.446433
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typing import List, Dict, Any
    from ..utils.fake_ast import parse_dummy_ast

    pass_ast = parse_dummy_ast("""
    class A:
        a = 1
    class B:
        pass
    """)

    class_A, module = pass_ast
    class_B, module = pass_ast

    t = MetaclassTransformer()
    new_ast = t.visit(pass_ast)

# Generated at 2022-06-23 22:44:44.036548
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = parse("""
        from six import with_metaclass as something

        class A(metaclass=B):
            pass
    """)
    MetaclassTransformer().visit(node)

    assert_equal("""
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """, node)



# Generated at 2022-06-23 22:44:49.356402
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast
    from asttokens import ASTTokens
    from six import add_metaclass

    class T(add_metaclass(type)):
        pass

    node = ast.parse(T.__module__)
    mt = MetaclassTransformer(ASTTokens(T.__module__))
    mt.visit(node)
    assert mt._tree_changed
    assert node.body[0].value == six_import.get_body()[0].value
    assert node.body[1].bases[0].func.value.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-23 22:44:57.409219
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    tree = ast.parse('''
        class A(metaclass=B):
            pass
    
        class C(D):
            pass
    ''')  # type: ast.Module
    expected_tree = ast.parse('''
        from six import _py_backwards_six_with_metaclass

        class A(_py_backwards_six_with_metaclass(B)):
            pass

        class C(D):
            pass
    ''')  # type: ast.Module
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert expected_tree == tree
    assert transformer._tree_changed



# Generated at 2022-06-23 22:45:06.358219
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.test_utils import transform, parse
    from ..patching import patch_module
    from ..utils.patching import make_tree
    import six

    with patch_module('py_backwards.transforms.metaclass', six=six):
        src = '''
        class A(metaclass=B): pass
        '''
        expected = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)): pass
        '''

        tree = transform(MetaclassTransformer, parse(src))
        tree = make_tree(tree)

        assert expected == tree

# Generated at 2022-06-23 22:45:07.402289
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:45:12.563078
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..unitutil import class_fixture

    metaclass_transformer = class_fixture(MetaclassTransformer)

    metaclass_transformer.visit(ast.parse('class A(): pass'))
    expected_bases = '_py_backwards_six_withmetaclass(list, *[str])'
    assert metaclass_transformer.bases == expected_bases

# Generated at 2022-06-23 22:45:20.779586
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast.ast3 import Module, ClassDef, Name, Str
    from ..utils.tester import node_test
    
    module_node = Module(body=[
        ClassDef(name='TestClass', 
                 bases=[], 
                 keywords=[], 
                 body=[
                     Str('Test'),
                 ], 
                 decorator_list=[],)
    ])
    
    tr = MetaclassTransformer()
    node_test(tr.visit(module_node), '''
    import six
    class TestClass(six.with_metaclass(object)):
        "Test"
    ''')



# Generated at 2022-06-23 22:45:23.356673
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer(
        from_version=None, to_version=None, tree=None).target == (2, 7)

# Generated at 2022-06-23 22:45:24.378225
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import six

# Generated at 2022-06-23 22:45:24.962289
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:45:31.365368
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    code = "class A(metaclass='B'): pass"
    node = astor.parse_build(code)
    tree_changed = MetaclassTransformer().visit(node)
    assert tree_changed.__dict__ == {'_tree_changed': True}
    assert astor.to_source(tree_changed).strip() == \
        'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(with_metaclass("B"))\n'


# Generated at 2022-06-23 22:45:36.695840
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from . import assert_node_transformation
    assert_node_transformation(MetaclassTransformer,
                               """
                               class Cls(metaclass=Meta):
                                   pass
                               """, """
                               from six import with_metaclass as _py_backwards_six_withmetaclass
                               class Cls(_py_backwards_six_withmetaclass(Meta)):
                                   pass
                               """)

# Generated at 2022-06-23 22:45:46.329750
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ... import transform
    from six import with_metaclass  # type: ignore
    from typed_ast import ast3 as ast

    code = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    expected = expected.lstrip()

    tree = ast.parse(code, '<test>', 'exec')
    tree = transform(tree, MetaclassTransformer)
    assert ast.dump(tree).strip() == expected
    tree = compile(tree, '<test>', 'exec')

    ns = {}
    exec(tree, ns)
    A = ns['A']


# Generated at 2022-06-23 22:45:47.619759
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast.ast3 import parse


# Generated at 2022-06-23 22:45:57.508177
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast27 as ast  # type: ignore
    from ..utils.transformer import transform
    
    class A(ast.NodeTransformer):

        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            if node.keywords:
                node.keywords = []
                self._tree_changed = True
            return self.generic_visit(node)
    
    class B(ast.NodeTransformer):

        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            if node.keywords:
                metaclass = node.keywords[0].value

# Generated at 2022-06-23 22:46:01.874827
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .test_pickle import assert_pickle_roundtrip
    assert_pickle_roundtrip(
        MetaclassTransformer,
        '''
        class A(metaclass=B):
            pass
        '''
    )



# Generated at 2022-06-23 22:46:07.084524
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typing import cast
    from ..utils.context import Context
    source = '''
        class A(metaclass=B):
            pass
    '''
    tree = ast.parse(source)
    context = Context()
    transformer = MetaclassTransformer(tree, context)
    transformer.visit(tree)
    classdef = cast(ast.ClassDef, tree.body[0])
    assert classdef.bases[0].value.func.attr == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-23 22:46:12.566657
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.source import source

    snippet = source(six_import) + source(class_bases)
    transformer = MetaclassTransformer()
    transformer.visit(ast.parse(snippet))
    transpiled = transformer.get_code()

    assert transpiled.strip() == snippet.strip()



# Generated at 2022-06-23 22:46:17.331131
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

    source = 'class A(metaclass=int): pass'
    expected = 'class A(_py_backwards_six_withmetaclass(int)): pass'

    node = ast.parse(source)
    node = MetaclassTransformer().visit(node)
    result = astor.to_source(node).strip()

    assert result == expected

# Generated at 2022-06-23 22:46:24.187625
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source_to_ast
    from ..utils.unparse import unparse
    from ..utils.visitor import get_visitor

    visitor = get_visitor(MetaclassTransformer, ast.ClassDef)
    ast_tree = source_to_ast.parse(
        """
       class A(metaclass=B):
            pass
        """
    )
    visitor.visit(ast_tree)
    assert ast_tree != unparse(ast_tree)

# Generated at 2022-06-23 22:46:33.975050
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    # Given
    class A(object):
        class B(metaclass=type):
            def bar(self):
                pass

    # When
    visitor = MetaclassTransformer()
    visitor.visit(A.B)

    # Then

# Generated at 2022-06-23 22:46:40.300532
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    snippet_from_test = """
    class Test(object):
        __metaclass__ = abc.ABCMeta
        class Nested(object, metaclass=abc.ABCMeta):
            pass
    """
    tree = ast.parse(snippet_from_test)
    transformer = MetaclassTransformer()
    new_tree = transformer.visit(tree)
    assert transformer.tree_changed is True
    assert transformer.initial_tree is not new_tree


# Generated at 2022-06-23 22:46:47.934055
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import check_as_expected, run_local_tests

    tests = [
        ('class A(B): pass', 'class A(_py_backwards_six_withmetaclass(B)): pass'),
        ('class A(metaclass=B): pass', 'class A(_py_backwards_six_withmetaclass(B)): pass'),
    ]
    check_as_expected(tests, MetaclassTransformer)
    run_local_tests()



# Generated at 2022-06-23 22:46:51.228502
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    text = snippet.src('''
        class A(B, C, metaclass=D):
            pass
    ''')

    module = ast.parse(text)
    module = MetaclassTransformer(module, (2, 7)).visit(module)

    assert snippet.dst(module) == snippet.dst(six_import) + snippet.dst(class_bases)

# Generated at 2022-06-23 22:46:53.191747
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..fix import fix_code
    from ..fixes.six_import import six_import
    assert (
        fix_code('import six')
        ==
        six_import.get_fixed_code()
    )

# Generated at 2022-06-23 22:47:02.616029
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast as pyast
    from ..utils.source_generator import SourceGenerator
    SourceGenerator.set_mode('exec')
    class_body = [
        pyast.FunctionDef(name='__init__',
                          args=pyast.arguments(args=[],
                                               defaults=[],
                                               vararg=None,
                                               kwonlyargs=[],
                                               kw_defaults=[],
                                               kwarg=None,
                                               posonlyargs=[]),
                          body=[],
                          decorator_list=[],
                          returns=None)]

# Generated at 2022-06-23 22:47:13.957722
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse("""class Foo(metaclass=Bar):\n    pass""")
    trans = MetaclassTransformer()
    trans.visit(node)

# Generated at 2022-06-23 22:47:19.149729
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    mc_trans = MetaclassTransformer()
    node = ast.parse("""
             class A(metaclass=B):
                 pass
             """)
    mc_trans.visit(node)
    expected = ast.parse("""
                     class A(_py_backwards_six_with_metaclass(B)):
                         pass
                     """)
    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-23 22:47:20.667923
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer().initialize()


# Generated at 2022-06-23 22:47:28.627160
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import transform, assert_equal, assert_node

    class_def = """
    class A(metaclass=B):
        pass
    """
    expected_class_def = """
    import six
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    class_def = ast.parse(class_def).body[0]
    expected_class_def = ast.parse(expected_class_def).body[0]

    assert_equal(MetaclassTransformer().visit_ClassDef(class_def), expected_class_def)
    assert_node(transform(class_def, MetaclassTransformer), expected_class_def)