

# Generated at 2022-06-23 22:37:34.525723
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    mt = MetaclassTransformer()


# Generated at 2022-06-23 22:37:40.309512
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = ("""
        class A(metaclass=B):
            pass
        """)
    result = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    assert MetaclassTransformer().run_single(source) == result


# Generated at 2022-06-23 22:37:43.526922
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class DummyNode(ast.AST):
        pass

    dummy_node = DummyNode()
    node = ast.Module([dummy_node])
    transformer = MetaclassTransformer()
    assert transformer.visit(node) == node


# Generated at 2022-06-23 22:37:46.215406
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import parse
    from ..transformers.six_withmetaclass import MetaclassTransformer


# Generated at 2022-06-23 22:37:56.776289
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class Test(unittest.TestCase):
        def test(self):
            module = ast.parse('class A(metaclass=B): pass')
            new_module = MetaclassTransformer().visit(module)
            transformed = ast.dump(new_module)

# Generated at 2022-06-23 22:38:07.436221
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from . import test_py_ast
    import py_backwards.nodes.python as python

    # @Test: Modify an ast
    # @Given: ast
    mod, = test_py_ast.parse_snippet(
        'class I(metaclass=type):',
    )

    # @When: apply MetaclassTransformer()
    t = MetaclassTransformer()
    mod = t.visit(mod)

    # @Then: class I is replaced with I = _py_backwards_six_with_metaclass(type, I)
    assert isinstance(mod, ast.Module)
    assert len(mod.body) == 1
    assert isinstance(mod.body[0], ast.ClassDef)
    assert mod.body[0].name == 'I'

    # @And: ast

# Generated at 2022-06-23 22:38:08.502499
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:38:13.980282
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class_in = ast.ClassDef(name='A',
                            bases=[],
                            keywords=[],
                            body=[],
                            decorator_list=[],
                            lineno=1,
                            col_offset=2)
    module_in = ast.Module(body=[class_in])
    out = MetaclassTransformer().visit(module_in)
    expected = six_import.get_ast() + module_in
    assert out == expected


# Generated at 2022-06-23 22:38:21.149596
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .transformer import transform
    src = "class A(metaclass=type):\n    pass"
    dest = transform(src, MetaclassTransformer)
    if dest != "from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(type)):\n    pass\n":
        raise RuntimeError(f"MetaclassTransformer transform error.\n"
                           f"src: {src}\n"
                           f"dest: {dest}\n")
    return True

# Generated at 2022-06-23 22:38:23.478954
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    print("===== test_MetaclassTransformer =====")

# Generated at 2022-06-23 22:38:24.816554
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()
    assert transformer.tree_changed is False


# Generated at 2022-06-23 22:38:26.395320
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .base import BaseNodeTest
    from ..utils.test_utils import assert_node_equal


# Generated at 2022-06-23 22:38:37.555198
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class MetaclassTransformerTest(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.ast = ast.parse('class A(metaclass=B): pass')
            self.metaclass_transformer = MetaclassTransformer()

        def test_transform(self):
            result = self.metaclass_transformer.visit(self.ast)
            expected = ast.parse("""
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A(_py_backwards_six_withmetaclass(B)):
                pass
            """)

# Generated at 2022-06-23 22:38:45.042564
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.ClassDef(name='Thing',
                        keywords=[ast.arg('metaclass',
                                          ast.Name(id='Meta'))],
                        bases=[ast.Name(id='Foo')],
                        body=[ast.Pass()])
    transformer = MetaclassTransformer()
    node = transformer.visit(node)

    assert isinstance(node, ast.ClassDef)
    assert node.name == 'Thing'
    assert node.keywords == []

    assert isinstance(node.bases[0], ast.Call)
    assert isinstance(node.bases[0].func, ast.Name)
    assert node.bases[0].func.id == '_py_backwards_six_withmetaclass'


# Generated at 2022-06-23 22:38:48.404263
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # import it for coverage
    from py_backwards.transformers.metaclass import MetaclassTransformer
    class MyTestTransformer(MetaclassTransformer):
        pass
    assert hasattr(MyTestTransformer, 'visit_Module')

# Generated at 2022-06-23 22:38:59.480526
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Arrange
    mt = MetaclassTransformer()
    mt._tree_changed = False
    classbases = ast.ClassDef(
        name='B',
        bases=[],
        keywords=[],
        body=[],
        decorator_list=[]
    )
    node = ast.ClassDef(
        name='A',
        bases=[],
        keywords=[ast.keyword(arg='metaclass', value=classbases)],
        body=[],
        decorator_list=[]
    )


# Generated at 2022-06-23 22:39:00.586826
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:39:01.326164
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:39:08.294547
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from textwrap import dedent
    code = dedent("""
    class A(metaclass=B):
        pass
    """)
    x = compile(code, '<string>', 'exec', ast.PyCF_ONLY_AST)
    assert isinstance(x, ast.Module)
    mt = MetaclassTransformer()
    mt.visit(x)
    assert x != compile(code, '<string>', 'exec', ast.PyCF_ONLY_AST)


# Generated at 2022-06-23 22:39:09.290767
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    MetaclassTransformer(None).visit(None)

# Generated at 2022-06-23 22:39:16.535772
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    module = ast.parse("""
    class Bar(metaclass=Foo):
        pass
    """)
    MetaclassTransformer().visit(module)


# Generated at 2022-06-23 22:39:20.829411
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()
    with snippet.open(snippet.path_to_data('source.py')) as tree:
        transformer.visit(tree)
        with snippet.open(snippet.path_to_data('target.py')) as target_tree:
            print(ast.dump(tree))
            print(ast.dump(target_tree))
            assert ast.dump(tree) == ast.dump(target_tree)

# Generated at 2022-06-23 22:39:21.718811
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast as _ast

# Generated at 2022-06-23 22:39:26.712649
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typing import List
    from .. import base
    from typed_ast import ast3 as ast

    class Analyzer(base.BaseNodeTransformer):
        def visit_Name(self, node: ast.Name) -> ast.Name:
            if node.id == 'a':
                self._tree_changed = True
            return node

    code = '''class a(metaclass=b):
    pass
    '''
    tree = ast.parse(code)
    transformed_tree = MetaclassTransformer().visit(tree)

# Generated at 2022-06-23 22:39:34.079779
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

    class A:
        pass

    class B(metaclass=A):
        pass

    target = ast.parse(
        """
        class B(_py_backwards_six_with_metaclass(A)):
            pass
        """.strip())

    tree = ast.parse("class B(metaclass=A):\n    pass")
    visitor = MetaclassTransformer()
    visitor.visit(tree)
    assert ast.dump(tree) == ast.dump(target)



# Generated at 2022-06-23 22:39:41.834795
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    module = ast.parse("class A(metaclass=B):\n  pass")
    MetaclassTransformer(module).visit(module)
    assert 'from six import with_metaclass as _py_backwards_six_withmetaclass' in ast.unparse(module)
    classdef = module.body[1]
    assert isinstance(classdef, ast.ClassDef)
    assert isinstance(classdef.bases[0], ast.Call)
    assert isinstance(classdef.bases[0].func, ast.Attribute)
    assert classdef.bases[0].func.attr == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-23 22:39:43.359398
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:39:47.259676
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("""class A(metaclass=B):pass""")
    node = MetaclassTransformer().visit(node)

# Generated at 2022-06-23 22:39:52.952599
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    source = dedent('''
    class MyClass(metaclass=MyMetaclass,
                  x=1,
                  ):
        pass
    ''')
    expected = dedent('''
    class MyClass(_py_backwards_six_with_metaclass(MyMetaclass, object)):
        pass
    ''')
    # When
    result = MetaclassTransformer().visit(ast.parse(source))
    # Then
    assert ast.dump(result) == ast.dump(ast.parse(expected))


# Generated at 2022-06-23 22:39:53.578970
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:40:00.313450
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from . import parse_ast
    from ..utils.tree import ast_equal, pretty_ast
    from ..utils.fixer import TestCase

    class TestMetaclassTransformer(TestCase):
        TRANSFORMER = MetaclassTransformer

        def test_metaclass(self):
            tree = parse_ast("""
                class A(object):
                    pass
                """)

            new_tree = self.TRANSFORMER(tree).visit(tree)

            expected = parse_ast("""
            from six import with_metaclass as _py_backwards_six_withmetaclass

            class A(_py_backwards_six_withmetaclass(object)):
                pass
            """)

            assert ast_equal(expected, new_tree)



# Generated at 2022-06-23 22:40:03.044697
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import dump
    from typed_ast.ast3 import ClassDef
    from typed_ast.ast3 import Module


# Generated at 2022-06-23 22:40:12.979846
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = """class A(metaclass=B): pass"""
    tree = ast.parse(source)
    expected_ast = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)): pass
    """
    expected_tree = ast.parse(expected_ast)
    transformer = MetaclassTransformer()
    tree = transformer.visit(tree)
    ast.fix_missing_locations(tree)
    print(ast.dump(tree))
    assert ast.dump(tree) == ast.dump(expected_tree)
    assert transformer._tree_changed == True
    assert transformer.has_changed() == True

# Generated at 2022-06-23 22:40:18.243789
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .transformer_test_case import TransformerTestCase, ast

    source = """
        class A(metaclass=B):
            pass
        """
    expected = """
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    node = ast.parse(source)
    node = MetaclassTransformer().visit(node)
    node = MetaclassTransformer().visit(node)
    TransformerTestCase.assert_source(node, expected)



# Generated at 2022-06-23 22:40:24.876947
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.test import transform
    assert transform(MetaclassTransformer, 'class A(metaclass=B): pass') == 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass\n'
    assert transform(MetaclassTransformer, 'class A(object, metaclass=B): pass') == 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B), object):\n    pass\n'

# Generated at 2022-06-23 22:40:35.737198
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .base import NodeTest

# Generated at 2022-06-23 22:40:43.409244
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import unittest

    from typed_ast import ast3 as ast

    class Test(unittest.TestCase):
        def test_basic(self):
            source = """
            class A:
                pass
            """
            root = ast.parse(source)
            self.assertEqual(None, MetaclassTransformer().visit(root))
            self.assertEqual(source, compile(root, '', 'exec').strip())

        def test_with_metaclass(self):
            source = """
            class A(metaclass=B):
                pass
            """
            root = ast.parse(source)
            MetaclassTransformer().visit(root)

# Generated at 2022-06-23 22:40:48.219665
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import make_module
    from ..utils.sample_code import metaclass_example
    module = make_module(metaclass_example)
    transformer = MetaclassTransformer()
    transformer.visit(module)
    result = transformer.revert(module)
    assert result == metaclass_example

# Generated at 2022-06-23 22:40:53.846212
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = "class A(metaclass=B): pass"
    tree = ast.parse(source)
    result = MetaclassTransformer().visit(tree)
    expected = ast.parse("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-23 22:41:00.474321
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .test_utils import assert_equal_source
    from .test_utils import assert_tree_unchanged

    from ... import ast_ as ast
    from ... import pygram
    from ..transformer.py2 import Py2Transformer

    # given
    class_def = ast.ClassDef(name='A', bases=[ast.Name(id='object', ctx=ast.Load())],
                             body=[ast.Pass()],
                             keywords=[ast.Keyword(arg='metaclass',
                                                   value=ast.Name(id='B', ctx=ast.Load()))])

    tree = ast.Module(
        body=[class_def],
        type_ignores=[],
        ctx=ast.Load(),
    )

    # when
    node = MetaclassTransformer().visit(tree)
   

# Generated at 2022-06-23 22:41:01.860869
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:41:02.472020
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    pass

# Generated at 2022-06-23 22:41:03.426849
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:41:05.034677
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:41:14.674506
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import parse
    from textwrap import dedent

    source = dedent('''\
    class A(B):
        pass
    class C(metaclass=D):
        pass
    ''')
    node = parse(source)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    target = dedent('''\
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(B):
        pass


    class C(_py_backwards_six_withmetaclass(D)):
        pass
    ''')
    assert transformer.get_updated_source() == target

# Generated at 2022-06-23 22:41:21.704632
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_code_equal

    # Tests for code.
    assert_code_equal(
        '''
        class A(metaclass=B):
            pass
        ''',
        '''
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        '''
    )
    # Test for comments.
    assert_code_equal(
        '''
        class A(metaclass=B):
            pass
        ''',
        '''
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        '''
    )

# Generated at 2022-06-23 22:41:27.506281
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .test_utils import make_test, round_trip
    from ..utils.tree import code
    from .six_one import six_one
    from .six_two import six_two


# Generated at 2022-06-23 22:41:31.969289
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import transform_and_compare_ast
    transform_and_compare_ast(MetaclassTransformer,
                              'from six import with_metaclass',
                              'from six import with_metaclass as _py_backwards_six_withmetaclass')


# Generated at 2022-06-23 22:41:32.885029
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:41:39.449083
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from textwrap import dedent
    import typed_ast.ast3 as ast
    from ..utils.source import Source
    from ..utils.snippet import snippet
    class_def_src = snippet(dedent('''\
        class A(metaclass=B):
            pass
    ''')).get_body()[0]
    expected_result = snippet(dedent('''\
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')).get_body()[0]
    transformer = MetaclassTransformer()
    assert transformer.visit(class_def_src) == expected_result

# Generated at 2022-06-23 22:41:40.947429
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ast_tools.passes.unparse import Unparser

# Generated at 2022-06-23 22:41:42.110509
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

# Generated at 2022-06-23 22:41:42.946103
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    MetaclassTransformer()

# Generated at 2022-06-23 22:41:45.011694
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    src = """class A(metaclass=B):\n    pass"""

# Generated at 2022-06-23 22:41:50.222285
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class MyVisitor(ast.NodeVisitor):
        nodes = []

        def visit(self, node):
            print("%s: %s" % (node.__class__.__name__, ast.dump(node)))
            self.nodes.append(node)
            super(MyVisitor, self).visit(node)


# Generated at 2022-06-23 22:41:51.154611
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:41:59.838253
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.test_utils import transform_and_compare
    transform_and_compare(MetaclassTransformer, '2to3', '''
        class A(metaclass=B):
            pass
    ''')
    transform_and_compare(MetaclassTransformer, '2to3', '''
        class A(B, metaclass=C):
            pass
    ''')
    transform_and_compare(MetaclassTransformer, '2to3', '''
        class A(B, C, metaclass=D):
            pass
    ''')
    transform_and_compare(MetaclassTransformer, '2to3', '''
        class A(B, C, D, metaclass=E):
            pass
    ''')

# Generated at 2022-06-23 22:42:00.706448
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:42:08.238963
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..context import Context
    from ..node_visitor import run_transformers
    
    ctx = Context()
    ctx.register_transformer(MetaclassTransformer)
    ctx.tree = ast.parse(
        '''class A(metaclass=B):
            pass
        ''')
    run_transformers(ctx)
    fixed = ast.dump(ctx.tree)
    

# Generated at 2022-06-23 22:42:17.436051
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import round_trip
    from ..error import InvalidSourceError

    with pytest.raises(InvalidSourceError):
        MetaclassTransformer.check_node(six_import.get_tree())

    with pytest.raises(InvalidSourceError):
        MetaclassTransformer.check_node(class_bases.get_tree())

    with pytest.raises(InvalidSourceError):
        MetaclassTransformer.check_node(class_bases.get_trees())

    src = '''class Foo(metaclass=Bar): pass'''

# Generated at 2022-06-23 22:42:22.750056
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from typed_ast.transforms.six_imports import MetaclassTransformer

    source = '''class A(metaclass=B):
                pass'''
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)

# Generated at 2022-06-23 22:42:24.910939
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """
    Compiles:
        class A(metaclass=B):
            pass
    To:
        class A(_py_backwards_six_with_metaclass(B))
    """
    python_version = (2, 7)

# Generated at 2022-06-23 22:42:29.784140
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import check_transformation
    code = '''
        class A(metaclass=B):
            pass
    '''
    expected = '''
        import six
        class A(six.with_metaclass(B)):
            pass
    '''
    check_transformation(MetaclassTransformer, code, expected)

# Generated at 2022-06-23 22:42:41.066394
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import compile
    from os import path
    from py_backwards.transformers.base import BaseNodeTransformer
    import ast

    with open(path.join(path.dirname(__file__), 'test_classes', 'metaclass.py')) as f:
        tree = compile(f.read(), path.join(path.dirname(__file__), 'test_classes', 'metaclass.py'), 'exec', ast.PyCF_ONLY_AST)

    test = MetaclassTransformer()
    test.visit(tree)
    assert BaseNodeTransformer.get_code(test.tree) == BaseNodeTransformer.get_code(tree)  # no change


# Generated at 2022-06-23 22:42:46.722804
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse("""\
    class Base(object):
        pass
    """)
    MetaclassTransformer().visit(module)

    # We expect the following AST tree:
    expected_tree = ast.parse("""\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class Base(_py_backwards_six_withmetaclass(object, *[])):
        pass
    """)

    assert expected_tree == module


# Generated at 2022-06-23 22:42:52.078789
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from asttokens import ASTTokens
    from ..utils import get_node
    result = []
    text = '''
        class A(metaclass=B):
            pass
    '''
    for module in MetaclassTransformer.run([text]):
        atok = ASTTokens(text, parse=True, tree=module)
        result.append(atok.get_text())
    expected = 'from six import with_metaclass as _py_backwards_six_withmetaclass\n' \
               'class A(_py_backwards_six_withmetaclass(B))'
    assert result == [expected]


# Generated at 2022-06-23 22:42:57.421911
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    metaclass_ast = ast.parse("""
    @staticmethod
    class Meta(type):
        pass
    
    class A(metaclass=Meta):
        pass
    """)
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(metaclass_ast)
    assert ast.dump(metaclass_ast) == six_import + class_bases + """
    class _py_backwards_six_withmetaclass(_py_backwards_six_withmetaclass, type):
        pass

    class A(_py_backwards_six_withmetaclass(Meta, _py_backwards_six_withmetaclass)):
        pass
    """



# Generated at 2022-06-23 22:43:05.095388
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils import get_ast
    from ..utils.compare_ast import compare_ast
    source = '''class A(metaclass=B):\n    pass'''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    tree = get_ast(source)
    transformer = MetaclassTransformer()
    new_tree = transformer.visit(tree)
    assert transformer.tree_changed is True
    compare_ast(expected, new_tree)

# Generated at 2022-06-23 22:43:06.217499
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:43:15.197355
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3
    class_def = ast3.ClassDef(name='Name', 
                              keywords=[ast3.keyword(arg='metaclass', value=ast3.Name(id='Foo', ctx=ast3.Load()))],
                              bases=[ast3.Name(id='object', ctx=ast3.Load())],
                              body=[],
                              decorator_list=[],
                              lineno=1,
                              col_offset=1,
                              end_lineno=3,
                              end_col_offset=1)
    transformer = MetaclassTransformer([])
    result = transformer.visit_ClassDef(class_def)

# Generated at 2022-06-23 22:43:23.857984
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # From: class Test(Exception, metaclass=type):
    # To:   class Test(_py_backwards_six_with_metaclass(type, Exception)):
    class_def_ast = ast.ClassDef(
        name='Test',
        bases=[
            ast.Name(id='Exception', ctx=ast.Load())
        ],
        keywords=[
            ast.keyword(arg='metaclass', value=ast.Name(id='type', ctx=ast.Load()))
        ]
    )
    trans = MetaclassTransformer()
    class_def_ast = trans.visit(class_def_ast)
    assert type(class_def_ast.bases[0]) == ast.Call

# Generated at 2022-06-23 22:43:32.677908
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast27 as ast

    code = snippet.format_code(
        """
        class A(metaclass=B):
            pass
        """
    )
    tree = ast.parse(code)
    node = tree.body[0]
    expected = snippet.format_code(
        """
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    )
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed is True
    expected_tree = ast.parse(expected)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 22:43:41.607836
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class ClassDef(ast.ClassDef):
        def __init__(self):
            super().__init__(name="test", bases=[], keywords=[], body=[], decorator_list=[])

    node = ClassDef()

    # no keywords
    m = MetaclassTransformer()
    n = m.visit_ClassDef(node)
    assert not n.keywords
    assert not n.bases

    # keyword present
    node.keywords = [ast.keyword(arg="metaclass", value=ast.Name("test", ast.Load()))]
    n = m.visit_ClassDef(node)
    assert not n.keywords
    assert len(n.bases) == 1



# Generated at 2022-06-23 22:43:51.246706
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .utils import assert_equal_with_printing
    from typed_ast import ast3 as ast

    class DummyTransformer(BaseNodeTransformer):
        _tree_changed = False

    transformer = MetaclassTransformer(DummyTransformer())
    class_def_node = ast.parse('class A(metaclass=C): pass').body[0]
    result = transformer.visit_ClassDef(class_def_node)
    expected = ast.parse('class A(_py_backwards_six_withmetaclass(C)): pass')
    assert_equal_with_printing(result, expected.body[0])

# Generated at 2022-06-23 22:43:53.158829
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    expected_imports = six_import.get_body()

# Generated at 2022-06-23 22:44:04.078905
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    r'''
    >>> from typed_ast import ast3
    >>> from typed_ast.ast3 import parse
    >>> from py_backwards.transformers.metaclass import MetaclassTransformer
    >>> source = r'''

# Generated at 2022-06-23 22:44:13.237862
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    def assert_result(original, expected):
        from ..utils import parse_ast

        class_ob = parse_ast(original).body[0]
        assert isinstance(class_ob, ast.ClassDef)

        t = MetaclassTransformer()
        result = t.visit_ClassDef(class_ob)
        assert isinstance(result, ast.ClassDef)

        from ..utils.snippet import compare_asts
        compare_asts(expected, result)

    assert_result("""
        class A:
            pass
    """, """
    class A:
        pass
    """)

    assert_result("""
        class A(type):
            pass
    """, """
    class A(type):
        pass
    """)


# Generated at 2022-06-23 22:44:20.668698
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    src = '''
        class Test(object):
            pass

        class Test2(object, metaclass=type):
            pass
    '''

    expected = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class Test(object):
            pass

        class Test2(_py_backwards_six_withmetaclass(type)):
            pass
    '''

    t = MetaclassTransformer()
    t.visit(ast.parse(src))
    assert ast.dump(t.root) == expected

# Generated at 2022-06-23 22:44:28.066288
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    foo = ast.parse('class A(metaclass=type): pass')
    tm = MetaclassTransformer()
    tm.visit(foo)
    assert ast.dump(foo) == "Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0), ClassDef(name='A', bases=[_py_backwards_six_withmetaclass(type)], keywords=[], body=[], decorator_list=[])])"

# Generated at 2022-06-23 22:44:31.010224
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = six_import.get_body()[0]
    compiled = compile(code.body[0], '', 'exec')
    assert eval(compiled) == six.with_metaclass

# Generated at 2022-06-23 22:44:33.970224
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer(None).target == (2, 7)
    assert not MetaclassTransformer(None).dependencies
    assert isinstance(MetaclassTransformer(None), (BaseNodeTransformer,))

# Generated at 2022-06-23 22:44:38.324465
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class Test(object):
        def test_metaclass(self):
            class A(metaclass=type):
                pass

    a = ast.parse(inspect.getsource(Test))
    v = MetaclassTransformer()
    v.visit(a)
    assert inspect.getsource(Test) == inspect.getsource(a)

# Generated at 2022-06-23 22:44:39.825161
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import compare_ast


# Generated at 2022-06-23 22:44:47.276501
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = six_import.dedent() + """
        def f():
            class Foo(base.bar, metaclass=FooMeta):
                pass
    """
    tree = ast.parse(code)
    compiler = MetaclassTransformer()
    compiler.visit(tree)
    assert compiler.result
    code_expected = six_import.dedent() + """
        def f():
            class Foo(_py_backwards_six_with_metaclass(FooMeta)):
                pass
    """
    assert ast.dump(tree) == ast.dump(ast.parse(code_expected))

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 22:44:56.602040
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = textwrap.dedent("""\
                              from six import with_metaclass
                              class A(metaclass=type):
                                  pass
                               """)
    expect_source = textwrap.dedent("""\
                              from six import with_metaclass as _py_backwards_six_withmetaclass
                              class A(_py_backwards_six_withmetaclass(type, )):
                                  pass
                               """)
    tree = ast.parse(source)
    transformer = MetaclassTransformer()
    result_tree = transformer.visit(tree)
    assert result_tree is not tree
    expect_tree = ast.parse(expect_source)
    assert expect_tree == result_tree

# Generated at 2022-06-23 22:44:57.138338
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class C(metaclass=type): pass

# Generated at 2022-06-23 22:45:07.354449
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    m = ast.parse('class Foo(A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z, metaclass=Baz): pass')
    MetaclassTransformer(m).visit(m)

# Generated at 2022-06-23 22:45:14.772771
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    # --- given ---
    node = ast.parse('class A(metaclass=B):\n    pass')
    transformer = MetaclassTransformer()
    # --- when ---
    transformer.visit(node)
    # --- then ---
    assert transformer._tree_changed is True
    assert astor.to_source(node) == six_import.get_source() + '\n' + \
                                    'class A(_py_backwards_six_withmetaclass(B)):\n' + \
                                    '    pass\n'

# Generated at 2022-06-23 22:45:17.600149
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:45:19.923548
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ...tests.test_transformer import assert_program
    from typed_ast import ast3 as ast

# Generated at 2022-06-23 22:45:30.222460
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Test method visit_ClassDef of class MetaclassTransformer"""
    # Test simple case without any metaclass
    before = dedent('''
    class A:
        pass
    ''')
    after = dedent('''
    class A:
        pass
    ''')
    tree = ast.parse(before)
    expected = ast.parse(after)
    transformer = MetaclassTransformer()
    transformed = transformer.visit(tree)

    assert ast.dump(transformed) == ast.dump(expected)

    # Test simple case with a single metaclass
    before = dedent('''
    class A(metaclass=B):
        pass
    ''')

# Generated at 2022-06-23 22:45:31.423496
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:45:32.852362
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    MetaclassTransformer(ast.parse('class A(metaclass=B): pass')).result

# Generated at 2022-06-23 22:45:37.923236
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert MetaclassTransformer().visit(parse(dedent(
        """
        class A(B, metaclass=C):
            pass
        """,  # noqa E501
        mode='exec'))).body[0].bases[0].value.func.id == '_py_backwards_six_withmetaclass'  # noqa E501

# Generated at 2022-06-23 22:45:47.201662
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

    class TestVisitor(ast.NodeTransformer):
        def visit_Module(self, node):
            node.body.append(ast.Pass())
            node.body.append(ast.Expr(value=ast.Name(id='x', ctx=ast.Load())))
            return node

    class TestTransformer(MetaclassTransformer):
        def visit_Module(self, node):
            return TestVisitor().visit(super(TestTransformer, self).visit_Module(node))

    before = ast.parse('class A(metaclass=B): pass')

# Generated at 2022-06-23 22:45:54.687796
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import ast_util

    code = '''class A(metaclass=B): pass'''
    old_tree = ast.parse(code)
    new_tree = MetaclassTransformer().visit(old_tree)
    new_code = ast_util.get_source(new_tree)

    assert (new_code ==
            "from six import with_metaclass as _py_backwards_six_withmetaclass\n"
            "\n"
            "class A(_py_backwards_six_withmetaclass(B, )):\n"
            "    pass")

# Generated at 2022-06-23 22:45:56.111215
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()

# Generated at 2022-06-23 22:46:04.448615
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse('''class A(metaclass=B):
    pass
    class B(metaclass=object):
        pass
    ''', mode='exec')
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert len(node.body) == 2
    A = node.body[1]
    assert A.bases[0].value.func.id == '_py_backwards_six_withmetaclass'
    assert A.bases[0].value.args[0].id == 'metaclass'
    assert A.bases[0].value.args[1].id == 'B'

# Generated at 2022-06-23 22:46:06.985527
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import textwrap
    module = ast.parse(textwrap.dedent("""
        class A(metaclass=B):
            pass
        """))
    tree = MetaclassTransformer().visit(module)
    assert tree is not None

# Generated at 2022-06-23 22:46:15.648671
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """
    Tests the constructor of class MetaclassTransformer
    """
    assert MetaclassTransformer.__name__ == 'MetaclassTransformer', "Passed"
    assert MetaclassTransformer.__doc__ == """Compiles:
        class A(metaclass=B):
            pass
    To:
        class A(_py_backwards_six_with_metaclass(B))
    
    """, "Passed"
    assert MetaclassTransformer.target == (2, 7), "Passed"
    assert MetaclassTransformer.dependencies == ['six'], "Passed"

# Generated at 2022-06-23 22:46:16.280823
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:46:22.925463
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ...testing.transform import assert_transformed


# Generated at 2022-06-23 22:46:26.461531
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()
    assert transformer.visit(ast.parse('class A(A): pass')) == ast.parse('class A(_py_backwards_six_with_metaclass(A)): pass')

# Generated at 2022-06-23 22:46:35.043639
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typing import Any
    from astrewrite import IdentityASTTransformer
    from ..utils.ast import parse, dumps

    tree = parse("""
    class A(metaclass=B):
        pass
    """)

    MetaclassTransformer(tree).visit(tree)

    class Rewriter(IdentityASTTransformer):
        def __init__(self, *args: Any, **kwargs: Any):
            self.dict = {}

    d = Rewriter(tree)
    d.visit(tree)

    assert dumps(d.dict['_py_backwards_six_with_metaclass']) == '''
    def _py_backwards_six_with_metaclass(meta, base=object, **kwds) :
      '''


# Generated at 2022-06-23 22:46:39.849047
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_utils import make_deep_copy, assert_equal_source
    node = make_deep_copy(ast.parse(
    '''
    class A(metaclass=B):
        pass
    '''))
    node = MetaclassTransformer().visit(node)
    assert_equal_source(
    '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    ''',
    node)

# Generated at 2022-06-23 22:46:41.397497
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.test_utils import assert_equal
    from ..utils.ast_utils import dump_ast, execute_module


# Generated at 2022-06-23 22:46:52.482172
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.test import AstTestCase
    from .. import transforms

    transforms.register(MetaclassTransformer)

    with AstTestCase([MetaclassTransformer]) as test:
        code = 'class A(object): pass'
        test.test(code, code)

        code = '''
            class A(object):
                pass
        '''
        test.test(code, code)

        code = 'class A(metaclass=B): pass'
        expected = 'class A(_py_backwards_six_withmetaclass(B)): pass'
        test.test(code, expected)

        code = '''
            class A(metaclass=B,
                   some_other_thing=None):
                pass
        '''

# Generated at 2022-06-23 22:46:55.581455
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    uut = MetaclassTransformer()
    node = ast.parse('class A(metaclass=B):pass', mode='exec')
    uut.visit(node)
    assert six_import.get_source() + 'class A(_py_backwards_six_withmetaclass(B)):\n    pass' == astunparse.unparse(node)

# Generated at 2022-06-23 22:47:00.036845
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test import assert_snippet
    module = ast.parse("""class A(metaclass=B): pass""")

# Generated at 2022-06-23 22:47:04.556212
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.test_utils import check

    c = '''
        class A(metaclass=B):
            pass
    '''
    c = check(c, MetaclassTransformer)
    assert c == '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    '''



# Generated at 2022-06-23 22:47:05.474527
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:47:06.376254
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:47:07.619694
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:47:14.043383
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast as pyast
    expected_code = six_import.get_source() + class_bases.get_source(
    ) + """class M(object):
    __metaclass__ = _py_backwards_six_withmetaclass(A, *[])
"""
    expected_tree = pyast.parse(expected_code)

# Generated at 2022-06-23 22:47:21.119025
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Simple case
    node = ast.parse("""
        class A(metaclass=B):
            pass
    """)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    result = ast.dump(node, include_attributes=True)
    expected = "Module(body=[ClassDef(name='A', bases=[Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), args=[Name(id='B', ctx=Load())], keywords=[])], body=[Pass()], decorator_list=[], keywords=[])])"
    assert result == expected



# Generated at 2022-06-23 22:47:32.437755
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer

    class ClassDef(ast.ClassDef):
        def __init__(self, *args, **kwargs):
            super(ClassDef, self).__init__(*args, **kwargs)
            self.bases = []

    class Keyword(ast.keyword):
        def __init__(self, *args, **kwargs):
            super(Keyword, self).__init__(*args, **kwargs)
            self.value = 1

    class Keyword2(Keyword):
        def __init__(self, *args, **kwargs):
            super(Keyword2, self).__init__(*args, **kwargs)


# Generated at 2022-06-23 22:47:33.144689
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    MetaclassTransformer()