

# Generated at 2022-06-23 22:37:38.188012
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    if sys.version_info >= (3, 8):
        pytest.skip("The transformation `six.with_metaclass` is only necessary in Python<3.8")
    # We are going to apply the following changes to this code:
    code = \
        """
        class A(B):
            pass
        """
    expected_code = \
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    # This test is to verify the class MetaclassTransformer
    # by comparing the output code with the expected code.
    module_node = ast.parse(code)
    transformer = MetaclassTransformer()

# Generated at 2022-06-23 22:37:44.950684
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    from .. import ast_util
    from ..compat import exec_function
    from ..utils.tree import print_tree
    from .base import BaseTestTransformer
    from .test_six import test_six_import
    from .test_class_bases import test_class_bases

    six_ast, six_exec, six_global_vars = test_six_import()
    test_class_bases_ast, test_class_bases_exec, test_class_bases_global_vars = test_class_bases()

    class TestTransformer(BaseTestTransformer):
        transformer = MetaclassTransformer

        def test_case_1(self):
            source = """
            class A(metaclass=B):
                pass

            """

# Generated at 2022-06-23 22:37:49.892791
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = """class A(metaclass=B):
    pass"""
    expected = """class A(_py_backwards_six_withmetaclass(B)):
    pass"""
    node = ast.parse(code)
    MetaclassTransformer().visit(node)
    assert ast.unparse(node).strip() == expected.strip()

# Generated at 2022-06-23 22:37:57.461863
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()

    class_node = ast.ClassDef(name='A',
                              bases=[],
                              keywords=[ast.keyword(arg='metaclass',
                                                     value=ast.Name(id='B',
                                                                    ctx=ast.Load()))],
                              body=[])

    transformer.visit(class_node)

    # class A(_py_backwards_six_with_metaclass(B))
    assert class_node.bases[0].elts[0].args[0].id == 'B'

# Generated at 2022-06-23 22:38:05.207408
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    print('> test_MetaclassTransformer_visit_Module')
    parse = ast.parse
    six = six_import
    assert (MetaclassTransformer(parse('foo')).visit(parse('foo')).body ==
            six.get_body() + parse('foo').body)
    assert (MetaclassTransformer(parse('class C:pass')).visit(parse('class C:pass')).body ==
            six.get_body() + parse('class C:pass').body)
    print('... OK')



# Generated at 2022-06-23 22:38:10.336402
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3
    from ...utils import load_module
    from ...utils import dump_module
    from ...utils import patch_ast

    test_ast = ast3.parse('class Foo(metaclass=object):\n    pass')
    test_module = load_module(test_ast)

    assert not test_module.six

    with patch_ast(test_module, 'six') as patched:
        patched.MetaclassTransformer().visit(test_ast)
        assert dump_module(test_module) == 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass Foo(_py_backwards_six_withmetaclass(object)):\n    pass\n\n'



# Generated at 2022-06-23 22:38:16.730518
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    transformer = MetaclassTransformer()
    node = ast.parse("class A(metaclass=B): pass")
    result = transformer.visit(node)
    exp = ast.parse("from six import with_metaclass as _py_backwards_six_withmetaclass\n"
                    "class A(_py_backwards_six_withmetaclass(B)): pass")
    assert ast.dump(exp) == ast.dump(result)



# Generated at 2022-06-23 22:38:19.618431
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = """class A(B, C, metaclass=D):
    pass"""

# Generated at 2022-06-23 22:38:27.125190
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # For now, just ensure no crashes.
    transformer = MetaclassTransformer()
    transformer.visit(ast.parse("class A(B): pass"))
    transformer.visit(ast.parse("class A(): pass"))
    transformer.visit(ast.parse("class A(metaclass=B): pass"))
    transformer.visit(ast.parse("""
    class A(B):
        def __init__(self):
            pass
    """))
    transformer.visit(ast.parse("""
    class A(metaclass=B):
        def __init__(self):
            pass
    """))
    transformer.visit(ast.parse("""
    class A(metaclass=B, other=2, other2=3):
        def __init__(self):
            pass
    """))

# Generated at 2022-06-23 22:38:31.953302
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from .utils import get_nodes, get_visitor, get_source
    from .mock_nodes import get_mock_node
    import re

    nodes = get_nodes()
    c_transformer = MetaclassTransformer()
    print('Function: visit_Module of class MetaclassTransformer')
    print('Source:   ' + re.sub('\n', '\n          ', c_transformer._source))
    print('Specific: ' + re.sub('\n', '\n          ', c_transformer._specific_source))

    print('\nExpected AST')
    print_tree(nodes['Module'].body[0])
    print('\nTransformed AST')
    visitor = get_vis

# Generated at 2022-06-23 22:38:40.253638
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:38:42.841162
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_astunparse import unparse

    from .six import inject_six_import


# Generated at 2022-06-23 22:38:49.479381
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    mt = MetaclassTransformer()
    
    # Dumb class, should be ignored
    cls = ast.ClassDef(name='A',
                       bases=[],
                       keywords=[],
                       body=[ast.Pass()],
                       decorator_list=[])
    
    module = ast.Module([cls])
    
    new_module = mt.visit(module)
    assert new_module is not module
    assert new_module.body[0] is cls


# Generated at 2022-06-23 22:39:00.785344
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():

    def t(inp_src, out_src):
        inp = ast.parse(inp_src)
        inp = MetaclassTransformer.run_pipeline(inp)
        out = ast.parse(out_src)

        assert ast.dump(inp) == ast.dump(out)

    t('class A(metaclass=B): pass',
      'from six import with_metaclass as _py_backwards_six_withmetaclass\n'
      'class A(_py_backwards_six_withmetaclass(B, )): pass')


# Generated at 2022-06-23 22:39:11.452486
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import unittest.mock
    import ast as pyast
    import inspect
    class MockParent:
        def __init__(self, tree_changed, name):
            self.tree_changed = tree_changed
            self.name = name
            self.generic_visit = unittest.mock.Mock()
            self.generic_visit.return_value = name

    class MockArguments:
        def __init__(self):
            self.args = []
            self.keywords = []
    class MockMetaclass:
        def __init__(self, attr):
            self.attr = attr
    class MockKeyword:
        def __init__(self, attr, value):
            self.attr = attr
            self.value = value

# Generated at 2022-06-23 22:39:21.928896
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Should correctly handle the case where the class does not have a metaclass
    MetaclassTransformer().generic_visit(ast.parse('class A(object): pass'))
    # Should correctly handle the case where class_bases should be added
    tree = ast.parse('class A(metaclass=type): pass')
    MetaclassTransformer().visit(tree)

# Generated at 2022-06-23 22:39:28.384077
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast.ast3 import Module, ClassDef, Name, Store, Arguments, \
                                 Keyword, NameConstant

    stub_module = Module(body=[ClassDef(name='A')])
    result_module = Module(body=[six_import.get_body()[0], ClassDef(name='A')])

    transformer = MetaclassTransformer()
    module = transformer.visit(stub_module)
    assert equal_ast(module, result_module) is True



# Generated at 2022-06-23 22:39:33.180516
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import textwrap
    from ..utils.compile_and_parse import compile_and_parse

    code = textwrap.dedent('''\
        class A(metaclass=B):
            pass
    ''')
    node = compile_and_parse(code)
    MetaclassTransformer().visit(node)

# Generated at 2022-06-23 22:39:42.093671
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer(): 
    snippet_import = six_import.get_body()
    snippet_bases = class_bases.get_body(metaclass=ast.Name(id='B', ctx=ast.Load()),
                                         bases=ast.List(elts=[ast.Name(id='A', ctx=ast.Load())],
                                                        ctx=ast.Load()))
    expect_class = ast.ClassDef(name='A', 
                                bases=snippet_bases,
                                body=[], 
                                keywords=[],
                                decorator_list=[]
                                )
    expect_module = ast.Module(body=[snippet_import,
                                     expect_class])

# Generated at 2022-06-23 22:39:47.601932
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ast import parse
    from ..utils.codegen import to_source
    node = parse("""class A(metaclass=B): pass""")
    MetaclassTransformer(parse("")).visit(node)

# Generated at 2022-06-23 22:39:48.298678
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:39:52.916900
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    transformer = MetaclassTransformer()

    result = transformer.visit(ast.parse('class A(A): pass'))  # type: ignore
    expected = ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass\n'
                         'class A(A): pass\n')  # type: ignore
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-23 22:39:53.552462
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer()

# Generated at 2022-06-23 22:39:55.767513
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    instance = MetaclassTransformer()
    assert isinstance(instance, BaseNodeTransformer)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 22:40:00.263929
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = """
        class A(metaclass=B):
            pass
        """
    expected_ast = """
    Module(
    body=[
    ImportFrom(
        module='six',
        names=[alias(
            name='with_metaclass',
            asname='_py_backwards_six_withmetaclass')],
        level=0)],
    type_ignores=[])
    """

    source = textwrap.dedent(source)
    expected_ast = textwrap.dedent(expected_ast)
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert astor.to_source(tree) == expected_ast

# Generated at 2022-06-23 22:40:10.832815
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from textwrap import dedent
    from .test_base import BaseNodeTestCase
    from .test_six import six

    code = dedent("""
    from six import with_metaclass
    class A(object, metaclass=with_metaclass):
        pass
    """)

    c = MetaclassTransformer
    self = BaseNodeTestCase(code, c)

    self.assertExactTransform(
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(with_metaclass)):
            pass
        """)


# Generated at 2022-06-23 22:40:18.887018
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .visitor import print_python_2_7
    from ..visitor import wrap_body_in_module
    from ..utils import ast2

    code = """
        class A(B, metaclass=C):
            x = 42
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(C), B):
            x = 42
    """
    m = ast2.parse(code)
    c = wrap_body_in_module(m)
    r = MetaclassTransformer()
    r.visit(c)
    assert print_python_2_7(c) == expected

# Generated at 2022-06-23 22:40:25.312460
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """Test case for method visit_Module of class MetaclassTransformer.
    """
    code = "import typing\nclass A(metaclass=typing.GenericMeta):\n    pass"
    root = ast.parse(code)
    mt = MetaclassTransformer()
    mt.visit(root)
    code_after = compile(root, filename="<ast>", mode="exec")
    ns = {}
    exec(code_after, ns)
    A = ns["A"]
    assert issubclass(A, typing.Generic)
    assert A.__orig_bases__ == (metaclass,)



# Generated at 2022-06-23 22:40:30.832915
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse(dedent('''\
    class A():
        pass
    '''))
    MetaclassTransformer().visit(module)
    assert ast.dump(module) == dedent('''\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A():
        pass
    ''')


# Generated at 2022-06-23 22:40:39.937322
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # No metaclasses
    M = ast.Module
    C = ast.ClassDef
    B = ast.Pass
    s = """
    class A:
        pass
    class B:
        pass
    """
    expected = ast.Module(body=[
        C(name='A', bases=[],
          body=[B()], keywords=[], decorator_list=[],
          lineno=2, col_offset=0),
        C(name='B', bases=[],
          body=[B()], keywords=[], decorator_list=[],
          lineno=4, col_offset=0)
    ], type_ignores=[])
    assert MetaclassTransformer(s).result() == expected
    # Single metaclass
    s = """
    class A(metaclass=B):
        pass
    """

# Generated at 2022-06-23 22:40:47.164659
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source

    code = """
    class A(metaclass=B):
        pass
    """

    tree = ast.parse(code)

    trans = MetaclassTransformer()
    trans.visit(tree)

    assert compile(tree, "<test>", mode="exec")


# Generated at 2022-06-23 22:40:55.081326
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys
    import ast

    if sys.version_info < (3, 0):
        raise RuntimeError("Cannot run tests for Python 2")

    # This example code is from:
    # https://www.python.org/dev/peps/pep-3115/#id3
    class Meta(type):
        pass

    class MyClass(object, metaclass=Meta):
        pass
    assert sys.version_info >= (3, 0)

    node = ast.parse(inspect.getsource(MyClass))
    MetaclassTransformer().visit(node)
    assert node.body[1].bases[0].func.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-23 22:41:02.046094
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    def check(src, dst):
        src = ast.parse(src)
        dst = ast.parse(dst)

        visitor = MetaclassTransformer()
        visitor.visit(src)

        assert ast.dump(dst) == ast.dump(src)  # type: ignore

    yield check, 'class A(object):\n    pass', 'class A(_py_backwards_six_withmetaclass(object)):\n    pass'

# Generated at 2022-06-23 22:41:08.095370
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    module = ast.parse("class Foo(Bar, metaclass=Baz): pass")
    with_metaclass = MetaclassTransformer()
    with_metaclass.visit(module)
    compiled = compile(module, filename="", mode="exec")
    scope = {}
    exec(compiled, scope)
    assert scope['__name__'] == '__main__'
    assert scope['Foo'].__bases__ == (Baz, Bar)

# Generated at 2022-06-23 22:41:16.507505
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = """
        class C(metaclass=M, extra_value=2):
            pass
    """
    target = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class C(_py_backwards_six_withmetaclass(M, *[])):
            pass
    """
    node = ast.parse(source)  # type: ignore
    node = MetaclassTransformer().visit(node)  # type: ignore
    result = compile(node, filename="<ast>", mode="exec")
    code = str(result)
    assert code == target



# Generated at 2022-06-23 22:41:24.438728
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    import io
    import unittest
    import unittest.mock

    sys.path.append('../..')
    from py_backwards.transformers.metaclass import MetaclassTransformer  # noqa: E402
    from py_backwards.transformers.six_import import SixImportTransformer  # noqa: E402
    from py_backwards.utils.snippet import get_source_code  # noqa: E402

    class Mock_get_source_code(unittest.mock.MagicMock):
    # mock method get_source_code of class Snippet
        def __init__(self, *args, **kwargs):
            pass

        def __call__(self, *args, **kwargs):
            return get_source_code(*args, **kwargs)

# Generated at 2022-06-23 22:41:25.379797
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:41:34.349179
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from astunparse import unparse
    from ast import parse
    from ..six import fix_six_import
    from typing import Any, Union

    class A(metaclass=type):
        pass

    tree = parse(__import__('inspect').getsource(A))
    tree = fix_six_import.visit(tree)
    tree = MetaclassTransformer().visit(tree)
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(type)):
        pass
    '''
    assert unparse(tree).strip() == expected.strip()

# Generated at 2022-06-23 22:41:37.831805
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astunparse
    ast.fix_missing_locations(six_import.get_body())
    ast.fix_missing_locations(class_bases.get_body())

# Generated at 2022-06-23 22:41:40.095244
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .. import create_unit_test

    create_unit_test(MetaclassTransformer, '''
        class A(metaclass=B):
            pass
    ''')

# Generated at 2022-06-23 22:41:41.284795
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:41:48.826983
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import parse_to_ast
    from ..utils import ast_to_source

    source = '''
    class A(B, metaclass=C):
        pass
    class B(N, metaclass=C):
        pass
    '''
    AST = parse_to_ast(source)
    expected = parse_to_ast('''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(C)):
        pass
    class B(_py_backwards_six_withmetaclass(C)):
        pass
    ''')

    transformer = MetaclassTransformer()
    res = transformer.visit_Module(AST)
    assert ast_to_source(res) == ast_to

# Generated at 2022-06-23 22:41:57.983190
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node_ = ast.parse(
        "class A(metaclass=B):\n"
        "  pass")
    node_.body.append(ast.Pass())
    node_.body[1].lineno = 2
    node_.body[1].col_offset = 6

    node = MetaclassTransformer().visit(node_)
    assert node.body[0].lineno == 1
    assert node.body[0].col_offset == 1
    assert ast.dump(node.body[0]) == (
        "ImportFrom(module='six', names=[alias(name='with_metaclass', "
        "asname='_py_backwards_six_withmetaclass')], level=0)")
    assert node.body[1].lineno == 2
    assert node.body[1].col_offset == 6

# Generated at 2022-06-23 22:42:04.358941
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    node = ast.ClassDef(name='Test',
                        bases=[],
                        keywords=[ast.keyword(arg='meta', value=ast.Num(n=1))],
                        body=[],
                        decorator_list=[])

    # When
    transformer = MetaclassTransformer(tree=None)
    result = transformer.visit(node=node)

    # Then
    assert isinstance(result.bases[0], ast.Call)
    assert ast.dump(result.bases[0].func) == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-23 22:42:15.089805
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Test simple case of class definition with metaclass
    node = ast.parse('class A(object, metaclass=B): pass').body[0]
    t = MetaclassTransformer()
    t.visit(node)
    assert isinstance(node, ast.ClassDef)
    assert isinstance(node.bases[0], ast.Call)
    assert isinstance(node.bases[0].func, ast.Name)
    assert node.bases[0].func.id == '_py_backwards_six_with_metaclass'
    assert node.bases[0].args[0].id == 'B'
    assert isinstance(node.bases[0].args[1], ast.Tuple)

# Generated at 2022-06-23 22:42:19.137172
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = dedent("""
        class A(metaclass=B):
            pass
    """)
    expected = dedent("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B))
            pass
    """)
    assert MetaclassTransformer().transform(code) == expected

# Generated at 2022-06-23 22:42:25.949001
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = '''
    class A(metaclass=B):
        pass
    '''
    import sys
    import typed_ast.ast3 as ast
    from ..utils.ast_compat import parse_module
    from ..utils.representation import dump_ast
    from .base import BaseNodeTransformer

    tree = parse_module(source)
    expected_tree = parse_module('''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    ''')

    transformer = MetaclassTransformer([], [sys.version_info])
    tree = transformer.visit(tree)
    print(dump_ast(tree))
    assert dump_ast(tree) == dump_ast

# Generated at 2022-06-23 22:42:34.125616
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = """
    class A(metaclass=B):
        pass
    """
    tree = ast.parse(code)

    transformer = MetaclassTransformer()
    transformer.visit(tree)

    expected_code = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    expected_tree = ast.parse(expected_code)
    assert ast.dump(tree) == ast.dump(expected_tree)



# Generated at 2022-06-23 22:42:35.510756
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-23 22:42:40.115778
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ...tests.lib import parse

    node = parse("class A(metaclass=B):\n    pass\n", mode='exec')
    transformer = MetaclassTransformer()
    transformer.visit(node)
    assert transformer._tree_changed == True



# Generated at 2022-06-23 22:42:46.188947
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import make_tree
    from .base import to_source

    make_mock_modules = lambda: {'six': 'mock'}
    node = ast.parse("""class A(metaclass=B):
        pass""")

    transformer = MetaclassTransformer(make_tree(node))
    transformer(make_modules=make_mock_modules)


# Generated at 2022-06-23 22:42:50.570052
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.test_utils import assert_node_equal
    from ..utils.test_utils import parse_and_transform
    node1 = ast.parse('class A(B):\n    pass')
    node2 = ast.parse('class A(B, C):\n    pass')
    node1 = parse_and_transform(node1, MetaclassTransformer)
    node2 = parse_and_transform(node2, MetaclassTransformer)
    assert_node_equal(node1, node2)

# Generated at 2022-06-23 22:42:56.175605
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.test_utils import transform, transform_from_section
    from ..utils.test_resources import get_test_resource_path

    with open(get_test_resource_path('backports_python_3.0.txt')) as fp:
        transform_from_section('python2.7', MetaclassTransformer, fp)


# Generated at 2022-06-23 22:43:02.899258
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.source import source_to_node
    from ..utils.compare import compare_source

    tree = source_to_node("""
        class A(metaclass=B):
            pass
    """)

    node = MetaclassTransformer().visit(tree)  # type: ignore
    assert compare_source(node, """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)



# Generated at 2022-06-23 22:43:08.588636
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse("class A(metaclass=B): pass")
    assert repr(MetaclassTransformer.run(module)) == repr(ast.parse("""\
from six import with_metaclass as _py_backwards_six_withmetaclass
_py_backwards_six_withmetaclass(B, *()).__name__ = 'A'\
"""))



# Generated at 2022-06-23 22:43:09.615308
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor


# Generated at 2022-06-23 22:43:17.904990
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..helpers import eval_stmts

    # We need to set up a fake globals dict to test eval_stmts
    fake_globals = {'six': six_import.get_module()}
    fake_globals['_py_backwards_six_with_metaclass'] = fake_globals['six'].with_metaclass

    f = MetaclassTransformer()
    tree = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    assert f.visit(tree)  # should not raise an error

    f = MetaclassTransformer()
    tree = ast.parse("""
    class A(B):
        pass
    """)
    assert f.visit(tree)  #

# Generated at 2022-06-23 22:43:22.948856
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..typed_ast import ast3
    from .base import BaseTestTransformer
    class TestMetaclassTransformer(BaseTestTransformer):
        transformer = MetaclassTransformer
        method = 'visit_ClassDef'
        target = (2, 7)
        dependencies = ['six']
        expected_dependencies = {'six'}
        expected_cache = {}

    # Tests
    TestMetaclassTransformer.generate_unit_tests()

# Generated at 2022-06-23 22:43:26.604326
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    #import typed_ast.ast3
    src = '''class A(metaclass=B):\n    pass'''
    node = ast.parse(src)
    res = MetaclassTransformer().visit(node) # type: ignore

# Generated at 2022-06-23 22:43:27.218041
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:43:34.882961
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    source = '''
    class Foo(metaclass=bar.Baz):
        pass
    '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class Foo(_py_backwards_six_withmetaclass(bar.Baz))
        pass
    '''

    tree = ast.parse(source)
    t = MetaclassTransformer()
    t.visit(tree)
    result = astor.to_source(t.visit(tree))
    assert result == expected

# Generated at 2022-06-23 22:43:36.053893
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # TODO: define a test
    pass


# Generated at 2022-06-23 22:43:37.452256
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 22:43:38.878910
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

# Generated at 2022-06-23 22:43:46.063497
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.tree import ast_from_str, ast_to_str

    # For using the class MetaclassTransformer
    from .utils import UnitTestInterface
    from .visitors import TypeCheckMixin

    # Compile test class
    src = """
    class SomeClass(metaclass=type):
        def __init__(self):
            pass
    """
    tree = ast_from_str(src)
    tree = UnitTestInterface().visit(tree)
    tree = TypeCheckMixin().visit(tree)
    tree = MetaclassTransformer().visit(tree)

# Generated at 2022-06-23 22:43:48.539282
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor


# Generated at 2022-06-23 22:43:54.538038
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class TestNodeTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            return node

    node = ast.parse('''
        class A(metaclass=object):
            pass
    
        class B(metaclass=object, object):
            def __init__(self):
                print(A)
    ''')
    node = MetaclassTransformer(TestNodeTransformer()).visit(node)
    print(ast.dump(node))

# Generated at 2022-06-23 22:44:04.974501
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ... import transform
    from ..ast_utils import dump_ast

    src = '''
        
        class A(metaclass=B):
            pass
        
        
        class C(object, metaclass=D):
            def __init__(self):
                pass'''
    expected = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        
        
        class C(object, _py_backwards_six_withmetaclass(D)):
            def __init__(self):
                pass'''
    actual = transform(MetaclassTransformer, src)
    print(expected)
    dump_ast.dump_ast(expected)
    print

# Generated at 2022-06-23 22:44:12.854195
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from py_mina.test.utils import make_test, run_test, compare_ast
    make_test(MetaclassTransformer, 'with_metaclass', """\
        class A(metaclass=B):
            pass
    """)

    make_test(MetaclassTransformer, 'no_metaclass', """\
        class A():
            pass
    """)

    make_test(MetaclassTransformer, 'multiple_bases', """\
        class A(B, metaclass=C):
            pass
    """)

    make_test(MetaclassTransformer, 'with_kwargs', """\
        class A(B, metaclass=C, **kwargs):
            pass
    """)

    run_test(compare_ast)

# Generated at 2022-06-23 22:44:16.063589
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = """
    class Meta(type):
        pass

    class A(metaclass=Meta):
        pass
    """
    tree = ast.parse(code)
    t = MetaclassTransformer()
    t.visit(tree)
    expected = compile(t._new_src, '<string>', 'exec')
    exec(expected)

# Generated at 2022-06-23 22:44:16.665850
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    MetaclassTransformer()

# Generated at 2022-06-23 22:44:18.503760
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    t = MetaclassTransformer()
    node = ast.parse('class X(metaclass=type): pass')
    assert isinstance(t.visit_ClassDef(node.body[0]), ast.ClassDef)

# Generated at 2022-06-23 22:44:20.960815
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    sample_input = """class A(object):
    pass"""

# Generated at 2022-06-23 22:44:22.034505
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:44:28.151784
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse("""
        class A(metaclass=B):
            pass
    """)

    transformer = MetaclassTransformer()
    transformer.visit(node)

    expected = ast.parse("""
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B),):
            pass
    """)
    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-23 22:44:38.076812
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    class Meta(type):
        pass

    cls = ast.ClassDef(name='A',
                       bases=[],
                       keywords=[ast.keyword(arg='metaclass',
                                             value=ast.Name(id='Meta',
                                                            ctx=ast.Load())
                                            )],
                       body=[],
                       decorator_list=[],
                       )

    transformer = MetaclassTransformer(None)
    node = transformer.visit(cls)

    assert transformer._tree_changed is True
    assert type(node.bases[0]) == ast.Call
    assert [arg.id for arg in node.bases[0].args] == ['_py_backwards_six_withmetaclass',
                                                      'Meta',
                                                      ]

# Generated at 2022-06-23 22:44:39.962120
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    MetaclassTransformer(None, None).visit(ast.ClassDef(name='MetaclassTransformer'))

# Generated at 2022-06-23 22:44:48.221650
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_tree
    from .base import Context
    from .base import ParseError

    transformer = MetaclassTransformer(Context())

    tree = get_tree('''
    class A(metaclass=B):
        pass
    ''')

    expected = get_tree('''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    ''')

    tree = transformer.visit(tree)
    assert tree == expected

    tree = get_tree('''
    class A(B, metaclass=C):
        pass
    ''')


# Generated at 2022-06-23 22:44:49.479529
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:44:55.687880
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.testing import assert_python_equals

    expected_class_def = """
        class A(_py_backwards_six_withmetaclass(str, [int])):
            pass
    """

    class_def = ast.parse(expected_class_def)
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(class_def)

    assert_python_equals(expected_class_def, class_def)

# Generated at 2022-06-23 22:45:06.497437
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # arrange
    metaclass = ast.Attribute(value=ast.Name(id='abc', ctx=ast.Load()), attr='meta',
                              ctx=ast.Load())
    bases = [ast.Name(id='Base', ctx=ast.Load())]
    node = ast.ClassDef(name='Test', bases=bases, keywords=[ast.keyword(arg='metaclass',
                        value=metaclass)])
    expected = ast.ClassDef(name='Test', bases=class_bases.get_body(metaclass=metaclass,
                        bases=ast.List(elts=bases)), keywords=[])
    transformer = MetaclassTransformer()

    # act
    actual = transformer.visit(node)

    # assert

# Generated at 2022-06-23 22:45:10.618668
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    def _test(code):
        tree = ast.parse(code)
        t = MetaclassTransformer()
        assert t._tree_changed is False
        t.visit(tree)
        assert t._tree_changed is True
        return tree


# Generated at 2022-06-23 22:45:19.043866
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    from typing import List, Union
    from asttokens import ASTTokens
    from typed_ast import ast3 as ast
    from ..utils import context_from_source
    from .transformer import Transformer
    from .nodes import TransformContext, TransformerState
    from .base import BaseNodeTransformer
    from .control_flow import ControlFlowTransformer
    from .strings import StringTransformer
    from .builtins import BuiltinsTransformer
    from .annotations import AnnotationTransformer
    from .import_alias import ImportAliasTransformer
    from .decorators import DecoratorTransformer
    from .metaclass import MetaclassTransformer
    from .convert_for_loop import ConvertForLoopTransformer
    from .raise_to_assert import RaiseToAssertTransformer
    from .raise_from import RaiseFromTrans

# Generated at 2022-06-23 22:45:25.203221
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..parser import parse_string
    from ..transpiler import Transpiler
    code = '''
        class A(metaclass=B):
            pass
    '''
    tree = parse_string(code)
    transpiler = Transpiler()
    tree = transpiler.visit(tree)
    assert tree.body[1].bases[0].func.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-23 22:45:28.939094
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.transform_test import transform_test


# Generated at 2022-06-23 22:45:39.082535
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .test_base import code_transformer_test
    from .test_base import assert_transform

    code_transformer_test(MetaclassTransformer, assert_transform, '''
        class A(metaclass=B):
            pass
    ''', '''
        from six import with_metaclass as _py_backwards_six_withmetaclass


        class A(metaclass=B):
            pass
    ''', 2.7)


# Generated at 2022-06-23 22:45:39.745596
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:45:44.655131
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.coverage import BackwardCompatibleTestCase
    from ..utils.source import source

    class TestMetaclassTransformer(BackwardCompatibleTestCase):
        transformer = MetaclassTransformer

        def test_metaclass(self):
            tree = source('''
            class A(metaclass=B):
                pass
            ''')

            transformed = source('''
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A(_py_backwards_six_withmetaclass(B)):
                pass
            ''')

            self.assertEqualAst(transformed, tree)

# Generated at 2022-06-23 22:45:45.724150
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:45:50.443973
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from ..utils.snippet import snippet
    from ..utils.tree import insert_at
    import six
    MetaclassTransformer.dependencies = ['typed_ast', 'six']
    node = ast. parse("class A(metaclass=B): pass")
    node = MetaclassTransformer().visit(node)
    node = compile(node, '<string>', 'exec')
    exec(node)



# Generated at 2022-06-23 22:45:52.446666
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    with pytest.raises(AttributeError):
        # The classes are not defined
        _py_backwards_six_with_metaclass()



# Generated at 2022-06-23 22:45:54.688976
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    t = MetaclassTransformer(None)

    assert isinstance(t, BaseNodeTransformer)

# Generated at 2022-06-23 22:45:55.303379
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:46:02.494868
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import parse
    from ..utils.codegen import to_source

    module = parse('''class A(metaclass=B, bases=C):
                       pass''')
    MetaclassTransformer().visit(module)
    assert to_source(module) == 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B), *C):\n    pass'



# Generated at 2022-06-23 22:46:03.383468
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor


# Generated at 2022-06-23 22:46:09.958779
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast as stdast
    from ast import parse as parse_stdast
    from ast import dump as dump_stdast
    import textwrap
    from _py_backwards_compat import utils
    from _py_backwards_compat.transformers import MetaclassTransformer

    # noinspection PyDeprecation
    def parse(source):
        return utils.parse_string(source)

    # noinspection PyDeprecation
    def dump(node):
        return utils.dump_ast(node)
    
    source = textwrap.dedent('''
        from six import with_metaclass as _py_backwards_six_withmetaclass


        class A(B):
            pass
    ''').strip().lstrip('\n')

# Generated at 2022-06-23 22:46:13.807071
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.Module([])
    expected = ast.Module([], type_ignores=[ast.Module, ast.stmt])
    transformed_node = MetaclassTransformer().visit_Module(node)
    assert transformed_node == expected


# Generated at 2022-06-23 22:46:20.843885
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Test data to use in tests
    sample_code = '''class Test:
    metaclass = TestMeta
    '''
    # Test each method of class MetaclassTransformer
    transformer = MetaclassTransformer()
    tree = ast.parse(sample_code)
    transformer.generic_visit = lambda x: x
    transformer.visit(tree)
    comparing_result = "from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass Test(_py_backwards_six_withmetaclass(TestMeta)):\n    pass\n"
    assert transformer.print_tree(tree) == comparing_result


# Generated at 2022-06-23 22:46:25.165240
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_in_ast


# Generated at 2022-06-23 22:46:28.673650
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """
    class A(metaclass=B):
        pass
    class C(D, E):
        pass
    """
    import astor

# Generated at 2022-06-23 22:46:37.236841
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..source import Source
    from ..utils.testing import compare_node
    from ..utils.ast import parse
    from .resolve_dependencies import ResolveDependenciesTransformer

    source = Source("""
    class A(metaclass=type):
        pass
    class B(metaclass=int):
        pass
    """)
    node = ResolveDependenciesTransformer().visit(parse(source))
    node = MetaclassTransformer().visit(node)

# Generated at 2022-06-23 22:46:43.817548
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.visitor import compare

    code = source('''
        class A(metaclass=object):
            pass
    ''')
    tree = MetaclassTransformer.run(code)
    compare(MetaclassTransformer, code, tree)

    code = source('''
        class A(metaclass=object, object):
            pass
    ''')
    tree = MetaclassTran

# Generated at 2022-06-23 22:46:51.094615
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import textwrap

    src = textwrap.dedent('''
    class A(metaclass=B):
        pass
    ''').strip()

    expected = textwrap.dedent('''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    ''').strip()

    result = MetaclassTransformer(src).result()

    assert expected == result

# Generated at 2022-06-23 22:46:59.139745
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    original_src = snippet.dedent("""
    class A(metaclass=ABCMeta):
        pass
    """)

    expected_src = snippet.dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(ABCMeta)):
        pass
    """)

    with_meta = MetaclassTransformer().visit(ast.parse(original_src))
    MetaclassTransformer().visit(with_meta)

    assert ast.dump(with_meta) == ast.dump(ast.parse(expected_src))

# Generated at 2022-06-23 22:47:00.087151
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:47:12.168601
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.ast import get_ast
    import ast
    source_code = source('''
    class NewStyleClass(metaclass=None):
        pass
    ''')
    ast_node = get_ast(source_code)
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(ast_node)
    classdef_node = ast_node.body[0]
    assert type(classdef_node) == ast.ClassDef
    assert classdef_node.keywords == []
    assert type(classdef_node.bases[0].func) == ast.Name
    assert classdef_node.bases[0].func.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-23 22:47:15.989183
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # var set to None to pass pyling linter
    var = None


# Generated at 2022-06-23 22:47:20.479751
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.Module(body=[])
    transformer = MetaclassTransformer()
    node = transformer.visit_Module(node)

    assert transformer._tree_changed
    expected = '''from six import with_metaclass as _py_backwards_six_withmetaclass
'''

    assert ast.dump(node) == expected


# Generated at 2022-06-23 22:47:21.844896
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer(None).target == (2, 7)

# Generated at 2022-06-23 22:47:24.379667
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:47:29.832203
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    ob = MetaclassTransformer()
    assert len(ob.visit_ClassDef(
        ast.ClassDef(name='A', bases=[], keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))], body=(), decorator_list=[]))) == 0

    assert ast.dump(ob.visit_ClassDef(
        ast.ClassDef(name='A', bases=[], keywords=[], body=(), decorator_list=[]))) == 'ClassDef(name=\'A\', bases=[], keywords=[], body=[], decorator_list=[])'

