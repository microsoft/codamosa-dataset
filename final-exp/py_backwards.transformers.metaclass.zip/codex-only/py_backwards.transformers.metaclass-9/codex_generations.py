

# Generated at 2022-06-23 22:37:38.478888
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class TestVisitor(ast.NodeVisitor):
        def visit_ClassDef(self, node):
            return node

    # Test for class without metaclass
    code_in = """
        class A(object):
            pass
    """
    root = ast.parse(code_in)
    MetaclassTransformer().visit(root)
    assert str(root).strip() == code_in.strip()

    # Test for class without metaclass or bases
    code_in = """
        class A:
            pass
    """
    root = ast.parse(code_in)
    MetaclassTransformer().visit(root)
    assert str(root).strip() == code_in.strip()

    # Test for class with metaclass

# Generated at 2022-06-23 22:37:47.200656
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # From:
    asdlkjf = inspect.cleandoc(
        """
        class A(metaclass=B):
            pass
        
        class C(D, E, metaclass=F):
            pass
        """
    )
    # To:
    asdlkjf_expected = inspect.cleandoc(
        """
        import six
        
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        
        class C(_py_backwards_six_withmetaclass(F), D, E):
            pass
        """
    )
    tree = ast.parse(asdlkjf)
    MetaclassTransformer().visit(tree)
    assert astunparse.unparse(tree) == asdlkjf_expected

# Generated at 2022-06-23 22:37:51.934011
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    f = """
    class Foo:
        pass
    """
    t = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class Foo:
        pass
    """
    assert MetaclassTransformer().visit(ast.parse(f)) == ast.parse(t)


# Generated at 2022-06-23 22:37:54.752289
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Type signature
    import inspect
    sig = inspect.signature(MetaclassTransformer.visit_ClassDef)
    assert str(sig) == '(self, node: ast.ClassDef) -> ast.ClassDef'


# Unit test

# Generated at 2022-06-23 22:37:57.595674
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .example import metaclass
    from .test_base import transform, assert_equal
    from .six import six_import

    assert_equal(MetaclassTransformer, metaclass)
    assert_equal(six_import, metaclass)

# Generated at 2022-06-23 22:37:58.729130
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:38:04.113384
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    input_code = "class A(metaclass=B):\n\tpass"
    output_code = "from six import with_metaclass as _py_backwards_six_withmetaclass\n"\
                  "\nclass A(_py_backwards_six_withmetaclass(B)):\n\tpass"
    assert output_code == astunparse.unparse(MetaclassTransformer().visit(ast.parse(input_code)))


# Generated at 2022-06-23 22:38:08.132187
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = textwrap.dedent("""
    class A(object):
        pass
    """)
    expected = textwrap.dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(object)):
        pass
    """)
    MetaclassTransformer().test(source, expected)



# Generated at 2022-06-23 22:38:16.298240
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.compat import format
    # Given
    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B))
        pass
    """
    tree = ast.parse(source)
    # When
    tree = MetaclassTransformer.run_pipeline(tree)
    # Then
    assert tree_to_str(tree) == format(expected)

# Generated at 2022-06-23 22:38:19.190907
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from . import six_import_transformer
    from . import base_transformer  # type: ignore
    from . import base_node_transformer  # type: ignore


# Generated at 2022-06-23 22:38:28.516311
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse("""class A(metaclass=B):
                              pass
                       """)
    transformer = MetaclassTransformer({})
    transformer.visit(module)
    assert transformer.changed == True
    assert transformer.imported_modules == {'six'}
    # Add six import
    assert six_import.get_body() == module.body[:2]
    assert six_import.get_body()[0] == module.body[0]
    assert six_import.get_body()[1] == module.body[1]
    assert six_import.get_body()[1].value.targets[0] == module.body[1].value.targets[0]
    assert six_import.get_body()[1].value.value == module.body[1].value.value

# Generated at 2022-06-23 22:38:38.460029
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str

    example_ast_class = ast.ClassDef(name='example',
                                     bases=[],
                                     keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='Meta',
                                                                                          ctx=ast.Load()))],
                                     body=[ast.Pass()],
                                     decorator_list=[])

    class Meta(type):
        pass


# Generated at 2022-06-23 22:38:39.834095
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:38:41.894606
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..fixer_util import tokenize_and_parse


# Generated at 2022-06-23 22:38:42.409566
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:38:49.438749
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    t = MetaclassTransformer()
    m = ast.parse('''
        class A(metaclass=B):
            pass
    ''')

    m = t.visit(m)
    assert t._tree_changed is True
    assert ast.dump(m) == ast.dump(ast.parse('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    '''))


# Generated at 2022-06-23 22:39:00.730387
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from ast_tools.visitors import TreeChangeVisitor
    source = 'class A(metaclass=B): pass'
    tree = ast.parse(source)
    transformer = MetaclassTransformer()
    result = transformer.visit(tree)
    visitor = TreeChangeVisitor()
    visitor.visit(result)
    assert source == '\n'.join([x.rstrip() for x in visitor.get_source().splitlines()])

    source = 'class A(metaclass=B, b=1): pass'
    tree = ast.parse(source)
    transformer = MetaclassTransformer()
    result = transformer.visit(tree)
    visitor = TreeChangeVisitor()
    visitor.visit(result)
   

# Generated at 2022-06-23 22:39:11.394579
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys
    import unittest
    from ..utils.test_utils import TestTranspileTestCase

    class TestMetaclassTransformer(TestTranspileTestCase):
        def setUp(self):
            self.transformer = MetaclassTransformer(target=MetaclassTransformer.target)

        def test_metaclass(self):
            code = (
                'class A(metaclass=B):\n'
                '    pass'
            )
            expected_code = (
                'from six import with_metaclass as _py_backwards_six_withmetaclass\n\n'
                'class A(_py_backwards_six_withmetaclass(B, object)):\n'
                '    pass'
            )

# Generated at 2022-06-23 22:39:13.476849
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils import parse
    from ..utils.compat import py_ver


# Generated at 2022-06-23 22:39:23.512348
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast
    import textwrap
    from typing import Any

    from asttokens import asttokens  # type: ignore
    from nbdime.patching import TigerSolver

    code = textwrap.dedent('''\
    class A(metaclass=B):
        pass
    ''')
    tree = ast.parse(code)
    atok = asttokens.ASTTokens(code, tree=tree)
    MetaclassTransformer().visit(tree)
    assert str(atok) == textwrap.dedent('''\
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    ''')



# Generated at 2022-06-23 22:39:30.426347
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = '''
        class A(metaclass=B):
            pass
    '''
    module = ast.parse(code)
    module = MetaclassTransformer.run_pipeline(module)
    assert module.body[0].value.keywords == []
    assert 'A' in module.body[0].value.bases.elts[0].args[0].__dict__
    assert 'B' in module.body[0].value.bases.elts[0].args[1].__dict__

# Generated at 2022-06-23 22:39:31.047910
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:39:40.378391
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import copy
    from typed_ast import ast3 as ast
    from ..transpile import Transpiler
    with_metaclass_code = "class A(metaclass=B):\n    pass\n"
    with_metaclass_tree = ast.parse(with_metaclass_code)
    with_metaclass_transpiled = Transpiler().transpile_tree(with_metaclass_tree)
    assert with_metaclass_transpiled.body[0].value.name == '_py_backwards_six_with_metaclass'
    assert with_metaclass_transpiled.body[0].value.args[1].elts[0].s == 'B'

# Generated at 2022-06-23 22:39:47.008206
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = '''class A(metaclass=B, *args, **kwargs):
    pass
    '''
    source = strip_extra_indentation(source)
    tree = ast.parse(source)  # type: ignore

    assert compile(tree, '<test>', 'exec')  # should fail (SyntaxError)

    transformer = MetaclassTransformer()
    transformer.visit(tree)  # type: ignore

    assert compile(tree, '<test>', 'exec')  # should pass

# Generated at 2022-06-23 22:39:47.580774
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:39:53.768198
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import textwrap
    from ast_compat import parse

    test_code = textwrap.dedent('''
    class A(metaclass=B):
        pass
    ''')
    expected = textwrap.dedent('''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    ''')
    module = parse(test_code)
    transformer = MetaclassTransformer()
    new = transformer.visit(module)
    assert expected == transformer.dump_code(new)

# Generated at 2022-06-23 22:39:59.009852
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    expected = [
        ast.ImportFrom(module='six', names=ast.alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')),
        ast.ClassDef(name='A', bases=ast.List(elts=_py_backwards_six_withmetaclass(B)))  # type: ignore
    ]
    result = MetaclassTransformer().visit_Module(ast.parse('class A(metaclass = B): pass'))
    assert all(ast.dump(expected_node) == ast.dump(result_node) for expected_node, result_node in zip(expected, result.body))

# Generated at 2022-06-23 22:40:07.112945
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_node_equals
    from .base import parse, assert_compiled
    import sys

    if sys.version_info >= (3, 0):
        parse_kwargs = {'mode': 'exec'}
    else:
        parse_kwargs = {}

    module_node = parse('class A(metaclass=B): pass')
    MetaclassTransformer().visit(module_node)


# Generated at 2022-06-23 22:40:16.469950
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast as pyast
    from typing import Any, List, Type
    from ..utilstest import assert_equal_code

    transformer = MetaclassTransformer()

    # No metaclass
    node = pyast.parse("""
        class Test:
            def __init__(self):
                self.attr = 1
    """)
    transformed = transformer.visit(node)
    assert not transformer._tree_changed
    assert_equal_code(transformed, """
        class Test(_py_backwards_six_with_metaclass):
            def __init__(self):
                self.attr = 1
    """)

    # With metaclass
    node = pyast.parse("""
        class Test(metaclass=type):
            def __init__(self):
                self.attr = 1
    """)

# Generated at 2022-06-23 22:40:17.344216
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:40:24.146791
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # setup
    from ..python_transpiler import PythonTranspiler
    from ..context import Context

    import_module = six_import.get_module()
    snippet.reset()

    node = ast.parse('''
    class A(metaclass=int):
        pass
    ''')
    ctx = Context(target=(2, 7), dependencies={'six'})
    # exercise
    actual = PythonTranspiler(ctx).visit(node)
    # verify
    expected = import_module
    expected.body.extend(node.body)
    assert ast.dump(expected) == ast.dump(actual)



# Generated at 2022-06-23 22:40:25.479949
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    transformer = MetaclassTransformer()

# Generated at 2022-06-23 22:40:29.478827
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .imports import ImportsTransformer

    source = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B, C, D)):
            pass
    '''
    module = ast.parse(source)
    transformer = ImportsTransformer()
    transformer.visit(module)
    transformer = MetaclassTransformer()
    transformer.visit(module)

    assert codegen.to_source(module) == eight_source



# Generated at 2022-06-23 22:40:30.674640
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:40:39.895193
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.testing import assert_transformed_ast
    from typed_ast import ast27
    from six import with_metaclass as sm
    import numpy as np

    class C:
        pass

    class D:
        pass

    class A(with_metaclass(type, sm(C), sm(sm(D, type), type))):
        pass


# Generated at 2022-06-23 22:40:48.806621
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # setup
    from .python27 import Python27Transformer
    code = """class B: pass"""
    node = ast.parse(code)

    # Preconditions
    target = (2, 7)
    dependencies = ['six']

    # Run
    transformer = MetaclassTransformer(target, dependencies)
    new_node = transformer.visit(node)

    # Postconditions
    target = (2, 7)
    dependencies = ['six']
    transformer = Python27Transformer(target, dependencies)
    assert transformer.visit(new_node) == transformer.visit(node)

# Generated at 2022-06-23 22:40:51.982415
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_base import compile_test
    compile_test(src='''
        class A(metaclass=B):
            pass
    ''', t_target=(2, 7), t_globals=globals())

# Generated at 2022-06-23 22:40:54.806208
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
  transformed = jit_compile(MetaclassTransformer,
      """class A(metaclass=B):
            pass""")

# Generated at 2022-06-23 22:41:05.227017
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .. import codegen

    # codegen.SourceGenerator does not implement generic_visit!
    class SourceGenerator(codegen.SourceGenerator):
        def visit_ClassDef(self, node: ast.ClassDef):
            return super().visit_ClassDef(node)

    expected = """
    class A:
        pass
    """
    source = """
    class A():
        pass
    """
    node = ast.parse(source)
    transformed = MetaclassTransformer().visit(node)
    assert SourceGenerator().visit(transformed) == expected
    # print(SourceGenerator().visit(transformed))


# Generated at 2022-06-23 22:41:15.215109
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():

    from typed_ast import ast3 as ast
    from .utils import parse
    from .visitor import ImportTransformer, add_imports

    code = parse('''
    class A(metaclass=B):
        pass

    ''')
    expected = parse('''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    ''')
    tree = ast.parse(code)
    tree = ImportTransformer().visit(tree)
    tree = MetaclassTransformer().visit(tree)

    assert(compare_ast(tree, expected) == True)


# Generated at 2022-06-23 22:41:22.586371
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import Compiler

    source = """
        class A(metaclass=B):
            pass
    """

    expect = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """

    tree = ast.parse(source)
    c = Compiler()
    c.attach(MetaclassTransformer)
    c.transform(tree)

    result = ast.fix_missing_locations(tree)
    result = ast.Module(body=[result])
    result = ast.dump(result)

    assert result == expect


# Generated at 2022-06-23 22:41:23.413092
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils import round_trip


# Generated at 2022-06-23 22:41:33.869938
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from py_backwards.transformers.metaclass import MetaclassTransformer
    from typed_ast import ast3 as ast

    def test(s, expected):
        module = ast.parse(s)
        tr = MetaclassTransformer()
        tr.visit(module)
        assert tr.tree_changed() == expected
        if expected:
            assert ast.dump(module) == ast.dump(ast.parse(expected))

    test("import six", None)
    test("class A(metaclass=B): pass",
         "from six import with_metaclass as _py_backwards_six_withmetaclass\n"
         "\n"
         "class A(_py_backwards_six_withmetaclass(B))")

# Generated at 2022-06-23 22:41:40.582767
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    import six
    import astunparse

    # Test simple case
    node = ast.parse("""
        from six import with_metaclass
        
        class A(with_metaclass(B)):
            pass
    """)

    tree = MetaclassTransformer().visit(node)

# Generated at 2022-06-23 22:41:48.390050
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():

    from typed_ast.ast3 import Module
    from typed_ast.ast3 import FunctionDef, ClassDef, Str, Expr, Pass, Name, Keyword


    code = "class A(metaclass=B):\n    pass\n"

    # Load the module ast tree.
    module = ast.parse(code)

    # Transform the module
    module = T(MetaclassTransformer)(module)

    # Check the result of the transformation

# Generated at 2022-06-23 22:41:54.680229
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():

    import astor
    code = "class A(metaclass=type):\n    pass"
    expected = "from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(type, object)):\n    pass"
    module = ast.parse(code)
    module = MetaclassTransformer().visit(module)
    result = astor.to_source(module)
    assert result == expected

# Generated at 2022-06-23 22:41:55.216105
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:41:59.574820
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    src = """
        class A:
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A:
            pass
    """
    mt = MetaclassTransformer()
    tree = ast.parse(src)
    mt.visit(tree)
    assert ast.dump(tree) == expected


# Generated at 2022-06-23 22:42:04.843501
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    snippet = """\
        class A(metaclass=B):
            pass
    """

    expected = """\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    node = ast.parse(snippet)
    mt = MetaclassTransformer()
    mt.visit(node)
    assert ast.dump(node) == ast.dump(ast.parse(expected))  # type: ignore

# Generated at 2022-06-23 22:42:11.322994
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

    tree = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    MetaclassTransformer().visit(tree)
    assert astor.to_source(tree) == """
    from six import with_metaclass as _py_backwards_six_withmetaclass  # @UnusedImport
    class A(_py_backwards_six_withmetaclass(B)) :
        pass
    """

# Generated at 2022-06-23 22:42:21.370770
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast, textwrap
    from py_backwards.transformers.metaclass_transformer import MetaclassTransformer
    source = textwrap.dedent('''
    class A(metaclass=B):
        pass
    ''')
    tree = ast.parse(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    code = compile(tree, '', 'exec')
    six_import_source = textwrap.dedent('''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    ''')
    six_import_tree = ast.parse(six_import_source)
    six_import_code = compile(six_import_tree, '', 'exec')

# Generated at 2022-06-23 22:42:25.463708
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from py2py.transformer.six.metaclass import MetaclassTransformer
    class_def = ast.ClassDef(name="Foo",
                             body=[],
                             keywords=[ast.keyword(arg="metaclass",
                                                    value=ast.Name("FooMeta"))],
                             decorator_list=[])
    module = ast.Module(body=[class_def])
    transformer = MetaclassTransformer()
    transformer.visit(module)
    assert module.body[0].bodies[0].nodes[0].bodies[0]._astname == "Name"
    assert transformer._tree_changed

# Generated at 2022-06-23 22:42:26.320594
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor


# Generated at 2022-06-23 22:42:32.463789
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from ..utils.fixtures import (metaclass_transformer_test_tree,
                                  metaclass_transformer_test_target_tree)

    tree = metaclass_transformer_test_tree()
    transformer = MetaclassTransformer()
    assert transformer.visit(tree) == metaclass_transformer_test_target_tree()


# Generated at 2022-06-23 22:42:43.236705
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .py_backwards_transformer import PyBackwardsTransformer
    from .six_transformer import SixTransformer
    from .source_transformer import SourceTransformer
    import astunparse
    source_transformer = SourceTransformer()
    six_transformer = SixTransformer()
    py_backwards_transformer = PyBackwardsTransformer()
    metaclass_transformer = MetaclassTransformer()
    meta = ast.Name(id='meta', ctx=ast.Load())
    class_bases = ast.Name(id='class_bases', ctx=ast.Load())

# Generated at 2022-06-23 22:42:48.993483
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from nuitka.ast.tree import build_node

    tree = build_node(
        '''class A(metaclass=metaclass, bar=3): pass'''
    )

    tree = MetaclassTransformer().visit(tree)

    import textwrap

    assert str(tree) == textwrap.dedent('''\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        
        class A( _py_backwards_six_withmetaclass(Bar)):
            pass
        ''')

# Generated at 2022-06-23 22:42:51.959319
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source_to_node
    from ..utils.compare_ast import compare_ast


# Generated at 2022-06-23 22:43:01.788995
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import parse
    from .some_nodes import A
    from .utils import round_trip, format_code
    from .utils import FormatError
    tree  = parse('a = 1\nclass A(metaclass=B):\n pass')
    node = MetaclassTransformer().visit(tree)
    assert node == parse(
        'from six import with_metaclass as _py_backwards_six_withmetaclass\n'
        'a = 1\nclass A(_py_backwards_six_withmetaclass(B)): pass')
    assert round_trip(node) == format_code(node)
    # Tree has not changed
    node2 = MetaclassTransformer().visit(tree)
    assert node2 == tree

# Generated at 2022-06-23 22:43:11.989490
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = """
        class Base(object):

            def __getitem__(self, index):
                return True

        class Derived(metaclass=Base):
            pass

        x = Derived()

        print(x[1])
    """
    expected_source = """
        from six import with_metaclass as _py_backwards_six_withmetaclass        
        class Base(object):

            def __getitem__(self, index):
                return True

        class Derived(_py_backwards_six_withmetaclass(Base)):
            pass

        x = Derived()

        print(x[1])
    """

    module_node = ast.parse(source)
    assert MetaclassTransformer.check_node(module_node)

    transformer = MetaclassTransformer()
    new_

# Generated at 2022-06-23 22:43:18.999115
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import typed_ast.ast3 as ast

    code = """
        class A(metaclass=B):
            pass
    """
    tree = ast.parse(code)
    transformer = MetaclassTransformer()
    transformer.visit(tree)

    import sys
    if sys.version_info[0:2] < (3, 7):
        assert str(tree) == """
            from six import with_metaclass as _py_backwards_six_withmetaclass


            class A(_py_backwards_six_withmetaclass(B, )):
                pass
        """  # noqa
    else:
        assert str(tree) == """
            class A(metaclass=B):
                pass
        """  # noqa


# Generated at 2022-06-23 22:43:26.258915
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    import sys
    import unittest

    import py_backwards.transformers.test.test_helpers.helper as test_helpers

    from py_backwards.transformers.six_metaclass import MetaclassTransformer

    class TypeVisitor(ast.NodeVisitor):
        def visit_ClassDef(self, node: ast.ClassDef) -> str:
            return node.bases[0].value.func.id

        def visit_Call(self, node: ast.Call) -> str:
            return node.func.id

    class TestMetaclassTransformer(unittest.TestCase):
        def test_init_strategy_fails(self):
            code = """class A(metaclass=B): pass"""
            tree = ast.parse(code)

# Generated at 2022-06-23 22:43:28.090956
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer(2, 7).dependencies == ['six']


# Generated at 2022-06-23 22:43:34.604033
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source_to_code
    from ..utils.tree import code_to_ast

    code = """
    class A(metaclass=B):
        pass
    """

    rewritten_code = MetaclassTransformer().visit(code_to_ast(code))

# Generated at 2022-06-23 22:43:43.532756
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.unparse import Unparser
    """
    Test that MetaclassTransformer transforms class definitions with a
    metaclass to one that uses six's with_metaclass
    """
    s = '''
    class A(metaclass=B):
        pass
    '''
    node = ast.parse(s)  # type: ignore
    transformer = MetaclassTransformer()
    out = transformer.visit(node)
    assert transformer._tree_changed == True
    Unparser(out)
    # assert Unparser(out) == 'from six import with_metaclass as _py_backwards_six_with_metaclass\nclass A(_py_backwards_six_with_metaclass(B))'
    
    
if __name__ == '__main__':
    test_Metaclass

# Generated at 2022-06-23 22:43:45.203787
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import parse, dump_ast

# Generated at 2022-06-23 22:43:54.870430
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import make_visitor_test
    from ..utils.testing import assert_testing_transformer

    code = """
        class A(object):
            pass
    """
    assert_testing_transformer("MetaclassTransformer", MetaclassTransformer, code)

    code = """
        class A(metaclass=bases):
            pass
    """
    tree = make_visitor_test(MetaclassTransformer, code)
    assert type(tree.body[0].body[0].bases[0].func) is ast.Name
    assert tree.body[0].body[0].bases[0].func.id == "_py_backwards_six_withmetaclass"
    assert len(tree.body[0].body[0].bases[0].args) == 2

# Generated at 2022-06-23 22:43:56.479431
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:44:04.114242
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils import make_snippet
    snippet = make_snippet([
        "class A(metaclass=B):",
        "    pass"
    ])
    transformer = MetaclassTransformer()
    module = ast.parse(snippet)
    new_tree = transformer.visit(module)
    new_code = compile(new_tree, filename="<ast>", mode="exec")

    class B(type):
        pass

    globals = {}
    eval(new_code, globals)
    assert type(globals["A"]) is B

# Generated at 2022-06-23 22:44:13.237243
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import unittest
    from . import TyppedTestCase
    from ast import parse

    class TestMetaclassTransformer(TyppedTestCase):
        def assert_transforms(self, before, after):
            transformer = MetaclassTransformer(parse(before))
            self.assertEqual(transformer.tree.body[0], parse(after).body[0])

        def test_simple(self):
            self.assert_transforms("class A(metaclass=B): pass",
                                  "class A(_py_backwards_six_withmetaclass(B)): pass")

        def test_bases(self):
            self.assert_transforms("class A(C, metaclass=B): pass",
                                  "class A(_py_backwards_six_withmetaclass(B, C)): pass")

# Generated at 2022-06-23 22:44:13.959039
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """
    
    """
    pass

# Generated at 2022-06-23 22:44:19.647373
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    mt = MetaclassTransformer()
    m = ast.Module(body=[])
    assert mt.visit_Module(m) == m
    assert m.body[0] == ast.Expr(value=ast.Call(func=ast.Name(id='_py_backwards_six_withmetaclass', ctx=ast.Load()),
                                                args=[ast.Str(s='metaclass')], keywords=[]))



# Generated at 2022-06-23 22:44:21.195111
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import parse

# Generated at 2022-06-23 22:44:23.818135
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:44:27.571789
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.unparser import Unparser
    src = "class A(metaclass=B):\n    pass"

# Generated at 2022-06-23 22:44:28.523878
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:44:38.324398
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    six_import_stmt = six_import.get_body()[0]
    six_withmetaclass_stmt = class_bases.get_body()[0]


# Generated at 2022-06-23 22:44:40.184269
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    mt = MetaclassTransformer()
    assert isinstance(mt, MetaclassTransformer)


# Generated at 2022-06-23 22:44:42.373144
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = """class A(metaclass=B):
    pass"""

# Generated at 2022-06-23 22:44:49.884453
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    six_import_mock = unittest.mock.Mock()
    six_import_mock.get_body = unittest.mock.Mock(return_value=six_import.get_body())
    class_bases_mock = unittest.mock.Mock()
    class_bases_mock.get_body = unittest.mock.Mock(return_value=class_bases.get_body())
    transformer = MetaclassTransformer()
    transformer.dependencies = [six_import_mock]
    transformer.snippets = [class_bases_mock]
    module = ast.parse("class A(metaclass=B):\n    pass", "<test string>", "exec")
    new_module = transformer.visit(module)
    assert new

# Generated at 2022-06-23 22:44:58.592646
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class Foo(metaclass=type):
        pass

    from ..ast_compat import parse
    code = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class Foo(_py_backwards_six_withmetaclass(type, )):
        pass
    """

    tree = parse(code)
    node = tree.body[2]  # type: ast.ClassDef

    transformer = MetaclassTransformer()
    node = transformer.visit(node)  # type: ast.ClassDef

    assert transformer.tree_changed == True
    assert transformer.changed == True
    assert transformer.dependencies == ['six']
    assert transformer.target == (2, 7)
    
    assert len(node.keywords) == 0

# Generated at 2022-06-23 22:45:02.239759
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from py_backwards.transformers.metaclass import MetaclassTransformer

    class A(metaclass=object):
        pass

    actual = astor.to_source(MetaclassTransformer().visit(ast.parse(astor.to_source(A))))


# Generated at 2022-06-23 22:45:07.872731
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3
    from ast_tools.transformers.metaclass import MetaclassTransformer
    from six import with_metaclass
    from typing import TypeVar, Type
    from ast_tools.macros.coroutine import AsyncIO

    T = TypeVar('T')

    class A(with_metaclass(type, int)):
        pass

    # TODO: make this test pass on Python 2
    # class B(with_metaclass(type, int, type('bases', (str,), {}))):
    #     pass

    class C(AsyncIO('C'), with_metaclass(type, int, AsyncIO('C'))):
        pass

    class D(with_metaclass(AsyncIO('D'), int, AsyncIO('D'))):
        pass


# Generated at 2022-06-23 22:45:12.894633
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    source = """class A(metaclass=int):pass"""
    result = """class A(six.with_metaclass(int, object)):pass"""
    tree = ast.parse(source)
    t = MetaclassTransformer()
    t.visit(tree)
    assert astor.to_source(tree) == result

# Generated at 2022-06-23 22:45:18.286545
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast as pyast

    node = pyast.NodeTransformer().visit(pyast.parse(_dummy_source_code))

    transformer = MetaclassTransformer()
    node = transformer.visit(node)

    assert transformer.tree_changed == True


# Generated at 2022-06-23 22:45:28.509930
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = """
        class A(metaclass=B):
            pass
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B))
            pass
    """

    module = ast.parse(code)
    expected_module = ast.parse(expected)
    transformer = MetaclassTransformer()
    module = transformer.visit(module)
    transformer.finalize()

    for stmt in module.body:
        assert isinstance(stmt, ast.ClassDef)
        stmt.lineno = 0
        stmt.col_offset = 0
    assert ast.dump(module) == ast.dump(expected_module)



# Generated at 2022-06-23 22:45:38.868918
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import typed_ast.ast3 as ast3
    import astor
    node = ast3.parse("class A(metaclass=B):\n  pass")
    node = MetaclassTransformer().visit(node)

# Generated at 2022-06-23 22:45:39.833910
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer.__name__ == 'MetaclassTransformer'

# Generated at 2022-06-23 22:45:40.944243
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.testing import assert_node

    # test for visit_ClassDef

# Generated at 2022-06-23 22:45:47.412762
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # type: () -> None
    from typed_ast import ast3 as ast

    dut = MetaclassTransformer()
    dut.target = (3, 5)
    node = ast.ClassDef(name='Foo', bases=[], keywords=None, body=[], decorator_list=[])  # type: ignore
    dut.visit(node)


    node = ast.ClassDef(name='Foo', bases=[], keywords=[], body=[], decorator_list=[])  # type: ignore
    dut.visit(node)

# Generated at 2022-06-23 22:45:51.518362
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    node = ast.parse("""
                    class A(B, metaclass=C):
                        pass
                    """)
    node = MetaclassTransformer().visit(node)
    assert(compile(node, "<test>", "exec").body[0].body[0].name ==
           "_py_backwards_six_withmetaclass")

# Generated at 2022-06-23 22:46:00.275509
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    six_import_list = six_import.get_body()
    class_bases_list = class_bases.get_body(metaclass='A', bases=ast.List(elts=[]))
    code = """
    class A:
        pass
    """
    tree = ast.parse(code)
    result_tree = MetaclassTransformer().visit(tree)
    assert ops.dump_tree(result_tree) == ops.dump_tree(ast.parse("""
    class A(_py_backwards_six_with_metaclass(A)):
        pass
    """))

# Generated at 2022-06-23 22:46:08.289390
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Given
    class_node = ast.parse('class A(metaclass=B):pass').body[0]
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(class_node)
    # Then

# Generated at 2022-06-23 22:46:18.647496
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..utils import parse

    code = """
        class A(metaclass=B):
            pass
    """
    tree = parse(code)
    mt = MetaclassTransformer()
    mt.visit(tree)

    # This is the expected output:
    expected = """
        from six import with_metaclass as _py_backwards_six_with_metaclass


        class A(_py_backwards_six_with_metaclass(B)):
            pass
    """

    # This is the actual output:
    actual = astor.to_source(tree)

    # Make them look the same
    expected = '\n'.join(line.lstrip() for line in expected.split('\n'))

# Generated at 2022-06-23 22:46:24.238853
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_visitor import assert_transformed

    assert_transformed('''
        class A(metaclass=B):
            pass
    ''',
    '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')


# Generated at 2022-06-23 22:46:29.372054
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_astunparse import unparse
    import ast

    class Example(ast.NodeTransformer):
        """Class docstring"""

        def visit_ClassDef(self, node):
            self.generic_visit(node)
            return node

    # Test with ClassDef body that has no keywords
    class_def = example_class_def

# Generated at 2022-06-23 22:46:35.098922
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    tree = ast.parse('class A(metaclass=B): pass')
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed

    # Add to existing imports
    existing = ast.parse('from six import with_metaclass\nclass A(metaclass=B): pass')
    transformer = MetaclassTransformer()
    transformer.visit(existing)
    assert not transformer.tree_changed

    assert existing.body == tree.body

# Generated at 2022-06-23 22:46:42.582179
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast.parse("class A(metaclass=B, bases=(3, 4)): pass")
    MetaclassTransformer.run_on_tree(tree)
    assert_code_equal(
        ast.fix_missing_locations(tree),
        "from six import with_metaclass as _py_backwards_six_withmetaclass\n"
        "class A(_py_backwards_six_withmetaclass(B, 3, 4)):\n"
        "    pass\n")

# Generated at 2022-06-23 22:46:50.739040
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    src = 'class A(metaclass=B): pass'
    tree = ast.parse(src)
    module = MetaclassTransformer().visit(tree)
    expected = \
        'from six import with_metaclass as _py_backwards_six_withmetaclass\n' + \
        'class A(_py_backwards_six_withmetaclass(B)):\n' + \
        '	pass'
    assert astor.to_source(module) == expected

test_MetaclassTransformer_visit_ClassDef()

# Generated at 2022-06-23 22:46:59.251530
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    mod = ast.parse("""class A(metaclass=B, c=True):
        pass""")
    MetaclassTransformer().visit(mod)

    mod2 = ast.parse("""from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B, object), c=True):\n    pass""")
    assert ast.dump(mod) == ast.dump(mod2)


if __name__ == "__main__":
    import sys
    from . import main
    main(sys.argv[1:], [MetaclassTransformer])

# Generated at 2022-06-23 22:47:10.423108
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node1 = ast.parse("""
    class A(metaclass=B):
        pass
    class C(metaclass=D):
        pass
    """, mode='exec')
    node2 = ast.Module(body=[
        six_import.get_body(),
        ast.ClassDef(name='A', bases=[
            ast.Call(func=ast.Name(id='_py_backwards_six_withmetaclass'), args=[ast.Name(id='B')], keywords=[])
        ]),
        ast.ClassDef(name='C', bases=[
            ast.Call(func=ast.Name(id='_py_backwards_six_withmetaclass'), args=[ast.Name(id='D')], keywords=[])
        ])
    ])

    assert MetaclassTransformer().visit(node1)

# Generated at 2022-06-23 22:47:13.210871
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from asttokens import ASTTokens
    from astunparse import unparse
    import pytest


# Generated at 2022-06-23 22:47:15.190500
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:47:24.641750
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astroid
    from ..utils import get_name_node
    module = astroid.parse("""
        class A(metaclass=B):
            pass
    """)
    node = module.body[0]
    assert isinstance(node, astroid.ClassDef)
    assert node.keywords
    # Test that we have a Name node for B
    assert isinstance(node.keywords[0].value, astroid.Name)
    assert node.keywords[0].value.name == 'B'
    # Test that the visit method works
    visitor = MetaclassTransformer()
    visitor.visit(module)
    assert len(module.body) == 1
    assert get_name_node(module.body[0]) == 'A'
    new_bases = module.body[0].bases
    #

# Generated at 2022-06-23 22:47:26.089148
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:47:29.789658
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    def check(code, result, assert_=True):
        tree = ast.parse(code)
        before = ast.dump(tree)
        MetaclassTransformer().visit(tree)
        if assert_:
            assert(ast.dump(tree) == result)
        else:
            print(ast.dump(tree))
