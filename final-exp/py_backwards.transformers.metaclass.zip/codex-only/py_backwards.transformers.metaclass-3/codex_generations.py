

# Generated at 2022-06-23 22:37:41.440454
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Given
    python_node = ast.parse('''
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass


    def class_bases(metaclass, bases):
        _py_backwards_six_withmetaclass(metaclass, *bases)


    class A(B, metaclass=C):
        pass''')  # type: ast.Module


# Generated at 2022-06-23 22:37:45.619486
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    assert MetaclassTransformer(2, 7).visit_Module(ast.parse('class A(b, c, d)')) == \
        ast.parse('''class A(b, c, d)
from six import with_metaclass as _py_backwards_six_withmetaclass''')



# Generated at 2022-06-23 22:37:51.304611
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ...tests.testing import assert_transformation
    assert_transformation(MetaclassTransformer, '''
        class A(metaclass=B):
            pass
    ''', '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

# Generated at 2022-06-23 22:37:52.323921
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:37:54.845954
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    mt = MetaclassTransformer()
    mt.visit(six_import.snippet())
    mt.visit(class_bases.snippet())

# Generated at 2022-06-23 22:37:56.229603
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # Test if constructor works
    obj = MetaclassTransformer([])


# Generated at 2022-06-23 22:38:07.091759
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .base import BaseTestTransformer
    from .test_custom_class import TestClassTransformer

    class TestMetaclassTransformer(BaseTestTransformer):
        transformer = MetaclassTransformer

        def test_class_basic(self):
            self.check_equal('''
                class A(metaclass=B):
                    pass''', '''
                class A(_py_backwards_six_withmetaclass(B)):
                    pass''')

        def test_class_bases(self):
            self.check_equal('''
                class A(B, metaclass=C):
                    pass''', '''
                class A(_py_backwards_six_withmetaclass(C, B)):
                    pass''')

        def test_class_keywords(self):
            self.check_equal

# Generated at 2022-06-23 22:38:17.261813
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

    module = ast.Module(body=[
        ast.ClassDef(
            name='A',
            bases=[],
            keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='C'))],
            body=[],
            decorator_list=[],
            returns=None
        )
    ])


# Generated at 2022-06-23 22:38:25.563584
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..mock_node import MockNode
    from ..mock_tree import MockTree
    from ..compiler import Compiler


    class Mock_six(MockNode):
        _fields = ('name',)
    six_import.set_body(Mock_six(name='six', lineno=1))

    class Mock_(_py_backwards_six_withmetaclass):
        _fields = ('metaclass', 'bases')

    class_bases.set_body(Mock_(_py_backwards_six_withmetaclass,
                               MockNode(lineno=5),
                               [MockNode(lineno=5)]))



# Generated at 2022-06-23 22:38:27.380818
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:38:36.463827
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import parse
    from . import dedent
    from ..utils.ast import compare_ast

    node = parse(dedent("""
    class A(object):
        pass
    """))

    res = parse(dedent("""
    # six import
    from six import with_metaclass as _py_backwards_six_withmetaclass
    # class bodies
    class A(_py_backwards_six_withmetaclass(object)):
        pass
    """))

    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(node)
    compare_ast(node, res)


# Generated at 2022-06-23 22:38:40.696487
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():

    @snippet
    def before(metaclass):
        class A(metaclass=metaclass):
            pass

    @snippet
    def after(metaclass):
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(metaclass)):
            pass

    assert MetaclassTransformer().visit(before.get_ast()) == after.get_ast()


# Generated at 2022-06-23 22:38:47.078445
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    i = "class A(metaclass=B, c, *d):\n    pass\n"
    o = "from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B))\n"

    assert o == astor.to_source(MetaclassTransformer().visit(astor.parse_file(i)))

# Generated at 2022-06-23 22:38:51.954162
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = (
        "class C(metaclass=type):\n"
        "    pass"
    )
    output = (
        "class C(_py_backwards_six_withmetaclass(type)):\n"
        "    pass\n"
    )
    tree = parse(code)
    MetaclassTransformer().visit(tree)
    assert output == tree.body[0].print_()  # type: ignore

# Generated at 2022-06-23 22:38:58.790705
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import compile_snippet
    from .. import cross_version

    n = MetaclassTransformer()
    n.visit(ast.parse("""
        class A(metaclass=B):
            pass
    """))
    assert n._tree_changed

    n = MetaclassTransformer()
    n.visit(ast.parse("""
        class A(B):
            pass
    """))
    assert not n._tree_changed

# Generated at 2022-06-23 22:39:08.990531
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # arrange
    from typed_ast.ast3 import Module, ClassDef, Name, keyword, dump

    tree = Module(body=[ClassDef(name='C', bases=[], keywords=[keyword(arg='metaclass', value=Name(id='M', ctx=Load()))], body=[], decorator_list=[])])

# Generated at 2022-06-23 22:39:16.307013
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:39:21.516196
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3
    from .tools import roundtrip, check_visitor
    from . import six_transformer

    def check_method(body):
        check_visitor(MetaclassTransformer,
                      """
      class Test(metaclass=Test2):
          {}
      """.format(body), """
      class Test(_py_backwards_six_withmetaclass(Test2)):
          {}
      """.format(body))

    check_method(None)
    check_method("")
    check_method("print('hello')")



# Generated at 2022-06-23 22:39:22.969762
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer().target == (2, 7)
    assert MetaclassTransformer().dependencies == ['six']

# Generated at 2022-06-23 22:39:25.624466
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    a = ast.parse("class A(metaclass=abc.ABCMeta): pass")
    print(MetaclassTransformer().visit(a).body[0])
    print(ast.dump(a))
    print(a)

# Generated at 2022-06-23 22:39:28.069074
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast as std_ast
    from typed_ast.ast3 import parse

    from ..utils.compiler import compile_and_load


# Generated at 2022-06-23 22:39:29.282490
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:39:37.801639
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class Test:
        name = "Test"
        input = "class A(metaclass=B): pass"
        output = "from six import with_metaclass as _py_backwards_six_withmetaclass\n" \
                 "class A(_py_backwards_six_withmetaclass(B))"

    instance = MetaclassTransformer()
    assert instance.name == Test.name
    assert instance.target == (2, 7)
    assert instance.dependencies == ['six']

    result = instance.transform(Test.input)

    assert result.body[0].value.name == '@snippet'
    assert result == Test.output

# Generated at 2022-06-23 22:39:45.268039
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import ast2list
    import os

    examples = {
        '''
        class A(metaclass=B):
            pass
        ''',
        '''
        class A(B, metaclass=C):
            pass
        ''',
    }

    for example in examples:
        node = ast.parse(example)
        visitor = MetaclassTransformer()
        node = visitor.visit(node)
        visitor.visit(node)
        assert visitor._tree_changed

# Generated at 2022-06-23 22:39:54.104613
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .transformer_examples.metaclass import example

    t = MetaclassTransformer(2, 7)
    code = t.visit(example)
    assert code == 'from six import with_metaclass as _py_backwards_six_with_metaclass\n' \
                   '\n' \
                   'class A(_py_backwards_six_with_metaclass(B), B):\n' \
                   '    pass\n' \
                   '\n' \
                   'class C(_py_backwards_six_with_metaclass(type), D):\n' \
                   '    pass\n' \
                   '\n' \
                   'class E(_py_backwards_six_with_metaclass(type), D):\n' \
                   '    pass\n'

# Generated at 2022-06-23 22:39:59.206369
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    a = ast.parse('class A(metaclass=B): pass', mode='exec') # type: ignore
    b = ast.parse('class A(B): pass', mode='exec') # type: ignore
    print('original code:')
    print(a)
    print('code to compare against:')
    print(b)
    MetaclassTransformer().visit(a) # type: ignore
    print('obtained code:')
    print(a)
    assert b == a # type: ignore


# Generated at 2022-06-23 22:40:06.654993
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse('class A(object):\n    pass')
    expected = ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass\n\n\nclass A(_py_backwards_six_withmetaclass(object))\n    pass')
    transformer = MetaclassTransformer('2.7')
    result = transformer.visit(module)
    assert_equal_ast(result, expected)
    assert_equal_code(result, expected)
    assert transformer._tree_changed is True



# Generated at 2022-06-23 22:40:08.228510
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:40:17.385191
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class TestMetaclassTransformer(MetaclassTransformer):
        def visit_Module(self, node):
            return node

    parse = lambda node: test_parse(node, mode='exec')

    # Regular class
    assert TestMetaclassTransformer(parse('class A:\n  pass')).run() == parse('class A:\n  pass')
    # Class with metaclass
    assert TestMetaclassTransformer(parse('class A(metaclass=B):\n  pass')).run() == parse(
        'class A(_py_backwards_six_withmetaclass=B)):\n  pass')
    # Class with no bases

# Generated at 2022-06-23 22:40:25.424400
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Input
    import_six = six_import.get_body()[0]
    node_0 = ast.Module(body=[import_six,
                              ast.ClassDef(name='Test_0',
                                           bases=[],
                                           keywords=[],
                                           body=[],
                                           decorator_list=[])])

    # Expected output
    node_0_expected = ast.Module(body=[import_six,
                                       ast.ClassDef(name='Test_0',
                                                    bases=[],
                                                    keywords=[],
                                                    body=[],
                                                    decorator_list=[])])

    # Run transformation
    t = MetaclassTransformer()
    t.visit(node_0)

    # Check result

# Generated at 2022-06-23 22:40:30.101805
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = "class A(metaclass=B):\n    pass"
    expected = "from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B))"
    assert MetaclassTransformer().visit(code) == expected



# Generated at 2022-06-23 22:40:37.386249
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import textwrap
    from ..utils.unparse import Unparser

    source = textwrap.dedent("""\
        class A(metaclass=B):
            pass
    """)
    tree = compile(source, '<test>', 'exec', ast.PyCF_ONLY_AST)
    MetaclassTransformer().visit(tree)

    assert Unparser(tree) == textwrap.dedent("""\
    from six import with_metaclass as _py_backwards_six_with_metaclass


    class A(_py_backwards_six_with_metaclass(B)):
        pass

    """)


# Generated at 2022-06-23 22:40:42.322410
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class A(metaclass=int):
        pass
    node = ast.parse(A.__module__)
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)
    #print(ast.dump(new_node))
    #print(compile(new_node, 'test.py', 'exec'))
    exec(compile(new_node, 'test.py', 'exec'))
    assert A is globals()['A']

# Generated at 2022-06-23 22:40:52.753861
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source

    source = source('''
    class C(metaclass=D):
        pass
    ''')
    expected = source('''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class C(_py_backwards_six_withmetaclass(D, )):
        pass
    ''')
    tree = ast.parse(source)
    node = tree.body[0]
    assert not isinstance(node.bases[0], ast.ClassDef)
    MetaclassTransformer().visit(node)
    assert isinstance(node.bases[0], ast.ClassDef)
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-23 22:40:56.120641
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse('class A(metaclass=B): pass')
    MetaclassTransformer().visit(node)

    import astor
    assert astor.to_source(node) == 'class A(_py_backwards_six_withmetaclass(B)):\n pass'


# Generated at 2022-06-23 22:41:01.577148
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert not MetaclassTransformer().visit_ClassDef(ast.parse("""class A(metaclass=B): pass""").body[0]).keywords
    assert not MetaclassTransformer().visit_ClassDef(ast.parse("""class A(B, C, metaclass=D): pass""").body[0]).keywords


# Generated at 2022-06-23 22:41:03.301535
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import run_transformer
    from .six_import import get_six_import


# Generated at 2022-06-23 22:41:13.859262
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    def check(source, expected_result, mode=None):
        expected_tree = ast.parse(expected_result)
        tree = ast.parse(source)

        t = MetaclassTransformer(mode=mode)
        new_tree = t.visit(tree)

        assert ast.dump(new_tree, include_attributes=True) == ast.dump(expected_tree, include_attributes=True)
        assert t.dependencies == ['six']

    check(
        '''
        class A(metaclass=B):
            pass
        ''',
        '''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass        
        '''
    )


# Generated at 2022-06-23 22:41:20.513307
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse(textwrap.dedent("""
    class A(metaclass=B):
        pass
    """))
    module_ = MetaclassTransformer().visit(module)

    module_ = ast.parse(textwrap.dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """))
    assert codegen.to_source(module_) == codegen.to_source(module)



# Generated at 2022-06-23 22:41:30.534202
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert (MetaclassTransformer(target=(2, 7), dependencies=['six']).transform(
        ast.parse(
            """
        class A(metaclass=B):
            pass
        """))) == (six_import.get_body() + [
            ast.ClassDef(name='A', bases=[
                ast.Call(func=ast.Name(id='_py_backwards_six_withmetaclass',
                                       ctx=ast.Load()),
                         args=[ast.Name(id='B', ctx=ast.Load()), ast.Name(id='object', ctx=ast.Load())],
                         keywords=[],
                         starargs=None,
                         kwargs=None)],
                     keywords=[],
                     body=[],
                     decorator_list=[])])

# Generated at 2022-06-23 22:41:39.157754
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    body = [ast.FunctionDef(name='foo', 
                            body=[ast.Pass()],
                            args=ast.arguments(defaults=[],
                            kwarg=None,
                            kwonlyargs=[],
                            kw_defaults=[],
                            posonlyargs=[],
                            vararg=None)),
            ast.ClassDef(name='A',
                         body=[ast.Pass()],
                         keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B',
                         ctx=ast.Load()))])]
    node = ast.Module(body=body)
    tr = MetaclassTransformer()
    new_node = tr.visit(node)
    
    assert len(new_node.body) == 3

# Generated at 2022-06-23 22:41:45.231283
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast
    import sys
    import six
    import py_backwards
    import py_backwards.transformers.metaclass

    with six.assertRaisesRegex(AssertionError, "Expected "):
        py_backwards.transformers.metaclass.MetaclassTransformer("")
    with six.assertRaisesRegex(AssertionError, "Expected "):
        py_backwards.transformers.metaclass.MetaclassTransformer(0)
    with six.assertRaisesRegex(AssertionError, "Expected "):
        py_backwards.transformers.metaclass.MetaclassTransformer([])
    with six.assertRaisesRegex(AssertionError, "Expected "):
        py_backwards.transformers.metaclass.MetaclassTransformer

# Generated at 2022-06-23 22:41:52.949169
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.examples import example_class_decorator_arg_1, example_class_decorator_arg_2, example_class_decorator_arg_3

    assert MetaclassTransformer(example_class_decorator_arg_1).visit() == example_class_decorator_arg_1
    assert MetaclassTransformer(example_class_decorator_arg_2).visit() == example_class_decorator_arg_3
    assert not MetaclassTransformer(example_class_decorator_arg_2).is_changed

# Generated at 2022-06-23 22:41:57.864923
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.source import source_to_ast as to_ast
    from ..utils.source import ast_to_source as to_source
    from ..utils.compare import expect_equal
    
    actual = to_source(MetaclassTransformer().visit(to_ast("")))
    expect = to_source(to_ast(six_import.dedent().strip()))

    expect_equal(expect, actual)



# Generated at 2022-06-23 22:42:01.144164
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..visitor import flatten
    from ..importer import import_

    module = import_(__name__, 'source_files.metaclass_transformer')
    new_node = MetaclassTransformer().visit(module)
    assert flatten(new_node) == flatten(module)

# Generated at 2022-06-23 22:42:06.286274
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()
    assert transformer.visit(ast.parse("class A(metaclass=B)")) == \
        ast.parse("from six import with_metaclass as _py_backwards_six_withmetaclass; "
                  "class A(_py_backwards_six_withmetaclass(B))")



# Generated at 2022-06-23 22:42:10.616703
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():

    from ..rewrite import RewriteContext
    from ..testing.utils import assert_transformed_ast

    ctx = RewriteContext()

    s = """class A(metaclass=B):
           pass"""


# Generated at 2022-06-23 22:42:15.397577
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_utils import C, load_example_module, get_just_body, transform_and_compare
    example = load_example_module('metaclass')
    expected = load_example_module('metaclass_expected')

    assert transform_and_compare(MetaclassTransformer, example, expected, get_just_body)

# Generated at 2022-06-23 22:42:21.005738
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .. import settings as py_backwards_settings
    from ..utils.testing import run_transformer_tests
    import typing
    class MyClass(typing.NamedTuple):
        test: int
        test2: int

    def _assertMyClass(myclass):
        assert type(myclass) == MyClass
        assert myclass.__name__ == 'MyClass'


# Generated at 2022-06-23 22:42:26.701800
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    assert ast.dump(MetaclassTransformer().visit(ast.parse('class A(metaclass=B): pass'))) == \
        'Module(body=[ImportFrom(module=\'six\', names=[alias(name=\'with_metaclass\', ' \
        'asname=\'_py_backwards_six_withmetaclass\')], level=0), ClassDef(name=\'A\', ' \
        'bases=[Call(func=_py_backwards_six_withmetaclass, args=[Name(id=\'B\', ctx=Load())], ' \
        'keywords=[])], body=[], decorator_list=[])])'

# Generated at 2022-06-23 22:42:27.786529
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:42:29.141165
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor


# Generated at 2022-06-23 22:42:35.761568
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    code = "class A(metaclass=B): pass"
    tree = ast.parse(code)
    result = MetaclassTransformer.visit(tree)
    expected = "from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B))\n"
    assert astor.to_source(result) == expected



# Generated at 2022-06-23 22:42:45.887735
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.testing import assert_transform, case

    transformer = MetaclassTransformer()
    case_00_in = """
        class A:
            pass
    """
    case_00_out = case_00_in
    case_01_in = """
        class A(metaclass=B):
            pass
    """
    case_01_out = """
        class A(metaclass=B):
            pass
    """
    case_02_in = """
        class A(metaclass=B, C):
            pass
    """
    case_02_out = """
        class A(metaclass=B, C):
            pass
    """
    case_03_in = """
        class A(B, C, metaclass=D):
            pass
    """
    case_03_

# Generated at 2022-06-23 22:42:47.419668
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:42:58.768628
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    ast_node = ast.ClassDef(name='A', 
                            bases=[ast.Name(id='a', ctx=ast.Load())], 
                            keywords=[ast.keyword(arg='metaclass', 
                                                  value=ast.Name(id='b', ctx=ast.Load()))], 
                            body=[], 
                            decorator_list=[])
    ast_node = MetaclassTransformer(BaseNodeTransformer.Options(source='f.py', target='2.7')).visit_ClassDef(ast_node)
    assert ast_node.bases[0].func.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-23 22:42:59.656290
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:43:05.893605
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast
    from astunparse import unparse
    from asttokens import ASTTokens
    from py_backwards.transformers import MetaclassTransformer
    source = """
    class A(metaclass=B):
        pass
    """

    # Get tokens
    tokens = ASTTokens(source, parse=True)

    # Get syntax tree
    tree = ast.parse(source)

    # Transform tree
    tree = MetaclassTransformer().visit(tree)
    print(unparse(tree))

    # Get new tokens
    new_tokens = ASTTokens(tree=tree)

    # Apply changes to original tokens
    new_tokens.set_tokens(tokens.get_tokens())
    print(new_tokens.get_text())



# Generated at 2022-06-23 22:43:14.993619
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class Module:
        body = []

    class ClassDef():
        base = []
        keywords = []

    class Name():
        id = 'B'

    class Keyword():
        arg = 'metaclass'
        value = Name()

    class Assign():
        targets = []
        value = Name()

    class Assign2():
        targets = []
        value = ClassDef()

    class FunctionDef():
        body = []

    class PassStatement():
        pass

    keyword = Keyword()
    assign1 = Assign()
    assign2 = Assign2()
    function = FunctionDef()
    function.body.append(PassStatement())
    class_def = ClassDef()
    class_def.bases.append(Name())
    class_def.keywords.append(keyword)

# Generated at 2022-06-23 22:43:15.523546
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:43:20.610175
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def = ast.ClassDef(name="A",
                             body=[],
                             keywords=[ast.keyword(arg="metaclass",
                                                   value=ast.Name("B"))])
    transformer = MetaclassTransformer()
    new_class_def = transformer.visit(class_def)
    assert new_class_def.bases[0].elts[0].id == "_py_backwards_six_withmetaclass"

# Generated at 2022-06-23 22:43:27.029310
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .. import tree
    from ..transformers import get_transformers

    class ExampleTransformer(BaseNodeTransformer):
        """An example for testing purposes"""
        target = (2, 7)

        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases += tuple([ast.Name(id='mybase', ctx=ast.Load())])
            return node

    tree_ = tree.parse("""
    class A(object):
        pass
    """)

    module = tree_.body[0]
    classes = [module.body[0]]
    class_ = classes[0]
    assert len(class_.bases) == 1
    assert type(class_.bases[0]) == ast.Name and class_.bases[0].id == 'object'


# Generated at 2022-06-23 22:43:37.451504
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from textwrap import dedent
    from .base import BaseNodeTransformerTest
    source = dedent('''\
        class Test(metaclass=type):
            def __init__(self):
                super().__init__()
            def __subclasshook__(self):
                pass
            def __new__(self):
                pass
            def __classcell__(self):
                pass
            def __prepare__(self):
                pass
        ''')

# Generated at 2022-06-23 22:43:38.500122
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:43:45.870628
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import transform_and_compile_snippet

    snippet_without_six_import = '''
    class A(metaclass=B):
        pass
    '''
    snippet_with_six_import = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(metaclass=B):
        pass
    '''

    six_import_source = six_import.get_source()
    expected_source = snippet_with_six_import + six_import_source
    actual_source = transform_and_compile_snippet(MetaclassTransformer, snippet_without_six_import)

    value = 0
    if expected_source != actual_source:
        print("\nExpected:")

# Generated at 2022-06-23 22:43:53.741427
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    test_code = '''
    class A():
        pass
    class B(metaclass=C):
        pass
    class C(metaclass=type):
        pass
    '''
    transformed = '''
    class A():
        pass
    class B(_py_backwards_six_withmetaclass(C)):
        pass
    class C(_py_backwards_six_withmetaclass(type)):
        pass
    '''
    t = MetaclassTransformer()
    assert t.visit(ast.parse(test_code)) == ast.parse(transformed)

# Generated at 2022-06-23 22:44:04.493298
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from ..testing_utils import make_dummy_tree
    from ..testing_utils import get_node
    from .six import SixTransformer

    dummy_tree = make_dummy_tree()
    dummy_tree['metadata']['py_version'] = (2, 7)

    expected_tree = astor.code_to_ast.parse('''
    import six
    class A(six.with_metaclass(B.__metaclass__)):
        pass
    ''')

    dummy_tree = SixTransformer().visit(dummy_tree)  # type: ignore
    dummy_tree = MetaclassTransformer(dummy_tree).visit(dummy_tree)  # type: ignore



# Generated at 2022-06-23 22:44:10.528507
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    before = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    after = ast.parse("""
    class A(_py_backwards_six_with_metaclass(B)):
        pass
    """)

    transformer = MetaclassTransformer()
    result = transformer.visit(before)

    assert ast.dump(result) == ast.dump(after)

# Generated at 2022-06-23 22:44:15.636483
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .base import UnitTestTransformer
    node = UnitTestTransformer(MetaclassTransformer,
                               'class A(metaclass=B): pass',
                               'class A(_py_backwards_six_withmetaclass(B)): pass')
    assert node is not None


# Generated at 2022-06-23 22:44:17.008153
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()

# Generated at 2022-06-23 22:44:17.923418
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    o = MetaclassTransformer()

# Generated at 2022-06-23 22:44:21.339400
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .utils import _build_module_from_text

    text = """
    class A(metaclass=ABCMeta):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
    class A(_py_backwards_six_withmetaclass(ABCMeta)):
        pass
    """
    module = _build_module_from_text(text, 'MetaclassTransformer')
    module = MetaclassTransformer.visit(module)
    assert module.as_string() == expected

# Generated at 2022-06-23 22:44:21.985944
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert True

# Generated at 2022-06-23 22:44:28.108572
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .test_utils import transform_to_source

    class A(metaclass=type):
        pass

    assert transform_to_source(A, MetaclassTransformer) == \
        'from six import with_metaclass as _py_backwards_six_withmetaclass\n' \
        '\n' \
        'class A(_py_backwards_six_withmetaclass(type)):\n' \
        '    pass\n'



# Generated at 2022-06-23 22:44:33.435327
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    mt = MetaclassTransformer()
    # Test with no imports
    mt.visit(ast.parse('class A(metaclass=B): pass'))
    assert mt._tree_changed

    # Test with existing imports
    mt.visit(ast.parse('import a\nimport b\nclass A(metaclass=B): pass'))
    assert mt._tree_changed



# Generated at 2022-06-23 22:44:39.489020
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.testutils import source
    
    t = MetaclassTransformer()
    tree = ast.parse(source('''
        class A(metaclass=M):
            pass
    '''))
    t.visit(tree)
    assert source(t) == '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(M)):
        pass'''


# Generated at 2022-06-23 22:44:42.372537
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast

    source = """class A(metaclass=B):
                    pass"""

# Generated at 2022-06-23 22:44:47.159379
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = """
    class A(metaclass=B):
        pass
    """
    c = MetaclassTransformer(code)
    c.visit(c.tree)
    print(c)
    assert c.code == """\
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

# Generated at 2022-06-23 22:44:53.739237
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():

    tree = parse('class A(metaclass=B): pass')
    tree_changed = False
    tree = MetaclassTransformer(tree, tree_changed).visit(tree)
    assert unparse(tree) == dedent("""\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass""")



# Generated at 2022-06-23 22:44:56.367224
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import six
    import ast
    from typed_ast import ast3 as typed_ast
    from py2to3.refactor.metaclass import MetaclassTransformer

# Generated at 2022-06-23 22:45:00.251682
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import assert_equal_ignore_ws
    from ..utils.tree import tree_to_str
    from ..utils.source import source_to_tree


# Generated at 2022-06-23 22:45:02.431761
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = "class A(metaclass=B): pass"


# Generated at 2022-06-23 22:45:07.340059
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from textwrap import dedent
    source = dedent('''\
        class A(b, c, d, metaclass=E):
            pass
        ''')
    tree = ast.parse(source)
    t = MetaclassTransformer()
    t.visit(tree)
    print(astor.to_source(tree))
    assert astor.to_source(tree).strip() == dedent('''\
        from six import with_metaclass as _py_backwards_six_with_metaclass
        class A(_py_backwards_six_with_metaclass(E)) :
            pass
        ''').strip()

# Generated at 2022-06-23 22:45:12.193428
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
  t = MetaclassTransformer
  t.visit_Module(ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass\n'
                           'class A(metaclass={},B):\n'
                           '    pass\n'
                           'class B: pass'))



# Generated at 2022-06-23 22:45:22.873572
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .implementation import ImplementationBuilder
    source = ImplementationBuilder()
    with source.function('test'):
        with source.class_('A'):
            source.pass_()
        with source.class_('B', meta='type'):
            source.pass_()
        with source.class_('C', meta='type', bases=['A']):
            source.pass_()

    expected = ImplementationBuilder()
    with expected.function('test'):
        expected.import_('six', 'with_metaclass', as_name='_py_backwards_six_with_metaclass')
        with expected.class_('A', bases='_py_backwards_six_with_metaclass(type)'):
            expected.pass_()

# Generated at 2022-06-23 22:45:28.221438
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_visitor import test_visitor
    import ast

    node = ast.Module(body=[
        ast.ClassDef(name='A', bases=[], body=[], decorator_list=[], keywords=[])
    ])

# Generated at 2022-06-23 22:45:34.027936
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..testing_utils import expect_removed, expect_unchanged

    expect_unchanged(MetaclassTransformer, '''
        def f():
            class A:
                pass
        ''')
    expect_unchanged(MetaclassTransformer, '''
        def f():
            class A(object):
                pass
        ''')
    expect_removed(MetaclassTransformer, '''
        def f():
            class A(metaclass=object):
                pass
        ''',
        replacements=[
            six_import,
            class_bases,
        ]
    )

# Generated at 2022-06-23 22:45:34.964575
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:45:36.571840
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..testing import assert_source


# Generated at 2022-06-23 22:45:42.858152
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = '''
    class A(metaclass=B):
        pass
    '''
    t = MetaclassTransformer('')
    out = t.visit(ast.parse(code))
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    assert expected == astor.to_source(out)

# Generated at 2022-06-23 22:45:49.225872
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils import assert_equal_ast
    from .python_minifier import PythonMinifier
    from .six_transformer import SixTransformer


# Generated at 2022-06-23 22:45:56.161291
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from ..utils.tree import get_source
    from .base import Python2to3
    from ..testing import assert_source

    node = ast.parse('''
    class A(metaclass=B):
        pass
    ''')
    transformer = Python2to3()
    transformer.apply(MetaclassTransformer)
    get_source(node)

# Generated at 2022-06-23 22:45:57.158121
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor

# Generated at 2022-06-23 22:46:05.554585
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    # Original source:
    #   class A(metaclass=B):
    #       pass

    input_source = """class A(metaclass=B):
        pass"""

    tree = ast.parse(input_source)
    MetaclassTransformer().visit(tree)

    # Desired output:
    #   from six import with_metaclass as _py_backwards_six_withmetaclass
    #   class A(_py_backwards_six_with_metaclass(B)):
    #       pass


# Generated at 2022-06-23 22:46:13.851377
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer

    class TestClass(BaseNodeTransformer):
        pass

    expected_output = """\
import six
from six import with_metaclass as _py_backwards_six_withmetaclass
"""

    input_module = ast.parse(expected_output)
    expected_module = ast.parse(expected_output)

    module = TestClass().visit_Module(input_module)
    assert ast.dump(module) == ast.dump(expected_module)


# Generated at 2022-06-23 22:46:14.475451
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:46:15.843560
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:46:16.419672
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:46:21.472850
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """class A(metaclass=object):
                pass
            """
    expected = """from six import with_metaclass as _py_backwards_six_with_metaclass
    class A(_py_backwards_six_with_metaclass(object)):
                pass
            """
    tree = ast.parse(code)
    MetaclassTransformer().visit(tree)
    actual = compile(tree, '', 'exec')
    assert ast.dump(actual) == ast.dump(ast.parse(expected))

# Generated at 2022-06-23 22:46:22.476834
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:46:32.643046
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from . import _utils
    from .six import _six_transformer

    node = _utils.parse_string('''
    class A(metaclass=type):
        pass
    ''')

    node = _six_transformer.visit(node)
    assert isinstance(node, ast.Module)

    node = MetaclassTransformer.visit(node)
    assert isinstance(node, ast.Module)
    assert len(node.body) == 2
    assert isinstance(node.body[0], ast.ImportFrom)
    assert isinstance(node.body[1], ast.ClassDef)

# Generated at 2022-06-23 22:46:36.637589
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import compile_snippet

    class A(object):
        __metaclass__ = type
        def a(self):
            pass
    class B(metaclass=type):
        def b(self):
            pass

    node = compile_snippet(A)
    node = MetaclassTransformer().visit(node)
    assert compile_snippet(B) == node

# Generated at 2022-06-23 22:46:47.708852
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    m = ast.parse('class A(metaclass=b): pass')
    m = MetaclassTransformer().visit(m)
    assert ast.dump(m) == """
Module(body=[
    ImportFrom(
        module='six',
        names=[alias(
            name='with_metaclass',
            asname='_py_backwards_six_withmetaclass')],
        level=0),
    ClassDef(
        name='A',
        bases=[Call(
            func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()),
            args=[Name(id='b', ctx=Load())],
            keywords=[])],
        body=[],
        decorator_list=[])])
"""

# Generated at 2022-06-23 22:46:49.826537
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..dummy_module import walk
    import astor

    root = astor.parse_file(__file__)
    root = walk(root, MetaclassTransformer(object()).visit)
    assert root is not None

# Generated at 2022-06-23 22:46:55.460655
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    assert MetaclassTransformer.visit_Module({'body': []}) == \
        ast.Module(body=[
            ast.ImportFrom(
                module='six',
                names=[
                    ast.alias(
                        name='with_metaclass',
                        asname='_py_backwards_six_withmetaclass',
                        )
                    ],
                level=0
                )
            ])



# Generated at 2022-06-23 22:47:00.937340
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = """
    class A(metaclass=B):
        pass
    """
    expected_code = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    result = MetaclassTransformer.run_pipeline(code)
    assert str(result) == expected_code

# Generated at 2022-06-23 22:47:01.931872
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:47:07.038221
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast.ast3 import Module
    from typed_ast.ast3 import ClassDef
    from typed_ast.ast3 import Name
    from typed_ast.ast3 import arguments
    from typed_ast.ast3 import arg
    from typed_ast.ast3 import Keyword

    class A(): pass
    class B(): pass


# Generated at 2022-06-23 22:47:08.831569
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ...transpiler import Transpiler
    from .six_transformer import SixTransformer

# Generated at 2022-06-23 22:47:16.588455
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse(textwrap.dedent("""\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(metaclass=B):
        pass
    """))

    MetaclassTransformer().visit(node)

    expected_node = ast.parse(textwrap.dedent("""\
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """))

    assert ast.dump(node) == ast.dump(expected_node)


# Generated at 2022-06-23 22:47:23.510809
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import textwrap

    node = ast.parse(textwrap.dedent("""\
        class A(metaclass=abc.ABCMeta):
            def f():
                pass
        """))
    MetaclassTransformer().visit(node)
    expected_node = ast.parse(textwrap.dedent("""\
        class A(_py_backwards_six_with_metaclass(abc.ABCMeta), object):
            def f():
                pass
        """))
    assert ast.dump(node) == ast.dump(expected_node)



# Generated at 2022-06-23 22:47:26.563426
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse("""
        class A(metaclass=B):
            pass
        """)

    transformer = MetaclassTransformer(module)

    assert transformer._tree_changed is False
    assert transformer.visit(module) == module
    assert transformer._tree_changed is True

    in_module = """
        from six import with_metaclass as _py_backwards_six_withmetaclass  

        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """

    assert ast.dump(module, include_attributes=True) == ast.dump(ast.parse(in_module), include_attributes=True)

# Generated at 2022-06-23 22:47:27.071516
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:47:33.961138
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source
    from ..utils.node import single_nodes
    m = source('''
    class A(metaclass=B):
        pass
    ''')
    assert m == single_nodes(MetaclassTransformer().visit(m))