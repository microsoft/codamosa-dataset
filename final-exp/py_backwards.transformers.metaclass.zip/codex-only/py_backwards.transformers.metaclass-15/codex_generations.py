

# Generated at 2022-06-23 22:37:33.717290
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    assert b'_py_backwards_six_withmetaclass' in MetaclassTransformer.visit_Module(None, ast.parse('class A(metaclass=B): pass')).body[0].args.args[0].s  # type: ignore
    assert b'_py_backwards_six_withmetaclass' not in MetaclassTransformer.visit_Module(None, ast.parse('class A: pass')).body[0].args.args[0].s  # type: ignore
    assert b'_py_backwards_six_withmetaclass' not in MetaclassTransformer.visit_Module(None, ast.parse('class A(object, metaclass=B): pass')).body[0].args.args[0].s  # type: ignore


# Generated at 2022-06-23 22:37:43.165617
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.node_visitor import NodeVisitor
    import ast
    import unittest
    class TestMetaclassTransformer(unittest.TestCase):

        def test_visit_ClassDef(self):

            source = '''
            class A(object):
                pass
            '''
            tree = ast.parse(source)
            tree_visitor = NodeVisitor()
            tree_visitor.visit(tree)
            print(tree)
            self.assertTrue(isinstance(tree_visitor.results['ClassDef'],list))
            self.assertTrue(len(tree_visitor.results['ClassDef'])==1)
            self.assertTrue(isinstance(tree_visitor.results['ClassDef'][0],ast.ClassDef))

# Generated at 2022-06-23 22:37:44.380999
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

# Generated at 2022-06-23 22:37:50.757863
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()
    module = ast.parse("""
    class A(metaclass=B):
        pass""")

    transformer.visit(module)
    assert module.body == six_import.get_body() + class_bases.get_body(metaclass=ast.Name(id='B'),
                                                                       bases=ast.List(elts=[], ctx=ast.Load()))

# Generated at 2022-06-23 22:37:53.690500
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    node = ast.parse('class A(metaclass=type): pass')
    MetaclassTransformer().visit(node)
    code = compile(node, filename='<string>', mode='exec')
    exec(code)
    assert class_bases().__bases__ == (type,)

# Generated at 2022-06-23 22:37:54.653202
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:38:05.734938
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast
    import sys
    import six

    # Test with a class that has a metaclass argument
    args = [ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)]
    kwargs = [ast.keyword(arg='metaclass',
                          value=ast.Name(id='metaclass'))]
    class_def = ast.ClassDef(name='A', bases=args,
                             keywords=kwargs,
                             body=[ast.Pass()])
    six_module = six.__file__.rsplit('/')[0] + '/six.py'
    module = ast.Module(body=[class_def], type_ignores=[])
    old_sys_path = sys.path

# Generated at 2022-06-23 22:38:10.307675
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import unittest

    class TestMetaclassTransformer(unittest.TestCase):
        def test_MetaclassTransformer(self):
            from ..utils import test_utils

            test_utils.assert_source_equal(
                MetaclassTransformer,
                '''
                class A(metaclass=type):
                    pass
                ''',
                '''
                from six import with_metaclass as _py_backwards_six_withmetaclass
                class A(_py_backwards_six_withmetaclass(type)):
                    pass
                ''')

    unittest.main()

transform = MetaclassTransformer().visit

# Generated at 2022-06-23 22:38:11.391973
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_astunparse
    

# Generated at 2022-06-23 22:38:21.680843
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..parsers import class_
    from ..compilers import compile_src
    from ..utils.source import Source
    from .test_helpers import compile_snippets
    from .test_helpers import dedent_ftl
    from .test_helpers import assertEqualFiles

    six_import_src = dedent_ftl("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
    """)

    class_bases_src = dedent_ftl("""
        _py_backwards_six_withmetaclass(metaclass, *bases)
    """)

    source = dedent_ftl("""
        class A(metaclass=B):
            pass
    """)


# Generated at 2022-06-23 22:38:32.350444
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import os

    import astor
    import six

    from ..utils.tree import parse_module

    if six.PY2:
        import mock

        import sys
        sys.modules['six'] = mock.Mock()
        del sys

    source = "class A(metaclass=B): pass"
    node = parse_module(source)

    transformer = MetaclassTransformer()
    transformer.visit(node)

    assert transformer._tree_changed

    assert astor.to_source(node).strip() == "from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B, object))"

# Generated at 2022-06-23 22:38:34.047721
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:38:39.929134
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse("class A(object): pass")
    transformer = MetaclassTransformer()
    transformer.visit(module)
    assert transformer._tree_changed is False
    module = ast.parse("class A(metaclass=object): pass")
    transformer = MetaclassTransformer()
    transformer.visit(module)
    assert transformer._tree_changed is True



# Generated at 2022-06-23 22:38:42.212782
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer(None, None).__class__.__name__ == \
           'MetaclassTransformer'

# Generated at 2022-06-23 22:38:49.560693
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source
    from ..utils.compare_ast import compare_ast
    
    source = source('''
        class A(metaclass=B):
            pass
        ''')
    expected = source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        ''')
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    compare_ast(tree, expected)

# Generated at 2022-06-23 22:38:50.151253
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:38:53.215685
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import PythonVersion
    from .six import SixTransformer
    from .to_function import LambdaTransformer

# Generated at 2022-06-23 22:39:04.053012
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import textwrap
    from .base import Parser
    from ..utils.source import Source
    from ..utils.tree import ast_pprint, dump_ast_node

    source = Source(textwrap.dedent(r"""\
        class Base(object): pass
        class A(Base, metaclass=type): pass
    """))

    tree = Parser(source).parse()

    print(ast_pprint(tree))
    print('\n\n')

    TreeTransformer(tree).apply(MetaclassTransformer)

    print(ast_pprint(tree))
    print('\n\n')

    print(source.getsource(tree))
    print('\n\n')

    for node in ast.walk(tree):
        dump_ast_node(node)

# Generated at 2022-06-23 22:39:13.411476
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """Tests the constructor of the class MetaclassTransformer."""
    node = ast.ClassDef(name=ast.Name(id='A', ctx=ast.Load()), bases=[], keywords=[],
                        body=[], decorator_list=[])
    expected_node = ast.ClassDef(name=ast.Name(id='A', ctx=ast.Load()), bases=[], keywords=[],
                                 body=[], decorator_list=[])
    new_node = MetaclassTransformer().visit(node)
    assert ast.dump(new_node) == ast.dump(expected_node)

    node.bases = [ast.Name(id='object', ctx=ast.Load())]

# Generated at 2022-06-23 22:39:18.351789
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class TestTransformer(MetaclassTransformer):
        def visit_name(self, node):
            pass

    class TestTransformer2(MetaclassTransformer):
        def visit(self, *args, **kwargs):
            pass

    assert TestTransformer.__name__ == 'TestTransformer'
    assert TestTransformer2.__name__ == 'TestTransformer2'

# Generated at 2022-06-23 22:39:21.977012
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from code import Source
    from ..utils.testutils import assert_transform, parse, dump

    code = Source("""
    from abc import ABCMeta
    class Test(metaclass=ABCMeta):
        pass
    """
    )

    res = dump(parse(code))
    assert_transform(MetaclassTransformer, code, res)

# Generated at 2022-06-23 22:39:23.899046
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:39:25.934999
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class_body = (
        ast.Pass()
    )

# Generated at 2022-06-23 22:39:36.324244
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import textwrap
    import unittest
    from typed_ast.ast3 import fix_missing_locations
    from ..utils.tree import print_tree, str_tree
    from ..utils.context import Context
    from ..compiler import compile_code, string

    class TestMetaclassTransformer_visit_Module(unittest.TestCase):
        maxDiff = None
        longMessage = True
        context = Context()
        context.imports = ['six', 'typing']
        context.python_version = (3, 8)

        def test_simple(self):
            source = textwrap.dedent(
                '''\
                from typing import List
                class A(metaclass=List):
                    pass
                ''')

# Generated at 2022-06-23 22:39:39.948212
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ast import parse
    from six import PY3

    if not PY3:
        from typed_ast import NodeTransformer
        from .six import test_six_transformer

        test_six_transformer(MetaclassTransformer, 'six', 'class')


# Generated at 2022-06-23 22:39:47.805929
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..module import Module
    import ast

    module = Module(path=__file__).parse()

    node = ast.parse("""
    class A(metaclass=B):
        pass
    """)

    metaclass_transformer = MetaclassTransformer()

    with module.patched_context() as ctx:
        transformed_node = metaclass_transformer.visit(node)
        assert ctx.patched == {
            'modules': {'six'},
            'aliases': {'six.with_metaclass': '_py_backwards_six_withmetaclass'},
            'snippets': {'six_import'},
            'classes': {'B'},
            'functions': {'class_bases'}
        }
        assert metaclass_transformer

# Generated at 2022-06-23 22:39:48.465224
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:39:56.015581
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Setup
    from py_backwards.transformers.metaclass import MetaclassTransformer
    from typed_ast import ast3 as ast
    import inspect
    import textwrap

    # Exercise
    module_transformer = MetaclassTransformer(None, {}, True)
    source = textwrap.dedent(inspect.getsource(test_MetaclassTransformer_visit_Module)).strip()
    tree = ast.parse(source)

    # Verify
    assert not hasattr(module_transformer, 'six_import_added')
    module_transformer.visit(tree)
    assert module_transformer.six_import_added

    source_lines = source.split('\n')

# Generated at 2022-06-23 22:39:58.251130
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ... import compile
    from .test_utils import wrap, transform_test_module

    class TestModule(compile.Module):
        @wrap('a')
        class D(metaclass=type):
            pass

    transform_test_module(TestModule, MetaclassTransformer)



# Generated at 2022-06-23 22:40:04.161083
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast

    source = "class A(metaclass=B): pass"
    mod = ast.parse(source)
    node = mod.body[0]

    mt = MetaclassTransformer()
    mt.visit(mod)

    assert type(node) is ast.ClassDef
    assert len(node.keywords) == 0
    assert len(node.bases) == 1

    import six
    assert six.PY2

# Generated at 2022-06-23 22:40:12.211433
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Generate test case program.
    t = MetaclassTransformer()
    c = ast.parse('class A(metaclass=B): pass').body[0]  # type: ignore
    c = t.visit_ClassDef(c)

    # Verify that the program is as expected.
    assert ast.dump(c) == "ClassDef(name='A', bases=[Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), args=[Name(id='B', ctx=Load())], keywords=[])], body=[], decorator_list=[])"

# Generated at 2022-06-23 22:40:19.348836
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from six import PY3

    class Foo:
        pass

    class Bar(Foo, metaclass=type):
        pass

    class B:
        def baa(self):
            return 1

    class A(metaclass=B):
        pass

    # class C(metaclass=type, some_attr=1):
    #     pass

    sample = ast.parse("""
        def baz(self):
            return 2
    """)

    A.baa = B.baa
    A.baz = baz


# Generated at 2022-06-23 22:40:22.468229
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys, os
    sys.path.append(os.path.dirname(__file__))
    from ..utils.run_python_module import run_python_module
    run_python_module(__file__, 'test_MetaclassTransformer.py')

# Generated at 2022-06-23 22:40:30.583457
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
    class Foo(metaclass=type):
        pass
    """
    tree = ast.parse(code)
    mt = MetaclassTransformer()
    updated_tree = mt.visit(tree)
    result = ast.dump(updated_tree)
    expected = """Module(body=[
    ClassDef(name='Foo', 
        bases=[Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), args=[Name(id='type', ctx=Load())], keywords=[])], body=[], decorator_list=[])
])"""
    assert result == expected

# Generated at 2022-06-23 22:40:36.895361
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .base import BaseTestTransformer
    import ast
    code = """class A(metaclass=B):
        pass"""
    tree = ast.parse(code)
    t = MetaclassTransformer()
    t.transform(tree)
    assert type(tree.body[0].bases[0]) == ast.Call
    expected = """from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B))"""
    assert BaseTestTransformer.to_source(tree) == expected

# Generated at 2022-06-23 22:40:42.206978
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    with temporary_directory() as tmpdir:
        with open(os.path.join(tmpdir,'test_MetaclassTransformer.py'),'w') as f:
            f.write("""class A(metaclass=object):
    pass
""")
        importer = Importer(tmpdir)
        result = importer.import_file('test_MetaclassTransformer')
        assert result.tree.body[0].bases[0].func.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-23 22:40:44.360358
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:40:54.077474
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # type: () -> None
    class A(object):
        pass

    class B(type):
        pass

    class C(A, B, metaclass=B):
        pass
    assert C.__mro__ == (C, A, B, object)

    tree = compile(dedent('''
            class A(object):
                pass
    
            class B(type):
                pass
    
            class C(A, B, metaclass=B):  # @NoEffect
                pass
            '''), '<test>', 'exec')
    result = MetaclassTransformer().visit(tree)
    compiled = compile(result, '<test>', 'exec')

# Generated at 2022-06-23 22:40:57.764892
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a = 'a = 1'
    code = 'class A(object, metaclass=B): pass'
    expected = 'class A(_py_backwards_six_withmetaclass(B), object): pass'
    node = ast.parse(code)
    node = MetaclassTransformer().visit(node)
    actual = ast.unparse(node)
    assert expected == actual, actual

# Generated at 2022-06-23 22:41:08.585252
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .test_base import compile_tree, check_tree
    code = """class A(metaclass=B):
    pass"""
    expected_tree = ast.Module(body=[six_import.get_body(), ast.ClassDef(name='A',
      bases=[ast.Call(func=ast.Name(id='_py_backwards_six_withmetaclass', ctx=ast.Load()),
        args=[ast.Name(id='B', ctx=ast.Load()), ast.Name(id='object', ctx=ast.Load())],
        keywords=[], starargs=None, kwargs=None)], 
      keywords=[], body=[], decorator_list=[])])

    tree = compile_tree(code, node_transformer=MetaclassTransformer)

# Generated at 2022-06-23 22:41:11.514323
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    import six
    import typed_astunparse
    from py_backwards.transformers.metaclass import MetaclassTransformer

# Generated at 2022-06-23 22:41:14.147207
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    src = """class A(metaclass=B): pass"""

# Generated at 2022-06-23 22:41:15.456480
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:41:22.018063
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()
    assert transformer._tree_changed == False
    node = ast.parse('class A(B):\n    pass')
    out_node = transformer.visit(node)
    assert transformer._tree_changed == True
    assert out_node._fields == ('body',)
    assert out_node.body[1].name == 'A'
    assert out_node.body[1].bases[0].func.id == '_py_backwards_six_with_metaclass'
    assert out_node.body[1].bases[0].args[0].id == 'B'

# Generated at 2022-06-23 22:41:29.817619
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert MetaclassTransformer.visit_ClassDef(
        [],
        ast.ClassDef(
            name='A',
            bases=[],
            body=[],
            keywords=[ast.keyword(arg='metaclass', value=None)],
            decorator_list=[]
        )
    ) == ast.ClassDef(
        name='A',
        bases=ast.List(elts=[], ctx=ast.Load()),
        body=[],
        decorator_list=[]
    )


# Generated at 2022-06-23 22:41:33.257581
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = """class A(metaclass=B):\n    pass"""
    expected_code = """from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass"""
    tree = ast.parse(code)
    transformer = MetaclassTransformer()
    result_tree = transformer.visit(tree)
    result_code = codegen.to_source(result_tree)
    assert result_code == expected_code, "expected `%s` but got `%s`" % (expected_code, result_code)



# Generated at 2022-06-23 22:41:40.952952
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils import cst
    node = ast.parse("class A(metaclass=B): pass")
    class_def = node.body[0]
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)

    assert len(transformer.local_imports) == 1
    import_statement = transformer.local_imports['six'][0]

    assert isinstance(import_statement, ast.ImportFrom)
    assert len(import_statement.names) == 1
    assert import_statement.names[0].name == 'with_metaclass'
    assert import_statement.names[0].asname == '_py_backwards_six_withmetaclass'


# Generated at 2022-06-23 22:41:45.514509
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # branch #1
    expected = ast.parse('from six import with_metaclass as _py_backwards_six_with_metaclass')
    tree = MetaclassTransformer()
    tree.visit(six_import.get_ast('module'))

    assert ast.dump(tree.ast, include_attributes=False) == ast.dump(expected, include_attributes=False)



# Generated at 2022-06-23 22:41:46.886750
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:41:50.896929
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse('''
        class A():
            pass
    ''')
    trans = MetaclassTransformer()
    node = trans.visit(node)
    assert not trans._tree_changed, 'should not changed'

    node = ast.parse('''
        class A(metaclass=B):
            pass
    ''')
    trans = MetaclassTransformer()
    node = trans.visit(node)
    assert len(node.body[0].bases) == 1
    assert len(node.body[0].bases[0].args) == 2
    assert type(node.body[0].bases[0].args[0]) == ast.Name

# Generated at 2022-06-23 22:41:53.858424
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    inp = """class C(metaclass=type): pass"""

# Generated at 2022-06-23 22:42:01.946044
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """
    This test unit checks if the method visit_ClassDef of class
    MetaclassTransformer works properly
    """
    import ast
    from typing import List, Union
    from .base_node_transformer import BaseNodeTransformer
    from .base_transformer import BaseTransformer
    from .tree_transformer import TreeTransformer
    from ..utils.ast import ast_inspector

    code = """
        class A(metaclass=B, foo=bar):
            pass
    """

    class_def = ast.parse(
        code).body[0]  # type: ignore  # noqa: E501
    metaclass_transformer = MetaclassTransformer()
    new_class_def = metaclass_transformer.visit(
        class_def)  # type: ignore  # noqa: E

# Generated at 2022-06-23 22:42:08.847446
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import unittest
    from ..utils.tests import test_node_transformer

    class MetaclassTransformerTest(unittest.TestCase):
        def test_simple(self):
            def test(input_, expected):
                test_node_transformer(self, MetaclassTransformer, input_, expected)


# Generated at 2022-06-23 22:42:10.324451
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer('2.7')

# Generated at 2022-06-23 22:42:11.090407
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:42:17.435955
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .transformer import TransformerVisitor
    from textwrap import dedent

    tree = ast.parse(dedent("""
        class A(metaclass=B):
            pass
    """))  # type: ast.Module

    visitor = TransformerVisitor()
    visitor.visit(tree)

    assert tree.body[0].__class__ == ast.ClassDef
    assert tree.body[1].__class__ == ast.ClassDef


# Generated at 2022-06-23 22:42:24.797055
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import sys
    import textwrap
    from typing import List
    from typed_ast import ast3 as ast

    from typed_astunparse import unparse
    from typed_astunparse.unparser import Unparser
    from ..compiler import Compiler

    with_metaclass: str = """
    class A(metaclass=List):
        pass
    """
    with_bases: str = """
    class A(List):
        pass
    """
    expected_with_metaclass: List[str] = textwrap.dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    class A(_py_backwards_six_withmetaclass(List)):
    
        pass
    """).splitlines(keepends=True)


# Generated at 2022-06-23 22:42:26.320660
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert type(MetaclassTransformer.dependencies) == list
    assert type(MetaclassTransformer.target) == tuple

# Generated at 2022-06-23 22:42:28.865497
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class Dummy(six.with_metaclass(type)):
        pass

    assert Dummy.__mro__ == (Dummy, object)

# Generated at 2022-06-23 22:42:34.325742
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    node = ast.parse("class A(metaclass=B):\n    pass").body[0]
    node = MetaclassTransformer().visit(node)
    assert (astor.to_source(node) ==
            "class A(_py_backwards_six_withmetaclass(B)):\n    pass")


# Generated at 2022-06-23 22:42:44.408867
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.testing import transform_and_compile_fragment
    from ..utils.compat import exec_

    fragment = '''
    class A(metaclass=type):
        pass
    '''
    target = (2, 7)
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(type)):
        pass
    '''
    assert expected.strip() == transform_and_compile_fragment(fragment,
                                                              target=target,
                                                              transformer=MetaclassTransformer
                                                              ).strip()
    exec_('class A(metaclass=type): pass')    # no error

# Generated at 2022-06-23 22:42:44.929358
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:42:45.741492
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:42:48.841387
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..visitor import Py23to27
    class Dummy(object):
        def __init__(self, x):
            self.x = x
    class Dummy2(object):
        def __init__(self, x):
            self.x = x

# Generated at 2022-06-23 22:42:59.782408
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import unittest
    from ..utils.test_utils import assert_equal_ast
    import six
    import textwrap
    class MetaclassTransformerTestCase(unittest.TestCase):
        def setUp(self):
            self.test_object = MetaclassTransformer()

        def test_metaclass_with_bases_state(self):
            code_str = textwrap.dedent("""
                class A(metaclass=type):
                    pass
            """)
            code_object = compile(code_str, '<input>', 'exec', ast.PyCF_ONLY_AST)
            tree = ast.parse(code_str)
            tree_expected = self.test_object.visit(tree)
            tree_expected = MetaclassTransformer().visit(tree_expected)


# Generated at 2022-06-23 22:43:07.953568
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

    assert MetaclassTransformer().visit(ast.Module(body=[ast.ClassDef(name="A",
                                                                       bases=[],
                                                                       keywords=[],
                                                                       body=[])])) == ast.Module(body=[
        ast.ImportFrom(module='six',
                       names=[ast.alias(name='with_metaclass',
                                        asname='_py_backwards_six_withmetaclass')],
                       level=0),
        ast.ClassDef(name='A',
                     bases=[],
                     keywords=[],
                     body=[])])

# Generated at 2022-06-23 22:43:08.926492
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astroid
    from .. import transform


# Generated at 2022-06-23 22:43:14.864296
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from six import with_metaclass as _py_backwards_six_with_metaclass
    node = ast.parse('''\
    class A(B):
        pass
    ''')
    expected = ast.parse('''\
    from six import with_metaclass as _py_backwards_six_with_metaclass
    class A(_py_backwards_six_with_metaclass(B)):
        pass
    ''')
    returned = MetaclassTransformer().visit(node)
    assert ast.dump(returned) == ast.dump(expected)


# Generated at 2022-06-23 22:43:16.749453
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import compile
    from ..helpers import get_ast
    from ..utils.tree import pretty


# Generated at 2022-06-23 22:43:17.281626
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:43:22.023125
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import backwards
    import ast as pyast
    import astor
    import textwrap

    node = pyast.parse(textwrap.dedent("""
        class A(metaclass=B):
            pass
        class B(metaclass=C):
            pass
        """))

    node = backwards.MetaclassTransformer().visit(node)
    print(astor.to_source(node))

# Generated at 2022-06-23 22:43:24.834574
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    t = MetaclassTransformer()

# Generated at 2022-06-23 22:43:33.177783
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from typed_bytes import ByteString

    from ..tests import from_string

    code = ByteString('''\
        class A(metaclass=B):
            pass
    ''')
    new_ast = from_string(code, [MetaclassTransformer])

    assert astor.to_source(new_ast) == '''\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    '''

# Generated at 2022-06-23 22:43:37.187597
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils import get_source

    module = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    MetaclassTransformer().visit(module)
    print(get_source(module))



# Generated at 2022-06-23 22:43:45.224683
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    class_node1 = ast.ClassDef(
        name='A',
        bases=[
            ast.Name(id='object')
        ],
        body=[],
        keywords=[
            ast.keyword(arg='metaclass', value=ast.Name('B'))
        ]
    )
    module_node1 = ast.Module(
        body=[
            class_node1
        ]
    )

# Generated at 2022-06-23 22:43:46.388254
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:43:52.675334
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # type: () -> None
    tree = ast.parse("""
        class Abc(metaclass=def):
            pass
    """)
    transformer = MetaclassTransformer()
    transformer.visit(tree)

    # Uses astor.to_source

# Generated at 2022-06-23 22:44:03.723096
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    metaclass = ast.Str('SomeMetaclass')
    bases = [ast.Name(id='SomeClass', ctx=ast.Load())]
    node = ast.ClassDef(name='TestMetaclass', bases=bases, keywords=[ast.keyword(arg='metaclass', value=metaclass)], body=[])
    module = ast.Module(body=[node])
    expected_module = ast.Module(body=[six_import.get_body(),
                                       ast.ClassDef(name='TestMetaclass', bases=[class_bases.get_body(metaclass=metaclass, bases=bases)],
                                                    keywords=[], body=[])])
    transform = MetaclassTransformer()
    new_module = transform.visit(module)

# Generated at 2022-06-23 22:44:11.617472
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module_src = """
        class A(metaclass=B):
            pass
    """
    expected_src = """
        from six import with_metaclass as _py_backwards_six_with_metaclass
        class A(_py_backwards_six_with_metaclass(B)):
            pass
    """
    expected_tree = ast.parse(expected_src)

    module = ast.parse(module_src)
    MetaclassTransformer().visit(module)

    assert ast.dump(module) == ast.dump(expected_tree)



# Generated at 2022-06-23 22:44:15.198366
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import textwrap
    from typed_ast import ast3
    tree = ast3.parse(textwrap.dedent("""
    class A:
        pass
    """))

    tree = MetaclassTransformer()(tree)
    assert tree != None

# Generated at 2022-06-23 22:44:25.314892
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast

    class A(metaclass=A):
        pass

    module = ast.parse(
        'class A(metaclass=A): pass',
        type_comments=True
    )
    transformer = MetaclassTransformer()
    module = transformer.visit(module)
    assert isinstance(module, ast.Module)
    assert len(module.body) == 2
    assert isinstance(module.body[0], ast.Expr)
    assert isinstance(module.body[0].value, ast.Call)
    assert isinstance(module.body[1], ast.ClassDef)
    assert isinstance(module.body[1].bases[0], ast.Call)
    assert isinstance(module.body[1].bases[0].func, ast.Attribute)
    assert module.body[1].b

# Generated at 2022-06-23 22:44:30.915733
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    from ..utils.tree import ast_dump, ast_parse

    class_code = """class A(metaclass=B):
    pass"""

    six_code = 'from six import with_metaclass as _py_backwards_six_withmetaclass'

    mt = MetaclassTransformer()
    mt.visit(ast_parse(class_code))
    assert(six_code in ast_dump(mt.result))

# Generated at 2022-06-23 22:44:40.005976
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = """
        class A():
            pass
        class B(metaclass=C):
            pass
    """
    node = ast.parse(code)
    new_ast = MetaclassTransformer().visit(node)
    assert ast.dump(new_ast) == """Module(body=[ImportFrom(
            module='six', names=[alias(
            name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0), ClassDef(
            name='A', bases=[], keywords=[], body=[], decorator_list=[]), ClassDef(
            name='B', bases=[_py_backwards_six_withmetaclass(C)], keywords=[], body=[], decorator_list=[])])"""

# Generated at 2022-06-23 22:44:42.217194
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .test_utils import make_test, round_trip
    
    make_test(MetaclassTransformer)
    

# Generated at 2022-06-23 22:44:49.780395
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast
    import typing
    class TestClass:
        """Test class."""

        def visit_Module(self, node):
            return self.generic_visit(node)

    metaclass_transformer = MetaclassTransformer()

# Generated at 2022-06-23 22:44:58.521972
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six

    import typed_ast.ast3 as ast

    from py_backwards.transformers.metaclass import MetaclassTransformer

    class A():
        __metaclass__ = 1

    class B():
        class C():
            __metaclass__ = 1

    class D():
        class E():
            __metaclass__ = 1
        __metaclass__ = 1

    # we need for this to be a real module, since the visitor simulates an insert_body
    module = ast.Module([])

    for stmt in (A(), B(), D()):
        node = ast.parse(six.text_type(stmt))
        transformer = MetaclassTransformer(target=(2, 7))
        transformer.visit(node)
        assert transformer.tree_changed == True
        node = transformer.vis

# Generated at 2022-06-23 22:45:05.831929
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = dedent("""\
    class A(metaclass=B):
        pass
    """)
    expected = dedent("""\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    node = ast.parse(source)
    output = MetaclassTransformer.run_pipeline(node)
    assert ast.dump(node) == ast.dump(ast.parse(expected))



# Generated at 2022-06-23 22:45:15.521905
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

    from ..utils.ast_builder import ast_call, ast_class_def, ast_import_from
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    import six

    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass

    six_import_stmt = ast_import_from(module='six')
    six_import_stmt.names = [ast.alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')]

    class_def = ast_class_def('B', bases=[])

# Generated at 2022-06-23 22:45:16.926783
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astunparse

# Generated at 2022-06-23 22:45:20.362417
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("class A(metaclass=B): pass")

# Generated at 2022-06-23 22:45:24.623321
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    node = ast.parse('x = "Hello"', mode='exec')
    node = MetaclassTransformer().visit(node)
    assert astor.to_source(node) == six_import.text + 'x = "Hello"\n'


# Generated at 2022-06-23 22:45:33.392270
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..basic import BasicTransformer
    from ..utils.snippet import load
    from ..utils.node_util import ast_parse, get_source

    source = load(__file__, 'test_MetaclassTransformer_visit_ClassDef.py')
    tree = ast_parse(source)
    basic_transformer = BasicTransformer()
    tree = basic_transformer.visit(tree)

    transformer = MetaclassTransformer()
    tree = transformer.visit(tree)
    new_source = get_source(tree)

    assert new_source.startswith('from six import with_metaclass as _py_backwards_six_withmetaclass')

# Generated at 2022-06-23 22:45:38.545691
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    m = ast.parse('class A(metaclass=B):\n    pass').body[0]
    result = MetaclassTransformer.run_pipeline(m)
    expected = ast.parse('from six import with_metaclass\nclass A(with_metaclass(B)):\n    pass').body[1]
    assert result == expected

# Generated at 2022-06-23 22:45:44.179989
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    before = module_from_source('''
        class A(metaclass=B):
            pass
    ''')

    after = module_from_source('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')

    assert compile(before, MetaclassTransformer) == after

# Generated at 2022-06-23 22:45:50.145841
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Set up test
    code_to_be_tested = """
        class Foo(metaclass=ABCMeta):
            def m(cls):
                pass
    """
    expected_output = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class Foo(_py_backwards_six_withmetaclass(ABCMeta)):
            def m(cls):
                pass
    """
    actual_output = astor.to_source(MetaclassTransformer.run_pipeline(code_to_be_tested))
    assert expected_output == actual_output


# Generated at 2022-06-23 22:45:59.545287
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from astmonkey import transformers
    statements = ast.parse("""    
        class A(metaclass=B):
            pass
    """)
    transformers.MetaclassTransformer().visit(statements)
    expected_source = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    expected_statements = ast.parse(expected_source)
    assert astor.to_source(expected_statements) == astor.to_source(statements)



# Generated at 2022-06-23 22:46:00.905996
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()

# Generated at 2022-06-23 22:46:08.615066
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():

    from .utils import get_ast, parse_to_class

    source = """
    class A(metaclass=B):
        pass
    """
    tree_expected1 = get_ast(source)
    tree_expected2 = get_ast(source)
    tree_expected2.body[0].bases = class_bases.get_body(metaclass=ast.Name(id='B', ctx=ast.Load()),
                                                        bases=ast.List(elts=[ast.Name(id='object', ctx=ast.Load())]))
    tree_expected2.body[0].keywords = []
    tree_expected1.body = six_import.get_body() + tree_expected1.body

# Generated at 2022-06-23 22:46:10.941461
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    trans = MetaclassTransformer(2.7)


# Generated at 2022-06-23 22:46:19.957792
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .base import unit_test_transform
    from ..python_version import python_version
    from .six import get_six_body

    six_body = get_six_body()

    module = unit_test_transform(MetaclassTransformer, """\
        class A(metaclass=B):
            pass
    """)

# Generated at 2022-06-23 22:46:28.981984
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..testing_utils import with_pyversion
    from .test_helpers import parse_python, compare_ast, assert_equal

    with_pyversion('3.6', MetaclassTransformer.visit_Module)
    node = parse_python('class A(metaclass=B):\n    pass')
    import six
    expected = parse_python(
        'from six import with_metaclass as _py_backwards_six_withmetaclass\n'
        'class A(metaclass=B):\n    pass')
    assert_equal(compare_ast(expected, node), True)



# Generated at 2022-06-23 22:46:33.854399
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import transform

    source = """
        class A(metaclass=B):
            pass
    """

    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    
    assert transform(MetaclassTransformer, source) == expected

# Generated at 2022-06-23 22:46:38.310227
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    source = six_import.get_body().source + '\n'
    source += class_bases.get_body(metaclass=None, bases=None).source + '\n'
    source += astor.to_source(MetaclassTransformer().visit(ast.parse(source)))
    assert source.find('_py_backwards_six_with_metaclass') == -1


transformer = MetaclassTransformer


# Generated at 2022-06-23 22:46:49.225510
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    arr = [ast.ImportFrom(module='six',
                          names=[ast.alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')],
                          level=0)]

# Generated at 2022-06-23 22:46:51.225730
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:46:52.658819
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..transform.module import ModuleTransformer

# Generated at 2022-06-23 22:46:59.140136
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    src = """
    class A(metaclass=B):
        pass
    """
    class_def = ast.parse(src).body[0]
    assert isinstance(class_def, ast.ClassDef)
    result = MetaclassTransformer.run_pipeline([MetaclassTransformer], class_def)
    expected = """
    class A(_py_backwards_six_withmetaclass(B, object)):
        pass
    """
    assert ast.dump(result) == expected

# Generated at 2022-06-23 22:47:01.837864
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .constructor import Constructor, Transformer
    transformer: Transformer = Constructor(MetaclassTransformer)
    assert transformer is not None

# Generated at 2022-06-23 22:47:06.941878
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert_transform(
        MetaclassTransformer,
        'class C(metaclass=S):pass',
        '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class C(_py_backwards_six_withmetaclass(S)):
            pass
        '''
    )

# Generated at 2022-06-23 22:47:07.911730
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:47:08.497159
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:47:09.442207
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:47:13.953008
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class DoesNotExist(metaclass=type):
        pass
    tree = ast.parse(inspect.getsource(DoesNotExist))
    tree = MetaclassTransformer().visit(tree)
    assert compile(tree, '<test>', 'exec')

# Generated at 2022-06-23 22:47:21.849185
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = textwrap.dedent("""
    import six
    
    class B:
        pass
    
    class A(metaclass=B):
        pass
    """)
    expected = textwrap.dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    class B:
        pass
    
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    tree = ast.parse(source)
    transformer = MetaclassTransformer()
    result = transformer.visit(tree)
    assert transformer.dependencies == {'six'}
    assert transformer._tree_changed
    assert ast.dump(result) == ast.dump(ast.parse(expected))

# Generated at 2022-06-23 22:47:32.663871
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    import sys
    from ..fix import fix_code
    from ..utils.source import source
    from ..utils.tree import tree_to_str
    from ..versions import get_current_version
    code = 'class A(object): pass'
    assert tree_to_str(ast.parse(code)) == code
    tree = ast.parse(code)
    MetaclassTransformer.transform_tree(tree)
    assert tree_to_str(tree) == code
    code = 'class A(metaclass = B): pass'
    assert tree_to_str(ast.parse(code)) == code
    tree = ast.parse(code)
    node = MetaclassTransformer.transform_tree(tree)