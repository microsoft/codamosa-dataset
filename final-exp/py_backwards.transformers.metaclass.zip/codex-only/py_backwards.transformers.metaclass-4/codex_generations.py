

# Generated at 2022-06-23 22:37:34.805592
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:37:42.987608
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

    from .six_import import six_import
    from .class_bases import class_bases

    node = ast.Module(body=[ast.ClassDef(name='A',
                                         bases=[ast.Name(id='object', ctx=ast.Load())],
                                         body=[],
                                         keywords=[ast.keyword(arg='metaclass',
                                                               value=ast.Name(id='B', ctx=ast.Load()))])])

    transformed = MetaclassTransformer().visit(node)
    assert transformed.body[0] == six_import.get_body()[0]
    assert transformed.body[2] == node



# Generated at 2022-06-23 22:37:47.365243
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """
    Tests for transformation of class definition:
        class A(metaclass=B):
            pass
    To:
        class A(_py_backwards_six_with_metaclass(B))
    """

# Generated at 2022-06-23 22:37:48.858719
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()

# Generated at 2022-06-23 22:37:50.301419
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:37:58.655959
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    module = ast.parse("""
    class A:
        pass
    """)
    module = MetaclassTransformer.run_pipeline(module)
    assert len(module.body) == 2
    assert module.body[0].body[0].value == 'six'
    assert isinstance(module.body[1], ast.ClassDef)
    assert module.body[1].name == 'A'
    assert isinstance(module.body[1].bases[0], ast.Call)
    assert isinstance(module.body[1].bases[0].func, ast.Name)
    assert module.body[1].bases[0].func.id == '_py_backwards_six_withmetaclass'


# Generated at 2022-06-23 22:38:01.424596
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import astor

    class TestVisitor(ast.NodeVisitor):
        '''
        Test node visitor.
        '''
        def generic_visit(self, node):
            return True


# Generated at 2022-06-23 22:38:05.850789
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = """
        class A(metaclass=B):
            pass
    """
    result = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    compare(code, result, MetaclassTransformer)


# Generated at 2022-06-23 22:38:09.306321
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.waitfor import waitfor
    from .parser import Parser
    from .unparser import Unparser
    from unittest.mock import MagicMock

    # Configure mocks
    waitfor.side_effect = lambda x: x

    # Import methods
    parser = Parser().parse
    unparser = Unparser().unparse
    transform = MetaclassTransformer().transform

    # Create target code

# Generated at 2022-06-23 22:38:10.745781
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    mt = MetaclassTransformer(2, 7)

# Generated at 2022-06-23 22:38:20.986997
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

    class DummyTransformer(BaseNodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            return node

    source = 'class A(metaclass=B):\n    pass'
    tree = ast.parse(source)

    transformer = MetaclassTransformer()
    transformer.visit(tree)
    expected = 'class A(_py_backwards_six_withmetaclass(B)):\n    pass'
    assert ast.dump(tree) == expected

    transformer = DummyTransformer()
    transformer.visit(tree)
    expected = 'class A(_py_backwards_six_withmetaclass(B)):\n    pass'
    assert ast.dump(tree) == expected

# Generated at 2022-06-23 22:38:27.985282
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class Test_MetaclassTransformer(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None # Allows us to assert multi-line strings
            self.old_syntax = """
                class C(metaclass=M):
                    pass
            """
            self.new_syntax = """
                from six import with_metaclass as _py_backwards_six_withmetaclass
                class C(_py_backwards_six_withmetaclass(M)):
                    pass
            """

        def test_if_new_syntax_is_created(self):
            old_node = ast.parse(self.old_syntax)
            old_classdef = old_node.body[0]
            metaclass_transformer = MetaclassTransformer()
            new_classdef

# Generated at 2022-06-23 22:38:38.097991
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import os
    import sys
    from lazy_object_proxy import Proxy
    from py_backwards.meta import MetaVisitor
    from typed_ast import ast3 as ast

    source = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class A(metaclass=B):
        pass
    class A(metaclass=B):
        pass
    class A(metaclass=B):
        pass
    class A(metaclass=B):
        pass
    class A(metaclass=B):
        pass
    '''

# Generated at 2022-06-23 22:38:38.791481
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:38:39.929195
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:38:48.360100
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # 2.7 compatible code
    ast_string = """
    class Test(metaclass=int):
        pass
    """
    # Expected output
    ast_output_string = """
    from six import with_metaclass as _py_backwards_six_withmetaclass 
    class Test(_py_backwards_six_withmetaclass(int, )):
        pass
    """
    test_ast = ast.parse(ast_string)
    new_ast = MetaclassTransformer().visit(test_ast)
    ast_output = ast.dump(new_ast)
    assert ast_output_string == ast_output

# Generated at 2022-06-23 22:38:59.427228
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast

    class X:
        def __init__(self, *args, **kwargs):
            # Example node which should be changed
            class A(metaclass=ABCMeta):
                pass

            # Example node which should not be changed
            class B(metaclass=ABCMeta):
                pass
            self.test_node = A

            # This is the expected result
            class Y: pass
            class Z: pass
            self.expected_node = Y
            self.non_expected_node = Z
            self.append_dependencies()
            self.expected_dependencies = ['six']
            self.append_imports()
            self.expected_import = 'from six import with_metaclass as _py_backwards_six_withmetaclass'


# Generated at 2022-06-23 22:39:05.718739
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = """
    class A(metaclass=type):
        pass
    """

    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(type, object)):
        pass
    """
    actual, _ = MetaclassTransformer().transform_single_file_text(source)
    assert actual == expected

# Generated at 2022-06-23 22:39:06.664979
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:39:14.906593
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import six
    from .base import BaseNodeTransformer
    from .base import TransformerTestCase

    class TestMetaclassTransformer(TransformerTestCase):
        transformer_class = MetaclassTransformer

        def test_metaclass(self):
            code = '''
            class A(metaclass=B):
                pass
            '''
            result = self.transform(code)
            assert 'A = _py_backwards_six_withmetaclass(B, *[])' in result
            assert 'from six import with_metaclass' in result

        def test_metaclass_with_bases(self):
            code = '''
            class A(metaclass=B, C, D):
                pass
            '''
            result = self.transform(code)

# Generated at 2022-06-23 22:39:18.788251
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("class A(metaclass=B): pass")
    actual = MetaclassTransformer().visit(node)
    expected = ast.parse("from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B))")
    assert ast.dump(actual) == ast.dump(expected)


# Generated at 2022-06-23 22:39:22.155181
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    s = """
        class A(metaclass=B):
            pass
        """
    emitted = MetaclassTransformer.run_simple(s)
    assert "from six" in emitted
    assert "metaclass=B" not in emitted
    assert "class A(_py_backwards_six_with_metaclass(B)" in emitted
 

# Generated at 2022-06-23 22:39:26.611470
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    mt = MetaclassTransformer()
    module: ast.Module = ast.parse('class A(metaclass=B): pass')
    module = mt.visit(module)

# Generated at 2022-06-23 22:39:33.984301
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...testing import assert_code_equal
    from ...testing import run_transform
    code = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    new_code = run_transform(MetaclassTransformer, code)
    assert_code_equal(new_code, expected)

# Generated at 2022-06-23 22:39:42.631029
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import Source
    from ..transformer import Transformer
    from ..version import Version
    import warnings

    warnings.simplefilter("error", category=DeprecationWarning)

    code = Source("""
                 class Meta(type):
                     pass
                 class A(metaclass=Meta):
                     pass
                 class B(object, metaclass=Meta):
                     pass
                 class C(object, A, metaclass=Meta):
                     pass
                 """)
    version = Version(3, 8)
    tree = ast.parse(code)
    transformer = Transformer(version, [MetaclassTransformer])
    transformer.visit(tree)

# Generated at 2022-06-23 22:39:50.546835
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...utils import ast_parse

    code = '''
        class A:
                pass
    '''
    tree = ast_parse(code)
    trans = MetaclassTransformer()
    for node in ast.walk(tree):
        if isinstance(node, ast.Module):
            trans.visit(node)

    expected = '''
            from six import with_metaclass as _py_backwards_six_withmetaclass


        class A(_py_backwards_six_withmetaclass(None)):
            pass
    '''
    assert ast.unparse(tree).strip() == expected.strip()



# Generated at 2022-06-23 22:39:55.820346
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class_def = ast.parse('class A(metaclass=B): pass')
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(class_def)
    print(ast.dump(class_def))
    expected = six_import.get_body() + class_bases.get_body(metaclass=ast.Name(id='B'),
                                                            bases=ast.List(elts=[]),
                                                            )
    assert metaclass_transformer.generic_visit(class_def) == expected

# Generated at 2022-06-23 22:39:58.834608
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import assert_recursive_node

    m = ast.parse("from six import with_metaclass as _py_backwards_six_withmetaclass\n"
                  "class A(metaclass=B,):\n"
                  "  pass\n",
                  mode="exec")

    t = MetaclassTransformer()
    assert_recursive_node(t.visit(m), m)



# Generated at 2022-06-23 22:40:06.608574
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    @snippet
    def before():
        class B(metaclass=type):
            pass

    @snippet
    def after():
        class B(_py_backwards_six_withmetaclass(type)):
            pass

    transformer = MetaclassTransformer()
    result = transformer.visit(ast.parse(before.get_body()))
    print(result)
    fixed = ast.parse(after.get_body())
    fixed.body[0].body = []
    assert ast.dump(result) == ast.dump(fixed)

# Generated at 2022-06-23 22:40:16.209026
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    six_import.get_body()[0].lineno = 0
    six_import.get_body()[0].col_offset = 0

# Generated at 2022-06-23 22:40:18.404011
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    b = MetaclassTransformer()
    assert b.name == 'six.MetaclassTransformer'


if __name__ == '__main__':
    # Test snippet
    six_import()
    class_bases(metaclass=object, bases=(object, ))

# Generated at 2022-06-23 22:40:22.157720
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    assert six_import.get_source() == 'from six import with_metaclass as _py_backwards_six_withmetaclass'
    assert six_import.get_body().body[0].names[1].name == '_py_backwards_six_withmetaclass'


# Generated at 2022-06-23 22:40:28.494726
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    source = """with_metaclass(A, B)"""
    node = ast.parse(source)
    tree = MetaclassTransformer().visit(node)
    result = astor.to_source(tree)
    assert result == \
"""from six import with_metaclass as _py_backwards_six_withmetaclass
_py_backwards_six_withmetaclass(A, B)"""


# Generated at 2022-06-23 22:40:36.627839
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import inspect
    import ast
    source = inspect.getsource(ast.ClassDef)
    source = source.replace(
        'bases=[expr],', 'metaclass=expr2, bases=[expr],')
    source = source.replace('self._fields =',
                            'self.keywords = []\n            self._fields =')
    tree = ast.parse(source)
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(tree)
    assert len(metaclass_transformer._errors) == 0

# Generated at 2022-06-23 22:40:43.935051
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..views import make_view
    from ..utils.snippet import load_snippet
    from ... import py2 as py2

    snippet_code = """
    class MyClass(metaclass=MyMeta):
        def __init__(self, a):
            self.a = a
    """
    code = load_snippet(snippet_code.strip())
    expected = load_snippet("""
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class MyClass(_py_backwards_six_withmetaclass(MyMeta, object)):
        def __init__(self, a):
            self.a = a
    """.strip())
    assert make_view(py2(code)) == make_view(expected)

# Generated at 2022-06-23 22:40:46.993478
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("class A(metaclass=B): pass")
    t = MetaclassTransformer()
    t.visit(node)
    assert ast.dump(node) == ast.dump(ast.parse("from six import with_metaclass as _py_backwards_six_withmetaclass\n"
                                                "class A(_py_backwards_six_withmetaclass(B)): pass"))


# Generated at 2022-06-23 22:40:50.662359
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("class A(metaclass=B):pass")
    MetaclassTransformer().visit(node)


# Generated at 2022-06-23 22:40:58.892490
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..test_utils import make_test_case, assert_parsed


# Generated at 2022-06-23 22:41:09.212686
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()

    # visit_ClassDef of ClassDef
    class_def = ast.ClassDef(
        name="Test",
        keywords=[ast.keyword(
            arg="metaclass",
            value=ast.Name(
                id="type",
                ctx=ast.Load()
            )
        )],
        body=[],
        decorator_list=[]
    )
    
    result = transformer.visit_ClassDef(class_def)
    result = ast.fix_missing_locations(result)

    # visit_ClassDef of ClassDef without metaclass
    class_def = ast.ClassDef(
        name="Test",
        keywords=[],
        body=[],
        decorator_list=[]
    )
    

# Generated at 2022-06-23 22:41:17.447407
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # type: () -> None
    node = ast.parse('''class A(metaclass=B): pass''')
    MetaclassTransformer().visit(node)
    assert ast.dump(node) == '''\
Module(body=[
    ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0),
    ClassDef(name='A', bases=[_py_backwards_six_withmetaclass(B)], keywords=[], body=[Pass()], decorator_list=[])])
'''  # noqa


# Generated at 2022-06-23 22:41:23.686538
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Fixture
    test_tree: ast.Module = ast.parse("""
        class A(metaclass=B):
            pass
        """)

    # Test
    result: ast.Module = MetaclassTransformer().visit(test_tree)

    # Assert result
    expected_result: ast.Module = ast.parse("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """)
    assert ast.dump(result, include_attributes=False) == ast.dump(expected_result, include_attributes=False)

# Generated at 2022-06-23 22:41:24.676642
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:41:25.243561
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:41:25.836069
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:41:30.745485
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse("""
    class A(metaclass=B):
        pass
    """)  # type: ast.AST
    assert MetaclassTransformer(None).visit(node) == ast.parse("""
    class A(_py_backwards_six_with_metaclass(B)):
        pass
    """)

# Generated at 2022-06-23 22:41:39.296468
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()

    @snippet
    def code():
        class Foo():
            pass

    new_code = transformer.visit(code.get_ast())
    assert six_import.get_body() == new_code.body[0]
    assert ast.parse(str(code)) == ast.parse(str(new_code.body[1]))

    @snippet
    def code():
        class Foo(metaclass=type):
            pass

    new_code = transformer.visit(code.get_ast())
    assert six_import.get_body() == new_code.body[0]
    assert ast.parse(str(code)) == ast.parse(str(new_code.body[1]))


# Generated at 2022-06-23 22:41:45.357977
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from six import assertRegex
    import ast
    import py_backwards.transformers.metaclass
    from py_backwards.transformers.metaclass import MetaclassTransformer
    from py_backwards.utils.snippet import snippet
    from py_backwards.utils.tree import dump_ast
    from ..utils.source_helpers import ast_from_source
    @snippet
    def source_before():
        class A(metaclass=B):
            pass
    @snippet
    def expected_source_after():
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B, object)):
            pass

# Generated at 2022-06-23 22:41:47.620147
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer(None).__class__.__name__ == 'MetaclassTransformer'

# Generated at 2022-06-23 22:41:56.937446
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast as py_ast
    import utils.tree as tree
    
    def get_statements(test_input, expected, test_description="test"):
        tree_to_test = tree.get_ast_tree(test_input)
        transformer = MetaclassTransformer()
        new_tree = transformer.visit(tree_to_test)
        assert transformer._tree_changed == True
        assert transformer._dependencies == ['six']
        actual = tree.ast_to_code(new_tree)
        assert actual == expected, "{0} failed. Expected:\n{1}\ngot:\n{2}".format(test_description, expected, actual)
    
    test_input = '''class A(metaclass=B):
        pass'''

# Generated at 2022-06-23 22:42:03.909935
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = (
        'class A(b, c, metaclass=B, d=42):\n'
        '    pass'
    )
    expected_code = (
        'from six import with_metaclass as _py_backwards_six_withmetaclass\n'
        '\n'
        '\n'
        'class A(_py_backwards_six_withmetaclass(B), *[b, c]): pass\n'
        '\n'
    )
    module = parse_ast(code)
    assert MetaclassTransformer(module, None).tree_changed
    assert to_source(module) == expected_code

# Generated at 2022-06-23 22:42:05.136084
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor

# Generated at 2022-06-23 22:42:06.189542
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:42:13.487511
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    node = ast.parse('class A(metaclass=B):\n\tpass')
    for _ in MetaclassTransformer().visit(node):
        pass
    assert ast.dump(node) == 'Module(body=[ImportFrom(module=\'six\', names=[alias(name=\'with_metaclass\', asname=\'_py_backwards_six_withmetaclass\')], level=0), ClassDef(name=\'A\', bases=[Call(func=Name(id=\'_py_backwards_six_withmetaclass\', ctx=Load()), args=[Name(id=\'B\', ctx=Load())], keywords=[], starargs=None, kwargs=None)], body=[Pass()], decorator_list=[])])'

# Generated at 2022-06-23 22:42:20.729770
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    src = """
        import six
        class A(metaclass=C):
            pass
        """
    res = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(C)):
            pass
        """

    tree = ast.parse(src)
    t = MetaclassTransformer()
    t.visit(tree)
    generated = astor.to_source(tree)
    assert(res in generated)



# Generated at 2022-06-23 22:42:24.480956
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    sample = """
    class A(metaclass=B):
        pass
    """
    t = MetaclassTransformer()
    tree = ast.parse(sample)
    t.visit(tree)
    sample2 = ast.dump(tree)
    assert "six" in sample2
    assert "_py_backwards_six_withmetaclass" in sample2

# Generated at 2022-06-23 22:42:35.125494
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ast_pprint import pprint
    from six import PY2
    from .test_utils import compile_snippet, should_raise

    # test case 1
    code = """
        class A:
            pass
    """
    tree = compile_snippet(code, 'single', 'exec')
    node = tree.body[0]
    node = MetaclassTransformer(PY2, logging.getLogger()).visit(node)  # type: ignore
    # check result
    assert_tree_equal(node, ast.ClassDef(name='A',
                                         bases=[],
                                         keywords=[],
                                         starargs=None,
                                         kwargs=None,
                                         body=[],
                                         decorator_list=[]))

    # test

# Generated at 2022-06-23 22:42:45.421378
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import ClassDef, Name, Module, arguments, mod, Expr, Str, parse
    from six import add_metaclass

    @add_metaclass(str)
    class A:
        pass

    module = parse(textwrap.dedent(inspect.getsource(A)))
    node = module.body[0]
    assert isinstance(node, ClassDef)
    assert node.keywords

    MetaclassTransformer().visit(node)
    module = Module(body=[node])

    assert not node.keywords
    assert isinstance(node.bases[0], Expr)
    assert str(node.bases[0].value) == "six.with_metaclass(metaclass=str, *(A,))"



# Generated at 2022-06-23 22:42:56.898333
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()
    node = ast.parse("class A(): pass")
    new_node = transformer.visit(node)
    assert(new_node == node)

    node = ast.parse("class A(metaclass=B): pass")
    new_node = transformer.visit(node)

# Generated at 2022-06-23 22:42:57.540055
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:43:07.399312
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    test_input = ast.Module([
        ast.ClassDef(
            name='D',
            bases=[
                ast.Name(id='object', ctx=ast.Load()),
            ],
            keywords=[
                ast.keyword(arg='metaclass', value=ast.Name(id='A', ctx=ast.Load())),
            ],
            body=[
            ],
            decorator_list=[],
        )
    ], [])

# Generated at 2022-06-23 22:43:12.394295
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.fixtures import make_test_function, make_test_class
    from ..utils.source import source
    from ..utils.compare import expect

    test_class = make_test_class(
        name='A',
        bases=['B'],
        keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='C'))]
    )

    module = ast.Module(body=[test_class])
    expected = module
    expect(MetaclassTransformer, module, expected, target_versions={(2, 7)})

# Generated at 2022-06-23 22:43:16.666287
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .compile_ import compile_
    from .helper import expect

    class A(metaclass=int):
        pass

    expect(compile_(A, target=MetaclassTransformer.target), """
    class A(_py_backwards_six_withmetaclass(int)):
        pass
    """)



# Generated at 2022-06-23 22:43:18.644908
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert six_import.get_body()
    assert class_bases.get_body(metaclass=(ast.Name()), bases=(ast.Name()))

# Generated at 2022-06-23 22:43:19.556595
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

# Generated at 2022-06-23 22:43:27.087972
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import run_test_nodes
    from ..utils.test_utils import assert_tree_changed
    from typed_ast.ast3 import FunctionDef, arguments, Name, Load
    from typed_ast.ast3 import ClassDef, Pass, Assign, NameConstant, Str
    from typed_ast.ast3 import arguments

    class TestClass(object):
        def __init__(self):
            pass

    source = '''
    class TestClass(metaclass=abc.ABCMeta):
        def __init__(self):
            pass
        
    class TestClass2(object):
        def __init__(self):
            pass
        
    '''

# Generated at 2022-06-23 22:43:33.189724
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    classDef = ast.parse("""
        class A(metaclass=B):
            pass""").body[0]  # type: ignore

    metaclassTransformer = MetaclassTransformer()
    metaclassTransformer.visit(classDef)

    assert repr(classDef) == repr(ast.parse("""
        class A(_py_backwards_six_withmetaclass(B)):
            pass""").body[0])

# Generated at 2022-06-23 22:43:42.620105
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import parse, dump, NodeTransformer
    from ..utils.test import assert_node_equals
    from ..utils.test import AutoFileImport, AutoImport
    from ..utils.test import BaseCase
    import textwrap
    from .six import six_import
    from .six import withmetaclass_for_metaclass

    class TestCase(BaseCase):
        transformer = MetaclassTransformer
        target = (2, 7)
        module_dependencies = ['six']
        function_dependencies = []

        def test_metaclass(self):
            code = '''
            class A(metaclass=B):
                pass
            '''

# Generated at 2022-06-23 22:43:44.365810
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:43:45.378918
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    obj = MetaclassTransformer()
    assert True

# Generated at 2022-06-23 22:43:50.735166
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from typing import List
    from ..utils.test import to_source
    from .base import BaseNodeTransformer
    from .six import six_import
    from .six import class_bases

    # Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:43:54.477685
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # type: () -> None
    mt = MetaclassTransformer(None)
    module = ast.parse("""
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(metaclass=int):
            pass
        """)
    assert mt.visit(module) is not None

# Generated at 2022-06-23 22:44:04.961027
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse("class A(metaclass=B):\n    pass")
    original_node = copy.deepcopy(node)
    node = MetaclassTransformer().visit(node)
    try:
        expected_output = ast.parse("from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass")
        assert ast.dump(node) == ast.dump(expected_output)
        assert node.body[1].bases[0] == original_node.body[0].keywords[0].value
    except AssertionError:
        print("AssertionError:")
        print("Expected:")
        print("{}".format(ast.dump(expected_output)))

# Generated at 2022-06-23 22:44:05.960719
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import astor

# Generated at 2022-06-23 22:44:06.831973
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:44:07.982459
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:44:11.268277
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3
    import sys
    sys.version_info = (3, 7)
    code = "class A(metaclass=B): pass"
    node = ast3.parse(code)
    MetaclassTransformer.run(node)
    assert node.body[0].body[0].value.elts[0].value.left.id == 'bases'

# Generated at 2022-06-23 22:44:17.843680
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import compare_ast
    from . import six_transformer
    from . import future_builtins_transformer
    from . import print_function_transformer

    t = MetaclassTransformer()
    t = six_transformer.SixImportTransformer()(t)
    t = future_builtins_transformer.MetaclassTransformer()(t)
    t = print_function_transformer.PrintFunctionTransformer()(t)
    source = """
        class A(metaclass=B): pass
    """
    subtree = ast.parse(source)  # type: ignore
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B, )):
            pass
    """


# Generated at 2022-06-23 22:44:18.702923
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:44:26.529669
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.setup import setup_module
    from ..utils.testing import assert_node

    assert_node(
        MetaclassTransformer(target=None).visit(
            setup_module(
                textwrap.dedent(
                    """\
                    from six import with_metaclass as _py_backwards_six_withmetaclass

                    class A(object, metaclass=type):
                        pass
                    """)
            )),
        textwrap.dedent(
            """\
            class A(_py_backwards_six_withmetaclass(type, object)):
                pass
            """)
    )

# Generated at 2022-06-23 22:44:33.205412
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source
    from ..utils.unparse import unparse

    class_source = """
    class A(metaclass=type):
        pass
    """

    expected_source = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(type)):
        pass
    """

    assert expected_source == unparse(MetaclassTransformer().visit(source(class_source)))

# Generated at 2022-06-23 22:44:40.978906
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    tree = ast.parse("""
        class A(metaclass=B):
            pass
    """)
    node = tree.body[0]

    transformer = MetaclassTransformer()
    transformer.visit_Module(tree)

    # assert_equal is used to handle whitespace on the tree
    assert_equal(ast.dump(tree), ast.dump(ast.parse("""
        from six import with_metaclass as _py_backwards_six_withmetaclass

        _py_backwards_six_withmetaclass(B, *())

        class A(_py_backwards_six_withmetaclass(B, *())):
            pass
    """)))


# Generated at 2022-06-23 22:44:47.984156
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    class T(MetaclassTransformer):
        def __init__(self, tree: ast.Module):
            super().__init__(tree)
            self._tree_changed = False

    example = ast.parse("""
    class A(metaclass=B):
        pass
    """, 'example.py')
    
    code = """
from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass"""
    assert T(example).visit(example) == ast.parse(code)

# Generated at 2022-06-23 22:44:55.605487
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .util import source, round_trip
    from textwrap import dedent

    src = dedent("""
        class A(metaclass=B):
            pass
    """)

    expected = dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)

    tree = source(src)
    new_tree = MetaclassTransformer().visit(tree)
    assert round_trip(new_tree) == dedent(expected)[1:]

# Generated at 2022-06-23 22:45:06.449086
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import typed_ast.ast3 as ast
    from ..utils.testing import assert_block_equals, assert_parses_and_generates, assert_parses
    node = assert_parses_and_generates(compiler.Compiler(), MetaclassTransformer())
    # assert that the class definition is altered
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)
    assert transformer._tree_changed
    assert isinstance(new_node.body[0], ast.ClassDef)
    assert isinstance(new_node.body[0].bases[0], ast.Call)
    assert transformer.dependencies == ['six']
    # assert that new class definition is parsed correctly by python
    assert_parses(compiler.Compiler(), new_node)

# Generated at 2022-06-23 22:45:10.190776
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .six import from_py2
    module = from_py2('class A(object): pass', [MetaclassTransformer])

    assert module.body[0].bases[0].body.func.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-23 22:45:12.074501
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typing import List

    from typed_ast import ast3 as ast


# Generated at 2022-06-23 22:45:18.753181
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    t = MetaclassTransformer()
    test_ast = ast.parse("""
    class A(metaclass=int):
        pass
    """)
    t.visit(test_ast)
    assert str(test_ast) == """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(int, object)):
        pass
    """


__all__ = ['MetaclassTransformer']

# Generated at 2022-06-23 22:45:26.089850
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..testing import assert_code_equal, normalize

    tree = ast.parse("""
    class A(metaclass=B):
        pass
    """)

    tr = MetaclassTransformer()
    tr.visit(tree)
    assert_code_equal(normalize(tr.result), normalize("""
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """))


# Generated at 2022-06-23 22:45:31.325897
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse('''
        class A(metaclass=B):
            pass
        ''')

    expected = ast.parse('''
        import six
        class A(six.with_metaclass(B)):
            pass
        ''')

    m = MetaclassTransformer()
    result = m.visit(node)

    assert ast.dump(expected) == ast.dump(result)


# Generated at 2022-06-23 22:45:36.695408
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer().visit(ast.parse(dedent('''
        class A(metaclass=B):
            pass
        '''))) == ast.parse(dedent('''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
        '''))


# Generated at 2022-06-23 22:45:43.434595
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..registry import register
    register(ast.ClassDef, MetaclassTransformer())
    from ..utils.source import source_to_ast as to_ast
    source = "class A(metaclass=B): pass"
    actual = to_ast(source)
    expected = to_ast("""
        from six import with_metaclass as _py_backwards_six_with_metaclass
        class A(_py_backwards_six_with_metaclass(B)): pass
    """)
    assert actual == expected

# Generated at 2022-06-23 22:45:51.320469
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .check import TestChecker
    from ..utils.test_utils import parse_test_case

    # Single class with metaclass
    src = """
        class A(metaclass=B):
            a = 1
        class C:
            c = 2
    """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass


        class A(_py_backwards_six_withmetaclass(B)):
            a = 1


        class C:
            c = 2
    """
    module = parse_test_case(src)
    TestChecker(module, MetaclassTransformer()).test(expected)

    # Multiple classes with and without metaclass

# Generated at 2022-06-23 22:45:53.408916
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import enum
    from typed_ast.ast3 import parse


# Generated at 2022-06-23 22:46:00.615388
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
    class A(metaclass=B):
        pass
    """

    tree = ast.parse(dedent(code))  # type: ignore
    MetaclassTransformer().visit(tree)
    assert to_source(tree).strip() == dedent('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''').strip()

# Generated at 2022-06-23 22:46:01.271797
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-23 22:46:01.910823
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:46:02.539236
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:46:09.105165
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing.utils import get_module

    source = '''
        class A(metaclass=B):
            pass
    '''
    mod, _ = get_module(source, '2.7')
    expected = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    '''
    MetaclassTransformer().visit(mod)
    assert mod.to_source() == expected


# Generated at 2022-06-23 22:46:17.956906
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

    tree: ast.Module = ast.parse("class A(metaclass=B): pass")
    transformer = MetaclassTransformer(target=(2, 7))
    transformer.visit(tree)
    assert transformer.dependencies == ["six"]
    assert transformer.tree_changed
    assert transformer._tree_changed

    expected_module: ast.Module = ast.parse("""
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)
    assert ast.dump(tree) == ast.dump(expected_module)

# Generated at 2022-06-23 22:46:29.132157
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    mt = MetaclassTransformer()
    assert mt.transform_snippet(
        """
        class A:
            pass
        """
    ) == """
    class A:
        pass
    """
    assert mt.transform_snippet(
        """
        class A(object):
            pass
        """
    ) == """
    class A(object):
        pass
    """
    assert mt.transform_snippet(
        """
        class A(metaclass=B):
            pass
        """
    ) == """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

# Generated at 2022-06-23 22:46:31.256958
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Given
    from typed_ast import ast3 as ast
    transformer = MetaclassTransformer()

# Generated at 2022-06-23 22:46:38.891841
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    tr = MetaclassTransformer()
    node = ast.parse('''
        class A(object):
            pass
    ''')
    tr.visit(node)
    assert AstEqual(node, ast.parse('''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(object)):
            pass
    '''))

    node = ast.parse('''
        class A(metaclass=A):
            pass
    ''')
    tr.visit(node)

# Generated at 2022-06-23 22:46:45.779391
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source_to_node

    m = source_to_node('''
        class A(metaclass=B): pass
    ''')
    node = MetaclassTransformer().visit(m)

    assert node is not None
    assert node[0].body[0].value.value.id == '_py_backwards_six_with_metaclass'
    assert node[0].body[0].value.args[0].id == 'B'

# Generated at 2022-06-23 22:46:56.154993
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .base import BaseTest
    from ..utils.transform import transform_program, transform_source
    from ..utils import snippets
    from ..utils.codegen import to_source
    from ..utils.cst import parse_module
    from ..utils.compatibility import python_version

    cst = parse_module(snippets.METACLASS_TRANSFORM)
    from_version = python_version()
    to_version = (3, 0)
    tr = BaseTest.from_cst(cst).transform(MetaclassTransformer)
    tr.save_state()
    tr.transform()
    assert tr.cst == parse_module(transform_source(snippets.METACLASS_TRANSFORM, from_version, to_version))
    tr.load_state()
    tr = BaseTest.from_

# Generated at 2022-06-23 22:47:04.566648
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Build AST
    body = [ast.ClassDef(name='A',
                         bases=[],
                         body=[ast.Expr(value=ast.Name(id='pass')),
                               ast.Expr(value=ast.Name(id='pass'))],
                         keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B'))],
                         decorator_list=[])]
    source = ast.Module(body=body)

    # Check that the expected result is returned

# Generated at 2022-06-23 22:47:05.475071
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:47:12.583765
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tt = MetaclassTransformer()
    module = ast.parse('class A(metaclass=A): pass')
    tt.visit(module)
    import astunparse
    assert(astunparse.unparse(module) == 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\n\nclass A(_py_backwards_six_withmetaclass(A)):\n    pass\n')

# Generated at 2022-06-23 22:47:17.613262
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_visitor import TestVisitor

    t = TestVisitor(MetaclassTransformer)

    node = ast.Module()

    assert t.visit(node) == ast.Module(
        body=[six_import.get_body()],
    )


# Generated at 2022-06-23 22:47:18.474878
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:47:22.712419
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    tree = ast.parse("class A(object, metaclass=B): pass")
    m = MetaclassTransformer()
    m.visit(tree)

# Generated at 2022-06-23 22:47:32.853427
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """
    Test that class with metaclass gets replaced with call to six.with_metaclass
    """
    import astor
    from ..utils.unparse import Unparser
    from ..tests.test_utils import write_ast

    class ASTCopy(ast.NodeVisitor):
        def generic_visit(self, node):
            """
            Copy the tree
            """
            new_fields = {}
            for a, value in ast.iter_fields(node):
                if isinstance(value, list):
                    new_fields[a] = [self.visit(x) for x in value]
                else:
                    new_fields[a] = self.visit(value)

            new_node = node.__class__(**new_fields)
            new_node.__dict__.update(node.__dict__)

# Generated at 2022-06-23 22:47:35.230146
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    transformer = MetaclassTransformer()
    code = """class A(A): pass"""