

# Generated at 2022-06-23 22:37:32.620055
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import datetime

    class A(metaclass=datetime.time.__class__):
        pass

    transformer = MetaclassTransformer()

# Generated at 2022-06-23 22:37:42.296414
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = '''class Foo(metaclass=type): pass'''
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert_source(tree, source)

    source = '''class Foo(metaclass=type, bar=42): pass'''
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert_source(tree,
                  '''from six import with_metaclass as _py_backwards_six_withmetaclass''' + '\n' +
                  '''class Foo(_py_backwards_six_withmetaclass(type))'''+ '\n'
                  '''pass''')


# Generated at 2022-06-23 22:37:50.089599
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast, typed_ast.ast3
    from . import fix_missing_locations
    node = typed_ast.ast3.parse('class A(object, metaclass=B):\n    pass')
    node = MetaclassTransformer.run_visitor(node)
    assert ast.dump(node) == "Module(body=[ClassDef(name='A', bases=[Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), args=[Name(id='B', ctx=Load())], keywords=[], starargs=None, kwargs=None)], body=[Pass()], decorator_list=[])])"
    assert fix_missing_locations(node) == node


# Generated at 2022-06-23 22:37:58.428587
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils import parse
    from ..utils.fake_six import fake_six_sources

    source = 'class A(metaclass=B):\n    pass'
    target = 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B))'

    tree = parse.parse(source)
    node_transformer = MetaclassTransformer()
    tree = node_transformer.visit(tree)
    assert parse.to_source(tree).strip() == target

    fake_six_sources.clear()
    fake_six_sources['six'] = six_import.get_source()
    fake_six_sources['_py_backwards_six_withmetaclass'] = six_import.find_

# Generated at 2022-06-23 22:38:05.099516
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .test_utils import make_test, standard_tests
    from ..utils.snippet import snippet

    make_test(MetaclassTransformer, 'module', standard_tests, [
        (
            "class A(metaclass=type):\n"
            "    pass",
            "class A(_py_backwards_six_withmetaclass(type)):\n"
            "    pass"
        ),
        (
            "class A(type):\n"
            "    pass",
            "class A(_py_backwards_six_withmetaclass(type)):\n"
            "    pass"
        ),
    ])

# Generated at 2022-06-23 22:38:07.754453
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class A(object):
        pass
    class B(metaclass=type):
        pass
    class C(metaclass=A):
        pass
    class D(object, metaclass=A,):
        pass
    

# Generated at 2022-06-23 22:38:10.129911
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree_visitor import TreeVisitor
    from .six_transformer import SixTransformer
    from .literal_transformer import LiteralTransformer


# Generated at 2022-06-23 22:38:16.682071
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    testcase = [
        ("class A(object): pass", "class A(object): pass"),
        ("class A(metaclass=B): pass", "class A(_py_backwards_six_withmetaclass(B)): pass"),
    ]

    for code, expected in testcase:
        t = MetaclassTransformer()
        tree = ast.parse(code)
        t.visit(tree)
        assert ast.dump(tree) == expected

# Generated at 2022-06-23 22:38:20.649278
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = """class A(metaclass=b): pass"""
    source_ast = ast.parse(source)
    mt = MetaclassTransformer()
    mt.visit(source_ast)

# Generated at 2022-06-23 22:38:26.887285
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    for test in [
            pytest.param('class A(metaclass=B): pass', False, id='class_metaclass'),
            pytest.param('class A: pass', False, id='plain_class'),
            pytest.param('class A(object): pass', False, id='plain_class_base'),
    ]:
        tree = ast.parse(test)  # type: ignore
        transformer = MetaclassTransformer()
        transformed = transformer.visit(tree)
        assert transformer._tree_changed == test[1]  # type: ignore
        assert ast.dump(transformed) == ast.dump(ast.parse(test[0]))  # type: ignore

# Generated at 2022-06-23 22:38:31.194372
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node_input = ast.parse(
        """class A(metaclass=B):
    pass""")

# Generated at 2022-06-23 22:38:39.877259
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astunparse
    import six
    import sys

    if sys.version_info >= (3, 5):
        metaclass_class_example = '''
        class A(A):
            def __init__(self):
                pass
        '''
        metaclass_instance_example = '''
        class A(A.A):
            def __init__(self):
                pass
        '''
        class_metaclass_example = '''
        class A(metaclass=A):
            def __init__(self):
                pass
        '''
        class_metaclass_instance_example = '''
        class A(metaclass=A.A):
            def __init__(self):
                pass
        '''

# Generated at 2022-06-23 22:38:50.001023
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    expected_codes = ['import six as _py_backwards_six',
                      'from six import with_metaclass as _py_backwards_six_withmetaclass',
                      'class A(_py_backwards_six_withmetaclass(B)): pass']
    py_code = "class A(metaclass=B): pass"

    from ..utils.py2to3 import fix_code
    from ..utils.six_support import IS_PYTHON2
    from ..utils.tree import ast2str

    fixed_code = fix_code(py_code, [MetaclassTransformer])

    if not IS_PYTHON2:
        expected_codes[0] = expected_codes[0].replace('import six as _py_backwards_six', 'import six')

# Generated at 2022-06-23 22:39:01.484332
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astunparse
    import six

    source = """
        class C(metaclass=type):
            pass
    
    """
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert astunparse.unparse(tree) == six.b("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
        class C(_py_backwards_six_withmetaclass(type)):
            pass
    
    """)
    return tree


if __name__ == "__main__":
    # Run all tests
    loc = locals()
    for key in list(loc.keys()):
        if key.startswith("test_") and hasattr(loc[key], "__call__"):
            loc

# Generated at 2022-06-23 22:39:01.980007
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:39:05.978905
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astunparse

    code = """
    class Other(metaclass=B):
        def a(self):
            pass
    """

# Generated at 2022-06-23 22:39:11.008715
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...testing import assert_transform

    assert_transform(
        MetaclassTransformer,
        """
        class W(metaclass=X, *z, **y):
            pass
        """,
        """
        class W(_py_backwards_six_with_metaclass(X, *z, **y)):
            pass
        """
    )


# Generated at 2022-06-23 22:39:12.922282
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing_utils import assert_program


# Generated at 2022-06-23 22:39:23.080936
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..compiler import backwards_compile

    import ast as pyast
    node1 = pyast.Module(body=[], )
    expected1 = pyast.Module(body=[pyast.ImportFrom(module='six',
                                                    names=[pyast.alias(name='with_metaclass',
                                                                       asname='_py_backwards_six_withmetaclass')],
                                                    level=0),
                                  ], )
    actual1 = backwards_compile(node1, 'MetaclassTransformer')
    assert expected1 == actual1

    node2 = pyast.Module(body=[], )

# Generated at 2022-06-23 22:39:27.375414
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..compiler import PyBackwardsCompiler
    from ..utils.test_utils import over_versions, assert_equivalent_without_whitespace
    compiler = PyBackwardsCompiler()

    @over_versions
    def test(self, version: int):
        compiler.target = version
        transformer = MetaclassTransformer(compiler)
        if version < transformer.target:
            source = "class A(metaclass=B):\n    pass"
            expected = "from six import with_metaclass as _py_backwards_six_withmetaclass;\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass"  # noqa E501
            assert_equivalent_without_whitespace(transformer, source, expected)

# Generated at 2022-06-23 22:39:36.048317
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys
    import unittest
    import astor

    class TestMetaclassTransformer(unittest.TestCase):
        def setUp(self):
            sys.version_info = (2, 7, 3, 'final', 0)  # type: ignore

        def test_metaclass_transformer(self):
            from py_backwards.transformers.metaclass import MetaclassTransformer
            from typed_ast import ast3 as ast
            source = '''class A(metaclass=int):\n pass'''

# Generated at 2022-06-23 22:39:40.062573
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    mt = MetaclassTransformer()
    module = ast.parse("class Foo(dict):\n    pass")
    module = mt.visit(module)
    assert str(module.body[0]) == 'class Foo(_py_backwards_six_withmetaclass(dict)):\n    pass'



# Generated at 2022-06-23 22:39:49.573721
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

    from .test_base import BaseNodeTransformerTestCase

    class TestMetaclassTransformer(
        BaseNodeTransformerTestCase, unittest.TestCase
    ):
        transformer = MetaclassTransformer

        def test_import(self):
            source = dedent('''\
            import six

            class A(metaclass=B):
                pass
            ''')
            expected = dedent('''\
            from six import with_metaclass as _py_backwards_six_withmetaclass

            class A(_py_backwards_six_withmetaclass(B)):
                pass
            ''')
            self.check_ast(source, expected)

    unittest.main()



# Generated at 2022-06-23 22:39:51.568277
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class A:
        def b(metaclass=A):
            pass
    class A:
        def b(self):
            pass
    ast.parse(A()) # for pyflakes

# Generated at 2022-06-23 22:39:52.313222
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

# Generated at 2022-06-23 22:39:58.294678
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import get_ast

    before = """
        class A(metaclass=B):
            pass
        class C(metaclass=type):
            pass
    """
    after = """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
        class C(_py_backwards_six_withmetaclass(type)):
            pass
    """
    tr = MetaclassTransformer()
    assert tr.signature == (2, 7)
    tr.visit(get_ast(before))
    assert tr.changed == True
    assert str(tr.tree) == after

# Generated at 2022-06-23 22:39:58.914028
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    pass

# Generated at 2022-06-23 22:40:04.823221
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.test_utils import assert_transformed

    assert_transformed(
        MetaclassTransformer,
        '''
        class A(list):
            pass
        ''',
        '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(list)):
            pass
        '''
    )

# Generated at 2022-06-23 22:40:12.024183
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import textwrap
    code = textwrap.dedent('''
        class A(metaclass=B):
            pass
    ''')
    e = ast.parse(code).body[0]
    expected = textwrap.dedent('''
        class A(_py_backwards_six_with_metaclass(B)):
            pass
    ''')
    result = MetaclassTransformer().visit(e)
    assert ast.dump(result) == ast.dump(ast.parse(expected).body[0])

# Generated at 2022-06-23 22:40:15.159240
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..table import lookup
    class_ = lookup(2, 7)['MetaclassTransformer']  # type: ignore
    instance = class_()
    assert isinstance(instance, MetaclassTransformer)

# Generated at 2022-06-23 22:40:20.602428
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class Test(ast.NodeTransformer):
        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.keywords = [ast.keyword(arg="metaclass", value=ast.Name(id="object", ctx=ast.Load()))]
            return node

    t = Test()
    mt = MetaclassTransformer()

    # Node generators
    classdef = ast.ClassDef(name="a", bases=[], body=[], decorator_list=[])

    # AST transformations
    classdef = t.visit(classdef)
    ClassDef_new = mt.visit(classdef)

    # Nodes

# Generated at 2022-06-23 22:40:23.030817
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = \
"""class A(metaclass=B):
    pass"""


# Generated at 2022-06-23 22:40:23.621816
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:40:29.792835
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from py_backwards.transformers.six import MetaclassTransformer
    from py_backwards.transformers.base import get_py_version
    
    node = ast.parse('''
    class A(B):
        pass
    
    ''')
    transformer = MetaclassTransformer(get_py_version())
    transformer.visit(node)
    assert not transformer._tree_changed


# Generated at 2022-06-23 22:40:39.140325
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .base import compile_to_ast
    code = '''
        class A(metaclass=B, c):
            pass
    '''
    tree = compile_to_ast(code, '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
    ''')
    tree = ast.fix_missing_locations(tree)

    expected = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B, c)):
            pass
    '''
    assert compile_to_ast(expected) == tree

# Generated at 2022-06-23 22:40:50.328692
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import assert_compiled_ast
    from ast import parse
    from six import with_metaclass
    from ..testing.utils import get_class_bases_body
    from ..utils.ast import parse_ast, dump_ast

    class Meta(type):
        pass

    class Foo(with_metaclass(Meta)):
        def bar(self):
            pass

    document = 'class Foo(metaclass=Meta): pass'
    document_tree = parse_ast(document)
    original_bases = get_class_bases_body(document_tree)
    assert dump_ast(original_bases) == 'Meta'


# Generated at 2022-06-23 22:40:58.144873
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..fixer_util import tokenize_print
    from typed_ast import ast3 as ast
    node = ast.ClassDef(name='A',
                        bases=[ast.Name(id='B', ctx=ast.Load())],
                        body=[],
                        decorator_list=[],
                        keywords=[ast.keyword(arg='metaclass',
                                              value=ast.Name(id='C', ctx=ast.Load()))])
    expected = "class A(_py_backwards_six_withmetaclass(C, B)):\n    pass"
    tree = MetaclassTransformer().visit(ast.Module(body=[node]))
    actual = tokenize_print(tree)
    assert expected == actual, actual



# Generated at 2022-06-23 22:40:59.924752
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:41:10.138563
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    # Skipping test as we are using pytest.skip
    # assert (isinstance(Instruction_object, (str, unicode)))

    tree = ast.parse('class A(metaclass=B): pass')
    tree = MetaclassTransformer().visit(tree)

# Generated at 2022-06-23 22:41:19.882457
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    import os
    import sys
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from utils.snippet import snippet
    from utils.tree import print_ast
    from .base import BaseNodeTransformer
    from .metaclass import MetaclassTransformer

    @snippet
    def expected_method_visit_ClassDef():
        class A(_py_backwards_six_withmetaclass(B), C):
            pass


# Generated at 2022-06-23 22:41:25.646585
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import compile

    code = """
        class A(metaclass=B):
            pass
    """
    expected_code = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """
    ast1 = compile(code)
    ast2 = compile(expected_code)
    assert ast1 == ast2

# Generated at 2022-06-23 22:41:31.354978
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class A(object, metaclass=type):
        pass


    source = source_to_ast(A)
    MetaclassTransformer(source)
    assert print_ast(source) == "from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(type, object)):\n    pass\n"

# Generated at 2022-06-23 22:41:34.772562
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node, expected = snippet.get_test_data(__file__,
                                           'MetaclassTransformer_visit_ClassDef_')
    node = MetaclassTransformer().visit(node)
    assert_equal(node, expected)

# Generated at 2022-06-23 22:41:43.224485
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..transformers.six_transformer import SixTransformer
    from ..processors.load_processor import LoadProcessor
    from ..processors.annotate_processor import AnnotateProcessor
    from ..processors.convert import convert
    from ..processors.unpack_processor import UnpackProcessor
    from ..processors.inline_processor import InlineProcessor
    from ..processors.name_processor import NameProcessor
    from ..processors.clean_processor import CleanProcessor
    from ..processors.dereference_processor import DereferenceProcessor

    snippet_six_import = """
import six
from six import with_metaclass
"""


# Generated at 2022-06-23 22:41:49.819136
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..sixer import Sixer
    from .common import source_to_ast
    from ..utils.tree import ast_to_source

    sixer = Sixer()
    transformer = sixer.get_transformer(MetaclassTransformer)

    assert transformer is MetaclassTransformer


# Generated at 2022-06-23 22:41:56.234464
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor  # type: ignore
    source = '''
            class A(metaclass=B):
                pass
            '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B, )):
        pass
    '''
    tree = ast.parse(source)
    MetaclassTransformer().visit(tree)
    assert astor.to_source(tree).strip() == expected.strip()

# Generated at 2022-06-23 22:42:00.010232
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:42:04.455984
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    src = """
            class Klass(object, metaclass=type):
                pass
        """
    expected = """
            from six import with_metaclass as _py_backwards_six_withmetaclass;
            class Klass(_py_backwards_six_withmetaclass(type)):
                pass
        """
    assert_source_equal(expected, MetaclassTransformer().visit(src))



# Generated at 2022-06-23 22:42:07.777110
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor

# Generated at 2022-06-23 22:42:18.145187
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys
    import textwrap

    from ..utils.codetree import CodeTree
    from ..utils.tree import dump_tree
    from ..utils.visitor import NodeVisitor
    from .base import BaseNodeTransformer

    class_def = CodeTree.from_string(textwrap.dedent('''
        class A(metaclass=B):
            pass
    ''')).body[0]

    expected = CodeTree.from_string(textwrap.dedent('''
        from six import with_metaclass as _py_backwards_six_with_metaclass

        class A(_py_backwards_six_with_metaclass(B)):
            pass
    '''))


# Generated at 2022-06-23 22:42:19.033274
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.source import source


# Generated at 2022-06-23 22:42:21.730953
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    six_import.test(
        'from six import with_metaclass as _py_backwards_six_with_metaclass'
    )
    class_bases.test(
        'class A(_py_backwards_six_with_metaclass(B, *bases)):\n    pass'
    )

# Generated at 2022-06-23 22:42:26.812932
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test import needs_local_scope
    from .tst_base import BaseNodeTest
    
    class Test(BaseNodeTest):
        target = MetaclassTransformer.target
        transform = MetaclassTransformer.visit_Module


# Generated at 2022-06-23 22:42:31.856904
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    metaclass_transformer = MetaclassTransformer()
    
    source = """class Foo:
        pass"""

# Generated at 2022-06-23 22:42:36.981390
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    tester = Tester(MetaclassTransformer)
    module_str = tester.load_test_case('class_with_metaclass')
    expected = tester.load_test_case('class_with_metaclass_result')
    tester.run_transform(module_str)
    assert tester.diff_last_transformation(expected) is None



# Generated at 2022-06-23 22:42:38.610788
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import compile_source


# Generated at 2022-06-23 22:42:40.928035
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3
    from ..utils.test import transform


# Generated at 2022-06-23 22:42:47.943624
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer(target=(2, 7)).target == (2, 7)
    assert MetaclassTransformer(target=(2, 7)).dependencies == ['six']
    assert MetaclassTransformer(target=(2, 7)).name == 'MetaclassTransformer'
    assert MetaclassTransformer(target=(2, 7)).description == (
        'Compiles:\n'
        '    class A(metaclass=B):\n'
        '        pass\n'
        'To:\n'
        '    class A(_py_backwards_six_with_metaclass(B))\n'
        '\n'
        '    \n'
    )

# Generated at 2022-06-23 22:42:49.198130
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:43:00.031985
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a = ast.Name("A", ast.Load())
    b = ast.Name("B", ast.Load())
    c = ast.Name("C", ast.Load())
    body = [ast.Pass()]
    keywords = [ast.keyword("metaclass", metaclass)]
    metaclass = ast.Name("B", ast.Load())
    m1 = ast.ClassDef(name=a, bases=[c], keywords=keywords, body=body)
    m2 = ast.ClassDef(name=a,
                      bases=[class_bases.get_body(metaclass, ast.List(elts=[c]))], body=body)
    m = ast.Module(body=[six_import.get_body(), m1])
    t = MetaclassTransformer()
    t.visit(m)


# Generated at 2022-06-23 22:43:02.755373
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    MetaclassTransformer().visit(normalize(six_import.get_ast()))
    return MetaclassTransformer().visit(normalize(class_bases.get_ast()))

# Generated at 2022-06-23 22:43:12.734258
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    from ..utils import bytecode_compile, get_python_version, run_python_source, ver
    from .mock_node import MockNodeTransformer

    # Unit test for __init__
    for t in ('2', '2.6', '2.7', '2.8', '3'):
        assert MetaclassTransformer(target=ver(t)) is not None, '__init__ test failed'

    # Unit test for visit_ClassDef
    mt = MetaclassTransformer(target=(2, 7))
    class_tree = ast.parse('''\
        class A(metaclass=B):
            pass
        ''')
    mt.visit(class_tree)
    print(astor.to_source(class_tree))

# Generated at 2022-06-23 22:43:15.094710
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    '''Meta Clause Transformer: Test visit_Module'''
    from ..python_transformer import PythonTransformer
    from ..utils.source import Source
    from ..utils.location import Location


# Generated at 2022-06-23 22:43:23.795018
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import six

    class Meta(type):
        pass

    class A(metaclass=Meta):
        pass

    def compile_(source: ast.AST) -> ast.AST:
        transformer = MetaclassTransformer(source)
        return transformer.source
        

# Generated at 2022-06-23 22:43:30.266922
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.builder import build
    from ..utils.graft import graft
    from ..utils.compile import compile
    from six import PY2

    source = ("from six import with_metaclass\n"
              "class A(metaclass=type):\n"
              "    pass\n")
    comp_source = ("from six import with_metaclass\n"
                   "class A(with_metaclass(type))\n"
                   "    pass\n")
    py_tree = build(source)
    py_metaclass_tree = graft(py_tree, MetaclassTransformer)
    assert compile(py_metaclass_tree) == comp_source


# Generated at 2022-06-23 22:43:40.402289
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast.ast3 import Module, ClassDef, Str, Call, Name, NameConstant

    def transform(node):
        return MetaclassTransformer().visit(node)


# Generated at 2022-06-23 22:43:47.324969
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .test_transformer import check_transformer

    check_transformer(
        MetaclassTransformer,
        'class X(metaclass=A):\n'
        '    pass'
        ,
        'from six import with_metaclass as _py_backwards_six_withmetaclass;\n'
        '\n'
        'class X(_py_backwards_six_withmetaclass(A)):\n'
        '    pass'
    )

# Generated at 2022-06-23 22:43:49.522235
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:43:49.885299
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:43:53.053899
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import generate_source
    source = generate_source(MetaclassTransformer)

# Generated at 2022-06-23 22:44:00.392617
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .base import BaseTestTransformer
    import ast
    
    class Test(BaseTestTransformer):
        
        transformer = MetaclassTransformer
        filename = __file__
        
        def test_one_metaclass_no_bases(self):
            input = """class A(metaclass=B): pass"""
            # should_raise = False

# Generated at 2022-06-23 22:44:02.584420
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import typed_astunparse
    import astunparse

    source = '''
    class A(metaclass=B):
        def __init__(self):
            pass
    '''


# Generated at 2022-06-23 22:44:10.964309
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast
    from ..encoders import base_encoder
    import sys, io
    tree = ast.parse("class Meta(metaclass=B): pass")
    tree = MetaclassTransformer().visit(tree)
    code = base_encoder.encode(tree)
    stream = io.StringIO()
    tree.show(stream=stream)
    # print(
    #     stream.getvalue(),
    #     code,
    #     sep='\n'
    # )
    print(code)
    exec(code, globals())
    print(Meta)

# Generated at 2022-06-23 22:44:21.985500
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import six
    import types
    from astunparse import unparse

    code = """
    class A(metaclass=int):
        def __init__(self):
            pass
    """

    class A(six.with_metaclass(int)):
        def __init__(self):
            pass

    assert isinstance(A, int)
    assert isinstance(A.__class__, types.FunctionType)
    assert isinstance(A().__class__, int)

    ast_tree = ast.parse(code)
    (MetaclassTransformer()).visit(ast_tree)
    new_code = unparse(ast_tree)

    # Re-evaluate new code
    globals().update({'six': six})
    exec(new_code)
    assert isinstance(A, int)

# Generated at 2022-06-23 22:44:23.002220
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer()


# Generated at 2022-06-23 22:44:30.715873
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast as _ast

    tree = _ast.parse('''
    class A(metaclass=B):
        pass
    ''')

    transformer = MetaclassTransformer()
    node = transformer.visit(tree)
    assert _ast.dump(node) == _ast.dump(
        _ast.parse(
            '''
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A(_py_backwards_six_withmetaclass(B)):
                pass
            '''
        ))

# Generated at 2022-06-23 22:44:39.526003
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import ast_util
    from ... import refactor

    source = '''
    class A(metaclass=B):
        pass
    '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
    
    
    
    
    
    
    
    
    
    
    
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    mod = ast_util.parse(source)
    transformer = refactor.get_transformer(MetaclassTransformer)
    transformer.refactor_tree(mod)
    assert ast_util.dump_str(mod) == expected


# Generated at 2022-06-23 22:44:40.433401
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:44:48.054628
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    mct = MetaclassTransformer()
    src = '''
        class A(metaclass=B):
            pass
        class Foo(Bar, metaclass=Baz):
            pass
    '''
    expected = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        class Foo(_py_backwards_six_withmetaclass(Baz), Bar):
            pass
    '''
    tree = ast.parse(src)
    tree = mct.visit(tree)
    new_src = compile(tree, '<test>', 'exec')
    assert new_src == expected

# Generated at 2022-06-23 22:44:57.472780
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer.run_on_code('class A(B):\n    pass') == 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass'
    assert MetaclassTransformer.run_on_code('class A(metaclass=B):\n    pass') == 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass'

# Generated at 2022-06-23 22:45:03.464795
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    test_code = """\
    class A(metaclass=B):
        pass
    """
    ref_code = """\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    ref_ast = ast.parse(ref_code)
    test_ast = ast.parse(test_code)
    transformer = MetaclassTransformer()
    transformer.visit(test_ast)
    assert transformer._tree_changed is True
    # ast.dump does not keep track of line numbers
    assert ast.dump(test_ast) == ast.dump(ref_ast)



# Generated at 2022-06-23 22:45:07.511346
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import untokenize
    import astor

    source = '''class A(metaclass=B):
    class C(metaclass=D):
        pass'''

    tree = astor.parse_file(source)
    new_tree = MetaclassTransformer(target=(2, 7), dependencies=['six']).visit(tree)
    new_source = untokenize.untokenize(new_tree.tokens).decode('utf-8')


# Generated at 2022-06-23 22:45:10.898389
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..visitor import BackwardsCompiler
    from ..utils import six

# Generated at 2022-06-23 22:45:21.073513
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node_classdef = ast.ClassDef(name="test_MetaclassTransformer_visit_ClassDef",
                                 bases=[ast.Name(id='object', ctx=ast.Load())],
                                 keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='object', ctx=ast.Load()))])
    result = map(ast.dump, MetaclassTransformer().visit(node_classdef))

# Generated at 2022-06-23 22:45:29.517395
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse('class A(metaclass=abc.ABCMeta): pass',
                     mode='exec')
    node = MetaclassTransformer.run_pipeline(node)
    # code is generated with ast.parse, so we should not use to Python code
    # but the AST representation
    expected = ast.parse(dedent('''\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(abc.ABCMeta)):pass
    '''), mode='exec')
    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-23 22:45:31.191973
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:45:34.343092
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    return MetaclassTransformer().visit(node)


if __name__ == '__main__':
    print(test_MetaclassTransformer_visit_ClassDef())

# Generated at 2022-06-23 22:45:40.523834
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()
    assert transformer.transform(
        'class A(metaclass=B):\n'
        '    pass\n'
    ) == (
        'from six import with_metaclass as _py_backwards_six_withmetaclass\n'
        '\n'
        'class A(_py_backwards_six_withmetaclass(B)):\n'
        '    pass\n'
    )

# Generated at 2022-06-23 22:45:46.760897
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..ast_compare import compare_ast

    source = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    result = MetaclassTransformer().visit(ast.parse(source))
    compare_ast(result, ast.parse(expected))

# Generated at 2022-06-23 22:45:51.426402
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class A(metaclass=type):
        pass
    expected = """from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(type)):\n    pass\n"""
    assert MetaclassTransformer().visit(ast.parse(dedent(inspect.getsource(type(A))))) == expected

# Generated at 2022-06-23 22:46:02.451014
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast
    from .transformers import MetaclassTransformer
    from unittest import TestCase
    from ..utils import astdump

    class Test(TestCase):
        def test_transformer(self):
            transformer = MetaclassTransformer()
            node = ast.Module(
                body=[
                    ast.ClassDef(
                        name='A',
                        bases=[ast.Name(id='object', ctx=ast.Load())],
                        keywords=[ast.keyword(arg='metaclass',
                                              value=ast.Name(id='B', ctx=ast.Load()))],
                        body=[ast.Pass()],
                        decorator_list=[]
                    )
                ]
            )

            transformer.visit(node)
            astdump(node)
            self.assertEqual

# Generated at 2022-06-23 22:46:03.675740
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast

# Generated at 2022-06-23 22:46:06.614088
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse('class A(metaclass=B): pass')
    transformer = MetaclassTransformer()
    transformer.visit(module)
    assert str(module).startswith(str(six_import.get_body()))


# Generated at 2022-06-23 22:46:07.654612
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:46:10.288983
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import Settings
    settings = Settings(target=(2, 7))

# Generated at 2022-06-23 22:46:10.657890
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:46:11.685047
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:46:19.080543
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import textwrap
    from ..compiler import Path
    from .base import compile_function
    from .node import format_python_source

    constr = compile_function(textwrap.dedent('''\
        def get_item(d, k):
            return d[k]
    '''), Path('test.py'))
    assert format_python_source(constr.__code__) == textwrap.dedent('''\
        import six
        class_dict = {'get_item': func_0}
        func_1.__dict__.update(class_dict)
        return func_1
    ''').strip()

# Generated at 2022-06-23 22:46:22.987017
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast.ast3 import parse
    from ..utils.visitor import print_node
    from . import remove_imports
    from .parse_future import ParseFuture


# Generated at 2022-06-23 22:46:33.019435
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ... import ast_util
    
    class_def = ast.ClassDef(name='Fob',
                             bases=[ast.Subscript(value=ast.Name(id='Other',
                                                                ctx=ast.Load()),
                                                  slice=ast.Index(value=ast.Str(s='metaclass')),
                                                  ctx=ast.Load())],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='Foo',
                                                                  ctx=ast.Load()))],
                             body=[ast.Pass()],
                             decorator_list=[])

# Generated at 2022-06-23 22:46:40.160690
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def = ast.ClassDef(
        name='Test',
        bases=[],
        keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='A', ctx=ast.Load()))],
        body=[],
        decorator_list=[],
    )

    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit_ClassDef(class_def)

    expected_bases = ast.List(elts=[])

    assert len(class_def.bases) == 1
    assert isinstance(class_def.bases[0], ast.Call)
    assert class_def.bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert len(class_def.bases[0].args)

# Generated at 2022-06-23 22:46:51.352797
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # No bases
    assert_equal_ast(
        MetaclassTransformer().visit(ast.parse("""
            class A(metaclass=B):
                pass
        """)),
        ast.parse("""
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A(_py_backwards_six_withmetaclass(B)):
                pass
        """)
    )

    # Bases

# Generated at 2022-06-23 22:46:56.676251
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .base import BaseTestTransformer
    from typed_ast import ast3 as ast
    import logging
    import sys

    class TestTransformer(BaseTestTransformer):
        transformer = MetaclassTransformer

    class A(metaclass=type):
        pass


# Generated at 2022-06-23 22:47:00.426562
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils import parse

    transformer = MetaclassTransformer()
    result = transformer.visit(parse('class A(metaclass=B):\n    pass'))

    assert transformer._tree_changed is True

# Generated at 2022-06-23 22:47:01.802920
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

# Generated at 2022-06-23 22:47:13.133723
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3 as ast
    from .base import BaseNodeTransformer

    class Mock(BaseNodeTransformer):
        pass

    node = ast.ClassDef(name='B',
                        body=[],
                        keywords=[],
                        decorator_list=[])

    context = Mock(tree=Mock(body=[node]))
    node = context.visit(node)
    assert node.bases == []

    node = ast.ClassDef(name='B',
                        body=[],
                        keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='A'))],
                        decorator_list=[])

    context = Mock(tree=Mock(body=[node]))
    node = context.visit(node)
    assert isinstance(node.bases[0], ast.Call)
   

# Generated at 2022-06-23 22:47:21.995844
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    snippet = '''
    class D(metaclass=B):
        pass
    '''
    node = ast.parse(snippet)  # type: ignore
    transformer = MetaclassTransformer()
    node = transformer.visit(node)  # type: ignore
    result = ast.dump(node)

# Generated at 2022-06-23 22:47:32.673640
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .utils import roundtrip
