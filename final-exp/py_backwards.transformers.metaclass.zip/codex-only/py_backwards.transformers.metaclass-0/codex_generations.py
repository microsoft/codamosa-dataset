

# Generated at 2022-06-23 22:37:29.120722
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    print(MetaclassTransformer())
    pass

# Generated at 2022-06-23 22:37:39.228211
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class Example(ast.NodeVisitor):
        def __init__(self):
            self.result = None

        def visit_ClassDef(self, node: ast.ClassDef) -> ast.ClassDef:
            node.bases = [ast.Name(id="B")]
            return ast.ClassDef(name="C", bases=node.bases,
                                body=node.body, decorator_list=node.decorator_list,
                                keywords=node.keywords, lineno=node.lineno,
                                col_offset=node.col_offset)

        def visit_Name(self, node: ast.Name) -> ast.Name:
            return ast.Name(id="B")

    example = Example()

    m = MetaclassTransformer

# Generated at 2022-06-23 22:37:47.726373
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    import astunparse

    class MyType(type):
        pass

    input_node = ast.parse("class A(metaclass=MyType):\n    pass")
    node = MetaclassTransformer().visit(input_node)


# Generated at 2022-06-23 22:37:54.962077
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_astunparse
    module = '''
    class MyClass(metaclass=A):
        def f():
            pass
    '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class MyClass(_py_backwards_six_withmetaclass(A)):
        def f():
            pass
    '''
    result = MetaclassTransformer().visit(ast.parse(module))
    assert typed_astunparse.unparse(result) == expected

# Generated at 2022-06-23 22:38:01.683273
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ...testing import assert_text_equals

    code = """\
    class P(object):
        pass
    class Q(object, metaclass=P):
        pass
    """

    new = MetaclassTransformer().visit(ast.parse(dedent(code)))

    assert_text_equals(six_import.get_text() + "\n" + code,
                       ast.unparse(new))



# Generated at 2022-06-23 22:38:04.996428
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    mod = ast.parse("""class A(metaclass=None): pass""")
    # type: ignore
    trans = MetaclassTransformer()
    trans.visit(mod)
    assert trans._tree_changed


# Generated at 2022-06-23 22:38:05.892457
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 22:38:11.261602
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformerTest
    from ..utils.tree import tree_to_str, compare_trees
    import sys
    import logging

    # This is a compile test, not a runtime test.
    # The generated Python code uses the six dependency
    # which can be pip installed.
    sys.modules['six'] = __import__('six')

    class Test(BaseNodeTransformerTest):
        @property
        def transformer(self) -> BaseNodeTransformer:
            return MetaclassTransformer

        def test_ClassDef(self):
            # type: () -> None
            source = '''
            class A(metaclass=B):
                pass
            '''
            tree = ast.parse(source)


# Generated at 2022-06-23 22:38:20.208407
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.syntax import to_source
    from ..utils.tree import get_body

    from . import UnsupportedCodeError

    source = '''
    class A(metaclass=int):
        pass
    '''

    tree = get_body(ast.parse(source))
    metaclass = MetaclassTransformer()
    metaclass.visit(tree)
    result = to_source(tree)
    assert result == '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(int)):
        pass
    '''



# Generated at 2022-06-23 22:38:27.511965
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:38:29.105760
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 22:38:30.771814
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import run_transformer

# Generated at 2022-06-23 22:38:36.092932
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast as pyast
    M = pyast.parse("def foo(): pass")
    assert isinstance(M, pyast.Module)
    MT = MetaclassTransformer()
    MT.visit(M)
    assert len(M.body) == 2
    assert M.body[0] == six_import.get_body()


# Generated at 2022-06-23 22:38:37.922064
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """
    This test is testing the class constructor
    """
    assert MetaclassTransformer.__bases__ == (BaseNodeTransformer,)

# Generated at 2022-06-23 22:38:39.978041
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    _node = ast.parse('class A(object, metaclass=B): pass')
    _res = Meta

# Generated at 2022-06-23 22:38:44.879699
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    src = six_import.src() + '\n' + 'class C(object):\n    pass'
    new_src = MetaclassTransformer().visit(ast.parse(src))
    new_src = ast.unparse(new_src).strip()

    assert six_import.src() == new_src


# Generated at 2022-06-23 22:38:52.978967
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class TestMetaclassTransformer(MetaclassTransformer):
        _tree_changed = False

    class TestVisitor(ast.NodeVisitor):
        def __init__(self):
            self._tree_changed = False

        def generic_visit(self, node):
            super().generic_visit(node)

    tmt = TestMetaclassTransformer()
    visitor = TestVisitor()

    ast_node = ast.ClassDef(name=ast.Name(id='A'),
                            bases=[ast.Name(id='B', ctx=ast.Load())],
                            keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='C', ctx=ast.Load()))],
                            decorator_list=[], body=[])


# Generated at 2022-06-23 22:38:59.003501
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("class A(metaclass=B): pass")
    MetaclassTransformer().visit(node)
    assert ast.dump(node) == dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """).strip()

# Generated at 2022-06-23 22:39:04.052479
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = textwrap.dedent("""\
    class A(metaclass=A):
        pass
    """)
    tree = ast.parse(source)
    transformer = MetaclassTransformer(tree)
    transformer.visit_Module(tree)
    assert source != astor.to_source(tree)



# Generated at 2022-06-23 22:39:10.770177
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # type: () -> None
    module = ast.parse("class A(metaclass=B):\n\tpass")
    MetaclassTransformer().visit(module)

    x = ast.parse(six_import.get_source())
    y = ast.parse("class A(_py_backwards_six_with_metaclass(B))")
    assert ast.dump(module) == ast.dump(ast.Module(body=[x.body[0], y.body[0]]))



# Generated at 2022-06-23 22:39:21.674868
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..base import BaseNodeTransformer
    from ..utils.snippet import snippet
    from ..utils.tree import tree_from_str
    from typed_ast import ast3 as ast
    import os
    import astor
    
    
    
    
    
    
    
    
    
    
    
    
    @snippet
    def six_import():
        from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
    class Test(BaseNodeTransformer):
        target = (2, 7)
        dependencies = ['six']
        
        def visit_Module(self, node: ast.Module) -> ast.Module:
            insert_at(0, node, six_import.get_body())
            return self.generic_visit(node)
    
    

# Generated at 2022-06-23 22:39:24.102025
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    node = ast.parse("""class A(metaclass=B): pass""")  # type: ignore
    mct = MetaclassTransformer()
    mct.visit(node)

# Generated at 2022-06-23 22:39:27.226249
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.python_source import PythonSource
    from ..utils.ast_helper import ast_from_source, ast_to_source, assert_ast_equals


# Generated at 2022-06-23 22:39:27.942627
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    pass

# Generated at 2022-06-23 22:39:30.700129
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    mt = MetaclassTransformer()
    assert mt.target == (2, 7)
    assert mt.dependencies == ['six']



# Generated at 2022-06-23 22:39:38.446522
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    from ..utils import parse
    from ..utils import compare_ast

    tree = parse("""
    class A(metaclass=int):
        pass
    """)
    t = MetaclassTransformer()
    new = t.visit(tree)
    print(astor.to_source(new))
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(int)):
        pass
    """
    assert compare_ast(astor.to_source(new), expected) is True


# Generated at 2022-06-23 22:39:43.023594
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()
    node = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    transformer.visit(node)
    assert transformer.should_run()
    assert transformer.tree_changed()

# Generated at 2022-06-23 22:39:52.430145
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """Unit test for method visit_Module of class MetaclassTransformer

    Source code:
        class A(metaclass=B):
            pass
    """

    from typed_ast import ast3 as ast

    tree = ast.parse("""\
        class A(metaclass=B):
            pass
        class B:
            pass
        """)  # type: ast.Module

    MetaclassTransformer().visit(tree)

    expected = ast.parse("""\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        class B:
            pass
        """)
    assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-23 22:39:53.837076
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """Check class MetaclassTransformer constructor"""
    assert MetaclassTransformer is not None


# Generated at 2022-06-23 22:39:54.836547
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..testing_utils import assert_equivalent_node


# Generated at 2022-06-23 22:39:59.991574
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..pgen2.parse import parse

    for src, desired in [
        ('class A(metaclass=B): pass',
         'class A(_py_backwards_six_with_metaclass(B), ): pass'),
        ('class A(B, metaclass=C): pass',
         'class A(_py_backwards_six_with_metaclass(C), B): pass'),
    ]:
        tree = parse(src)
        assert MetaclassTransformer().process(tree)
        [c] = tree.body
        assert isinstance(c, ast.ClassDef)
        assert type(c).__name__ == 'ClassDef'
        assert ast.dump(c) == desired

# Generated at 2022-06-23 22:40:06.655335
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    _input = 'class A(metaclass=B):\n    pass'
    _expected = 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B))'
    _module, _tree_changed = MetaclassTransformer().visit_string(_input)
    assert _module == _expected
    assert _tree_changed == True


# Generated at 2022-06-23 22:40:07.825215
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-23 22:40:13.705889
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():

    a = ast.parse("class A(metaclass=str): pass")
    a_expected = ast.parse("""
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(str)):
        pass""")

    m = MetaclassTransformer()
    a = m.visit(a)

    assert ast.dump(a_expected) == ast.dump(a)

# Generated at 2022-06-23 22:40:22.440236
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    from astor.ast_compat import get_symbol_names
    from ..utils.test import assert_code_equal

    class X(metaclass=type):
        pass

    '''
    Should turn into:
    
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class X(_py_backwards_six_withmetaclass(type)):
        pass
    '''
    node = ast.parse(astor.to_source(X.__class__))
    transformed = MetaclassTransformer().visit(node)
    code = astor.to_source(transformed)

# Generated at 2022-06-23 22:40:32.828571
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ...tests.lib.compat import backport_unittest
    from ..utils.__util__ import backport_and_update_tree
    from ..utils.__util__ import get_name_node

    class TestCase(backport_unittest.TestCase):
        def test_ok(self):
            code = """
                class a(metaclass=b):
                    pass
            """
            tree = ast.parse(code)
            backport_and_update_tree(tree, (3, 8))
            self.assertEqual(len(tree.body), 2)
            self.assertEqual(get_name_node(tree.body[0]), "six")
            self.assertEqual(get_name_node(tree.body[1].bases[0]), "b")

# Generated at 2022-06-23 22:40:33.881118
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:40:42.084594
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import unittest
    import astor
    from ..utils.ast_factory import Factory

    factory = Factory()

    # Generate AST
    tree = factory.parse('''
        class A(metaclass=B):
            pass
    ''')
    # Get node to test
    node = tree.body[0]

    # Perform transformation
    MetaclassTransformer().visit(tree)

    # Compare output
    assert astor.to_source(tree) == '\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass\n'

# Generated at 2022-06-23 22:40:47.266106
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:40:50.977144
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..converter import Converter
    from typed_ast import ast3
    from .six_transformer import SixTransformer

    class TestTransformer(SixTransformer, MetaclassTransformer):
        pass

    conv = Converter([TestTransformer])


# Generated at 2022-06-23 22:40:58.859558
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3
    from compile_py_backwards.modules.six import six_import
    from compile_py_backwards.modules.six import class_bases

    class_body_for_six_import = (
        ast3.Expr(value=ast3.Call(func=ast3.Attribute(value=ast3.Name(id='six',
                                                                      ctx=ast3.Load()),
                                                      attr='with_metaclass',
                                                      ctx=ast3.Load()),
                                  args=[ast3.Str(s='_py_backwards_six_withmetaclass')],
                                  keywords=[]))
    )

# Generated at 2022-06-23 22:41:09.214206
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    mt = MetaclassTransformer()
    mt_ast = ast.parse('class A(metaclass=B):pass')
    mt.visit(mt_ast)
    assert len(mt_ast.body) == 2
    assert ast.dump(mt_ast) == """\
Module(body=[
    ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0),
    ClassDef(name='A', bases=Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), args=[Name(id='B', ctx=Load())], keywords=[], starargs=None, kwargs=None), body=[], decorator_list=[])])
"""

# Generated at 2022-06-23 22:41:18.522538
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    metaclass = ast.Name(id='B', ctx=ast.Load())
    bases = [ast.Name(id='object', ctx=ast.Load())]
    old_class = ast.ClassDef(name='A', bases=bases, keywords=[ast.keyword(arg='metaclass', value=metaclass)], body=[])

    keyword = class_bases.get_body(metaclass=metaclass, bases=ast.List(elts=bases))
    new_class = ast.ClassDef(name='A', bases=[keyword], body=[])

    result = MetaclassTransformer().visit(old_class)

    assert result == new_class

# Generated at 2022-06-23 22:41:25.248849
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

    tree = ast.parse('''
    class A(metaclass=B): pass
    ''')

    transformer = MetaclassTransformer()
    transformer.visit(tree)

    expected = ast.parse('''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)): pass
    ''')

    assert ast.dump(tree, include_attributes=True) == ast.dump(expected, include_attributes=True)



# Generated at 2022-06-23 22:41:27.136985
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.visitor import visit_and_modify


# Generated at 2022-06-23 22:41:32.665586
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    assert str(MetaclassTransformer().visit(ast.parse('''
    class A(metaclass=B):
        pass
    '''))) == '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''


# Generated at 2022-06-23 22:41:40.072684
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import textwrap
    from ..utils.test import TestCase2

    class Test(TestCase2):

        transform = MetaclassTransformer().visit_Module

        def test_adds_six_import(self):
            code = textwrap.dedent('''
                class A(metaclass=B):
                    pass
            ''')

            expected_code = textwrap.dedent('''
                from six import with_metaclass as _py_backwards_six_withmetaclass
                
                class A(metaclass=B):
                    pass
            ''')

            self.assertEqual(self.transform(ast.parse(code)), 
                             ast.parse(expected_code))

    Test().run()


# Generated at 2022-06-23 22:41:44.095707
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import assert_node

    node = ast.parse('class A(metaclass=B, arg1): pass')
    transformer = MetaclassTransformer()
    result = transformer.visit(node)
    assert_node(result, 'class A(_py_backwards_six_withmetaclass(B)): pass')

# Generated at 2022-06-23 22:41:51.109413
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast
    import os
    import sys
    import unittest

    class TestMetaclassTransformer(unittest.TestCase):
        cur_dir = os.path.dirname(__file__)
        test_data_dir = os.path.join(cur_dir, 'testdata', 'metaclass_transformer')

        def test_metaclass_transformer(self):
            with open(os.path.join(self.test_data_dir, 'basic.py'), 'r') as test_file:
                actual = test_file.read()
            test_file.close()
            with open(os.path.join(self.test_data_dir, 'basic.expected.py'), 'r') as expected_file:
                expected = expected_file.read()
            expected_file.close()
           

# Generated at 2022-06-23 22:41:59.838233
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    print('test_MetaclassTransformer_visit_Module')
    x = ast.parse('class A(metaclass=B): pass')
    MetaclassTransformer().visit(x)

# Generated at 2022-06-23 22:42:06.792802
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..unparse import Unparser
    import astor
    input = astor.parse_file(
        "tests/fixtures/metaclass.py",
        "exec")
    input_node = input.body[0]
    assert isinstance(input_node, ast.ClassDef)
    assert "metaclass" in [keyword.arg for keyword in input_node.keywords]

    transformer = MetaclassTransformer()
    output = transformer.visit(input)
    output_node = output.body[0].body[0]
    assert isinstance(output_node, ast.ClassDef)
    assert output_node.keywords == []
    assert isinstance(output_node.bases[0], ast.Call)
    assert isinstance(output_node.bases[0].func, ast.Name)
   

# Generated at 2022-06-23 22:42:07.829235
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # TODO
    pass

# Generated at 2022-06-23 22:42:15.040825
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import parse
    module = parse("""
    class Foo(metaclass=Type):
        pass
    """)
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class Foo(_py_backwards_six_withmetaclass(Type)):
        pass
    """
    actual = MetaclassTransformer().visit(module)
    print(actual)
    print(ast.dump(actual))
    assert expected == astor.to_source(actual)

# Generated at 2022-06-23 22:42:19.517106
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .context import backwards_compat_faker
    from ..tests.utils import transform

    class_def_ast = ast.parse("""
        class A(metaclass=B):
            pass
    """)

# Generated at 2022-06-23 22:42:24.363168
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    correct_module = ast.parse("""
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    MetaclassTransformer().visit(module)
    assert ast.dump(module) == ast.dump(correct_module)


# Generated at 2022-06-23 22:42:31.237510
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    code = '''class A(B, metaclass=C):
    pass
    '''
    transformed_code = '''class A(_py_backwards_six_withmetaclass(C, B)):
    pass
    '''
    node = ast.parse(code)
    transformer = MetaclassTransformer()
    transformer.visit(node)
    exec(compile(node, '', 'exec'))
    assert str(node) == transformed_code

# Generated at 2022-06-23 22:42:37.588730
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class T(object):
        _tree_changed = False
    t = T()

    tree = ast.parse("""
        class A(object):
            pass
    """)
    t.visit(tree)
    e = ast.parse("""
        class A(_py_backwards_six_with_metaclass(object)):
            pass
    """)
    assert ast.dump(tree) == ast.dump(e)
    assert t._tree_changed


# Generated at 2022-06-23 22:42:47.197413
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # Test for method visit_ClassDef of class MetaclassTransformer
    # Testing for ClassDef node having metaclass specified
    tree = ast.parse("""
    class A(metaclass = B):
        pass
    """)
    transformer = MetaclassTransformer()
    transformer.visit(tree)

    assert transformer._tree_changed is True
    assert ast.dump(tree) == ast.dump("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B, )):
        pass
    """)

    # Testing for ClassDef node not having metaclass specified
    tree = ast.parse("""
    class C(B):
        pass
    """)
    transformer = MetaclassTransformer()


# Generated at 2022-06-23 22:42:48.037308
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:42:58.148778
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    obj = MetaclassTransformer()
    node = ast.ClassDef(name='Name',
                        bases=[ast.parse('M', mode='eval').body],
                        keywords=[ast.keyword(arg='metaclass', value=ast.parse('int').body)],  # type: ignore
                        body=[ast.Pass()],
                        decorator_list=[])
    result = obj.visit_ClassDef(node)
    assert result == ast.ClassDef(name='Name',
                                  bases=[ast.parse('_py_backwards_six_withmetaclass(int, M)', mode='eval').body],
                                  keywords=[],
                                  body=[ast.Pass()],
                                  decorator_list=[])

# Generated at 2022-06-23 22:43:04.832570
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from src.transpilers.python_backwards.metaclass_transformer import MetaclassTransformer
    
    transformer = MetaclassTransformer()
    node = ast.ClassDef(
        name = "A",
        bases = [],
        keywords = [ast.keyword(arg="metaclass",
                                value = ast.Name(
                                    id="B",
                                    ctx=ast.Load()
                                )
                            )],
        body = [],
        decorator_list = [],
        starargs = None,
        kwargs = None
    )
    actual_output = transformer.visit(node)

# Generated at 2022-06-23 22:43:13.703622
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    input = """
        class A(metaclass=B):
            pass
        """
    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    t = MetaclassTransformer()
    tree = ast.parse(input)
    new_tree = t.visit(tree)
    result = compile(new_tree, '<test_MetaclassTransformer_visit_Module>', 'exec')
    six_mixin = {}
    exec(result, six_mixin)
    assert six_mixin['A'].__base__ == six_mixin['B']

# Generated at 2022-06-23 22:43:22.790948
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    # class A(A_bases, metaclass=A_metaclass):
    #    A_body
    A_body = [ast.Expr(value=ast.Str(s="Expr in class body"))]
    A_bases = [ast.Name(id="A_base1", ctx=ast.Load()),
               ast.Name(id="A_base2", ctx=ast.Load())]
    A_metaclass = ast.Name(id="A_metaclass", ctx=ast.Load())
    A = ast.ClassDef(name="A",
                     bases=A_bases,
                     keywords=[ast.keyword(arg="metaclass",
                                           value=A_metaclass)],
                     body=A_body)


# Generated at 2022-06-23 22:43:26.439945
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Test setup
    from ..compiler import compile_snippets
    from ..testing import Timer

    class Test:
        pass

    with Timer() as t:
        # Test
        compile_snippets(__name__)

    # Test assertions
    assert t.elapsed < 0.1, 'Compilation took {}s'.format(t.elapsed)



# Generated at 2022-06-23 22:43:30.403510
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    generator = MetaclassTransformer()
    generator.visit(ast.parse('''class A(object):
    pass
'''))


# Generated at 2022-06-23 22:43:37.827351
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    from .utils import round_trip

    before = """
        class A(metaclass=B):
            pass
"""
    after = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B))
            pass
"""

    node = ast.parse(before)
    node = MetaclassTransformer().visit(node)
    node = round_trip(node)

    assert after == astor.to_source(node)

# Generated at 2022-06-23 22:43:45.563386
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import ClassDef, Expr, Load, Str
    from typed_ast.ast3 import Name, Pass, parse, fix_missing_locations, walk
    class_def = ClassDef(
        name='G',
        bases=[],
        keywords=[
            ast.keyword(arg='metaclass',
                        value=Name(id='F', ctx=Load())),
        ],
        body=[Pass()],
        decorator_list=[],
    )
    module = Module(body=[
        class_def,
    ])
    fixed_module = MetaclassTransformer().visit(module)
    assert fixed_module is not None
    fixed_class_def = fixed_module.body[0]
    assert isinstance(fixed_class_def, ClassDef)

# Generated at 2022-06-23 22:43:46.714712
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:43:48.443383
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:43:52.830069
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils import roundtrip

    with six_import.snippet:
        class A(metaclass=int):
            def test(self):
                return int


# Generated at 2022-06-23 22:44:03.840547
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    # node.keywords is not empty
    classdef = ast.ClassDef(
        name="A",
        keywords=[ast.keyword(arg="metaclass", value=ast.Name(id="B", ctx=ast.Load()))],
        bases=[], body=[]
    )
    node = MetaclassTransformer().visit(classdef)
    assert node.keywords == []
    expected = (
        "class A(_py_backwards_six_withmetaclass(B)):\n"
        "    pass\n"
    )
    assert astor.to_source(node) == expected
    # node.keywords is empty
    classdef = ast.ClassDef(name="A", keywords=[], bases=[], body=[])
    node = MetaclassTransformer().visit(classdef)
   

# Generated at 2022-06-23 22:44:13.175295
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import parse
    from unittest.mock import Mock
    from ...processors.base import Processor
    from ...visitors.filters import (
        TreeFilter,
        TreeFilterChain
    )
    import six
    import sys

    scope = {
        'six': six,
        'sys': sys,
    }

    filter = TreeFilterChain(
        filters=[
            TreeFilter.suppress_module('typed_ast'),
            TreeFilter.suppress_module('six'),
            TreeFilter.suppress_module('builtins'),
            TreeFilter.suppress_module('test.test_transformers.test_metaclass'),
        ]
    )


# Generated at 2022-06-23 22:44:22.703895
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.compile import compile_source
    code = """class A(metaclass=B): pass"""
    module = compile_source(code, __name__, MetaclassTransformer, target=(2, 7))

    # Make sure that the transformed code has the expected values for module, class and function names.
    assert module.__name__ == __name__
    assert module.A.__name__ == 'A'
    assert module.A.__qualname__ == __name__ + '.A'
    assert module.A.__module__ == __name__

    # Test that code execution gives the expected result
    assert module.A.__mro__ == (module.A, object)
    assert module.A.__bases__ == (object,)

# Generated at 2022-06-23 22:44:33.205328
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.conftest import dummy_node_factory
    from copy import copy

    dummy_node = dummy_node_factory()
    dummy_metaclass = dummy_node_factory()
    dummy_node.keywords[0].value = dummy_metaclass
    dummy_node.bases.append(dummy_node_factory())

    before_bases = copy(dummy_node.bases)
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(dummy_node)

    expected = ast.Name(id='_py_backwards_six_withmetaclass')
    assert dummy_node.bases[0].func.id == expected.id

# Generated at 2022-06-23 22:44:39.331870
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """ Unit test for method visit_ClassDef of class MetaclassTransformer """
    # Setup
    pm = astor.parse_module(test_code)
    node = pm.body[0]
    visitor = MetaclassTransformer()
    # Exercise and verify
    visitor.visit(node)
    assert(visitor._tree_changed == True)
    assert(astor.to_source(node) == expected_code)

# Test code and expected code

# Generated at 2022-06-23 22:44:44.660270
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .helper import transform_and_compile_snippet

    transform_and_compile_snippet(
        MetaclassTransformer,
        """
        class A(metaclass=type):
            pass
        """,
        """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(type)):
            pass
        """
    )

# Generated at 2022-06-23 22:44:51.097157
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3
    from py_backwards.transformers.metaclass import class_bases, MetaclassTransformer, six_import
    from typing import Union
    from typing_extensions import Final
    from . import nodes

    tree: Final[ast3.AST] = ast3.parse('''
        class A(metaclass=B):
            pass
        ''')

    result_tree: Union[ast3.AST, nodes.ErrorNode] = MetaclassTransformer().visit(tree)

    assert_equals(len(result_tree.body), 2)

    assert_is_instance(result_tree.body[0], ast3.Expr)
    assert_is_instance(result_tree.body[0].value, ast3.Call)

# Generated at 2022-06-23 22:44:52.793635
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:44:58.249961
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    six_import.test()
    class_bases.test()

    class CustomObject(object):
        pass

    class CustomDict(dict):
        def __missing__(self, key):
            return None

    node = ast.parse("""class Temp(object, metaclass=CustomObject):
    pass""")

    MetaclassTransformer(CustomDict()).visit(node)


# Generated at 2022-06-23 22:45:04.431213
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..test_utils import make_test_tree

    module = make_test_tree()
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(module)
    assert metaclass_transformer._tree_changed

    assert module.body[0] == six_import.get_body()[0]
    assert module.body[1].bases == class_bases.get_body()[0].bases  # type: ignore

# Generated at 2022-06-23 22:45:05.010548
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:45:08.752050
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    given_source = """
    class Foo(metaclass=Bar):
        pass
    """
    node = ast.parse(textwrap.dedent(given_source))
    node = MetaclassTransformer().visit(node)  # type: ignore

    expected_source = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class Foo(_py_backwards_six_withmetaclass(Bar))":
        pass
    """  # noqa

    expected = ast.parse(textwrap.dedent(expected_source))
    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-23 22:45:16.677785
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Test case for method visit_ClassDef of class MetaclassTransformer
    """
    # Setup test case
    case = 'class A(metaclass=B): pass'
    expected = 'class A(_py_backwards_six_withmetaclass(B)):   pass'

    # Run test
    node = ast.parse(case)
    transformer = MetaclassTransformer()
    actual = transformer.visit(node)

    # Verify results
    actual = ast.fix_missing_locations(actual)
    actual = ast.dump(actual)
    expected = ast.dump(ast.parse(expected))
    assert actual == expected

# Generated at 2022-06-23 22:45:24.132036
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():

    program = snippet.class_(metaclass=True)
    mod = ast.parse(program)

    transformer = MetaclassTransformer()
    new_mod = transformer.visit(mod)

    assert_code_equal(program, new_mod)

    program = snippet.class_()
    mod = ast.parse(program)

    transformer = MetaclassTransformer()
    new_mod = transformer.visit(mod)

    assert_code_equal(program, new_mod)


# Generated at 2022-06-23 22:45:32.240221
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import io
    import unittest
    from typed_ast import ast3 as ast

    import typed_astunparse

    class TestMetaclassTransformer(unittest.TestCase):
        def test_pass(self) -> None:
            code = 'class A(metaclass=B): pass'
            tree = ast.parse(code)
            node = MetaclassTransformer().visit(tree)
            out = io.StringIO()
            typed_astunparse.unparse(node, file=out)
            self.assertEqual(out.getvalue().strip(),
                             'class A(_py_backwards_six_withmetaclass(B)): pass')

    unittest.main()

# Generated at 2022-06-23 22:45:34.087116
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import get_ast, compare_ast
    from ..utils.compat import StringIO

# Generated at 2022-06-23 22:45:44.305614
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...utils.source import source_to_ast as sta, ast_to_source as ats
    from ..utils.transformer import TransformError

    tr = MetaclassTransformer()
    assert ats(sta('''class A(): pass''')) == ats(tr.visit(sta('''class A(): pass''')))  # noqa: E121

    tr = MetaclassTransformer()
    assert ats(sta('''class A(metaclass=int): pass''')) == ats(tr.visit(sta('''class A(metaclass=int): pass''')))  # noqa: E121

    tr = MetaclassTransformer()

# Generated at 2022-06-23 22:45:45.519419
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor


# Generated at 2022-06-23 22:45:54.782769
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    metaclass = ast.Name(id='metaclass', ctx=ast.Load())
    bases = ast.Name(id='B', ctx=ast.Load())
    cls = ast.ClassDef(name='A', bases=[bases], keywords=[ast.keyword(arg='metaclass', value=metaclass)])
    test_module = ast.Module(body=[cls])

    transformer = MetaclassTransformer()
    transformer.visit(test_module)
    # print(astor.to_source(test_module))
    assert transformer.tree_has_changed() is True
    assert test_module.body[0].keywords == []
    assert test_module.body[0].bases[0].value.func.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-23 22:45:57.011768
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast.ast3 import parse
    import ast
    mt = MetaclassTransformer()

# Generated at 2022-06-23 22:46:06.340244
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast
    import textwrap
    nodes = ast.parse(textwrap.dedent("""\
        class A(metaclass=B):
            pass
    """))

    t = MetaclassTransformer()
    t.visit(nodes)
    assert ast.dump(nodes) == "Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0), ClassDef(name='A', bases=[Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), args=[Name(id='B', ctx=Load())], keywords=[])], keywords=[], body=[], decorator_list=[])])"

# Generated at 2022-06-23 22:46:17.210971
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast
    from ..utils.fake_ctx import FakeCtx
    from .base import BaseNodeTransformer
    from .transformer import Transformer
    from .generator import CodeGenerator

    class ATransformer(BaseNodeTransformer):
        def visit_Pass(self, node: ast.Pass) -> None:
            return None

    class BTransformer(BaseNodeTransformer):
        def visit_Expr(self, node: ast.Expr) -> ast.Expr:
            return node

    source = """class A: pass"""
    ctx = FakeCtx(source, target=(2, 7), dependencies=['six'])
    source = source.encode('utf8')

    # Test initialization with invalid parameters

# Generated at 2022-06-23 22:46:19.126910
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # TODO: test MetaclassTransformer
    assert True

# Generated at 2022-06-23 22:46:20.027064
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:46:22.070863
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer().transform(ast.parse("class A(metaclass=B): pass"))

# Generated at 2022-06-23 22:46:23.876341
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    mt = MetaclassTransformer()

# Generated at 2022-06-23 22:46:32.427948
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # This test is failing. It is a bit difficult to fix, because of the
    # indentation issues. Fixing it would probably require the
    # insertion of a snippet at the right indentation level.
    # Actually the insertion itself doesn't work either.
    code = '''import six.moves.abc as abc_module'''
    tree = ast.parse(code)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert ast.dump(tree) == '''
import six.moves.abc as abc_module
from six import with_metaclass as _py_backwards_six_withmetaclass
'''


# Generated at 2022-06-23 22:46:39.682472
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import unittest

    class TestMetaclassTransformer(unittest.TestCase):
        if not hasattr(unittest.TestCase, 'assertIsInstance'):
            def assertIsInstance(self, obj, cls, msg=None):
                if not isinstance(obj, cls):
                    self.fail(self._formatMessage(msg, '%s is not an instance of %r' % (obj, cls)))

        def assertNoChange(self, source):
            transformer = MetaclassTransformer()
            ast_tree = parse(source)
            transformer.visit(ast_tree)
            self.assertEqual(source, total_compile(ast_tree))

        def assertTransformsTo(self, source, output):
            transformer = MetaclassTransformer()
            ast_tree = parse(source)


# Generated at 2022-06-23 22:46:48.020440
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source_tree = ast.parse('class A(metaclass=B): pass')
    transformer = MetaclassTransformer()
    target_tree = transformer.visit(source_tree)

    expected_tree = ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass;\nclass A(with_metaclass(B)): pass')

    print(ast.dump(target_tree))
    print()
    print(ast.dump(expected_tree))

    assert ast.dump(target_tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 22:46:48.954073
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ast import parse as ast_parse


# Generated at 2022-06-23 22:46:49.940539
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:46:55.896427
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.source import source
    source_code = source(MetaclassTransformer)
    source_code = source_code.replace('metaclass=', 'metaclass=').replace('metaclass =', 'metaclass =')
    node = ast.parse(source_code)
    visitor = MetaclassTransformer()
    visitor.visit(node)
    assert source(node) == MetaclassTransformer.get_source()

# Generated at 2022-06-23 22:47:00.341128
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("class A(metaclass=int): pass")
    assert MetaclassTransformer().visit(node) == ast.parse("from six import with_metaclass as _py_backwards_six_withmetaclass;\nclass A(_py_backwards_six_withmetaclass(int)): pass")



# Generated at 2022-06-23 22:47:06.122892
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .six_import_trf import SixImportTransformer
    from ..utils.source import source

    source = source('''
    class A(metaclass=B):
        pass
    ''')
    tree = ast.parse(source)
    tree = SixImportTransformer().visit(tree)
    tree = MetaclassTransformer().visit(tree)
    expected = source("""
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    assert ast.dump(tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-23 22:47:07.377173
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:47:16.639712
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import copy
    import astor
    assert MetaclassTransformer().visit(copy.deepcopy(ast.parse('''class Foo(metaclass=Bar):
    pass'''))) == ast.Module(body=[
        ast.Import(names=[ast.alias(name='six', asname=None)]),
        ast.ClassDef(
            name='Foo',
            bases=[ast.Call(func=ast.Name(id='_py_backwards_six_withmetaclass'),
                            args=[ast.Name(id='Bar')], keywords=[], starargs=None, kwargs=None)],
            keywords=[], body=[ast.Pass()], decorator_list=[])
    ])

# Generated at 2022-06-23 22:47:20.011823
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer()
    node = ast.parse("class A(metaclass=B):pass")
    node = transformer.visit(node)
    assert node == ast.parse("class A(_py_backwards_six_withmetaclass(B))")

# Generated at 2022-06-23 22:47:23.322002
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import assert_changed
    assert_changed("class A(metaclass=B): pass",
                   "class A(_py_backwards_six_with_metaclass(B)): pass",
                   MetaclassTransformer)

# Generated at 2022-06-23 22:47:29.964520
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Setup
    t = MetaclassTransformer()
    prog = ast.parse("""
    class A(type):
        pass
    """, filename='<string>', mode='exec')

    # Exercise
    result = t.visit_Module(prog)

    # Verify
    expected = ast.Module(body=[ast.ImportFrom(module='six', names=[six_import.get_name()], level=0),
                                ast.ClassDef(name='A', decorator_list=[],
                                             bases=[class_bases.get_name()], keywords=[],
                                             body=[], starargs=None, kwargs=None)],
                           type_ignores=[])
    assert ast.dump(result) == ast.dump(expected)

