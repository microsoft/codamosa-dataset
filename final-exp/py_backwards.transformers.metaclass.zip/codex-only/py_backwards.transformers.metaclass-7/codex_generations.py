

# Generated at 2022-06-23 22:37:38.271759
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """Compile:
        class A(metaclass=B):
            pass
    To:
        class A(_py_backwards_six_with_metaclass(B))
    
    """
    import ast
    source = 'class A(metaclass=B):\n    pass\n'
    tree = ast.parse(source)
    print('Source:')
    print(source)
    print()
    transformer = MetaclassTransformer()
    new_tree = transformer.visit(tree)
    if new_tree is tree:
        print('Did not change code.')
    else:
        print('Transformed code:')
        print(ast.unparse(new_tree))
    print()
    print()


# Generated at 2022-06-23 22:37:40.115269
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    t = MetaclassTransformer()
    t._tree_changed = False
    t._dependencies = set()

# Generated at 2022-06-23 22:37:45.212334
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    sample_code='class A(metaclass=B):\n    pass'
    target_code='class A(_py_backwards_six_with_metaclass(B)):\n    pass'
    node = ast.parse(sample_code)
    t = MetaclassTransformer()
    node = t.visit(node)
    assert astor.to_source(node) == target_code


# Generated at 2022-06-23 22:37:50.552204
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert MetaclassTransformer().visit(ast.parse("""
    class A(metaclass=type):
        pass
    """)) == ast.parse("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(type))
        pass
    """)


# Generated at 2022-06-23 22:37:58.875374
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    assert_equal(MetaclassTransformer('class A(metaclass=object): pass').result,
                 'class A(object): pass')
    assert_equal(MetaclassTransformer('class A(int, metaclass=object): pass').result,
                 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(object, int)): pass')
    assert_equal(MetaclassTransformer('class A(int, "foo", metaclass=object): pass').result,
                 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(object, int, "foo")): pass')



# Generated at 2022-06-23 22:37:59.792439
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:38:08.683838
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    module = ast.parse('''\
    class A(metaclass=Foo):
        pass
    ''')

    assert module.body[0].keywords[0].arg == "metaclass"
    assert module.body[0].bases[0].id == "Foo"

    MetaclassTransformer(2, 7).visit(module)

    assert module.body[0].bases[0].func.id == "_py_backwards_six_withmetaclass"
    assert module.body[0].bases[0].keywords[0].arg == "metaclass"
    assert module.body[0].bases[0].keywords[0].value.id == "Foo"



# Generated at 2022-06-23 22:38:13.936436
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.ClassDef(name='A', bases=[],
                        keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B', ctx=ast.Load()))],
                        body=[], decorator_list=[])
    res = MetaclassTransformer().visit(node)
    assert res.bases[0].func.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-23 22:38:21.760978
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ...t import Tester
    t = Tester()
    snippet = t.code_compiles('class A(metaclass=B)')
    assert snippet == six_import.get_body() + class_bases.get_body()
    snippet = t.code_compiles('class A(B, metaclass=C)')
    assert snippet == six_import.get_body() + class_bases.get_body()
    snippet = t.code_compiles('class A(B, C, metaclass=D, E)')
    assert snippet == six_import.get_body() + class_bases.get_body()

# Generated at 2022-06-23 22:38:33.559721
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    #  Test dependencies
    assert sys.version_info >= MetaclassTransformer.target, "Not applicable on this Python version"

    assert six_import.get_body() == [ast.ImportFrom(module='six',
                                                    names=[ast.alias(name='with_metaclass',
                                                                     asname='_py_backwards_six_withmetaclass')],
                                                    level=0)]


# Generated at 2022-06-23 22:38:36.263861
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # type: () -> None
    ast_module = ast.parse('class A(object, metaclass=B): pass')

# Generated at 2022-06-23 22:38:41.092631
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
        class A(metaclass=B):
            pass
    """
    lines = [line.strip() for line in code.splitlines()]
    parsed = ast.parse('\n'.join(lines))

    m = MetaclassTransformer()
    res = m.visit(parsed)
    module = {}
    six = __import__('six')
    module.update(six=six)
    exec(compile(ast.Module(body=res.body), '<test>', 'exec'), module)
    assert module['A'].__class__.__name__ == 'A'

# Generated at 2022-06-23 22:38:50.751358
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    expected_module_body_0 = six_import.get_body()
    expected_module_body_1 = ast.ClassDef(
        name='A',
        bases=class_bases.get_body(
            metaclass=ast.Str(s='B'),
            bases=ast.List(elts=[], ctx=ast.Load())
        ),
        body=[ast.Pass()],
    )
    sample_module_body_0 = ast.Pass()
    sample_module_body_1 = ast.ClassDef(
        name='A',
        bases=[ast.Str(s='B')],
        keywords=[ast.keyword(arg='metaclass', value=ast.Str(s='B'))],
        body=[ast.Pass()],
    )

# Generated at 2022-06-23 22:38:52.041325
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:39:03.308603
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    def check(input, desired_output):
        tree = ast.parse(input)  # type: ignore
        _tree_changed, transformed = MetaclassTransformer().visit(tree)
        assert transformed == desired_output

    check('''
            class Test(object, metaclass=type):
                pass
        ''', '''
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class Test(_py_backwards_six_withmetaclass(type, object)):
                pass
        ''')

# Generated at 2022-06-23 22:39:11.845524
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Given the input.py
    input = ast.parse("""class A(metaclass=B):
    pass""")
    # And the MetaclassTransformer instance
    mt = MetaclassTransformer()

    # When I visit the node
    mt.visit(input)

    # Then it should have transformed correctly
    # None of the assertions should err
    assert input.body[0] == six_import.get_module()
    assert input.body[1] == ast.ClassDef(name='A',
        bases=[class_bases.get_body(metaclass=ast.Name(id='B', ctx=ast.Load()))],
        body=[ast.Pass()])

# Generated at 2022-06-23 22:39:15.083997
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    src = six_import.format_code()
    src += '\n'
    src += class_bases.format_code()
    src += '\n\n'

# Generated at 2022-06-23 22:39:21.958492
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    import pprint
    import astunparse
    from ..codegen import CodeGenerator
    from ..transformers import MetaclassTransformer
    from .. import utils
    from ..utils import snippet
    from ... import utils as gutils

    with snippet('class A(metaclass=B): pass') as  snippet_code:
        code_ast = ast.parse(snippet_code.read())

    before = '\n'.join(gutils.ast2code(code_ast).split('\n')[1:])
    print(before)
    transformer = MetaclassTransformer()
    transformer.transform(code_ast)

    after = CodeGenerator().visit(code_ast)
    after = '\n'.join(after.split('\n')[1:])
    print(after)


# Generated at 2022-06-23 22:39:23.271135
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    #Test:

# Generated at 2022-06-23 22:39:25.023204
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:39:35.873292
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six
    import inspect
    import astor
    from six.moves import builtins
    from py27_mypy_backport.utils.tree import tree_to_str

    # Make sure that snippet `six_import` is correctly written
    test_for_six_import = six_import.get_body()

    if astor.to_source(test_for_six_import) != "from six import with_metaclass as _py_backwards_six_withmetaclass\n":
        print(astor.to_source(test_for_six_import))
        assert False

    # Make sure that snippet `class_bases` is correctly written
    # This test is not good, since there is no dependency checking for the arguments

# Generated at 2022-06-23 22:39:43.904381
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ...utils.testing import check_transformation, check_import
    from ...utils.testing import check_snippet

    check_transformation(
        MetaclassTransformer, 'class Foo(metaclass=Bar): pass',
        'class Foo(_py_backwards_six_withmetaclass(Bar)): pass',
    )

    check_import(
        MetaclassTransformer, 'class Foo(metaclass=Bar): pass', 'six'
    )

    check_snippet(
        MetaclassTransformer, 'class Foo(object, metaclass=Bar): pass',
        'from six import with_metaclass as _py_backwards_six_withmetaclass',
        'class Foo(_py_backwards_six_withmetaclass(Bar)): pass',
    )

# Generated at 2022-06-23 22:39:52.199445
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    node = ast.parse('class A(metaclass=B):\n    pass')
    MetaclassTransformer().visit(node)
    return node


if __name__ == "__main__":
    from typed_ast import ast3
    import sys
    def set_trace():
        from IPython.core.debugger import Pdb
        Pdb(color_scheme='Linux').set_trace(sys._getframe().f_back)
    import pprint
    ast3.parse('class A: pass'.strip())
    ast3.parse('class A(metaclass=B): pass'.strip())
    print('\n\n\n')
    pprint.pprint(test_MetaclassTransformer())

# Generated at 2022-06-23 22:39:53.903130
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Unit test for method visit_ClassDef of class MetaclassTransformer
    """
    import astor


# Generated at 2022-06-23 22:39:54.367842
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:39:56.246504
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..unittest_tools import assertEqualAST
    from typed_ast import ast3 as ast
    transformer = MetaclassTransformer()

# Generated at 2022-06-23 22:39:56.877279
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:39:59.050801
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:40:02.885688
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast as py_ast
    import astunparse
    #
    # test MetaclassTransformer
    transformer = MetaclassTransformer(target_version=MetaclassTransformer.target)
    # prepare test database
    #
    # test input

# Generated at 2022-06-23 22:40:10.547416
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class_def = ast.ClassDef(name='Test',
                             bases=[],
                             keywords=[ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='TestMetaclass',
                                                                  ctx=ast.Load()))],
                             body=[],
                             decorator_list=[])
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(class_def)
    assert metaclass_transformer._tree_changed is True

# Generated at 2022-06-23 22:40:15.702541
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..testing import transform
    from string import whitespace
    snippet = """
            class A(metaclass = B):
                pass
            """
    expected = """
            from six import with_metaclass as _py_backwards_six_withmetaclass


            class A(_py_backwards_six_withmetaclass(B)):
                pass
            """
    transform(MetaclassTransformer, snippet, expected, (2, 7))

# Generated at 2022-06-23 22:40:18.192646
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class Foo(object): pass
    import astunparse
    # result = ast.parse(u"Foo = type(u'Foo', (), {})")
    # assert result == code



# Generated at 2022-06-23 22:40:20.683485
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    text = """class A(metaclass=B): pass"""

# Generated at 2022-06-23 22:40:25.450549
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import six
    import _py_backwards_six_withmetaclass
    node = ast.parse('class A(metaclass=B): pass')
    assert node.body[0].bases[0].id == 'B'
    MetaclassTransformer().visit(node)

    assert node.body[0].bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert node.body[0].bases[0].args[0].id == 'B'

# Generated at 2022-06-23 22:40:29.103085
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    tree = ast.parse("""
        class A(metaclass=B):
            pass

        def f():
            pass
    """)

    transformer = MetaclassTransformer()
    transformer.visit(tree)

    assert transformer._tree_changed

    tree = ast.parse("""
        class A(metaclass=B):
            pass

        def f():
            pass
    """)
    assert transformer._painstake_visit(tree) == transformer._painstake_visit(transformer.visit(tree))



# Generated at 2022-06-23 22:40:36.836342
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor
    tree = ast.parse('''
            class Main(metaclass=type):
                pass
            print(Main)
    ''')
    result = astor.to_source(MetaclassTransformer().visit(tree))
    assert result.strip() == '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class Main(_py_backwards_six_withmetaclass(type)):
        pass
    print(Main)
    '''

# Generated at 2022-06-23 22:40:39.499703
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    six_import = snippet('six_import')

    class_bases = snippet('class_bases')

    visitor = MetaclassTransformer()


# Generated at 2022-06-23 22:40:47.612370
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # eval(compile(source=six_import.get_source(), filename="<string>", mode="exec"))

    t = ast.parse(dedent(
        """
        class Foo(Bar):
            def __init__(self):
                pass
        """
    ))
    s = MetaclassTransformer()
    result = s.visit(t)

    print(ast.dump(result, annotate_fields=False, include_attributes=False))
    print(result.body[0].bases[0].args[0].__class__)
    # assert result == ast.Module(
    #     body=[
    #         ast.ClassDef(
    #             name='Foo',
    #             bases=[
    #                 ast.Call(
    #                     func=ast.Attribute(
    #                         value=ast

# Generated at 2022-06-23 22:40:56.161643
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_def_input = ast.ClassDef(name='A',
                                   bases=[
                                       ast.Name(id='object', ctx=ast.Load()),
                                   ],
                                   keywords=[
                                       ast.keyword(arg='metaclass',
                                                   value=ast.Name(id='B',
                                                                  ctx=ast.Load())),
                                   ],
                                   body=[
                                       ast.Pass()
                                   ],
                                   decorator_list=[],
                                   lineno=1,
                                   col_offset=0
                                   )

# Generated at 2022-06-23 22:41:03.062078
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..pgen2 import parse
    module = parse("""
    class A(metaclass=B):
        pass
    """).module
    transformer = MetaclassTransformer()
    assert transformer.visit(module) == parse("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """).module



# Generated at 2022-06-23 22:41:13.570939
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from py_backwards.transformers.six.with_metaclass import MetaclassTransformer, six_import, class_bases
    source = """class A(metaclass=B):
    pass""".split('\n')
    tree = ast.parse('\n'.join(source))
    tree_updated = MetaclassTransformer().visit(tree)
    assert tree_updated is not None
    assert MetaclassTransformer.dependencies == ['six']

# Generated at 2022-06-23 22:41:19.639886
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """
    Test the visit_ClassDef method of class MetaclassTransformer
    """
    transformer = MetaclassTransformer()
    simple_class = ast.parse("""
        class test(metaclass=type):
            pass
    """)
    transformer.visit(simple_class)
    result = ast.dump(simple_class)
    expected = ast.dump("""
        _py_backwards_six_withmetaclass(type, test)
    """)
    assert result == expected


# Generated at 2022-06-23 22:41:24.534042
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    code = """
    class A(B, metaclass=C):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_with_metaclass

    class A(_py_backwards_six_with_metaclass(C, B)):
        pass
    """
    _assert_code(MetaclassTransformer, code, expected)

# Generated at 2022-06-23 22:41:26.760955
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from typed_ast.transforms import MetaclassTransformer


# Generated at 2022-06-23 22:41:29.634419
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert ast.parse(six_import()) == six_import.get_ast()
    assert ast.parse(class_bases()) == class_bases.get_ast()



# Generated at 2022-06-23 22:41:35.307227
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys
    import six
    from .. import Examples
    from ast_tools.transformers import TransformerSequence

    old_version, new_version = sys.version_info[:2]
    tf = TransformerSequence(examples=[Examples.metaclass, MetaclassTransformer], target=(old_version, new_version))
    node = tf.transform()

    compile(node, '<ast>', 'exec')



# Generated at 2022-06-23 22:41:35.974383
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:41:43.503635
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
      class A(metaclass=B):
          def __init__(self):
              pass
    """
    expected_code = """
      from six import with_metaclass as _py_backwards_six_withmetaclass
      class A(_py_backwards_six_withmetaclass(B), ):
          def __init__(self):
              pass
    """

    tree = ast.parse(code)
    MetaclassTransformer(2, 7).visit(tree)
    assert astor.to_source(tree).strip() == expected_code.strip()

# Generated at 2022-06-23 22:41:44.638306
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:41:51.460161
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.Module(
        body=[
            ast.ClassDef(
                name='A',
                keywords=[
                    ast.keyword(arg='metaclass',  # type: ignore
                                value=ast.Name(id='B'))
                ],
                body=[
                ]
            )
        ]
    )
    module = MetaclassTransformer.run_pipeline(module)
    expected_module = ast.parse('from six import with_metaclass as _py_backwards_six_withmetaclass\n\n'
                                '\n'
                                'class A(_py_backwards_six_withmetaclass(B, )):\n'
                                '    pass\n')

    assert ast.dump(module) == ast.dump(expected_module)

# Generated at 2022-06-23 22:41:56.413579
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Given this program:
    module_node = ast.parse('class A(metaclass=object): pass')

    # When transformed:
    MetaclassTransformer('').visit(module_node)

    # Then the result is:
    assert ast.dump(module_node) == "Module(body=[\nImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_with_metaclass')], level=0),\nClassDef(name='A', bases=[_py_backwards_six_with_metaclass(Object())], keywords=[], body=[Pass()], decorator_list=[])])"



# Generated at 2022-06-23 22:41:56.938608
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:42:01.737279
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3

    ast_string = "class A(metaclass=B): pass"
    tree = ast3.parse(ast_string)

    tree = MetaclassTransformer()(tree)

    expected = "from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B)): pass"
    assert expected == ast3.dump(tree)

# Generated at 2022-06-23 22:42:09.904486
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .base import BaseTestCompiler
    class Test(BaseTestCompiler):
        transformer = MetaclassTransformer
        code = """
        class A:
            pass
        """
        result = """
        class A:
            pass
        """

        def test_static_method_def(self):
            code = """
            class A(metaclass=B):
                pass
            """
            result = """
            class A(_py_backwards_six_with_metaclass(B)):
                pass
            """
            self.check(code, result)

# test_MetaclassTransformer()

# Generated at 2022-06-23 22:42:16.426513
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node_module = ast.parse("""
        class A(metaclass=B):
            pass
    """)
    MetaclassTransformer().visit(node_module)
    assert ast.dump(node_module) == """\
Module(body=[
    Import(names=[alias(
        name='six',
        asname='_py_backwards_six_withmetaclass')]),
    ClassDef(name='A',
             bases=[Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()),
                        args=[Name(id='B', ctx=Load())],
                        keywords=[])],
             body=[Pass()])])"""



# Generated at 2022-06-23 22:42:21.932016
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse(dedent('''
        class Foo(metaclass=Bar):
            pass
    '''))
    module = MetaclassTransformer().visit(module)
    expected = ast.parse(dedent('''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class Foo(_py_backwards_six_withmetaclass(Bar)):
            pass
    '''))
    print(ast.dump(module))
    assert module == expected



# Generated at 2022-06-23 22:42:22.479748
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:42:23.880635
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast as pyast  # The module typed_ast.ast3 re-exports python builtins

# Generated at 2022-06-23 22:42:34.074597
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    from six import with_metaclass as _py_backwards_six_withmetaclass

# Generated at 2022-06-23 22:42:42.494652
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    node = ast.ClassDef(name="A",
                        bases=[],
                        keywords=[ast.keyword(value=ast.Name(id="B", ctx=ast.Load())),],
                        body=[],
                        decorator_list=[])
    transformer = MetaclassTransformer(target_version=(2, 7))
    transformer.visit_ClassDef(node)
    assert len(node.bases) == 1
    assert len(node.bases[0].args) == 1
    assert node.bases[0].args[0].id == "B"

# Generated at 2022-06-23 22:42:50.127431
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typing import Any, List
    from ..utils.python import Adder

    class TestTransformer(MetaclassTransformer, Adder):
        TREE: List[Any] = []

    class A(metaclass=TestTransformer):
        pass


# Generated at 2022-06-23 22:42:56.458842
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(metaclass=type):
        pass

    transformer = MetaclassTransformer()
    module = transformer.visit(ast.parse(A.__module__ + '\n' + A.__qualname__))
    # Import six
    assert isinstance(module.body[0], ast.ImportFrom)
    # Class A with metaclass type

# Generated at 2022-06-23 22:43:02.452850
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    from ..utils.ast_tools import dump
    node = ast.parse("""class A(metaclass=B): pass""")
    transformer = MetaclassTransformer()
    transformer.visit(node)
    dump(node)
    assert 'from six import with_metaclass as _py_backwards_six_withmetaclass' in dump(node)  # noqa
    assert 'class A(_py_backwards_six_withmetaclass(B))' in dump(node)  # noqa

# Generated at 2022-06-23 22:43:08.978653
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    metaclassTransformer = MetaclassTransformer()
    test_body = ast.parse("class A(metaclass=B): pass")
    assert ast.dump(metaclassTransformer.visit(test_body)) == ast.dump(ast.parse(
    "from six import with_metaclass as _py_backwards_six_withmetaclass\n\n\nclass A(_py_backwards_six_withmetaclass(B, object)):\n    pass"))

# Generated at 2022-06-23 22:43:17.120757
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    import six
    import sys
    import tempfile
    import unittest
    
    
    if six.PY2:
        CLASS_DEF = """
        class A(metaclass=B):
            pass
        """
        EXPECTED = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    else:
        CLASS_DEF = """
        class A(metaclass=B):
            pass
        """
        EXPECTED = """
        class A(metaclass=B):
            pass
        """
    tree = ast.parse(CLASS_DEF)
    result = MetaclassTransformer().transpile_tree

# Generated at 2022-06-23 22:43:18.423983
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()

# Generated at 2022-06-23 22:43:21.087483
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse('class A(metaclass=B): pass')
    MetaclassTransformer().visit(module)

# Generated at 2022-06-23 22:43:24.859905
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor

    class TestMetaclassTransformer(MetaclassTransformer):
        def visit_ClassDef(self, node):
            node.bases = ast.List(elts=[ast.Name(id='object', ctx=ast.Load())])
            return self.generic_visit(node)


# Generated at 2022-06-23 22:43:31.445154
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_six_import import test_SixImportTransformer_visit_Module
    code = """
    class A(object, bar=baz, metaclass=B):
        pass
    """
    expected = """
    class A(_py_backwards_six_withmetaclass(B, object)):
        pass
    """
    result = test_SixImportTransformer_visit_Module(code)
    assert expected in result

# Generated at 2022-06-23 22:43:38.120953
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    s = """
        class A(metaclass=B):
            pass
        """
    expect = """
        from six import with_metaclass as _py_backwards_six_withmetaclass


        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """
    t = MetaclassTransformer(options={})
    result = t.visit(ast.parse(s))
    print(ast.dump(result))
    assert str(result) == expect

# Generated at 2022-06-23 22:43:44.328665
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    ast_tree = ast.parse('class A(metaclass=B): pass')
    # TODO: ast_tree.body[0].keywords[0].value = ast.Name(id='B')
    expected = 'from six import with_metaclass as _py_backwards_six_withmetaclass\n' \
               'class A(_py_backwards_six_withmetaclass(B))'

    tree_changed = MetaclassTransformer().visit(ast_tree)
    assert tree_changed == True
    assert astor.to_source(ast_tree).strip() == expected.strip()

# Generated at 2022-06-23 22:43:52.752908
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ...helpers import compile_snippet, parse_snippet
    from .six import SixTransformer
    source = """
    class A(metaclass=B):
        pass
    """
    expected = six_import.get_source() + """
    class A(_py_backwards_six_withmetaclass(B, object)):
        pass
    """
    tree = parse_snippet(source)
    tree = SixTransformer().visit(tree)
    new_tree = MetaclassTransformer().visit(tree)
    assert compile_snippet(new_tree) == expected

# Generated at 2022-06-23 22:43:59.956592
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    tree = ast.parse(
    '''
    class A(metaclass=B):
        pass
    '''
    )
    assert MetaclassTransformer().visit(tree) == ast.parse(
    '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    )


# Generated at 2022-06-23 22:44:00.632401
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:44:08.171260
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    module = ast.parse(textwrap.dedent('''
        class A(metaclass=B):
            pass
        '''))
    metaclass_transformer = MetaclassTransformer(None)
    transformed_module = metaclass_transformer.visit(module)
    print(ast.dump(transformed_module))
    module = ast.parse(ast.fix_missing_locations(six_import.get_body()).body[0])
    class_def = ast.parse(ast.fix_missing_locations(class_bases.get_body()).body[0]).body[0]
    module.body.extend(transformed_module.body)
    assert ast.dump(module, annotate_fields=False) == ast.dump(transformed_module, annotate_fields=False)

# Generated at 2022-06-23 22:44:12.452908
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node_before = ast.parse("class C(metaclass=A): pass")
    node_after = ast.parse("""
    from six import with_metaclass as _py_backwards_six_with_metaclass

    class C(_py_backwards_six_with_metaclass(A))): pass
    """)
    transformer = MetaclassTransformer(None)
    node_after = transformer.visit(node_after)  # type: ignore
    assert ast.dump(node_before) == ast.dump(node_after)

# Generated at 2022-06-23 22:44:16.276245
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    return_node = MetaclassTransformer().visit(ast.parse(
        '''
        import sys
        class A(object, metaclass=sys.version_info[0]):
            pass
        '''
    ))

# Generated at 2022-06-23 22:44:26.382887
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ast import parse
    from .base import BaseNodeTransformerTest
    from .six_import import test_SixImportTransformer_visit_Module

    class Test(BaseNodeTransformerTest):
        target_class = MetaclassTransformer

        @property
        def ast_before(self):
            return parse("""
                class A(metaclass=B):
                    pass

                class C(metaclass=D, foo=True):
                    pass
            """)


# Generated at 2022-06-23 22:44:36.594722
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    c = MetaclassTransformer()
    class_def = ast.ClassDef(name="A",
                             bases=[ast.Name(id="B")],
                             keywords=[ast.keyword(arg="metaclass", value=ast.Name(id="B"))],
                             body=[ast.Pass()],
                             decorator_list=[])
    expected = ast.ClassDef(name="A",
                            bases=class_bases.get_body(metaclass=ast.Name(id="B"), bases=ast.List(elts=[ast.Name(id="B")])),
                            keywords=[],
                            body=[ast.Pass()],
                            decorator_list=[])
    assert c.visit_ClassDef(class_def) == expected

# Unit

# Generated at 2022-06-23 22:44:43.025473
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .py2to3 import BASE_TRANSFORMERS

    module = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    transformer = MetaclassTransformer(module, BASE_TRANSFORMERS)
    new_module = transformer.visit(module)

    assert transformer.tree_changed
    expected_module = ast.parse("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    assert expected_module.body[1] == new_module.body[1]

# Generated at 2022-06-23 22:44:50.296824
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.test import check_code
    from . import example_module

    class B:
        pass

    class C(metaclass=B):
        pass

    print(C.__class__)
    print(C.__bases__)

    module = example_module(__name__)
    module_node = module
    transformer = MetaclassTransformer()
    module_node = transformer.visit(module_node)


    class B:
        pass

    class C2(metaclass=B):
        pass

    print(C2.__class__)
    print(C2.__bases__)

    # print(module.__dict__['C2'])
    # print(module.__dict__['C2'].__bases__)

    print(module_node)


# Generated at 2022-06-23 22:44:58.824187
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    node = ast.Module([
        ast.ClassDef(name='Test', bases=[], keywords=[],
                     body=[ast.Pass()], decorator_list=[], lineno=1, col_offset=4),
    ])
    res = MetaclassTransformer().visit(node)
    print(ast.dump(res))

# Generated at 2022-06-23 22:45:00.947442
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    with backwards.tests.utils.setup_test('__future__', 'six'):
        with backwards.tests.utils.setup_test('metaclass'):
            assert backwards.transform(__name__)

# Generated at 2022-06-23 22:45:05.863929
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3
    from ast_toolbox.backports.MetaclassTransformer import MetaclassTransformer
    from ast_toolbox import ast_to_source
    obj = MetaclassTransformer()
    node = ast3.parse('class A(metaclass=B): pass', mode='exec')
    node = obj.visit(node)
    assert ast_to_source(node).strip() == 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass'

# Generated at 2022-06-23 22:45:08.070642
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class DummyNode(ast.AST):
        _fields = []
    dummy_node = DummyNode()
    assert dummy_node

# Generated at 2022-06-23 22:45:09.509353
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 22:45:18.217965
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from tests.utils import round_trip
    from ..utils.tree import transforms_to
    snippet = '''
        class A(metaclass=B, a=1): pass
        class B(a=2): pass
    '''

    expected = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B, a=1)): pass
        class B(a=2): pass
    '''

    assert round_trip(snippet, MetaclassTransformer, expected) == expected
    assert round_trip(snippet, MetaclassTransformer) > snippet
    transforms_to(snippet, MetaclassTransformer, expected)


# Generated at 2022-06-23 22:45:26.480944
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..test import GeneratorTestCase
    from ..utils.snippet import snippet

    class test_MetaclassTransformer_visit_ClassDef(GeneratorTestCase):
        # TODO(girishramnani): How to auto generate the first 2 parameters,
        # subtransformer and transformer?
        def test_1(self):
            src = "class A(metaclass=B):\n    pass"

# Generated at 2022-06-23 22:45:27.472571
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:45:32.933825
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.testing import assert_program

    program = '''
    class A(metaclass=B, obj=C):
        pass
    '''

    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B, *[C, ]), obj=C):
        pass
    '''

    assert_program(program, expected, [MetaclassTransformer])

# Generated at 2022-06-23 22:45:33.457651
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:45:39.290093
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = textwrap.dedent("""\
        class A():
            pass
        class B(metaclass=C):
            pass
        """)
    expected = textwrap.dedent("""\
        from six import with_metaclass
        class A():
            pass
        class B(with_metaclass(C)):
            pass
        """)
    assert expected == MetaclassTransformer.run(source)

# Generated at 2022-06-23 22:45:43.643607
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_visitor import VisitorTestCase

    class Test(VisitorTestCase):
        visitor_class = MetaclassTransformer
        text = """\
        class A(metaclass=B):
            pass
        """
        expected = """\
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """

    # yapf: disable
    assert Test.run().text == Test.expected
    # yapf: enable

# Generated at 2022-06-23 22:45:47.447860
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class DummyMetaclass(type):
        pass
    class DummyBase(object):
        pass
    class DummyChild(DummyBase):
        __metaclass__ = DummyMetaclass

# Generated at 2022-06-23 22:45:54.251199
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    before = AST.parse('''
        class A(metaclass=B):
            pass
    ''')

    after = AST.parse('''
        from six import with_metaclass as _py_backwards_six_with_metaclass

        class A(_py_backwards_six_with_metaclass(B))
    ''')

    m = MetaclassTransformer()
    m.visit(before)
    res = Compare(after, before).are_same()
    assert res is True



# Generated at 2022-06-23 22:46:00.321893
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    m = ast.parse('class B(metaclass=A): pass')
    MetaclassTransformer().visit(m)
    assert ast.dump(m) == "from six import with_metaclass as _py_backwards_six_withmetaclass\n\n\nclass B(_py_backwards_six_withmetaclass(A, )):\n    pass"


# Generated at 2022-06-23 22:46:08.314773
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():

    # case 1
    class Node:
        _fields = ['bases']

        def __getitem__(self, item):
            return getattr(self, item)

    def f():
        metaclass = Node()
        metaclass._fields = ['lineno']
        metaclass.lineno = 1
        metaclass.bases = 'arg'
        return metaclass

    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B))
    '''

    node = ast.parse('''
    class A(B, metaclass=C):
        pass
    ''')

    metaclass = f()
    metaclass.lineno = 1
    metaclass

# Generated at 2022-06-23 22:46:10.458759
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()

# Generated at 2022-06-23 22:46:15.060873
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Given
    module = ast.parse('''class A(metaclass=B):
    pass''')

    # When
    transformer = MetaclassTransformer()
    transformed = transformer.visit(module)

    # Then

# Generated at 2022-06-23 22:46:25.013814
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Test if the visit_ClassDef method of MetaclassTransformer works.
    """

    # Example of the input
    input = """
    class A(metaclass=B):
        pass
    """

    # The expected output
    expected = """
    from six import with_metaclass as _py_backwards_six_with_metaclass

    class A(_py_backwards_six_with_metaclass(B)):
        pass
    """

    # Compile the input
    node = ast.parse(input)

    # Run MetaclassTransformer
    transformer = MetaclassTransformer()
    new_node = transformer.visit(node)

    # The "expected" node
    expected_node = ast.parse(expected)

    # Check if the node returned by
    # MetaclassTransformer is

# Generated at 2022-06-23 22:46:26.024357
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:46:35.391476
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import ClassDef, Str, Expr, Name, Dict, Num, List, keywords, arguments, mod
    from typed_astunparse import unparse

    # Example 1
    input = ClassDef(name="A",
                     bases = [Str(s="B")],
                     keywords = [keywords(arg="metaclass", value=Expr(value=Name(id="C")))],
                     body = [],
                     decorator_list = [Expr(value=Name(id="D"))])

    output = unparse(input)

    assert output == dedent("""
        @D
        class A(_py_backwards_six_withmetaclass(C, 'B'))""")

    # Example 2

# Generated at 2022-06-23 22:46:42.215660
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ...testing.utils import assert_subtree

    code = """
        class A(metaclass=B):
            pass
    """

    expected = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """

    assert_subtree(MetaclassTransformer().visit(ast.parse(code)),
                   ast.parse(expected))

# Generated at 2022-06-23 22:46:50.440027
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_body
    from ..utils.shim import Shim

    input = ast.parse('class A: pass')
    output = get_body(ast.parse('''\
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A: pass
    '''))

    assert get_body(MetaclassTransformer().visit(input)) == output
    assert MetaclassTransformer.test_tree(input) == output


# Generated at 2022-06-23 22:47:00.384264
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3
    from .test_transformer import run_test, transform_and_compile
    from .test_utils import assert_equal_code

    class TestMetaclassTransformer(MetaclassTransformer):
        def __init__(self):
            self._tree_changed = False
            super().__init__()

    code = """
    class A():
        pass
    class B(metaclass=C):
        pass
    """
    compare_expected = """
    class A():
        pass
    class B(_py_backwards_six_withmetaclass(C)):
        pass
    """
    run_test(code, compare_expected, TestMetaclassTransformer,
             transform_and_compile)

    tree = ast3.parse(code)
    transformer = TestMetac

# Generated at 2022-06-23 22:47:01.595571
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:47:12.964750
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:47:17.678970
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class_code = 'class A(metaclass=B):\n    pass'
    expected = six_import.get_body() + class_code

    actual = MetaclassTransformer().visit(ast.parse(class_code))

    assert(expected == astor.to_source(actual))

# Generated at 2022-06-23 22:47:26.679528
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    six_import_ = six_import.get_ast()
    six_import_.body[0].lineno = 0
    six_import_.body[0].col_offset = 0
    tree = ast.parse('class A(metaclass=B):\n pass')
    print(MetaclassTransformer().visit(tree))

# Generated at 2022-06-23 22:47:34.556976
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import typing  # noqa

    assert six_import.get_body() == [
        ast.ImportFrom(
            module='six',
            names=[ast.alias(
                name='with_metaclass',
                asname='_py_backwards_six_withmetaclass')],
            level=0)
    ]
