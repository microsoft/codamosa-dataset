

# Generated at 2022-06-23 22:37:42.654540
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..pysnippets import _py_backwards_six_withmetaclass
    import sys
    from ..utils import get_node
    from textwrap import dedent

    if sys.version_info >= (3, 0):
        # Unit test MetaclassTransformer.visit_Module
        node = get_node(dedent('''
        class A(metaclass=B):
            pass
        '''))
        expected = get_node(dedent('''
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        '''))
        transformer = MetaclassTransformer()
        transformer.visit(node)
        assert node == expected


# Generated at 2022-06-23 22:37:51.108201
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from astunparse import dump
    from ..utils.tree import parse_module
    from ..utils.snippet import snippet

    snippet = snippet("""
    class A(metaclass=B):
        pass
    """)

    code_tree = parse_module(snippet.get_body())
    six_import_tree = parse_module(six_import.get_body())

    transformer = MetaclassTransformer()
    transformer.visit(code_tree)
    assert dump(six_import_tree) in dump(code_tree)



# Generated at 2022-06-23 22:38:02.178232
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    from metatree.utils.compat import source_parse
    from metatree.transform.six import Metaclass
    from metatree.transform.helpers.tuple import TupleComprehensions

# Generated at 2022-06-23 22:38:03.982512
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_visitor import TestVisitor

# Generated at 2022-06-23 22:38:08.025902
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast
    tree = ast.parse(snippet('''
    class Array(metaclass=ArrayMeta):
        pass
    '''))
    t = MetaclassTransformer()
    t.visit(tree)
    assert ast.dump(tree) == snippet('''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class Array(_py_backwards_six_withmetaclass(ArrayMeta)):
        pass
    ''')

# Generated at 2022-06-23 22:38:13.126914
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class_ = ast.ClassDef(
        name='A',  # type: ignore
        bases=[ast.Name(id='object', ctx=ast.Load())],
        keywords=[ast.keyword(arg='metaclass',  # type: ignore
                              value=ast.Name(id='object', ctx=ast.Load()))],
        body=[])

    expected = ast.ClassDef(
        name='A',  # type: ignore
        bases=[ast.Call(
            func=ast.Attribute(
                value=ast.Name(id='six', ctx=ast.Load()),
                attr='with_metaclass',
                ctx=ast.Load()
            ),
            args=[ast.Name(id='object', ctx=ast.Load())],
            keywords=[])],
        body=[])

   

# Generated at 2022-06-23 22:38:22.548641
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast as pyast
    from typed_ast import ast3 as typed_ast

    with_metaclass = typed_ast.WithItem(context_expr=typed_ast.Name(id='metaclass', ctx=typed_ast.Load()),
                                        optional_vars=None)

    def _test(test_expr: pyast.expr, result_expr: pyast.expr) -> None:

        tree = typed_ast.parse(test_expr)
        tree = MetaclassTransformer().visit(tree)
        assert typed_ast.dump(tree) == result_expr

    # Single class

# Generated at 2022-06-23 22:38:30.853075
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = """
    class A(metaclass=B):
        pass
    """
    root = astor.parse_tree(source)
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """
    MetaclassTransformer().visit(root)
    actual = astor.to_source(root).strip()
    assert actual == expected.strip()



# Generated at 2022-06-23 22:38:38.401119
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source_to_code
    code = 'class A(metaclass=type):\n pass'
    expected = 'from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(type)):\n    pass'  # noqa
    expected = expected.replace('\n', os.linesep)

    tree = source_to_code(code)
    transformer = MetaclassTransformer()
    tree = transformer.visit(tree)
    transformed = code_to_source(tree)

    assert expected == transformed

# Generated at 2022-06-23 22:38:41.394139
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:38:47.570039
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("""
        class A(object, metaclass=int):
            pass
        """, mode='exec')
    res = ast.dump(node, annotate_fields=False, include_attributes=False)
    assert res == ("Module(body=[ClassDef(name='A', bases=[object, _py_backwards_six_withmetaclass(<metaclass>=int)], "
                   "keywords=[], body=[], decorator_list=[])])")

# Generated at 2022-06-23 22:38:50.632222
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import unittest
    import ast as python_ast
    from ..utils.compiler import compile_isolated, compile_snippet
    from ..compatibility import MODULE_NAME


# Generated at 2022-06-23 22:38:59.106522
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    a = ast.Module([ast.ClassDef(name="A", bases=[], keywords=[ast.keyword(arg="metaclass", value=ast.Name("B"))], body=[], decorator_list=[])])
    b = ast.Module([six_import.get_node(), ast.ClassDef(name="A", bases=[class_bases.get_node(metaclass=ast.Name("B"), bases=[])], keywords=[], body=[], decorator_list=[])])
    c = MetaclassTransformer()
    assert c.visit(a) == c.visit(b)

# Generated at 2022-06-23 22:39:04.291071
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = """
    class A(metaclass=B):
        pass
    """

    expected_output = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """

    module = ast.parse(source)
    module = MetaclassTransformer().visit(module)
    output = str(astunparse.unparse(module))
    print(output)
    assert output == expected_output


# Generated at 2022-06-23 22:39:13.585717
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert_equal(MetaclassTransformer().visit(ast.parse('class A: pass')),
                 ast.parse('class A: pass'))
    assert_equal(MetaclassTransformer().visit(ast.parse('class A(object): pass')),
                 ast.parse('class A(object): pass'))
    assert_equal(MetaclassTransformer().visit(ast.parse('class A(metaclass=B): pass')),
                 ast.parse('from six import with_metaclass\nclass A(_py_backwards_six_with_metaclass(B)): pass'))

# Generated at 2022-06-23 22:39:16.550707
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import _test_transform
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 22:39:22.235094
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import _ast
    import astor
    source = MetaclassTransformer.snippet.get_source()
    source = source.replace('pass', 'print("test")')
    source = source.replace('def main():', 'class A:')
    node = _ast.parse(source)
    node = MetaclassTransformer().visit(node)
    assert astor.to_source(node) == 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(str, int, float)):\n    print("test")'

# Generated at 2022-06-23 22:39:24.134851
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from asttokens import ASTTokens
    from ..compat import python_version
    from .. import transformers


# Generated at 2022-06-23 22:39:25.888884
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast

# Generated at 2022-06-23 22:39:33.554068
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ast import Module
    from .base import AutoExCompiler
    from ..utils.tree import print_tree
    from ..utils.meta import MetaClass
    from ..utils.snippet import snippet

    @snippet
    def source():
        class X(metaclass=MetaClass):
            pass

    module = Module(body=[AutoExCompiler().visit(source.get_tree())])
    print_tree(module)

    try:
        import six
    except ImportError:
        return
    else:
        assert six.exec_


# Generated at 2022-06-23 22:39:37.893283
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse('a=1')
    assert (
        MetaclassTransformer().visit(node) ==
        ast.Module(body=[six_import.get_body(), ast.Assign(targets=[ast.Name(id='a')], value=ast.Num(n=1))]))


# Generated at 2022-06-23 22:39:38.440463
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:39:41.508044
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils import as_source
    from .base import Unparseable
    result = MetaclassTransformer().visit(as_source(six_import))
    assert isinstance(result, ast.Module)
    assert result.body == []



# Generated at 2022-06-23 22:39:45.611512
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """
    Input:
    class A(metaclass=B):
        pass
    Output:
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_with_metaclass(B))
    """
    source = """class A(metaclass=B): pass"""


# Generated at 2022-06-23 22:39:54.309587
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .test_utils import make_test, make_visitor_test, get_target_version
    from . import snippet

    code1 = """
        from six import with_metaclass
        class A(metaclass=B):
        pass
        """

    code2 = """
        from six import with_metaclass
        class A(with_metaclass(B)):
        pass
        """

    expected = """
        class A(with_metaclass(B)):
        pass
        """

    make_test(MetaclassTransformer, code1, expected)
    make_test(MetaclassTransformer, code2, expected)
    make_test(MetaclassTransformer, code2, expected)
    
    make_visitor_test(MetaclassTransformer, code1, expected)
    make

# Generated at 2022-06-23 22:39:57.245840
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..compiler import compile_str

    code = compile_str("""
        class A(metaclass=B):
            pass
    """,
    'test_MetaclassTransformer_visit_Module',
    'exec')

    assert '_py_backwards_six_withmetaclass' in code


# Generated at 2022-06-23 22:39:58.241446
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .transformers import _transform


# Generated at 2022-06-23 22:40:00.992186
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer([])
    code = 'class A(metaclass=B): pass'
    tree = ast.parse(code)
    transformer.visit(tree)

# Generated at 2022-06-23 22:40:08.038175
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    source = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    expected = ast.parse("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    mt = MetaclassTransformer()
    mt.visit(source)
    assert ast.dump(source) == ast.dump(expected)

# Generated at 2022-06-23 22:40:15.907570
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Given
    code = '''
        class Foo(metaclass=Bar):
            pass
        '''
    tree = ast.parse(code)
    expected = '''
        import six
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class Foo(_py_backwards_six_withmetaclass(Bar)):
            pass
        '''

    # When
    transformer = MetaclassTransformer()
    new_tree = transformer.visit(tree)

    # Then
    assert ast.dump(new_tree, annotate_fields=False, include_attributes=False) == expected


# Generated at 2022-06-23 22:40:21.109335
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # type: () -> None
    source = 'class A(metaclass=B): pass'

    # No transform for Python 3
    result = transform(source, 3)
    assert str(result) == source
    assert result.body[0].keywords[0].arg == 'metaclass'

    result = transform(source, 2)
    assert result.body[0].elts[0].func.id == '_py_backwards_six_withmetaclass'

    # Transform for Python 2
    result = transform(source, (2, 7))
    assert result.body[0].elts[0].func.id == '_py_backwards_six_withmetaclass'

    # No transform for Python 2.6
    result = transform(source, (2, 6))
    assert str(result) == source

# Generated at 2022-06-23 22:40:28.279245
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = """
            class A(metaclass=B):
                pass
            """
    expected_code = """
            from six import with_metaclass as _py_backwards_six_with_metaclass
            
            class A(_py_backwards_six_with_metaclass(B)):
                pass
            
            """
    module = ast.parse(code)
    transformer = MetaclassTransformer()
    module = transformer.visit(module)
    result_code = compile(module, '', 'exec')
    assert result_code == expected_code

# Generated at 2022-06-23 22:40:39.246401
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .six import SixImporter
    from .utils import parse
    import six

    class B(type):
        pass

    class A(metaclass=B):
        def __init__(self):
            pass

    class A2(metaclass=B, other_class=list):
        def __init__(self):
            pass

    class A3(object, metaclass=B):
        pass

    class A4(metaclass=six.with_metaclass(B)):
        pass

    test_cases = [('A', 'A'),
                  ('A2', 'A2'),
                  ('A3', 'A3'),
                  ('A4', 'A4')]


# Generated at 2022-06-23 22:40:39.683906
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:40:41.937910
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.test_utils import AssertNodeEqual
    from ..utils.fixer_utils import FormatCode


# Generated at 2022-06-23 22:40:53.136236
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.fake_context import FakeContext
    import six

    def test(source: str) -> ast.Module:
        ctx = FakeContext(source=source)
        node = ctx.get_root()
        transformer = MetaclassTransformer(tree=node)
        transformer.visit(node)
        return node

    code = """\
    class Meta:
        pass

    class A(metaclass=Meta):
        pass
    """

    expected = """\
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class Meta:
        pass

    class A(_py_backwards_six_withmetaclass(Meta)):
        pass
    """
    node = test(code)
    assert six.text_

# Generated at 2022-06-23 22:40:54.531178
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import get_code
    from .utils import assert_code_equal
    

# Generated at 2022-06-23 22:40:55.108957
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..transpile import Transpiler

# Generated at 2022-06-23 22:41:04.608342
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from textwrap import dedent
    from .base import BaseNodeTransformer

    input = dedent("""
    class A(metaclass=B):
        pass
    """)
    expected = dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    node = ast.parse(input)
    transformer = MetaclassTransformer(BaseNodeTransformer)
    actual = transformer.visit(node)
    assert transformer.tree_changed is True
    assert ast.dump(actual) == expected

# Generated at 2022-06-23 22:41:08.677824
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module_in = ast.parse('''
        class A(metaclass=B):
            pass
    ''')
    module_out = ast.parse('''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass
    ''')
    assert (MetaclassTransformer().visit(module_in) == module_out)


# Generated at 2022-06-23 22:41:15.551763
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from asttokens import ASTTokens
    from . import Preprocessor
    from .base import parse

    code = """class A(metaclass=B):
        pass"""
    tree = parse(code)
    tokens = ASTTokens(code, tree)
    p = Preprocessor(tokens)
    p.include_transformer(MetaclassTransformer)
    p.transform()


# Generated at 2022-06-23 22:41:16.556948
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:41:17.106142
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import re

# Generated at 2022-06-23 22:41:18.370716
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer()

# Generated at 2022-06-23 22:41:24.070496
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformer = MetaclassTransformer(targets={}, extra_deps=set())
    source = ast.parse("""
        class A(metaclass=B, base=C):
            pass
        """)
    expected = ast.parse("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B), base=C):
            pass
        """)
    assert transformer.visit(source) == expected

# Generated at 2022-06-23 22:41:25.467318
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.cst import parse_module

# Generated at 2022-06-23 22:41:35.748251
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import parse
    from ..utils.compilers import TreeCompiler
    from ..utils.differ import diff_source

    source1 = """
    class A(metaclass=B):
        pass
    """
    source2 = """
    class A(_py_backwards_six_with_metaclass(B)):
        pass
    """

    node1 = parse(source1)
    node2 = parse(source2)
    transformer = MetaclassTransformer()
    new_node = transformer.visit_Module(node1)
    result = TreeCompiler().compile(new_node)
    diff = diff_source(result, source2)
    assert diff is None, diff
    assert transformer._tree_changed == True
    diff = diff_source(new_node, node2)

# Generated at 2022-06-23 22:41:45.122058
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.Module(body=[
        ast.ClassDef(
            name='A',
            bases=[ast.Name(id='object')],
            keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B'))],
            body=[]
        )
    ])
    transformer = MetaclassTransformer(node)
    transformer.visit(node)
    actual = ast.dump(node)

# Generated at 2022-06-23 22:41:55.256608
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .test_utils import round_trip
    from .test_classes import get_class_def

    module = get_class_def()

    # Test that method does nothing if the class does not have a metaclass
    assert MetaclassTransformer(2, 7).visit(module) == module

    # Test that method does nothing if the code is not Python 2.6
    module.body[0].keywords = [ast.keyword(arg='metaclass', value=ast.Name(id='metaclass',
                                                                            ctx=ast.Load()))]
    assert MetaclassTransformer(2, 6).visit(module) == module

    # Test that method correctly replaces a metaclass with _py_backwards_six_with_metaclass
    expected_module = round_trip(module)
    expected

# Generated at 2022-06-23 22:41:59.874875
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils import setup_test_env
    setup_test_env()
    from ..parser.parser import Parser
    from ..utils.tree import parse

    code = 'class A(metaclass=B): pass'
    node = parse(code)
    parser = Parser().parse_module(code)

# Generated at 2022-06-23 22:42:00.702650
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:42:06.189909
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():

    class Dummy(MetaclassTransformer):
        _tree_changed = False

    transformer = Dummy()

    # Test if the tree changes
    s = """class A(metaclass=B): pass"""
    code = ast.parse(s, '<test-file>', 'exec')
    transformer.visit(code)
    assert transformer._tree_changed
    # TODO: check the result


# Generated at 2022-06-23 22:42:08.440539
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..python_version import python_version


# Generated at 2022-06-23 22:42:09.905065
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .. import unparse
    from . import parse


# Generated at 2022-06-23 22:42:15.431061
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast

    t = MetaclassTransformer()
    tree = ast.parse('''
                   class Foo(metaclass=Bar):
                       pass
                   ''')
    transformed = t.visit(tree)
    code = compile(transformed, '<string>', 'exec')
    namespace = {}
    exec(code, namespace)
    assert namespace['Foo'].__class__ is namespace['bar']

# Generated at 2022-06-23 22:42:20.758119
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

    source = """
    class MyClass(object):
        pass
    """
    tree = ast.parse(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class MyClass(_py_backwards_six_withmetaclass(object)):
        pass
    """
    assert transformer._tree_changed
    assert ast.dump(tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-23 22:42:24.967734
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    MetaclassTransformer().generic_visit(ast.ClassDef(name='A',
                                         bases=ast.List(elts=[]),
                                         keywords=[ast.keyword(arg='metaclass',
                                                               value=ast.Name(id='B',
                                                                              ctx=ast.Load()))],
                                         body=[],
                                         decorator_list=[],
                                         returns=None))

# Generated at 2022-06-23 22:42:26.119159
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astor

# Generated at 2022-06-23 22:42:32.668052
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class ExampleClass(object):
        pass
    
    parser = ast.PyCF_ONLY_AST
    
    source = "class Foo(metaclass=ExampleClass): pass"
    tree = ast.parse(source, mode='exec', parser=parser)
    tree2 = MetaclassTransformer().visit(tree)


# Generated at 2022-06-23 22:42:43.403445
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    # type: () -> None
    from ..utils.base import BaseNodeTransformerTest

    original_source = """
        import six
        class A(metaclass=type):
            pass
        class B(B2, metaclass=type):
            pass
        class C(metaclass=type):
            pass
    """

    desired_source = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(type)):
            pass
        class B(_py_backwards_six_withmetaclass(type), B2):
            pass
        class C(_py_backwards_six_withmetaclass(type)):
            pass
    """


# Generated at 2022-06-23 22:42:49.977011
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Function setup
    node = get_ast("""
        class A(metaclass=B):
            pass
    """)
    # Function body
    obj = MetaclassTransformer()
    node = obj.visit_Module(node)
    assert len(node.body) == 1
    assert isinstance(node.body[0], ast.Expr)
    assert isinstance(node.body[0].value, ast.Call)
    assert isinstance(node.body[0].value.func, ast.Attribute)
    assert node.body[0].value.func.attr == 'get_body'
    assert isinstance(node.body[1], ast.ClassDef)


# Generated at 2022-06-23 22:42:55.979566
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast
    import six
    import typed_ast.ast3

    class FakeSix(six.moves.six):
        def with_metaclass(self, cls, *bases):
            return type.__new__(cls, 'A', bases, dict())

    six.moves.six = FakeSix()

    A = MetaclassTransformer('2.7').transform(typed_ast.ast3.parse('class A(metaclass=type): pass'))
    A = ast.fix_missing_locations(A)

    @six.add_metaclass(type)
    class B:
        pass

    assert list(A.body)[0].body == B.__dict__['__dict__']

# Generated at 2022-06-23 22:43:05.771095
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    def test(tree):
        t = MetaclassTransformer()
        new_tree = t.visit(tree)
        assert ast.dump(new_tree) == expected
    
    # simple
    tree = ast.parse('class A(metaclass=B):\n    pass')
    expected = ast.dump(
        ast.parse('from six import with_metaclass\nclass A(with_metaclass(B)):\n    pass')
    )
    test(tree)

    # bases
    tree = ast.parse('class A(C, D, metaclass=B):\n    pass')
    expected = ast.dump(
        ast.parse('from six import with_metaclass\nclass A(with_metaclass(B, C, D)):\n    pass')
    )


# Generated at 2022-06-23 22:43:12.033328
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    transformed = MetaclassTransformer().visit(
        test_utils.build_visitor_ast('class A(metaclass=B):\n pass')
    )

    test_utils.assert_source_equal(transformed,
                                   '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
    class A(_py_backwards_six_withmetaclass(B), *[]):
        pass
    ''')


# Generated at 2022-06-23 22:43:19.179130
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    transformer = MetaclassTransformer()

    expected_tree = ast.Module(body=[six_import.get_body(),
                                     ast.ClassDef(name='A',
                                                  bases=[class_bases.get_body(metaclass=ast.Name(id='B'),  # type: ignore
                                                                               bases=ast.List(elts=[]))],
                                                  body=[],
                                                  decorator_list=[],
                                                  keywords=[])])
    tree = ast.Module(body=[ast.ClassDef(name='A',
                                         bases=[],
                                         body=[],
                                         decorator_list=[],
                                         keywords=[ast.keyword(arg='metaclass', value=ast.Name(id='B'))])])

    actual_tree = transformer.visit(tree)



# Generated at 2022-06-23 22:43:23.455037
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    scope = {}
    exec(six_import.get_code(), scope)
    assert scope['_py_backwards_six_withmetaclass'] is six.with_metaclass

    scope = {}
    exec(class_bases.get_code(), scope)
    assert scope['_py_backwards_six_withmetaclass'] is six.with_metaclass

# Generated at 2022-06-23 22:43:28.635054
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    snippet = \
        """
        class A(metaclass=X):
            pass
        """
    expected = \
        """
        from six import with_metaclass as _py_backwards_six_with_metaclass
        
        class A(_py_backwards_six_with_metaclass(X)):
            pass
        """
    tree = ast.parse(snippet)
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert astor.to_source(tree) == expected



# Generated at 2022-06-23 22:43:35.583799
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import get_test_nodes
    nodes = get_test_nodes('class A(metaclass=B):\n pass')
    assert MetaclassTransformer().visit(nodes[0]) == ast.parse('\n'.join(six_import.get_body()+class_bases.get_body(metaclass=nodes[0].body[0].keywords[0].value, bases=ast.List(elts=nodes[0].body[0].bases))))

# Generated at 2022-06-23 22:43:42.572846
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module
    from ..utils.compiler import compile_func
    from ..utils.example import example_python_source

    source = example_python_source(
        """
        class A(metaclass=B):
            pass
        """)

    tree = ast.parse(source)
    new_tree = MetaclassTransformer().visit(tree)  # type: Module
    code = compile_func(new_tree)

    assert '_py_backwards_six_withmetaclass' in code

# Generated at 2022-06-23 22:43:51.576315
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """
    Test visit_Module method.
    """
    import astor

    module = ast.parse(
        '''
        class A(metaclass=B):
            pass
        '''
    )

    module = MetaclassTransformer().visit(module)
    module_str = astor.to_source(module)

    assert module_str == "from six import with_metaclass as _py_backwards_six_withmetaclass\n\nclass A(_py_backwards_six_withmetaclass(B, )):\n    pass"

# Generated at 2022-06-23 22:43:58.682872
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import (ast3 as ast, parse)
    from ..utils.ast_compare import compare_asts

    class_def = parse('class Foo: pass').body[0]
    expected = parse('class Foo(_py_backwards_six_withmetaclass(ABCMeta)): pass')
    MetaclassTransformer.apply(class_def)
    assert compare_asts(class_def, expected)



# Generated at 2022-06-23 22:44:01.633798
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astunparse
    from .six_import import SixImportTransformer
    from .remove_kwargs import RemoveKwargsTransformer
    from .from_import import FromImportTransformer

# Generated at 2022-06-23 22:44:10.994851
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.testutil import assert_equal

    expected = source("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    
    
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    expected = expected.get_ast()
    actual = ast.parse("""
    class A(metaclass=B):
        pass
    """)
    actual = MetaclassTransformer().visit(actual)
    assert_equal(expected, actual)

# Generated at 2022-06-23 22:44:13.900540
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """Python 2.6 doesn't have metaclass
    """
    assert MetaclassTransformer(None).target == (2, 7)

# Generated at 2022-06-23 22:44:16.909414
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(ast.parse("class A(metaclass=B): pass"))
    assert metaclass_transformer._tree_changed

# Generated at 2022-06-23 22:44:22.804965
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    tt = MetaclassTransformer

    tree = ast.parse('')
    tt.visit(tree)
    assert ast.dump(tree) == 'Module(\n    ImportFrom(module=\'six\', names=[alias(\n        name=\'with_metaclass\',\n        asname=\'_py_backwards_six_withmetaclass\',\n    )], level=0))'



# Generated at 2022-06-23 22:44:33.300295
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ast import Module, Name, Load, ClassDef, Pass, Str, keyword

    # Given
    node = Module(body=[
        ClassDef(name='A', bases=[
            Name(id='object', ctx=Load())],
                 keywords=[keyword(arg='metaclass', value=Name(id='B', ctx=Load()))],
                 decorator_list=[],
                 body=[Pass()])])

    # When
    mt = MetaclassTransformer()
    mt.visit(node)

    # Then
    assert mt._tree_changed == True

# Generated at 2022-06-23 22:44:36.348253
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from ..utils.transformer import print_node
    from ..utils.testing import run_local_tests


# Generated at 2022-06-23 22:44:42.840237
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import py_backwards.transformers

    py_backwards.transformers.six_import = six_import
    transformer = MetaclassTransformer()
    module = ast.parse("class A(metaclass=B): pass")
    assert transformer.visit(module) == ast.parse("from six import withmetaclass as _py_backwards_six_withmetaclass;class A(_py_backwards_six_withmetaclass(B)): pass")



# Generated at 2022-06-23 22:44:48.663583
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    expected_source = 'from six import with_metaclass as py_backwards_six_withmetaclass\n\n\nclass A(py_backwards_six_withmetaclass(b, c)):\n    pass'
    expected_tree = ast.parse(expected_source)
    result_tree = MetaclassTransformer.run_pipeline(ast.parse('class A(metaclass=b, c): pass',
                                                              filename='<test>'))
    assert ast.dump(expected_tree) == ast.dump(result_tree)

# Generated at 2022-06-23 22:44:54.843471
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    input = '''
    class A(metaclass=B):
        pass
    '''
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''

    node = ast.parse(input)
    MetaclassTransformer().visit(node)
    assert ast.dump(node) == expected


# Generated at 2022-06-23 22:45:02.922393
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astunparse

    code = '''
    class A(metaclass=B):
        pass
    '''
    node = ast.parse(code)
    result = MetaclassTransformer().visit(node)
    expected = '''
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class A(_py_backwards_six_withmetaclass(B)):
        pass
    '''
    assert astunparse.unparse(result).strip() == expected.strip()


# Generated at 2022-06-23 22:45:10.859140
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import textwrap
    from typed_ast.ast3 import parse
    source = textwrap.dedent("""
    class Foo(metaclass=type):
        pass
    """)

    expected = textwrap.dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class Foo(_py_backwards_six_withmetaclass(type, )):
        pass
    """)

    tree = parse(source)
    tree = MetaclassTransformer().visit(tree)
    assert expected == compile(tree, "<ast>", "exec").co_consts[1]

# Generated at 2022-06-23 22:45:17.734013
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils import transforms_code

    transforms_code(
        from_version=(2, 7),
        to_version=(3, 7),
        code='''
        class A(metaclass=B, **kwargs):
            pass
        ''',
        expected_code='''
        from six import with_metaclass as _py_backwards_six_withmetaclass


        class A(_py_backwards_six_withmetaclass(B, *[], **{}), **kwargs):
            pass
        '''
    )

# Generated at 2022-06-23 22:45:25.596925
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    x = ast.parse("""
    class A(metaclass=B):
        def __new__(cls, *args, **kwargs):
            pass
    """)
    mt = MetaclassTransformer()
    mt.visit(x)
    assert mt.get_code() == """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        def __new__(cls, *args, **kwargs):
            pass
    """

# Generated at 2022-06-23 22:45:26.242483
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:45:34.250236
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:45:38.731716
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .. import tree
    from ..tree import print_tree

    code = '''class A(B, metaclass=C):
               pass
           '''

    tree = tree.build(code, 'exec')
    MetaclassTransformer().visit(tree)
    print_tree(tree)

# Generated at 2022-06-23 22:45:40.380536
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    print ("Testing constructor for class MetaclassTransformer")
    mct = MetaclassTransformer()
    assert(mct is not None)
    print ("Passed")



# Generated at 2022-06-23 22:45:41.232404
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:45:46.168844
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    source = textwrap.dedent("")
    expected = textwrap.dedent("from six import with_metaclass as _py_backwards_six_withmetaclass")

    tree = ast.parse(source)
    transformer = MetaclassTransformer()
    transformer.visit(tree)

    assert_source_equal(str(tree), expected)



# Generated at 2022-06-23 22:45:47.137925
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():

    assert MetaclassTransformer is not None

# Generated at 2022-06-23 22:45:54.636773
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    module = ast.parse('''
    class A(metaclass=B):
        pass 
    ''')
    metaclass_transformer = MetaclassTransformer()
    metaclass_transformer.visit(module)
    code = compile(module, '<test>', 'exec')
    namespace = {}
    exec(code, namespace)
    assert '_py_backwards_six_withmetaclass' in namespace
    assert 'A' in namespace
    assert issubclass(namespace['A'], namespace['_py_backwards_six_withmetaclass'])


# Generated at 2022-06-23 22:45:56.502325
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..transformers.basics import AssignmentsToAttributesTransformer

# Generated at 2022-06-23 22:46:06.271627
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import typed_ast.ast3
    from ..testing import NodeTestCase

    class TestCase(NodeTestCase):
        transform = MetaclassTransformer
        target = (2, 7)
        dependencies = ['six']

        def make_node(self, **kwargs):
            return typed_ast.ast3.fix_missing_locations(typed_ast.ast3.ClassDef(**kwargs))

        def test_no_metaclass(self):
            n = self.transform().transform(
                self.make_node(name='A',
                               bases=[],
                               keywords=[],
                               body=[typed_ast.ast3.Pass(lineno=1, col_offset=0, end_lineno=1, end_col_offset=4)],
                               decorator_list=[]))
            self

# Generated at 2022-06-23 22:46:09.104660
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:46:18.573994
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = """
            class TestWithMetaclass(type):
                pass

            class TestClass(metaclass=TestWithMetaclass):
                pass

            class TestClass2(TestClass):
                pass
            """
    expected = """
            from six import with_metaclass as _py_backwards_six_withmetaclass

            class TestWithMetaclass(type):
                pass

            class TestClass(_py_backwards_six_withmetaclass(TestWithMetaclass)):
                pass

            class TestClass2(TestClass):
                pass
            """
    tree = ast.parse(code)
    tree2 = MetaclassTransformer().visit(tree)
    assert ast.dump(tree2) == ast.dump(ast.parse(expected))

# Generated at 2022-06-23 22:46:29.186810
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .vendor.six import PY3
    from ..utils.tree import tree_to_str
    from ..utils import parse

    code = """
    class A(B, metaclass=C):
        pass
    """
    six_import = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    """
    with_metaclass = """
    _py_backwards_six_withmetaclass(C, *[B])
    """
    code_to_compare = """
    class A(_py_backwards_six_withmetaclass(C, *[B])):
        pass
    """
    node = parse(code)

# Generated at 2022-06-23 22:46:37.589096
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    ast_tree = ast.parse('''
        from six import with_metaclass as _with_metaclass

        class Magic(type):
            pass
        class A(metaclass=Magic):
            pass
        class B(metaclass=Magic, object):
            pass
        class C(metaclass=Magic, object, str):
            pass
        class D(object, metaclass=Magic):
            pass
        class F(str, metaclass=Magic, object):
            pass
    ''')

    visitor = MetaclassTransformer()
    visitor.visit(ast_tree)
    assert visitor.tree_changed is True

    loc = locals()

    class Magic(type):
        pass

    assert isinstance(loc['A'], Magic)
    assert isinstance(loc['B'], Magic)


# Generated at 2022-06-23 22:46:45.456013
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast.parse(
        "class A(metaclass=B):\n"
        "    pass")
    transformer = MetaclassTransformer()
    transformer.visit(tree)
    assert transformer.get_new_code() == (
        "from six import with_metaclass as _py_backwards_six_withmetaclass\n"
        "\n"
        "class A(_py_backwards_six_withmetaclass(B)):\n"
        "    pass\n"
    )

# Generated at 2022-06-23 22:46:50.738911
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """Test snippets of MetaclassTransformer.visit_Module.

    Mock dependencies and test whether bodies of all snippet methods included
    in visit_Module are valid Python code and whether calling the snippet
    methods actually appends the bodies to the given node.
    """
    from ..utils.testing import ensure_ast

# Generated at 2022-06-23 22:46:53.446211
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse("""class A(metaclass=B):\n pass""")
    MetaclassTransformer().visit(node)
    print(astunparse.dump(node))

# Generated at 2022-06-23 22:46:56.424473
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    m = ast.parse('class A(metaclass=ABCMeta, object):\n    pass')
    t = MetaclassTransformer()
    m = t.visit(m)
    assert t.tree_changed is True
    assert ast.dump(m) == '<Module>\nclass A(with_metaclass(ABCMeta, object)):\n    pass'

# Generated at 2022-06-23 22:47:01.506633
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast.parse("""class A(metaclass=B):pass""")
    MetaclassTransformer().visit(tree)
    assert ast.dump(tree) == inspect.cleandoc("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)

# Generated at 2022-06-23 22:47:04.229981
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import get_test_name, generate_test
    from .ast_utils import parse


# Generated at 2022-06-23 22:47:05.105769
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:47:15.718548
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ._test_base import BaseTestMetaclass

    # From Python source code
    expected = """class B(_py_backwards_six_withmetaclass(A, type)):
    pass
"""

    metaclass = ast.Name(id='A', ctx=ast.Load())
    bases = [ast.Name(id='type', ctx=ast.Load())]
    node = ast.ClassDef(name='B',
                        bases=bases,
                        keywords=[ast.keyword(arg='metaclass',
                                              value=metaclass)],
                        body=[])
    assert not hasattr(node, '_backwards_fields')

    result = MetaclassTransformer().visit(node)
    assert not hasattr(result, '_backwards_fields')
    assert BaseTestMetaclass.comp

# Generated at 2022-06-23 22:47:18.727995
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    m1 = ast.parse('''class A(): pass''')
    m2 = MetaclassTransformer().visit(m1)

# Generated at 2022-06-23 22:47:27.460816
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    top = ast.parse('class Foo(metaclass=Bar): pass',
                    mode='exec')
    assert top.body[0] == ast.ClassDef(name='Foo',
                                       bases=[ast.Name(id='Bar', ctx=ast.Load())],
                                       keywords=[ast.keyword(arg='metaclass',
                                                             value=ast.Name(id='Bar',
                                                                            ctx=ast.Load()))],
                                       body=[],
                                       decorator_list=[])
    MetaclassTransformer.run_node(top)

# Generated at 2022-06-23 22:47:32.467119
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    node = ast.parse("""
    class A(metaclass=B):
       def foo(self):
           pass
    """)
    expected = ast.parse("""
    class A(_py_backwards_six_with_metaclass(B))
        def foo(self):
            pass
    """)
    trans = MetaclassTransformer()
    trans.visit(node)

    assert(trans._tree_changed)
    assert(ast.dump(node) == ast.dump(expected))

# Generated at 2022-06-23 22:47:35.148305
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # "import six" is inserted at the top of the module

    code = '''class A: pass'''