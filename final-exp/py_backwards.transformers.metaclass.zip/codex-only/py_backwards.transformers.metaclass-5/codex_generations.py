

# Generated at 2022-06-23 22:37:41.146861
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
        mod = ast.parse(textwrap.dedent(r'''
            class A(metaclass=B):
                pass
        '''))
        exp = ast.parse(textwrap.dedent(r'''
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A(_py_backwards_six_withmetaclass(B)):
                pass
        '''))

        MetaclassTransformer(mod).run()
        assert ast.dump(mod) == ast.dump(exp)


# Generated at 2022-06-23 22:37:45.340350
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.test_utils import transforms

    transforms(MetaclassTransformer,
               'class A(B):\n pass',
               'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)):\n pass\n')

# Generated at 2022-06-23 22:37:52.669113
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer(None, {'__future__'}).target == (2, 7)
    assert MetaclassTransformer(None, {'__future__', 'six'}).dependencies == ['six']
    assert MetaclassTransformer(None, {'__future__', 'six'}).visit_Module(ast.parse('pass')) == ast.parse('import six; pass')

# Generated at 2022-06-23 22:38:00.534397
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .util import source_to_ast

    source = """
    import six
    class A(metaclass=six.with_metaclass):
        pass
    """
    expected = """
    import six
    class A(six.with_metaclass(metaclass, *bases)):
        pass
    """
    tree = source_to_ast.parse(source)
    tr = MetaclassTransformer()
    actual = tr.visit(tree)
    assert source_to_ast.to_source(actual) == expected

# Generated at 2022-06-23 22:38:05.207730
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    transformer = MetaclassTransformer()
    node = ast.parse('class A(metaclass=B): pass')
    node = transformer.visit(node)
    assert ast.dump(node) == six_import.get_ast().dump() + '\nclass A(metaclass=B): pass\n'


# Generated at 2022-06-23 22:38:07.035512
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ... import Tree

    str_ = """
    class A():
        c = 5
    """
    tree = Tree(str_)
    tree.assert_valid()

# Generated at 2022-06-23 22:38:11.174069
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..unit_test import assert_compilation

    assert_compilation(
        MetaclassTransformer,
        """
        class A(metaclass=B):
            pass
        """
    )
    assert_compilation(
        MetaclassTransformer,
        """
        class A(B, metaclass=C):
            pass
        """
    )
    assert_compilation(
        MetaclassTransformer,
        """
        class A(metaclass=C, B):
            pass
        """
    )

# Generated at 2022-06-23 22:38:14.557369
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    old_code = """class A(metaclass=B):
    pass
"""

# Generated at 2022-06-23 22:38:21.991626
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast.ast3 import ClassDef, parse
    from ..codegen import to_source
    from .test_base import BaseNodeTransformerTest
    from ..utils.compat import OrderedDict
    import six

    class MockModule(BaseNodeTransformerTest):
        target = (2, 7)
        dependencies = ['six']

        def test_class_def(self):
            metaclass_stmt = 'class A(metaclass=B):\n    pass'

# Generated at 2022-06-23 22:38:23.550743
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast

# Generated at 2022-06-23 22:38:28.497749
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    nodes = [
        ast.Expr(value=ast.Str(s='foo')),
        ast.ClassDef(name='A', bases=[], body=[],
                     keywords=[ast.keyword(arg='metaclass',
                                           value=ast.Name(id='B', ctx=ast.Load()))],
                     decorator_list=[])
    ]
    actual = MetaclassTransformer().visit(ast.Module(body=nodes))
    assert ast.dump(actual) == ast.dump(ast.Module(body=[six_import.get_body()] + nodes))



# Generated at 2022-06-23 22:38:34.970072
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    import sys; sys.path.insert(0, '/home/fgeigl/Dropbox/Bachelorthesis/code/automation/pybackwards/tests')
    import test_fixtures.py2.metaclass_transformer as test_module
    node = ast.parse(test_module.code)
    t = MetaclassTransformer()
    result = t.visit(node)
    assert astor.to_source(result) == test_module.expected

# Generated at 2022-06-23 22:38:43.876385
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast

    from .base import BaseTestTransformer

    class Test(BaseTestTransformer):
        target = (2, 7)

        def test_class_def(self):
            before = ast.parse("""
                class A(B, metaclass=C):
                    pass
            """)
            after = ast.parse("""
                class A(_py_backwards_six_withmetaclass(C), B):
                    pass
            """)
            self.compare(before, after)

        def test_class_def_no_exp(self):
            before = ast.parse("""
                class A(B):
                    pass
            """)
            after = ast.parse("""
                class A(B):
                    pass
            """)
            self.compare(before, after)

# Generated at 2022-06-23 22:38:48.447446
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typing import List
    
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as typed_ast
    from ..utils.tree import ast_to_string, ast_to_typed_ast, typed_ast_to_ast
    from ..fixers.six import MetaclassTransformer



# Generated at 2022-06-23 22:38:59.532740
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    from ..utils.ast_helpers import CodeBlock
    from ..utils.ast_helpers import parse_snippet

    snippet_content = """
        class A(metaclass=B):
            pass
        """

    expected_content = """
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
        """

    # No tree changes when no class is defined
    test_snippet = parse_snippet(snippet_content)
    tree_changed, node = MetaclassTransformer().visit_and_transform(test_snippet)
    assert not tree_changed

# Generated at 2022-06-23 22:39:07.083363
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.source import source

    # Given
    code = """
        class A(metaclass=B):
            pass

        class C(metaclass=D):
            pass
    """
    node = ast.parse(code)  # type: ast.Module

    # When
    transformer = MetaclassTransformer()
    transformer.visit(node)

    # Then

# Generated at 2022-06-23 22:39:08.275611
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:39:15.489274
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import ast_to_source as ats
    from ..utils.compare import expect_same_ast

    src = six_import.dedent() + """
    class A(metaclass=B):
        pass
    """
    expect = """
    class A(_py_backwards_six_withmetaclass(B))
    """
    ast1 = sta(src)
    transformer = MetaclassTransformer()
    ast2 = transformer.visit(ast1)
    ast3 = sta(expect)
    assert transformer._tree_changed
    expect_same_ast(ast2, ast3)
    assert ats(ast2) == ats(ast3)

# Generated at 2022-06-23 22:39:21.662244
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import os
    location = os.path.realpath(
        os.path.join(os.getcwd(), os.path.dirname(__file__)))
    with open(os.path.join(location, "test_MetaclassTransformer.py")) as f:
        tree = ast3.parse(f.read())
    mt = MetaclassTransformer()
    mt.visit(tree)
    assert mt._tree_changed
    generated_code = ast3.get_source(tree)
    with open(os.path.join(location, "test_MetaclassTransformer.out")) as f:
        expected_code = f.read()
    assert generated_code == expected_code

# Generated at 2022-06-23 22:39:22.726990
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import sys
    import ast
    sys.argv += ['test.py']

# Generated at 2022-06-23 22:39:23.721007
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import six
    import sys
    import astor
    transformer = MetaclassTransformer()

# Generated at 2022-06-23 22:39:28.903280
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.test_utils import transform_and_compile
    from textwrap import dedent

    code = dedent("""
        class A(metaclass=B):
            pass
        """)
    assert transform_and_compile(code, MetaclassTransformer).body[0].bases[0].func.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-23 22:39:30.126053
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:39:39.718275
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    m = ast.parse('class C(object, metaclass=type): pass')
    c = m.body[0]
    v = MetaclassTransformer()
    r = v.visit(m)
    assert r == m

    if not isinstance(r, ast.Module):
        raise AssertionError()

    if len(r.body) != 2:
        raise AssertionError()

    if not isinstance(r.body[0], ast.Expr):
        raise AssertionError()

    if not isinstance(r.body[0].value, ast.Lambda):
        raise AssertionError()

    if len(r.body[0].value.body.args.args) != 4:
        raise AssertionError()


# Generated at 2022-06-23 22:39:48.312165
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ...tests.fixtures import make_test_module

    source = make_test_module("""
        class A(metaclass=B):
            pass

        class C(metaclass=D, base=A):
            pass
        """)

    expected = make_test_module("""
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B)):
            pass

        class C(_py_backwards_six_withmetaclass(D), base=A):
            pass
        """)

    mod = MetaclassTransformer().visit(source)

    assert mod == expected

# Generated at 2022-06-23 22:39:55.951418
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    # Compiles:
    # if __name__ == "__main__":
    #    class A(metaclass=B):
    #        pass
    # to:
    # if __name__ == "__main__":
    #    from six import with_metaclass as _py_backwards_six_withmetaclass
    #    class A(_py_backwards_six_with_metaclass(B, object)):
    #        pass
    node = ast.parse(
        textwrap.dedent(
            """\
            if __name__ == "__main__":
                class A(metaclass=B):
                    pass
            """
        )
    )


# Generated at 2022-06-23 22:39:56.962867
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    # Case: ClassDef with keyword arguments
    # The original code:

# Generated at 2022-06-23 22:39:57.663767
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:40:02.872761
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import test_utils
    test_code = """
    class A(metaclass=B): pass
    """
    expected_code = """
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)): pass
    """
    expected_tree = test_utils.build_module(expected_code)
    actual_tree = test_utils.build_module(test_code)
    node_transformer = MetaclassTransformer()
    actual_tree = node_transformer.visit(actual_tree)  
    assert test_utils.compare_trees(expected_tree, actual_tree) is True, 'Test Failed'

# Generated at 2022-06-23 22:40:04.253612
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:40:14.406421
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class A(object):
        pass

    class B(object, metaclass=A):
        pass

    code = ast.parse(dedent(inspect.getsource(B)))
    assert isinstance(code, ast.Module)
    assert len(code.body) == 1
    assert isinstance(code.body[0], ast.ClassDef)

    fixer = MetaclassTransformer()
    fixed = fixer.visit(code)

    assert isinstance(fixed, ast.Module)
    assert len(fixed.body) == 2
    assert isinstance(fixed.body[0], ast.ImportFrom)
    assert isinstance(fixed.body[1], ast.ClassDef)
    assert isinstance(fixed.body[1].keywords[0], ast.Arg)

# Generated at 2022-06-23 22:40:17.008021
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class TestMeta(metaclass=MetaclassTransformer):
        pass

    assert TestMeta.__class__
    assert TestMeta.__class__.__name__ == 'MetaclassTransformer'
    print('Passed MetaclassTransformer.__init__ test')

# Generated at 2022-06-23 22:40:19.842659
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """Test that MetaclassTransformer().visit_ClassDef
    transforms valid source code into valid source code."""
    # Setup
    transformer = MetaclassTransformer()

# Generated at 2022-06-23 22:40:23.215096
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    class A(object):
        pass
    node = ast.parse('class A(object, metaclass=B): pass')
    node = MetaclassTransformer().visit(node)
    assert str(node) == "class A(_py_backwards_six_withmetaclass(B)):\n    pass"

# Generated at 2022-06-23 22:40:24.549089
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    """No unit test currently defined."""
    assert False, "No unit test defined."

# Generated at 2022-06-23 22:40:29.992886
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    assert MetaclassTransformer().visit(ast.parse("""
    class A(metaclass=B):
        pass
    """)) == ast.parse("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)



# Generated at 2022-06-23 22:40:38.105785
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .test_utils import SourceWrap
    from .. import checker
    from .. import fixer

    source = '''
    class Spam(metaclass=SpamMeta):
        pass
    '''
    tree = checker.parse_module(source)
    fixer.fix_module(tree)
    tree = MetaclassTransformer.run(tree)
    assert tree == SourceWrap('''
    from six import with_metaclass
    class Spam(with_metaclass(SpamMeta)):
        pass
    ''')

# Generated at 2022-06-23 22:40:49.103966
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    assert MetaclassTransformer().visit(ast.parse("""
        class A:
            pass
    """)) == ast.parse("""
        class A:
            pass
    """)

    assert MetaclassTransformer().visit(ast.parse("""
        class A(metaclass=B):
            pass
    """)) == ast.parse("""
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)


# Generated at 2022-06-23 22:40:54.806447
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    xlator = MetaclassTransformer()
    xlator._tree_changed = False

    # We need to supply the metaclass when testing.
    test_source = "class A(metaclass=abc.ABCMeta):\n    @abc.abstractmethod\n    def foo(self):\n        pass"
    test_tree = ast.parse(test_source)
    xlator.visit(test_tree)
    # print("Dump", ast.dump(test_tree))
    assert xlator._tree_changed

# Generated at 2022-06-23 22:40:55.619368
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-23 22:40:57.609411
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..nodes import ast_module

    # type: () -> Module

# Generated at 2022-06-23 22:41:02.805549
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast
    import textwrap
    node = ast.parse(textwrap.dedent('''\
        class A(): pass
        class B(metaclass=C): pass
        class D(metaclass=C, bases=B): pass
    '''))
    orig_code = compile(node, '', 'exec')
    trans = MetaclassTransformer()
    newnode = trans.visit(node)
    newcode = compile(newnode, '', 'exec')
    assert orig_code.co_consts[0] == 'A'
    assert orig_code.co_consts[1] == 'B'
    assert orig_code.co_consts[2] == 'metaclass'
    assert orig_code.co_consts[3] == 'C'
    assert orig_code.co_

# Generated at 2022-06-23 22:41:03.560631
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:41:05.152713
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    mt = MetaclassTransformer()

# Generated at 2022-06-23 22:41:08.441127
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils import test_name
    from ..utils.ast_builder import ast_from_snippet

    # Test correct transformation

# Generated at 2022-06-23 22:41:14.577573
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    node = ast.parse('class a(metaclass=m): pass')
    TransformerClass = MetaclassTransformer()
    new_node = TransformerClass.visit(node)
    expected_node = ast.parse('class a(_py_backwards_six_withmetaclass(m)): pass')
    assert ast.dump(new_node) == ast.dump(expected_node)


# Unit test with multiple metaclasses

# Generated at 2022-06-23 22:41:22.155063
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..codecompat import Visitor
    from typed_ast import ast3 as ast
    from .test_utils import (
        assert_node,
        assert_lines,
        get_name,
    )

    source = """\
        class Foo(metaclass=Bar):
            pass
        """
    expected = """\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class Foo(_py_backwards_six_withmetaclass(Bar)):
            pass
        """

    module = Visitor().visit(ast.parse(source))
    MetaclassTransformer().visit(module)

    assert_lines(expected, module)

# Generated at 2022-06-23 22:41:23.763436
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:41:27.551952
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    """MetaclassTransformer should correctly transform class"""
    import typed_astunparse
    code = """class A(metaclass=B): pass"""

# Generated at 2022-06-23 22:41:37.221827
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import subprocess
    import sys
    import os
    code = 'class A(metaclass=B): pass'
    expected = 'class A(_py_backwards_six_with_metaclass(B)): pass'
    proc = subprocess.Popen(
        [os.path.join(os.path.dirname(sys.executable), 'python'), '-m', 'compileall', '-q', '-f', '/dev/null'],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        universal_newlines=True,
    )
    out, err = proc.communicate(code)
    assert 'SyntaxError' not in err
    assert out.endswith(expected)

# Unit

# Generated at 2022-06-23 22:41:45.760054
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class TestMetaclassTransformer_visit_ClassDef_Class(unittest.TestCase):
        transformer = MetaclassTransformer
        module = ast.parse('''
        class MyMetaclass(type):
            pass

        class MyClass(metaclass=MyMetaclass):
            pass''')
        expected_processed = ast.parse('''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class MyMetaclass(type):
            pass

        class MyClass(_py_backwards_six_withmetaclass(MyMetaclass)):
            pass''')

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestMetaclassTransformer_visit_ClassDef_Class))
    return

# Generated at 2022-06-23 22:41:53.681283
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = "class A(metaclass=B, x, y): pass"
    module = ast.parse(code)
    transformer = MetaclassTransformer()
    assert transformer.tree_changed is False
    result, _ = transformer.visit_and_return_diff(module)
    assert transformer.tree_changed is True
    compare_source(result, """
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class A(_py_backwards_six_withmetaclass(B, *[x, y])):
            pass
        """)



# Generated at 2022-06-23 22:41:56.895857
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import sys
    import six
    sys.version_info = (3, 0)
    @six.add_metaclass(MetaclassTransformer)
    class A(metaclass=object):
        pass
    assert A.__bases__ == (object,)

# Generated at 2022-06-23 22:42:04.035422
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ... import parse
    from ... import transform
    from ... import serialize

    n = parse('class A(object): pass')
    s = serialize(n)
    n2 = transform(MetaclassTransformer, n)
    s2 = serialize(n2)
    nose.tools.assert_equal(s, s2)

    # class A(B, metaclass=C): pass
    n = parse('class A(object, metaclass=B): pass')
    s = serialize(n)
    n2 = transform(MetaclassTransformer, n)
    s2 = serialize(n2)
    nose.tools.assert_not_equal(s, s2)

    # class A(B, metaclass=C, D=E): pass

# Generated at 2022-06-23 22:42:13.536049
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    nodes = '''
        class Foo(metaclass=Bar):
            pass
        '''
    expected_str = '''
        from six import with_metaclass as _py_backwards_six_withmetaclass

        class Foo(_py_backwards_six_withmetaclass(Bar, object)):
            pass
        '''
    expected_ast = ast.parse(expected_str)

    transformer = MetaclassTransformer()
    actual_ast = transformer.visit(ast.parse(nodes))

    assert transformer.tree_changed
    assert ast.dump(actual_ast, include_attributes=True) == ast.dump(expected_ast, include_attributes=True)

# Generated at 2022-06-23 22:42:14.580971
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:42:15.188356
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:42:24.489057
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ast import Module, Name, Attribute, Num, List, Expr, ClassDef
    from .base import BaseNodeTransformer
    
    six_import_lines = six_import.get_lines()

    class Dummy(BaseNodeTransformer):
        def __init__(self):
            self._tree_changed = False
            self.generic_visit = lambda x: x

    dummy = Dummy()

    module = Module(body=[
        Name(id='a', ctx=Load()),
        Num(n=1),
        ClassDef(name='A',
                 bases=[],
                 keywords=[],
                 body=[Expr(value=Name(id='b', ctx=Load()))])
    ])
    dummy.visit_Module(module)

# Generated at 2022-06-23 22:42:31.859413
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    metaclass = ast.Name(id='a', ctx=ast.Load())
    bases = ast.List(elts=[ast.Name(id='b', ctx=ast.Load())])
    new_bases = class_bases.get_body(metaclass=metaclass, bases=bases)
    from ...utils.tree import new_tree, print_tree
    print_tree(new_bases)
    print_tree(new_tree(MetaclassTransformer, 'class C(metaclass=a): pass'))

# Generated at 2022-06-23 22:42:33.307407
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .test_utils import make_test


# Generated at 2022-06-23 22:42:40.334638
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    node = ast.parse('''class A: pass''')
    m = MetaclassTransformer()
    result = m.visit_Module(node)
    expected = ast.Module(body=[
        six_import.get_body()[0],
        ast.ClassDef(name='A',
                     bases=[],
                     keywords=[],
                     body=[],
                     decorator_list=[])])
    assert ast.dump(result) == ast.dump(expected)



# Generated at 2022-06-23 22:42:45.383540
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.testing import transform
    source = """
            class A(metaclass=type):
                pass
            """
    expected = """
            from six import with_metaclass as _py_backwards_six_withmetaclass
            class A(_py_backwards_six_withmetaclass(type)):
                pass
            """
    with transform(source, MetaclassTransformer) as result:
        assert expected == result

# Generated at 2022-06-23 22:42:48.025660
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..utils.test_visitor import generate_visit_test
    return generate_visit_test(MetaclassTransformer)

__all__ = ['MetaclassTransformer']

# Generated at 2022-06-23 22:42:53.812880
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    ast_tree = ast.parse("""
    class A(object, metaclass=type):
        pass
    """)
    transformer = MetaclassTransformer()
    transformer.visit(ast_tree)
    exec(compile(ast_tree, '', 'exec'))
    assert A.__class__ is type


# Generated at 2022-06-23 22:43:00.720608
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from ..utils.testing import assert_parses_to, assert_transforms_to
    example = """
    class A(metaclass=B):
        pass
    """
    expected = """
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B, object)):
        pass
    """
    assert_parses_to(example, "ast")
    assert_transforms_to(example, expected, MetaclassTransformer, "ast")

# Generated at 2022-06-23 22:43:10.579837
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from py_backwards.transformers.six import WithMetaclassTransformer
    from py_backwards.transformers.builtins import OperatorTransformer

    class Transformer(
        WithMetaclassTransformer,
        OperatorTransformer,
    ):
        pass

    transformer = Transformer()
    result = transformer.visit_and_update('''
    class A(metaclass=B):
        def add(self, other):
            return operator.add(self, other)
    ''')
    assert result == '''
    from six import with_metaclass as _py_backwards_six_withmetaclass


    class A(_py_backwards_six_withmetaclass(B)):
        def add(self, other):
            return self + other
    '''

# Generated at 2022-06-23 22:43:19.827324
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:43:26.374807
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.unparse import Unparser
    from typing import List
    from textwrap import dedent

    source = dedent("""
    class A(metaclass=B):
        pass
    """)
    actual = MetaclassTransformer(2, 7).visit(ast.parse(source))
    assert isinstance(actual, ast.Module)
    assert Unparser(actual.body, indentation='    ').getvalue() == dedent("""
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """).strip()

# Generated at 2022-06-23 22:43:28.187131
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    # metaclass=type

# Generated at 2022-06-23 22:43:33.077637
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    code = \
"""class Test(metaclass=TestMeta):
    pass"""
    parsed_code = ast.parse(code)
    transformed_code = MetaclassTransformer().visit(parsed_code)

# Generated at 2022-06-23 22:43:38.451915
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .registry import TransformerRegistry
    from ..utils import validate_transformer_output

    registry = TransformerRegistry()
    registry.register_transformer(MetaclassTransformer())


# Generated at 2022-06-23 22:43:43.735296
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..language_support import ast_to_source
    from ..utils.tree import build_tree

    # Compiling for py2
    test_input = """class A(object):
        pass"""

    tree = build_tree(test_input, 2)
    MetaclassTransformer().visit(tree)
    output = ast_to_source(tree)


# Generated at 2022-06-23 22:43:49.522085
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    class TestNodeVisitor(ast.NodeVisitor):
        def visit_Name(self, node: ast.Name) -> bool:
            assert node.id == "six"
            return True

    node = ast.parse(six_import)
    MetaclassTransformer().visit(node)
    TestNodeVisitor().visit(node)  # type: ignore



# Generated at 2022-06-23 22:43:54.160535
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """It should work even it if the module contains a class that uses a metaclass
    
    """
    test_snippet = """class A(metaclass=B): pass"""

    expected_result = """"""
    node = ast.parse(test_snippet)
    result = MetaclassTransformer().visit_Module(node)
    assert ast.dump(result) == expected_result


# Generated at 2022-06-23 22:44:01.311026
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from textwrap import dedent
    from ..utils.source import source_to_ast

    module = dedent('''\
    class A(metaclass=B):
        pass
    ''')

    module_node = source_to_ast(module)
    MetaclassTransformer().visit(module_node)

    assert ast.dump(module_node) == 'Module(body=[Import(names=[alias(name=\'six\', asname=None)])])'

# Generated at 2022-06-23 22:44:08.559817
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    tree = ast.parse('class C(object, metaclass=A): pass')
    class_def = tree.body[0]
    assert type(class_def) == ast.ClassDef
    assert len(class_def.keywords) == 1

    MetaclassTransformer().visit(tree)

    assert class_def.bases[0].func.id == '_py_backwards_six_withmetaclass'
    assert class_def.bases[0].args[0].id == 'A'
    assert class_def.bases[0].args[1].id == 'object'
    assert len(class_def.keywords) == 0

    tree = ast.parse('class C(metaclass=A): pass')
    class_def = tree.body[0]
    assert type(class_def)

# Generated at 2022-06-23 22:44:13.409068
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import astunparse

    class Test(ast.NodeVisitor):
        def generic_visit(self, node):
            print(type(node).__name__)
            ast.NodeVisitor.generic_visit(self, node)


# Generated at 2022-06-23 22:44:14.413445
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:44:16.025552
# Unit test for constructor of class MetaclassTransformer

# Generated at 2022-06-23 22:44:16.858053
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    t = MetaclassTransformer()


# Generated at 2022-06-23 22:44:18.644108
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_astunparse import astunparse
    import ast
    # we need to use ast.parse :/

# Generated at 2022-06-23 22:44:23.392929
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from . import Source, Result
    from .. import compile


# Generated at 2022-06-23 22:44:28.354753
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    test_node = ast.parse("""
        class Bar():
            pass
    """, kind=None)

    node_transformer = MetaclassTransformer()
    new_node = node_transformer.visit(test_node)
    assert node_transformer._tree_changed is False
    assert new_node == test_node


# Generated at 2022-06-23 22:44:29.805897
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-23 22:44:39.451558
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from typed_ast import ast3
    from typed_ast import parse
    from typed_ast.visitor import NodeTransformer
    from typed_ast import py27
    from typed_ast import py33

    # Setup 2.7 AST
    test_ast27: ast3.AST = parse("""
    class A(metaclass=B):
        def foo(self):
            return 1

    """)
    # Setup 3.3 AST
    test_ast33: ast3.AST = parse("""
    class A(B):
        def foo(self):
            return 1

    """)
    # Run transformation
    transformer = MetaclassTransformer()
    result = transformer.visit(test_ast27)
    # Compare
    # TODO: This test doesn't take into account the added dependencies

# Generated at 2022-06-23 22:44:46.318434
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from . import make_test_case

    tests = [
        make_test_case('class Foo(Foo2, Foo3, metaclass=Foo4):',
                       'class Foo(_py_backwards_six_withmetaclass(Foo4,Foo2,Foo3)):',
                       'from six import with_metaclass as _py_backwards_six_withmetaclass\n'
                       'class Foo(_py_backwards_six_withmetaclass(Foo4,Foo2,Foo3)):\n'
                       '    pass'),
    ]

    for test in tests:
        yield test

# Generated at 2022-06-23 22:44:56.132060
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    import ast
    # Unit test for constructor of class MetaclassTransformer
    def test_MetaclassTransformer():
        import ast
        from ..utils.treebuild import treebuild
        from ..utils.tree import find_all

        source = '''
        class A(metaclass=B):
            pass
        '''
        tree = treebuild(source, ast.parse)
        mct = MetaclassTransformer()
        mct.visit(tree)

        from_classes = find_all(tree, ast.ImportFrom)
        print(from_classes)
        assert len(from_classes) == 1
        assert from_classes[0].module == 'six'
        assert len(from_classes[0].names) == 1
        assert from_classes[0].names[0].name == 'with_metaclass'

# Generated at 2022-06-23 22:45:00.849862
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    st = 'class A(metaclass=B): pass'
    s = MetaclassTransformer().visit_Module(ast.parse(st))
    assert s.body[0].value.func.value.id == '_py_backwards_six_withmetaclass'

# Generated at 2022-06-23 22:45:02.970965
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import gast as ast
    from py_backwards.transformers import MetaclassTransformer

# Generated at 2022-06-23 22:45:12.743804
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast
    import unittest

    from ..utils.ast_builder import ast_str, ast_call, ast_name, ast_import, ast_import_from

    import_six_snippet, import_six_str = six_import()
    class_bases_snippet, class_bases_str = class_bases()

    class TestFun(unittest.TestCase):
        def test_visit_Module(self):
            with self.subTest(msg='Test snippet'):
                module_str = '''
                    class A(B):
                        pass
                '''
                module = ast_str(module_str, mode='exec')
                transformer = MetaclassTransformer()
                transformed_module = transformer.visit(module)

# Generated at 2022-06-23 22:45:22.195117
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    """Check that visit_Module method of MetaclassTransformer class would
    be able to compile following code:

    class A(metaclass=B):
        pass

    To:
    from six import with_metaclass as _py_backwards_six_withmetaclass
    class A(_py_backwards_six_with_metaclass(B)):
        pass
    """

    node = ast.parse(
        dedent("""\
        class A(metaclass=B):
            pass
        """)
    )
    t = MetaclassTransformer()
    t.visit(node)
    compiled = compile(node, filename='<test>', mode='exec')
    exec(compiled)

# Generated at 2022-06-23 22:45:23.599235
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor

# Generated at 2022-06-23 22:45:25.745348
# Unit test for method visit_ClassDef of class MetaclassTransformer

# Generated at 2022-06-23 22:45:27.520801
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import ast
    import astor
    # Given

# Generated at 2022-06-23 22:45:34.821591
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    metaclass_transformer = MetaclassTransformer()
    node = ast.ClassDef(name='NodeClass',
                        bases=[ast.Name(id='BaseClass', ctx=ast.Load())],
                        keywords=[ast.keyword(arg='metaclass',
                                              value=ast.Name(id='MetaClass', ctx=ast.Load()))],
                        body=[],
                        decorator_list=[],
                        keywords=[])

# Generated at 2022-06-23 22:45:41.609530
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    tree = ast.parse("""
        import os
        import six
        class A(metaclass=B):
            pass
    """)

    visitor = MetaclassTransformer()
    visitor.visit(tree)
    assert ast.dump(tree) == dedent("""\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        import os
        import six
        class A(_py_backwards_six_withmetaclass(B)):
            pass
    """)


# Generated at 2022-06-23 22:45:45.283499
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import ast as pyast
    from typing import List, Tuple
    class TestTransformer(MetaclassTransformer):
        def __init__(self):
            self.methods_entered: List[Tuple[str, object]] = []

        def visit(self, node: pyast.AST) -> pyast.AST:
            self.methods_entered.append((node.__class__.__name__, node))
            return super().visit(node)


# Generated at 2022-06-23 22:45:53.700092
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from .base import BaseNodeTest
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    class Test(BaseNodeTest):
        target = MetaclassTransformer.target
        transformer = MetaclassTransformer
        code = 'class A(metaclass=B): pass'

        def test_ast(self):
            tree = source_to_ast(self.transformer, self.code)
            self.assertEqual(ast_to_source(tree), 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass')


# Generated at 2022-06-23 22:46:04.086243
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .base import BaseTestTransformer

    class Test(BaseTestTransformer):
        target = (2, 7)
        transformer = MetaclassTransformer
        method = 'visit_ClassDef'

        def _good_results_test(self, node: ast.AST, updated: bool, lines: List[str]) -> None:
            self.assertIsInstance(node, ast.ClassDef)
            self.assertTrue(updated)
            self.assertEqualLines(
                lines,
                ['class A(_py_backwards_six_withmetaclass(B, C)):',
                 '    pass'])

    Test('''
        class A(B, C, metaclass=D):
            pass
        ''').test(add_imports=[six_import])


# Generated at 2022-06-23 22:46:11.586403
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    transformer = MetaclassTransformer
    source = "class A(metaclass=B, other=123): pass"
    expected = """\
        from six import with_metaclass as _py_backwards_six_withmetaclass
        class A(_py_backwards_six_withmetaclass(B), other=123):
            pass
    """
    assert transformer.run(source) == expected
    transformer.run(source, mode="exec")
    transformer.run(source, mode="eval")
    transformer.run(source, mode="single")

# Generated at 2022-06-23 22:46:12.566995
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from .. import transform

# Generated at 2022-06-23 22:46:19.721787
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    metaclass = ast.Name(id='A', ctx=ast.Load())
    bases = ast.List(elts=[], ctx=ast.Load())
    classdef = ast.ClassDef(name='B', bases=bases, keywords=[],
                            body=[], decorator_list=[])
    module = ast.Module(body=[classdef])

    node = ast.Module(body=[classdef])
    mt = MetaclassTransformer()
    mt.visit(node)
    assert node.body[0].bases == class_bases.get_body(metaclass=metaclass,
                                                      bases=bases)

# Generated at 2022-06-23 22:46:22.122770
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    @six_import
    def test_MetaclassTransformer_six_import():
        pass



# Generated at 2022-06-23 22:46:23.924913
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    instance = MetaclassTransformer()

# Generated at 2022-06-23 22:46:29.131988
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    source = """class A(metaclass=B):
    pass"""
    expected_result = """from six import with_metaclass as _py_backwards_six_with_metaclass\n\nclass A(_py_backwards_six_with_metaclass(B)):
    pass"""
    assert MetaclassTransformer().transform_source(source) == expected_result

# Generated at 2022-06-23 22:46:30.127468
# Unit test for method visit_Module of class MetaclassTransformer

# Generated at 2022-06-23 22:46:38.138890
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    code = """
    class A(metaclass=B):
        pass
    """
    tree = ast.parse(code)
    mt = MetaclassTransformer()
    mt.visit(tree)
    assert mt._tree_changed
    assert ast.dump(tree) == "Module(body=[ImportFrom(module='six', names=[alias(name='with_metaclass', asname='_py_backwards_six_withmetaclass')], level=0), ClassDef(name='A', bases=[Call(func=Name(id='_py_backwards_six_withmetaclass', ctx=Load()), args=[Name(id='B', ctx=Load())], keywords=[], starargs=None, kwargs=None)], keywords=[], body=[Pass()], decorator_list=[])])"  # noqa:

# Generated at 2022-06-23 22:46:46.200965
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from typed_ast import ast3
    transformer = MetaclassTransformer()

    module = ast3.parse("""
    class A(metaclass=B):
        pass
    """)
    result = transformer.visit(module)
    expected_result = ast3.parse("""
    from six import with_metaclass as _py_backwards_six_withmetaclass

    class A(_py_backwards_six_withmetaclass(B)):
        pass
    """)
    assert ast3.dump(result) == ast3.dump(expected_result)

# Generated at 2022-06-23 22:46:52.483430
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from .utils import get_ast

    # Given
    ast_tree = get_ast("""
    class A(B, C, D, metaclass=E):
        pass
    """)

    # When
    t = MetaclassTransformer()
    t.visit(ast_tree)

    # Then
    assert str(ast_tree) == """
    class A(_py_backwards_six_with_metaclass(E))
        pass
    """

# Generated at 2022-06-23 22:46:58.955417
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    import astor
    ast_tree = ast.parse('class A(object, metaclass=B):\n    pass')
    x = MetaclassTransformer()
    x.visit(ast_tree)
    assert astor.to_source(ast_tree).strip() == 'from six import with_metaclass as _py_backwards_six_withmetaclass\nclass A(_py_backwards_six_withmetaclass(B)):\n    pass'



# Generated at 2022-06-23 22:47:05.030396
# Unit test for constructor of class MetaclassTransformer
def test_MetaclassTransformer():
    from ..tests.utils.base import BaseTest

    class Test(BaseTest):
        target = MetaclassTransformer.target
        transformer = MetaclassTransformer
        method = 'visit_ClassDef'
        name = 'test_class'
        module_dependencies = ['six']
        suite = (
            ('class Test(metaclass=int): pass', 'class Test(_py_backwards_six_withmetaclass(int)): pass'),
            ('class Test(metaclass=int, object): pass', 'class Test(_py_backwards_six_withmetaclass(int), object): pass'),
        )
    Test().run_tests()

# Generated at 2022-06-23 22:47:15.676816
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer, BaseCodeGenerator
    node = ast.ClassDef(name='Foo',
                        bases=[
                            ast.Name(id='Bar', ctx=ast.Load())
                        ],
                        keywords=[
                            ast.keyword(arg='metaclass', value=ast.Name(id='Baz', ctx=ast.Load()))
                        ],
                        body=[],
                        decorator_list=[])
    BaseNodeTransformer.generic_visit = lambda self, node: None
    transformer = MetaclassTransformer(None)
    transformed_node = transformer.visit_ClassDef(node)
    assert transformer.tree_changed
    assert type(transformed_node.bases[0]) == ast.Call

# Generated at 2022-06-23 22:47:20.668644
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    import astor
    from .transform_test_cases import TransformTestCase

    test = TransformTestCase(
        MetaclassTransformer,
        '''
        class A(metaclass=B):
            pass
        '''
    )

# Generated at 2022-06-23 22:47:29.195861
# Unit test for method visit_ClassDef of class MetaclassTransformer
def test_MetaclassTransformer_visit_ClassDef():
    class TestMetaclassTransformer(MetaclassTransformer):
        def visit(self, node: ast.AST, *args, **kwargs):
            self._visited = node
            return self.generic_visit(node)  # type: ignore

    node = ast.parse("class X(object):\n    pass")
    transformer = TestMetaclassTransformer()
    transformer.visit(node)

    assert transformer._visited == node.body[0]


# Generated at 2022-06-23 22:47:38.776533
# Unit test for method visit_Module of class MetaclassTransformer
def test_MetaclassTransformer_visit_Module():
    from ..utils.source import source_to_node
    from .base import BaseNodeTest

    class test_MetaclassTransformer_visit_Module(BaseNodeTest):
        target = MetaclassTransformer.target
        transformer = MetaclassTransformer

        def test_class_no_metaclass(self):
            node = source_to_node('''
            class C:
                pass
            ''')
            expected_node = source_to_node('''
            class C:
                pass
            ''')

            self.compare_node(node, expected_node)

        def test_class_with_metaclass(self):
            node = source_to_node('''
            class C(metaclass=type):
                pass
            ''')
            expected_node = source_to_