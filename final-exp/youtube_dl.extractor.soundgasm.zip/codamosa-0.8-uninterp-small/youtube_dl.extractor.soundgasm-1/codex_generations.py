

# Generated at 2022-06-26 12:41:39.650735
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test if soundgasm_profile_i_e_0 is an instance of InfoExtractor
    assert isinstance(soundgasm_profile_i_e_0,InfoExtractor)


# Generated at 2022-06-26 12:41:40.459312
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    Soundgasm_I_E = SoundgasmIE()



# Generated at 2022-06-26 12:41:42.737678
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_0 = SoundgasmIE()


# Generated at 2022-06-26 12:41:45.092992
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # arguments (and their default values) in actual order
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()
    assert soundgasm_profile_i_e_0.SUCCESS_REGEX == re.compile(r'')
    assert soundgasm_profile_i_e_0.IE_NAME == 'Soundgasm'



# Generated at 2022-06-26 12:41:53.074887
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert soundgasm_profile_i_e_0._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$', 'Attribute "soundgasm_profile_i_e_0.SoundgasmProfileIE._VALID_URL" does not match its value in __init__()'

# Generated at 2022-06-26 12:41:55.430541
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e = SoundgasmIE()

test_case_0()
test_SoundgasmIE()

# Generated at 2022-06-26 12:42:08.559335
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/s/8055/My-First-Sissy-Assignme"
    mobj = re.match(SoundgasmIE._VALID_URL, url)
    if not mobj:
        raise SystemExit('Cannot recognize URL: %s' % url)
    user_id = mobj.group('user')
    soundgasm_i_e = SoundgasmIE()
    soundgasm_profile_i_e_1 = SoundgasmProfileIE.suitable(url)
    soundgasm_profile_i_e_2 = SoundgasmProfileIE(soundgasm_i_e)
    assert_equal(soundgasm_profile_i_e_2.ie_key(), 'Soundgasm')

# Generated at 2022-06-26 12:42:09.402562
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE(InfoExtractor())

# Generated at 2022-06-26 12:42:11.296869
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_0 = SoundgasmIE()


# Generated at 2022-06-26 12:42:13.597806
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test with correct args
    soundgasm_profile_i_e = SoundgasmProfileIE()

    # Test with wrong args
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()

    # Test with invalid number of args
    soundgasm_profile_i_e_1 = SoundgasmProfileIE()


# Generated at 2022-06-26 12:42:21.307374
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    i = SoundgasmProfileIE()
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    i.extract(url)

# Generated at 2022-06-26 12:42:25.512812
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	ie = SoundgasmProfileIE('url')
	assert ie.IE_NAME == 'soundgasm:profile'
	assert ie.IE_DESC == 'Soundgasm Profile'

# Generated at 2022-06-26 12:42:29.430562
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    i = SoundgasmIE()
    assert i.match(url)
    assert i._download_webpage()
    assert i._real_extract()
    assert i._search_regex()
    assert i._html_search_regex()

# Generated at 2022-06-26 12:42:35.262870
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Test for SoundgasmIE.__init__"""
    a = SoundgasmIE()
    assert a._VALID_URL == SoundgasmIE._VALID_URL
    assert a._TEST == SoundgasmIE._TEST
    assert a.IE_NAME == SoundgasmIE.IE_NAME

# Generated at 2022-06-26 12:42:39.401404
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    a = SoundgasmIE()
    b = SoundgasmIE()
    print (a)
    print (b)
    print (a.test)
    print (b.test)
    return

# Generated at 2022-06-26 12:42:45.624674
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    result = SoundgasmIE._build_result(url)
    assert result == {'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
                      'user': 'ytdl',
                      'display_id': 'Piano-sample'}

# Generated at 2022-06-26 12:42:52.248336
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    m = re.match(SoundgasmIE._VALID_URL, url)
    mobj = m.groupdict()
    mobj['display_id']
    # Test 'Piano-sample'


# Generated at 2022-06-26 12:42:53.211535
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_SoundgasmProfileIE = SoundgasmProfileIE(None)

if __name__ == '__main__':
    test_SoundgasmProfileIE()

# Generated at 2022-06-26 12:42:54.728527
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    temp = SoundgasmProfileIE()

# Generated at 2022-06-26 12:42:56.782293
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-26 12:43:06.804177
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_id = 'ytdl'
    assert(SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/'+profile_id+'/?(?:\#.*)?$')

# Generated at 2022-06-26 12:43:16.228529
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    extractor = SoundgasmIE()
    metadata = extractor._real_extract(url)
    assert metadata["id"] == "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
    assert metadata["display_id"] == "Piano-sample"
    assert metadata["vcodec"] == "none"
    assert metadata["title"] == "Piano sample"
    assert metadata["description"] == "Royalty Free Sample Music"
    assert metadata["uploader"] == "ytdl"

# Generated at 2022-06-26 12:43:28.319877
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE("")
    success = True
    if soundgasm.IE_NAME != 'soundgasm':
        print("Error: SoundgasmIE.IE_NAME is not 'soundgasm'")
        success = False

# Generated at 2022-06-26 12:43:35.198383
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl/")
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl/#")
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl/#top")

# Generated at 2022-06-26 12:43:37.115893
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    class_ = SoundgasmProfileIE
    assert class_ is not None


# Generated at 2022-06-26 12:43:38.400710
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import SoundgasmIE
    print("Testing for constructor of SoundgasmProfileIE")
    ie = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    assert ie.valid

# Generated at 2022-06-26 12:43:43.153402
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # First test whether the constructor of class SoundgasmProfileIE takes u/ytdl
    # as the user name and return it as the index name
    test1 = SoundgasmProfileIE('u/ytdl')
    assert test1._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/ytdl/?(?:\#.*)?$'
    
    # Second test whether the constructor of class SoundgasmProfileIE takes u/ytdl?
    # as the user name and return it as the index name
    test2 = SoundgasmProfileIE('u/ytdl?')
    assert test2._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/ytdl/?(?:\#.*)?$'  
    
    # Third test whether the

# Generated at 2022-06-26 12:43:48.284445
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    param = {
        't': 'a',
        'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
        'md5': '010082a2c802c5275bb00030743e75ad',
        'info_dict': {
            'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
            'ext': 'm4a',
            'title': 'Piano sample',
            'description': 'Royalty Free Sample Music',
            'uploader': 'ytdl',
        }
    }
    testcase = SoundgasmIE('Soundgasm', param)
    testcase.run()

# Generated at 2022-06-26 12:43:57.602938
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    audio_url = 'http://soundgasm.net:80/stream/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    # Test that constructor is able to parse the given URL into a URL of the audio file and an audio id.
    ie = SoundgasmIE()

# Generated at 2022-06-26 12:44:00.907121
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl/Piano-sample")


# Generated at 2022-06-26 12:44:17.398315
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import common_test
    common_test(SoundgasmProfileIE)

# Generated at 2022-06-26 12:44:18.314944
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    unit = SoundgasmProfileIE()



# Generated at 2022-06-26 12:44:23.870884
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info = SoundgasmIE()._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert info['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert info['title'] == 'Piano sample'
    assert info['uploader'] == 'ytdl'


# Generated at 2022-06-26 12:44:33.949136
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	import os
	import unittest
	test_dir = os.path.dirname(os.path.abspath(__file__))
	f = open(os.path.join(test_dir, 'test_data/test.html'), 'r')
	html = f.read()
	f.close()

	import HTMLParser
	htmlparser = HTMLParser.HTMLParser()
	html = htmlparser.unescape(html)

	ie = SoundgasmIE("test soundgasm")
	ie.get_info("88abd86ea000cafe98f96321b23cc1206cbcbcc9", html)

	print ("*"*30)
	print ("Uploader: " + ie.uploader_name)
	print ("Audio name: " + ie.title)

# Generated at 2022-06-26 12:44:36.573516
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:44:41.996707
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import urllib
    userid = 'ytdl'
    display_id = 'Piano-sample'
    url = 'http://soundgasm.net/u/%s/%s' % (userid, display_id)
    ies = SoundgasmIE()
    assert ies._download_webpage(url, display_id)


# Generated at 2022-06-26 12:44:43.662988
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample', {})

# Generated at 2022-06-26 12:44:47.743873
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ieg = SoundgasmIE(audio_url)
    assert ieg.url == audio_url
    assert ieg.display_id == 'Piano-sample'

# Generated at 2022-06-26 12:44:50.334854
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE()
    result = ie._real_extract(test_url)
    assert result['id'] == 'ytdl'

# Generated at 2022-06-26 12:45:01.375845
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Test constructor of SoundgasmIE"""
    # all ok
    IE = SoundgasmIE(None, 'http://soundgasm.net/u/ytdl/Piano-sample')
    assert IE.IE_NAME == 'soundgasm'
    assert IE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:45:50.738225
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	IE_Soundgasm = SoundgasmIE()
	assert IE_Soundgasm.IE_NAME == 'Soundgasm'
	assert IE_Soundgasm._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:45:52.169611
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert isinstance(ie, SoundgasmIE)

# Generated at 2022-06-26 12:45:58.823785
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

	# This checks that the video is correctly downloaded and has the same md5 hash as its known.
	# It also checks that the metadata of the video is correctly extracted.
	# This particular video is: http://soundgasm.net/u/ytdl/Piano-sample
	# with md5 hash: 010082a2c802c5275bb00030743e75ad

	soundgasm_info_extractor = SoundgasmIE()
	info_dict = soundgasm_info_extractor._real_extract("http://soundgasm.net/u/ytdl/Piano-sample")

	print("\n\n\nTesting SoundgasmIE.py\n\n\n")
	print("-----------------------")
	print("Testing its ID:")

# Generated at 2022-06-26 12:46:02.978355
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Constructed object
    soundgasm_ie = SoundgasmIE()

    # Test properties
    assert soundgasm_ie.IE_NAME == 'soundgasm'

    # Test methods
    # TODO: this unit test still needs to be implemented

    # Test for exceptions
    # TODO: this unit test still needs to be implemented


# Generated at 2022-06-26 12:46:09.092067
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert obj._download_webpage('http://soundgasm.net/u/ytdl') is not None
    assert obj._match_id('http://soundgasm.net/u/ytdl') == 'ytdl'

# Generated at 2022-06-26 12:46:14.734433
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Checks that the object is created correctly
    e = SoundgasmProfileIE()
    assert (e.IE_NAME == 'soundgasm:profile')
    assert (e._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
    assert (e._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1})

# Generated at 2022-06-26 12:46:15.230583
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-26 12:46:16.960321
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE()
    assert soundgasm_profile_ie.ie_key() == 'SoundgasmProfile'

# Generated at 2022-06-26 12:46:17.441373
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-26 12:46:23.346886
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import hashlib
    test_value = '2jmj7l5rSw0yVb/vlWAYkK/YBwk=\n'
    assert(hashlib.sha256(test_value.encode('utf-8')).hexdigest() == 'a315e55e1c54de4d4a1f36a9eb9b51cdaa04d4d864e3961b7850a4fbb97b7060')


# Generated at 2022-06-26 12:48:07.861643
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    ie.extract()
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    ie.extract()
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    ie.extract()

# Generated at 2022-06-26 12:48:12.870185
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # SoundgasmProfileIE()._real_extract('http://soundgasm.net/u/ytdl')
    SoundgasmProfileIE()._download_webpage('http://soundgasm.net/u/ytdl', 'ytdl')
    SoundgasmProfileIE()._match_id('http://soundgasm.net/u/ytdl')
# test_SoundgasmProfileIE()

# Generated at 2022-06-26 12:48:14.469230
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE()
    assert isinstance(instance, SoundgasmProfileIE)


# Generated at 2022-06-26 12:48:19.910466
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sgpIE = SoundgasmProfileIE()

    # Checking valid url
    url = sgpIE.IE_NAME + ' ' + sgpIE._VALID_URL
    assert(sgpIE._VALID_URL == sgpIE._match_id(url))

    # Checking invalid url
    url = sgpIE.IE_NAME + ' http://soundgasm.net/u/a'
    assert(None == sgpIE._match_id(url))



# Generated at 2022-06-26 12:48:24.066988
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert SoundgasmProfileIE._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert SoundgasmProfileIE._TEST['info_dict'] == {'id': 'ytdl'}
    assert SoundgasmProfileIE._TEST['playlist_count'] == 1

# Generated at 2022-06-26 12:48:25.611050
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    inst = SoundgasmProfileIE()
    assert inst.name, 'SoundgasmProfileIE'

# Generated at 2022-06-26 12:48:31.436907
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sgpi = SoundgasmProfileIE()
    assert sgpi.IE_NAME == "soundgasm:profile"
    assert sgpi._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert sgpi._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': { 'id': 'ytdl'}, 'playlist_count': 1}

# Generated at 2022-06-26 12:48:32.200492
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE("")
    assert ie is not None


# Generated at 2022-06-26 12:48:33.154927
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-26 12:48:33.922506
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie is not None