

# Generated at 2022-06-26 12:41:37.519998
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # 1st test case
    soundgasm_i_e_0 = SoundgasmIE()


# Generated at 2022-06-26 12:41:40.748369
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e = SoundgasmIE()


# Generated at 2022-06-26 12:41:48.324515
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert_equals(SoundgasmProfileIE.IE_NAME, 'soundgasm:profile')
    assert_equals(SoundgasmProfileIE._VALID_URL, r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
    assert_equals(SoundgasmProfileIE._TEST, {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1})


# Generated at 2022-06-26 12:41:56.268731
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e = SoundgasmProfileIE()
    assert soundgasm_profile_i_e.ie_key() == 'Soundgasm:profile'
    assert soundgasm_profile_i_e.ie_name() == 'Soundgasm'
    assert soundgasm_profile_i_e.valid_url('http://soundgasm.net/u/ytdl', 'Soundgasm') == True



# Generated at 2022-06-26 12:41:59.754185
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()


# Generated at 2022-06-26 12:42:01.782067
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_0 = SoundgasmIE()


# Generated at 2022-06-26 12:42:02.681760
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e = SoundgasmProfileIE()


# Generated at 2022-06-26 12:42:03.759242
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE(SoundgasmIE.IE_NAME, SoundgasmIE.IE_DESC) is not None


# Generated at 2022-06-26 12:42:05.407272
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # simple unit test for constructor of class SoundgasmProfileIE
    print('simple unit test for constructor of class SoundgasmProfileIE')
    ie = SoundgasmIE()



# Generated at 2022-06-26 12:42:07.594870
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e = SoundgasmProfileIE()
    assert_equals(type(soundgasm_profile_i_e), SoundgasmProfileIE)


# Generated at 2022-06-26 12:42:17.182049
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_0 = SoundgasmIE()


# Generated at 2022-06-26 12:42:21.240583
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e = SoundgasmProfileIE()
    assert soundgasm_profile_i_e.IE_NAME == 'Soundgasm:profile'


# Generated at 2022-06-26 12:42:22.631422
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE


# Generated at 2022-06-26 12:42:24.608313
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()


# Generated at 2022-06-26 12:42:29.001516
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()
    assert soundgasm_profile_i_e_0._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-26 12:42:36.746898
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    soundgasm_profile_i_e = SoundgasmProfileIE()
    assert soundgasm_profile_i_e.suitable(url)
    assert soundgasm_profile_i_e._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:42:39.509745
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        soundgasm_i_e_0 = SoundgasmIE()
        assert(soundgasm_i_e_0 != None)
        print ('SoundgasmIE constructor OK')
    except:
        print ('SoundgasmIE constructor NOK')


# Generated at 2022-06-26 12:42:43.464607
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = SoundgasmIE._VALID_URL
    ie = SoundgasmIE()
    try:
        ie.suitable(url)
        assert True
    except:
        assert False


# Generated at 2022-06-26 12:42:45.606981
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Constructor of SoundgasmIE should take two arguments
    assert SoundgasmIE.__init__.__code__.co_argcount == 2
    return


# Generated at 2022-06-26 12:42:47.565171
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e = SoundgasmIE()


# Generated at 2022-06-26 12:43:01.603431
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    assert soundgasm.IE_NAME == 'soundgasm'
    assert soundgasm._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:43:03.455506
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    s = SoundgasmIE()
    assert(s)



# Generated at 2022-06-26 12:43:11.350958
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .test import Mock
    def _mock_download_webpage(url, display_id, errnote, fatal, headers=None, data=None, query={}):
        return """
            <!DOCTYPE html>
            <html>
            <head>
                <title>Title</title>
            </head>
            <body>
                <div class="jp-title">title</div>
                <div class="jp-description">description</div>
                <script>
                var my_mock_audio_url = "http://audio_url/";
                </script>
                <script type='text/javascript' src='/test.js'></script>
            </body>
            </html>
            """

    SoundgasmIE._download_webpage = _mock_download_webpage


# Generated at 2022-06-26 12:43:12.936181
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    expected_result = SoundgasmIE()._real_extract(test_SoundgasmIE._TEST['url'])
    assert expected_result == test_SoundgasmIE._TEST

# Generated at 2022-06-26 12:43:16.700042
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    my_soundgasm_profile_ie = SoundgasmProfileIE()
    # Tested with url: http://soundgasm.net/u/ytdl
    url = 'http://soundgasm.net/u/ytdl'
    my_soundgasm_profile_ie.extract(url)


# Generated at 2022-06-26 12:43:18.963950
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-26 12:43:24.401636
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    user = "ytdl"
    display_id = "Piano-sample"
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    SoundgasmIE()._real_extract(url)

# Generated at 2022-06-26 12:43:25.694564
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE = SoundgasmProfileIE()
    assert isinstance(IE, InfoExtractor)

# Generated at 2022-06-26 12:43:36.725993
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = "http://soundgasm.net/u/ytdl"
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.IE_DESC == 'Soundgasm.net profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    Test = ie._TEST
    Test['info_dict']['id'] == 'ytdl'
    Test['playlist_count'] == 1
    return True


# Generated at 2022-06-26 12:43:46.996908
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    tester = SoundgasmProfileIE('SoundgasmProfileIE')
    assert isinstance(tester, InfoExtractor)
    assert tester.IE_NAME == 'SoundgasmProfileIE'
    assert tester.IE_DESC is None
    assert tester._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert tester._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    assert tester._downloader is None

# Generated at 2022-06-26 12:44:03.756875
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    return sg

# Generated at 2022-06-26 12:44:07.282758
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert(SoundgasmIE._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample')
    assert(SoundgasmIE._TEST['md5'] == '010082a2c802c5275bb00030743e75ad')
    return


# Generated at 2022-06-26 12:44:19.613342
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-26 12:44:24.034944
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE()
    assert profile.IE_NAME == 'soundgasm:profile'
    assert profile._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:44:24.559958
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-26 12:44:26.553116
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert isinstance(SoundgasmProfileIE(None), SoundgasmProfileIE)

# Generated at 2022-06-26 12:44:35.627024
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import os

# Generated at 2022-06-26 12:44:40.941815
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.__dict__ == {'_downloader': None, 'url': 'http://soundgasm.net/u/YTDL', '_match_id': 'ytdl', '_VALID_URL': 'https?://(?:www\\.)?soundgasm\\.net/u/(?P<id>[^/]+)/?(?:\\#.*)?$', '_TEST': {'info_dict': {'id': 'ytdl'}, 'playlist_count': 1, 'url': 'http://soundgasm.net/u/ytdl'}, 'IE_NAME': 'soundgasm:profile'}

# Generated at 2022-06-26 12:44:45.573042
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_class = SoundgasmIE()
    test_class._download_webpage = lambda x,y: ''
    test_class._search_regex = lambda *x: ''
    test_class._html_search_regex = lambda *x: ''
    test_class._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-26 12:44:52.829223
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test without input parameters
    extractor = SoundgasmIE()

    assert extractor.IE_NAME == 'soundgasm'
    assert extractor._VALID_URL is not None
    assert extractor._TEST is not None
    assert extractor._TEST.get('url') is not None
    assert extractor._TEST.get('md5') is not None
    assert extractor._TEST.get('info_dict') is not None
    assert extractor._TEST.get('info_dict').get('id') is not None
    assert extractor._TEST.get('info_dict').get('ext') is not None
    assert extractor._TEST.get('info_dict').get('title') is not None
    assert extractor._TEST.get('info_dict').get('description') is not None
    assert extractor

# Generated at 2022-06-26 12:45:33.891998
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE(None)._download_webpage('http://soundgasm.net/u/ytdl/Piano-sample', 'Piano-sample')

# Generated at 2022-06-26 12:45:37.259090
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    video_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    video_info = SoundgasmIE()._real_extract(video_url)
    assert video_info["id"] == "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
    assert video_info["ext"] == "m4a"
    assert video_info["title"] == "Piano sample"
    assert video_info["description"] == "Royalty Free Sample Music"
    assert video_info["uploader"] == "ytdl"


# Generated at 2022-06-26 12:45:40.054976
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasmProfileIE = SoundgasmProfileIE('SoundgasmProfileIE')
    assert soundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:45:41.277182
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    x = SoundgasmIE()
    assert x.IE_NAME == "Soundgasm"

# Generated at 2022-06-26 12:45:48.354683
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    class SoundgasmProfileIE_test(SoundgasmProfileIE):
        def _download_webpage(self, url, display_id):
            return 'href="%s"' % url
    obj = SoundgasmProfileIE_test()
    playlist = obj.extract('http://soundgasm.net/u/ytdl')
    assert playlist == {
        'id': 'ytdl',
        'entries': [{
            'id': 'u/ytdl',
            'url': 'http://soundgasm.net/u/ytdl',
        }],
    }

# Generated at 2022-06-26 12:45:52.209048
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('ytdl', 'Piano-sample')
    assert ie.url == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie.display_id == 'Piano-sample'
    assert ie.user == 'ytdl'


# Generated at 2022-06-26 12:45:53.105527
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()

# Generated at 2022-06-26 12:45:56.519297
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-26 12:46:01.613072
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print("test_SoundgasmProfileIE()")
    ie = SoundgasmProfileIE("soundgasm", "http://soundgasm.net/u/ytdl")
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.IE_NAME == "soundgasm"
    assert ie.ie_key() == "Soundgasm"

# Generated at 2022-06-26 12:46:02.751904
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == 'soundgasm'


# Generated at 2022-06-26 12:47:30.748614
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SE = SoundgasmIE()
    SE.suite()



# Generated at 2022-06-26 12:47:34.238215
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert soundgasm_profile_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:47:38.028131
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg_ie = SoundgasmIE('test', 'http://soundgasm.net/u/ytdl')
    assert(sg_ie.IE_NAME == 'soundgasm')
    assert(sg_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')


# Generated at 2022-06-26 12:47:44.662998
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("Test SoundgasmIE")
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE._download_webpage = lambda self, url, display_id: \
        open('./test/soundgasm.net/u/ytdl/Piano-sample/webpage.txt').read()
    SoundgasmIE._search_regex = lambda self, pattern, string, name, default, fatal, flags: \
        re.search(pattern, string).group(1)
    SoundgasmIE._html_search_regex = lambda self, pattern, string, name, default, fatal, flags: \
        re.search(pattern, string).group(1)
    result = SoundgasmIE().extract(url)

# Generated at 2022-06-26 12:47:51.565173
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    def download_webpage(url, *args, **kwargs):
        webpage = {}
        webpage['url'] = url
        webpage['webpage'] = webpage
        return webpage

    soundgasm_profile = SoundgasmProfileIE()
    soundgasm_profile._download_webpage = download_webpage
    assert soundgasm_profile.ie_key() == 'Soundgasm:profile'
    assert soundgasm_profile.IE_NAME == 'Soundgasm:profile'
    assert soundgasm_profile._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert soundgasm_profile.IE_DESC == 'Soundgasm profiles'

# Generated at 2022-06-26 12:47:57.511266
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == ie.__class__.IE_NAME
    assert ie.IE_NAME == 'Soundgasm'
    assert ie.VALID_URL == ie.__class__._VALID_URL
    assert ie.VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:48:01.300734
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'Soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:48:03.098679
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info_extractor = SoundgasmProfileIE()
    assert info_extractor.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-26 12:48:05.491718
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    ie.download('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-26 12:48:07.697781
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    "Checks whether SoundgasmIE exists"
    SoundgasmIE('SoundgasmIE')


# Generated at 2022-06-26 12:51:22.128673
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_url = 'http://soundgasm.net/u/ytdl'
    profile = SoundgasmProfileIE(downloader=None)
    profile_id = profile._match_id(profile_url)
    assert profile_id == 'ytdl'
    entries = profile._real_extract(profile_url)
    assert 'playlist' in entries
    assert len(entries['entries']) == 1


# Generated at 2022-06-26 12:51:25.154593
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    tester = "http://soundgasm.net/u/ytdl/Piano-sample"
    url = (tester)
    ie = SoundgasmIE(url)
    teste = ie.extract()


# Generated at 2022-06-26 12:51:30.965103
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # test_SoundgasmIE.py is located in youtube_dl/test/test_SoundgasmIE.py
    # and the class SoundgasmIE is located in youtube_dl/extractor/SoundgasmIE.py
    # so we need to add '..' to PYTHONPATH.
    import os
    import sys
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from SoundgasmIE import SoundgasmIE
    # Check if the object SoundgasmIE can be constructed
    assert SoundgasmIE({})