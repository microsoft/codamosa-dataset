

# Generated at 2022-06-26 12:41:38.651536
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e = SoundgasmProfileIE()

# Generated at 2022-06-26 12:41:41.493258
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e = SoundgasmProfileIE()


# Generated at 2022-06-26 12:41:46.549022
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e = SoundgasmProfileIE()
    assert soundgasm_profile_i_e._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:41:51.542158
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test case 0:
    arg_0 = 'http://soundgasm.net/u/ytdl'

    soundgasm_profile_i_e_0 = SoundgasmProfileIE()

# Generated at 2022-06-26 12:41:56.202721
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .common import InfoExtractor

    assert issubclass(SoundgasmIE, InfoExtractor)
    assert SoundgasmIE.IE_NAME == 'soundgasm'
    assert SoundgasmIE.IE_DESC == 'Soundgasm'


# Generated at 2022-06-26 12:41:57.677525
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE()


# Generated at 2022-06-26 12:42:00.063871
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass


# Generated at 2022-06-26 12:42:02.082365
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e = SoundgasmIE()


# Generated at 2022-06-26 12:42:04.198521
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert issubclass(SoundgasmProfileIE, InfoExtractor)

# Generated at 2022-06-26 12:42:06.004855
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
   soundgasm_profile_i_e_0 = SoundgasmProfileIE()

# Generated at 2022-06-26 12:42:19.589822
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	link = 'http://soundgasm.net/u/ytdl/Piano-sample'
	ie = SoundgasmIE(link)
	assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:42:20.597061
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('Soundgasm', 'http://soundgasm.net/u/ytdl', 'ytdl') is not None

# Generated at 2022-06-26 12:42:21.433297
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-26 12:42:24.198941
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert ie._TEST['info_dict']['id'] == 'ytdl'
    assert ie._TEST['playlist_count'] == 1
    

# Generated at 2022-06-26 12:42:30.759675
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE = SoundgasmProfileIE()
    IE._match_id('http://soundgasm.net/u/ytdl') == 'ytdl'
    IE._match_id('http://soundgasm.net/u/ytdl/') == 'ytdl'
    IE._match_id('http://soundgasm.net/u/ytdl/#') == 'ytdl'
    IE._match_id('http://soundgasm.net/u/ytdl/#/') == 'ytdl'


# Generated at 2022-06-26 12:42:32.112529
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-26 12:42:37.070188
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    #Unit test with 999 different test cases
    #Test cases taken from input files
    test_cases = []
    f = open("urls_for_input.txt",'r')
    for line in f:
        test_cases.append((line.rstrip('\n')))
    f.close()
    for i in range(1,len(test_cases)):
        test_cases[i]=test_cases[i].split(' ')
    print("Unit testing has begun for class SoundgasmIE")
    for i in range(1,len(test_cases)):
        if i == 1 :
            print("Test Case "+str(i)+": URL - "+ test_cases[i][0] + " ; Title - " + test_cases[i][1])
            tester = SoundgasmIE()
            tester._download

# Generated at 2022-06-26 12:42:45.293918
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test the constructor
    # The constructor is tested because it is used in the test of class SoundgasmIE
    # The constructor is not tested in test_common because it is private to the class
    ie = InfoExtractor(None, {}, None)
    # The expected result of calling the constructor
    expected_result = {
        'extractor': 'generic',
        'ie_key': 'Generic',
        'playlist': False,
    }
    assert ie.__dict__ == expected_result

# Generated at 2022-06-26 12:42:55.010564
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    # The expected id from the url
    expected_id = 'Piano-sample'
    # The expected title from the url.
    expected_title = 'Piano sample'
    # The expected description from the url.
    expected_description = 'Royalty Free Sample Music'
    # The expected uploader from the url.
    expected_uploader = 'ytdl'



# Generated at 2022-06-26 12:42:57.776043
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	try:
		SoundgasmIE()
		SoundgasmIE.add_ie()
		SoundgasmIE.ie_keywords()
	except Exception as e:
		print(e)
		pass


# Generated at 2022-06-26 12:43:06.267914
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Tested in test_main
    pass

# Generated at 2022-06-26 12:43:09.450144
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    e = SoundgasmIE()
    assert e.IE_NAME == 'soundgasm'


# Generated at 2022-06-26 12:43:12.068675
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")



# Generated at 2022-06-26 12:43:14.700020
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test = SoundgasmProfileIE(None)
    assert test.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-26 12:43:22.031050
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_class = 'SoundgasmIE'
    setup_test(test_class)
    print('Beginning of test case:',test_class)
    print('Test case:',test_class,'Passes =',test_constructor(test_class))
    print('End of test case:',test_class)


# Generated at 2022-06-26 12:43:22.929042
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    Pass

# Generated at 2022-06-26 12:43:30.771532
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert type(SoundgasmIE()).__name__ == 'SoundgasmIE'
    assert type(SoundgasmIE()).__name__ != 'SoundgasmProfileIE'
    assert SoundgasmIE()._VALID_URL == SoundgasmIE._VALID_URL
    assert SoundgasmIE()._TEST == SoundgasmIE._TEST
    assert type(SoundgasmIE().suitable(test_url)) == bool
    assert SoundgasmIE().suitable(test_url) == True
    assert type(SoundgasmIE()._real_extract(test_url)) == dict
    assert SoundgasmIE()._real_extract(test_url).get('description') == 'Royalty Free Sample Music'


# Generated at 2022-06-26 12:43:31.434645
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == 'soundgasm'

# Generated at 2022-06-26 12:43:36.177554
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    extractor = SoundgasmProfileIE()
    assert extractor.IE_NAME == 'soundgasm:profile'
    assert extractor._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:43:37.118096
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass

# Generated at 2022-06-26 12:43:55.526805
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    '''
    URL should have "http://www.soundgasm.net/u/wiz" as its homepage URL.
    '''
    test_ie = SoundgasmProfileIE()
    homepage_url = test_ie._HOMEPAGE
    assert homepage_url == 'http://www.soundgasm.net/u/wiz'



# Generated at 2022-06-26 12:43:57.971672
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    constructor = SoundgasmProfileIE
    constructor(SoundgasmProfileIE.IE_NAME)

# Generated at 2022-06-26 12:44:08.752667
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = "http://soundgasm.net/u/ytdl/Piano-sample"
    print(test)
    result = SoundgasmIE()._real_extract(test)
    print(result)
    print("\n")
    #print(SoundgasmIE._TEST['url'])
    #print(SoundgasmIE._TEST['md5'])
    #print(SoundgasmIE._TEST['info_dict'])
    #print(SoundgasmIE._TEST['info_dict']['id'])
    #print(SoundgasmIE._TEST['info_dict']['title'])
    #print(SoundgasmIE._TEST['info_dict']['uploader'])
    #print(SoundgasmIE._TEST['info_dict']['ext'])

# Generated at 2022-06-26 12:44:12.946179
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert profile.IE_NAME == 'SoundgasmProfileIE'

# Generated at 2022-06-26 12:44:15.536559
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE({'url': 'http://soundgasm.net/u/ytdl', 'id': 'ytdl'})

# Generated at 2022-06-26 12:44:18.595136
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_id = 'ytdl'
    url = "http://soundgasm.net/u/%s" % profile_id
    obj = SoundgasmProfileIE()
    obj._real_extract(url)



# Generated at 2022-06-26 12:44:21.222968
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = __import__('test', globals(), locals(), ['test'], 0)
    test.main(SoundgasmIE)

# Generated at 2022-06-26 12:44:22.735045
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        SoundgasmProfileIE()
    except:
        assert False


# Generated at 2022-06-26 12:44:30.288825
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    soundgasmIE = SoundgasmIE(test_url)
    assert soundgasmIE.url == test_url
    assert soundgasmIE.url_pattern == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-26 12:44:31.799952
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    class_inst = SoundgasmProfileIE()
    assert class_inst.ie_key() == 'SoundgasmProfile'

# Generated at 2022-06-26 12:45:05.088636
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_id = 'ytdl'
    url = 'http://soundgasm.net/u/ytdl'

    sg_profile = SoundgasmProfileIE()
    sg_profile._real_extract(url)

# Generated at 2022-06-26 12:45:12.256740
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = r'http://soundgasm.net/u/ytdl'
    first_id = "ytdl"
    second_id = "Piano-sample"
    third_id = "010082a2c802c5275bb00030743e75ad"
    response = "ytdl/Piano-sample/\nytdl/Piano-sample/\n010082a2c802c5275bb00030743e75ad"

    # Unit test for Downloading the url of profile
    # - Check two or more files
    # - Check the owner of profile
    instance = SoundgasmProfileIE()
    result = instance.url_result(url, first_id)
    owner = instance._download_webpage(url, first_id)
    assert first_id == result.get('id')
    assert re

# Generated at 2022-06-26 12:45:14.747844
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
        ie=SoundgasmIE()
        print(ie.extract('http://soundgasm.net/u/ytdl/Piano-sample'))

# Generated at 2022-06-26 12:45:24.600400
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # "m4a" field is not present on certain links, but audio is still playable
    assert SoundgasmIE._download_json(
        'http://soundgasm.net/u/ytdl/Piano-sample', None).get(
            'm4a') is None

    # "m4a" field is properly extracted
    assert SoundgasmIE._download_json(
        'http://soundgasm.net/u/ytdl/AC-DC-Thunderstruck', None)[
            'm4a'] == 'https://s3.amazonaws.com/sg_audio/14084cee3e4a4c33f9a76d9a077adb0fdbc57359.m4a'

# Generated at 2022-06-26 12:45:31.286740
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    audio_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    profile_id = 'ytdl'
    webpage = '<title>ytdl\'s profile</title><a href="%s">Piano-sample</a><a href="%s">abc</a>' % (audio_url, audio_url)
    entries = [
        'http://soundgasm.net/u/ytdl/Piano-sample',
        'http://soundgasm.net/u/ytdl/Piano-sample',
    ]

    assert(SoundgasmProfileIE._extract_entries(webpage, profile_id) == entries)

# Generated at 2022-06-26 12:45:34.776251
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	user = 'ytdl'  # ytdl
	url = "http://soundgasm.net/u/ytdl"
	soundgasm_ie = SoundgasmProfileIE.ie

	# get webpage from url
	webpage = soundgasm_ie._download_webpage(url, user)

	# get audio urls from webpage
	audio_urls = re.findall(r'href="([^"]+/u/%s/[^"]+)' % user, webpage)

	# print audio_urls
	print(audio_urls)
	print(len(audio_urls))

# Generated at 2022-06-26 12:45:37.470165
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # This URL returns the html at server side
    ie = SoundgasmIE()
    ie.url = "http://soundgasm.net/u/ytdl/Piano-sample"
    # The call to webpage downloader downloaded webpage
    webpage = ie._webpage_downloader()
    assert webpage is not None


# Generated at 2022-06-26 12:45:46.477705
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import urlparse as up
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    url_parts = up.urlparse(url)
    ie = SoundgasmIE(url)

    assert ie.ie_key() == 'Soundgasm'
    assert ie.ie_name() == 'Soundgasm'
    assert ie.IE_NAME == 'Soundgasm'

    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie._TEST['url'] == url

# Generated at 2022-06-26 12:45:50.276789
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    fixture = {'url': 'http://soundgasm.net/u/ytdl', 'uploader': 'ytdl'}
    ie = SoundgasmProfileIE()
    assert ie._match_id(fixture['url']) == ie._match_id(fixture['uploader'])

# Generated at 2022-06-26 12:45:55.659727
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    dl = SoundgasmProfileIE()
    assert dl._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert dl._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert dl._TEST['info_dict']['id'] == 'ytdl'
    assert dl._TEST['playlist_count'] == 1

# Generated at 2022-06-26 12:47:18.111544
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Constructor test for SoundgasmIE
    """
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie.IE_NAME == 'soundgasm'


# Generated at 2022-06-26 12:47:24.293822
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE_NAME = 'soundgasm:profile'
    _VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    _TEST = {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    instance = SoundgasmProfileIE()
    result = instance.suitable(_VALID_URL)
    expected = True
    assert result == expected
    result = instance.IE_NAME
    expected = IE_NAME
    assert result == expected
    result = instance._TEST
    expected = _TEST
    assert result == expected
    #

# Generated at 2022-06-26 12:47:31.207660
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    i = SoundgasmIE('soundgasm')
    t  = i._real_extract(url)
    assert t == {'uploader': 'ytdl', 'description': 'Royalty Free Sample Music', 'url': 'http://www.soundgasm.net/sounds/88ab/88abd86ea000cafe98f96321b23cc1206cbcbcc9/Piano-sample-ytdl.m4a', 'display_id': 'Piano-sample', 'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9', 'vcodec': 'none', 'title': 'Piano sample'}

# Generated at 2022-06-26 12:47:32.983974
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert obj is not None

# Generated at 2022-06-26 12:47:33.962294
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test = SoundgasmProfileIE()
    test.IE_NAME = 'SoundgasmProfileIE'
    return test

# Generated at 2022-06-26 12:47:35.390910
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE(None)
    assert ie._VALID_URL == SoundgasmIE._VALID_URL
    assert ie._TEST == SoundgasmIE._TEST

# Generated at 2022-06-26 12:47:35.859068
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    SoundgasmIE()

# Generated at 2022-06-26 12:47:39.265426
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Unit test for constructor of class SoundgasmProfileIE
    """
    # Construct an instance of SoundgasmProfileIE
    SoundgasmProfileIE_test = SoundgasmProfileIE()
    assert SoundgasmProfileIE_test
    if SoundgasmProfileIE_test:
        print("Unit test for constructor of class SoundgasmProfileIE passed")
    else:
        assert False


# Generated at 2022-06-26 12:47:42.157150
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test constructor of class SoundgasmIE
    audio_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE(audio_url)
    assert (ie.audio_id == 'Piano-sample')
    assert (ie.user == 'ytdl')


# Generated at 2022-06-26 12:47:44.764144
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg_example = "http://soundgasm.net/u/ytdl"
    sg_real_extract = SoundgasmProfileIE()._real_extract(sg_example)
    assert sg_real_extract is not None

# Generated at 2022-06-26 12:50:54.716247
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasmProfileIE = SoundgasmProfileIE('https://soundgasm.net/u/ytdl')
    assert soundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert soundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert soundgasmProfileIE._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}

# Generated at 2022-06-26 12:51:00.240370
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sampleURL = 'http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasmIE = SoundgasmIE()
    assert soundgasmIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert soundgasmIE.url_result(sampleURL) == {
        '_type': 'url',
        'url': sampleURL,
        'ie_key': 'Soundgasm',
    }


# Generated at 2022-06-26 12:51:07.180197
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # test case needs to be has a valid link
    URL = 'http://soundgasm.net/u/ytdl'
    # create new object
    soundgasm_profile_IE = SoundgasmProfileIE(
        downloader=None,
        download_using=None,
        ie=None,
        params=None,
        working_dir=None,
    )
    # check for the properties
    assert soundgasm_profile_IE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert soundgasm_profile_IE.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-26 12:51:08.033175
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    return SoundgasmIE(InfoExtractor()).get_testcases()

# Generated at 2022-06-26 12:51:13.131556
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    '''
    Unit test for constructor of class SoundgasmIE
    '''
    site_name = "soundgasm"
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    result = "http://soundgasm.net/u/ytdl/Piano-sample"

    soundgasm_ie = SoundgasmIE(url)
    assert soundgasm_ie.site_name == site_name
    assert soundgasm_ie.url() == result


# Generated at 2022-06-26 12:51:18.906148
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	ie = SoundgasmProfileIE()
	# check that all regexes are defined and do not cause errors when used
	assert	ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
	assert	ie._TEST == {
		'url': 'http://soundgasm.net/u/ytdl',
		'info_dict': {
			'id': 'ytdl',
        },
		'playlist_count': 1,
    }


# Generated at 2022-06-26 12:51:28.102337
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie.IE_NAME == 'soundgasm'

    # Unit test for constructor of class SoundgasmProfileIE
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-26 12:51:28.804666
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE(c = 0)

# Generated at 2022-06-26 12:51:30.780053
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert profile

if __name__ == '__main__':
    test_SoundgasmProfileIE()