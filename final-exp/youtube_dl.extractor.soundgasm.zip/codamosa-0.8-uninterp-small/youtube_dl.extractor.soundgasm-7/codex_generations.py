

# Generated at 2022-06-26 12:41:40.813147
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()


# Generated at 2022-06-26 12:41:48.351408
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert SoundgasmProfileIE().IE_NAME == 'soundgasm:profile'
    assert SoundgasmProfileIE()._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-26 12:41:52.687348
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    result = False
    if isinstance(soundgasm_profile_i_e_0, InfoExtractor):
        result = True
    assert result


# Generated at 2022-06-26 12:41:56.396732
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    config = {'proxy': None}
    soundgasm_profile_i_e_0 = SoundgasmProfileIE(config)
    assert soundgasm_profile_i_e_0._downloader.params['proxy'] is None


# Generated at 2022-06-26 12:42:05.385557
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()
    soundgasm_profile_i_e_1 = SoundgasmProfileIE('test')
    assert (isinstance(soundgasm_profile_i_e_0, SoundgasmProfileIE))
    assert (isinstance(soundgasm_profile_i_e_1, SoundgasmProfileIE))


# Generated at 2022-06-26 12:42:06.962859
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert_equal(soundgasm_profile_i_e_0.ie_key(), 'Soundgasm')



# Generated at 2022-06-26 12:42:10.745385
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # from soundgasm_ie import SoundgasmIE
    soundgasm_i_e_0 = SoundgasmIE()


# Generated at 2022-06-26 12:42:12.896855
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e = SoundgasmIE()


# Generated at 2022-06-26 12:42:14.867813
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e = SoundgasmIE()


# Generated at 2022-06-26 12:42:17.588949
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert isinstance(SoundgasmProfileIE()._VALID_URL, str)


# Generated at 2022-06-26 12:42:27.271185
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	soundgasm_i_e_0 = SoundgasmIE()
# Code snippet for class SoundgasmIE(InfoExtractor)

# Generated at 2022-06-26 12:42:29.888531
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE().__class__ == SoundgasmProfileIE

# Generated at 2022-06-26 12:42:38.400858
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert soundgasm_profile_i_e_0.IE_NAME == 'soundgasm:profile'
    assert soundgasm_profile_i_e_0._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert soundgasm_profile_i_e_0._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}


# Generated at 2022-06-26 12:42:47.108700
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert SoundgasmProfileIE._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'playlist_count': 1, 'info_dict': {'id': 'ytdl'}}
    assert not SoundgasmProfileIE.BR_DESC
    assert not SoundgasmProfileIE.IE_DESC
    assert not SoundgasmProfileIE.VERSION
    assert not SoundgasmProfileIE.js_to_json
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()


# Generated at 2022-06-26 12:42:49.529095
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()


# Generated at 2022-06-26 12:42:52.247601
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE()
    assert isinstance(instance, SoundgasmIE)

# Generated at 2022-06-26 12:43:00.290815
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Case 1:
    # Result expected:
    # 'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
    # 'ext': 'm4a',
    # 'title': 'Piano sample',
    # 'description': 'Royalty Free Sample Music',
    # 'uploader': 'ytdl',
    sdg1 = SoundgasmIE()
    sdg1_result = sdg1._real_extract(sdg1._TEST['url'])
    for key, val in sdg1_result.iteritems():
        assert val == sdg1._TEST['info_dict'][key]

# Unit test method for SoundgasmIE._real_extract

# Generated at 2022-06-26 12:43:03.793775
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()
    assert soundgasm_profile_i_e_0 is not None


# Generated at 2022-06-26 12:43:04.735419
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()


# Generated at 2022-06-26 12:43:07.960317
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_1 = SoundgasmProfileIE()


# Generated at 2022-06-26 12:43:18.180011
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE('soundgasm:profile')
    assert soundgasm.IE_NAME == 'Soundgasm'

# Generated at 2022-06-26 12:43:25.115001
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	obj = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample', {'Piano sample': 'Royalty Free Sample Music'}, '00', "Piano sample", 'a')
	assert obj.display_id == '00'
	assert obj.url == 'a'
	assert obj.title == 'Piano sample'

# Generated at 2022-06-26 12:43:37.697728
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print("Unit test for SoundgasmProfileIE")
    test_url = "http://soundgasm.net/u/ytdl"
    test_data = {'url': test_url, 'id': "ytdl"}
    test_playlist_count = 1
    print("Test url is: " + test_url)
    print("Test data is: " + str(test_data))
    print("Test playlist count is: " + str(test_playlist_count))
    # The corrresponding class (SoundgasmProfileIE) in soundgasm.py
    # must make sure the test data is correct.
    ie_object = SoundgasmProfileIE()
    ie_object.playlist_count = test_playlist_count
    v_url = ie_object._match_id(test_url)

# Generated at 2022-06-26 12:43:40.007113
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg = InfoExtractor()
    profile = SoundgasmProfileIE()
    assert profile.IE_NAME == 'soundgasm:profile'
    assert profile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

    assert sg._downloader == None

# Generated at 2022-06-26 12:43:42.248035
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    class DummySoundgasmProfileIE(SoundgasmProfileIE):
        name = 'DummySoundgasmProfileIE'

    expected = SoundgasmProfileIE(DummySoundgasmProfileIE.ie_key())
    actual = DummySoundgasmProfileIE(DummySoundgasmProfileIE.ie_key())
    assert expected == actual

# Generated at 2022-06-26 12:43:44.499669
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Without a working URL in the test, it would be difficult to error-check
    # the constructor of SoundgasmIE
    assert SoundgasmIE(SoundgasmIE.IE_NAME, None)

# Generated at 2022-06-26 12:43:46.280391
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE._VALID_URL is not None

# Generated at 2022-06-26 12:43:56.900397
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-26 12:43:58.474281
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE();

# Generated at 2022-06-26 12:44:08.940200
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    #assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl/Piano-sample', 'md5': '010082a2c802c5275bb00030743e75ad', 'info_dict': {'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9', 'ext': 'm4a', 'title': 'Piano sample', 'description': 'Royalty Free

# Generated at 2022-06-26 12:44:27.419282
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    t = SoundgasmIE()
    result = t.extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert len(result) > 0
    assert result['title'] == 'Piano sample'


# Generated at 2022-06-26 12:44:29.541989
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE(None)
    assert sg


# Generated at 2022-06-26 12:44:30.737963
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE = SoundgasmIE()
    assert IE.IE_NAME == 'soundgasm'

# Generated at 2022-06-26 12:44:38.171763
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mobj = re.match(SoundgasmIE._VALID_URL, url)
    display_id = mobj.group('display_id')
    audio_id = display_id

    audio_url = 'http://soundgasm.net/sound/2in/media/mp3/' + display_id + '.m4a'
    title = 'Piano sample'
    description = 'Royalty Free Sample Music'
    uploader = mobj.group('user')

    # Test the data structure returned by the extractor
    ie = SoundgasmIE(dict(url=url))

    webpage = ie._download_webpage(url, display_id)


# Generated at 2022-06-26 12:44:38.708140
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE

# Generated at 2022-06-26 12:44:40.760908
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	SoundgasmProfileIE("https://soundgasm.net/u/ytdl")

# Generated at 2022-06-26 12:44:42.139467
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    isinstance(SoundgasmIE().IE_NAME, str)

# Generated at 2022-06-26 12:44:44.540815
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE = SoundgasmIE()
    IE._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-26 12:44:49.499453
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('https://soundgasm.net/u/ytdl')
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl/')
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl#')

# Generated at 2022-06-26 12:44:55.030074
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # print("TEST: Loading Soundgasm test url")
    ie = SoundgasmIE()
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    # print(ie.extract(url))
    # print(ie._real_extract(url))
    # print(ie._real_extract(url))
    print(ie._real_extract(url))


# Generated at 2022-06-26 12:45:38.035800
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE(None)
    # Name of the IE
    if instance.IE_NAME != 'soundgasm':
        raise AssertionError('Wrong instance.IE_NAME')
    
    # Valid url format
    if instance._VALID_URL != r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)':
        raise AssertionError('Incorrect instance._VALID_URL')
    
    if type(instance._TEST) is not dict:
        raise AssertionError('Incorrect instance._TEST')

# Generated at 2022-06-26 12:45:39.490315
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-26 12:45:39.938770
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-26 12:45:49.286207
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Download a webpage from a specific user of Soundgasm.net
    webpage = 'http://soundgasm.net/u/ytdl'
    # Create an instance of a SoundgasmProfileIE 
    test = SoundgasmProfileIE()
    # Check if URL is that of the webpage
    assert(test._match_id(webpage) == 'ytdl')
    # Get the webpage using the download_webpage method
    test._download_webpage(webpage, 'ytdl')
    # Look through the webpage using the regex to find all audio files
    assert(len(re.findall(r'href="([^"]+/u/ytdl/[^"]+)' , test.webpage_data)) > 0)
    # Create entries for each of the audio files

# Generated at 2022-06-26 12:45:50.471807
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    return SoundgasmIE().run()


# Generated at 2022-06-26 12:45:52.210373
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    x = SoundgasmIE()
    assert x.IE_NAME == 'soundgasm'



# Generated at 2022-06-26 12:45:54.306927
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .test_soundcloud import SoundcloudIE
    from .test_utils import check_extractor_classes
    check_extractor_classes(SoundcloudIE, 'SoundgasmProfileIE')

# Generated at 2022-06-26 12:45:56.278382
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from . import SoundgasmProfileIE
    from . import SoundgasmIE
    ie = SoundgasmProfileIE()
    #assert ie.instance_of(SoundgasmIE)

# Generated at 2022-06-26 12:46:05.738941
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Constructor of class SoundgasmIE
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:46:14.808821
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    TEST_DATA = {'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
                 'md5': '010082a2c802c5275bb00030743e75ad',
                 'info_dict': {'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9', 'ext': 'm4a', 
                               'title': 'Piano sample', 
                               'description': 'Royalty Free Sample Music',
                               'uploader': 'ytdl'}}
    ie = SoundgasmIE()
    assert ie.suitable(TEST_DATA['url'])
    assert ie._real_extract(TEST_DATA['url']) == TEST_DATA['info_dict']

# Generated at 2022-06-26 12:47:46.671573
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-26 12:47:52.889307
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    audio_url = 'https://s3.amazonaws.com/soundgasm/audio/original/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    display_id = 'Piano-sample'
    description = 'Royalty Free Sample Music'
    title = 'Piano sample'
    uploader = 'ytdl'

    # Get soundgasmIE
    soundgasmIE = SoundgasmIE()

    # Test audio_url

# Generated at 2022-06-26 12:47:55.387520
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    def test():
        ie = IE_NAME.construct_ie()
        ie.suitable('http://soundgasm.net/u/ytdl')
        ie.extract('http://soundgasm.net/u/ytdl')
    assert 'Soundgasm' in IE_NAME.construct_ie()._WORKING

# Generated at 2022-06-26 12:48:03.166589
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Mock downloader to return fixed html
    mock_downloader = InfoExtractor._downloader
    class MockDownloader(mock_downloader.__class__):
        """Mock downloader with fixed html"""
        def __init__(self, downloader):
            super(MockDownloader, self).__init__()
            self.filename = downloader.filename
            self.cache = downloader.cache
            self.params = downloader.params

        def to_screen(self, *args, **kargs):
            pass

        def to_stdout(self, *args, **kargs):
            pass

        def to_stderr(self, *args, **kargs):
            pass


# Generated at 2022-06-26 12:48:04.439380
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-26 12:48:10.500191
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    construct_class = globals()['SoundgasmProfileIE']
    construct_class.__name__ = 'Soundgasm'
    construct_class.test_info_dict = SoundgasmIE._TEST
    construct_class.test_url = SoundgasmIE._TEST['url']

    # Call superclass constructor
    SoundgasmIE.__init__(construct_class)

# Generated at 2022-06-26 12:48:17.841919
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	"""Test constructor of class SoundgasmProfileIE.
	"""

	# test case 1
	url = "http://soundgasm.net/u/ytdl"
	obj = SoundgasmProfileIE(url)

	assert obj.ie_name == "SoundgasmProfileIE"
	assert obj.valid_url(url)

	# test case 2
	url = "http://soundgasm.net/u/ytdl1233"
	obj = SoundgasmProfileIE(url)

	assert obj.ie_name == "SoundgasmProfileIE"
	assert obj.valid_url(url)

	# test case 3
	url = "http://soundgasm.net/u/ytdl#1233"
	obj = SoundgasmProfileIE(url)


# Generated at 2022-06-26 12:48:20.093178
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .test import make_test_ie_result
    assert make_test_ie_result(SoundgasmProfileIE, 'http://soundgasm.net/u/ytdl', 'Soundgasm')

# Generated at 2022-06-26 12:48:21.458478
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Unit test for the constructor of the soundgasmIE class
    testSoundgasm = SoundgasmIE()
    assert testSoundgasm != null

# Generated at 2022-06-26 12:48:21.892402
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE

# Generated at 2022-06-26 12:51:33.536170
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from . import test_constructor as tc
    tc.assert_constructor_works(SoundgasmProfileIE, 'http://soundgasm.net/u/ytdl')
    tc.assert_constructor_works(SoundgasmProfileIE, 'http://soundgasm.net/u/ytdl/')