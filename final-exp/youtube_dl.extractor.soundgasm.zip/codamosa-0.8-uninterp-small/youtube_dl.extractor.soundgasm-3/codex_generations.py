

# Generated at 2022-06-26 12:41:49.124470
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    # Check if object is initialized correctly
    assert soundgasm_i_e_0.IE_NAME == 'soundgasm'
    assert soundgasm_i_e_0._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:41:50.937706
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-26 12:41:53.151151
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()


# Generated at 2022-06-26 12:41:56.048774
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert isinstance(soundgasm_i_e_0, SoundgasmIE)
# This is a test of _real_extract function in class SoundgasmIE

# Generated at 2022-06-26 12:41:59.525661
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()


# Generated at 2022-06-26 12:42:01.642064
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()


# Generated at 2022-06-26 12:42:03.826760
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_ie_0 = SoundgasmIE()


# Generated at 2022-06-26 12:42:05.798256
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()


# Generated at 2022-06-26 12:42:18.094243
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    webpage = 'http://soundgasm.net/u/ytdl/Piano-sample'
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    display_id = 'Piano-sample'
    mobj = re.match(soundgasm_i_e_0._VALID_URL, url)
    try:
        audio_url = soundgasm_i_e_0._real_extract(webpage)['url']
    except:
        pass
    else:
        audio_id = soundgasm_i_e_0._search_regex(r'/([^/]+)\.m4a', audio_url, 'audio id', default=display_id)

# Generated at 2022-06-26 12:42:18.601792
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-26 12:42:25.100176
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profileIE = SoundgasmProfileIE()
    assert soundgasm_profileIE

# Generated at 2022-06-26 12:42:30.117843
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    This is a test for the constructor of class SoundgasmIE
    """
    # Test for invalid url
    invalid_url = 'http://www.soundgasm.net/test'
    # Should raise an error for an invalid url
    error = False
    try:
        SoundgasmIE(invalid_url)
    except:
        error = True
    assert error, 'Invalid url did not raise an error'


# Generated at 2022-06-26 12:42:34.298962
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test = SoundgasmProfileIE()
    assert test._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert test._TEST['playlist_count'] == 1

# Generated at 2022-06-26 12:42:40.184741
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj_class = SoundgasmIE(None)
    obj = obj_class()
    assert isinstance(obj, obj_class)
    assert isinstance(obj.IE_NAME, str)
    assert isinstance(obj._VALID_URL, str)
    assert isinstance(obj._TEST, dict)

# Generated at 2022-06-26 12:42:46.879005
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test constructor of class SoundgasmProfileIE
    assert SoundgasmProfileIE(SoundgasmIE)
    # Test constructor of class SoundgasmProfileIE with valid id
    assert SoundgasmProfileIE(SoundgasmIE, 'ytdl')
    # Test constructor of class SoundgasmProfileIE with invalid id
    assert not SoundgasmProfileIE(SoundgasmIE, 'InvalidID')
    # Test constructor of class SoundgasmProfileIE with empty id
    assert not SoundgasmProfileIE(SoundgasmIE, '')

# Generated at 2022-06-26 12:42:55.800448
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test that SoundgasmProfileIE uses the same constructor as InfoExtractor
    import types

    assert SoundgasmProfileIE.__init__ == InfoExtractor.__init__
    assert SoundgasmProfileIE.__doc__ == InfoExtractor.__doc__

    assert type(SoundgasmProfileIE.__init__) == types.FunctionType
    assert type(SoundgasmProfileIE.__doc__) == types.UnicodeType



# Generated at 2022-06-26 12:43:01.771923
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL
    assert ie._TEST
    assert ie._match_id
    assert ie._search_regex
    assert ie._download_webpage
    assert ie._html_search_regex
    assert ie._real_extract



# Generated at 2022-06-26 12:43:05.977732
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Test instantiation of SoundgasmProfileIE
    """
    IE = SoundgasmProfileIE('SoundgasmProfileIE')
    assert IE.ie_key() == 'SoundgasmProfileIE'
    assert IE.ie_name() == 'Soundgasm'
    assert IE.test() == {}

# Generated at 2022-06-26 12:43:08.529502
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    s = SoundgasmIE()
    assert(s != None)

# Generated at 2022-06-26 12:43:09.646773
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert (SoundgasmIE().IE_NAME == 'Soundgasm')


# Generated at 2022-06-26 12:43:24.851375
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    if __name__ == '__main__':
        a = SoundgasmProfileIE(SoundgasmIE(),'http://soundgasm.net/u/ytdl',{'id':'ytdl'})
        a.url_result(a._type(),'Soundgasm') # url_result is a method of InfoExtractor

# Generated at 2022-06-26 12:43:31.203282
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # test to see if SoundgasmProfileIE class is instantiated correctly
    se = SoundgasmProfileIE("SoundgasmProfileIE", "http://soundgasm.net/u/ytdl", {}, {}, {}, {})
    assert(se.display_id == "ytdl")

# Generated at 2022-06-26 12:43:40.205249
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    class ProfileIE(SoundgasmProfileIE):
        def _real_extract(self, url):
            profile_id = self._match_id(url)
            webpage = self._download_webpage(url, profile_id)

            entries = [
                self.url_result(audio_url, 'Soundgasm')
                for audio_url in re.findall(r'href="([^"]+/u/%s/[^"]+)' % profile_id, webpage)]

            return self.playlist_result(entries, profile_id)
    url = 'http://soundgasm.net/u/ytdl'
    ie = ProfileIE()
    assert ie.suitable(url) == True
    playlist = ie.extract(url)
    assert playlist['id'] == 'ytdl'

# Generated at 2022-06-26 12:43:41.311253
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-26 12:43:52.443633
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    result = SoundgasmIE()._real_extract(url)
    assert (result == {'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9', 'display_id': 'Piano-sample',
                       'url': 'https://d2xvxj0bffrbop.cloudfront.net/uploads/ytdl/Piano-sample.m4a',
                       'vcodec': 'none', 'title': 'Piano sample', 'description': 'Royalty Free Sample Music',
                       'uploader': 'ytdl'})


# Generated at 2022-06-26 12:43:57.777086
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE()
    assert ie._download_webpage is not None
    assert ie._extract_description is not None
    assert ie._extract_title is not None
    assert ie._extract_uploader is not None
    assert ie._match_id is not None
    m = SoundgasmIE._VALID_URL.match(url)
    assert m is not None, 'IE should validate this url'
    assert ie._TEST['url'] == url, 'IE should extract this url'

# Generated at 2022-06-26 12:44:02.170046
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE = SoundgasmIE()
    mobj = re.match(IE._VALID_URL, IE._TEST['url'])
    audio_url = IE._TEST['url']
    audio_id = IE._TEST['info_dict']['id']
    # Create a unit test for the private method "_download_webpage"
    webpage = IE._download_webpage(audio_url, audio_id)
    # Create a unit test for the private method "_html_search_regex"
    audio_url = IE._html_search_regex(
            r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', webpage,
            'audio URL', group='url')


# Generated at 2022-06-26 12:44:10.113660
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://www.soundgasm.net/u/ytdl/Piano-sample')
    assert ie._VALID_URL == re.compile(r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-26 12:44:14.471976
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == "Soundgasm"
    assert SoundgasmIE()._VALID_URL == "http://soundgasm.net/u/[^/]+/[^/]+"

# Generated at 2022-06-26 12:44:16.193437
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-26 12:44:33.302175
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE().IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-26 12:44:34.460552
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == "soundgasm"

# Generated at 2022-06-26 12:44:38.024028
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info_extractor = SoundgasmProfileIE()
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'
    assert(info_extractor._match_id(url) == profile_id)


# Generated at 2022-06-26 12:44:46.635851
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl',
                        'info_dict': {
                            'id': 'ytdl',
                        },
                        'playlist_count': 1}

# Generated at 2022-06-26 12:44:53.016606
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	print("\n\nAhmad-test_SoundgasmIE: Basic unit test for SoundgasmIE\n\n")
	test_url = "http://soundgasm.net/u/ytdl/Piano-sample"
	test_info = {"id":"88abd86ea000cafe98f96321b23cc1206cbcbcc9",
				"ext":"m4a",
				"title":"Piano sample",
				"description":"Royalty Free Sample Music",
				"uploader":"ytdl"}
	
	IE = SoundgasmIE()
	t_info = IE._real_extract(test_url)


# Generated at 2022-06-26 12:44:57.192748
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ydl = SoundgasmIE()
    print (ydl.ie_key())
    print(ydl.ie_key())

if __name__ == '__main__':
    test_SoundgasmIE()

# Generated at 2022-06-26 12:45:06.979992
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:45:08.543441
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert SoundgasmProfileIE('SoundgasmProfileIE', 'http://soundgasm.net/u/ytdl', {}) is not None

# Generated at 2022-06-26 12:45:14.838659
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
  x = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-26 12:45:19.005184
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    # Test for valid URL
    assert ie._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?"


# Generated at 2022-06-26 12:45:59.197411
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Testing for constructor
    obj = SoundgasmIE()
    assert repr(obj) == '<SoundgasmIE: http://soundgasm.net>'


# Generated at 2022-06-26 12:46:02.673384
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    f = SoundgasmProfileIE('ytdl', 'http://soundgasm.net/u/ytdl', 'Soundgasm')

# Generated at 2022-06-26 12:46:13.401577
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Test SoundgasmIE plugin.

    Use ytdl-testdata.soundgasm.net as the URL of the webpage to be downloaded.
    """
    SoundgasmIE._TEST = {
        'url': 'http://ytdl-testdata.soundgasm.net/u/ytdl/Piano-sample',
        'md5': '010082a2c802c5275bb00030743e75ad',
        'info_dict': {
            'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
            'ext': 'm4a',
            'title': 'Piano sample',
            'description': 'Royalty Free Sample Music',
            'uploader': 'ytdl',
        }
    }
    ie = SoundgasmIE()

# Generated at 2022-06-26 12:46:19.346443
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    assert sg.IE_NAME == "soundgasm"
    assert sg._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)"

# Generated at 2022-06-26 12:46:24.292095
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Test that Soundgasm profile constructor is working properly."""
    obj = SoundgasmProfileIE()

    assert obj.ie_key() == 'Soundgasm'
    assert obj.ie_name() == 'Soundgasm'
    assert obj.suitable('http://soundgasm.net/u/ytdl') == True
    return

# Generated at 2022-06-26 12:46:29.013704
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE_NAME = 'soundgasm'
    IE_DESC = 'Soundgasm.net audio website'
    VALID_URL = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE()
    ie.ie_name == IE_NAME
    ie.ie_desc == IE_DESC
    ie.valid_url == VALID_URL


# Generated at 2022-06-26 12:46:31.362611
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print(SoundgasmProfileIE()._real_extract("http://soundgasm.net/u/ytdl"))

# Generated at 2022-06-26 12:46:33.937485
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    t = SoundgasmProfileIE()
    assert t._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:46:37.494224
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	import soundgasm
	t = soundgasm.SoundgasmIE()
	assert(t._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')
	assert(t.IE_NAME == 'soundgasm')



# Generated at 2022-06-26 12:46:44.324975
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_ie = SoundgasmIE()
    assert soundgasm_ie.IE_NAME == 'soundgasm'
    assert soundgasm_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:48:23.551299
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-26 12:48:25.704836
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        test = SoundgasmProfileIE()
    except:
        print('Failed to construct a test instance of SoundgasmProfileIE')
        return
    print('SoundgasmProfileIE constructed successfully')


# Generated at 2022-06-26 12:48:33.602875
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest # Importing unittest to create unit tests.
    from .soundgasm import SoundgasmProfileIE # Importing class.
    import requests # Importing requests to interact with website.
    from bs4 import BeautifulSoup # Importing BeautifulSoup

    class SoundgasmProfileIETestCase(unittest.TestCase):
        def test_profile_page_link(self):
            test_instance = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
            self.assertEqual(test_instance._VALID_URL, 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')

        def test_profile_page_link2(self):
            test_instance = SoundgasmProfileIE

# Generated at 2022-06-26 12:48:41.100126
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_info = SoundgasmIE()._real_extract('%s/u/ytdl/Piano-sample' % SoundgasmIE._TEST['url'])

    assert(soundgasm_info['id'] == SoundgasmIE._TEST['info_dict']['id'])
    assert(soundgasm_info['title'] == SoundgasmIE._TEST['info_dict']['title'])
    assert(soundgasm_info['url'] == SoundgasmIE._TEST['info_dict']['url'])
    assert(soundgasm_info['uploader'] == SoundgasmIE._TEST['info_dict']['uploader'])
    assert(soundgasm_info['description'] == SoundgasmIE._TEST['info_dict']['description'])

# Generated at 2022-06-26 12:48:50.475046
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE.construct_soundgasm_profile('id')
    assert ie is not None
    expected = {
    	'_VALID_URL': 'https?://(?:www\.)?soundgasm\.net/u/id/?(?:#.*)?$',
    	'IE_NAME': 'soundgasm:profile',
    	'_TEST': {
    		'url': 'http://soundgasm.net/u/id',
    		'info_dict': {
    			'id': 'id',
    		},
    		'playlist_count': 1,
    	}
    }
    for key, value in expected.items():
        assert getattr(ie, key) == value

# Generated at 2022-06-26 12:48:52.251149
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-26 12:48:55.686684
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert SoundgasmIE().extract(url)['id'] == audio_id

# Generated at 2022-06-26 12:48:56.162634
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-26 12:48:57.128312
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie is not None

# Generated at 2022-06-26 12:49:01.161353
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("Unit test for SoundGasmIE")
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    # Simulating unit test calling of the extract method of SoundGasmIE
    SoundgasmIE()._real_extract(url)
