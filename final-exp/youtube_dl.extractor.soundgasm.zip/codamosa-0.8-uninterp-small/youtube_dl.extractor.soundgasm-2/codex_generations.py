

# Generated at 2022-06-26 12:41:46.702825
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-26 12:41:48.956332
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e = SoundgasmProfileIE()

# Generated at 2022-06-26 12:41:50.706895
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass


# Generated at 2022-06-26 12:41:52.303520
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None,None,None)

# Generated at 2022-06-26 12:41:55.350207
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg_profile_ie = SoundgasmProfileIE()
    assert sg_profile_ie is not None


# Generated at 2022-06-26 12:42:00.593896
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # soundgasm_i_e_0 = SoundgasmIE()

    # This will cause an exception.
    # assert soundgasm_i_e_0.test() == 'test'
    return


# Generated at 2022-06-26 12:42:05.087039
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    Tests = unittest.TestLoader().loadTestsFromTestCase(TestSoundgasmIE)
    unittest.TextTestRunner(verbosity=2).run(Tests)


# Generated at 2022-06-26 12:42:11.555695
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SOUNDGASM_URL = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SOUNDGASM_ID = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    soundgasm_i_e = SoundgasmIE()
    assert(soundgasm_i_e.suitable(SOUNDGASM_URL))
    assert(soundgasm_i_e.IE_NAME == 'soundgasm')
    if(soundgasm_i_e.suitable(SOUNDGASM_URL)):
        soundgasm_i_e.extract(SOUNDGASM_URL)
        assert(soundgasm_i_e._downloader.params['outtmpl'] == '%(id)s')

# Generated at 2022-06-26 12:42:14.583986
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE().to_screen('http://soundgasm.net/u/ytdl/Piano-sample')
    

# Generated at 2022-06-26 12:42:16.361868
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e = SoundgasmProfileIE()

# Generated at 2022-06-26 12:42:22.915723
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.VALID_URL
    assert ie.get_url()
    assert ie.get_id()
    ie._real_initialize()
    assert ie.playlist_result()
    assert ie._real_extract()
    assert ie.playlist_count

# Generated at 2022-06-26 12:42:26.154616
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
  url = 'http://soundgasm.net/u/ytdl/Piano-sample'
  # Should correctly create an instance of SoundgasmIE
  inst = SoundgasmIE(url)
  # Should correctly set the _VALID_URL
  assert inst._VALID_URL == SoundgasmIE._VALID_URL
  # Should correctly set the _TEST
  assert inst._TEST == SoundgasmIE._TEST
  # Should correctly set the IE_NAME
  assert inst.IE_NAME == SoundgasmIE.IE_NAME

# Generated at 2022-06-26 12:42:28.498912
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert 'SoundgasmProfileIE' == SoundgasmProfileIE.IE_NAME
    assert 'http://soundgasm.net/u/ytdl' == SoundgasmProfileIE.VALID_URL


# Generated at 2022-06-26 12:42:39.568825
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import unescapeHTML

    SoundgasmProfileIE.IE_NAME = 'soundgasm'
    SoundgasmProfileIE._VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    SoundgasmProfileIE._TEST = {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    
    ydl = YoutubeDL({'youtube_include_dash_manifest': True})
    


# Generated at 2022-06-26 12:42:46.339167
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == "soundgasm:profile"
    assert ie._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$"
    assert ie._TEST["url"] == "http://soundgasm.net/u/ytdl"
    assert ie._TEST["info_dict"]["id"] == "ytdl"
    assert ie._TEST["playlist_count"] == 1

# Generated at 2022-06-26 12:42:53.771242
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Unit test of constructor of class SoundgasmProfileIE
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:42:57.777000
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    assert obj._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)"

# Generated at 2022-06-26 12:43:07.817379
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    expectedTitle = 'Piano sample'
    expectedUser = 'ytdl'
    instance = SoundgasmIE(url)
    id = instance._match_id(url)
    title = SoundgasmIE._search_regex(SoundgasmIE._VALID_URL, url, 'title', default=id)
    user = SoundgasmIE._search_regex(SoundgasmIE._VALID_URL, url, 'user', default=id)
    assert(instance._TEST['url'] == url)
    assert(expectedTitle == title)
    assert(expectedUser == user)


# Generated at 2022-06-26 12:43:17.844329
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    className = SoundgasmIE.__name__
    obj = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:43:23.354022
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    for url in ('http://soundgasm.net/u/ytdl',
                'http://soundgasm.net/u/ytdl/',
                ):
        assert SoundgasmProfileIE._match_id(url) == 'ytdl'

# Generated at 2022-06-26 12:43:34.796592
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	print('\n\n Unit test for constructor of class SoundgasmProfileIE')
	url = 'http://soundgasm.net/u/ytdl'
	SoundgasmProfileIE(url)


# Generated at 2022-06-26 12:43:37.694207
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from unittest import TestCase

    with TestCase().assertRaises(AttributeError):
        SoundgasmProfileIE().__init__()

# Generated at 2022-06-26 12:43:40.135154
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    g = SoundgasmProfileIE()
    assert g.__class__.__name__ == 'SoundgasmProfileIE'

# Generated at 2022-06-26 12:43:43.528334
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = SoundgasmIE._VALID_URL
    obj = SoundgasmIE(url)
    assert re.match(url, obj._VALID_URL)


# Generated at 2022-06-26 12:43:44.299997
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert True

# Generated at 2022-06-26 12:43:47.993763
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        soundgasm_profile_IE = SoundgasmProfileIE()
    except:
        assert False



# Generated at 2022-06-26 12:43:51.895686
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(SoundgasmProfileIE.IE_NAME, SoundgasmProfileIE._VALID_URL).extract('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-26 12:43:58.976462
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE(url)

    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-26 12:44:09.143363
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert SoundgasmProfileIE._TEST[0] == 'url'
	assert SoundgasmProfileIE._TEST[1] == 'http://soundgasm.net/u/ytdl'
	assert SoundgasmProfileIE._TEST[2] == 'info_dict'
	assert SoundgasmProfileIE._TEST[3][0] == 'id'
	assert SoundgasmProfileIE._TEST[3][1] == 'ytdl'
	assert SoundgasmProfileIE._TEST[4] == 'playlist_count'
	assert SoundgasmProfileIE._TEST[5] == 1
	assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'



# Generated at 2022-06-26 12:44:14.427098
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('soundgasm:profile')
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:44:30.858296
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')


# Generated at 2022-06-26 12:44:38.260798
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie.ie_key() == 'Soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:44:48.843137
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        from .common import _sort_formats
    except ImportError:
        from .common import _sort_formats
    try:
        from .common import _test_playlist
    except ImportError:
        from .common import _test_playlist
    try:
        from .common import _test_playlist_result
    except ImportError:
        from .common import _test_playlist_result
    try:
        from .common import _test_url_result
    except ImportError:
        from .common import _test_url_result
    try:
        from .common import parse_duration
    except ImportError:
        from .common import parse_duration
    try:
        from .common import parse_iso8601
    except ImportError:
        from .common import parse_iso8601

# Generated at 2022-06-26 12:44:49.438405
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE(None, None)

# Generated at 2022-06-26 12:44:50.181647
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-26 12:44:54.462072
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE._VALID_URL == [
        re.compile(r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')
    ]


# Generated at 2022-06-26 12:45:05.006642
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # my_object_1: instantiate SoundgasmIE with url.
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    # my_object_2: instantiate SoundgasmIE with url.
    url1 = "http://soundgasm.net/u/ytdl/Piano-sample"
    my_object_1 = SoundgasmIE(url)
    # my_object_1: return the URL of the video of the instantiated object.
    assert my_object_1.url == url
    # my_object_2: return the URL of the video of the instantiated object.
    my_object_2 = SoundgasmIE(url1)
    assert my_object_2.url == url1
    # my_object_1: instantiated object returns a URL.


# Generated at 2022-06-26 12:45:09.891742
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE_NAME = 'soundgasm:profile'
    _VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    _TEST = {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }






# Generated at 2022-06-26 12:45:12.490393
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    ie.download('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-26 12:45:14.568554
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    w = SoundgasmIE()
    assert w is not None

if __name__ == '__main__':
    test_SoundgasmIE()

# Generated at 2022-06-26 12:45:57.383788
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE()._real_extract(url)


# Generated at 2022-06-26 12:46:03.021123
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-26 12:46:03.847789
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-26 12:46:11.152472
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    check_IE = SoundgasmProfileIE()
    content = "Soundgasm.net is a royalty free music sharing website."
    assert check_IE._match_id(content) == 'ytdl'
    assert check_IE._search_regex(r'(?s)href="([^"]+/u/ytdl/[^"]+)', content, 'Soundgasm') == ['/u/ytdl/Piano-sample']

# Generated at 2022-06-26 12:46:17.253324
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from soundgasm import SoundgasmProfileIE
    from utils import url_basename
    url = 'http://soundgasm.net/u/ytdl'
    audio = SoundgasmProfileIE()._real_extract(url)
    assert audio['_type'] == 'playlist'
    # Make sure that the playlist contains the url.
    audio_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert audio_url in audio['entries'][0]
    assert url_basename(audio['entries'][0]) == 'Piano-sample'
    assert audio['id'] == 'ytdl'

# Generated at 2022-06-26 12:46:18.484493
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE()

    assert profile is not None

# Generated at 2022-06-26 12:46:23.785178
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_ie = SoundgasmIE()
    assert soundgasm_ie.IE_NAME == 'soundgasm'
    assert soundgasm_ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:46:26.324223
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie_obj = SoundgasmIE('MD5')
    assert ie_obj.ie_key() == 'Soundgasm'


# Generated at 2022-06-26 12:46:30.500177
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    # Check if the constructor of SoundgasmIE works without a problem
    # Through this test, check if there is a wrong project setting

    # test object
    test = SoundgasmIE()

    # Check if test object is instance of SoundgasmIE
    assert isinstance(test, SoundgasmIE)


# Generated at 2022-06-26 12:46:30.997175
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-26 12:48:12.758786
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	# SoundgasmProfileIE(InfoExtractor):
	pass

# Generated at 2022-06-26 12:48:14.884968
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE.IE_NAME == 'soundgasm:profile')
    assert(SoundgasmProfileIE.IE_DESC == 'Soundgasm Profile')


# Generated at 2022-06-26 12:48:19.588505
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Constructor of class SoundgasmIE
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie.VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:48:20.719992
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    newSoundgasmIE = SoundgasmIE()
    print(newSoundgasmIE.IE_NAME)

# Generated at 2022-06-26 12:48:26.918004
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    
    # For class SoundgasmIE
    InfoExtractor.col = getattr(sys.modules['__main__'], 'col', None)
    entry = SoundgasmIE('http://soundgasm.net/u/ytdl')._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-26 12:48:28.141949
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # class SoundgasmProfileIE(InfoExtractor):
    assert SoundgasmProfileIE._VALID_URL

# Generated at 2022-06-26 12:48:32.987414
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    test_SoundgasmIE.assertEqual(obj.IE_NAME, 'SoundgasmIE')
    test_SoundgasmIE.assertEqual(obj.VALID_URL, 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-26 12:48:35.503965
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    #Given a url representing SoundgasmProfileIE
    url = 'http://soundgasm.net/u/ytdl'
    inst = SoundgasmProfileIE(url)
    #Then We expect profile_id to be ytdl
    assert inst.profile_id == 'ytdl'

# Generated at 2022-06-26 12:48:36.548412
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()


# Generated at 2022-06-26 12:48:44.736999
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # the fields of the test object  instantiated from SoundgasmIE
    fields_test_obj = [
        'url',
        '_type',
        'ie_key',
        'title',
        'id',
        'ext',
        'uploader',
        'uploader_id',
        'thumbnail',
        'description',
        'categories',
        'subtitles',
        'automatic_captions',
        'duration',
        'age_limit',
        'annotations',
        'chapters',
        'webpage_url',
        'view_count',
        'like_count',
        'average_rating',
        'formats',
        'is_live',
    ]

    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'