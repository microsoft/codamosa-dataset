

# Generated at 2022-06-26 12:41:41.188381
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_p_e = SoundgasmProfileIE()


# Generated at 2022-06-26 12:41:47.806387
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = SoundgasmIE._TEST
    soundgasm_i_e_ = SoundgasmIE()
    webpage = soundgasm_i_e_._download_webpage(url, 'Piano-sample')
    audio_url = soundgasm_i_e_._html_search_regex(r'm4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', webpage, 'audio URL', group='url')


# Generated at 2022-06-26 12:41:51.465313
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        test_case_0()
    except Exception as e:
        assert(e.message == 'please implement test case')

# Generated at 2022-06-26 12:41:53.686499
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e = SoundgasmProfileIE()



# Generated at 2022-06-26 12:41:59.625171
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert_equals(soundgasm_i_e_0.IE_NAME, 'SoundgasmIE')
    assert_equals(soundgasm_i_e_0.__module__, 'YoutubeDL.extractor.generic.SoundgasmIE')
    assert_equals(soundgasm_i_e_0._VALID_URL, '^https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)$')

# Generated at 2022-06-26 12:42:01.704668
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()

# Generated at 2022-06-26 12:42:04.420462
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()


# Generated at 2022-06-26 12:42:08.859459
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert_equals(SoundgasmIE()._VALID_URL, 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')
    assert_equals(SoundgasmIE().IE_NAME, 'soundgasm')


# Generated at 2022-06-26 12:42:09.635989
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()


# Generated at 2022-06-26 12:42:11.026302
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()


# Generated at 2022-06-26 12:42:20.616410
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e = SoundgasmIE()


# Generated at 2022-06-26 12:42:21.884610
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_1 = SoundgasmIE()
    assert_equals()


# Generated at 2022-06-26 12:42:22.453232
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert_raises(Exception, SoundgasmProfileIE)

# Generated at 2022-06-26 12:42:31.828016
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    (test_cases_mapping_0) = [{
        0:
            {
                'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
                'md5': '010082a2c802c5275bb00030743e75ad',
                'info_dict': {
                    'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
                    'ext': 'm4a',
                    'title': 'Piano sample',
                    'description': 'Royalty Free Sample Music',
                    'uploader': 'ytdl',
                },
            }
    }]

# Generated at 2022-06-26 12:42:34.322394
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Verify that constructor and call of SoundgasmIE.suitable() is successful
    assert SoundgasmIE().suitable(SoundgasmIE._VALID_URL)

    # Verify that constructor and call of SoundgasmIE.extract() is successful
    assert SoundgasmIE().extract(SoundgasmIE._TEST['url'])


# Generated at 2022-06-26 12:42:40.183688
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e = SoundgasmIE()
    assert soundgasm_i_e.IE_NAME == 'soundgasm'
    assert type(soundgasm_i_e.IE_NAME) is str
    assert not hasattr(soundgasm_i_e, '_downloader')


# Generated at 2022-06-26 12:42:41.535455
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e = SoundgasmIE()


# Generated at 2022-06-26 12:42:43.168761
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()

# Generated at 2022-06-26 12:42:48.447883
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    audio_url = 'http://soundgasm.net/u/somebody/Piano_sample'
    webpage = '<div><a href="http://soundgasm.net/u/somebody/Piano_sample">'
    entries = [
        SoundgasmIE().url_result(audio_url, 'Soundgasm')
        for audio_url in re.findall(r'href="([^"]+/u/somebody/[^"]+)', webpage)]

    PlaylistResult = {'id': 'somebody', 'entries': entries}
    assert PlaylistResult == SoundgasmProfileIE().playlist_result(entries, profile_id)

# Generated at 2022-06-26 12:42:49.676132
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass

# Generated at 2022-06-26 12:43:08.510874
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ex = SoundgasmIE()
    assert ex.IE_NAME == 'soundgasm'
    assert ex._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:43:13.370322
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-26 12:43:18.444417
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    class OptDict(dict):
        def __init__(self, *args, **kwargs):
            super(OptDict, self).__init__(*args, **kwargs)
            self.test_result = True

    ydl_opts = OptDict()
    ydl_opts.username = 'ytdl'
    profile_url = 'http://soundgasm.net/u/ytdl'
    soundgasm_ie = SoundgasmProfileIE()
    playlist = soundgasm_ie.extract(ydl_opts, profile_url)

# Generated at 2022-06-26 12:43:25.895721
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	test_url = 'https://soundgasm.net/u/BrianaLeeOnline/Foot-Fetish-Footjob'
	test_obj = SoundgasmIE()
	# test_obj._real_extract(test_url)

# Generated at 2022-06-26 12:43:31.923319
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    x = SoundgasmProfileIE()
    assert(x._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')

# Generated at 2022-06-26 12:43:40.510963
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    audio_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    display_id = 'Piano-sample'

    sg_info = SoundgasmIE()._real_extract(url)

    assert (sg_info['id'] == audio_id)
    assert (sg_info['display_id'] == display_id)
    assert (sg_info['url'] == 'http://d1bjlm9dp57w71.cloudfront.net/u/ytdl/Piano-sample.m4a')
    assert (sg_info['vcodec'] == 'none')
    assert (sg_info['title'] == display_id)

# Generated at 2022-06-26 12:43:42.399025
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    error = 0
    try:
        e = SoundgasmProfileIE()  # noqa
    except:
        error = 1
    assert(error == 0)



# Generated at 2022-06-26 12:43:53.153764
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    
    # test for the constructor of SoundgasmProfileIE
    assert SoundgasmProfileIE.__name__ == 'SoundgasmProfileIE'
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    
    # test for class valid URL
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    
    # test for class test
    assert SoundgasmProfileIE._TEST['url'] == 'http://soundgasm.net/u/ytdl'

# Generated at 2022-06-26 12:43:53.507635
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	pass

# Generated at 2022-06-26 12:43:56.602448
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test1 = SoundgasmProfileIE('youtube-dl','http://soundgasm.net/u/ytdl', {})

# Generated at 2022-06-26 12:44:14.571121
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasmProfile = SoundgasmProfileIE()
    assert soundgasmProfile != None


# Generated at 2022-06-26 12:44:17.060205
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-26 12:44:22.635742
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        class TestSoundgasmIE(SoundgasmIE):
            def _download_webpage(self, *args, **kwargs):
                return args[1]
    except SyntaxError:
        pass  # Python 2.x
    # Python 3.x
    assert TestSoundgasmIE(SoundgasmIE.ie_key())._real_extract("test") == "test"



# Generated at 2022-06-26 12:44:23.512573
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-26 12:44:28.635951
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.suitable('http://soundgasm.net/u/ytdl')
    assert not ie.suitable('http://soundgasm.net/u/ytdl/i_am_happy')
    assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-26 12:44:36.395107
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    sg = SoundgasmIE()

    assert sg._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert sg._TEST['url'] == url
    assert sg._TEST['info_dict']['title'] == 'Piano sample'
    assert sg._TEST['info_dict']['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'


# Generated at 2022-06-26 12:44:38.785544
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_variable = 'https://soundgasm.net/u/ytdl/'
    assert re.match(SoundgasmProfileIE._VALID_URL, test_variable) == None

# Generated at 2022-06-26 12:44:42.371512
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie_obj = SoundgasmIE('http://www.soundgasm.net/u/ytdl/Piano-sample')
    assert isinstance(ie_obj, SoundgasmIE)


# Generated at 2022-06-26 12:44:47.863569
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Arrange
    expected_url = 'http://soundgasm.net/u/ytdl/Piano-sample'

    # Act
    soundgasm = SoundgasmIE(expected_url)

    # Assert
    assert soundgasm.url == expected_url
    assert soundgasm.audio_id == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-26 12:44:49.121610
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE().IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-26 12:45:36.262164
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    # Test that Video id is extracted
    audio_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    audio_info = ie.extract(audio_url)
    assert audio_info['id'] == 'Piano-sample'
    # Test that Video title is extracted
    assert audio_info['title'] == 'Piano sample'
    # Test that Video uploader is extracted
    assert audio_info['uploader'] == 'ytdl'
    # Test that Video description is extracted
    assert audio_info['description'] == 'Royalty Free Sample Music'
    # Test that Video url is extracted

# Generated at 2022-06-26 12:45:37.636185
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# test the constructor
    main_test = SoundgasmIE()
    assert main_test != None
    print('Constructor of class SoundgasmIE tested')


# Generated at 2022-06-26 12:45:38.721312
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE()

# Generated at 2022-06-26 12:45:41.538331
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    ie.extract()
    #assert_raises(RegexNotFoundError, SoundgasmProfileIE, 'http://soundgasm.net/u/ytdl/wrong')

# Generated at 2022-06-26 12:45:44.278313
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('http://soundgasm.net/u/ytdl', {'username': 'ytdl'})

# Generated at 2022-06-26 12:45:48.278355
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        obj = SoundgasmProfileIE('https://www.soundgasm.net/u/ytdl/')
    except:
        assert False, 'An exception occurred creating the object'
    if not isinstance(obj, InfoExtractor):
        assert False, 'It is not an instance of InfoExtractor'
    return obj


# Generated at 2022-06-26 12:45:50.965934
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(None, 'http://soundgasm.net/u/ytdl', 'Soundgasm')
    assert ie.IE_NAME == 'Soundgasm'


# Generated at 2022-06-26 12:45:53.971633
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = "http://soundgasm.net/u/ytdl"
    soundgasm_profile = SoundgasmProfileIE()
    print(soundgasm_profile._real_extract(url)['entries'])



# Generated at 2022-06-26 12:45:56.993309
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE(u'http://www.soundgasm.net/u/ytdl', u'soundgasm:profile')
    assert a.user == u'ytdl'
    assert a.url_name == u'http://www.soundgasm.net/u/ytdl'



# Generated at 2022-06-26 12:45:58.355594
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().test('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-26 12:47:24.349392
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # TODO: Use mock to test this
    # http://saravanan-kuppusamy.blogspot.com.br/2014/07/mocking-explained-with-python-examples.html
    pass

# Generated at 2022-06-26 12:47:32.300370
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class_ = SoundgasmIE
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'

    # Test cases for SoundgasmIE

# Generated at 2022-06-26 12:47:33.133178
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test = SoundgasmProfileIE()




# Generated at 2022-06-26 12:47:33.571593
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-26 12:47:36.933070
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE = SoundgasmProfileIE()
    assert IE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert IE._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-26 12:47:39.239286
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert re.match(r'http://soundgasm\.net/u/[0-9a-zA-Z_-]+/Piano-sample', ie.construct_url(ie._TEST['url']))

# Generated at 2022-06-26 12:47:40.021916
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    inst = SoundgasmProfileIE("SoundgasmProfileIE", {})

# Generated at 2022-06-26 12:47:47.340426
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# Test 1
	sg_ie = SoundgasmIE()
	url1 = "http://soundgasm.net/u/ytdl/Piano-sample"
	expected_id1 = "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
	expected_title1 = "Piano sample"
	expected_uploader1 = "ytdl"
	expected_description1 = "Royalty Free Sample Music"
	expected_url1 = "http://soundgasm.net/u/ytdl/Piano-sample.m4a"
	expected_ext1 = "m4a"
	# Check whether we can match the url
	assert sg_ie._VALID_URL == re.match(sg_ie._VALID_URL,url1).re
	# Check whether the

# Generated at 2022-06-26 12:47:49.206024
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Check if SoundgasmProfileIE can be constructed with URL as parameter
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')


# Generated at 2022-06-26 12:47:50.302612
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test creating SoundgasmProfileIE instance
    SoundgasmProfileIE()


# Generated at 2022-06-26 12:51:11.060905
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    text = '''<audio src="/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a?sha1=8rq3rTvCgDz2lfBKjX8W7ZiRvbs&amp
;expires=1426758740" preload="none" />'''
    result = SoundgasmIE.from_html(text)
    assert result.id == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-26 12:51:12.005572
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    #Doesnt work because of a issue with the soundgasm website
    assert True

# Generated at 2022-06-26 12:51:17.178543
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE(None)._VALID_URL == SoundgasmIE._VALID_URL
    assert SoundgasmIE(None)._TEST == SoundgasmIE._TEST
    assert SoundgasmIE(None)._TEST['url'] == SoundgasmIE._TEST['url']
    assert SoundgasmIE(None)._TEST['md5'] == SoundgasmIE._TEST['md5']
    assert SoundgasmIE(None)._TEST['info_dict'] == SoundgasmIE._TEST['info_dict']


# Generated at 2022-06-26 12:51:19.693715
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sound = SoundgasmIE(None)
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    sound._real_extract(url)


# Generated at 2022-06-26 12:51:24.274391
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	sgIE = SoundgasmIE()
	if sgIE._VALID_URL != re.compile(sgIE._VALID_URL).pattern:
		raise Exception("Regular exp failed: %s" % sgIE._VALID_URL)
	if sgIE.IE_NAME != sgIE.IE_NAME:
		raise Exception("Constructor for SoundgasmIE failed")

# Generated at 2022-06-26 12:51:25.286726
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	ie = SoundgasmIE()

# Generated at 2022-06-26 12:51:32.449175
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# Make sure that the class has been made correctly
	assert SoundgasmIE.IE_NAME == 'soundgasm'
	assert SoundgasmIE.VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'