

# Generated at 2022-06-26 12:41:36.803160
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e = SoundgasmIE()

# Generated at 2022-06-26 12:41:39.224546
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_0 = SoundgasmIE()


# Generated at 2022-06-26 12:41:40.123400
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-26 12:41:42.223040
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e = SoundgasmIE()


# Generated at 2022-06-26 12:41:43.964333
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()



# Generated at 2022-06-26 12:41:45.407625
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert isinstance(SoundgasmProfileIE(), InfoExtractor)


# Generated at 2022-06-26 12:41:47.211504
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e = SoundgasmProfileIE()


# Generated at 2022-06-26 12:41:50.394400
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE()
    except Exception as e:
        print(e)


# Generated at 2022-06-26 12:41:52.614128
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()

# Generated at 2022-06-26 12:41:56.071716
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e = SoundgasmIE()
    assert soundgasm_i_e.suitable("http://soundgasm.net/u/ytdl/Piano-sample")


# Generated at 2022-06-26 12:42:04.727339
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e = SoundgasmProfileIE()



# Generated at 2022-06-26 12:42:05.472723
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sndgam_i_e_0 = SoundgasmIE()


# Generated at 2022-06-26 12:42:07.689368
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()
    result = soundgasm_profile_i_e_0.suitable(url)
    expected = True
    assert result == expected
    # TODO: Implement further tests

if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-26 12:42:09.647836
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-26 12:42:11.793654
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e = SoundgasmIE()


# Generated at 2022-06-26 12:42:13.172809
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-26 12:42:17.070190
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    mobj_0 = re.match(SoundgasmProfileIE._VALID_URL, 'http://soundgasm.net/u/ytdl/Piano-sample')
    assert mobj_0 is None
    test_case_0()

# Generated at 2022-06-26 12:42:18.946487
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert soundgasm_profile_i_e_0 != -1


# Generated at 2022-06-26 12:42:29.454774
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert re.match(SoundgasmIE._VALID_URL, 'http://soundgasm.net/u/ytdl/Piano-sample') != None
    assert SoundgasmIE._TEST == {'url': 'http://soundgasm.net/u/ytdl/Piano-sample', 'md5': '010082a2c802c5275bb00030743e75ad', 'info_dict': {'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9', 'ext': 'm4a', 'title': 'Piano sample', 'description': 'Royalty Free Sample Music', 'uploader': 'ytdl'}}


# Generated at 2022-06-26 12:42:30.763422
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e = SoundgasmProfileIE()



# Generated at 2022-06-26 12:42:41.314958
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE().extract(url)


# Generated at 2022-06-26 12:42:46.487386
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	"""
	Test class constructor
	"""
	soundgasm = SoundgasmIE()
	assert soundgasm.ie_name == SoundgasmIE.IE_NAME
	assert soundgasm.ie_key == SoundgasmIE.IE_NAME
	assert soundgasm.cause_str == 'Unknown cause'
	assert soundgasm.errmsg == 'Unspecified error'


# Generated at 2022-06-26 12:42:58.641911
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie.IE_DESC == 'Soundgasm'

# Generated at 2022-06-26 12:42:59.640459
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-26 12:43:05.458953
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:43:08.529908
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info_extractor = SoundgasmProfileIE()
    print(info_extractor)


# Generated at 2022-06-26 12:43:18.082700
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test 1
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'
    webpage = '<html><body><div>' + '<a href="/u/ytdl/1"></a>' + '<a href="/u/ytdl/2"></a>' + '</div></body></html>'
    entries = [
        'http://soundgasm.net/u/ytdl/1',
        'http://soundgasm.net/u/ytdl/2']

    # Test 1.1
    assert SoundgasmProfileIE._match_id(url) == profile_id

    # Test 1.2
    assert SoundgasmProfileIE._download_webpage(url, profile_id) == webpage

    # Test 1.3

# Generated at 2022-06-26 12:43:29.167958
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # SoundgasmProfileIE(InfoExtractor)
    SoundgasmProfileIE(InfoExtractor()).to_screen()
    # SoundgasmProfileIE.suitable(url)
    assert SoundgasmProfileIE.suitable('http://soundgasm.net/u/ytdl')
    assert not SoundgasmProfileIE.suitable('http://soundgasm.net/u/ytdl/Piano-sample')
    assert not SoundgasmProfileIE.suitable('http://soundgasm.net/u/ytdl/Piano-sample#')
    assert not SoundgasmProfileIE.suitable('http://soundgasm.net')
    # SoundgasmProfileIE._real_extract()

# Generated at 2022-06-26 12:43:31.924244
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	test_obj = SoundgasmProfileIE()
# test_SoundgasmProfileIE()


# Generated at 2022-06-26 12:43:33.868175
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    check_for_ie(SoundgasmProfileIE.name)


# Generated at 2022-06-26 12:43:53.355902
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    t_soundgasmie = SoundgasmIE()
    t_soundgasmie.IE_NAME
    t_soundgasmie._VALID_URL
    t_soundgasmie._TEST

# Generated at 2022-06-26 12:43:55.577386
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test constructor of SoundgasmIE
    assert SoundgasmIE

# Generated at 2022-06-26 12:44:00.330968
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    playlist_url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE(playlist_url)
    assert ie.display_id == 'ytdl'

# Generated at 2022-06-26 12:44:04.061098
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE(SoundgasmProfileIE.ie_key(), SoundgasmProfileIE.test_urls[0])

# Generated at 2022-06-26 12:44:04.653737
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	pass

# Generated at 2022-06-26 12:44:05.504665
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE('Soundgasm')

# Generated at 2022-06-26 12:44:14.624296
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # http://soundgasm.net/u/ytdl/Piano-sample
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    soundgasm = SoundgasmIE()
    print("test_SoundgasmIE: url=%s" % url)
    result = soundgasm.url_result(url)
    print("test_SoundgasmIE: result=%s" % result)

# Generated at 2022-06-26 12:44:16.006825
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl")

# Generated at 2022-06-26 12:44:21.063837
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    WL_ID = 'ytdl'
    url = 'https://soundgasm.net/u/ytdl/'
    obj = SoundgasmProfileIE()
    # Unit test for
    # _match_id(self,url):
    id = obj._match_id(url)
    assert id == WL_ID

test_SoundgasmProfileIE()

# Generated at 2022-06-26 12:44:22.948385
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE(None).IE_NAME == 'soundgasm'


# Generated at 2022-06-26 12:45:03.550969
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    audio_url = 'http://d1o29p8ksg1i5l.cloudfront.net/audios/b/e/b/bebfb7cd0d41939e6f77a804069a0130c9ae9e22/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'

    ie = SoundgasmIE()
    info_dict = ie.extract(url)
    assert info_dict['title'] == 'Piano sample'
    assert info_dict['url'] == audio_url

# Generated at 2022-06-26 12:45:06.005820
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	url = "http://soundgasm.net/u/ytdl/Piano-sample"
	ie = SoundgasmIE()

# Generated at 2022-06-26 12:45:08.821834
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmProfileIE()._download_webpage("http://soundgasm.net/u/ytdl", "ytdl")
    SoundgasmIE()._download_webpage("http://soundgasm.net/u/ytdl/Piano-sample", "Piano-sample")

# Generated at 2022-06-26 12:45:09.588696
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()

# Generated at 2022-06-26 12:45:12.102879
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# Create a SoundgasmIE instance with URL and display_id
	soundgasm_ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample', 'Piano-sample')
	# Check if an object is created
	assert SoundgasmIE

# Generated at 2022-06-26 12:45:13.118101
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert True==True

# Generated at 2022-06-26 12:45:16.193963
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Test case for SoundgasmProfileIE"""

# Generated at 2022-06-26 12:45:21.940563
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    inst = SoundgasmProfileIE('')
    assert isinstance(inst, InfoExtractor)
    assert inst.IE_NAME == 'soundgasm:profile'
    assert inst.suitable('http://soundgasm.net/u/ytdl')
    assert inst.suitable('http://soundgasm.net/u/ytdl/')
    assert not inst.suitable('foo')


# Generated at 2022-06-26 12:45:30.364204
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
		from SoundgasmProfileIE import SoundgasmProfileIE	
		test_url = "http://soundgasm.net/u/ytdl"
		test_obj = SoundgasmProfileIE(test_url)
		assert (test_obj.IE_NAME == "soundgasm:profile")
		assert (test_obj._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$")
		assert (test_obj.IE_DESC == "soundgasm.net profiles")
		assert (test_obj._TEST["url"] == "http://soundgasm.net/u/ytdl")

# Generated at 2022-06-26 12:45:35.133032
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-26 12:46:52.647790
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-26 12:46:54.533081
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Test code for constructor of class SoundgasmProfileIE
if __name__ == '__main__':
    test_SoundgasmProfileIE()

# Generated at 2022-06-26 12:46:58.795797
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    url_IE_Soundgasm = SoundgasmIE(PornoRevealIE.IE_NAME)._real_extract(test_url)

    assert url_IE_Soundgasm is not None
    assert url_IE_Soundgasm.title is not None
    assert url_IE_Soundgasm.description is not None
    assert url_IE_Soundgasm.id is not None
    assert url_IE_Soundgasm.display_id is not None
    assert url_IE_Soundgasm.url is not None
    assert url_IE_Soundgasm.vcodec is not None


# Generated at 2022-06-26 12:47:05.220959
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE(None).IE_NAME == 'soundgasm'
    assert SoundgasmIE(None)._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:47:05.704997
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_SoundgasmIE = SoundgasmIE()

# Generated at 2022-06-26 12:47:06.184244
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE._VALID_URL

# Generated at 2022-06-26 12:47:08.799574
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert obj.url == 'http://soundgasm.net/u/ytdl'
    assert obj.profile_id == 'ytdl'
    assert obj.ie_name == 'soundgasm:profile'
    assert obj.display_id == 'ytdl'
    assert obj.webpage_url == 'http://soundgasm.net/u/ytdl'


# Generated at 2022-06-26 12:47:15.080992
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert 'ytdl' == SoundgasmProfileIE._match_id('http://soundgasm.net/u/ytdl')
    assert 'ytdl' == SoundgasmProfileIE._match_id('http://soundgasm.net/u/ytdl/')
    url = 'http://soundgasm.net/u/ytdl/#'
    assert 'ytdl' == SoundgasmProfileIE._match_id(url)
    assert 'ytdl' == SoundgasmProfileIE._match_id('http://soundgasm.net/u/ytdl/#/u/dj_joe_mama/chrome-test-poll')

test_SoundgasmProfileIE()

# Generated at 2022-06-26 12:47:16.360961
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()


# Generated at 2022-06-26 12:47:17.187131
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-26 12:50:34.198202
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/'
    inst = SoundgasmProfileIE()
    assert inst.IE_NAME in inst.constructor(url).IE_NAME
    assert inst.IE_NAME in inst.constructor(url, True).IE_NAME
    assert inst.IE_NAME in inst.constructor(url, False).IE_NAME
    assert inst.IE_NAME in inst.constructor(url, True, None).IE_NAME
    assert inst.IE_NAME in inst.constructor(url, False, None).IE_NAME

# Generated at 2022-06-26 12:50:35.963811
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._build_url('123') == '%s/u/123/' % SoundgasmProfileIE._VALID_URL_BASE

# Generated at 2022-06-26 12:50:37.424422
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = "http://soundgasm.net/u/ytdl"
    SoundgasmProfileIE(url, "Soundgasm")

# Generated at 2022-06-26 12:50:38.847633
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-26 12:50:39.463221
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	# Constructor
	SoundgasmProfileIE()

# Generated at 2022-06-26 12:50:40.859953
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test = 'http://soundgasm.net/u/ytdl'
    SoundgasmProfileIE._TEST = {}
    SoundgasmProfileIE.suite()

# Generated at 2022-06-26 12:50:44.382464
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.IE_NAME == 'soundgasm:profile'
    #print("Test Passed")

# Generated at 2022-06-26 12:50:48.168636
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('SoundgasmProfileIE', [])
    assert ie.IE_NAME == 'SoundgasmProfileIE'
    assert ie.ie_key() == 'SoundgasmProfileIE'
    assert ie.SUCCESS == 'SoundgasmProfileIE'
    assert ie.FAILED == 'SoundgasmProfileIE'

# Generated at 2022-06-26 12:50:49.367118
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_IE = SoundgasmProfileIE()
    assert soundgasm_profile_IE.IE_NAME == 'SoundgasmProfileIE'

# Generated at 2022-06-26 12:50:52.083786
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    x = SoundgasmProfileIE('ytdl')
    # Unit test for method _download_webpage
    assert x._download_webpage('http://soundgasm.net/u/ytdl', 'ytdl') == '<html></html>'