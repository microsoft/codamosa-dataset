

# Generated at 2022-06-26 12:41:40.423871
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e = test_case_0()


# Generated at 2022-06-26 12:41:42.648383
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-26 12:41:43.661922
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass


# Generated at 2022-06-26 12:41:45.246358
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()

# Generated at 2022-06-26 12:41:57.516930
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert(type(soundgasm_i_e_0) is SoundgasmIE)
    assert(soundgasm_i_e_0.IE_NAME == 'soundgasm')
    assert(soundgasm_i_e_0._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')
    assert(soundgasm_i_e_0._TEST.get('url') == 'http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-26 12:41:59.833284
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print(SoundgasmIE())


# Generated at 2022-06-26 12:42:01.855735
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert callable(SoundgasmIE)


# Generated at 2022-06-26 12:42:05.755509
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ProfileIE = SoundgasmProfileIE()

if __name__ == '__main__':
    test_case_0()
    test_SoundgasmProfileIE()

# Generated at 2022-06-26 12:42:09.238306
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()


# Generated at 2022-06-26 12:42:10.611886
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-26 12:42:16.066289
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(downloader=None)

# Generated at 2022-06-26 12:42:18.732113
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    ie.extract()

# Generated at 2022-06-26 12:42:20.085447
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()


# Generated at 2022-06-26 12:42:21.438272
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE('https://www.youtube.com')
    assert(obj.IE_NAME == 'soundgasm')

# Generated at 2022-06-26 12:42:25.051685
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """ test constructor of class SoundgasmIE """
    info_extractor = SoundgasmIE({})
    if info_extractor.IE_NAME is not 'soundgasm':
        raise Exception("Info extractor name is not soundgasm")
    if info_extractor._VALID_URL is not r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)':
        raise Exception("Invalid URL")

test_SoundgasmIE()


# Generated at 2022-06-26 12:42:28.646399
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        url = 'http://soundgasm.net/u/ytdl/Piano-sample'
        soundgasm = SoundgasmIE()
        soundgasm.extract(url)
        return True
    except Exception:
        return False



# Generated at 2022-06-26 12:42:37.656967
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-26 12:42:47.707826
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE.IE_NAME == 'soundgasm'
    assert SoundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:42:51.413451
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	SGprofileTest = SoundgasmProfileIE(InfoExtractor())
	assert SGprofileTest.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-26 12:42:55.513902
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Should have no error if the constructor is called
    try:
        SoundgasmIE()
        assert True
    except Exception:
        assert False


# Generated at 2022-06-26 12:43:04.576834
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()

# Generated at 2022-06-26 12:43:10.150637
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    ie_name = ie.IE_NAME
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie.download(url)
    ie_name.lower()

# Generated at 2022-06-26 12:43:13.844217
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
  # test the constructor of class SoundgasmIE
  extractor = SoundgasmIE()
  assert extractor.IE_NAME == 'SoundgasmIE'


# Generated at 2022-06-26 12:43:15.139354
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sgp = SoundgasmProfileIE('SoundgasmProfile')
    assert sgp.ie_key() == 'SoundgasmProfile'

# Generated at 2022-06-26 12:43:16.385700
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE() != None)

# Generated at 2022-06-26 12:43:19.174633
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-26 12:43:22.170198
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert SoundgasmProfileIE("http://soundgasm.net/u/ytdl").test("url")

# Generated at 2022-06-26 12:43:28.578175
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE()
    assert a.playlist_mincount == 1
    b = SoundgasmProfileIE()
    print(b.playlist_mincount)
    assert b.playlist_mincount == 1
    print(a.playlist_mincount)
    assert a.playlist_mincount == 2
    print(b.playlist_mincount)
    assert b.playlist_mincount == 2
    assert a.playlist_mincount == 2
    assert b.playlist_mincount == 2

# Generated at 2022-06-26 12:43:35.675450
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        c1=SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
        c2=SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
        print("Passed: constructor test")
    except Exception as e:
        print("Failed: constructor test")
        print(e)


# Generated at 2022-06-26 12:43:46.607203
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE = SoundgasmProfileIE('/u/ytdl')
    print("before assert")
    assert IE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    print("after assert")
    print("before assert")
    assert IE._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}
    print("after assert")
    print("before assert")

# Generated at 2022-06-26 12:44:04.860256
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info(SoundgasmIE._VALID_URL, SoundgasmIE, True)


# Generated at 2022-06-26 12:44:13.860951
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sgProfileIE = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    assert sgProfileIE.IE_NAME == "soundgasm:profile"
    assert sgProfileIE.url == "http://soundgasm.net/u/ytdl"
    assert sgProfileIE.profile_id == "ytdl"
    assert sgProfileIE.title == "http://soundgasm.net/u/ytdl"


# Generated at 2022-06-26 12:44:16.844829
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Construct unit tests for SoundgasmProfileIE
    """
    ie = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    assert ie.name == 'Soundgasm'

# Generated at 2022-06-26 12:44:18.434845
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    assert obj.IE_NAME == 'soundgasm'
    

# Generated at 2022-06-26 12:44:19.490408
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-26 12:44:22.597379
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE = SoundgasmIE()

# Generated at 2022-06-26 12:44:23.827502
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE(_test_file=False)
    return ie

# Generated at 2022-06-26 12:44:29.026494
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    dict = {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    instance = SoundgasmProfileIE()
    assert instance._TEST == dict

# Generated at 2022-06-26 12:44:33.489554
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE()
    #Pattern is wrong, should be 'http://soundgasm.net/u/ytdl/Piano-sample'
    a.suitable('http://soundgasm.net/u/ytdl/Piano-sample/')
    #Pattern is right, suitable function should return True
    a.suitable('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-26 12:44:34.875097
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # unit test for constructor of class SoundgasmProfileIE
    profile = SoundgasmProfileIE()
    return profile

# Generated at 2022-06-26 12:45:12.871757
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_id = 'ytdl'
    inst = SoundgasmProfileIE(profile_id)
    assert inst.profile_id == 'ytdl'

# Generated at 2022-06-26 12:45:22.473402
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_arr = [
        {'url': 'http://soundgasm.net/u/ytdl', 'id': 'ytdl'},
        {'url': 'http://soundgasm.net/u/ytdl/', 'id': 'ytdl'},
        {'url': 'http://soundgasm.net/u/ytdl/#', 'id': 'ytdl'},
        {'url': 'http://soundgasm.net/u/ytdl/#test', 'id': 'ytdl'},
    ]
    for test in test_arr:
        test_obj = SoundgasmProfileIE()
        assert test_obj._match_id(test['url']) == test['id']

# Generated at 2022-06-26 12:45:28.720456
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import youtube_dl.extractor
    youtube_dl.extractor.Extractor._call_downloader = lambda self, *args: args
    grp = ('url', 'SoundgasmProfileIE')
    single = ('http://soundgasm.net/u/ytdl', grp + ('ytdl',))
    plural = ('http://soundgasm.net/u/harukasan', grp + ('harukasan',))
    for inp, out in [single, plural]:
        assert youtube_dl.extractor.Extractor._test_extractor_class(SoundgasmProfileIE, inp, out) == out

# Generated at 2022-06-26 12:45:30.739689
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """The unit test of SoundgasmIE"""
    obj = SoundgasmIE()
    assert obj != None

# Generated at 2022-06-26 12:45:36.958726
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie.VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    mobj = re.match(ie.VALID_URL, 'http://soundgasm.net/u/ytdl/Piano-sample')
    assert mobj.group('user') == 'ytdl'
    assert mobj.group('display_id') == 'Piano-sample'

# Unit tests for constructor of class SoundgasmProfileIE

# Generated at 2022-06-26 12:45:38.971165
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Test for constructor of class SoundgasmProfileIE"""
    IE = SoundgasmProfileIE(None)
    assert IE.IE_NAME == "SoundgasmProfileIE"

# Generated at 2022-06-26 12:45:48.129847
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    global url_test, audio_url_test, title_test, description_test, id_test, display_id_test, uploader_test
    url_test = 'http://soundgasm.net/u/ytdl/Piano-sample'
    audio_url_test = 'https://d1k7hi32a36oov.cloudfront.net/piano_sample.m4a'
    title_test = 'Piano sample'
    description_test = 'Royalty Free Sample Music'
    id_test = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    display_id_test = 'Piano-sample'
    uploader_test = 'ytdl'

# Generated at 2022-06-26 12:45:55.949709
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    #test 1, a valid URL
    result = ie.extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert result['title'] == 'Piano sample'
    #test 2, a URL with space in the end
    result = ie.extract('http://soundgasm.net/u/ytdl/Piano-sample ')
    assert result['title'] == 'Piano sample'
    try:
        #test 3, an invalid URL
        result = ie.extract('http://soundgasm.net/u/ytdl/Piano-sample-asdf')
        #assert result['title'] == 'Piano sample'
    except:
        assert True

# Generated at 2022-06-26 12:45:57.880720
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = "http://soundgasm.net/u/ytdl"
    soundgasm_profile_ie = SoundgasmProfileIE(url)
    soundgasm_profile_ie._real_extract(url)

# Generated at 2022-06-26 12:46:07.902016
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    url_result = 'https://soundgasm.net/u/ytdl/Piano-sample'
    info_dict = {
        'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
        'ext': 'm4a',
        'title': 'Piano sample',
        'description': 'Royalty Free Sample Music',
        'uploader': 'ytdl',
    }
    expected_result = (url_result, info_dict)
    result = SoundgasmIE().extract(test_url)
    assert result == expected_result

# Generated at 2022-06-26 12:47:46.478914
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    # Test valid URL
    sg_ie = SoundgasmIE()
    video_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    valid_url = sg_ie._valid_url(video_url)
    assert(valid_url)

    # Test invalid URL
    invalid_url = sg_ie._valid_url("some_random_string")
    assert(not invalid_url)

# Generated at 2022-06-26 12:47:49.908069
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    mobj = re.match(ie._VALID_URL, url)
    assert mobj
    assert mobj.group('display_id') == 'Piano-sample'
    assert mobj.group('user') == 'ytdl'

# Generated at 2022-06-26 12:47:55.598648
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .test_common import assertCategories, FakeYDL
    from .test_soundgasm import SoundgasmIE
    test_cases = [
        {
            'note': 'test1',
            'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
            'result': {
                'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
                'ext': 'm4a',
                'title': 'Piano sample',
                'description': 'Royalty Free Sample Music',
                'uploader': 'ytdl',
                'categories': [],
            },
        }
    ]
    ydl = FakeYDL()
    for t_case in test_cases:
        ie = SoundgasmIE()._real_

# Generated at 2022-06-26 12:47:56.569968
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie_object = SoundgasmIE()


# Generated at 2022-06-26 12:47:57.560032
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None, 'http://soundgasm.net/u/ytdl')


# Generated at 2022-06-26 12:48:00.855271
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_ie = SoundgasmIE()
    if soundgasm_ie.IE_NAME == 'soundgasm':
        print("constructor of SoundgasmIE class is OK.")
    else:
        print("constructor of SoundgasmIE class is NG.")

# Generated at 2022-06-26 12:48:11.037603
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-26 12:48:17.759059
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()

# Generated at 2022-06-26 12:48:18.366064
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-26 12:48:19.744850
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
