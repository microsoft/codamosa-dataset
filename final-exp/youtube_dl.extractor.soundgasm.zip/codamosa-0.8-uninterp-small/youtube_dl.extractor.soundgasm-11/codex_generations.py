

# Generated at 2022-06-26 12:41:45.685573
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)', 'Wrong _VALID_URL value.'
    assert SoundgasmIE().IE_NAME == 'soundgasm', 'Wrong IE_NAME value.'


# Generated at 2022-06-26 12:41:47.701211
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_0 = SoundgasmIE()


# Generated at 2022-06-26 12:41:49.952262
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_IE_0 = SoundgasmProfileIE()

# Generated at 2022-06-26 12:41:51.620076
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()

# Generated at 2022-06-26 12:41:53.325448
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-26 12:41:59.542719
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert soundgasm_i_e_0._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert soundgasm_i_e_0._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert soundgasm_i_e_0._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-26 12:42:01.044461
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert True


# Generated at 2022-06-26 12:42:06.291963
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE()
    assert soundgasm_profile_ie.ie_key() == 'Soundgasm'
    assert soundgasm_profile_ie.ie_name() == 'Soundgasm'
#

# Generated at 2022-06-26 12:42:09.576446
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert_equal(type(soundgasm_i_e_0), SoundgasmIE)


# Generated at 2022-06-26 12:42:14.518473
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-26 12:42:19.277604
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-26 12:42:22.209281
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-26 12:42:28.022143
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	obj = SoundgasmProfileIE()
	assert re.match(r'https?://(?:www\.)?soundgasm\.net/u/ytdl/Piano-sample', obj._VALID_URL)
	assert obj._TEST.get('url') == 'http://soundgasm.net/u/ytdl/Piano-sample'


# Generated at 2022-06-26 12:42:31.629475
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert (isinstance(SoundgasmIE().user, str) and
            isinstance(SoundgasmIE().title, str))


# Generated at 2022-06-26 12:42:32.923951
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    song = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert song != None

# Generated at 2022-06-26 12:42:45.844286
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    test_sample = 'https://soundgasm.net/u/ytdl/Piano-sample'
    test_video_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-26 12:42:49.228042
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE(u'ytdl')
    assert type(instance) == SoundgasmProfileIE
    return

# Generated at 2022-06-26 12:42:59.535457
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-26 12:43:09.240846
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    audio_IE = SoundgasmIE()
    audio_dict = audio_IE.extract(url)

# Generated at 2022-06-26 12:43:15.442356
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:43:26.847317
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'



# Generated at 2022-06-26 12:43:28.454476
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-26 12:43:38.883095
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    assert obj.IE_NAME == 'soundgasm'
    assert obj.VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert obj.TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert obj.TEST['md5'] == '010082a2c802c5275bb00030743e75ad'
    assert obj.TEST['info_dict']['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-26 12:43:40.031523
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	myIE = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")


# Generated at 2022-06-26 12:43:42.161086
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Constructor(url=url, ie, downloader)
    SoundgasmIE(url = "http://soundgasm.net/u/ytdl/Piano-sample")


# Generated at 2022-06-26 12:43:43.376869
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
        yt_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
        SoundgasmIE()._real_extract(yt_url)

# Generated at 2022-06-26 12:43:50.473877
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sgie = SoundgasmIE()
    assert sgie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:43:59.398217
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class_SoundgasmIE = SoundgasmIE()
    md5_expected_result = '010082a2c802c5275bb00030743e75ad'
    expected_result = (
        'http://static.soundgasm.net/sounds/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a',
        'http://static.soundgasm.net/sounds/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a',
        md5_expected_result,
        {
            'title': 'Piano sample',
            'description': 'Royalty Free Sample Music',
            'uploader': 'ytdl'
        }
    )
    # Check that we get the expected result from the constructor
   

# Generated at 2022-06-26 12:44:07.658752
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """ Test case for the constructor of class SoundgasmProfileIE """
    # Test case with video URL
    video_url = 'http://soundgasm.net/u/ytdl'
    test_video_url = SoundgasmProfileIE(video_url)
    assert test_video_url.url == video_url

    # Test case with invalid video URL
    invalid_video_url = 'http://soundgasm.net/'
    try:
        SoundgasmProfileIE(invalid_video_url)
        assert False
    except AssertionError:
        assert True

# Generated at 2022-06-26 12:44:12.535052
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:44:29.068866
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-26 12:44:36.911019
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    # assert ie.IE_NAME == 'Soundgasm'

    # assert ie._TEST == {
    #     'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
    #     'md5': '010082a2c802c5275bb00030743e75ad',
    #     'info_dict': {
    #         'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
    #         '

# Generated at 2022-06-26 12:44:38.794446
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # test constructor of class
    m1 = SoundgasmIE()
    m2 = SoundgasmIE()
    assert m1.name == m2.name

# Generated at 2022-06-26 12:44:49.311019
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    m = SoundgasmIE()
    assert m._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

    m = SoundgasmIE()

# Generated at 2022-06-26 12:44:52.233004
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE.ie._downloader.params.update(
        {'usenetrc': False, 'username': 'fake', 'password': 'fake'})
    SoundgasmIE.ie.download('http://soundgasm.net/u/ytdl/sample')

# Generated at 2022-06-26 12:44:55.366351
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .common import InfoExtractor
    from .soundgasm import SoundgasmIE
    __name__ = '__main__'
    InfoExtractor('soundgasm')
    exit()

# Generated at 2022-06-26 12:44:59.130809
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    # Test that the regexp matches given url
    ie.suitable('http://soundgasm.net/u/ytdl/Piano-sample')



# Generated at 2022-06-26 12:45:03.218439
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg = SoundgasmProfileIE()
    assert sg.IE_NAME == 'soundgasm:profile'
    assert sg._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'



# Generated at 2022-06-26 12:45:05.045340
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = SoundgasmIE(None, 'http://soundgasm.net/u/ytdl/Piano-sample').url
    return url

# Generated at 2022-06-26 12:45:07.418854
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE(None).url_result(test_url, 'Soundgasm')

# Generated at 2022-06-26 12:45:54.821546
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    '''test_SoundgasmIE'''
    s_test = SoundgasmIE()
    assert s_test.IE_NAME == 'soundgasm'
    assert s_test._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert s_test._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert s_test._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-26 12:45:56.207245
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    assert isinstance(soundgasm, InfoExtractor)

# Generated at 2022-06-26 12:46:01.413744
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        ie = SoundgasmProfileIE('SoundgasmProfileIE')
        assert(str(ie) == 'SoundgasmProfileIE')
        assert(ie.IE_NAME == 'SoundgasmProfileIE')
    except AssertionError:
        print("test_SoundgasmProfileIE has failed.")
        return
    else:
        print("test_SoundgasmProfileIE has passed.")
        return

test_SoundgasmProfileIE()


# Generated at 2022-06-26 12:46:02.245642
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE is not -1

# Generated at 2022-06-26 12:46:04.257206
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .test_soundcloud import test_SoundcloudIE
    import sys
    sys.argv = ['', 'Test.testName']
    unittest.main()

# Generated at 2022-06-26 12:46:14.843291
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Create a SoundgasmProfileIE instance
    # Test whether the SoundgasmProfileIE can be initialized
    ie = SoundgasmProfileIE(SoundgasmProfileIE.IE_NAME, {'extractor': SoundgasmProfileIE})
    # Test whether the _VALID_URL can be compiled
    assert re.match(SoundgasmProfileIE._VALID_URL, 'http://soundgasm.net/u/ytdl')
    # Test whether the url in _TEST dict can be compiled
    assert re.match(SoundgasmProfileIE._VALID_URL, SoundgasmProfileIE._TEST['url'])
    # Test whether the soundgasm.net/u/ytdl in _TEST dict can be extracted
    assert ie._match_id(SoundgasmProfileIE._TEST['url']) == 'ytdl'

# Generated at 2022-06-26 12:46:19.927230
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE()
    assert ie._match_id(url) == 'ytdl'
    webpage = ie._download_webpage(url, 'ytdl')
    assert webpage.startswith(b'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0')
    entries = [ie.url_result(audio_url, 'Soundgasm') for audio_url in re.findall(r'href="([^"]+/u/ytdl/[^"]+)', webpage)]
    assert len(entries) >= 1
    assert entries[0].startswith('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-26 12:46:25.129998
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Given SoundgasmProfileIE instance
    SoundgasmProfileIE_instance = SoundgasmProfileIE()
    # Then the value of SoundgasmProfileIE_instance
    # is SoundgasmProfileIE instance
    assert isinstance(SoundgasmProfileIE_instance, SoundgasmProfileIE), 'The value of SoundgasmProfileIE_instance should be SoundgasmProfileIE instance'

# Generated at 2022-06-26 12:46:34.233036
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    This is a unit test for SoundgasmProfileIE.
    If a valid youtube video( https://www.youtube.com/watch?v=b1XGPvbWn0A ) is given as input,
    Then the expected output is:
    SoundgasmProfileIE is a subclass of InfoExtractor
    The title of the youtube video is "YouTube Downloader Test Video - 1080p"
    """
    url = 'http://soundgasm.net/u/ytdl'
    info_dict = {'id': 'ytdl'}
    playlist_count = 1
    actual_output = SoundgasmProfileIE(InfoExtractor)
    assert actual_output.IE_NAME == 'soundgasm:profile'
    actual_output = SoundgasmProfileIE._VALID_URL

# Generated at 2022-06-26 12:46:38.557036
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    assert soundgasm.IE_NAME == 'soundgasm'
    assert soundgasm._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:48:13.934050
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-26 12:48:17.568579
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    # test if the constructor of SoundgasmIE can be initialized
    assert SoundgasmIE(url).url == url


# Generated at 2022-06-26 12:48:23.031228
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Sometimes it takes longer than 10s to load the webpage and selenium can
    # throw a TimeoutException. It is better to catch the exception and display
    # an error message.
    try:
        driver = webdriver.Firefox()
        driver.get("http://soundgasm.net/u/ytdl/Piano-sample")
        time.sleep(2)
    except TimeoutException:
        print("Page load timeout, please check your network connection.")
        return
    return SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")


# Generated at 2022-06-26 12:48:25.558650
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'

# Generated at 2022-06-26 12:48:29.017700
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    e = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert e.user == 'ytdl'
    assert e.display_id == 'Piano-sample'
    assert e.url == 'http://soundgasm.net/u/ytdl/Piano-sample'

# Generated at 2022-06-26 12:48:32.497070
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-26 12:48:35.014057
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    sg_profile_ie = SoundgasmProfileIE()
    profile_id = sg_profile_ie._match_id(url)
    assert profile_id == 'ytdl'


# Generated at 2022-06-26 12:48:41.844877
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'
    webpage = '<html></html>'
    _download_webpage = lambda url, profile_id: webpage
    _match_id = lambda url: profile_id
    url_result = lambda audio_url, ie: ie
    playlist_result = lambda entries, profile_id: profile_id
    assert profile_id == SoundgasmProfileIE._real_extract(
        SoundgasmProfileIE(
            SoundgasmProfileIE._VALID_URL,
            SoundgasmProfileIE.IE_NAME,
            SoundgasmProfileIE._TEST
        ),
        url
    )

# Generated at 2022-06-26 12:48:44.016383
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
  soundgasm_ie = SoundgasmIE('')
  assert isinstance(soundgasm_ie, SoundgasmIE)

# Generated at 2022-06-26 12:48:48.114385
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert(ie.name == 'soundgasm')
    assert(ie.url == 'http://soundgasm.net/u/ytdl/Piano-sample')