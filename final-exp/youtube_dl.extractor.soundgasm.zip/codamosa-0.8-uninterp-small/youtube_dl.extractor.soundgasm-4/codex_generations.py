

# Generated at 2022-06-26 12:41:44.706626
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = "http://soundgasm.net/u/ytdl"
    instance = SoundgasmProfileIE(url)
    instance.url = url
    assert_equals(instance.url, url)


# Generated at 2022-06-26 12:41:46.291444
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info_extractor = SoundgasmIE()


# Generated at 2022-06-26 12:41:48.515417
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_0 = SoundgasmIE()

# Generated at 2022-06-26 12:41:50.860391
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_0 = SoundgasmIE()


# Generated at 2022-06-26 12:41:53.162512
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_0 = SoundgasmIE()


# Generated at 2022-06-26 12:41:53.811411
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_0 = SoundgasmIE()


# Generated at 2022-06-26 12:41:54.684974
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-26 12:41:55.902628
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e = SoundgasmIE()

# Generated at 2022-06-26 12:42:02.448182
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_0 = SoundgasmIE()
    assert_equal(soundgasm_i_e_0.ie_key(), 'Soundgasm')
    assert_equal(soundgasm_i_e_0.ie_name(), 'Soundgasm')

# Generated at 2022-06-26 12:42:05.798579
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_0 = SoundgasmIE()

if __name__ == '__main__':
    test_SoundgasmIE()

# Generated at 2022-06-26 12:42:15.145893
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_case_0()


# Generated at 2022-06-26 12:42:17.206491
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        soundgasm_i_e_0 = SoundgasmIE()
    except Exception:
        assert False


# Generated at 2022-06-26 12:42:17.985351
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    return

# Generated at 2022-06-26 12:42:23.203991
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_0 = SoundgasmIE()
    soundgasm_i_e_1 = SoundgasmIE()
    soundgasm_i_e_2 = SoundgasmIE()


# Generated at 2022-06-26 12:42:25.168825
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e = SoundgasmIE()


# Generated at 2022-06-26 12:42:26.887075
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE(InfoExtractor)


# Generated at 2022-06-26 12:42:29.401037
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_0 = SoundgasmIE()


# Generated at 2022-06-26 12:42:30.794541
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass


# Generated at 2022-06-26 12:42:41.434840
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    if not hasattr(SoundgasmIE, 'IE_NAME'):
        SoundgasmIE.IE_NAME = 'soundgasm'
    if not hasattr(SoundgasmIE, '_VALID_URL'):
        SoundgasmIE._VALID_URL = 'r\'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)\''

# Generated at 2022-06-26 12:42:42.217887
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    arg_1 = SoundgasmIE()


# Generated at 2022-06-26 12:42:57.077135
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	ie = SoundgasmIE(None)

	assert ie._VALID_URL == \
	       r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


if __name__ == "__main__":
    test_SoundgasmIE()

# Generated at 2022-06-26 12:42:59.359379
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    print(ie._VALID_URL)

# Generated at 2022-06-26 12:43:05.608674
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profileIE = SoundgasmProfileIE()
    assert profileIE.IE_NAME == 'SoundgasmProfile'
    assert profileIE.IE_DESC == 'Soundgasm Profile'
    assert profileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-26 12:43:12.273886
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE()
    assert profile.IE_NAME == 'soundgasm:profile'
    assert profile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:43:14.179945
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert hasattr(SoundgasmProfileIE(), '_download_webpage')

# Generated at 2022-06-26 12:43:18.256978
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_ie=SoundgasmProfileIE()
    assert test_ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert test_ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
# NOTE: Soundgasm is a niche site and doesn't have many videos.
# If you discover more test cases, please contribute them.

# Generated at 2022-06-26 12:43:19.881846
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()

# Generated at 2022-06-26 12:43:20.709376
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-26 12:43:22.381579
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	assert SoundgasmIE() is not None

# Generated at 2022-06-26 12:43:25.243185
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        soundgasm = SoundgasmIE()
    except:
        assert False
    assert True


# Generated at 2022-06-26 12:43:47.206658
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    'Unit test for constructor of class SoundgasmProfileIE'
    try:
 	# Create an instance of class SoundgasmProfileIE
        obj = SoundgasmProfileIE()
        url = 'http://soundgasm.net/u/ytdl'
        profile_id = 'ytdl'
        id = obj._match_id(url)
        assert(id == profile_id)
    except:
        raise 


# Generated at 2022-06-26 12:43:57.258153
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    obj = SoundgasmIE()._real_extract(url)
    assert obj.get('title', 'Random title') == 'Piano sample'
    assert obj.get('description', 'Random description') == 'Royalty Free Sample Music'
    assert  obj.get('uploader', 'Random uploader') == 'ytdl'
    assert  obj.get('display_id', 'Random display_id') == 'Piano-sample'
    assert  obj.get('id', 'Random id') == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert  obj.get('ext', 'Random ext') == 'm4a'

# Generated at 2022-06-26 12:44:08.552704
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE()
    assert ie._match_id(url) == 'ytdl'
    # Test webpage, display_id, user

# Generated at 2022-06-26 12:44:13.480197
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-26 12:44:18.024665
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasmIE = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert soundgasmIE.display_id == 'Piano-sample'
    assert soundgasmIE.url == 'http://soundgasm.net/u/ytdl/Piano-sample'


# Generated at 2022-06-26 12:44:29.240266
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import unittest
    class SoundgasmIETestCase(unittest.TestCase):
        def test_class_SoundgasmIE(self):
            self.assertTrue(hasattr(SoundgasmIE, 'ie_key'))
            self.assertTrue(hasattr(SoundgasmIE, 'ie_name'))
            self.assertTrue(hasattr(SoundgasmIE, '_VALID_URL'))
            self.assertTrue(hasattr(SoundgasmIE, '_TEST'))
            self.assertTrue(hasattr(SoundgasmIE, '_download_webpage'))
            self.assertTrue(hasattr(SoundgasmIE, '_html_search_regex'))
            self.assertTrue(hasattr(SoundgasmIE, '_search_regex'))

# Generated at 2022-06-26 12:44:30.456107
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-26 12:44:31.305413
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE({})

# Generated at 2022-06-26 12:44:38.567006
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    test = SoundgasmIE()._real_extract(url)
    assert(test['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9')
    assert(test['display_id'] == 'Piano-sample')
    assert(test['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a')
    assert(test['vcodec'] == 'none')
    assert(test['title'] == 'Piano sample')
    assert(test['description'] == 'Royalty Free Sample Music')

# Generated at 2022-06-26 12:44:40.211920
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-26 12:45:20.241441
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    if __name__ == "__main__":
        sa = SoundgasmIE()
        sa.test()

# Generated at 2022-06-26 12:45:26.584982
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    To run tests on an individual test case, go to the directory above
    youtube-dl and run:

        PYTHONPATH=. python test/test_soundgasm.py \
            SoundgasmIE.test_SoundgasmIE

    """
    TESTCASEURL = 'http://soundgasm.net/u/ytdl/Piano-sample'

    # Check that the constructor doesn't throw any exceptions
    SoundgasmIE(TESTCASEURL)


# Generated at 2022-06-26 12:45:31.075701
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    result = SoundgasmIE().extract_info("http://soundgasm.net/u/ytdl/Piano-sample")
    print("Info:", result['id'], result['title'], result['uploader'], result['description'], result['ext'])
    return result['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'


# Generated at 2022-06-26 12:45:31.832406
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-26 12:45:36.743802
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest

    name = SoundgasmProfileIE().__class__.__name__
    print('SoundgasmProfileIE._TEST[\'playlist_mincount\'] = number of videos in test_SoundgasmProfileIE()')
    exec('{0}._TEST[\'playlist_mincount\'] = len(test_SoundgasmProfileIE())'.format(name))
    suite = unittest.TestLoader().loadTestsFromTestCase(TestSoundgasmProfileIE)
    unittest.TextTestRunner(verbosity=2).run(suite)


# Generated at 2022-06-26 12:45:38.720480
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    return SoundgasmIE().extract(url)


# Generated at 2022-06-26 12:45:40.171940
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profileIE = SoundgasmProfileIE(None)
    assert soundgasm_profileIE.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-26 12:45:41.458860
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE(InfoExtractor(None))



# Generated at 2022-06-26 12:45:51.042015
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = SoundgasmIE()
    # test SoundgasmIE
    assert ('Soundgasm' == test.IE_NAME)

    # test SoundgasmIE.extract
    mobj = re.match(test._VALID_URL, test._TEST['url'])

    display_id = mobj.group('display_id')

    webpage = test._download_webpage(test._TEST['url'], display_id)
    audio_url = test._html_search_regex(r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', webpage, 'audio URL', group='url')

    # test SoundgasmIE._search_regex

# Generated at 2022-06-26 12:45:52.742890
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-26 12:47:25.312040
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    id = SoundgasmProfileIE._match_id(url)
    instance = SoundgasmProfileIE()
    assert isinstance(instance, InfoExtractor)
    assert instance.IE_NAME == 'soundgasm:profile'
    assert instance._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert id == 'ytdl'

# Generated at 2022-06-26 12:47:26.497362
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE('https://soundgasm.net/u/ytdl/') != None)

# Generated at 2022-06-26 12:47:27.890886
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Unit test for constructor of class SoundgasmIE"""
    SoundgasmIE(None)

# Generated at 2022-06-26 12:47:29.431037
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # This is a unit test, running this assert should be enough.
    assert(True)


# Generated at 2022-06-26 12:47:31.615407
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert len(ie.playlist_count) == 1


# Generated at 2022-06-26 12:47:34.403518
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    my_instance = SoundgasmProfileIE()
    assert(my_instance.IE_NAME == 'soundgasm:profile')
    assert(my_instance._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')



# Generated at 2022-06-26 12:47:36.111351
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test for instantiating a class SoundgasmProfileIE object
    soundgasm_profile_ie_obj = SoundgasmProfileIE()

    assert soundgasm_profile_ie_obj


# Generated at 2022-06-26 12:47:42.697059
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	def test_SoundgasmIE_with_valid_url_valid_download_url_valid_description():
		url = "http://soundgasm.net/u/ytdl/Piano-sample"
		valid_url = "http://s2.soundgasm.net/u/ytdl/Piano-sample.mp3?f1b907"
		valid_description = "Royalty Free Sample Music"
		valid_id = "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
		valid_uploader = "ytdl"
		valid_display = "Piano-sample"

# Generated at 2022-06-26 12:47:46.410601
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm = SoundgasmProfileIE()
    assert soundgasm.url is None
    assert soundgasm.IE_NAME == 'Soundgasm'
    assert soundgasm.soundgasm._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:47:52.699344
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    display_id = 'ytdl'

    # this is a subclass of InfoExtractor object, thus it's an object
    ie = SoundgasmProfileIE(b'http://soundgasm.net/u/ytdl')

    # _VALID_URL and _TEST are class variables of type string
    # ie.CLASS_NAME is the string 'SoundgasmProfileIE'
    assert ie._VALID_URL == url
    assert ie._TEST['url'] == url
    assert ie.IE_NAME == ie.CLASS_NAME
    # ie.CLASS_NAME is the string 'SoundgasmProfileIE'

# Generated at 2022-06-26 12:51:14.080562
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    #Unit test for constructor
    ie = InfoExtractor()
    


# Generated at 2022-06-26 12:51:22.336507
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Initializing the SoundgasmIE constructor
    soundgasmIE = SoundgasmIE()
    # Data extraction using REGEX
    audioURL_Regex = r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1'
    title_Regex = r'<div[^>]+\bclass=["\']jp-title[^>]+>([^<]+)'
    description_Regex = r'(?s)<li>Description:\s(.*?)<\/li>'
    audioID_Regex = r'/([^/]+)\.m4a'
    # Testing the REGEX with sample input
    #url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    #webpage = "<p

# Generated at 2022-06-26 12:51:24.548223
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = "http://soundgasm.net/u/ytdl"
    return SoundgasmProfileIE()._real_extract(url)

# Generated at 2022-06-26 12:51:26.669036
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample').extract() == SoundgasmIE._TEST

# Generated at 2022-06-26 12:51:29.055002
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """ test case for SoundgasmIE constructor. """
    assert SoundgasmIE() is not None
    assert SoundgasmIE(InfoExtractor())._VALID_URL == SoundgasmIE._VALID_URL


# Generated at 2022-06-26 12:51:34.937648
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'