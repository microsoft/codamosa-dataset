

# Generated at 2022-06-26 12:41:41.564749
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()

# Generated at 2022-06-26 12:41:44.607494
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    u_t_soundgasm_profile_i_e_0 = SoundgasmProfileIE()


# Generated at 2022-06-26 12:41:46.166846
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-26 12:41:48.371279
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()

# Generated at 2022-06-26 12:41:50.706834
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()

# Generated at 2022-06-26 12:41:52.920871
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_0 = SoundgasmIE()


# Generated at 2022-06-26 12:41:54.984336
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	soundgasm_i_e = SoundgasmIE()


# Generated at 2022-06-26 12:41:55.513140
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	return




# Generated at 2022-06-26 12:41:57.532190
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_0 = SoundgasmIE()


# Generated at 2022-06-26 12:42:00.440127
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE()

# Generated at 2022-06-26 12:42:08.123927
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_SoundgasmIE = SoundgasmIE()
    print(test_SoundgasmIE._VALID_URL)
    print(test_SoundgasmIE._TEST)
    print(test_SoundgasmIE._TEST['url'])
    print(test_SoundgasmIE.IE_NAME)

# Generated at 2022-06-26 12:42:18.224327
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    id_ = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    display_id = 'Piano-sample'
    title = 'Piano sample'
    audio_url = 'http://sgs-production.s3.amazonaws.com/audio/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    uploader = 'ytdl'

    # Test __init__
    SoundgasmIE.__init__(
        id_, display_id, title, audio_url, uploader)



# Generated at 2022-06-26 12:42:24.537729
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert(ie.id == 'ytdl')
    assert(ie.url == 'http://soundgasm.net/u/ytdl')
    assert(ie.playlist_count > 0)

# Generated at 2022-06-26 12:42:26.885713
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE().url_result('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-26 12:42:29.400288
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    #assert_equal()

# Generated at 2022-06-26 12:42:35.305435
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import itertools

# Generated at 2022-06-26 12:42:37.771207
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None).download('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-26 12:42:40.247103
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-26 12:42:44.239866
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    p = SoundgasmProfileIE()
    i = p._real_extract('http://soundgasm.net/u/ytdl')
    assert i['id'] == 'ytdl'

# Generated at 2022-06-26 12:42:46.802637
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio = SoundgasmIE()
    audio.extract('http://soundgasm.net/u/ytdl/Piano-sample')
    audio.extract('http://soundgasm.net/u/cerulean/Test-sound')


# Generated at 2022-06-26 12:42:56.590678
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	import soundcloud
	sg = SoundgasmIE(soundcloud)
	sg2 = SoundgasmIE(soundcloud)


# Generated at 2022-06-26 12:43:02.186883
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    except:
        assert 0, "Wrong url format or wrong version of constructor in class SoundgasmIE"
    return 1


# Generated at 2022-06-26 12:43:03.983058
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    except:
        ie = None

    assert ie is not None, "Failed to instantiate SoundgasmProfileIE"

# Generated at 2022-06-26 12:43:08.765308
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    mytestobj = SoundgasmIE('http://soundgasm.net/u/ytdl')
    assert type(mytestobj) == SoundgasmIE
    assert mytestobj._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-26 12:43:10.174497
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_ie = SoundgasmIE({})
    assert isinstance(soundgasm_ie, InfoExtractor)

# Generated at 2022-06-26 12:43:11.305528
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie= SoundgasmProfileIE()

# Generated at 2022-06-26 12:43:16.740642
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Basic unit test for SoundgasmProfileIE
    """
    # Test with results
    url = 'http://soundgasm.net/u/ytdl/'
    soundgasm_profile_ie = SoundgasmProfileIE(SoundgasmProfileIE._create_ie())
    soundgasm_profile_ie.extract(url)
    # Test with no results
    url = 'http://soundgasm.net/u/totallynonexistentguy/'
    soundgasm_profile_ie = SoundgasmProfileIE(SoundgasmProfileIE._create_ie())
    with pytest.raises(ExtractorError) as excinfo:
        soundgasm_profile_ie.extract(url)
    assert 'No videos found' in str(excinfo)

# Generated at 2022-06-26 12:43:28.525933
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	test = {
		'url': 'http://soundgasm.net/u/ytdl',
		'info_dict': {
			'id': 'ytdl',
		},
		'playlist_count': 1,
	}
	assert(SoundgasmProfileIE.suitable(test['url']))
	assert(SoundgasmProfileIE.IE_NAME == 'soundgasm:profile')
	assert(SoundgasmProfileIE.IE_DESC == 'Soundgasm user profile')
	assert(SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
	assert(SoundgasmProfileIE._TEST == test)

# Generated at 2022-06-26 12:43:37.061953
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE.IE_NAME == 'soundgasm:profile')
    assert(SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
    assert(SoundgasmProfileIE._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    })

# Generated at 2022-06-26 12:43:47.076936
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pattern = re.compile(SoundgasmIE._VALID_URL)
    assert pattern.match('http://soundgasm.net/u/ytdl/Piano-sample')
    assert pattern.match('http://soundgasm.net/u/ytdl/Piano-sample#')
    assert pattern.match('http://soundgasm.net/u/ytdl/Piano-sample#another')
    assert pattern.match('https://soundgasm.net/u/ytdl/Piano-sample')
    assert pattern.match('https://soundgasm.net/u/ytdl/Piano-sample#')
    assert pattern.match('https://soundgasm.net/u/ytdl/Piano-sample#another')

# Generated at 2022-06-26 12:44:08.723313
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('https://soundgasm.net/u/ytdl')
    assert ie.name == 'Soundgasm Profile'
    assert ie.ie_key() == 'Soundgasm'
    assert ie.url_result('http://soundgasm.net/u/ytdl/Piano-sample', 'Soundgasm').ie_key() == 'Soundgasm'
    assert ie.input_root == 'http://soundgasm.net/u/ytdl'
    assert ie.input_root_name == 'Soundgasm Profile'

# Generated at 2022-06-26 12:44:11.727991
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'


# Generated at 2022-06-26 12:44:15.146590
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_case = SoundgasmProfileIE()
    expected_output = SoundgasmProfileIE.IE_NAME
    assert test_case.IE_NAME == expected_output


# Generated at 2022-06-26 12:44:20.343902
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    _TEST = {
            "url" : "http://soundgasm.net/u/ytdl",
            "info_dict": {
                    "id": "ytdl",
            },
            "playlist_count": 1,
    }

    class DummySoundgasmProfileIE(SoundgasmProfileIE):
        def _real_extract(self, url):
            return self.playlist_result(["a", "b", "c", "d"], 'id')

    obj = DummySoundgasmProfileIE()
    playlist = obj._real_extract(_TEST['url'])

    assert playlist['_type'] == 'playlist'
    assert playlist['id'] == 'id'
    assert playlist['entries'] == ["a", "b", "c", "d"]

# Generated at 2022-06-26 12:44:23.310999
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'soundgasm'


# Generated at 2022-06-26 12:44:26.971792
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE()
    assert (a._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')


# Generated at 2022-06-26 12:44:29.404785
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    val = SoundgasmIE()

    assert val.IE_NAME == "soundgasm"


# Generated at 2022-06-26 12:44:31.024568
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    SoundgasmIE()._real_extract(url)


# Generated at 2022-06-26 12:44:31.869612
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()

# Generated at 2022-06-26 12:44:33.373426
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'SoundgasmProfileIE'

# Generated at 2022-06-26 12:45:07.657671
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("https://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-26 12:45:08.176298
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-26 12:45:12.069181
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_ie = SoundgasmIE()
    assert soundgasm_ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert soundgasm_ie.IE_NAME == 'soundgasm'

# Generated at 2022-06-26 12:45:16.679231
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Initialize SoundgasmProfileIE
    ie = SoundgasmProfileIE()
    # Fetch user ytdl
    ie.url = 'http://soundgasm.net/u/ytdl'
    audio_list = ie.get_list_audio()
    # Check condition
    assert len(audio_list) > 0

# Generated at 2022-06-26 12:45:26.556982
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    assert obj.IE_NAME == 'soundgasm'
    assert obj._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    obj._real_initialize()

# Generated at 2022-06-26 12:45:27.434682
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    print(ie)

# Generated at 2022-06-26 12:45:31.287418
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """ Test function for SoundgasmIE constructors """
    audio_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    SoundgasmIE()._real_extract(audio_url)
    SoundgasmProfileIE()._real_extract(audio_url)

# Generated at 2022-06-26 12:45:32.034042
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    print(ie)

# Generated at 2022-06-26 12:45:33.589358
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Test SoundgasmProfileIE Constructor"""
    instance = SoundgasmProfileIE()
    assert instance.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-26 12:45:37.943017
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST['url'] == "http://soundgasm.net/u/ytdl"
    assert ie._TEST['info_dict']['id'] == "ytdl"
    assert ie._TEST['playlist_count'] == 1


# Generated at 2022-06-26 12:46:56.982975
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class TestSoundgasmIE(SoundgasmIE):
        def _download_webpage(self, *args):
            return args[0]
    TestSoundgasmIE('test').download_file('test/')
    TestSoundgasmIE('test').download_recipe('test/')

# Generated at 2022-06-26 12:46:57.705818
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie=SoundgasmIE()
    return 0


# Generated at 2022-06-26 12:46:58.998336
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test if 'SoundgasmIE()' can be initialized
    # Test if 'SoundgasmIE' can be used to download the Soundgasm video
    s = SoundgasmIE()


# Generated at 2022-06-26 12:47:00.194160
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    s = SoundgasmProfileIE()
    print("test")
    #print(s._VALID_URL)
    #print(s._TEST['url'])
    print(s.workingAlias)

# Generated at 2022-06-26 12:47:06.822277
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test 1
    audio_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasm_ie = SoundgasmIE(None)
    sg_test = soundgasm_ie.extract(audio_url)
    assert sg_test['url'] == 'http://soundgasm-audio.s3.amazonaws.com/u/ytdl/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    assert sg_test['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert sg_test['ext'] == 'm4a'
    assert sg_test['title'] == 'Piano sample'
    assert sg_

# Generated at 2022-06-26 12:47:14.343255
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Testing with all combinations of given arguments
    SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    SoundgasmIE('www.soundgasm.net/u/ytdl/Piano-sample')
    SoundgasmIE('soundgasm.net/u/ytdl/Piano-sample')
    with open('soundgasm_test.html', 'r') as html_file:
        webpage = html_file.read()
    SoundgasmIE('soundgasm.net/u/ytdl/Piano-sample', webpage=webpage)


# Generated at 2022-06-26 12:47:18.334972
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    object_SoundgasmProfileIE = SoundgasmProfileIE()
    assert object_SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert object_SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:47:18.957545
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-26 12:47:25.143498
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE=SoundgasmIE()
    assert IE.IE_NAME=='soundgasm'
    assert IE._VALID_URL==r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert IE._TEST.get('url')=='http://soundgasm.net/u/ytdl/Piano-sample'
    assert IE._TEST.get('md5')=='010082a2c802c5275bb00030743e75ad'
    assert IE._TEST.get('info_dict').get('id')=='88abd86ea000cafe98f96321b23cc1206cbcbcc9'
   

# Generated at 2022-06-26 12:47:29.373799
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(SoundgasmProfileIE.IE_NAME, SoundgasmProfileIE._VALID_URL, {'id': 'e'})
    assert ie.profile_id == 'e'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:50:47.388526
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test user: 'ytdl' 
    # This should produce 1 result
    # The result should be of type class SoundgasmIE
    # The result should be http://soundgasm.net/u/ytdl/Piano-sample
    ie = SoundgasmProfileIE(IE_NAME) # The line to be tested
    result = ie._real_extract(url='http://soundgasm.net/u/ytdl') # Line tested
    result1 = result['entries'][0]
    assert result1['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-26 12:50:53.777740
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sample_url = 'https://soundgasm.net/u/ytdl/Piano-sample'
    expected_id = 'www.soundgasm.net/u/ytdl/Piano-sample'
    expected_title = 'Piano sample'
    expected_formats = ['m4a']
    expected_ext = 'm4a'
    expected_url = 'http://audio.sgs.com/a/00/88/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'

    ie = SoundgasmIE(sample_url)

    assert ie.ie_key() == 'Soundgasm'
    assert ie.video_id == expected_id
    assert ie.title == expected_title
    assert ie.formats == expected_formats

# Generated at 2022-06-26 12:50:55.223833
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE('Soundgasm:profile')


# Generated at 2022-06-26 12:51:00.175385
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert ie._TEST['info_dict'] == {
            'id': 'ytdl',
        }
    assert ie._TEST['playlist_count'] == 1


# Generated at 2022-06-26 12:51:02.249699
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE.suitable('http://soundgasm.net/u/ytdl/Piano-sample')
    assert not SoundgasmIE.suitable('http://soundgasm.net/u/ytdl')


# Generated at 2022-06-26 12:51:06.557599
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = InfoExtractor('extractor', 'http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._VALID_URL == SoundgasmIE._VALID_URL
    assert ie._TEST == SoundgasmIE._TEST
    assert ie._real_extract == SoundgasmIE._real_extract

if __name__ == '__main__':
    test_SoundgasmIE()

# Generated at 2022-06-26 12:51:13.438126
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = SoundgasmIE("url")
    assert test.IE_NAME == 'soundgasm'
    assert test._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:51:19.022742
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import pytest
    @pytest.fixture
    def yt_stub(request):
        from .mock_soundgasm import MockSoundgasmIE
        return MockSoundgasmIE()
    tstobj = yt_stub
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    sg_test = tstobj._real_extract(url)
    assert sg_test['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'


# Generated at 2022-06-26 12:51:20.680790
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()._real_extract('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-26 12:51:22.127881
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()
    SoundgasmProfileIE.ie_key()