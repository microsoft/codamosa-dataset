

# Generated at 2022-06-26 12:41:49.125604
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance_0 = SoundgasmProfileIE()
    assert_equal(instance_0._VALID_URL, 'https?://(?:www\\.)?soundgasm\\.net/u/(?P<id>[^/]+)/?(?:\\#.*)?')
    assert_equal(instance_0._TEST, {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1})
    assert_equal(instance_0.IE_NAME, 'SoundgasmProfileIE')
    assert_equal(instance_0.IE_DESC, 'Instances of this class will be hidden')
    assert_equal(instance_0.__name__, 'SoundgasmProfileIE')

# Generated at 2022-06-26 12:41:51.543279
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e = SoundgasmProfileIE()


# Generated at 2022-06-26 12:41:53.151029
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass


# Generated at 2022-06-26 12:41:55.470961
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()

test_SoundgasmProfileIE()

# Generated at 2022-06-26 12:42:08.558687
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_1 = SoundgasmIE()
    assert soundgasm_i_e_1._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert soundgasm_i_e_1.IE_NAME == 'soundgasm'

# Generated at 2022-06-26 12:42:10.382437
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-26 12:42:14.161874
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    #
    # The SoundgasmIE class is constructed.
    #
    soundgasm_i_e_0 = SoundgasmIE()


# Generated at 2022-06-26 12:42:17.752156
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert hasattr(SoundgasmProfileIE, '_VALID_URL'), 'No \'_VALID_URL\' attribute in SoundgasmProfileIE'
    assert hasattr(SoundgasmProfileIE, 'IE_NAME'), 'No \'IE_NAME\' attribute in SoundgasmProfileIE'
    assert hasattr(SoundgasmProfileIE, '_TEST'), 'No \'_TEST\' attribute in SoundgasmProfileIE'
    assert callable(getattr(SoundgasmProfileIE, '_real_extract')), 'No \'_real_extract\' method in SoundgasmProfileIE'
    assert callable(getattr(SoundgasmProfileIE, '_real_initialize')), 'No \'_real_initialize\' method in SoundgasmProfileIE'

# Generated at 2022-06-26 12:42:20.335267
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()


# Generated at 2022-06-26 12:42:26.886186
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert SoundgasmIE().IE_NAME == 'soundgasm'

# Generated at 2022-06-26 12:42:34.648550
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert( issubclass(SoundgasmProfileIE, SoundgasmIE) )
	assert( issubclass(SoundgasmProfileIE, InfoExtractor) )


# Generated at 2022-06-26 12:42:42.935047
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_instance = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    assert test_instance._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)"
    assert test_instance.IE_NAME == "soundgasm"

# Generated at 2022-06-26 12:42:46.310737
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:42:51.136338
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:42:59.793730
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	# ytdl is an instance of the class in question: SoundgasmProfileIE
	ytdl = SoundgasmProfileIE()
	# test is a dictionary that contains the verification cases
	test = {
		'url': 'http://soundgasm.net/u/ytdl',
		'info_dict': {
			'id': 'ytdl',
		},
		'playlist_count': 1,
	}

	ytdl._match_id(ytdl._TEST['url'])
	# query = ytdl.extract(ytdl._TEST['url'])
	# assert query == ytdl._TEST['info_dict']

# Generated at 2022-06-26 12:43:00.336692
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert(SoundgasmIE is not None)

# Generated at 2022-06-26 12:43:02.855823
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    assert obj.IE_NAME == 'soundgasm'
    assert obj.VALID_URL == SoundgasmIE._VALID_URL
    assert obj.TEST == SoundgasmIE._TEST
    assert obj.url is None
    assert obj.video_id is None


# Generated at 2022-06-26 12:43:05.043395
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SGP_IE = SoundgasmProfileIE(None)
    assert SGP_IE.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-26 12:43:12.753642
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # URL referenced in SoundgasmProfileIE._TEST
    url="http://soundgasm.net/u/ytdl"
    # Create instance of class SoundgasmProfileIE.
    ie = SoundgasmProfileIE(downloader=None)
    # Check whether function _real_extract matches URL.
    assert ie._match_id(url) == "ytdl"

# Generated at 2022-06-26 12:43:13.576627
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-26 12:43:30.178175
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    src_test = r"""
    <div id="page-wrapper"> <article> <header> <h2> {{title}} </h2> </header> <div class="media"> <a href="http://soundgasm.net{{link}}" title="{{title}}"> <img class="img-responsive" src="{{image}}" alt="{{title}}"> </a> </div> <div class="media-body"> {{body}} </div> </article> </div>
    """
    src_test_result = (r"",r"")
    sgpi = SoundgasmProfileIE()
    test_func = getattr(sgpi, '_real_extract')
    test_result = test_func(src_test)
    assert(test_result == src_test_result)

# Generated at 2022-06-26 12:43:30.986504
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(None, None)
    assert ie.TESTING == 'Testing'

# Generated at 2022-06-26 12:43:32.650927
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert not SoundgasmProfileIE.suitable(object())
    assert SoundgasmProfileIE.suitable(SoundgasmProfileIE.ie_key())

# Generated at 2022-06-26 12:43:35.397708
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('SoundgasmProfileIE', 'http://soundgasm.net/u/ytdl', 'SoundgasmProfileIE')
    assert class_name == 'SoundgasmProfileIE'
    assert url == 'http://soundgasm.net/u/ytdl'
    assert name == 'SoundgasmProfileIE'

# Generated at 2022-06-26 12:43:38.983215
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert SoundgasmIE._VALID_URL.match(url) is not None

# Generated at 2022-06-26 12:43:41.457580
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Test for constructor of class SoundgasmProfileIE"""
    extractor = SoundgasmProfileIE('soundgasm:profile')
    assert extractor.IE_NAME == 'soundgasm:profile'
    assert extractor._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:43:54.019485
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    audio_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    display_id = 'Piano-sample'
    title = 'Piano sample'
    description = 'Royalty Free Sample Music'
    uploader = 'ytdl'

    assert SoundgasmIE._TEST['info_dict']['id'] == audio_id
    assert SoundgasmIE._TEST['info_dict']['title'] == title
    assert SoundgasmIE._TEST['info_dict']['description'] == description
    assert SoundgasmIE._TEST['info_dict']['uploader'] == uploader

    assert SoundgasmIE._TEST['url'] == url


# Generated at 2022-06-26 12:43:55.509501
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-26 12:44:02.206026
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sound = SoundgasmProfileIE()
    assert len(sound.IE_NAME) > 0
    assert len(sound._VALID_URL) > 0
    assert len(sound._TEST['url']) > 0
    assert len(sound._TEST['info_dict']['id']) > 0


# Generated at 2022-06-26 12:44:09.749189
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    # compiler practice:
    # this is how the SoundgasmProfileIE._VALID_URL is set.
    url_mgl = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    # this is how the SoundgasmProfileIE._match_id is set.
    match_id = ie._match_id
    assert match_id(url_mgl, 'http://soundgasm.net/u/ytdl') == 'ytdl'
    assert match_id(url_mgl, 'http://soundgasm.net/u/ytdl/') == 'ytdl'


# Generated at 2022-06-26 12:44:32.223232
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj1 = SoundgasmProfileIE()
    assert obj1._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert obj1._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert obj1._TEST['info_dict'] == {'id': 'ytdl'}
    assert obj1._TEST['playlist_count'] == 1


# Generated at 2022-06-26 12:44:33.275074
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-26 12:44:35.283813
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert IE.url == 'http://soundgasm.net/u/ytdl'

# Generated at 2022-06-26 12:44:46.028973
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Test the constructor and extract() method of class SoundgasmIE
    """
    from .common import COMMON_DOCUMENTS_URL
    ie = SoundgasmIE()
    assert ie.ie_key() == 'Soundgasm'
    assert ie.ie_name() == 'Soundgasm'
    assert ie.http_headers() is None
    assert ie.filepath_to_id() is None
    assert ie.age_limit is None
    assert ie.params is None
    assert ie._downloader is None
    assert ie.working_directory is None
    assert ie.storage is None

    # Test extract method

# Generated at 2022-06-26 12:44:52.518080
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info_dict = {
        'id': 'Piano-sample',
        'display_id': 'Piano-sample',
        'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
        'vcodec': 'none',
        'title': 'Piano sample',
        'description': 'Royalty Free Sample Music',
        'uploader': 'ytdl',
    }
    test_ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert test_ie.IE_NAME == 'Soundgasm'
    assert test_ie.extract(SoundgasmIE._TEST['url']) == info_dict


# Generated at 2022-06-26 12:45:03.797040
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# Normal Use:
	url = 'http://soundgasm.net/u/ytdl/Piano-sample'
	soundgasm_ie = SoundgasmIE()
	soundgasm_info = soundgasm_ie._real_extract(url)
	print(soundgasm_info)
	print(soundgasm_info['url'])
	print(soundgasm_info['title'])
	print(soundgasm_info['id'])
	print(soundgasm_info['description'])
	print(soundgasm_info['display_id'])
	print(soundgasm_info['uploader'])
	
	# Abnormal Use:
	url = 'http://soundgasm.net/u/ytdl/Piano-sample'
	soundgasm_ie = SoundgasmIE

# Generated at 2022-06-26 12:45:08.578908
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # create an instance of class SoundgasmProfileIE
    soundgasm_profile_ie = SoundgasmProfileIE()
    # test if object is of class SoundgasmProfileIE
    assert isinstance(soundgasm_profile_ie, SoundgasmProfileIE)
    assert soundgasm_profile_ie.url_re == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:45:11.372215
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasmie = SoundgasmIE()
    assert soundgasmie.IE_NAME == 'Soundgasm'

# Generated at 2022-06-26 12:45:21.869532
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE()
    ie._download_webpage = lambda url, display_id: """\
            <div id="jp-title">Piano sample</div>
            <li>Description: Royalty Free Sample Music</li>
            <input id="audio" value="m4a:http://audio.com/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a" />\
        """.replace('\n', '')


# Generated at 2022-06-26 12:45:23.961909
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    userIE = SoundgasmProfileIE('http://soundgasm.net/u/ytdl/')
    assert userIE.user == 'ytdl'

# Generated at 2022-06-26 12:46:03.623326
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 12:46:07.913979
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
		ie = SoundgasmProfileIE('soundgasm:profile')
		assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-26 12:46:11.522901
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:46:13.289203
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("***************************************\n")
    s = SoundgasmIE()
    print("***************************************\n")



# Generated at 2022-06-26 12:46:16.326298
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert('SoundgasmProfileIE' in globals())
    SoundgasmProfileIE_instance = SoundgasmProfileIE(SoundgasmProfileIE._downloader, 'http://soundgasm.net/u/ytdl')
    assert(isinstance(SoundgasmProfileIE_instance, object))


# Generated at 2022-06-26 12:46:17.199621
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE(None) is not None)


# Generated at 2022-06-26 12:46:18.712147
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE(InfoExtractor())._VALID_URL == SoundgasmIE._VALID_URL

# Generated at 2022-06-26 12:46:20.790802
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl', 'Soundgasm')


# Generated at 2022-06-26 12:46:23.567504
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        test = SoundgasmProfileIE(None)
    except Exception as e:
        print('test failed with error message: {}'.format(e))


# Generated at 2022-06-26 12:46:25.330308
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    _constructor = SoundgasmIE(None, None)
    assert _constructor is not None

# Generated at 2022-06-26 12:48:09.693506
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    try:
        assert SoundgasmProfileIE(
            SoundgasmProfileIE._VALID_URL, 'youtube-dl')
    except TypeError as e:
        assert 'super()' in str(e)

# Generated at 2022-06-26 12:48:10.786665
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    e = SoundgasmIE()
    assert e.IE_NAME == 'soundgasm'

# Generated at 2022-06-26 12:48:11.668508
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None)

# Generated at 2022-06-26 12:48:14.150413
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE().suitable(url) == True


# Generated at 2022-06-26 12:48:22.660268
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class Instance:
        def __init__(self, name, webpage, audioURL, title, description, audioID, displayID):
            self.name = name
            self.webpage = webpage
            self.audioURL = audioURL
            self.title = title
            self.description = description
            self.audioID = audioID
            self.displayID = displayID


# Generated at 2022-06-26 12:48:23.865868
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE()
    assert isinstance(instance, SoundgasmIE)


# Generated at 2022-06-26 12:48:25.053162
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	s = SoundgasmProfileIE()
	s.soundgasm_profile = SoundgasmProfileIE.playlist_result

# Generated at 2022-06-26 12:48:28.836078
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    if __name__ == '__main__':
        print(type(url))
    print('URL: ',url)
    soundgasm = SoundgasmIE()
    soundgasm.extract(url)

test_SoundgasmIE()


# Generated at 2022-06-26 12:48:31.723470
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE('test', 'SoundgasmProfileIE')
    # Set test value to make the unit test pass
    profile._VALID_URL = SoundgasmProfileIE._VALID_URL
    return profile

# Generated at 2022-06-26 12:48:32.986495
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None, SoundgasmProfileIE._TEST)
