

# Generated at 2022-06-26 12:41:41.653839
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie_0 = SoundgasmProfileIE()

if __name__ == '__main__':
    test_case_0()
    test_SoundgasmProfileIE()

# Generated at 2022-06-26 12:41:44.043694
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e = SoundgasmProfileIE()

# Generated at 2022-06-26 12:41:48.074529
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'

    assert type(url) == str
    # We expect the first parameter to be a string.

    soundgasm_i_e_0 = SoundgasmIE()
    soundgasm_i_e_0.test()


test_case_0()
# ------------------------------------------------------------------------------

# Generated at 2022-06-26 12:41:49.469277
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()


# Generated at 2022-06-26 12:41:50.635984
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass

# Generated at 2022-06-26 12:41:53.456945
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()


# Generated at 2022-06-26 12:41:57.285629
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE()
    mobj = ie._extract_url(url)
    assert mobj is not None, 'An error occurred while validating the URL.'
    assert True, 'The URL was validated correctly.'


# Generated at 2022-06-26 12:42:02.585786
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e = SoundgasmProfileIE()

if __name__ == '__main__':
    test_case_0()
    test_SoundgasmProfileIE()

# Generated at 2022-06-26 12:42:03.343177
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e = SoundgasmIE()

test_case_0()

# Generated at 2022-06-26 12:42:04.385937
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()

# Generated at 2022-06-26 12:42:11.932043
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    x = SoundgasmProfileIE()
    assert x.IE_NAME == 'soundgasm:profile'

test_SoundgasmProfileIE()

# Generated at 2022-06-26 12:42:18.062390
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-26 12:42:29.035913
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE()._real_extract("http://soundgasm.net/u/ytdl/Piano-sample")
    except:
        assert False

    try:
        SoundgasmIE()._real_extract("https://soundgasm.net/u/ytdl/Piano-sample")
    except:
        assert False

    try:
        SoundgasmIE()._real_extract("http://soundgasm.net/u/ytdl")
    except:
        assert False

    try:
        SoundgasmIE()._real_extract("https://soundgasm.net/u/ytdl")
    except:
        assert False

    assert True

# Generated at 2022-06-26 12:42:32.207424
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()

# Generated at 2022-06-26 12:42:37.125581
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Test class SoundgasmIE."""
    test_ie = SoundgasmIE()
    assert test_ie.IE_NAME == 'soundgasm'
    test_ie = SoundgasmIE('soundgasm')
    assert test_ie.IE_NAME == 'soundgasm'
    test_ie = SoundgasmIE(None)
    assert test_ie.IE_NAME == 'soundgasm'
    test_ie = SoundgasmIE(selected_ie=None)
    assert test_ie.IE_NAME == 'soundgasm'
    test_ie = SoundgasmIE('nonexisting_ie')
    assert test_ie.IE_NAME == 'soundgasm'
    test_ie = SoundgasmIE(selected_ie='nonexisting_ie')

# Generated at 2022-06-26 12:42:39.067760
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert isinstance(SoundgasmProfileIE(), InfoExtractor)

# Generated at 2022-06-26 12:42:48.114756
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert(SoundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-26 12:42:51.760167
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('Soundgasm.SoundgasmProfileIE', 'http://127.0.0.1:8080')

# Generated at 2022-06-26 12:42:58.056974
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    feature = SoundgasmIE(FakeYDL())
    feature.add_default_info_extractors()
    assert feature.suitable(feature.ie_key())
    assert feature.ie_key() == 'Soundgasm'
    assert len(feature._TESTS) > 0
    for (key,tests) in feature._TESTS.items():
        assert hasattr(feature, '_real_extract')


# Generated at 2022-06-26 12:43:08.677395
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    soundgasm = SoundgasmIE()
    assert soundgasm.IE_NAME == "soundgasm"
    assert soundgasm._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert soundgasm._TEST["url"] == "http://soundgasm.net/u/ytdl/Piano-sample"
    assert soundgasm._TEST["md5"] == "010082a2c802c5275bb00030743e75ad"

# Generated at 2022-06-26 12:43:28.347302
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    ie = SoundgasmIE()
    obj = ie._real_extract("http://soundgasm.net/u/ytdl/Piano-sample")
    assert obj['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert obj['display_id'] == 'Piano-sample'
    assert obj['vcodec'] == 'none'
    assert obj['url'] == 'https://media.soundgasm.net/sounds/88a/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    assert obj['title'] == 'Piano sample'

# Generated at 2022-06-26 12:43:32.215047
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    empty_dict = {}
    return SoundgasmProfileIE._test_suite('http://soundgasm.net/u/ytdl',
            empty_dict)

# Generated at 2022-06-26 12:43:40.627721
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    '''
    Test for constructor of class SoundgasmProfileIE.
    '''
    test_url = 'http://soundgasm.net/u/ytdl'
    test_regex = 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    soundgasm_profile_ie = SoundgasmProfileIE()
    assert soundgasm_profile_ie.IE_NAME == 'Soundgasm Profile'
    assert soundgasm_profile_ie._VALID_URL == test_regex
    assert soundgasm_profile_ie._match_id(test_url) == 'ytdl'

# Generated at 2022-06-26 12:43:41.502728
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('https://soundgasm.net/u/ytdl')

# Generated at 2022-06-26 12:43:42.489030
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()



# Generated at 2022-06-26 12:43:54.780502
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:43:56.475087
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-26 12:44:02.935620
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Constructor test
    """

    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    ie = SoundgasmIE()

    obj = re.match(ie._VALID_URL, url)

    assert obj.group('user')



# Generated at 2022-06-26 12:44:07.919074
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    get_test_instances({
        'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
        'md5': '010082a2c802c5275bb00030743e75ad',
        'info_dict': {
            'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
            'ext': 'm4a',
            'title': 'Piano sample',
            'description': 'Royalty Free Sample Music',
            'uploader': 'ytdl',
        }
    })

# Generated at 2022-06-26 12:44:20.013585
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    user = 'ytdl'
    display_id = 'Piano-sample'
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    title = 'Piano sample'
    description = 'Royalty Free Sample Music'
    audio_url = 'http://d.soundgasm.net/sounds/88abd86ea000cafe98f96321b23cc1206cbcbcc9/Piano-sample.m4a'
    webpage = '!http://soundgasm.net/u/ytdl/Piano-sample!'

    # Create instance of SoundgasmIE using a tuple
    testobj_tuple = SoundgasmIE(('http', 'soundgasm.net', '/u/ytdl/Piano-sample'))
    # Create instance of Soundgasm

# Generated at 2022-06-26 12:44:35.760562
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # TODO: write unit test
    pass

# Generated at 2022-06-26 12:44:41.523161
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url_ = 'http://soundgasm.net/u/ytdl/Piano-sample'
    IE = SoundgasmIE()
    mobj = re.match(IE._VALID_URL, url_)
    assert(mobj.group('user') == 'ytdl')
    assert(mobj.group('display_id') == 'Piano-sample')

# Generated at 2022-06-26 12:44:47.139569
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasm = SoundgasmIE()
    soundgasm._downloader = None
    soundgasmIE = soundgasm.extract(url)
    print(soundgasmIE)
    assert soundgasmIE is not None

if __name__=="__main__":
    test_SoundgasmIE()

# Generated at 2022-06-26 12:44:49.611444
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    inst = SoundgasmProfileIE('Soundgasm:profile')
    assert_raises(AttributeError, inst.url_result, "http://soundgasm.net/u/ytdl", "Soundgasm")

# Generated at 2022-06-26 12:44:50.727423
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	ie=SoundgasmProfileIE()
	print(ie)
	

# Generated at 2022-06-26 12:44:57.811008
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Test test case of SoundgasmIE."""
    # The case to check the result
    yield (None, {'url': 'http://soundgasm.net/u/ytdl/Piano-sample'},
           {'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
            'ext': 'm4a',
            'title': 'Piano sample',
            'description': 'Royalty Free Sample Music',
            'uploader': 'ytdl'})

# Generated at 2022-06-26 12:45:00.172015
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('Soundgasm')
    assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-26 12:45:01.205744
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass
    #assert SoundgasmIE() is not None

# Generated at 2022-06-26 12:45:05.125437
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasmIE = SoundgasmIE()
    assert soundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:45:12.285809
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	import os
	import argparse
	from subprocess import call, Popen, PIPE
	from you_get.extractors.soundgasm import SoundgasmIE
	from you_get.extractors.soundgasm import SoundgasmProfileIE
	from you_get.common import url_size
	#parser = argparse.ArgumentParser(description='Download the audio file from Soundgasm')
	#parser.add_argument('url', metavar='URL', type=str, help='The URL to download the audio file')

	#args = parser.parse_args()

	#url = args.url
	url = "http://soundgasm.net/u/ytdl/Piano-sample"
	file_id = SoundgasmIE._match_id(SoundgasmIE, url)
	audio_url, file

# Generated at 2022-06-26 12:45:54.343472
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:45:57.746473
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	assert SoundgasmIE(None)._VALID_URL == 'https?://(?:www\\.)?soundgasm\\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Test for extractor of class SoundgasmProfileIE

# Generated at 2022-06-26 12:46:08.693646
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .utils.mock import MockIE

    mocked_info_dict = {
        'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
        'ext': 'm4a',
        'title': 'Piano sample',
        'description': 'Royalty Free Sample Music',
        'uploader': 'ytdl',
    }

    mocked_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mocked_url_content = '<div>This is the webpage content</div>'

    instance = SoundgasmIE()

    # This is intended to check arguments for the returned mocked instance

# Generated at 2022-06-26 12:46:10.990354
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from soundgasmIE import SoundgasmProfileIE
    sgIe = SoundgasmProfileIE()
    assert isinstance(sgIe, InfoExtractor)

# Generated at 2022-06-26 12:46:11.819684
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    return SoundgasmProfileIE(None, None)

# Generated at 2022-06-26 12:46:15.842225
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasm_IE = SoundgasmIE({'url': soundgasm_url})
    assert soundgasm_IE.url == soundgasm_url, "Url constructor error"
    assert soundgasm_IE._VALID_URL, "Valid url not found"


# Generated at 2022-06-26 12:46:16.788312
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE() is not None


# Generated at 2022-06-26 12:46:20.709934
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasmIE = SoundgasmIE()
    # test SoundgasmIE instance
    assert isinstance(soundgasmIE, SoundgasmIE)
    # test SoundgasmIE function _real_extract
    assert isinstance(soundgasmIE._real_extract(soundgasmIE._TEST['url']), dict)

# Generated at 2022-06-26 12:46:28.868772
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("\n\nTESTING SOUNDGASM IE:")
    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE(None)
    url_info = ie._real_extract(test_url)
    assert url_info['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert url_info['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample.m4a'
    assert url_info['vcodec'] == 'none'


# Generated at 2022-06-26 12:46:30.994004
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
   ie = SoundgasmIE('test')
   assert ie is not None


# Generated at 2022-06-26 12:48:10.679915
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg = SoundgasmProfileIE()
    obj = vars(sg)
    assert obj['IE_NAME'] == 'soundgasm:profile'

# Generated at 2022-06-26 12:48:15.465498
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Unit test for constructor of class SoundgasmIE.
    """
    from youtube_dl.extractor.soundgasm import SoundgasmIE

    assert SoundgasmIE.ie_key() == 'Soundgasm'
    assert SoundgasmIE.ie_key() in SoundgasmIE.known_extractors
    assert SoundgasmIE.ie_key() in SoundgasmIE.working_extractors



# Generated at 2022-06-26 12:48:17.608944
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    loaded_module = __import__("soundgasm")
    assert loaded_module.SiteInfoRegistry.getInstance().is_registered("soundgasm")

# Generated at 2022-06-26 12:48:21.122086
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-26 12:48:23.802231
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    return_value = SoundgasmProfileIE()
    assert return_value.IE_NAME == 'soundgasm:profile'
    assert return_value._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:48:29.437657
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:48:37.132854
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import os

    #helper.copy_credentials_file()
    os.environ['YOUTUBE_ACCOUNT_CREDENTIALS_FILE'] = 'credentials.json'

    # SoundgasmProfileIE.__init__()
    SoundgasmProfileIE('Soundgasm:profile')

    # SoundgasmProfileIE._real_extract()
    SoundgasmProfileIE._real_extract(SoundgasmProfileIE,
        'http://soundgasm.net/u/ytdl')

    # SoundgasmProfileIE.suitable()
    SoundgasmProfileIE.suitable(SoundgasmProfileIE,
        'http://soundgasm.net/u/ytdl')

    # SoundgasmProfileIE._real_extract()

# Generated at 2022-06-26 12:48:45.342710
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # NOTE: the comment below is what you want to test
    # The tricky part is to construct a class that soundgasm you are testing uses
    # The class is SoundgasmIE, and it inherits from InfoExtractor.
    # So, you can use InfoExtractor as below
    class TestSoundgasmClass(InfoExtractor):
        class_description = 'Soundgasm IE'
        class_ie_key = 'SoundgasmIE'
        class_title = 'Soundgasm'

        # these two methods are necessary for the test
        def __init__(self, *args, **kwargs):
            InfoExtractor.__init__(self, *args, **kwargs)

        def report_extraction(self, ie_result):
            print("class description =", ie_result.get("class_description"))

# Generated at 2022-06-26 12:48:45.862216
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert True

# Generated at 2022-06-26 12:48:55.598937
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    user = 'ytdl'
    display_id = 'Piano-sample'
    info_dict = {
        'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
        'ext': 'm4a',
        'title': 'Piano sample',
        'description': 'Royalty Free Sample Music',
        'uploader': 'ytdl',
    }
    obj = SoundgasmIE()
    mobj = re.match(obj._VALID_URL, url)
    assert mobj is not None
    assert mobj.group('user') == user
    assert mobj.group('display_id') == display_id
    obj.url = url
    obj