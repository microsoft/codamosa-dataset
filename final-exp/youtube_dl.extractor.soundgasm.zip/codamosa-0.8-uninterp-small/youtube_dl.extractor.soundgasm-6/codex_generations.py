

# Generated at 2022-06-26 12:41:41.493440
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass
# end


# Generated at 2022-06-26 12:41:49.912447
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    u = r'https://soundgasm.net/u/ytdl/Piano-sample'
    #Make an instance of InfoExtractor
    soundgasm_i_e = SoundgasmIE()

    #Check if instance created successfully
    if soundgasm_i_e:
        print("Successfully created InfoExtractor for soundgasm instance")
    else:
        print("Instance is not created for soundgasm")
    assert soundgasm_i_e

    #Check if method _real_extract exists
    if hasattr(soundgasm_i_e, '_real_extract'):
        print("_real_extract method found")
    else:
        print("_real_extract method not found")
    assert hasattr(soundgasm_i_e, '_real_extract')

    # Call

# Generated at 2022-06-26 12:41:52.380449
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()


# Generated at 2022-06-26 12:41:53.842924
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE().toString()

# Generated at 2022-06-26 12:41:55.547962
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert_not_null(SoundgasmIE)


# Generated at 2022-06-26 12:41:57.606555
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-26 12:42:00.520481
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e = SoundgasmProfileIE()


# Generated at 2022-06-26 12:42:02.516312
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e = SoundgasmIE()


# Generated at 2022-06-26 12:42:04.644079
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e = SoundgasmIE()


# Generated at 2022-06-26 12:42:06.251164
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_i_e_0 = SoundgasmProfileIE()

# Generated at 2022-06-26 12:42:12.831029
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	assert(str(SoundgasmIE) == "<class '__main__.SoundgasmIE'>")


# Generated at 2022-06-26 12:42:13.726614
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert [SoundgasmIE(None).IE_NAME] == [SoundgasmIE.IE_NAME]


# Generated at 2022-06-26 12:42:20.971934
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# Constructor of the class
	constr_obj = SoundgasmIE()
	# Assertions to check whether all the values are set or not
	assert constr_obj._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:42:22.359757
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert 'Soundgasm' in globals()

# Generated at 2022-06-26 12:42:26.599034
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test URL access
    test_url = 'http://soundgasm.net/u/ytdl'
    profile = SoundgasmProfileIE()
    profile.extract(test_url)

# Generated at 2022-06-26 12:42:27.778785
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.IE_NAME

# Generated at 2022-06-26 12:42:29.748720
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	pass


# Generated at 2022-06-26 12:42:33.379993
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    data = SoundgasmIE(url)
    assert data.url == url

# Generated at 2022-06-26 12:42:46.290117
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    # Test URL with profile and display id
    test_url_1 = 'http://soundgasm.net/u/ytdl/Piano-sample'
    # Test URL with profile and no display id
    test_url_2 = 'http://soundgasm.net/u/ytdl/'
    # Test URL with profile and no soundgasm.net
    test_url_3 = 'http://soundgasm.net/u/ytdl'

    class MockInfoExtractor():
        extractor_key = 'MockInfoExtractor'

    ie = SoundgasmIE()

    assert ie.IE_NAME == 'soundgasm'

# Generated at 2022-06-26 12:42:47.630652
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	SoundgasmProfileIE()

# Generated at 2022-06-26 12:42:59.924556
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_object = SoundgasmIE()
    test_object._download_webpage(
        "http://soundgasm.net/u/ytdl/Piano-sample", "Piano-sample")
    test_object._search_regex(
        r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1',
        test_object.webpage,
        'audio URL',
        group='url')

# Generated at 2022-06-26 12:43:03.034586
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from common import test_soundgasm
    ie = SoundgasmIE()
    test_soundgasm.test_soundgasm(ie)

# Generated at 2022-06-26 12:43:05.506524
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # to test whether the constructor is right
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:43:08.053521
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE(1)
    except:
        assert 0

# Generated at 2022-06-26 12:43:16.129778
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .common import urlopen
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    webpage = urlopen(url).read()
    ie = SoundgasmIE()
    output = ie._real_extract(url)
    assert output['url'] == 'https://media-2.soundgasm.net/sounds/88abd86ea000cafe98f96321b23cc1206cbcbcc9/1534943-125670-Piano-sample.m4a'

# Generated at 2022-06-26 12:43:18.180927
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == "Soundgasm"

# Generated at 2022-06-26 12:43:21.591406
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class_ = SoundgasmIE
    testing_class = class_('Soundgasm')
    assert testing_class.IE_NAME == 'Soundgasm'

# Generated at 2022-06-26 12:43:25.895069
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print("Running constructor unit test for SoundgasmProfileIE...")

    url = "http://soundgasm.net/u/ytdl"

    SoundgasmProfileIE()._real_extract(url)


# Generated at 2022-06-26 12:43:37.606409
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
  SoundgasmIE('Soundgasm', '88abd86ea000cafe98f96321b23cc1206cbcbcc9')
  SoundgasmIE('Soundgasm', 'm4a:http://d2ua9h7wyx0g31.cloudfront.net/media/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a')
  # or
  ie = SoundgasmIE('Soundgasm', 'm4a:http://d2ua9h7wyx0g31.cloudfront.net/media/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a')
  if ie is None:
    return

# Generated at 2022-06-26 12:43:41.606074
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print("test_SoundgasmProfileIE")
    url = 'http://soundgasm.net/u/ytdl'
    t = SoundgasmProfileIE(url)
    assert(t.url == url)

# Generated at 2022-06-26 12:44:05.063488
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE(url)
    assert ie.url == url
    assert ie.ie_name == 'SoundgasmProfileIE'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:44:14.623609
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl', 'en')
    # Assert url is valid
    ie.validate_url('http://soundgasm.net/u/ytdl')

    # Assert url is not valid
    ie.validate_url('http://soundgasm.net/u/ytdl/Piano-sample')
    ie.validate_url('http://soundgasm.net/u/ytdl/bad_url')

# Generated at 2022-06-26 12:44:24.477713
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert SoundgasmIE._match_id(url) == 'ytdl'
    assert SoundgasmIE._match_id('https://soundgasm.net/u/ytdl/Piano-sample') == 'ytdl'
    assert SoundgasmIE._match_id('http://www.soundgasm.net/u/ytdl/Piano-sample') == 'ytdl'
    assert SoundgasmIE._match_id('https://www.soundgasm.net/u/ytdl/Piano-sample') == 'ytdl'
    assert SoundgasmIE._match_id('http://soundgasm.net/u/ytdl') == 'ytdl'
    assert SoundgasmIE._match

# Generated at 2022-06-26 12:44:31.993422
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.provider() == 'Soundgasm'
    assert ie.provider_url() == 'http://www.soundgasm.net/'
    assert ie.name() == 'Soundgasm'
    assert ie.description() == None
    assert ie._type() == 'playlist'
    assert ie.url() == 'http://soundgasm.net/u/ytdl'
    assert ie.id() == 'ytdl'

# Generated at 2022-06-26 12:44:41.374464
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        profileIE = SoundgasmProfileIE('http://soundgasm.net/u/ytdl', 'ytdl')
    except:
        assert False
    assert profileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert profileIE._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert profileIE._TEST['info_dict']['id'] == 'ytdl'
    assert profileIE._TEST['playlist_count'] == 1

    # Unit test for _real_extract of class SoundgasmProfileIE
    playlist = profileIE._real_extract('http://soundgasm.net/u/ytdl')



# Generated at 2022-06-26 12:44:43.447736
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    resp = SoundgasmProfileIE()
    assert resp

# Generated at 2022-06-26 12:44:45.104529
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE()
    except:
        pass
    else:
        assert False


# Generated at 2022-06-26 12:44:49.039093
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg_profile_ie = SoundgasmProfileIE()
    assert sg_profile_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:44:55.767475
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert hasattr(SoundgasmProfileIE, "name")
    assert hasattr(SoundgasmProfileIE, "description")
    assert hasattr(SoundgasmProfileIE, "version")
    assert hasattr(SoundgasmProfileIE, "_VALID_URL")
    assert hasattr(SoundgasmProfileIE, "_TEST")
    assert hasattr(SoundgasmProfileIE, "_download_webpage")
    assert hasattr(SoundgasmProfileIE, "url_result")
    assert hasattr(SoundgasmProfileIE, "playlist_result")


# Generated at 2022-06-26 12:45:05.966785
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()._REAL_EXTENSION == 'mp4'
    assert SoundgasmIE()._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert SoundgasmIE().IE_NAME == 'soundgasm'

# Generated at 2022-06-26 12:45:54.308419
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Verifies that the constructor of class SoundgasmProfileIE works."""
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/([^/]+)/?(?:#.*)?$'
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1
    }

# Generated at 2022-06-26 12:45:55.119008
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-26 12:45:56.207065
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-26 12:46:04.920436
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Test the methods in class SoundgasmIE
    """
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    seg = SoundgasmIE()
    print("\n First unit test for SoundgasmIE")
    print("\n First test: extract 'URL' from class SoundgasmIE")
    print("\n Extract URL from class SoundgasmIE:")
    print(seg._VALID_URL)
    print("\n Expected result:")
    print("https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)")

# Generated at 2022-06-26 12:46:11.702827
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    result = SoundgasmProfileIE._build_ie_result(SoundgasmProfileIE, url, {'id': 'ytdl'})
    assert result['_type'] == 'playlist'
    assert result['id'] == 'ytdl'
    assert result['entries'][0]['id'] == 'Piano-sample'


# Generated at 2022-06-26 12:46:13.137324
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'


# Generated at 2022-06-26 12:46:19.202668
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.ie_key() == 'Soundgasm'
    ie = SoundgasmIE(SoundgasmIE.ie_key())
    assert ie.ie_key() == 'Soundgasm'
    assert ie.extract('http://soundgasm.net/u/ytdl/Piano-sample') == {'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9', 'url': 'http://media.soundgasm.net/u/ytdl/Piano-sample.m4a', 'ext': 'm4a', 'vcodec': 'none'}

# Generated at 2022-06-26 12:46:21.649952
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie.IE_NAME == 'soundgasm'


# Generated at 2022-06-26 12:46:26.818636
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE(InfoExtractor())
    assert soundgasm_profile_ie is not None
    assert soundgasm_profile_ie._VALID_URL ==  r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-26 12:46:27.649232
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert SoundgasmProfileIE()

# Generated at 2022-06-26 12:48:08.105275
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()  # Test SoundgasmIE constructor

# Generated at 2022-06-26 12:48:11.959627
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:48:18.708121
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    sg_ie = SoundgasmIE()
    assert isinstance(sg_ie, InfoExtractor)
    assert sg_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert sg_ie._TEST['url'] == "http://soundgasm.net/u/ytdl/Piano-sample"
    assert sg_ie._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'
    assert sg_ie._TEST['id']

# Generated at 2022-06-26 12:48:21.337343
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import sys
    import json

    # test using the example URL provided above in this file
    with open(sys.argv[1], 'r') as input_json:
        input_json = json.load(input_json)
        SoundgasmIE()._real_extract(input_json['url'])

# Generated at 2022-06-26 12:48:22.013931
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE(None)

# Generated at 2022-06-26 12:48:28.065222
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:48:34.728027
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/sunshine218/Piano-sample"
    sg = SoundgasmIE()
    assert (sg.IE_NAME == 'soundgasm')
    assert (sg.countries == ['US'])
    assert (sg._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')
    assert (sg._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-26 12:48:35.442979
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-26 12:48:40.297253
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = SoundgasmProfileIE._VALID_URL
    playlists_url = re.findall(SoundgasmProfileIE._VALID_URL, url)
    playlist1 = playlists_url[0]
    playlist2 = playlists_url[1]
    playlist3 = playlists_url[2]
    if playlist1 != playlist2 and playlist2 != playlist3 and playlist1 != playlist3:
        print ("SoundgasmProfileIE successfully extracted the playlists urls")


# Generated at 2022-06-26 12:48:42.263307
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    sys_argv = ['', url]
    SoundgasmProfileIE().run(sys_argv)