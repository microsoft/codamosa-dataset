

# Generated at 2022-06-26 12:41:40.387837
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_0 = SoundgasmIE()


# Generated at 2022-06-26 12:41:42.648773
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_0 = SoundgasmIE()


# Generated at 2022-06-26 12:41:45.123260
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert test_case_0() == None, 'Failed at constructing SoundgasmProfileIE'


# Generated at 2022-06-26 12:41:46.918995
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    soundgasm_i_e = SoundgasmIE()


# Generated at 2022-06-26 12:41:53.915532
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert soundgasm_profile_i_e_0.IE_NAME == 'soundgasm:profile'
    assert SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-26 12:41:55.153667
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_0 = SoundgasmIE()


# Generated at 2022-06-26 12:41:57.157942
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e = SoundgasmIE()


# Generated at 2022-06-26 12:42:06.958699
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  url = "http://soundgasm.net/u/ytdl"
  soundgasm_profile_i_e_1 = SoundgasmProfileIE()
  assert soundgasm_profile_i_e_1.suitable(url)
  assert soundgasm_profile_i_e_1._real_extract(url)["id"] == "ytdl"
  assert soundgasm_profile_i_e_1.IE_NAME == "soundgasm:profile"


# Generated at 2022-06-26 12:42:09.647522
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_i_e_0 = SoundgasmIE()

# Generated at 2022-06-26 12:42:14.371964
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert_equals(soundgasm_profile_i_e_0._VALID_URL, 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
    assert_equals(soundgasm_profile_i_e_0._TEST, {'url': 'http://soundgasm.net/u/ytdl', 'playlist_count': 1, 'info_dict': {'id': 'ytdl'}})
    assert_equals(soundgasm_profile_i_e_0._NETRC_MACHINE, 'soundgasm')

# Generated at 2022-06-26 12:42:24.319896
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from pytest import raises
    from soundgasm_dl.extractor import SoundgasmIE
    with raises(TypeError):
        SoundgasmIE(None)
    s = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    s.to_screen('foo')

# Generated at 2022-06-26 12:42:30.494067
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('id')
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-26 12:42:35.274244
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE()
        print('SoundgasmIE constructor test PASSED!')
        return 0
    except:
        print('SoundgasmIE constructor test FAILED.')
        return 1


# Generated at 2022-06-26 12:42:46.459810
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import os
    import unittest
    from soundgasm import SoundgasmProfileIE

    class TestSoundgasmProfileIE(unittest.TestCase):
        def setUp(self):
            self.url = 'http://soundgasm.net/u/ytdl'
            self.profile = SoundgasmProfileIE(self.url)

        def test__real_initialisation(self):
            self.assertEqual(self.profile.url, self.url)

        def test_SoundgasmProfileIE_class_should_be_properly_initialized(self):
            self.assertEqual(self.profile.profile_id, 'ytdl')

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-26 12:42:56.783054
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # check if the constructor works fine
    SongProfile = SoundgasmProfileIE('1')
    assert SongProfile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert SongProfile._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert SongProfile._TEST['info_dict']['id'] == 'ytdl'
    assert SongProfile._TEST['playlist_count'] == 1

# Generated at 2022-06-26 12:42:59.569806
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-26 12:43:07.679470
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert a.IE_NAME == 'soundgasm:profile'
    assert a._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert a._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-26 12:43:17.768050
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        from urllib.parse import urljoin
    except ImportError:
        from urlparse import urljoin

    # Testing the constructor of class SoundgasmProfileIE
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    pattern = re.compile(r'https?://(?:www\.)?soundgasm\.net/u/([^/]+)/?(?:\#.*)?$')
    mobj = pattern.match(url)
    profile_id = mobj.group(1)
    webpage = SoundgasmProfileIE()._download_webpage(url, profile_id)


# Generated at 2022-06-26 12:43:18.732649
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	pass

# Generated at 2022-06-26 12:43:29.435691
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Constructor of class SoundgasmIE
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    # Constuctor of class SoundgasmIE accepts url in the following format
    assert ie.IE_NAME == 'soundgasm'
    # Constuctor of class SoundgasmIE accepts url in the following format
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    # Constuctor of class SoundgasmIE accepts url in the following format

# Generated at 2022-06-26 12:43:46.959533
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    tester = SoundgasmIE()
    assert tester._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert tester._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert tester._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-26 12:43:50.460544
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-26 12:43:53.016116
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .test import run_test
    run_test('soundgasm:profile', SoundgasmProfileIE)

# Generated at 2022-06-26 12:43:59.331877
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    # ie = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    ie = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    assert ie._download_webpage("http://soundgasm.net/u/ytdl/Piano-sample") == None
    assert ie._search_regex("http://soundgasm.net/u/ytdl/Piano-sample") == None
    assert ie._real

# Generated at 2022-06-26 12:44:01.552132
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import doctest
    doctest.testmod()


# Generated at 2022-06-26 12:44:09.937158
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	''' Test for good instantiation of class SoundgasmIE '''
	test = SoundgasmIE()
	print(test)
	assert test.IE_NAME == 'soundgasm'
	ie_name = (test.IE_NAME == 'soundgasm')
	assert test._VALID_URL == 'https?://(?:www\\.)?soundgasm\\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:44:14.382812
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert SoundgasmProfileIE(soundgasm_IE, 'C:/Users/OMB/Desktop/python/others/ytdl/ytdl/tests/test_data/test_data.txt')

# Generated at 2022-06-26 12:44:17.231845
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL == SoundgasmProfileIE._VALID_URL
    assert SoundgasmProfileIE()._TEST == SoundgasmProfileIE._TEST

# Generated at 2022-06-26 12:44:27.570003
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info_extractor = SoundgasmIE()
    
    # Test constructor of class SoundgasmIE
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert info_extractor._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample' 
    assert info_extractor._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-26 12:44:30.370521
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .modules import soundgasm as sg
    assert isinstance(sg.SoundgasmProfileIE('soundgasm'), sg.SoundgasmProfileIE)

# Generated at 2022-06-26 12:44:49.933645
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_ie = SoundgasmIE()
    soundgasm_ie.add_ie(SoundgasmIE.ie_key())
    soundgasm_ie.add_ie(SoundgasmProfileIE.ie_key())
    return soundgasm_ie

if __name__ == '__main__':
    print(test_SoundgasmIE())

# Generated at 2022-06-26 12:44:53.644034
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Test class SoundgasmProfileIE"""
    #class name
    name = "SoundgasmProfileIE"
    #constructor of class SoundgasmProfileIE
    soundgasm_profile_ie = SoundgasmProfileIE(name, {})
    assert name == soundgasm_profile_ie.ie_key()


# Generated at 2022-06-26 12:44:55.767040
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('SoundgasmProfileIE', 'test_type')

# Generated at 2022-06-26 12:45:05.966665
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test that a constructor worked
    ie = SoundgasmIE('https://www.soundgasm.net/u/ytdl/Piano-sample')
    # Test a private method
    audio_url = ie._html_search_regex(
        r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1',
        '<script>\nm4a : \'http://audiofiles.soundgasm.net/u/ytdl/Piano-sample.m4a\'',
        'audio URL', group='url')
    # Test properties
    assert ie.ie_key() == 'Soundgasm'
    assert ie.ie_name() == 'soundgasm'
    assert ie.ie_version() == '1.0'
    assert ie

# Generated at 2022-06-26 12:45:07.382641
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_ie = SoundgasmIE()
    soundgasm_ie._download_webpage("", "")

# Generated at 2022-06-26 12:45:08.729403
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmIE({
            'Test':'hello'
    })
    ie.test()

# Generated at 2022-06-26 12:45:09.757511
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE()
    assert instance is not None


# Generated at 2022-06-26 12:45:14.493543
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info_extractor = SoundgasmProfileIE()
    assert info_extractor.IE_NAME == 'soundgasm:profile'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert info_extractor._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-26 12:45:17.284158
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    ie = SoundgasmIE.from_crawler(None)
    ie.extract_info(url)

# Generated at 2022-06-26 12:45:27.048745
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import sys
    from .test_utils import get_testcases
    from .common import parse_duration
    SoundgasmProfileIE = sys.modules['youtube_dl.extractor.soundgasm'].SoundgasmProfileIE
    ie = SoundgasmProfileIE('Soundgasm', 'http://soundgasm.net/u/ytdl', {})

# Generated at 2022-06-26 12:46:12.638547
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_SoundgasmProfileIE_url = ['http://soundgasm.net/u/ytdl']
    test_SoundgasmProfileIE_class = SoundgasmProfileIE

    assert test_SoundgasmProfileIE_class.suitable(test_SoundgasmProfileIE_url[0]) == True
    test_SoundgasmProfileIE_video = test_SoundgasmProfileIE_class.ie_key(
        test_SoundgasmProfileIE_url[0])
    assert type(test_SoundgasmProfileIE_video) == type(list())
    assert test_SoundgasmProfileIE_video[1] == 'ytdl'

# Generated at 2022-06-26 12:46:14.911587
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/daniel_florida'
    ie = SoundgasmProfileIE()
    assert(ie._match_id(url) == 'daniel_florida')

# Generated at 2022-06-26 12:46:23.963785
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
  soundgasmIE = SoundgasmIE()
  assert(soundgasmIE.IE_NAME == 'soundgasm')
  assert(soundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-26 12:46:33.447398
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Verifies the test_SoundgasmProfileIE function
    """
    class TestSoundgasmProfileIE(SoundgasmProfileIE):
        """
        class to test the playlist length
        """
        def __init__(self, *args, **kwargs):
            """
            Initializes the object
            """
            self.len_playlist = 0
            super(TestSoundgasmProfileIE, self).__init__(*args, **kwargs)

        def _real_extract(self, url):
            """
            Returns a dictionary and playlist length
            """
            playlist = super(TestSoundgasmProfileIE, self)._real_extract(url)
            self.len_playlist = len(playlist['entries'])
            return playlist

    obj = TestSoundgasmProfileIE()
    obj._download_web

# Generated at 2022-06-26 12:46:35.661706
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE("", "", "", "", "", "", "")
    assert soundgasm_profile_ie.IE_NAME == "soundgasm:profile"


# Generated at 2022-06-26 12:46:37.038302
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Constructor of class SoundgasmProfileIE should take two arguments
    assert SoundgasmProfileIE.__init__.__code__.co_argcount == 2

# Generated at 2022-06-26 12:46:40.401409
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert isinstance(ie, SoundgasmIE)
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie.IE_NAME == 'soundgasm'

# Generated at 2022-06-26 12:46:48.714419
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # unit test for constructor
    obj = SoundgasmIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-26 12:46:53.161178
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    #TEST_CASES = [
    #    {
    #        "url": "http://soundgasm.net/u/ytdl/Piano-sample",
    #    },
    #]
    #
    #for test_case in TEST_CASES:
    #    try:
    #        assert SoundgasmIE._VALID_URL in test_case["url"]
    #    except:
    #        print "test_case_url: "+test_case["url"]+" doesn't match SoundgasmIE._VALID_URL"
    pass

# Generated at 2022-06-26 12:46:55.053581
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert (SoundgasmProfileIE())._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-26 12:48:35.824121
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    def test_SoundgasmProfileIE():
        """Unit test for constructor of class SoundgasmProfileIE"""

        testargs = {
            'access_token': 'asdfgqwer1234',
            'device_id': '1234890abcdef',
            'referrer': 'http://soundgasm.net/u/ytdl',
            'user_agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
        }
        testargs = dict(testargs.items())
        if sys.version_info[0] == 2:
            testargs = dict(testargs.iteritems())


# Generated at 2022-06-26 12:48:37.805293
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE()
    assert soundgasm_profile_ie.IE_NAME == 'Soundgasm'

# Generated at 2022-06-26 12:48:42.434220
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'
    assert SoundgasmProfileIE._TEST == { 'url': 'http://soundgasm.net/u/ytdl', 'info_dict': { 'id': 'ytdl' }, 'playlist_count': 1}

# Generated at 2022-06-26 12:48:44.272167
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()
    assert obj.ie_name == 'Soundgasm Profile'

# Generated at 2022-06-26 12:48:53.798275
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    #Unit test for constructor of class SoundgasmIE
    ################################################
    print()
    print("en test_SoundgasmIE: ")
    a = SoundgasmIE()
    print(a._TEST['url'])
    print(a._TEST['md5'])
    print(a._TEST['info_dict'].get('id'))
    print(a._TEST['info_dict'].get('ext'))
    print(a._TEST['info_dict'].get('title'))
    print(a._TEST['info_dict'].get('description'))
    print(a._TEST['info_dict'].get('uploader'))
    print()

    #extract id from url
    print("extract id from url: ")

# Generated at 2022-06-26 12:48:54.625639
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-26 12:48:58.322419
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_instance = SoundgasmProfileIE()
    assert test_instance._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert test_instance.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-26 12:48:59.954126
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg = SoundgasmProfileIE()
    assert(type(sg) == SoundgasmProfileIE)


# Generated at 2022-06-26 12:49:01.854978
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()._extract_profile(u'SoundgasmProfileIE',u'http://soundgasm.net/u/ytdl')

# Generated at 2022-06-26 12:49:03.197138
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
