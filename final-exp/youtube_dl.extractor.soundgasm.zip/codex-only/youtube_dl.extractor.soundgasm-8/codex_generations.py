

# Generated at 2022-06-24 13:08:25.015761
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # test case: url not valid format
    test_cases = ([],
                  [''],
                  ['http://soundgasm.net/u/ytdl'])
    for test_input in test_cases:
        actual = SoundgasmIE(test_input)
        expected = None
        # assertion
        assert actual == expected
    # test case: url valid format
    test_input = 'http://soundgasm.net/u/ytdl'
    actual = SoundgasmIE(test_input)
    expected = object
    # assertion
    assert isinstance(actual, expected)


# Generated at 2022-06-24 13:08:34.016935
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # construct an object of class SoundgasmIE
    assert SoundgasmIE() != None
    s = SoundgasmIE()
    assert s.info_dict != None
    assert s.name == 'Soundgasm'
    assert s.user_agent == 'ytdl'
    assert s.IE_NAME == 'Soundgasm'
    assert s.VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

test_SoundgasmIE()


# Generated at 2022-06-24 13:08:37.334423
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Simple unit test to validate the constructor of class SoundgasmProfileIE
    """
    ie = SoundgasmProfileIE()
    test = 'http://soundgasm.net/u/ytdl'
    ie.suitable('%s' % test)

# Generated at 2022-06-24 13:08:37.926244
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert True

# Generated at 2022-06-24 13:08:42.087821
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mobj = re.match(ie._VALID_URL, url)
    assert mobj.group('user') == 'ytdl'
    assert mobj.group('display_id') == 'Piano-sample'


# Generated at 2022-06-24 13:08:45.293404
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	url = 'http://soundgasm.net/u/ytdl'
	args = [url]
	self = SoundgasmProfileIE()
	self.SoundgasmProfileIE(*args)

# Generated at 2022-06-24 13:08:47.475809
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    url = ie._VALID_URL
    ie._real_extract(url)


# Generated at 2022-06-24 13:08:48.455888
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(True is True)

# Generated at 2022-06-24 13:08:57.761880
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import youtube_dl.postprocessor.ffmpeg
    import youtube_dl.YoutubeDL

    class MySoundgasmIE(SoundgasmIE):
        def __init__(self, *args, **kwargs):
            super(MySoundgasmIE, self).__init__(*args, **kwargs)
            self._count = 0

        def report_warning(self, msg):
            self._count += 1

    my_ydl = youtube_dl.YoutubeDL()
    my_ydl.add_info_extractor(MySoundgasmIE)
    my_ydl.add_post_processor(youtube_dl.postprocessor.ffmpeg.FFmpegPostProcessor())
    my_ydl.download(['https://soundgasm.net/u/ytdl/Piano-sample'])
    assert my_ydl

# Generated at 2022-06-24 13:09:00.191879
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_ie = SoundgasmIE()
    assert test_ie.IE_NAME == "soundgasm"


# Generated at 2022-06-24 13:09:04.215098
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	sgprofile = SoundgasmProfileIE()
	sgprofile.IE_NAME == "soundgasm:profile"
	sgprofile._TEST['url'] == "http://soundgasm.net/u/ytdl"
	isinstance(sgprofile, InfoExtractor) == True

# Generated at 2022-06-24 13:09:07.566607
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert soundgasm_ie is not None


# Generated at 2022-06-24 13:09:12.025554
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    '''
    Constructor of class SoundgasmIE
    '''
    obj = SoundgasmIE()

# Generated at 2022-06-24 13:09:16.626472
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	url = "http://soundgasm.net/u/ytdl"
	#assert SoundgasmProfileIE(url, None).get_filename() == "ytdl"
	assert SoundgasmProfileIE(url, None)._type == "playlist"


# Generated at 2022-06-24 13:09:17.523985
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert (SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample') != None)

# Generated at 2022-06-24 13:09:24.649443
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	
	src=SoundgasmIE()._download_webpage_handle(url='http://soundgasm.net/u/ytdl/Piano-sample',video_id='Piano-sample',note='Downloading page',errnote='Unable to download webpage')
	src_b=src.read()
	
	src=SoundgasmIE()._download_webpage_handle(url='http://soundgasm.net/u/ytdl/Piano-sample',video_id='Piano-sample',note='Downloading page',errnote='Unable to download webpage')
	src_r=src.read()
	
	assert src_b==src_r
	print("test passed")
	
test_SoundgasmIE()

# Generated at 2022-06-24 13:09:29.777799
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # It is not a good extraction test. It tests that the constructor can be called
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE(url)
    SoundgasmIE(url + '#some_name?some_param=some_value')

# Generated at 2022-06-24 13:09:30.326792
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:09:35.233440
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	t1 = SoundgasmIE()
	t2 = SoundgasmProfileIE()
	t3 = SoundgasmIE()
	assert t1.IE_NAME == 'soundgasm'
	assert t2.IE_NAME == 'soundgasm:profile'
	assert t3.IE_NAME == 'soundgasm'


# Generated at 2022-06-24 13:09:39.765579
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Testing SoundgasmProfileIE without webpage and webpage source code
    obj = SoundgasmProfileIE('SoundgasmProfileIE','http://soundgasm.net/u/ytdl','','','','','','','','','','','','','','','')
    # Testing SoundgasmProfileIE with webpage and webpage source code
    obj = SoundgasmProfileIE('SoundgasmProfileIE','http://soundgasm.net/u/ytdl','webpage','webpage source code','','','','','','','','','','','','','')
    # Testing SoundgasmProfileIE with webpage, webpage source code and playlist_count
    obj = SoundgasmProfileIE('SoundgasmProfileIE','http://soundgasm.net/u/ytdl','webpage','webpage source code','','','','','','','','','','','','',3)


# Generated at 2022-06-24 13:09:43.827139
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:09:47.550490
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    testInstance = SoundgasmIE()
    assert testInstance._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-24 13:09:48.691738
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None)

# Generated at 2022-06-24 13:09:51.225978
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE(
        'http://example.com/foo/bar',
        'http://example.com/foo/bar',
        'http://example.com/foo/bar')

# Generated at 2022-06-24 13:09:55.375802
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Constructor test - checks if instance of SoundgasmIE class is created successfully
    """
    assert SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    print("\nInstance of SoundgasmIE created successfully!")


# Generated at 2022-06-24 13:09:57.293508
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:09:59.049621
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE(None)._VALID_URL == SoundgasmIE._VALID_URL


# Generated at 2022-06-24 13:10:09.946309
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # get constructor
    s = SoundgasmIE()

    # get description
    description = 'This is a test description.'
    title = 'Test Title'
    webpage = r"""
<div class="jp-title">%s</div>
<div class="jp-description">%s</div>
""" % (title, description)

    # check for valid url
    url = 'http://soundgasm.net/u/ytdl/TestTitle'
    m = s._VALID_URL.search(url)

    # do real extract
    info = s._real_extract(url)

    assert info['url'] == 'http://soundgasm.net/u/ytdl/TestTitle.m4a'
    assert info['title'] == 'Test Title'
    assert info['vcodec'] == 'none'
   

# Generated at 2022-06-24 13:10:11.874739
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'Soundgasm:profile'
    assert ie.IE_NAME == 'Soundgasm:Profile'

# Generated at 2022-06-24 13:10:15.779753
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    assert ie.match("http://soundgasm.net/u/ytdl")
    assert ie.match("http://soundgasm.net/u/ytdl/")


# Generated at 2022-06-24 13:10:21.613070
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from pytest import raises
    from soundgasm.soundgasm_profile import SoundgasmProfileIE
    webpage = 'http://soundgasm.net/u/ytdl'
    with raises(InfoExtractor.DownloadError) as excinfo:
        SoundgasmProfileIE(webpage,'http://soundgasm.net/u/ytdl/Piano-sample')
    assert excinfo




# Generated at 2022-06-24 13:10:23.696742
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	url = 'http://soundgasm.net/u/ytdl/Piano-sample'
	SoundgasmIE()._download_webpage(url)


# Generated at 2022-06-24 13:10:24.174652
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	pass

# Generated at 2022-06-24 13:10:31.807581
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE()
    assert profile.IE_NAME == 'soundgasm:profile'
    assert profile._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert profile._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-24 13:10:35.668442
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test constructor
    try:
        object = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
        assert object.IE_NAME == 'SoundgasmIE', 'Unit test for this class is failed.'
    except:
        print('Unit test for this class is failed.')

# Generated at 2022-06-24 13:10:37.490328
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    s = SoundgasmProfileIE('')
    assert SoundgasmProfileIE._VALID_URL == s.VALID_URL

# Generated at 2022-06-24 13:10:43.354459
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        # Create Instance
        se = SoundgasmProfileIE()

        # Run test
        result = se._real_extract("http://soundgasm.net/u/ytdl")
        assert result["id"] == "ytdl"
    except Exception as e:
        print("error in SoundgasmProfileIE unit test")
        print(str(e))
        assert False


# Generated at 2022-06-24 13:10:53.035924
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test on page whose url is of the form 'http://soundgasm.net/u/ytdl/',
    # and it has 3 sound clips on it.
    obj_SoundgasmProfileIE = SoundgasmProfileIE()
    obj_SoundgasmProfileIE.url = 'http://soundgasm.net/u/ytdl/'
    obj_SoundgasmProfileIE.ie_key = 'SoundgasmProfile'
    obj_SoundgasmProfileIE._match_id = obj_SoundgasmProfileIE.url
    assert obj_SoundgasmProfileIE.ie_key == 'SoundgasmProfile'
    assert obj_SoundgasmProfileIE.url == 'http://soundgasm.net/u/ytdl/'

# Generated at 2022-06-24 13:10:55.681169
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg_profile_ie = SoundgasmProfileIE()
    assert sg_profile_ie is not None

if __name__ == '__main__':
    test_SoundgasmProfileIE()

# Generated at 2022-06-24 13:10:58.794172
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    a = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert a.__class__.__name__ == 'SoundgasmIE'


# Generated at 2022-06-24 13:11:02.459961
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    CE = SoundgasmProfileIE("This is a title", "This is the profile ID", "This is the profile URL")
    print(CE.profile_id)
    print(CE.profile_url)
    CE.ie_key()

# Generated at 2022-06-24 13:11:11.216650
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test download of audio file
    audio_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    audio_title = "Piano sample"
    audio_description = "Royalty Free Sample Music"
    audio_uploader = "ytdl"
    audio_id = "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
    audio_ext = "m4a"
    audio_m4a_url = "http://d1pgqke3goo8l6.cloudfront.net/u/%s/%s.m4a" % (audio_uploader, audio_id)

    # Create SoundgasmIE object
    ie = SoundgasmIE()
    
    # Extract information from url
    audio_info = ie._real_

# Generated at 2022-06-24 13:11:19.063743
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Test method SoundgasmIE.__init__
    """
    print('Test SoundgasmIE.__init__')
    sg_ie = SoundgasmIE()
    assert sg_ie is not None
    assert sg_ie.ie_key() == 'Soundgasm'
    assert sg_ie.ie_name() == 'Soundgasm'
    assert sg_ie.ie_version() == '0.1'
    assert sg_ie.ie_desc() == 'Soundgasm'
    assert sg_ie.working() is True


# Generated at 2022-06-24 13:11:26.464804
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Basic test for class SoundgasmIE.
    """
    # Test creation of an instance of SoundgasmIE
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie_SoundgasIE = SoundgasmIE(url)

    # Test audio URL
    assert ie_SoundgasIE.url == "http://soundgasm.net/u/ytdl/Piano-sample"
    # Test the display ID
    assert ie_SoundgasIE.display_id == "Piano-sample"
    # Test the audio ID
    assert ie_SoundgasIE.audio_id == "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
    # Test the audio title
    assert ie_SoundgasIE.title == "Piano sample"


# Generated at 2022-06-24 13:11:35.919779
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Constructor test"""

    # Test SoundgasmIE
    ie = SoundgasmIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:11:38.092499
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl#test')
    print(ie.url)

    assert(ie)

# Generated at 2022-06-24 13:11:39.572448
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert isinstance(SoundgasmProfileIE(), SoundgasmProfileIE)


# Generated at 2022-06-24 13:11:49.187173
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from . import SoundgasmIE
    from . import SoundgasmProfileIE
    # Constructor of class SoundgasmIE
    # For each url, extract_info function is called and returns a dictionary
    t = SoundgasmIE._TEST
    t['url'] = 'http://soundgasm.net/u/ytdl/Piano-sample'
    extractor = SoundgasmIE(t)
    info = extractor._real_extract(t['url'])
    assert info['id'] == t['info_dict']['id']
    # Constructor of class SoundgasmProfileIE
    # For each url, extract_info function is called and returns a dictionary
    t2 = SoundgasmProfileIE._TEST
    t2['url'] = 'http://soundgasm.net/u/ytdl'
    extract

# Generated at 2022-06-24 13:11:50.513359
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
  assert isinstance(SoundgasmIE().IE_NAME, unicode)


# Generated at 2022-06-24 13:11:51.873346
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg = SoundgasmProfileIE()
    assert sg.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:11:52.621813
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:11:56.747454
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info_extractor = SoundgasmIE()
    assert info_extractor.IE_NAME == 'soundgasm'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:11:57.245232
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:12:00.599303
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.name == 'soundgasm'
    assert ie.host == 'soundgasm.net'


# Generated at 2022-06-24 13:12:02.764051
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """The constructor of class SoundgasmProfileIE should be executed"""
    assert (SoundgasmProfileIE.__module__ == __name__ and
            'SoundgasmProfileIE' in globals())

# Generated at 2022-06-24 13:12:10.320872
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Create an instance of the class SoundgasmIE
    inst = SoundgasmIE()

    # Tests whether or not the url matches the regex
    assert inst._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

    # An expected result for the _real_extract method

# Generated at 2022-06-24 13:12:13.143623
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from . import SoundgasmIE
    from .soundgasm import SoundgasmProfileIE
    SoundgasmIE.__name__
    SoundgasmProfileIE.__name__

# Generated at 2022-06-24 13:12:24.326018
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE._download_webpage = lambda self, url, display_id: '''
        <!DOCTYPE html>
        <html>
            class_title_1
            href="https://soundgasm.net/u/ytdl/1"
            href="https://soundgasm.net/u/ytdl/2"
            class_title_2
            href="https://soundgasm.net/u/ytdl/2"
        </html>

        <html>
            href="/u/ytdl/1"
            href="/u/ytdl/2"
        </html>
    '''

    SoundgasmProfileIE._match_id = lambda self, url: 'ytdl'

    print(SoundgasmProfileIE._real_extract('profile_url'))

# Generated at 2022-06-24 13:12:32.137556
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Definition of test sample
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    url_name = 'http://soundgasm.net/u/ytdl'

    # Test sample
    test_sample = SoundgasmIE()
    # Test sample audio id
    id_string = test_sample._search_regex(r'/([^/]+)\.m4a', 'http://a.soundgasm.net/u/ytdl/Piano-sample/Piano-sample.m4a', 'audio id', default=False)
    print("Id: " + id_string)
    # Test sample uploader name

# Generated at 2022-06-24 13:12:37.321683
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test input
    url = 'http://soundgasm.net/u/ytdl'

    # Test output
    expected_output = 'ytdl'

    # Test for valid URL
    ie = SoundgasmProfileIE()
    assert(ie._match_id(url) == expected_output)
    # Test for invalid URL
    assert(ie._match_id(url + 'xyz') == None)

# Generated at 2022-06-24 13:12:43.161859
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:12:45.954158
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')
    assert ie.url == 'http://soundgasm.net/u/ytdl/Piano-sample'

# Generated at 2022-06-24 13:12:49.251171
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'

    obj = SoundgasmIE()
    assert re.match(obj._VALID_URL, url) == True


# Generated at 2022-06-24 13:12:49.627964
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:12:59.521465
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Unit test for constructor of class SoundgasmIE"""
    test_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    expected_md5 = "010082a2c802c5275bb00030743e75ad"
    test_obj = SoundgasmIE()
    test_obj.url = test_url
    result = test_obj.extract()
    if result["id"] != "88abd86ea000cafe98f96321b23cc1206cbcbcc9":
        print("Test failed: extracting id")
    elif result["title"] != "Piano sample":
        print("Test failed: extracting title")
    elif result["description"] != "Royalty Free Sample Music":
        print("Test failed: extracting description")

# Generated at 2022-06-24 13:13:03.731903
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # An instance of the SoundgasmProfileIE should be created
    extractor = SoundgasmProfileIE()

    # A profile should exist
    assert extractor.profile_id == 'ytdl'

    # A profile url should be generated
    assert extractor.url == 'http://soundgasm.net/u/ytdl/'
    # A profile playlist should be returned
    assert extractor.playlist

# Generated at 2022-06-24 13:13:06.439725
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE = SoundgasmProfileIE(None, {'url': 'http://soundgasm.net/u/ytdl'})
    assert IE.IE_NAME == 'soundgasm:profile'



# Generated at 2022-06-24 13:13:14.931194
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	# URL: http://soundgasm.net/u/ytdl
	sg = SoundgasmProfileIE()
	assert sg._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
	assert sg.IE_NAME == 'soundgasm:profile'
	assert sg._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-24 13:13:16.580592
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # GIVEN a class object of SoundgasmProfileIE
    testclass = SoundgasmProfileIE()

    # WHEN I construct the object
    # THEN a new object of SoundgasmProfileIE is created
    assert(testclass)



# Generated at 2022-06-24 13:13:22.708580
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    '''
    This function tests the constructor of the class SoundgasmIE.
    It checks if an exception is thrown when invalid parameter is given.
    '''
    # Test invalid parameter
    with pytest.raises(ValueError):
        # invalid url
        SoundgasmIE('invalid_url')

    # Test valid parameter
    IE = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert IE.name == 'Soundgasm'
    assert IE.VALID_URL == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert IE.url == 'http://soundgasm.net/u/ytdl/Piano-sample'


# Generated at 2022-06-24 13:13:24.521059
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:13:33.012240
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    audio_url = 'http://soundgasm.net/u/ytdl/Piano-sample.m4a'
    s = SoundgasmIE()
    assert isinstance(s, InfoExtractor)
    assert s.IE_NAME == 'Soundgasm'
    assert s._VALID_URL == (r'https?://(?:www\.)?soundgasm\.net/u/'
                            r'(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
                           )
    assert s._TEST['url'] == url

# Generated at 2022-06-24 13:13:42.026628
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    #url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    result = SoundgasmIE()._download_webpage('http://soundgasm.net/u/ytdl/Piano-sample', None)
    #audio_url = self._html_search_regex(r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', 'http://soundgasm.net/u/ytdl/Piano-sample', 'audio URL', group='url')
    #title = re.findall(r'<div[^>]+\bclass=["\']jp-title[^>]+>([^<]+)', result, 'title', default=None)

# Generated at 2022-06-24 13:13:43.596526
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:13:50.088410
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:13:55.600543
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

    # Test for the existence of a 'url' attribute
    assert ie.url == 'http://soundgasm.net/u/ytdl/Piano-sample'

    # Test for the existence of a 'url' attribute
    assert ie.ext == 'm4a'


# Generated at 2022-06-24 13:13:57.674226
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info_extractor = SoundgasmProfileIE()
    assert type(info_extractor) == SoundgasmProfileIE


# Generated at 2022-06-24 13:13:58.709701
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:13:59.769303
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE(InfoExtractor())._VALID_URL == SoundgasmProfileIE._VALID_URL

# Generated at 2022-06-24 13:14:00.465306
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(_download_webpage)

# Generated at 2022-06-24 13:14:00.916279
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	pass

# Generated at 2022-06-24 13:14:01.390693
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert True

# Generated at 2022-06-24 13:14:07.737595
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    'Unit test for constructor of class SoundgasmProfileIE'
    url = "http://soundgasm.net/u/ytdl/"
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$"
    assert ie._TEST["url"] == "http://soundgasm.net/u/ytdl"
    assert ie._TEST["info_dict"] == { 'id': 'ytdl' }
    assert ie._TEST["playlist_count"] == 1

# Generated at 2022-06-24 13:14:09.384762
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()

# Generated at 2022-06-24 13:14:14.854652
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = SoundgasmIE()._TEST['url']
    audio_url = SoundgasmIE()._TEST['info_dict']['url']
    instance = SoundgasmIE._get_info_extractor(url)
    assert isinstance(instance(url), SoundgasmIE)
    assert isinstance(instance(audio_url), SoundgasmIE)

# Generated at 2022-06-24 13:14:16.273570
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    infoExtractor = SoundgasmIE('youtube-dl')
    print(infoExtractor)

# Generated at 2022-06-24 13:14:17.239834
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(issubclass(SoundgasmProfileIE, InfoExtractor))


# Generated at 2022-06-24 13:14:26.621036
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	#Get the audio URL using class SoundgasmIE
    input_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    expected_output_url = "http://soundgasm.net/u/ytdl/Piano-sample.m4a"
    returned_output_url = SoundgasmIE()._real_extract(input_url)['url']
	#Check if the audio URL returned by the class SoundgasmIE is equal to the expected audio URL
    assert(returned_output_url == expected_output_url)
	
#Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-24 13:14:27.950066
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('SoundgasmProfile/ytdl')

# Generated at 2022-06-24 13:14:28.965075
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('ytdl')

# Generated at 2022-06-24 13:14:34.165833
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    class DummySoundgasmIE(InfoExtractor):
        IE_NAME = 'Soundgasm'
        _VALID_URL = 'https://soundgasm.net/u/the-account/the-title'
        def _real_extract(self, url):
            return {}

    test = SoundgasmProfileIE(DummySoundgasmIE())
    assert test.IE_NAME == 'Soundgasm:profile'

# Generated at 2022-06-24 13:14:38.678767
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    e = SoundgasmProfileIE()
    assert(e.IE_NAME == 'soundgasm:profile')
    assert(e.IE_NAME == e.ie_key())
    assert(r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$' == e._VALID_URL)

# Generated at 2022-06-24 13:14:40.792810
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    if __name__ == '__main__':
        print ("\nUnit test for SoundgasmProfileIE\n")
        print ("End of unit test\n")

# Generated at 2022-06-24 13:14:41.633602
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	SoundgasmProfileIE()


# Generated at 2022-06-24 13:14:42.236778
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	SoundgasmIE()

# Generated at 2022-06-24 13:14:45.692573
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    video_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE(video_url)
    assert ie.url == video_url
    assert ie.user == 'ytdl'
    assert ie.display_id == 'Piano-sample'

# Generated at 2022-06-24 13:14:51.075855
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # For coverage test purpose only.
    # - This test is called in function test_SoundgasmProfileIE
    # - If the test is called directly, the unittest library will
    #   ignore it.  So we need a trick to let the test go through
    #   the test function. 
    # - This is not a problem for other tests in this file.
    #   They are called directly from unittest library because
    #   they are not decorated as 'classmethod'.
    url = 'https://soundgasm.net/u/ytdl'
    soundgasm_profile_ie = SoundgasmProfileIE()
    soundgasm_profile_ie._real_extract(url)

# Generated at 2022-06-24 13:14:53.474377
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    # testing if the constructor returned an instance of the class SoundgasmIE
    assert sg.__class__.__name__ == 'SoundgasmIE'

# Generated at 2022-06-24 13:14:54.604141
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    assert soundgasm.IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:15:03.867680
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Unit test for constructor of class SoundgasmIE
    a = SoundgasmIE()
    b = SoundgasmIE(IE_NAME)
    assert a == b
    # Unit test for _download_webpage of class SoundgasmIE
    dl = a._download_webpage('http://soundgasm.net/u/ytdl', 'Piano-sample')
    # Unit test for is_suitable
    assert SoundgasmIE.is_suitable('http://soundgasm.net/u/ytdl/Piano-sample') == True
    assert SoundgasmIE.is_suitable('http://www.soundgasm.net/u/ytdl/Piano-sample') == True
    assert SoundgasmIE.is_suitable('soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:15:05.204031
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sgasmIE = SoundgasmIE()
    print(sgasmIE)

# Generated at 2022-06-24 13:15:06.597710
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	sg_profile_ie = SoundgasmProfileIE(None)

# Generated at 2022-06-24 13:15:09.218526
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info_extractor = SoundgasmProfileIE()
    assert info_extractor.IE_NAME == 'soundgasm:profile'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:15:11.527165
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert obj.IE_NAME == 'Soundgasm'


# Generated at 2022-06-24 13:15:12.344697
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print(SoundgasmProfileIE._TEST)

# Generated at 2022-06-24 13:15:22.909529
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    expected_result_1 = {
        'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
        'ext': 'm4a',
        'title': 'Piano sample',
        'description': 'Royalty Free Sample Music',
        'uploader': 'ytdl'
    }

    assert SoundgasmIE._real_extract(
        SoundgasmIE,
        'http://soundgasm.net/u/ytdl/Piano-sample') == expected_result_1

    expected_result_2 = {
        'id': '2317',
        'ext': 'm4a',
        'title': 'Crazy Soundgasm',
        'description': None,
        'uploader': 'ytdl'
    }

    assert SoundgasmIE

# Generated at 2022-06-24 13:15:32.484283
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
        audio_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
        expected_extraction = SoundgasmIE()._real_extract(audio_url)
        assert expected_extraction['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
        assert expected_extraction['display_id'] == 'Piano-sample'
        assert expected_extraction['url'] == 'http://soundgasm.net/u/ytdl/audio/Piano_sample.m4a'
        assert expected_extraction['vcodec'] == 'none'
        assert expected_extraction['title'] == 'Piano sample'
        assert expected_extraction['description'] == 'Royalty Free Sample Music'
        assert expected_extraction['uploader']

# Generated at 2022-06-24 13:15:38.877521
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE = SoundgasmProfileIE()
    assert IE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert IE.IE_NAME == 'soundgasm:profile'
    assert IE.IE_DESC == 'soundsgasm.net profiles'


# Generated at 2022-06-24 13:15:46.741742
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('https://soundgasm.net/u/ytdl')
    assert ie._VALID_URL == SoundgasmProfileIE._VALID_URL
    assert ie == SoundgasmProfileIE('https://www.soundgasm.net/u/ytdl/')
    assert ie != SoundgasmProfileIE('https://soundgasm.net/u/ytdl/?#search=query')
    assert ie != SoundgasmProfileIE('https://soundgasm.net/u/ytdl/blah')


# Generated at 2022-06-24 13:15:48.227099
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    print(sg.IE_NAME)

if __name__ == '__main__':
    test_SoundgasmIE()

# Generated at 2022-06-24 13:15:56.852575
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:15:59.590636
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Define an object of SoundgasmIE and use its context manager to test
    # whether it can be successfully constructed
    with SoundgasmIE() as obj:
        pass

# Generated at 2022-06-24 13:16:02.504163
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    test_dict = {'id': 'ytdl',}
    assert(ie._TEST == test_dict)


# Generated at 2022-06-24 13:16:07.973925
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# Happy path
	IE = SoundgasmIE()
	assert IE.IE_NAME == 'soundgasm'
	assert IE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:16:09.347740
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ins = SoundgasmProfileIE(None)
    assert ins != None

# Generated at 2022-06-24 13:16:11.661964
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 13:16:16.452437
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-24 13:16:21.154552
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl/')
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:16:22.179069
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()

# Generated at 2022-06-24 13:16:23.060279
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    x = SoundgasmProfileIE()


# Generated at 2022-06-24 13:16:24.219163
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('/u/ytdl')

# Generated at 2022-06-24 13:16:25.040008
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:16:27.766535
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from test import _assert_urls_test
    _assert_urls_test(SoundgasmIE, 'http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:16:38.215062
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .extractors import SoundgasmIE
    from .common import InfoExtractor
    import unittest

    class TestSoundgasmIE(unittest.TestCase):
        def setUp(self):
            self.ie = SoundgasmIE()
            self.className = self.ie.__class__.__name__

        def test_constructor(self):
            self.assertTrue(hasattr(self.ie, '_VALID_URL'))
            self.assertTrue(hasattr(self.ie, '_match_id'))
            self.assertTrue(hasattr(self.ie, '_real_initialize'))
            self.assertTrue(hasattr(self.ie, '_real_extract'))
            self.assertTrue(hasattr(self.ie, '_download_webpage'))


# Generated at 2022-06-24 13:16:40.032888
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE()
    assert isinstance(instance, SoundgasmProfileIE)

# Generated at 2022-06-24 13:16:41.733692
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-24 13:16:51.127342
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test for the SoundgasmIE constructor
    search = SoundgasmIE()
    extracted_url = search._real_extract('http://www.soundgasm.net/u/ytdl/Piano-sample')
    assert extracted_url['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert extracted_url['display_id'] == 'Piano-sample'
    assert extracted_url['uploader'] == 'ytdl'
    assert extracted_url['title'] == 'Piano sample'
    assert extracted_url['description'] == 'Royalty Free Sample Music'
    assert extracted_url['ext'] == 'm4a'


# Generated at 2022-06-24 13:16:52.207995
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:17:02.168779
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Pass a string url to constructor of SoundgasmIE class.
    """
    url = "http://soundgasm.net/u/ytdl/Piano-sample"

    SoundgasmIE()
    assert SoundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert SoundgasmIE._TEST['url'] == url
    assert SoundgasmIE._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-24 13:17:11.181519
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE()
    ie.url = url
    ie.download = lambda x: None
    assert ie.__class__.__name__ == 'SoundgasmProfileIE'
    assert ie._TEST['url'] == url
    assert ie.ie_key() == 'Soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:17:12.061456
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:17:13.638308
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    my_test = SoundgasmIE()
    assert my_test.IE_NAME == 'Soundgasm'

# Generated at 2022-06-24 13:17:17.745132
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    test = SoundgasmProfileIE()

    assert test._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:17:19.796968
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.IE_NAME == "soundgasm:profile"
        
# Unit tests for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:17:29.780351
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Create test object by passing valid URL to constructor
    valid_IE = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

    # Assert that we now have the name of the IE that we are testing
    assert valid_IE.IE_NAME == 'soundgasm:profile'

    # Assert that we now have the valid URL that we passed
    assert valid_IE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

    # Assert that the test dictionary is now a valid InfoExtractor dictionary

# Generated at 2022-06-24 13:17:31.222058
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL == SoundgasmProfileIE._VALID_URL


# Generated at 2022-06-24 13:17:32.924217
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	a = SoundgasmProfileIE()
	a.extract('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:17:35.599198
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    x = SoundgasmIE()
    y = SoundgasmIE()
    assert(x.IE_NAME == y.IE_NAME)
    assert(x.IE_NAME == "SoundgasmIE")

# Generated at 2022-06-24 13:17:40.290439
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    mobj = re.match(soundgasm._VALID_URL,
                    'http://soundgasm.net/u/ytdl/Piano-sample')
    assert mobj.group('user') == 'ytdl'
    assert mobj.group('display_id') == 'Piano-sample'

# Generated at 2022-06-24 13:17:50.383130
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    s = SoundgasmIE(None)
    assert s.IE_NAME == 'soundgasm'
    assert s._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert s._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert s._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-24 13:17:53.843246
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert 'The Soundgasm Media Player' in SoundgasmIE()._download_webpage(
        'http://soundgasm.net/u/ytdl/Piano-sample', '88abd86ea000cafe98f96321b23cc1206cbcbcc9')

# Generated at 2022-06-24 13:17:58.201339
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    v = 'http://soundgasm.net/u/ytdl/Piano-sample'
    b = SoundgasmIE()
    assert b._VALID_URL == v

# Uint test for download func of class SoundgasmIE

# Generated at 2022-06-24 13:18:01.801759
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    code = SoundgasmIE()
    code.IE_NAME
    code.IE_DESC
    code._VALID_URL
    code._TEST
    code._downloader
    code._download_webpage
    code._html_search_regex
    code._search_regex
    code._real_extract

# Generated at 2022-06-24 13:18:03.515680
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	url = 'http://soundgasm.net/u/ytdl'
	profile_id = 'ytdl'

# Generated at 2022-06-24 13:18:06.383988
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    assert soundgasm.IE_NAME == 'soundgasm'
    assert re.match(soundgasm._VALID_URL, 'http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-24 13:18:11.227704
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test default constructor
    assert SoundgasmProfileIE()._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/.*'
    assert SoundgasmProfileIE().IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:18:14.149481
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pros_unit_test = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    print ("Id: "+str(pros_unit_test.profile_id))


# Generated at 2022-06-24 13:18:15.813025
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    #TODO: Add constructor test of class SoundgasmProfileIE
    pass

# Generated at 2022-06-24 13:18:25.102341
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mobj = re.match(SoundgasmIE._VALID_URL, url)
    display_id = mobj.group('display_id')
    title = 'Piano sample'
    description = 'Royalty Free Sample Music'
    audio_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    uploader = 'ytdl'
    audio_url = 'https://s3.amazonaws.com/soundgasm/ytdl/piano-sample.m4a'
