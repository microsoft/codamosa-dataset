

# Generated at 2022-06-24 13:08:25.984157
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('SoundgasmProfileIE').IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:08:36.098934
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    test_dict = {
        'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
        'md5': '010082a2c802c5275bb00030743e75ad',
        'info_dict': {
            'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
            'ext': 'm4a',
            'title': 'Piano sample',
            'description': 'Royalty Free Sample Music',
            'uploader': 'ytdl',
        }
    }

    soundgasm = SoundgasmIE()
    info_dict = soundgasm._real_extract(url)

    # Test that expected

# Generated at 2022-06-24 13:08:44.017167
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('soundgasm:88abd86ea000cafe98f96321b23cc1206cbcbcc9')
    assert ie.result['info_dict']['title'] == 'Piano sample'
    assert ie.result['info_dict']['uploader'] == 'ytdl'
    assert ie.result['info_dict']['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert ie.result['info_dict']['ext'] == 'm4a'
    assert ie.result['info_dict']['description'] == 'Royalty Free Sample Music'
    assert ie.result['info_dict']['display_id'] == 'Piano-sample'

# Generated at 2022-06-24 13:08:45.825004
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
   return SoundgasmIE()._real_extract(SoundgasmIE._TEST['url'])

# Generated at 2022-06-24 13:08:49.899694
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # test parse
    ie = SoundgasmIE()
    obj = ie.url_result('http://soundgasm.net/u/ytdl/Piano-sample')
    assert(obj[0]['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:08:57.606866
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('ytdl')
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.URL_TEMPLATE.match('http://soundgasm.net/u/ytdl') is not None
    assert ie.URL_TEMPLATE.match('http://soundgasm.net/u/ytdl/') is not None
    assert ie.URL_TEMPLATE.match('http://soundgasm.net/u/ytdl#foolist') is not None
    assert ie.URL_TEMPLATE.match('http://soundgasm.net/u/ytdl/#foolist') is not None

# Generated at 2022-06-24 13:08:59.903558
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_url = 'http://soundgasm.net/u/ytdl'
    soundgasm = SoundgasmProfileIE()
    assert soundgasm._match_id(profile_url) == 'ytdl'

# Generated at 2022-06-24 13:09:07.007613
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    audio_id = 'Piano-sample'
    user = 'ytdl'
    display_id = 'Piano-sample'
    webpage = None
    soundgasm_ie = SoundgasmIE()
    result = soundgasm_ie._real_extract(url=url, webpage=webpage)
    assert audio_id == result['id']
    assert user == result['uploader']
    assert display_id == result['display_id']

# Generated at 2022-06-24 13:09:08.662580
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert isinstance(SoundgasmIE, object)


# Generated at 2022-06-24 13:09:19.420838
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:09:26.387082
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    e = SoundgasmProfileIE()

    # Test for valid url
    sample_url = 'http://soundgasm.net/u/ytdl'
    assert e.suitable(sample_url)
    assert e._VALID_URL is not None
    mobj = re.match(e._VALID_URL, sample_url)
    assert mobj is not None
    assert mobj.group('id') == 'ytdl'

    # Test for invalid url
    sample_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert not e.suitable(sample_url)

    # Test for valid url with different file
    sample_url = 'http://soundgasm.net/u/N0Y0'

# Generated at 2022-06-24 13:09:27.592265
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL == SoundgasmProfileIE._VALID_URL

# Generated at 2022-06-24 13:09:28.255560
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:09:32.029465
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE_obj = SoundgasmProfileIE()
    assert SoundgasmProfileIE_obj.IE_NAME == 'soundgasm'
    assert SoundgasmProfileIE_obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert SoundgasmProfileIE_obj._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict':{'id': 'ytdl'}, 'playlist_count': 1}

# Generated at 2022-06-24 13:09:35.130996
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Create the instance of class SoundgasmProfile
    profile = SoundgasmProfileIE()
    profile._match_id('http://soundgasm.net/u/ytdl')


# Generated at 2022-06-24 13:09:35.694381
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()



# Generated at 2022-06-24 13:09:41.198713
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert SoundgasmProfileIE.IE_DESC == 'soundgasm.net profiles'
    assert SoundgasmProfileIE.VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:09:42.882945
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None).suite()



# Generated at 2022-06-24 13:09:51.056259
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE('http://soundgasm.net/u/ytdl/', lambda x: x, lambda x: x)
    assert profile.IE_NAME == 'soundgasm:profile'
    assert profile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert profile._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    result = profile._real_extract('http://soundgasm.net/u/ytdl')
    assert result['id'] == 'ytdl'


# Generated at 2022-06-24 13:09:55.977105
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE = SoundgasmProfileIE()
    assert IE.IE_NAME == 'soundgasm:profile'
    assert IE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert isinstance(IE._TEST, dict)

# Generated at 2022-06-24 13:09:58.195362
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    d = SoundgasmProfileIE()
    d._match_id
    d._real_extract
    d.playlist_result



# Generated at 2022-06-24 13:10:01.312975
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmIE != SoundgasmProfileIE  # Sanity check for no subclassing

    profile_ie = SoundgasmProfileIE('test')
    assert profile_ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:10:03.543546
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from compound import CompoundIE
    # Test it can be constructed
    CompoundIE.for_website(SoundgasmProfileIE.IE_NAME)

# Generated at 2022-06-24 13:10:05.112052
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:10:14.861143
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_url = 'http://soundgasm.net/u/ytdl'
    youtube_dl = SoundgasmProfileIE()
    # Test constructor
    test_obj = youtube_dl.__class__(youtube_dl)
    # Assert type of object is same as constructor of class
    assert isinstance(test_obj, youtube_dl.__class__)
    # Assert URL is same as passed URL
    assert test_obj._url == test_url
    # Assert pagenum is initialized to 1
    assert test_obj._pagenum == 1
    # Assert playlist_title is initialized to URL
    assert test_obj._playlist_title == test_url
    # Assert playlist_id is initialized to URL
    assert test_obj._playlist_id == test_url

# Generated at 2022-06-24 13:10:17.916099
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info_extractor = SoundgasmIE()
    assert info_extractor.IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:10:21.706560
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._TEST == { 'url': 'http://soundgasm.net/u/ytdl', 'info_dict': { 'id': 'ytdl' }, 'playlist_count': 1 }

# Generated at 2022-06-24 13:10:24.323796
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:10:29.652236
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from unittest import TestCase
    from .common import FakeYDL
    ydl = FakeYDL()
    ie = SoundgasmProfileIE(ydl, {})
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.VALID_URL == SoundgasmProfileIE._VALID_URL
    assert ie._TEST == SoundgasmProfileIE._TEST

# Generated at 2022-06-24 13:10:30.647437
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()

# Generated at 2022-06-24 13:10:32.311770
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().ie_key() == 'soundgasm'


# Generated at 2022-06-24 13:10:35.470318
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE = SoundgasmIE('soundgasm')
    assert hasattr(IE, '_VALID_URL')
    assert hasattr(IE, '_TEST')
    assert hasattr(IE, '_real_extract')
    assert hasattr(IE, '_download_webpage')

# Generated at 2022-06-24 13:10:37.179905
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Tests for no exception in SoundgasmProfileIE constructor
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:10:41.994213
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	
	# Creating a SoundgasmProfileIE object
	print("Running test for SoundgasmProfileIE object creation...")
	object = SoundgasmProfileIE()
	if not object:
		raise AssertionError("SoundgasmProfileIE object creation failed")
	else:
		print("SoundgasmProfileIE object creation successful!")


# Generated at 2022-06-24 13:10:42.599277
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-24 13:10:45.369504
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        ie = SoundgasmProfileIE()
    except:
        raise Exception('Could not create instance of class SoundgasmProfileIE')


# Generated at 2022-06-24 13:10:50.695928
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    result = SoundgasmIE().extract(url)
    assert(result['url'] == 'https://storage.googleapis.com/soundgasm-production/uploads/af1e898f-a483-4cda-9ece-4c4d4a4e4f2c.m4a')

# Generated at 2022-06-24 13:10:57.948948
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    mobj = re.match(SoundgasmIE._VALID_URL, url)
    user = mobj.group('user')
    display_id = mobj.group('display_id')
    ie = SoundgasmIE(user)
    admin_url = 'http://www.soundgasm.net/admin-ajax.php'
    data = {
        'action': 'soundgasm_search_url',
        'soundgasm_url': display_id
    }
    webpage_json = ie._download_json(admin_url, display_id, data, query={'soundgasm_url': display_id})
    page_url = webpage_json['url']

# Generated at 2022-06-24 13:11:02.648706
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    filename = '88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE()._check_valid_filename(url, filename)


# Generated at 2022-06-24 13:11:03.826350
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()

# Generated at 2022-06-24 13:11:10.502218
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # test url
    url = "http://soundgasm.net/u/ytdl"
    # Test expected values
    expected_id = "ytdl"
    profile_ie = SoundgasmProfileIE()
    result = profile_ie._real_extract(url)

    # Result is tuple of two str (id, playlist_count)
    assert(len(result) == 2)
    # test id
    assert(result[0] == expected_id)
    # test playlist_count
    assert(result[1] > 0)
    assert(result[1] == len(result[2]))

# Generated at 2022-06-24 13:11:12.787778
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert(ie.IE_NAME == 'soundgasm')


# Generated at 2022-06-24 13:11:22.573312
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    print("Testing for constructor of class SoundgasmIE")
    assert instance._TEST['url'] == "http://soundgasm.net/u/ytdl/Piano-sample"
    assert instance._TEST['md5'] == "010082a2c802c5275bb00030743e75ad"
    assert instance._TEST['info_dict']['id'] == "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
    assert instance._TEST['info_dict']['ext'] == "m4a"
    assert instance._TEST['info_dict']['title'] == "Piano sample"

# Generated at 2022-06-24 13:11:33.445564
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    audio_url = 'http://media.soundgasm.net/u/ytdl/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    audio_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    title = 'Piano sample'
    description = 'Royalty Free Sample Music'
    uploader = 'ytdl'
    display_id = 'Piano-sample'

    webpage = '<a href="' + audio_url + '"></a>'
    webpage += '<a href="http://soundgasm.net/u/ytdl/' + display_id + '"></a>'


# Generated at 2022-06-24 13:11:36.582435
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    m = re.match(SoundgasmProfileIE._VALID_URL, url)
    assert m is not None
    SoundgasmProfileIE(None).suitable(url)

# Generated at 2022-06-24 13:11:38.184482
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-24 13:11:43.867961
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = SoundgasmIE._TEST
    code = SoundgasmIE(None)._real_extract(test['url'])
    assert 'id' in code
    assert 'display_id' in code
    assert 'uploader' in code
    assert 'url' in code
    assert 'title' in code
    assert 'description' in code
    assert 'vcodec' in code
    return code

# Generated at 2022-06-24 13:11:45.855103
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('%s/%s' % (SoundgasmProfileIE.IE_NAME, SoundgasmProfileIE._VALID_URL))

# Generated at 2022-06-24 13:11:53.610945
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    valid_url = 'http://soundgasm.net/u/ytdl/Piano-sample'

    instance = SoundgasmIE()

    m = re.match(instance._VALID_URL, valid_url)
    assert m is not None

    instance.IE_NAME = 'Soundgasm'


# Generated at 2022-06-24 13:11:55.526163
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-24 13:11:56.397054
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert True

# Generated at 2022-06-24 13:11:58.926459
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    print("REGEX: " + soundgasm._VALID_URL)


# Generated at 2022-06-24 13:11:59.912185
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:12:08.247707
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # This is a unit test for the constructor (i.e., __init__ function) of class SoundgasmIE
    # This unit test is aimed at testing the parsing of the input argument to the constructor
    # and the return value of the constructor.
    valid_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    valid_url_re = r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    expected_display_id = 'Piano-sample'
    ie_handler = SoundgasmIE(valid_url)
    regex_obj = re.compile(valid_url_re)

# Generated at 2022-06-24 13:12:09.868322
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_class = SoundgasmProfileIE()

# Generated at 2022-06-24 13:12:15.588208
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    #test url with default class
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE(url)
    assert ie.url == url
    assert ie.display_id == 'Piano-sample'
    assert ie.valid_url, True
    assert ie.IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:12:16.698424
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    obj = SoundgasmIE(url)
    obj.IE_NAME



# Generated at 2022-06-24 13:12:18.598680
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
        assert True
    except Exception as e:
        assert False, "Error in SoundgasmIE constructor"


# Generated at 2022-06-24 13:12:28.352668
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Make sure that constructor is properly implemented
    ie_obj = SoundgasmIE()

    assert ie_obj.name == 'Soundgasm.net'
    assert ie_obj.params['name'] == 'Soundgasm.net'
    assert ie_obj.params['_api_url'] is None
    assert ie_obj.params['_api_version'] == 1.0
    assert ie_obj.params['_api_query'] == {}
    assert ie_obj.params['_api_method_name'] == 'GET'
    assert ie_obj.params['_api_json_resp'] is False
    assert ie_obj.params['_api_format'] == 'json'
    assert ie_obj.params['_api_search_key'] is None
    assert ie_obj.params['_api_result_key'] == 'results'

# Generated at 2022-06-24 13:12:35.200762
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    audio_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    webpage = ie._download_webpage(audio_url, "Piano-sample")
    audio_url = ie._html_search_regex(r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', webpage, 'audio URL', group='url')
    print(audio_url)

# Generated at 2022-06-24 13:12:36.614887
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE('SoundgasmProfile','http://soundgasm.net/u/ytdl') is not None)

# Generated at 2022-06-24 13:12:41.347777
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # test the constructor
    ie = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

    # test __module__ and __name__ of the class,
    # to satisfy the assertion in InfoExtractor.__init__
    assert ie.__module__.startswith("youtube_dl.")
    assert ie.__module__.endswith(".soundgasm")
    assert ie.__name__ == "SoundgasmProfileIE"

    # test the fields of the class

# Generated at 2022-06-24 13:12:44.630205
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    # check if the constructor of class SoundgasmIE is working properly
    assert SoundgasmIE._VALID_URL.search(url)

# Generated at 2022-06-24 13:12:46.243498
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    reload(importer)
    importer.install()

    g = SoundgasmProfileIE()

# Generated at 2022-06-24 13:12:47.477118
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:12:52.705235
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE()
    assert soundgasm_profile_ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'
    assert soundgasm_profile_ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:12:54.210911
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert isinstance(SoundgasmProfileIE(), InfoExtractor)

# Generated at 2022-06-24 13:12:55.936731
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.suitable('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:13:03.902268
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    try:
        # Check if the constructor raises an exception
        # when the url is empty
        SoundgasmIE(None)

        # Check if the constructor raises an exception
        # when the url is not a string
        SoundgasmIE(123)

        # Check if the constructor raises an exception
        # when the url is not a valid youtube url
        SoundgasmIE('www.example.com')

        # Check if the constructor raises an exception
        # when the url is not a valid youtube url
        SoundgasmIE('')

        # Check if the constructor returns a object
        # when the url is valid
        assert isinstance(SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample'), SoundgasmIE)
    except:
        assert False

# Generated at 2022-06-24 13:13:13.725678
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE._TEST = {
        'url': 'http://soundgasm.net/u/ytdl#profile_stream',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 2,
    }

    import json
    import os
    import sys

    if sys.version_info >= (3,0,0):
        from urllib.request import urlretrieve
    else:
        from urllib import urlretrieve

    url = SoundgasmProfileIE._TEST['url']
    filename = os.path.join(os.path.dirname(__file__), "test.html")
    urlretrieve(url, filename=filename)

    with open(filename) as f:
        results = json.load(f)

    playlist

# Generated at 2022-06-24 13:13:14.256861
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:13:19.835192
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info_extractor = SoundgasmIE()
    # First Parameter is a valid URL to grab some data from
    # Second parameter is a true flag if we want to download the file
    info_extractor.extract('http://soundgasm.net/u/ytdl/Piano-sample', True)
    # Test with default parameter for second parameter(download the file)
    info_extractor.extract('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:13:30.517505
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	print("\nBEGIN: test_SoundgasmProfileIE")
	import soundgasm_test
	import urlparse
	import unittest

	class SoundgasmProfileIETest(unittest.TestCase):
		def setUp(self):
			self.ie = SoundgasmProfileIE()

		def assertIsPlaylist(self, info):
			"""Make sure the info has '_type' set to 'playlist'."""
			self.assertEqual(info['_type'], 'playlist')

		def assertIsPlaylist(self, info):
			"""Make sure the info has '_type' set to 'playlist'."""
			self.assertEqual(info['_type'], 'playlist')


# Generated at 2022-06-24 13:13:31.383926
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-24 13:13:35.195403
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  test_obj = SoundgasmProfileIE(None)
  assert test_obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:13:38.452899
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasmProfileIE = SoundgasmProfileIE()
    """
    Test case for constructor of class SoundgasmProfileIE
    """
    assert soundgasmProfileIE.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-24 13:13:43.826361
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test to verify that the instance is created properly
    test_obj = SoundgasmProfileIE()
    assert test_obj.IE_NAME == 'soundgasm:profile'
    assert test_obj._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert test_obj._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-24 13:13:50.844401
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert ie._TEST['info_dict']['id'] == 'ytdl'

# Generated at 2022-06-24 13:13:54.416240
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-24 13:13:56.576990
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl/',
    _SoundgasmProfileIE(url, None)


# Generated at 2022-06-24 13:13:57.172970
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:14:03.506557
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # URL of piano sample on soundgasm.net
    ie = SoundgasmIE()
    result = ie.result("http://soundgasm.net/u/ytdl/Piano-sample")
    assert result['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert result['ext'] == 'm4a'
    assert result['title'] == 'Piano sample'
    assert result['description'] == 'Royalty Free Sample Music'
    assert result['uploader'] == 'ytdl'

# Generated at 2022-06-24 13:14:07.934956
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    result = [(ie.IE_NAME, ie._VALID_URL, ie._TEST)]
    # Test case for valid URL
    assert ie.suitable('http://soundgasm.net/u/ytdl/Piano-sample')
    # Test case for invalid URL
    assert not ie.suitable('http://soundgasm.net/')

# Generated at 2022-06-24 13:14:18.272813
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('http://soundgasm.net/u/ytdl')._TEST == SoundgasmProfileIE._TEST
    assert SoundgasmProfileIE('http://soundgasm.net/u/ytdl')._VALID_URL == SoundgasmProfileIE._VALID_URL
    assert SoundgasmProfileIE('http://soundgasm.net/u/ytdl#')._TEST == SoundgasmProfileIE._TEST
    assert SoundgasmProfileIE('http://soundgasm.net/u/ytdl#')._VALID_URL == SoundgasmProfileIE._VALID_URL
    assert SoundgasmProfileIE('https://soundgasm.net/u/ytdl')._TEST == SoundgasmProfileIE._TEST

# Generated at 2022-06-24 13:14:24.324089
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie.IE_DESC == 'Soundgasm.net audio streams'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:14:27.344555
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Create object from class constructor
    test_object = SoundgasmIE({})
    # Test object
    assert isinstance(test_object, SoundgasmIE)


# Generated at 2022-06-24 13:14:29.469798
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    SoundgasmIE(url)

# Generated at 2022-06-24 13:14:32.697880
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'https://soundgasm.net/u/ytdl/Piano-sample'
    obj = SoundgasmIE()
    obj._real_extract(url)
    assert obj.IE_NAME == 'soundgasm'


# Generated at 2022-06-24 13:14:35.272482
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    assert SoundgasmIE._soundgasm_url_re.match('http://soundgasm.net/u/ytdl/Piano-sample')

    return True

# Generated at 2022-06-24 13:14:36.298305
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    print(ie)

# Generated at 2022-06-24 13:14:37.894267
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Initialize an instance of class `SoundgasmProfileIE`
    SoundgasmProfileIE()
    # It should not fail

# Generated at 2022-06-24 13:14:40.365571
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    objSoundgasmProfileIE = SoundgasmProfileIE('test',{})
    print(str(objSoundgasmProfileIE))
    assert objSoundgasmProfileIE is not None



# Generated at 2022-06-24 13:14:48.350226
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasmIE = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    assert soundgasmIE._VALID_URL == \
        r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:14:50.404783
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test default constructor
    test_instance = SoundgasmProfileIE(None)

    # Test the inherited method _match_id()
    assert test_instance._match_id('http://soundgasm.net/u/ytdl') == 'ytdl'

# Generated at 2022-06-24 13:14:53.937210
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile = SoundgasmProfileIE()
    profile.suite()			# unit test for class ie_suite

    return profile.suite(url)		# extract audio files from profile



# Generated at 2022-06-24 13:14:55.045622
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	ie = SoundgasmProfileIE()
	assert ie.ie_key() == "SoundgasmProfileIE"

# Generated at 2022-06-24 13:14:56.899580
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    constructor_test(SoundgasmProfileIE, [],
                     ['http://soundgasm.net/u/ytdl'])

# Generated at 2022-06-24 13:15:00.544141
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Unit test for constructor of class SoundgasmIE
    """

    i = SoundgasmIE()
    i = SoundgasmIE.ie_key()
    i = SoundgasmIE.suitable()
    i = SoundgasmIE.can_extract()
    i = SoundgasmIE.__init__()

# Generated at 2022-06-24 13:15:01.155613
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:15:01.767802
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:15:11.649183
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print('Unit test for constructor of class SoundgasmProfileIE')
    video_url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'
    playlist = SoundgasmProfileIE(video_url)._real_extract(video_url)
    assert(profile_id == playlist['title'])
    profile_id = 'ytdl'
    playlist = SoundgasmProfileIE('http://soundgasm.net/u/ytdl#profile')._real_extract('http://soundgasm.net/u/ytdl#profile')
    assert(profile_id == playlist['title'])
    profile_id = 'ytdl'

# Generated at 2022-06-24 13:15:21.566677
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import urllib
    import tempfile
    from .common import get_testdata_file
    from .test_soundcloud import file_id_from_url

    with tempfile.NamedTemporaryFile() as f:
        with open(get_testdata_file('soundgasm_profile.html'), 'r') as fr:
            f.write(fr.read().encode('utf-8'))
            f.flush()

        with open(f.name, 'r') as fr:
            profile = fr.read()
            profile = urllib.unquote(profile).decode('utf-8')

            audio_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
            expected_id = file_id_from_url(audio_url)

# Generated at 2022-06-24 13:15:23.318546
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    inst = SoundgasmProfileIE()
    assert(inst._VALID_URL) == r'https?://(?:www\.)?soundgasm\.net/u/([^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:15:24.686156
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_obj = SoundgasmProfileIE()

# Generated at 2022-06-24 13:15:26.987150
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().extract("https://soundgasm.net/u/ytdl/Piano-sample") is not None

# Generated at 2022-06-24 13:15:27.940271
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:15:35.360289
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie.IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:15:36.400488
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()

# Generated at 2022-06-24 13:15:41.076799
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print("\nTesting constructor of class SoundgasmProfileIE")
    # Testing 'IE_NAME'
    ie = SoundgasmProfileIE(None)
    ie.get_all_urls("")
    assert ie.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-24 13:15:49.477270
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'SoundgasmProfileIE'
    assert ie.IE_DESC == 'soundgasm.net'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}


# Generated at 2022-06-24 13:15:53.267833
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	#print("Hello")
	#print("Inside")
	#print("Soundgasm")
	#print(InfoExtractor())
	#print("Soylent Green is People")
	#print(SoundgasmIE())
	#print("Good Bye")
	Pass


# Generated at 2022-06-24 13:15:58.434316
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    TestIE = SoundgasmIE()._constructor
    assert TestIE

    # Since we cannot guarantee that the test data is still available
    # on soundgasm.net, we cannot verify the md5 hashes here.
    # This process should be done in youtube-dl's test framework.
    assert TestIE._VALID_URL == SoundgasmIE._VALID_URL
    assert TestIE._TEST == SoundgasmIE._TEST

# Generated at 2022-06-24 13:16:02.606297
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    downloader = InfoExtractor()
    song = SoundgasmIE('http://soundgasm.net/u/username/songname')
    downloader.add_info_extractor(song)
    downloader.download('http://soundgasm.net/u/username/songname')

# Generated at 2022-06-24 13:16:03.988635
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/somebody')

# Generated at 2022-06-24 13:16:10.295920
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """test for SoundgasmIE constructor"""
    download_urls = {'m4a': 'http://soundgasm.net/u/ytdl/Piano-sample/download'}

    # Test for download_urls
    extractor = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert extractor.download_urls == download_urls.get('m4a')

# Generated at 2022-06-24 13:16:12.675261
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj_SoundgasmProfileIE = SoundgasmProfileIE()
    assert obj_SoundgasmProfileIE.ie_key() == 'Soundgasm'

# Generated at 2022-06-24 13:16:14.751541
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:16:17.767721
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    link='http://soundgasm.net/u/Nathan/Star-Wars-Duel-of-the-Fates'
    SoundgasmIE()._real_extract(link)

# Generated at 2022-06-24 13:16:20.974952
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print(list(SoundgasmIE('http://example.com', {})._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')))


# Generated at 2022-06-24 13:16:22.677137
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(None)
    assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:16:24.772632
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE('ytdl')
    assert a._TEST['url'] == 'http://soundgasm.net/u/ytdl'

# Generated at 2022-06-24 13:16:29.890436
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .test import get_testcases
    from .test import list_testcases
    for entry in list_testcases:
        if (entry['test'] == 'test_SoundgasmProfileIE'):
            testcase = entry
    SoundgasmProfileIE._tests = {'basic': [testcase]}
    return get_testcases(SoundgasmProfileIE, fetch_subtitle=False)

# Generated at 2022-06-24 13:16:34.906015
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE('Soundgasm')
    assert obj.ie_key() == 'Soundgasm'
    assert obj.ie_url() == 'http://soundgasm.net'
    assert obj.root_id() == 'soundgasm'
    assert obj.timestamp() == None
    assert obj.age_limit() == None

# Generated at 2022-06-24 13:16:38.775379
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("Testing SoundgasmIE class")
    # Test SoundgasmIE with no error
    try:
        SoundgasmIE()
    except Exception as e:
        print("An error occured, is '" + str(e) + "'")
    else:
        print("No error occured")


# Generated at 2022-06-24 13:16:39.399129
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-24 13:16:44.163225
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    i = SoundgasmProfileIE()
    if i.IE_NAME != 'SoundgasmProfileIE':
        print('Name of class mismatch !\n')
    if not isinstance(i, InfoExtractor):
        print('Class not subclass of InfoExtractor !\n')
    return

# Generated at 2022-06-24 13:16:53.379256
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	url = 'http://soundgasm.net/u/ytdl/Piano-sample'
	ie = SoundgasmIE()

	metadata = ie._extract_metadata(url)
	if not metadata:
		print('No metadata!')
		return
	print('Metadata:', metadata)
	
	audio_url, audio_id, title, description, uploader = ie._extract_key_info(url, metadata)
	print('audio_url:', audio_url)
	print('audio_id:', audio_id)
	print('title:', title)
	print('description:', description)
	print('uploader:', uploader)
	
	real_title = ie._real_extract_title(url, metadata, title)
	print('real_title:', real_title)
	

# Generated at 2022-06-24 13:17:03.226220
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_obj = SoundgasmIE(None)
    assert test_obj.IE_NAME == 'soundgasm'
    assert test_obj._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:17:07.296274
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class testException(Exception):
        pass

    try:
        # Create instance of class SoundgasmIE to ensure that it works
        SoundgasmIE()
    except Exception as e:
        raise testException("Constructor of class SoundgasmIE failed. Message: " + str(e))


# Generated at 2022-06-24 13:17:07.835880
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE

# Generated at 2022-06-24 13:17:14.429316
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()._VALID_URL(
        'http://soundgasm.net/u/ytdl/Piano-sample')
    assert SoundgasmIE()._VALID_URL(
        'https://soundgasm.net/u/ytdl/Piano-sample')
    assert SoundgasmIE()._VALID_URL(
        'http://soundgasm.net/u/ytdl/Piano-sample?#')
    assert not SoundgasmIE()._VALID_URL(
        'http://soundgasm.net/u/ytdl/Piano-sample#')
    assert not SoundgasmIE()._VALID_URL(
        'http://soundgasm.net/u/ytdl/')

# Generated at 2022-06-24 13:17:24.346938
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'
    ie = SoundgasmProfileIE(url, 'Soundgasm')
    assert ie.IE_NAME == 'Soundgasm'
    assert ie.__class__.__name__ == 'SoundgasmProfileIE', ie.__class__.__name__
    assert ie._VALID_URL == SoundgasmIE._VALID_URL 
    assert ie._match_id(url) == profile_id
    assert ie._real_extract(url) == ie.playlist_result([ie.url_result('http://soundgasm.net/u/ytdl/Piano-sample', 'Soundgasm')], profile_id)



# Generated at 2022-06-24 13:17:26.066367
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print ('Test for SoundgasmIE')
    youtube_ie = SoundgasmIE()


# Generated at 2022-06-24 13:17:33.842720
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie.suitable('http://soundgasm.net/u/ytdl/Piano-sample')
    assert not ie.suitable('http://soundgasm.net')

# Generated at 2022-06-24 13:17:43.714682
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    unit_test = SoundgasmIE()

    assert unit_test._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

    assert unit_test.IE_NAME == 'soundgasm'


# Generated at 2022-06-24 13:17:50.383724
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test case 1
    soundgasm_test_case1 = SoundgasmIE()
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert soundgasm_test_case1._match_id(url) == 'Piano-sample'
    assert soundgasm_test_case1._real_extract(url)['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'


# Generated at 2022-06-24 13:17:53.841762
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # test playlist_count
    ie = SoundgasmProfileIE()
    info = ie.extract('http://soundgasm.net/u/ytdl')
    assert info['id'] == 'ytdl'
    assert info['playlist_count'] == 1

# Generated at 2022-06-24 13:17:59.222060
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from tests.test_soundgasm_profile_IE import SoundgasmProfileIE
    from tests._test_utils import identical
    identic_result = SoundgasmProfileIE()
    test_result = SoundgasmProfileIE('https://soundgasm.net/u/ytdl')
    identical(identic_result, test_result)

# Generated at 2022-06-24 13:18:01.124531
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    def test_constructor():
        return SoundgasmProfileIE
    assert test_constructor() is SoundgasmProfileIE


# Generated at 2022-06-24 13:18:08.780920
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Test for constructor of class SoundgasmProfileIE

    Purpose of this test is to assert that class constructor works as expected.
    """
    ie = SoundgasmProfileIE('test', 'http://www.soundgasm.net/u/unknown')

    assert ie.ie_key() == 'Soundgasm'
    assert ie.ie_name() == 'soundgasm:profile'
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'

# Generated at 2022-06-24 13:18:16.285862
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}

# Generated at 2022-06-24 13:18:19.813064
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_SoundgasmProfileIE = SoundgasmProfileIE()
    test_SoundgasmProfileIE.extract("http://soundgasm.net/u/ytdl")

test_SoundgasmProfileIE()

# Generated at 2022-06-24 13:18:21.829228
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.suitable('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:18:27.102227
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().extract(
        'http://soundgasm.net/u/ytdl/Piano-sample') == {
        'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
        'display_id': 'Piano-sample',
        'url': 'http://soundgasm.net/sample_music/piano.m4a',
        'vcodec': 'none',
        'title': 'Piano sample',
        'description': 'Royalty Free Sample Music',
        'uploader': 'ytdl',
    }
