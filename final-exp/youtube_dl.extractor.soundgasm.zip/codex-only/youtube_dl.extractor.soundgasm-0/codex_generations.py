

# Generated at 2022-06-24 13:08:22.327596
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://example.com')
    ie.name = 'Soundgasm'
    ie.ie_key = 'Soundgasm'
    ie.video_extensions = []
    ie.soundgasm_profile_IE_class.soundgasm_profile_IE_class.IE_NAME

# Generated at 2022-06-24 13:08:33.023490
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
	test_instance = SoundgasmIE()
	result = test_instance._real_extract(test_url)
	assert result['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
	assert result['display_id'] == 'Piano-sample'
	assert result['url'] == 'http://soundgasm.net/media/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
	assert result['vcodec'] == 'none'
	assert result['title'] == 'Piano sample'
	assert result['description'] == 'Royalty Free Sample Music'

# Generated at 2022-06-24 13:08:34.445452
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    c = SoundgasmIE()
    c._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-24 13:08:41.212925
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# TODO: Separate this into its own function (e.g. a test_suite() function)
	# TODO: Add other test functions for other classes/instances of this class
	# TODO: Test for other info_dicts
    sg = SoundgasmIE()
    obj = sg.suitable("http://soundgasm.net/u/ytdl/Piano-sample")
    assert obj, "SoundgasmIE not suitable"
    obj = sg.suitable("http://soundgasm.net/u/ytdl/asdf")
    assert not obj, "SoundgasmIE suitable"

# Generated at 2022-06-24 13:08:42.271009
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:08:44.960414
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Unit test for SoundgasmIE
    # Instantiating an object of class SoundgasmIE
    ie = SoundgasmIE()
    print(ie)
    

# Generated at 2022-06-24 13:08:51.179080
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Arrange
    expected_id = 'some_id'
    profile_url = 'http://soundgasm.net/u/%s' % expected_id

    # Act
    soundgasm_profile = SoundgasmProfileIE(None, None)
    result = soundgasm_profile._match_id(profile_url)

    # Assert
    assert expected_id == result, 'Expected id to be %s, but it was %s' % (expected_id, result)

# Generated at 2022-06-24 13:08:52.235694
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert repr(SoundgasmProfileIE)

# Generated at 2022-06-24 13:09:00.517584
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    # URL format https://soundgasm.net/u/ytdl/Piano-sample
    ie.url = 'https://soundgasm.net/u/ytdl/Piano-sample'
    assert ie.IE_NAME == 'soundgasm'
    assert ie.url == 'https://soundgasm.net/u/ytdl/Piano-sample'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/([0-9a-zA-Z_-]+)/([0-9a-zA-Z_-]+)'
    assert ie.extract('https://soundgasm.net/u/ytdl/Piano-sample').get('title', None) == 'Piano sample'
    # URL format https

# Generated at 2022-06-24 13:09:05.315863
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    object_SoundgasmIE = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample", "http://soundgasm.net/u/ytdl/Piano-sample")
    assert object_SoundgasmIE.test_result()["info_dict"]["uploader"] == "ytdl"

# Generated at 2022-06-24 13:09:07.618858
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:09:08.939069
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE({})
    assert(obj)

# Generated at 2022-06-24 13:09:09.516660
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE();

# Generated at 2022-06-24 13:09:11.224675
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('compat_cookie', {})
    assert ie.ie_key() == 'Soundgasm'

# Generated at 2022-06-24 13:09:21.404843
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # SoundgasmIE shall support class SoundgasmIE
    ie = SoundgasmIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'
    assert ie._TEST['info_dict']['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-24 13:09:22.498780
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl#')

# Generated at 2022-06-24 13:09:24.435581
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert isinstance(instance, SoundgasmIE)


# Generated at 2022-06-24 13:09:28.930529
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie1 = SoundgasmIE()
    assert(ie1 != None)
    assert(ie1.IE_NAME == 'soundgasm')

if __name__ == '__main__':
    test_SoundgasmIE()

# Generated at 2022-06-24 13:09:39.201990
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	user = 'ytdl'
	display_id = 'Piano-sample'
	url = 'http://soundgasm.net/u/' + user + '/' + display_id
	
	#test constructor
	test_soundgasmIE = SoundgasmIE(url,display_id)
	
	#test attribute
	assert test_soundgasmIE.IE_NAME == 'soundgasm'
	assert test_soundgasmIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:09:43.957247
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	result = SoundgasmIE().extract_info(url="http://soundgasm.net/u/ytdl/Piano-sample", ie_key=None, download=False, extra_info={})
	assert(result["id"] == "88abd86ea000cafe98f96321b23cc1206cbcbcc9")


# Generated at 2022-06-24 13:09:51.880325
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    clips = [SoundgasmProfileIE._extract_profile('https://soundgasm.net/u/otherUser/'),
             SoundgasmProfileIE._extract_profile('https://soundgasm.net/u/otherUser'),
             SoundgasmProfileIE._extract_profile('https://soundgasm.net/u/otherUser/ownership-history'),
             SoundgasmProfileIE._extract_profile('https://soundgasm.net/u/otherUser/comments'),
             SoundgasmProfileIE._extract_profile('https://soundgasm.net/u/otherUser/liked-by'),
             SoundgasmProfileIE._extract_profile('https://soundgasm.net/u/otherUser/liked')]
    assert all(clip != None for clip in clips)

# Generated at 2022-06-24 13:09:56.385778
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print("\nTesting SoundgasmProfileIE")
    ie = SoundgasmProfileIE()
    assert_true(ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')


# Generated at 2022-06-24 13:09:57.410797
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()

# Generated at 2022-06-24 13:09:59.906878
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# Unit test for constructor of class Point
	p = SoundgasmIE()
	assert  True, "Construction failed"
	return

# Generated at 2022-06-24 13:10:02.543245
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        sg_ie = SoundgasmIE()
    except Exception as e:
        #assert(0 != 0)
        raise e


# Generated at 2022-06-24 13:10:05.317354
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    instance = ie(url = 'http://soundgasm.net/u/ytdl')
    assert isinstance(instance, SoundgasmProfileIE)

# Generated at 2022-06-24 13:10:15.314325
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    test_url = 'http://soundgasm.net/u/ytdl'
    assert ie._match_id(test_url) == 'ytdl'
    assert( ie.IE_NAME == 'soundgasm:profile')
    assert( ie.IE_NAME == IE_NAME)
    assert( ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
    assert( ie._TEST['url'] == 'http://soundgasm.net/u/ytdl')
    assert( ie._TEST['info_dict']['id'] == 'ytdl')
    assert( ie._TEST['playlist_count'] == 1)

# Generated at 2022-06-24 13:10:18.652346
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        dir(soundgasm.SoundgasmIE())
    except Exception:
        assert False, "SoundgasmIE class constructor failed"



# Generated at 2022-06-24 13:10:20.428079
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.__class__.__name__ == ie.IE_NAME

# Generated at 2022-06-24 13:10:24.129520
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    '''
    Unit test for constructor of class SoundgasmProfileIE
    The constructor of this class have already been tested in test_SoundgasmIE
    '''
    def construct(url):
        return SoundgasmProfileIE(url)
    assert construct('https://soundgasm.net/u/ytdl/') is not None

# Generated at 2022-06-24 13:10:34.408512
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

        url = 'http://soundgasm.net/u/ytdl/Piano-sample'
        ids = ('88abd86ea000cafe98f96321b23cc1206cbcbcc9', 'Piano-sample')

        actual_kwords = SoundgasmIE._build_kwords(url)
        expected_kwords = {'url': url, 'display_id': ids[1], 'ie_key': 'Soundgasm'}

        assert actual_kwords == expected_kwords

        ie = SoundgasmIE(**expected_kwords)
        assert ie._VALID_URL == SoundgasmIE._VALID_URL

        # Override default test case

# Generated at 2022-06-24 13:10:36.207951
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('test')
    assert ie.__class__.__name__ == 'SoundgasmProfileIE'

# Generated at 2022-06-24 13:10:37.100557
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert isinstance(IE_NAME, str)

# Generated at 2022-06-24 13:10:43.046773
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = """
    <script type="text/javascript">
        var jwplayer_config = {"id":"jwplayer_1","file":"/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a","streamer":"http:\/\/streaming.soundgasm.net\/","title":"Piano sample","description":"Royalty Free Sample Music","debug":false,"autostart":false,"width":185,"height":40,"skin":"\/static\/skins\/compact\/compact.xml","controlbar":"bottom","stretching":"uniform","icons":true,"playerready":"playerready","setup":"jwplayer_setup"};
    </script>"""
    title = 'Piano sample'
    description = 'Royalty Free Sample Music'
    uploader = 'ytdl'

# Generated at 2022-06-24 13:10:51.804775
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample");
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample/");
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample#");
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample/#");
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample/#/");
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample/#/s/");


# Generated at 2022-06-24 13:11:00.410723
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Create unit test for constructor of class SoundgasmProfileIE
    _Downloader = object
    _ExtractorError = object
    _SSLError = object
    _download_json = object
    _Extractor = object
    _PostProcessor = object

    class _InfoExtractor(object):
        pass

    s = SoundgasmProfileIE(
        _Downloader, _ExtractorError, _SSLError, _download_json, _Extractor, _InfoExtractor, _PostProcessor)

    assert(s.ie_key() == 'SoundgasmProfile')
    assert(s.IE_NAME == 'Soundgasm:Profile')
    assert(s.IE_DESC == 'Soundgasm:Profile downloadable content')

# Generated at 2022-06-24 13:11:10.088109
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mobj = re.match(SoundgasmIE._VALID_URL, url)
    display_id = mobj.group('display_id')

    webpage = SoundgasmIE()._download_webpage(url, display_id)

    audio_url = SoundgasmIE()._html_search_regex(
        r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', webpage,
        'audio URL', group='url')


# Generated at 2022-06-24 13:11:13.827308
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Check if the constructor of class SoundgasmIE works.
    """
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    obj = SoundgasmIE()
    obj._match_id(url)

# Generated at 2022-06-24 13:11:23.367635
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	IE = SoundgasmIE()
	assert(IE.IE_NAME=='soundgasm')
	assert(IE._VALID_URL==r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')
	assert(IE._TEST['url']=='http://soundgasm.net/u/ytdl/Piano-sample')
	assert(IE._TEST['md5']=='010082a2c802c5275bb00030743e75ad')
	assert(IE._TEST['info_dict']['id']=='88abd86ea000cafe98f96321b23cc1206cbcbcc9')

# Generated at 2022-06-24 13:11:24.712306
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = SoundgasmIE()
    assert (test.IE_NAME == 'soundgasm')



# Generated at 2022-06-24 13:11:29.975560
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info = SoundgasmProfileIE._build_url_result(
        "http://soundgasm.net/u/ytdl/Piano-sample",
        "Soundgasm"
    )
    assert info['url'] == "http://soundgasm.net/u/ytdl/Piano-sample"
    assert info['ie_key'] == "Soundgasm"

# Generated at 2022-06-24 13:11:34.255370
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Static test
    assert SoundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert SoundgasmIE._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert SoundgasmIE._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-24 13:11:44.240013
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_soundgasm_profile_ie = SoundgasmProfileIE(InfoExtractor())
    assert test_soundgasm_profile_ie._match_id('http://soundgasm.net/u/ytdl') == 'ytdl'
    assert test_soundgasm_profile_ie._match_id('http://soundgasm.net/u/ytdl/') == 'ytdl'
    assert test_soundgasm_profile_ie._match_id('http://soundgasm.net/u/ytdl/#newest') is None
    assert test_soundgasm_profile_ie._match_id('http://soundgasm.net/u/ytdl/test1') is None

# Generated at 2022-06-24 13:11:52.456768
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    # __init__(self, url, ie_key, video_id, video_title=None, video_description=None, video_view_count=None, video_thumbnail=None, video_duration=None, age_limit=None):
    audio_url_one = 'http://soundgasm.net/u/ytdl/Piano-sample'
    audio_url_two = 'http://soundgasm.net/u/ytdl/Royalty-Free-Piano-Sample'
    new_audio = SoundgasmIE(audio_url_one, 'Soundgasm', 'ytdl')
    query = 'http://soundgasm.net/u/ytdl'
    new_audio_two = SoundgasmProfileIE(query, 'soundgasm:profile', 'ytdl')

# Generated at 2022-06-24 13:12:01.620060
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = SoundgasmIE()._test_extract_video('http://soundgasm.net/u/ytdl/Piano-sample')
    assert test.get('id') == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert test.get('uploader') == 'ytdl'
    assert test.get('title') == 'Piano sample'
    assert test.get('display_id') == 'Piano-sample'
    assert test.get('description') == 'Royalty Free Sample Music'
    assert test.get('ext') == 'm4a'
    assert test.get('url') == 'http://soundgasm.net/p/ytdl/Piano-sample.m4a'
    assert test.get('vcodec') == 'none'

# Generated at 2022-06-24 13:12:07.292030
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .common import TestCase
    from .common import pt_urls
    class TestSoundgasmIE(TestCase):
        SOUNDGASMIE = SoundgasmIE()
        def test_soundgasmie(self):
            for url in pt_urls:
                self.SOUNDGASMIE.extract(url)
    test_soundgasmie = TestSoundgasmIE('test_soundgasmie')
    test_soundgasmie.test_soundgasmie()
    return test_soundgasmie

# Generated at 2022-06-24 13:12:10.182082
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("Testing SoundgasmIE() ...")
    soundgasm = SoundgasmIE()
    print("Done\n")


# Generated at 2022-06-24 13:12:21.363228
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'

    webpage = ie._download_webpage(url, profile_id)
    entries = [
        ie.url_result(audio_url, 'Soundgasm')
        for audio_url in re.findall(r'href="([^"]+/u/%s/[^"]+)' % profile_id, webpage)]

    res = ie.playlist_result(entries, profile_id)


# Generated at 2022-06-24 13:12:24.557232
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:#.*)?$'

# Generated at 2022-06-24 13:12:32.917115
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    e = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert e.IE_NAME == 'soundgasm:profile'
    assert e._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert e._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}
    assert e._html_search_regex is not None
    assert e._search_regex is not None
    assert e._match_id is not None
    assert e._download_webpage is not None
    assert e.playlist_result is not None

# Generated at 2022-06-24 13:12:36.447271
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    soundgasmprof = SoundgasmProfileIE(url)
    assert soundgasmprof.IE_NAME == 'soundgasm:profile'



# Generated at 2022-06-24 13:12:40.263531
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # A test case for constructor of class SoundgasmProfileIE
    # See https://github.com/rg3/youtube-dl/pull/11592#issuecomment-335464001
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:12:46.795813
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl/')
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

    # two constructors should accept the same type of url
    assert ie._VALID_URL == SoundgasmProfileIE._VALID_URL
    # the constructor of SoundgasmProfileIE should accept the same type of url as SoundgasmIE
    assert SoundgasmProfileIE._VALID_URL == SoundgasmIE._VALID_URL

# Generated at 2022-06-24 13:12:49.044280
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert re.match(SoundgasmIE._VALID_URL, ie._VALID_URL)

# Generated at 2022-06-24 13:12:50.083556
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie2 = SoundgasmIE('ytdl')

# Generated at 2022-06-24 13:12:51.529109
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl")

# Generated at 2022-06-24 13:12:56.551135
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE("test")
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:12:59.644011
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    target = SoundgasmProfileIE('SoundgasmProfile')
    assert isinstance(target, SoundgasmProfileIE)
    assert isinstance(target, InfoExtractor)
    assert isinstance(target, object)
    

# Generated at 2022-06-24 13:13:00.638859
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()

# Generated at 2022-06-24 13:13:04.531342
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    myTest = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    myTest._real_extract("http://soundgasm.net/u/ytdl/Piano-sample")
    print("Unit test for contructor of SoundgasmIE passed")


# Generated at 2022-06-24 13:13:06.163457
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-24 13:13:13.496888
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE()
    assert isinstance(instance, SoundgasmProfileIE)
    assert instance.IE_NAME == 'soundgasm:profile'
    assert instance.VALID_URL() == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'
    assert instance.TEST() == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}


# Generated at 2022-06-24 13:13:14.529071
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert SoundgasmProfileIE(object)

# Generated at 2022-06-24 13:13:22.120721
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE()
    assert profile.IE_NAME == 'soundgasm:profile'
    assert re.match(profile._VALID_URL, 'http://soundgasm.net/u/ytdl/')
    assert re.match(profile._VALID_URL, 'http://soundgasm.net/u/ytdl#')
    assert re.match(profile._VALID_URL, 'http://soundgasm.net/u/ytdl')
    assert re.match(profile._VALID_URL, 'http://soundgasm.net/u/ytdl/') is None
    assert re.match(profile._VALID_URL, 'http://soundgasm.net/u/ytdl#') is None

# Generated at 2022-06-24 13:13:30.478289
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    ie = SoundgasmIE()
    assert ie.suitable(url)
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie.IE_DESC == 'Soundgasm'

# Run test
if __name__ == "__main__":
    test_SoundgasmIE()

# Generated at 2022-06-24 13:13:32.984549
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	print('Testing constructor of class SoundgasmIE ...')
	soundgasm_ie = SoundgasmIE()
	print('Testing constructor of class SoundgasmIE DONE')


# Generated at 2022-06-24 13:13:37.535838
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    s = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert s.IE_NAME == 'soundgasm'
    assert s.VALID_URL == SoundgasmIE._VALID_URL
    assert s.TEST == SoundgasmIE._TEST


# Generated at 2022-06-24 13:13:39.826252
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Constructor test"""
    instance = SoundgasmProfileIE('https://soundgasm.net/u/ytdl')
    assert instance.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:13:43.976296
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-24 13:13:55.454848
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()

    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-24 13:14:04.110598
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    inst = SoundgasmProfileIE()
    info = inst._real_extract(url)

# Generated at 2022-06-24 13:14:14.635201
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import unittest
    """
    Test class SoundgasmIE
    """
    test_case1 = "https://soundgasm.net/u/jizzmuncher/HOT-GIRL-MOANING-SO-HARD-SHE-SQUIRTS-INTENSE-ORGASM-WITH-ROCKET-DILDO-HARD-CREAMPIE-MULTIO"
    test_case2 = "https://soundgasm.net/u/ytdl/Piano-sample"
    test_case3 = "https://soundgasm.net/u/Paradox_Tiger/LOVE-AND-TENSION"
    test_case4 = "http://soundgasm.net/u/ytdl"


# Generated at 2022-06-24 13:14:15.756131
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    return SoundgasmIE(None)

# Generated at 2022-06-24 13:14:19.343668
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    print (ie.extract("http://soundgasm.net/u/ytdl/Piano-sample"))

# Generated at 2022-06-24 13:14:30.197041
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    #First, let's check that soundgasmIE is an instance of InfoExtractor
    assert issubclass(SoundgasmIE,InfoExtractor)

    #Let's run extractor on Soundgasm profile page
    # ie = SoundgasmIE()
    # ie.extract(test_SoundgasmIE.url)
    # assert ie.title == test_SoundgasmIE.title

    # #Let's see if it can find all the information on the uploaded audio
    # assert ie.id == test_SoundgasmIE.id
    # assert ie.ext == test_SoundgasmIE.ext
    # assert ie.uploader == test_SoundgasmIE.uploader

    # #Let's make sure that extractor can download the audio
    # info_dict = ie.extract(test_SoundgasmIE.url)
    #

# Generated at 2022-06-24 13:14:33.561831
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    i = SoundgasmProfileIE()
    assert i._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:14:34.536972
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:14:35.857823
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE('SoundgasmIE', 'Soundgasm')

# Generated at 2022-06-24 13:14:37.057368
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    class_test = SoundgasmProfileIE()
    assert class_test != None

# Generated at 2022-06-24 13:14:42.316677
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Arrange
    url = "http://soundgasm.net/u/ytdl"

    # Act
    obj = SoundgasmProfileIE()

    # Assert
    assert obj._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:14:44.530429
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    testResult = True
    sg = SoundgasmProfileIE()
    if not sg == SoundgasmProfileIE():
        testResult = False
    return testResult

# Generated at 2022-06-24 13:14:51.125161
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from . import SoundgasmIE
    from .common import InfoExtractor
    from .common import extract_info
    from .common import compat_urllib_request
    from .common import compat_urlparse
    from .common import compat_str

    def _get_testcases():
        # _VALID_URL is set as global variable
        for input_url in [
                # you can add more test URL here
                SoundgasmIE._VALID_URL
            ]:
            yield (input_url, {
                'url': input_url,
                'playlist_mincount': 1,
            })

    ie = SoundgasmIE(InfoExtractor())
    for input_url, expected in _get_testcases():
        actual_result = ie.suitable(input_url)

# Generated at 2022-06-24 13:14:54.178375
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        link = input('Enter link to a Soundgasm user profile: ')
        obj = SoundgasmProfileIE(link)
    except:
        print('Test failed.')
    else:
        print('Test passed.')


# Generated at 2022-06-24 13:14:57.045415
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:14:57.573693
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE

# Generated at 2022-06-24 13:15:00.974303
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert(SoundgasmIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-24 13:15:05.392406
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE = SoundgasmProfileIE('ytdl')
    expect = 'http://soundgasm.net/u/ytdl/'
    assert IE._VALID_URL == expect, 'VALID_URL should be %s, but was %s' % (expect, IE._VALID_URL)


# Generated at 2022-06-24 13:15:06.024012
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:15:09.583703
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_url = 'http://soundgasm.net/u/ytdl'
    result = SoundgasmProfileIE()._real_extract(test_url)
    entries = result['entries']
    playlist_count = len(entries)
    assert playlist_count == 1

# Generated at 2022-06-24 13:15:18.998585
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:15:23.958511
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:15:30.013494
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Test constructor of class SoundgasmProfileIE"""
    extras = [
        'http://soundgasm.net/u/ytdl',
    ]
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'SoundgasmProfileIE'
    assert ie._VALID_URL == 'http://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:15:30.769106
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:15:32.192281
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	assert SoundgasmIE("https://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-24 13:15:33.578511
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()


# Generated at 2022-06-24 13:15:39.039967
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE()

# Generated at 2022-06-24 13:15:41.827023
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    if __name__ == '__main__':
        SoundgasmIE().download_audio(SoundgasmIE().extract_audio_info(SoundgasmIE().test_url))

# Generated at 2022-06-24 13:15:47.099695
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.__name__ == 'SoundgasmProfileIE'
    assert SoundgasmProfileIE._TEST == {'url': 'http://soundgasm.net/u/ytdl',
                                        'info_dict': {'id': 'ytdl'},
                                        'playlist_count': 1}


# Generated at 2022-06-24 13:15:52.623816
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    assert soundgasm._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:15:54.673039
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'https://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE()._real_extract(url)

# Generated at 2022-06-24 13:15:55.557295
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:15:57.775722
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Constructor of class SoundgasmIE
    instance = SoundgasmIE()
    # Check if instance is created successfully
    assert instance is not None

# Generated at 2022-06-24 13:16:08.645828
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    assert ie._real_extract.__name__ == 'SoundgasmProfileIE._real_extract'
    assert ie._match_id.__name__ == 'SoundgasmProfileIE._match_id'
    assert ie._download_webpage.__name__ == 'SoundgasmProfileIE._download_webpage'

# Generated at 2022-06-24 13:16:09.210657
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	test_SoundgasmIE = SoundgasmIE()

# Generated at 2022-06-24 13:16:14.035900
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    '''
    Test the constructor of class SoundgasmProfileIE
    '''
    # Test the constructor of SoundgasmProfileIE
    instance = SoundgasmProfileIE()
    assert instance.ie_key() == 'Soundgasm:profile'
    assert instance.ie_name() == 'Soundgasm'

# Generated at 2022-06-24 13:16:23.948372
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:16:28.387622
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url='http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasm = SoundgasmIE()
    # test out that the regex matches properly
    assert re.match(soundgasm._VALID_URL, url).group("display_id") == "Piano-sample"



# Generated at 2022-06-24 13:16:38.633327
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:16:41.690977
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE(url)
    assert ie.name == 'Soundgasm:Profile:ytdl'

# Generated at 2022-06-24 13:16:43.643506
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()

# Generated at 2022-06-24 13:16:45.675812
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    except Exception:
        assert False

# Generated at 2022-06-24 13:16:54.658514
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:16:57.274232
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert (profile.ie_name == 'Soundgasm')
    assert (profile.ie_key == 'Soundgasm')

# Generated at 2022-06-24 13:16:57.875515
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:17:00.271436
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # tester code
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-24 13:17:03.350952
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print("SoundgasmProfileIE Test:")
    url = "http://soundgasm.net/u/ytdl"
    ie = SoundgasmProfileIE()
    print("User ID: " + ie._match_id(url))

# Generated at 2022-06-24 13:17:08.128658
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_obj = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert(re.search(r'^https?://a\d+\.p\.soundgasm.net/', test_obj._downloader.urlopen('http://soundgasm.net/u/ytdl/Piano-sample').geturl()))



# Generated at 2022-06-24 13:17:12.326945
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    #Test with a URL which is not actually on Soundgasm.net
    #TODO: fix this once the regex is fixed
    #ie = SoundgasmIE()
    #ie.download("http://youtube.com/watch?v=WYt8Rgb5hRs")

    #Test with an actual Soundgasm.net URL
    ie = SoundgasmIE()
    ie.download("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-24 13:17:15.571566
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:17:25.525029
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    constructor = SoundgasmProfileIE()

    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'

    webpage = constructor._download_webpage(url, profile_id)

    profile_entries = re.findall(r'href="([^"]+/u/%s/[^"]+)' % profile_id, webpage)

    entries = [constructor.url_result(audio_url, 'Soundgasm') for audio_url in profile_entries]

    result = constructor.playlist_result(entries, profile_id)

    assert result['id'] == profile_id
    assert result['_type'] == 'playlist'

# Generated at 2022-06-24 13:17:33.560385
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:17:36.383320
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie._match_id(ie._VALID_URL) == 'ytdl'

# Generated at 2022-06-24 13:17:40.248495
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        b = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
        b.playlist_count
        b.url
        b.id
        b.entries
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-24 13:17:50.354372
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = "http://soundgasm.net/u/ytdl"

    obj = SoundgasmProfileIE()
    obj.url = url
    obj.playlist_count = 1

    assert obj.IE_NAME == "soundgasm:profile"
    assert obj.url == url
    assert obj._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?"
    assert obj._TEST['url'] == "http://soundgasm.net/u/ytdl"
    assert obj.profile_id == obj._match_id(url)
    assert obj.webpage == obj._download_webpage(url, obj.profile_id)
    assert obj.playlist_count == 1
    assert obj.playlist_

# Generated at 2022-06-24 13:17:54.840184
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url1 = 'http://soundgasm.net/u/ytdl/Piano-sample'
    iframes = SoundgasmIE()._make_iframes(url1)
    assert iframes == [{'url': 'http://soundgasm.net/u/ytdl/Piano-sample'}]

# Generated at 2022-06-24 13:18:04.537082
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    # basic test
    ie._download_webpage = lambda *args: '''\
<html><head>
<a href="http://soundgasm.net/u/ytdl/Piano-sample">
<a href="http://soundgasm.net/u/ytdl/Something-else">
'''

# Generated at 2022-06-24 13:18:14.241616
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE()
    instance.url = "http://soundgasm.net/u/ytdl/#-_-"

    assert instance.IE_NAME == 'soundgasm:profile'
    assert instance.url == "http://soundgasm.net/u/ytdl/#-_-"
    assert instance.param == "http://soundgasm.net/u/ytdl/#-_-"
    assert instance.VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert instance._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert instance._T

# Generated at 2022-06-24 13:18:15.895855
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from soundgasm import SoundgasmProfileIE
        
SoundgasmProfileIE()

# Generated at 2022-06-24 13:18:17.166375
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:18:18.609675
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    d = SoundgasmProfileIE()
    assert d is not None

# Generated at 2022-06-24 13:18:19.762771
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    return SoundgasmIE()
