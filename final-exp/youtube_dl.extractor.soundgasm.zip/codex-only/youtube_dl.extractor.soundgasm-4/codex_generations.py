

# Generated at 2022-06-24 13:08:26.815421
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	class_name = 'SoundgasmProfileIE'
	test_folder = 'Soundgasm'
	url = 'http://soundgasm.net/u/ytdl'
	profile_id = 'ytdl'
	playlist_count = 1
	playlist_total = 1
	# Create object of class
	object_class = eval(class_name)
	object = object_class()
	# Call functions
	playlist = object.extract(url)
	playlist_title = playlist['title']
	playlist_entries = playlist['entries']
	# Check results
	assert profile_id in playlist_title
	assert playlist_count == len(playlist_entries)


# Generated at 2022-06-24 13:08:28.326765
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:08:31.475238
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('Soundgasm Profile', 'http://soundgasm.net/u/ytdl')
    assert isinstance(ie, SoundgasmProfileIE)

# Generated at 2022-06-24 13:08:32.046461
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:08:36.631930
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    audio_id = 88
    display_id = 'Piano-sample'
    info_dict = {
        'id': audio_id,
        'display_id': display_id,
        'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
        'vcodec': 'none',
        'title': display_id,
        'description': 'Royalty Free Sample Music',
        'uploader': 'ytdl',
    }

    ie = SoundgasmIE()
    assert info_dict == ie.extract(url)


# Generated at 2022-06-24 13:08:41.606788
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Unit test for constructor of class SoundgasmProfileIE
    """
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.BRAND == 'Soundgasm'

# Generated at 2022-06-24 13:08:52.334243
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    s = SoundgasmIE()
    t = SoundgasmIE()
    v = SoundgasmIE()
    w = SoundgasmIE()
    x = SoundgasmIE()
    y = SoundgasmIE()
    z = SoundgasmIE()
    u = SoundgasmIE()
    i = SoundgasmIE()
    o = SoundgasmIE()
    p = SoundgasmIE()
    q = SoundgasmIE()
    r = SoundgasmIE()
    a = SoundgasmIE()
    b = SoundgasmIE()
    c = SoundgasmIE()
    d = SoundgasmIE()
    e = SoundgasmIE()
    f = SoundgasmIE()
    g = SoundgasmIE()
    h = SoundgasmIE()
   

# Generated at 2022-06-24 13:08:58.955141
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    x = SoundgasmProfileIE()
    assert x.IE_NAME == 'soundgasm:profile'
    assert x._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert x._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-24 13:09:09.741334
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:09:15.372801
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test for the constructor of class SoundgasmIE
    test_instance = SoundgasmIE()
    assert test_instance._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:09:23.941683
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('https://soundgasm.net/u/0nly4u/hey-%20this-is%20a-Title')
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie.IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:09:36.002114
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    y = SoundgasmProfileIE()
    y.IE_NAME == 'Soundgasm Profile'
    y.IE_DESC == 'Soundgasm Profile: bad url'
    y.VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'
    y.TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1} 
    y.TEST2 == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 3} 

# Generated at 2022-06-24 13:09:39.919189
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('https://www.soundgasm.net/u/ytdl#')

# Generated at 2022-06-24 13:09:40.818018
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('Soundgasm')

# Generated at 2022-06-24 13:09:49.172027
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        print("--- Unit test for class SoundgasmProfileIE")
        url = "http://soundgasm.net/u/ytdl"
        #Test creating object
        print("- Testing creating object")
        info_extractor = SoundgasmProfileIE()
        print("Test completed")
        #Test extracting information
        print("- Testing extracting information")
        info = info_extractor._real_extract(url)
        print("Title: ", info["title"])
        print("URL: ", info["url"])
        print("Playlist count: ", info["_type"])
        print("Test completed")
    except:
        #Throw exception if failed
        print("Error, test failed!")
        raise
    print("Test completed")

# Generated at 2022-06-24 13:09:50.947066
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._TEST['url'] ==  ie._VALID_URL

# Generated at 2022-06-24 13:09:58.283393
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test sample constructor
    testEntry = SoundgasmIE();
    
    # Name of sample site
    assert testEntry.siteName == 'soundgasm.net'

    # URL of sample site
    assert testEntry.siteBaseURL == 'http://soundgasm.net'

    # URL of sample site in mobile version
    assert testEntry.mobileBaseURL == 'http://m.soundgasm.net'

    # URL of sample site in mobile version
    assert testEntry.embedBaseURL == 'http://m.soundgasm.net/e/'

# Generated at 2022-06-24 13:10:01.020532
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    assert SoundgasmIE()._match_id(url) == 'Piano-sample'

# Generated at 2022-06-24 13:10:05.422624
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # when SoundgasmIE class is instantiated, it should return the video instance
    video = SoundgasmIE()
    assert video is not None
    # when video instance is initialized, the video instance should return the 'IE_KEY' which is 'Soundgasm'
    assert video.IE_KEY == 'Soundgasm'

# Generated at 2022-06-24 13:10:06.532475
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print(SoundgasmIE('SoundgasmIE'))

# Generated at 2022-06-24 13:10:07.582632
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE(None).IE_NAME == 'soundgasm'


# Generated at 2022-06-24 13:10:12.101904
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()
    assert obj.IE_NAME == 'soundgasm:profile'
    assert obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:10:15.539180
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('soundgasm','http://soundgasm.net/u/ytdl/Piano-sample','Royalty Free Sample Music','88abd86ea000cafe98f96321b23cc1206cbcbcc9','','','','','','')

# Generated at 2022-06-24 13:10:16.721403
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()._check_embed()

# Generated at 2022-06-24 13:10:20.523732
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test constructor of SoundgasmIE by checking the class of
    # an instance of SoundgasmIE.
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie.__class__ == SoundgasmIE

    # test_SoundgasmIE is a test with an arbitrary URL.
    # Remove the arbitrary URL from the test.
    ie = SoundgasmIE(ie._test_url)
    assert ie.__class__ == SoundgasmIE

# Generated at 2022-06-24 13:10:21.736127
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()
    print(obj)

# Generated at 2022-06-24 13:10:23.202131
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ske = SoundgasmProfileIE('test','test','test',None)
    assert ske.playlist_count == 0

# Generated at 2022-06-24 13:10:31.998735
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE()
    match = instance._VALID_URL
    assert match != None, 'Did not match URL'
    assert match.match('http://soundgasm.net/u/ytdl/Piano-sample'), 'URL not recognized by regex'
    assert match.match('https://soundgasm.net/u/ytdl/Piano-sample'), 'URL not recognized by regex'
    assert match.match('https://soundgasm.net/u/ytdl/Piano-sample.mp4'), 'URL not recognized by regex'
    assert match.match('https://soundgasm.net/u//Piano-sample'), 'URL not recognized by regex'

# Generated at 2022-06-24 13:10:38.434977
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    expected_values = {
        'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
        'display_id': 'Piano-sample',
        'ext': 'm4a',
        'title': 'Piano sample',
        'description': 'Royalty Free Sample Music',
        'uploader': 'ytdl',
    }

    ie = SoundgasmIE()
    extracted_values = ie.extract(url)
    assert expected_values == extracted_values


# Generated at 2022-06-24 13:10:46.430513
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # These are the top two entries from http://soundgasm.net/u/ytdl
    urls = [
            'http://soundgasm.net/u/ytdl/Piano-sample',
            'http://soundgasm.net/u/ytdl/Vivaldi-Autumn-sample'
           ]
    for url in urls:
        ie = SoundgasmIE(url)
        video_id = ie.video_id
        result = ie.extract()
        assert result['id'] == video_id


# Generated at 2022-06-24 13:10:48.886827
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl', {}, {'config': {'http_chunk_size': 1}})


# Generated at 2022-06-24 13:10:56.531772
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie.VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:11:05.494666
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Unit test for constructor of class SoundgasmIE
    """
    objSoundgasmIE = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    if (objSoundgasmIE.IE_NAME == 'soundgasm') & (objSoundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'):
        return True
    else:
        return False



# Generated at 2022-06-24 13:11:06.512667
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    cla = SoundgasmProfileIE
    obj = cla(None)
    return

# Generated at 2022-06-24 13:11:08.848570
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # The following URL does not actually exist, but it is the form of a Soundgasm
    # profile URL.
    instance = SoundgasmProfileIE()
    assert instance._match_id(r'www.soundgasm.net/u/ytdl') == 'ytdl'

# Generated at 2022-06-24 13:11:19.322191
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE._VALID_URL = re.compile(SoundgasmIE._VALID_URL)
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._VALID_URL.match('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._download_webpage('http://soundgasm.net/u/ytdl/Piano-sample', 'Piano-sample')
    assert ie._search_regex('http://soundgasm.net/u/ytdl/Piano-sample', '#([0-9a-zA-Z_-]+)', 'display_id')

# Generated at 2022-06-24 13:11:23.266587
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Basic test to make sure that SoundgasmProfileIE
    is constructed correctly
    """
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert ie._TEST['info_dict'] == {'id': 'ytdl'}
    assert ie._TEST['playlist_count'] == 1

# Generated at 2022-06-24 13:11:25.365921
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    assert 'SoundgasmProfileIE' == SoundgasmProfileIE._get_info_extractor(url).IE_NAME

# Generated at 2022-06-24 13:11:29.725363
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Create instance of class SoundgasmIE
    ie = SoundgasmIE()
    # Test whether url of the instance is correct
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie.suitable(url) == True


# Generated at 2022-06-24 13:11:30.971083
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE (None)
    assert ie != None

# Generated at 2022-06-24 13:11:34.756212
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test that the regular expression to match the URL is valid
    url = 'http://soundgasm.net/u/ytdl'
    mobj = re.match(SoundgasmProfileIE._VALID_URL, url)
    assert mobj.group('id') == 'ytdl'

# Generated at 2022-06-24 13:11:38.394784
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    _test = {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    assert SoundgasmProfileIE._TEST == _test

# Generated at 2022-06-24 13:11:39.529723
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('SoundgasmProfileIE');

# Generated at 2022-06-24 13:11:41.044439
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    e = SoundgasmIE()

# Generated at 2022-06-24 13:11:42.768839
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Unit test for constructor of class SoundgasmProfileIE.
    """
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:11:45.469634
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sample = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert sample is not None
    assert sample.display_id == 'Piano-sample'

# Generated at 2022-06-24 13:11:50.609277
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Constructor for actual class
    soundgasmIE = SoundgasmIE()
    # Private member
    assert soundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

if __name__ == '__main__':
    test_SoundGasmIE()

# Generated at 2022-06-24 13:11:57.372363
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie._TEST[0] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie._TEST[1] == '010082a2c802c5275bb00030743e75ad'
    assert ie._TEST[2][0] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert ie._TEST[2][1] == 'm4a'

# Generated at 2022-06-24 13:12:03.095065
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_cases = ["http://soundgasm.net/u/ytdl","http://soundgasm.net/u/ytdl/"]
    # test_cases = ["http://soundgasm.net/u/ytdl"]
    for url in test_cases:
        print(url)
        ie_test = SoundgasmProfileIE()
        ie_test._real_extract(url)

# Generated at 2022-06-24 13:12:05.836580
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:12:17.389564
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	from .test_youtube_dl import FakeYDL
	ydl = FakeYDL()
	ydl.params['usenetrc'] = False
	ydl.params['username'] = 'username'
	ydl.params['password'] = 'password'
	ydl.params['videopassword'] = 'videopassword'
	ydl.add_default_info_extractors()
	result = ydl.extract_info(
		'http://soundgasm.net/u/ytdl', download=False
	)
	assert result['id'] == 'ytdl'
	assert len(result['entries']) == 1
	assert result['entries'][0]['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-24 13:12:21.268976
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == "soundgasm:profile"
    assert ie.VALID_URL == "https?://(?:www.)?soundgasm.net/u/(?P<id>[^/]+)/?(?:#.*)?$"

# Generated at 2022-06-24 13:12:25.872082
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # When
    ie = SoundgasmProfileIE()
    # Then
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:12:35.201165
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    soundgasm_ie_match_user = re.match(ie._VALID_URL, "http://soundgasm.net/u/ytdl/Piano-sample")
    assert soundgasm_ie_match_user.group('user') == 'ytdl'
    assert soundgasm_ie_match_user.group('display_id') == 'Piano-sample'


# Generated at 2022-06-24 13:12:42.797427
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    #Checks the extraction of a public audio profile, then prints the result 
    # and all the attributes of the object
    profileIE = SoundgasmProfileIE()
    profileIE_result = profileIE.extract('http://soundgasm.net/u/ytdl')
    print("\n### {0} ###\n".format("Testing an extraction of a public audio profile: "))
    print("Extraction result: {0}\n".format(profileIE_result))
    #Tests the assertRaises() method
    #assertRaises(SoundgasmProfileIE, profileIE.extract, 'www.soundgasm.net')
    print("### Attributes ###\n")
    print("IE_NAME              = {0}".format(profileIE.IE_NAME))

# Generated at 2022-06-24 13:12:45.579719
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert str(ie) == 'SoundgasmProfileIE()'
    print('ok')


if __name__ == '__main__':
    test_SoundgasmProfileIE()

# Generated at 2022-06-24 13:12:49.196668
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info = SoundgasmIE()._call_api('http://soundgasm.net/u/ytdl/Piano-sample', '88abd86ea000cafe98f96321b23cc1206cbcbcc9')
    print('info:', info)

# Generated at 2022-06-24 13:12:59.178409
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = SoundgasmIE()
    assert test.IE_NAME == 'soundgasm'
    assert test.VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:13:01.343950
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert isinstance(SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample"), SoundgasmIE)


# Generated at 2022-06-24 13:13:02.053877
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE() 
    assert ie is not None
    

# Generated at 2022-06-24 13:13:11.923902
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:13:15.218740
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    constructor = SoundgasmIE
    i = constructor(test_SoundgasmIE.__name__, {'display_id': 'latest'},
                    'Hello')
    assert i is not None
    assert i.playlist_count == 1
    return

# Generated at 2022-06-24 13:13:17.215083
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Test case for class SoundgasmIE"""
    obj = SoundgasmIE()
    assert obj.ie_key() == 'Soundgasm'
    assert obj._VALID_URL is not None
    assert obj.name() == 'Soundgasm'
    assert obj.description() is not None


# Generated at 2022-06-24 13:13:19.017165
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    p=SoundgasmProfileIE('Soundgasm')
    print(p)
    print(p.IE_NAME)
    print(p.__name__)
    print(p._VALID_URL)
    print(p._downloader)


# Generated at 2022-06-24 13:13:23.610089
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg_test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    sg_test = SoundgasmIE() 
    print(sg_test._download_webpage(sg_test_url, 'display_id'))

# Generated at 2022-06-24 13:13:32.502591
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    inst = SoundgasmIE()
    AudioInfo = inst.extract(url)
    audio_url = AudioInfo['url']
    audio_id = AudioInfo['id']
    title = AudioInfo['title']
    description = AudioInfo['description']
    uploader = AudioInfo['uploader']
    assert audio_url == "http://soundgasm.net/sounds/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a"
    assert audio_id == "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
    assert title == 'Piano sample'
    assert description == 'Royalty Free Sample Music'
    assert uploader

# Generated at 2022-06-24 13:13:33.952614
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().initialize()


# Generated at 2022-06-24 13:13:35.237485
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl#')

# Generated at 2022-06-24 13:13:38.156478
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE(None)._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'

# Generated at 2022-06-24 13:13:42.877147
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-24 13:13:44.557278
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_object = SoundgasmProfileIE(InfoExtractor())
    test_object._match_id('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:13:51.760478
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """test SoundgasmProfileIE, this test is designed to make sure that the
    constructor of class SoundgasmProfileIE works"""
    soundgasm_profile_ie = SoundgasmProfileIE()

    assert soundgasm_profile_ie.ie_key() == 'SoundgasmProfile'
    assert soundgasm_profile_ie.ie_name() == 'Soundgasm:profile'
    assert soundgasm_profile_ie.ie_description() == 'Soundgasm Profile'

# Generated at 2022-06-24 13:13:55.742203
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Unit test for constructor of class SoundgasmProfileIE
    """
    url = 'http://soundgasm.net/u/ytdl'
    soundgasmProfileIE = SoundgasmProfileIE()
    soundgasmProfileIE.extract(url)

# Generated at 2022-06-24 13:13:56.713510
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE().extract()


# Generated at 2022-06-24 13:14:00.805924
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    print(ie.IE_NAME)
    print(ie._VALID_URL)
    print(ie._TEST)
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    print(ie._real_extract(url))


# Generated at 2022-06-24 13:14:03.909671
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
  url = 'http://soundgasm.net/u/ytdl/Piano-sample'
  assert '010082a2c802c5275bb00030743e75ad' == SoundgasmIE()._real_extract(url)['md5']

# Generated at 2022-06-24 13:14:06.519037
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    sg = SoundgasmProfileIE()
    result = sg._real_extract(url)
    print(result)

# Generated at 2022-06-24 13:14:08.956290
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')._downloader.params

# Generated at 2022-06-24 13:14:10.373298
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE._VALID_URL is not None
    

# Generated at 2022-06-24 13:14:12.728284
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	assert SoundgasmIE(SoundgasmIE._VALID_URL) is not None
# end of test for constructor of class SoundgasmIE



# Generated at 2022-06-24 13:14:14.166929
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE.test()


# Generated at 2022-06-24 13:14:21.390227
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test URL: http://soundgasm.net/u/ytdl/Piano-sample
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    expected_video_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    expected_title = 'Piano sample'
    expected_uploader = 'ytdl'

    SoundgasmIE = SoundgasmIE()
    SoundgasmIE.IE_NAME = 'SoundgasmIE'    
    SoundgasmIE._VALID_URL = SoundgasmIE._VALID_URL + "|" + url

    # The constructor of InfoExtractor should match audio_url with _VALID_URL,
    # and then extract the video_id from audio_url, and then find the

# Generated at 2022-06-24 13:14:22.482150
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:14:32.822600
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = SoundgasmIE()
    test._real_initialize('http://soundgasm.net/u/ytdl/Piano-sample')
    assert test.IE_NAME == 'soundgasm'
    assert test.SUFFIX == '.m4a'

# Generated at 2022-06-24 13:14:39.561742
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert SoundgasmProfileIE._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert SoundgasmProfileIE._TEST['info_dict'] == {'id': 'ytdl'}
    assert SoundgasmProfileIE._TEST['playlist_count'] == 1

test_SoundgasmProfileIE()

# Generated at 2022-06-24 13:14:46.336379
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import inspect, os
    file_path = inspect.getfile(test_SoundgasmProfileIE)
    file_dir = os.path.dirname(file_path)
    os.chdir(file_dir)

    soundgasm_id = 'ytdl'
    profile_url = 'http://soundgasm.net/u/ytdl/'
    webpage = open('test_profile_page.txt','r').read()
    playlist_urls = re.findall(r'href="([^"]+/u/%s/[^"]+)' % soundgasm_id, webpage)

    instance_test_SoundgasmProfileIE = SoundgasmProfileIE()

# Generated at 2022-06-24 13:14:49.740797
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_class = SoundgasmIE()
    assert(test_class.IE_NAME == "Soundgasm")

# Generated at 2022-06-24 13:14:53.688757
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano"
    ies = SoundgasmIE(url)
    assert ies.display_id == 'Piano'
    assert ies.url == url
    assert ies.uid == 'ytdl'


# Generated at 2022-06-24 13:14:58.486696
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert ie._TEST['info_dict']['id'] == 'ytdl'
    assert ie._TEST['playlist_count'] == 1


# Generated at 2022-06-24 13:15:00.076815
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    s = SoundgasmIE()
    assert(s.IE_NAME == 'soundgasm')

# Generated at 2022-06-24 13:15:01.902011
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE()
    assert a.__class__.__name__ == 'SoundgasmProfileIE'

# Generated at 2022-06-24 13:15:08.983080
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = "http://soundgasm.net/u/ytdl"
    profile_id = 'ytdl'

    # GIVEN an instance of SoundgasmProfileIE
    profileIE = SoundgasmProfileIE()
    # WHEN I pass the url variable to _match_id()
    profile_id_from_match_id = profileIE._match_id(url)
    # THEN profile_id_from_match_id should be the same as profile_id
    assert profile_id_from_match_id == profile_id


# Generated at 2022-06-24 13:15:12.156274
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # assert isinstance(SoundgasmProfileIE, InfoExtractor), 'SoundgasmProfileIE is not a class of soundgasm.py'
    assert hasattr(SoundgasmProfileIE, '_VALID_URL'), 'SoundgasmProfileIE misses the attribute _VALID_URL'

# Generated at 2022-06-24 13:15:22.433376
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	test_url = "http://soundgasm.net/u/ytdl/Piano-sample"
	test_exp_title = "Piano sample"
	test_exp_url = "http://d2zo9lplkbi5tl.cloudfront.net/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a"
	test_exp_id = "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
	
	extractor_obj = SoundgasmIE()
	info_dict = extractor_obj._real_extract(test_url)
	
	assert info_dict["id"] == test_exp_id
	assert info_dict["url"] == test_exp_url
	assert info_dict["title"]

# Generated at 2022-06-24 13:15:24.685245
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = IE_NAME = 'SoundgasmIE()'

# Generated at 2022-06-24 13:15:26.024812
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE().IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:15:28.630409
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert obj.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:15:30.312860
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .testing import make_test_IE
    SoundgasmProfileIE()


# Unit tests for SoundgasmIE

# Generated at 2022-06-24 13:15:31.027802
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    print(ie)


# Generated at 2022-06-24 13:15:33.105025
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """make sure constructor of class SoundgasmIE is working properly"""
    instance = SoundgasmIE()
    assert instance.IE_NAME == 'soundgasm'
    assert instance.VALID_URL == SoundgasmIE._VALID_URL
    assert instance.TEST == SoundgasmIE._TEST


# Generated at 2022-06-24 13:15:35.454677
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = SoundgasmIE()._run_test(
        SoundgasmIE._TEST
    )
    assert test == True


# Generated at 2022-06-24 13:15:42.314046
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    
    url = 'http://soundgasm.net/u/ytdl'
    
    ie = SoundgasmProfileIE()

    assert ie.ie_key() == 'Soundgasm:profile'
    assert ie.suitable(url)
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'



# Generated at 2022-06-24 13:15:52.981686
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    quals = [
        'http://soundgasm.net/u/ytdl/Piano-sample',
        'http://soundgasm.net/u/ytdl/Piano-sample',
    ]
    for url in quals:
        test_SoundgasmIE=SoundgasmIE()
        results= test_SoundgasmIE._real_extract(url)
        print(results)
        assert(results['url']=='http://cdn.soundgasm.net/sounds/88abd86ea000cafe98f96321b23cc1206cbcbcc9/54bfcfb6d24b7.m4a')
        assert(results['title']=='Piano sample')

# Generated at 2022-06-24 13:15:54.479024
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert isinstance(SoundgasmProfileIE(None, None), InfoExtractor)

# Generated at 2022-06-24 13:16:00.523318
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasmIE = SoundgasmIE()
    # test for method '_real_extract' with URL
    # http://soundgasm.net/u/ytdl/Piano-sample
    mobj = re.match(soundgasmIE._VALID_URL, 'http://soundgasm.net/u/ytdl/Piano-sample')
    soundgasmIE._real_extract(SoundgasmIE, mobj)


# Generated at 2022-06-24 13:16:11.790810
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE('SoundgasmProfileIE')
    assert soundgasm_profile_ie.ie_name == 'SoundgasmProfileIE'
    assert soundgasm_profile_ie.ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert soundgasm_profile_ie.ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert soundgasm_profile_ie.ie._TEST['info_dict'] == {
            'id': 'ytdl',
        }
    assert soundgasm_profile_ie.ie._TEST['playlist_count'] == 1
    assert soundgasm_profile_

# Generated at 2022-06-24 13:16:15.824799
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    #print vars(ie)
    #print ie.url

# Generated at 2022-06-24 13:16:19.824755
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sample_test_case = {
        "url": "http://soundgasm.net/profile/ytdl",
    }
    inst = SoundgasmProfileIE()
    inst._real_extract(sample_test_case["url"])


# Generated at 2022-06-24 13:16:24.550926
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    print("Unit test for constructor of class SoundgasmProfileIE")
    print("URL: ", soundgasm_profile_ie._VALID_URL)
    print("ID: ", soundgasm_profile_ie._TEST['url'])
    print("\n")


# Generated at 2022-06-24 13:16:35.148406
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test the constructor
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    ie = SoundgasmIE()
    assert ie.get_IE_NAME() == 'soundgasm'
    assert ie.get_VALID_URL() == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:16:42.248967
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    audio_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    display_id = 'Piano-sample'
    audio_url = 'http://soundgasm.net/f/sounds/88abd86ea000cafe98f96321b23cc1206cbcbcc9/Piano-sample.m4a'

    # Create instance of SoundgasmIE
    soundgasmIE = SoundgasmIE()
    mobj = soundgasmIE._regex_search(soundgasmIE._VALID_URL, audio_url)
    assert audio_id == soundgasmIE._search_regex(r'/([^/]+)\.m4a', audio_url, 'audio id', default=display_id)

# Generated at 2022-06-24 13:16:44.205734
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-24 13:16:47.060057
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url= "http://soundgasm.net/u/ytdl/Piano-sample"
    tech1 = SoundgasmIE(url)
    assert tech1.IE_NAME == 'SoundgasmIE'

# Generated at 2022-06-24 13:16:48.760802
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert SoundgasmProfileIE._TEST['info_dict']['id'] == 'ytdl'


# Generated at 2022-06-24 13:16:50.487025
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    assert "SoundgasmIE" in str(soundgasm.__class__)

# Generated at 2022-06-24 13:16:54.929809
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    s = SoundgasmIE()
    action = {
        'type': 'playlist',
        'url': 'http://soundgasm.net/u/whisperlover/',
        'playlist_id': 'whisperlover'
    }
    playlist = s.url_result(action['url'], action['type'])
    assert playlist.id == action['playlist_id']

# Generated at 2022-06-24 13:16:55.405758
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:17:00.532599
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.__class__.__name__ == 'SoundgasmProfileIE'

# Generated at 2022-06-24 13:17:07.421241
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-24 13:17:08.327045
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from . import Soundgasm

# Generated at 2022-06-24 13:17:15.583523
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    extractor = SoundgasmProfileIE('SoundgasmProfileIE')
    assert extractor.IE_NAME == 'soundgasm:profile'
    assert extractor._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert extractor._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-24 13:17:16.712869
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE()

# Generated at 2022-06-24 13:17:19.365597
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        SoundgasmProfileIE()
    except Exception as e:
        assert False, "Constructor of class SoundgasmProfileIE raised an exception: " + str(e)

# Generated at 2022-06-24 13:17:29.356355
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Basic test to confirm expected extraction from a known Soundgasm video
    """

    # Load a known video and confirm expected values
    ie = SoundgasmIE()
    info = ie._call_downloader('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:17:29.949044
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-24 13:17:31.721807
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    SoundgasmIE()


# Generated at 2022-06-24 13:17:33.135958
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-24 13:17:34.709686
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("Testing SoundgasmIE..")
    assert SoundgasmIE.IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:17:39.010198
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    url = 'http://soundgasm.net/u/ytdl'
    parsed = ie._real_extract(url)
    assert parsed.get('id') == 'ytdl'
    assert parsed.get('playlist_count') == 1


# Generated at 2022-06-24 13:17:40.670513
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    a = SoundgasmIE()
    assert isinstance(a, InfoExtractor)


# Generated at 2022-06-24 13:17:42.351300
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()._build_url('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:17:50.006617
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print ("Testing SoundgasmIE")
    s = SoundgasmIE()
    #assert s.IE_NAME == "soundgasm"
    #assert s._VALID_URL == "http://soundgasm.net/u/%s/%s" % (SOUNDGASM_USER, SOUNDGASM_DISPLAY_ID)
    #assert s._TEST["url"] == "http://soundgasm.net/u/%s/%s" % (SOUNDGASM_USER, SOUNDGASM_DISPLAY_ID)


# Generated at 2022-06-24 13:18:00.207138
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    # url = "http://soundgasm.net/u/ytdl/Piano-sample#gp=23"
    # url = "http://soundgasm.net/u/ytdl/Piano-sample#gs=23"
    # url = "http://soundgasm.net/u/ytdl/Piano-sample#gsp=30"
    e = SoundgasmIE()
    # e.set_url(url)
    # assert e.has_ieid('soundgasm')
    # assert e.has_extract_id('88abd86ea000cafe98f96321b23cc1206cbcbcc9')
    # assert e.has_extract_user('ytdl')

# Generated at 2022-06-24 13:18:01.803428
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('test', 'http://soundgasm.net/u/ytdl')



# Generated at 2022-06-24 13:18:09.221571
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    '''
    Unit test to check if constructor of class SoundgasmProfileIE is working as it is supposed to.

    The test will create an instance of the class and then check if the extract function is called.
    '''
    # Import dependencies
    import sys
    sys.path.insert(0,'/home/sidharth/ytdl')
    from ytdl.extractor.common import InfoExtractor
    from ytdl.compat import compat_urllib_request
    
#    user_agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36'

# Generated at 2022-06-24 13:18:20.513046
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # test SoundgasmProfileIE._real_extract(), return value
    # return value
    # value is a dict
    # value.get('entries').get('url') = 'http://soundgasm.net/u/ytdl'
    # value.get('title') = 'ytdl'
    # value.get('id') = 'ytdl'
    import SoundgasmProfileIE
    assert SoundgasmProfileIE.SoundgasmProfileIE()._real_extract(
        "http://soundgasm.net/u/ytdl/")['entries'][0]['url'] == 'http://soundgasm.net/u/ytdl/'