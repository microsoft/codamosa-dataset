

# Generated at 2022-06-24 13:08:24.949193
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .soundgasm import SoundgasmProfileIE
    class_ = SoundgasmProfileIE
    class_.__name__ = 'SoundgasmProfileIE'
    ins = class_(class_._VALID_URL, 'Soundgasm')
    assert ins.IE_NAME == 'soundgasm:profile'
    assert ins.__name__ == 'SoundgasmProfileIE'

# Generated at 2022-06-24 13:08:27.034518
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Should not raise an exception
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")


# Generated at 2022-06-24 13:08:30.327977
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    s = SoundgasmIE()
    print(re.match(s._VALID_URL, 'http://soundgasm.net/u/ytdl/Piano-sample'))

# Generated at 2022-06-24 13:08:33.923899
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()

    # Check its field '_VALID_URL'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:08:36.920557
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'Soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert '_TEST' in ie.__dict__


# Generated at 2022-06-24 13:08:43.192789
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.TEST == {
            'url': 'http://soundgasm.net/u/ytdl',
            'info_dict': {
                'id': 'ytdl',
            },
            'playlist_count': 1,
        }

# Generated at 2022-06-24 13:08:49.275479
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test the constructor of SoundgasmIE class
    # Do not write unit test for downloader
    assert SoundgasmIE.IE_NAME == 'soundgasm'
    assert SoundgasmIE.VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-24 13:08:56.770520
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
    'url': 'http://soundgasm.net/u/ytdl',
    'info_dict': {
        'id': 'ytdl',
    },
    'playlist_count': 1,
    }



# Generated at 2022-06-24 13:08:57.558058
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    x = SoundgasmIE('Soundgasm', {})
    print(x)

# Generated at 2022-06-24 13:09:02.962333
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    info_dict = SoundgasmIE()._real_extract(url)
    assert info_dict['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert info_dict['ext'] == 'm4a'
    assert info_dict['title'] == 'Piano sample'
    assert info_dict['description'] == 'Royalty Free Sample Music'
    assert info_dict['uploader'] == 'ytdl'


# Generated at 2022-06-24 13:09:13.844091
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test for constructor of SoundgasmIE class
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    expected_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    expected_md5 = '010082a2c802c5275bb00030743e75ad'
    expected_title = 'Piano sample'
    expected_description = 'Royalty Free Sample Music'
    expected_uploader = 'ytdl'
    expected_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    expected_ext = 'm4a'

    class_SoundgasmIE = SoundgasmIE(expected_url)


# Generated at 2022-06-24 13:09:15.273455
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:09:20.143970
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile = SoundgasmProfileIE(url)
    assert profile.IE_NAME == 'soundgasm:profile'
    assert profile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:09:25.929251
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-24 13:09:27.168826
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:09:35.907273
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    id = "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
    title = "Piano sample"
    description = "Royalty Free Sample Music"
    uploader = "ytdl"

    ie = SoundgasmIE()

    info_dict = ie._real_extract(url)
    assert info_dict['id'] == id
    assert info_dict['title'] == title
    assert info_dict['uploader'] == uploader
    assert info_dict['description'] == description

# Generated at 2022-06-24 13:09:36.524150
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-24 13:09:44.730429
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	with open('soundgasm.html', 'r') as f:
		webpage = f.read()
		profile_id = 'ytdl'
		entries = [
			'http://soundgasm.net/u/ytdl/Piano-sample',
			'http://soundgasm.net/u/ytdl/10s-test',
			'http://soundgasm.net/u/ytdl/8-bit-intro-test',
		]

# Generated at 2022-06-24 13:09:47.154836
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL == ('https?://(?:www\.)?soundgasm\.net/u/([^/]+)/?(?:\#.*)?$') 


# Generated at 2022-06-24 13:09:57.659906
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .common import play_count
    ie = SoundgasmIE()
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mobj = ie.url_result(url)

# Generated at 2022-06-24 13:09:59.451201
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    columnTest() # calls SoundgasmIE
    assert( SoundgasmIE._VALID_URL != None )


# Generated at 2022-06-24 13:10:05.735134
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	print("Test: SoundgasmProfileIE constructor")
	soundgasm_profile_ie = SoundgasmProfileIE()
	assert(soundgasm_profile_ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
	assert(soundgasm_profile_ie.IE_NAME == 'soundgasm:profile')


# Generated at 2022-06-24 13:10:08.050731
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()

# Generated at 2022-06-24 13:10:12.475583
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SGProfileIE = SoundgasmProfileIE(object)
    assert SGProfileIE.IE_NAME == "soundgasm"
    assert SGProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:10:16.564914
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert(ie.IE_NAME == 'soundgasm:profile')
    assert(ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')

# Generated at 2022-06-24 13:10:18.555821
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    print('Hello')

# Generated at 2022-06-24 13:10:24.129711
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Construct an object
    ie = SoundgasmProfileIE()

    assertions = {
        '_VALID_URL': SoundgasmProfileIE._VALID_URL,
        'IE_NAME': SoundgasmProfileIE.IE_NAME,
        'test': SoundgasmProfileIE._TEST,
    }

    for attr, value in assertions.items():
        assert getattr(ie, attr) == value, \
            'Attribute %s != %s' % (attr, value)



# Generated at 2022-06-24 13:10:25.201823
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()

# Generated at 2022-06-24 13:10:28.289402
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE = SoundgasmProfileIE()
    ie_SoundgasmProfileIE = ie.IE(SoundgasmProfileIE)
    ie_SoundgasmProfileIE.suitable(SoundgasmProfileIE)

# Generated at 2022-06-24 13:10:37.578165
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Unit test for constructor of class SoundgasmIE
    """

    # url not a string
    _VALID_URL = 3
    _TEST = {
        'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
        'md5': '010082a2c802c5275bb00030743e75ad',
        'info_dict': {
            'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
            'ext': 'm4a',
            'title': 'Piano sample',
            'description': 'Royalty Free Sample Music',
            'uploader': 'ytdl',
        }
    }

    # IE_NAME not a string

# Generated at 2022-06-24 13:10:38.738088
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE(
        InfoExtractor()
    )

# Generated at 2022-06-24 13:10:49.646706
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	ie = SoundgasmIE("https://soundgasm.net/u/ytdl/Piano-sample")

	assert ie.IE_NAME == "soundgasm"
	assert ie._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)"

# Generated at 2022-06-24 13:10:50.001992
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:10:50.921505
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = SoundgasmIE()


# Generated at 2022-06-24 13:10:55.153053
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test soundgasm:profile
    url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE()
    result = ie.extract(url)
    assert result['_type'] == 'playlist'
    assert result['entries'][0]['id'] == 'Piano-sample'
    assert result['title'] == 'ytdl'

# Generated at 2022-06-24 13:10:57.807261
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE().ie_key() == 'Soundgasm:profile'
    assert SoundgasmProfileIE().ie_name() == 'Soundgasm:profile'

# Generated at 2022-06-24 13:11:08.239382
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE.construct()
    assert ie.IE_NAME == 'soundgasm'
    assert ie.IE_DESC == 'soundgasm.net'
    assert ie._VALID_URL == 'https?://(?:www\\.)?soundgasm\\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-24 13:11:16.570367
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert SoundgasmProfileIE._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert SoundgasmProfileIE._TEST['info_dict'] == {'id': 'ytdl'}
    assert SoundgasmProfileIE._TEST['playlist_count'] == 1


# Generated at 2022-06-24 13:11:18.098960
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Constructor test"""
    ie = SoundgasmIE()

# Generated at 2022-06-24 13:11:22.466656
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = SoundgasmProfileIE._match_id(url)

    assert(profile_id == 'ytdl')
    assert(SoundgasmProfileIE.IE_NAME == 'soundgasm:profile')

# Testing whether constructor of class SoundgasmIE can properly recognize a given url

# Generated at 2022-06-24 13:11:33.363215
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Code for testing
    # return

    sgasmIE = SoundgasmIE()
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    video = sgasmIE.extract(url)
    print('Video title is: ', video.get('title'))   # output: Piano sample
    print('Video id is: ', video.get('id'))         # output: 88abd86ea000cafe98f96321b23cc1206cbcbcc9
    print('Video author is: ', video.get('uploader')) # output ytdl
    print('Video description is: ', video.get('description'))
    print('Video thumbnail is: ', video.get('thumbnail'))
    print('Vide url is: ', video.get('url'))

# Generated at 2022-06-24 13:11:34.511438
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-24 13:11:35.703698
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:11:45.429664
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'
    webpage = '<html><a href="http://soundgasm.net/u/ytdl/audiourl1">1</a><a href="http://soundgasm.net/u/ytdl/audiourl2">2</a><a href="http://soundgasm.net/u/ytdl/audiourl3">3</a></html>'

# Generated at 2022-06-24 13:11:53.307313
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE()
    webpage = ie._download_webpage(url, 'Piano-sample')
    audio_url = ie._html_search_regex(r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', webpage,
                                    'audio URL', group='url')

    title = ie._search_regex(r'<div[^>]+\bclass=["\']jp-title[^>]+>([^<]+)',
                        webpage, 'title', default='Piano-sample')


# Generated at 2022-06-24 13:11:55.121893
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info_extractor = SoundgasmProfileIE('soundgasm:profile', {})
    assert info_extractor.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:11:56.948907
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie_prof = SoundgasmProfileIE('/u/ytdl')
    assert ie_prof is not None

# Generated at 2022-06-24 13:12:04.259699
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    t = SoundgasmProfileIE()
    t.ie_key = None
    t.info_dict = None
    t.id = None
    t.is_ready = False
    t.url = "http://soundgasm.net/u/ytdl"
    assert(t.is_ready == False)
    t.initialize()
    assert(t.is_ready == True)
    assert(t.id == "ytdl")
    assert(t.info_dict == None)
    assert(t.ie_key == "SoundgasmProfileIE")

# Generated at 2022-06-24 13:12:08.650125
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    class_name = 'SoundgasmIE'
    file_name = 'SoundgasmIE.py'

    # Create a new Instance of this class with the url
    instance = globals()[class_name](url)

    print("Testing {0} in {1}".format(url, file_name))
    print("=" * 80)

    # Print the variables
    for key in instance.__dict__:
        value = instance.__dict__[key]
        print("{0}: {1}".format(key, value))

    # Print the functions

# Generated at 2022-06-24 13:12:15.463991
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie_test = SoundgasmProfileIE('soundgasm:profile')
    assert ie_test.IE_NAME is not None
    assert ie_test._VALID_URL is not None
    assert ie_test._TEST is not None
    assert ie_test._real_extract is not None
    assert ie_test._match_id is not None
    assert ie_test._download_webpage is not None


# Generated at 2022-06-24 13:12:17.907198
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert obj

# Generated at 2022-06-24 13:12:21.027281
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert "soundgasm.net/u/" in SoundgasmProfileIE._VALID_URL
    assert "http://soundgasm.net/u/ytdl" in SoundgasmProfileIE._VALID_URL

# Generated at 2022-06-24 13:12:23.408827
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Ensure we have an instance of SoundgasmIE
    ie = SoundgasmIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:12:30.714374
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import MockFile
    from .common import get_testdata_file
    from .common import str_to_testid

    expected_playlist_id = 'test_playlist'
    test_id = lambda url: str_to_testid(SoundgasmProfileIE._match_id(url))

    # test on a webpage, which contains valid audio urls, then find out if the
    # IE can construct the playlist correctly
    webpage = MockFile(open(get_testdata_file('soundgasm_profile.html'), 'rb'))
    playlist = SoundgasmProfileIE._real_extract('http://soundgasm.net/u/'
            + expected_playlist_id, webpage)
    assert playlist['id'] == expected_playlist_id

# Generated at 2022-06-24 13:12:32.296595
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:12:34.901378
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	IE = SoundgasmIE
	IE()._downloader
	# TODO : write test for SoundgasmIE


# Generated at 2022-06-24 13:12:39.372550
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    yie = SoundgasmProfileIE()
    assert yie['IE_NAME'] == 'soundgasm:profile'
    assert yie['_VALID_URL'] == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert yie['_TEST']['url'] == 'http://soundgasm.net/u/ytdl'
    assert yie['_TEST']['info_dict']['id'] == 'ytdl'
    assert yie['_TEST']['playlist_count'] == 1


# Generated at 2022-06-24 13:12:40.836135
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    profile_id = profile_ie._match_id(profile_ie._VALID_URL)
    print(profile_id)

# Generated at 2022-06-24 13:12:50.585465
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert re.match(r'https?://(?:www\.)?soundgasm\.net/u/[^/]+/?(?:\#.*)?', 'http://soundgasm.net/u/ytdl')
    assert re.match(r'https?://(?:www\.)?soundgasm\.net/u/[^/]+/?(?:\#.*)?', 'http://soundgasm.net/u/ytdl/')
    assert re.match(r'https?://(?:www\.)?soundgasm\.net/u/[^/]+/?(?:\#.*)?', 'http://soundgasm.net/u/ytdl/#')

# Generated at 2022-06-24 13:13:00.343430
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url1 = 'http://soundgasm.net/u/ytdl/Piano-sample'
    url2 = 'http://soundgasm.net/u/ytdl/Abstraction.mp3'

    result1 = SoundgasmIE()._real_extract(url1)
    result2 = SoundgasmIE()._real_extract(url2)

    assert result1['id'] == 'Piano-sample'
    assert result1['uploader'] == 'ytdl'
    assert result1['display_id'] == 'Piano-sample'
    assert result1['url'][-4:] == '.m4a'
    assert result2['id'] == 'Abstraction'
    assert result2['uploader'] == 'ytdl'
    assert result2['display_id'] == 'Abstraction'

# Generated at 2022-06-24 13:13:01.480251
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(None)

    ie.IE_NAME

# Generated at 2022-06-24 13:13:11.021424
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # I want to test the constructor of the class SoundgasmProfileIE
    # so I can use the python built-in ‘assert’ method to test a
    # number of properties of the instance.
    sp_instance = SoundgasmProfileIE()

    # Test the ‘IE_NAME’ property is set correctly.
    assert sp_instance.IE_NAME == 'soundgasm:profile'

    # Test that the '_VALID_URL' property contains a valid regex.
    assert re.search(sp_instance._VALID_URL, 'https://soundgasm.net/u/ytdl') is not None
    assert re.search(sp_instance._VALID_URL, 'https://soundgasm.net/u/ytdl/') is not None

# Generated at 2022-06-24 13:13:12.744442
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_object = SoundgasmIE()
    assert isinstance(soundgasm_object, InfoExtractor)

# Generated at 2022-06-24 13:13:19.628524
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/([^/]+)/?(?:\\#.*)?$'
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert SoundgasmProfileIE._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-24 13:13:22.047211
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE()
    except:
        assert False, 'Failed to initialize SoundgasmIE'

# Generated at 2022-06-24 13:13:28.060814
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    s = SoundgasmIE()
    #assert s.IE_DESC == 'Soundgasm'
    assert s.IE_NAME == 'soundgasm'
    assert s._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-24 13:13:29.716660
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Unit test for constructor of class SoundgasmIE"""
    SoundgasmIE('SoundgasmIE')

# Generated at 2022-06-24 13:13:35.502085
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?"
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-24 13:13:36.456376
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_url = 'http://soundgasm.net/u/ytdl'
    SoundgasmProfileIE()(test_url)

# Generated at 2022-06-24 13:13:40.717459
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-24 13:13:45.785418
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    test_class = "SoundgasmIE"
    test_instance = SoundgasmIE()

    assert test_instance.ie_key() == 'Soundgasm'
    assert test_instance.ie_name == 'Soundgasm'
    assert test_instance.test() == list()
    assert test_instance.SUCCESS == list()
    assert test_instance.result() == list()

# Generated at 2022-06-24 13:13:47.707394
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()._VALID_URL == SoundgasmIE._VALID_URL


# Generated at 2022-06-24 13:13:55.047189
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Constructor test
    """
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    # Assert that we are using the URL for SoundgasmIE.
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:13:58.930820
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_instance=SoundgasmIE()
    url="http://soundgasm.net/u/ytdl/Piano-sample"
    webpage=soundgasm_instance._download_webpage(url,'Piano-sample')
    assert webpage.startswith('<html')


# Generated at 2022-06-24 13:14:01.593029
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:14:04.007114
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE(None)._VALID_URL == SoundgasmIE._VALID_URL
    assert SoundgasmIE(None).IE_NAME == SoundgasmIE.IE_NAME

# Generated at 2022-06-24 13:14:05.233470
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE(None) == SoundgasmProfileIE(None)

# Generated at 2022-06-24 13:14:06.182725
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:14:10.928513
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie.md5 == '010082a2c802c5275bb00030743e75ad'
    assert ie.display_id == 'Piano-sample'
    assert ie.user == 'ytdl'

# Generated at 2022-06-24 13:14:20.039088
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE()
    if instance._VALID_URL != 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)':
        raise AssertionError('_VALID_URL value is incorrect after initialization!')

# Generated at 2022-06-24 13:14:28.046151
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE()
    assert a.IE_NAME == 'soundgasm:profile'
    assert a._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert a._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-24 13:14:34.765512
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import expected_warnings
    from .common import extractor_for_url
    from .common import test_urls

    for url in test_urls.keys():
        if not isinstance(extractor_for_url(url), SoundgasmIE):
            continue
        with expected_warnings(('This test checks that a playlist is '
                                'returned for SoundgasmProfileIE; '
                                'the entries will be checked in the next test')):
            SoundgasmProfileIE()._real_extract(url)

# Generated at 2022-06-24 13:14:38.878435
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest
    class TestSoundgasmProfileIE(unittest.TestCase):
        def test_constructor(self):
            SoundgasmProfileIE()

    suite = unittest.defaultTestLoader.loadTestsFromTestCase(TestSoundgasmProfileIE)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-24 13:14:41.528797
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert(str(SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')) == '<SoundgasmIE http://soundgasm.net/u/ytdl/Piano-sample>')


# Generated at 2022-06-24 13:14:46.862876
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}

# Generated at 2022-06-24 13:14:49.889343
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.__name__ == 'Soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'

# Generated at 2022-06-24 13:14:54.756762
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test for unknown values
    mp = SoundgasmProfileIE("", "", "", "", "", "", "")
    assert mp.default_extractor is None

    # Test for valid values
    mp = SoundgasmProfileIE("", "", "", "", "", "", "Soundgasm")
    assert mp.default_extractor == "Soundgasm"

test_SoundgasmProfileIE()

# Generated at 2022-06-24 13:14:59.875423
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    instance = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    val = re.search(r'http://soundgasm.net/u/([^/]+)/([^/]+)', url).groups()
    assert val[0] is not None
    assert val[1] is not None


# Generated at 2022-06-24 13:15:08.551461
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SOUNDGASM_PROFILE_URL = r'https?://(?:www\.)?soundgasm\.net/u/([^/]+)/?(?:\#.*)?$'
    sg_profile_IE = SoundgasmProfileIE(SOUNDGASM_PROFILE_URL)
    assert sg_profile_IE._VALID_URL == SOUNDGASM_PROFILE_URL, "_VALID_URL of class SoundgasmProfileIE is not " + SOUNDGASM_PROFILE_URL
    assert sg_profile_IE.IE_NAME == 'soundgasm:profile', "IE_NAME of class SoundgasmProfileIE is not 'soundgasm:profile'"

# Generated at 2022-06-24 13:15:10.460697
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class_ = SoundgasmIE
    assert class_ is not None
    obj = class_()
    assert obj is not None



# Generated at 2022-06-24 13:15:11.998338
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    SoundgasmProfileIE(url)

# Generated at 2022-06-24 13:15:18.779172
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    # test the regex
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mobj = re.match(ie._VALID_URL, url)
    assert mobj.group('user') == 'ytdl'
    assert mobj.group('display_id') == 'Piano-sample'
    url = 'http://soundgasm.net/u/ytdl/'
    mobj = re.match(ie._VALID_URL, url)
    assert mobj.group('user') == 'ytdl'
    assert mobj.group('display_id') == ''
    # test the function _real_extract
    # test the audio id

# Generated at 2022-06-24 13:15:21.565600
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    return soundgasm


# Generated at 2022-06-24 13:15:27.129862
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    r = SoundgasmIE(downloader=None)
    r.ie_key = 'Soundgasm'
    url = r._VALID_URL
    video_id = r._match_id(url)
    assert (isinstance(video_id, str))
    assert (video_id == 'ytdl/Piano-sample')
    

# Generated at 2022-06-24 13:15:34.871072
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://www.soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE(url)
    assert ie.WEBSITE_URL == 'http://soundgasm.net/'
    assert ie.IE_NAME == 'soundgasm'
    assert ie.VALID_URL == r'^https?://(?:www\.)?soundgasm\.net/u/[0-9a-zA-Z_-]+/[0-9a-zA-Z_-]+$'
    assert ie.VALID_URL_RE == re.compile(ie.VALID_URL)
    assert ie.FILE_EXTENSIONS == ['m4a']
    assert ie.BRIGHTCOVE_URL_TEMPLATE == None
    assert ie.YOUTUBE_URL_

# Generated at 2022-06-24 13:15:36.448851
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert(SoundgasmIE().IE_NAME == 'soundgasm')


# Generated at 2022-06-24 13:15:37.863308
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._TEST

# Generated at 2022-06-24 13:15:43.621399
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test to check if SoundgasmProfileIE constructor can be called
    # and to check if response from constructor call is valid.
    ie = SoundgasmProfileIE()
    expected_response = "Soundgasm"
    response = ie._download_webpage('http://soundgasm.net/u/ytdl', 'ytdl')
    assert response == expected_response

# Generated at 2022-06-24 13:15:46.166556
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE()._real_extract(url)

# Generated at 2022-06-24 13:15:49.534765
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'https://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE()
    assert ie._match_id(url) == 'ytdl'
    assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:15:57.630398
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # One part of the constructor is to get the audio URL from web page.
    # This test is to verify that the audio URL is parsed correctly.
    audio_url = 'http://audio.soundgasm.net/u/ytdl/Piano-sample.m4a'

# Generated at 2022-06-24 13:16:00.667403
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    kwargs = {"url": "http://soundgasm.net/u/ytdl", "profile_id": "ytdl"}
    ie = SoundgasmProfileIE(**kwargs)
    assert ie is not None

# Generated at 2022-06-24 13:16:03.146743
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = "http://soundgasm.net/u/ytdl"
    assert SoundgasmProfileIE.suitable(url)


# Generated at 2022-06-24 13:16:05.221345
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('')
    assert ie.IE_NAME == 'soundgasm'


# Generated at 2022-06-24 13:16:08.742651
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test object creation
    ie = SoundgasmProfileIE('SoundgasmProfileIE', 
                            'http://soundgasm.net/u/ytdl',
                            {})
    assert ie is not None


# Generated at 2022-06-24 13:16:12.109613
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    temp = SoundgasmIE()._real_extract(url)
    print(temp)


# Generated at 2022-06-24 13:16:14.131473
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:16:15.962153
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_obj = SoundgasmIE('test')
    assert isinstance(test_obj, SoundgasmIE)

# Generated at 2022-06-24 13:16:18.421487
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Constructor test
    """
    # First test
    assert SoundgasmProfileIE()

    # Second test
    assert SoundgasmProfileIE(SoundgasmIE())

# Generated at 2022-06-24 13:16:27.013945
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .common import TestCase
    from .test_soundcloud import TEST_PLAYLIST_URL, extract_info as soundcloud_extract_info

    class TestSoundgasmIE(TestCase):
        def test_extract_soundgasm(self):

            soundgasm_info_dict = SoundgasmIE()._real_extract(
                TEST_PLAYLIST_URL
            )
            self.assertEqual(soundgasm_info_dict, {
                'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
                'ext': 'm4a',
                'title': 'Piano sample',
                'description': 'Royalty Free Sample Music',
                'uploader': 'ytdl',
            })

# Generated at 2022-06-24 13:16:29.404714
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasmType = type(SoundgasmProfileIE)
    soundgasmInst = soundgasmType()
    assert True


# Generated at 2022-06-24 13:16:39.324409
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm = SoundgasmProfileIE()
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'
    profile_webpage = soundgasm._download_webpage(url, profile_id)
    # Serialize html page
    import json
    json_data = json.loads(profile_webpage)
    # Find audio_urls
    audio_urls = re.findall(r'href="([^"]+/u/ytdl/[^"]+)' , profile_webpage)
    # Download webpage
    # webpage = soundgasm._real_download(audio_urls[0])
    # Call class SoundgasmIE to extract audio information
    # result = SoundgasmIE()._real_extract(audio_urls[0])
    #

# Generated at 2022-06-24 13:16:42.336511
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE('http://www.soundgasm.net/u/ytdl/')
    assert(a.IE_NAME == 'soundgasm:profile')



# Generated at 2022-06-24 13:16:43.515779
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    audio.extract()

# Generated at 2022-06-24 13:16:47.479586
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('http://soundgasm.net/u/ytdl', {})._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:16:51.713383
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-24 13:17:01.519847
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')
    assert 'ytdl' in ie.name
    assert 'Piano-sample' in ie.name
    assert 'ytdl' in ie.display_id
    assert 'Piano-sample' in ie.display_id
    assert ie.login_name == 'ytdl'
    assert ie.login_id == ie._VALID_URL % 'ytdl/Piano-sample'
    assert ie.login_pwd == ''
    assert ie.website_url == 'https://soundgasm.net'
    assert ie.authentication_url == 'https://soundgasm.net/login'
    assert ie.web_session == False
    assert ie.website_name == 'Soundgasm'
   

# Generated at 2022-06-24 13:17:09.308532
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_ie = SoundgasmIE()
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert soundgasm_ie.suitable(url) is True
    assert soundgasm_ie.IE_NAME == 'soundgasm'
    assert soundgasm_ie.IE_DESC == 'Soundgasm.net'
    assert soundgasm_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:17:19.270187
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    unit_test = SoundgasmIE()

    # Make sure that self.IE_NAME is assigned correctly when IE instance created
    assert unit_test.IE_NAME == 'soundgasm'

    # Make sure that _VALID_URL is assigned correctly when IE instance created
    assert unit_test._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

    # Make sure that improper url is not accepted
    assert unit_test._valid_url('http://soundgasm.net/u/ytdl/') is False
    # check that a valid url is accepted

# Generated at 2022-06-24 13:17:20.186317
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    assert obj

# Generated at 2022-06-24 13:17:29.134242
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Check whether the SoundgasmProfileIE constructor passes the unit test.
    """
    # Test call with a copyright warning
    ie = SoundgasmProfileIE()
    ie.url = 'https://soundgasm.net/u/ytdl#\n<p>Royalty Free Sample Music</p>'
    assert 'Royalty Free Sample Music' in ie._real_extract(ie.url)['title']
    # Test call with an empty copyright warning
    ie = SoundgasmProfileIE()
    ie.url = 'https://soundgasm.net/u/ytdl#\n<p></p>'
    assert ie._real_extract(ie.url)['title'] == 'ytdl'

# Generated at 2022-06-24 13:17:30.415607
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print("Testing constructor of class SoundgasmProfileIE")
    return


# Generated at 2022-06-24 13:17:31.953854
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	b=SoundgasmProfileIE()

# Generated at 2022-06-24 13:17:41.746664
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.ie_key() == 'Soundgasm:profile'
    assert ie.ie_name() == 'Soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.valid_url('http://soundgasm.net/u/ytdl#')
    assert ie.valid_url('http://soundgasm.net/u/ytdl')
    assert ie.valid_url('http://soundgasm.net/u/ytdl/')
    assert not ie.valid_url('http://soundgasm.net/u/')

# Generated at 2022-06-24 13:17:51.446509
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.SUCCESS == 'OK'
    assert ie.FAILURE == 'FAILURE'
    assert ie.VALID_URL_PATTERN == re.compile(SoundgasmProfileIE._VALID_URL)
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.REAL_DEAL == 'SoundgasmProfileIE'
    assert ie.SUCCEEDED(ie.SUCCESS)
    assert ie.SUCCEEDED('OK') == False
    assert ie.FAILED(ie.FAILURE)
    assert ie.FAILED('FAILURE') == False
    assert ie.VALID_URL('http://soundgasm.net/u/ytdl/Piano-sample') == True
    assert ie.VALID_URL

# Generated at 2022-06-24 13:17:52.815940
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None).to_screen('test')

# Generated at 2022-06-24 13:17:56.025129
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('')
    assert isinstance(ie, SoundgasmProfileIE)  # Pass


# Generated at 2022-06-24 13:18:03.165464
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	import os
	import json
	import sys
	from ConfigParser import ConfigParser
	from url_preview import parse_url
	from pprint import pprint
	#cls = SoundgasmProfileIE
	#url = 'http://soundgasm.net/u/miss_d/'

	url = 'http://soundgasm.net/u/miss_d'
	info = parse_url(url)
	#print(info)
	pprint(info)

if __name__ == '__main__':
	#test_SoundgasmProfileIE()
	test_SoundgasmIE()

# Generated at 2022-06-24 13:18:03.712906
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE() == None


# Generated at 2022-06-24 13:18:10.580962
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    This function tests the constructor of class SoundgasmIE
    """
    # Arrange
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    expected_md5 = '010082a2c802c5275bb00030743e75ad'

    # Act
    ie = SoundgasmIE(url=url)

    # Assert
    assert ie is not None
    assert ie.get_url() == url
    assert ie.get_filename() == 'Piano-sample'
    assert ie.get_md5() == expected_md5

# Generated at 2022-06-24 13:18:18.859540
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	"""Test SoundgasmProfileIE constructor"""
	obj = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
	assert obj.url == 'http://soundgasm.net/u/ytdl'
	assert obj._VALID_URL == 'http://soundgasm.net/u/ytdl'
	assert obj.__name__ == 'SoundgasmProfileIE'
	assert obj._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}

# Generated at 2022-06-24 13:18:26.609376
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert obj.constructor_args[0] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert obj.IE_NAME == 'soundgasm'
    assert obj.VALID_URL == 'http://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert obj.test_url == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert obj.test_md5 == '010082a2c802c5275bb00030743e75ad'