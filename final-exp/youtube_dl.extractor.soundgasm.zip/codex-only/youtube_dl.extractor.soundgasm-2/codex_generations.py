

# Generated at 2022-06-24 13:08:22.109218
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:08:23.803220
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    inst = SoundgasmProfileIE()
    assert inst._match_id('http://soundgasm.net/u/ytdl') == 'ytdl'

# Generated at 2022-06-24 13:08:26.998877
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    inst = SoundgasmProfileIE('http://soundgasm.net/u/ytdl/Piano-sample', 'Soundgasm')
    assert inst.url == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert inst.title == 'Soundgasm'
    assert inst.display_id == 'Piano-sample'


# Generated at 2022-06-24 13:08:30.280683
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  # Test whether the constructor of class SoundgasmProfileIE
  # returns an instance of SoundgasmProfileIE
  assert(isinstance(SoundgasmProfileIE(None), SoundgasmProfileIE))

# Generated at 2022-06-24 13:08:35.547951
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info = SoundgasmProfileIE()._real_extract(
        'http://soundgasm.net/u/ytdl')

    for i in info:
        if(i == '_type'):
            assert info[i] == 'playlist'
        elif(i == 'entries'):
            assert len(info[i]) == 1
            assert 'ytdl' in info[i][0]['url']

# Generated at 2022-06-24 13:08:43.430645
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    '''
    test for constructor of class SoundgasmProfileIE
    '''
    soundgasm_profile_IE = SoundgasmProfileIE('test')
    assert soundgasm_profile_IE.IE_NAME == 'soundgasm:profile'
    assert soundgasm_profile_IE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert soundgasm_profile_IE._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-24 13:08:53.466108
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Soundgasm is a website where people can share recordings and rate them.
    # I (ytdl) am a member with one recording.
    ie = SoundgasmProfileIE()
    # A recording is referred to as an 'audio'.
    # A user's profile shows all of the audio that the user has uploaded.
    profile = ie.extract('http://soundgasm.net/u/ytdl')
    # The profile contains all of the audio uploaded by ytdl.
    assert profile['id'] == 'ytdl'
    assert profile['title'] == 'ytdl'
    # ensure_list returns a list. This is necessary because sometimes the profile contains a single audio.
    assert len(ie.ensure_list(profile['entries'])) == 1
    # The audio is also available as a separate soundgasm entry.
   

# Generated at 2022-06-24 13:08:54.868083
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie is not None


# Generated at 2022-06-24 13:08:56.366280
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('Soundgasm:Profile') == SoundgasmProfileIE('Soundgasm:Profile')

# Generated at 2022-06-24 13:08:57.213995
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    inst = SoundgasmProfileIE()

# Generated at 2022-06-24 13:08:58.914953
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:09:00.764161
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()

    try:
        ie.suite()
    except:
        pass

# Generated at 2022-06-24 13:09:06.913804
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    expected_md5 = '010082a2c802c5275bb00030743e75ad'
    SoundgasmIE().download(url)
    result_md5 = SoundgasmIE()._downloader.result['md5']
    assert expected_md5 == result_md5, 'FC: %s\n' % result_md5

# Generated at 2022-06-24 13:09:07.905392
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

	pass

# Generated at 2022-06-24 13:09:09.246972
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('Soundgasm', 'Soundgasm profile page')

# Generated at 2022-06-24 13:09:11.526052
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    #test constructor function
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-24 13:09:16.147630
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'

    i = SoundgasmIE()

    video = i._real_extract(url)

    print(video)
    
test_SoundgasmIE()

# Generated at 2022-06-24 13:09:22.398129
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    c = SoundgasmProfileIE()
    assert c.IE_NAME == 'soundgasm:profile'
    assert c.VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert c.TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert c.TEST['info_dict'] == {'id': 'ytdl'}
    assert c.TEST['playlist_count'] == 1

# Generated at 2022-06-24 13:09:25.147351
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    test_soundgasmie = SoundgasmIE()
    test_soundgasmie.suitable(url)
    test_soundgasmie.extract(url)

# Generated at 2022-06-24 13:09:29.190794
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')


# Generated at 2022-06-24 13:09:39.403063
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url  = 'http://soundgasm.net/u/ytdl/Piano-sample'
    test_data = SoundgasmIE()._real_extract(test_url)
    assert test_data['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert test_data['url'] == 'https://s3.amazonaws.com/soundgasm-production/sounds/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    assert test_data['description'] == 'Royalty Free Sample Music'
    assert test_data['title'] == 'Piano sample'
    assert test_data['uploader'] == 'ytdl'

# Generated at 2022-06-24 13:09:41.327346
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Check that SoundgasmIE is a subclass of InfoExtractor
    assert issubclass(SoundgasmIE, InfoExtractor)


# Generated at 2022-06-24 13:09:42.286082
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:09:43.570715
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE()
    assert 'SoundgasmProfileIE' in instance

# Generated at 2022-06-24 13:09:51.583597
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    exp_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    soundgasm.url = exp_url
    assert (exp_url or '') == soundgasm.url
    exp_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    actual_url = soundgasm._url_basename
    assert (exp_url or '') == actual_url
    exp_field = "_VALID_URL"
    actual_field = soundgasm._VALID_URL
    assert (exp_field or '') == actual_field
    exp_field = "IE_NAME"
    actual_field = soundgasm.IE_NAME
    assert (exp_field or '') == actual_field

# Generated at 2022-06-24 13:10:01.448268
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-24 13:10:08.059294
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    # Test constructor without web page
    assert('_url' not in ie.__dict__)
    # Test constructor with web page
    ie = SoundgasmIE(webpage='http://soundgasm.net/u/ytdl/Piano-sample')
    assert('_url' in ie.__dict__)
    assert(ie._url == "http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-24 13:10:10.682882
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    q = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    assert q.IE_NAME == 'SoundgasmProfileIE'

# Generated at 2022-06-24 13:10:19.629652
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    dct = dict()
    dct.update(SoundgasmIE._TEST)
    dct['url'] = 'http://soundgasm.net/u/ytdl/Piano-sample'
    dct['md5'] = '010082a2c802c5275bb00030743e75ad'
    dct['info_dict'].update({
	'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
	'ext': 'm4a',
	'title': 'Piano sample',
	'description': 'Royalty Free Sample Music',
	'uploader': 'ytdl'
    })
    return dct

# Generated at 2022-06-24 13:10:23.807552
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE('SoundgasmIE')
    print(instance.__class__.__bases__[0])
    print(instance.IE_NAME)
    print(instance.__class__.__name__)
    print(re.match(instance._VALID_URL, 'http://soundgasm.net/u/ytdl/Piano-sample'))

# Generated at 2022-06-24 13:10:34.084845
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    # Test constructor of SoundgasmIE
    temp = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

    # Test the attributes of SoundgasmIE
    assert 'http://soundgasm.net/u/ytdl/Piano-sample' == temp.url
    assert "/Piano-sample" == temp.display_id
    assert "ytdl" == temp.user
    assert "Piano-sample" == temp.title
    assert "ytdl" == temp.uploader
    assert '010082a2c802c5275bb00030743e75ad' == temp.md5
    assert '88abd86ea000cafe98f96321b23cc1206cbcbcc9' == temp.id
    assert "Royalty Free Sample Music" == temp.description

# Generated at 2022-06-24 13:10:39.492739
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sge = SoundgasmProfileIE()
    assert sge.IE_NAME == 'soundgasm:profile'
    assert sge._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert sge._TEST == {'url': 'http://soundgasm.net/u/ytdl',
                         'info_dict': {'id': 'ytdl'},
                         'playlist_count': 1}


# Generated at 2022-06-24 13:10:45.411965
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE(): 
	ie = SoundgasmIE()
	je = SoundgasmProfileIE()
	str = "http://soundgasm.net/u/ytdl/Piano-sample"
	str2 = "http://soundgasm.net/u/ytdl"

# Generated at 2022-06-24 13:10:47.496404
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    inst = SoundgasmProfileIE()
    assert isinstance(inst, InfoExtractor)



# Generated at 2022-06-24 13:10:50.209474
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    a = SoundgasmIE('http://some.url/some.file')
    assert str(a) == 'Soundgasm http://some.url/some.file', 'test_SoundgasmIE failed'

# Generated at 2022-06-24 13:10:51.131980
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:10:54.210442
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:10:57.429049
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    # Testing to make sure object SoundgasmProfileIE instantiated properly 
    assert instance



# Generated at 2022-06-24 13:11:05.977979
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        # Test SoundgasmIE, to see if SoundgasmIE can be instantiated
        SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
        # Test SoundgasmProfileIE, to see if SoundgasmProfileIE can be instantiated
        SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    except Exception as e:
        # If instantiation fails, the exception will be caught and
        # the test will fail.
        assert False, "Test failed with exception: " + str(e)


# Generated at 2022-06-24 13:11:07.231172
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()._VALID_URL == SoundgasmIE._VALID_URL


# Generated at 2022-06-24 13:11:07.759841
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:11:11.363089
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest
    class TestSoundgasmProfileIE(unittest.TestCase):
        def setUp(self):
            self.SoundgasmProfileIE_unit_test_instance = SoundgasmProfileIE()

        def test_type(self):
            self.assertTrue(self.SoundgasmProfileIE_unit_test_instance)
    unittest.main()

# Generated at 2022-06-24 13:11:13.460242
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    syh = SoundgasmProfileIE()
    assert syh.SUFFIX == 'soundgasm'
    return

# Generated at 2022-06-24 13:11:19.435140
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie.VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie.VIDEO_ID_PATTERN == ie.VALID_URL

# Generated at 2022-06-24 13:11:22.392125
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE("test_SoundgasmProfileIE", "SoundgasmProfileIE", "test_SoundgasmProfileIE", "SoundgasmProfileIE")._real_extract("http://soundgasm.net/u/ytdl")

# Generated at 2022-06-24 13:11:24.947477
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    ie.download('Piano-sample')

# Generated at 2022-06-24 13:11:27.681974
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-24 13:11:36.549259
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    # Arange
    user = "ytdl"
    display_id = "Piano-sample"

    # Act
    sgie = SoundgasmIE()

    # Assert
    assert(sgie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')
    assert(sgie.IE_NAME == "soundgasm")
    assert(sgie._TEST["url"] == "http://soundgasm.net/u/" + user + "/" + display_id)
    assert(sgie._TEST["md5"] == "010082a2c802c5275bb00030743e75ad")

# Generated at 2022-06-24 13:11:38.092410
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:11:47.988733
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_url = 'http://soundgasm.net/u/ytdl'
    expected_list=['http://soundgasm.net/u/ytdl/Piano-sample', 'http://soundgasm.net/u/ytdl/dubstep-sample']

    ie = SoundgasmProfileIE()
    #extract playlist entries
    playlist = ie._real_extract(test_url)
    #get urls of audio files
    result_list = []
    for entry in playlist[u'entries']:
        result_list.append(entry[u'url'])

# Generated at 2022-06-24 13:11:51.757190
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    handler = SoundgasmIE().url_result(url)
    assert handler.__class__.__name__ == 'SoundgasmIE'
    assert handler._VALID_URL == SoundgasmIE._VALID_URL
    assert handler._TEST == SoundgasmIE._TEST

# Generated at 2022-06-24 13:11:53.037154
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl', lambda url: 'webpage')

# Generated at 2022-06-24 13:11:58.912877
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert(ie.IE_NAME == 'soundgasm')
    assert(ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-24 13:12:00.922870
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert isinstance(ie, SoundgasmIE)


# Generated at 2022-06-24 13:12:08.964491
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info = SoundgasmIE()._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert info['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert info['display_id'] == 'Piano-sample'
    assert info['url'] == 'https://d1rwhvwstyk9yq.cloudfront.net/track/url/88abd86ea000cafe98f96321b23cc1206cbcbcc9/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    assert info['vcodec'] == 'none'
    assert info['title'] == 'Piano sample'

# Generated at 2022-06-24 13:12:20.844193
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = {
        'url': 'http://soundgasm.net/u/ytdl/Piano-sample',		# Test 1.a
        'md5': '010082a2c802c5275bb00030743e75ad',
        'info_dict': {
            'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
            'ext': 'm4a',
            'title': 'Piano sample',
            'description': 'Royalty Free Sample Music',
            'uploader': 'ytdl',
        },
    }
    # Successful initialization with URL
    assert SoundgasmIE().suitable(test['url'])
    assert SoundgasmIE()._real_extract(test['url']) == test

# Generated at 2022-06-24 13:12:23.267110
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    return SoundgasmProfileIE().extract(SoundgasmProfileIE()._TEST.get('url'))


# Generated at 2022-06-24 13:12:25.351049
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test that constructor doesn't raise ValueError.
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:12:30.231781
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from soundgasm import soundgasm

    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    result = soundgasm.extract(url)
    assert result['url'] == 'http://soundgasm.net/storage/users/ytdl/88abd86ea000cafe98f96321b23cc1206cbcbcc9/Piano%20sample.m4a'


# Generated at 2022-06-24 13:12:31.081669
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-24 13:12:34.618492
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    i = SoundgasmProfileIE()
    assert i._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:12:37.471459
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    expected = 'Piano sample'
    actual = SoundgasmIE()._get_title(url)

    assert expected == actual

# Generated at 2022-06-24 13:12:43.961723
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    '''
    Unit test for constructor of class SoundgasmProfileIE.
    '''
    # Test empty url
    dummy_url = ''
    instance = SoundgasmProfileIE()
    assert(instance._match_id(dummy_url) is None)
    # Test invalid url
    dummy_url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    instance = SoundgasmProfileIE()
    assert(instance._match_id(dummy_url) is None)
    # Test valid url
    dummy_url = 'http://soundgasm.net/u/ytdl'
    instance = SoundgasmProfileIE()
    assert(instance._match_id(dummy_url) == 'ytdl')

# Generated at 2022-06-24 13:12:52.754422
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Unit test for constructor of class SoundgasmIE."""
#    print ('\nUnit test for constructor of class SoundgasmIE')
    # Init unit test environment
#    print (u'Init unit test environment')
#    x = _TEST['url']
#    y = _TEST['md5']
#    z = _TEST['info_dict']
#    print(u'Constructed object - SoundgasmIE()  for url - ' + x )
    # Construct test object
#    print (u'Construct test object')
#    # Call method to actually test
#    print (u'Call method to actually test')
#    assert_equal(SoundgasmIE(), 1)


# Generated at 2022-06-24 13:12:55.803075
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE("id_1", "url_1", 1)
    assert ie.id == "id_1"
    assert ie.url == "url_1"
    assert ie.num == 1

# Generated at 2022-06-24 13:12:58.230042
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')
    assert isinstance(soundgasm, SoundgasmIE)

# Generated at 2022-06-24 13:13:01.101906
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('SoundgasmProfile', 'http://soundgasm.net/u/ytdl') == SoundgasmProfileIE('SoundgasmProfile', 'http://soundgasm.net/u/ytdl')


# Generated at 2022-06-24 13:13:08.106191
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from soundgasm import SoundgasmProfile
    sg_profile = SoundgasmProfile('ytdl', 'http://soundgasm.net/u/ytdl', 'http://soundgasm.net/u/ytdl', 'Royalty free sample music.', 'Royalty Free Sample Music.')
    assert (sg_profile.uploader == 'ytdl')
    assert (sg_profile.profile_url == 'http://soundgasm.net/u/ytdl')
    assert (sg_profile.title == 'Royalty Free Sample Music.')
    assert (sg_profile.description == 'Royalty free sample music.')


# Generated at 2022-06-24 13:13:12.885967
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_result = SoundgasmProfileIE()._real_extract("http://soundgasm.net/u/ytdl")
    assert test_result['_type'] == 'playlist'
    assert test_result['id'] == 'ytdl'
    assert len(test_result['entries']) == 1


# Generated at 2022-06-24 13:13:15.461105
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.IE_DESC == 'Soundgasm user profile'

# Generated at 2022-06-24 13:13:17.649171
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(None, None)
    assert ie.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-24 13:13:20.728367
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audiotest = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    print('AUDIOTEST.URL = %s' % audiotest.url)
    print('AUDIOTEST.AUDIO_ID = %s' % audiotest.audio_id)

# Generated at 2022-06-24 13:13:25.087044
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert(SoundgasmIE._VALID_URL == 'https?://(?:www\\.)?soundgasm\\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-24 13:13:27.144491
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import test_html
    assert test_html.constructor_test(SoundgasmProfileIE)

# Generated at 2022-06-24 13:13:27.730317
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass

# Generated at 2022-06-24 13:13:30.400945
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")._real_extract("http://soundgasm.net/u/ytdl/Piano-sample");

# Generated at 2022-06-24 13:13:34.532447
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert "soundgasm.net/u/ytdl/" == SoundgasmProfileIE._TEST["url"]
    assert "ytdl" == SoundgasmProfileIE._TEST["info_dict"]["id"]
    assert 1 == SoundgasmProfileIE._TEST["playlist_count"]

# Generated at 2022-06-24 13:13:41.106358
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	import json
	from unittest import TestCase
	from unit.test_soundgasm import SoundgasmProfileIE

	class SoundgasmProfileIETestCase(TestCase):
		@staticmethod
		def test():
			result = SoundgasmProfileIE()._real_extract("http://soundgasm.net/u/ytdl/")
			assert result["id"] == "ytdl"
			assert result["title"] == "ytdl"

	SoundgasmProfileIETestCase.test()
	print(json.dumps(result))

# Generated at 2022-06-24 13:13:41.970281
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
   SoundgasmProfileIE()

# Generated at 2022-06-24 13:13:44.722738
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE(1) == None
    assert SoundgasmIE(1, 2) == None
    assert SoundgasmIE(1, 2, 3) == None

# Generated at 2022-06-24 13:13:45.508528
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:13:54.224889
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.IE_DESC == 'Soundgasm profiles'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-24 13:13:55.245337
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:13:57.055095
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:13:58.943123
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.ie_key() == 'Soundgasm'
    assert ie.ie_name() == 'Soundgasm'
    assert ie._VALID_URL == ie._VALID_URL

# Generated at 2022-06-24 13:13:59.796979
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert isinstance(ie, SoundgasmIE)

# Generated at 2022-06-24 13:14:00.224120
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:14:09.248229
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    _ie_test = SoundgasmIE()
    assert _ie_test.IE_NAME == 'soundgasm'
    assert _ie_test._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert _ie_test._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert _ie_test._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-24 13:14:11.071588
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    testobj = SoundgasmIE()
    assert testobj.__class__.__name__


# Generated at 2022-06-24 13:14:17.747841
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	# Given
	url_exists = 'https://soundgasm.net/u/ytdl'
	url_not_exists = 'https://soundgasm.net/u/not_exists'
	# When
	url_exists = SoundgasmProfileIE.suitable(url_exists)
	url_not_exists = SoundgasmProfileIE.suitable(url_not_exists)
	# Then
	assert url_exists == True
	assert url_not_exists == False

# Generated at 2022-06-24 13:14:22.075131
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sIE = SoundgasmIE(None)
    sIE.IE_NAME = 'SoundgasmIE'
    sIE._VALID_URL = 'soundgasmIE_VALID_URL'
    sIE._TEST = {'url': 'soundgasmIE_TEST'}

# Generated at 2022-06-24 13:14:26.823065
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()

    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'

# Generated at 2022-06-24 13:14:30.009051
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE._TEST['url'] == 'http://soundgasm.net/u/ytdl')
    assert(SoundgasmProfileIE._TEST['playlist_count'] == 1)

# Generated at 2022-06-24 13:14:30.982702
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:14:32.730923
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None)._extract_url('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:14:36.479458
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = SoundgasmIE._VALID_URL
    m = re.match(SoundgasmIE._VALID_URL, url)
    assert m.group('user') == 'ytdl'
    assert m.group('display_id') == 'Piano-sample'

# Generated at 2022-06-24 13:14:38.440108
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE()
    except TypeError:
        assert False, 'SoundgasmIE must have no arguments'


# Generated at 2022-06-24 13:14:39.929055
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test that it is possible to create an instance of SoundgasmProfileIE
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:14:44.128402
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.__class__.__name__ == 'SoundgasmProfileIE'

# Generated at 2022-06-24 13:14:47.076354
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.name == 'Soundgasm'
    assert ie.url == 'http://soundgasm.net/u/ytdl'
    assert ie.id == 'ytdl'

# Generated at 2022-06-24 13:14:48.383097
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:14:50.004438
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:14:51.404620
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasmprofile.SoundgasmProfileIE()


# Generated at 2022-06-24 13:14:53.086125
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl")


# Generated at 2022-06-24 13:14:55.497761
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import SoundgasmProfileIE

# Generated at 2022-06-24 13:15:00.593322
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	test = 'http://soundgasm.net/u/ytdl/Piano-sample'
	result = SoundgasmIE()._real_extract(test)
	assert result['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
	assert result['description'] == 'Royalty Free Sample Music'
	assert result['title'] == 'Piano sample'

test_SoundgasmIE()

# Generated at 2022-06-24 13:15:02.731283
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	soundgasmlib_object = SoundgasmProfileIE()
	print('Object creation of class SoundgasmProfileIE is successful')
	

# Generated at 2022-06-24 13:15:12.458431
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pattern = r'href="([^"]+/u/%s/[^"]+)'

    class TestSoundgasmProfileIE(SoundgasmProfileIE):
        def _real_extract(self, url):
            return {
                '_type': 'playlist',
                'entries': [
                    self.url_result(a_url, 'Soundgasm')
                    for a_url in re.findall(r'href="([^"]+/u/%s/[^"]+)' % profile_id, webpage)],
                'id': profile_id,
            }

    # test_profile_id contains the name of the user, this name must be
    # changed if the name of the user changes in the link.
    test_profile_id = 'ytdl'


# Generated at 2022-06-24 13:15:15.963601
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('Soundgasm:profile')
    assert ie.IE_NAME == 'Soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:15:16.819262
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-24 13:15:24.349357
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()

    data = "http://soundgasm.net/u/ytdl/Piano-sample"
    url = ie.extract(data)

# Generated at 2022-06-24 13:15:33.274698
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    # Ensure the class is constructed properly
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:15:44.818570
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	
	url_1 = 'http://soundgasm.net/u/ytdl/Piano-sample'
	url_2 = 'https://soundgasm.net/u/ytdl/Piano-sample'

	url_3 = 'http://soundgasm.net/u/ytdl/'
	url_4 = 'https://soundgasm.net/u/ytdl/'

	url_5 = 'http://soundgasm.net/u/ytdl'
	url_6 = 'https://soundgasm.net/u/ytdl'

	try:
		SoundgasmProfileIE.suitable(url_1)
		SoundgasmProfileIE.suitable(url_2)
	except:
		print("Error")


# Generated at 2022-06-24 13:15:48.125229
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    g = globals()
    for k, v in list(g.items()):
        if k.startswith('SoundgasmProfileIE'):
            del g[k]

    SoundgasmProfileIE()

# Generated at 2022-06-24 13:15:49.096305
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm = SoundgasmProfileIE()

# Generated at 2022-06-24 13:15:52.644827
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url_str = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE(None)
    assert ie._match_id(url_str) == 'ytdl'

# Generated at 2022-06-24 13:16:02.806777
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    tester = SoundgasmIE()
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mobj = re.match(SoundgasmIE._VALID_URL, url)
    display_id = mobj.group('display_id')
    webpage = tester._download_webpage(url, display_id)
    audio_url = tester._html_search_regex(
            r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', webpage,
            'audio URL', group='url')

# Generated at 2022-06-24 13:16:05.271485
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('','','','','','','','','','','','','','','','','','','','','','','','')

# Generated at 2022-06-24 13:16:14.889990
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE("ytdl");
    assert (ie.extractor_key() == 'SoundgasmProfile');
    assert (ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$');
    assert (ie._TEST['url'] == 'http://soundgasm.net/u/ytdl');
    assert (ie._TEST['info_dict'] == {'id': 'ytdl'});
    assert (ie._TEST['playlist_count'] == 1);
    print("Unit test for SoundgasmProfileIE passed.");


# Generated at 2022-06-24 13:16:18.282510
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')



# Generated at 2022-06-24 13:16:25.499961
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test1 = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert test1.profile_id == 'ytdl'
    assert test1.rtsp_url == 'rtsp://soundgasm.net/u/ytdl'
    test2 = SoundgasmProfileIE('http://soundgasm.net/u/ytdl/')
    assert test2.profile_id == 'ytdl'
    assert test2.rtsp_url == 'rtsp://soundgasm.net/u/ytdl'


# Generated at 2022-06-24 13:16:28.055511
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  ie = SoundgasmProfileIE(SoundgasmProfileIE.IE_NAME, '', SoundgasmProfileIE._VALID_URL)
  assert ie

# Generated at 2022-06-24 13:16:34.535510
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test for creating object for class SoundgasmIE
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasm_ie = SoundgasmIE()
    soundgasm_ie._real_initialize()
    # Test for checking validity of url
    assert(soundgasm_ie._real_extract(url).get('id') == '88abd86ea000cafe98f96321b23cc1206cbcbcc9')

# Generated at 2022-06-24 13:16:42.025371
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:16:43.976409
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    x = SoundgasmIE('url')
    assert x

# Generated at 2022-06-24 13:16:50.903228
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
        """
        Simple unit test function.
        """
        constructor_test_1 = SoundgasmIE()
        assert constructor_test_1._VALID_URL == SoundgasmIE._VALID_URL
        assert constructor_test_1.IE_NAME == SoundgasmIE.IE_NAME
        constructor_test_2 = SoundgasmIE(SoundgasmIE._VALID_URL)
        assert constructor_test_2._VALID_URL == SoundgasmIE._VALID_URL
        assert constructor_test_2.IE_NAME == SoundgasmIE.IE_NAME

# Generated at 2022-06-24 13:16:51.792990
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE._test_cases()

# Generated at 2022-06-24 13:16:52.661325
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:16:56.436717
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE_test = SoundgasmIE()
    print(IE_test)
    assert IE_test._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)"

# Generated at 2022-06-24 13:17:00.582417
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from soundgasm import SoundgasmProfileIE
    instance = SoundgasmProfileIE('SoundgasmProfile', 'soundgasm.net', 'http://soundgasm.net/u/ytdl')
    assert instance.suitable('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:17:04.274050
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.ie_name == 'Soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:17:05.328459
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-24 13:17:10.829024
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest
    soundgasm = SoundgasmProfileIE()
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = soundgasm._match_id(url)
    print("Soundgasm profile URL test: " + profile_id)
    if profile_id == 'ytdl':
        print("Soundgasm profile URL test OK.")
    else:
        print("Soundgasm profile URL test FAIL.")


# Generated at 2022-06-24 13:17:13.762753
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "https://soundgasm.net/u/ytdl/Piano-sample"
    soundgasm = SoundgasmIE._build_youtube_url(url)
    print(soundgasm)
    return soundgasm


# Generated at 2022-06-24 13:17:19.053210
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """ Constructor of class SoundgasmProfileIE is working as expected """
    soundgasm_profile_ie = SoundgasmProfileIE('SoundgasmProfile', 'soundgasm')
    assert 'SoundgasmProfile' == soundgasm_profile_ie.ie_key()
    assert 'soundgasm' == soundgasm_profile_ie.ie_name()

# Generated at 2022-06-24 13:17:29.046061
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

	import SoundgasmIE

	soundgasm = SoundgasmIE()

	assert soundgasm._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
	assert soundgasm._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'
	assert soundgasm._TEST['info_dict']['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
	assert soundgasm._TEST['info_dict']['ext'] == 'm4a'
	assert soundgasm._TEST['info_dict']['title'] == 'Piano sample'
	assert soundgasm._TEST['info_dict']['description'] == 'Royalty Free Sample Music'

# Generated at 2022-06-24 13:17:30.344461
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert hasattr(SoundgasmProfileIE, '_TEST')

# Generated at 2022-06-24 13:17:30.831674
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:17:34.959843
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  profile_ie = SoundgasmProfileIE()
  assert_equals(profile_ie.ie_key(), 'Soundgasm:profile')

  # Test profile_id extraction
  profile_id = profile_ie._match_id('http://soundgasm.net/u/ytdl')
  assert_equals(profile_id, 'ytdl')

# Generated at 2022-06-24 13:17:44.925084
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg=SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample', 'http://soundgasm.net/u/ytdl/Piano-sample')
    assert sg._URL_TEMPLATE == 'http://soundgasm.net/u/{0}/{1}'
    assert sg._TEST_SUCCESSFUL == True

# Generated at 2022-06-24 13:17:47.598857
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	pass
	# assert_raises(SoundgasmIE, 'http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:17:48.691764
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    return SoundgasmIE()

# Generated at 2022-06-24 13:17:50.236628
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    x = SoundgasmIE()
    assert type(x) == SoundgasmIE


# Generated at 2022-06-24 13:17:58.503215
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE().test_extractors({
        'url': 'https://soundgasm.net/u/ytdl/Piano-sample',
        'md5': '010082a2c802c5275bb00030743e75ad',
         'info_dict': {
            'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
            'ext': 'm4a',
            'title': 'Piano sample',
            'description': 'Royalty Free Sample Music',
            'uploader': 'ytdl',
        }
    })

# Generated at 2022-06-24 13:18:05.117561
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    test_url = 'http://soundgasm.net/u/ytdl'
    match = ie._VALID_URL_RE.match(test_url)
    assert ie._real_initialize() is None

# Generated at 2022-06-24 13:18:09.170582
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    '''
    This tests that the class SoundgasmProfileIE is well constructed.
    '''
    url = "http://soundgasm.net/u/ytdl"

    test = SoundgasmProfileIE()
    #We test the regular expression to format the URL
    assert re.match(test._VALID_URL, url)


# Generated at 2022-06-24 13:18:12.797851
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('88abd86ea000cafe98f96321b23cc1206cbcbcc9', 'm4a', 'Piano sample', 'Royalty Free Sample Music', 'ytdl')

# Generated at 2022-06-24 13:18:14.703051
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:18:22.280213
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_urls = [
        'http://soundgasm.net/u/ytdl',
        'http://soundgasm.net/u/ytdl/',
        'http://soundgasm.net/u/ytdl/#whatever'
    ]
    for test_url in test_urls:
        downloader = InfoExtractor(SoundgasmProfileIE.IE_NAME)
        downloader.urls = [test_url]
        downloader.extract(downloader.urls[0])
        assert downloader.title == 'ytdl'