

# Generated at 2022-06-24 13:08:26.069488
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    '''
    Unit test for constructor of class SoundgasmIE
    '''
    obj = SoundgasmIE()
    assert obj._VALID_URL is not None
    assert obj._TEST is not None
    return

# Generated at 2022-06-24 13:08:28.858959
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg_ie = SoundgasmIE()
    if not isinstance(sg_ie, SoundgasmIE):
        raise ValueError('Unit test for constructor of class Soundgasm IE failed')

# Generated at 2022-06-24 13:08:30.281137
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()


# Generated at 2022-06-24 13:08:33.191742
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    instance = SoundgasmIE(url)
    assert isinstance(instance, SoundgasmIE)


# Generated at 2022-06-24 13:08:41.914716
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sampleURL = 'http://soundgasm.net/u/ytdl/Piano-sample'

    ie = SoundgasmIE()

    # Test that the regular expression is found
    m = re.match(ie._VALID_URL, sampleURL)
    assert m is not None, "Not correct regular expression!"

    # Test that the function returns the correct url for the given video
    audio_url = 'http://www.soundgasm.net/u/ytdl/Piano-sample/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'

# Generated at 2022-06-24 13:08:52.433708
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    i = SoundgasmIE()
    assert i._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert i._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert i._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'
    assert i._TEST['info_dict']['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert i._TEST['info_dict']['ext'] == 'm4a'


# Generated at 2022-06-24 13:08:53.277753
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()


# Generated at 2022-06-24 13:08:59.885855
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest
    class TestSoundgasmProfileIE(unittest.TestCase):
        def setUp(self):
            self.ie = SoundgasmProfileIE()

        def tearDown(self):
            self.ie = None

        def test_soundgasm_profile_ie(self):
            data = self.ie._real_extract('http://soundgasm.net/u/ytdl')
            self.assertEqual(data['id'], 'ytdl')

    unittest.main(argv=[''])

# Generated at 2022-06-24 13:09:01.757707
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    _ = SoundgasmProfileIE('Soundgasm', 'http://soundgasm.net/u/ytdl', 'Soundgasm')


# Generated at 2022-06-24 13:09:12.854610
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    formatter = ID3TagFormatter()

    profile = SoundgasmProfileIE()

    # Test by fetch and parse data from test site of Soundgasm
    test_site = profile._download_webpage(
        "https://soundgasm.net/u/ytdl")

    # Search for the specific data segment of audio files in test site
    # and store them to the list entries
    entries = [
        profile.url_result(audio_url, 'Soundgasm')
        for audio_url in re.findall(
            # Audio files in test site are all under 'ytdl' account
            r'href="([^"]+/u/ytdl/[^"]+)', test_site)]

    # Initialize a list for storing audio metadata
    entries_list = []

    # Iterate through the list entries and extract metadata then

# Generated at 2022-06-24 13:09:13.704252
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    (SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample'))


# Generated at 2022-06-24 13:09:16.578401
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(SoundgasmProfileIE.IE_NAME, 'http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:09:18.634168
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    print(ie.extract())

# Generated at 2022-06-24 13:09:21.001665
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    '''
    Tests Constructor of SoundgasmIE class.
    '''
    # Instantiate SoundgasmIE object
    SoundgasmIE(url)


# Generated at 2022-06-24 13:09:23.840397
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    extractor = SoundgasmIE()
    web_page = extractor.download_webpage(url, 'Piano-sample')
    assert(web_page is not None)

# Generated at 2022-06-24 13:09:29.978591
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    for url in ['http://soundgasm.net/u/ytdl/Piano-sample', 'http://www.soundgasm.net/u/ytdl/Piano-sample']:
        SoundgasmIE().suitable(url)
        SoundgasmIE()._real_extract(url)


# Generated at 2022-06-24 13:09:32.934151
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Test SoundgasmProfileIE constructor"""
    class_test = SoundgasmProfileIE()
    assert class_test.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-24 13:09:39.892679
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    

# Generated at 2022-06-24 13:09:48.942108
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    audioUrl = 'http://www.youtube.com'
    profileId = 'ytdl'

    soundgasmProfileIE = SoundgasmProfileIE()
    assert soundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert soundgasmProfileIE._TEST['url'] == r'http://soundgasm.net/u/ytdl'
    assert soundgasmProfileIE._TEST['info_dict']['id'] == profileId
    assert soundgasmProfileIE._TEST['playlist_count'] == 1
    assert soundgasmProfileIE._real_extract(soundgasmProfileIE._TEST['url'])['playlist'][0]['url'] == audio

# Generated at 2022-06-24 13:09:52.382372
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    obj = SoundgasmIE()
    obj.set_url(url)
    obj._real_extract(url)
    assert obj

# Generated at 2022-06-24 13:10:02.030778
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # test an instance of class SoundgasmProfileIE
    profile = SoundgasmProfileIE()
    assert profile.IE_NAME == 'soundgasm:profile'
    assert profile._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert profile._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-24 13:10:03.933427
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:10:06.001177
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie == SoundgasmProfileIE()
    assert ie == ie

# Generated at 2022-06-24 13:10:10.339890
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    test_obj = SoundgasmProfileIE()
    result = test_obj._real_extract(url)
    assert result['id'] == 'ytdl'
    assert len(result['entries']) == 1


# Generated at 2022-06-24 13:10:13.014019
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    def _soundgasm_profile_ie_assertions(soundgasm_profile_ie):
        assert isinstance(soundgasm_profile_ie, SoundgasmProfileIE)
    _soundgasm_profile_ie_assertions(SoundgasmProfileIE())

# Generated at 2022-06-24 13:10:23.179053
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-24 13:10:27.402811
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    result = obj._real_extract("http://soundgasm.net/u/ytdl/Piano-sample")
    assert result["id"] == "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
#test_SoundgasmIE()

# Generated at 2022-06-24 13:10:31.807405
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    '''
    It just tests the constructor of class SoundgasmProfileIE
    '''

    # It just tests the constructor of class SoundgasmProfileIE
    assert SoundgasmProfileIE(SoundgasmIE(None))._VALID_URL == SoundgasmProfileIE._VALID_URL

# Generated at 2022-06-24 13:10:34.085287
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'

if __name__ == '__main__':
    test_SoundgasmIE()

# Generated at 2022-06-24 13:10:43.845365
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # test 1
    url = "http://soundgasm.net/u/ytdl"
    soundgasm_profile = SoundgasmProfileIE()
    mobj = re.match(soundgasm_profile._VALID_URL, url)
    if mobj:
        profile_id = mobj.group('id')
        webpage = soundgasm_profile._download_webpage(url, profile_id)
        entries = [
            soundgasm_profile.url_result(audio_url, 'Soundgasm')
            for audio_url in re.findall(r'href="([^"]+/u/%s/[^"]+)' % profile_id, webpage)]
        playlist_result = soundgasm_profile.playlist_result(entries, profile_id)

# Generated at 2022-06-24 13:10:44.906534
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:10:48.843637
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # The following link is not expected to be changed in the future
    test_link = 'https://soundgasm.net/u/sarahs_voice'
    ie = SoundgasmProfileIE()
    res = ie.suitable(test_link)
    assert res

# Generated at 2022-06-24 13:10:53.160854
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    obj = SoundgasmIE(InfoExtractor)
    valid_url = obj._VALID_URL
    match_url = re.match(valid_url, url)
    assert match_url.groups() == ('ytdl', 'Piano-sample')


# Generated at 2022-06-24 13:10:53.868509
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:10:56.954157
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-24 13:10:57.901720
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:11:02.267532
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Just a test to check if constructor of class SoundgasmProfileIE works properly
    from .common import SoundgasmProfileIE
    url = "http://soundgasm.net/u/ytdl"
    ie = SoundgasmProfileIE(url)


# Generated at 2022-06-24 13:11:02.868228
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-24 13:11:05.760876
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE(url)
    assert ie.get_title() == 'ytdl'

# Generated at 2022-06-24 13:11:07.045167
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net'
    return SoundgasmProfileIE()

# Generated at 2022-06-24 13:11:08.278820
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert(isinstance(SoundgasmIE().return_IE_class(), SoundgasmIE))

# Generated at 2022-06-24 13:11:16.615433
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._match_id('http://soundgasm.net/u/ytdl') == 'ytdl'
    assert SoundgasmProfileIE._match_id('http://soundgasm.net/u/ytdl/#') == 'ytdl'
    assert SoundgasmProfileIE._match_id('http://soundgasm.net/u/ytdl/#slide=13') == 'ytdl'
    assert SoundgasmProfileIE._match_id('http://soundgasm.net/u/ytdl/#slide=13&foreground=%23000000&highlight=%23ff0000') == 'ytdl'

# Generated at 2022-06-24 13:11:17.752704
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE = SoundgasmProfileIE()
    IE._match_id('https://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:11:22.465926
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    s = SoundgasmIE()
    assert s.IE_NAME == 'soundgasm'
    assert s._VALID_URL ==  'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert s._TEST



# Generated at 2022-06-24 13:11:29.351357
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    user_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    user_profileIE = SoundgasmProfileIE(user_url)
    assert user_profileIE.ie_key() == 'SoundgasmProfileIE'
    assert user_profileIE.ie_name == 'soundgasm:profile'
    assert user_profileIE.display_id == 'Piano-sample'
    assert user_profileIE.url == user_url


# Generated at 2022-06-24 13:11:30.578668
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm = SoundgasmProfileIE()
    test = 1


# Generated at 2022-06-24 13:11:38.253681
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_input = "http://soundgasm.net/u/ytdl/Piano-sample"
    soundgasm_ie = SoundgasmIE(test_input)
    assert soundgasm_ie.IE_NAME == "soundgasm"
    assert soundgasm_ie.VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:11:41.824617
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE(None, 'http://soundgasm.net/u/ytdl/Piano-sample/')
    except TypeError as e:
        print(e)

# Generated at 2022-06-24 13:11:48.358894
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
        result = SoundgasmProfileIE()._real_extract("http://soundgasm.net/u/ytdl")
        assert set(result) == {'_type', 'entries', 'id'}
        assert result["id"] == "ytdl"
        assert len(result["entries"]) == 1
        assert re.search(r'href="([^"]+/u/%s/[^"]+)' % result["id"],
                self._download_webpage("http://soundgasm.net/u/ytdl", result["id"]))


# Generated at 2022-06-24 13:11:48.992827
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()


# Generated at 2022-06-24 13:11:49.793675
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert(SoundgasmProfileIE('ytdl')=='ytdl')

# Generated at 2022-06-24 13:11:56.856645
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE()
    video_id = ie._match_id(url)
    assert video_id == 'Piano-sample'
    assert ie._real_extract(url)['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert ie._real_extract(url)['url'] == 'http://media.soundgasm.net/u/ytdl/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    assert ie._real_extract(url)['title'] == 'Piano sample'

# Generated at 2022-06-24 13:11:59.229413
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('test', 'http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:12:01.046379
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()._VALID_URL == SoundgasmIE._VALID_URL


# Generated at 2022-06-24 13:12:04.497737
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    info_dict = {
        'id': 'ytdl',
    }

    soundgasm_profile_ie = SoundgasmProfileIE(url)
    soundgasm_profile_ie.test_url(url, info_dict)

# Generated at 2022-06-24 13:12:05.334018
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:12:07.258412
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    x = SoundgasmIE()
    assert(x)
    try:
        assert(False)
    except AssertionError:
        pass

# Generated at 2022-06-24 13:12:19.079213
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Unit test for constructor of class SoundgasmIE
    ie = SoundgasmIE()
    # testing for _VALID_URL
    match = ie._VALID_URL
    assert re.search(match, 'http://soundgasm.net/u/ytdl/Piano-sample')
    # testing for _download_webpage()
    ie._download_webpage('http://soundgasm.net/u/ytdl/Piano-sample', 'Piano-sample')
    # testing for _real_extract()
    i = ie._real_extract("http://soundgasm.net/u/ytdl/Piano-sample")
    # testing for get info
    assert i.get("id") == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
   

# Generated at 2022-06-24 13:12:22.798198
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	url = 'http://soundgasm.net/u/ytdl/Piano-sample'
	soundgasm = SoundgasmIE().suitable(url)
	soundgasm.download('Piano-sample')


# Generated at 2022-06-24 13:12:24.557256
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Unit test for constructor of class SoundgasmIE"""
    assert SoundgasmIE().IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:12:30.875635
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'
    webpage = '<html></html>'
    entries = list()
    print("\nTesting SoundgasmProfileIE...")
    soundgasmIE = SoundgasmProfileIE()
    assert soundgasmIE._match_id(url) == profile_id
    soundgasmIE._download_webpage(url, profile_id)
    assert soundgasmIE._match_id(url) == profile_id
    soundgasmIE.playlist_result(entries, profile_id)

# Generated at 2022-06-24 13:12:33.779703
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    test_SoundgasmProfileIE = SoundgasmProfileIE()
    test_SoundgasmProfileIE._real_extract(url)

# Generated at 2022-06-24 13:12:35.668884
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    return profile

# Generated at 2022-06-24 13:12:36.207370
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(True)

# Generated at 2022-06-24 13:12:43.521887
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:12:53.624996
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	# Initialize instance of class SoundgasmProfileIE and test url
	ie = SoundgasmProfileIE()
	assert ie._match_id('http://soundgasm.net/u/ytdl') == 'ytdl'

	# Test if _type is 'playlist' and _VALID_URL is correct
	assert ie._type == 'playlist'
	assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
	
	# Test if _TEST is properly defined

# Generated at 2022-06-24 13:12:56.132475
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        SoundgasmProfileIE()
    except Exception:
        print("test_SoundgasmProfileIE:ERROR encountered")
        return False
    return True


# Generated at 2022-06-24 13:12:59.323747
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    assert SoundgasmProfileIE._VALID_URL.search('http://soundgasm.net/u/ytdl').group('id') == 'ytdl'
    assert SoundgasmProfileIE._VALID_URL.search('http://soundgasm.net/u/ytdl/').group('id') == 'ytdl'
    assert SoundgasmProfileIE._VALID_URL.search('http://soundgasm.net/u/ytdl/#').group('id') == 'ytdl'


# Generated at 2022-06-24 13:13:06.573988
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-24 13:13:07.842759
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_ie = SoundgasmProfileIE()
    profile_ie.IE_NAME

# Generated at 2022-06-24 13:13:09.975926
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE()
        print("OK")
    except NameError:
        print("Name Error")


# Generated at 2022-06-24 13:13:11.738477
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    parser = soundgasm.SoundgasmProfileIE()

    assert parser != None

# Generated at 2022-06-24 13:13:18.844203
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert ie._TEST['info_dict']['id'] == 'ytdl'
    assert ie._TEST['playlist_count'] == 1

# Generated at 2022-06-24 13:13:20.606442
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:13:25.047454
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL
    assert SoundgasmProfileIE()._TEST
    assert SoundgasmProfileIE().IE_NAME
    assert SoundgasmProfileIE()._real_extract(SoundgasmProfileIE()._TEST.get('url'))

# Generated at 2022-06-24 13:13:33.275754
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sample_profile_url = "http://soundgasm.net/u/ytdl"
    instance = SoundgasmProfileIE()
    if instance._TEST["url"] == sample_profile_url:
        print("test of SoundgasmProfileIE test_url success")
    else:
        print("test of SoundgasmProfileIE test_url failed")
    if instance._VALID_URL == sample_profile_url:
        print("test of SoundgasmProfileIE VALID_URL success")
    else:
        print("test of SoundgasmProfileIE VALID_URL failed")
    if instance._TEST["info_dict"] == "ytdl":
        print("test of SoundgasmProfileIE info_dict success")
    else:
        print("test of SoundgasmProfileIE info_dict failed")

# Generated at 2022-06-24 13:13:37.843271
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    class TestSoundgasmProfileIE(SoundgasmProfileIE):
        pass

    username="ytdl"
    expected_url=r'https?://(?:www\.)?soundgasm\.net/u/%s/?' % username
    assert TestSoundgasmProfileIE(expected_url)._VALID_URL==expected_url

# Generated at 2022-06-24 13:13:42.583941
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert info.info_dict['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert info.info_dict['uploader'] == 'ytdl'
    assert info.info_dict['description'] == 'Royalty Free Sample Music'
    assert info.info_dict['title'] == 'Piano sample'

# Generated at 2022-06-24 13:13:46.852228
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # create instance of SoundgasmIE
    ie = SoundgasmIE()

    # test method _real_extract
    result = ie._real_extract("http://soundgasm.net/u/ytdl/Piano-sample")
    assert "http://media.soundgasm.net/u/ytdl/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a" == result["url"]
    assert "Piano sample" == result["title"]
    assert "ytdl" == result["uploader"]

# Generated at 2022-06-24 13:13:57.671340
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Make sure the constructor of class SoundgasmIE is correct
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:13:59.323836
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        obj = SoundgasmProfileIE()
    except:
        assert False
    assert True

# Generated at 2022-06-24 13:14:01.668773
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	soundgasm_profile_ie = SoundgasmProfileIE(InfoExtractor())
	assert soundgasm_profile_ie.ie_key() == 'Soundgasm'

# Generated at 2022-06-24 13:14:03.452858
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ydl = SoundgasmIE()
    assert ydl.IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:14:13.813251
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert isinstance(SoundgasmProfileIE, InfoExtractor)
    soundgasm_profile_ie = SoundgasmProfileIE(None)
    assert isinstance(soundgasm_profile_ie, SoundgasmProfileIE)
    assert soundgasm_profile_ie.IE_NAME == 'soundgasm:profile'
    assert soundgasm_profile_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert soundgasm_profile_ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
#

# Generated at 2022-06-24 13:14:15.795528
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    soundgasm_profile = SoundgasmProfileIE(url)
    expected_value = 'ytdl'
    assert (soundgasm_profile.playlist_id == expected_value), 'Test failed!'

# Generated at 2022-06-24 13:14:18.712942
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE = SoundgasmProfileIE()
    assert type(IE) == SoundgasmProfileIE
    assert (IE.IE_NAME == 'SoundgasmProfileIE')

# Generated at 2022-06-24 13:14:19.937377
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ext = SoundgasmIE()
    assert ext.IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:14:21.972577
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    s = SoundgasmIE()
    #Test constructor of class SoundgasmIE
    assert s != None

# Generated at 2022-06-24 13:14:28.238282
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    _VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    test_id = 'ytdl'
    test_url = 'http://soundgasm.net/u/' + test_id
    assert re.compile(_VALID_URL).match(test_url).group('id') == test_id

# Generated at 2022-06-24 13:14:37.197221
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Unit test for constructor of class SoundgasmProfileIE
    """
    # Test constructor with some URL
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl/')
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl/#')
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl/#asdfasdf')
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl/asdf#')
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl/asdf#asdf')

# Generated at 2022-06-24 13:14:46.612672
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'
    assert ie._TEST['info_dict']['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-24 13:14:52.562158
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl/')
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl/#')
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl/#/')

# Generated at 2022-06-24 13:14:55.642333
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE('http://soundgasm.net/u/ytdl', 'video')
    assert a.name == 'Soundgasm'
    assert a.url == 'http://soundgasm.net/u/ytdl'
    assert a._type == 'video'

# Generated at 2022-06-24 13:14:58.141928
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_ie = SoundgasmProfileIE()
    assert soundgasm_ie.IE_NAME == 'soundgasm:profile'
    assert soundgasm_ie.IE_DESC == 'Soundgasm user profile'

# Generated at 2022-06-24 13:15:08.192801
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert(re.match(SoundgasmIE._VALID_URL, "http://soundgasm.net/u/ytdl/Piano-sample") is not None)
    assert(re.match(SoundgasmIE._VALID_URL, "http://soundgasm.net/u/ytdl/Piano-sample#") is not None)
    assert(re.match(SoundgasmIE._VALID_URL, "http://soundgasm.net/u/ytdl/Piano-sample#whatever") is not None)
    assert(re.match(SoundgasmIE._VALID_URL, "https://soundgasm.net/u/ytdl/Piano-sample") is not None)

# Generated at 2022-06-24 13:15:16.300372
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    '''
    SoundgasmProfileIE()._real_extract("http://soundgasm.net/u/ytdl")
    '''
    class UnitTestSoundgasmProfileIE(InfoExtractor):
        def __init__(self):
            self._downloader = None
            self._download_webpage = None
            self._match_id = None
            self.url_result = None
            self.playlist_result = None
            self.url = "http://soundgasm.net/u/ytdl"
        def _real_extract(self, url):
            return SoundgasmProfileIE()._real_extract(url)

    utsgpie = UnitTestSoundgasmProfileIE()
    utsgpie._downloader = None

# Generated at 2022-06-24 13:15:16.955332
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:15:21.513324
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	SoundgasmIE(SoundgasmIE.IE_NAME_EXTRA_INFO, SoundgasmIE.IE_NAME, SoundgasmIE.VALID_URL_PATTERN, SoundgasmIE.TITLE, SoundgasmIE.URL_PROTOCOLS, SoundgasmIE.TEST)

# Generated at 2022-06-24 13:15:31.744537
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-24 13:15:34.347720
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample') is not None

# Generated at 2022-06-24 13:15:39.824794
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE._TEST['description'] == "<h2>Description</h2>\n<p>Sample music created with <a href=\"http://www.synthtopia.com/content/2011/01/05/free-piano-sample-collection-1/\" target=\"_blank\">Free Piano Sample Collection 1</a></p>\n</div>"

# Generated at 2022-06-24 13:15:42.313321
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    assert ie.profile_id == "ytdl"

# Generated at 2022-06-24 13:15:52.984259
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    user = 'ytdl'
    audio_id = 'Piano-sample'
    audio_url = "http://soundgasm.net/u/ytdl/Piano-sample"

    # Constructor of class SoundgasmIE
    sie = SoundgasmIE.suitable(audio_url)
    assert sie is not None

    # Attribute of class InfoExtractor
    assert sie.ie_key() == 'Soundgasm'
    assert sie.ie_name() == 'Soundgasm'
    assert sie.ie_version() == '2015.10.12'
    assert sie.name() == 'Soundgasm'

    # Audio info
    audio_url = "http://soundgasm.net/u/ytdl/Piano-sample"

# Generated at 2022-06-24 13:15:56.502111
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert re.match(SoundgasmProfileIE._VALID_URL, 'http://soundgasm.net/u/ytdl')
    assert re.match(SoundgasmProfileIE._VALID_URL, 'http://soundgasm.net/u/ytdl/')

# Generated at 2022-06-24 13:15:57.733445
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()

# Generated at 2022-06-24 13:16:08.601065
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie_soundgasmprofile = SoundgasmProfileIE("test_soundgasmprofile")
    if ie_soundgasmprofile.IE_NAME != 'soundgasm:profile':
        raise NameError("ie_soundgasmprofile.IE_NAME is " + ie_soundgasmprofile.IE_NAME + ", not the expected \'soundgasm:profile\'")
    import urlparse
    url_parsed = urlparse.urlparse("http://soundgasm.net/u/ytdl")

# Generated at 2022-06-24 13:16:11.297678
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	print('In test_SoundgasmIE()')
	testObj = SoundgasmIE(None)
	assert testObj is not None


# Generated at 2022-06-24 13:16:17.205975
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-24 13:16:18.182594
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	SoundgasmProfileIE()

# Generated at 2022-06-24 13:16:26.857055
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    sg._VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    sg_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mobj = re.match(sg._VALID_URL, sg_url)
    assert mobj is not None
    sg.IE_NAME = 'Soundgasm'

# Generated at 2022-06-24 13:16:36.528582
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')
    assert ie.IE_NAME == 'Soundgasm.net'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-24 13:16:42.053503
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profileInstance = SoundgasmProfileIE('soundgasm:profile')
    assert profileInstance.IE_NAME == 'soundgasm:profile'
    assert profileInstance.VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    profileInstance._real_extract('http://soundgasm.net/u/ytdl')



# Generated at 2022-06-24 13:16:44.020704
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-24 13:16:46.871446
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    SoundgasmIE(url=url)
    print("Correct initialization with URL")


# Generated at 2022-06-24 13:16:47.847048
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()


# Generated at 2022-06-24 13:16:56.302760
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
   assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
   assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
   assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-24 13:16:58.019598
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.ie_key() == 'SoundgasmProfile'
    assert ie.__class__.__name__ == 'SoundgasmProfileIE'

# Generated at 2022-06-24 13:17:03.965765
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ##
    ## Test the constructor of class SoundgasmProfileIE
    ## Assumption - the constructor of class SoundgasmIE is tested
    ##

    class TestSoundgasmProfileIE(SoundgasmProfileIE):
        def _real_extract(self, url):
            return url

    url = 'http://www.soundgasm.net/u/ytdl/'
    SoundgasmProfileIE(TestSoundgasmProfileIE, TestSoundgasmProfileIE.IE_NAME, {})._real_extract(url)

    # class SoundgasmProfileIE(InfoExtractor):
    #     IE_NAME = 'soundgasm:profile'
    #     _VALID_URL = r''
    #     _TEST = {
    #         'url': '',
    #         'info_dict': {
    #             '

# Generated at 2022-06-24 13:17:05.713013
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Unit test for constructor of class SoundgasmIE"""
    ie = SoundgasmIE()
    assert ie is not None

# Generated at 2022-06-24 13:17:12.918550
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test 1: test __init__ of SoundgasmProfileIE
    soundgasm_profile_ie = SoundgasmProfileIE()
    assert soundgasm_profile_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert soundgasm_profile_ie._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}
# End of Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-24 13:17:19.923371
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert SoundgasmProfileIE._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }



# Generated at 2022-06-24 13:17:29.897929
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE(): 
    url = "http://soundgasm.net/u/ytdl"
    ie = SoundgasmProfileIE()
    actual_result = ie._real_extract(url)

# Generated at 2022-06-24 13:17:31.074113
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert type(SoundgasmIE('test')) == SoundgasmIE


# Generated at 2022-06-24 13:17:35.559247
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    infoExtractor = SoundgasmIE()
    assert infoExtractor.IE_NAME == 'Soundgasm'
    assert infoExtractor._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:17:45.499872
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    if __name__ == "__main__":
        url = 'http://soundgasm.net/u/ytdl'
        profile_id = 'ytdl'

# Generated at 2022-06-24 13:17:49.372708
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	print("TESTING SOUNDGASMIE")
	url = "http://soundgasm.net/u/ytdl/Piano-sample"
	ie1 = SoundgasmIE()
	ie1.extract(url)

# Generated at 2022-06-24 13:17:54.913693
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	def test_valid_url():
		valid_url_list = [
			'http://soundgasm.net/u/ytdl',
			'http://soundgasm.net/u/ytdl/',
			'http://soundgasm.net/u/ytdl/#naboo',
			'http://soundgasm.net/u/ytdl/#lorem-ipsum',
		]
		for url in valid_url_list:
			if not SoundgasmProfileIE._VALID_URL.match(url):
				return 'Failed to match %r' % (url)
		return 'Passed!'
	assert test_valid_url() == 'Passed!', test_valid_url()

test_SoundgasmProfileIE()

# Generated at 2022-06-24 13:17:56.269674
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = "http://soundgasm.net/u/ytdl"
    soundgasm = SoundgasmProfileIE()
    assert soundgasm._match_id(url) == "ytdl"

# Generated at 2022-06-24 13:18:00.714602
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL == SoundgasmProfileIE._VALID_URL
    assert SoundgasmProfileIE().IE_NAME == SoundgasmProfileIE._IE_NAME
    assert SoundgasmProfileIE()._TEST == SoundgasmProfileIE._TEST
    assert SoundgasmProfileIE()._real_extract(SoundgasmProfileIE()._TEST['url']).get('id') == SoundgasmProfileIE._TEST['info_dict']['id']
    return

# Generated at 2022-06-24 13:18:01.333590
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:18:02.434067
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    new = SoundgasmProfileIE()
    return new

# Generated at 2022-06-24 13:18:04.239557
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = SoundgasmProfileIE._VALID_URL
    SoundgasmProfileIE._real_extract(SoundgasmProfileIE(), url)

# Generated at 2022-06-24 13:18:10.009515
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class MockSoundgasmIE:
        def __init__(self, user, display_id):
            self.user = user
            self.display_id = display_id
    class MockSoundgasm(SoundgasmIE):
        def __init__(self, user, display_id):
            if user == 'ytdl' and display_id == 'Piano-sample':
                self.__class__ = MockSoundgasmIE
                self.__init__(user, display_id)
    mock_sg = MockSoundgasm('ytdl', 'Piano-sample')
    assert mock_sg.user == 'ytdl'
    assert mock_sg.display_id == 'Piano-sample'


# Generated at 2022-06-24 13:18:12.138565
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-24 13:18:15.780604
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == "soundgasm:profile"
    assert ie._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$"
    assert ie._TEST == {
        "url": "http://soundgasm.net/u/ytdl",
        "info_dict": {
            "id": "ytdl",
        },
        "playlist_count": 1,
    }


# Generated at 2022-06-24 13:18:18.256942
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Test SoundgasmProfileIE"""
    ie_instance = SoundgasmProfileIE()
    ie_instance._downloader = None

# Generated at 2022-06-24 13:18:24.448690
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # test instantiating the class with a valid url, and an invalid one
    test_valid_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    test_invalid_url = 'http://soundgasm.net/u/ytdl/invalid'
    extractor = SoundgasmIE(test_valid_url)
    assert extractor.valid_url == test_valid_url
    extractor = SoundgasmIE(test_invalid_url)
    assert not extractor.valid_url
