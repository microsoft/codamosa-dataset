

# Generated at 2022-06-24 13:08:23.981543
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:08:26.536402
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert len(ie._WORKING) > 0
    assert ie._working == ie._WORKING[0]



# Generated at 2022-06-24 13:08:32.469087
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    assert(sg.IE_NAME == 'soundgasm')
    assert(sg._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')


# Generated at 2022-06-24 13:08:34.684838
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()
    assert obj.IE_NAME == 'soundgasm:profile'
    assert obj.VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:08:38.412664
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:08:41.842245
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info=SoundgasmIE()._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert(info['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9')
    assert(info['ext'] == 'm4a')
    assert(info['title'] == 'Piano sample')
    assert(info['uploader'] == 'ytdl')
    assert(info['description'] == 'Royalty Free Sample Music')

# Generated at 2022-06-24 13:08:52.433934
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample');
    assert ie.IE_NAME == 'soundgasm';
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:08:56.904623
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_ie = SoundgasmProfileIE("../../SoundgasmIE.py")
    assert profile_ie.IE_NAME == "soundgasm:profile"
    assert profile_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:09:06.780455
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # print "start unit testing..."
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    sg = SoundgasmIE()
    assert sg._TEST['url'] == url
    info = sg.extract(url)
    assert info['url'] == "https://soundgasm.net/media/play/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a"
    assert info['title'] == "Piano sample"
    assert info['id'] == "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
    assert info['display_id'] == "Piano-sample"
    # print "unit testing done!"

# Generated at 2022-06-24 13:09:11.131163
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:09:12.853691
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().ie_key() == 'soundgasm'

# Generated at 2022-06-24 13:09:22.469163
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert(ie.extract_info({"url": "https://soundgasm.net/u/ytdl"})['info']['id'] == 'ytdl')
    assert(ie.extract_info({"url": "http://soundgasm.net/u/ytdl"})['info']['id'] == 'ytdl')
    assert(ie.extract_info({"url": "http://soundgasm.net/u/ytdl/"})['info']['id'] == 'ytdl')
    assert(ie.extract_info({"url": "http://soundgasm.net/u/ytdl/#"})['info']['id'] == 'ytdl')

# Generated at 2022-06-24 13:09:23.258198
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:09:25.366878
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    result = SoundgasmProfileIE(url)

    assert result.url == url
    assert result.profile_id == 'ytdl'

# Generated at 2022-06-24 13:09:29.451390
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Create an instance of class SoundgasmProfileIE
    ie = SoundgasmProfileIE()
    # Checks if the given url is a valid url for SoundgasmProfileIE
    assert ie._match_id(ie._VALID_URL) != None

# Generated at 2022-06-24 13:09:32.412829
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

if __name__ == '__main__':
    test_SoundgasmIE()

# Generated at 2022-06-24 13:09:41.640695
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sgasm_ie = SoundgasmIE()
    assert 'Soundgasm' == sgasm_ie.IE_NAME
    assert 'http://soundgasm.net/u/ytdl/Piano-sample' == sgasm_ie._TEST['url']
    assert '010082a2c802c5275bb00030743e75ad' == sgasm_ie._TEST['md5']
    assert '88abd86ea000cafe98f96321b23cc1206cbcbcc9' == sgasm_ie._TEST['info_dict']['id']
    assert 'm4a' == sgasm_ie._TEST['info_dict']['ext']
    assert 'Piano sample' == sgasm_ie._TEST['info_dict']['title']

# Generated at 2022-06-24 13:09:43.229628
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    infoExtractor = SoundgasmProfileIE()
    assert infoExtractor.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-24 13:09:45.898171
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert(SoundgasmProfileIE._VALID_URL == 'https?://(?:www.)?soundgasm.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')


# Generated at 2022-06-24 13:09:46.668491
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass


# Generated at 2022-06-24 13:09:50.387900
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_input = 'http://soundgasm.net/u/ytdl'
    test_want = 'ytdl'
    test_get = SoundgasmProfileIE._match_id(test_input)
    assert (test_get == test_want)



# Generated at 2022-06-24 13:09:55.271928
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    filename = os.path.basename(__file__)
    assert filename.startswith('test_SoundgasmProfileIE')
    assert filename.endswith('.py')
    instance = SoundgasmProfileIE()
    assert isinstance(instance, InfoExtractor)
    assert isinstance(instance, SoundgasmProfileIE)


# Generated at 2022-06-24 13:10:00.789069
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    s = SoundgasmProfileIE()
    print (s.__init__.__doc__)

# Generated at 2022-06-24 13:10:03.034614
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    print(repr(ie))

# Generated at 2022-06-24 13:10:06.743804
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    t = ie._TEST
    assert t['url'] == ie._VALID_URL
    assert ie._real_extract(t['url']) == t['info_dict']


# Generated at 2022-06-24 13:10:07.759047
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass


# Generated at 2022-06-24 13:10:08.826530
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    return SoundgasmProfileIE

# Generated at 2022-06-24 13:10:09.948068
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('Soundgasm:profile')


# Generated at 2022-06-24 13:10:13.201421
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:10:15.780218
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    t = SoundgasmProfileIE()
    i = t._match_id('http://soundgasm.net/u/ytdl')
    assert i == 'ytdl'

# Generated at 2022-06-24 13:10:20.250389
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert soundgasm_profile_ie._match_id('http://soundgasm.net/u/ytdl') == 'ytdl'

# Generated at 2022-06-24 13:10:21.105677
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()._VALID_URL == SoundgasmIE._VALID_URL

# Generated at 2022-06-24 13:10:22.198391
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.name() == 'soundgasm'

# Generated at 2022-06-24 13:10:25.487859
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    my_url='http://soundgasm.net/u/ytdl/Piano-sample'
    #url_test_soundgasm = SoundgasmIE(my_url)
    #assert(url_test_soundgasm.url == my_url)

# Generated at 2022-06-24 13:10:26.482475
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:10:28.102050
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    result = SoundgasmProfileIE(None)
    assert result

# Generated at 2022-06-24 13:10:29.746853
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print(SoundgasmProfileIE)
    assert True


# Generated at 2022-06-24 13:10:30.365473
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:10:36.925292
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-24 13:10:38.083801
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert(isinstance(SoundgasmIE, object))


# Generated at 2022-06-24 13:10:46.380771
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Simple unit test for SoundgasmIE,
    checking if it could construct url and uid
    """
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    uid = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    SoundgasmIE().match_url(url)
    obj = SoundgasmIE()
    obj.construct_url(url,uid)
    obj.extract_from_url(obj.construct_url(url,uid))

# Generated at 2022-06-24 13:10:48.494785
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert isinstance(SoundgasmProfileIE()._instantiate_extractor(
        SoundgasmProfileIE._VALID_URL), SoundgasmProfileIE)

# Generated at 2022-06-24 13:10:49.773685
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:10:51.381423
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Unit test for constructor of class SoundgasmProfileIE."""
    assert SoundgasmProfileIE() is not None

# Generated at 2022-06-24 13:10:53.238830
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    assert soundgasm.IE_NAME == "soundgasm"


# Generated at 2022-06-24 13:10:58.381542
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE(None, None)
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-24 13:11:02.961243
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    m = SoundgasmIE()
    assert m._VALID_URL == m.IE_NAME + ":%s" % SoundgasmIE._VALID_URL
    assert m.IE_NAME == 'soundgasm'
    assert m.IE_DESC == 'Soundgasm'



# Generated at 2022-06-24 13:11:04.165137
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('abc', 'abc')

# Generated at 2022-06-24 13:11:05.305898
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE() != None)

# Generated at 2022-06-24 13:11:06.615636
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-24 13:11:09.807058
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  ie_profile = SoundgasmProfileIE('https://soundgasm.net/u/ytdl#')
  assert ie_profile.IE_NAME == 'soundgasm:profile'
  assert ie_profile._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:11:14.092906
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie_obj = SoundgasmIE()
    assert ie_obj.ie_key() == 'Soundgasm'
    # assert here for ie_key() to make sure SoundgasmIE inherited from InfoExtractor
    assert issubclass(SoundgasmIE, InfoExtractor)


# Generated at 2022-06-24 13:11:15.599198
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(downloader=None)


# Generated at 2022-06-24 13:11:19.522593
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .test_compat import ConfigTestCase, unittest
    from .test_compat import compat_urllib_request, compat_urllib_parse
    for key in SoundgasmProfileIE._TEST.keys():
        pass


# Generated at 2022-06-24 13:11:20.645431
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    constructor_test(SoundgasmIE, 'http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-24 13:11:21.388776
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE()
    assert 'IE_NAME' in dir(instance)

# Generated at 2022-06-24 13:11:27.768032
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    global IE_NAME,_VALID_URL,_TEST
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    # check IE_NAME
    assert IE_NAME == 'soundgasm'
    # check _VALID_URL
    m = re.match(_VALID_URL,url)
    assert m
    # check _TEST
    soundgasm = SoundgasmIE(url)
    assert soundgasm._TEST['url'] == _TEST['url']
    assert soundgasm._TEST['md5'] == _TEST['md5']
    assert soundgasm._TEST['info_dict']['id'] == _TEST['info_dict']['id']
    assert soundgasm._TEST['info_dict']['ext'] == _TEST

# Generated at 2022-06-24 13:11:34.717254
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    constructor=SoundgasmIE
    # Suppose I want to test a youtube video
    example_url="https://soundgasm.net/u/ytdl/Piano-sample"
    # I will get a new object called example_video
    example_video=constructor(example_url)
    # Now I can unit test this example_video
    assert "Piano sample" in example_video.get_title()
    # (Optional) I can get more attributes, e.g., id, description, etc.
    assert example_video.get_webpage() # This should be available

# Generated at 2022-06-24 13:11:36.347043
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-24 13:11:37.520020
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE("http://www.google.com")
    assert obj != None

# Generated at 2022-06-24 13:11:39.351482
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    assert isinstance(soundgasm, SoundgasmIE)

# Generated at 2022-06-24 13:11:44.519571
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Smoke test
    SoundgasmProfileIE().suitable('http://soundgasm.net/u/ytdl')
    SoundgasmProfileIE().suitable('http://soundgasm.net/u/ytdl/#')
    assert not SoundgasmProfileIE().suitable('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:11:52.655535
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url_1 = 'http://soundgasm.net/u/ytdl/Piano-sample'
    url_2 = 'http://soundgasm.net/u/ytdl/Piano-sample-2'
    ie1 = SoundgasmIE()
    ie2 = SoundgasmIE()
    ie3 = SoundgasmIE()
    # In one class, only one of objects is created, so the number of created objects is 3.
    assert SoundgasmIE.count == 3

    ie1_result = ie1._real_extract(url_1)
    ie2_result = ie2._real_extract(url_2)
    ie3_result = ie3._real_extract(url_1)

    # When both URLs are same, they should be same object.
    assert ie1_result == ie3

# Generated at 2022-06-24 13:11:54.842195
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.ie_key() == 'SoundgasmProfile'
    assert ie.suitable(ie.url)



# Generated at 2022-06-24 13:12:03.136698
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    constructor = SoundgasmIE()
    # Testing the transformation of the URL.
    transformed_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert transformed_url == constructor._real_extract()
    # Testing extracted attributes.
    assert '88abd86ea000cafe98f96321b23cc1206cbcbcc9' == constructor.id
    assert 'm4a' == constructor.ext
    assert 'Piano sample' == constructor.title
    assert 'Royalty Free Sample Music' == constructor.description
    assert 'ytdl' == constructor.uploader


# Generated at 2022-06-24 13:12:07.839008
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:12:08.803205
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('SoundgasmProfileIE')

# Generated at 2022-06-24 13:12:20.801467
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    x = SoundgasmIE()
    assert x.IE_NAME == 'soundgasm'
    assert x.IE_DESC == 'Soundgasm'
    assert re.match(r'https?://(?:www\.)?soundgasm\.net/u/[0-9a-zA-Z_-]+/[0-9a-zA-Z_-]+', x._VALID_URL)
    assert x._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert x._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'
    assert x._TEST['info_dict']['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'


# Generated at 2022-06-24 13:12:25.785420
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.ie_key() == 'SoundgasmProfileIE'
    assert SoundgasmProfileIE.ie_key() == SoundgasmProfileIE._ie_key()
    assert SoundgasmProfileIE.ie_key() in SoundgasmProfileIE.suitable

if __name__ == '__main__':
    test_SoundgasmProfileIE()

# Generated at 2022-06-24 13:12:27.097387
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('SoundgasmProfileIE', 'SoundgasmProfileIE')



# Generated at 2022-06-24 13:12:36.720742
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print("test_SoundgasmProfileIE:")
    _test = {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    _test_ie = SoundgasmProfileIE(_test)
    assert _test_ie.IE_NAME == 'soundgasm:profile'
    assert _test_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert _test_ie._TEST == _test
    _real_extract_test = _test_ie._real_extract(_test_ie._TEST['url'])

# Generated at 2022-06-24 13:12:41.414259
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Construct an instance of SoundgasmProfileIE
    ie = SoundgasmProfileIE()
    # Test the value of member variable IE_NAME
    assert ie.IE_NAME == 'soundgasm:profile'
    # Test the value of member variable _VALID_URL
    valid_url = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._VALID_URL == valid_url
    # Test the value of member variable _TEST
    test = {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    assert ie._TEST == test

# Generated at 2022-06-24 13:12:51.257165
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    example_inputs = [{
        "url": "http://soundgasm.net/u/ytdl/Piano-sample",
        "display_id": "Piano-sample",
        "display_title": "Piano sample",
        "uploader": "ytdl"
    }]

# Generated at 2022-06-24 13:12:58.826784
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Use this function to test the SoundgasmIE class.
    """
    info = SoundgasmIE()._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert info['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert info['ext'] == 'm4a'
    assert info['title'] == 'Piano sample'
    assert info['uploader'] == 'ytdl'
    assert info['description'] == 'Royalty Free Sample Music'


# Generated at 2022-06-24 13:13:00.932205
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    # Test case for the profile URL 
    url = 'http://soundgasm.net/u/ytdl'
    # get the video objects
    video = ie.extract(url)
    # check if the video object is valid
    print(video)
    assert video is not None


# Generated at 2022-06-24 13:13:05.716689
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_var = SoundgasmIE()
    assert(test_var.IE_NAME == "soundgasm")
    assert(test_var._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')
    

# Generated at 2022-06-24 13:13:11.144704
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_ie = SoundgasmIE()
    assert soundgasm_ie.IE_NAME == 'soundgasm'
    assert soundgasm_ie._VALID_URL ==  r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:13:20.317373
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	import re
	from .common import InfoExtractor
	from .soundgasm import SoundgasmProfileIE
	
	downloader = InfoExtractor({})
	
	audio_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
	display_id = 'Piano-sample'
	profile_id = 'ytdl'
	profile_url = 'http://soundgasm.net/u/ytdl'
	
	sgProfile = SoundgasmProfileIE(downloader)
	
	assert(sgProfile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
	
	res = re.search(sgProfile._VALID_URL, profile_url)


# Generated at 2022-06-24 13:13:28.251066
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('Soundgasm', 'http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie.IE_NAME == 'Soundgasm'
    assert ie.display_id == 'Piano-sample'


# Generated at 2022-06-24 13:13:31.096001
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    # Make sure that obj._VALID_URL match for this url
    assert obj._VALID_URL.match("http://soundgasm.net/u/ytdl/Piano-sample")


# Generated at 2022-06-24 13:13:36.509168
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sgIE = SoundgasmIE()
    assert(sgIE.IE_NAME == 'soundgasm')
    assert(sgIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')


# Generated at 2022-06-24 13:13:42.833645
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test the class constructor.
    # Parameters:
    # - url: The URL for the video
    # - ie: The expected YoutubeIE object
    # - video_id: The expected video ID
    def test_constructor(url, ie, video_id):
        """Test that the youtube class constructor returns the expected values."""
        info = YoutubeIE(url)
        assert info.ie == ie
        assert info.video_id == video_id

    # Test cases with valid URLs
    test_constructor('http://soundgasm.net/u/ytdl/Piano-sample', 'Soundgasm', 'Piano-sample')

# Generated at 2022-06-24 13:13:45.811461
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    i = SoundgasmIE()
    assert i.IE_NAME == "soundgasm"
    assert i._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:13:49.573678
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    inst = SoundgasmProfileIE(url)
    assert inst.url == url
    assert inst.id == 'ytdl'

# Generated at 2022-06-24 13:13:52.247739
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test with valid URL
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:13:53.761006
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # This is a configuration test
    return SoundgasmProfileIE()

# Generated at 2022-06-24 13:14:03.049343
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    # Note: I am not sure which url arg should be passed to class constructor
    # https://github.com/rg3/youtube-dl/tree/master/test/testcases/site/soundgasm.py#L69
    # TODO: Fix the constructor call
    ie = SoundgasmProfileIE(SoundgasmProfileIE._VALID_URL)

    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:14:12.915170
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE()
    # This is a regular expression that is used to check if a URL is of a
    # certain format
    url_regex = instance._VALID_URL
    # This will check if the string has the structure:
    # http://soundgasm.net/u/ytdl/Piano-sample
    assert re.match(url_regex, 'http://soundgasm.net/u/ytdl/Piano-sample')
    assert re.match(url_regex, 'http://www.soundgasm.net/u/ytdl/Piano-sample')
    assert re.match(url_regex, 'MATCH://www.soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:14:17.529757
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    test = SoundgasmIE()._real_extract(url)
    assert test['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert test['uploader'] == 'ytdl'

# Generated at 2022-06-24 13:14:19.260537
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print(SoundgasmIE()._VALID_URL)


# Generated at 2022-06-24 13:14:30.059736
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE ("http://soundgasm.net/u/ytdl/Piano-sample")
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:14:34.537830
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	obj = SoundgasmIE()
	assert obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-24 13:14:40.609206
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('Soundgasm')
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl',
            'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}

# Generated at 2022-06-24 13:14:45.426324
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # note: class SoundgasmProfileIE derives from class InfoExtractor
    # and so instantiating an object of class SoundgasmProfileIE
    # allows us to use its methods
    my_soundgasm_url = 'http://soundgasm.net/u/ytdl'
    my_se_object = SoundgasmProfileIE(my_soundgasm_url)
    assert(my_se_object.IE_NAME == 'SoundgasmProfile')

# Generated at 2022-06-24 13:14:51.232512
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'

# Generated at 2022-06-24 13:14:58.674579
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:15:01.855463
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # SoundgasmProfileIE is a subclass of InfoExtractor
    instance = SoundgasmProfileIE("test")
    if not isinstance(instance, InfoExtractor):
        print("Error! Not an instance of InfoExtractor")
        

# Generated at 2022-06-24 13:15:06.306671
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:15:13.422812
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Let's create an instance of this class
    inst = SoundgasmIE('soundgasm')
    assert inst._VALID_URL.__class__ == type(re.compile(''))
    assert inst._TEST['url'].__class__ == type('')
    assert inst._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert inst._TEST['md5'].__class__ == type('')
    assert inst._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'
    assert inst._TEST['info_dict'].__class__ == type({})
    assert inst._TEST['info_dict']['id'].__class__ == type('')

# Generated at 2022-06-24 13:15:14.863940
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  try:
      SoundgasmProfileIE()
  except TypeError:
      return False
  return True

# Generated at 2022-06-24 13:15:16.685666
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg = SoundgasmProfileIE()
    assert sg.extractor == SoundgasmIE

# Generated at 2022-06-24 13:15:19.056953
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    try:
        assert(ie is not None)
    except:
        assert(False)


# Generated at 2022-06-24 13:15:29.925810
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Unit test for constructor of class SoundgasmProfileIE"""
    # Constructor of class SoundgasmProfileIE is called with one parameter URL
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

    # Test member variable _VALID_URL
    assert ie._VALID_URL == 'https?://(?:www\\.)?soundgasm\\.net/u/(?P<id>[^/]+)/?(?:\\#.*)?'

    # Test member variable IE_NAME
    assert ie.IE_NAME == 'soundgasm:profile'

    # Test member variable _TEST

# Generated at 2022-06-24 13:15:36.334910
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = r'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'
    page = 'https://soundgasm.net/u/ytdl'
    instance = SoundgasmProfileIE(url)
    assert instance._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert instance.name == 'soundgasm:profile'
    assert instance._match_id(url) == "ytdl"
    assert instance._download_webpage(page, profile_id) is not None
    assert instance.url_result(r'http://soundgasm.net/u/ytdl/Piano-sample', 'Soundgasm') is not None

# Generated at 2022-06-24 13:15:41.022465
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from legi.test import check_playlist_rule
    check_playlist_rule('http://soundgasm.net/u/ytdl',
                        [('url', 'http://soundgasm.net/u/ytdl/Piano-sample')])

# Generated at 2022-06-24 13:15:46.688609
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	import re
	invalid_URL = 'This is not a URL because "://" is missing.'
	mobj = re.match(SoundgasmIE._VALID_URL, invalid_URL)
	if mobj == None:
		assert True, 'Invalid URL was not accepted by the constructor.'
	else:
		assert False, 'Invalid URL was accepted by the constructor.'


# Generated at 2022-06-24 13:15:47.676465
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    return SoundgasmProfileIE("SoundgasmProfileIE")

# Generated at 2022-06-24 13:15:49.476843
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl")



# Generated at 2022-06-24 13:15:56.123309
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE("http://soundgasm.net/u/ytdl#history")
    assert isinstance(ie._download_webpage("http://soundgasm.net/u/ytdl#history", "ytdl"), str)
    assert isinstance(ie._match_id("http://soundgasm.net/u/ytdl#history"), str)
    assert isinstance(ie.playlist_count, int)
    assert ie.playlist_count == 1
    assert isinstance(ie._real_extract("http://soundgasm.net/u/ytdl"), dict)

# Generated at 2022-06-24 13:15:57.691038
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Basic test for SoundgasmIE
    """
    SoundgasmIE()

# Generated at 2022-06-24 13:16:01.743407
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    video_info = youtube_dl.InfoExtractor('')._get_info('http://soundgasm.net/u/ytdl', download=False)
    assert video_info['id'] == 'ytdl'
    assert len(video_info['entries']) == 1

# Generated at 2022-06-24 13:16:09.115578
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    m = re.match(r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)',
                 'http://soundgasm.net/u/ytdl/Piano-sample')
    m.group('user')
    m.group('display_id')
    print(m.group('user') + " " + m.group('display_id'))

# Generated at 2022-06-24 13:16:12.856870
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	url = 'http://soundgasm.net/u/ytdl/Piano-sample'
	obj = SoundgasmIE()
	assert obj.suitable(url)
	assert obj.IE_NAME in obj.ie_key()


# Generated at 2022-06-24 13:16:19.965789
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._match_id('http://soundgasm.net/u/ytdl/Piano-sample') == 'Piano-sample'
    assert ie._match_id('http://soundgasm.net/u/ytdl/Piano-sample#') == 'Piano-sample'
    assert ie._match_id('http://soundgasm.net/u/ytdl/Piano-sample#comment') == 'Piano-sample'



# Generated at 2022-06-24 13:16:21.904558
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # This is the test function for constructor of class SoundgasmIE
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE(url)
    assert ie is not None


# Generated at 2022-06-24 13:16:24.698464
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print("Testing: SoundgasmProfileIE Constructor")
    test = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    print("Succesfully run test")
    return True


# Generated at 2022-06-24 13:16:29.403874
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie_soundgasm_profile = SoundgasmProfileIE()
    assert ie_soundgasm_profile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$', \
        'The object failed to get the valid url'

# Generated at 2022-06-24 13:16:31.876451
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    ie._real_extract(ie.url)
    # No errors

# Generated at 2022-06-24 13:16:34.439165
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE()._download_webpage(url)

# Generated at 2022-06-24 13:16:39.360120
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_cases = [
        # Test for SoundgasmProfileIE.__init__()
        {
            "url": "http://soundgasm.net/u/ytdl"
        }
    ]

    for testcase in test_cases:
        url = testcase["url"]
        SoundgasmProfileIE.__init__(SoundgasmProfileIE, url)
    return


# Generated at 2022-06-24 13:16:41.642793
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    dom_test = SoundgasmIE("www.soundgasm.net/u/ytdl/Piano-sample")


# Generated at 2022-06-24 13:16:47.709658
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(url="http://soundgasm.net/u/ytdl", downloader=None)
    assert ie._match_id(url="http://soundgasm.net/u/ytdl") == "ytdl"
    assert ie._match_id(url="http://soundgasm.net/u/ytdl?parameter=foo") == "ytdl"

# Generated at 2022-06-24 13:16:55.528418
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE.IE_NAME =='soundgasm:profile' )
    assert(SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
    soundgasmProfileIE = SoundgasmProfileIE('ytdl')
    assert(soundgasmProfileIE.IE_NAME == 'soundgasm:profile')
    assert(soundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')

# Generated at 2022-06-24 13:16:58.406945
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from __main__ import m_soundgasm
    SoundgasmIE(m_soundgasm, 'http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-24 13:17:05.546836
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	class_name_object = 'SoundgasmProfileIE'
	const_class_name = class_name_object.upper()
	class_meta = type(const_class_name, (object,), {'IE_NAME': 'youtube', '_VALID_URL': r'^\d{1,3}$'})
	class_class = type(class_name_object, (class_meta,), {'_real_extract': lambda self, url: {}})
	my_obj = class_class()
	my_obj._downloader = object()
	return my_obj

# Generated at 2022-06-24 13:17:15.016031
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("Unit test for constructor of class SoundgasmIE")
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    #img_thumb = "https://img03.soundgasm.net/u/ytdl/thumb/Piano-sample.jpg"
    audio_url = "https://audio03.soundgasm.net/u/ytdl/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a"


# Generated at 2022-06-24 13:17:22.028699
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:17:24.860217
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(url='http://soundgasm.net/u/ytdl/')
    assert ie.get_url() == 'http://soundgasm.net/u/ytdl/'

# Generated at 2022-06-24 13:17:26.565729
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Simple unit test for SoundgasmProfileIE
    """
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:17:27.508217
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()

# Generated at 2022-06-24 13:17:30.010160
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()._real_extract('http://soundgasm.net/u/ytdl')


# Generated at 2022-06-24 13:17:34.364745
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """ Unit test for SoundgasmProfileIE.__init__()
    """
    from .test_utils import get_testcases
    from . import _test_classes as test_classes
    for tc in get_testcases('SoundgasmProfileIE'):
        ie_test = test_classes['SoundgasmProfileIE'](tc)
        ie_test.runTest()

# Generated at 2022-06-24 13:17:39.816768
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    s = SoundgasmIE(url)
    assert s.ie_key() == 'Soundgasm'
    assert s.display_id == 'ytdl'
    assert s.display_name == 'Piano-sample'
    assert s.user_name == 'ytdl'



# Generated at 2022-06-24 13:17:49.967694
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Basic test on constructor of class SoundgasmIE
    """
    # SoundgasmIE
    ie = SoundgasmIE()
    assert hasattr(ie, 'IE_NAME'), "Missing attribute IE_NAME in instance"
    assert hasattr(ie, '_VALID_URL'), "Missing attribute _VALID_URL in instance"
    assert hasattr(ie, '_TEST'), "Missing attribute _TEST in instance"
    assert ie.IE_NAME == 'SoundgasmIE'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Command to run unit tests
# python -m un

# Generated at 2022-06-24 13:18:00.169870
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    object = SoundgasmIE()
    # Class attributes are class specific and thus start with capitals
    assert (object.IE_NAME == "soundgasm")
    assert (object.IE_DESC == "Soundgasm.net")
    assert (object._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-24 13:18:01.412779
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None, 'http://soundgasm.net/something.html')

# Generated at 2022-06-24 13:18:03.477557
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Constructor test"""
    inst = SoundgasmProfileIE()
    inst2 = SoundgasmProfileIE()
    assert inst != inst2
    return

# Generated at 2022-06-24 13:18:06.340872
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm = SoundgasmProfileIE()
    assert soundgasm._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:18:13.469043
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE()
    # tests for private method _valid_url
    test_url = 'http://soundgasm.net/u/ytdl'
    assert profile._valid_url(test_url, 'SoundgasmPlaylist') is True
    test_url_2 = 'http://soundgasm.net/u/ytdl/'
    assert profile._valid_url(test_url_2, 'SoundgasmPlaylist') is True

# Generated at 2022-06-24 13:18:23.624265
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Simple test for constructor of class SoundgasmIE
    """
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    display_id = url.split('/')[-1]
    audio_id = display_id

    expected_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    expected_title = 'Piano sample'
    expected_description = 'Royalty Free Sample Music'
    expected_uploader = 'ytdl'
    expected_duration = None
    expected_formats = None
    expected_subtitles = None
    expected_thumbnail = None

    soundgasm_ie = SoundgasmIE()
    info_dict = soundgasm_ie.extract(url)

    assert expected_