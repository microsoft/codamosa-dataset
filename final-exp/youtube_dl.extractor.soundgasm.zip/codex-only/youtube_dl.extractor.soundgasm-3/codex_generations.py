

# Generated at 2022-06-24 13:08:19.724981
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:08:27.010853
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.ie_key() == 'Soundgasm'
    assert ie.ie_name() == 'Soundgasm'
    assert ie.suitable(ie._VALID_URL)
    assert ie.suitable(ie._TEST['url'])

    assert ie.suitable('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie.suitable('http://soundgasm.net/u/ytdl/Piano-sample/#comments')
    assert ie.suitable('http://soundgasm.net/u/ytdl/Piano-sample/#comments-1')
    assert ie.suitable('http://soundgasm.net/u/ytdl/Piano-sample/#fav')

# Generated at 2022-06-24 13:08:28.159710
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # init
    assert True
    return True

# Generated at 2022-06-24 13:08:34.203666
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	obj = SoundgasmIE()
	assert obj._VALID_URL==r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
	assert obj._TEST['url']== 'http://soundgasm.net/u/ytdl/Piano-sample'

# Generated at 2022-06-24 13:08:42.192280
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://www.soundgasm.net/u/ytdl/Music%20sample'
    expected_output = {
        'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
        'uploader': 'ytdl',
        'description': 'Royalty Free Sample Music',
        'title': 'Music sample',
        'ext': 'm4a',
        'url': 'http://soundgasm.net/sample/music-sample.m4a',
        'display_id': 'Music%20sample',
    }
    actual_output = SoundgasmIE(url)
    print(actual_output)
    assert actual_output == expected_output

# Generated at 2022-06-24 13:08:44.220982
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:08:44.818589
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  assert True

# Generated at 2022-06-24 13:08:48.226176
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    result = SoundgasmProfileIE()._real_extract(u'http://soundgasm.net/u/ytdl')
    assert result['id'] == 'ytdl'
    assert len(result['entries']) == 1

# Generated at 2022-06-24 13:08:48.885589
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-24 13:08:49.851498
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:08:53.606301
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        soundgasm_test = SoundgasmProfileIE()
        print(soundgasm_test.extract('http://soundgasm.net/u/ytdl'))
    except Exception as exc:
        print('ERROR: {}'.format(exc))


# Generated at 2022-06-24 13:09:02.895241
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    inst = SoundgasmIE(url)
    assert inst.IE_NAME == 'soundgasm'
    assert inst._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:09:13.455064
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie_profile = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    assert ie_profile.IE_NAME == "soundgasm:profile"
    assert ie_profile.__class__.__name__ == "SoundgasmProfileIE"
    assert ie_profile._VALID_URL == r"https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$"
    assert ie_profile._TEST['url'] == "http://soundgasm.net/u/ytdl"
    assert ie_profile._TEST['info_dict'] == {'id': 'ytdl'}
    assert ie_profile._TEST['playlist_count'] == 1



# Generated at 2022-06-24 13:09:14.034094
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-24 13:09:20.978807
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	# Test Case 1:
	print("Testing Case 1: Correct URL")
	url = "http://soundgasm.net/u/ytdl"
	SoundgasmProfileIE._TEST = {
        'url': url,
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
	print("Input details: URL: ",url)
	print("Output details: ",SoundgasmProfileIE._real_extract(SoundgasmProfileIE(),url))


# Generated at 2022-06-24 13:09:22.934319
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    playlist = SoundgasmProfileIE()._real_extract(
        'http://soundgasm.net/u/ytdl')
    assert playlist['_type'] == 'playlist'

# Generated at 2022-06-24 13:09:23.987080
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert isinstance(SoundgasmProfileIE(), InfoExtractor)

# Generated at 2022-06-24 13:09:32.360267
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Test SoundgasmIE class.
    """
    ie = SoundgasmIE()
    info_dict = ie._call_api({
        'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
        'display_id': 'Piano-sample',
        'extract_flat': True
    })
    assert info_dict['title'] == "Piano sample"
    assert info_dict['uploader'] == "ytdl"
    

# Generated at 2022-06-24 13:09:37.715933
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    # with profile_id and page_number
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie._VALID_URL == 'http://soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'

# Generated at 2022-06-24 13:09:38.537438
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE

# Generated at 2022-06-24 13:09:41.198127
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample').expect_url('010082a2c802c5275bb00030743e75ad')

# Generated at 2022-06-24 13:09:43.228091
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Just create an instance for debugging purpose.
    """
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:09:48.783933
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_ie = SoundgasmProfileIE()
    assert profile_ie.name == SoundgasmProfileIE.IE_NAME
    assert profile_ie.ie_key() == SoundgasmProfileIE.IE_NAME
    assert profile_ie.IE_NAME == 'soundgasm:profile'
    assert profile_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:09:50.560560
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None)._real_extract('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:09:56.816504
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Perform a unit test for class SoundgasmIE
test_SoundgasmIE()

# Generated at 2022-06-24 13:10:07.512929
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	url = "http://soundgasm.net/u/ytdl"
	ie = SoundgasmProfileIE(url)
	assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
	assert ie._TEST == {
	        'url': 'http://soundgasm.net/u/ytdl',
	        'info_dict': {
	            'id': 'ytdl',
	        },
	        'playlist_count': 1,
	    }

	assert ie._match_id(url) == "ytdl"

	assert ie.IE_NAME == "soundgasm:profile"
	assert ie.__name__ == "SoundgasmProfileIE"
# Test case

# Generated at 2022-06-24 13:10:08.976808
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    x = SoundgasmIE()
    return x



# Generated at 2022-06-24 13:10:17.861176
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url_test_regex = r'"http://soundgasm\.net/u/ytdl/Piano-sample"'
    extractor = SoundgasmIE()
    extractor._downloader = None
    extractor._download_webpage = lambda url, *args, **kargs: test_SoundgasmIE.test_html
    extractor._search_regex = lambda *args, **kargs: test_SoundgasmIE.search_regex_result
    extractor._html_search_regex = lambda *args, **kargs: test_SoundgasmIE.html_search_regex_result
    extractor._download_webpage = lambda *args, **kargs: test_SoundgasmIE.test_html
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    result

# Generated at 2022-06-24 13:10:25.892630
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:10:26.442856
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert 1 == 1

# Generated at 2022-06-24 13:10:36.322456
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE_NAME = 'SoundgasmProfileIE'
    VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    TEST = {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

    import pprint
    import json
    from urlparse import urlparse

    result = urlparse(TEST["url"])
    pattern = re.search(VALID_URL, result.path)
    id = pattern.group("id")

    pages = []
    page = 1

# Generated at 2022-06-24 13:10:42.550439
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Build SoundgasmIE
    ie = SoundgasmIE()
    # Run test on valid URL
    assert ie._TEST['url'] == ie._TEST['info_dict']['id']
    # Run test on invalid URL
    assert ie.url_result('http://soundgasm.net/u/ytdl/Pian-sample', 'Soundgasm').url == None
    assert ie.url_result('http://soundgasm.net/u/ytdl/Pian-sample', 'Soundgasm').id == None
    # Run test on valid URL
    assert ie.url_result('http://soundgasm.net/u/ytdl/Piano-sample', 'Soundgasm').url == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie.url_result

# Generated at 2022-06-24 13:10:50.120818
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == "soundgasm:profile"
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-24 13:10:50.593020
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()

# Generated at 2022-06-24 13:10:55.402078
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    with SoundgasmIE(SoundgasmIE.ie_key()) as ie:
        assert_equal(ie._match_id(test_url), "88abd86ea000cafe98f96321b23cc1206cbcbcc9")
        assert_equal(ie._real_extract(test_url)['title'] , "Piano sample")

# Generated at 2022-06-24 13:11:04.769763
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Unittest for class SoundgasmProfileIE
    test_obj = SoundgasmProfileIE()
    assert test_obj.IE_NAME == 'soundgasm:profile'
    assert test_obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert test_obj._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-24 13:11:12.356195
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:11:22.282389
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from SimpleXMLRPCServer import SimpleXMLRPCServer
    from xmlrpclib import Binary
    
    class SoundgasmXMLRPCServer(SimpleXMLRPCServer):
        def __init__(self, host="127.0.0.1", port=9000):
            SimpleXMLRPCServer.__init__(self, (host, port))
            self.register_function(self.add)
            self.register_function(self.subtract)
            self.register_function(self.multiply)
            self.register_function(self.divide)
            self.register_function(self.binary)

        def add(self, a, b):
            return a+b

        def subtract(self, a, b):
            return a-b


# Generated at 2022-06-24 13:11:28.563128
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # This was the SoundgasmIE that failed in the past
    audio_sample = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert SoundgasmIE()._match_id(audio_sample).group('display_id') == 'Piano-sample'
    assert SoundgasmIE()._match_id(audio_sample).group('user') == 'ytdl'


# Generated at 2022-06-24 13:11:29.488688
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	print("Implemented")
	

# Generated at 2022-06-24 13:11:33.418099
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    audio_url = 'http://media.soundgasm.net/u/ytdl/Piano-sample.m4a'
    title = 'Piano sample'
    description = 'Royalty Free Sample Music'
    audio_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    uploader = 'ytdl'
    display_id = 'Piano-sample'

    test_instance = SoundgasmIE(url)

    assert test_instance.IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:11:34.310926
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.extractor

# Generated at 2022-06-24 13:11:40.668684
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url_profile = 'http://soundgasm.net/u/ytdl'
    info_extractor = SoundgasmProfileIE()
    result_dict = info_extractor._real_extract(url_profile)
    assert result_dict['id'] == 'ytdl'
    assert result_dict['_type'] == 'playlist'
    assert 'ytdl/Piano-sample' in result_dict['entries'][0]['url']


# Generated at 2022-06-24 13:11:41.291495
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-24 13:11:44.046567
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	soundgasmProfileIE = SoundgasmProfileIE()
	print(soundgasmProfileIE.IE_NAME)
	print(soundgasmProfileIE.playlist_count)


# Generated at 2022-06-24 13:11:45.001711
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()


# Generated at 2022-06-24 13:11:52.211119
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    IE = SoundgasmIE()
    ie_result = IE.extract(url)
    assert ie_result.get('extractor') == IE.IE_NAME
    assert ie_result.get('url') == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie_result.get('display_id') == 'Piano-sample'
    assert ie_result.get('vcodec') == 'none'
    assert ie_result.get('description') == 'Royalty Free Sample Music'
    assert ie_result.get('uploader') == 'ytdl'

# Generated at 2022-06-24 13:11:53.781270
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl',
        {
            'id': 'ytdl',
        },
        1)

# Generated at 2022-06-24 13:11:55.127539
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    return "http://soundgasm.net/u/ytdl/Piano-sample"
    

# Generated at 2022-06-24 13:12:02.107896
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Arrange
    url = "http://soundgasm.net/u/ytdl"

    expected_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    expected_name = "Soundgasm"
    expected_id = "Piano-sample"
   
    # Act
    result = SoundgasmProfileIE()

    # Assert
    assert result.url == expected_url
    assert result.name == expected_name
    assert result.id == expected_id

# Generated at 2022-06-24 13:12:03.942192
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    s = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    s.extract()

# Generated at 2022-06-24 13:12:07.333150
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    soundgasmProfileIE = SoundgasmProfileIE(url)

# Generated at 2022-06-24 13:12:16.743662
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .test_imports import unittest
    from .test_html import get_test_cases
    test_cases = get_test_cases('SoundgasmProfileIE')
    test_cases.append(unittest.TestCase(methodName='test_SoundgasmProfileIE',
      test=lambda: SoundgasmProfileIE()._real_extract(url='http://soundgasm.net/u/ytdl')))

    suite = unittest.TestSuite()
    suite.addTests(test_cases)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-24 13:12:26.759359
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    # Test case to test return statement of new_result function when 'audio_id' is first parameter
    audio_id = 'audioID'
    audio_url = 'audioURL'
    display_id = '123ABC'
    title = 'title'
    description = 'description'
    uploader = 'uploader'

    #
    result = {
            'id': audio_id,
            'display_id': display_id,
            'url': audio_url,
            'vcodec': 'none',
            'title': title,
            'description': description,
            'uploader': uploader,
        }


    # Test case to test return statement of new_result function when 'audio_id' is not first parameter
    audio_id = 'audioID'
    audio_url = 'audioURL'

# Generated at 2022-06-24 13:12:28.714160
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Sample-Sound'
    a = SoundgasmIE(url)

# Generated at 2022-06-24 13:12:30.835337
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    instance.extract()

# Generated at 2022-06-24 13:12:33.102256
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_result = SoundgasmProfileIE()._real_extract('http://soundgasm.net/u/ytdl')
    assert len(profile_result['entries']) == 1

# Generated at 2022-06-24 13:12:36.245141
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

if __name__ == '__main__':
    test_SoundgasmIE()

# Generated at 2022-06-24 13:12:37.503343
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    current_instance = SoundgasmProfileIE('SoundgasmProfileIE', 'http://soundgasm.net/u/ytdl', {})

# Generated at 2022-06-24 13:12:44.369366
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SGI = SoundgasmIE()
    SGI_test = SGI.IE_NAME
    SGI_url = SGI._VALID_URL
    SGI_url_match = SGI.test(url=SGI.test_url)
    SGI_md5 = SGI.test_md5
    SGI_dict = SGI.test_info_dict
    SGI_key = SGI.test_key

    assert SGI_test == 'soundgasm'
    assert SGI_url == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert SGI_url_match == True
    assert SGI_md5

# Generated at 2022-06-24 13:12:47.435406
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl/'
    profile = SoundgasmProfileIE(url)
    assert profile.url == url
    assert profile.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:12:51.870074
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Purpose of this test is to check if it is possible to create instance of
    # SoundgasmIE and if it doesn't raise any errors
    ie = SoundgasmIE()
    if not isinstance(ie, SoundgasmIE):
        raise AssertionError("Creating instance of SoundgasmIE has failed")


# Generated at 2022-06-24 13:12:57.539212
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Test SoundgasmIE constructor"""
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'



# Generated at 2022-06-24 13:13:05.307721
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import json
    from urllib import urlencode

    # Constructor of class SoundgasmIE should accept dictionary that specifies arguments
    test_dict = {
        'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
        'playliststart': 1,
        'playlistend': 2,
    }
    assert isinstance(SoundgasmIE(test_dict), InfoExtractor)
    # The constructor should accept url that has query string
    assert isinstance(SoundgasmIE(json.dumps(test_dict)), InfoExtractor)

# Generated at 2022-06-24 13:13:12.980391
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Simple test to ensure that the SoundgasmIE constructor actually works.
    # This just tests it accepts the parameters
    # (one day it might accept more parameters, and this test will fail)
    ie = SoundgasmIE('abc')
    assert ie.IE_NAME == 'soundgasm'
    # Make sure we don't accept invalid urls
    assert SoundgasmIE.suitable('https://soundgasm.net/u/ytdl/Piano-sample') == True
    assert SoundgasmIE.suitable('https://soundgasm.com/u/ytdl/Piano-sample') == False


# Generated at 2022-06-24 13:13:14.413102
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:13:18.546750
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = SoundgasmIE()
    match_result = test._match_id('http://soundgasm.net/u/ytdl/Piano-sample')
    expected_result = 'Piano-sample'
    assert match_result == expected_result
    assert test.IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:13:25.569573
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    d = SoundgasmProfileIE()
    assert_equal(d._VALID_URL, 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?')
    assert_equal(d._TEST, {"url": "http://soundgasm.net/u/ytdl", "info_dict": {"id": "ytdl"}, "playlist_count": 1})

# Generated at 2022-06-24 13:13:29.360497
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    _SoundgasmProfileIE = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert _SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert not _SoundgasmProfileIE.IE_DESC

# Generated at 2022-06-24 13:13:30.554217
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    SoundgasmProfileIE(ie)

# Generated at 2022-06-24 13:13:31.427557
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()

# Generated at 2022-06-24 13:13:32.899035
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    e = SoundgasmProfileIE()
    e.update_ie_mapping()

# Generated at 2022-06-24 13:13:33.457994
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-24 13:13:35.812614
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:13:43.271719
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasmProfileIE = SoundgasmProfileIE()
    soundgasmProfileIE._download_webpage = lambda url, display_id: url
    soundgasmProfileIE._match_id = lambda url: url
    assert soundgasmProfileIE._real_extract("http://soundgasm.net/u/ytdl") == {
        "playlist": "http://soundgasm.net/u/ytdl",
        "playlist_count": 0,
        "id": "http://soundgasm.net/u/ytdl",
        "title": "http://soundgasm.net/u/ytdl",
        "uploader": "http://soundgasm.net/u/ytdl",
        "extractor": "SoundgasmProfile",
    }

# Generated at 2022-06-24 13:13:47.435880
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_url = 'http://soundgasm.net/u/ytdl'
    test_obj = SoundgasmProfileIE()
    assert test_obj._match_id(test_url) == 'ytdl'



# Generated at 2022-06-24 13:13:53.901149
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    construct_SoundgasmProfileIE = SoundgasmProfileIE._real_extract
    test_SoundgasmProfileIE = test_SoundgasmIE._real_extract
    test_SoundgasmIE._real_extract = construct_SoundgasmProfileIE
    construct_SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    test_SoundgasmIE._real_extract = test_SoundgasmProfileIE


# Generated at 2022-06-24 13:13:56.112345
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE("SoundgasmIE")

# Generated at 2022-06-24 13:14:00.273153
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    profile = SoundgasmProfileIE()

    assert profile != None # See if the test fails by creating an instance of SoundgasmProfileIE
    assert profile._TEST['url'] == 'http://soundgasm.net/u/ytdl' # Test for playlist

# Generated at 2022-06-24 13:14:00.724669
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:14:06.659019
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    A unit test case to test constructor of class SoundgasmProfileIE
    """
    profile=SoundgasmProfileIE()
    assert profile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert profile.IE_NAME == 'soundgasm:profile'
    assert profile._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-24 13:14:11.452692
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert SoundgasmIE()._match_id(url) == 'Piano-sample'
    url = 'http://soundgasm.net/u/ytdl/'
    assert SoundgasmIE()._match_id(url) == 'ytdl'

# Generated at 2022-06-24 13:14:20.288656
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # check for extra definition of class SoundgasmProfileIE
    assert SoundgasmProfileIE.__module__ == "youtube_dl.extractor.soundgasm"
    # check for definition of class SoundgasmProfileIE
    assert SoundgasmProfileIE.__name__ == "SoundgasmProfileIE"
    # check for definition of attribute IE_NAME
    assert SoundgasmProfileIE.IE_NAME == "soundgasm:profile"
    # check for definition of attribute _VALID_URL
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    # check for definition of attribute _TEST

# Generated at 2022-06-24 13:14:30.892384
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# test_constructor tests the constructor of the class and tests whether
	# the constructor sets the correct instance attributes
	print ("\ntest_SoundgasmIE test_constructor")
	url = 'http://soundgasm.net/u/ytdl/Piano-sample'
	SoundgasmIE.IE_NAME = 'soundgasm'
	SoundgasmIE._VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:14:32.641198
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE(None)._VALID_URL == SoundgasmProfileIE.IE_NAME

# Generated at 2022-06-24 13:14:35.237516
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('https://soundgasm.net/u/ytdl') == SoundgasmProfileIE('https://soundgasm.net/u/ytdl/')

# Generated at 2022-06-24 13:14:38.634749
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # if _match_id not implemented, this test will raise an error
    ie = SoundgasmProfileIE()
    # if _real_extract not implemented, this test will raise an error
    ie._real_extract('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:14:45.729900
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE(url)
    ie.IE_NAME.should.equal('soundgasm:profile')
    ie.IE_DESC.should.equal('soundgasm')
    ie._VALID_URL.should.equal('https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
    ie._TEST['url'].should.equal(url)
    ie._TEST['info_dict']['id'].should.equal('ytdl')

# Generated at 2022-06-24 13:14:48.178749
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sie = SoundgasmProfileIE()
    m = re.match(sie._VALID_URL, 'http://soundgasm.net/u/ytdl')
    assert m.group('id') == 'ytdl'

# Generated at 2022-06-24 13:14:50.454988
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    aud = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    aud.extract()

# Generated at 2022-06-24 13:14:58.287459
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # prepare objects to be used in constructor test
    ie = SoundgasmProfileIE("soundgasm")
    url = "http://soundgasm.net/u/ytdl"

# Generated at 2022-06-24 13:14:59.866293
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    ie.IE_NAME = "SoundgasmIE"

# Generated at 2022-06-24 13:15:02.414520
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    succes = True
    try:
        SoundgasmIE()
    except Exception as e:
        succes = False
    assert succes


# Generated at 2022-06-24 13:15:12.190333
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	url = 'http://soundgasm.net/u/blump/Piano-sample'
	sg = SoundgasmIE()
	assert sg._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
	mobj = re.match(sg._VALID_URL, url)
	display_id = mobj.group('display_id')
	webpage = sg._download_webpage(url, display_id)

# Generated at 2022-06-24 13:15:20.160801
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print('Unit test for SoundgasmIE')
    # Get user's profile
    userpage = 'http://soundgasm.net/u/ytdl'
    # Get audio page
    audiopage = 'http://soundgasm.net/u/ytdl/Piano-sample'
    # Test SoundgasmIE
    ie = SoundgasmIE()
    # Test _real_extract function
    ie._real_extract(audiopage)
    # Test SoundgasmProfileIE
    ie = SoundgasmProfileIE()
    ie._real_extract(userpage)

# Run test
test_SoundgasmIE()

# Generated at 2022-06-24 13:15:22.341531
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample', download = False)

# Generated at 2022-06-24 13:15:25.793285
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Initialise SoundgasmProfileIE class"""
    _SoundgasmProfileIE = SoundgasmProfileIE()
    assert _SoundgasmProfileIE is not None

test = test_SoundgasmProfileIE

# Generated at 2022-06-24 13:15:33.243824
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    t = SoundgasmProfileIE()
    assert t.__class__.__name__ == 'SoundgasmProfileIE'
    assert t.IE_NAME == 'soundgasm:profile'
    assert t.IE_DESC == 'Soundgasm user profile'
    assert t._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert t._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}

# Generated at 2022-06-24 13:15:44.819546
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    input_url = "http://soundgasm.net/u/ytdl/#/u/ytdl/Piano-sample"
    expected_output = "http://soundgasm.net/u/ytdl/Piano-sample"

    test_profile = SoundgasmProfileIE(None) # test constructor
    assert test_profile._match_id("http://soundgasm.net/u/ytdl") == "ytdl", "test constructor, test _match_id method failed"
    assert test_profile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$', "test constructor, test _VALID_URL attribute failed"


# Generated at 2022-06-24 13:15:49.666598
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	try:
		print("Enter the URL to be checked")
		url = input()
		SoundgasmIE()._real_extract(url)
		print("The input URL is a valid Soundgasm URL")
	except Exception as e:
		print("The input is not a valid Soundgasm URL")


# Generated at 2022-06-24 13:15:51.713516
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('ytdl')
    assert ie.ie_key() == 'SoundgasmProfileIE'

# Generated at 2022-06-24 13:15:54.221735
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test the constructor of class SoundgasmProfileIE.
    url = 'http://soundgasm.net/u/ytdl/'
    SoundgasmProfileIE._real_initialize(url)


# Generated at 2022-06-24 13:15:55.516415
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert(SoundgasmIE()._downloader is not None)


# Generated at 2022-06-24 13:15:57.382245
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl/')


# Generated at 2022-06-24 13:16:01.805555
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info_extractor = InfoExtractor(SoundgasmIE._NAME)
    assert info_extractor.IE_NAME == SoundgasmIE._NAME
    assert info_extractor.IE_DESC == SoundgasmIE.IE_DESC
    assert info_extractor._WORKING == SoundgasmIE._WORKING

# Generated at 2022-06-24 13:16:05.961032
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test creation of SoundgasmIE
    ie = SoundgasmIE()
    assert ie.ie_key() == 'Soundgasm'
    assert ie.ie_name() == 'Soundgasm'
    assert ie.supported_ie() == ['Soundgasm']

# Generated at 2022-06-24 13:16:12.194762
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?"
    assert ie._TEST == {"url": "http://soundgasm.net/u/ytdl",
                        "info_dict": {"id": "ytdl"},
                        "playlist_count": 1}



# Generated at 2022-06-24 13:16:22.598288
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    webpage = ie._download_webpage('http://soundgasm.net/u/ytdl')

    # Get all urls of ytdl's list, which also appear on a user's main page
    # of soundgasm.net
    expected_urls = re.findall(r'href="([^"]+/u/ytdl/[^"]+)', webpage)

    profile_id = 'ytdl'
    urls = ie._real_extract('http://soundgasm.net/u/ytdl/')

    # Test urls with assertEqual
    # Test for entries with assertEqual
    assert len(urls['entries']) == len(expected_urls)


# Generated at 2022-06-24 13:16:24.108903
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # test overriding SoundgasmIE constructor
    # SoundgasmIE()
    pass


# Generated at 2022-06-24 13:16:29.072068
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')
# test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-24 13:16:35.239609
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print ("Starting unit test for class SoundgasmProfileIE")

    a = SoundgasmProfileIE()
    b = a.IE_NAME
    print (b)
    if (b == 'soundgasm:profile'):
        print ("[OK] class SoundgasmProfileIE constructor")
    else:
        print ("[FAIL] class SoundgasmProfileIE constructor")

if __name__ == '__main__':
    test_SoundgasmProfileIE()

# Generated at 2022-06-24 13:16:36.480643
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-24 13:16:37.988165
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('Youtube-dl').run()

# Generated at 2022-06-24 13:16:40.116867
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    urlSoundgasmProfileIE = SoundgasmProfileIE('soundgasm.net')

# Generated at 2022-06-24 13:16:42.187447
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    a = SoundgasmIE()
    # Check that __init__ does not raise a TypeError
    assert(a != None)


# Generated at 2022-06-24 13:16:48.260864
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl#page=1'
    ie = SoundgasmProfileIE()
    assert ie._match_id(url) == 'ytdl'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:16:51.754620
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-24 13:16:52.838981
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    if __name__ == '__main__':
        test_SoundgasmProfileIE()

# Generated at 2022-06-24 13:16:56.794725
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:16:57.826563
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	SoundgasmIE(None)


# Generated at 2022-06-24 13:17:03.856545
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    x = SoundgasmIE('http://soundgasm.net/profile/pianosounds')
    assert x.IE_NAME == 'soundgasm'
    assert ('http://soundgasm.net/u/pianosounds/Piano-sample',
            '88abd86ea000cafe98f96321b23cc1206cbcbcc9') == x._get_id('http://soundgasm.net/u/pianosounds/Piano-sample')

# Generated at 2022-06-24 13:17:05.241453
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        s = SoundgasmProfileIE()
    except:
        pass

# Generated at 2022-06-24 13:17:06.794285
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    i = SoundgasmProfileIE('SoundgasmProfile')
    assert i.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:17:08.185969
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg = SoundgasmProfileIE("ytdl")
    assert(sg.IE_NAME == "Soundgasm Profile ytdl")

# Generated at 2022-06-24 13:17:08.648410
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:17:09.508695
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:17:10.668432
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = SoundgasmIE()
    assert test.IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:17:11.921854
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL == SoundgasmProfileIE._VALID_URL

# Generated at 2022-06-24 13:17:22.249655
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Instantiate class SoundgasmIE
    instance = SoundgasmIE()

    # Test class SoundgasmIE
    assert hasattr(instance, '_VALID_URL')
    assert hasattr(instance, '_TESTS')
    assert hasattr(instance, 'IE_NAME')
    assert hasattr(instance, '_real_extract')

    # Test method _real_extract()
    url = 'http://soundgasm.net/u/ytdl/Piano-sampl'
    m4a_url = 'https://s3.amazonaws.com/soundgasm.net/audio/2013/12/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    display_id = 'Piano-sampl'

# Generated at 2022-06-24 13:17:23.975601
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-24 13:17:27.508648
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Simple unit test to confirm class SoundgasmProfileIE constructor sets the right instance name.
    """
    errmsg = 'The IE name should be {0}'.format('SoundgasmProfileIE')
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile', errmsg

# Generated at 2022-06-24 13:17:31.437138
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Constructor of class SoundgasmProfileIE
    # Test suite for function __init__
    
    # Should be able to create a SoundgasmProfileIE object by giving a valid link to constructor
    assert SoundgasmProfileIE(url='http://soundgasm.net/u/ytdl') is not None

# Generated at 2022-06-24 13:17:36.832428
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import unittest
    class TestSoundgasmIE(unittest.TestCase):
        def test_soundgasm_instance(self):
            ie = SoundgasmIE()
            self.assertEqual(ie.ie_key(), 'Soundgasm')
            self.assertEqual(ie.ie_name(), 'Soundgasm')
            self.assertEqual(ie.ie_version(), '0.1')

    unittest.main()

# Generated at 2022-06-24 13:17:38.883226
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(InfoExtractor('test', {'id': 'test_id'}))

# Generated at 2022-06-24 13:17:49.116504
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Unit test for constructor of class SoundgasmIE
    """
    print("Running unit test for constructor of class SoundgasmIE")

    ie_soundgasm = SoundgasmIE()
    assert ie_soundgasm._VALID_URL == SoundgasmIE._VALID_URL

    ie = InfoExtractor()
    ie_soundgasm = ie.create_ie(ie_soundgasm._IE_NAME)
    assert ie_soundgasm._VALID_URL == SoundgasmIE._VALID_URL

    ie_soundgasm_test = SoundgasmIE()
    for key in SoundgasmIE._TEST.keys():
        assert key in ie_soundgasm_test._TEST
        assert ie_soundgasm_test._TEST[key] == SoundgasmIE._TEST[key]
    print

# Generated at 2022-06-24 13:17:49.675474
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass

# Generated at 2022-06-24 13:18:00.618897
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Unit test for constructor of class SoundgasmIE.
    """

    test = SoundgasmIE()

    assert test.IE_NAME == 'soundgasm'
    assert test._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    # assert test._TEST == {
    #     'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
    #     'md5': '010082a2c802c5275bb00030743e75ad',
    #     'info_dict': {
    #         'id': '88abd86ea000cafe98f

# Generated at 2022-06-24 13:18:05.546723
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl' # The original URL
    expected = 'http://soundgasm.net/u/ytdl/Piano-sample' # The expected URL
    result = SoundgasmProfileIE._real_extract(url) # The extraction result
    actual = result[0]['url'] # The actual URL
    assert(actual == expected) # Checking the actual URL against what is expected

# Generated at 2022-06-24 13:18:10.580662
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    result = SoundgasmProfileIE._build_url_result('http://soundgasm.net/u/ytdl/Piano-sample')
    assert result['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert result['ie_key'] == 'Soundgasm'


# Generated at 2022-06-24 13:18:12.842739
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    ie.extract()

# Generated at 2022-06-24 13:18:19.625141
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('Soundgasm:profile')
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'
    assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl',
                        'info_dict': {'id': 'ytdl'},
                        'playlist_count': 1}