

# Generated at 2022-06-24 13:08:21.673123
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        SoundgasmProfileIE(SoundgasmProfileIE._VALID_URL)
        print("Constructor return a SoundgasmProfileIE")
    except(Exception):
        print("Constructor return an error")

# Generated at 2022-06-24 13:08:31.814955
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == 'soundgasm'
    assert SoundgasmIE()._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:08:40.774532
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    instance = SoundgasmProfileIE()
    assert instance._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    # Test _real_extract function
    webpage = instance._download_webpage(url, 'ytdl')
    entries = [
        instance.url_result(audio_url, 'Soundgasm')
        for audio_url in re.findall(r'href="([^"]+/u/ytdl/[^"]+)', webpage)]
    result = instance.playlist_result(entries, 'ytdl')
    assert result['title'] == 'ytdl'
# Test for class SoundgasmIE

# Generated at 2022-06-24 13:08:45.828742
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE._download_webpage = lambda url: url
    SoundgasmIE._search_regex = lambda url, pat1, pat2, pat3: pat3
    obj = SoundgasmIE(url)
    obj.extract()
    # Test whether the appropriate attributes are set

# Generated at 2022-06-24 13:08:48.786237
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	print('%s\n' % SoundgasmProfileIE('http://soundgasm.net/u/ytdl', 'Soundgasm'))

test_SoundgasmProfileIE()


# Generated at 2022-06-24 13:08:53.007251
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:08:53.960996
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('')

# Generated at 2022-06-24 13:09:01.796090
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ieInstance = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample");
    if( isinstance(ieInstance._match_id, re._pattern_type)):
        print("The _match_id is the correct type");
    else:
        print("The _match_id is the incorrect type");

    if( isinstance(ieInstance._VALID_URL, str)):
        print("The _VALID_URL is the correct type");
    else:
        print("The _VALID_URL is the incorrect type");

    #As we don't want to download the webpage in a unit test we can set the _download_webpage function to
    #return a constant value

# Generated at 2022-06-24 13:09:02.571615
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:09:08.281971
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info = SoundgasmProfileIE()._real_extract('http://soundgasm.net/u/ytdl')
    assert 'Audio URL: http://soundgasm.net/u/ytdl/Piano-sample' in info['description']
    assert 'Audio format: m4a' in info['description']
    assert 'Audio quality: audio only' in info['description']

# Generated at 2022-06-24 13:09:10.662130
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    mobj = ie._VALID_URL
    ie._match_id('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:09:21.082998
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from soundgasmIE import SoundgasmProfileIE
    import requests
    import json
    # In order to get a "example" session (cookie) for testing,
    # we can use the following code
    # cookie = requests.get('http://soundgasm.net/login').cookies.get_dict()
    # json_str = json.dumps(cookie, indent=2)
    # print json_str
    # Then we can use the string 'json_str' to get it back
    # the following is the "example" cookie

# Generated at 2022-06-24 13:09:27.877264
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    # Test for #find_xpath()
    ie._find_xpath(None, '//div')
    # Test for #extract_xpath()
    ie._extract_xpath(None, '//div')
    # Test for #xpath_text()
    ie._xpath_text(None, '//div')
    # Test for #_search_regex()
    ie._search_regex(None, None, None, fatal=False)
    # Test for #_html_search_regex()
    ie._html_search_regex(None, None, None, fatal=False)
    # Test for #_extract_entries()
    ie._extract_entries(None, None)
    # Test for #_download_webpage()
    ie._download

# Generated at 2022-06-24 13:09:32.517130
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    # Import all of the files in the "tests" directory that start with "test_"
    import os
    import glob
    for path in glob.glob(os.path.join(os.path.dirname(__file__), 'tests', 'test_*')):
        __import__(path[:-3])

# Generated at 2022-06-24 13:09:34.379023
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	ie = SoundgasmIE()
	assert ie.IE_NAME, 'soundgasm'


# Generated at 2022-06-24 13:09:42.985499
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    title = 'Piano sample'
    description = 'Royalty Free Sample Music'
    audio_url = 'https://s3.amazonaws.com/sg-content-prod/audio/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    audio_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    display_id = 'Piano-sample'
    uploader = 'ytdl'

    soundgasm_test = SoundgasmIE()

    assert soundgasm_test._match_id(url) == display_id

# Generated at 2022-06-24 13:09:43.761073
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:09:45.322416
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    s = SoundgasmProfileIE()
    assert s.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:09:49.133966
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    SoundgasmIE._TEST['url'] = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie.suitable(SoundgasmIE._TEST['url'])
    assert ie.IE_NAME == 'soundgasm'



# Generated at 2022-06-24 13:09:57.705003
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # test the constructor of class SoundgasmProfileIE
    # to make sure that it correctly extracts the url
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    # when initializing the class SoundgasmProfileIE, the value of profile_id should be 'ytdl'.
    SoundgasmProfileIE._TEST = {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    ie = SoundgasmProfileIE(url)

# Generated at 2022-06-24 13:10:08.620871
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Initialise a new SoundgasmIE object
    ie = SoundgasmIE()
    # Check if the object is instance of SoundgasmIE
    assert isinstance(ie, SoundgasmIE)
    # Check for the attribute '_VALID_URL'
    assert hasattr(ie, '_VALID_URL')
    # Check for the value of attribute '_VALID_URL'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    # Check for the attribute 'IE_NAME'
    assert hasattr(ie, 'IE_NAME')
    # Check for the value of attribute 'IE_NAME'
   

# Generated at 2022-06-24 13:10:17.610149
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE['display_id'] == 'soundgasm.net'
    assert SoundgasmIE['title'] == 'Soundgasm'
    assert SoundgasmIE['extractor'] == 'soundgasm'
    assert SoundgasmIE['_VALID_URL'] == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:10:20.271401
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	test_obj = SoundgasmProfileIE('test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test')
	assert test_obj.ie_key == 'Soundgasm'

# Generated at 2022-06-24 13:10:20.722540
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	pass

# Generated at 2022-06-24 13:10:26.352956
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE("http://soundgasm.net/u/ytdl", "test")
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert ie._TEST['info_dict']['id'] == 'ytdl'
    assert ie._TEST['playlist_count'] == 1


# Generated at 2022-06-24 13:10:31.998405
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = "https://soundgasm.net/u/ytdl?value=0"
    ie = SoundgasmProfileIE(url, "Soundgasm")
    #print("ie._match_id(url=%s): %s" % (url, ie._match_id(url)))
    assert ie._match_id(url) == "ytdl"

# Generated at 2022-06-24 13:10:40.724225
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    i = SoundgasmIE()
    assert i.IE_NAME == 'soundgasm'
    assert i._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:10:46.525629
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE(SoundgasmIE._VALID_URL, 'Soundgasm')
    mobj = re.match(soundgasm._VALID_URL, SoundgasmIE._TEST['url'])
    assert soundgasm._real_extract(SoundgasmIE._TEST['url']) == SoundgasmIE._TEST['info_dict']

# Generated at 2022-06-24 13:10:48.269609
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_test = SoundgasmProfileIE('test')
    assert profile_test.IE_NAME == 'Soundgasm'

# Generated at 2022-06-24 13:10:48.847895
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()

# Generated at 2022-06-24 13:10:52.833585
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # This is a sample audio link from user ytdl
    link = 'http://soundgasm.net/u/ytdl/Piano-sample'
    print("Testing SoundgasmIE(%s) ... " % link)
    soundgasm_ie = SoundgasmIE(link)
    print("Testing done")
    return


# Generated at 2022-06-24 13:10:56.223235
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    obj_sg = SoundgasmIE('Soundgasm')
    assert obj_sg._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-24 13:10:58.427872
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.__name__ == 'Soundgasm Profile'

# Generated at 2022-06-24 13:11:04.964486
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasmIEInstance = SoundgasmProfileIE();
    assert soundgasmIEInstance.IE_NAME == 'soundgasm:profile', 'IE_NAME is not correctly initialized'
    assert soundgasmIEInstance._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$', '_VALID_URL is not correctly initialized'

# Generated at 2022-06-24 13:11:07.874292
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == [
        'http://soundgasm.net/u/ytdl/', 'http://soundgasm.net/u/ytdl/Piano-sample'
    ]

# Generated at 2022-06-24 13:11:09.912523
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_object = SoundgasmIE()
    assert re.search(r'soundgasm\.net/u/\w+/\w+', test_object._VALID_URL)

# Generated at 2022-06-24 13:11:13.414073
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE = SoundgasmProfileIE(callback=None, downloader=None)
    SoundgasmProfileIE._real_extract(None, 'http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:11:15.361633
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(None)
    assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:11:19.994056
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    tester = SoundgasmIE()
    testURL = 'http://soundgasm.net/u/ytdl/Piano-sample'
    result = tester._real_extract(testURL)
    assert(result['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9')

# Generated at 2022-06-24 13:11:21.650592
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:11:28.074931
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .test_downloads import real_extract
    # Have to use real URLs for unit test
    urls = [
        'http://soundgasm.net/u/ytdl',
        'http://soundgasm.net/u/ytdl/',
    ]
    for url in urls:
        real_extract(SoundgasmProfileIE.ie_key(), url)

# Generated at 2022-06-24 13:11:28.701705
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:11:36.489637
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	# Create an instance of the class SoundgasmProfileIE
	instance = SoundgasmProfileIE()

	# Call method _match_id
	instance._match_id('http://soundgasm.net/u/ytdl')

	# Call method _real_extract
	instance._real_extract('http://soundgasm.net/u/ytdl')

	# Call method playlist_result
	instance.playlist_result('http://soundgasm.net/u/ytdl', 'ytdl')

	# Call method url_result
	instance.url_result('http://soundgasm.net/u/ytdl/Piano-sample', 'Soundgasm')


# Generated at 2022-06-24 13:11:39.661264
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    check_str = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE(check_str)
    assert isinstance(ie, SoundgasmIE), "Incorrect class being assigned"

# Generated at 2022-06-24 13:11:44.003222
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    assert sg._VALID_URL == 'https?://(?:www\\.)?soundgasm\\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:11:47.357821
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test SoundgasmProfileIE.__init__
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:11:48.221985
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import test_constructor
    test_constructor(SoundgasmProfileIE)

# Generated at 2022-06-24 13:11:54.034421
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE("http://soundgasm.net/u/ytdl", "SoundgasmProfileIE")

# Generated at 2022-06-24 13:11:54.766454
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE.test()


# Generated at 2022-06-24 13:12:00.135317
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ''' Unit tests for constructor of class SoundgasmProfileIE '''
    # Constructor testcase 1
    testcase1 = SoundgasmProfileIE(test_SoundgasmProfileIE)
    assert testcase1._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

    # Constructor testcase 2
    testcase2 = SoundgasmProfileIE(test_SoundgasmProfileIE, test_SoundgasmProfileIE)
    assert testcase2._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

    # Constructor testcase 3

# Generated at 2022-06-24 13:12:04.118175
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    se = SoundgasmIE()
    se._download_webpage = lambda url, display_id: ''
    se._search_regex = lambda pattern, string, name, default=None, fatal=True, flags=0: '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    se._html_search_regex = lambda pattern, string, name, default=None, fatal=True, flags=0: '010082a2c802c5275bb00030743e75ad'
    se.extract(url)

# Generated at 2022-06-24 13:12:05.015146
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 13:12:06.716584
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    m = SoundgasmProfileIE('http://www.soundgasm.net/u/ytdl', {}, {}, {})
    assert m.IE_NAME == 'soundgasm:profile'
    assert isinstance(m, InfoExtractor)

# Generated at 2022-06-24 13:12:08.421328
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().extract(test_SoundgasmIE._TEST['url']) == test_SoundgasmIE._TEST


# Generated at 2022-06-24 13:12:20.358228
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == 'Soundgasm'
    assert SoundgasmIE()._VALID_URL == '^https?://(?:www\.)?soundgasm\.net/u/([0-9a-zA-Z_-]+)/([0-9a-zA-Z_-]+)'
    assert SoundgasmIE()._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert SoundgasmIE()._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'
    assert SoundgasmIE()._TEST['info_dict']['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert SoundgasmIE()._

# Generated at 2022-06-24 13:12:23.173805
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    # Success: no exception
    ie._match_id('http://soundgasm.net/u/ytdl/')

# Generated at 2022-06-24 13:12:29.489436
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from youtube_dl.compat import compat_urlparse
    sg_ie = SoundgasmIE()
    assert sg_ie.IE_NAME == 'soundgasm'
    assert sg_ie._VALID_URL.replace('https?://www.soundgasm.net', 'https://soundgasm.net') == compat_urlparse.urljoin('https://soundgasm.net/', r'u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-24 13:12:32.649743
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    tester = SoundgasmIE()
    sample_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    tester.download(sample_url)
    assert(tester._match_id(sample_url) == 'Piano-sample')

# Generated at 2022-06-24 13:12:35.915352
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('SoundgasmProfileIE', SoundgasmProfileIE._VALID_URL, 'username').extract('http://soundgasm.net/u/username')


# Generated at 2022-06-24 13:12:43.318191
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    e = SoundgasmIE()
    test = e.suite()
    import sys
    import os
    # to run a single unit test, you can use the following:
    # from py import test
    # test.cmdline.main(['-x', os.path.basename(__file__), '-s', 'test_SoundgasmIE'])
    # the -x flag should be replaced by -k in order to run the unit test with the same name
    #  as the function
    # the -s flag should be replaced by -k in order to run the unit test with the same name
    #  as the function
    if sys.version_info >= (3,):
        # actually do nothing other than make it run on Python 3
        # (this is because the test function doesn't have a return)
        assert test

# Generated at 2022-06-24 13:12:44.238985
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()

# Generated at 2022-06-24 13:12:45.277694
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	SoundgasmProfileIE()

# Generated at 2022-06-24 13:12:53.426100
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    sample = "http://soundgasm.net/u/ytdl/Piano-sample?autoplay=true"
    sg_obj = SoundgasmIE(None)
    assert sg_obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert sg_obj._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'


# Generated at 2022-06-24 13:13:02.338785
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'http://(?:www\.)?soundgasm\.net/u/(?P<id>[0-9a-zA-Z_-]+)/?(?:\#.*)?$'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert ie._TEST['playlist_count'] == 1
    # Check to make sure the class initilization is correct
    assert ie.suitable(test_url)
    test_url2 = 'http://soundgasm.net/u/ytdl/'

# Generated at 2022-06-24 13:13:12.203603
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Init
    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    audio_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    audio_url = 'http://s3.amazonaws.com/audio.soundgasm.net/u/ytdl/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    display_id = 'Piano-sample'
    title = 'Piano sample'
    description = 'Royalty Free Sample Music'
    uploader = 'ytdl'

    # Begin
    soundgasm_ie = SoundgasmIE()
    info_dict = soundgasm_ie._real_extract(test_url)

   

# Generated at 2022-06-24 13:13:17.469458
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test the SoundgasmProfileIE constructor
    ie = SoundgasmProfileIE(SoundgasmProfileIE.ie_key())
    assert ie.ie_key() == SoundgasmProfileIE.ie_key()
    assert ie.suitable(SoundgasmProfileIE._VALID_URL)
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.IE_DESC == 'soundgasm profiles'

# Generated at 2022-06-24 13:13:19.936257
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    assert isinstance(obj, SoundgasmIE)
    assert obj._VALID_URL is not None
    assert obj._TEST is not None

# Generated at 2022-06-24 13:13:26.496450
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Bad URL
    bad_url = 'http://soundgasm.net'
    bad_ie = SoundgasmIE(bad_url)
    assert bad_ie.isValid() == False
    good_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    good_ie = SoundgasmIE(good_url)
    assert good_ie.isValid() == True


# Generated at 2022-06-24 13:13:33.716985
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    def check(expected_length, expected_keys):
        assert len(result) == expected_length
        for key in expected_keys:
            assert key in result

    # test the extractor in download mode
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    sg = SoundgasmIE().download(url)
    result = sg.result

    check(7, ['id', 'uploader', 'title', 'description', 'ext', 'vcodec', 'url'])

    # test the extractor in test mode
    sg = SoundgasmIE().test(url)
    result = sg.result
    check(7, ['id', 'uploader', 'title', 'description', 'ext', 'vcodec', 'url'])

# Generated at 2022-06-24 13:13:35.366552
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE("soundgasm.net/u/user123")
    assert ie != None

# Generated at 2022-06-24 13:13:38.974092
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print("This is a test of SoundgasmProfileIE")
    test = SoundgasmProfileIE("http://www.youtube.com")
    if test is None:
        print("SoundgasmProfileIE is None")
    else:
        print("SoundgasmProfileIE is not None")

# Generated at 2022-06-24 13:13:43.063158
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test for when invalid URL is passed to constructor
    # i.e. regex of _VALID_URL fails to match URL
    invalid_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie_class = SoundgasmProfileIE(invalid_url, {})
    
    # Assert that invalid URL is in invalid_urls list
    assert invalid_url in ie_class.invalid_urls

# Generated at 2022-06-24 13:13:45.457302
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ytdl_url = 'http://soundgasm.net/u/ytdl'
    ytdl_inst = SoundgasmProfileIE()
    ytdl_match = ytdl_inst._match_id(ytdl_url)
    assert(ytdl_match == 'ytdl')

# Generated at 2022-06-24 13:13:46.976592
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE._TEST['url'], "unit test failed"

# Generated at 2022-06-24 13:13:49.472743
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:13:56.160065
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_url = 'http://soundgasm.net/u/ytdl'
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert SoundgasmProfileIE._TEST['url'] == soundgasm_url
    assert SoundgasmProfileIE._TEST['info_dict'] == {'id': 'ytdl'}

# Generated at 2022-06-24 13:14:04.595084
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(url=None, downloader=None)
    ie._downloader = None

# Generated at 2022-06-24 13:14:10.665527
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    #test_url = 'http://soundgasm.net/u/ytdl'
    #test_url = 'http://soundgasm.net/u'
    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    class_SoundgasmProfileIE = SoundgasmIE()
    result_obj = class_SoundgasmProfileIE._real_extract(test_url)
    print (result_obj)

# Generated at 2022-06-24 13:14:16.231169
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Need to test:
    #  * Uploader of the audio file
    #  * Description of the audio file
    #  * Audio id
    #  * Title of the audio
    assert SoundgasmIE()._VALID_URL == SoundgasmIE._VALID_URL
    assert SoundgasmIE()._TEST == SoundgasmIE._TEST


# Generated at 2022-06-24 13:14:19.467195
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    obj = SoundgasmIE()
    obj.match(test_url)
    obj.extract(test_url)

# Generated at 2022-06-24 13:14:20.627887
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE()

# Generated at 2022-06-24 13:14:26.672349
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE('token')
    a = SoundgasmIE._VALID_URL
    assert a == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert instance is not None
    

# Generated at 2022-06-24 13:14:27.623663
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = SoundgasmIE()

# Generated at 2022-06-24 13:14:31.230733
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-24 13:14:40.404183
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from unittest import TestCase
    from .common import MockIE

    class TestSoundgasmProfileIE(TestCase):
        def test_constructor(self):
            ige = MockIE(['http://soundgasm.net/u/ytdl'])
            sgpie = SoundgasmProfileIE(ige)

            soundgasm_url = 'http://soundgasm.net/u/ytdl'
            self.assertEqual(sgpie.IE_NAME, 'soundgasm:profile')
            self.assertTrue(sgpie._VALID_URL)
            self.assertRegexpMatches(soundgasm_url, sgpie._VALID_URL)

            # Test the _real_extract method
            sgpie._real_extract(soundgasm_url)
            self.assertListEqual

# Generated at 2022-06-24 13:14:42.951018
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	url = "http://soundgasm.net/u/ytdl"
	soundgasm_profile = SoundgasmProfileIE()
	soundgasm_profile._real_extract(url)


# Generated at 2022-06-24 13:14:50.194558
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:14:57.701169
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # For the constructor(self, ie_key, url) of InfoExtractor, ie_key is needed.
    # Get it from class SoundgasmIE.
    ie_key = SoundgasmIE.ie_key()

    # Then, we can pass the ie_key and url to the constructor of InfoExtractor as
    # follows.
    sgie = SoundgasmIE(ie_key, 'http://soundgasm.net/u/ytdl/Piano-sample')

    # print the info_dict of return of sgie._real_extract(sgie._match_id(url)).
    print(sgie._real_extract(sgie._match_id(sgie._url))['info_dict'])


# Generated at 2022-06-24 13:15:05.348269
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio_url = 'soundgasm.net/u/ytdl/Piano-sample'
    audio_url_title = 'Royalty Free Sample Music'
    audio_url_description = 'Piano sample'
    audio_url_uploader = 'ytdl'
    audio_url_display_id = 'Piano-sample'

    # Make sure that arguments are valid.
    audio_url_dict = SoundgasmIE._build_url_result(audio_url, audio_url_title, audio_url_description, audio_url_uploader, audio_url_display_id)

    return

# Generated at 2022-06-24 13:15:14.304870
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    webpage = "Whatever string that we don't need"
    audio_id = "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
    title = 'Piano sample'
    description = 'Royalty Free Sample Music'
    audio_url_found = 'http://d1klcyzc6ykq17.cloudfront.net/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'

# Generated at 2022-06-24 13:15:17.127734
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest
    class test_class(unittest.TestCase):
        def test_SoundgasmProfileIE_constructor(self):
            SoundgasmProfileIE(None)._downloader

# Generated at 2022-06-24 13:15:17.783890
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
   sv = SoundgasmProfileIE()

# Generated at 2022-06-24 13:15:19.882368
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    obj = SoundgasmIE().url_result(url)
    assert obj.get('vcodec') == 'none'
    assert obj.get('uploader') == 'ytdl'

# Generated at 2022-06-24 13:15:27.312259
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'
    webpage = "link to <a href='http://soundgasm.net/u/ytdl/sunrise'>sunrise</a>"
    entries = [
        'http://soundgasm.net/u/ytdl/sunrise'
    ]
    result = SoundgasmProfileIE._real_extract(None, url, profile_id, webpage, entries)
    pass

# Generated at 2022-06-24 13:15:30.185681
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .test_downloader import get_testcases
    testcase = get_testcases(SoundgasmProfileIE, filename='SoundgasmProfileIE.json')
    for t in testcase:
        yield t

# Generated at 2022-06-24 13:15:32.553029
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from . import Faker
    url = 'http://www.soundgasm.net/u/ytdl'
    _, __ = Faker.test_extractor(SoundgasmProfileIE, url)

# Generated at 2022-06-24 13:15:44.168762
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Constructor: SoundgasmProfileIE(self, name, ie)
    testObject = SoundgasmProfileIE(_downloader=None, name='SoundgasmProfileIE', ie='SoundgasmProfileIE')
    # Method: test_class
    # In this test case, the url is: http://soundgasm.net/u/ytdl
    test_url = 'http://soundgasm.net/u/ytdl'
    # This expected result is a dictionary
    expected_result = {
        'id': 'ytdl'
    }
    # The value of playlist_count is the number of items in the playlist
    test_playlist_count = 1
    # The result of method is a dictionary
    result = testObject._real_extract(test_url)
    assert result
    # Check that the items in the dictionary

# Generated at 2022-06-24 13:15:54.336805
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    data_url = "http://soundgasm.net/u/ytdl/Sample-Piano-Loop"
    data_info = {
        'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
        'ext': 'm4a',
        'title': 'Sample Piano Loop',
        'description': 'Royalty Free Sample Music',
        'uploader': 'ytdl',
    }
    data_name = 'Soundgasm'
    data_ie = SoundgasmIE()
    o = data_ie.extract(data_url)
    assert o['id'] == data_info['id']
    assert o['ext'] == data_info['ext']
    assert o['title'] == data_info['title']
    assert o['description'] == data_info

# Generated at 2022-06-24 13:15:58.693019
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        SoundgasmProfileIE('http://soundgasm.net/u/ytdl', {}, {})
    except:
        raise
    assert('http://soundgasm.net/u/ytdl' == SoundgasmProfileIE('http://soundgasm.net/u/ytdl', {}, {})._VALID_URL)

# Generated at 2022-06-24 13:16:00.667192
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE("hi")
    assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:16:05.412682
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    audio_url = r'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmProfileIE(None)
    result = ie._real_extract(audio_url)
    assert result['id'] == 'ytdl'



# Generated at 2022-06-24 13:16:16.261322
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import json
    IE = SoundgasmProfileIE()
    # Testing for successful initialization
    assert IE.ie_key() == 'Soundgasm'
    assert IE.ie_name() == 'Soundgasm'
    # Testing for expected output from _VALID_URL and _TEST
    IE = SoundgasmProfileIE('Soundgasm:profile')
    assert IE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert json.loads(json.dumps(IE._TEST)) == {"url": "http://soundgasm.net/u/ytdl", "info_dict": {"id": "ytdl"}, "playlist_count": 1}
    # Testing for expected output from _real_extract

# Generated at 2022-06-24 13:16:25.668915
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    o = SoundgasmIE()
    assert o.ie_key() == 'Soundgasm'
    assert o.ie_name() == 'Soundgasm'
    assert o.ie_description() == 'Soundgasm'
    assert o.is_suitable(None)
    assert o.is_suitable('http://soundgasm.net/u/ytdl/Piano-sample') is True
    assert o.is_suitable('http://soundgasm.net/u/ytdl') is False
    assert o.is_suitable('http://soundgasm.net/u/ytdl?_escaped_fragment_=') is False
    assert o.is_suitable('http://soundgasm.net/u/ytdl#_=_') is False

# Generated at 2022-06-24 13:16:30.182306
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # unit test for SoundgasmProfileIE
    # this test is located in :
    # test/test_download.py
    print('Unit test for SoundgasmProfileIE')
    print('load file test_download.py')
    import os
    os.system('python3 test/test_download.py')

# Generated at 2022-06-24 13:16:35.521973
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    #testurl = "http://soundgasm.net/u/ytdl/Piano-sample"
    testurl = "http://soundgasm.net/u/ytdl/Welcome-To-My-Channel"
    ie = SoundgasmIE()

# Generated at 2022-06-24 13:16:38.635877
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg = SoundgasmProfileIE()
    assert sg._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/([^/]+)/?(?:#.*)?$'



# Generated at 2022-06-24 13:16:44.905659
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_IE = SoundgasmProfileIE(None)

    assert soundgasm_profile_IE.IE_NAME == 'soundgasm:profile'
    assert soundgasm_profile_IE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:16:48.124896
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profileIE = SoundgasmProfileIE()
    assert soundgasm_profileIE.IE_NAME == 'soundgasm:profile'
    assert soundgasm_profileIE.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-24 13:16:49.584092
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://www.soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-24 13:16:51.323737
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:16:56.366532
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
   assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
   assert SoundgasmProfileIE._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}



# Generated at 2022-06-24 13:16:57.740605
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE()
        assert True
    except:
        assert False

# Generated at 2022-06-24 13:17:03.185589
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	from .common import InfoExtractor
	from .SoundgasmIE import SoundgasmIE
	assert SoundgasmIE('Soundgasm')._VALID_URL == SoundgasmIE._VALID_URL
	assert SoundgasmIE('Soundgasm')._TEST == SoundgasmIE._TEST
	assert SoundgasmIE('Soundgasm')._download_webpage == InfoExtractor._download_webpage


# Generated at 2022-06-24 13:17:07.586185
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg_profile=SoundgasmProfileIE()
    assert sg_profile._VALID_URL=='https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert sg_profile.IE_NAME=='soundgasm:profile'


# Generated at 2022-06-24 13:17:12.789130
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample') == {
		'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
		'ext': 'm4a',
		'title': 'Piano sample',
		'description': 'Royalty Free Sample Music',
		'uploader': 'ytdl',
	}


# Generated at 2022-06-24 13:17:14.007519
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert (SoundgasmIE().IE_NAME == 'soundgasm')



# Generated at 2022-06-24 13:17:17.282391
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    global sgp_ie
    sgp_ie = SoundgasmProfileIE()
    assert isinstance(sgp_ie, SoundgasmProfileIE)


# Generated at 2022-06-24 13:17:18.899610
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.IE_NAME == 'SoundgasmProfileIE'
    assert SoundgasmProfileIE.IE_NAME is not None
    assert SoundgasmProfileIE.IE_NAME != False
    assert SoundgasmProfileIE.IE_NAME is True

# Generated at 2022-06-24 13:17:19.450775
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:17:20.014230
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:17:21.805707
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Create a Video object
    audio = SoundgasmIE()
    assert audio.IE_NAME in ("Soundgasm")

# Generated at 2022-06-24 13:17:27.553238
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    #if you can't find the target website,you can check the url by typing:
    #python -m youtube_dl.extractor.soundgasm --print-json 'url'
    ie._downloader.params.update({'noplaylist': True})
    result = ie.extract('http://soundgasm.net/u/ytdl/Piano-sample')
    print(result)
test_SoundgasmIE()

# Generated at 2022-06-24 13:17:30.638077
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE()
    ie = ie.suitable(url)

# Generated at 2022-06-24 13:17:33.092424
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    # Instantiate SoundgasmProfileIE class
    SoundgasmProfileIE(url)


# Generated at 2022-06-24 13:17:34.319887
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE('')
    assert True

# Generated at 2022-06-24 13:17:36.474060
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """ Test that the constructor of SoundgasmProfileIE works. """
    assert SoundgasmProfileIE.ie_key() == 'Soundgasm:profile'

# Generated at 2022-06-24 13:17:40.332762
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	get_yt_url = 'https://en.wikipedia.org/wiki/YouTube'
	test_result = SoundgasmProfileIE(SoundgasmProfileIE, get_yt_url)
	assert test_result.IE_NAME == 'SoundgasmProfileIE'


# Generated at 2022-06-24 13:17:46.751500
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Using the file system, not downloading any file
    # test url: http://soundgasm.net/u/ytdl/Piano-sample
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE()
    soundgasm_info = ie.extract(url)
    print(soundgasm_info)


if __name__ == '__main__':
    test_SoundgasmIE()

# Generated at 2022-06-24 13:17:49.326349
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert isinstance(ie, SoundgasmProfileIE)


# Generated at 2022-06-24 13:17:49.886720
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  pass

# Generated at 2022-06-24 13:17:51.296252
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    p = SoundgasmProfileIE('SoundgasmProfileIE')
    assert p is not None
    print(p)

# Generated at 2022-06-24 13:18:01.721229
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg_profileextract1 = SoundgasmProfileIE._real_extract(
        SoundgasmProfileIE(), 'http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:18:04.087301
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    _test = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    assert _test.IE_NAME == "Soundgasm"

# Generated at 2022-06-24 13:18:09.217005
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    # Create an instance of SoundgasmIE
    ie = SoundgasmIE()
    # Create an instance of InfoExtractor
    ieu = InfoExtractor()

    # Call method _download_webpage to get webpage of given url
    webpage = ie._download_webpage(url, 'Piano-sample')

    # Get audio url from webpage
    audio_url = ie._html_search_regex(
        r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', webpage,
            'audio URL', group='url')


# Generated at 2022-06-24 13:18:11.227236
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE("SoundgasmProfileIE", "soundgasm:profile")

# Generated at 2022-06-24 13:18:12.724212
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE()
    profile_id = profile._match_id('http://soundgasm.net/u/ytdl')
    assert profile_id == 'ytdl'

# Generated at 2022-06-24 13:18:14.461477
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE(None)
    assert ie.IE_NAME == 'Soundgasm'

# Generated at 2022-06-24 13:18:22.195185
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test the constructor of class SoundgasmProfileIE.
    # If the constructor works, the instance of the class will be returned.
    # The constructor of the class should work.
    soundgasm_profile_ie = SoundgasmProfileIE()
    # If the attributes of the returned instance do not match the expected
    # values, an error will be raised.
    assert soundgasm_profile_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'