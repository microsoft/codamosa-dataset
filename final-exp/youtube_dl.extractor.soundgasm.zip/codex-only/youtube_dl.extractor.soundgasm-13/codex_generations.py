

# Generated at 2022-06-24 13:08:23.388402
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-24 13:08:29.347407
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info = SoundgasmProfileIE().extract(r'https://soundgasm.net/u/ytdl')
    assert info['id'] == 'ytdl'
    assert len(info['entries']) == 1
    assert info['entries'][0]['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-24 13:08:31.717158
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()
    assert SoundgasmProfileIE.IE_NAME == obj.ie_key()
    return 0

# Generated at 2022-06-24 13:08:32.698881
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-24 13:08:34.584013
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-24 13:08:41.650333
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Initialize SoundgasmProfileIE object with a valid url
    obj = SoundgasmProfileIE()
    obj._download_webpage = lambda a, b: "test data"
    obj._match_id = lambda a: "test id"
    result = obj.url_result("test url", "Soundgasm")
    assert result["url"] == "test url"
    assert result["ie_key"] == "Soundgasm"
    assert obj.playlist_count == 1
    assert obj.playlist_result(["test url"], "test id")["id"] == "test id"
    assert obj._real_extract("test url")

# Generated at 2022-06-24 13:08:45.582878
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'



# Generated at 2022-06-24 13:08:53.655123
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	from youtube_dl.extractor.soundgasm import SoundgasmProfileIE
	test_object = SoundgasmProfileIE(None)

	assert test_object._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
	assert test_object._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-24 13:08:58.485388
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:09:01.759878
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    entry = SoundgasmIE().IE_NAME
    if entry == 'soundgasm':
        print("Test for constructor of class SoundgasmIE is passed.")
    else:
        print("Test for constructor of class SoundgasmIE is failed.")


# Generated at 2022-06-24 13:09:02.529380
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:09:10.061835
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    # Valid URL
    assert re.match(ie._VALID_URL, "http://soundgasm.net/u/ytdl/Piano-sample")
    # Invalid URL
    assert re.match(ie._VALID_URL, "http://soundgasm.net/u/ytdl/Piano-sample/something-else") == None
    # Invalid URL
    assert re.match(ie._VALID_URL, "http://soundgasm.net/u/ytdl/Piano-sample/") == None

# Generated at 2022-06-24 13:09:20.628741
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    extractor = SoundgasmIE()
    assert extractor.suitable(url)
    assert extractor.IE_NAME == "Soundgasm"
    assert extractor._VALID_URL == "https?://(?:www\\.)?soundgasm\\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)"
    assert extractor._TEST['url'] == "http://soundgasm.net/u/ytdl/Piano-sample"
    assert extractor._TEST['md5'] == "010082a2c802c5275bb00030743e75ad"

# Generated at 2022-06-24 13:09:22.570951
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg_profileIE = SoundgasmProfileIE()
    assert sg_profileIE
    assert isinstance(sg_profileIE, SoundgasmProfileIE)


# Generated at 2022-06-24 13:09:24.357049
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profileIE = SoundgasmProfileIE(None, None)

    assert soundgasm_profileIE.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:09:31.230485
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_object = SoundgasmProfileIE()
    assert test_object.IE_NAME == SoundgasmProfileIE.IE_NAME
    assert test_object._VALID_URL == SoundgasmProfileIE._VALID_URL
    assert test_object.TITLE == SoundgasmProfileIE.TITLE
    assert test_object.THUMBNAIL == SoundgasmProfileIE.THUMBNAIL

# Generated at 2022-06-24 13:09:31.785329
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:09:39.970595
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasmProfileIE = SoundgasmProfileIE(_download_webpage=None)
    assert soundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert soundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert soundgasmProfileIE._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-24 13:09:49.018689
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert SoundgasmIE._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'#
    assert SoundgasmIE._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'
    assert SoundgasmIE._TEST['info_dict']['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-24 13:09:56.816949
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl', 'Soundgasm')
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-24 13:10:01.559025
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('ytdl', u'http://soundgasm.net/u/ytdl/Piano-sample/')

    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:10:10.582769
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg_example_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    sg_profile_url = 'http://soundgasm.net/u/ytdl'
    sg_profile_2_url = 'http://soundgasm.net/u/ytdl/#_=_'

    sg = SoundgasmIE()
    sg_profile = SoundgasmProfileIE()
    
    result = sg.suitable(sg_example_url) or sg_profile.suitable(sg_profile_url) or sg_profile.suitable(sg_profile_2_url)
    assert(result)

# Generated at 2022-06-24 13:10:20.602112
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # TODO: remove this once it is fixed in git
    # remove the following lines once it is fixed
    # https://github.com/rg3/youtube-dl/issues/7665
    info_dict = {
        'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
        'ext': 'm4a',
        'uploader': 'ytdl',
        'title': 'Piano sample',
        'description': 'Royalty Free Sample Music',
    }
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    instance = SoundgasmIE()
    file = instance._real_extract(url)
    for key in info_dict:
        assert(info_dict[key] == file[key])
    #

# Generated at 2022-06-24 13:10:27.263952
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_Test = SoundgasmProfileIE()
    # Check if the attribute id of the class is set correctly
    if profile_Test.IE_NAME != 'soundgasm:profile':
        print('Fail - id attribute is not set correctly')
    else:
        print('Pass - id attribute is set correctly')
    # Check if the the regular expression for valid URL is set correctly
    if profile_Test._VALID_URL != 'https?://(?:www\\.)?soundgasm\\.net/u/(?P<id>[^/]+)/?(?:\\#.*)?$':
        print('Fail - _VALID_URL attribute is not set correctly')
    else:
        print('Pass - _VALID_URL attribute is set correctly')
    # Check if the attribute _TEST is set correctly

# Generated at 2022-06-24 13:10:31.478277
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('soundgasm:profile')
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:10:33.592471
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert 'http://soundgasm.net/u/ytdl/Piano-sample' == ie._VALID_URL

# Generated at 2022-06-24 13:10:35.560142
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('SoundgasmProfileIE', 'http://soundgasm.net/u/ytdl')
    assert ie.IE_NAME == 'SoundgasmProfileIE'

# Generated at 2022-06-24 13:10:37.064996
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-24 13:10:43.003961
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    path = ('http://soundgasm.net/u/ytdl/Piano-sample')

    # Tested with Python 2.7.8 and Python 3.4.1
    print("Testing instantiating SoundgasmIE:")
    ie = SoundgasmIE(SoundgasmIE._create_ie_instance())
    info = ie._real_extract(path)

# Generated at 2022-06-24 13:10:51.132004
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie_instance = SoundgasmProfileIE('http://soundgasm.net/u/ytdl', 'test')
    assert ie_instance._VALID_URL == 'http://soundgasm.net/u/ytdl/?'
    assert ie_instance._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert ie_instance.IE_NAME == 'soundgasm:profile'
    webpage = ie_instance._download_webpage('http://soundgasm.net/u/ytdl', 'ytdl')
    assert '<ul class="list-group">' in webpage


# Generated at 2022-06-24 13:10:59.262816
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    #Tests for SoundgasmIE.__init__(self, url)
    def test_url_property():
        """Test for SoundgasmIE.url property"""

        #Test for SoundgasmIE.url property of SoundgasmIE object
        def test_url_check():
            """Test for SoundgasmIE.url property: Check if the url property is right"""
            test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
            ieObject = SoundgasmIE(test_url)
            if ieObject.url != test_url:
                raise Exception("Bad url property: " + ieObject.url)

        #Test for SoundgasmIE.url property: Check if the SoundgasmIE object can be created with an empty url

# Generated at 2022-06-24 13:11:00.805243
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_instance = SoundgasmIE()
    assert test_instance

# Generated at 2022-06-24 13:11:04.164854
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    obj = SoundgasmProfileIE._real_extract(SoundgasmProfileIE(), url)
    assert obj['id'] is 'ytdl'

# Generated at 2022-06-24 13:11:07.989571
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
   print("Unit test for constructor of class SoundgasmIE")
   url = "http://soundgasm.net/u/ytdl/Piano-sample"
   obj = SoundgasmIE()
   result = obj._real_extract(url)
   print(result)


# Generated at 2022-06-24 13:11:09.739146
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Basic test for class SoundgasmProfileIE

    """
    assert SoundgasmProfileIE().IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:11:20.458654
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	from .extractors import SoundgasmProfileIE
	from .extractors import SoundgasmIE
	from .extractors import _test_preload
	from .extractors import _test_preload_multi

	ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
	assert ie._VALID_URL == SoundgasmProfileIE._VALID_URL
	_test_preload(ie)
	#assert repr(ie) == '<SoundgasmProfileIE http://soundgasm.net/u/ytdl>'
	#assert str(ie) == 'http://soundgasm.net/u/ytdl'
	#assert ie.__class__ == SoundgasmProfileIE

# Generated at 2022-06-24 13:11:23.155626
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	test_SoundgasmIE = SoundgasmIE()
	assert test_SoundgasmIE.IE_NAME == 'soundgasm'
	assert test_SoundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-24 13:11:25.030975
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    unit_test = SoundgasmProfileIE()
    print(unit_test._VALID_URL)

# Constructor of class SoundgasmProfileIE
test_SoundgasmProfileIE()

# Generated at 2022-06-24 13:11:30.929819
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print("Testing class SoundgasmProfileIE")
    audio_url = "http://soundgasm.net/u/ytdl"

    # Testing the constructor of class SoundgasmProfileIE
    assert issubclass(SoundgasmProfileIE, InfoExtractor)
    ie = SoundgasmProfileIE()

    # Testing _real_extract
    result = ie._real_extract(audio_url)
    assert len(result['entries']) > 0

# Generated at 2022-06-24 13:11:32.331062
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert isinstance(ie, SoundgasmIE)

# Generated at 2022-06-24 13:11:38.921915
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test url = 'http://soundgasm.net/u/ytdl'
    # Test profile_id = 'ytdl'
    # Test webpage = '<div class="jp-download"><a href="/u/ytdl/Piano-sample"><span>Download Audio</span></a></div>'
    class SoundgasmProfileIE_test(InfoExtractor):
        # _match_id(url)
        def _match_id(self, url):
            mobj = re.match(self._VALID_URL, url)
            return mobj.group('id')
        # _download_webpage(url, display_id)
        def _download_webpage(self, url, display_id):
            return webpage
    # Test entries = ['http://soundgasm.net/u/ytdl/Piano-

# Generated at 2022-06-24 13:11:42.767459
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ieTest = SoundgasmProfileIE('', SoundgasmProfileIE._VALID_URL)
    assert ieTest._match_id('http://soundgasm.net/u/ytdl') == 'ytdl'


# Generated at 2022-06-24 13:11:46.858922
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# Initialize SoundgasmIE from an URL and test it's title
	soundgasm = SoundgasmIE()
	result = soundgasm.extract(
		'http://soundgasm.net/u/ytdl/Piano-sample')
	assert result.get('title') == 'Piano sample'


# Generated at 2022-06-24 13:11:47.557137
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-24 13:11:49.055135
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    print(vars(ie))


# Generated at 2022-06-24 13:11:49.649543
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE()
    assert True

# Generated at 2022-06-24 13:11:53.492782
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Unit test for constructor of class SoundgasmIE"""
    print('Executing test for constructor of SoundgasmIE')
    test_urls = ['http://soundgasm.net/u/ytdl/Piano-sample']
    IE = SoundgasmIE()
    for url in test_urls:
        assert(re.match(IE._VALID_URL, url) != None)

# Generated at 2022-06-24 13:11:55.314626
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()._download_webpage('http://soundgasm.net/u/ytdl/Piano-sample', 'Piano-sample')


# Generated at 2022-06-24 13:11:56.867363
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        SoundgasmProfileIE()()
    except:
        assert False

# Generated at 2022-06-24 13:12:00.073071
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()._VALID_URL == SoundgasmIE._VALID_URL
    assert SoundgasmIE()._TEST == SoundgasmIE._TEST

# Generated at 2022-06-24 13:12:05.299290
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert(SoundgasmIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')
    assert(SoundgasmIE.IE_NAME == 'soundgasm')
    assert(SoundgasmIE.__name__ == 'SoundgasmIE')
    return


# Generated at 2022-06-24 13:12:06.109488
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profileIE = SoundgasmProfileIE(InfoExtractor())

# Generated at 2022-06-24 13:12:09.486074
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	yt_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
	xt = SoundgasmIE()

	# Testing url, options and download_webpage
	if xt.suitable(yt_url):
		# test download method
		xt.download(yt_url)


# Generated at 2022-06-24 13:12:11.533366
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('Soundgasm:profile')
    assert ie.name == 'Soundgasm:Profile'

# Generated at 2022-06-24 13:12:15.588249
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    s = SoundgasmIE()
    #print(s.__class__.__mro__)
    #print(s.__class__)
    #print(s.__class__.__name__)
    #s.download()


# Generated at 2022-06-24 13:12:18.337342
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:12:25.484498
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sgIE = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample', 'http://soundgasm.net/u/ytdl/Piano-sample')
    assert sgIE.IE_NAME == 'Soundgasm'
    assert sgIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:12:31.754072
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Unit test for constructor of class SoundgasmIE
    """
    test_object = SoundgasmIE()
    # Assert that regex for finding audio URL is correct
    assert test_object._html_search_regex(r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', "<script>var audio_url = 'http://example.com/url.m4a';</script>", 'audio URL', group='url') == 'http://example.com/url.m4a'


# Generated at 2022-06-24 13:12:40.556488
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """ Test case for SoundgasmIE """
    info_extractor = SoundgasmIE(None)
    assert(info_extractor.IE_NAME == 'soundgasm')
    assert(info_extractor._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')
    assert(SoundgasmIE._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample')
    assert(SoundgasmIE._TEST['md5'] == '010082a2c802c5275bb00030743e75ad')

# Generated at 2022-06-24 13:12:42.927393
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import test_urls, test_extractors
    for url in test_urls('soundgasm:profile'):
        test_extractors({'soundgasm:profile': SoundgasmProfileIE})(url)

# Generated at 2022-06-24 13:12:49.095315
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    try:
        webpage_url = 'http://soundgasm.net/u/ytdl'
        webpage_url2 = 'http://soundgasm.net/u/ytdl/Piano-sample'

        # Create object Audio
        test = SoundgasmIE()._real_extract(webpage_url)
        test2 = SoundgasmIE()._real_extract(webpage_url2)
        return test, test2
    except Exception:
        return False


# Generated at 2022-06-24 13:12:50.538073
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE()
    except:
        return False
    return True

# Generated at 2022-06-24 13:12:54.112744
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:12:54.707115
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	pass

# Generated at 2022-06-24 13:12:59.968181
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'
    webpage = 'http://soundgasm.net/u/ytdl/Piano-sample'
    entries = [
        'http://soundgasm.net/u/ytdl/Piano-sample'
    ]
    assert SoundgasmProfileIE(url,profile_id,webpage) == entries

# Generated at 2022-06-24 13:13:00.744162
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:13:07.379938
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile = SoundgasmProfileIE()
    # You may want to add more assert statements
    assert profile._VALID_URL == 'https?://(?:www\\.)?soundgasm\\.net/u/(?P<id>[^/]+)/?(?:\\#.*)?$'
    assert profile._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert profile._TEST['info_dict']['id'] == 'ytdl'
    assert profile._TEST['playlist_count'] == 1

# Generated at 2022-06-24 13:13:11.877828
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj_soundgasm = SoundgasmIE()
    assert obj_soundgasm._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    #assert obj_soundgasm._TEST == {'url': 'http://soundgasm.net/u/ytdl/Piano-sample', 'md5': '010082a2c802c5275bb00030743e75ad', 'info_dict': {'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9', 'ext': 'm4a', 'title': 'Piano sample', 'description': 'Royalty Free Sample Music

# Generated at 2022-06-24 13:13:20.729181
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_obj = SoundgasmIE()
    assert(test_obj.IE_NAME) == 'SoundGasm'
    assert(test_obj._VALID_URL) == r'https?://(?:www\.)?SoundGasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert(test_obj._TEST.get('url')) == 'http://SoundGasm.net/u/ytdl/Piano-sample'
    assert(test_obj._TEST.get('md5')) == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-24 13:13:31.096905
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(None)
    assert ie.name == 'soundgasm:profile'
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    assert ie._match_id('id') == 'id'
    assert ie._download_webpage('url', 'name') == 'webpage'

# Generated at 2022-06-24 13:13:32.898460
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('http://www.soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:13:41.927336
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasmIE = SoundgasmIE()
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    assert soundgasmIE._VALID_URL == "https?://(?:www\\.)?soundgasm\\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)"
    result = soundgasmIE._real_extract(url)
    assert result.has_key("id")
    assert result.has_key("display_id")
    assert result.has_key("url")
    assert result.has_key("vcodec")
    assert result.has_key("title")
    assert result.has_key("description")

# Generated at 2022-06-24 13:13:42.800521
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE() != None

# Generated at 2022-06-24 13:13:50.367083
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = SoundgasmIE()
    assert test.IE_NAME == 'Soundgasm'
    assert test._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert test.IE_DESC == 'Soundgasm extracts audio from soundgasm.net'


# Generated at 2022-06-24 13:13:58.800315
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print ('\nStarting test for constructor ' + test_SoundgasmProfileIE.__name__)
    
    if (len(sys.argv) < 2):
        raise TypeError('The number of arguments is incorrect.')
    url = sys.argv[1]
    
    # Check the url
    if not re.match(SoundgasmProfileIE._VALID_URL, url):
        raise ValueError('The format of the URL provided is not valid.')
    
    # Call the constructor
    soundgasm_profile_ie = SoundgasmProfileIE()
    print ('\nExiting test for constructor ' + test_SoundgasmProfileIE.__name__)
    

# Generated at 2022-06-24 13:13:59.630228
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sgProfile = SoundgasmProfileIE()
    assert sgProfile is not None

# Generated at 2022-06-24 13:14:06.815962
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:14:09.984373
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasmIE = SoundgasmIE()
    assert soundgasmIE.suitable(url)

# Generated at 2022-06-24 13:14:13.121629
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    https://github.com/rg3/youtube-dl/issues/8003
    """
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:14:15.332223
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None)._real_extract('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:14:20.978773
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    user = SoundgasmProfileIE('http://soundgasm.net/u/ytdl', {})
    assert user._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert user.IE_NAME == 'soundgasm:profile'
    assert user.test['url'] == 'http://soundgasm.net/u/ytdl'
    assert user.test['info_dict']['id'] == 'ytdl'
    assert user.test['playlist_count'] == 1


# Generated at 2022-06-24 13:14:31.477559
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    _test_ie = SoundgasmIE()

    assert _test_ie.IE_NAME == 'soundgasm'
    assert _test_ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert _test_ie._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert _test_ie._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-24 13:14:32.458366
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    inst = SoundgasmProfileIE()
    assert inst

# Generated at 2022-06-24 13:14:36.208321
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    d = SoundgasmIE()
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    d.urlv = url

# Generated at 2022-06-24 13:14:40.383251
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Constructor test for SoundgasmIE
    """
    soundgasm_ie = SoundgasmIE("Simpson's soundgasm.net/u/ytdl/Piano-sample")
    assert soundgasm_ie.ie_key() == "Soundgasm"



# Generated at 2022-06-24 13:14:41.186015
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:14:45.388710
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'https://soundgasm.net/u/ytdl/Piano-sample'
    assert SoundgasmIE().suitable(url), 'SoundgasmIE is suitable'
    assert SoundgasmIE()._VALID_URL == url, 'Extract url is correct'
    assert SoundgasmIE()._TEST['url'] == url, 'Test url is correct'

# Generated at 2022-06-24 13:14:53.688375
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    x = SoundgasmProfileIE()
    assert x.name == 'soundgasm:profile'
    assert x.ie_key() == 'soundgasm:profile'
    assert x._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert x._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}


# Generated at 2022-06-24 13:15:01.807984
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Create an SoundgasmProfileIE instance
    SoundgasmProfile = SoundgasmProfileIE("test",test_SoundgasmProfileIE.url)
    # Download a webpage
    SoundgasmProfile.download("http://soundgasm.net/u/ytdl","http://soundgasm.net/u/ytdl")
    # Extract a key-value pair
    SoundgasmProfile.extract("test","test")
    # Extract a key-value pair with no value
    SoundgasmProfile.extract("test",None)
    # Match an id
    SoundgasmProfile.match("http://soundgasm.net/u/ytdl")
    # Return a dictionary of results
    SoundgasmProfile.result("test","test","test")
    # Return a dictionary of playlist results
    SoundgasmProfile.playlist_result

# Generated at 2022-06-24 13:15:03.969361
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('http://soundgasm.net/u/ytdl', {}) != None

# Generated at 2022-06-24 13:15:08.058421
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    '''
    Unit test for constructor of class SoundgasmIE
    '''
    i = SoundgasmIE()
    assert i == [], "i should be an empty list"

if __name__ == '__main__':
    # Test function "test_SoundgasmIE()"
    test_SoundgasmIE()

# Generated at 2022-06-24 13:15:08.983541
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE() != None


# Generated at 2022-06-24 13:15:10.214648
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE.ie_key() == "Soundgasm"

# Generated at 2022-06-24 13:15:11.841735
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from tests.test_soundgasm import test_SoundgasmProfileIE
    test_SoundgasmProfileIE()

# Generated at 2022-06-24 13:15:15.386290
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Unit test for constructor of class SoundgasmProfileIE"""
    SoundgasmProfileIE('ytdl')
    SoundgasmProfileIE('ytdl','http://soundgasm.net/u/ytdl/')
    SoundgasmProfileIE('ytdl','http://soundgasm.net/u/ytdl')
    return True

# Generated at 2022-06-24 13:15:16.595810
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert_equal(ie.IE_NAME, 'soundgasm:profile')

# Generated at 2022-06-24 13:15:18.406785
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test = SoundgasmProfileIE()
    assert test.IE_NAME == 'Soundgasm Profile'

# Generated at 2022-06-24 13:15:20.418372
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm = InfoExtractor()
    assert isinstance(soundgasm, SoundgasmProfileIE)

# Generated at 2022-06-24 13:15:28.075147
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    s = SoundgasmProfileIE()
    assert s.IE_NAME == 'soundgasm:profile'
    assert s._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert s._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-24 13:15:29.525284
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.__name__ is 'SoundgasmProfileIE'

# Generated at 2022-06-24 13:15:30.608128
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None)

# Generated at 2022-06-24 13:15:31.927129
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().extract('http://soundgasm.net/u/ytdl/Piano-sample').get('title') == 'Piano sample'

# Generated at 2022-06-24 13:15:38.819569
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mobj = re.match(SoundgasmIE._VALID_URL, url)
    audio_id = SoundgasmIE._search_regex(SoundgasmIE._TEST['url'],SoundgasmIE._TEST['url'],'audio id')
    assert(audio_id == 'Piano-sample')

# Generated at 2022-06-24 13:15:39.875741
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()


# Generated at 2022-06-24 13:15:42.426122
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(None)
    assert SoundgasmProfileIE._VALID_URL == ie._VALID_URL

# Generated at 2022-06-24 13:15:47.521848
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    print('Testing soundgasm:profile')
    print(ie.extract('http://soundgasm.net/u/ytdl'))
    print('Testing soundgasm:profile')
    print(ie.extract('http://soundgasm.net/u/ytdl/'))

# Generated at 2022-06-24 13:15:56.420653
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:15:59.935187
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    argv = ['--username', 'ttonyc', '--password', '123456']
    SoundgasmIE()._downloader.add_default_info_extractors()
    SoundgasmIE()._downloader.parse_args(argv)

# Generated at 2022-06-24 13:16:11.297437
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasmIE = SoundgasmIE()
    # Test _VALID_URL
    valid_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    assert re.match(soundgasmIE._VALID_URL, valid_url)
    # Test _TEST
    assert soundgasmIE._TEST['url'] == "http://soundgasm.net/u/ytdl/Piano-sample"
    assert soundgasmIE._TEST['md5'] == "010082a2c802c5275bb00030743e75ad"
    assert soundgasmIE._TEST['info_dict']['id'] == "88abd86ea000cafe98f96321b23cc1206cbcbcc9"

# Generated at 2022-06-24 13:16:18.701390
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-24 13:16:20.063939
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	test = SoundgasmIE()
	return True

# Generated at 2022-06-24 13:16:24.143999
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE = SoundgasmProfileIE('ytuser')
    assert IE.IE_NAME == 'soundgasm:profile'
    assert IE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:16:26.967626
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Unit test for constructor of class SoundgasmProfileIE
    """
    obj_profile = SoundgasmProfileIE()
    assert obj_profile.ie_key() == "Soundgasm"

# Generated at 2022-06-24 13:16:30.897774
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Test constructor of class SoundgasmProfileIE"""
    obj = SoundgasmProfileIE('test')
    assert obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:16:32.875687
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == SoundgasmIE._VALID_URL

# Generated at 2022-06-24 13:16:38.633740
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    #Create object of class SoundgasmIE
    sgIE = SoundgasmIE("soundgasm.net")

    #Checking if object is of class SoundgasmIE
    assert isinstance(sgIE, SoundgasmIE)

    if hasattr(sgIE, "extractor"):
        extractor = sgIE.extractor

        #Checking if extractor is of class InfoExtractor
        assert isinstance(extractor, InfoExtractor)

# Generated at 2022-06-24 13:16:40.580376
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    i=SoundgasmProfileIE()
    assert i.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:16:45.130464
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .test_soundcloud import SoundCloudSetIE
    sg_test = SoundCloudSetIE()
    test = SoundgasmProfileIE()
    assert sg_test != test

#Unit test for method _real_extract of class SoundgasmProfileIE

# Generated at 2022-06-24 13:16:46.870909
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Constructor of SoundgasmProfileIE
    SoundgasmProfileIE()


# Generated at 2022-06-24 13:16:48.596440
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    clazz = SoundgasmProfileIE

# Generated at 2022-06-24 13:16:52.864610
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    # Create instance of class SoundgasmProfileIE
    inst = SoundgasmProfileIE(url)

# Generated at 2022-06-24 13:16:55.486445
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info = SoundgasmProfileIE()._real_extract(r'http://soundgasm.net/u/ytdl')
    assert info['id'] == 'ytdl'

# Generated at 2022-06-24 13:16:55.966807
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert True

# Generated at 2022-06-24 13:17:04.572726
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/profile/ytdl'
    SoundgasmIE()._download_webpage(url, "ytdl")
    # Test case for downloading webpage
    SoundgasmIE()._extract_description(url)
    # Test case for extracting description
    SoundgasmIE()._extract_uploader(url)
    # Test case for extracting uploader
    SoundgasmIE()._extract_title(url)
    # Test case for extracting title
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE()._real_extract(url)
    # Test case for real_extract function

# Generated at 2022-06-24 13:17:05.287978
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:17:07.179098
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE(InfoExtractor)
    assert soundgasm is not None


# Generated at 2022-06-24 13:17:11.011252
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = SoundgasmIE("https://soundgasm.net/u/ytdl/Piano-sample")
    assert test.IE_NAME == 'soundgasm'
    assert test.IE_DESC == 'Soundgasm'
    assert test._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    test = SoundgasmIE("https://soundgasm.net/u/ytdl/Piano-sample")
    assert test.IE_NAME == 'soundgasm'
    assert test.IE_DESC == 'Soundgasm'

# Generated at 2022-06-24 13:17:19.409146
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    inst = SoundgasmProfileIE.suitable(url)
    assert inst is not None
    assert inst.IE_NAME == 'soundgasm:profile'
    assert inst._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert inst._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}


# Generated at 2022-06-24 13:17:22.305541
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert 'Soundgasm' in SoundgasmIE.__name__
    sIE = SoundgasmIE('youtube-dl')
    assert 'Soundgasm' in sIE._VALID_URL


# Generated at 2022-06-24 13:17:24.395398
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE('www.soundgasm.net/u/ytdl')
    assert isinstance(instance, SoundgasmProfileIE)

# Generated at 2022-06-24 13:17:32.948754
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# Test for valid url
	m = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
	assert m._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
	assert m._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
	assert m._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-24 13:17:34.537179
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class_SoundgasmIE = SoundgasmIE(None)
    assert class_SoundgasmIE != None

# Generated at 2022-06-24 13:17:44.499935
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import sys
    import HTMLParser
    from contextlib import closing
    from six.moves.urllib.parse import urlparse
    
    # sys.argv[1] : url
    # sys.argv[2] : file name
    # sys.argv[3] : file size
    

# Generated at 2022-06-24 13:17:50.123458
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Unit test for the constructor of class SoundgasmProfileIE
    url = "http://soundgasm.net/u/ytdl"
    sgm_profile = SoundgasmProfileIE(url)
    assert sgm_profile.name == 'soundgasm:profile'
    assert sgm_profile.url == url
    assert sgm_profile.playlist_count == 1
    return


# Generated at 2022-06-24 13:17:52.302136
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    inst = SoundgasmProfileIE('SoundgasmProfileIE', 'http://soundgasm.net/u/ytdl', 'ytdl')
    assert inst.playlist_count == 1

# Generated at 2022-06-24 13:17:57.850855
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sie = SoundgasmIE()
    mobj = re.match(sie._VALID_URL, 'http://soundgasm.net/u/ytdl/Piano-sample')
    assert mobj.group('user') == 'ytdl'
    assert mobj.group('display_id') == 'Piano-sample'

# Generated at 2022-06-24 13:17:58.757748
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert 'Soundgasm' in globals()

# Generated at 2022-06-24 13:18:01.955836
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_ie = SoundgasmIE()

    mobj = re.match(
        soundgasm_ie._VALID_URL,
        'http://soundgasm.net/u/ytdl/Piano-sample')
    assert mobj.group('user') == 'ytdl'
    assert mobj.group('display_id') == 'Piano-sample'



# Generated at 2022-06-24 13:18:03.097728
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE()
    except:
        print("Constructor of SoundgasmIE didn't run")


# Generated at 2022-06-24 13:18:04.538107
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == SoundgasmIE._VALID_URL
    assert ie._TEST == SoundgasmIE._TEST

# Generated at 2022-06-24 13:18:06.315179
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    # Simple test, to make sure nothing breaks.
    # This empty dictionary would return the same result if tester doesn't pass any argument.
    assert SoundgasmIE({})
    assert SoundgasmProfileIE({})

# Generated at 2022-06-24 13:18:08.809710
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
        assert('SoundgasmIE' in globals())
        test_SoundgasmIE = SoundgasmIE('http://www.youtube.com/watch?v=2Yh8WzHq5qw')
        assert(isinstance(test_SoundgasmIE, InfoExtractor))

# Generated at 2022-06-24 13:18:11.927450
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print('Test SoundgasmIE constructor')
    SoundgasmIE('http://www.soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:18:15.812065
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest

    class TestSoundgasmProfileIE(unittest.TestCase):
        def test_SoundgasmProfileIE(self):
            SoundgasmProfileIE()

    unittest.main(argv=['test_SoundgasmProfileIE'])

# Generated at 2022-06-24 13:18:18.315163
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert(SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample').validate_url())


# Generated at 2022-06-24 13:18:20.657925
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert isinstance(SoundgasmProfileIE(None), InfoExtractor)
    assert isinstance(SoundgasmIE(None), InfoExtractor)

# Generated at 2022-06-24 13:18:27.411899
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test for proper extraction
    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    # TODO: check if any other id is generated when audio is downloaded
    test_id = hashlib.sha1('/ytdl/Piano-sample'.encode('utf-8')).hexdigest()
    soundgasm_info_extractor = SoundgasmIE()
    info_dict = soundgasm_info_extractor._real_extract(test_url)
    assert(info_dict['id'] == test_id)
    # Test for video url
    video_url = info_dict['url']
    video_content = requests.get(video_url).content
    # TODO: Generate proper expected data
    expected_data = None