

# Generated at 2022-06-24 13:08:22.854941
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('SoundgasmProfileIE')
    assert ie.IE_NAME == 'SoundgasmProfileIE'

# Generated at 2022-06-24 13:08:24.061979
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None)


# Generated at 2022-06-24 13:08:34.047430
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # The url following is a real URL of a valid mp3 music.
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    url_mock = re.match(r"^https?://(.*\.)?soundgasm\.net/", url)

    instance = SoundgasmIE()
    result = instance._match_id(url_mock)
    assert result == SoundgasmIE._VALID_URL

    extract_result = instance._real_extract(url)
    assert extract_result['url'] == "http://snds.s3.amazonaws.com/88/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a"

# Generated at 2022-06-24 13:08:36.656217
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Create an instance of class SoundgasmIE
    test_object = SoundgasmIE()
    # Verify that the class was created successfully
    assert_not_null(test_object)


# Generated at 2022-06-24 13:08:38.323134
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test = SoundgasmProfileIE(None)
    assert hasattr(test)


# Generated at 2022-06-24 13:08:40.240902
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  from .test_real_case import construct_test
  construct_test(InfoExtractor, 'test_info_extractor', 'SoundgasmProfileIE')

# Generated at 2022-06-24 13:08:40.872820
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg = SoundgasmProfileIE()

# Generated at 2022-06-24 13:08:45.910747
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest.mock
    from youtube_dl.extractor.soundgasm import SoundgasmProfileIE
    from youtube_dl.compat import compat_HTTPError

    assert isinstance(SoundgasmProfileIE, type)
    mock = unittest.mock.Mock()
    mock.return_value = compat_HTTPError(404, 'Not Found')
    instance = SoundgasmProfileIE()
    with unittest.mock.patch('youtube_dl.downloader.http.HttpFD.download', mock):
        assert instance._real_extract('http://soundgasm.net/u/ytdl/?page=1')
        mock.return_value = compat_HTTPError('404', 'Not Found')

# Generated at 2022-06-24 13:08:49.997940
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasmProfile = SoundgasmProfileIE()
    # default value for object attribute
    assert soundgasmProfile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:08:56.729890
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    playlist = SoundgasmProfileIE()
    assert playlist.IE_NAME == 'soundgasm:profile'
    assert playlist.VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert playlist.TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }



# Generated at 2022-06-24 13:08:58.614050
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('Soundgasm:profile')
    ie2 = SoundgasmProfileIE('Soundgasm:profile')
    assert ie == ie2
    ie3 = SoundgasmProfileIE('Soundgasm:profile:test')
    assert ie != ie3

# Generated at 2022-06-24 13:09:09.383048
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    if (ie.ie_key() != 'Soundgasm'):
        assert(False)
    if (ie.test() != '88abd86ea000cafe98f96321b23cc1206cbcbcc9'):
        assert(False)
    if (ie.working() != ''):
        assert(False)
    if (ie._TEST['title'] != 'Piano sample'):
        assert(False)
    if (ie._TEST['description'] != 'Royalty Free Sample Music'):
        assert(False)
    if (ie._TEST['uploader'] != 'ytdl'):
        assert(False)

# Generated at 2022-06-24 13:09:10.708880
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    # test init
    assert sg != None

# Generated at 2022-06-24 13:09:21.115215
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE("")
    assert ie is not None
    # Test URL nothing after /u/
    with pytest.raises(RegexMatchError):
        ie._real_extract("http://soundgasm.net/u/ytdl/")
    # Test URL invalid
    with pytest.raises(ExtractorError):
        ie._real_extract("http://soundgasm.net/u/ytdl/Invalid")
    # Test URL not exist
    with pytest.raises(RegexMatchError):
        ie._real_extract("http://soundgasm.net/u/ytdl/notexist")
    # Test URL normal URL
    assert ie._real_extract("http://soundgasm.net/u/ytdl/Piano-sample") is not None

# Generated at 2022-06-24 13:09:24.228451
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ige = SoundgasmIE()
    assert ige.IE_NAME == "soundgasm"
    assert ige.get_description(description="Sample Music") == "Sample Music"
    assert ige.get_description(description=None) == ""

# Generated at 2022-06-24 13:09:26.985251
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE().IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-24 13:09:28.183520
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    s = SoundgasmProfileIE('https://www.soundgasm.net/u/ytdl/')
    s.IE_NAME

# Generated at 2022-06-24 13:09:29.972092
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert isinstance(ie._VALID_URL, str)
    assert ie._VALID_URL
    assert isinstance(ie._TEST, dict)
    assert ie._TEST


# Generated at 2022-06-24 13:09:30.869493
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:09:34.033046
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print('Test SoundgasmIE')
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    IE = SoundgasmIE()
    IE._real_extract(url)

# Generated at 2022-06-24 13:09:35.077582
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test = SoundgasmProfileIE('url');
    assert test.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:09:37.206448
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_obj = SoundgasmIE('Soundgasm')
    assert test_obj.IE_NAME == 'soundgasm'


# Generated at 2022-06-24 13:09:39.485951
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")


# Generated at 2022-06-24 13:09:42.416530
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info = SoundgasmIE()._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert info['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'


# Generated at 2022-06-24 13:09:43.997780
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from . import SoundgasmProfileIE
    assert SoundgasmProfileIE.NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:09:50.523294
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    title = 'http://soundgasm.net/u/ytdl'
    user = 'ytdl'

    # Check default return
    profile = SoundgasmProfileIE()
    assert profile.IE_NAME == 'SoundgasmProfileIE'
    assert profile.IE_DESC == 'Soundgasm profile'
    assert profile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[0-9a-zA-Z_-]+)/?(?:\#.*)?$'
    assert profile._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}

# Generated at 2022-06-24 13:09:53.170491
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Cock_in_mouth_Youtube-DL"
    SoundgasmIE().extract(url)

# Generated at 2022-06-24 13:09:57.012994
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = {
        'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
    }
    assert test == SoundgasmIE._build_url_result(test['url'])



# Generated at 2022-06-24 13:09:58.784122
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Simple test to make sure SoundgasmIE class is constructed
    """
    SoundgasmIE


# Generated at 2022-06-24 13:10:02.016980
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE()
    assert(re.match(ie._VALID_URL, url) != None)

# Generated at 2022-06-24 13:10:03.083132
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    Profile_obj = SoundgasmProfileIE()

# Generated at 2022-06-24 13:10:13.744901
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    instance = SoundgasmIE({"username": "DQmbYDKjX9YQWmxUB8Bv1rjta1dF3tqcavP8fvGJbbRjK9X",
                              "password": "DQmPPdw3q3t11B8zvwuJAkfkZje9dYXaWnJfVPteLjgwEbc"},
                              "test")._real_extract(url)
    assert instance["id"] == "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
    assert instance["uploader"] == "ytdl"
    assert instance["title"] == "Piano sample"
   

# Generated at 2022-06-24 13:10:16.131909
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    return SoundgasmIE().download('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-24 13:10:20.146701
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    sg = SoundgasmIE()
    #sg._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')
    #sg._real_extract('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:10:21.642939
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    obj = SoundgasmProfileIE(url)
    return obj.url == url


# Generated at 2022-06-24 13:10:22.513707
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:10:24.470546
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    constructor_test(SoundgasmIE, 'http://soundgasm.net/u/ytdl/Piano-sample', 'Piano-sample')


# Generated at 2022-06-24 13:10:28.340273
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    #should be initialized with a string containing a valid URL
    assert SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    #should not be initialized with an invalid URL
    assert not SoundgasmProfileIE('https://soundgasm.net/a')

# Generated at 2022-06-24 13:10:37.613708
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .simulate import TestSimulate
    from .extractor.test import util
    from .extractor.soundgasm import SoundgasmIE

    manifest = [
        ('http://soundgasm.net/u/ytdl/Piano-sample', TestSimulate(
            request_headers={
                'Referer': 'http://soundgasm.net/u/ytdl/'
            }), [
            util.getid('ytdl/Piano-sample', SoundgasmIE)
        ])
    ]

    s = SoundgasmProfileIE()
    s.extractor._make_request = util.make_reuqests(manifest)
    s.extractor._download_json = util.make_json(manifest)

    s.extractor._make_request.return_value = 0
    s.ext

# Generated at 2022-06-24 13:10:40.623596
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test SoundgasmProfileIE
    import pytest
    with pytest.raises(pytest.fail.Exception):
        SoundgasmProfileIE('foo%s' % 'bar', None)

# Generated at 2022-06-24 13:10:43.250616
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    x = SoundgasmIE()
    x.extract("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-24 13:10:52.956045
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

	# Tested on: http://soundgasm.net/u/ytdl/Piano-sample
	url = "http://soundgasm.net/u/ytdl/Piano-sample"

	# The expected output of the _real_extract method from the SoundgasmIE class
	extract_result = {
		'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
		'ext': 'm4a',
		'title': 'Piano sample',
		'description': 'Royalty Free Sample Music',
		'uploader': 'ytdl',
	}

	# Create object and run the _real_extract method
	soundgasmIE = SoundgasmIE()
	result = soundgasmIE._real_extract(url)

# Generated at 2022-06-24 13:10:54.196525
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE()
    assert soundgasm_profile_ie is not None

# Generated at 2022-06-24 13:11:00.002422
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    seeder = SoundgasmIE.Seeder('test', 'http://www.soundgasm.net/u/ytdl/Piano-sample')
    assert seeder.user == 'ytdl'
    assert seeder.display_id == 'Piano-sample'
    assert seeder.get_url() == 'http://www.soundgasm.net/u/ytdl/Piano-sample'

# Generated at 2022-06-24 13:11:04.475530
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()

# Generated at 2022-06-24 13:11:08.447297
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    assert isinstance(soundgasm, InfoExtractor)
    assert soundgasm.ie_key() == 'Soundgasm'
    assert soundgasm.suitable(SoundgasmIE._TEST['url'])
    assert soundgasm.IE_NAME == 'Soundgasm'


# Generated at 2022-06-24 13:11:11.543224
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # test if class SoundgasmProfileIE is present in soundgasm.py
    try:
        SoundgasmProfileIE
    except:
        raise AssertionError("class SoundgasmProfileIE not found\n")


# Generated at 2022-06-24 13:11:13.654193
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-24 13:11:17.488305
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    m = SoundgasmIE( )
    obj = re.match( m._VALID_URL, url )
    obj.group('display_id')

# Generated at 2022-06-24 13:11:18.443855
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()


# Generated at 2022-06-24 13:11:19.738960
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-24 13:11:22.196257
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    Test_SoundgasmIE = SoundgasmIE()
    assert Test_SoundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-24 13:11:26.780386
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile = SoundgasmProfileIE(None, url)
    assert profile.url == 'http://soundgasm.net/u/ytdl'
    assert profile.profile_id == 'ytdl'

# Generated at 2022-06-24 13:11:27.977636
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
   a = SoundgasmIE()

# Generated at 2022-06-24 13:11:34.872163
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE_NAME = 'soundgasm:profile'
    VALID_URL = 'http://soundgasm.net/u/ytdl'
    TEST = {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    assert SoundgasmProfileIE()._VALID_URL == VALID_URL
    assert SoundgasmProfileIE().IE_NAME == IE_NAME
    assert SoundgasmProfileIE()._TEST == TEST

# Generated at 2022-06-24 13:11:37.838881
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    soundgasm_profile_ie = SoundgasmProfileIE(url)
    assert soundgasm_profile_ie.IE_NAME == "Soundgasm"

# Generated at 2022-06-24 13:11:42.102978
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_ie = SoundgasmProfileIE()
    assert profile_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:11:43.027569
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	SoundgasmProfileIE()

# Generated at 2022-06-24 13:11:46.431086
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("Testing SoundgasmIE initialization")
    soundgasmIE = SoundgasmIE()
    assert soundgasmIE.extractor_key == soundgasmIE.IE_NAME
    assert soundgasmIE.ie_key() == soundgasmIE.IE_NAME


# Generated at 2022-06-24 13:11:51.970309
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    res = SoundgasmProfileIE()
    assert res.IE_NAME == "soundgasm:profile"
    assert res._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$"
    assert res._TEST["url"] == "http://soundgasm.net/u/ytdl"
    assert res._TEST["info_dict"]["id"] == "ytdl"
    assert res._TEST["playlist_count"] == 1

# Generated at 2022-06-24 13:11:52.876160
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE()
    print('Constructor OK')


# Generated at 2022-06-24 13:11:56.488494
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    unit_test = SoundgasmIE()
    assert unit_test._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-24 13:12:05.990891
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    obj = SoundgasmIE()
    mobj = re.match(SoundgasmIE._VALID_URL, url)
    assert mobj is not None
    # test match function
    assert obj._match_id(url) == mobj.group('display_id')
    # test download webpage
    webpage = obj._download_webpage(url, obj._match_id(url))
    # test extractor
    assert obj._real_extract(url) == SoundgasmIE._TEST
    assert obj._html_search_regex(SoundgasmIE._TEST['md5'], webpage, 'md5') == \
        SoundgasmIE._TEST['info_dict']

# Generated at 2022-06-24 13:12:17.388073
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:12:26.675807
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Test for constructor of class SoundgasmProfileIE and its helper functions.
    """
    import os

    # Import test data
    webpage_test_case = os.path.join(os.path.dirname(__file__), 'test_data', 'soundgasm', 'ytdl')
    webpage_test_case_content = open(webpage_test_case, 'r').read()

    # Create instance and test
    internet_ex = SoundgasmProfileIE('ytdl')
    playlist = internet_ex._real_extract('http://soundgasm.net/u/ytdl', webpage_test_case_content)
    assert playlist is not None
    assert len(playlist['entries']) == 1

# Generated at 2022-06-24 13:12:30.257726
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    i = SoundgasmIE()
    assert i._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-24 13:12:39.236301
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .test import get_testcases
    from ..utils import ExtractorError


# Generated at 2022-06-24 13:12:43.743064
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # TODO: add more unit test data
    data = (
        (
            'http://soundgasm.net/u/ytdl/Piano-sample',
            ('88abd86ea000cafe98f96321b23cc1206cbcbcc9', 'ytdl')),
    )
    for url, expected in data:
        ie = SoundgasmIE(url)
        assert (ie.extract()['id'], ie.extract()['uploader']) == expected

# Generated at 2022-06-24 13:12:45.494545
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE = SoundgasmProfileIE()
    SoundgasmP = SoundgasmProfileIE.url_result

# Generated at 2022-06-24 13:12:46.368525
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:12:48.466076
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    obj = ie.ie_key()
    assert obj == 'Soundgasm:profile'

# Generated at 2022-06-24 13:12:50.438778
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class_constructor = lambda: SoundgasmIE(0)
    assert_raises(TypeError, class_constructor)

# Generated at 2022-06-24 13:12:56.647052
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Constructor test for class SoundgasmIE
    """
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-24 13:13:04.714422
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    '''
    Test constructor of class SoundgasmProfileIE.
    '''
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl/")
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl/#")
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl/#asd")
    SoundgasmProfileIE("http://www.soundgasm.net/u/ytdl")
    SoundgasmProfileIE("http://www.soundgasm.net/u/ytdl/")
    SoundgasmProfileIE("http://www.soundgasm.net/u/ytdl/#")

# Generated at 2022-06-24 13:13:06.349159
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	x = SoundgasmProfileIE()
	assert(x.IE_NAME == 'SoundgasmProfileIE')

# Generated at 2022-06-24 13:13:12.931530
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from soundgasm import SoundgasmProfileIE
    assert SoundgasmProfileIE._TEST == SoundgasmIE._TEST
    assert SoundgasmProfileIE._VALID_URL == SoundgasmIE._VALID_URL

if __name__ == '__main__':
    import sys
    sys.argv[0] = re.sub(r'(-script\.pyw|\.exe)?$', '', sys.argv[0])
    sys.exit(test_SoundgasmProfileIE())

# Generated at 2022-06-24 13:13:21.569442
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert audio.IE_NAME == 'soundgasm'
    assert audio.VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:13:24.746003
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE('SoundgasmProfileIE')
    assert instance.ie_key() == 'Soundgasm:profile'
    assert instance.ie_name() == 'Soundgasm'


# Generated at 2022-06-24 13:13:33.136340
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()._downloader.cache.delete("http://soundgasm.net/u/ytdl/Piano-sample")
    SoundgasmIE()._downloader.cache.delete("http://soundgasm.net/u/ytdl")
    test = SoundgasmIE()._downloader.urlopen("http://soundgasm.net/u/ytdl/Piano-sample")
    test.read().decode('utf-8')
    assert test._headers.get('content-type', None).startswith("text/html")

    test = SoundgasmIE()._download_webpage("http://soundgasm.net/u/ytdl/Piano-sample", "Piano-sample")
    assert test is not None


# Generated at 2022-06-24 13:13:39.785956
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE(url)
    # test constructor
    assert(ie.IE_NAME == 'SoundgasmProfileIE')
    assert(ie.IE_CODE == 'SoundgasmProfileIE')
    assert(ie._VALID_URL == 'http://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
    assert(ie._TEST['url'] == url)

# Generated at 2022-06-24 13:13:42.723180
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    indexer = SoundgasmIE()
    assert indexer._match_id('http://soundgasm.net/u/ytdl/') == 'ytdl'
    assert indexer.extract('http://soundgasm.net/u/ytdl/') is not None


# Generated at 2022-06-24 13:13:44.749514
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	# Test constructor
	s = SoundgasmProfileIE()
	s1 = SoundgasmProfileIE()
	assert s._VALID_URL == s1._VALID_URL
    # Test constructor


# Generated at 2022-06-24 13:13:55.929374
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    assert (sg._VALID_URL == 
            r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-24 13:13:58.349860
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None, {'youtube_ie': 'youtube', 'extractor': 'soundcloud'}, get_audio_extractor, get_audio_extractor)


# Generated at 2022-06-24 13:14:03.725467
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test 1
    url = 'http://soundgasm.net/u/ytdl'
    obj = SoundgasmProfileIE()
    soundgasm_profile_ie_1 = obj._real_extract(url)
    assert soundgasm_profile_ie_1

    # Test 2
    url = 'http://soundgasm.net/u/teddy-love'
    obj = SoundgasmProfileIE()
    soundgasm_profile_ie_2 = obj._real_extract(url)
    assert soundgasm_profile_ie_2


# Generated at 2022-06-24 13:14:05.644419
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert(SoundgasmIE.suitable("http://soundgasm.net/u/ytdl/Piano-sample") == True)

# Generated at 2022-06-24 13:14:16.398793
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    assert soundgasm.IE_NAME == 'soundgasm'
    assert soundgasm._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert '_TEST' in soundgasm.__dict__
    assert 'url' in soundgasm._TEST
    assert 'md5' in soundgasm._TEST
    assert 'info_dict' in soundgasm._TEST
    assert 'id' in soundgasm._TEST['info_dict']
    assert 'ext' in soundgasm._TEST['info_dict']
    assert 'title' in soundgasm

# Generated at 2022-06-24 13:14:19.727946
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasm_ie_obj = SoundgasmIE()
    soundgasm_ie_obj.suitable(url)



# Generated at 2022-06-24 13:14:21.428126
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == "soundgasm"


# Generated at 2022-06-24 13:14:27.020089
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().suitable('http://soundgasm.net/u/ytdl/Piano-sample')
    assert SoundgasmIE().suitable('http://soundgasm.net/u/ytdl/Piano-Sample123')
    assert not SoundgasmIE().suitable('http://soundgasm.net/u/ytdl/')


# Generated at 2022-06-24 13:14:34.492615
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test 1
    success('Test 1 (valid url)', SoundgasmIE(SoundgasmIE._VALID_URL))
    # Test 2
    failure('Test 2 (invalid url)', SoundgasmIE, 'soundgas')
    # Test 3
    failure('Test 3 (valid url, invalid user)', SoundgasmIE, 'http://soundgasm.net/u/frosty/first-time-experience')
    # Test 4
    failure('Test 4 (valid url, invalid id)', SoundgasmIE, 'http://soundgasm.net/u/ytdl/first-time-experience')

# Generated at 2022-06-24 13:14:35.814580
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    return SoundgasmProfileIE(SoundgasmProfileIE._constructor())


# Generated at 2022-06-24 13:14:42.595456
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test constructor function
    SoundgasmIE._TEST = {
        'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
        'md5': '010082a2c802c5275bb00030743e75ad',
        'info_dict': {
            'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
            'ext': 'm4a',
            'title': 'Piano sample',
            'description': 'Royalty Free Sample Music',
            'uploader': 'ytdl',
        }
    }
    ie = SoundgasmIE(None)

# Generated at 2022-06-24 13:14:43.837401
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert isinstance(SoundgasmIE(), InfoExtractor)


# Generated at 2022-06-24 13:14:46.210869
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    example = SoundgasmIE()
    print(example._real_extract(url))


# Generated at 2022-06-24 13:14:48.606950
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('SoundgasmProfileIE')._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:14:49.787926
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	pass


# Generated at 2022-06-24 13:14:52.343038
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info = SoundgasmIE()._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert info['title'] == 'Piano sample'

# Generated at 2022-06-24 13:14:54.872332
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class_ = SoundgasmIE
    inst = class_('http://soundgasm.net/u/ytdl/Piano-sample')
    assert inst._downloader.params['noplaylist']

# Generated at 2022-06-24 13:14:56.682571
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE('soundgasm:profile')
    assert soundgasm_profile_ie is not None

# Generated at 2022-06-24 13:14:59.515469
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('http://soundgasm.net/u/ytdl')._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/([^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:15:00.878257
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE.ie_key() == 'Soundgasm'

# Generated at 2022-06-24 13:15:05.731731
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(None, "http://soundgasm.net/u/ytdl", [], None)
    assert ie._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:#.*)?$"


# Generated at 2022-06-24 13:15:07.911840
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # The constructor of the class SoundgasmProfileIE is called with two arguments
    assert SoundgasmProfileIE._constructor() == (None, None)

# Generated at 2022-06-24 13:15:09.542443
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	s = SoundgasmProfileIE({})
	assert s.ie_name == 'Soundgasm:profile'

# Generated at 2022-06-24 13:15:17.190676
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    result = SoundgasmIE()
    assert result.IE_NAME == "soundgasm"
    assert result.VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:15:22.469371
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    regex = re.compile(ie._VALID_URL)
    assert regex.match('http://soundgasm.net/u/foo/bar').groups() == ('foo', 'bar')
    assert regex.match('https://soundgasm.net/u/foo/bar').groups() == ('foo', 'bar')
    assert regex.match('http://www.soundgasm.net/u/foo/bar').groups() == ('foo', 'bar')
    assert regex.match('https://www.soundgasm.net/u/foo/bar').groups() == ('foo', 'bar')
    assert regex.match('http://soundgasm.net/u/foo/bar/').groups() == ('foo', 'bar')

# Generated at 2022-06-24 13:15:28.214512
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	"""Test SoundgasmProfileIE construction"""

	# Class creation
	soundgasm_profile_ie = SoundgasmProfileIE()

	# Asserting class validation URL
	assert soundgasm_profile_ie._VALID_URL == \
		r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:15:35.517709
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("\nTesting SoundgasmIE\n")
    title_extracted = SoundgasmIE._get_title("http://soundgasm.net/u/ytdl/Piano-sample")
    # Testing title extraction from given link
    if title_extracted == "Piano sample":
        print("Title extracted correctly\n")
    else:
        print("Title extracted incorrectly\n")

    # Testing URL extraction from given link
    soundgasm = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    url = soundgasm._real_extract("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-24 13:15:47.288307
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    # Init an instance of SoundgasmIE
    ie = SoundgasmIE()
    # Test to verify constructor worked
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-24 13:15:48.577832
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_ie = SoundgasmIE('test')
    assert soundgasm_ie.IE_NAME == 'soundgasm'


# Generated at 2022-06-24 13:15:57.066148
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    with open('tests/testdata/test.html') as f:
        webpage = f.read()
        title = ie._html_search_regex(
            r'<div[^>]+\bclass=["\']jp-title[^>]+>([^<]+)',
            webpage, 'title')
        audio_url = ie._html_search_regex(
            r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', webpage,
            'audio URL', group='url')

# Generated at 2022-06-24 13:15:58.741617
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    x = SoundgasmIE()
    y = SoundgasmIE()
    assert x == y

# Generated at 2022-06-24 13:16:09.648894
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl/Piano-sample', 'md5': '010082a2c802c5275bb00030743e75ad', 'info_dict': {'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9', 'ext': 'm4a', 'title': 'Piano sample', 'description': 'Royalty Free Sample Music', 'uploader': 'ytdl'}}
   

# Generated at 2022-06-24 13:16:20.665056
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest
    import youtube_dl.extractor.soundgasm
    import youtube_dl.extractor
    import youtube_dl.utils

    # SoundgasmProfileIE inherits from SoundgasmIE
    class Test(unittest.TestCase):
        def setUp(self):
            self.ie = youtube_dl.extractor.soundgasm.SoundgasmProfileIE()

        def test_suite(self):
            # soundgasm.net
            self.url = 'https://soundgasm.net/u/ytdl'
            self.ie.url = self.url
            self.assertEqual(self.ie.url, self.url)
            self.assertEqual(self.ie.ie_key(), 'SoundGasm')

# Generated at 2022-06-24 13:16:22.721516
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    ie.extract()

# Generated at 2022-06-24 13:16:31.925534
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    info_dict = {
            'id': 'ytdl',
        }
    playlist_count = 1
    
    # constructor
    test = SoundgasmProfileIE(url=url, info_dict=info_dict, playlist_count=playlist_count)

    # isinstance check
    assert isinstance(test, SoundgasmProfileIE), "Instance is not SoundgasmProfileIE"

    # instance members check
    assert test.IE_NAME == 'soundgasm:profile'
    assert test._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:16:35.789330
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest
    class Test(unittest.TestCase):
        def setUp(self):
            self.ie = SoundgasmProfileIE()

    unittest.main(argv=[''])



# Generated at 2022-06-24 13:16:42.504821
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert SoundgasmIE().IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:16:47.533133
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_cases = [
        (r'https://soundgasm.net/u/ytdl',
         ('ytdl', 'https://soundgasm.net/u/ytdl')),
        (r'https://soundgasm.net/u/ytdl/',
         ('ytdl', 'https://soundgasm.net/u/ytdl')),
        (r'https://soundgasm.net/u/ytdl/something-else',
         ('ytdl', 'https://soundgasm.net/u/ytdl/something-else')),
        (r'https://soundgasm.net/u/ytdl/#something-else',
         ('ytdl', 'https://soundgasm.net/u/ytdl/#something-else')),
    ]

    REDIR_

# Generated at 2022-06-24 13:16:48.568931
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        _ = SoundgasmIE()
        assert True
    except Exception:
        assert False

# Generated at 2022-06-24 13:16:50.574557
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = SoundgasmProfileIE._TEST['url']
    playlist_count = SoundgasmProfileIE._TEST['playlist_count']
    ie = SoundgasmProfileIE(url)
    playlist = ie.extract(url)
    assert len(playlist['entries']) == playlist_count

# Generated at 2022-06-24 13:16:55.574314
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mobj = re.match(SoundgasmIE._VALID_URL, url)
    ex = SoundgasmIE()

    assert mobj.group('user') == 'ytdl'
    assert mobj.group('display_id') == 'Piano-sample'
    assert ex.feed_url == 'http://soundgasm.net/u/ytdl/Piano-sample'

# Generated at 2022-06-24 13:17:03.851561
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_id = 'soundgasm'
    # Use the extractor of SoundgasmProfileIE to get a list of audio
    profile = SoundgasmProfileIE()
    profile_url = 'http://soundgasm.net/u/%s' %profile_id 
    entries = profile._real_extract(profile_url)
    # Use the extractor of SoundgasmIE to get the info of each audio
    def get_audio_info(entry):
        audio = SoundgasmIE()
        return audio._real_extract(entry)
    # Print the result
    for entry in entries:
        audio_info = get_audio_info(entry)

# Generated at 2022-06-24 13:17:05.584421
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(InfoExtractor)._real_extract(SoundgasmProfileIE._TEST['url'])

# Generated at 2022-06-24 13:17:13.131332
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sgprofile = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert sgprofile.IE_NAME == 'soundgasm:profile'
    assert sgprofile.VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert sgprofile.TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-24 13:17:18.731722
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    testcases = [
        ('username must be string', '123', TypeError),
        ('username must be valid username', 'abc$', ValueError),
    ]
    for input, expected, errtype in testcases:
        try:
            SoundgasmProfileIE(input)
            assert False
        except errtype as e:
            assert expected in e.args[0]



# Generated at 2022-06-24 13:17:19.662913
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert isinstance(SoundgasmProfileIE, type)

# Generated at 2022-06-24 13:17:29.659951
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'
    assert ie._TEST['info_dict']['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-24 13:17:36.521057
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm = SoundgasmProfileIE()
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = soundgasm._match_id(url)
    webpage = soundgasm._download_webpage(url, profile_id)
    entries = [
        soundgasm.url_result(audio_url, 'Soundgasm')
        for audio_url in re.findall(r'href="([^"]+/u/%s/[^"]+)' % profile_id, webpage)]
    # Assert that entries contains a number of items
    assert len(entries) > 1

# Generated at 2022-06-24 13:17:42.187686
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    #test_class_object = SoundgasmIE()
    #test_class_object2 = SoundgasmIE()
    #print("Hey there! "+str(test_class_object))
    #print("\nHey there! "+str(test_class_object2))
    assert(True)

if __name__ == '__main__':
    #test_SoundgasmIE()
    print('Hey there! Test cases finished')

# Generated at 2022-06-24 13:17:49.503398
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:17:51.646124
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_entry = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert(soundgasm_entry.name == "SoundgasmIE")


# Generated at 2022-06-24 13:17:58.716140
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        # Constructor of class SoundgasmProfileIE
        obj = SoundgasmProfileIE
        obj.IE_NAME
        obj.IE_DESC
        obj.ie_key()
        obj.get_ie_key()
        obj.suitable()
        obj.is_suitable()
        obj.working()
        obj.extract()
    except Exception:
        assert False, 'Unable to instantiate SoundgasmProfileIE'


# Generated at 2022-06-24 13:18:02.513775
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    assert sg._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:18:07.829487
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Fake parameters 
    url = 'https://soundgasm.net/u/ytdl/Piano-sample'
    title = 'Piano sample'
    audio_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    description = 'Royalty Free Sample Music'

    # Create the instance
    instance = SoundgasmIE()

    # Assign values to parameters
    instance._download_webpage = lambda x, y: ''
    instance._html_search_regex = lambda a, b, c, d: 'https://audio.soundgasm.net/sounds/8b/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'

# Generated at 2022-06-24 13:18:15.896883
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert SoundgasmProfileIE._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}


# Generated at 2022-06-24 13:18:25.161727
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url = 'https://soundgasm.net/u/ytdl/Piano-sample'
    url = 'https://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE()
    info = ie.extract(test_url)
    assert info['display_id'] == 'Piano-sample'
    assert info['title'] == 'Piano sample'
    assert info['description'] == 'Royalty Free Sample Music'
    assert info['uploader'] == 'ytdl'