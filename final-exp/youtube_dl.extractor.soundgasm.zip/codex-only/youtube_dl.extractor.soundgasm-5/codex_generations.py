

# Generated at 2022-06-24 13:08:27.124132
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_obj = SoundgasmIE()
    assert test_obj.IE_NAME == 'soundgasm'
    assert test_obj._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert test_obj._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert test_obj._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-24 13:08:29.441702
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    # Done

# Generated at 2022-06-24 13:08:36.056171
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    expected = '010082a2c802c5275bb00030743e75ad'
    i = SoundgasmIE()
    result = i._real_extract(test_url)

    assert result['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9' and result['md5'] == expected


if __name__ == '__main__':
    test_SoundgasmIE()

# Generated at 2022-06-24 13:08:41.723364
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    This method is a unit test for SoundgasmIE class
    """
    # instantiate an object of SoundgasmIE class
    ie = SoundgasmIE()

    # test _VALID_URL pattern
    mobj = re.match(ie._VALID_URL, 'http://soundgasm.net/u/sandbox/Piano-sample')
    assert mobj.group('user') == 'sandbox'
    assert mobj.group('display_id') == 'Piano-sample'

# Generated at 2022-06-24 13:08:43.688716
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie is not None


# Generated at 2022-06-24 13:08:45.003942
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(None,None)
    assert ie == None

# Generated at 2022-06-24 13:08:54.935465
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:09:02.476700
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    i = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert i._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:09:04.650100
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE('Soundgasm')

    assert instance.IE_NAME == 'Soundgasm'

# Generated at 2022-06-24 13:09:14.081557
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE()
    # Test the constructor of class SoundgasmProfileIE
    assert(profile.name == 'soundgasm:profile')
    assert(profile.IE_NAME == 'soundgasm:profile')
    assert(profile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
    assert(profile._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    })
    

# Generated at 2022-06-24 13:09:16.529592
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	assert('Soundgasm' == SoundgasmIE._VALID_URL)


# Generated at 2022-06-24 13:09:19.386914
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:09:20.963193
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url = u'http://soundgasm.net/u/ytdl/Piano-sample'
    '%s' % test_url

# Generated at 2022-06-24 13:09:24.031297
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('')
    assert ie.ie_key() == 'Soundgasm'

    # Unit test for class SoundgasmProfileIE
    def test_ie():
        ie = SoundgasmProfileIE('')
        assert ie.ie_key() == 'Soundgasm'

# Generated at 2022-06-24 13:09:26.924357
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert 'Soundgasm' in [c.IE_NAME for c in InfoExtractor.get_classes()]

# Generated at 2022-06-24 13:09:31.922854
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    audio_url = 'https://s3.amazonaws.com/sgs/uid/1/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    # Test for _real_extract():
    # 1. Download web page with no caching

# Generated at 2022-06-24 13:09:34.630651
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = IE_NAME(IE_NAME)
    ie.url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie.extract()

# Generated at 2022-06-24 13:09:38.916769
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
  url = "http://soundgasm.net/u/ytdl/Piano-sample"
  #print(url)
  s = SoundgasmIE()
  s._real_extract(url)
  #return s
if __name__ == "__main__":
  s = test_SoundgasmIE()

# Generated at 2022-06-24 13:09:39.446060
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:09:41.819098
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile=SoundgasmProfileIE()
    url="http://soundgasm.net/u/ytdl"
    profile_id="ytdl"

    assert profile._match_id(url)==profile_id

# Generated at 2022-06-24 13:09:43.227267
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl")

# Generated at 2022-06-24 13:09:44.834063
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    new_ie = SoundgasmIE()
    assert new_ie is not None


# Generated at 2022-06-24 13:09:45.739997
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  SoundgasmProfileIE()


# Generated at 2022-06-24 13:09:53.077847
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    assert sg.IE_NAME == 'Soundgasm'
    assert sg._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert sg._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert sg._TEST['md5'] == '010afddb5e9b2ad0d5b13f5d5e5c0f5e'

# Generated at 2022-06-24 13:09:55.171716
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # TypeError: __init__() takes exactly 2 arguments (1 given)
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:10:03.629858
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test a valid url
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    instance = SoundgasmIE()._real_extract(url)
    
    # Definition of expected values of the instance
    expected_keys = ['id', 'display_id', 'url', 'vcodec', 'title', 'description', 'uploader']
    expected_values = ['88abd86ea000cafe98f96321b23cc1206cbcbcc9', 'Piano-sample', 'https://media.soundgasm.net/m/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a', 'none', 'Piano sample', 'Royalty Free Sample Music', 'ytdl']

# Generated at 2022-06-24 13:10:06.531763
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    user = 'anonymous'
    profile = SoundgasmProfileIE(user, user)
    assert profile.user == user
    assert profile.profile_id == user

# Generated at 2022-06-24 13:10:08.827326
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # SoundgasmProfileIE(self, user, display_id)
    SoundgasmProfileIE('ytdl', 'Piano-sample')

# Generated at 2022-06-24 13:10:10.632916
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE(info_extractors=[]).ie_key() == 'Soundgasm'

# Generated at 2022-06-24 13:10:18.994818
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample/')
    assert SoundgasmIE('http://www.soundgasm.net/u/ytdl')
    assert SoundgasmIE('http://www.soundgasm.net/u/ytdl/')
    assert SoundgasmIE('http://www.soundgasm.net/u/ytdl/Piano-sample')
    assert SoundgasmIE('http://www.soundgasm.net/u/ytdl/Piano-sample/')
    assert SoundgasmIE('http://www.soundgasm.net/u/ytdl/Piano-sample/#')
    assert SoundgasmIE

# Generated at 2022-06-24 13:10:20.383673
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()

# Generated at 2022-06-24 13:10:24.882591
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    s = SoundgasmIE()
    assert s._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-24 13:10:27.784696
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .common import FakeYDL
    ie = SoundgasmIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, SoundgasmIE)
    assert isinstance(ie, FakeYDL)

# Generated at 2022-06-24 13:10:37.216390
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    SoundgasmProfileIE._download_webpage = lambda self, url, display_id: '<body><a href="http://soundgasm.net/u/ytdl/Piano-sample"><img src="Piano-sample.png"></a><a href="http://soundgasm.net/u/ytdl/Drum-sample"><img src="Drum-sample.png"></a></body>'
    soundgasm_profile_ie = SoundgasmProfileIE()
    soundgasm_profile_ie._real_extract(url)
    assert soundgasm_profile_ie._download_webpage.__name__ == 'lambda'
    assert soundgasm_profile_ie.playlist_result.__name__ == 'playlist_result'
   

# Generated at 2022-06-24 13:10:38.773125
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.get_real_url(ie.ie_key()) == SoundgasmProfileIE.IE_NAME

# Generated at 2022-06-24 13:10:49.647020
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import os.path
    downloader = InfoExtractor()
    webpage_url = "http://soundgasm.net/u/ytdl/Piano-sample"

# Generated at 2022-06-24 13:10:50.213487
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-24 13:10:51.528231
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE("SoundgasmProfileIE")
    assert obj.__class__.__name__ == "SoundgasmProfileIE"

# Generated at 2022-06-24 13:10:55.342078
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .constructors import _make_result_to_test
    result = _make_result_to_test(SoundgasmIE)
    assert result['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert len(result['uploader']) > 0
    assert 'uploader_url' not in result

# Generated at 2022-06-24 13:10:57.148660
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample", None)

# Generated at 2022-06-24 13:10:59.955699
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('SoundgasmProfileIE')
    assert ie.ie_key() == 'Soundgasm'
    assert ie.ie_name() == 'Soundgasm'

# Generated at 2022-06-24 13:11:05.582621
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    responce = {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    assert SoundgasmProfileIE()._real_extract(responce['url']) == responce


# Generated at 2022-06-24 13:11:13.920280
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()

    assert soundgasm._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:11:17.750807
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE._build_url_result(
            'http://soundgasm.net/u/ytdl/Piano-sample', 'Soundgasm')
        return True
    except:
        return False

# Generated at 2022-06-24 13:11:21.853426
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	print("Testing soundgasm")
	url = "http://soundgasm.net/u/ytdl/Piano-sample"
	s = SoundgasmIE()
	assert s.suitable(url) == True
	assert s.IE_NAME == "soundgasm"
	assert s.__class__.__name__ == "SoundgasmIE"

# Generated at 2022-06-24 13:11:24.395328
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL == SoundgasmProfileIE._VALID_URL

# Generated at 2022-06-24 13:11:26.491618
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE(SoundgasmProfileIE._downloader, None, None) is not None

# Generated at 2022-06-24 13:11:35.953955
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert 'SoundgasmProfileIE' in globals()
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert SoundgasmProfileIE.__doc__ is not None
    assert hasattr(SoundgasmProfileIE, '_VALID_URL')
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert hasattr(SoundgasmProfileIE, '_TEST')

# Generated at 2022-06-24 13:11:41.823399
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE("https://soundgasm.net/u/ytdl/Argentinean_horn_sample")
    assert("SoundgasmIE" == obj.IE_NAME)
    assert("https://soundgasm.net/u/ytdl/Argentinean_horn_sample" == obj._VALID_URL)
    assert("Argentinean horn sample" == obj._TEST["title"])


# Generated at 2022-06-24 13:11:50.536460
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:11:57.110958
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    i = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert i._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\\#.*)?$'
    assert i.IE_NAME == 'soundgasm:profile'
    assert i.PLAYLIST_TITLE == 'Soundgasm profile %s'
    assert i.SUFFIX == 'Soundgasm'
    assert i._TESTS['url'] == 'http://soundgasm.net/u/ytdl'
    assert i._TESTS['info_dict'] == {'id': 'ytdl'}
    assert i._TESTS['playlist_count'] == 1

# Generated at 2022-06-24 13:11:59.040721
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    print(ie)

# Generated at 2022-06-24 13:12:01.631471
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE = SoundgasmProfileIE()
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:12:03.701593
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    i = SoundgasmProfileIE()
    assert i.IE_NAME == 'soundgasm:profile'
    assert i._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:12:10.961991
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
  """This function tests the constructor of class SoundgasmIE"""

  # Test for the valid input
  assert SoundgasmIE().IE_NAME == 'Soundgasm'
  assert SoundgasmIE()._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:12:22.100841
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Args: url, expected, expected_exception, expected_regex
    testcases = []
    # Example case
    testcases.append(("http://soundgasm.net/u/ytdl/Piano-sample",
                      "010082a2c802c5275bb00030743e75ad", None, None))
    # Invalid URL
    testcases.append(("http://soundgasm.net/u/ytdl", None, re.error, None))
    # Invalid URL (missing user)
    testcases.append(("http://soundgasm.net/u//Piano-sample", None, re.error, None))
    # Invalid URL (missing display_id)
    testcases.append(("http://soundgasm.net/u/ytdl/", None, re.error, None))

   

# Generated at 2022-06-24 13:12:23.536118
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Check if it is an object of the right class
    assert SoundgasmProfileIE(SoundgasmProfileIE.IE_NAME, SoundgasmProfileIE.IE_NAME) is not None


# Generated at 2022-06-24 13:12:24.052326
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-24 13:12:25.777171
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    info = sg._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert info['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-24 13:12:33.139111
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    audio_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    display_id = 'Piano-sample'
    uploader = 'ytdl'
    title = 'Piano sample'
    description = 'Royalty Free Sample Music'
    audio_url = 'http://s3.amazonaws.com/media.soundgasm.net/u/ytdl/Piano-sample.m4a'
    ie = SoundgasmIE()
    audio = ie.extract(url)
    assert audio.get('id') == audio_id
    assert audio.get('display_id') == display_id
    assert audio.get('url') == audio_url

# Generated at 2022-06-24 13:12:35.626153
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    instance.download('Piano sample')

# Generated at 2022-06-24 13:12:40.974055
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test downloading audio from another site
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE()
    expected_url = 'http://soundgasm.net/f/2/9/7/1/4/f2971469d7755e5a8ba5a5f5e7309ebc9d9a871e/ytdl-Piano-sample.m4a'
    assert ie._real_extract(url)['url'] == expected_url

# Generated at 2022-06-24 13:12:50.683841
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'

    # Create an instance of the SoundgasmProfileIE
    soundgasm_profile_ie = SoundgasmProfileIE(url)

    # Make sure that the _VALID_URL class constant is set to the correct value
    assert(soundgasm_profile_ie._VALID_URL == SoundgasmProfileIE._VALID_URL)

    # Make sure that the _test set is not empty
    assert(SoundgasmProfileIE._TEST)

    # Make sure that the SoundgasmProfileIE._real_extract method is defined
    assert(soundgasm_profile_ie._real_extract)

    # Make sure that the SoundgasmProfileIE.ie_key is set to the correct value

# Generated at 2022-06-24 13:12:51.720589
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:12:53.092381
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    assert obj != None


# Generated at 2022-06-24 13:13:02.122230
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    song = SoundgasmIE()
    song.SoundgasmIE._VALID_URL = r'https://soundgasm.net/u/Lustful_Whisper/shush'
    song.SoundgasmIE._TEST = {
        'url': 'https://soundgasm.net/u/Lustful_Whisper/shush',
        'md5': '010082a2c802c5275bb00030743e75ad',
        'info_dict': {
            'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
            'ext': 'm4a',
            'title': 'shush',
            'description': 'Royalty Free Sample Music',
            'uploader': 'Lustful_Whisper',
        }
    }


# Generated at 2022-06-24 13:13:05.302758
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:13:06.618099
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    ie.suite()


# Generated at 2022-06-24 13:13:08.991607
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == SoundgasmIE._VALID_URL
    assert ie.IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:13:16.167583
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Tests for constructor of class SoundgasmIE"""
    assert SoundgasmIE.IE_NAME == 'soundgasm'
    assert SoundgasmIE.valid_url == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert SoundgasmIE.md5 == '010082a2c802c5275bb00030743e75ad'
    assert SoundgasmIE.title == 'Piano sample'
    assert SoundgasmIE.uploader == 'ytdl'


# Generated at 2022-06-24 13:13:17.256348
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = InfoExtractor()
    assert(isinstance(ie, SoundgasmProfileIE))

# Generated at 2022-06-24 13:13:21.569319
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Ensure that the website does not update the title for a given profile
    # to contain non-latin characters (see
    # https://github.com/rg3/youtube-dl/pull/5290).
    profile_page = """\
<html>
<head><title>non-latin title</title></head>
<body>
<div class="jp-title">
<a href="/u/ytdl/Piano-sample">Piano sample</a>
</div>
</body>
</html>
"""
    profile = SoundgasmProfileIE(YoutubeDL())._real_extract('http://soundgasm.net/u/ytdl', profile_page)
    assert profile['id'] == 'ytdl'
    assert profile['entries'][0]['id'] == 'Piano-sample'

# Generated at 2022-06-24 13:13:31.378082
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """ Unit test for constructor of class SoundgasmIE """


# Generated at 2022-06-24 13:13:36.461608
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        # Create an object of class SoundgasmIE
        se = SoundgasmIE()
        # Check if the object of class SoundgasmIE is created successfully
        assert type(se) == SoundgasmIE
    except:
        # If not, print the error message
        print("Error: Fail to create an object of class SoundgasmIE")


# Generated at 2022-06-24 13:13:37.516741
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie_obj = SoundgasmProfileIE()
    assert ie_obj.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:13:41.322103
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

    assert ie.url == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie.display_id == 'Piano-sample'
    assert ie.user == 'ytdl'

# Generated at 2022-06-24 13:13:45.784817
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Currently, this is the only class inheriting from InfoExtractor that does not implement _real_extract() method.
    We check that the constructor does not fail.
    """
    url = 'http://soundgasm.net/u/ytdl'
    SoundgasmIE(url)

# Generated at 2022-06-24 13:13:47.237185
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        SoundgasmProfileIE()
    except TypeError:
        pass

# Generated at 2022-06-24 13:13:55.393987
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  instance = SoundgasmProfileIE()
  assert(instance.IE_NAME == 'soundgasm:profile')
  assert instance._VALID_URL == 'h.*?t/u/(?P<id>[^/]+)/?(?:\#.*)?$'
  # assert instance._TEST == 'h.*?t/u/(?P<id>[^/]+)/?(?:\#.*)?$'
  # assert instance._TEST == 'h.*?t/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:14:00.142453
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_ie = SoundgasmIE()
    assert soundgasm_ie.IE_NAME == 'soundgasm'
    assert soundgasm_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:14:01.655609
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasmIE = SoundgasmIE(downloader=None)
    assert isinstance(soundgasmIE, InfoExtractor)

# Generated at 2022-06-24 13:14:03.452306
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-24 13:14:04.948154
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME in ie.supported_ie




# Generated at 2022-06-24 13:14:06.562419
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    print(ie)

test_SoundgasmIE()

# Generated at 2022-06-24 13:14:07.935233
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    
    assert SoundgasmIE(1)==1


# Generated at 2022-06-24 13:14:12.959368
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    expect_entries = [
        'http://soundgasm.net/u/ytdl/Piano-sample',
    ]
    playlist = SoundgasmProfileIE._real_extract(Url(), url)
    assert playlist["entries"] == expect_entries

# Generated at 2022-06-24 13:14:16.007418
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert re.match(SoundgasmProfileIE._VALID_URL, 'http://soundgasm.net/u/ytdl') is not None


# Generated at 2022-06-24 13:14:23.703498
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    t1 = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert isinstance(t1, SoundgasmIE)
    t2 = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample', 'ytdl')
    assert isinstance(t2, SoundgasmIE)
    assert t1._TEST['url'] == t2._TEST['url']
    assert t1._TEST['md5'] == t2._TEST['md5']


# Generated at 2022-06-24 13:14:24.772393
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('testuser')

# Generated at 2022-06-24 13:14:26.276500
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:14:28.753590
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import socket  # prevent connection errors
    socket.setdefaulttimeout(10)
    e = SoundgasmIE()
    assert e.IE_NAME == 'soundgasm'


# Generated at 2022-06-24 13:14:30.339561
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-24 13:14:33.343866
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?')

# Generated at 2022-06-24 13:14:36.208911
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    play = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert play.__class__.__name__ == 'SoundgasmIE'


# Generated at 2022-06-24 13:14:37.483456
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE(None) is not None


# Generated at 2022-06-24 13:14:41.427103
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE = SoundgasmProfileIE()
    assert IE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:14:47.358698
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('Soundgasm:profile')
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.IE_NAME == 'Soundgasm:profile'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-24 13:14:56.899545
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("Testing constructor of class SoundgasmIE.")
    IE = SoundgasmIE()
    assert IE.IE_NAME == 'soundgasm'
    assert IE._VALID_URL == r'https?://(?:www\.)?sounggasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:14:58.801547
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE(SoundgasmProfileIE._VALID_URL) == SoundgasmProfileIE(SoundgasmProfileIE._VALID_URL)

# Generated at 2022-06-24 13:15:03.921143
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    t = SoundgasmIE()
    assert t._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert t.IE_NAME == 'soundgasm'



# Generated at 2022-06-24 13:15:09.374148
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    iep = SoundgasmProfileIE('www.soundgasm.net/u/ytdl')
    assert iep._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert iep.ie_key() == 'SoundgasmProfile'
    assert iep.ie_name() == 'soundgasm:profile'

# Generated at 2022-06-24 13:15:13.640299
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test construct of SoundgasmIE using url
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasmIE = SoundgasmIE()
    mobj = re.match(soundgasmIE._VALID_URL, url)
    soundgasmIE._real_extract(url)


# Generated at 2022-06-24 13:15:14.447400
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	print("SoundgasmIE passed")

# Generated at 2022-06-24 13:15:25.367558
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Fetching a page that includes Soundgasm audio urls (ie. http://soundgasm.net/u/ytdl/)
    # should return a list of all Soundgasm audio urls
    urls = [
        'http://soundgasm.net/u/ytdl/',
        'http://soundgasm.net/u/ytdl/Piano-sample',
        'http://soundgasm.net/u/ytdl/Another-sample-1',
        'http://soundgasm.net/u/ytdl/Another-sample-2',
        'http://soundgasm.net/u/ytdl/Another-sample-3',
        'http://soundgasm.net/u/ytdl/Another-sample-4',
    ]


# Generated at 2022-06-24 13:15:27.626894
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.extract('http://soundgasm.net/u/ytdl/Piano-sample') != None

# Generated at 2022-06-24 13:15:30.142934
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url ='http://soundgasm.net/u/ytdl'
    obj = SoundgasmProfileIE._real_extract(url)
    assert obj

# Generated at 2022-06-24 13:15:32.518233
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl#'
    obj = SoundgasmProfileIE(url=url)
    assert obj.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-24 13:15:36.175135
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	url = 'http://soundgasm.net/u/ytdl'
	# assert SoundgasmProfileIE._match_id(url) == 'ytdl'
	# assert SoundgasmProfileIE.suitable(url)

# Generated at 2022-06-24 13:15:47.147508
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Generate params for construct SoundgasmIE instance.
    ie = SoundgasmIE()
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    #Construct the SoundgasmIE instance.
    ie = SoundgasmIE()
    # Test the method in class SoundgasmIE, '_real_extract' and '_real_extract'.
    ie.extract(url)
    ie.extract(url)
    # Test the method in class SoundgasmIE, '_real_extract'.
    ie._real_extract(url)
    # Test the method in class SoundgasmIE, '_real_extract'.
    ie._real_extract(url)
    
    

# Generated at 2022-06-24 13:15:50.656731
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE(None)._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:15:51.278795
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE() is not None

# Generated at 2022-06-24 13:15:56.223336
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test = dict()
    test['url'] = 'http://soundgasm.net/u/ytdl'
    soundgasmProfileIE = SoundgasmProfileIE(test)
    assert soundgasmProfileIE.IE_NAME == 'soundgasm:profile', "Value of IE_NAME should be soundgasm:profile"
    assert soundgasmProfileIE.playlist_count == 1, "Value of playlist_count should be 1"


# Generated at 2022-06-24 13:15:58.476527
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	f = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
	assert f is not None

# Generated at 2022-06-24 13:16:00.416763
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE(None)._VALID_URL == SoundgasmIE._VALID_URL


# Generated at 2022-06-24 13:16:11.659311
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .test_soundcloud import SoundcloudIE_TEST
    from .test_youtube import YoutubeIE_TEST

    test_cases = {
        SoundcloudIE_TEST['_TEST'].copy():
        SoundcloudIE_TEST['_TEST']['url'],
        YoutubeIE_TEST['_TEST'].copy():
        YoutubeIE_TEST['_TEST']['url'],
        SoundgasmIE._TEST.copy():
        SoundgasmIE._TEST['url'],
    }


# Generated at 2022-06-24 13:16:22.093229
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import requests
    import re
    import os
    import subprocess
    import sys
    import json
    import urllib
    import shutil
    import io
    import time
    import os.path
    
    # json file to handle user inputs
    # default ytdl_config.json generated at top level directory
    config_file = "ytdl_config.json"

    # location of the parent directory
    parent_dir = os.path.abspath(os.path.join(os.getcwd(), os.pardir))

    # pass the config_file name as an argument
    # if there is no input argument, use default config_file name
    if(len(sys.argv) == 2):
        config_file = sys.argv[1]

# Generated at 2022-06-24 13:16:24.844342
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("\nStarting test of constructor of class SoundgasmIE...")
    assert SoundgasmIE().IE_NAME == "soundgasm"
    print("\nSUCCESS: constructor of class SoundgasmIE works fine!")


# Generated at 2022-06-24 13:16:26.131927
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    return SoundgasmProfileIE("SoundgasmProfileIE", "soundgasm.net")

# Generated at 2022-06-24 13:16:37.051560
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test case 01: Standard case
    # Test case 02: Standard case
    # Test case 03: Class SoundgasmIE takes in a webpage with invalid format 1
    # Test case 04: Class SoundgasmIE takes in a webpage with invalid format 2
    # Test case 05: Class SoundgasmIE takes in a webpage with invalid format 3
    test_cases = ["http://soundgasm.net/u/ytdl/Piano-sample", "http://soundgasm.net/u/ytdl/Piano-sample",
                  "http://soundgasm.net/u/ytdl/Piano-sample/", "http://soundgasm.net/u/ytdl/Piano-sample//",
                  "http://soundgasm.net/u/ytdl/Piano-sample///"]

# Generated at 2022-06-24 13:16:44.253277
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Example of a generated JSON file
    json_str = '[{"f":"https://d1xt1ocedrw1oi.cloudfront.net/file/ytdl/Piano-sample.m4a"},{1:"http://soundgasm.net/u/ytdl/Piano-sample",2:"Piano sample",3:"Royalty Free Sample Music",4:"ytdl"}]'

    # Make assertIsNotNone to the constructor of SoundgasmProfileIE
    assert IE_NAME == 'soundgasm:profile'
    


# Generated at 2022-06-24 13:16:52.496821
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Unit tests for SoundgasmProfileIE
    """
    url = SoundgasmProfileIE._VALID_URL
    mobj = re.match(SoundgasmProfileIE._VALID_URL, url)
    profile_id = mobj.group('id')
    webpage = SoundgasmProfileIE._download_webpage(url, profile_id)
    entries = [
        SoundgasmProfileIE.url_result(audio_url, 'Soundgasm')
        for audio_url in re.findall(r'href="([^"]+/u/%s/[^"]+)' % profile_id, webpage)]
    SoundgasmProfileIE.playlist_result(entries, profile_id)

# Generated at 2022-06-24 13:17:02.469623
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	testurl = 'http://soundgasm.net/u/ytdl/Piano-sample'
	testurl1 = 'http://soundgasm.net/u/ytdl'
	testurl2 = 'http://soundgasm.net/u/ytdl/'
	SoundgasmIE._VALID_URL = r'(?P<quote>(?(quote)%(quote)s|(?:(?!%(quote)s).))+)'

# Generated at 2022-06-24 13:17:03.684075
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:17:04.913563
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import soundgasm
    soundgasm.SoundgasmProfileIE()

# Generated at 2022-06-24 13:17:07.873187
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasm = SoundgasmIE(url)
    assert soundgasm.match(url)

# Generated at 2022-06-24 13:17:09.190468
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE('http://soundgasm.net/u/ytdl') is not None)

# Generated at 2022-06-24 13:17:12.013932
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[^/]+)/(?P<display_id>[^/]+)'

# Generated at 2022-06-24 13:17:13.595628
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().extract('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:17:23.325634
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    extractor = SoundgasmIE()
    assert extractor.suitable(test_url)
    assert extractor.IE_NAME == 'Soundgasm'
    assert extractor.__name__ == 'Soundgasm'
    assert extractor._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert extractor._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'

# Generated at 2022-06-24 13:17:32.320094
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    # Created by using main/test/test_xpath.py
    xpath_test_path = '../test/test.xml'
    xml = xpath.html.fromstring(open(xpath_test_path, 'r').read())
    urls = ie._html_search_regex(r'href="([^"]+)', xml, 'html', fatal=False)
    lst = ie._html_search_regex(r'xpath', xml, 'html', fatal=False)

    if (urls != None):
        print('HTML regex test passed.')
    else:
        print('HTML regex test failed.')

    if (lst != None):
        print('XPath regex test passed.')
    else:
        print('XPath regex test failed.')


# Generated at 2022-06-24 13:17:35.554371
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()

# Generated at 2022-06-24 13:17:36.614747
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    object = SoundgasmProfileIE(InfoExtractor())

# Generated at 2022-06-24 13:17:38.232165
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert isinstance(SoundgasmProfileIE, InfoExtractor)


# Generated at 2022-06-24 13:17:48.562531
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test profile
    ie = SoundgasmProfileIE({"url": "http://soundgasm.net/u/ytdl", "ie": "Soundgasm"})

    # Test field ie of class SoundgasmProfileIE
    assert ie.ie == "Soundgasm"
    # Test field info_dict of class SoundgasmProfileIE
    info_dict = {"id": "ytdl"}
    assert ie.info_dict == info_dict
    # Test field _VALID_URL of class SoundgasmProfileIE
    VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._VALID_URL == VALID_URL
    # Test field _TEST of class SoundgasmProfileIE
   

# Generated at 2022-06-24 13:17:49.196568
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('SoundgasmProfile')

# Generated at 2022-06-24 13:17:53.954324
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # check the example from class docstring
    assert SoundgasmIE._TEST == {
        'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
        'md5': '010082a2c802c5275bb00030743e75ad',
        'info_dict': {
            'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
            'ext': 'm4a',
            'title': 'Piano sample',
            'description': 'Royalty Free Sample Music',
            'uploader': 'ytdl',
        }
    }

# Generated at 2022-06-24 13:17:57.569894
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    v = SoundgasmIE()
    assert v.ie_key() == 'Soundgasm'
    assert v.IE_NAME == 'Soundgasm'


# Generated at 2022-06-24 13:18:01.536380
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    profile_id = 'foo'
    url = 'http://soundgasm.net/u/%s/' % (profile_id)
    ie.url = url
    assert ie._match_id(url) == profile_id
    assert ie._real_extract(url)['id'] == profile_id

# Generated at 2022-06-24 13:18:04.538009
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_instance = SoundgasmProfileIE()
    assert SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:18:10.677159
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.can_extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie.can_extract('http://soundgasm.net/u/ytdl/Piano-sample#comments')
    assert not ie.can_extract('http://soundgasm.net/u/ytdl/')
    assert not ie.can_extract('http://soundgasm.net/u/ytdl/Piano-sample2')

# Generated at 2022-06-24 13:18:12.168951
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:18:16.996814
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_SoundgasmProfileIE.last_url = 'http://soundgasm.net/u/ytdl'
    _VALID_URL = test_SoundgasmProfileIE.last_url
    test_SoundgasmProfileIE.last_info_dict = {
        'id': 'ytdl',
    }
    _TEST = test_SoundgasmProfileIE.last_info_dict
    test_SoundgasmProfileIE.last_playlist_count = 1
    _TEST_2 = test_SoundgasmProfileIE.last_playlist_count
    entries = [
            self.url_result('http://soundgasm.net/u/ytdl/Piano-sample', 'Soundgasm')
            ]
    expected = self.playlist_result(entries, 'ytdl')

# Generated at 2022-06-24 13:18:20.968830
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    file = open("soundgasm.html", "r")

    webpage = file.read()

    result = re.findall(r'href="([^"]+/u/[^"]+)"', webpage)

    print("Test result: ", result)