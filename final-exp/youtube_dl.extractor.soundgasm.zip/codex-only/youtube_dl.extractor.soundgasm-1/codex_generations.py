

# Generated at 2022-06-24 13:08:22.654082
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	url = "http://soundgasm.net/u/ytdl/Piano-sample"
	e = SoundgasmIE()
	assert e._real_extract(url) is not None

# Generated at 2022-06-24 13:08:25.699394
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    extractor = SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')
    assert 'Piano-sample' == extractor.display_id
    assert 'https://soundgasm.net/u/ytdl/Piano-sample' == extractor.url


# Generated at 2022-06-24 13:08:28.242639
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE = SoundgasmIE()
    url = IE._VALID_URL
    info = IE._real_extract(url)
    print (info)
    return info


# Generated at 2022-06-24 13:08:31.380174
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE('Soundgasm Profile')
    print('SoundgasmProfileIE:', soundgasm_profile_ie)

# Generated at 2022-06-24 13:08:33.158106
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert (SoundgasmProfileIE._TEST['url'] == 'http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:08:41.872865
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from youtube_dl.utils import FakeYDL
    from os.path import dirname, join, realpath
    from json import loads

    # Load expected output from file
    input_json_file = join(dirname(realpath(__file__)), 'SoundgasmProfileIE_input.json')
    with open(input_json_file, 'r') as fin:
        expected_entries = loads(fin.read())

    ydl = FakeYDL()
    ydl.add_default_info_extractors()

    ie = SoundgasmProfileIE(ydl)
    ie_result = ie._real_extract('http://soundgasm.net/u/ytdl')

    assert ie_result['_type'] == 'playlist'
    assert ie_result['id'] == 'ytdl'

# Generated at 2022-06-24 13:08:44.872380
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._NAME == 'Soundgasm'
    assert ie._VALID_URL == SoundgasmIE._VALID_URL

# Generated at 2022-06-24 13:08:53.421599
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    videolist = ie.extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert 'no_of_entries' in videolist
    assert len(videolist['entries']) == 1
    assert len(videolist['entries'][0]['id']) > 0
    assert len(videolist['entries'][0]['description']) > 0
    assert len(videolist['entries'][0]['title']) > 0
    assert len(videolist['entries'][0]['display_id']) > 0

# Generated at 2022-06-24 13:09:01.422403
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'https://soundgasm.net/u/ytdl/Piano-sample'
    display_id = 'Piano-sample'
    webpage = """
    <html>
        <div class="jp-title">Piano sample</div>
        <div class="jp-description">Royalty Free Sample Music</div>
        <script>
            var test = {
                title: 'Piano sample',
                m4a: 'http://somewhere.com/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
            };
        </script>
    </html>
    """


# Generated at 2022-06-24 13:09:06.638848
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    i = SoundgasmIE()
    assert i.IE_NAME == 'soundgasm'
    assert i._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:09:17.784815
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = SoundgasmIE()
    # SoundgasmIE.IE_NAME
    assert test.IE_NAME == 'soundgasm'
    # SoundgasmIE._VALID_URL
    assert test._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    # SoundgasmIE._TEST

# Generated at 2022-06-24 13:09:19.830648
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    s = SoundgasmProfileIE()
    print(s)
    print(s.__class__)

test_SoundgasmProfileIE()

# Generated at 2022-06-24 13:09:21.142562
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    e = SoundgasmIE()
    assert_equal(e.__class__.__name__, 'SoundgasmIE')

# Generated at 2022-06-24 13:09:23.395326
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-24 13:09:25.451727
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    match = SoundgasmIE._VALID_URL.match('http://soundgasm.net/u/ytdl/Piano-sample')
    assert match is not None
    assert SoundgasmIE._download_webpage is not None


# Generated at 2022-06-24 13:09:30.510501
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE()
    assert(instance.ie_key() == "SoundgasmProfile")
    assert(instance.IE_NAME == "SoundgasmProfile")
    assert(instance.thumbnail == r"http://img\.youtube\.com/vi/%(id)s/hqdefault\.jpg")

# Generated at 2022-06-24 13:09:40.288378
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    input_string = ie.extract (test_url)
    # testing extract method
    assert input_string['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert input_string['url'] == 'http://soundgasm-mp3.s3.amazonaws.com/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    # testing constructor

# Generated at 2022-06-24 13:09:42.286319
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
  ie = SoundgasmIE("", "")
  ie.extract("<html></html>")

# Generated at 2022-06-24 13:09:47.223637
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        assert SoundgasmProfileIE.ie_key() == 'SoundgasmProfile'
        assert SoundgasmProfileIE.ie_key() == 'Soundgasm'
        assert SoundgasmProfileIE.ie_key() == 'Soundgasm'
        assert SoundgasmProfileIE.ie_key() == 'Soundgasm'
        assert SoundgasmProfileIE.ie_key() == 'Soundgasm'
    finally:
        pass


# Generated at 2022-06-24 13:09:55.674732
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    if SoundgasmProfileIE.IE_NAME is None:
        return
    ie = SoundgasmProfileIE(None)
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-24 13:10:00.168966
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasm_ie = SoundgasmIE(None)
    info_dict = soundgasm_ie._get_info_dict(url)
    assert (info_dict.get('display_id') == 'Piano-sample')

# Generated at 2022-06-24 13:10:02.398223
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info_extractor = SoundgasmProfileIE()
    assert info_extractor.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-24 13:10:13.133801
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	IE = SoundgasmIE()

	assert_equal(IE.IE_NAME, 'soundgasm')
	assert_equal(IE._VALID_URL, r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-24 13:10:14.437703
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE(None).IE_NAME == 'Soundgasm'

# Generated at 2022-06-24 13:10:19.869482
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Constructor test for SoundgasmIE using a dummy URL.

    This is a unit test for the SoundgasmIE constructor.
    """
    ie = SoundgasmIE(SoundgasmIE._TEST)
    assert ie.extract(SoundgasmIE._TEST['url']).__class__ == dict


# Generated at 2022-06-24 13:10:27.641309
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()

    assert soundgasm.IE_NAME == 'soundgasm'
    # Test of VALID_URL attribute
    assert re.match(soundgasm._VALID_URL, 'http://soundgasm.net/u/ytdl/Piano-sample')
    assert re.match(soundgasm._VALID_URL, 'http://www.soundgasm.net/u/ytdl/Piano-sample')
    assert re.match(soundgasm._VALID_URL, 'http://soundgasm.net/u/ytdl/Piano-sample?o=0')
    assert re.match(soundgasm._VALID_URL, 'http://www.soundgasm.net/u/ytdl/Piano-sample?o=0#comments')

# Generated at 2022-06-24 13:10:30.127022
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Check whether the constructor of SoundgasmProfileIE does not fail
    soundgasm_profile_ie = SoundgasmProfileIE("")

# Generated at 2022-06-24 13:10:32.917932
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('test', 'http://soundgasm.net/u/ytdl')
    assert ie.IES_TO_SCRAP == ['Soundgasm']

# Generated at 2022-06-24 13:10:33.795894
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # SoundgasmIE()
    assert True

# Generated at 2022-06-24 13:10:35.897405
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .test_soundcloud import get_playlist_url_test

# Generated at 2022-06-24 13:10:36.400466
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert 1 == 1

# Generated at 2022-06-24 13:10:36.910239
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	SoundgasmIE()

# Generated at 2022-06-24 13:10:47.641616
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:10:55.797722
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Unit test for constructor of class SoundgasmProfileIE.
    """
    obj_SoundgasmProfileIE = SoundgasmProfileIE()
    #print 'Web Page URL ="%s"'%obj_SoundgasmProfileIE._TEST['url']

# Generated at 2022-06-24 13:11:06.532734
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # get a SoundgasmIE to work with
    ie = SoundgasmIE()
    # get the test url
    url = ie._TEST['url']
    # get the expected id
    id = ie._TEST['info_dict']['id']
    # get the expected title
    title = ie._TEST['info_dict']['title']
    # get the expected description
    description = ie._TEST['info_dict']['description']
    # get the expected uploader
    uploader = ie._TEST['info_dict']['uploader']
    # give this a try

# Generated at 2022-06-24 13:11:13.364090
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Basic unit test for constructor of class SoundgasmIE
    """
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE()._real_initialize()

    download_info = ie._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert download_info['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert download_info['url'].startswith('http://www.soundgasm.net/sounds/')

# Generated at 2022-06-24 13:11:16.020025
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert isinstance(ie, SoundgasmIE)
    assert ie.IE_NAME == 'SoundgasmIE'


# Generated at 2022-06-24 13:11:19.149748
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print('Testing constructor of SoundgasmIE class...')
    obj_SoundgasmIE = SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')



# Generated at 2022-06-24 13:11:25.666915
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    
# Test snippet of code
# Test if the constructor of class SoundgasmProfileIE works
    SoundgasmProfileIE()

# Test snippet of code
# Test if the function _real_extract of class SoundgasmProfileIE works    

# Generated at 2022-06-24 13:11:28.514144
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Unit test for the constructor of SoundgasmIE
    """
    obj = SoundgasmIE()
    assert obj.IE_NAME == 'Soundgasm'


# Generated at 2022-06-24 13:11:30.167094
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    model = SoundgasmProfileIE()
    url = "http://soundgasm.net/u/ytdl"
    assert model.ie_key() == 'Soundgasm'
    assert model._match_id(url) == 'ytdl'


# Generated at 2022-06-24 13:11:34.012032
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test if it can be instantiated
    assert (SoundgasmIE() != None)

    # Test if it can be instantiated
    # assert (SoundgasmProfileIE() != None)

# Test if class SoundgasmIE has the attribute '_VALID_URL'

# Generated at 2022-06-24 13:11:34.962394
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	SoundgasmProfileIE()


# Generated at 2022-06-24 13:11:44.786857
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test with no playlists
    profileIE1 = SoundgasmProfileIE('http://soundgasm.net/u/soundgasm_net')
    assert profileIE1.url == 'http://soundgasm.net/u/soundgasm_net'
    assert profileIE1.name == 'SoundgasmProfile'
    assert profileIE1.id == 'soundgasm_net'
    assert profileIE1._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

    # Test with playlists
    profileIE2 = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert profileIE2.url == 'http://soundgasm.net/u/ytdl'
   

# Generated at 2022-06-24 13:11:50.902877
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE()
    assert profile.IE_NAME == 'soundgasm:profile'
    assert profile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert profile._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert profile._TEST['info_dict']['id'] == 'ytdl'
    assert profile._TEST['playlist_count'] == 1

# Generated at 2022-06-24 13:11:56.912804
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    profile_ie = SoundgasmProfileIE({})

    assert profile_ie.IE_NAME == 'soundgasm:profile'
    assert profile_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert profile_ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert profile_ie._TEST['info_dict']['id'] == 'ytdl'
    assert profile_ie._TEST['playlist_count'] == 1
    assert profile_ie.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-24 13:12:01.581794
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    inst = SoundgasmIE()
    assert inst._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:12:03.422726
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()._download_webpage('http://soundgasm.net/u/ytdl/Piano-sample', 'Piano-sample')

# Generated at 2022-06-24 13:12:10.773604
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE(url)
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie._TEST['url'] == url
    assert ie._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'
    assert ie._TEST['info_dict']['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'


# Generated at 2022-06-24 13:12:11.590045
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    S = SoundgasmProfileIE()
    assert S != None

# Generated at 2022-06-24 13:12:22.935189
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    t = SoundgasmIE()
    # test the __init__ function of SoundgasmIE
    assert t.IE_NAME == 'soundgasm', 'Constructor of SoundgasmIE class is test failed'
    assert t._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)', 'Constructor of SoundgasmIE class is test failed'

# Generated at 2022-06-24 13:12:24.525626
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'    
             

# Generated at 2022-06-24 13:12:28.744833
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')._VALID_URL == '^http?://(?:www\\.)?soundgasm\\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:12:31.876490
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # This is a simple test for constructor of class SoundgasmIE
    test_SoundgasmIE = SoundgasmIE()
    assert test_SoundgasmIE.__class__.__name__ == 'SoundgasmIE'


# Generated at 2022-06-24 13:12:40.663834
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # instantiate a SoundgasmProfileIE object
    soundgProfile = SoundgasmProfileIE()

    assert(soundgProfile.IE_NAME == 'soundgasm:profile')
    assert(soundgProfile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')

    soundgProfileTest = soundgProfile._TEST
    assert(soundgProfileTest['url'] == 'http://soundgasm.net/u/ytdl')
    soundgProfileTestInfo = soundgProfileTest['info_dict']
    assert(soundgProfileTestInfo['id'] == 'ytdl')
    playlistCount = soundgProfileTest['playlist_count']
    assert(playlistCount == 1)

# Generated at 2022-06-24 13:12:43.948773
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl#f', {}, None)
    assert ie.url == 'http://soundgasm.net/u/ytdl/'



# Generated at 2022-06-24 13:12:45.318790
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	SoundgasmProfileIE("https://soundgasm.net/u/ytdl")

# Generated at 2022-06-24 13:12:47.562447
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # https://soundgasm.net/u/ytdl/
    return SoundgasmProfileIE()._real_extract('http://soundgasm.net/u/ytdl/')

# Generated at 2022-06-24 13:12:49.573189
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    expected = 'Soundgasm'
    assert obj._VALID_URL == expected

# Generated at 2022-06-24 13:12:59.478739
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import random
    import time

    print("\nTesting SoundgasmProfileIE...")

    # Create object of class SoundgasmProfileIE
    test_obj = SoundgasmProfileIE(SoundgasmIE(), SoundgasmIE._TEST)

    # Required fields
    display_id = 'kite-surfer-' + str(random.randint(1, 100)) + '_' + str(time.time())
    test_obj._TEST = {
        'url': 'http://soundgasm.net/u/ytdl/' + display_id,
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

    # Extract info
    print("Testing extract method...")

# Generated at 2022-06-24 13:13:00.529254
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE(None) != None)


# Generated at 2022-06-24 13:13:02.519410
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test constructor of SoundgasmIE.
    return SoundgasmIE(None)

if __name__ == '__main__':
    test_SoundgasmIE()

# Generated at 2022-06-24 13:13:05.672983
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    oIE = SoundgasmProfileIE("SoundgasmProfileIE")
    print("oIE.IE_NAME: %s" % oIE.IE_NAME)
    print("oIE.IE_DESC: %s" % oIE.IE_DESC)

# Generated at 2022-06-24 13:13:09.128602
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj1 = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    obj2 = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert obj1 == obj2


# Generated at 2022-06-24 13:13:11.738857
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # The test passes if the constructor doesn't throw an AssertionError
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:13:16.914734
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    inst = SoundgasmProfileIE()
    assert inst._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'
    assert inst._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert inst._TEST['playlist_count'] == 1

# Generated at 2022-06-24 13:13:18.390367
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    def _get_sg_ie():
        return SoundgasmIE(None)
    assert _get_sg_ie() is not None
    assert _get_sg_ie().IE_NAME == 'soundgasm'



# Generated at 2022-06-24 13:13:20.292094
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Creation
    soundgasm_ie = SoundgasmIE()
    print(soundgasm_ie)

# Generated at 2022-06-24 13:13:30.885076
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    '''
    Test case for SoundgasmIE.
    '''
    soundgasm_ie=SoundgasmIE()
    soundgasm_ie.IE_NAME='soundgasm'
    assert soundgasm_ie.IE_NAME=='soundgasm'
    assert soundgasm_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:13:32.351025
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:13:41.494584
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from pprint import pprint
    from nose.tools import assert_equal
    from soundgasm_dl import __version__
    from soundgasm_dl import _soundgasm_dl_main as main

    print('Running test on soundgasm_dl, version', __version__)

    url = 'http://soundgasm.net/u/ytdl'

    def run_SoundgasmProfileIE(argv):
        ie = SoundgasmProfileIE()
        print('url: {}'.format(url))
        pprint(ie._real_extract(url))
        return

    assert_equal(main(['--test-SoundgasmProfileIE']), 0)
    assert_equal(main(['--test-SoundgasmProfileIE', url]), 0)

# Generated at 2022-06-24 13:13:42.249011
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_SoundgasmIE.instance = SoundgasmIE()

# Generated at 2022-06-24 13:13:47.769299
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test constructor of class SoundgasmIE
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert isinstance(ie, SoundgasmIE)
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'
    assert ie._T

# Generated at 2022-06-24 13:13:53.083746
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    s = SoundgasmIE('Soundgasm')
    assert(s._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')


# Generated at 2022-06-24 13:13:55.741459
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE().suitable(url)



# Generated at 2022-06-24 13:13:58.169294
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE(url)

# Generated at 2022-06-24 13:14:05.770525
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    i = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert i._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:14:12.076935
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Unit test for constructor of class SoundgasmProfileIE"""
    # Test case:
    #   'http://soundgasm.net/u/ytdl'
    profileIe = SoundgasmProfileIE(None, None)
    assert isinstance(profileIe, InfoExtractor)
    assert profileIe.IE_NAME == 'soundgasm:profile'
    assert 'SoundgasmProfileIE' in profileIe.__repr__()


# Generated at 2022-06-24 13:14:15.661707
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert(SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample') == SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample'))

# Generated at 2022-06-24 13:14:19.405085
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_url = "http://soundgasm.net/u/ytdl"
    test_esult = SoundgasmProfileIE().extract(test_url) 
    assert SoundgasmProfileIE()._match_id(test_url) == test_esult['id']
    assert SoundgasmProfileIE()._TEST['url'] == test_url
    

# Generated at 2022-06-24 13:14:20.584119
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()

# Generated at 2022-06-24 13:14:23.758734
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    sie = SoundgasmIE()
    sie._download_webpage(url, 'Piano-sample')

# Generated at 2022-06-24 13:14:27.852325
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import random

    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'
    

# Generated at 2022-06-24 13:14:28.432538
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-24 13:14:38.017799
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Constructor should throw exception if an audio file is not found in the URL
    # The following URL is a valid URL but it does not have an audio file
    url = 'http://soundgasm.net/u/ytdl/piano-sample'
    soundgasmIE = SoundgasmIE()
    try:
        soundgasmIE._real_extract(url)
        raise AssertionError('constructor should throw exception if an audio file is not found in the URL')
    except:
        pass
    url = 'http://soundgasm.net/u/ytdl'
    try:
        soundgasmIE._real_extract(url)
        raise AssertionError('constructor should throw exception if an audio file is not found in the URL')
    except:
        pass
    # Constructor should not throw any exception once

# Generated at 2022-06-24 13:14:41.359949
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Create an instance of SoundgasmProfileIE class.

    When we call the constructor,
    the IE_NAME is set to the expected value.
    """
    ie_SoundgasmProfileIE = SoundgasmProfileIE()

    assert ie_SoundgasmProfileIE.IE_NAME == 'SoundgasmProfileIE'

# Generated at 2022-06-24 13:14:49.168668
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == 'soundgasm'
    assert SoundgasmIE()._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert SoundgasmIE()._TEST.get('url') == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert SoundgasmIE()._TEST.get('md5') == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-24 13:14:57.586764
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    audio_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    display_id = 'Piano-sample'
    title = 'Piano sample'
    description = 'Royalty Free Sample Music'
    uploader = 'ytdl'

    _TEST = {
        'url': url,
        'md5': '010082a2c802c5275bb00030743e75ad',
        'info_dict': {
            'id': audio_id, 
            'ext': 'm4a', 
            'title': title, 
            'description': description, 
            'uploader': uploader,
        }
    }


# Generated at 2022-06-24 13:14:59.183335
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert(SoundgasmProfileIE.IE_NAME == 'soundgasm:profile')


# Generated at 2022-06-24 13:15:06.261195
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert SoundgasmProfileIE._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert SoundgasmProfileIE._TEST['info_dict']['id'] == 'ytdl'
    assert SoundgasmProfileIE._TEST['playlist_count'] == 1


# Generated at 2022-06-24 13:15:14.977447
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # test for SoundgasmProfileIE with input url
    s = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    # the assert statements checks if the url is valid
    assert s._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    # the asert statements checks if the name is valid
    assert s.IE_NAME == 'soundgasm:profile'
    # the asert statements checks if the test is valid
    assert s._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert s._TEST['info_dict']['id'] == 'ytdl'

# Generated at 2022-06-24 13:15:19.422307
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ydl = SoundgasmProfileIE()
    playlist_url = "https://soundgasm.net/u/tiger89"
    expected_playlist_id = "tiger89"

    assert expected_playlist_id == ydl._match_id(url=playlist_url)



# Generated at 2022-06-24 13:15:30.185760
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import json
    from .common import expected_warnings

    info = SoundgasmProfileIE()._real_extract('http://soundgasm.net/u/ytdl/')
    assert info == {
        '_type': 'playlist',
        'id': 'ytdl',
        'entries': [
            {
                '_type': 'url',
                'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
                'ie_key': 'Soundgasm',
            },
        ],
    }

    json_str = json.dumps(info)

# Generated at 2022-06-24 13:15:30.800033
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE

# Generated at 2022-06-24 13:15:33.304016
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://www.soundgasm.net/u/ytdl/')
    assert ie.profile_id == 'ytdl'

    ie = SoundgasmProfileIE('http://www.soundgasm.net/u/ytdl')
    assert ie.profile_id == 'ytdl'

# Generated at 2022-06-24 13:15:35.671068
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    t = SoundgasmProfileIE()
    t.url = 'http://soundgasm.net/u/ytdl/'

# Generated at 2022-06-24 13:15:42.599114
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test __init__() of class SoundgasmIE
    ie = SoundgasmIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie.IE_NAME == 'soundgasm'


# Generated at 2022-06-24 13:15:45.107870
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	r = re.compile(r'href="([^"]+/u/%s/[^"]+)' % profile_id)
	assert r == r

# Generated at 2022-06-24 13:15:48.634827
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """ Unit test for constructor of class SoundgasmProfileIE """

    # Calling constructor with "ytdl" as profile_id
    assert(SoundgasmProfileIE("ytdl").profile_id == "ytdl")


# Generated at 2022-06-24 13:15:53.228290
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_ie = SoundgasmProfileIE()
    assert test_ie.IE_NAME == 'soundgasm:profile'
    assert test_ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'



# Generated at 2022-06-24 13:16:00.916263
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm = SoundgasmProfileIE()
    assert soundgasm.IE_NAME == 'soundgasm:profile'
    assert soundgasm._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert soundgasm._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-24 13:16:12.152713
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie.IE_NAME == 'soundgasm'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'
    assert ie._TEST['info_dict']['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-24 13:16:22.556756
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Simulate webpage from soundgasm.net/u/ytdl and ensure that
    the resulting playlist contains an audio item for each
    known soundgasm.net/u/ytdl/<filename> sample
    """
    test = SoundgasmProfileIE()
    test.to_screen = lambda *args, **kwargs: None
    test._download_webpage = lambda *args, **kwargs: """
    <div class="jp-playlist">
    <ul>
    <li>
    <a href="/u/ytdl/Piano-sample">Piano sample</a>
    </li>
    <li>
    <a href="/u/ytdl/Bowed-glass">Bowed glass</a>
    </li>
    </ul>
    </div>
    """

# Generated at 2022-06-24 13:16:27.593893
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert ie._TEST['info_dict']['id'] == 'ytdl'
    assert ie._TEST['playlist_count'] == 1


# Generated at 2022-06-24 13:16:30.667226
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # This will only test whether this test case is working with the testing
    # framework.
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == SoundgasmProfileIE.IE_NAME

# Generated at 2022-06-24 13:16:40.151323
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE();

    print ("Testing SoundgasmIE constructor\n")
    assert (ie.IE_NAME == 'soundgasm')
    assert (ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-24 13:16:50.622308
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # first audio
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasmIE = SoundgasmIE()
    # audio_id = (88abd86ea000cafe98f96321b23cc1206cbcbcc9)
    assert soundgasmIE.IE_NAME == 'soundgasm'
    assert SoundgasmIE._VALID_URL == 'https?://(?:www\\.)?soundgasm\\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert SoundgasmIE._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    # test if vod

# Generated at 2022-06-24 13:16:52.067825
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE.ie_key() == SoundgasmIE.ie_key()


# Generated at 2022-06-24 13:16:55.614445
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ins = SoundgasmIE()
    assert ins._VALID_URL is not None
    assert ins._TEST is not None
    assert ins._download_webpage is not None
    assert ins._html_search_regex is not None
    assert ins._search_regex is not None

# Generated at 2022-06-24 13:16:57.187324
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from . import soundgasm
    assert isinstance(soundgasm.SoundgasmProfileIE, InfoExtractor)

# Generated at 2022-06-24 13:17:00.211025
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    # Constructor test 1
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    try:
        SoundgasmIE(url)
    except:
        print("Passed first test in SoundgasmIE")
    else:
        print("Failed first test in SoundgasmIE")
        exit(1)



# Generated at 2022-06-24 13:17:01.248564
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE(None)


# Generated at 2022-06-24 13:17:08.085065
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.extraction_exceptions == {
        'http://soundgasm.net/u/ytdl/Piano-sample',
        'http://soundgasm.net/u/ytdl',
    }
    assert  ie.extraction_failure_reasons == {
        'http://soundgasm.net/u/ytdl/Piano-sample': 'Unable to extract js code.',
        'http://soundgasm.net/u/ytdl': 'Unable to extract js code.'
    }

# Generated at 2022-06-24 13:17:13.697185
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test for normal constructor of class SoundgasmProfileIE
    ie = SoundgasmProfileIE('http://soundgasm.net/u/test')
    assert ie.name == 'Soundgasm:profile'
    assert ie.ID == 'test'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/test',
        'info_dict': {
            'id': 'test',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-24 13:17:15.571132
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    isinstance(SoundgasmIE(), InfoExtractor)


# Generated at 2022-06-24 13:17:17.643772
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl', 'ytdl')

# Generated at 2022-06-24 13:17:19.008053
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE('www.soundgasm.net')

# Generated at 2022-06-24 13:17:21.134812
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import bs4
    site = SoundgasmIE()
    assert type(site) == SoundgasmIE


# Generated at 2022-06-24 13:17:22.076746
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:17:25.660983
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    test = SoundgasmProfileIE._TEST['url'] == url

# Generated at 2022-06-24 13:17:33.633261
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-24 13:17:43.473250
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-24 13:17:44.499619
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE(True)


# Generated at 2022-06-24 13:17:49.800626
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import dev_playlists
    DEV_PLAYLISTS_URL = dev_playlists[-1]
    soundgasmIE = SoundgasmProfileIE(DEV_PLAYLISTS_URL)
    expected = SoundgasmProfileIE.IE_NAME
    actual = soundgasmIE.ie_key()
    assert(expected == actual)


# Generated at 2022-06-24 13:18:00.131409
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    # Download the webpage
    webpage = download(url)
    # Create an instance of SoundgasmIE
    ie = SoundgasmIE()
    # Extract audio url
    audio_url = "http://soundgasm.net/m4a/4f/4f846b76695337edf258b0d2c8f3f7f0.m4a"
    # Simulate the response from '_download_webpage'
    # classes in python are functions
    # Extract name of artist
    mobj = re.match(ie._VALID_URL, url)
    # Extract the username
    user_name = mobj.group('user')
    # Extract the name of audio
    display_id = mobj.group

# Generated at 2022-06-24 13:18:01.720477
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    e = SoundgasmIE()
    assert e.IE_NAME == 'soundgasm'


# Generated at 2022-06-24 13:18:09.168541
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE_NAME = 'soundgasm:profile'
    _VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

    sg = SoundgasmProfileIE()
    test = {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

    assert sg.ie_key() == IE_NAME, "The IE_NAME should be " + IE_NAME + ", but it's " + sg.ie_key()
    assert sg._VALID_URL == _VALID_URL, "The _VALID_URL should be " + _VALID

# Generated at 2022-06-24 13:18:11.639257
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # This raises the exception if the class can't be instantiated
    SoundgasmIE()


# Generated at 2022-06-24 13:18:16.531524
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._match_id('https://soundgasm.net/u/ytdl/Piano-sample') == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert ie._match_id('https://soundgasm.net/u/ytdl') == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert ie._download_webpage(
        'https://soundgasm.net/u/ytdl/Piano-sample',
        'https://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:18:22.685268
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE._TEST = {
        'url': 'http://soundgasm.net/u/1user',
        'info_dict': {
            'id': '1user',
        },
        'playlist_count': 1,
    }

    SoundgasmProfileIE(test_SoundgasmProfileIE.test_data,test_SoundgasmProfileIE.test_id,test_SoundgasmProfileIE.test_result)
