

# Generated at 2022-06-24 13:08:20.555322
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()

# Generated at 2022-06-24 13:08:27.525560
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	extractor = SoundgasmIE()
	assert extractor.IE_NAME == "soundgasm"
	assert extractor._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:08:32.838654
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	infoExtractor = SoundgasmIE()
	assert infoExtractor._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-24 13:08:33.755099
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	print(SoundgasmIE)

# Generated at 2022-06-24 13:08:38.825524
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest
    from soundgasm.utils import download_page

    # url from code above
    url = "http://soundgasm.net/u/ytdl"
    # download page content
    content = download_page(url)
    # get it
    ie = SoundgasmProfileIE()
    play_list = ie._real_extract(url)
    # get playlist
    list = play_list["entries"]
    # count playlist
    count = play_list["playlist_count"]
    
    # tests
    class SoundgasmProfileIE_tests(unittest.TestCase):

        def test_download_page_and_count_list(self):
            self.assertEqual(count, len(list))


# Generated at 2022-06-24 13:08:43.254161
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None, 'http://soundgasm.net/u/ytdl')
    SoundgasmProfileIE(None, 'http://soundgasm.net/u/ytdl/')
    SoundgasmProfileIE(None, 'http://soundgasm.net/u/ytdl#comments')
    SoundgasmProfileIE(None, 'http://soundgasm.net/u/ytdl/#comments')

# Generated at 2022-06-24 13:08:46.612972
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE(None)
    assert(a._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')

# Generated at 2022-06-24 13:08:49.899759
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    id = 'ytdl'
    url = 'https://soundgasm.net/u/ytdl/'

# Generated at 2022-06-24 13:08:50.585351
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	pass

# Generated at 2022-06-24 13:08:59.314305
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    result = SoundgasmIE('Soundgasm', 'http://soundgasm.net/u/ytdl/Piano-sample')

    assert result._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert result._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert result._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-24 13:09:00.913356
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('SoundgasmProfileIE', 'test_SoundgasmProfileIE', 'url')

# Generated at 2022-06-24 13:09:03.479833
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:09:09.561930
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    audio_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mobj = re.match(ie._VALID_URL, audio_url)
    # Test that constructor of class SoundgasmIE can extract video id
    assert mobj.group('display_id') == 'Piano-sample'


# Generated at 2022-06-24 13:09:11.295828
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  SoundgasmProfileIE().extract_info_dict('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:09:12.090768
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME is 'Soundgasm'
    

# Generated at 2022-06-24 13:09:14.265428
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:09:17.077662
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._download_webpage('http://soundgasm.net/u/ytdl', 'ytdl')



# Generated at 2022-06-24 13:09:20.181653
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = SoundgasmIE(_call_downloader=mock_downloader, _downloader=mock_downloader)
    assert test._downloader is mock_downloader
    assert test._call_downloader is mock_downloader


# Generated at 2022-06-24 13:09:23.042294
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    '''
    Here we are testing whether the soundgasm constructor is working or not.
    If it works then the assert statement should be True
    else the assertion will fail.
    '''
    ie = SoundgasmIE()
    assert isinstance(ie, SoundgasmIE)

# Generated at 2022-06-24 13:09:27.780039
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE()
    assert soundgasm_profile_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert soundgasm_profile_ie.IE_NAME == 'soundgasm:profile'
    assert soundgasm_profile_ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-24 13:09:31.585184
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert SoundgasmProfileIE(obj={})._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:09:33.870443
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    passed = False
    try:
        SoundgasmProfileIE()
        passed = True
    except:
        passed = False
    assert passed

# Generated at 2022-06-24 13:09:35.497981
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:09:38.670408
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    return SoundgasmIE()._download_url('http://www.soundgasm.net/u/ytdl/Piano-sample', '88abd86ea000cafe98f96321b23cc1206cbcbcc9')

# Generated at 2022-06-24 13:09:42.282443
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-24 13:09:46.385564
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_object = SoundgasmProfileIE()
    expected_match = True
    
    result = (test_object._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
    assert result == expected_match, 'Test failed because expected match was not found'

# Generated at 2022-06-24 13:09:47.153708
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('')

# Generated at 2022-06-24 13:09:48.052260
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-24 13:09:57.523704
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	test_SoundgasmIE = SoundgasmIE()
	test_soundgasm_obj = test_SoundgasmIE._real_extract("http://soundgasm.net/u/ytdl/Piano-sample")
	print(test_soundgasm_obj['id'])
	print(test_soundgasm_obj['display_id'])
	print(test_soundgasm_obj['url'])
	print(test_soundgasm_obj['vcodec'])
	print(test_soundgasm_obj['title'])
	print(test_soundgasm_obj['description'])
	print(test_soundgasm_obj['uploader'])
	return


# Generated at 2022-06-24 13:10:00.761772
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    for i in range(4):  # fail too often?
        iep = SoundgasmProfileIE(0)
        assert isinstance(iep, SoundgasmProfileIE)


# Generated at 2022-06-24 13:10:04.271027
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:10:08.826197
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info_extractor = SoundgasmProfileIE()

    assert info_extractor.IE_NAME == 'SoundgasmProfileIE'
    assert info_extractor.IE_NAME == "soundgasm:profile"
    assert info_extractor.IE_VERSION == '20170430'



# Generated at 2022-06-24 13:10:13.180223
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    tmp_class = SoundgasmProfileIE
    assert tmp_class 
    
    #given
    url = "http://soundgasm.net/u/ytdl"

    #when
    tmp_instance = tmp_class(url)

    #then
    assert tmp_instance



# Generated at 2022-06-24 13:10:23.365073
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	"""
	Unit test for constructor of class SoundgasmIE
	"""
	# Create an instance of class SoundgasmIE
	soundgasm_ie = SoundgasmIE()
	# Reading an invalid url
	url = "http://soundgasm.net/u/invalid"
	# Check if the method returns True for valid url and False for invalid url
	assert (soundgasm_ie._match_id(url) == None), "Invalid url doesn't return None"
	# Reading a valid url
	url = "http://soundgasm.net/u/ytdl/Piano-sample"
	# Check if the method returns the id, user and display_id of the audio

# Generated at 2022-06-24 13:10:31.100888
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from youtube_dl.downloader import FileDownloader
    ffmpeg_options = []
    downloader = FileDownloader({}, SoundgasmIE())
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'

    # Check that format_spec is set correctly
    assert downloader.format_spec == None

    # Check that ytdl_filename is set correctly
    assert downloader.ytdl_filename == None

    # Check that the file is downloaded and that the title hasn't changed
    info = downloader.extract(url)
    assert info['title'] == 'Piano sample'

# Generated at 2022-06-24 13:10:39.281461
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # check that a regex is not inside another one (this regex is a complete subset of the older regex)
    regex_pair = ["(?s)<div[^>]+\bclass=", "(?s)<div[^>]+\bclass=['\"]jp-description"]


# Generated at 2022-06-24 13:10:49.946695
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:10:51.546419
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    t = SoundgasmIE()
    assert t.IE_NAME == 'soundgasm'


# Generated at 2022-06-24 13:10:52.096442
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass

# Generated at 2022-06-24 13:10:53.277218
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profileIE = SoundgasmProfileIE()
    assert profileIE != None

# Generated at 2022-06-24 13:10:54.263826
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie1 = SoundgasmIE()

# Generated at 2022-06-24 13:10:56.024176
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:10:59.955698
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert hasattr(SoundgasmIE, '_VALID_URL')
    assert hasattr(SoundgasmIE, '_TEST')
    assert re.match(SoundgasmIE._VALID_URL, SoundgasmIE._TEST['url'])


# Generated at 2022-06-24 13:11:09.770967
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE(): 
    s = SoundgasmProfileIE()
    s.IE_NAME = 'Soundgasm'
    s._VALID_URL = 'http://soundgasm.net/u/ytdl'
    s._TEST = {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}}
    
    s._real_extract('http://soundgasm.net/u/ytdl')
    s.playlist_result(['asdf'], 'ytdl')
    s.url_result('http://soundgasm.net/u/ytdl/Sine-sample', 'Soundgasm')
    s.IE_NAME == 'Soundgasm'

# Generated at 2022-06-24 13:11:17.303476
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # This test is for constructor of class SoundgasmIE.
    # When you execute this test, you will find there is one test passed.
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    self = SoundgasmIE()
    # Assert that the value of self.IE_NAME is equal to 'soundgasm'
    assert (self.IE_NAME == 'soundgasm'), "Given url is a valid url, but the IE_NAME is not soundgasm."


# Generated at 2022-06-24 13:11:25.425432
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print('Starting the unit tests for SoundgasmIE')
    print('\tCreating an instance of SoundgasmIE')
    ie = SoundgasmIE()
    print (ie)
    
    print('\tDone creating an instance of SoundgasmIE')
    print('\tTesting SoundgasmIE.extract_id()')
    assert ie.extract_id('http://soundgasm.net/u/ytdl/Piano-sample') == 'Piano-sample'
    print('\tDone testing SoundgasmIE.extract_id()')

    print('\tTesting SoundgasmIE.extract()')
    ie.extract('http://soundgasm.net/u/ytdl/Piano-sample')
    print('\tDone testing SoundgasmIE.extract()')


# Generated at 2022-06-24 13:11:26.865923
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == "soundgasm"
    assert ie.IE_DESC == "soundgasm.net"


# Generated at 2022-06-24 13:11:27.685494
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-24 13:11:28.451582
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:11:37.026531
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio_url = 'https://soundgasm.net/u/ytdl/Piano-sample'
    expected_audio_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    expected_display_id = 'Piano-sample'

    SoundgasmIE._download_webpage = lambda self, url, display_id: '<script>m4a: \'%s\';</script>' % audio_url

    soundgasm_ie = SoundgasmIE()
    output = soundgasm_ie._real_extract(audio_url)

    # Some tests
    assert output['url'] == audio_url
    assert output['id'] == expected_audio_id
    assert output['display_id'] == expected_display_id



# Generated at 2022-06-24 13:11:46.901444
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # If this is run with the test paramater, it will check to see if the
    # functions are valid by running them with values, instead of the boiler
    # place code.
    # It will also print the results.

    # Set to True to run the basic unit tests        
    if False:
        print("Checking SoundgasmProfileIE")
        temp = SoundgasmProfileIE('SoundgasmProfileIE')
        url = "http://soundgasm.net/u/ytdl"
        print(temp.extract(url))
        print("End of Test")
    
    # Set to true to check if the url matches the expected value
    if False:
        print("Checking SoundgasmProfileIE: _VALID_URL")
        temp = SoundgasmProfileIE('SoundgasmProfileIE')

# Generated at 2022-06-24 13:11:47.800719
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie is not None

# Generated at 2022-06-24 13:11:55.350735
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

	from .SoundgasmIE import SoundgasmIE

	assert(SoundgasmIE.IE_NAME == 'soundgasm')
	assert(SoundgasmIE.IE_DESC == 'Soundgasm.net')

	# Check whether the regex matches the url
	assert(SoundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

	# Check whether the regex matches the url and whether the regex extracts the correct groups

# Generated at 2022-06-24 13:11:59.772454
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg_Profile = SoundgasmProfileIE()
    assert_equal(sg_Profile._VALID_URL, 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')

# Generated at 2022-06-24 13:12:08.177606
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import http_testserver
    from .common import FakeDownloader
    from .common import FakeInfoExtractor
    from .common import IncompleteDownloadError
    from .common import FakeHttpServer

    test_url = "http://localhost:23451/test.html"
    fake_downloader = FakeDownloader()
    fake_downloader.addResult(test_url, 'test_page')

    extractor1 = InfoExtractor()
    extractor1.downloader = fake_downloader

    extractor2 = SoundgasmProfileIE()
    extractor2.downloader = fake_downloader

    extractor3 = FakeInfoExtractor()
    extractor3.downloader = fake_downloader

    it = http_testserver.loop(False)


# Generated at 2022-06-24 13:12:14.138121
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """This function aims to test the constructor of SoundgasmIE"""
    audio_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    ie = SoundgasmIE()
    extractor = ie._call_downloader(audio_url)
    assert type(extractor) is SoundgasmIE

# Generated at 2022-06-24 13:12:18.663756
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:12:20.198086
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.ie_key() == 'Soundgasm:profile'

# Generated at 2022-06-24 13:12:21.951600
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE(None)._VALID_URL == SoundgasmIE._VALID_URL


# Generated at 2022-06-24 13:12:23.365046
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    extractor = SoundgasmIE()
    extractor._real_extract(url)
    return extractor

# Generated at 2022-06-24 13:12:29.054739
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Given
    test_case = SoundgasmIE._TEST
    url = test_case['url']
    # When
    ie = SoundgasmIE()
    # Then
    assert ie._VALID_URL == SoundgasmIE._VALID_URL
    assert ie._TEST == SoundgasmIE._TEST
    assert ie.IE_NAME == SoundgasmIE.IE_NAME
    assert ie._real_initialize() is None
    assert ie._real_extract(url) == test_case

# Generated at 2022-06-24 13:12:35.326933
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	#url = "https://soundgasm.net/u/ytdl"
	#print SoundgasmProfileIE.IE_NAME
	user_id = 'ytdl'
	url = "https://soundgasm.net/u/" + user_id + "/"

# Generated at 2022-06-24 13:12:42.897320
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Create a new instance of class SoundgasmIE,
    # no parameter passed to the constructor
    audio_extractor = SoundgasmIE()
    # Check if the URL is valid.

# Generated at 2022-06-24 13:12:52.705301
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Load the instance with the URL
    url = "http://soundgasm.net/u/ytdl"
    obj = SoundgasmProfileIE(url)
    # Check that the URL is valid
    assert obj._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$"
    # Check that the URL matches the URL
    assert obj._match_id(url) == "ytdl"
    # Check that the URL matches the test URL
    assert obj._TEST["url"] == url
    # Check that the URL matches the Profile ID
    assert obj._TEST["info_dict"]["id"] == obj._match_id(url)
    # Check that the webpage is not empty

# Generated at 2022-06-24 13:13:01.902444
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    extractor = SoundgasmIE(SoundgasmIE._VALID_URL)
    assert extractor != None
    assert extractor._TESTS == [
        {'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
         'md5': '010082a2c802c5275bb00030743e75ad',
         'info_dict': {'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
                       'ext': 'm4a',
                       'title': 'Piano sample',
                       'description': 'Royalty Free Sample Music',
                       'uploader': 'ytdl'}}]

# Generated at 2022-06-24 13:13:03.612662
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    x = SoundgasmProfileIE()
    assert x.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-24 13:13:13.409700
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    obj = SoundgasmIE()
    # Check if the class name is correctly set
    assert obj.IE_NAME == 'Soundgasm'
    # Check if the URL matches the URL regex
    assert obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/[0-9a-zA-Z_-]+/[0-9a-zA-Z_-]+'

# Generated at 2022-06-24 13:13:18.383511
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.params == {'skip_download': True}

# Generated at 2022-06-24 13:13:21.603183
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE('https://soundgasm.net/u/ytdl')
    assert instance.IE_NAME == 'SoundgasmProfileIE'



# Generated at 2022-06-24 13:13:24.746967
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(SoundgasmProfileIE.IE_NAME, 'http://soundgasm.net/u/ytdl', {'extractor': 'SoundgasmProfileIE'})

# Generated at 2022-06-24 13:13:32.038636
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/([^/]+)/?(?:\#.*)?$')
    assert(SoundgasmProfileIE._TEST['url'] == 'http://soundgasm.net/u/ytdl')
    assert(SoundgasmProfileIE._TEST['info_dict']['id'] == 'ytdl')
    assert(SoundgasmProfileIE._TEST['playlist_count'] == 1)
    assert(SoundgasmProfileIE.IE_NAME == 'soundgasm:profile')


# Generated at 2022-06-24 13:13:34.218908
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-24 13:13:36.414531
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(set(SoundgasmProfileIE._TESTS).issubset(set(SoundgasmIE._TESTS)))


# Generated at 2022-06-24 13:13:39.402266
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import SoundgasmProfileIE
    # Create an instance of SoundgasmProfileIE
    inst = SoundgasmProfileIE(None)
    assert isinstance(inst, SoundgasmProfileIE)
    # TODO: add more unit tests.

# Generated at 2022-06-24 13:13:41.461851
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    url = 'http://soundgasm.net/u/ytdl'
    print(ie._real_extract(url))


# Generated at 2022-06-24 13:13:43.000955
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    InfoExtractor.test_video_urls(SoundgasmProfileIE)



# Generated at 2022-06-24 13:13:49.887981
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # This URL is the original example of SoundgasmIE.
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    # The purpose of this test is to make sure we have a successful query.
    # We don't need to checksum or validate the audio file for this particular
    # test.
    ie = SoundgasmIE()
    ie.extract(url)

# Generated at 2022-06-24 13:13:50.915417
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('','','','','','','','','','','','','','','','','','','','','','','')

# Generated at 2022-06-24 13:13:51.897945
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:13:52.536456
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert True

# Generated at 2022-06-24 13:13:56.021096
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test = SoundgasmProfileIE
    url = "http://soundgasm.net/u/ytdl/"
    assert test._TEST
    assert test._VALID_URL
    assert test.IE_NAME


# Generated at 2022-06-24 13:14:00.515176
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Constructor test for :class:`~SoundgasmIE`. """
    ie = SoundgasmIE('aaa')
    assert ie.IE_NAME == 'soundgasm'
    assert ie.VALID_URL == 'http://soundgasm\.net/u/[0-9a-zA-Z_-]+/[0-9a-zA-Z_-]+'

# Generated at 2022-06-24 13:14:09.739873
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    TestClass = type('Test', (object,), {'assertTrue': lambda x: True})
    soundgasm_iec = SoundgasmIE(TestClass())

    assert soundgasm_iec.IE_NAME == 'soundgasm'

    assert soundgasm_iec._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

    assert soundgasm_iec._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'


# Generated at 2022-06-24 13:14:13.616283
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    a = SoundgasmIE()
    assert(a.IE_NAME == 'soundgasm')
# Test build_url with invalid parameters
    assert(a._build_url() == None)
# Test for class SoundgasmIE

# Generated at 2022-06-24 13:14:14.633531
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE(None) is not None

# Generated at 2022-06-24 13:14:18.787201
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.IE_DESC == 'Soundgasm user profiles'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'


# Generated at 2022-06-24 13:14:29.560226
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasm = SoundgasmIE()
    assert soundgasm._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert soundgasm._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert soundgasm._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-24 13:14:31.286906
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE({})
    except Exception:
        return False

    return True


# Generated at 2022-06-24 13:14:37.566312
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("Testing SoundgasmIE")
    SoundgasmIE._download_webpage = lambda self, URL, display_id: '<html>'
    SoundgasmIE._html_search_regex = lambda self, regex, webpage, name, group: 'http://example.com/audio.m4a'
    SoundgasmIE._search_regex = lambda self, regex, webpage, name, default: 'audio_id'
    assert isinstance(SoundgasmIE(None), SoundgasmIE)


# Generated at 2022-06-24 13:14:45.197280
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE()
    assert profile.IE_NAME == 'soundgasm:profile'
    assert profile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert profile.IE_DESC == 'Soundgasm user profile'
    assert profile._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}


# Generated at 2022-06-24 13:14:50.638875
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_IE = SoundgasmProfileIE()
    assert profile_IE.IE_NAME == 'soundgasm:profile'
    assert profile_IE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:14:57.729366
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.suitable('http://soundgasm.net/u/ytdl')
    assert SoundgasmProfileIE.suitable('http://soundgasm.net/u/ytdl/')
    assert SoundgasmProfileIE.suitable('http://soundgasm.net/u/ytdl/abc')
    assert not SoundgasmProfileIE.suitable('http://soundgasm.net/u/ytdl/abc/def')
    assert SoundgasmProfileIE.suitable('http://soundgasm.net/u/ytdl#abc')
    assert SoundgasmProfileIE.suitable('http://soundgasm.net/u/ytdl/#abc')

# Generated at 2022-06-24 13:14:58.961889
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert 'SoundgasmProfileIE' in globals()

# Generated at 2022-06-24 13:15:06.020645
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert not hasattr(SoundgasmProfileIE, 'constructor')
    for key in SoundgasmProfileIE.__dict__:
        if key.startswith('_'):
            continue
        if key in ('IE_NAME', '_VALID_URL', '_TEST'):
            continue
        assert not hasattr(SoundgasmProfileIE, key), '{} should not be in class SoundgasmProfileIE'.format(key)
    assert SoundgasmProfileIE.__dict__.get('_real_extract') is not None


# Generated at 2022-06-24 13:15:06.617698
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert isinstance(SoundgasmProfileIE, InfoExtractor)


# Generated at 2022-06-24 13:15:08.006684
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	assert SoundgasmIE(SoundgasmIE._TEST)

# Generated at 2022-06-24 13:15:11.407290
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE_VALID_URL = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert re.match(SoundgasmIE._VALID_URL, IE_VALID_URL, flags=0) is not None


# Generated at 2022-06-24 13:15:13.046509
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE(InfoExtractor('youtube'))._VALID_URL == SoundgasmIE._VALID_URL

# Generated at 2022-06-24 13:15:16.084233
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_class = SoundgasmIE('SoundgasmIE')
    test_class.download_webpage = lambda x, y=None: x
    test = test_class._download_webpage('http://google.com')
    assert test == 'http://google.com'

# Generated at 2022-06-24 13:15:18.160031
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE()
    assert instance.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-24 13:15:22.387464
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SOUNDGASM_URL = 'http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasm_ie = SoundgasmIE()
    soundgasm_ie._real_extract(SOUNDGASM_URL)

# Generated at 2022-06-24 13:15:29.432908
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    i = SoundgasmIE()
    assert i._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert i._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert i.IE_NAME == 'soundgasm'


# Generated at 2022-06-24 13:15:36.098074
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    # Check for audio URL on web page
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:15:39.876598
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert profile._match_id('http://soundgasm.net/u/ytdl') == 'ytdl'

# Generated at 2022-06-24 13:15:41.882352
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:15:43.569965
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Unit test for constructor of class SoundgasmIE"""
    SoundgasmIE()

# Generated at 2022-06-24 13:15:46.944756
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Constructor test
    """
    obj = SoundgasmProfileIE({})
    assert obj.ie_key() == 'SoundgasmProfile'
    assert obj.ie_name() == 'Soundgasm:profile'

# Generated at 2022-06-24 13:15:48.681273
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-24 13:15:50.653175
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg = SoundgasmProfileIE(None)
    assert isinstance(sg, IE_NAME)

# Generated at 2022-06-24 13:15:52.311617
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sound = SoundgasmIE()

    sound.IE_NAME
    sound.validate_url(url)
    sound.validate_url(another_url)


# Generated at 2022-06-24 13:15:54.818115
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE(None)
    #assert ie.url_result('http://soundgasm.net/u/ytdl/Piano-sample', 'Soundgasm')

# Generated at 2022-06-24 13:16:05.414173
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """ Unit test for the SoundgasmProfileIE constructor """

    # Arrange
    unit_test_url = "http://soundgasm.net/u/ytdl"

    expected_id = "ytdl"
    expected_playlist_count = 1

    # Action
    soundgasm_profile_ie = SoundgasmProfileIE(unit_test_url)

    # Assert
    assert soundgasm_profile_ie.IE_NAME == "soundgasm:profile"
    assert soundgasm_profile_ie._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$"

# Generated at 2022-06-24 13:16:16.309203
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasmIE = SoundgasmIE()
    obj = soundgasmIE._real_extract(url)
    soundgasmIE_test = SoundgasmIE._TEST
    print("\nID: " + obj['id'])
    assert obj['id'] == soundgasmIE_test['url']
    print("\nDescription: " + obj['description'])
    assert obj['description'] == soundgasmIE_test['info_dict']['description']
    print("\nTitle: " + obj['title'])
    assert obj['title'] == soundgasmIE_test['info_dict']['title']
    print("\nDisplay ID: " + obj['display_id'])

# Generated at 2022-06-24 13:16:22.515035
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    assert hasattr(sg, '_VALID_URL')
    assert hasattr(sg, '_TEST')
    assert hasattr(sg, '_real_extract')
    assert hasattr(sg, '_download_webpage')
    assert hasattr(sg, '_html_search_regex')
    assert hasattr(sg, '_search_regex')
    assert hasattr(sg, 'url_result')


# Generated at 2022-06-24 13:16:25.330598
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE()
    except:
        assert False, "constructor for class SoundgasmIE failed"
    else:
        assert True, "constructor for class SoundgasmIE passed"


# Generated at 2022-06-24 13:16:31.416581
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Testing extractor
    result = SoundgasmIE().extract("http://soundgasm.net/u/ytdl/Piano-sample")

    # Assertions
    assert(result['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9')
    assert(result['uploader'] == 'ytdl')
    assert(result['description'] == 'Royalty Free Sample Music')

# Generated at 2022-06-24 13:16:40.603922
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'

# Generated at 2022-06-24 13:16:44.023841
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie.IE_URL == SoundgasmIE._VALID_URL


# Generated at 2022-06-24 13:16:45.333981
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    SoundgasmProfileIE()._real_extract(url)

# Generated at 2022-06-24 13:16:48.899955
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	url = 'http://soundgasm.net/u/ytdl'
	obj = SoundgasmProfileIE(url)
	assert obj._match_id(url) == 'ytdl'
	assert obj.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:16:53.300292
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Constructor
    ie = SoundgasmProfileIE()

    # Test
    info = ie._real_extract(r'https://soundgasm.net/u/ytdl/')
    info_dict = info['entries'][0]
    assert info_dict['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-24 13:16:57.205206
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # URL of a user profile in Soundgasm.net
    url = 'http://soundgasm.net/u/ytdl'
    SoundgasmIE._download_webpage = lambda *args, **kwargs: '<html>'
    SoundgasmIE._search_regex = lambda *args, **kwargs: '/u/ytdl/Piano-sample'
    SoundgasmProfileIE(url)

# Generated at 2022-06-24 13:16:58.767020
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE()
    print(a)
    return a

# Generated at 2022-06-24 13:17:01.562800
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE("SoundgasmProfileIE", "http://www.soundgasm.net/u/ytdl/", "SoundgasmProfileIE", "")


# Generated at 2022-06-24 13:17:10.628628
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    MOCK_HTML = """
        <div>
        <script>
        var test = [
        {"title":"Piano sample", "description":"Royalty Free Sample Music"},
        {"link": "http://media.soundgasm.net/u/ytdl/Piano-sample/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a"}
        ];
        </script>
        </div>
    """
    ie = SoundgasmIE()
    ie._download_webpage = lambda *args, **kwargs: MOCK_HTML

# Generated at 2022-06-24 13:17:11.504120
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:17:21.805822
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from riprova.registry import register_assertion
    from riprova.strategies import all_strategies

    register_assertion(all_strategies, lambda x, y: isinstance(x, SoundgasmProfileIE) and isinstance(y, SoundgasmProfileIE))

    SoundgasmProfileIE(SoundgasmProfileIE).assert_equals(SoundgasmProfileIE)

    # Unit test for constructor of class SoundgasmIE
    from riprova.registry import register_assertion
    from riprova.strategies import all_strategies

    register_assertion(all_strategies, lambda x, y: isinstance(x, SoundgasmIE) and isinstance(y, SoundgasmIE))

    SoundgasmIE(SoundgasmIE).assert_equals(SoundgasmIE)

# Generated at 2022-06-24 13:17:25.755613
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    testurl = 'http://soundgasm.net/u/ytdl/Piano-sample'
    se = SoundgasmIE()

# Generated at 2022-06-24 13:17:29.738390
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Arrange
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'

    # Action
    profile_ie = SoundgasmProfileIE()

    # Assert
    assert profile_ie._VALID_URL == url

# Generated at 2022-06-24 13:17:30.761923
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:17:32.305702
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(SoundgasmProfileIE._VALID_URL)
    #print ie


# Generated at 2022-06-24 13:17:35.195924
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:17:44.404299
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = SoundgasmIE()
    assert(issubclass(test.__class__, InfoExtractor))
    assert(test.IE_NAME == 'soundgasm')
    assert(test._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')
    assert(test._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample')
    assert(test._TEST['md5'] == '010082a2c802c5275bb00030743e75ad')


# Generated at 2022-06-24 13:17:49.373537
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie.url == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie.display_id == 'Piano-sample'
    assert ie.user == 'ytdl'

# Generated at 2022-06-24 13:17:50.795189
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    i = SoundgasmIE()
    assert i.IE_NAME == 'soundgasm'


# Generated at 2022-06-24 13:17:52.776293
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	sg = SoundgasmIE()
	print(sg.SPIDER_VERSION)
	print(sg.IE_DESC)

# Generated at 2022-06-24 13:18:03.244442
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import unittest
    from soundgasmIE import SoundgasmIE
    from soundgasmIE import _VALID_URL

    class TestSoundgasmIE(unittest.TestCase):
        def setUp(self):
            link = 'http://soundgasm.net/u/ytdl/Piano-sample'

# Generated at 2022-06-24 13:18:05.166091
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	url = 'http://soundgasm.net/u/ytdl/Piano-sample'
	ex = SoundgasmIE()
	assert ex._download_webpage(url)
	assert ex._real_extract(url)


# Generated at 2022-06-24 13:18:13.562113
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_arg = 'http://soundgasm.net/u/ytdl'
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert SoundgasmProfileIE._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert SoundgasmProfileIE._TEST['info_dict']['id'] == 'ytdl'
    assert SoundgasmProfileIE._TEST['playlist_count'] == 1



# Generated at 2022-06-24 13:18:15.942823
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE._TEST['url'] == 'http://soundgasm.net/u/ytdl')



# Generated at 2022-06-24 13:18:18.459805
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('Soundgasm', {})
    assert ie.name == 'Soundgasm'

# Generated at 2022-06-24 13:18:22.195349
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import urllib2
    from tests.test_soundgasm import TestSoundgasm as ts
    url = 'http://soundgasm.net/u/ytdl'
    ts.assertTrue(urllib2.quote(url) == SoundgasmProfileIE._VALID_URL)