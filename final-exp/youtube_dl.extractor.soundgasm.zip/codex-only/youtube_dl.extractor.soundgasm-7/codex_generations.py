

# Generated at 2022-06-24 13:08:23.462929
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert SoundgasmProfileIE("http://soundgasm.net/u/ytdl") is not None

# Generated at 2022-06-24 13:08:26.192357
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    s = SoundgasmProfileIE()
    s.suite()
    print("\n==== Passed! ====\n")


# Generated at 2022-06-24 13:08:34.017341
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    '''Constructor of class SoundgasmIE'''
    # Given the URL of a soundgasm video
    # When the class is constructed
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl')
    # Then it should have the correct _VALID_URL
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:08:37.693450
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    i = SoundgasmProfileIE('http://www.soundgasm.net/u/3nix')
    assert i.url == 'http://www.soundgasm.net/u/3nix'
    assert i.id == '3nix'
    assert i.display_id == '3nix'

# Generated at 2022-06-24 13:08:39.658436
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    reload(sys)
    sys.setdefaultencoding('utf-8')
    obj = SoundgasmIE();
    obj.extract(url);

# Generated at 2022-06-24 13:08:45.429125
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest
    import soundgasm_test

    if unittest.TestCase.__name__=='TestCase':
        test_case=unittest.TestCase("__init__")
    else:
        test_case = unittest.TestCase()

    print("\nUnit test for contructor of class SoundgasmProfileIE.\n")
    ie = SoundgasmProfileIE("SoundgasmProfileIE", {})
    test_case.assertNotEqual(ie, None)
    print("Unit test for SoundgasmProfileIE.__init__() passed.\n")
    print("Unit test for SoundgasmProfileIE passed.\n")

test_SoundgasmProfileIE()

# Generated at 2022-06-24 13:08:52.382568
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_cases = {
        'http://soundgasm.net/u/ytdl': 'ytdl',
        'http://soundgasm.net/u/ytdl/': 'ytdl',
        'http://soundgasm.net/u/ytdl/soundgasm': 'ytdl',
    }
    for url, expected_id in test_cases.items():
        result = SoundgasmProfileIE._VALID_URL_RE.match(url).groupdict()
        assert result['id'] == expected_id

# Generated at 2022-06-24 13:08:53.278686
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:08:55.224515
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:08:58.605991
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # The constructor of class InfoExtractor return an instance of class InfoExtractor
    instance = InfoExtractor()
    # Check the return type
    assert isinstance(instance, InfoExtractor)
    # Check if it is the instance of class SoundgasmIE
    assert isinstance(instance, SoundgasmIE)

# Generated at 2022-06-24 13:09:00.550592
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE(SoundgasmProfileIE._VALID_URL, SoundgasmProfileIE.IE_NAME).IE_NAME == "SoundgasmProfileIE"

# Generated at 2022-06-24 13:09:01.835958
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
   assert SoundgasmProfileIE._TEST



# Generated at 2022-06-24 13:09:12.948941
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Loading the url
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE(url)

# Generated at 2022-06-24 13:09:16.579106
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    print(SoundgasmIE(url))
    print(SoundgasmIE(url)._TEST)

# Generated at 2022-06-24 13:09:20.999695
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert SoundgasmProfileIE._VALID_URL == \
        'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert SoundgasmProfileIE._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert SoundgasmProfileIE._TEST['info_dict'] == {'id': 'ytdl'}
    assert SoundgasmProfileIE._TEST['playlist_count'] == 1


# Generated at 2022-06-24 13:09:25.371914
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
    'url': 'http://soundgasm.net/u/ytdl',
    'info_dict': {
        'id': 'ytdl',
    },
    'playlist_count': 1,
}


# Generated at 2022-06-24 13:09:28.616354
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_url = "http://soundgasm.net/u/ytdl"
    SoundgasmProfileIE()._real_extract(test_url)



# Generated at 2022-06-24 13:09:37.941717
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Tests for SoundgasmIE class extending class InfoExtractor.

    This test is intended to catch any exceptions raised during the constructor of the
    SoundgasmIE class.

    For more information on unit testing, see the following documentation:

    https://en.wikipedia.org/wiki/Unit_testing
    https://docs.python.org/2/library/unittest.html
    https://docs.python.org/2/library/unittest.html#assert-methods
    """
    # The following line should be commented out when the test is done.
    raise Exception("SoundgasmIE is not yet implemented. Please test when it is.")

    # Creating an instance of the SoundgasmIE class
    SoundgasmIE()

# Generated at 2022-06-24 13:09:40.132518
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE.suitable('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-24 13:09:41.030319
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(0,0)

# Generated at 2022-06-24 13:09:46.486948
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    expected_fields = ['id', 'display_id', 'url',
                       'vcodec', 'title', 'description', 'uploader']

    actual_fields = SoundgasmIE(expected_fields, url)._TEST['info_dict'].keys()

    for key in expected_fields:
        assert key in actual_fields


# Generated at 2022-06-24 13:09:47.495874
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:09:52.619432
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("Testing Constructor\n")
    temp = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    print("Display ID")
    print(temp.display_id)
    print("URL")
    print(temp.url)
    print("Extractor")
    print(temp.ie_key())


# Generated at 2022-06-24 13:09:56.380398
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:09:57.410083
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-24 13:09:58.830873
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    i = SoundgasmProfileIE()
    assert i is not None


# Generated at 2022-06-24 13:10:04.110478
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    IE = SoundgasmIE()
    assert IE.IE_NAME == 'soundgasm'
    assert IE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:10:08.672710
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Create an instance of the class.
    ie = SoundgasmProfileIE()
    # Extract the URLs.
    ie.extract('http://soundgasm.net/u/ytdl')
    # Proceed to the tests.
    assert isinstance(ie.url, basestring)


# Generated at 2022-06-24 13:10:10.095762
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    ie.extract()

# Generated at 2022-06-24 13:10:20.055343
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	current = SoundgasmIE()
	assert current._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:10:21.989909
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  """
  SoundgasmProfileIE constructor function test
  """
  instance = SoundgasmProfileIE()
  assert type(instance) == SoundgasmProfileIE

# Generated at 2022-06-24 13:10:25.062126
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert SoundgasmProfileIE('http://soundgasm.net/u/ytdl/#news-feed')
    assert not SoundgasmProfileIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:10:27.641706
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert instance.playlist_count == 0
    assert instance.playlist_mincount == 1

# Generated at 2022-06-24 13:10:29.352370
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.IE_NAME == 'Soundgasm'

# Generated at 2022-06-24 13:10:33.545527
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    parser = re.match(ie._VALID_URL, url)
    assert parser.groups() == ('ytdl', 'Piano-sample')
    #print parser.group('user')

# Generated at 2022-06-24 13:10:40.784929
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = SoundgasmIE()
    assert test._download_webpage('http://soundgasm.net/u/ytdl/Piano-sample', display_id='Piano-sample') is not None

# Generated at 2022-06-24 13:10:44.376144
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'



# Generated at 2022-06-24 13:10:45.694100
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE == InfoExtractor.for_site('soundgasm.net')

# Generated at 2022-06-24 13:10:54.742411
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    here = os.path.abspath(os.path.dirname(__file__))
    data_dir = os.path.join(here, 'tests', 'data')

    # test with a test file containing the target audio's web page
    file_name = 'soundgasm.net_u_ytdl_Piano-sample.html'
    target_file_path = os.path.join(data_dir, file_name)
    # test with the target audio's web page's URL
    target_url = 'http://soundgasm.net/u/ytdl/Piano-sample'

    def check_test(test_target):
        print('test target: {}'.format(test_target))
        test_ie = SoundgasmIE(test_target)
        check_test_results(test_ie)

   

# Generated at 2022-06-24 13:10:57.990853
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    fake_SoundgasmProfileIE = SoundgasmProfileIE()
    assert repr(fake_SoundgasmProfileIE) == "<SoundgasmProfileIE(soundgasm:profile)>"


# Generated at 2022-06-24 13:11:06.405981
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Provided by Soundgasm
    import pytest
    url = 'http://soundgasm.net/u/ytdl'
    assert SoundgasmProfileIE(pytest.param(url))
    # Provided by Soundgasm documentation
    url2 = 'http://soundgasm.net/u/ytdl#audio'
    assert SoundgasmProfileIE(pytest.param(url2))
    # Provided by Soundgasm documentation
    url3 = 'http://soundgasm.net/u/ytdl/audio'
    assert SoundgasmProfileIE(pytest.param(url3))

# Generated at 2022-06-24 13:11:07.808594
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from unit.test_soundgasm_profile_ie import TestSoundgasmProfileIE
    TestSoundgasmProfileIE().test()

# Generated at 2022-06-24 13:11:14.267629
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    #Initialize the class SoundgasmProfileIE
    my_object = SoundgasmProfileIE('SoundgasmProfileIE', 'http://soundgasm.net/u/ytdl')
    my_object.dislike_count = 0
    my_object.favorite_count = 0
    my_object.like_count = 0
    my_object.thumbnail = ''
    my_object.description = ''
    my_object.comment_count = 0
    my_object.tags = []
    assert my_object.IE_NAME == 'SoundgasmProfileIE'
    assert my_object.url == 'http://soundgasm.net/u/ytdl'
    assert my_object.extractor_key == 'SoundgasmProfile'
    assert my_object.dislike_count == 0
    assert my_object.favorite_

# Generated at 2022-06-24 13:11:15.049217
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	info_dict = soundgasm.SoundgasmProfileIE()
	assert info_dict

# Generated at 2022-06-24 13:11:24.108807
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    x = SoundgasmProfileIE('http://soundgasm.net/audio/ytdl/Sample-Piano', {}, 'Soundgasm')
    assert x.url == 'http://soundgasm.net/audio/ytdl/Sample-Piano'
    assert x.video_id == 'http://soundgasm.net/audio/ytdl/Sample-Piano'
    assert x._video_id == 'http://soundgasm.net/audio/ytdl/Sample-Piano'
    assert x.video_url == 'http://soundgasm.net/audio/ytdl/Sample-Piano'
    assert x.video_title == 'http://soundgasm.net/audio/ytdl/Sample-Piano'
    assert x.extractor == 'Soundgasm'
    assert x.webpage_

# Generated at 2022-06-24 13:11:27.634429
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_SoundgasmProfileIE.__name__="test_SoundgasmProfileIE"
    assert test_SoundgasmProfileIE(SoundgasmProfileIE,"http://soundgasm.net/u/ytdl")

# Generated at 2022-06-24 13:11:36.519810
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_ie = SoundgasmProfileIE('SoundgasmProfileIE')
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert profile_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert SoundgasmProfileIE._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}

# Generated at 2022-06-24 13:11:45.003067
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    URL = 'http://soundgasm.net/u/ytdl/Piano-sample'
    video = SoundgasmIE().extract(URL)
    
    assert video['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert video['title'] == 'Piano sample'
    assert video['uploader'] == 'ytdl'
    assert video['url'] == 'http://soundgasm.net/sounds/88abd86ea000cafe98f96321b23cc1206cbcbcc9/piano_sample.m4a'
    assert video['description'] == 'Royalty Free Sample Music'

# Generated at 2022-06-24 13:11:45.556908
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	SoundgasmIE()

# Generated at 2022-06-24 13:11:49.185615
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Run the test cases from the webpage itself.
    """
    import doctest
    doctest.testfile(
        filename=__file__ + '.doctest',
        module_relative=False,
        encoding='utf-8',
        optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-24 13:11:51.140237
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert 'http://soundgasm.net/u/ytdl/Piano-sample' in ie._VALID_URL

# Generated at 2022-06-24 13:11:52.179519
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE().IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-24 13:11:53.749854
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Unit test for constructor of class SoundgasmIE.
    """
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'Soundgasm'

# Generated at 2022-06-24 13:12:01.170364
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert (ie.IE_NAME == 'soundgasm:profile')
    assert (ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?')
    assert (ie._TEST['url'] == 'http://soundgasm.net/u/ytdl')
    assert (ie._TEST['info_dict']['id'] == 'ytdl')
    assert (ie._TEST['playlist_count'] == 1)

# Generated at 2022-06-24 13:12:03.190096
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Unit test for constructor of class SoundgasmProfileIE
    """
    profile_ie = SoundgasmProfileIE('Soundgasm')
    # Test get_info_extractor
    assert profile_ie._get_info_extractor(profile_ie._VALID_URL) == profile_ie



# Generated at 2022-06-24 13:12:04.132595
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()._VALID_URL == SoundgasmIE._VALID_URL


# Generated at 2022-06-24 13:12:10.383517
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    e = SoundgasmIE()
    assert(e.IE_NAME == 'soundgasm')
    assert(e.valid_url('http://soundgasm.net/u/ytdl/Piano-sample') == True)
    assert(e.valid_url('http://www.soundgasm.net/u/ytdl/Piano-sample') == True)
    assert(e.valid_url('http://soundgasm.net/u/ytdl/Piano-sample?xyz') == False)

# Generated at 2022-06-24 13:12:11.431210
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE() != None

# Generated at 2022-06-24 13:12:13.376590
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE = SoundgasmIE()
    #assert(IE.IE_NAME == 'Soundgasm')



# Generated at 2022-06-24 13:12:24.557329
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    rg1 = re.compile(r'href="([^"]+/u/%s/[^"]+)' % 'ytdl')
    rg2 = SoundgasmProfileIE._VALID_URL
    print(rg1)
    print(rg2)

    profile_id = 'ytdl'
    url = 'http://soundgasm.net/u/ytdl'
    profile_id2 = SoundgasmProfileIE._match_id(url)
    print(profile_id2)


# Generated at 2022-06-24 13:12:25.328177
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-24 13:12:26.353207
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(None) # for coverage


# Generated at 2022-06-24 13:12:35.791924
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-24 13:12:39.382767
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Unit test for constructor of class SoundgasmIE"""
    # Constructor
    ie = SoundgasmIE()
    # Static test with no parameters
    ie.extract('https://soundgasm.net/u/ytdl/Piano-sample')

if __name__ == '__main__':
    test_SoundgasmIE()

# Generated at 2022-06-24 13:12:46.753327
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test direct call
    result = SoundgasmIE().extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert result['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9', result['id']
    assert result['title'] == 'Piano sample', result['title']

    # Test class SoundgasmProfileIE
    result = SoundgasmProfileIE().extract('http://soundgasm.net/u/ytdl')
    assert result['id'] == 'ytdl', result['id']
    assert result['playlist_count'] == 1, result['playlist_count']

# Generated at 2022-06-24 13:12:48.514171
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test to ensure that a basic SoundgasmIE instantiation will run
    ie = SoundgasmIE()


# Generated at 2022-06-24 13:12:56.130562
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie.IE_NAME == 'soundgasm'
    assert ie.__class__.__name__ == 'SoundgasmIE'


# Generated at 2022-06-24 13:12:58.451622
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    filename(u'http://soundgasm.net/u/ytdl', u'soundgasm.net-u-ytdl', u'ytdl')
    test_SoundgasmProfileIE.runme()



# Generated at 2022-06-24 13:12:59.217179
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-24 13:13:01.415169
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sound = SoundgasmIE()
    valid_test = sound.test()
    assert valid_test == True, "Test Failed"
    print("Test Passed")
    

# Generated at 2022-06-24 13:13:07.671904
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    title_regex = r'(?s)<div[^>]+\bclass=["\']jp-title[^>]+>([^<]+)'
    id_regex = r'/([^/]+)\.m4a'
    description_regex = (r'(?s)<div[^>]+\bclass=["\']jp-description[^>]+>(.+?)</div>',
                         r'(?s)<li>Description:\s(.*?)<\/li>')
    sg = SoundgasmIE(url)

# Generated at 2022-06-24 13:13:11.333019
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(SoundgasmIE.IE_NAME, SoundgasmProfileIE._VALID_URL, SoundgasmProfileIE._TEST)
    assert ie._VALID_URL == SoundgasmProfileIE._VALID_URL

# Generated at 2022-06-24 13:13:14.571760
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE(NULL)._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-24 13:13:18.695765
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Example URL from the documentation
    example_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE()._real_extract("example_url")

if __name__ == '__main__' :
    test_SoundgasmIE()

# Generated at 2022-06-24 13:13:20.145595
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert(SoundgasmProfileIE.__name__ == "SoundgasmProfileIE")

# Generated at 2022-06-24 13:13:26.257282
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'

# Generated at 2022-06-24 13:13:28.558002
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()
    instance = obj.ie_key()
    assert(instance == 'Soundgasm:profile')


# Generated at 2022-06-24 13:13:31.606363
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_id = 'ytdl'
    url = 'http://soundgasm.net/u/ytdl'
    expected_title = profile_id
    assert SoundgasmProfileIE(None)._real_extract(url).get('id') == expected_title

# Generated at 2022-06-24 13:13:33.413243
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-24 13:13:42.297366
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:13:47.807235
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio_url = 'http://soundgasm.net/u/ytdl/Piano-sample'

    # Test the constructor of the SoundgasmIE class
    m = SoundgasmIE()

    assert m.IE_NAME == 'soundgasm'
    assert m._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:13:49.867732
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('https://soundgasm.net/u/ytdl')
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-24 13:13:59.710138
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test = SoundgasmProfileIE()
    test.IE_NAME = 'SoundgasmProfileIE'
    assert test._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert test._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}
    assert test._match_id('http://soundgasm.net/u/ytdl/first-post') == 'ytdl'
    assert test._match_id('http://soundgasm.net/u/ytdl') == 'ytdl'

# Generated at 2022-06-24 13:14:00.689262
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 13:14:03.928877
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	test_obj = SoundgasmProfileIE()
	assert_true(test_obj._VALID_URL==r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')

# Generated at 2022-06-24 13:14:09.504438
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	assert SoundgasmIE().IE_NAME == 'soundgasm'
	assert SoundgasmIE()._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Unit Test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-24 13:14:10.928591
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl');

# Generated at 2022-06-24 13:14:14.128898
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = SoundgasmIE._VALID_URL
    match = SoundgasmIE._VALID_URL_RE.match(url)

# Generated at 2022-06-24 13:14:16.357455
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    inst = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    inst.extract()

# Generated at 2022-06-24 13:14:19.002720
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Unit test for constructor
    ie = SoundgasmIE()
    assert ie.IE_NAME == ie.ie_key() and 'soundgasm' == ie.ie_key()

# Generated at 2022-06-24 13:14:29.783141
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	from soundgasm import SoundgasmProfileIE
	from pprint import pprint
	#assert SoundgasmProfileIE.suitable('http://soundgasm.net/u/ytdl/Piano-sample')
	pprint()
	#assert SoundgasmProfileIE
	#assert SoundgasmProfileIE.suitable('http://soundgasm.net/u/ytdl/Piano-sample')

	#assert soundgasm.SoundgasmProfileIE('http://soundgasm.net/u/ytdl').suitable('http://soundgasm.net/u/ytdl/Piano-sample')
	#assert soundgasm.SoundgasmProfileIE.suitable('http://soundgasm.net/u/ytdl/Piano-sample')
	#assert soundgasm.SoundgasmProfileIE.suitable

# Generated at 2022-06-24 13:14:36.524841
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('SoundgasmProfileIE').title
    assert SoundgasmProfileIE('SoundgasmProfileIE')._TEST
    assert SoundgasmProfileIE('SoundgasmProfileIE')._VALID_URL
    assert SoundgasmProfileIE('SoundgasmProfileIE')._download_webpage
    assert SoundgasmProfileIE('SoundgasmProfileIE')._match_id
    assert SoundgasmProfileIE('SoundgasmProfileIE')._real_extract
    assert SoundgasmProfileIE('SoundgasmProfileIE').url_result

# Generated at 2022-06-24 13:14:37.374188
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()

# Generated at 2022-06-24 13:14:41.004217
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE('http:soundgasm.net/u/ytdl/Piano-sample')
    assert obj.IE_NAME == 'soundgasm'
    assert obj._VALID_URL == ''

# Generated at 2022-06-24 13:14:44.292393
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    TestClass = type('TestClass',(SoundgasmProfileIE,),{})
    obj = TestClass()
    assert 'ytdl' == obj._real_extract('http://soundgasm.net/u/ytdl')['entries'][0]['display_id']

# Generated at 2022-06-24 13:14:50.143235
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import unittest
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    # Test with valid url
    soundgasmIE = SoundgasmIE(url=url)
    assert soundgasmIE.IE_NAME == 'soundgasm'
    assert soundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    # Test with invalid url
    url = "http://www.youtube.com/watch?v=BaW_jenozKc"
    try:
        soundgasmIE = SoundgasmIE(url=url)
    except:
        assert True

# Generated at 2022-06-24 13:14:52.997766
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-24 13:14:59.505634
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # assume that this test method is called within the main test method of class SoundgasmIE
    # assume that 'test' is an instance of SoundgasmIE
    # consider the following url: http://soundgasm.net/u/ytdl/Piano-sample
    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    # assume that a dictionary is stored in a variable called 'video_type_data'
    video_type_data = {'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
                       'ext': 'm4a',
                       'title': 'Piano sample',
                       'description': 'Royalty Free Sample Music',
                       'uploader': 'ytdl'}
    # call the method '_real_ext

# Generated at 2022-06-24 13:15:09.583958
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:15:14.291442
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('https://www.soundgasm.net/u/ytdl/titlename')
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-24 13:15:16.110618
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test the case of an incorrect URL
    ie = SoundgasmIE('https://soundgasm.net/u/ytdl')
    assert ie.IE_NAME == 'soundgasm'

# Generated at 2022-06-24 13:15:19.105150
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sgIE = SoundgasmProfileIE()
    print('Classic test for SoundgasmProfileIE:')
    print(sgIE._real_extract(sgIE._TEST['url']))

# Generated at 2022-06-24 13:15:29.927683
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    VALID_URL = 'http://soundgasm.net/u/ytdl/Piano-sample'
    INVALID_URL_FORMAT = 'http://soundgasm.net/Piano-sample'
    INVALID_URL_UNUSED_ID = 'http://soundgasm.net/u/ytdl'


# Generated at 2022-06-24 13:15:34.828326
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_url = 'http://soundgasm.net/u/ytdl'

    input_args = [test_url,]
    expected_result = {'id': 'ytdl',
            'uploader': 'ytdl',}

    profile = SoundgasmProfileIE(*input_args)
    result = profile._real_extract(test_url)

    assert result['id'] == expected_result['id']
    assert result['uploader'] == expected_result['uploader']

# Generated at 2022-06-24 13:15:40.736410
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_ie = SoundgasmIE()
    mobj = re.match(soundgasm_ie._VALID_URL, 'http://soundgasm.net/u/ytdl/Piano-sample')
    assert mobj.group('user') == 'ytdl'
    assert mobj.group('display_id') == 'Piano-sample'

# Generated at 2022-06-24 13:15:51.793492
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    e = SoundgasmIE()
    assert e.IE_NAME == 'soundgasm'
    assert e._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert e._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert e._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-24 13:15:58.606737
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Create an instance of the SoundgasmIE class given the URL https://soundgasm.net/u/ytdl/Piano-sample
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    # Ensure that the URL matches the URL of the Soundgasm entry
    assert ie._match_id('http://soundgasm.net/u/ytdl/Piano-sample') == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'


# Generated at 2022-06-24 13:16:00.120937
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'Soundgasm'

# Generated at 2022-06-24 13:16:11.483958
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest
    class TestSoundgasmProfileIE(unittest.TestCase):
        def test_constructor(self):
            cur_obj = SoundgasmProfileIE()
            self.assertTrue(cur_obj)
            self.assertTrue(isinstance(cur_obj, InfoExtractor))
            self.assertEqual(cur_obj.IE_NAME, 'soundgasm:profile')
            self.assertEqual(cur_obj.IE_DESC, 'Soundgasm profile')
            self.assertTrue(cur_obj._VALID_URL.startswith('https?://(?:www\.)?soundgasm\.net/u/'))
            self.assertTrue(cur_obj._TEST)

# Generated at 2022-06-24 13:16:20.014440
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url='http://soundgasm.net/u/ytdl/Piano-sample'
    module_soundgasm = SoundgasmIE()
    module_soundgasm.download(test_url)
    print("\nTesting module_soundgasm with URL: " + test_url)
    print("Title: " + module_soundgasm._TEST['info_dict']['title'])
    print("Uploader: " + module_soundgasm._TEST['info_dict']['uploader'])
    print("Description: " + module_soundgasm._TEST['info_dict']['description'] +  "\n")

# Generated at 2022-06-24 13:16:24.110070
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE()._VALID_URL == SoundgasmProfileIE._VALID_URL)
    assert(SoundgasmProfileIE().IE_NAME == SoundgasmProfileIE._TEST['url'])
    assert(SoundgasmProfileIE()._VALID_URL == SoundgasmProfileIE._TEST['url'])

# Generated at 2022-06-24 13:16:29.843268
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}

# Generated at 2022-06-24 13:16:39.652099
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # url = "http://soundgasm.net/u/ytdl/Piano-sample"
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    info = dict()
    obj = SoundgasmIE()
    obj.extract(url, info)

    assert info['id'] == "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
    assert info['title'] == "Piano sample"
    assert info['display_id'] == "Piano-sample"
    assert info['url'] == "https://s3.amazonaws.com/soundgasm/000/889/889-88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a"

# Generated at 2022-06-24 13:16:50.353452
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Success: using valid url
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE(url)
    assert True

    # Failure: using invalid url
    url = 'http://soundgasm.net/u/ytdl/Piano-sample/asdf'
    try:
        SoundgasmIE(url)
    except:
        assert True
    else:
        assert False

    # Failure: using invalid url
    url = 'http://soundgasm.net/u/ytdl/asdf'
    try:
        SoundgasmIE(url)
    except:
        assert True
    else:
        assert False

    # Failure: using invalid url

# Generated at 2022-06-24 13:16:59.962804
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest
    import sys
    globals()['SoundgasmIE'] = sys.modules['__main__'].SoundgasmIE
    globals()['InfoExtractor'] = sys.modules['__main__'].InfoExtractor
    globals()['test'] = sys.modules['__main__'].test
    globals()['compat_str'] = sys.modules['__main__'].compat_str
    globals()['compat_urllib_parse_unquote'] = sys.modules['__main__'].compat_urllib_parse_unquote
    globals()['compat_urlparse'] = sys.modules['__main__'].compat_urlparse
    globals()['compat_urllib_parse_urlencode'] = sys.modules['__main__'].compat_

# Generated at 2022-06-24 13:17:07.627359
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert re.match(SoundgasmIE._VALID_URL, 'http://soundgasm.net/u/ytdl/Piano-sample')
    assert re.match(SoundgasmIE._VALID_URL, 'https://soundgasm.net/u/ytdl/Piano-sample')
    assert re.match(SoundgasmIE._VALID_URL, 'http://www.soundgasm.net/u/ytdl/Piano-sample')
    assert re.match(SoundgasmIE._VALID_URL, 'https://www.soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-24 13:17:10.786862
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test normal case
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

    # Test case with additional content in URL (the link for everyone on Reddit)
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl/#')

# Generated at 2022-06-24 13:17:21.045599
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    a = SoundgasmIE()
    b = SoundgasmIE()

    print("Test case #1: ")
    a._VALID_URL = 'https://soundgasm.net/u/ytdl/Piano-sample'
    a._TEST = 'http://soundgasm.net/u/ytdl/Piano-sample'
    result = a.test(a._TEST)
    print("URL: %s \n %r\n" % (a._TEST, result))

    print("Test case #2: ")
    b._VALID_URL = 'https://soundgasm.net/u/ytdl/Piano-sample'
    b._TEST = 'http://soundgasm.net/u/ytdl/Piano-sample'

# Generated at 2022-06-24 13:17:29.486758
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_profile_url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.IE_DESC == 'Soundgasm user profiles'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.__class__.__name__ == 'SoundgasmProfileIE'

# Generated at 2022-06-24 13:17:38.835886
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .check import check_mp3_content
    from .downloader import ParseError

    # The m4a URL is not expected to work for long.
    # This just tests that the constructor works.
    with check_mp3_content.check_mp3('010082a2c802c5275bb00030743e75ad',
                                     'https://my.mixtape.moe/uueczx.mp3'):
        ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

    # Test invalid URL.
    with check_mp3_content.check_mp3('010082a2c802c5275bb00030743e75ad',
                                     'https://my.mixtape.moe/uueczx.mp3'):
        ie = Soundg

# Generated at 2022-06-24 13:17:40.496002
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE1 = SoundgasmIE()
    assert(IE1 is not None)


# Generated at 2022-06-24 13:17:43.376737
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    assert SoundgasmIE()._match_id(url) == ('Piano-sample', 'ytdl')

# Generated at 2022-06-24 13:17:50.123242
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info = SoundgasmIE()._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert info['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert info['display_id'] == 'Piano-sample'
    assert info['title'] == 'Piano sample'
    assert info['vcodec'] == 'none'
    assert info['uploader'] == 'ytdl'

# Generated at 2022-06-24 13:17:52.302005
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        SoundgasmProfileIE('http://www.soundgasm.net/u/ytdl')
        exit(0)
    except:
        exit(1)

# Generated at 2022-06-24 13:18:02.804283
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    args = {
        'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
        'display_id': 'Piano-sample',
        'audio_url': 'http://d.soundgasm.net/sounds/88abd86ea000cafe98f96321b23cc1206cbcbcc9/Piano-sample.m4a',
        'title': 'Piano sample',
        'description': 'Royalty Free Sample Music',
        'uploader': 'ytdl',
        'upload_date': '20140219',
        'audio_id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    }
    actual = SoundgasmIE(**args)

# Generated at 2022-06-24 13:18:07.401452
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._real_extract(url)['id'] == 'ytdl'

# Generated at 2022-06-24 13:18:10.060443
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Inject code to make a new SoundgasmIE object.
    code = """
        new_ie = SoundgasmIE()
    """

    # Execute code to create a new SoundgasmIE object.
    exec(code)

    # Verify that the object has been created successfully.
    assert new_ie is not None


# Generated at 2022-06-24 13:18:11.033218
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    
    TestClass = SoundgasmIE()
    

# Generated at 2022-06-24 13:18:12.410355
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  x = SoundgasmProfileIE()
  assert x != None

# Generated at 2022-06-24 13:18:12.985000
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass

# Generated at 2022-06-24 13:18:15.028400
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .soundgasm import SoundgasmIE

    assert SoundgasmIE



# Generated at 2022-06-24 13:18:18.657991
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
   ie = SoundgasmProfileIE(SoundgasmProfileIE.IE_NAME, SoundgasmProfileIE._VALID_URL,
           SoundgasmProfileIE._TEST)
   assert ie.ie_key() == SoundgasmProfileIE.IE_NAME

# Generated at 2022-06-24 13:18:25.646347
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE()._real_extract(url)
    assert ie['id'] == 'ytdl'
    assert ie['title'] == 'ytdl'
    assert ie['url'] == 'http://soundgasm.net/u/ytdl/#'
    assert ie['_type'] == 'playlist'
    assert len(ie['entries']) == 1
    assert ie['entries'][0]['_type'] == 'url'
    assert ie['entries'][0]['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'