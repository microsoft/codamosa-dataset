

# Generated at 2022-06-12 18:07:00.015508
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-12 18:07:05.348393
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    name = SoundgasmIE.IE_NAME
    print("Constructing class " + name + "...")
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    print("Class " + name + " constructed.")

# Generated at 2022-06-12 18:07:12.325641
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    if __name__ == '__main__':
        instance = SoundgasmProfileIE()
        assert(instance.IE_NAME == 'soundgasm:profile')
        assert(instance._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
        assert(instance._TEST['url'] == 'http://soundgasm.net/u/ytdl')
        assert(instance._TEST['info_dict']['id'] == 'ytdl')
        assert(instance._TEST['playlist_count'] == 1)


# Generated at 2022-06-12 18:07:16.002818
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	"""Test function for SoundgasmIE"""
	url = 'http://soundgasm.net/u/ytdl/Piano-sample'
	test_instance = SoundgasmIE()._real_extract(url)

# Generated at 2022-06-12 18:07:19.460807
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    cls = SoundgasmProfileIE
    # Make sure the class is working
    ie = cls()
    assert ie._downloader is not None
    # Make sure the template is copied
    ie._TEST = 1
    ie = cls()
    assert ie._TEST == 1

# Generated at 2022-06-12 18:07:24.462941
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE(0)
    assert obj.IE_NAME == 'soundgasm:profile'
    assert obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:07:28.075468
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = SoundgasmProfileIE._VALID_URL
    test_unit = SoundgasmProfileIE._TEST
    result = SoundgasmProfileIE.suite()
    if result.countTestCases() != 1:
        raise Exception('Incorrect count of cases')

# Generated at 2022-06-12 18:07:29.625483
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    temp = SoundgasmProfileIE(True)
    assert temp.playlist_from_matches

# Generated at 2022-06-12 18:07:32.683360
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info = SoundgasmIE()._work()
    assert info['title'] == 'Piano sample'
    assert info['description'] == 'Royalty Free Sample Music'
    assert info['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert info['uploader'] == 'ytdl'

# Generated at 2022-06-12 18:07:44.113373
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
	assert(ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-12 18:07:52.115418
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-12 18:07:54.149764
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ConstructorTestCase.check_constructor(SoundgasmProfileIE)

# Generated at 2022-06-12 18:07:56.436415
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-12 18:08:05.047716
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	# extract values
	url = 'http://soundgasm.net/u/ytdl'
	profile_id = re.search(r'https?:\/\/(?:www\.)?soundgasm\.net\/u/(?P<id>[^/]+)/?(?:\#.*)?$', url).group('id')

	# initialize test class
	test_class = SoundgasmProfileIE()

	# test values
	assert test_class._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P[^/]+)/?(?:\#.*)?$'
	assert test_class._TEST['url'] == 'http://soundgasm.net/u/ytdl'
	assert test_class._TEST['playlist_count'] == 1
	assert test_class

# Generated at 2022-06-12 18:08:14.407349
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	
	# 2nd argument is the filename of the file containing the web page to be scraped
	# 3rd argument is the url of the web page to be scraped
	constructor = SoundgasmProfileIE(None, "soundgasm-u-ytdl.html", "http://soundgasm.net/u/ytdl")
	
	# Get the playlist
	playlist = constructor.playlist_result()
	

# Generated at 2022-06-12 18:08:18.065938
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  soundgasmProfileIE = SoundgasmProfileIE('ytdl')
  assert soundgasmProfileIE.IE_NAME == 'Soundgasm:Profile'


# Generated at 2022-06-12 18:08:25.399686
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = [x for x in SoundgasmProfileIE.__bases__
          if x.IE_NAME == 'youtube:playlist'][0]('http://soundgasm.net/u/ytdl')
    assert ie.playlist_id == 'UUXfBZGJjOv-Dt1xMxwOw14A'
    assert ie._PLAYLIST_TITLE == 'Soundgasm profiles'

# Generated at 2022-06-12 18:08:32.282381
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    def test_SoundgasmProfileIE_assert_equal(one, two):
        if one != two:
            print('test fail')

    ie = SoundgasmProfileIE()
    test_SoundgasmProfileIE_assert_equal(ie.ie_key(), 'Soundgasm')
    test_SoundgasmProfileIE_assert_equal(ie.ie_name(), 'Soundgasm')
    test_SoundgasmProfileIE_assert_equal(ie.suitable(None), False)
    test_SoundgasmProfileIE_assert_equal(ie.suitable('https://iamnotavalidurl.com'), False)
    test_SoundgasmProfileIE_assert_equal(ie.suitable('https://iamnotavalidurl.com/'), False)

# Generated at 2022-06-12 18:08:33.372045
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()


# Generated at 2022-06-12 18:08:44.747319
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    mobj = re.match(ie._VALID_URL, ie._TEST['url'])
    audio_url = re.search(r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', ie._download_webpage(ie._TEST['url'], mobj.group('display_id'))).group('url')
    audio_id = re.search(r'/([^/]+)\.m4a', audio_url).group(1)

    info = ie._real_extract(ie._TEST['url'])
    assert info['id'] == audio_id
    assert info['url'] == audio_url
    assert info['ext'] == ie._TEST['info_dict']['ext']

# Generated at 2022-06-12 18:08:57.207272
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    '''
    Unit test for constructor of class SoundgasmIE
    '''
    # test first constructor
    SoundgasmIE(None)

    # test second constructor
    SoundgasmIE(None, 'http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-12 18:09:05.229193
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# Result: http://soundgasm.net/u/ytdl/Piano-sample
	soundgasm_ie = SoundgasmIE()
	audio_result = soundgasm_ie._real_extract("http://soundgasm.net/u/ytdl/Piano-sample")
	print("1/4. Real extract result: \n" + str(audio_result))

	# Result: http://soundgasm.net/u/ytdl
	soundgasm_ie = SoundgasmProfileIE()
	audio_result = soundgasm_ie._real_extract("http://soundgasm.net/u/ytdl")
	print("2/4. Real extract result: \n" + str(audio_result))

	# Result: None
	soundgasm_ie = SoundgasmIE()
	

# Generated at 2022-06-12 18:09:09.064159
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    s = SoundgasmProfileIE()
    a = s.get_test_cases(url, None)
    assert(a[0] == 'ytdl')

# Generated at 2022-06-12 18:09:16.404628
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    config = {"url": "http://soundgasm.net/u/ytdl/Piano-sample",
              "display_id": "Piano-sample",
              "audio_id": "88abd86ea000cafe98f96321b23cc1206cbcbcc9"}
    soundgasm_ie = SoundgasmIE()
    assert soundgasm_ie._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)"

# Generated at 2022-06-12 18:09:18.204883
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE("")
    print("Testing SoundgasmProfileIE constructor")

# Generated at 2022-06-12 18:09:25.655786
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """test constructor of SoundgasmIE"""
    igor = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert igor._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert igor.IE_NAME == 'Soundgasm'


# Generated at 2022-06-12 18:09:29.532840
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE()._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    })

# Generated at 2022-06-12 18:09:39.352548
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.__name__ == 'SoundgasmProfileIE'
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert SoundgasmProfileIE._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}


# Generated at 2022-06-12 18:09:46.504535
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest
    import os.path
    from urlparse import urlparse
    from deepdiff import DeepDiff

    class SoundgasmProfileIETest(unittest.TestCase):
        URL_VIDEOS_LIST_PAGE = 'http://www.soundgasm.net/u/ytdl'
        global RETURN_GET_URL_VIDEOS_LIST_PAGE
        global RETURN_VIDEOS_LIST_PAGE
        global RETURN_VIDEOS_LIST_PAGE_ROOT
        global RETURN_URL_VIDEOS_LIST_PAGE
        global RETURN_VIDEOS_LIST_PAGE_HOSTNAME
        global RETURN_VIDEOS_LIST_PAGE_FILE
        global RETURN_VIDEOS_LIST_PAGE_QUERY
        global RETURN_PLAYLIST

# Generated at 2022-06-12 18:09:54.536601
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert re.match(ie._VALID_URL, 'http://soundgasm.net/u/ytdl/Piano-sample') is not None
    assert re.match(ie._VALID_URL, 'http://www.soundgasm.net/u/ytdl/Piano-sample') is not None
    assert re.match(ie._VALID_URL, 'http://soundgasm.net/u/ytdl/Piano-sample#') is not None

# Generated at 2022-06-12 18:10:08.589458
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info = SoundgasmProfileIE()._real_extract('http://soundgasm.net/u/ytdl')
    assert info is not None
    assert info['id'] == 'ytdl'
    assert info['_type'] == 'playlist'
    assert len(info['entries']) > 100

# Generated at 2022-06-12 18:10:11.196800
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Test whether a SoundgasmIE instance can be constructed. """
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-12 18:10:13.984679
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()._real_extract('http://soundgasm.net/u/ytdl/Dinner-for-Two')

# Generated at 2022-06-12 18:10:16.679432
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = SoundgasmIE._VALID_URL
    obj = SoundgasmIE(url)
    display_id = obj._match_id(url)
    assert display_id is not None


# Generated at 2022-06-12 18:10:27.946935
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "https://soundgasm.net/u/ytdl/Piano-sample"
    sg_ie = SoundgasmIE()
    assert sg_ie.suitable(url)
    assert sg_ie.IE_NAME == 'soundgasm:user'
    assert sg_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    profile_url = "https://soundgasm.net/u/ytdl#jp-popup-1"
    assert SoundgasmProfileIE().suitable(profile_url)

# Generated at 2022-06-12 18:10:32.186285
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from . import SoundgasmIE
    from . import SoundgasmProfileIE
    assert isinstance(SoundgasmIE('SoundgasmIE'), InfoExtractor)
    assert isinstance(SoundgasmProfileIE('SoundgasmProfileIE'), InfoExtractor)

# Generated at 2022-06-12 18:10:39.029308
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Redirects to new URL
    assert SoundgasmIE().suitable('http://soundgasm.net/play/ytdl/Piano-sample')
    # From Play button on user profiles
    assert SoundgasmIE().suitable('http://soundgasm.net/u/ytdl/Piano-sample')
    assert not SoundgasmIE().suitable('http://soundgasm.net/u/ytdl')
    assert not SoundgasmIE().suitable('http://soundgasm.net/')
    assert not SoundgasmIE().suitable('http://soundgasm.net/new')

# Generated at 2022-06-12 18:10:41.013440
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_object = SoundgasmProfileIE()
    assert type(test_object) == SoundgasmProfileIE

# Generated at 2022-06-12 18:10:52.770242
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-12 18:10:58.830944
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	ie = SoundgasmIE()
	assert ie.IE_NAME == "soundgasm"
	assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
	assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'


# Generated at 2022-06-12 18:11:18.469766
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('Soundgasm')

# Generated at 2022-06-12 18:11:20.638699
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE(None)._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-12 18:11:24.016181
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-12 18:11:27.501912
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-12 18:11:37.967100
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test object creation
    print('Testing object creation...')
    # Test improper usage of the constructor.
    print('Testing constructor with invalid arguments...')
    g = SoundgasmIE('foo', '1', '2', '3')
    assert g.url == 'foo' and g.user == '1' and g.display_id == '2' and g.webpage == '3'
    # Test proper usage of the constructor.
    print('Testing constructor with valid arguments...')
    g = SoundgasmIE('foo', '1', '2', '3', '4')
    assert g.url == 'foo' and g.user == '1' and g.display_id == '2' and g.webpage == '3' and g.is_playlist == '4'


# Generated at 2022-06-12 18:11:45.245738
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie._TEST['title'] == 'Piano sample'
    assert ie._TEST['uploader'] == 'ytdl'


# Generated at 2022-06-12 18:11:57.275192
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from youtube_dl.utils import encode_data_uri
    from youtube_dl.extractor import get_info_extractor
    SoundgasmIE = get_info_extractor('Soundgasm')
    audio_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    audio_url = encode_data_uri('audio/mp4', 'bla')
    audio_title = 'Piano Sample'
    profile_url = 'https://soundgasm.net/u/ytdl'
    description = 'Royalty Free Sample Music'

# Generated at 2022-06-12 18:12:08.290418
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test SoundgasmIE’s constructor SoundgasmIE(**kwargs)
    # which is inherited from YoutubeDLExtractor._subclass_search_for_extractor()
    # via YoutubeDLExtractor._match_id()

    # ToDo: test YoutubeDLExtractor._subclass_search_for_extractor()
    # as for now it is empty

    # ToDo: test YoutubeDLExtractor._match_id()
    # as for now it is empty

    # New instance of class SoundgasmIE, the subclass of YoutubeDLExtractor
    inst = SoundgasmIE(**{})

    # Test instance’s variable VALID_URL

# Generated at 2022-06-12 18:12:09.535029
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE()
    assert a.IE_NAME == 'soundgasm'

# Generated at 2022-06-12 18:12:10.682239
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test = SoundgasmProfileIE()
    assert test.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-12 18:12:59.741627
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test =  SoundgasmProfileIE()


# Generated at 2022-06-12 18:13:05.137833
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import sys
    sys.path.append('../')
    from yt_dl.utils import construct_IE
    # To test class SoundgasmIE
    Soundgasm = construct_IE('Soundgasm')
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    test_result = Soundgasm._real_extract(Soundgasm, url)
    assert test_result['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    # Make sure that the title is correct
    assert test_result['title'] == 'Piano sample'
    # Verify that the uploader is correct
    assert test_result['uploader'] == 'ytdl'



# Generated at 2022-06-12 18:13:10.647469
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    # test
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:13:12.595906
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None)._real_extract(None)

# Generated at 2022-06-12 18:13:15.797389
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl', {})
    assert ie._match_id('http://soundgasm.net/u/ytdl') == 'ytdl'

# Generated at 2022-06-12 18:13:26.704490
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    user = """
        <div class="jp-title">
            <a href="/u/ytdl/Piano-sample" style="text-decoration:none;">
                <span style="font-size:80%">ytdl</span><br>
                Piano sample
            </a>
        </div>
        """
    desc = """<li>Description:<br>
    Royalty Free Sample Music</li>"""
    title = """<div class="jp-title">
            <a href="/u/ytdl/Piano-sample" s
            tyle="text-decoration:none;">
                <span style="fo
                nt-size:80%">ytdl</span><br>
                Piano sample
            </a>
        </div>"""

# Generated at 2022-06-12 18:13:28.228506
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE('ytdl')
    assert obj.info_dict['id'] == 'ytdl'

# Generated at 2022-06-12 18:13:29.398293
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == "Soundgasm"

# Generated at 2022-06-12 18:13:35.189988
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # This is testing the functionality of constructor with a test user's profile.
    # If the test case fails, it is probably because the webpage has been changed.
    info_extractor = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert info_extractor._VALID_URL == 'http://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:13:36.353222
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE()
    assert isinstance(a, object)

# Generated at 2022-06-12 18:15:10.371313
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from . import SoundgasmProfileIE

# Generated at 2022-06-12 18:15:12.641299
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Create an instance of class SoundgasmProfileIE
    SoundgasmProfileIE()


# Generated at 2022-06-12 18:15:15.931822
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    result = SoundgasmIE()._constructor(
        'http://soundgasm.net/u/ytdl/Piano-sample')
    assert result.get_url() == 'http://soundgasm.net/u/ytdl/Piano-sample'

# Generated at 2022-06-12 18:15:17.203054
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	SoundgasmProfileIE("http://soundgasm.net/u/ytdl")

# Generated at 2022-06-12 18:15:21.977002
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	
	#Use a sample from the file 'test' from the website to test
	#and make sure that the file was not changed.
	test = SoundgasmIE({})
	result = test.extract_info(
				'http://soundgasm.net/u/ytdl/Piano-sample',
				download=False)
	assert result['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-12 18:15:25.197277
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	# Please note that you cannot check url in constructor,
	assert SoundgasmProfileIE(None)._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

	# Please note that you cannot check params in constructor,
	assert SoundgasmProfileIE(None)._downloader == None

# Generated at 2022-06-12 18:15:27.804743
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    id = "ytdl"
    url = "http://soundgasm.net/u/ytdl"
    assert IE_NAME=='soundgasm:profile'

# Generated at 2022-06-12 18:15:29.880959
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    # Make sure that the constructor works
    ie = SoundgasmProfileIE()

    assert ie is not None



# Generated at 2022-06-12 18:15:32.977801
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE_TEST = SoundgasmIE()
    assert IE_TEST._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert IE_TEST.IE_NAME == 'soundgasm'

# Generated at 2022-06-12 18:15:41.299909
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE()
    soundgasm_profile_url = 'http://soundgasm.net/u/ytdl'
    _VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    
    # Test that a profile URL is valid 
    mobj = re.match(_VALID_URL, soundgasm_profile_url)
    assert mobj != None
    
    # Test that the profile ID is extracted correctly
    profile_id = soundgasm_profile_ie._match_id(soundgasm_profile_url)
    assert profile_id == 'ytdl'
