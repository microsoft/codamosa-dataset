

# Generated at 2022-06-12 18:06:53.159747
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    


# Generated at 2022-06-12 18:07:03.965619
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
# Constructor parameters
# ie -- like YoutubeIE or regexp pattern
    ie = 'SoundgasmProfileIE'
# url -- like 'http://soundgasm.net/u/ytdl'
    url = 'http://soundgasm.net/u/ytdl'
# video_id -- like 'ytdl'
    video_id = 'ytdl'
# webpage -- html page acquired by url
    webpage = 'http://soundgasm.net/u/ytdl' # (really, it is a string)
# video_title -- video title, if it can be found
    video_title = 'ytdl'
# video_thumbnail -- video thumbnail image url
    video_thumbnail = None
# video_description -- video description
    video_description = None
# video_duration -- video duration in seconds
    video_duration

# Generated at 2022-06-12 18:07:08.532367
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    sg_ie = SoundgasmIE()._real_extract(url)

    assert sg_ie['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert sg_ie['uploader'] == 'ytdl'
    assert sg_ie['display_id'] == 'Piano-sample'
    assert sg_ie['title'] == 'Piano sample'
    assert sg_ie['description'] == 'Royalty Free Sample Music'
    assert sg_ie['url'] == 'http://soundgasm.net/sounds/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'


# Generated at 2022-06-12 18:07:15.596961
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == "soundgasm"
    # Regression test for #939
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    expected_structure = {
            'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
            'ext': 'm4a',
            'title': 'Piano sample',
            'description': 'Royalty Free Sample Music',
            'uploader': 'ytdl',
         }
    # Regression test for #939
    assert ie._TEST

# Generated at 2022-06-12 18:07:16.217936
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-12 18:07:17.249303
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None)

# Generated at 2022-06-12 18:07:22.023235
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Check that the constructor of SoundgasmProfileIE can initialize an object
    # with a profile having no audio samples
    ie = SoundgasmProfileIE()
    obj = ie.suitable('https://soundgasm.net/u/ytdl/')
    assert(obj)
    assert(isinstance(obj, SoundgasmProfileIE))
    assert(obj.name() == 'Soundgasm:profile')
    assert(obj.suitable('http://soundgasm.net/u/') is False)

# Generated at 2022-06-12 18:07:24.360255
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    #Inicializamos las variables
    assert SoundgasmProfileIE._VALID_URL
    assert SoundgasmProfileIE._TEST

# Generated at 2022-06-12 18:07:28.293342
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert  SoundgasmProfileIE()._match_id('http://soundgasm.net/u/ytdl/') == 'ytdl'
    assert  SoundgasmProfileIE()._match_id('http://soundgasm.net/u/ytdl/test') == 'ytdl'


# Generated at 2022-06-12 18:07:30.139122
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    testModule = __import__('__main__').sys.modules['__main__']
    SoundgasmProfileIE(testModule)


# Generated at 2022-06-12 18:07:45.806488
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == 'soundgasm'
    assert SoundgasmIE()._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert SoundgasmIE()._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert SoundgasmIE()._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-12 18:07:46.809211
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()



# Generated at 2022-06-12 18:07:48.497609
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	t = SoundgasmProfileIE()
	assert t.IE_NAME == 'Soundgasm profile'

# Generated at 2022-06-12 18:07:51.412640
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	args = {
		'url': 'http://soundgasm.net/u/ytdl',
		'info_dict': {
			'id': 'ytdl',
		},
		'playlist_count': 1,
	}
	return SoundgasmProfileIE('Soundgasm: Soundgasm Profile', args)

test_SoundgasmProfileIE()

# Generated at 2022-06-12 18:07:56.274600
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import _make_valid_url, FakeYDL
    
    def test_constructor():
        return SoundgasmProfileIE(_make_valid_url("Soundgasm"), FakeYDL())
    
    test_constructor()

# Generated at 2022-06-12 18:07:58.625610
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')



# Generated at 2022-06-12 18:08:00.271371
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Test for constructor of class SoundgasmIE"""
    ie = SoundgasmIE()
    assert ie

# Generated at 2022-06-12 18:08:06.976271
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # First, we construct an instance of class SoundgasmProfileIE
    ie = SoundgasmProfileIE()
    # Now that the instance has been constructed, let's see if we have the
    # expected value for the IE_NAME attribute.
    assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-12 18:08:09.354887
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # constructor of SoundgasmIE
    extractor = SoundgasmIE()
    assert extractor.IE_NAME == 'SoundgasmIE'

# Generated at 2022-06-12 18:08:15.114351
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    baseurl = 'http://soundgasm.net/u/ytdl/Piano-sample'
    expected = SoundgasmIE(InfoExtractor)._real_extract(baseurl)
    assert expected['url'] == 'https://soundgasm.net/dynamic/ytdl/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
test_SoundgasmIE()


# Generated at 2022-06-12 18:08:26.266331
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'

# Generated at 2022-06-12 18:08:36.557569
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE._VALID_URL is not None
    assert SoundgasmIE._TEST is not None
    assert SoundgasmIE._TEST['url'] is not None
    assert SoundgasmIE._TEST['info_dict'] is not None
    assert SoundgasmIE._TEST['info_dict']['id'] is not None
    assert SoundgasmIE._TEST['info_dict']['ext'] is not None
    assert SoundgasmIE._TEST['info_dict']['title'] is not None

    # 
    assert SoundgasmIE._TEST['info_dict']['description'] is not None


# Generated at 2022-06-12 18:08:40.310072
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	from .test import get_testcases

	testclass = SoundgasmProfileIE()
	for tc in get_testcases(testclass.IE_NAME, include_only_testcases=True):
		testclass._run_test(tc)

# Generated at 2022-06-12 18:08:42.009550
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE("test")
    assert ie


# Generated at 2022-06-12 18:08:46.354633
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test = SoundgasmProfileIE()
    unit = test._real_extract(SoundgasmProfileIE()._TEST['url'])
    assert unit['id'] == SoundgasmProfileIE()._TEST['info_dict']['id']
    assert len(unit['entries']) == SoundgasmProfileIE()._TEST['playlist_count']


# Generated at 2022-06-12 18:08:47.589385
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    assert obj.IE_NAME == 'Soundgasm'

# Generated at 2022-06-12 18:08:49.531411
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass


# Generated at 2022-06-12 18:08:53.696633
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:08:55.057552
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE is not None

# Generated at 2022-06-12 18:09:03.901548
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    my_obj = SoundgasmIE()
    my_obj._download_webpage('http://soundgasm.net/u/ytdl/Piano-sample', 'Piano-sample')
    my_obj._search_regex('<div[^>]+\bclass=["\']jp-title[^>]+>([^<]+)', '<div[^>]+\bclass=["\']jp-title[^>]+>([^<]+)')

# Generated at 2022-06-12 18:09:30.848567
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    entry = SoundgasmIE().get_info(url)
    assert entry == {'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
                     'ext': 'm4a',
                     'title': 'Piano sample',
                     'description': 'Royalty Free Sample Music',
                     'uploader': 'ytdl',
                     'display_id': 'Piano-sample'}


# Generated at 2022-06-12 18:09:41.370476
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Unit test for constructor of class SoundgasmIE"""
    print("SoundgasmIE constructor unit test")
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    url_short = "http://soundgasm.net/u/ytdl/Piano-sample"
    url_long = "http://soundgasm.net/u/yt-dl/Piano-sample"
    url_list = "http://soundgasm.net/u/yt-dl"
    ie = SoundgasmIE()
    # test a single extractor
    print("test a single extractor")
    assert ie.ie_key() == "Soundgasm"
    assert ie.suitable(url) == True
    assert ie.suitable(url_short) == True

# Generated at 2022-06-12 18:09:42.474022
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert isinstance(SoundgasmIE(None), InfoExtractor)
    

# Generated at 2022-06-12 18:09:44.103870
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Constructor test
    """
    ie = SoundgasmProfileIE(None)
    ie.IE_NAME



# Generated at 2022-06-12 18:09:52.811875
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}

# Generated at 2022-06-12 18:09:53.780769
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    a = SoundgasmIE()
    print(a._TEST)

# Generated at 2022-06-12 18:09:57.349992
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie.IE_NAME == 'soundgasm'

if __name__ == "__main__":
    test_SoundgasmIE()

# Generated at 2022-06-12 18:10:00.752745
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}


# Generated at 2022-06-12 18:10:02.476090
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	pass

# Generated at 2022-06-12 18:10:14.860879
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:10:58.428155
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_url = "http://soundgasm.net/u/ytdl"
    ie = SoundgasmProfileIE()
    # Test the class is built
    assert ie is not None
    # Test the built class can extract profile data
    ie.extract(test_url)

# Generated at 2022-06-12 18:11:08.364537
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'
    webpage = """
    <p><a href="/u/ytdl/Piano-sample">Piano sample</a></p>
    """
    """ The function _download_webpage of class SoundgasmIE returns the webpage with the id, profile_id and the webpage content. """
    webpage_content = SoundgasmIE._download_webpage(webpage, 0, url)
    """ This function, _real_extract is declared in the constructor of SoundgasmProfileIE. It is called to check the validity of the url and extract the details from the webpage"""
    profile_details = SoundgasmProfileIE._real_extract(webpage_content, 0, url)

# Generated at 2022-06-12 18:11:16.720540
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Unit test for constructor of class SoundgasmIE
    """
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    downloader = InfoExtractor(SoundgasmIE.IE_NAME)
    info = downloader.extract(url)
    assert info["id"] == "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
    assert info["url"] == "http://d1z8bhy6pmmn0r.cloudfront.net/uploads/8/2/b/5/82b5d7e5-8a05-4c0d-b5ba-0150c3016579/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a"
   

# Generated at 2022-06-12 18:11:20.912688
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """ 
    Unit test for class SoundgasmIE
    """
    # instatiate a class
    soundgasm_class = SoundgasmIE()
    # test for testing the class
    assert isinstance(soundgasm_class, SoundgasmIE)


# Generated at 2022-06-12 18:11:21.780360
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	# Test code goes here
	pass


# Generated at 2022-06-12 18:11:30.893746
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.name == 'soundgasm:profile'
    assert ie.IE_NAME == ie.name
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/([^/]+)/?(?:\#.*)?'
    assert ie._TEST == { 'url': 'http://soundgasm.net/u/ytdl', 'info_dict': { 'id': 'ytdl' }, 'playlist_count': 1 }

# Generated at 2022-06-12 18:11:35.111825
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    s = SoundgasmProfileIE()
    assert isinstance(s, SoundgasmProfileIE)
    assert isinstance(s, InfoExtractor)
    s = SoundgasmIE()
    assert isinstance(s, SoundgasmIE)
    assert isinstance(s, InfoExtractor)

# Generated at 2022-06-12 18:11:36.131898
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-12 18:11:38.181866
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	from SoundgasmIE import SoundgasmIE

# Generated at 2022-06-12 18:11:44.217364
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    soundgasm_profile_ie = SoundgasmProfileIE()
    audio_url = soundgasm_profile_ie.extract('http://soundgasm.net/u/ytdl')
    assert audio_url.get('url') == 'http://soundgasm.net/u/ytdl/Piano-sample'

# Generated at 2022-06-12 18:13:17.898306
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  """
  This function is unit test for the constructor of class SoundgasmProfileIE.
  The class constructor is tested with a random Youtube URL and with the URL of a random Youtube video.
  """

# Generated at 2022-06-12 18:13:26.309501
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE("soundgasm:profile")
    assert ie.IE_NAME == "soundgasm:profile"
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-12 18:13:27.694753
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # type: () -> None
    SoundgasmProfileIE()

# Generated at 2022-06-12 18:13:36.936441
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'

# Generated at 2022-06-12 18:13:38.263013
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()
    assert isinstance(obj, SoundgasmProfileIE)

# Generated at 2022-06-12 18:13:39.502677
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('Soundgasm', 'http://soundgasm.net/u/ytdl')

# Generated at 2022-06-12 18:13:42.354969
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        # check instantiation of class SoundgasmProfileIE
        ie = SoundgasmProfileIE()
        print("[OK] Class SoundgasmProfileIE instantiated")
    except Exception as err:
        print("[ERROR] Class SoundgasmProfileIE not instantiated: %s" % err)



# Generated at 2022-06-12 18:13:43.892640
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Make sure the SoundgasmIE class constructor works
    """
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-12 18:13:48.797617
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_cases = {
        'https://soundgasm.net/u/ytdl': 'ytdl'
    }
    obj = SoundgasmProfileIE(None)
    for test_url, expected_result in test_cases.items():
        result = obj._match_id(test_url)
        assert result == expected_result

# Generated at 2022-06-12 18:13:53.014899
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    assert ie.display_id == "Piano-sample"
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
