

# Generated at 2022-06-12 18:06:52.914782
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    i = SoundgasmIE()
    assert i.IE_NAME == 'soundgasm'


# Generated at 2022-06-12 18:07:03.901273
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasm_ie = SoundgasmIE()

    assert soundgasm_ie.IE_NAME == 'soundgasm'
    assert re.match(soundgasm_ie._VALID_URL, soundgasm_url)

# Generated at 2022-06-12 18:07:06.960700
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl', None).download('http://soundgasm.net/u/ytdl', None, None, None)

# Generated at 2022-06-12 18:07:08.549950
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    a = SoundgasmIE()
    assert soundgasm_ie.__name__ == 'SoundgasmIE'

# Generated at 2022-06-12 18:07:10.357621
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Constructor of class SoundgasmIE
    assert SoundgasmIE().ie_key() == 'Soundgasm'

# Generated at 2022-06-12 18:07:16.881935
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test audio URL
    audio_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    # Test instantiation
    audio_obj = SoundgasmIE(audio_url)
    # Check class of instantiated object is SoundgasmIE
    assert(isinstance(audio_obj, SoundgasmIE))
    # Check URL is same
    assert(audio_obj.url == audio_url)


# Generated at 2022-06-12 18:07:18.217888
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    return ie


# Generated at 2022-06-12 18:07:19.870782
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    x = SoundgasmIE()

# Generated at 2022-06-12 18:07:23.994362
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    val = SoundgasmProfileIE()
    assert val._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:07:32.371554
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from extractor import Extractor
    from extractor.common import InfoExtractor
    # import logging

    # logging.basicConfig(level=logging.DEBUG,filename = 'soundgasm')

    workspace = './SoundgasmProfileIE_test/'
    test_url = 'http://www.soundgasm.net/u/ytdl/'
    list_test = ['http://www.soundgasm.net/u/ytdl/Piano-sample',
                 'http://www.soundgasm.net/u/ytdl/Piano-sample-2',
                 'http://www.soundgasm.net/u/ytdl/Sample-music']

    info_extractor = SoundgasmProfileIE()
    info_extractor._downloader = Extractor()

# Generated at 2022-06-12 18:07:42.521881
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert isinstance(ie, SoundgasmProfileIE)

# Generated at 2022-06-12 18:07:43.545835
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._downloader is None

# Generated at 2022-06-12 18:07:45.522688
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Create and return a test instance of the class SoundgasmIE"""
    return SoundgasmIE()


# Generated at 2022-06-12 18:07:53.567707
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sound = SoundgasmProfileIE()
    url = 'http://soundgasm.net/u/ytdl'
    ie = sound.ie_key()
    # Unit test for method ie_key in class SoundgasmProfileIE
    assert ie == 'Soundgasm', 'Incorrect %s' % ie
    # Unit test for method _real_extract in class SoundgasmProfileIE

# Generated at 2022-06-12 18:07:56.323969
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert 'http://soundgasm.net/u/ytdl/Piano-sample' == SoundgasmIE()._VALID_URL

# Generated at 2022-06-12 18:08:04.959468
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    # Test when the description contains an URL
    description_with_url = '''
            <div class="jp-description">This is some sample text. \
            More sample text can be found <a href="http://sample.com">here</a></div>
            '''
    url = "http://soundgasm.net/u/ytdl/Piano-sample"

# Generated at 2022-06-12 18:08:07.364557
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # check whether SoundgasmProfileIE can be constructed
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl")

# Generated at 2022-06-12 18:08:10.655797
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://www.soundgasm.net/u/ytdl')
    assert ie.__class__.__name__ == 'SoundgasmProfileIE'
    assert ie.ie_key() == 'Soundgasm'

# Generated at 2022-06-12 18:08:14.152952
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url = 'http://soundgasm.net/u/ytdl/Piano-royalty-free-sample'
    m = SoundgasmIE()
    result = m.match(test_url)
    assert result is not None


# Generated at 2022-06-12 18:08:17.168453
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("begin test_SoundgasmIE")
    inst = SoundgasmIE()
    print("end test_SoundgasmIE")


# Generated at 2022-06-12 18:08:40.137264
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE()
    assert soundgasm_profile_ie.suitable('http://soundgasm.net/u/ytdl') == True
    assert soundgasm_profile_ie.suitable('http://soundgasm.net/u/ytdl/') == True
    assert soundgasm_profile_ie.suitable('http://soundgasm.net/u/ytdl/Piano-sample') == False

# Generated at 2022-06-12 18:08:42.507460
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('file:///tmp/ytdl_test/www.soundgasm.net/u/ytdl/')

# Generated at 2022-06-12 18:08:47.767036
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_ie = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    assert(profile_ie)
    assert(profile_ie.IE_NAME == 'soundgasm:profile')
    assert(profile_ie.IE_DESC == 'soundgasm')
    assert(profile_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
    assert(profile_ie._TEST != None)

# Generated at 2022-06-12 18:08:50.774276
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:08:53.911373
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE(url)

# Generated at 2022-06-12 18:08:56.128141
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from soundgasm_downloader import soundgasm_ie
    soundgasm_ie.SoundgasmIE(None)

# Generated at 2022-06-12 18:08:58.904498
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE = SoundgasmProfileIE(None, {
        'id': 'profile',
        'url': 'http://soundgasm.net/u/ytdl',
        'playlist_count': 1
    })

# Generated at 2022-06-12 18:09:05.139217
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from_url = SoundgasmProfileIE._build_url_result(
        SoundgasmProfileIE._TEST['url'], SoundgasmProfileIE.ie_key())
    SoundgasmProfileIE._TEST.update(from_url)
    from_url['info_dict']['id'] = from_url['_type'] + ':' + from_url['info_dict']['id']
    SoundgasmProfileIE._TEST.update(from_url)
    ie = SoundgasmProfileIE(SoundgasmProfileIE._TEST)
    assert ie.__class__.__name__ == 'SoundgasmProfileIE'

# Generated at 2022-06-12 18:09:06.089805
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()

# Generated at 2022-06-12 18:09:08.068491
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    song = SoundgasmIE()
    #Test case not added yet
    return song


# Generated at 2022-06-12 18:09:53.341866
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    info_dict = {
        'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
        'ext': 'm4a',
        'title': 'Piano sample',
        'description': 'Royalty Free Sample Music',
        'uploader': 'ytdl',
    }

    downloader = SoundgasmIE()
    result = downloader.extract(url)
    print(result)
    assert result == info_dict

# Generated at 2022-06-12 18:09:54.361959
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('SoundgasmProfileIE')

# Generated at 2022-06-12 18:10:01.512974
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """test the constructor of the class SoundgasmProfileIE"""

    IE = SoundgasmProfileIE()
    assert(IE.ie_key() == 'Soundgasm')
    assert(IE.IE_NAME == 'soundgasm:profile')
    assert(IE.IE_DESC == 'Soundgasm profile page')
    assert(IE.phash == '7978f215c8e4f0b2ca7a099f4b8d74b6')
    assert(IE.is_suitable('ytdl'))

# Generated at 2022-06-12 18:10:14.565828
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-12 18:10:17.980157
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_ie = SoundgasmProfileIE()
    assert profile_ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:10:21.854198
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Constructor case
    ie = SoundgasmProfileIE()

    # Unit test for _real_extract()
    SoundgasmProfileIE._real_extract(ie, 'http://soundgasm.net/u/ytdl')

# Generated at 2022-06-12 18:10:30.851090
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Tests the constructor and public methods of class SoundgasmIE."""
    #pylint: disable=W0212
    # Suppress "Access to a protected member" warning

    # Instantiate an instance of class SoundgasmIE
    inst = SoundgasmIE()
    # Testing _VALID_URL
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    print("Testing class %s: %s" % (inst.IE_NAME, url))
    assert inst._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'  # pylint: disable=line-too-long


# Generated at 2022-06-12 18:10:31.754361
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE();

# Generated at 2022-06-12 18:10:35.310381
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().calculate_id('http://soundgasm.net/u/ytdl/Piano-sample') == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-12 18:10:36.405743
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == 'soundgasm'

# Generated at 2022-06-12 18:11:51.196050
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert '110082a2c802c5275bb00030743e75ad' == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-12 18:11:53.216567
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .playlist import Playlist
    profile_ie = SoundgasmProfileIE('SoundgasmProfileIE');
    assert(isinstance(profile_ie, Playlist))

# Generated at 2022-06-12 18:12:00.350103
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    #test_url = 'http://soundgasm.net/u/ytdl/'
    test_url = 'http://soundgasm.net/u/ytdl'
    test_url_2 = 'http://soundgasm.net/u/ytdl/#maincontent'
    valid_url = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    mobj = re.match(valid_url, test_url)
    assert mobj is not None and mobj.group('id') == 'ytdl'
    mobj = re.match(valid_url, test_url_2)
    assert mobj is not None and mobj.group('id') == 'ytdl'

# Generated at 2022-06-12 18:12:09.477290
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test if the constructor of class SoundgasmIE is working properly
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:12:10.844387
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE()
    except:
        assert False, "Failed to instantiate SoundgasmIE"


# Generated at 2022-06-12 18:12:12.571447
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_SoundgasmIE = SoundgasmIE()

# Generated at 2022-06-12 18:12:15.057039
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ytdl = SoundgasmProfileIE()
    result = ytdl.extract('http://soundgasm.net/u/ytdl')
    print(result)
    

# Generated at 2022-06-12 18:12:17.512619
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Unit test for SoundgasmIE."""
    assert True


# Generated at 2022-06-12 18:12:19.387143
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()._VALID_URL == SoundgasmIE._VALID_URL

# Generated at 2022-06-12 18:12:23.202689
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    rURL='http://soundgasm.net/u/ytdl/Piano-sample'
    T1=SoundgasmIE()._real_extract(rURL) 

# Generated at 2022-06-12 18:13:57.090061
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # test that constructor works
    ie = SoundgasmIE()

# Generated at 2022-06-12 18:14:01.068382
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE()
    audio = ie.extract(audio_url)
    assert audio['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-12 18:14:08.420342
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	#Given an url for ytdl's profile
	url = "http://soundgasm.net/u/ytdl"
	#When I create an instance of SoundgasmProfileIE
	ie_obj = SoundgasmProfileIE(url)
	#Then the value of _VALID_URL is correct
	assert ie_obj._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$"

# Generated at 2022-06-12 18:14:15.554667
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# url = 'http://soundgasm.net/u/ytdl/Piano-sample'
	# url = 'http://soundgasm.net/u/ytdl/Feminization'
	url = 'http://soundgasm.net/u/ytdl/Gag-Talking'
	regex = re.compile(SoundgasmIE._VALID_URL)
	match = regex.match(url)
	assert match

	music_info = SoundgasmIE().extract({'url':url})
	assert music_info['id'] == 'fec1b555d4b46f2e4ffc33a0f8db9e8722b2faa7'
	assert music_info['uploader'] == 'ytdl'

# Generated at 2022-06-12 18:14:17.044333
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert hasattr(SoundgasmProfileIE, 'playlist_result')

# Generated at 2022-06-12 18:14:18.754976
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """test for constructor of class SoundgasmIE"""
    # this extractor does not raise exception in its constructor
    _ = SoundgasmIE()

# Generated at 2022-06-12 18:14:26.378022
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert re.match(SoundgasmProfileIE._VALID_URL, 'http://soundgasm.net/u/ytdl/#')

    s = SoundgasmProfileIE()
    s._download_webpage_handle = open('./test/test.html', 'rb')

# Generated at 2022-06-12 18:14:28.836453
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-12 18:14:31.110754
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_moudle = SoundgasmProfileIE()
    assert isinstance(test_moudle, SoundgasmProfileIE)

# Generated at 2022-06-12 18:14:39.104656
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg_IE = SoundgasmIE()
    assert sg_IE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'