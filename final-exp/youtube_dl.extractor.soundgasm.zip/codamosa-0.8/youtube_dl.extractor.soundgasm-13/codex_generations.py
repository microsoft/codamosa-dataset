

# Generated at 2022-06-12 18:06:56.031166
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-12 18:06:59.017206
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    s = SoundgasmIE()
    assert_equals(s.ie_key(), 'Soundgasm')



# Generated at 2022-06-12 18:07:05.956541
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    with open('test/test_data/test_soundgasm.html') as f:
        webpage = f.read()

    audio_url = SoundgasmIE._html_search_regex(
        r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', webpage,
        'audio URL', group='url')

    title = SoundgasmIE._search_regex(
        r'<div[^>]+\bclass=["\']jp-title[^>]+>([^<]+)',
        webpage, 'title', default='display_id')


# Generated at 2022-06-12 18:07:17.150370
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Unit test for constructor of class SoundgasmIE
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie.__name__ == 'SoundgasmIE'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'


# Generated at 2022-06-12 18:07:18.764841
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE(None)._VALID_URL == SoundgasmProfileIE._VALID_URL


# Generated at 2022-06-12 18:07:25.910130
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print('Testing '+SoundgasmProfileIE.__name__+'...', end = ' ')
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    info = ie._real_extract('http://soundgasm.net/u/ytdl')
    if info['id'] == 'ytdl':
        print('Ok')
        return True
    else:
        print('Fail')
        return False

# Generated at 2022-06-12 18:07:26.802987
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    global soundgasmProfileIE
    soundgasmProfileIE = SoundgasmProfileIE()

# Generated at 2022-06-12 18:07:27.610670
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    return SoundgasmIE()

# Generated at 2022-06-12 18:07:28.520114
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    m = SoundgasmProfileIE()


# Generated at 2022-06-12 18:07:30.018617
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:07:42.521625
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        profile = SoundgasmProfileIE("",None)
        profile = SoundgasmProfileIE("http://soundgasm.net/u/ytdl",None)
        print("Unit test for SoundgasmProfileIE successful")
    except:
        print("Unit test for SoundgasmProfileIE failed")

# Generated at 2022-06-12 18:07:46.105369
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert SoundgasmProfileIE().extract('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-12 18:07:47.035435
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-12 18:07:49.025682
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.__class__.__name__ == 'SoundgasmProfileIE'

# Generated at 2022-06-12 18:07:53.026318
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Initialize a test suite instance of class SoundgasmProfileIE using a sample URL.
    """
    # Create instance of SoundgasmProfileIE with sample URL
    profile = SoundgasmProfileIE(url = 'http://soundgasm.net/u/ytdl')
    # Check if profile ID is correct
    assert profile.playlist_id == 'ytdl', 'Profile ID for Soundgasm profile did not match.'

# Generated at 2022-06-12 18:08:00.742008
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie.title == 'Piano sample'
    assert ie.description == 'Royalty Free Sample Music'
    assert ie.id == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert ie.display_id == 'Piano-sample'
    assert ie.uploader == 'ytdl'

if __name__ == "__main__":
    test_SoundgasmIE()

# Generated at 2022-06-12 18:08:05.119580
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()
    func2test = '_real_extract'
    assert hasattr(obj, func2test)

# Generated at 2022-06-12 18:08:10.583329
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    obj = SoundgasmIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:08:18.266966
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    #Initialize SoundgasmProfileIE instance
    inst = SoundgasmProfileIE()
    #Test class ID getter method (ie_key)
    assert inst.ie_key() == "SoundgasmProfileIE"
    #Test class name getter method (IE_NAME)
    assert inst.IE_NAME == "soundgasm:profile"
    #Test _real_extract function
    assert inst._real_extract == SoundgasmProfileIE._real_extract
    #Test _real_extract function with custom URL
    with open("SOUNDGASM_PROFILE_TEST.html") as f:
        data = f.read()
        url = "http://soundgasm.net/u/ytdl"
        profile_id = "ytdl"
        webpage = data

# Generated at 2022-06-12 18:08:29.245017
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    unit = SoundgasmIE()
    result = unit._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert(result[u'id'] == "88abd86ea000cafe98f96321b23cc1206cbcbcc9")
    assert(result[u'display_id'] == "Piano-sample")
    assert(result[u'uploader'] == "ytdl")
    assert(result[u'title'] == "Piano sample")
    assert(result[u'uploader_id'] == "ytdl")
    assert(result[u'description'] == "Royalty Free Sample Music")

# Generated at 2022-06-12 18:08:45.135025
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	SoundgasmIE.test()

# Generated at 2022-06-12 18:08:48.778367
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-12 18:08:56.938249
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$';
    assert SoundgasmProfileIE()._TEST == { 'url': 'http://soundgasm.net/u/ytdl', 'info_dict': { 'id': 'ytdl', }, 'playlist_count': 1, };
    assert SoundgasmProfileIE()._TEST['info_dict']['id'] == 'ytdl'

# Generated at 2022-06-12 18:09:02.013618
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.ie_key() == 'Soundgasm'
    assert ie.SUFFIX == '.net'
    assert ie.url_result('test', ie.ie_key()) == {
        'url': 'test',
        'ie_key': 'Soundgasm',
        '_type': 'url_transparent',
    }

# Generated at 2022-06-12 18:09:12.924589
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    class UnitTestSoundgasmProfileIE(SoundgasmProfileIE):
        def _real_extract(self, url):
            return super(UnitTestSoundgasmProfileIE, self)._real_extract(url)

    inst = UnitTestSoundgasmProfileIE()
    test_url = 'http://soundgasm.net/u/ytdl'
    result = inst._real_extract(test_url)

# Generated at 2022-06-12 18:09:18.596171
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print("<SoundgasmProfileIE> test_SoundgasmProfileIE")

    # Define a SoundgasmProfileIE object
    SoundgasmProfileIE_obj = SoundgasmProfileIE()

    # Extract the real data
    profile_url = "http://soundgasm.net/u/ytdl"
    SoundgasmProfileIE_obj._real_extract(profile_url)

    # Define the global and local variable
    a_url = "https://soundgasm.net/u/ytdl"

    # Define local variable
    profile_id = SoundgasmProfileIE_obj._match_id(a_url)
    assert profile_id == "ytdl"



# Generated at 2022-06-12 18:09:29.720599
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert 'SoundgasmProfileIE' in globals()
    assert 'constructor of class SoundgasmProfileIE' in globals()
    assert 'url is %s' % IE_SOUNDGASM_PROFILE_TEST_URL in globals()
    assert 'IE_SOUNDGASM_PROFILE_TEST_URL' in globals()
    assert 'IE_SOUNDGASM_PROFILE_TEST_RESULT' in globals()
    assert 'info_dict' in globals()
    assert 'playlist_count' in globals()
    Display_id_of_SoundgasmProfileIE = 'Test'

# Generated at 2022-06-12 18:09:30.329067
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-12 18:09:41.056546
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# Test with a random video
	# Data for this test video is stored in the file
	# test_Soundgasm_random.html
	url = "http://soundgasm.net/u/ytdl/Piano-sample"
	data_file = 'test_Soundgasm_random.html'
	# Make the object  
	IE = SoundgasmIE()

	# Read the data from the file
	data = ""
	with open (data_file, "r") as myfile:
    		data = myfile.read()
	# Match the metadata
	match_metadata = re.search('m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', data)

	# Add the values to the metadata_dict
	metadata_dict = {}
	metadata_

# Generated at 2022-06-12 18:09:42.206151
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE(None)
    ie.register()

# Generated at 2022-06-12 18:10:04.942439
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie_cls = globals()['SoundgasmProfileIE']
    test_cases = {
        "Example": {},
        "Example Example": {},
        "Example/Example": None,
        "Example\\Example": {},
        "Example\\Example/Example": None,
    }
    for input_url, output_url in test_cases.items():
        if output_url is None:
            output_url = input_url
        assert ie_cls._VALID_URL.match(ie_cls._get_url(input_url))
        assert ie_cls._VALID_URL.match(ie_cls._get_url('http://soundgasm.net/u/' + input_url))

# Generated at 2022-06-12 18:10:05.758955
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert True

# Generated at 2022-06-12 18:10:08.521461
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE = SoundgasmProfileIE()
    assert isinstance(SoundgasmProfileIE, SoundgasmProfileIE)

# Generated at 2022-06-12 18:10:15.812866
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    print("Unit test for SoundgasmIE")

    info = SoundgasmIE._extract_info("http://soundgasm.net/u/ytdl/Piano-sample")

    print("id>>:          ", info['id'])
    print("display_id>>:  ", info['display_id'])
    print("url>>:         ", info['url'])
    print("title>>:       ", info['title'])
    print("description>>: ", info['description'])
    print("uploader>>:    ", info['uploader'])


# Generated at 2022-06-12 18:10:17.853724
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'


# Generated at 2022-06-12 18:10:21.716707
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    klass = SoundgasmIE
    # Testing for both the constructor and the function _real_extract
    instance = klass()
    instance._real_extract("http://soundgasm.net/u/ytdl/")

# Generated at 2022-06-12 18:10:30.764552
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert 'ytdl' == SoundgasmProfileIE._match_id('http://soundgasm.net/u/ytdl')
    assert 'u/ytdl/ytdl' == SoundgasmProfileIE._match_id('http://soundgasm.net/u/ytdl/ytdl')
    assert 'u/ytdl/ytdl' == SoundgasmProfileIE._match_id('http://soundgasm.net/u/ytdl/ytdl/')
    assert 'ytdl?#piano' == SoundgasmProfileIE._match_id('http://soundgasm.net/u/ytdl#piano')
    assert 'ytdl?#piano' == SoundgasmProfileIE._match_id('http://soundgasm.net/u/ytdl/#piano')

# Generated at 2022-06-12 18:10:33.970559
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    # assert ie._VALID_URL == ie.VALID_URL
    assert ie._TEST['url'] == ie.TEST_URLs[0]

# Generated at 2022-06-12 18:10:34.845064
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	SoundgasmIE.suite()

# Generated at 2022-06-12 18:10:35.949131
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.extractor

# Generated at 2022-06-12 18:11:24.493048
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_ie = SoundgasmProfileIE()
    assert profile_ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert profile_ie.IE_NAME == 'soundgasm:profile'
    assert profile_ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-12 18:11:29.284856
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl/'
    ie = SoundgasmProfileIE()
    obj = ie._real_extract(url)

# Generated at 2022-06-12 18:11:33.196234
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    sie = SoundgasmIE()
    m = re.match(sie._VALID_URL, url)
    assert m
    sie._real_extract(url)


# Generated at 2022-06-12 18:11:36.174386
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE(None)
    soundgasm_profile_ie._match_id('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-12 18:11:37.141143
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None)

# Generated at 2022-06-12 18:11:38.750125
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:11:43.376327
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print(SoundgasmProfileIE('test1','test2','test3','test4','test5','test6','test7','test8','test9','test10','test11','test12','test13'))


# Generated at 2022-06-12 18:11:48.992489
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import fake_urlopen
    from .common import extractor_test

    class FakeUrl(object):
        def __init__(self, url):
            self.url = url

    def urlopen(request):
        if 'soundgasm.net/u/ytdl' in request.url:
            return fake_urlopen('http://soundgasm.net/u/ytdl')
        else:
            raise NotImplementedError()


# Generated at 2022-06-12 18:11:56.869333
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    class SGProfile(SoundgasmProfileIE):
        def _download_webpage(self, url, display_id):
            return """<html>
                <a href="http://soundgasm.net/u/ytdl/test1">http://soundgasm.net/u/ytdl/test1</a>
                <a href="http://soundgasm.net/u/ytdl/test2">http://soundgasm.net/u/ytdl/test2</a>
             </html>"""

    ydl = SoundgasmProfileIE()
    result = ydl.ie_key('http://soundgasm.net/u/ytdl')
    assert result == 'Soundgasm:profile'
    result = ydl.extract('http://soundgasm.net/u/ytdl')
   

# Generated at 2022-06-12 18:12:08.124574
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert ie._TEST['info_dict'] == {'id': 'ytdl'}
    assert ie._match_id('http://soundgasm.net/u/ytdl') == 'ytdl'
    assert ie._match_id('http://soundgasm.net/u/ytdl/') == 'ytdl'

# Generated at 2022-06-12 18:13:38.378425
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-12 18:13:39.115433
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-12 18:13:39.844888
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # urls to be tested
    return []

# Generated at 2022-06-12 18:13:41.109596
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == SoundgasmProfileIE._VALID_URL

# Generated at 2022-06-12 18:13:45.302672
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    video_info_url = 'http://soundgasm.net/u/ytdl'
    downloader = SoundgasmProfileIE()
    print(downloader.ie_key(), downloader.ie_name())
    info = downloader.extract(video_info_url)
    print(info['id'])
    for entry in info['entries']:
        print(entry)
        print()

if __name__ == '__main__':
    # test_SoundgasmProfileIE()
    print("Test finished.")

# Generated at 2022-06-12 18:13:48.068068
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_class = SoundgasmProfileIE()
    assert test_class.IE_NAME == 'soundgasm:profile'
    assert test_class._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:13:50.161865
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE("youtube-dl")
    assert obj.ie_key() == "SoundgasmProfileIE"
    assert obj.ie_name() == "Soundgasm: profile"
    assert obj.ie_description() == "Download all audio of a user"

# Generated at 2022-06-12 18:13:54.953335
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    '''Tests constructor of class SoundgasmProfileIE
    '''

    info_extractor = SoundgasmProfileIE()
    assert info_extractor.name == 'soundgasm:profile'
    assert info_extractor.IE_NAME == 'soundgasm:profile'
    assert info_extractor.IE_DESC == 'soundgasm profile URL'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:13:57.165435
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    return SoundgasmIE().extract('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-12 18:14:02.870885
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest

    class TestSoundgasm(unittest.TestCase):
        def test_constructor(self):
            soundgasm = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
            self.assertEquals("SoundgasmProfileIE", str(type(soundgasm)))
            self.assertEquals("soundgasm:profile", soundgasm.IE_NAME)
            self.assertEquals("ytdl", soundgasm._match_id("http://soundgasm.net/u/ytdl"))

    unittest.main()