

# Generated at 2022-06-12 18:07:00.775220
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    '''
    Check if SoundgasmIE can successfully be instantiated
    '''
    assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample', test=True)
    assert SoundgasmIE('http://soundgasm.net/u/ytdl', test=True)
    assert SoundgasmIE('http://soundgasm.net/u/ytdl/', test=True)


# Generated at 2022-06-12 18:07:06.852607
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()
    obj._TEST = {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    return obj.suite()

# Generated at 2022-06-12 18:07:07.798547
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE() != False

# Generated at 2022-06-12 18:07:10.630764
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE("http://soundgasm.net/u/nic")

# Generated at 2022-06-12 18:07:16.912692
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()

    assert (sg.IE_NAME == 'soundgasm')
    m = re.match(sg._VALID_URL, sg._TEST['url'])

    assert (m is not None)
    assert (m.group(1) == sg._TEST['info_dict']['uploader'])
    assert (m.group(2) == sg._TEST['info_dict']['display_id'])

    # Unit test for real_extract method of class SoundgasmIE
    res = sg._real_extract(sg._TEST['url'])
    assert (res['id'] == sg._TEST['info_dict']['id'])

# Generated at 2022-06-12 18:07:18.263016
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-12 18:07:22.522587
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	print("Testing SoundgasmIE instance constructor...")
	instance = SoundgasmIE()
	assert(len(str(instance)) > 0)
	print("SoundgasmIE instance constructor works.")


# Generated at 2022-06-12 18:07:31.608432
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	IE_NAME = 'soundgasm:profile'
	_VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
	test_url = "https://soundgasm.net/u/ytdl"
	profile_id = "ytdl"
	webpage_data = "href=\"https://soundgasm.net/u/ytdl/Piano-sample\">href=\"http://soundgasm.net/u/ytdl/Piano-sample\">href=\"http://soundgasm.net/u/ytdl/Piano-sample"
	test_entry = "https://soundgasm.net/u/ytdl/Piano-sample"

# Generated at 2022-06-12 18:07:39.049936
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-12 18:07:49.588075
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    base_url = u'http://soundgasm.net/u/ytdl/Piano-sample'

# Generated at 2022-06-12 18:07:59.364013
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-12 18:08:02.012809
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test the constructor of class SoundgasmProfileIE
    #
    # Input:
    #   url: A str.
    #
    # Output:
    #   Nothing.
    instance = SoundgasmProfileIE(SoundgasmProfileIE._downloader, url='url')
    assert instance.IE_NAME == 'soundgasm:profile'
    assert instance._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:08:12.415174
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .constructor_test import test_constructor
    from .constructor_test import test_valid_url
    from .constructor_test import test_invalid_url

    root = "http://soundgasm.net"
    valid_urls = [
        "http://soundgasm.net/u/ytdl",
        "http://soundgasm.net/u/ytdl/",
        "http://soundgasm.net/u/ytdl#",
        "http://soundgasm.net/u/ytdl/#",
        "http://soundgasm.net/u/ytdl/#_=_"]

    invalid_urls = [
        "http://soundgasm.net/u/ytdl/subpage"]

    test_constructor(SoundgasmProfileIE)
    test_

# Generated at 2022-06-12 18:08:19.666780
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    def assert_audio_url(expected_url, expected_audio_id, example_url):
        expected_info = {
            'id': expected_audio_id,
            'url': expected_url,
            'ext': 'm4a',
            'title': 'Piano sample',
            'description': 'Royalty Free Sample Music',
            'uploader': 'ytdl',
        }
        assert SoundgasmIE()._get_info(example_url) == expected_info


# Generated at 2022-06-12 18:08:24.523276
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE_test = SoundgasmIE()
    soundgasm = SoundgasmIE._TEST
    assert soundgasm['url'] == IE_test._TEST['url']
    assert soundgasm['md5'] == IE_test._TEST['md5']

# Generated at 2022-06-12 18:08:31.316301
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_url = 'http://soundgasm.net/u/ytdl'
    # value after calling __init__()
    ie = SoundgasmProfileIE(downloader=None)
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.IE_NAME == 'soundgasm:profile'

    # value after calling _real_extract()
    assert ie._real_extract(test_url)['id'] == 'ytdl'
    assert ie._real_extract(test_url)['playlist_count'] == 1


# Generated at 2022-06-12 18:08:39.621153
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    # Constructor of class SoundgasmIE
    ie = SoundgasmIE(url)

# Generated at 2022-06-12 18:08:41.564406
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('ytdl')
    assert ie is not None


# Generated at 2022-06-12 18:08:44.214774
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-12 18:08:47.462824
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE(InfoExtractor())
    ie.download('http://soundgasm.net/u/ytdl/Piano-sample')
    ie.download('http://soundgasm.net/u/ytdl/Piano-sample#.VjgzNzU6yM8')


# Generated at 2022-06-12 18:09:04.250702
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg = SoundgasmProfileIE()
    sg.url = 'http://soundgasm.net/u/ytdl'

    assert sg.IE_NAME == 'soundgasm:profile'
    assert sg._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert sg._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-12 18:09:06.425718
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE()

    assert str(instance) == '<SoundgasmIE>'


# Generated at 2022-06-12 18:09:11.638361
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    i = SoundgasmProfileIE()
    x = i._real_extract('http://soundgasm.net/u/ytdl')
    assert(i.IE_NAME == 'soundgasm:profile')
    assert x == i.playlist_result([i.url_result('http://soundgasm.net/u/ytdl/Piano-sample', 'Soundgasm')], 'ytdl')

# Generated at 2022-06-12 18:09:13.259979
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	test = SoundgasmProfileIE()
	test.test('http://soundgasm.net/u/ytdl')


# Generated at 2022-06-12 18:09:14.257955
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-12 18:09:16.282624
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_object = SoundgasmIE()
    assert test_object.IE_NAME == 'Soundgasm'
    assert test_object.IE_DESC == 'Soundgasm'


# Generated at 2022-06-12 18:09:17.337701
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert isinstance(SoundgasmIE(), InfoExtractor)

# Generated at 2022-06-12 18:09:20.825576
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie_obj = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie_obj._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:09:26.935943
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    #test initialisation

    soundgasm = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    assert soundgasm._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$"

# Generated at 2022-06-12 18:09:33.036695
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sample_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    sample_result = SoundgasmIE().extract(sample_url)
    assert sample_result
    assert sample_result['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert sample_result['title'] == 'Piano sample'


# Generated at 2022-06-12 18:09:59.954203
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.name == 'soundgasm:profile'
    assert ie.url == 'http://soundgasm.net/u/ytdl'
    assert ie.pattern == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.ie_key() == 'soundgasm:profile'
    assert ie.video_id == 'ytdl'
    assert ie.suitable('http://soundgasm.net/u/ytdl') == True
    assert ie.suitable('http://soundgasm.net/u/ytdl/Piano-sample') == False

# Generated at 2022-06-12 18:10:01.852962
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .construct_test import test_construct_class
    test_construct_class(SoundgasmProfileIE, AudioIE, 'SoundgasmProfileIE')

# Generated at 2022-06-12 18:10:14.604200
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    regex = re.compile(r'^https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')
    assert SoundgasmIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert regex.match(url) == SoundgasmIE._VALID_URL
    assert SoundgasmIE._TEST['url'] == url

# Generated at 2022-06-12 18:10:17.696627
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(SoundgasmIE(), {'id': 'foo'})
    assert ie.name == 'Soundgasm'
    assert ie.playlist_id == 'foo'

# Generated at 2022-06-12 18:10:21.889175
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	IE_NAME = 'soundgasm:profile'
	_VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
	print("DONE")


# Generated at 2022-06-12 18:10:25.472444
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert ("String containing class name", str(SoundgasmProfileIE)) == (
        "String containing class name", "<class '__main__.SoundgasmProfileIE'>")

# Generated at 2022-06-12 18:10:29.015986
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assertSoundgasmIETest(ie, 'http://soundgasm.net/u/ytdl/Piano-sample')
    assertSoundgasmIETest(ie, 'http://www.soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-12 18:10:30.464107
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():  # pylint: disable=unused-function
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl")

# Generated at 2022-06-12 18:10:32.120390
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
   soundgasm_IE = SoundgasmIE(InfoExtractor)

# Generated at 2022-06-12 18:10:34.412430
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE(InfoExtractor).ie_key() == 'Soundgasm'


# Generated at 2022-06-12 18:11:21.244469
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    testUrl = "http://soundgasm.net/u/ytdl/Piano-sample"
    testObj = SoundgasmIE()
    testObj.suite()
    testObj.test_SoundgasmIE(testUrl)


# Generated at 2022-06-12 18:11:22.120369
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('plop')

# Generated at 2022-06-12 18:11:28.284427
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE('SoundgasmProfileIE', 'http://soundgasm.net/u/ytdl', 'Soundgasm')
    assert 'Soundgasm' == instance._NAME
    assert 'http://soundgasm.net/u/ytdl' == instance._VALID_URL

# Generated at 2022-06-12 18:11:29.905425
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE().IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-12 18:11:32.208453
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.match('http://soundgasm.net/u/ytdl/')

# Generated at 2022-06-12 18:11:33.574253
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE(test_SoundgasmProfileIE)

# Generated at 2022-06-12 18:11:42.108053
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    newClass = SoundgasmProfileIE()
    assert newClass.IE_NAME == 'soundgasm:profile'
    assert newClass._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert len(newClass._TEST) == 3
    assert newClass._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert len(newClass._TEST['info_dict']) == 1
    assert newClass._TEST['info_dict']['id'] == 'ytdl'
    assert newClass._TEST['playlist_count'] == 1
    assert len(newClass._EXTENSIONS) == 0

# Generated at 2022-06-12 18:11:43.490922
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE('SoundgasmIE')

# Generated at 2022-06-12 18:11:52.725855
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test theory:
    #   In theory, this test unit is not needed since the website doesn't
    #   change much and the SoundgasmIE is a small class.  But in practice,
    #   it's better to keep this test unit in case the website changes and
    #   (1) cause the SoundgasmIE class to do unexpected things; or
    #   (2) cause this test unit to fail.
    #   Therefore, this test unit is needed in practice to ensure the
    #   reliability of downloader.py
    #
    # Description:
    #   Ensure SoundgasmIE constructor works fine when used in downloader.py
    info_extractor = SoundgasmIE(None)
    # Ensure type of the returned object is <type 'instance'>
    assert isinstance(info_extractor, InfoExtractor)

# Generated at 2022-06-12 18:11:57.725749
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()

    # Unit test for constructor of class SoundgasmProfileIE
    def test_SoundgasmProfileIE():
        ie = SoundgasmProfileIE()

    # Unit test for constructor of class SoundgasmProfileIE
    def test_SoundgasmProfileIE():
        ie = SoundgasmProfileIE()

    # Unit test for constructor of class SoundgasmProfileIE
    def test_SoundgasmProfileIE():
        ie = SoundgasmProfileIE()

    # Unit test for constructor of class SoundgasmProfileIE
    def test_SoundgasmProfileIE():
        ie = SoundgasmProfileIE()

# Generated at 2022-06-12 18:13:35.769511
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # an instance of class SoundgasmProfileIE
    inst = SoundgasmProfileIE('test')
    # test __init__()
    assert(inst.IE_NAME == 'soundgasm:profile')
    # test the test_url for __init__()
    assert(inst._TEST['url'] == 'http://soundgasm.net/u/ytdl')
    # test the playlist_count for __init__()
    assert(inst._TEST['playlist_count'] == 1)
    # test the test_info_dict for __init__()
    assert(inst._TEST['info_dict']['id'] == 'ytdl')




# Generated at 2022-06-12 18:13:41.524047
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from urlparse import urlparse
    url = 'http://soundgasm.net/u/ytdl' # includes '#' in url
    dir, ie = urlparse(url)[1].split('.')[0], SoundgasmProfileIE
    instance = ie(dir, ie._build_url_result(url))
    print(instance)
    if (instance.suitable(url) and instance.IE_NAME == ie._VALID_URL):
        print('%s is suitable' % ie.IE_NAME)
    else:
        print('%s is not suitable' % ie.IE_NAME)
#test_SoundgasmProfileIE()

# Generated at 2022-06-12 18:13:45.023494
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Set duration to 1 second to speed up test
    SoundgasmIE._TEST['info_dict']['duration'] = 1
    SoundgasmProfileIE('test', 'test')

# Generated at 2022-06-12 18:13:48.491819
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test = SoundgasmProfileIE(None)._TEST
    result = SoundgasmProfileIE(None)._real_extract(test['url'])
    entries = list(result['entries'])
    assert len(entries) == test['playlist_count']
    assert entries[0]['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-12 18:13:50.451258
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    assert obj.IE_NAME == 'soundgasm'

if __name__ == '__main__':
    test_SoundgasmIE()

# Generated at 2022-06-12 18:13:58.249911
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        sg = SoundgasmIE()
    except (ValueError, NameError):
        raise AssertionError('Can\'t create SoundgasmIE instance')
    else:
        if sg._VALID_URL != r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)':
            raise AssertionError('Incorrect SoundgasmIE _VALID_URL value')


# Generated at 2022-06-12 18:14:04.798288
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url='http://soundgasm.net/u/ytdl'
    obj_SoundgasmProfileIE=SoundgasmProfileIE()
    assert obj_SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert obj_SoundgasmProfileIE.VALID_URL=='%s(?P<id>[^/]+)/?(?:\\#.*)?$' % obj_SoundgasmProfileIE.ie_key()
    assert obj_SoundgasmProfileIE._VALID_URL == '%s(?P<id>[^/]+)/?(?:\\#.*)?$' % obj_SoundgasmProfileIE.ie_key()
    assert obj_SoundgasmProfileIE.ie_key()=='SoundgasmProfile'

# Generated at 2022-06-12 18:14:07.283844
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	#url = "http://soundgasm.net/u/ytdl/Piano-sample"
	#SoundgasmIE(url)
	pass

# Generated at 2022-06-12 18:14:08.520960
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == b'soundgasm'

# Generated at 2022-06-12 18:14:09.359312
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()