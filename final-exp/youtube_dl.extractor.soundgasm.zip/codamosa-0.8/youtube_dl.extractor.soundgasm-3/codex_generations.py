

# Generated at 2022-06-12 18:07:00.015515
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_ie = SoundgasmIE()
    try:
        test_ie.url_result(test_ie.test_suite[0]['url'], 'Soundgasm')
        print('Successfully constructed')
    except:
        print('Failed to construct')


# Generated at 2022-06-12 18:07:08.430235
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from . import IETestCase

    # test for URL is valid
    def test_valid_url(url):
        mobj = re.match(SoundgasmIE._VALID_URL, url)
        return mobj.group('display_id')

    valid_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    IETestCase.check_assert(test_valid_url(valid_url), "Piano-sample", "class SoundgasmIE invalid url")


# Generated at 2022-06-12 18:07:16.881781
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    profile_id = "ytdl"

    # Constructor of class InfoExtractor
    #   test_class : Class to instantiate, instance of info_extractor.InfoExtractor
    #       Argument is a class SoundgasmIE
    #   ie_id : An ID for the InfoExtractor, defaults to the class name
    ie = InfoExtractor(SoundgasmProfileIE, 'soundgasm:profile')
    info = ie.extract(url="http://soundgasm.net/u/" + profile_id)

    assert profile_id == info['id']
    assert info['title'] == profile_id

# Generated at 2022-06-12 18:07:21.637480
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.IE_DESC == 'Soundgasm profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.ie_key() == 'SoundgasmProfileIE'

# Generated at 2022-06-12 18:07:24.176072
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # test one
    sg = SoundgasmIE()
    assert sg.IE_NAME == 'soundgasm'


# Generated at 2022-06-12 18:07:26.703284
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .common import list_categories, list_ies
    assert 'Soundgasm' in list_categories()
    assert 'Soundgasm' in list_ies()

# Generated at 2022-06-12 18:07:35.935361
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE()
    b = InfoExtractor()

    # Check that class SoundgasmProfileIE and class InfoExtractor
    # have exactly the same methods (with the same names)
    assert(set(dir(a)) == set(dir(b)))

    # Check that class SoundgasmProfileIE and class InfoExtractor
    # have exactly the same class attributes (with the same
    # names)
    for attr in a.__dict__:
        # Ignore the '_downloader' attribute and the attributes that
        # are not strings
        if attr == '_downloader' or not isinstance(a.__dict__[attr], str):
            continue

        # Check that 'a' and 'b' have the same attribute values
        assert(a.__dict__[attr] == b.__dict__[attr])


# Generated at 2022-06-12 18:07:47.466847
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.VALID_URL is not None
    assert ie._TEST is None
    assert ie._TESTS is None
    assert ie._TEMPLATE is None
    assert ie._TESTS is None
    assert ie._BASE_URL is None
    assert ie._GEO_COUNTRIES is None
    assert ie._GEO_BYPASS is None
    assert ie._GEO_BYPASS_IP is None
    assert ie._GEO_BYPASS_COUNTRY is None
    assert ie._downloader is None
    assert ie._download_webpage is not None
    assert ie._html_search_regex is not None
    assert ie._ordered_dict is not None
    assert ie._sleep is not None

# Generated at 2022-06-12 18:07:53.047698
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info = SoundgasmIE()
    print("\nTesting the following soundgasm.net URL...")
    example_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    print(example_url)
    print("\nExpected result:")
    print('{')
    print('	"id": "88abd86ea000cafe98f96321b23cc1206cbcbcc9",')
    print('	"ext": "m4a",')
    print('	"title": "Piano sample",')
    print('	"description": "Royalty Free Sample Music",')
    print('	"uploader": "ytdl"')
    print('}')
    print("\nActual result:")
    print(info.ie_key())

# Generated at 2022-06-12 18:07:58.304492
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Simple test that checks the constructor of the SoundgasmIE class
    """
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    return ie.IE_NAME

if __name__ == '__main__':
    test_SoundgasmIE()

# Generated at 2022-06-12 18:08:10.280803
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://example.com/')._match_id('https://soundgasm.net/u/ytdl/') == 'ytdl'
    #assert SoundgasmProfileIE('http://example.com/')._match_id('https://soundgasm.net/u/ytdl/') == 'ytdl'

# Generated at 2022-06-12 18:08:11.319971
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-12 18:08:15.357937
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    SoundgasmProfileIE._match_id(url)
    if not SoundgasmProfileIE._match_id(url):
        raise Exception("Unit test for SoundgasmProfileIE failed")
    print("Unit test for SoundgasmProfileIE passed!")


# Generated at 2022-06-12 18:08:25.723146
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._TEST_expected_id == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert ie._TEST_expected_ext == 'm4a'
    assert ie._TEST_expected_title == 'Piano sample'
    assert ie._TEST_expected_description == 'Royalty Free Sample Music'
    assert ie._TEST_expected_uploader == 'ytdl'
    assert ie._TEST_expected_format == 'm4a'


# Generated at 2022-06-12 18:08:27.620613
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('Soundgasm')._download_webpage('url', 'display_id', 'note')

# Generated at 2022-06-12 18:08:40.438220
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # For test case, see file test_html
    html_path_for_test = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_html')
    f = open(html_path_for_test, 'r')
    test_html = f.read()
    f.close()
    info_dict = {}
    upload_date = '2016-09-10 00:00:00'
    webpage = test_html
    url = 'http://soundgasm.net/u/ytdl'

    IE = SoundgasmProfileIE()
    assert IE.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-12 18:08:49.680895
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = SoundgasmProfileIE._TEST['url']
    soundgasm_profile_ie = SoundgasmProfileIE()
    assert soundgasm_profile_ie.IE_NAME == 'Soundgasm'
    assert soundgasm_profile_ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert soundgasm_profile_ie._TEST == {'url': url, 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}
#
#	# Unit test for _real_extract method of class SoundgasmProfileIE

# Generated at 2022-06-12 18:08:55.446841
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mobj = re.match(SoundgasmIE._VALID_URL, url)
    SoundgasmIE(
        'http://soundgasm.net/u/ytdl/Piano-sample',
        mobj.group('user'),
        mobj.group('display_id'))

# Generated at 2022-06-12 18:08:56.072655
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-12 18:09:04.489105
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest
    class TestSoundgasmProfileIE(unittest.TestCase):
        def test_constructor(self):
            test_cases = [
                {
                    'input_url': 'http://soundgasm.net/u/ytdl/',
                    'expected_profile_id': 'ytdl'
                },
                {
                    'input_url': 'http://soundgasm.net/u/ytdl',
                    'expected_profile_id': 'ytdl'
                }
            ]
            for test_case in test_cases:
                self.assertEqual(SoundgasmProfileIE(test_case['input_url'])._match_id(test_case['input_url']), test_case['expected_profile_id'])
    unittest.main()

# Generated at 2022-06-12 18:09:27.072652
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url_short_pattern = '\w+'
    url = 'http://soundgasm.net/u/ytdl/'
    soundgasmIE = SoundgasmIE(url)
    assert re.match(url_short_pattern, soundgasmIE.display_id)

# Generated at 2022-06-12 18:09:30.423531
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    SoundgasmProfileIE(None).suitable(url) and \
    SoundgasmProfileIE(None).extract(url)


# Generated at 2022-06-12 18:09:41.056275
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Default input
    argv = []
    argc = len(argv)
    if (argc != 0):
        print('Usage: python3 test_SoundgasmProfileIE.py')
        return
    # Test data
    url = 'http://soundgasm.net/u/ytdl'
    IE_NAME = 'soundgasm:profile'
    # Constructor
    ieg = SoundgasmProfileIE()
    # Check
    assert(ieg._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')

# Generated at 2022-06-12 18:09:47.437108
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Set up objects required to construct SoundgasmIE object
    assert SoundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:09:48.116171
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-12 18:09:53.343447
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = SoundgasmIE._VALID_URL
    mobj = re.match(url, "http://soundgasm.net/u/ytdl/Piano-sample")
    assert mobj is not None
    assert mobj.group('user') == "ytdl"
    assert mobj.group('display_id') == "Piano-sample"

# Generated at 2022-06-12 18:09:56.641447
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie_unit_test_SoundgasmProfileIE = SoundgasmProfileIE('SoundgasmProfileIE')
    print(ie_unit_test_SoundgasmProfileIE)
    assert True


# Generated at 2022-06-12 18:09:59.774842
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	test_url = "http://soundgasm.net/u/ytdl/Piano-sample"
	test_extractor = SoundgasmIE().suitable(test_url)
	assert test_extractor

# Generated at 2022-06-12 18:10:02.500985
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.ie_key() == 'Soundgasm'
    assert ie.ie_name() == 'Soundgasm'


# Generated at 2022-06-12 18:10:14.896486
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # https://www.youtube.com/watch?v=2Td8mv1nzgM&t=0m30s
    info_extractor = IE_NAME = 'soundgasm:profile'
    url = 'http://soundgasm.net/u/ytdl'
    title = 'Soundgasm'
    description = 'Royalty Free Sample Music'
    video_id = '2Td8mv1nzgM'
    video_url = 'https://www.youtube.com/watch?v=2Td8mv1nzgM'
    thumbnail = 'https://i.ytimg.com/vi/2Td8mv1nzgM/hqdefault.jpg'
    uploader = 'ytdl'
    profile_id = 'ytdl'
    assert SoundgasmProfileIE._

# Generated at 2022-06-12 18:10:34.728014
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .test_soundcloud import test_SoundcloudIE
    test_SoundcloudIE()

# Generated at 2022-06-12 18:10:41.956929
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Unit test for argument url
    # Argument url is in the valid format -> get the media of this url
    IE = SoundgasmIE(url='http://soundgasm.net/u/ytdl/Piano-sample')
    media = IE.get_media()
    assert media.get('id') == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert media.get('display_id') == 'Piano-sample'
    assert media.get('ext') == 'm4a'
    assert media.get('title') == 'Piano sample'
    assert media.get('description') == 'Royalty Free Sample Music'
    assert media.get('uploader') == 'ytdl'

    # Argument url is in the invalid format -> raise exception

# Generated at 2022-06-12 18:10:49.135246
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    s = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert s._match_id == 'Piano-sample'
    assert s._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:10:53.978664
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profileIE = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    assert soundgasm_profileIE.url == "http://soundgasm.net/u/ytdl"
    assert soundgasm_profileIE.ie_key == "SoundgasmIE"
    assert soundgasm_profileIE.ie_key == "SoundgasmIE"


# Generated at 2022-06-12 18:10:55.003479
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    assert soundgasm

# Generated at 2022-06-12 18:11:03.091919
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'playlist_count': 1, 'info_dict': {'id': 'ytdl'}}

# Generated at 2022-06-12 18:11:04.504595
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_ie = SoundgasmProfileIE('soundgasm', 'http://example.com')
    assert profile_ie.ie_key() == 'Soundgasm'

# Generated at 2022-06-12 18:11:08.410639
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    audio_id = 'Piano-sample'
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert (SoundgasmIE.IE_NAME == 'soundgasm')

# Generated at 2022-06-12 18:11:13.828958
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie_test = SoundgasmProfileIE(InfoExtractor)

    assert ie_test._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie_test._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert ie_test._TEST['info_dict']['id'] == 'ytdl'

# Generated at 2022-06-12 18:11:24.157876
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .common import InfoExtractor
    from .common import InfoExtractorTest
  #  from .common import mock

    # First, create a mock for the InfoExtractor._download_webpage
    # method.
    # The name "patcher" must be used.
    patcher = mock.patch('ytdl.InfoExtractor._download_webpage')
    # "patcher" is a "Mock" object
    # Start to patch the _download_webpage method
    _download_webpage_mock = patcher.start()
    # Configure the mock object
    _download_webpage_mock.return_value = 'WEBPAGE'
    # Create the Mock object for parse_html_form()
    patcher2 = mock.patch('ytdl.InfoExtractor.parse_html_form')
    parse_

# Generated at 2022-06-12 18:11:59.362435
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-12 18:12:02.938190
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE.suitable("https://soundgasm.net/u/ytdl/Piano-sample")
# end of test_SoundgasmIE()

# Generated at 2022-06-12 18:12:04.977993
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert ('ytdl' == SoundgasmProfileIE._TEST['info_dict']['id'])


# Generated at 2022-06-12 18:12:08.740155
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE("test", "test")._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$"

# Generated at 2022-06-12 18:12:14.312463
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    i = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert i.IE_NAME == 'soundgasm'
    assert i._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'



# Generated at 2022-06-12 18:12:17.751090
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = "http://soundgasm.net/u/ytdl"
    ie = SoundgasmProfileIE(url)
    assert ie.IE_NAME in str(ie)

# Generated at 2022-06-12 18:12:20.071453
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')


# Generated at 2022-06-12 18:12:22.118519
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    t = SoundgasmIE()
    assert t.IE_NAME == 'soundgasm'


# Generated at 2022-06-12 18:12:30.925771
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    info_dict = {'uploader': 'ytdl',
                 'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
                 'title': 'Piano sample',
                 'description': 'Royalty Free Sample Music',
                 'display_id': 'Piano-sample',
                 'url': 'http://soundgasm.net/u/ytdl/piano-sample/Piano-sample.m4a',
                 'ext': 'm4a',
                 'vcodec': 'none'}
    soundgasm = SoundgasmIE({})
    assert(soundgasm.IE_NAME == 'soundgasm')

# Generated at 2022-06-12 18:12:32.338299
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # TODO: see 'todo' note in __init__.py
    pass

# Generated at 2022-06-12 18:14:06.015176
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE()
    assert profile._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert profile.IE_NAME == 'soundgasm:profile'
    assert profile._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}



# Generated at 2022-06-12 18:14:08.864363
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
   ies = SoundgasmIE(None)
   ies.IE_NAME
   ies.VALID_URL
   ies.TEST


# Generated at 2022-06-12 18:14:10.590613
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-12 18:14:18.286863
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import soundgasm

    ydl = YoutubeDL()
    assert isinstance(ydl.find_info_extractor(u'https://soundgasm.net/u/ytdl/Piano-sample'), soundgasm.SoundgasmIE)
    assert isinstance(ydl.find_info_extractor(u'https://soundgasm.net/u/ytdl'), soundgasm.SoundgasmProfileIE)

# Generated at 2022-06-12 18:14:19.405030
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert isinstance(SoundgasmProfileIE(), InfoExtractor)


# Generated at 2022-06-12 18:14:26.905248
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import ExtractorError
    IE = SoundgasmProfileIE()
    assert 'http://soundgasm.net/u/ytdl' == IE.url_result('http://soundgasm.net/u/ytdl')
    assert 'http://soundgasm.net/u/ytdl' == IE.url_result('http://soundgasm.net/u/ytdl/')
    assert 'http://soundgasm.net/u/ytdl' == IE.url_result('http://soundgasm.net/u/ytdl/#some-hash')
    assert 'http://soundgasm.net/u/ytdl' == IE.url_result('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:14:27.796643
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Constructor test
    assert SoundgasmIE()

# Generated at 2022-06-12 18:14:37.344808
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    user = 'ytdl'
    display_id = 'Piano-sample'
    inst = SoundgasmIE()
    assert(inst.IE_NAME == 'Soundgasm')
    assert(inst.IE_DESC == 'Soundgasm')
    assert(inst._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')
    assert(inst._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:14:38.238638
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    return SoundgasmProfileIE(None)._download_webpage('http://soundgasm.net/u/123', u'test')

# Generated at 2022-06-12 18:14:49.597824
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    tester = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert tester._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'