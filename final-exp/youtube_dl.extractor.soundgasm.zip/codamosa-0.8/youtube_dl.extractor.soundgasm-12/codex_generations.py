

# Generated at 2022-06-12 18:06:57.348676
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")


# Generated at 2022-06-12 18:06:59.581788
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Is this actually test of anything?
    try:
        SoundgasmIE()
        return True
    except:
        return False

# Generated at 2022-06-12 18:07:05.799078
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Simple test to ensure constructor of class SoundgasmProfileIE
    returns a object of type SoundgasmProfileIE.
    """
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-12 18:07:06.768396
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print(SoundgasmProfileIE())

# Generated at 2022-06-12 18:07:09.902037
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    x = SoundgasmIE()
    x.extract(url)

# Generated at 2022-06-12 18:07:16.337556
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    a = {
    'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
    'ext': 'm4a',
    'title': 'Piano sample',
    'description': 'Royalty Free Sample Music',
    'uploader': 'ytdl',
    }

    b = SoundgasmIE()

    assert b.suitable(a['id']) == False


# Generated at 2022-06-12 18:07:20.053484
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    ie._VALID_URL = 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    ie.IE_NAME = 'soundgasm:profile'
    ie.extract_info_entry = lambda x: {}
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:07:30.220164
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    s = SoundgasmIE()
    assert s._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)"
    assert s._TEST['url'] == test_url
    assert s._TEST['info_dict']['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert s._TEST['info_dict']['ext'] == 'm4a'
    assert s._TEST['info_dict']['title'] == 'Piano sample'


# Generated at 2022-06-12 18:07:32.739063
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    assert obj._VALID_URL is not None
    assert obj._TEST['url'] is not None
    assert obj._TEST['md5'] is not None
    assert obj._TEST['info_dict'] is not None

# Generated at 2022-06-12 18:07:33.449697
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-12 18:07:43.956906
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._match_id('http://soundgasm.net/u/ytdl', '') == 'ytdl'

# Generated at 2022-06-12 18:07:49.468912
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    u = "http://soundgasm.net/u/ytdl/Piano-sample"
    obj = SoundgasmIE(u)
    assert obj._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:07:52.671042
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE._VALID_URL)
    assert(SoundgasmProfileIE._TEST)
    assert(not SoundgasmProfileIE._TEST.get('playlist'))
    assert(all(re.match(SoundgasmProfileIE._VALID_URL, i) for i in SoundgasmProfileIE._TEST.get('input_urls', [])))


# Generated at 2022-06-12 18:07:55.623901
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE()._real_extract(url)

# Generated at 2022-06-12 18:07:58.447078
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ydl = SoundgasmIE()
    from youtube_dl.YoutubeDL import YoutubeDL

    assert(isinstance(ydl, YoutubeDL))

# Generated at 2022-06-12 18:08:03.945691
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'https://www.soundgasm.net/u/ytdl/'
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'SoundgasmProfileIE'
    assert ie.IE_DESC == 'Soundgasm.net'
    assert ie.valid_url_regex.match(url).groupdict() == {'id': 'ytdl'}
    assert isinstance(ie._VALID_URL, str)
    assert ie.IE_NAME in ie.GENERIC_IE_NAME

# Generated at 2022-06-12 18:08:10.241819
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE._download_webpage = lambda x, y: '<a href="http://soundgasm.net/u/ytdl/Piano-sample"></a>'
    SoundgasmProfileIE.url_result = lambda x, y, z: y
    SoundgasmProfileIE.playlist_result = lambda x, y, z: {'playlist_count': len(y)}
    assert test_SoundgasmProfileIE()['playlist_count'] == 1

# Generated at 2022-06-12 18:08:11.667915
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == 'soundgasm'


# Generated at 2022-06-12 18:08:12.206012
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-12 18:08:14.950980
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_str = 'http://soundgasm.net/u/ytdl'
    test_instance = SoundgasmProfileIE()
    assert test_instance._match_id(test_str) == 'ytdl'

# Generated at 2022-06-12 18:08:32.606133
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("Constructing SoundgasmIE:");
    soundgasm_ie = SoundgasmIE();
    print("Done");


# Generated at 2022-06-12 18:08:43.864110
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """test for SoundgasmIE"""
    #test for _VALID_URL
    valid_url = SoundgasmIE()._VALID_URL
    mobj = re.match(valid_url, 'http://soundgasm.net/u/ytdl/Piano-sample')
    assert (mobj is not None), 'regexp of valid_url failed'
    assert (mobj.group('user') == 'ytdl')
    assert (mobj.group('display_id') == 'Piano-sample')

    #test for _real_extract function
    info_dict = SoundgasmIE()._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert (len(info_dict['url']) > 0), 'audio url is empty'

# Generated at 2022-06-12 18:08:44.801733
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass


# Generated at 2022-06-12 18:08:46.424006
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	soundgasm_profile_ie = SoundgasmProfileIE(_download_webpage = lambda x: '<body></body>')
	assert soundgasm_profile_ie is not None

# Generated at 2022-06-12 18:08:47.338185
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_instance = SoundgasmProfileIE()

# Generated at 2022-06-12 18:08:50.438141
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	from .common import SoundgasmProfileIE
	assert SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-12 18:08:56.128487
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	valid_url = "http://soundgasm.net/u/ytdl/Piano-sample"
	invalid_url = "http://soundgasm.net/u/ytdl/Piano-sample/11"
	assert(SoundgasmIE.suitable(valid_url))
	assert(not SoundgasmIE.suitable(invalid_url))


# Generated at 2022-06-12 18:09:00.152707
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	print("Starting test")
	print("Loading webpage")
	webpage = get_test_webpage()
	print("Webpage loaded")
	print("Picking user name")
	profile_id = pick_user_name(webpage)
	print("User name picked")
	print("Generating entries")
	entries = entries_for_user_name(profile_id, webpage)
	print("Entries generated")
	print("Generating playlist result")
	result = playlist_result_for_entries(entries, profile_id)
	print("Playlist generated")
	print("Result: {}".format(result))
	return True


# Generated at 2022-06-12 18:09:10.993083
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_Instnace = SoundgasmIE('ytdl', 'http://soundgasm.net/u/ytdl/Piano-sample')
    # Asserting display_id of IE object
    assert soundgasm_Instnace._VALID_URL=='https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    # Asserting _TEST of IE object

# Generated at 2022-06-12 18:09:12.015155
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    infoextract = SoundgasmIE()
    assert infoextract is not None

# Generated at 2022-06-12 18:09:32.952685
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	ie = SoundgasmProfileIE()
	assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-12 18:09:40.288190
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_case = 'http://soundgasm.net/u/ytdl/Piano-sample'
    result = SoundgasmIE()._real_extract(test_case)
    assert result['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert result['ext'] == 'm4a'
    assert result['title'] == 'Piano sample'
    assert result['uploader'] == 'ytdl'
    assert result['description'] == 'Royalty Free Sample Music'


# Generated at 2022-06-12 18:09:41.870593
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("www.soundgasm.net/u/ytdl/Piano-sample")


# Generated at 2022-06-12 18:09:46.855762
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
		u=SoundgasmProfileIE('https://www.soundgasm.net/u/ytdl')
		assert u._VALID_URL==r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
		assert u._TEST['url']=='http://soundgasm.net/u/ytdl'
		assert u._TEST['info_dict']['id']=='ytdl'
		assert u._TEST['playlist_count']==1


# Generated at 2022-06-12 18:09:50.017215
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE()
    assert soundgasm_profile_ie is not None



# Generated at 2022-06-12 18:09:52.043129
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  SoundgasmProfileIE(None, None)

# Unit test SoundgasmProfileIE._real_extract 

# Generated at 2022-06-12 18:09:54.188836
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    my_ie = SoundgasmIE()
    assert my_ie.IE_NAME == 'soundgasm'


# Generated at 2022-06-12 18:09:57.455182
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Test case for SoundgasmIE"""
    soundgasm_ie = SoundgasmIE()
    print(soundgasm_ie.IE_NAME)
    print(soundgasm_ie.params)

# Generated at 2022-06-12 18:10:05.099294
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie_obj = SoundgasmIE()
    assert ie_obj.IE_NAME == 'soundgasm'
    assert ie_obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie_obj._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie_obj._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-12 18:10:08.248658
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	url = 'http://soundgasm.net/u/ytdl'

	ie = SoundgasmProfileIE()
	ie._real_extract(url)

# Generated at 2022-06-12 18:10:47.375722
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE('My User Agent')
    # No need to test further, if constructor fails then the rest of the code
    # will not be executed and unit tests will fail
    assert True

# Generated at 2022-06-12 18:10:52.011301
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:10:53.977779
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SIE = SoundgasmProfileIE()
    assert(SIE.ie_key() == 'Soundgasm')


# Generated at 2022-06-12 18:10:56.289564
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test for valid url
    # Test for invalid url
    try:
        SoundgasmIE(url="http://www.soundgasm.net/u/ytdl/Piano-sample-0")
    except AssertionError:
        return

    raise AssertionError

# Generated at 2022-06-12 18:11:00.595251
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie=SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:11:03.389650
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # initialize
    instance = SoundgasmProfileIE()
    # check
    assert isinstance(instance, InfoExtractor)


# Generated at 2022-06-12 18:11:07.138528
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    expected_vars = {'ie_key': 'Soundgasm', 'display_id': 'Piano-sample'}
    assert ie.suitable('http://soundgasm.net/u/ytdl/Piano-sample') == expected_vars


# Generated at 2022-06-12 18:11:08.019572
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE = SoundgasmIE()

# Generated at 2022-06-12 18:11:08.978463
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-12 18:11:09.723130
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-12 18:12:24.375555
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class ConstructorTest(object):
        def __init__(self, soundgasmIE=SoundgasmIE):
            self.soundgasmIE = soundgasmIE

        def _print_field(self, field_name):
            print(getattr(self.soundgasmIE, field_name))

        def test(self):
            self._print_field('_VALID_URL')
            self._print_field('IE_NAME')
            self._print_field('_TEST')

    ConstructorTest().test()

if __name__ == '__main__':
    test_SoundgasmIE()

# Generated at 2022-06-12 18:12:26.077791
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE().IE_NAME == 'soundgasm:profile'
    assert SoundgasmProfileIE()._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:12:30.033000
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # It would be better if there were a URL for this test,
    # but the site seems to have no way to save recordings.
    ie = SoundgasmProfileIE()
    expected = ie.IE_NAME
    actual = SoundgasmProfileIE._NAME
    assert actual == expected


# Generated at 2022-06-12 18:12:34.274279
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'

    class C(SoundgasmProfileIE):
        def __init__(self):
            SoundgasmProfileIE.__init__(self)
            self.url = url

    c = C()
    c.extract()
    assert c.profile_id == 'ytdl'

# Generated at 2022-06-12 18:12:37.042564
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    #  Here is a sample link http://soundgasm.net/u/ytdl/Piano-sample
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:12:39.381625
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert 'ytdl' == SoundgasmProfileIE()._match_id('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-12 18:12:41.501979
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    i = SoundgasmIE()
    a = i._real_extract(i._TEST['url'])
    assert(a == i._TEST['info_dict'])


# Generated at 2022-06-12 18:12:47.742555
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('https://soundgasm.net/u/sgrho')
    assert ie.IE_NAME == 'SoundgasmProfileIE'
    assert ie.test_name() == 'SoundgasmProfileIE'
    assert ie.extractor_key() == 'SoundgasmProfileIE'
    assert ie.extractor_name() == 'SoundgasmProfileIE'
    assert ie.IE_DESC == 'Soundgasm Profiles'
    assert 'Soundgasm Profiles' in ie.__str__()

# Generated at 2022-06-12 18:12:49.264363
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL == SoundgasmProfileIE._VALID_URL


# Generated at 2022-06-12 18:12:56.125970
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # You would need to provide your input here.
    test_url1 = 'https://soundgasm.net/u/ytdl/Piano-sample'
    test_url2 = 'https://soundgasm.net/u/ytdl'
    test_url3 = 'https://soundgasm.net/u/ytdl#'

    # Initialize an instance of class SoundgasmIE.
    sg_extractor1 = SoundgasmIE()
    sg_extractor2 = SoundgasmIE()
    sg_extractor3 = SoundgasmIE()

    # Extract info from test_url1.
    res1 = sg_extractor1.extract(test_url1)

    # Extract info from test_url2.

# Generated at 2022-06-12 18:16:07.182033
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample', 'soundgasm')

# Generated at 2022-06-12 18:16:10.325706
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE(SoundgasmIE.IE_NAME, {})
    assert ie.ie_key() == 'Soundgasm'
    assert ie.ie_name() == 'Soundgasm'
    assert ie.suitable("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-12 18:16:10.833233
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert True

# Generated at 2022-06-12 18:16:15.508942
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    mod_profile_IE = SoundgasmProfileIE()
    mod_profile_IE.IE_NAME = 'soundgasm:profile'
    mod_profile_IE._VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

    profile_IE = SoundgasmProfileIE()

    assert mod_profile_IE._VALID_URL == profile_IE._VALID_URL


# Generated at 2022-06-12 18:16:15.943246
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-12 18:16:17.225158
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print('Running test for constructor of class SoundgasmIE.')
    SoundgasmIE(None, None)


# Generated at 2022-06-12 18:16:19.623279
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:16:24.523208
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("Tests for class SoundgasmIE")
    # SoundgasmIE.__init__
    print("Test for constructor")
    sgIE = SoundgasmIE('soundgasm');

    # SoundgasmIE._real_extract
    print("Test for _real_extract")
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    sgIE._real_extract(url)

# Generated at 2022-06-12 18:16:32.921650
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test with a valid url
    s = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert s.IE_NAME == 'Soundgasm'
    assert s._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert s._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert s._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-12 18:16:33.929695
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()
