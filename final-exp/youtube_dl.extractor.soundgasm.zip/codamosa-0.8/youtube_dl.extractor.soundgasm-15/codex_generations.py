

# Generated at 2022-06-12 18:07:00.809160
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("Testing SoundgasmIE")
    try:
        SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    except:
        print("Error in SoundgasmIE")
        raise
    
if __name__ == "__main__":
    test_SoundgasmIE()

# Generated at 2022-06-12 18:07:11.505694
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# this is an example of a model
    filename = "../test.wav"
    duration = 30
    sr = 16000
    audio_clip,sr = librosa.load(filename, sr)
    audio_clip = librosa.resample(audio_clip, sr, 22050)
    # downmix audio clip to mono
    audio_clip = audio_clip.mean(axis=1)
    # pad audio clip with zeros
    pad_length = 22050 * (duration - len(audio_clip) // 22050)
    audio_clip = np.pad(audio_clip, (0, int(pad_length)), 'constant')
    assert audio_clip.shape[0] == 22050 * duration, "Audio clip does not have the right length"
    return audio_clip
    # Test run, this should not change anything
   

# Generated at 2022-06-12 18:07:13.037221
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("SoundgasmIE","http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-12 18:07:14.488877
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    # test SoundgasmProfileIE constructor
    SoundgasmProfileIE(url)

# Generated at 2022-06-12 18:07:16.427904
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_object = SoundgasmIE()
    # assertEqual() method compares two objects for equality and
    # raises an AssertionError if they are not equal
    assertEqual(test_object.IE_NAME, 'Soundgasm')


# Generated at 2022-06-12 18:07:22.049978
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    
    p = SoundgasmProfileIE()
    assert p.IE_NAME == 'soundgasm:profile'
    assert p._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert p._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-12 18:07:31.322580
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from youtube_dl.options import opts
    
    opts.proxy = False
    opts.no_check_certificate = True
    opts.default_search='auto'
    opts.quiet = True

    # Assume that url is a valid url
    url = 'http://soundgasm.net/u/ytdl'

    # Assume that profile_id is the expected profile_id
    profile_id = 'ytdl'

    # This constructor shall create an instance of class SoundgasmProfileIE
    soundgasm_profile_ie = SoundgasmProfileIE(SoundgasmIE._downloader, url, {})

    # Assert that the profile_id returned is the same as the expected
    assert profile_id == soundgasm_profile_ie._match_id(url)


# Generated at 2022-06-12 18:07:34.203113
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL == SoundgasmProfileIE._VALID_URL
    assert SoundgasmProfileIE()._TEST == SoundgasmProfileIE._TEST

# Generated at 2022-06-12 18:07:45.761797
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    i = SoundgasmIE()
    assert i._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert i.IE_NAME == 'soundgasm'
    assert i._download_webpage == InfoExtractor._download_webpage
    assert i._html_search_regex == InfoExtractor._html_search_regex
    assert i._search_regex == InfoExtractor._search_regex
    assert i._real_extract == SoundgasmIE._real_extract

# Generated at 2022-06-12 18:07:48.238542
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # We check if the class was able to be instantiated
    ie = SoundgasmIE()
    # Grab the unit tests
    test = ie._TEST


# Generated at 2022-06-12 18:07:56.708163
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    inst = SoundgasmProfileIE(url)
    assert inst.valid_url(url)

# Generated at 2022-06-12 18:08:01.052635
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE({'url': 'http://soundgasm.net/u/ytdl'})
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:08:03.980075
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Run the constructor
    SoundgasmProfileIE()

# Generated at 2022-06-12 18:08:05.825367
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE(None, 'foobar')._VALID_URL == SoundgasmProfileIE._VALID_URL

# Generated at 2022-06-12 18:08:09.847220
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	import soundgasm_ie
	SoundgasmProfileIE('https://soundgasm.net/u/ytdl', soundgasm_ie.SoundgasmIE._download_webpage, soundgasm_ie.SoundgasmIE._match_id)
	return

# Generated at 2022-06-12 18:08:12.765081
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    # Unit test for constructor of class SoundgasmIE
    # It is just a non regression test
    ie = SoundgasmIE()
    assert ie._VALID_URL == SoundgasmIE._VALID_URL

# Generated at 2022-06-12 18:08:14.722912
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    player = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert player.name == 'Soundgasm'

# Generated at 2022-06-12 18:08:17.375282
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    my_SoundgasmIE = SoundgasmIE()
    print(my_SoundgasmIE)

# Generated at 2022-06-12 18:08:27.361803
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE(None)
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
        'md5': '010082a2c802c5275bb00030743e75ad',
        'info_dict': {
            'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
            'ext': 'm4a',
            'title': 'Piano sample',
            'description': 'Royalty Free Sample Music',
            'uploader': 'ytdl',
        }
    }

# Generated at 2022-06-12 18:08:29.040766
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert "ovv_b" in SoundgasmProfileIE._TESTS

# Generated at 2022-06-12 18:08:46.280041
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest


# Generated at 2022-06-12 18:08:47.846645
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample', 'ytdl')

# Generated at 2022-06-12 18:08:51.298574
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Testing Constructor
    ie = SoundgasmIE()
    # Testing IE Name
    assert ie._NAME == 'Soundgasm'

# Generated at 2022-06-12 18:08:52.421208
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ydl = SoundgasmProfileIE()

# Generated at 2022-06-12 18:08:53.412653
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    print(ie)

# Generated at 2022-06-12 18:08:56.802110
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'https://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE(title='test')
    ie._test_extract_profile_id(url)



# Generated at 2022-06-12 18:08:58.097938
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg = SoundgasmProfileIE(None)
    assert sg is not None

# Generated at 2022-06-12 18:08:59.076277
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-12 18:09:02.603514
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:09:07.551524
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('https://soundgasm.net/u/EroticAudio/')
    assert ie._match_id('https://soundgasm.net/u/EroticAudio/') == 'EroticAudio'


# Generated at 2022-06-12 18:09:26.935188
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()


# Generated at 2022-06-12 18:09:27.960370
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    constructor_test(SoundgasmProfileIE)

# Generated at 2022-06-12 18:09:30.139439
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    SoundgasmIE()._real_extract(url)

# Generated at 2022-06-12 18:09:40.898006
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Note: Use this code to test it standalone
    # Test constructor and its params
    class TestSoundgasmIE(SoundgasmIE):
        def _real_extract(self):
            # Test here if params are correctly initialized
            # Simulate SoundgasmAPI class initialization
            assert self._downloader is not None
            assert self._downloader.cookiejar is not None
            assert self._downloader.user_agent is not None
            assert not self._downloader.params.get('nooverwrites', False)
            assert self._downloader.params.get('noprogress', True)
            assert self._downloader.params.get('format', None) is None
            assert self._downloader.params.get('outtmpl', None) is None
            assert self._downloader.params.get('continuedl', False)


# Generated at 2022-06-12 18:09:44.073128
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info_extractor = SoundgasmProfileIE()
    info_extractor._match_id('https://soundgasm.net/u/john_doe')
    assert info_extractor._match_id('https://soundgasm.net/u/john_doe/#') == 'john_doe'

# Generated at 2022-06-12 18:09:56.272074
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    # Test URL
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    # Test default value of the field 'display_id'
    assert ie.display_id == 'id'
    # Test default value of the field 'ie_key'
    assert ie.ie_key == 'Soundgasm'
    # Test default value of the field '_TEST'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-12 18:09:59.486399
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test with valid url of Soundgasm.net
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE().extract(url)

    # Test with empty url
    url = ''
    SoundgasmIE().extract(url)

    # Test with invalid url
    url = 'http://soundgasm.net/'
    SoundgasmIE().extract(url)

# Generated at 2022-06-12 18:10:02.282339
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print("\n~~~~~~~Unit test for constructor of class SoundgasmProfileIE~~~~~~~\n")
    ie = SoundgasmProfileIE()
    url = ie.from_id("ytdl")
    print("Unit test passed")

# Generated at 2022-06-12 18:10:09.851170
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    loader = SoundgasmProfileIE()
    assert loader._match_id('http://soundgasm.net/u/ytdl') == 'ytdl'
    assert loader._match_id('http://soundgasm.net/u/ytdl/') == 'ytdl'
    assert loader._match_id('http://soundgasm.net/u/ytdl?a=b') == 'ytdl'

# Generated at 2022-06-12 18:10:18.061560
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE(None)
    ie.match = lambda t: True
    ie.extract(test_url)
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-12 18:11:06.953827
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:11:11.435825
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class_ = SoundgasmIE
    assert class_.IE_NAME == 'soundgasm'
    assert class_._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:11:12.352830
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-12 18:11:18.046214
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test equalities
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasm = SoundgasmIE()
    mobj = re.match(soundgasm._VALID_URL, url)
    assert(mobj, 'Input url did not match the regexp')
    # Test non-equalities
    url = 'http://soundgasm.net/u/ytdl/'
    mobj = re.match(soundgasm._VALID_URL, url)
    assert(None == mobj, 'Expected None, got a match object.')

# Generated at 2022-06-12 18:11:25.280313
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()

    mobj = re.match(soundgasm._VALID_URL, soundgasm._TEST['url'])
    assert mobj, "URL is not being parsed correctly."

    assert mobj.group('user'), "User field is empty."
    assert mobj.group('display_id'), "Display ID field is empty."

    assert soundgasm._TEST['info_dict']['uploader'] == mobj.group('user'), "User field is not being parsed correctly."
    assert soundgasm._TEST['info_dict']['title'] == mobj.group('display_id'), "Display ID field is not being parsed correctly."


# Generated at 2022-06-12 18:11:29.387708
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE('http://soundgasm.net/u/soumilnath/Piano-sample')
    assert(obj.display_id == 'Piano-sample')
    assert(obj.user == 'soumilnath')

# Generated at 2022-06-12 18:11:32.057690
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.suitable('http://soundgasm.net/u/ytdl/Piano-sample')
    

# Generated at 2022-06-12 18:11:33.064438
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-12 18:11:37.141270
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print('Testing constructor')
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    print('URL for Audio is %s' % ie._URL)
    print('Download URL is %s' % ie._DOWNLOAD_URL)

# Generated at 2022-06-12 18:11:48.189683
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    audio_url = 'https://s3.us-east-2.amazonaws.com/sound-gasm-prod/audio/d41d8cd98f00b204e9800998ecf8427e.m4a?Expires=1490791384&Signature=oWQlKjwf-aKdg1NbtwSxoVsG0o4%3D&AWSAccessKeyId=AKIAJF7KVWWROPB3V7AA'
    title = 'Piano sample'
    description = 'Royalty Free Sample Music'
    audiotype = 'Playlist'

    soundgasm_info = SoundgasmIE._real_extract(url)

    assert soundgasm_

# Generated at 2022-06-12 18:13:05.513963
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:13:17.527728
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-12 18:13:21.943877
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print("Testing construction of class SoundgasmProfileIE\n")
    assert (SoundgasmProfileIE.__doc__ is not None)

# Generated at 2022-06-12 18:13:23.835552
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        extractor = SoundgasmIE()
        return True
    except:
        return False


# Generated at 2022-06-12 18:13:24.639428
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()

# Generated at 2022-06-12 18:13:27.370192
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # should not crash when constructing SoundgasmProfileIE
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl")

# Generated at 2022-06-12 18:13:28.883936
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	ie = SoundgasmProfileIE()
	ie.extract('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-12 18:13:33.331574
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()
    assert obj.IE_NAME == 'SoundgasmProfileIE'
    assert obj.VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-12 18:13:36.756507
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Unit test for constructor of class SoundgasmProfileIE"""

    # input
    url = "https://soundgasm.net/u/ytdl"

    # instance
    soundgasm_profile_instance = SoundgasmProfileIE()

    # test
    soundgasm_profile_instance._real_extract(url)

# Generated at 2022-06-12 18:13:38.399514
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(SoundgasmProfileIE.ie_key())
    ie.extract(ie._TEST['url'])

# Generated at 2022-06-12 18:16:48.886276
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print ("Testing SoundgasmIE")
    # check the audio url is resoved correctly
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    test = SoundgasmIE()
    _, audio_url = test._real_extract(url)
    assert audio_url == "http://soundgasm.net/media/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a"
    # check the audio id is extracted correctly
    _, audio_id = test._real_extract(url)
    assert audio_id == "88abd86ea000cafe98f96321b23cc1206cbcbcc9"

# Generated at 2022-06-12 18:16:50.413670
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl")