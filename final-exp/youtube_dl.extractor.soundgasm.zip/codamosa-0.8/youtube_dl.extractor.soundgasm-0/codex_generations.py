

# Generated at 2022-06-12 18:07:01.834219
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    url = "https://soundgasm.net/u/ytdl/Piano-sample"
    display_id = 'Piano-sample'
    user = 'ytdl'
    reobj = re.compile(SoundgasmIE._VALID_URL)
    (mobj) = reobj.match(url)
    assert mobj.group('user') == user
    assert mobj.group('display_id') == display_id

# Generated at 2022-06-12 18:07:11.466421
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert SoundgasmIE._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

    SoundgasmIE._TEST['info_dict'] == {
    'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
    'ext': 'm4a',
    'title': 'Piano sample',
    'description': 'Royalty Free Sample Music',
    'uploader': 'ytdl',
    }
# Test for method _real_extract of class SoundgasmIE

# Generated at 2022-06-12 18:07:14.636963
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test constructor of class SoundgasmIE
    ie = SoundgasmIE(None)

    # Test type of IE
    assert ie.ie_key() == 'Soundgasm'

# Generated at 2022-06-12 18:07:20.222137
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	ie = SoundgasmProfileIE()
	assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
	assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}


# Generated at 2022-06-12 18:07:24.254480
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Can't load the profile correctly.
    SoundgasmProfileIE._real_extract('http://soundgasm.net/u/ytdl')

if __name__ == '__main__':
    test_SoundgasmProfileIE()

# Generated at 2022-06-12 18:07:27.127810
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = "http://soundgasm.net/u/ytdl"
    soundgasm_profile = SoundgasmProfileIE._download_webpage(url)
    print(soundgasm_profile)

# Generated at 2022-06-12 18:07:31.397311
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    #soundgasm_test = SoundgasmProfileIE("url")
    #assert "SoundgasmProfileIE" == soundgasm_test.IE_NAME
    SoundgasmProfileIE("")._real_extract("http://soundgasm.net/u/ytdl")
    SoundgasmProfileIE("")._real_extract("http://soundgasm.net/u/ytdl/")

# Generated at 2022-06-12 18:07:41.687271
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    constructor_test(
        SoundgasmIE,
        [
            # Test for valid URL
            {
                'url' : 'http://soundgasm.net/u/ytdl/Piano-sample',
                'info_dict' : {
                    'id' : '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
                    'title' : 'Piano sample',
                    'description' : 'Royalty Free Sample Music',
                    'ext' : 'm4a',
                    'uploader' : 'ytdl'
                },
                'params' : {
                    'skip_download' : True,
                }
            }
        ]
    )


# Generated at 2022-06-12 18:07:45.429821
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_ie = SoundgasmIE()
    assert soundgasm_ie._TEST["url"] == "http://soundgasm.net/u/ytdl/Piano-sample", \
           "Unit test for SoundgasmIE failed."

# Generated at 2022-06-12 18:07:48.238324
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    except:
        assert False, "test_SoundgasmIE failed"

# Generated at 2022-06-12 18:07:56.729677
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE()
    assert_true(a._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')

# Generated at 2022-06-12 18:07:59.078281
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # SoundgasmIE class
    assert SoundgasmIE.ie_key() == 'Soundgasm'

# Generated at 2022-06-12 18:08:01.287254
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sgIE = SoundgasmIE()
    print("\nTesting constructor of SoundgasmIE:")
    print("sgIE: " + str(sgIE))



# Generated at 2022-06-12 18:08:10.472615
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    user = SoundgasmProfileIE('ytdl')
    assert user.IE_NAME == 'SoundgasmProfileIE'
    assert user.VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert user.TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-12 18:08:12.466225
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # assert isinstance(SoundgasmIE, Object)
    assert(SoundgasmIE is InfoExtractor)



# Generated at 2022-06-12 18:08:17.207707
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    dl = SoundgasmProfileIE()
    soundgasm = dl._real_extract(dl._TEST['url'])
    assert soundgasm['id'] == dl._TEST['info_dict']['id']
    assert len(soundgasm['entries']) == dl._TEST['playlist_count']
    #TODO: assert soundgasm['entries'] == dl._TEST['info_dict']['entries']


# Generated at 2022-06-12 18:08:24.633338
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_id = 'ytdl'
    webpage = '<a href="/u/ytdl/Piano-sample">Piano sample</a>'
    audio_url = '/u/ytdl/Piano-sample'
    assert re.findall(r'href="([^"]+/u/%s/[^"]+)' % profile_id, webpage) == [audio_url]

# Generated at 2022-06-12 18:08:25.397584
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-12 18:08:29.676894
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# Create an instance of class SoundgasmIE
	#audio = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
	#print audio.url
	#print audio.display_id
	#print audio.title
	#print audio.description
	#print audio.uploader
	#print audio.id
	#print audio.ext
	#print audio.vcodec
	return


# Generated at 2022-06-12 18:08:31.652049
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info = SoundgasmIE()
    assert info != None


# Generated at 2022-06-12 18:08:41.910333
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    for input_url in [
        "http://soundgasm.net/u/user-name",
        "http://soundgasm.net/u/user-name/"
    ]:
        from_test = SoundgasmProfileIE._test_class_extract(input_url)
        assert from_test["id"] == "user-name"
        assert from_test.get("playlist_count") == 1

test_SoundgasmProfileIE()

# Generated at 2022-06-12 18:08:48.968945
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE(): # NOQA
    ie = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    assert ie.IE_NAME == "soundgasm"
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:08:50.285110
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('ytdl')

# Generated at 2022-06-12 18:08:55.232111
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE_NAME = 'soundgasm'
    soundgasm = SoundgasmIE(IE_NAME)
    assert (soundgasm.ie_key() == IE_NAME)
    assert (soundgasm.ie_name() == IE_NAME)
    assert (soundgasm.ie_version == '0.1')

# Generated at 2022-06-12 18:08:57.743235
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    return SoundgasmIE()._real_extract('http://soundgasm.net/u/ytdl/Piano-sample') is not None


# Generated at 2022-06-12 18:08:59.756141
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert SoundgasmProfileIE("http://soundgasm.net/u/ytdl").IE_NAME == "SoundgasmProfileIE"

# Generated at 2022-06-12 18:09:01.338223
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    print(ie)

test_SoundgasmIE()

# Generated at 2022-06-12 18:09:06.893524
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._TEST['info_dict']['id'] == SoundgasmProfileIE._VALID_URL[-6:-1]
    assert SoundgasmProfileIE._TEST['url'] == (SoundgasmProfileIE._TEST['info_dict']['id'][-6:-1])[-6:0]+'/'

# Generated at 2022-06-12 18:09:12.204874
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# Test with a valid youtube_url
	s = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
	# Test with an invalid youtube_url
	try:
		SoundgasmIE('http://www.youtube.com/watch?v=9bZkp7q19f0')
	except Exception as e:
		assert (e is not None)



# Generated at 2022-06-12 18:09:18.727977
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	from StringIO import StringIO
	from urlparse import urlparse
	import unittest

	def url_from_name(name):
		return 'http://soundgasm.net/u/' + name + '/'

	def path_from_url(url):
		return urlparse(url).path

	# Init unit test framework
	class TestSoundgasmProfileIE(unittest.TestCase):
		def setUp(self):
			# Set up TestCase
			self.maxDiff = None

		def test_constructor(self):
			# Test constructor
			self.assertEqual(SoundgasmProfileIE.IE_NAME, 'soundgasm:profile')

# Generated at 2022-06-12 18:09:38.565076
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    obj_SoundgasmIE = SoundgasmIE()
    result_obj = obj_SoundgasmIE._real_extract(url)
    assert result_obj['id'] == "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
    assert result_obj['display_id'] == "Piano-sample"
    assert result_obj['url'] == "https://soundgasm.net/static/uploads/ytdl/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a"
    assert result_obj['vcodec'] == "none"
    assert result_obj['title'] == "Piano sample"
    assert result_obj

# Generated at 2022-06-12 18:09:40.491790
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	print('Started test for SoundgasmProfileIE')
	soundgasmProfile = SoundgasmProfileIE()
	print(soundgasmProfile)

# Generated at 2022-06-12 18:09:41.931669
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test for the constructor
    obj = SoundgasmProfileIE()
    assert isinstance(obj, SoundgasmProfileIE)

# Generated at 2022-06-12 18:09:45.098569
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_case = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert test_case._VALID_URL is not None
    assert test_case._TEST is not None, 'Test is empty'
    assert test_case._real_extract is not None, 'Test is empty'


# Generated at 2022-06-12 18:09:47.551764
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()._real_extract()

# Generated at 2022-06-12 18:09:51.107875
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        info_extractor = SoundgasmProfileIE()
        print("Test success: SoundgasmProfileIE()")
    except:
        print("Test failure: SoundgasmProfileIE()")


# Generated at 2022-06-12 18:09:58.764872
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sgp = SoundgasmProfileIE('', {}, None)
    assert (sgp._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
    assert (sgp.IE_NAME == 'soundgasm:profile')
    assert (sgp._TEST == {'url': 'http://soundgasm.net/u/ytdl','info_dict': {'id': 'ytdl'},'playlist_count': 1})


# Generated at 2022-06-12 18:10:01.392493
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie_obj1 = SoundgasmProfileIE()
    ie_obj2 = SoundgasmProfileIE()
    assert(ie_obj1 != ie_obj2)

# Generated at 2022-06-12 18:10:07.214006
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE("http://soundgasm.net/u/ytdl")._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-12 18:10:17.242658
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio_id = "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    class_ = SoundgasmIE
    assert class_.suitable(url)
    assert class_.IE_NAME == "soundgasm"
    assert class_.IE_DESC == "Soundgasm"
    ie = class_(None, url)
    info_dict = ie._real_extract(url)
    assert info_dict['id'] == audio_id
    assert info_dict['display_id'] == "Piano-sample"
    assert info_dict['url'] == "http://soundgasm.net/assets/audio/piano-sample.m4a"

# Generated at 2022-06-12 18:10:40.099392
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    user = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    assert user.IE_NAME == "soundgasm:profile"
    assert user.display_id == "ytdl"
    assert user._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$"


# Generated at 2022-06-12 18:10:51.946198
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl', 'SoundgasmProfileIE')
    self.assertEqual(ie.ie_key(), 'SoundgasmProfileIE')
    self.assertEqual(ie.ie_name(), 'Soundgasm')
    self.assertEqual(ie.suitable(None), True)
    self.assertEqual(ie.suitable('http://soundgasm.net/u/ytdl'), True)
    self.assertEqual(ie.suitable('http://soundgasm.net/u/ytdl/'), True)
    self.assertEqual(ie.suitable('http://soundgasm.net/u/ytdl/#'), True)

# Generated at 2022-06-12 18:10:55.913160
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import os
    import unittest
    from .extractors import common

    class SoundgasmIETestCase(common.SimpleGetDownloadTestCase):
        IE = SoundgasmIE

    return unittest.main(argv=[os.sys.argv[0], os.path.basename(__file__)
        ] + os.sys.argv[1:])


# Generated at 2022-06-12 18:10:59.432277
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import main
    from .generic_extractor import extractor
    from .soundgasm import SoundgasmProfileIE
    main(extractor(SoundgasmProfileIE, 'SoundgasmProfileIE'))


# Generated at 2022-06-12 18:11:00.888200
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE == SoundgasmProfileIE.ie_key()

# Generated at 2022-06-12 18:11:10.791541
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from urlparse import urlparse
    from .common import InfoExtractor
    from .common import parse_resolution
    from .tests.test_soundcloud import get_content

    content = get_content(
        'https://www.testurl.com/u/ytdl', url_handle=None,
        encoding='utf-8',
        match=r'href="([^"]+/u/\w+/[^"]+)'
    )
    urls = re.findall(r'href="([^"]+/u/\w+/[^"]+)', content)

    ie = InfoExtractor()
    ie._downloader.urlopen = lambda x: StringIO(content)

    ae = ie.extract(urls[0])
    # the result object should have an id and title

# Generated at 2022-06-12 18:11:16.867569
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Instantiates an object of SoundgasmProfileIE
    soundgasm_profile = SoundgasmProfileIE()
    assert soundgasm_profile.IE_NAME == 'soundgasm:profile'
    assert soundgasm_profile.VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:11:18.430863
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == 'soundgasm'
    assert SoundgasmProfileIE().IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-12 18:11:21.842047
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE("http://soundgasm.net/u/JALYsOOs/orgasm-test")
    assert ie.IE_NAME == "Soundgasm"
    assert ie._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)"

# Generated at 2022-06-12 18:11:34.976560
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from yt_dl.extractor import SoundgasmIE
    sg = SoundgasmIE()
    assert(sg.IE_NAME == 'soundgasm')
    assert(sg.IE_DESC == 'Soundgasm')
    assert(sg._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-12 18:12:09.208759
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:12:17.081003
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class_ = SoundgasmIE
    class_._download_webpage = lambda *args, **kwargs: '<script>window.playlist = [{"title":"title", "m4a":"https://example.com/path.m4a"}]</script>'
    instance = class_()
    assert instance.IE_NAME == 'Soundgasm'
    assert instance._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:12:20.678541
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print('creating a new SoundgasmIE object')
    obj = SoundgasmIE()
    assert('SoundgasmIE' in str(type(obj)))
    print('ok')



# Generated at 2022-06-12 18:12:23.427349
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE_NAME = 'soundgasm:profile'
    _VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    url = 'http://soundgasm.net/u/ytdl'
    a = SoundgasmProfileIE(IE_NAME, _VALID_URL, url)

# Generated at 2022-06-12 18:12:24.075552
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-12 18:12:26.302268
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        assert SoundgasmProfileIE._VALID_URL is not None
    except Exception as e:
        print(e)
        assert False

test_SoundgasmProfileIE()


# Generated at 2022-06-12 18:12:27.277696
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Test creation of SoundgasmIE"""
    SoundgasmIE()

# Generated at 2022-06-12 18:12:32.912431
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE('http://soundgasm.net/u/frozen_virus');
    instance = SoundgasmProfileIE('http://soundgasm.net/u/frozen_virus');
    instance = SoundgasmProfileIE('http://soundgasm.net/u/frozen_virus');
    instance = SoundgasmProfileIE('http://soundgasm.net/u/frozen_virus');

# Generated at 2022-06-12 18:12:34.499725
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    output = SoundgasmProfileIE('174910')
    assert '174910' in output

# Generated at 2022-06-12 18:12:35.454412
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-12 18:14:03.223512
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-12 18:14:03.739809
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-12 18:14:04.259234
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-12 18:14:06.923307
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Simple test for constructor of class SoundgasmIE in order to ensure that
    the class can be instantiated
    """
    _ = SoundgasmIE(InfoExtractor())

# Generated at 2022-06-12 18:14:12.897345
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

	# Create an instance of class SoundgasmProfileIE
	soundgasm_profile = SoundgasmProfileIE()

	# Check if the instance is created
	assert soundgasm_profile._NAME == 'SoundgasmProfileIE'

	# Check if _VALID_URL is set correctly
	assert soundgasm_profile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-12 18:14:14.600024
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE("http://soundgasm.net/u/ytdl", {})

# Generated at 2022-06-12 18:14:23.698493
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    obj = SoundgasmIE({})
    assert obj._match_id(url) == 'Piano-sample'
    assert obj._match_id('Piano-sample') == 'Piano-sample'
    assert obj._match_id('https://www.soundgasm.net/u/ytdl/Piano-sample') == 'Piano-sample'
    assert obj._match_id('https://www.soundgasm.net/u/ytdl/') == None
    assert obj._match_id('http://soundgasm.net/u/ytdl/Piano-sample/') == None
    assert obj._match_id('http://soundgasm.net/u/ytdl/')== None
    assert obj._

# Generated at 2022-06-12 18:14:28.874863
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_object = SoundgasmProfileIE()
    assert test_object._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'



# Generated at 2022-06-12 18:14:30.455998
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print(SoundgasmProfileIE._VALID_URL)


# Generated at 2022-06-12 18:14:33.599089
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()

    assert (ie.__class__.__name__ == 'SoundgasmProfileIE')
    assert (ie.__class__.__name__ is not 'InfoExtractor')
