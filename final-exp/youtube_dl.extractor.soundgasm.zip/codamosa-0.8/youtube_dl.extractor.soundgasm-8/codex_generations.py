

# Generated at 2022-06-12 18:07:00.361453
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Test constructor SoundgasmIE"""
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE(url)
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie.IE_NAME == 'soundgasm'
    assert ie.test() == True

# Generated at 2022-06-12 18:07:02.911760
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    module = __name__.split('.')[-1]
    SoundgasmIE()

# Generated at 2022-06-12 18:07:05.137841
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Construct an example to test
    example = SoundgasmIE()
    # Execute the test
    example._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:07:13.491928
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Define inputs and outputs
    input_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    output_ie = 'Soundgasm'
    output_id = "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
    output_title = "Piano sample"

    # Create a new instance of the class
    soundgasm_ie = SoundgasmIE()

    # Download webpage with URL
    webpage = soundgasm_ie._download_webpage(input_url, output_id)

    # Extract info from webpage
    info_dict = soundgasm_ie._real_extract(input_url)

    # Checks that the title equals "Piano sample"
    assert output_title == info_dict['title']


# Generated at 2022-06-12 18:07:15.256377
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    s = SoundgasmProfileIE()

# Generated at 2022-06-12 18:07:17.094684
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    assert(sg.IE_NAME == 'Soundgasm')

# Generated at 2022-06-12 18:07:18.396547
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    
    assert ie != None


# Generated at 2022-06-12 18:07:25.864524
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE('http://soundgasm.net/u/ytdl', {})
    assert isinstance(obj, SoundgasmProfileIE)
    assert obj.IE_NAME == 'soundgasm:profile', 'attributes IE_NAME is incorrect'
    assert obj.valid_url(obj.VALID_URL), 'valid_url returns wrong value'
    assert obj._download_webpage('http://soundgasm.net/u/ytdl', 'ytdl')

# Generated at 2022-06-12 18:07:31.414456
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE_name_list = ['SoundgasmIE', 'SoundgasmProfileIE']
    for IE_name in IE_name_list:
        ie = globals()[IE_name]()
        example_url_list = ie._TEST.get('url')
        if isinstance(example_url_list, list):
            for url in example_url_list:
                ie.suitable(url)
        else:
            ie.suitable(ie._TEST.get('url'))


# Generated at 2022-06-12 18:07:34.345915
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        assert SoundgasmIE(None, None)
    except Exception:
        assert False, "Should not raise exception, but did."


# Generated at 2022-06-12 18:07:45.941426
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-12 18:07:53.826435
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE()
    # Test property _VALID_URL
    assert instance._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)"
    # Test property IE_NAME
    assert instance.IE_NAME == "soundgasm"
    # Test property _TEST

# Generated at 2022-06-12 18:08:03.748538
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl', 'Soundgasm')
    #assert ie.params['url'] == 'http://soundgasm.net/u/ytdl', 'ie.params["url"] == "http://soundgasm.net/u/ytdl" failed!'
    #assert ie.params['_type'] == 'playlist', 'ie.params["_type"] == "playlist" failed!'
    #assert ie.params['playlistend'] == 10, 'ie.params["playlistend"] == 10 failed!'
    #assert ie.params['extractor_key'] == 'SoundgasmProfileIE', 'ie.params["extractor_key"] == "SoundgasmProfileIE" failed!'
    #assert ie.params['IE_NAME'] == 'Soundgasm', 'ie

# Generated at 2022-06-12 18:08:05.160129
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert isinstance(ie, SoundgasmIE)

# Generated at 2022-06-12 18:08:14.541876
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert(SoundgasmIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-12 18:08:18.226203
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	"""Unit test for constructor of class SoundgasmProfileIE"""

	# Create instance of class SoundgasmProfileIE
	soundgasm_profile_ie_instance = SoundgasmProfileIE()

# Generated at 2022-06-12 18:08:26.644747
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	print ("Unit test for constructor of class SoundgasmProfileIE")
	#Set url of the video to be downloaded
	url1= 'http://soundgasm.net/u/ytdl'
	#Create an object of class SoundgasmProfileIE
	soundgasmProfileIE = SoundgasmProfileIE()
	#Call the method extract of class SoundgasmProfileIE
	print ("Calling the method extract of class SoundgasmProfileIE")
	soundgasmProfileIE.extract(url1)


# Generated at 2022-06-12 18:08:33.830056
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg = SoundgasmProfileIE()
    ie = sg._real_extract('http://www.soundgasm.net/u/ytdl')
    assert ie['id'] == 'ytdl'
    entries = ie['entries']
    assert len(entries) == 1
    assert entries[0]['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-12 18:08:35.426211
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-12 18:08:37.558899
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a =  SoundgasmProfileIE()
    assert isinstance(a,InfoExtractor)


# Generated at 2022-06-12 18:08:47.888768
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # building object of derived class by calling constructor of base class
    obj = SoundgasmProfileIE('ytdl')
    assert obj.ie_key() == 'Soundgasm', 'Wrong IE extracted'

# Generated at 2022-06-12 18:08:59.546368
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_obj = SoundgasmIE()
    assert test_obj.IE_NAME == 'soundgasm'
    assert test_obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:09:07.042858
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test for soundgasm.net
    soundgasmie = SoundgasmIE()
    assert soundgasmie.IE_NAME == "Soundgasm"
    assert soundgasmie._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)"
    assert soundgasmie.IE_DESC == "Soundgasm"

# Generated at 2022-06-12 18:09:09.521271
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Test SoundgasmProfileIE against a url that isn't a SoundgasmProfileIE url"""
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    se = SoundgasmProfileIE()
    se._real_initialize()
    try:
        se.suitable(url)
        assert(False)
    except:
        pass

# Generated at 2022-06-12 18:09:10.590828
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()


# Generated at 2022-06-12 18:09:14.116697
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    video = ie.extract(url)
    assert video['title'] == 'Piano sample'
    assert video['description'] == 'Royalty Free Sample Music'
    assert video['uploader'] == 'ytdl'


# Generated at 2022-06-12 18:09:20.066873
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:09:28.771155
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    Test = SoundgasmIE()
    Test._download_webpage = lambda url, display_id: 'http://soundgasm.net/u/ytdl/Piano-sample'
    Test._html_search_regex = lambda pattern: 'soundgasm.net/sounds/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    Test._search_regex = lambda pattern: 'Piano sample'
    assert Test._real_extract(Test._TEST['url']) == Test._TEST

# Generated at 2022-06-12 18:09:29.394290
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-12 18:09:33.574470
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Set a specific value that can be distinguished
    SoundgasmProfileIE.description = 'description'
    ie = SoundgasmProfileIE(None)
    ie._real_initialize()
    assert ie.description == ''
    assert ie.__class__.description == 'description'

# Generated at 2022-06-12 18:09:50.642117
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE is not None

# Generated at 2022-06-12 18:10:00.447535
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1 }
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.__module__ == 'youtube_dl.extractor.soundgasm'
    assert ie._match_id('http://soundgasm.net/u/ytdl/Piano-sample') == 'Piano-sample'

# Generated at 2022-06-12 18:10:06.206491
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    aSoundgasmProfileIE = SoundgasmProfileIE()
    aSoundgasmProfileIE.IE_NAME
    aSoundgasmProfileIE._VALID_URL
    aSoundgasmProfileIE._TEST

# Generated at 2022-06-12 18:10:11.921105
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    inst = SoundgasmIE()
    inst._download_webpage = lambda url, display_id: (url, display_id)
    assert inst._download_webpage('http://soundgasm.net/u/ytdl/Piano-sample', 'Piano-sample') == ('http://soundgasm.net/u/ytdl/Piano-sample', 'Piano-sample')

# Generated at 2022-06-12 18:10:18.579999
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	test_data = {
		'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
		'md5': '010082a2c802c5275bb00030743e75ad',
		'info_dict': {
			'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
			'ext': 'm4a',
			'title': 'Piano sample',
			'description': 'Royalty Free Sample Music',
			'uploader': 'ytdl',
		}
	}
	SoundgasmIE().extract(test_data['url'])

# Generated at 2022-06-12 18:10:20.186584
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    The constructor of class SoundgasmIE uses the static class variable IE_NAME
    to retrieve the correct name for the instance.
    """
    assert SoundgasmIE.IE_NAME == 'soundgasm'



# Generated at 2022-06-12 18:10:21.169531
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE("ytdl")

# Generated at 2022-06-12 18:10:30.376809
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    assert soundgasm.IE_NAME == 'Soundgasm'
    assert soundgasm._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:10:35.818992
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    audio_id = "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
    display_id = "Piano-sample"
    title = "Piano sample"
    description = "Royalty Free Sample Music"
    uploader = "ytdl"

    # Constructor without arguments
    ie = SoundgasmIE()

    # Constructor with audio_url and audio_id
    ie = SoundgasmIE(audio_url, audio_id)
    assert ie.audio_url == audio_url and ie.audio_id == audio_id

    # Constructor with audio_url, audio_id and display_id

# Generated at 2022-06-12 18:10:37.267630
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL == SoundgasmProfileIE._VALID_URL

# Generated at 2022-06-12 18:11:19.745557
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE


# Generated at 2022-06-12 18:11:25.489443
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_ie = SoundgasmIE()
    # test with normal input
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    normal_result = soundgasm_ie.extract(url)
    assert normal_result is not None
    # test with strange input
    strange_input = SoundgasmIE._VALID_URL.replace('.', '..').replace('/', '\/')
    strange_result = soundgasm_ie.extract(strange_input)
    assert strange_result is not None


# Generated at 2022-06-12 18:11:27.135219
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """ Instantiates a new object of class SoundgasmProfileIE """
    SoundgasmProfileIE()

# Generated at 2022-06-12 18:11:29.495498
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test that the SoundgasmIE can be initialized
    SoundgasmIE()


# Generated at 2022-06-12 18:11:39.515625
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	
	def assert_equal(a, b):
		if cmp(a, b) != 0:
			print ("Error: %s != %s"%(a,b))

	a1 = SoundgasmIE()._VALID_URL
	a2 = re.compile(r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')
	assert_equal(a1,a2)

	a3 = SoundgasmIE().IE_NAME
	a4 = 'soundgasm'
	assert_equal(a4, a4)


# Generated at 2022-06-12 18:11:50.975856
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # test the constructor of SoundgasmIE
    ie_obj = SoundgasmIE('')
    assert ie_obj.IE_NAME == 'Soundgasm'
    # test the _VALID_URL attribute
    assert ie_obj._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/([^/]+)/([^/]+)$'
    # test the _TEST attribute

# Generated at 2022-06-12 18:11:54.615397
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from . import main
    r = main([
        '-i', 'SoundgasmProfile', 'http://soundgasm.net/u/ytdl'
    ])

# Generated at 2022-06-12 18:11:56.092334
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-12 18:11:59.964966
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == "soundgasm:profile"
    assert ie._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$"
    assert ie._TEST == {
           "url": "http://soundgasm.net/u/ytdl",
           "info_dict": {
                "id": "ytdl",
           },
           "playlist_count": 1,
    }

# Generated at 2022-06-12 18:12:09.253579
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from . import SoundgasmProfileIE
    from . import unittest
    from . import urlopen
    from . import make_mock_urlopen_urls_generator
    from . import make_mock_urlopen_generator
    from . import compat_urllib_parse
    import ytdl_extractor_test
    import contextlib
    import itertools

    # Test urlopen calls

# Generated at 2022-06-12 18:13:45.385480
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == "soundgasm"


# Generated at 2022-06-12 18:13:47.099930
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profileIE = SoundgasmProfileIE('SoundgasmProfileIE')
    assert profileIE.name == 'SoundgasmProfileIE'
    assert profileIE.urls != None

# Generated at 2022-06-12 18:13:47.817377
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('Soundgasm:profile')

# Generated at 2022-06-12 18:13:51.346975
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    assert sg.IE_NAME == 'soundgasm'
    assert sg._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:13:56.836207
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Unit test for constructor of class SoundgasmProfileIE"""

# Generated at 2022-06-12 18:13:58.669658
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        test = SoundgasmProfileIE()
        return 1
    except:
        return 0

# Generated at 2022-06-12 18:14:03.675273
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-12 18:14:04.467055
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    return SoundgasmProfileIE().result()

# Generated at 2022-06-12 18:14:06.807933
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE()
    instance._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:14:13.055234
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert obj._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }