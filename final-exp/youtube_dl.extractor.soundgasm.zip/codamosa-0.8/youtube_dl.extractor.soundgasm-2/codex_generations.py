

# Generated at 2022-06-12 18:07:02.697981
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'

    webpage = '<html><head></head><body><a href="/u/ytdl/Piano-sample"/></body></html>'
    entries = re.findall(r'href="([^"]+/u/%s/[^"]+)' % profile_id, webpage)

    ie = SoundgasmProfileIE()
    result = ie.extract(url)

    assert result['id'] == profile_id
    assert result['entries'][0]['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'

# Generated at 2022-06-12 18:07:06.183582
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('https://soundgasm.net/u/ytdl')
    ie._real_extract('https://soundgasm.net/u/ytdl')

# Generated at 2022-06-12 18:07:09.110807
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    test = SoundgasmIE().suitable(url)
    assert test == True, 'url: {0} should be true'.format(url)

# Generated at 2022-06-12 18:07:10.309676
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    tester = SoundgasmProfileIE()
    tester.suite()

# Generated at 2022-06-12 18:07:16.048562
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from . import SoundgasmIE
    video = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert video.url == 'http://s3.soundgasm.net/u/ytdl/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'

# Generated at 2022-06-12 18:07:18.562441
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    SoundgasmIE()._real_extract(url)


# Generated at 2022-06-12 18:07:19.522528
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-12 18:07:22.417554
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'

# Generated at 2022-06-12 18:07:26.608175
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    unit_test = SoundgasmProfileIE()
    # To check if the valid_url is valid, since this is the variable that starts the extraction process.
    assert re.match(unit_test._VALID_URL, unit_test._TEST['url']) is not None, \
        'The valid_url variable is not valid.'

# Generated at 2022-06-12 18:07:28.248449
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
        sound = SoundgasmProfileIE()
        assert sound.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-12 18:07:39.204462
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    check = SoundgasmProfileIE()
    assert check.ie_key() == 'Soundgasm:profile'
    assert check.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-12 18:07:46.574714
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert ie._TEST['info_dict']['id'] == 'ytdl'
    assert ie._TEST['playlist_count'] == 1


# Generated at 2022-06-12 18:07:52.807498
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	import pprint
	url = 'http://soundgasm.net/u/ytdl/Piano-sample'
	print('Download Video URL: ' + url)
	ie = SoundgasmIE()
	data = ie._real_extract(url)
	pprint.pprint(data)
	url2 = 'https://soundgasm.net/u/trying'
	print('Download Profile URL: ' + url2)
	ie2 = SoundgasmProfileIE()
	data2 = ie2._real_extract(url2)
	pprint.pprint(data2)


# Generated at 2022-06-12 18:08:03.033239
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasmIE = SoundgasmIE()
    # Test if function parse_duration() works
    result = soundgasmIE.parse_duration('1h 12m 7s')
    assert result == 4327
    result = soundgasmIE.parse_duration('0h 1m 7s')
    assert result == 67
    result = soundgasmIE.parse_duration('1m 7s')
    assert result == 67
    result = soundgasmIE.parse_duration('7s')
    assert result == 7
    result = soundgasmIE.parse_duration('   0  s  ')
    assert result == 0
    result = soundgasmIE.parse_duration('   asdf  ')
    assert result == 0
    # Test if function format_duration() works
    result = soundgasmIE.format_duration(4327)

# Generated at 2022-06-12 18:08:07.682823
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE()
    # test for constructor of class SoundgasmProfileIE
    # inputs: url = https://soundgasm.net/u/ytdl/
    url = "https://soundgasm.net/u/ytdl/"
    # expected: info_dict = {'id': 'ytdl'}
    expected = {'id': 'ytdl'}
    info_dict = soundgasm_profile_ie._real_extract(url)
    assert info_dict == expected



# Generated at 2022-06-12 18:08:14.410130
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	sgIE = SoundgasmIE()
	sgIE = sgIE.__init__()
	assert sgIE.IE_NAME == 'soundgasm'
	assert sgIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:08:22.870055
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._match_id('http://soundgasm.net/u/ytdl/Piano-sample') == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert ie._match_id('http://soundgasm.net/u/ytdl') == 'ytdl'

# Generated at 2022-06-12 18:08:24.866854
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')


# Generated at 2022-06-12 18:08:27.824204
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE("SoundgasmProfileIE", "SoundgasmProfileIE", "SoundgasmProfileIE", "SoundgasmProfileIE")

# Generated at 2022-06-12 18:08:30.715682
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE('SoundgasmProfile'))

# Generated at 2022-06-12 18:08:55.108733
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert SoundgasmProfileIE._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-12 18:08:58.369134
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import unittest
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    self = SoundgasmIE(unittest.TestCase)
    self._match_id(url)
    

# Generated at 2022-06-12 18:08:59.931010
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from . import _disclaimer_mock
    _disclaimer_mock()
    assert info_extractor(
        'http://soundgasm.net/u/ytdl'
    )

# Generated at 2022-06-12 18:09:03.087822
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_object = SoundgasmProfileIE(IE_NAME, VALID_URL, 'Soundgasm')
    assert test_object.IE_NAME == IE_NAME
    assert test_object._VALID_URL == VALID_URL
    assert test_object._TEST == 'Soundgasm'

# Generated at 2022-06-12 18:09:07.364485
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    ie.extract('http://soundgasm.net/u/ytdl')



# Generated at 2022-06-12 18:09:09.272218
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None, 'http://soundgasm.net/u/ytdl')

# Generated at 2022-06-12 18:09:11.503561
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample', 'http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:09:13.393576
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    ie.extract('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-12 18:09:14.379944
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	profile_ie = SoundgasmProfileIE()
	assert profile_ie

# Generated at 2022-06-12 18:09:16.110920
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    assert obj._VALID_URL == SoundgasmIE._VALID_URL
    assert obj.IE_NAME == SoundgasmIE.IE_NAME

# Generated at 2022-06-12 18:09:38.649703
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test = SoundgasmProfileIE()
    assert test.IE_NAME == 'soundgasm:profile'
    assert test._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:09:46.073960
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Given args
    info = {
        'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
        'md5': '010082a2c802c5275bb00030743e75ad',
        'info_dict': {
            'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
            'ext': 'm4a',
            'title': 'Piano sample',
            'description': 'Royalty Free Sample Music',
            'uploader': 'ytdl',
        }
    }

    # When SoundgasmIE object is created
    ie = SoundgasmIE()
    expected_output = True

    # Then the object should have the given args

# Generated at 2022-06-12 18:09:52.189462
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mobj = re.match(SoundgasmIE._VALID_URL, url)
    ie = SoundgasmIE(None)
    assert ie._real_extract(url) == SoundgasmIE._TEST

# Generated at 2022-06-12 18:09:57.407193
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_ie = SoundgasmProfileIE()
    assert profile_ie._VALID_URL is SoundgasmProfileIE._VALID_URL
    assert profile_ie._TEST is SoundgasmProfileIE._TEST
    assert profile_ie.IE_NAME is SoundgasmProfileIE.IE_NAME
    assert profile_ie.__doc__ is SoundgasmProfileIE.__doc__

# Generated at 2022-06-12 18:10:03.334530
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url_info = SoundgasmProfileIE._VALID_URL.split('(')
    regex_info = [re.compile(url_info[0]), url_info[1].strip(')').split(')')[0]]
    assert regex_info[0].search(SoundgasmProfileIE._TEST['url'])
    assert regex_info[1] == 'id'
    assert SoundgasmProfileIE._TEST['url'].find(SoundgasmProfileIE._TEST['info_dict']['id']) >= 0

# Generated at 2022-06-12 18:10:09.769127
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info_extractor = SoundgasmProfileIE()
    assert info_extractor.IE_NAME == 'soundgasm:profile'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-12 18:10:11.643564
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE(): 
    test_inst = SoundgasmIE()
    assert type(test_inst) == SoundgasmIE

# Generated at 2022-06-12 18:10:13.819765
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ydl = SoundgasmProfileIE()
    assert ydl.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-12 18:10:19.880200
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        IE = SoundgasmProfileIE()
        assert IE.IE_NAME == 'soundgasm:profile'
        assert IE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    except AssertionError:
        print("Test failed: constructor of class SoundgasmProfileIE")


# Generated at 2022-06-12 18:10:22.742772
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class_ = SoundgasmIE
    class_.ie_key = SoundgasmIE.ie_key
    obj = class_(None)
    assert obj.ie_key == SoundgasmIE.ie_key

# Generated at 2022-06-12 18:11:10.030001
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
        myInstance = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
        myInstance.extract()

# Constructor of class SoundgasmProfileIE

# Generated at 2022-06-12 18:11:10.911489
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE(SoundgasmIE._TEST)

# Generated at 2022-06-12 18:11:14.630540
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    obj = SoundgasmIE({'url': url, 'download': True, 'extract_flat': 'in_playlist'})

    assert obj.url == url
    assert obj.download
    assert obj.extract_flat == 'in_playlist'

# Generated at 2022-06-12 18:11:18.463317
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    ex = SoundgasmIE()
    print(ex._real_extract(url))


# Generated at 2022-06-12 18:11:23.866707
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.suitable('http://soundgasm.net/u/ytdl')
    assert ie.suitable('https://soundgasm.net/u/ytdl')
    assert ie.suitable('https://soundgasm.net/u/ytdl/')
    assert ie.suitable('https://soundgasm.net/u/ytdl/#')


# Generated at 2022-06-12 18:11:29.495221
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie.VALID_URL.__name__ == '_VALID_URL'
    assert ie.VALID_URL.pattern == SoundgasmIE._VALID_URL
    assert ie.TEST == SoundgasmIE._TEST

# Generated at 2022-06-12 18:11:36.828158
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'

    webpage = "Download and listen to ytdl's Soundgasm: Piano sample [Royalty Free Sample Music]"
    entries = [
        "http://soundgasm.net/u/ytdl/Piano-sample"
    ]

    instance = SoundgasmProfileIE()
    actual_entries = instance._extract_entries(webpage, profile_id)
    assert actual_entries == entries


# Generated at 2022-06-12 18:11:38.138492
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'

# Generated at 2022-06-12 18:11:44.117961
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sgProfile = SoundgasmProfileIE()
    test_url = 'http://soundgasm.net/u/ytdl'
    assert sgProfile._match_id(test_url) == 'ytdl'
    assert sgProfile._valid_url(test_url,'') == True

# Generated at 2022-06-12 18:11:46.604107
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_url = 'http://soundgasm.net/u/ytdl'
    profile = SoundgasmProfileIE()
    profile.suite()

# Generated at 2022-06-12 18:13:12.389822
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    return SoundgasmProfileIE()

# Generated at 2022-06-12 18:13:15.004200
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	test_obj = SoundgasmIE()
	assert(test_obj.IE_NAME == 'soundgasm')


# Generated at 2022-06-12 18:13:18.398248
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'

    # IE_NAME is 'soundgasm:profile'
    profile = SoundgasmProfileIE(url)

    assert profile.name == 'SoundgasmProfileIE'
    assert profile.ie_key() == 'SoundgasmProfileIE'
    assert profile.suitable(url) == True
    assert profile.working() == True

# Generated at 2022-06-12 18:13:25.398376
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Test that class SoundgasmIE object is created properly"""
    ie = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    ## Check that the attributes have been set
    assert ie.IE_NAME == 'Soundgasm'
    assert ie._VALID_URL == 'http://soundgasm.net/u/ytdl/Piano-sample'



# Generated at 2022-06-12 18:13:29.851164
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # A profile page of a non-existant user on soundgasm.net
    try:
        SoundgasmProfileIE("soundgasm", "http://soundgasm.net/u/sdfsdfsdfsdfsdfd")
    except Exception as e:
        assert "Unable to download webpage" in str(e)


# Generated at 2022-06-12 18:13:33.605177
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # URL for the class to be tested.
    url = 'http://soundgasm.net/u/ytdl'

    # Initializing a class with the url.
    ie = SoundgasmProfileIE(url)
    ie._download_webpage()

# Generated at 2022-06-12 18:13:36.114881
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile = SoundgasmProfileIE(soundgasm_ie=None, ytdl_ie=None)
    assert soundgasm_profile.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-12 18:13:43.049694
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie.VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:13:46.361216
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .test_soundgasm import test_SoundgasmProfileIE
    test_SoundgasmProfileIE()

# Generated at 2022-06-12 18:13:48.763880
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'

    SoundgasmProfileIE(url)
    SoundgasmProfileIE.extract(url)