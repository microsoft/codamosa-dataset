

# Generated at 2022-06-12 18:06:58.047451
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    x = SoundgasmIE()
    x.extract(test_SoundgasmIE._TEST['url'])

# Generated at 2022-06-12 18:07:00.700728
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl/")

# Generated at 2022-06-12 18:07:06.768409
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Unit test initialization
    # Create object of class SoundgasmIE - Extractor object
    ie = SoundgasmIE()
    # Create test data
    url = "http://soundgasm.net/u/ytdl/Piano-sample"

    # Call function _real_extract with test data
    ie._real_extract(url)

# Generated at 2022-06-12 18:07:08.975743
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    x = SoundgasmProfileIE();
    y = SoundgasmProfileIE();
    assert(x is not y)

# Generated at 2022-06-12 18:07:10.441319
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE
    except:
        assert False


# Generated at 2022-06-12 18:07:16.983373
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	url = 'http://soundgasm.net/u/ytdl/Piano-sample'
	url_profile = 'http://soundgasm.net/u/ytdl'
	ie = SoundgasmIE(url)
	ie_profile = SoundgasmProfileIE(url_profile)
	assert(ie.IE_NAME == 'soundgasm')
	assert(ie_profile.IE_NAME == 'soundgasm:profile')

# Generated at 2022-06-12 18:07:19.572652
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl', 'Soundgasm')
    assert ie.ie_key() == 'Soundgasm'
    assert ie.working == True

# Generated at 2022-06-12 18:07:24.568591
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert type(ie) is SoundgasmIE
    assert ie._VALID_URL == SoundgasmIE._VALID_URL
    assert ie._TEST == SoundgasmIE._TEST

# Generated at 2022-06-12 18:07:26.286609
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-12 18:07:26.925497
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print(SoundgasmProfileIE._TEST)

# Generated at 2022-06-12 18:07:38.686940
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('1','2','3','4','5','6','7','8','9','0','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','')

# Generated at 2022-06-12 18:07:43.134626
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE(None)._VALID_URL == SoundgasmIE._VALID_URL
    assert SoundgasmIE(None).IE_NAME == SoundgasmIE._NAME
    assert SoundgasmIE(None)._TEST == SoundgasmIE._TEST

# Generated at 2022-06-12 18:07:47.035333
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie=SoundgasmProfileIE(SoundgasmProfileIE.IE_NAME, SoundgasmProfileIE._VALID_URL, SoundgasmProfileIE._TEST)
    # Constructor has no return value, nothing to test.
    #print soundgasm_profile_ie

# Generated at 2022-06-12 18:07:49.242733
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-12 18:07:51.551547
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie_test = SoundgasmIE(SoundgasmIE.IE_NAME)
    assert ie_test.IE_NAME == 'soundgasm'
    print("test_SoundgasmIE() ran successfully")


# Generated at 2022-06-12 18:07:53.418535
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test if the instance of class SoundgasmProfileIE has a working constructor
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl")

# Generated at 2022-06-12 18:08:03.390160
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class SoundgasmIE():
        IE_NAME = 'soundgasm'
        _VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:08:04.606455
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-12 18:08:10.109813
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    expected = """SoundgasmIE
    IE_NAME: soundgasm
    _VALID_URL: r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'"""

    actual = str(SoundgasmIE)

    assert expected == actual

# Generated at 2022-06-12 18:08:17.421809
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ret1 = SoundgasmProfileIE
    assert ret1.IE_NAME == 'soundgasm:profile'
    assert ret1._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    test_dict = {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}
    ret2 = ret1._TEST
    assert ret2 == test_dict
    assert ret1._real_extract('http://soundgasm.net/u/ytdl') == test_dict

# Generated at 2022-06-12 18:08:26.247801
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-12 18:08:28.442832
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/"
    return SoundgasmIE(url)


# Generated at 2022-06-12 18:08:33.172915
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-12 18:08:39.369225
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    obj = SoundgasmIE()
    result = obj._real_extract(url)
    assert result['url'] == 'https://s3.amazonaws.com/soundgasm/audio/releases/_full/ytdl/Piano-sample.m4a'

# Generated at 2022-06-12 18:08:41.442812
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE(None)
    assert ie.IE_NAME == 'soundgasm'


# Generated at 2022-06-12 18:08:43.223562
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://example.org/', 'http://example.com/')
    assert ie is not None

# Generated at 2022-06-12 18:08:48.799240
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    info_dict = {
        'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
        'ext': 'm4a',
        'title': 'Piano sample',
        'description': 'Royalty Free Sample Music',
        'uploader': 'ytdl',
    }
    ie = SoundgasmIE()
    #test SoundgasmIE._real_extract method
    info = ie._real_extract(url)
    assert info == info_dict


# Generated at 2022-06-12 18:08:52.149272
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(None, 'http://soundgasm.net/u/ytdl/')
    assert ie.user_id == 'ytdl'

# Generated at 2022-06-12 18:08:56.752403
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Check private method _VALID_URL
    soundgasm_profile = SoundgasmProfileIE()
    # Return the match of the regular expression
    match = re.match(soundgasm_profile._VALID_URL, 'http://soundgasm.net/u/ytdl')
    assert match

# Generated at 2022-06-12 18:09:01.177474
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """ unit tests of class SoundgasmIE """
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    # instantiate class
    soundgasm = SoundgasmIE()
    # extract video info
    soundgasm.extract(url)
    # print video info

# Generated at 2022-06-12 18:09:19.702282
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-12 18:09:20.559959
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-12 18:09:27.391190
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.IE_NAME == 'SoundgasmProfileIE'
    assert ie.IE_DESC == 'Soundgasm Profile'
    assert ie._VALID_URL == SoundgasmProfileIE._VALID_URL
    assert ie._TEST == SoundgasmProfileIE._TEST


# Generated at 2022-06-12 18:09:38.474825
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Sample 1
    sg = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    # Check if _real_extract was called
    assert(sg.result['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9')
    # Sample 2
    sg = SoundgasmIE('http://soundgasm.net/u/ytdl/Instrumental-Piano-Sample-Music-Song')
    assert(sg.result['id'] == '7ef9dd917e7c8e10a21804acdab593b239f6c0dc')
    # Sample 3

# Generated at 2022-06-12 18:09:41.674670
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import sys
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    func = sys.modules['__main__'].__dict__['test_%s' % __name__]
    func(SoundgasmIE)


# Generated at 2022-06-12 18:09:47.264790
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE_NAME = 'soundgasm:profile'
    _VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    _TEST = {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    assert re.match(_VALID_URL, _TEST['url'])
    assert SoundgasmProfileIE._TEST is _TEST
    assert SoundgasmProfileIE.IE_NAME is IE_NAME


# Generated at 2022-06-12 18:09:50.900227
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:09:52.900254
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    a = SoundgasmIE({})
    assert a.ie_name == 'Soundgasm'


# Generated at 2022-06-12 18:09:54.134199
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .test_soundgasm import test_Soundgasm_Profile_IE
    test_Soundgasm_Profile_IE()

# Generated at 2022-06-12 18:09:54.557552
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-12 18:10:27.086230
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert 'soundgasm' in globals()
    assert 'SoundgasmIE' in globals()

test_SoundgasmIE()

# Generated at 2022-06-12 18:10:29.031289
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	SoundgasmIE().test()


# Generated at 2022-06-12 18:10:32.723475
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    ie._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')



# Generated at 2022-06-12 18:10:34.290087
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(download=True)

# Generated at 2022-06-12 18:10:36.629991
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    ie.download("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-12 18:10:37.994081
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    st = SoundgasmIE()
    assert st._VALID_URL
    assert st._TEST

# Generated at 2022-06-12 18:10:41.245793
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # This test case is the tokenization of an example
    streamer = {'name': 'Soundgasm', 'url': 'http://soundgasm.net/u/ytdl/Piano-sample'}
    assert streamer['url'] == SoundgasmIE().extract_url_info(streamer['url'])['url']

# Generated at 2022-06-12 18:10:44.190022
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Should be able to construct SoundgasmIE with a valid url
    assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

    # Should not be able to construct SoundgasmIE with an invalid url
    try:
        SoundgasmIE('http://soundgasm.net/u/ytdl/')
    except RegexNotFoundError:
        pass


# Generated at 2022-06-12 18:10:45.094634
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    parse(IE_NAME, 'http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:10:50.219140
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    m = SoundgasmIE('Soundgasm', 'soundgasm.net')
    assert m._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:11:29.185632
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasmIE = SoundgasmIE({})
    assert soundgasmIE.IE_NAME == 'soundgasm'

# Generated at 2022-06-12 18:11:30.937797
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    e = SoundgasmIE()
    # Make sure the constructor didn't crash
    assert e is not None

# Generated at 2022-06-12 18:11:40.442222
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """test_SoundgasmIE
    """
    test_obj = SoundgasmIE()
    assert test_obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:11:42.447746
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    constructor = SoundgasmIE()

# Generated at 2022-06-12 18:11:48.189593
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import merge_dicts
    from . import SoundgasmIE
    from . import SoundgasmProfileIE
    from . import unescapeHTML
    from . import get_element_by_id
    from . import get_elements_by_class
    from . import ExtractorError
    from . import clean_html

    # Given
    ytdl_url = 'http://soundgasm.net/u/ytdl'

    # When
    profile = SoundgasmProfileIE(SoundgasmIE,'SoundgasmProfileIE', merge_dicts({'ie_key': 'Soundgasm'},{}))
    webpage = profile._download_webpage(ytdl_url, 'ytdl')

# Generated at 2022-06-12 18:11:56.243253
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert SoundgasmProfileIE._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert SoundgasmProfileIE._TEST['info_dict'] == {'id': 'ytdl'}
    assert SoundgasmProfileIE._TEST['playlist_count'] == 1
    assert SoundgasmProfileIE.ie_key() == 'soundgasm:profile'
    assert SoundgasmProfileIE.suitable('http://soundgasm.net/u/ytdl')


# Generated at 2022-06-12 18:11:57.531971
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Assert that the constructor class SoundgasmProfileIE throws no exceptions
    return SoundgasmProfileIE(InfoExtractor())

# Generated at 2022-06-12 18:12:01.530330
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from . import extractor
    from .extractors import soundgasm
    # Test constructor of class SoundgasmProfileIE
    assert isinstance(soundgasm.SoundgasmProfileIE(),extractor.InfoExtractor)

# Generated at 2022-06-12 18:12:10.258051
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl/')
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl/#/')
    SoundgasmProfileIE('https://soundgasm.net/u/ytdl/')
    SoundgasmProfileIE('https://soundgasm.net/u/ytdl/#/')
    SoundgasmProfileIE('http://www.soundgasm.net/u/ytdl/')
    SoundgasmProfileIE('http://www.soundgasm.net/u/ytdl/#/')
    SoundgasmProfileIE('https://www.soundgasm.net/u/ytdl/')

# Generated at 2022-06-12 18:12:16.517249
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    #assert ie.extract('http://soundgasm.net/u/ytdl/Piano-sample') == '010082a2c802c5275bb00030743e75ad'


# Generated at 2022-06-12 18:13:49.428461
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	info_extractor_object = SoundgasmIE()
	assert(info_extractor_object.IE_NAME=='soundgasm')
	assert(info_extractor_object._VALID_URL ==r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')


# Generated at 2022-06-12 18:13:54.103210
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mobj = re.match(obj._VALID_URL, url)
    display_id = mobj.group('display_id')
    assert display_id == 'Piano-sample'

# Generated at 2022-06-12 18:13:56.478111
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	#Define a class object of class SoundgasmProfileIE
	soundgasm_profile_class = SoundgasmProfileIE()

# Generated at 2022-06-12 18:13:58.330094
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    t = SoundgasmProfileIE()
    assert t.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-12 18:14:04.845080
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    r = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    assert r._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:14:08.089269
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert isinstance(obj, SoundgasmProfileIE)


# Generated at 2022-06-12 18:14:13.087438
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import InfoExtractor
    from . import soundgasm # This import is needed to make sure that
                             # the class SoundgasmProfileIE is registered
    ie = InfoExtractor.get_info_extractor('SoundgasmProfileIE')
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, 'IE_NAME')
    assert hasattr(ie, '_TEST')
    assert hasattr(ie, '_real_extract')

# Generated at 2022-06-12 18:14:18.250520
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE._TEST = {'url': '', 'info_dict': {'id': ''}, 'playlist_count': 1, 'skip': True}
    SoundgasmProfileIE('', {'id': '', 'md5': '', 'title': '', 'ext': '', 'url': '', 'uploader': '', 'display_id': ''})

# Generated at 2022-06-12 18:14:21.291201
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio_url = 'https://soundgasm.net/u/ytdl/Piano-sample'
    soundgasmIE = SoundgasmIE(dict())
    soundgasmIE.extract(audio_url)


# Generated at 2022-06-12 18:14:24.558671
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    i = SoundgasmIE()
    assert i._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
test_SoundgasmIE()