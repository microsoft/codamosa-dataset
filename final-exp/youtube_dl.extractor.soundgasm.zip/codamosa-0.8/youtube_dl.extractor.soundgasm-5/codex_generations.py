

# Generated at 2022-06-12 18:06:57.349578
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:06:58.834706
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    a = SoundgasmIE()
    assert a is not None


# Generated at 2022-06-12 18:07:00.952643
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .soundgasm import SoundgasmProfileIE
    SoundgasmProfileIE("SoundgasmProfileIE", "Unit test for SoundgasmProfileIE")

# Generated at 2022-06-12 18:07:04.677439
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Testing class SoundgasmIE
    test_class_SoundgasmIE = SoundgasmIE()
    assert test_class_SoundgasmIE.IE_NAME == 'soundgasm'

# Generated at 2022-06-12 18:07:09.110668
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	from youtube_dl.YoutubeDL import YoutubeDL
	from youtube_dl.extractor import common
	common.quiet = True
	dl = YoutubeDL()
	test = SoundgasmIE()

# Generated at 2022-06-12 18:07:15.536372
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Unit test for constructor of class SoundgasmIE
    """
    sg_ie = SoundgasmIE('soundgasm')
    expected_name = 'soundgasm'
    name = sg_ie.ie_key()
    assert name == expected_name, 'Unexpected name [%s] expected [%s]' % (name, expected_name)

if __name__ == '__main__':
    test_SoundgasmIE()

# Generated at 2022-06-12 18:07:19.157030
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest
    from soundgasm_test import SoundgasmProfileIETest
    suite = unittest.TestLoader().loadTestsFromTestCase(SoundgasmProfileIETest)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-12 18:07:24.099289
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE(None)._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:07:27.716918
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    obj = SoundgasmIE(None)
    reobj = re.match(obj._VALID_URL, url)
    print(reobj.group('user'))


# Generated at 2022-06-12 18:07:34.253032
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE(): 
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'

    webpage = '<html>href="http://soundgasm.net/u/ytdl/Piano-sample"</html>'
    entries = [
            'http://soundgasm.net/u/ytdl/Piano-sample'
            ]

    assert entries == re.findall(r'href="([^"]+/u/%s/[^"]+)' % profile_id, webpage)

# Generated at 2022-06-12 18:07:39.503768
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from soundgasm import soundgasm
    SoundgasmIE()

# Generated at 2022-06-12 18:07:42.725575
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    iet = SoundgasmIE()
    assert iet.ie_key() == 'Soundgasm'
    assert iet.ie_name() == 'Soundgasm'

# Generated at 2022-06-12 18:07:45.896463
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    assert soundgasm.IE_NAME == 'soundgasm'
    assert soundgasm.ie_key() == 'Soundgasm'


# Generated at 2022-06-12 18:07:48.323542
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')._real_extract('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-12 18:07:55.136231
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    x = SoundgasmIE()
    assert x.IE_NAME == 'soundgasm'
    assert x._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:07:55.928965
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE

# Generated at 2022-06-12 18:08:04.742234
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Use the constructor to create an instance of SoundgasmIE,
    # and see if the returned information is correct
    ie = SoundgasmIE()
    info = ie.extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert info['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert info['display_id'] == 'Piano-sample'
    assert info['url'] == 'http://audio.soundgasm.net/u/ytdl/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    assert info['vcodec'] == 'none'
    assert info['title'] == 'Piano sample'

# Generated at 2022-06-12 18:08:13.853511
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    # test _real_extract
    # Passing in only the required parameters
    profile_id = 'ytdl'

# Generated at 2022-06-12 18:08:15.321327
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE(None)._VALID_URL == SoundgasmProfileIE._VALID_URL

# Generated at 2022-06-12 18:08:18.213877
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    _constructor_test(SoundgasmProfileIE, 'http://soundgasm.net/u/ytdl')

# Generated at 2022-06-12 18:08:38.434786
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasmIE = SoundgasmIE()
    assert soundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    match = soundgasmIE._VALID_URL.match(url)
    assert match.group('user') == 'ytdl' and match.group('display_id') == 'Piano-sample'
    assert soundgasmIE._real_extract(url)['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
   

# Generated at 2022-06-12 18:08:39.936246
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert isinstance(SoundgasmProfileIE, InfoExtractor)

# Generated at 2022-06-12 18:08:46.369256
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    expected_result = 'http://soundgasm.net/u/ytdl/Piano-sample.m4a'

    ie = SoundgasmIE()
    webpage = ie._download_webpage(url, 'test')
    audio_url = ie._search_regex(
        r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', webpage,
        'audio URL', group='url')

    assert audio_url == expected_result

# Generated at 2022-06-12 18:08:50.143881
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    ie.extract('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:08:51.947967
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE(None, None)


# Generated at 2022-06-12 18:08:58.370310
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmIE._TEST = {}
    SoundgasmProfileIE._TEST = {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_mincount': 1,
    }
    test_SoundgasmProfileIE.run()

if __name__ == '__main__':
    test_SoundgasmProfileIE()

# Generated at 2022-06-12 18:08:59.965171
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL == SoundgasmProfileIE._VALID_URL

# Generated at 2022-06-12 18:09:01.537118
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    inst = SoundgasmProfileIE()
    assert inst.IE_NAME == "Soundgasm Profile"

# Generated at 2022-06-12 18:09:03.623722
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    c = SoundgasmProfileIE()
    assert c.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-12 18:09:13.562923
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    # This is an example of a page on Soundgasm.net
    webpage_url = "http://soundgasm.net/u/ytdl/Piano-sample"

    # This is what we expect to be returned.
    expected_result = {
        'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
        'ext': 'm4a',
        'title': 'Piano sample',
        'description': 'Royalty Free Sample Music',
        'uploader': 'ytdl',
        'display_id': 'Piano-sample'
    }

    # Construct an instance of the SoundgasmIE class
    ie = SoundgasmIE()

    # Extract the page that was passed into the constructor
    result = ie.extract(webpage_url)

    #

# Generated at 2022-06-12 18:09:36.408523
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_obj = SoundgasmProfileIE()
    assert test_obj.IE_NAME == 'soundgasm:profile'
    assert test_obj._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:09:39.052020
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    new_inst = SoundgasmIE()

# Generated at 2022-06-12 18:09:41.560813
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert 'Soundgasm' in InfoExtractor.list_supported_ie(['Soundgasm']).keys()


# Generated at 2022-06-12 18:09:43.965722
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    This test verifies that it is possible to create an instance of class SoundgasmProfileIE.
    For more information, see https://github.com/rg3/youtube-dl/issues/1754
    """
    instance = SoundgasmProfileIE()

# Generated at 2022-06-12 18:09:49.484826
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:09:51.457686
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert hasattr(ie, '_VALID_URL')



# Generated at 2022-06-12 18:09:56.105985
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE()
    ie._download_webpage = lambda *a, **k: None
    SoundgasmIE._real_initialize()
    SoundgasmIE._real_extract(ie, url)


# Generated at 2022-06-12 18:09:58.131333
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_instance = SoundgasmIE()
    assert isinstance(test_instance, SoundgasmIE)


# Generated at 2022-06-12 18:10:01.816240
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	IE=SoundgasmProfileIE()

# Generated at 2022-06-12 18:10:06.458866
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from validators import url as urlcheck
    url = "Soundgasm url"
    inst = SoundgasmIE(url)                                          #test
test_SoundgasmIE()


# Generated at 2022-06-12 18:10:45.006963
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """just test that the url can be parsed"""
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE().suitable(url)
    SoundgasmIE()._real_extract(url)

# Generated at 2022-06-12 18:10:47.392297
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    audio_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    entry = ie.url_result(audio_url, 'Soundgasm')
    assert entry.get('id') == 'Piano-sample'
    assert entry.get('url').find(audio_url) > 0

# Generated at 2022-06-12 18:10:51.405054
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	""" Unit test for constructor of class SoundgasmProfileIE """
	
	try:
		assert SoundgasmProfileIE(None, None)
	except:
		print('Unit test failed')
	else:
		print('Unit test passed')

# Generated at 2022-06-12 18:10:55.977820
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        import soundgasmIE
    except Exception:
        print ("There is no class SoundgasmProfileIE");
        return 1

    url_test = "http://soundgasm.net/u/ytdl"
    test = SoundgasmProfileIE()
    try:
        test = test._real_extract(url_test)
        print ("init successed")
    except Exception:
        print ("init failed");
        return 1

    return 0

# Generated at 2022-06-12 18:10:57.303716
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	return SoundgasmProfileIE

# Generated at 2022-06-12 18:11:00.136563
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .dummy import DummyIE

    obj = DummyIE()
    obj.addcallback(obj.pafy._extract, obj.test_url, True)
    print(obj)

# Generated at 2022-06-12 18:11:03.703594
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Create an instance of class SoundgasmIE
    soundgasm_ie = SoundgasmIE()
    # test SoundgasmIE.extract
    soundgasm_ie.extract()


# Generated at 2022-06-12 18:11:08.412420
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    testurl = 'http://soundgasm.net/u/ytdl'
    instance = SoundgasmProfileIE()
    assert 'ytdl' in testurl
    assert instance.IE_NAME == 'soundgasm:profile'
    assert instance._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:11:11.937065
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    a = SoundgasmIE()
    a._real_extract("http://soundgasm.net/u/ytdl/Piano-sample")
    a.IE_NAME
    a._VALID_URL


# Generated at 2022-06-12 18:11:13.211966
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass

# Generated at 2022-06-12 18:11:48.551964
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmIE()
    obj_profile = SoundgasmProfileIE()
    assert obj.IE_NAME == obj_profile.IE_NAME
    assert obj.ie_key() == obj_profile.ie_key()
    assert obj.SUITABLE_DEFAULT == obj_profile.SUITABLE_DEFAULT

if __name__ == '__main__':
    test_SoundgasmProfileIE()

# Generated at 2022-06-12 18:11:56.546570
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import unittest
    class TestSoundgasmIE(unittest.TestCase):
        def test_constructor(self):
            soundgasmIE = SoundgasmIE(InfoExtractor())
            self.assertEqual(
                soundgasmIE.IE_NAME, 'soundgasm')
            self.assertEqual(
                soundgasmIE._VALID_URL,
                r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-12 18:12:00.718972
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    constructor = SoundgasmIE('test1')
    assert constructor.ie_key() == 'test1'
    assert constructor.ie_key() != 'test2'

# Generated at 2022-06-12 18:12:07.000190
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}

# Generated at 2022-06-12 18:12:09.260465
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-12 18:12:16.489850
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from youtube_dl import YoutubeDL
    from youtube_dl.extractor.soundgasm import SoundgasmIE
    from youtube_dl.utils import match1

    ydl = YoutubeDL()
    ydl = SoundgasmIE()
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    info_dict = ydl.extract(url)
    assert info_dict.get('url')
    assert info_dict.get('description')
    assert info_dict.get('uploader')
    assert info_dict.get('title')
    assert info_dict.get('id')
    assert info_dict.get('vcodec')



# Generated at 2022-06-12 18:12:19.942856
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    except NameError:  # Python 2 doesn't have check_valid_url() yet
        pass

# Generated at 2022-06-12 18:12:26.409255
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio = SoundgasmIE(None).extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert audio['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert audio['title'] == 'Piano sample'
    assert audio['url'] == 'http://api-v2.soundgasm.net/sounds/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
test_SoundgasmIE()

# Generated at 2022-06-12 18:12:36.411852
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest
    from youtube_dl.utils import unescapeHTML
    from unittest.mock import patch

    class TestSoundgasmProfileIE(unittest.TestCase):
        def setUp(self):
            self.ie = SoundgasmProfileIE('')
            self.ie._download_webpage = lambda url, display_id, note='', errnote='', fatal=True: url


# Generated at 2022-06-12 18:12:38.193431
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('Piano-sample', 'http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:14:11.391192
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

test_SoundgasmIE()

# Generated at 2022-06-12 18:14:12.469523
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	SoundgasmProfileIE('pataphysical')


# Generated at 2022-06-12 18:14:16.822145
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        from soundgasm import SoundgasmProfileIE
    except:
        print("Error: Failed to import SoundgasmProfileIE")
    else:
        print("Success: Imported SoundgasmProfileIE")


# Generated at 2022-06-12 18:14:18.863780
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:14:22.814707
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert SoundgasmProfileIE._TEST['info_dict']['id'] == 'ytdl'
    assert SoundgasmProfileIE._TEST['playlist_count'] == 1


# Generated at 2022-06-12 18:14:33.945333
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mobj = re.match(SoundgasmIE._VALID_URL, url)
    webpage = SoundgasmIE._download_webpage(url, mobj.group('display_id'))

    audio_url = SoundgasmIE._html_search_regex(
        r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', webpage,
        'audio URL', group='url')


# Generated at 2022-06-12 18:14:37.497604
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(SoundgasmProfileIE.ie_key())
    # check if name is same as in class
    print(ie.IE_NAME)
    assert ie.IE_NAME == "soundgasm:profile"
    # check if testing is working
    assert ie._TEST['info_dict']['id'] == "ytdl"
    # check if test url is working
    assert ie._TEST['url'] == "http://soundgasm.net/u/ytdl"

# Generated at 2022-06-12 18:14:38.672382
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie.valid_url('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:14:39.024227
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-12 18:14:42.901868
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None)._real_initialize()