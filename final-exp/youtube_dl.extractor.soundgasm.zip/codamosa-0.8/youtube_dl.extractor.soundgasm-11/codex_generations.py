

# Generated at 2022-06-12 18:06:59.257294
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'Soundgasm'
    assert ie._VALID_URL == 'http://soundgasm\.net/u/(?P<user>.+)/(?P<display_id>.+)'


# Generated at 2022-06-12 18:07:04.330093
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert ie._TEST['info_dict'] == {'id': 'ytdl'}
    assert ie._TEST['playlist_count'] == 1

# Generated at 2022-06-12 18:07:05.700873
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        SoundgasmProfileIE()
    except TypeError:
        assert 1==1
    except:
        assert 1==0

# Generated at 2022-06-12 18:07:06.680650
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('test')

# Generated at 2022-06-12 18:07:13.174421
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    PlaylistConstructor = SoundgasmProfileIE()
    AudioConstructor = SoundgasmIE()
    webpage = "<html><body><div><a href='http://soundgasm.net/u/ytdl/Piano-sample'></a></div></body></html>"
    audio_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    playlist_id = 'ytdl'
    audio_id = 'Piano-sample'
    assert PlaylistConstructor._real_extract(webpage, playlist_id) == AudioConstructor._real_extract(audio_url, audio_id)


# Generated at 2022-06-12 18:07:15.670348
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:07:17.142192
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	obj_IE=SoundgasmIE()

# Generated at 2022-06-12 18:07:25.148190
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == "Soundgasm"
    assert ie._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)"

# Generated at 2022-06-12 18:07:28.985112
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_ = type('test_',(object,),{})
    test_.args = [None]
    test_.add_default_error_handler = lambda *args, **kwargs : None
    test_.IE_NAME = 'SoundgasmProfileIE'

    SoundgasmProfileIE(test_)

# Generated at 2022-06-12 18:07:33.204480
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    t = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert t._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert t._SUCCESS == True
    assert t._downloader.params['noprogress'] == True

# Generated at 2022-06-12 18:07:48.150964
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    testargs = ["test_SoundgasmIE.py",
                "--username", "test_username",
                "--id", "test_id"
                ]
    with open('test_SoundgasmIE.json','r') as file:
        test_SoundgasmIE_json = json.loads(file.read())
    assert test_SoundgasmIE_json == ydl.process_ie_result(
        InfoExtractor().extract("https://soundgasm.net/u/test_username/test_id"), test_SoundgasmIE_json)

# Generated at 2022-06-12 18:07:54.861477
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    user = 'ytdl'
    ie = SoundgasmProfileIE(url, user)
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


if __name__ == '__main__':
    test_SoundgasmProfileIE()

# Generated at 2022-06-12 18:07:57.618630
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert not ie == None


# Generated at 2022-06-12 18:08:03.105006
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_ie = SoundgasmIE()
    mobj = test_ie._VALID_URL
    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mobj = test_ie._VALID_URL
    mobj = re.match(mobj, test_url)
    assert mobj.group('user') == 'ytdl'
    assert mobj.group('display_id') == 'Piano-sample'



# Generated at 2022-06-12 18:08:04.393143
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None, 'http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:08:08.537863
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    #url = "http://soundgasm.net/u/ytdl"
    ret = SoundgasmIE()._real_extract(url)
    print(ret)
    pass

# Generated at 2022-06-12 18:08:11.606638
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'

    SoundgasmIE()._real_initialize()
    SoundgasmIE().suitable(url)
    SoundgasmIE()._real_extract(url)


# Generated at 2022-06-12 18:08:13.309330
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info_extractor = SoundgasmIE()
    print(info_extractor.IE_NAME)

# Generated at 2022-06-12 18:08:15.139553
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import TestCase
    from .test_soundcloud import TestSoundcloudIE
    TestCase(TestSoundcloudIE).run(SoundgasmProfileIE)

# Generated at 2022-06-12 18:08:22.171563
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import soundgasm
    profile_user = soundgasm.SoundgasmProfileIE('ytdl')
    assert profile_user.IE_NAME == "soundgasm:profile"
    assert profile_user.display_id == "ytdl"
    assert profile_user.url == "http://soundgasm.net/u/ytdl"

# Generated at 2022-06-12 18:08:38.278416
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'


# Generated at 2022-06-12 18:08:42.491489
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  # Create an instance of SoundgasmProfileIE
  soundgasm_profile_ie = SoundgasmProfileIE();
  # Set the value for "url" of class SoundgasmProfileIE to a known value
  soundgasm_profile_ie.url = "http://soundgasm.net/u/ytdl"

# Generated at 2022-06-12 18:08:46.114067
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    my_SoundgasmProfileIE = SoundgasmProfileIE()
    my_SoundgasmProfileIE.get_url()
    my_SoundgasmProfileIE.get_login_info()
    my_SoundgasmProfileIE.extract()
    print ("Unit tests for class SoundgasmProfileIE complete.")

# Generated at 2022-06-12 18:08:51.249548
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Case 1: Test for constructor of class SoundgasmIE 
    """
    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'

# Generated at 2022-06-12 18:08:55.945074
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE().IE_NAME == 'Soundgasm:profile'
    assert SoundgasmProfileIE()._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:08:56.560763
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass

# Generated at 2022-06-12 18:08:58.101702
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Unit test for class SoundgasmProfileIE"""
    SoundgasmProfileIE("SoundgasmProfileIE", "soundgasm", "soundgasm.net/u/ytdl/")


# Generated at 2022-06-12 18:09:05.795687
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    class SoundgasmProfileIE_test(SoundgasmProfileIE):
        def _download_webpage(self, url, display_id):
            return 'href="/u/ytdl/Piano-sample"'

    ie = SoundgasmProfileIE_test(None)
    # Use a utf-8 encoded string instead of a str instance
    # See http://stackoverflow.com/q/59895#59938
    ytdl_result = '<html></html>'.encode('utf-8')
    ie._download_webpage = lambda url: ytdl_result
    result = ie.extract('http://soundgasm.net/u/ytdl')
    assert result['id'] == 'ytdl'
    assert result['entries'][0]['title'] == 'Piano sample'

# Generated at 2022-06-12 18:09:07.033468
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-12 18:09:08.026644
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-12 18:09:27.696917
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	sg = SoundgasmIE()
	assert isinstance(sg, InfoExtractor)


# Generated at 2022-06-12 18:09:28.717332
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    t = SoundgasmIE()


# Generated at 2022-06-12 18:09:36.097649
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Unit test for constructor of class SoundgasmIE
    s = SoundgasmIE('http://www.soundgasm.net/u/ytdl/Piano-sample')
    assert(s.__class__.__name__ == 'SoundgasmIE')
    assert(s.valid_url == 'http://www.soundgasm.net/u/ytdl/Piano-sample')
    assert(s.user == 'ytdl')
    assert(s.display_id == 'Piano-sample')

# Generated at 2022-06-12 18:09:36.705200
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	pass

# Generated at 2022-06-12 18:09:38.652478
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from YouTubeAudioDownloader.soundgasm import SoundgasmProfileIE
    assert SoundgasmProfileIE

# Generated at 2022-06-12 18:09:42.435389
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    result = SoundgasmIE()._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert(result['title'] == 'Piano sample')
    assert(result['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9')

# Generated at 2022-06-12 18:09:44.778219
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    inst = SoundgasmProfileIE()
    assert inst._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:09:48.491828
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    SoundgasmProfileIE()._real_extract(url)

# Generated at 2022-06-12 18:09:59.630851
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import re
    import unittest

    class TestSoundgasmProfileIE(unittest.TestCase):
        def test_construct(self):
            test_url='https://soundgasm.net/u/ytdl'
            assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
            assert SoundgasmProfileIE(test_url)
            assert SoundgasmProfileIE.test()
            assert SoundgasmProfileIE._TEST['url'] == test_url
            assert SoundgasmProfileIE._TEST['info_dict']['id'] == 'ytdl'

    suite = unittest.TestLoader().loadTestsFromTestCase(TestSoundgasmProfileIE)

# Generated at 2022-06-12 18:10:00.169123
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == 'soundgasm'


# Generated at 2022-06-12 18:10:40.524766
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    for input_url in SoundgasmIE._TEST.get('url'):
        #test should return
        #test should return
        output_dict = {'id': u'88abd86ea000cafe98f96321b23cc1206cbcbcc9', 'display_id': u'Piano-sample', 'ext': u'm4a',
                       'description': u'Royalty Free Sample Music', 'title': u'Piano sample',
                       'url': u'http://soundgasm.net/storage/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a',
                       'uploader': u'ytdl'}
        #print output_dict
        assert SoundgasmIE._real_extract(SoundgasmIE(), input_url) == output_dict


# Generated at 2022-06-12 18:10:45.737348
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    t = SoundgasmIE()
    t._TEST = {}
    t._TEST['url'] = 'http://soundgasm.net/u/ytdl/Piano-sample'
    t._TEST['extract_flat'] = 'Piano sample.m4a'

# Generated at 2022-06-12 18:10:55.130750
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL ==\
           r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:11:05.966237
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    '''
    Unit test for constructor of class SoundgasmProfileIE
    '''
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert SoundgasmProfileIE._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}
    # Turn off timeouts
    test_inst = SoundgasmProfileIE()
    test_inst._downloader.params.update({'noprogress': True, 'retries': 0})
    test_inst._downloader.params.update({'proxy': None})
    # test valid URL
    test_

# Generated at 2022-06-12 18:11:14.592689
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	# Test case 1: when profile ID is 'ytdl'
	profile_ie = SoundgasmProfileIE(1, 'http://soundgasm.net/u/ytdl')
	assert profile_ie.IE_NAME == 'soundgasm:profile', 'name of class'
	assert profile_ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$', '_VALID_URL'
	assert profile_ie._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1},\
	'_TEST'

# Generated at 2022-06-12 18:11:16.070723
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-12 18:11:18.398900
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie.url == 'http://soundgasm.net/u/ytdl/Piano-sample'


# Generated at 2022-06-12 18:11:20.964848
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-12 18:11:21.490479
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-12 18:11:26.549232
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == "soundgasm:profile"
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-12 18:12:35.646034
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """ Unit test for constructor of class SoundgasmProfileIE<P>
        Test valid input.
    """
    # test valid input
    profile_ie = SoundgasmProfileIE('yt_dl')
    assert profile_ie.IE_NAME == 'soundgasm:profile'
    profile_ie = SoundgasmProfileIE('yt_dl', {})
    assert profile_ie.IE_NAME == 'soundgasm:profile'



# Generated at 2022-06-12 18:12:36.443044
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-12 18:12:37.501042
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(isinstance(SoundgasmProfileIE(), InfoExtractor))


# Generated at 2022-06-12 18:12:42.716167
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'
    assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl', 
        'info_dict': {'id': 'ytdl',}, 
        'playlist_count': 1,}
    assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-12 18:12:48.242540
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert re.match(SoundgasmProfileIE._VALID_URL, 'http://soundgasm.net/u/ytdl')
    assert re.match(SoundgasmProfileIE._VALID_URL, 'http://soundgasm.net/u/ytdl/#')
    assert not re.match(SoundgasmProfileIE._VALID_URL, 'http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:12:50.069508
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	soundgasmIE = SoundgasmIE("%s" % sys.argv[1])
	print("Done")


# Generated at 2022-06-12 18:12:56.731845
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()

    ie_test = ie.IE_NAME

    test_url = ie._TEST['url']
    test_md5 = ie._TEST['md5']
    test_info_dict = ie._TEST['info_dict']

    mobj = re.match(ie._VALID_URL, test_url)
    display_id = mobj.group('display_id')

    webpage = ie._download_webpage(test_url, display_id)

    audio_url = ie._html_search_regex(
        r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', webpage,
        'audio URL', group='url')


# Generated at 2022-06-12 18:12:58.233260
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE()
    print(profile.__dict__)

# Generated at 2022-06-12 18:13:04.339574
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-12 18:13:08.814143
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-12 18:16:03.837766
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        SoundgasmProfileIE('https://www.soundgasm.net/u/ytdl')
    except:
        print("Exception raised in"
            + " SoundgasmProfileIE(https://www.soundgasm.net/u/ytdl).\n"
            + "I don't know why.")

# Generated at 2022-06-12 18:16:08.634867
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from functools import partial
    import doctest
    SoundgasmProfileIE.suite = lambda self: doctest.DocTestSuite(soundgasm, extraglobs={"s": SoundgasmProfileIE()})
    __test__ = {'test_SoundgasmProfileIE': SoundgasmProfileIE}

# Generated at 2022-06-12 18:16:10.185949
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
  tester = SoundgasmIE()
  tester.to_screen("Test Successfull, added SoundgasmIE to list of extractors")

# Generated at 2022-06-12 18:16:11.463420
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'


# Generated at 2022-06-12 18:16:18.078094
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("Testing SoundgasmIE")
    metadata = SoundgasmIE._real_extract("http://soundgasm.net/u/ytdl/Piano-sample")
    print("id: " + metadata['id'])
    print("title: " + metadata['title'])
    print("uploader: " + metadata['uploader'])
    print("url: " + metadata['url'])
    print("vcodec: " + metadata['vcodec'])

    # Testing for id
    assert(metadata['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9')
    # Testing for title
    assert(metadata['title'] == 'Piano sample')
    # Testing for uploader
    assert(metadata['uploader'] == 'ytdl')
    # Testing for

# Generated at 2022-06-12 18:16:19.162791
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    i = SoundgasmProfileIE()
    assert(i.IE_NAME == 'soundgasm:profile')

# Generated at 2022-06-12 18:16:25.629993
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
        print("Testing SoundgasmProfileIE")
        ie = SoundgasmProfileIE()
        display_id = 'ytdl'
        url = 'http://soundgasm.net/u/ytdl'
        webpage = ie._download_webpage(url, display_id)

        entries = [
            ie.url_result(audio_url, 'Soundgasm')
            for audio_url in re.findall(r'href="([^"]+/u/%s/[^"]+)' % display_id, webpage)]
        
        print(entries)
        print(entries[0])
        
test_SoundgasmProfileIE()

# Generated at 2022-06-12 18:16:28.559035
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert isinstance(ie._VALID_URL, re._pattern_type)
    assert isinstance(ie.IE_NAME, basestring)
    assert ie.IE_NAME == ie.ie_key()


# Generated at 2022-06-12 18:16:32.849342
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from . import SoundgasmIE
    test_cases=['http://soundgasm.net/u/ytdl/Piano-sample']
    urls=dict((test_case,SoundgasmIE(test_case)._real_extract()) for test_case in test_cases)
    return urls


# Generated at 2022-06-12 18:16:34.764953
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    inst = SoundgasmIE()
    assert inst.IE_NAME == "Soundgasm"

# Test instance of class SoundgasmIE