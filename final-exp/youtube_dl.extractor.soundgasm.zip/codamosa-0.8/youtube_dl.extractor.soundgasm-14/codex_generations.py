

# Generated at 2022-06-12 18:07:02.390820
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()
    assert obj.IE_NAME == 'soundgasm:profile'
    assert obj._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert obj._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-12 18:07:05.294689
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    print(ie.IE_NAME)

# Generated at 2022-06-12 18:07:09.838431
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url_profile = 'http://soundgasm.net/u/ytdl'
    url_audio = 'http://soundgasm.net/u/ytdl/Piano-sample'

    ie = SoundgasmProfileIE(url_profile)
    assert ie.url == url_profile
    ie = SoundgasmProfileIE(url_audio)
    assert ie.url == url_profile

# Generated at 2022-06-12 18:07:12.397344
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        soundgasm_ie = SoundgasmIE();
    except NameError as e:
        raise AssertionError(str(e))

# Generated at 2022-06-12 18:07:16.475846
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	soundgasm_ie = SoundgasmIE()
	expected_ie_name = 'soundgasm'
	ie_name = soundgasm_ie.IE_NAME
	assert expected_ie_name == ie_name


# Generated at 2022-06-12 18:07:17.535195
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://test.test')

# Generated at 2022-06-12 18:07:20.530774
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    _stub_SoundgasmProfileIE = SoundgasmProfileIE(None)
    assert isinstance(_stub_SoundgasmProfileIE, SoundgasmProfileIE)
    assert isinstance(_stub_SoundgasmProfileIE, InfoExtractor)


# Generated at 2022-06-12 18:07:30.414146
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SG = SoundgasmIE()
    assert(SG.ie_key() == 'Soundgasm')
    assert(SG.IE_NAME == 'soundgasm')
    assert(SG.SUCCESS_REGEX == None)
    assert(SG._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-12 18:07:38.581157
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg_profile = SoundgasmProfileIE()
    assert(sg_profile.IE_NAME == 'soundgasm:profile')
    assert(sg_profile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
    assert(sg_profile._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1})


# Generated at 2022-06-12 18:07:43.441777
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_case = {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    a = SoundgasmProfileIE().suite()

# Generated at 2022-06-12 18:07:48.367562
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-12 18:07:52.257226
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    ie = SoundgasmIE()
    oe = ie.extract(url)
    assert oe['display_id'] == 'Piano-sample'
    assert oe['title'] == 'Piano sample'
    assert oe['uploader'] == 'ytdl'

# Generated at 2022-06-12 18:07:53.840065
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(1 == 2)

# Generated at 2022-06-12 18:07:59.123210
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    instance = SoundgasmIE(SoundgasmIE._VALID_URL)
    test_dict = SoundgasmIE._TEST
    instance._real_extract(test_url) == test_dict

# Generated at 2022-06-12 18:08:06.436254
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-12 18:08:09.612047
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    get_playlist_result = SoundgasmProfileIE()._real_extract(
    "https://soundgasm.net/u/ytdl")
    print(get_playlist_result)


# Generated at 2022-06-12 18:08:17.422497
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE()
    assert soundgasm_profile_ie.IE_NAME == 'soundgasm:profile'
    assert soundgasm_profile_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert soundgasm_profile_ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert soundgasm_profile_ie._TEST['info_dict'] == {'id': 'ytdl'}
    assert soundgasm_profile_ie._TEST['playlist_count'] == 1



# Generated at 2022-06-12 18:08:23.889383
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    ie._download_webpage('http://soundgasm.net/u/ytdl', 'ytdl')
    ie.playlist_result(['http://soundgasm.net/u/ytdl/Piano-sample'], 'ytdl')

# Generated at 2022-06-12 18:08:32.605959
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    sg_ie = SoundgasmIE()
    result = sg_ie.extract(url)
    assert(result['id'] == "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
            and result['url'] == "http://file.soundgasm.net/u/ytdl/Piano-sample.m4a"
            and result['vcodec'] == 'none'
            and result['title'] == "Piano sample")

# Generated at 2022-06-12 18:08:43.864682
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample/')
    assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample/#')
    assert SoundgasmIE('http://www.soundgasm.net/u/ytdl/Piano-sample/')
    assert SoundgasmIE('http://www.soundgasm.net/u/ytdl/Piano-sample/#')
    assert SoundgasmIE('soundgasm.net/u/ytdl/Piano-sample')
    assert SoundgasmIE('soundgasm.net/u/ytdl/Piano-sample/')
    assert Soundgasm

# Generated at 2022-06-12 18:08:52.617984
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None).assert_success(
        'http://soundgasm.net/u/ytdl', 'http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-12 18:08:54.011693
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_case = SoundgasmProfileIE()
    assert test_case is not None

# Generated at 2022-06-12 18:08:58.055765
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample';
    from test_constructor import test_constructor
    print("test_constructor:")
    test_constructor(SoundgasmIE, test_url)

# Generated at 2022-06-12 18:09:00.053895
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Tests that the constructor works properly
    SoundgasmIE('http://www.soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:09:04.966945
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info_extractor = SoundgasmProfileIE()
    assert info_extractor.IE_NAME == 'soundgasm:profile'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-12 18:09:14.057190
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	info_extractor = SoundgasmIE()
	assert info_extractor.IE_NAME == 'soundgasm'
	assert info_extractor._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:09:14.787090
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-12 18:09:17.066033
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    a = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert a.ie_key() == 'Soundgasm'
    assert a.provider() == 'Soundgasm'

# Generated at 2022-06-12 18:09:21.821859
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    # Test for constructor of class `SoundgasmProfileIE`
    url = 'http://soundgasm.net/u/ytdl'

    profile = SoundgasmProfileIE(url)

    assert profile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert profile.IE_NAME == 'soundgasm:profile'
    assert profile.test_url == 'http://soundgasm.net/u/ytdl'
    assert profile.test['url'] == 'http://soundgasm.net/u/ytdl'
    assert profile.test['playlist_count'] == 1
    assert profile.id() == 'ytdl'



# Generated at 2022-06-12 18:09:33.621214
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .common import fake_urlopen
    from .common import compat_urlparse
    from .common import ExtractorError
    fake_response = compat_urlparse.parse_qs('title=Piano+sample&uri=88abd86ea000cafe98f96321b23cc1206cbcbcc9&type=audio/x-m4a&bitrate=64&duration=7636')
    result = SoundgasmIE._extract_jwplayer_data(fake_urlopen(fake_response))
    assert result['title'] == 'Piano sample'

# Generated at 2022-06-12 18:09:43.969842
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE.IE_NAME)
    assert(SoundgasmProfileIE._VALID_URL)
    assert(SoundgasmProfileIE(None)._VALID_URL == SoundgasmProfileIE._VALID_URL)


# Generated at 2022-06-12 18:09:56.230612
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # code to create obj
    yt = SoundgasmIE()

    # testing to see if url exists
    def test_url():
        url = 'http://soundgasm.net/u/ytdl/Piano-sample'
        yt.url = url
        yt.extract()
        test_url.actualresult = yt.url
  
    # testing to see if _VALID_URL exists
    def test_valid_url():
        valid_url = r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
        yt._VALID_URL = valid_url
        test_valid_url.actualresult = valid_url

# Generated at 2022-06-12 18:09:58.789468
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('www.test-youtube-dl.com', {})
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.valid_url('https://www.soundgasm.net/u/ytdl', 'ytdl')



# Generated at 2022-06-12 18:10:00.049849
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-12 18:10:02.403256
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # URL
    url = 'http://soundgasm.net/u/ytdl'
    test_SoundgasmProfileIE = SoundgasmProfileIE(url)
    assert test_SoundgasmProfileIE.IE_NAME == 'SoundgasmProfileIE'
    # xmlfile - empty string
    xmlfile = ''
    test_SoundgasmProfileIE = SoundgasmProfileIE(xmlfile)
    assert test_SoundgasmProfileIE.IE_NAME == 'SoundgasmProfileIE'

# Generated at 2022-06-12 18:10:09.547924
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert obj.ie_key() == 'Soundgasm'
    assert obj.ie_name() == 'Soundgasm'
    assert obj.SUCCESS == obj.validate_url('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:10:14.105233
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	from soundgasm import SoundgasmIE
	#obj = SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')
	obj = SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')
	print(obj)

# Generated at 2022-06-12 18:10:14.934003
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-12 18:10:17.687704
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('88abd86ea000cafe98f96321b23cc1206cbcbcc9', 'Ytdl', 'Piano sample', 'Royalty Free Sample Music')

# Generated at 2022-06-12 18:10:19.989331
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test one class of SoundgasmIE is created as expected
    obj = SoundgasmIE()
    assert obj is not None

# Generated at 2022-06-12 18:10:40.951567
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Can not have unit test for class SoundgasmIE
    pass

# Generated at 2022-06-12 18:10:45.330159
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE(None)._VALID_URL == SoundgasmProfileIE._VALID_URL)
    assert(SoundgasmProfileIE(None).IE_NAME == SoundgasmProfileIE._NAME)

# Generated at 2022-06-12 18:10:54.845041
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
            'playlist_count': 1
        }
    }

# Generated at 2022-06-12 18:10:55.347221
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    return

# Generated at 2022-06-12 18:11:02.329337
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Unit test for constructor of class SoundgasmIE
    """
    # Download a file and check if it has the correct title.
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE(url)
    assert ie.download_url(url).title == 'Piano sample'
    ie._download_url('http://soundgasm.net/u/ytdl/Piano-sample')



# Generated at 2022-06-12 18:11:11.557131
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-12 18:11:12.433266
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()

# Generated at 2022-06-12 18:11:19.615855
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Does it work with 'no audio yet' case?
    IE = SoundgasmProfileIE('https://soundgasm.net/u/ytdl_new')
    m = IE._TEST
    profile_id = m['id']
    webpage = IE._download_webpage(m['url'], profile_id)
    entries = [
        IE.url_result(audio_url, m['IE_NAME'])
            for audio_url in re.findall(r'href="([^"]+/u/%s/[^"]+)' % profile_id, webpage)]
    playlist_result = IE.playlist_result(entries, profile_id)
    # Does it work with 'empty' case?
    IE = SoundgasmProfileIE('https://soundgasm.net/u/ytdl_new_empty')

# Generated at 2022-06-12 18:11:26.922460
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl/'
    url2 = 'http://www.soundgasm.net/u/ytdl/#'
    url3 = 'http://soundgasm.net/u/ytdl'
    url4 = 'http://soundgasm.net/u/ytdl/#'
    url5 = 'http://soundgasm.net/u/ytdl/#'
    url6 = 'http://soundgasm.net/u/ytdl/Piano-sample'

    assert SoundgasmProfileIE.suitable(url)
    assert SoundgasmProfileIE.suitable(url2)
    assert SoundgasmProfileIE.suitable(url3)
    assert SoundgasmProfileIE.suitable(url4)
    assert SoundgasmProfileIE.suitable

# Generated at 2022-06-12 18:11:28.846069
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == 'soundgasm'


# Generated at 2022-06-12 18:12:03.530968
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	SoundgasmProfileIE("http://soundgasm.net/u/ytdl")._real_extract("http://soundgasm.net/u/ytdl")

# Generated at 2022-06-12 18:12:08.931532
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(None)
    assert isinstance(ie, SoundgasmProfileIE)
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.KEY_DEFAULT == 'display_id'

# Generated at 2022-06-12 18:12:12.592940
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert (
        SoundgasmIE._get_media_from_page(
            'http://soundgasm.net/u/ytdl/Piano-sample', {})._html
        is '010082a2c802c5275bb00030743e75ad')


# Generated at 2022-06-12 18:12:21.314016
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://www.soundgasm.net/u/test')
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-12 18:12:30.352061
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test most basic case
    # Create temp file as audio stream
    audio_stream = open("audio-file.m4a", 'w')
    audio_stream.write("This file is only for testing purposes. Please remove this file after testing the program")
    audio_stream.close()

    # Create extractor and extract
    extractor = SoundgasmIE()
    extractor_result = extractor.extract("http://soundgasm.net/u/ytdl/Piano-sample")

    # Check if extractor result is as expected

# Generated at 2022-06-12 18:12:39.684075
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    e = SoundgasmIE()
    assert e.IE_NAME == 'soundgasm'
    assert e.TITLE_REGEX == r'<div[^>]+\bclass=["\']jp-title[^>]+>([^<]+)'
    assert e._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:12:42.309626
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg_profile_ie = SoundgasmProfileIE()
    assert sg_profile_ie.IE_NAME == 'soundgasm:profile'
    assert re.match(sg_profile_ie._VALID_URL, 'http://soundgasm.net/u/ytdl')


# Generated at 2022-06-12 18:12:43.556173
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()._VALID_URL == SoundgasmIE._VALID_URL


# Generated at 2022-06-12 18:12:50.505790
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_class = SoundgasmIE()
    assert(test_class.params is None)
    assert(test_class.videoinfo_dict is None)
    assert(test_class._ies is None)
    assert(test_class._downloader is None)
    assert(test_class.extractor is None)
    assert(test_class.info_extractors is None)
    assert(test_class.ie_key2id is None)
    assert(test_class.ie_key2name is None)
    assert(test_class.ie_key is None)


# Generated at 2022-06-12 18:12:51.276915
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    constructor_test(SoundgasmProfileIE)

# Generated at 2022-06-12 18:14:24.559210
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Basic test for SoundgasmProfileIE constructor
    """
    assert SoundgasmProfileIE

# Generated at 2022-06-12 18:14:27.989076
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    Profile = __import__('soundgasm.SoundgasmProfileIE', fromlist=(
        'get_info_extractor', 'get_default_extractor'
    ))
    profile = Profile.get_info_extractor('soundgasm.net/u/ytdl')
    assert profile.IE_NAME == 'soundgasm:profile'
    assert profile.ie_key() == 'SoundgasmProfile'

# Generated at 2022-06-12 18:14:29.081088
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    print(ie._VALID_URL)
    print(ie._TEST)

# Generated at 2022-06-12 18:14:31.005049
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Just makes sure that the class gets properly created
    It can't be tested by other means as
    the parent class requires to download a webpage
    """
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-12 18:14:39.009494
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    video = SoundgasmIE()._real_extract(url)
    audioId = video['id']
    audioUrl = video['url']
    title = video['title']
    description = video['description']
    assert audioId == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert audioUrl == 'http://d3njx5w5n3q5r5.cloudfront.net/assets/24/88abd86ea000cafe98f96321b23cc1206cbcbcc9/original.m4a?1466435578'
    assert title == 'Piano sample'
    assert description == 'Royalty Free Sample Music'


# Generated at 2022-06-12 18:14:49.151742
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-12 18:14:56.848895
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Expected initial values
    title = 'ytdl - Soundgasm.net'
    profile_id = 'ytdl'
    url = 'http://soundgasm.net/u/ytdl'
    webpage = '<html></html>'
    
    # Create new instance of class SoundgasmProfileIE
    new_profile = SoundgasmProfileIE()
    new_profile._TEST = {
        'title': title,
        'url': url,
        'webpage': webpage,
    }
    new_profile._VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    
    # Call _real_extract
    new_profile._real_extract(url)
    


# Generated at 2022-06-12 18:14:57.377876
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-12 18:15:01.906592
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.__module__ == 'youtube_dl.extractor.soundgasm'

# Generated at 2022-06-12 18:15:04.180917
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    Audio = SoundgasmIE(_TEST)
    Testaudio = Audio.test()
    Testaudio.assertTrue(Testaudio)
