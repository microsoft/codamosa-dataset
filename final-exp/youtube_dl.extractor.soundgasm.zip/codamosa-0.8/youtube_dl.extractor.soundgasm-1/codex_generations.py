

# Generated at 2022-06-12 18:06:59.208191
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    ie.download('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-12 18:07:00.032430
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-12 18:07:03.719319
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE()
    assert soundgasm_profile_ie.url_result('MyUrl', 'MyIE')



# Generated at 2022-06-12 18:07:08.224750
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    valid_url = "http://soundgasm.net/u/ytdl"
    object = SoundgasmProfileIE( '', '')
    object.add_info_extractor( 'Soundgasm', SoundgasmProfileIE.ie_key() )
    assert object.suitable('', valid_url) == False

# Generated at 2022-06-12 18:07:09.718060
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()
    print("It works! SoundgasmIE can be instantiated!")


# Generated at 2022-06-12 18:07:11.793844
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test without argument
    youtube_dl = SoundgasmIE()
    
    # Test with argument
    youtube_dl = SoundgasmIE(SoundgasmIE())


# Generated at 2022-06-12 18:07:14.518647
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:07:16.640349
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    #print(SoundgasmIE._TEST)
    a = SoundgasmIE()
    #print(a._TEST)

    #print(a._VALID_URL)
    #print(re.match(a._VALID_URL, 'http://soundgasm.net/u/ytdl/Piano-sample'))
    print(a._real_extract('http://soundgasm.net/u/ytdl/Piano-sample'))


# Generated at 2022-06-12 18:07:22.157798
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample', 'post')
    assert IE.get_video_url() == 'http://assets.soundgasm.net/sounds/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    assert IE.get_video_title() == 'Piano sample'
    assert IE.get_video_description() == 'Royalty Free Sample Music'
    assert IE.get_video_uploader() == 'ytdl'

# Generated at 2022-06-12 18:07:24.865068
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.url == 'http://soundgasm.net/u/ytdl'

# Generated at 2022-06-12 18:07:37.739923
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == 'soundgasm'
    assert hasattr(SoundgasmIE(), '_VALID_URL')
    assert SoundgasmIE()._VALID_URL == SoundgasmIE._VALID_URL
    assert SoundgasmIE()._TEST == SoundgasmIE._TEST

# Generated at 2022-06-12 18:07:39.602422
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	i = SoundgasmProfileIE()
	assert i.IE_NAME == "soundgasm:profile"
	return

# Generated at 2022-06-12 18:07:50.014500
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test = {
        'info': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    o = SoundgasmProfileIE()
    o._download_webpage = lambda id, url, note=None: None
    o._match_id = lambda self, url: None
    o.playlist_result = lambda id, entries: None
    o.url_result = lambda url, ie: None
    # assertEqual is used instead of assertAlmostEqual because of the floating number arithmetic
    # assertAlmostEqual is used because the result of the multiplication may be rounded,
    # which will cause a different number to be used as the comparison result.
    # see reference: https://docs.python.org/2/library/unittest.html#unittest.TestCase.assertEqual


# Generated at 2022-06-12 18:07:56.473363
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    class_SoundgasmProfileIE = SoundgasmProfileIE()
    assert class_SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-12 18:07:59.517123
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE()
    profile._downloader = None # hack to prevent downloading of the profile
    profile.download('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-12 18:08:05.819699
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-12 18:08:06.581067
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass

# Generated at 2022-06-12 18:08:11.195432
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """The constructor of class SoundgasmIE"""
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    soundgasmIE = SoundgasmIE()
    print(soundgasmIE)
    # assert (soundgasmIE._VALID_URL == '')
    # print(soundgasmIE._VALID_URL)

# Generated at 2022-06-12 18:08:14.644426
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Arrange
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'

    # Act
    ie = SoundgasmProfileIE()

    # Assert
    assert ie._match_id(url) == profile_id

# Generated at 2022-06-12 18:08:27.470092
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("Entering")
    Soundgasm = SoundgasmIE()
    Soundgasm.ie_key = 'Soundgasm'
    Soundgasm.set_media_url("http://soundgasm.net/u/ytdl/Piano-sample")
    print("is_valid_url=%s" % Soundgasm.is_valid_url("http://soundgasm.net/u/ytdl/Piano-sample"))
    print("ext=%s" % Soundgasm.ext)
    print("display_id=%s" % Soundgasm.display_id)
    print("id=%s" % Soundgasm.id)
    print("info_dict=%s" % Soundgasm.info_dict)
    print("ie_key=%s" % Soundgasm.ie_key)


# Generated at 2022-06-12 18:08:43.329719
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Tests for constructor of class SoundgasmIE"""

    # In this test, we are trying to instantiate class SoundgasmIE
    # with a valid URL to the website.
    soundgasm_ie = SoundgasmIE(url = "http://soundgasm.net/u/ytdl/Piano-sample")

    assert soundgasm_ie.IE_NAME == "Soundgasm"
    assert soundgasm_ie._VALID_URL == "http://soundgasm.net/u/ytdl/Piano-sample"


# Generated at 2022-06-12 18:08:44.998385
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    t = SoundgasmProfileIE()
    t._match_id("http://soundgasm.net/u/ytdl")

# Generated at 2022-06-12 18:08:56.279433
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert(ie._VALID_URL)
    ie._download_webpage('http://soundgasm.net/u/ytdl/Piano-sample', 'Piano-sample', errnote='Downloading webpage failed.')
    assert(ie._html_search_regex(r'm4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', 'xm4a\s*:\s*""', 'audio URL', group='url'))
    assert(ie._search_regex(r'/([^/]+)\.m4a', '/ytdl.m4a', 'audio id', default='Piano-sample'))

# Generated at 2022-06-12 18:08:57.965963
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-12 18:09:05.714762
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE_NAME = 'SoundgasmIE'
    URL = 'http://soundgasm.net/u/ytdl/Piano-sample'
    VIDEO_ID = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    VIDEO_URL = 'http://media.soundgasm.net/u/ytdl/piano-sample.m4a'
    VIDEO_TITLE = 'Piano sample'
    
    # create an instance of the SoundgasmIE class 
    soundgasmmm = SoundgasmIE()

    # test if the class name is correct
    assert(soundgasmmm.IE_NAME == IE_NAME) 

    # test if the video ID can be extracted from the URL
    assert(soundgasmmm._match_id(URL) == VIDEO_ID) 
    

# Generated at 2022-06-12 18:09:08.148584
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from SoundgasmProfileIE import SoundgasmProfileIE
    """Test that ensure constructor doesn't fail"""

    assert SoundgasmProfileIE is not None

# Generated at 2022-06-12 18:09:09.979197
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-12 18:09:16.918864
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-12 18:09:18.203975
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert SoundgasmProfileIE is not None


# Generated at 2022-06-12 18:09:22.970459
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_url = 'http://soundgasm.net/u/ytdl'
    test_profileID = 'ytdl'

    profile = SoundgasmProfileIE(test_url, test_profileID)

    assert profile.url == test_url
    assert profile.profile_id == test_profileID

# Generated at 2022-06-12 18:09:44.932966
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-12 18:09:52.467708
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    assert sg.IE_NAME == 'soundgasm'
    assert sg.VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-12 18:09:53.592245
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(None)



# Generated at 2022-06-12 18:09:59.570663
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    s = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert s.__class__.__name__ == 'SoundgasmIE'
    assert s._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:10:01.512665
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profileIE = SoundgasmProfileIE()
    assert soundgasm_profileIE.IE_NAME == 'SoundgasmProfileIE'

# Generated at 2022-06-12 18:10:07.211485
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl', 'Soundgasm: Profile')
    assert ie._get_url() == 'http://soundgasm.net/u/ytdl'
    assert ie._get_id() == 'ytdl'

# Generated at 2022-06-12 18:10:16.768255
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	from SoundgasmProfileIE import SoundgasmProfileIE
	from urlparse import urlparse
	from urlparse import parse_qs

	profile_id = 'ytdl'
	url = "http://soundgasm.net/u/ytdl/"

	# Create an instance of SoundgasmProfileIE
	result = SoundgasmProfileIE()._real_extract(url)

	assert result['id'] == profile_id

	assert len(result['entries']) == 1

	audio_url = result['entries'][0]['url']
	query = urlparse(audio_url).query
	url_query = parse_qs(query)

	assert url_query['id'][0] == profile_id



# Generated at 2022-06-12 18:10:28.021149
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    IE_NAME = 'soundgasm'
    VALID_URL = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie.ie_key() == IE_NAME
    m = re.match(ie._VALID_URL, VALID_URL)
    assert m
    assert ie._real_extract(VALID_URL)['uploader'] == 'ytdl'
    assert ie._real_extract(VALID_URL)['title'] == 'Piano sample'
    assert ie._real_extract(VALID_URL)['description'] == 'Royalty Free Sample Music'

# Generated at 2022-06-12 18:10:31.892049
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-12 18:10:32.800591
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-12 18:11:18.856622
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	t = SoundgasmIE()
	return t

# Generated at 2022-06-12 18:11:21.034878
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # This is a constructor test case.
    IE = SoundgasmIE()
    assert (IE.IE_NAME == 'Soundgasm')

# Generated at 2022-06-12 18:11:26.676689
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
        }



# Generated at 2022-06-12 18:11:29.756702
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-12 18:11:39.696632
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:11:50.976933
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE(None)
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-12 18:11:52.841912
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert True


# Generated at 2022-06-12 18:11:58.298319
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE()
    assert a.IE_NAME == 'soundgasm:profile'
    assert a._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert a._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}

# Generated at 2022-06-12 18:12:00.988563
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_obj = SoundgasmProfileIE('SoundgasmProfile')
    assert test_obj.IE_NAME == 'SoundgasmProfile'

# Generated at 2022-06-12 18:12:06.632137
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Init constructor
    soundgasm = SoundgasmIE()

    # Get unit test data
    url_input = soundgasm._TEST['url']

    # Test download function
    # Download web page of 'url_input' and save as 'webpage'.
    webpage = soundgasm._download_webpage(url_input, '88abd86ea000cafe98f96321b23cc1206cbcbcc9')
    print(webpage)

# Generated at 2022-06-12 18:13:50.645360
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    #  Create instance of class SoundgasmProfileIE
    soundgasm_profile_ie = SoundgasmProfileIE()
    #  Here is must be id of profile and not id of audio
    assert soundgasm_profile_ie.ie_key() == "Soundgasm"

# Generated at 2022-06-12 18:13:58.102665
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    expResult = {
        'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
        'ext': 'm4a',
        'title': 'Piano sample',
        'description': 'Royalty Free Sample Music',
        'uploader': 'ytdl',
    }

    ie = SoundgasmIE()
    result = ie._real_extract("http://soundgasm.net/u/ytdl/Piano-sample")
    assert expResult == result


# Generated at 2022-06-12 18:14:02.615068
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Unit test for constructor of class SoundgasmProfileIE
    """
    profileIE = SoundgasmProfileIE()
    if profileIE.IE_NAME == 'soundgasm:profile' and profileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$':
        print('Test passed')
    else:
        print('Test failed')



# Generated at 2022-06-12 18:14:05.539673
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert 'soundgasm.net/u/ytdl/Piano-sample' in SoundgasmProfileIE('Soundgasm')('http://soundgasm.net/u/ytdl')._TEST

# Generated at 2022-06-12 18:14:08.379770
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print('Test Begin')
    sg_profile_ie = SoundgasmProfileIE()

if __name__ == '__main__':
    test_SoundgasmProfileIE()

# Generated at 2022-06-12 18:14:15.553846
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test the object
    ie = SoundgasmIE()

    # Test for result of _real_extract

# Generated at 2022-06-12 18:14:23.928852
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-12 18:14:27.453817
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    r"""
     This is test class for the constructor of SoundgasmProfileIE
     
     This test case checks if the constructor is able to take the url and extract the id
    """
    t = SoundgasmProfileIE(None)
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    t.suitable(url)
    t.get_real_extract(url)

# Generated at 2022-06-12 18:14:34.241914
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.suitable('http://soundgasm.net/u/ytdl')
    assert ie.suitable('http://soundgasm.net/u/ytdl/')
    assert not ie.suitable('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-12 18:14:39.361420
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Create an instance of class SoundgasmIE
    ie = SoundgasmIE(None)

    # Check if the instance has a VALID_URL
    m = re.match(ie._VALID_URL, ie._TEST['url'])
    assert m

    # Check if there is a test url
    assert ie._TEST.get('url')

    # Check if there is a test md5
    assert ie._TEST.get('md5')

    # Check if a test info_dict is present
    assert ie._TEST.get('info_dict')