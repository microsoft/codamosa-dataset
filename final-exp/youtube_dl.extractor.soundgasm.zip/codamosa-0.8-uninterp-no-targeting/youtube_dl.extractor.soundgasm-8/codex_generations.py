

# Generated at 2022-06-22 08:18:39.921871
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    Sgasm = SoundgasmIE()
    assert Sgasm.IE_NAME == 'soundgasm'
    assert Sgasm._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:18:42.882016
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    actual_soundgasm_profile_ie = SoundgasmProfileIE('Soundgasm:profile')
    assert actual_soundgasm_profile_ie.IE_NAME == 'Soundgasm:profile'


# Generated at 2022-06-22 08:18:44.802543
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Construct a new SoundgasmProfileIE instance
    """
    return SoundgasmProfileIE(InfoExtractor._downloader)

# Generated at 2022-06-22 08:18:55.677482
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    entry = SoundgasmIE()

    assert entry.IE_NAME == 'soundgasm'
    assert entry._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:19:00.414450
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    for url in ['http://soundgasm.net/u/ytdl/Piano-sample']:
        SoundgasmIE().extract(url)


# Generated at 2022-06-22 08:19:02.680570
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'


# Generated at 2022-06-22 08:19:12.063230
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl_opts = {}
    ydl = YoutubeDL(ydl_opts)
    ie = SoundgasmIE()
    result = ie.extract('http://soundgasm.net/u/ytdl/Piano-sample')
    assert(result.get('id') == '88abd86ea000cafe98f96321b23cc1206cbcbcc9')
    assert(result.get('ext') == 'm4a')
    assert(result.get('title') == 'Piano sample')
    assert(result.get('description') == 'Royalty Free Sample Music')
    assert(result.get('uploader') == 'ytdl')


# Generated at 2022-06-22 08:19:13.398579
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()._VALID_URL == SoundgasmIE._VALID_URL

# Generated at 2022-06-22 08:19:15.754221
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert 'Soundgasm' == ie._VALID_URL

# Generated at 2022-06-22 08:19:19.697232
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    constructor = SoundgasmProfileIE.__dict__['_real_extract']
    assert SoundgasmProfileIE._TEST['info_dict']['id'] == constructor(SoundgasmProfileIE, SoundgasmProfileIE._TEST['url'])['id']

# Generated at 2022-06-22 08:19:30.310693
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	soundgasm = SoundgasmIE()
	assert soundgasm.IE_NAME == 'soundgasm'

# Generated at 2022-06-22 08:19:41.394964
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    obj = SoundgasmIE()._real_extract(url)
    assert obj['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert obj['display_id'] == 'Piano-sample'
    assert obj['url'] == 'http://static.soundgasm.net/audiofiles/2014/10/15/35b8a7aa-2e9f-42be-a59f-7164688059d5.m4a'
    assert obj['vcodec'] == 'none'
    assert obj['title'] == 'Piano sample'
    assert obj['description'] == 'Royalty Free Sample Music'

# Generated at 2022-06-22 08:19:42.758113
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	SoundgasmIE("http://yay.com")


# Generated at 2022-06-22 08:19:45.353896
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = ie._match_id(url)
    assert profile_id == 'ytdl'

# Generated at 2022-06-22 08:19:50.645478
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-22 08:20:00.137300
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	sgie = SoundgasmIE('http://soundgasm.net/u/ytdl/sample-music');
	assert sgie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
	#assert sgie._TEST == {
	#	'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
	#	'md5': '010082a2c802c5275bb00030743e75ad',
	#	'info_dict': {
	#		'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc

# Generated at 2022-06-22 08:20:02.210645
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()



# Generated at 2022-06-22 08:20:02.846927
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    assert True == True

# Generated at 2022-06-22 08:20:05.020443
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	ie = SoundgasmProfileIE('https://soundgasm.net/u/ytdl')
	print(ie)

# Generated at 2022-06-22 08:20:11.591039
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert ie._TEST['info_dict'] == { 'id': 'ytdl'}
    assert ie._TEST['playlist_count'] == 1

# Generated at 2022-06-22 08:20:30.293764
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    url     = 'http://soundgasm.net/u/ytdl'
    profile = 'ytdl'

    # Test class inputs
    ie = SoundgasmProfileIE(url=url, user_id=profile)

    # Test class outputs
    assert (ie.url =='http://soundgasm.net/u/ytdl'), "SoundgasmProfileIE.url should be 'http://soundgasm.net/u/ytdl', but is %s" % ie.url
    assert (ie.user_id == 'ytdl'), "SoundgasmProfileIE.user_id should be 'ytdl', but is %s" % ie.user_id
    assert (ie.is_download_user_profile == True), "SoundgasmProfileIE.is_download_user_profile should be True, but is %s"

# Generated at 2022-06-22 08:20:33.319490
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	a = SoundgasmIE();
	assert(isinstance(a, SoundgasmIE))
	print("test_SoundgasmIE passed.")
	return True;


# Generated at 2022-06-22 08:20:44.770963
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from tests import fake_webpage
    from .test_common import expected_failure

    # Unit test for constructor of class SoundgasmIE
    @expected_failure
    def test_constructor():
        webpage = fake_webpage(
            u'Piano sample',
            u'http://soundgasm.net/sound/ytdl/Piano-sample',
            u'<audio src="http://soundgasm.net/u/ytdl/Piano-sample.m4a" />')
        extractor = SoundgasmIE()
        info = extractor.extract(webpage)

    # Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-22 08:20:56.479081
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import os
    import unittest
    import unittest.mock as mock

    def _isdir(path):
        return True

    def _isfile(path):
        return True

    def _open(path, mode):
        class _file(object):
            def read(self):
                return 'Piano sample'
        return _file()


# Generated at 2022-06-22 08:20:58.292121
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE('SoundgasmProfileIE')

# Generated at 2022-06-22 08:21:06.660817
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Test for constructor of class SoundgasmIE
    """
    # Test with valid URL
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie, 'Could not create SoundgasmIE constructor'

    # Test with invalid URL
    try:
        ie = SoundgasmIE('http://soundgasm.net')
    except ValueError:
        assert True, 'Invalid url should raise exception'
    else:
        assert False, 'Invalid url should raise exception'

# Generated at 2022-06-22 08:21:07.943475
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    SoundgasmProfileIE()

# Generated at 2022-06-22 08:21:10.973148
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    A = SoundgasmIE((SoundgasmIE._VALID_URL % "Test_User", "Test_Audio"))
    assert A.IE_NAME == SoundgasmIE.IE_NAME
    assert A.user == "Test_User"
    assert A.display_id == "Test_Audio"

# Generated at 2022-06-22 08:21:15.938414
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	print('Creating instances of class SoundgasmIE...')
	ie = SoundgasmIE()

	# Verify that the instance is not null
	assert ie is not None
	print('Instance of class SoundgasmIE is not null.')

	print('Finished creating instances of class SoundgasmIE.')


# Generated at 2022-06-22 08:21:23.370973
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    # test using a public profile
    webpage = ie._download_webpage('http://soundgasm.net/u/ytdl/1st-test-upload')
    # test using a public file
    webpage = ie._download_webpage('http://soundgasm.net/u/ytdl/Piano-sample')
    # test using a private profile
    webpage = ie._download_webpage('http://soundgasm.net/u/kothbauer/michael')
    # test using a private file
    webpage = ie._download_webpage('http://soundgasm.net/u/kothbauer/michael/test')

# Generated at 2022-06-22 08:21:45.451285
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Prepare the test data
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    expected_result = test_SoundgasmIE._TEST['info_dict']

    # Create an instance of SoundgasmIE
    test = SoundgasmIE()

    # Extract the information from URL
    result = test._real_extract(url)

    # Check if the result is expected
    assert result == expected_result

# Generated at 2022-06-22 08:21:51.571621
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:21:54.479507
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE(url)()
    return

# Generated at 2022-06-22 08:21:55.503372
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    return SoundgasmIE()

# Generated at 2022-06-22 08:21:56.156456
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert 2 == 2

# Generated at 2022-06-22 08:22:00.571563
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

    

# Generated at 2022-06-22 08:22:10.458004
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_data = {
        'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
        'md5': '010082a2c802c5275bb00030743e75ad',
        'info_dict': {
            'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
            'ext': 'm4a',
            'title': 'Piano sample',
            'description': 'Royalty Free Sample Music',
            'uploader': 'ytdl',
        }
    }
    soundgasm_ie_obj = SoundgasmIE()
    result = soundgasm_ie_obj._real_extract(test_data['url'])
    assert test_data['info_dict'] == result


# Generated at 2022-06-22 08:22:16.128508
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # test constructor of class SoundgasmProfileIE
    profile = SoundgasmProfileIE()
    print(profile)
    assert(profile._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$")
    assert(profile.IE_NAME == "soundgasm:profile")

# Generated at 2022-06-22 08:22:24.472862
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from platform import python_version
    
    if python_version() < '3':
        from StringIO import StringIO
    else:
        from io import StringIO
    from ytdl.cachedb import CacheDB
    from ytdl.extractor import gen_extractors
    from ytdl.extractor.common import SearchInfoExtractor
    from ytdl.extractor.site import SiteInfoExtractor

    sg_profile_ie = SoundgasmProfileIE()
    # Cache DB
    test_cache_db = CacheDB.get_singleton(
        StringIO(
            '    {"title": "ytdl"}'))
    test_cache_db.set_downloader(None)

# Generated at 2022-06-22 08:22:25.367139
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    downloader = InfoExtractor()
    extractor = SoundgasmIE()
    downloader.add_info_extractor(extractor)


# Generated at 2022-06-22 08:23:13.957567
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    mobj = re.match(ie._VALID_URL, ie._TEST['url'])
    user = mobj.group('user')
    display_id = mobj.group('display_id')
    # If the test fails, and you get an exception, then you might be adding a URL which is not supported.
    # The extractor does not say anything about unsupported URLs, it will just silently fail.
    # So, pay attention to the last URL you added, and make sure it's a valid one.
    ie._real_extract(ie._TEST['url'])
    # If this fails, then a regular expression has been changed, but the URL has not been updated.
    assert user == 'ytdl'
    assert display_id == 'Piano-sample'
end_test()

# Generated at 2022-06-22 08:23:15.859478
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    TestClass = SoundgasmProfileIE

    TestClass()._match_id('http://soundgasm.net/u/ytdl') == 'ytdl'

# Generated at 2022-06-22 08:23:26.471281
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test the class constructor for validity
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl', {})
    assert ie is not None
    # Test the __name__ attribute
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.__name__ == 'soundgasm:profile'
    # Test the _VALID_URL and _TEST attributes
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert ie._TEST['info_dict'] == { 'id': 'ytdl' }
    assert ie._T

# Generated at 2022-06-22 08:23:28.154951
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info_extractor = SoundgasmProfileIE(None)



# Generated at 2022-06-22 08:23:32.540770
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import pytest
    music_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    # Initialize class
    SoundgasmIE_object = SoundgasmIE()
    # Test _real_extract function
    SoundgasmIE_object._real_extract(music_url)

# Generated at 2022-06-22 08:23:34.835798
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-22 08:23:45.672513
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Testing class SoundgasmIE
    ie = SoundgasmIE(InfoExtractor._downloader, 'http://soundgasm.net/u/ytdl/Piano-sample')
    # testing for type of object created
    assert(isinstance(ie, SoundgasmIE))
    # testing for type of url
    assert(ie._url == 'http://soundgasm.net/u/ytdl/Piano-sample')
    assert(ie._match_id == 'Piano-sample')
    # testing for type of downloader
    assert(isinstance(ie._downloader, InfoExtractor._downloader.__class__))
    # testing for type of IE_NAME
    assert(ie.IE_NAME == 'Soundgasm')
    # testing for type of _VALID_URL

# Generated at 2022-06-22 08:23:47.593710
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert isinstance(ie, SoundgasmIE)

# Generated at 2022-06-22 08:23:58.140001
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.field_map.keys() == ['display_id', 'uploader']
    assert ie.field_map['display_id'] == 'display_id'
    assert ie.field_map['uploader'] == 'uploader'
    assert ie.playlist_count == 1
    assert ie.playlist_mincount == 1
    assert ie.playlist_title == 'user'
    assert ie.playlist_description == 'user'


# Generated at 2022-06-22 08:23:59.991208
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from soundgasm.makeytdl import SoundgasmProfileIE

# Generated at 2022-06-22 08:25:32.977413
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print(SoundgasmProfileIE('SoundgasmProfileIE', 'http://soundgasm.net/u/ytdl')._TEST)

# Generated at 2022-06-22 08:25:35.766701
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert(SoundgasmIE()._TEST['url'] == SoundgasmIE()._VALID_URL)

# Generated at 2022-06-22 08:25:46.172533
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    result = SoundgasmProfileIE()._real_extract(
        'http://soundgasm.net/u/ytdl')

# Generated at 2022-06-22 08:25:51.088510
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE()
    if not isinstance(instance, object):
        raise AssertionError("Not Object instance")
    if not isinstance(instance, InfoExtractor):
        raise AssertionError("Not InfoExtractor instance")


# Generated at 2022-06-22 08:25:57.160583
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """ Unit test for constructor of class SoundgasmProfileIE"""
    testUrl = "http://soundgasm.net/u/ytdl"
    testResult = {'playlist': 'ytdl', 'playlist_count': 1}
    assert SoundgasmProfileIE()._real_extract(testUrl) == testResult

# Generated at 2022-06-22 08:26:03.652238
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import fake_get_test
    from .common import FauxFile
    htmlcontent = fake_get_test('http://soundgasm.net/u/ytdl', 'ytdl.html')
    with FauxFile(htmlcontent):
        ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
        ie._real_extract('http://soundgasm.net/u/ytdl')
    pass

# Generated at 2022-06-22 08:26:05.065491
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    global ie
    ie = SoundgasmIE()

# Generated at 2022-06-22 08:26:08.124398
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    playlist = SoundgasmProfileIE('SoundgasmProfileIE', 'http://soundgasm.net/u/ytdl')
    return playlist

# Generated at 2022-06-22 08:26:16.949939
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    t = SoundgasmIE()
    assert SoundgasmIE.IE_NAME == 'soundgasm'
    assert t.suitable('http://soundgasm.net/u/ytdl/Piano-sample')
    assert not t.suitable('http://soundgasm.net/u/ytdl/Piano-sample/')
    assert t._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert t.IE_DESC == 'Soundgasm'


# Generated at 2022-06-22 08:26:19.201079
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
