

# Generated at 2022-06-22 08:18:41.443130
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    i = SoundgasmIE()
    assert i.IE_NAME == 'soundgasm'
    assert i.VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:18:43.420785
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-22 08:18:48.924503
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE()
    url = "http://soundgasm.net/u/ytdl"
    assert soundgasm_profile_ie._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$"
    assert soundgasm_profile_ie.IE_NAME == 'soundgasm:profile'
    # Unit test for _match_id method of class SoundgasmProfileIE
    assert soundgasm_profile_ie._match_id(url) == 'ytdl'

# Generated at 2022-06-22 08:18:49.983784
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert isinstance(SoundgasmIE(),InfoExtractor)

# Generated at 2022-06-22 08:18:52.136925
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

test_SoundgasmIE()

# Generated at 2022-06-22 08:18:56.309175
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test for empty profile
    empty_profile = SoundgasmProfileIE("")
    assert empty_profile is not None
    assert empty_profile.name == "Soundgasm"
    assert empty_profile.ie_key() == "Soundgasm"
    assert empty_profile.valid_url("") == False

# Generated at 2022-06-22 08:19:07.200647
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    # Test an instance of class SoundgasmProfileIE
    instance = SoundgasmProfileIE(url)
    # Has the value of class SoundgasmProfileIE been set correctly?
    assert instance.url == url
    # Has the value of class InfoExtractor been set correctly?
    assert instance.ie_key == 'Soundgasm:profile'
    expected_info_dict = {'id': 'ytdl'}
    # Has the value of class SoundgasmProfileIE been set correctly?
    assert instance.info_dict == expected_info_dict
    # Has the value of info extractor (SoundgasmProfileIE) been set correctly?
    assert instance.IE_NAME == 'Soundgasm:profile'
# end of test_SoundgasmProfileIE()

# Generated at 2022-06-22 08:19:12.009547
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sgp = SoundgasmProfileIE
    results = sgp.extract("http://soundgasm.net/u/ytdl")
    assert(results['id'] == 'ytdl')

# Generated at 2022-06-22 08:19:15.113054
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.ie_key() == 'Soundgasm'
    assert ie.ie_name() == 'Soundgasm'
    assert ie.info_extractors() == [SoundgasmIE]


# Generated at 2022-06-22 08:19:16.997790
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    This unit test is for the constructor of class SoundgasmProfileIE.
    """
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:19:24.698947
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    expected_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    actual_url = SoundgasmProfileIE(url)._real_extract(url)

    assert expected_url == actual_url['entries'][0]['url']

# Generated at 2022-06-22 08:19:28.015547
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert "The URL is correct" in ie._real_extract(ie._VALID_URL)

# Generated at 2022-06-22 08:19:35.033197
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .common import ExtractorError
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    # A valid url should not throw an error
    SoundgasmIE()._real_extract(url)
    # An error should be thrown when the url is invalid
    invalid_url = 'http://soundgasm.net/u/ytdl/'
    throws_error = False
    try:
        SoundgasmIE()._real_extract(invalid_url)
    except ExtractorError as e:
        throws_error = True
    assert throws_error == True


# Generated at 2022-06-22 08:19:37.950518
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        SoundgasmProfileIE()
    except Exception as ex:
        print('Caught exception: %s' % ex)
        assert False


# Generated at 2022-06-22 08:19:41.759618
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE = InfoExtractor('Soundgasm')
    assert IE._VALID_URL is SoundgasmIE._VALID_URL
    assert IE._TEST is SoundgasmIE._TEST



# Generated at 2022-06-22 08:19:42.713486
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert isinstance(SoundgasmIE(), InfoExtractor)

# Generated at 2022-06-22 08:19:53.010101
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	"""
	Test constructor of class SoundgasmIE
	"""
	print("executing test_SoundgasmIE")
	# Unit test for constructor of SoundgasmIE
	test_url = "http://soundgasm.net/u/ytdl/Piano-sample"
	test_Soundgasm = SoundgasmIE().suitable(test_url)
	assert(test_Soundgasm == True)
	# Unit test for constructor of SoundgasmIE
	test_url2 = "https://soundgasm.net/u/ytdl/Piano-sample"
	test_Soundgasm2 =  SoundgasmIE().suitable(test_url2)
	assert(test_Soundgasm2 == True)
	# Unit test for constructor of SoundgasmIE

# Generated at 2022-06-22 08:19:55.965621
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test html page containing a playlist
    profile = SoundgasmProfileIE()
    profile.extract("http://soundgasm.net/u/LoudestLibrarian")

# Generated at 2022-06-22 08:19:57.825862
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  ie = SoundgasmProfileIE(None)
  assert ie.IE_NAME == 'SoundgasmProfileIE'


# Generated at 2022-06-22 08:20:01.514304
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    result = SoundgasmIE().extract(url)
    assert len(result['id']) == len('88abd86ea000cafe98f96321b23cc1206cbcbcc9')
    assert result['uploader'] == 'ytdl'
    assert 'royalty free' in result['description']

# Generated at 2022-06-22 08:20:18.163784
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_cases = [
        {
            'title': 'Unit test for SoundgasmIE',
            'input': 'http://soundgasm.net/u/ytdl/Piano-sample',
            'expected_results': {
                'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
                'ext': 'm4a',
                'title': 'Piano sample',
                'description': 'Royalty Free Sample Music',
                'uploader': 'ytdl',
            }
        }
    ]

    for test_case in test_cases:
        input = test_case['input']
        ie = SoundgasmIE()
        actual = ie.suitable(input)
        expected = True

# Generated at 2022-06-22 08:20:26.248665
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()._VALID_URL == SoundgasmIE._VALID_URL
    assert SoundgasmIE().IE_NAME == SoundgasmIE._IE_NAME
    assert SoundgasmIE()._TEST['url'] == SoundgasmIE._TEST['url']
    assert SoundgasmIE()._TEST['md5'] == SoundgasmIE._TEST['md5']
    assert SoundgasmIE()._TEST['info_dict'] == SoundgasmIE._TEST['info_dict']


# Generated at 2022-06-22 08:20:27.296944
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('', {})

# Generated at 2022-06-22 08:20:30.017419
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        soundgasm_consumer = SoundgasmProfileIE()
    except Exception as e:
        raise AssertionError(str(e))

# Generated at 2022-06-22 08:20:31.413981
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()    # No error


# Generated at 2022-06-22 08:20:36.058184
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test for case when user has no audio
    assert SoundgasmProfileIE(
        "http://soundgasm.net/u/kwikalex"
    )._real_extract(
        "http://soundgasm.net/u/kwikalex"
    )['_type'] == 'playlist'

# Generated at 2022-06-22 08:20:46.943370
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    s = SoundgasmIE()
    assert s._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert s._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert s._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'
    assert s._TEST['info_dict']['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert s._TEST['info_dict']['ext'] == 'm4a'


# Generated at 2022-06-22 08:20:48.141987
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    r = SoundgasmIE()
    return r

# Generated at 2022-06-22 08:20:48.803384
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    return True

# Generated at 2022-06-22 08:21:00.472221
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info_dict = {
        'id': 'ytdl',
        'display_id': 'ytdl',
        'url': 'http://soundgasm.net/u/ytdl/',
        'title': 'ytdl',
        'description': '',
        'uploader': 'ytdl'
    }

    soundgasm_profile_url = SoundgasmProfileIE._TEST['url']
    soundgasm_profile_ie = SoundgasmProfileIE()

    assert soundgasm_profile_url == soundgasm_profile_ie._TEST['url']

    soundgasm_profile_id = soundgasm_profile_ie._match_id(soundgasm_profile_url)


# Generated at 2022-06-22 08:21:08.353407
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:21:17.554268
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-22 08:21:20.146431
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE(InfoExtractor())._default_headers

# Generated at 2022-06-22 08:21:22.566011
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Uncomment the following lines to test your class
    # obj = SoundgasmIE('')
    # data = obj.extract('')
    assert False, 'todo'

# Generated at 2022-06-22 08:21:23.201552
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-22 08:21:29.854390
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info = SoundgasmIE()
    assert(info.IE_NAME == 'soundgasm')
    assert(info._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-22 08:21:34.658345
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    assert ie.playlist_count == 1
    assert ie.url == 'http://soundgasm.net/u/ytdl'
    assert ie.IE_NAME == 'soundgasm:profile'

if __name__ == '__main__':
    test_SoundgasmProfileIE()

# Generated at 2022-06-22 08:21:42.634320
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	url = "http://soundgasm.net/u/ytdl"
	ie = SoundgasmProfileIE()
	assert(ie.IE_NAME == "soundgasm:profile")
	assert(ie._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?")
	assert(ie._TEST["url"] == url)

# Generated at 2022-06-22 08:21:47.652040
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    Sg = SoundgasmIE()
    assert Sg.IE_NAME == 'Soundgasm'
    assert Sg._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:21:56.494232
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg_profile_ie = SoundgasmProfileIE()
    assert_true(sg_profile_ie.IE_NAME == 'soundgasm:profile')
    assert_true(sg_profile_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
    assert_true(sg_profile_ie._TEST['url'] == 'http://soundgasm.net/u/ytdl')
    assert_true(sg_profile_ie._TEST['info_dict']['id'] == 'ytdl')

# Generated at 2022-06-22 08:22:03.856037
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
  ie = SoundgasmIE("")

# Generated at 2022-06-22 08:22:07.575635
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg = SoundgasmIE(a=1, b=2, c=3)
    assert sg.a == 1
    assert sg.b == 2
    assert sg.c == 3



# Generated at 2022-06-22 08:22:10.360022
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from __init__ import SoundgasmIE
    s = SoundgasmIE()
    assert s.IE_NAME == 'soundgasm'
    

# Generated at 2022-06-22 08:22:11.791411
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(None);
    ie._real_initialize()

# Generated at 2022-06-22 08:22:14.163134
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-22 08:22:22.753313
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE_NAME = 'soundgasm:profile'
    _VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    _TEST = {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    assert SoundgasmProfileIE._VALID_URL == _VALID_URL
    assert SoundgasmProfileIE.IE_NAME == IE_NAME
    assert SoundgasmProfileIE._TEST == _TEST

# Generated at 2022-06-22 08:22:31.533519
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info_extractor = SoundgasmIE()

    assert info_extractor._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert info_extractor.__name__ == 'SoundgasmIE'
    assert info_extractor.ie_key() == 'Soundgasm'
    assert info_extractor.thumbnail == r're:^https?://.*\.jpg$'



# Generated at 2022-06-22 08:22:42.336097
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/nordic-nature"
    info_dict = {
        'id': "8caabd86ea000cafe98f96321b23cc1206cbcbcc9",
        'display_id': "nordic-nature",
        'url': "https://soundgasm.net/u/ytdl/nordic-nature",
        'title': "nordic-nature",
        'description': "Ambient recording in a Swedish forest, with birds chirping and nearby water.",
        'uploader': "ytdl",
        'vcodec': "none",
        'ext': "m4a"
    }
    obj = SoundgasmIE()

# Generated at 2022-06-22 08:22:43.009578
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:22:44.782066
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-22 08:23:05.528412
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # This is a copy of the test for the constructor of class SoundgasmProfileIE
    # It will check the validity of the regex for Soundgasm profile url
    # It is written because the url regex has failed to pass in setup.py
    # because of the length of the regex
    assert SoundgasmProfileIE._VALID_URL

# Generated at 2022-06-22 08:23:10.450942
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    mobj = re.match(SoundgasmProfileIE._VALID_URL, 'http://soundgasm.net/u/ytdl')
    assert mobj.group('id') == 'ytdl'


# Generated at 2022-06-22 08:23:13.633044
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
   return SoundgasmProfileIE()

# Generated at 2022-06-22 08:23:24.309226
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE_NAME = 'soundgasm:profile'
    _VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    _TEST = {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

    test = SoundgasmProfileIE()

# Generated at 2022-06-22 08:23:36.220171
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest
    import youtube_dl
    class TestExample(unittest.TestCase):
        def test_constructor(self):
            info_extractor = SoundgasmProfileIE()
            self.assertEqual(info_extractor.IE_NAME, 'soundgasm:profile')
            self.assertEqual(info_extractor._VALID_URL, r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
            self.assertEqual(info_extractor._TEST,{
                'url': 'http://soundgasm.net/u/ytdl',
                'info_dict': {
                    'id': 'ytdl',
                },
                'playlist_count': 1,
            })
           

# Generated at 2022-06-22 08:23:40.275911
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie._VALID_URL == 'http://soundgasm.net/u/ytdl'

# Generated at 2022-06-22 08:23:41.626758
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:23:46.230733
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info = SoundgasmProfileIE()._real_extract('http://soundgasm.net/u/ytdl')
    assert info['id'] == 'ytdl'
    assert len(info['entries']) == 8

# Generated at 2022-06-22 08:23:46.966993
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert True

# Generated at 2022-06-22 08:23:50.909718
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE("ytdl")
    SoundgasmProfileIE("ytdl", "password")

# Generated at 2022-06-22 08:24:43.410711
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest

    class TestSoundgasmProfileIE(unittest.TestCase):

        def setUp(self):
            self.test_object = SoundgasmProfileIE()

        def test_type(self):
            self.assertIsInstance(self.test_object, SoundgasmProfileIE)
            self.assertIsInstance(self.test_object.IE_NAME, basestring)
            self.assertTrue(len(self.test_object.IE_NAME) > 0)
            self.assertTrue(len(self.test_object._TESTS) > 0)
            self.assertTrue(len(self.test_object._VALID_URL) > 0)

        def test_match_url(self):
            test_url = "random_url"

# Generated at 2022-06-22 08:24:45.258569
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    t = SoundgasmIE()
    assert 'Soundgasm' in t.IE_NAME

# Generated at 2022-06-22 08:24:50.301858
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Simple unit test for testing constructor of class SoundgasmProfileIE."""
    expected_name = 'Soundgasm:profile'
    ie = SoundgasmProfileIE('test:test:test:test')
    if ie.IE_NAME != expected_name:
        raise AssertionError('Unexpected IE name: expected "%s", got "%s"' %
                             (expected_name, ie.IE_NAME))

# Generated at 2022-06-22 08:24:53.235076
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:24:54.706873
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sound = SoundgasmIE()

# Generated at 2022-06-22 08:25:04.782548
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('ytdl')
    if(ie.IE_NAME != 'soundgasm:profile'):
        raise Exception('SoundgasmProfileIE failed')
    if(ie._VALID_URL != r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'):
        raise Exception('SoundgasmProfileIE failed')
    if(ie._TEST['url'] != 'http://soundgasm.net/u/ytdl'):
        raise Exception('SoundgasmProfileIE failed')
    if(ie._TEST['info_dict']['id'] != 'ytdl'):
        raise Exception('SoundgasmProfileIE failed')

# Generated at 2022-06-22 08:25:05.753410
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:25:07.446138
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE().IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-22 08:25:13.590845
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print ('Testing constructor of class SoundgasmIE()')
    absolute_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    try:
        SoundgasmIE(absolute_url)
    except AssertionError as e:
        print (e.message)
        raise
    except:
        raise
    else:
        print ('Constructor of class SoundgasmIE() test passed!')


# Generated at 2022-06-22 08:25:22.304506
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    '''This function, test_SoundgasmIE(), tests the functionality of constructor, ie.SoundgasmIE().
    '''
    test_extractor_class_name = 'SoundgasmIE'
    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    test_instance = InfoExtractor()
    test_class = test_instance.get_info_extractor(test_url)
    assert test_class.__name__ == test_extractor_class_name, \
        "Expected class name: " + test_extractor_class_name + " but received: " + test_class.__name__


# Generated at 2022-06-22 08:26:20.414546
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile = SoundgasmProfileIE()
    data = profile._real_extract(url)
    assert data['id'] == 'ytdl'

# Generated at 2022-06-22 08:26:22.832136
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE.IE_NAME == 'soundgasm:profile')


# Generated at 2022-06-22 08:26:31.965312
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	print('\nTesting instantiation of class SoundgasmIE\n')
	import sys
	print('\nPython version: ' + sys.version + '\n')
	
	import ytdl_org
	assert ytdl_org.version() == '1.0.0'
	
	from ytdl_org.extractors import SoundgasmIE
	
	print('\nInstantiate class SoundgasmIE\n')
	
	soundgasmIE = SoundgasmIE()
	
	print('\nDone testing instantiation of class SoundgasmIE\n')


# Generated at 2022-06-22 08:26:33.384458
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    play_list_instance = SoundgasmProfileIE('SoundgasmProfileIE')

# Generated at 2022-06-22 08:26:44.679289
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    if not ie.suitable('http://soundgasm.net/u/ytdl/Piano-sample'):
        print('Unit test for class SoundgasmIE: failed to validate url')
        raise Exception('Unit test for class SoundgasmIE: failed to validate url')

    # Unit test for constructor of class SoundgasmProfileIE
    ie2 = SoundgasmProfileIE()
    if not ie2.suitable('http://soundgasm.net/u/ytdl'):
        print('Unit test for class SoundgasmProfileIE: failed to validate url')
        raise Exception('Unit test for class SoundgasmProfileIE: failed to validate url')

if __name__ == '__main__':
    test_SoundgasmIE()

# Generated at 2022-06-22 08:26:47.080691
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test instance creation
    soundgasm_profile_IE = SoundgasmProfileIE()
    assert soundgasm_profile_IE

# Generated at 2022-06-22 08:26:52.263188
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE()
    assert obj.IE_NAME == 'soundgasm'
    assert obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-22 08:26:56.321917
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    valid_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE()
    m = re.match(ie._VALID_URL, valid_url)
    assert m.group('user') == "ytdl"
    assert m.group('display_id') == "Piano-sample"

# Generated at 2022-06-22 08:27:04.526392
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test case for audio play
    audio_get = SoundgasmIE()
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    audio_get.extract(url)
    assert len(audio_get.entries) == 1
    assert 'ytdl' == audio_get.entries[0]['uploader']
    assert 'Piano sample' == audio_get.entries[0]['title']
    assert '010082a2c802c5275bb00030743e75ad' == audio_get.entries[0]['md5']

# Generated at 2022-06-22 08:27:05.778416
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    constructor = SoundgasmProfileIE(NULL, NULL)
    assert constructor