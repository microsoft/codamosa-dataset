

# Generated at 2022-06-22 08:18:43.227173
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasm = SoundgasmIE()
    info_dict = soundgasm.extract(url)
    assert info_dict['title'] == 'Piano sample'
    assert info_dict['description'] == 'Royalty Free Sample Music'
    assert info_dict['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert info_dict['uploader'] == 'ytdl'

# Generated at 2022-06-22 08:18:50.139025
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    parser = 'soundgasmie'
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    data = {
        'url': url,
        'md5': '010082a2c802c5275bb00030743e75ad',
        'info_dict': {
            'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
            'ext': 'm4a',
            'thumbnail': 'http://img.soundgasm.net/img/site/soundgasm-logo.png',
            'title': 'Piano sample',
            'description': 'Royalty Free Sample Music',
            'uploader': 'ytdl',
        }
    }
    import soundgasmie 
    ie = soundg

# Generated at 2022-06-22 08:18:54.277827
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:18:57.711416
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie_Soundgasm = SoundgasmIE()
    audio_id = ie_Soundgasm._search_regex(r'/([^/]+)\.m4a', 'http://soundgasm.net/u/ytdl/Piano-sample/Piano-sample.m4a', 'audio id', default='Piano-sample')
    assert audio_id == 'Piano-sample'
test_SoundgasmIE()

# Generated at 2022-06-22 08:19:01.683896
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    ie.get_info(url=ie._TEST['url'])

# Generated at 2022-06-22 08:19:11.996211
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    tester = SoundgasmIE()
    assert(tester._VALID_URL.match('http://soundgasm.net/u/ytdl/Piano-sample').group('user') == 'ytdl')
    assert(tester._VALID_URL.match('http://soundgasm.net/u/ytdl/Piano-sample').group('display_id') == 'Piano-sample')
    assert(tester._TEST.get('url') == 'http://soundgasm.net/u/ytdl/Piano-sample')
    assert(tester._TEST.get('md5') == '010082a2c802c5275bb00030743e75ad')

# Generated at 2022-06-22 08:19:19.595000
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-22 08:19:27.105551
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ve = SoundgasmIE()
    # for video id "Piano-sample" by user "ytdl"
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    result = ve.suitable(url)
    assert result is True
    # for video id "Piano-sample" by user "ytdl"
    url = 'http://www.soundgasm.net/u/ytdl/Piano-sample'
    result = ve.suitable(url)
    assert result is True
    # for video id "Piano-sample" by user "ytdl"
    url = 'soundgasm.net/u/ytdl/Piano-sample'
    result = ve.suitable(url)
    assert result is False
    # for video id "Piano-sample

# Generated at 2022-06-22 08:19:31.144852
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    result_dict = SoundgasmProfileIE._real_extract(SoundgasmProfileIE(), 'http://soundgasm.net/u/ytdl')
    assert len(result_dict['entries']) == 1

# Generated at 2022-06-22 08:19:35.038130
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Test for SoundgasmIE"""
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE(SoundgasmIE.ie_key()).extract(url)

# Generated at 2022-06-22 08:19:39.641738
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass

# Generated at 2022-06-22 08:19:40.707585
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	assert 1 == 1
	return

# Generated at 2022-06-22 08:19:46.867440
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg_profile_ie = SoundgasmProfileIE()
    assert sg_profile_ie.__class__.__name__ == 'SoundgasmProfileIE'
    assert sg_profile_ie.IE_NAME == 'soundgasm:profile'
    assert sg_profile_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:19:47.906190
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	test = SoundgasmIE()


# Generated at 2022-06-22 08:19:56.980010
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    soundgasm_ie = SoundgasmIE()
    assert soundgasm_ie._VALID_URL == SoundgasmIE._VALID_URL
    assert soundgasm_ie._TEST['url'] == SoundgasmIE._TEST['url']
    assert soundgasm_ie._TEST['md5'] == SoundgasmIE._TEST['md5']
    assert soundgasm_ie._TEST['info_dict'] == SoundgasmIE._TEST['info_dict']
    assert str(soundgasm_ie) == '[SoundgasmIE]'

    # Unit test for method real_extract of class SoundgasmIE
    info_dict = soundgasm_ie._real_extract(audio_url)


# Generated at 2022-06-22 08:20:04.016581
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'

# Generated at 2022-06-22 08:20:06.588245
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test an empty constructor, should create an instance of the class
    instance = SoundgasmProfileIE()
    assert isinstance(instance, SoundgasmProfileIE)


# Generated at 2022-06-22 08:20:07.846102
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_instantiate_class(SoundgasmProfileIE)


# Generated at 2022-06-22 08:20:17.275013
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    #Test case to contructor object of SoundgasmProfileIE
    TestClass = type('TestClass', (object,), {'_real_extract': lambda *args: ['try']})
    TestObject = TestClass()
    TestObject.profile_id = 'ytdl'
    profile_ie = SoundgasmProfileIE()
    class_name = profile_ie.__class__.__name__
    assert class_name == "SoundgasmProfileIE"
    assert profile_ie.IE_NAME == "SoundgasmProfile"
    assert profile_ie._real_extract("http://soundgasm.net/u/ytdl") == ["try"]
    result, entries = profile_ie.playlist_result([{'info_dict': {'id': 'ytdl'}}], 'ytdl')

# Generated at 2022-06-22 08:20:29.107243
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    # Test whether valid_url() method can find a non-existent URL
    assert soundgasm.valid_url('http://www.google.com/') == False
    # Test whether valid_url() method can find a existent URL
    assert soundgasm.valid_url('http://soundgasm.net/u/ytdl/Piano-sample') == True
    # Test whether _real_extract() method can extract a audio url from existent url
    assert soundgasm._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')['url'] == 'http://s3.amazonaws.com/ytdl/ytdl/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'

# Generated at 2022-06-22 08:20:40.473754
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    for a in range(0, 10):
        try:
            return SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
        except Exception:
            pass
    raise AssertionError("Couldn't create instance of SoundgasmIE")

# Generated at 2022-06-22 08:20:43.616316
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('ytdl')
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:20:46.180707
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"

# Generated at 2022-06-22 08:20:48.628903
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE({})
    assert ie.ie_key() == "Soundgasm"

# Generated at 2022-06-22 08:21:00.381887
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasm_ie = SoundgasmIE(url)
    assert soundgasm_ie.get_url() == url
    assert soundgasm_ie.get_IE_NAME() == 'soundgasm'
    assert soundgasm_ie.get_valid_url() == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert soundgasm_ie.get_ext() == 'm4a'

# Generated at 2022-06-22 08:21:02.728837
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class_ = globals()['SoundgasmIE']
    print(class_)



# Generated at 2022-06-22 08:21:14.558926
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    name, iurl = SoundgasmProfileIE()._fetch_info(4)
    assert name == "soundgasm"
    assert iurl == "http://soundgasm.net/u/" + str(4)
    assert SoundgasmProfileIE()._match_id(iurl) == str(4)
    assert SoundgasmProfileIE()._match_id("http://soundgasm.net/u/4.html") == str(4)
    assert SoundgasmProfileIE()._match_id("http://soundgasm.net/u/4#!#") == str(4)
    assert SoundgasmProfileIE()._match_id("http://soundgasm.net/u/4/") == str(4)

# Generated at 2022-06-22 08:21:15.972405
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    assert isinstance(soundgasm, SoundgasmIE)

# Generated at 2022-06-22 08:21:22.648546
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    # Audio of piano being played
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    info_dict = soundgasm._real_extract(url)
    # The site can't be downloaded without generating a new token which depends on the current time
    # Therefore, this test can't download any files
    # The test will check if all the info_dict contains the same values as the TEST dict
    # Which is created by manual testing to check if the result is correct
    assert info_dict['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert info_dict['ext'] == 'm4a'
    assert info_dict['title'] == 'Piano sample'

# Generated at 2022-06-22 08:21:24.411507
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('soundgasm')


# Generated at 2022-06-22 08:21:41.632767
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test constructor of class SoundgasmProfileIE
    profile_ie = SoundgasmProfileIE()
    print(profile_ie)


# Generated at 2022-06-22 08:21:50.156914
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import os.path
    import tempfile
    from ydl import YDL
    from ydl.YoutubeDL import YoutubeDL
    import soundgasm

    path = os.path.join(tempfile.gettempdir(), "test_download.m4a")
    audio_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    ydl = YDL()
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(soundgasm.SoundgasmIE())
    ydl.download([audio_url])
    ydl.prepare_filename()
    assert ydl.get_filename() == 'Piano-sample'

# Generated at 2022-06-22 08:21:55.553386
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE()
    ie._download_webpage = lambda url: '<html><div id="ytdl"></div></html>'
    ie._match_id(url)
    ie._real_extract(url)

# Generated at 2022-06-22 08:21:56.943365
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    my_object = SoundgasmProfileIE()
    assert my_object() 


# Generated at 2022-06-22 08:22:02.874013
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	#Create a new instance of SoundgasmProfileIE
	sgprofile = SoundgasmProfileIE()
	#Test that the _VALID_URL matches
	assert sgprofile._VALID_URL_RE.match('http://soundgasm.net/u/ytdl')
	#Test that the _VALID_URL matches
	assert sgprofile._VALID_URL_RE.match('http://soundgasm.net/u/ytdl/')
	#Test that the _VALID_URL does not match
	assert sgprofile._VALID_URL_RE.match('http://soundgasm.net/u/ytdl/Piano-sample') is None
	#Test that the _VALID_URL does not match

# Generated at 2022-06-22 08:22:05.749422
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    s = SoundgasmIE()
    pass


# Generated at 2022-06-22 08:22:08.542412
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    obj = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert obj.__class__.__name__ == 'SoundgasmIE'

# Generated at 2022-06-22 08:22:10.360511
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-22 08:22:11.353243
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE({})



# Generated at 2022-06-22 08:22:12.322373
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	assert SoundgasmIE()

# Generated at 2022-06-22 08:23:01.915038
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Unit test for constructor of class SoundgasmIE
    # Unstable, as the extraction relies on many external websites.
    # This unit test would help to indicate unexpected changes.
    url = "http://soundgasm.net/u/ytdl/Piano-sample"

    sg = SoundgasmIE()
    sg.extract(url)
    assert sg._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)"
    assert sg._USER_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<id>[0-9a-zA-Z_-]+)/?"

# Generated at 2022-06-22 08:23:04.525101
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    # This should not crash
    SoundgasmIE()._real_extract(url)

# Generated at 2022-06-22 08:23:09.728643
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Given a string representing a playlist,
    # when I instantiate the object SoundgasmProfileIE,
    # then I should get a valid object
    assert SoundgasmProfileIE

# Generated at 2022-06-22 08:23:17.639786
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(SoundgasmProfileIE.ie_key())
    url = 'http://soundgasm.net/u/ytdl'
    expected_id = 'ytdl'
    assert ie._match_id(url) == expected_id
    assert ie._real_extract(url)['id'] == expected_id

# Generated at 2022-06-22 08:23:27.355051
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    info_extractor = SoundgasmProfileIE()
    # test _VALID_URL
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    # test _TEST
    assert info_extractor._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    # test _real_extract
    test_url = 'http://soundgasm.net/u/ytdl'
    test_profile_id = 'ytdl'

# Generated at 2022-06-22 08:23:29.693284
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg_ie = SoundgasmIE()
    assert sg_ie.IE_NAME == 'soundgasm'


# Generated at 2022-06-22 08:23:32.974901
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(SoundgasmProfileIE._VALID_URL)
    print ("%s __init__() is working properly" % ie.__class__.__name__)


# Generated at 2022-06-22 08:23:37.362776
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'SoundgasmProfileIE'
    assert ie.IE_DESC == 'Soundgasm'
#if __name__ == '__main__':
#    test_SoundgasmProfileIE()

# Generated at 2022-06-22 08:23:41.793885
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import os
    from .constants import *
    # Create object of class SoundgasmProfileIE
    soundgasmProfileIE = SoundgasmProfileIE(os.getcwd(), None, None)
    soundgasmProfileIE.toString()

# Generated at 2022-06-22 08:23:46.297632
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('test')
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:25:19.098272
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._match_id('http://soundgasm.net/u/ytdl/Piano-sample') == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-22 08:25:20.932637
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('SoundgasmProfileIE', '', 'Soundgasm')

# Generated at 2022-06-22 08:25:30.184300
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_cases = [
        'http://soundgasm.net/u/ytdl',
        'http://www.soundgasm.net/u/ytdl',
        'http://soundgasm.net/u/ytdl/',
        'http://www.soundgasm.net/u/ytdl/',
        'http://soundgasm.net/u/ytdl#sandwich',
        'http://www.soundgasm.net/u/ytdl#sandwich',
        'http://soundgasm.net/u/ytdl/#sandwich',
        'http://www.soundgasm.net/u/ytdl/#sandwich',
    ]

    i = SoundgasmProfileIE()


# Generated at 2022-06-22 08:25:42.371863
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Unit test constructor of class SoundgasmProfileIE"""
    url_regex = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    profile_id = 'ytdl'
    content = "hello world"
    profile = {
        'id': profile_id,
        'entries': [
            'https://soundgasm.net/u/ytdl/Piano-sample'
        ]
    }

    ie = SoundgasmProfileIE(
        url_regex,
        profile_id,
        content,
        profile
    )

    assert ie.url_regex == url_regex
    assert ie.profile_id == profile_id
    assert ie.content == content

# Generated at 2022-06-22 08:25:43.988215
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-22 08:25:47.556122
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Note:
        This function only tests the class can be constructed.
        There is no actual test case.
    """
    test_url = 'https://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE(SoundgasmIE._create_ie(), test_url)

# Generated at 2022-06-22 08:25:55.976207
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    t = SoundgasmIE()
    assert t._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:26:02.114435
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE("http://soundgasm.net/u/ytdl/")
    assert ie.IE_NAME == "soundgasm:profile"
    assert ie.name == "Soundgasm Profile"
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:26:08.360652
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'

# Generated at 2022-06-22 08:26:09.084005
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()