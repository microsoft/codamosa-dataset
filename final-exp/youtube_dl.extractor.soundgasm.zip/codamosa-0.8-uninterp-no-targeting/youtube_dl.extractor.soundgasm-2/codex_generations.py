

# Generated at 2022-06-22 08:18:43.014620
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE()
    assert soundgasm_profile_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert soundgasm_profile_ie._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}

# Generated at 2022-06-22 08:18:44.294496
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert (SoundgasmIE("") != None)


# Generated at 2022-06-22 08:18:53.583709
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    assert ie.ie_name == "Soundgasm"
    assert ie.mp3_id == "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
    assert ie.mp3_url == "http://soundgasm.net/samples/ytdl/Piano-sample.m4a"
    assert ie.video_title == "Piano sample"
    assert ie.video_description == "Royalty Free Sample Music"
    assert ie.video_uploader == "ytdl"

# Generated at 2022-06-22 08:18:56.373358
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Tests when no uploaded sounds found
    url = 'http://soundgasm.net/u/viv812'
    ie = SoundgasmProfileIE(url)

# Generated at 2022-06-22 08:18:58.879273
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert( isinstance(SoundgasmIE(), InfoExtractor) )


# Generated at 2022-06-22 08:19:10.638132
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    tester = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert tester._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert tester.IE_NAME == 'soundgasm'
    #assert tester._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert tester._TEST['info_dict']['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-22 08:19:22.269117
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # The test_SoundgasmIE method should be executed if and only if its name does not begin with 'test_'
    if test_SoundgasmIE.__name__ == "test_SoundgasmIE":
        return 0
    else:
        # Check if SoundgasmIE initialized correctly:
        #  1) The parameter should be a string
        #  2) The string should not be empty
        #  3) The string should be a valid Soundgasm URL, so that it can be used to extract all the available
        #     info, as in the above unit tests
        if len(SoundgasmIE.__init__.__code__.co_varnames) != 2:
            return -1       # The number of parameters of the class differs from what is expected

# Generated at 2022-06-22 08:19:25.310932
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Tests that the constructor of SoundgasmProfileIE works properly"""
    demo_url = "http://soundgasm.net/u/ytdl"
    extractor = SoundgasmProfileIE()
    assert extractor._match_id(demo_url) == "ytdl"


# Generated at 2022-06-22 08:19:27.810012
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.__class__.__name__ == 'SoundgasmProfileIE'

# Generated at 2022-06-22 08:19:32.904731
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	print ('\nUnit test for SoundgasmProfileIE\n')
	print ('\nTesting of SoundgasmProfileIE\n')
	assert SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:19:43.404537
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    userInfo = {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    sgProfileIE = SoundgasmProfileIE()
    assert sgProfileIE._TEST == userInfo

# Generated at 2022-06-22 08:19:44.469208
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-22 08:19:50.398898
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert isinstance(ie, InformationExtractor)
    assert hasattr(ie, '_VALID_URL') and ie._VALID_URL is not None
    assert hasattr(ie, 'IE_NAME') and ie.IE_NAME is not None
    assert hasattr(ie, '_TEST') and ie._TEST is not None


# Generated at 2022-06-22 08:19:53.653044
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.ie_key() == 'Soundgasm:profile'
    assert ie.suitable(ie.webpage_url_hook('http://soundgasm.net/u/ytdl'))

# Generated at 2022-06-22 08:19:55.238612
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-22 08:20:03.639694
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import time
    import pprint

# Generated at 2022-06-22 08:20:11.408690
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    ie = SoundgasmProfileIE(None)
    assert ie.IE_NAME == 'soundgasm:profile'
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:20:13.108612
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test constructor
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'

# Generated at 2022-06-22 08:20:14.075607
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()


# Generated at 2022-06-22 08:20:18.569562
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	d = SoundgasmProfileIE()
	assert d.IE_NAME == 'soundgasm:profile'
	assert d._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-22 08:20:28.032797
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("Creating an instace of SoundgasmIE")
    ie = SoundgasmIE([])
    print("Instance created")


# Generated at 2022-06-22 08:20:34.438692
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # This test makes sure that the constructor is doing well
    url = 'http://soundgasm.net/u/ytdl'
    SoundgasmProfileIE._download_webpage = \
        lambda _, url: None
    SoundgasmProfileIE.playlist_result = lambda self, entries: entries
    g = SoundgasmProfileIE(None)
    entries = g._real_extract(url)
    expected_count = 1
    assert len(entries) == expected_count

# Generated at 2022-06-22 08:20:36.569909
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Checks that we can create a SoundgasmIE
    SoundgasmIE('Soundgasm', 'hello', {})

# Generated at 2022-06-22 08:20:42.107056
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest
    suite = unittest.TestSuite()
    suite.addTest(SoundgasmProfileIE("test_SoundgasmProfileIE"))
    runner = unittest.TextTestRunner()
    runner.run(suite)

# Generated at 2022-06-22 08:20:48.073657
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-22 08:20:50.064352
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    new_age = SoundgasmProfileIE("soundgasm.net")
    assert new_age.age > 21

# Generated at 2022-06-22 08:20:57.103736
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    # Test invalid URL
    with pytest.raises(AssertionError):
        SoundgasmIE("http://soundgasm.net/u/ytdl/0")

    # Test valid URL
    assert SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")._VALID_URL == r'^(?:https?://)?(?:\w+\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)$'


# Generated at 2022-06-22 08:20:58.453869
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-22 08:21:07.469697
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from . import SoundgasmProfileIE
    ie = SoundgasmProfileIE('SoundgasmProfileIE', 'soundgasm.net')
    info_dict = {
        'id': 'ytdl',
    }
    url = 'http://soundgasm.net/u/ytdl'
    assert ie._real_extract(url) == ie.playlist_result(ie.url_result('http://soundgasm.net/u/ytdl/Piano-sample', 'Soundgasm'), info_dict['id'])

if __name__ == '__main__':
    test_SoundgasmProfileIE()

# Generated at 2022-06-22 08:21:08.394886
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:21:26.061813
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    i = SoundgasmIE()
    i.extract('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-22 08:21:32.554616
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    i = SoundgasmIE()
    assert i.IE_NAME == 'soundgasm'
    assert i.IE_DESC == 'Soundgasm.net sound files'
    assert i._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:21:33.190564
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-22 08:21:39.924136
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  # Test constructor of class SoundgasmProfileIE
  # given
  soundgasm = SoundgasmProfileIE()
  soundgasm_re = re.compile(soundgasm._VALID_URL)

  # when
  result = soundgasm._real_extract('http://soundgasm.net/u/ytdl')

  # then
  assert result['id'] == 'ytdl'


# Generated at 2022-06-22 08:21:45.080021
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_class = SoundgasmIE()
    print(test_class.get_media_info(
        'http://soundgasm.net/u/ytdl/Piano-sample')[0])
    print(test_class.get_media_info(
        'http://soundgasm.net/u/ytdl/Piano-sample')[0].get_filesize())

# Generated at 2022-06-22 08:21:47.177375
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    print (audio._url)
    print (audio._uid)
    print (audio._display_id)

# Generated at 2022-06-22 08:21:49.245207
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass

# Generated at 2022-06-22 08:21:52.172647
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # For commit: 3c6f1319aac7ad18bbf34f455980d5a5b5a9f75f
    # Test if main executes without error
    SoundgasmProfileIE("main", "main")

# Generated at 2022-06-22 08:22:02.484556
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Unit test for constructor of class SoundgasmIE"""

    audio_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    display_id = 'Piano-sample'
    audio_url = 'http://samples.soundgasm.net/u/soundgasm/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'

    soundgasm = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-22 08:22:07.470785
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE('http://soundgasm.net/u/ytdl/#user-sounds')
    print(profile._TEST['url'] == 'http://soundgasm.net/u/ytdl')
    print(profile._TEST['info_dict']['id'] == 'ytdl')
    print(profile._TEST['playlist_count'] == 1)


# Generated at 2022-06-22 08:22:44.704934
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .helper import soundgasm_playlist
    assert soundgasm_playlist.Playlist.__name__ == 'Playlist'

# Generated at 2022-06-22 08:22:45.606692
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:22:47.062963
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:22:50.155058
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert 'SoundgasmProfileIE' in globals()
    assert isinstance(SoundgasmProfileIE, type)
    assert issubclass(SoundgasmProfileIE, InfoExtractor)


# Generated at 2022-06-22 08:22:56.964476
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == "soundgasm"

# Generated at 2022-06-22 08:22:59.723056
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_SoundgasmProfileIE.__doc__ = None
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-22 08:23:09.506682
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    x = SoundgasmIE()

    # test valid url
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    ie_result = x.extract(url)
    assert ie_result['id'] == "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
    assert ie_result['url'] == "http://dl.soundgasm.net/ytdl/Piano-sample.m4a"
    assert ie_result['display_id'] == "Piano-sample"
    assert ie_result['title'] == "Piano sample"
    assert ie_result['description'] == "Royalty Free Sample Music"
    assert ie_result['uploader'] == "ytdl"

    # test invalid url

# Generated at 2022-06-22 08:23:13.474686
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE.__name__ == "SoundgasmIE"


# Generated at 2022-06-22 08:23:17.733536
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('soundgasm:profile')
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:23:20.220417
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None)

# Generated at 2022-06-22 08:24:42.553484
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	assert SoundgasmIE()._TEST

# Generated at 2022-06-22 08:24:43.150542
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-22 08:24:53.482696
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:24:55.002100
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None, {})

# Generated at 2022-06-22 08:24:58.766322
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE(url)

    # Test that the id property is set correctly
    profile_id = ie._match_id(url)
    assert(ie.id == profile_id)

# Generated at 2022-06-22 08:25:01.541984
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE("ytdl")
    assert obj

# Generated at 2022-06-22 08:25:05.482690
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Given a url of Soundgasm
    url = 'http://soundgasm.net/u/ytdl'

    # When class SoundgasmProfileIE is constructed with the url
    # Then I should get an object of the class
    object = SoundgasmProfileIE(url)
    assert isinstance(object, SoundgasmProfileIE)

# Generated at 2022-06-22 08:25:07.543807
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('SoundgasmProfileIE','http://soundgasm.net/u/ytdl','1')

# Generated at 2022-06-22 08:25:15.604058
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie.IE_NAME == 'soundgasm'
    assert ie.SUFFIX == '.m4a'


# Generated at 2022-06-22 08:25:16.198144
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass

# Generated at 2022-06-22 08:28:00.924824
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    s = SoundgasmIE(url)
    assert s.IE_NAME == "soundgasm"
    assert s.VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)"
    assert s._TEST['url'] == url


# Generated at 2022-06-22 08:28:03.911354
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie is not None


# Generated at 2022-06-22 08:28:05.234012
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	a = SoundgasmProfileIE()

# Generated at 2022-06-22 08:28:12.936858
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-22 08:28:14.428704
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert isinstance(SoundgasmProfileIE('Soundgasm'), SoundgasmProfileIE)

# Generated at 2022-06-22 08:28:25.888937
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# http://soundgasm.net/u/ytdl/Piano-sample
	url = 'http://soundgasm.net/u/ytdl/Piano-sample'
	result = SoundgasmIE()._real_extract(url)
	assert result['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
	assert result['uploader'] == 'ytdl'
	assert result['title'] == 'Piano sample'
	assert result['upload_date'] is None
	assert result['duration'] is None
	assert result['view_count'] is None
	assert result['like_count'] is None
	assert result['dislike_count'] is None
	assert result['average_rating'] is None
	assert result['tags'] == []

# Generated at 2022-06-22 08:28:27.695943
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # constructor of class SoundgasmProfileIE
    SoundgasmProfileIE(InfoExtractor())

# Generated at 2022-06-22 08:28:32.559430
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import _add_ns, test_youtube_dl

    url = 'http://soundgasm.net/u/ytdl'
    result = {
        'id': 'ytdl'
    }

    _add_ns(globals())
    test_youtube_dl(globals(), locals(), [url], result)