

# Generated at 2022-06-22 08:18:32.653255
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == 'soundgasm'


# Generated at 2022-06-22 08:18:37.843244
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    IE_TEST_URL = 'http://soundgasm.net/u/ytdl'
    # This test verifies that all methods are defined for the class constructor
    # instance given the input URL. Methods are defined for this class as
    # methods that start with ie_ (ie: _real_extract).
    ie = SoundgasmProfileIE(IE_TEST_URL)
    test_methods = filter(lambda x: x.startswith('ie_'), dir(ie))
    assert(len(test_methods) > 0)

# Generated at 2022-06-22 08:18:39.345061
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
        video = SoundgasmProfileIE().get_testcases()



# Generated at 2022-06-22 08:18:42.926554
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasmIE = SoundgasmIE()
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    t = soundgasmIE._real_extract(url)

# Generated at 2022-06-22 08:18:44.253196
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE("SoundgasmProfileIE", "soundgasm")

# Generated at 2022-06-22 08:18:55.530292
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sr = SoundgasmProfileIE()
    url1 = 'http://soundgasm.net/u/ytdl'
    url2 = 'http://soundgasm.net/u/ytdl#comments'
    url3 = 'http://soundgasm.net/u/ytdl#following'
    url4 = 'http://soundgasm.net/u/ytdl#favorites'
    url5 = 'http://soundgasm.net/u/ytdl#stream'
    assert sr._match_id(url1) == 'ytdl'
    assert sr._match_id(url2) == 'ytdl'
    assert sr._match_id(url3) == 'ytdl'
    assert sr._match_id(url4) == 'ytdl'
    assert sr._match_

# Generated at 2022-06-22 08:18:56.065172
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-22 08:19:00.918184
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    "Initialize SoundgasmProfileIE object with test data"
    url = "http://soundgasm.net/u/ytdl"
    SoundgasmProfileIE(url)

# Generated at 2022-06-22 08:19:05.873273
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:19:09.785361
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    _ = SoundgasmIE()


# Generated at 2022-06-22 08:19:14.425594
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()
    print(obj)

# Generated at 2022-06-22 08:19:23.671854
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    s = SoundgasmProfileIE()
    user_name = 'ytdl'
    url = 'http://soundgasm.net/u/' + user_name
    assert s._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert s._real_extract('http://soundgasm.net/u/' + user_name)
    assert s._real_extract('http://soundgasm.net/u/' + user_name + '/')
    assert s._real_extract('http://soundgasm.net/u/' + user_name + '/#')

# Generated at 2022-06-22 08:19:33.167281
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test = SoundgasmProfileIE({'id': 'ytdl'}, {})

    assert test.IE_NAME == 'SoundgasmProfileIE'
    assert test._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert test._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}


# Generated at 2022-06-22 08:19:35.251621
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME =='soundgasm:profile'




# Generated at 2022-06-22 08:19:39.757295
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # test for url == 'http://soundgasm.net/u/ytdl'
    test_url = 'http://soundgasm.net/u/ytdl'
    assert SoundgasmProfileIE().suitable(test_url) == True

# Generated at 2022-06-22 08:19:43.319758
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # check SoundgasmIE object constructor
    SoundgasmIE()

    # check whether it checks SoundgasmIE._VALID_URL
    test_SoundgasmIE = SoundgasmIE()
    with pytest.raises(RegexNotFoundError):
        test_SoundgasmIE.extract('http://soundgasm.net/u/ytdl/')



# Generated at 2022-06-22 08:19:48.368771
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = "https://soundgasm.net/u/ytdl/"
    profile_id = "ytdl"

    instance = SoundgasmProfileIE(url)
    assert isinstance(instance, SoundgasmProfileIE)

    assert_equal(instance.valid_id(url), True)
    assert_equal(instance.match_id(url), profile_id)

# Generated at 2022-06-22 08:19:52.932508
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	try:
		assert SoundgasmIE.__bases__[0] == InfoExtractor
		print("Unit test for constructor of class SoundgasmIE is ok.")
	except AssertionError:
		print("Unit test for constructor of class SoundgasmIE is fail.")


# Generated at 2022-06-22 08:19:56.889978
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-22 08:19:58.629573
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()._real_extract('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-22 08:20:07.242911
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'SoundgasmProfileIE'

# Generated at 2022-06-22 08:20:17.244526
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import InfoExtractor
    from .common import unescapeHTML
    from .soundgasm import SoundgasmProfileIE
    from .compat import compat_urlparse
    # Test for fetching all audios
    def test_fetch_all_audios(self):
        def _extract_entries(url):
            # Correcting the url
            url = url.replace('ytdl', 'ztfytdl')
            webpage = self._download_webpage(url, '1')
            audio_id_regex = r'/([^/]+)/'
            audio_ids = re.findall(audio_id_regex, webpage)
            # Generating audios' URLs

# Generated at 2022-06-22 08:20:21.054979
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        print (SoundgasmProfileIE)
    except:
        print ('Unexpected error:', sys.exc_info()[0])
        raise


# Generated at 2022-06-22 08:20:25.610044
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pl = SoundgasmProfileIE('audio')
    assert(pl.IE_NAME == 'soundgasm:profile')
    assert(pl._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')

# Generated at 2022-06-22 08:20:27.307565
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    class_SoundgasmProfileIE = SoundgasmProfileIE()



# Generated at 2022-06-22 08:20:36.972100
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    a = IE_NAME('http://soundgasm.net/u/ytdl/Piano-sample')
    assert a.IE_NAME == 'soundgasm'
    assert a._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:20:47.798549
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    __name__ = '__main__'
    test = SoundgasmIE()
    test._download_webpage = lambda url: r'''
<div class="play-btn jp-play-me m4a" data-title="Piano sample" data-jp-field="{&quot;m4a&quot;:&quot;http:\/\/soundgasm.net\/media\/audios\/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a&quot;,&quot;oga&quot;:&quot;http:\/\/soundgasm.net\/media\/audios\/88abd86ea000cafe98f96321b23cc1206cbcbcc9.ogg&quot;}"></div>
'''
    result = test._real

# Generated at 2022-06-22 08:20:51.257942
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    class SoundgasmProfileIE1(SoundgasmProfileIE):
        def __init__(self):
            SoundgasmProfileIE.__init__(self)
    SoundgasmProfileIE1()

# Generated at 2022-06-22 08:20:53.513938
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")


# Generated at 2022-06-22 08:21:05.817821
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:21:23.383325
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    IE = SoundgasmIE()
    obj = IE.extract(url)
    print(obj['uploader'])

if __name__ == "__main__":
    test_SoundgasmIE()

# Generated at 2022-06-22 08:21:30.842566
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    # Test for _VALID_URL
    wp = webparser.WebParser('http://soundgasm.net/u/ytdl/Piano-sample', ie)
    # Test for _extract_url
    wp.download_webpage()
    assert 'm4a' in wp.webpage
    assert 'jp-title' in wp.webpage
    assert 'jp-description' in wp.webpage


# Generated at 2022-06-22 08:21:32.250248
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    f = SoundgasmIE()
    assert f.IE_NAME == 'soundgasm'

# Generated at 2022-06-22 08:21:39.450146
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile = SoundgasmProfileIE(url);
    assert(profile.IE_NAME == 'soundgasm:profile')
    assert(profile.IE_DESC == 'soundgasm.net user profile')
    assert(profile.test_soundgasm_profile_urls(url) == True)
    assert(profile._match_id(url) == 'ytdl')

# Generated at 2022-06-22 08:21:46.212859
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from collections import defaultdict
    from .html5 import AudioIE
    video_list = defaultdict(lambda: defaultdict(list))
    for ie in gen_extractors(AudioIE, False):
        if ie.IE_NAME != 'Soundgasm': continue
        ie._build_extractor()
        if ie.IE_NAME != 'SoundgasmProfile': continue
        if ie.IE_NAME not in video_list: video_list[ie.IE_NAME] = defaultdict(list)
        url = 'http://soundgasm.net/u/ytdl/Piano-sample'
        webpage = ie._download_webpage(url, 'test')
        entries = ie._entries_from_url(url, webpage, None, None)

# Generated at 2022-06-22 08:21:47.230599
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:21:53.482617
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    

# Generated at 2022-06-22 08:21:59.961233
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    result = {
        'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
        'ext': 'm4a',
        'title': 'Piano sample',
        'description': 'Royalty Free Sample Music',
        'uploader': 'ytdl'
    }

    assert SoundgasmIE()._real_extract('http://soundgasm.net/u/ytdl/Piano-sample') == result
#Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-22 08:22:05.634651
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    yt_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    yt_ie = SoundgasmIE()
    yt_ie._downloader = None
    yt_ie.download(yt_url)



# Generated at 2022-06-22 08:22:15.551184
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class TestSoundgasmIE(SoundgasmIE):
        _TEST = {
            'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
            'md5': '010082a2c802c5275bb00030743e75ad',
            'info_dict': {
                'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
                'ext': 'm4a',
                'title': 'Piano sample',
                'description': 'Royalty Free Sample Music',
                'uploader': 'ytdl',
            }
        }

        def _real_extract(self, url):
            return SoundgasmIE._real_extract(self, url)


# Generated at 2022-06-22 08:22:52.299562
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie_obj = SoundgasmProfileIE(referer='http://soundgasm.net/u/ytdl')
    assert ie_obj is not None

# Generated at 2022-06-22 08:22:55.213910
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    #assert 1==1
    assert 1==2


# Generated at 2022-06-22 08:22:57.792626
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print('Constructing class SoundgasmIE')
    ob1 = SoundgasmIE()
    print('Constructed class SoundgasmIE')
    return ob1

# Generated at 2022-06-22 08:23:01.767063
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert SoundgasmProfileIE._VALID_URL == 'https?://(?:www\\.)?soundgasm\\.net/u/(?P<id>[^/]+)/?(?:\\#.*)?$'


# Generated at 2022-06-22 08:23:10.772589
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    webpage = "http://soundgasm.net/u/ytdl/Piano-sample"
    server_response_string = r'<div[^>]+\bclass=["\']jp-title[^>]+>([^<]+)</div>\s*<div[^>]+\bclass=["\']jp-description[^>]+>([^<]+)</div>\s*<div[^>]+\bclass=["\']jp-time-holder[^>]+>[^<]+<div[^>]+\bdata-duration=["\']([0-9]+)'
    url = "http://soundgasm.net/u/ytdl/Piano-sample"

# Generated at 2022-06-22 08:23:16.481143
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    info = SoundgasmProfileIE().extract(url)
    assert(info.get('id') == 'ytdl')

# Generated at 2022-06-22 08:23:17.124930
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-22 08:23:20.046380
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()


# Generated at 2022-06-22 08:23:22.660891
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_SoundgasmIE = SoundgasmIE()
    assert(test_SoundgasmIE)

# Generated at 2022-06-22 08:23:27.184745
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-22 08:24:51.213896
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-22 08:24:54.606815
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE("http://soundgasm.net/u/ytdl") == SoundgasmProfileIE("http://soundgasm.net/u/ytdl/")

# Generated at 2022-06-22 08:24:56.462102
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Should not fail because the constructor calls the constructor of SoundgasmIE
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:25:01.661243
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE
    obj = ie('SoundgasmProfileIE', test=True)
    assert hasattr(obj, '_download_webpage')
    assert hasattr(obj, '_match_id')
    assert hasattr(obj, '_real_extract')
    assert hasattr(obj, '_VALID_URL')
    assert hasattr(obj, 'url_result')
    assert hasattr(obj, 'playlist_result')

# Generated at 2022-06-22 08:25:05.896303
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    obj = SoundgasmIE(url)
    assert obj.url == url
    assert obj.match == re.match(SoundgasmIE._VALID_URL, url)

# Generated at 2022-06-22 08:25:17.337314
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	
	#Test 1
	SoundgasmIE()._download_webpage('https://soundgasm.net/u/ytdl/Piano-sample', 'Piano-sample')

	# Test 2
	SoundgasmIE()._search_regex('<div[^>]+\bclass=["\']jp-title[^>]+>([^<]+)', '<div class="jp-title" id="orff-title"><ul><li>Orff-style music</li></ul></div>', 'title', default='Piano-sample')

	# Test 3
    #SoundgasmIE()._search_regex('https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-z

# Generated at 2022-06-22 08:25:19.401046
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	for item in unit_test_info_extractors_generator(SoundgasmProfileIE):
		yield item

# Generated at 2022-06-22 08:25:22.733871
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = "http://soundgasm.net/u/ytdl"
    assert(SoundgasmProfileIE._VALID_URL == re.compile(SoundgasmProfileIE._VALID_URL).match(url).re.pattern)


# Generated at 2022-06-22 08:25:33.442028
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .test import TEST_DATA_DIR
    from .test_soundcloud import _TEST_URL, _TEST_TITLE, _TEST_DESCRIPTION, _TEST_THUMBNAIL_URL, _TEST_UPLOADER
    from soundgasmie import SoundgasmIE
    from soundgasmie import SoundGasmIE
    soundgasm_ie = SoundgasmIE()

    assert soundgasm_ie.ie_key() == 'Soundgasm'
    assert soundgasm_ie.ie_name() == 'Soundgasm'

    # Test with the actual list of qualities
    TEST_FILE = 'http://soundgasm.net/u/ytdl/Piano-sample'

# Generated at 2022-06-22 08:25:41.674942
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from soundgasm_profile_ie import SoundgasmProfileIE
    from youtube_dl import YoutubeDL
    url = 'http://soundgasm.net/u/ytdl'
    inst = SoundgasmProfileIE(YoutubeDL())
    inst._real_extract(url)
    assert inst._match_id(url) == 'ytdl'