

# Generated at 2022-06-22 08:18:39.767858
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # As a side note, the credentials provided here are dummy ones (the password is invalid)
    soundgasm = SoundgasmProfileIE({'username': 'ytdl', 'password': 'ytdl'})
    assert soundgasm

# Generated at 2022-06-22 08:18:41.643815
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	SoundgasmProfileIE('SoundgasmProfileIE', 'soundgasm.net')


# Generated at 2022-06-22 08:18:43.344544
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    h = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    # print h._TEST

# Generated at 2022-06-22 08:18:46.657190
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Simple unit test for SoundgasmIE
    """
    from . import  _test_playlist_class_by_id
    _test_playlist_class_by_id('SoundgasmIE', 'input_soundgasm_url', 'input_expected_title')

# Generated at 2022-06-22 08:18:47.434627
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:18:56.340001
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Test case to check the constructor of class SoundgasmIE
    """
    assert SoundgasmIE()._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert SoundgasmIE().IE_NAME == 'soundgasm'
    assert SoundgasmIE()._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample', "Test did not run correctly"

# Generated at 2022-06-22 08:19:01.819889
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Test class SoundgasmProfileIE."""
    # Create an instance of class SoundgasmProfileIE
    ie = SoundgasmProfileIE()
    # Test _real_extract method
    ie._real_extract('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-22 08:19:06.925376
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import unittest
    import youtube_dl.extractor.soundgasm as soundgasm
    class TestSoundgasmIE(unittest.TestCase):
        def test_SoundgasmIE(self):
            print("Testing SoundgasmIE")
            self.assertTrue(soundgasm.SoundgasmIE)
    unittest.main()

# Generated at 2022-06-22 08:19:17.258833
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = SoundgasmProfileIE._match_id(url)
    webpage = SoundgasmProfileIE._download_webpage(url, profile_id)
    entries = [
        SoundgasmProfileIE.url_result(audio_url, 'Soundgasm')
        for audio_url in re.findall(r'href="([^"]+/u/%s/[^"]+)' % profile_id, webpage)]

# Generated at 2022-06-22 08:19:22.268555
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SG = SoundgasmIE()
    assert SG._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-22 08:19:33.379330
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-22 08:19:42.641176
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Check out the test_url_SoundgasmIE method to understand why I need to save the files in a temporary folder

    # library/* is the folder where the audio files are saved
    # We use os to make our way to the library folder
    import os
    import shutil
    # Let's get the path of the current page
    local_url = os.path.dirname(os.path.abspath(__file__))
    # Let's go two levels above to have the path of the soundgasm folder
    soundgasm_folder = os.path.abspath(os.path.join(local_url, '..', '..'))
    # Let's create a temporary folder to save the audio files
    temp_folder_name = 'temp_audio'

# Generated at 2022-06-22 08:19:47.260512
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_url = 'http://soundgasm.net/u/ytdl'
    soundgasm = SoundgasmProfileIE()
    assert(soundgasm.IE_NAME == "soundgasm:profile")
    assert(soundgasm.IE_NAME == test_url[test_url.rfind('/') + 1:])

# Generated at 2022-06-22 08:19:48.276047
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()



# Generated at 2022-06-22 08:19:56.417683
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    testCase = type('UnitTest', (object,), {'assertEqual': lambda a, b: print(str(a)+' = '+str(b))})()
    soundgasm = SoundgasmProfileIE()
    profile_id = 'ytdl'
    url = 'https://soundgasm.net/u/'+profile_id
    webpage = soundgasm._download_webpage(url, profile_id)
    entries = re.findall(r'href="http://soundgasm.net/u/([^"]+/[^"]+)', webpage)
    for audio_url in entries:
        print(soundgasm.url_result(audio_url, 'Soundgasm'))


# Generated at 2022-06-22 08:19:58.382827
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL == SoundgasmProfileIE._VALID_URL

# Generated at 2022-06-22 08:20:00.465805
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile_ie = SoundgasmProfileIE()
    assert soundgasm_profile_ie is not None


# Generated at 2022-06-22 08:20:02.751952
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	soundgasm.SoundgasmIE()


# Generated at 2022-06-22 08:20:12.784056
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-22 08:20:18.029156
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print(SoundgasmProfileIE('http://www.soundgasm.net/u/ytdl').IE_NAME)
    print(SoundgasmProfileIE('http://www.soundgasm.net/u/ytdl/foobar').IE_NAME)
    print(SoundgasmProfileIE('http://www.soundgasm.net/u/foo/bar'))

# Generated at 2022-06-22 08:20:42.575620
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print('Testing constructor')
    audioIE = SoundgasmIE()
    assert audioIE.suitable('http://soundgasm.net/u/ytdl/Piano-sample') is True
    assert audioIE.suitable('http://soundgasm.net/u/') is False
    assert audioIE._VALID_URL == '(?i)https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-22 08:20:49.021965
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .common import parse_duration

    URL = 'http://soundgasm.net/u/ytdl/Piano-sample'
    Soundgasm = SoundgasmIE()
    result = Soundgasm.extract(URL)
    assert result['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert result['uploader'] == 'ytdl'
    assert result['ext'] == 'm4a'
    assert result['title'] == 'Piano sample'
    assert result['thumbnail'] is None
    assert result['duration'] == 18.752
    assert result['view_count'] is None


# Generated at 2022-06-22 08:20:52.940393
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        SoundgasmProfileIE(SoundgasmProfileIE.IE_NAME, SoundgasmProfileIE._VALID_URL, 'Soundgasm')
    except ValueError:
        assert True

# Generated at 2022-06-22 08:20:55.787941
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://www.soundgasm.net/u/ytdl')
    assert ie.ie_key() == 'Soundgasm'

# Generated at 2022-06-22 08:21:07.830532
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-22 08:21:19.404140
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'Soundgasm'
    assert ie.IE_DESC == 'Soundgasm audio files'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:21:21.548657
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    print(ie)
    assert ie

# Generated at 2022-06-22 08:21:23.974244
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    constructor_test(SoundgasmProfileIE)


# Generated at 2022-06-22 08:21:29.082257
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/tralalalala/Piano-sample'
    obj = SoundgasmIE()._real_extract(url)
    assert(obj.get('id') == '88abd86ea000cafe98f96321b23cc1206cbcbcc9')

# Generated at 2022-06-22 08:21:31.755009
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-22 08:21:49.509964
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  
  url = "http://soundgasm.net/u/ytdl"
  assert SoundgasmProfileIE._match_id(url) == "ytdl"
  assert SoundgasmProfileIE._real_extract(url) == {
    'id': 'ytdl',
  }

# Generated at 2022-06-22 08:21:51.428305
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()._real_extract("http://soundgasm.net/u/ytdl")


# Generated at 2022-06-22 08:21:53.186895
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    tester = SoundgasmProfileIE('SoundgasmProfile')
    assert tester != None

# Generated at 2022-06-22 08:21:55.180313
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import TestIE

    soundgasm_profile = TestIE.TestSoundgasmProfile('SoundgasmProfile')
    print(soundgasm_profile)
    print(soundgasm_profile.info())
    print(soundgasm_profile.playlist_count())


# Generated at 2022-06-22 08:21:56.309740
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	SoundgasmIE(None, None)


# Generated at 2022-06-22 08:22:07.575599
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasmIE = SoundgasmIE('SoundgasmIE','http://soundgasm.net/u/ytdl/Piano-sample')
    assert soundgasmIE._SOUNDGASMIE__VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert soundgasmIE._SOUNDGASMIE__TEST['url'] =='http://soundgasm.net/u/ytdl/Piano-sample'
    assert soundgasmIE._SOUNDGASMIE__TEST['md5'] == '010082a2c802c5275bb00030743e75ad'
    assert soundgasm

# Generated at 2022-06-22 08:22:12.630426
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    key_value_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    mo = ie._VALID_URL.match(key_value_url)
    assert mo.group('user') == 'ytdl'
    assert mo.group('display_id') == 'Piano-sample'
    assert True

# Generated at 2022-06-22 08:22:19.775755
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-22 08:22:24.177562
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	url = 'http://soundgasm.net/u/ytdl'
	ie = SoundgasmProfileIE(url)
	assert ie.IE_NAME == 'SoundgasmProfile'
	assert ie.URL == 'http://soundgasm.net/u/ytdl'

# Generated at 2022-06-22 08:22:30.867300
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE(None)
    assert(instance.IE_NAME == 'soundgasm:profile')
    assert(instance.VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
    assert(instance._TEST['url'] == 'http://soundgasm.net/u/ytdl')


# Generated at 2022-06-22 08:22:55.692846
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    x = SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
# Test executing a real world example - extract a user profile playlist

# Generated at 2022-06-22 08:22:57.900085
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-22 08:23:00.434051
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # An error occurs when there are no audios in a profile.
    # The constructor should handle this gracefully.
    profile = SoundgasmProfileIE()

# Generated at 2022-06-22 08:23:02.466951
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-22 08:23:06.617543
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	url = 'http://soundgasm.net/u/ytdl/Piano-sample'
	result = SoundgasmIE().extract(url)
	assert result['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'


# Generated at 2022-06-22 08:23:07.337080
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_instance = SoundgasmIE({})
    assert soundgasm_instance


# Generated at 2022-06-22 08:23:09.167521
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE = SoundgasmIE()
    assert not IE._valid_url("http://example.com")
    IE.suite()

# Generated at 2022-06-22 08:23:12.686888
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie.suitable(url), 'Test wrong URL is not suitable'
    assert ie.suitable(url) == ie._VALID_URL, 'Test wrong URL is not suitable'
    assert ie.IE_NAME == 'soundgasm', 'Test IE name is wrong'

# Generated at 2022-06-22 08:23:15.916503
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    p = SoundgasmProfileIE()
    instance = p._make_instance()
    assert instance.IE_NAME == 'Soundgasm Profile'

# Generated at 2022-06-22 08:23:18.592822
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        test_SoundgasmProfileIE.profile = SoundgasmProfileIE('test-id')
    except Exception as exc:
        return False
    return True

# Generated at 2022-06-22 08:23:56.721790
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    ie.initialize()
    return ie

# Generated at 2022-06-22 08:24:04.224862
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

    assert ie.IE_NAME == 'soundgasm'

    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-22 08:24:14.084077
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

	# Test values (id, display_id, audio_id and title) are obtained from the
	# url above.
	# Make sure that in each test the type of each attribute is the same that
	# the one implemented in the class.
	# Otherwise, the test fails.
	testAttributes = [("Piano-sample", "88abd86ea000cafe98f96321b23cc1206cbcbcc9", "88abd86ea000cafe98f96321b23cc1206cbcbcc9", "Piano sample")]

	for attributes in testAttributes:
		testIE = SoundgasmIE()
		assert testIE.IE_NAME == 'soundgasm'
		assert testIE._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'


# Generated at 2022-06-22 08:24:24.736984
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:24:33.894311
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE.ie_key() == 'soundgasm'
    assert SoundgasmIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert SoundgasmIE._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert SoundgasmIE._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'
    assert SoundgasmIE._TEST['info_dict']['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
   

# Generated at 2022-06-22 08:24:36.040925
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("test")._real_extract("test") == SoundgasmIE("test")._real_extract("test")


# Generated at 2022-06-22 08:24:47.498558
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """ test constructor of class SoundgasmIE. """
    ie = SoundgasmIE(None)
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:24:57.960497
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    This function checks if SoundgasmIE is constructed properly.
    """
    # Creating the SoundgasmIE object.
    sg = SoundgasmIE()
    assert sg._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:25:04.289746
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # This is the test for constructor of class SoundgasmProfileIE
    url = 'http://soundgasm.net/u/ytdl'
    IE = SoundgasmProfileIE()
    IE.IE_NAME = 'Soundgasm'
    info_dict = IE._real_extract(url)
    print(info_dict)



# Generated at 2022-06-22 08:25:10.030933
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_id = 'ytdl'
    profile_url = 'http://soundgasm.net/u/ytdl'
    extractor = SoundgasmProfileIE()
    
    assert extractor._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert extractor.IE_NAME == 'soundgasm:profile'
    assert extractor._match_id(profile_url) == profile_id

# Generated at 2022-06-22 08:26:27.230661
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import unittest
    import os
    import sys
    import shutil
    sys.path.append('..')

    class TempFile(object):
        def __init__(self, content=None):
            self.content = content

        def getContent(self):
            return self.content

    class FakeHttpServer(object):
        def __init__(self, response=None):
            self.response = response

        def download(self, url, filename=None, params=None, retries=None):
            return TempFile(self.response)

    class SoundgasmUnitTest(unittest.TestCase):
        def test_SoundgasmIE(self):
            self._save_file()


# Generated at 2022-06-22 08:26:35.871798
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    assert_raises(RegexNotFoundError, ie._real_extract, "http://soundgasm.net/u/ytdl")


# Generated at 2022-06-22 08:26:46.680504
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-22 08:26:48.386069
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()._VALID_URL == SoundgasmIE._VALID_URL

# Generated at 2022-06-22 08:26:58.443983
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_instance = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert test_instance.IE_NAME == 'soundgasm'
    assert test_instance.VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert test_instance.TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert test_instance.TEST['info_dict']['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert test_instance.TEST

# Generated at 2022-06-22 08:26:59.741446
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl/")

# Generated at 2022-06-22 08:27:06.533661
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    print(vars(soundgasm))
    assert soundgasm.IE_NAME == 'soundgasm'
    assert soundgasm._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:27:09.238054
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    IG = SoundgasmIE()
    obj = IG._call_IE(url)

# Generated at 2022-06-22 08:27:13.419957
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('https://soundgasm.net/u/ytdl') == SoundgasmProfileIE('http://soundgasm.net/u/ytdl/?#page=1')



# Generated at 2022-06-22 08:27:16.357847
# Unit test for constructor of class SoundgasmIE