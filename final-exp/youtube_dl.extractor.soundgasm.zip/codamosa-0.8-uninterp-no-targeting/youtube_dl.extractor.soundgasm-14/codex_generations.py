

# Generated at 2022-06-22 08:18:33.541223
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.__name__ == 'SoundgasmProfileIE'
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'


# Generated at 2022-06-22 08:18:37.686953
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE()
    assert(instance.IE_NAME == "soundgasm:profile")

# Generated at 2022-06-22 08:18:43.311605
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    input_url = "http://soundgasm.net/u/ytdl"
    profile_ie = SoundgasmProfileIE()
    assert profile_ie.suitable(input_url), "data should be suitable for SoundgasmProfileIE class"
    profile_data = profile_ie.extract(input_url)
    assert profile_data['id'] == 'ytdl', "id should be ytdl"

# Generated at 2022-06-22 08:18:45.467308
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_url = 'http://soundgasm.net/u/ytdl'
    test_instance = SoundgasmProfileIE()
    test_instance.extract(test_url)

# Generated at 2022-06-22 08:18:46.960088
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-22 08:18:58.162647
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == 'soundgasm'
    assert SoundgasmIE().VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:19:10.426336
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    #Test SoundgasmIE constructor
    IE = SoundgasmIE()
    assert IE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert IE.IE_NAME == 'soundgasm'

# Generated at 2022-06-22 08:19:13.179858
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE('Soundgasm', None, -1)

# Generated at 2022-06-22 08:19:23.578495
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    web_page = 'http://soundgasm.net/u/ytdl/Piano-sample'
    test_container = ie._real_extract(web_page)

    # Test the id
    id = ie._search_regex(
            r'/([^/]+)\.m4a', test_container['url'], 'audio id', default=test_container['display_id'])
    assert id == test_container['id']

    # Test the title
    title = ie._html_search_regex(
            r'<div[^>]+\bclass=["\']jp-title[^>]+>([^<]+)',
            webpage, 'title', default=test_container['display_id'])
    assert title

    # Test the description
    description = ie._

# Generated at 2022-06-22 08:19:25.782912
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE()._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')


# Generated at 2022-06-22 08:19:33.811390
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print('test_SoundgasmIE:')
    e = SoundgasmIE()
    print('  e.IE_NAME: %s' % e.IE_NAME)
    print('  e._VALID_URL: %s' % e._VALID_URL)
    print('  e._TEST: %s' % e._TEST)
    print()


# Generated at 2022-06-22 08:19:45.819843
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    page_id = "Piano-sample"

    _TEST = {
        'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
        'md5': '010082a2c802c5275bb00030743e75ad',
        'info_dict': {
            'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
            'ext': 'm4a',
            'title': 'Piano sample',
            'description': 'Royalty Free Sample Music',
            'uploader': 'ytdl',
        }
    }

    extractor = SoundgasmIE()
    extractor.extract(_TEST)
    # Test for found info

# Generated at 2022-06-22 08:19:47.123016
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	pass


# Generated at 2022-06-22 08:19:52.262998
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url ='http://soundgasm.net/u/ytdl'
    profile_IE = SoundgasmProfileIE()
    assert profile_IE.IE_NAME == 'soundgasm:profile'
    assert profile_IE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-22 08:19:52.775186
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert False

# Generated at 2022-06-22 08:19:55.701071
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Create SoundgasmIE instance class_test_SoundgasmIE"""
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-22 08:20:00.094524
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == "soundgasm"
    assert ie.VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-22 08:20:11.409677
# Unit test for constructor of class SoundgasmIE

# Generated at 2022-06-22 08:20:17.013054
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    _TEST = {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    s = SoundgasmProfileIE()
    r = s._call_api(s, _TEST)
    assert isinstance(s, SoundgasmProfileIE)

# Generated at 2022-06-22 08:20:29.107723
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE()
    assert instance.IE_NAME == 'soundgasm'
    assert instance._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:20:44.571912
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.IE_NAME == 'SoundgasmProfileIE'
    assert ie.VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}

# Generated at 2022-06-22 08:20:55.068096
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    IE = SoundgasmIE()
    # PASS: URL pattern is matched
    #        URL is matched
    test_url1 = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert IE.suitable(test_url1) == True
    test_url2 = 'http://soundgasm.net/u/ytdl/Piano-sample.mp4'
    assert IE.suitable(test_url2) == False
    # FAIL: URL is not matched
    test_url3 = 'http://soundgasm.net/'
    assert IE.suitable(test_url3) == False


# Generated at 2022-06-22 08:21:01.658881
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_ie = SoundgasmIE()
    assert soundgasm_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-22 08:21:05.003354
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/([^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:21:09.647727
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    class_name = ie.__class__.__name__
    assert class_name == "SoundgasmProfileIE", "Unit test for constructor of class " + class_name + ": FAILED"


# Generated at 2022-06-22 08:21:10.738177
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE(None)._VALID_URL == SoundgasmProfileIE._VALID_URL

# Generated at 2022-06-22 08:21:12.002188
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()

# Generated at 2022-06-22 08:21:14.134572
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE(SoundgasmIE._VALID_URL).IE_NAME == 'Soundgasm'

# Generated at 2022-06-22 08:21:15.206952
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:21:21.893846
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    constructor = SoundgasmIE(InfoExtractor())
    assert ('88abd86ea000cafe98f96321b23cc1206cbcbcc9', 'm4a') == constructor._get_id_from_url('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-22 08:21:40.338448
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('soundgasm')
    if ie.IE_NAME != 'soundgasm':
        raise RuntimeError('test for SoundgasmIE failed')

# Generated at 2022-06-22 08:21:43.802073
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from . import test_utils
    from .common import SoundgasmProfileIE

    # Ensure that new instance can be created
    test_utils.ensure_name_and_id(SoundgasmProfileIE)

# Generated at 2022-06-22 08:21:48.312530
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    testObj = SoundgasmProfileIE(None, {})
    assert testObj.IE_NAME == 'soundgasm:profile'
    assert testObj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-22 08:21:54.423976
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # check for non-existing class
    result = re.match(SoundgasmProfileIE._VALID_URL, 'http://soundgasm.net/u/ytdl', flags=0)
    assert result

    # check for existing class
    result = re.match(SoundgasmProfileIE._VALID_URL, 'http://soundgasm.net/u/ytdl', flags=0)
    assert result

# Generated at 2022-06-22 08:21:59.717417
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    

# Generated at 2022-06-22 08:22:02.706308
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE(InfoExtractor)

# Generated at 2022-06-22 08:22:04.183369
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie._TEST

# Generated at 2022-06-22 08:22:07.629702
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    mg = SoundgasmProfileIE(None)
    assert mg.IE_NAME == 'soundgasm:profile'
    assert mg.IE_DESC == 'Soundgasm Profile'


# Generated at 2022-06-22 08:22:09.610073
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert(ie.IE_NAME == 'soundgasm')


# Generated at 2022-06-22 08:22:16.291180
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    with open("tests/data/soundgasm_profile.html") as f:
        webpage = f.read()
    url = "http://soundgasm.net/u/ytdl"
    profile_id = "ytdl"
    instance = SoundgasmProfileIE()
    instance.webpage = webpage
    assert len(instance._real_extract(url)) == 2
    assert instance._real_extract(url)['id'] is profile_id
    assert len(instance._real_extract(url)['entries']) == 2


# Generated at 2022-06-22 08:22:56.567790
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert isinstance(ie, SoundgasmIE)

# Generated at 2022-06-22 08:23:06.301757
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Constructor of SoundgasmIE class
    info_extractor = SoundgasmIE()

    # url of the audio page
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    # extract information from the webpage
    result = info_extractor._real_extract(url)

    assert result['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert result['url'] == 'http://soundgasm.net/f/snd/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    assert result['title'] == 'Piano sample'
    assert result['description'] == 'Royalty Free Sample Music'

# Generated at 2022-06-22 08:23:08.538000
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE()

# Generated at 2022-06-22 08:23:09.810990
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'

# Generated at 2022-06-22 08:23:13.244072
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    # Test to instantiate
    ie = SoundgasmProfileIE('ytdl')

    # Test the url that must be parsed
    url = 'http://soundgasm.net/u/ytdl'

    assert ie.suitable(url) == True
    info = ie.extract(url)

    # Check that the required fields are in the parsed info
    assert info['id'] == 'ytdl'
    assert 'playlist_mincount' in info

# Generated at 2022-06-22 08:23:21.438468
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio_url = "https://soundgasm.net/u/dolatsabz/Piano-sample"
    audio_id = "dolatsabz_Piano-sample"
    title = "Piano sample by dolatsabz"
    description = "Royalty Free Sample Music"
    audio = SoundgasmIE(audio_url, "dolatsabz")

    assert(audio.id == audio_id)
    assert(audio.title == title)
    assert(audio.description == description)
    assert(audio.uploader == "dolatsabz")
    assert(audio.ext == "m4a")


# Generated at 2022-06-22 08:23:23.293893
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()._real_extract("https://soundgasm.net/u/ytdl")

# Generated at 2022-06-22 08:23:26.537128
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	from . import SoundgasmProfileIE
	import json
	config = {}
	config_file = open('song_config.json')
	config = json.load(config_file)
	url = config['soundgasm_profile_url']
	IE = SoundgasmProfileIE(url)

if __name__ == '__main__':
	test_SoundgasmProfileIE()

# Generated at 2022-06-22 08:23:28.629269
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sdg = SoundgasmIE()
    assert sdg.IE_NAME == 'soundgasm'

# Generated at 2022-06-22 08:23:40.680838
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import sys

    if sys.version_info < (2, 7, 0):
        import unittest2 as unittest
    else:
        import unittest
    from unittest.mock import MagicMock

    class MyTestCase(unittest.TestCase):
        TEST_EMPTY_PARAMS = 'test_empty_params'
        TEST_FULL_PARAMS = 'test_full_params'

        def get_case(self):
            if sys.version_info < (3, 3):
                return self._get_case()
            else:
                return super().get_case()

        def _get_case(self):
            return self.id().split('.')[-1]

        def test_empty_params(self):
            self.assertIsInstance(SoundgasmIE(), SoundgasmIE)

# Generated at 2022-06-22 08:25:17.433354
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE(): # Added by Rohan
    assert SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert SoundgasmProfileIE('http://soundgasm.net/u/ytdl/')
    assert SoundgasmProfileIE('http://soundgasm.net/u/ytdl/#')
    assert SoundgasmProfileIE('http://soundgasm.net/u/ytdl/#/')

# Generated at 2022-06-22 08:25:25.185613
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """ test_SoundgasmIE class tests the correct constructor and init of SoundgasmIE """
    # test constructor of SoundgasmIE
    ie = SoundgasmIE()
    assert ie.ie_key() == 'Soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:25:27.651509
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert url == SoundgasmIE()._match_id(url)


# Generated at 2022-06-22 08:25:32.128939
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    if(ie):
        print("Constructor of class SoundgasmIE is binded sucessfully")
    else:
        print("Constructor of class SoundgasmIE is binded unsucessfully")


# Unit test

# Generated at 2022-06-22 08:25:41.254620
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    downloader = SoundgasmIE()
    info_dict = downloader.extract(url)
    assert info_dict['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert info_dict['title'] == 'Piano sample'
    assert info_dict['uploader'] == 'ytdl'
    assert info_dict['description'] == 'Royalty Free Sample Music'
    assert info_dict['ext'] == 'm4a'


# Generated at 2022-06-22 08:25:42.902046
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE()
    except Exception:
        assert False

# Generated at 2022-06-22 08:25:44.600760
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	soundgasmIE = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-22 08:25:47.787858
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    constructor = SoundgasmProfileIE.__bases__[0].__init__
#    constructor(
#        SoundgasmProfileIE, 'http://soundgasm.net/u/ytdl', {},
#        lambda x: True)

# Generated at 2022-06-22 08:25:49.445680
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('url')
    assert ie.IE_NAME == 'soundgasm'
    

# Generated at 2022-06-22 08:25:58.097830
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'https://github.com/ytdl-org/youtube-dl/blob/master/test/test_soundgasm.py'
    print(url)
    soundgasm = SoundgasmProfileIE(url)
    assert soundgasm._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'