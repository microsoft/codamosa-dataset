

# Generated at 2022-06-22 08:18:34.041624
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert SoundgasmProfileIE._VALID_URL.match('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-22 08:18:45.779263
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class TestSoundgasmIE(SoundgasmIE):
        IE_NAME = 'TestSoundgasmIE'
    
    ies = TestSoundgasmIE.ies
    ies.append(TestSoundgasmIE)

    ie = TestSoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample', {})
    assert ie.ie_key() == 'TestSoundgasmIE'


# Generated at 2022-06-22 08:18:49.253224
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    obj = SoundgasmProfileIE()
    valid_url = obj._VALID_URL
    assert re.match(valid_url, url) is not None

# Generated at 2022-06-22 08:18:50.686798
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	from soundgasm_ie import SoundgasmProfileIE


# Generated at 2022-06-22 08:18:52.042032
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	#assert issubclass(SoundgasmIE, InfoExtractor)
	return

# Generated at 2022-06-22 08:18:56.688676
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'SoundgasmProfileIE'
    assert ie.IE_DESC == 'Soundgasm playlist'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-22 08:19:05.523886
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_cases = [
        # test if the constructor of SoundgasmProfileIE can recognize a soundgasm profile
        {
            'url': 'http://soundgasm.net/u/ytdl',
            'IE_NAME': 'soundgasm:profile',
        },
    ]

    for t in test_cases:
        ie = InfoExtractor.for_url(t['url'])
        assert ie.IE_NAME == t['IE_NAME']

# Generated at 2022-06-22 08:19:15.640786
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    inst = SoundgasmIE()
    assert inst._VALID_URL == '^https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)$'
    assert inst._TEST[0] == 'url'
    assert inst._TEST[1] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert inst._TEST[2] == '010082a2c802c5275bb00030743e75ad'
    assert inst._TEST[3][0] == 'id'

# Generated at 2022-06-22 08:19:17.971929
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        SoundgasmProfileIE()
    except Exception as e:
        assert e is not None # If this error occures, we are in trouble and need to fix it

# Generated at 2022-06-22 08:19:23.571121
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class_ = SoundgasmIE
    obj = class_(None)
    assert obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert obj._TEST is not None
    assert obj._downloader is None

# Generated at 2022-06-22 08:19:30.265090
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    InfoExtractor('SoundgasmProfileIE')


# Generated at 2022-06-22 08:19:37.421492
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test SoundgasmIE constructor
    ie = SoundgasmIE()
    # test for expected values of type and title
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-22 08:19:44.670408
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE('Soundgasm', 'http://soundgasm.net/u/ytdl', 'http://example.com')
    assert profile.ie_key() == 'Soundgasm'
    assert profile.ie_name() == 'SoundgasmProfile'
    assert profile.profile_id() == 'ytdl'
    assert profile.profile_url() == 'http://soundgasm.net/u/ytdl'
    assert profile.thumbnail_url() == 'http://example.com'

# Generated at 2022-06-22 08:19:55.745761
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    t = SoundgasmIE()
    assert t.IE_NAME == 'soundgasm'
    assert t.IE_DESC == 'Soundgasm'
    assert t._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert t._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert t._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-22 08:19:57.093714
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-22 08:19:58.190353
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert SoundgasmProfileIE

# Generated at 2022-06-22 08:20:07.922844
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert not re.match(SoundgasmIE._VALID_URL, 'http://www.soundgasm.net/u/ytdl')
    assert not re.match(SoundgasmIE._VALID_URL, 'http://www.soundgasm.net/u/ytdl/Piano-sample/')
    assert re.match(SoundgasmIE._VALID_URL, 'http://www.soundgasm.net/u/ytdl/Piano-sample')
    # Unit test for download of sample audio file
    # Test uses https://soundgasm.net/u/ytdl/Piano-sample
    ie = SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')
    filename = 'Piano-sample.m4a'
    out, err = ie.download

# Generated at 2022-06-22 08:20:09.540444
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Unit test for constructor of class SoundgasmProfileIE"""
    assert SoundgasmProfileIE(youtube_dl=None)

# Generated at 2022-06-22 08:20:13.494186
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-22 08:20:19.411496
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_arguments = ["http://soundgasm.net/u/ytdl/", "http://soundgasm.net/u/ytdl/", "http://soundgasm.net/u/ytdl/Piano-sample"]
    try:
        S = []
        for i in test_arguments:
            S.append(SoundgasmProfileIE(i))
    except:
        print("Constructor test failed!")


# Generated at 2022-06-22 08:20:31.268126
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_url = "http://soundgasm.net/u/ytdl"
    res = SoundgasmProfileIE()._real_extract(test_url)
    assert res['id'] == 'ytdl'
    assert len(res['entries']) >= 1

# Generated at 2022-06-22 08:20:35.424131
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
        ie = SoundgasmProfileIE()
        _VALID_URL = ie._VALID_URL
        mobj = re.match(_VALID_URL, 'http://soundgasm.net/u/ytdl/Piano-sample')
        assert mobj, 'Failed to match url of SoundgasmProfileIE'

# Generated at 2022-06-22 08:20:38.570855
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Set the url
    url = "http://soundgasm.net/u/ytdl"
    # Test the constructor of the SoundgasmProfileIE class
    ie = SoundgasmProfileIE(None)
    # Test if the input url is correct
    result = ie._real_extract(url)
    assert result["id"] == "ytdl"

# Generated at 2022-06-22 08:20:39.611355
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-22 08:20:49.935463
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio_url = 'https://soundgasm.net/u/ytdl/Piano-sample'
    # Test case: extract audio from piano sample
    test_case = [
        {
            'url': audio_url,
            'md5': '010082a2c802c5275bb00030743e75ad',
            'info_dict': {
                'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
                'ext': 'm4a',
                'title': 'Piano sample',
                'description': 'Royalty Free Sample Music',
                'uploader': 'ytdl',
            }
        }
    ]
    test_audio = SoundgasmIE()
    for entry in test_case:
        info_dict = test_audio.ext

# Generated at 2022-06-22 08:20:54.550950
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Expecting an object to be created with the given parameters
    assert SoundgasmIE('http://soundgasm.net/u/test/test-test')
    # Expecting an object to be created without arguments
    assert SoundgasmIE()
    # Expecting an object to be created without arguments
    assert SoundgasmProfileIE()

# Generated at 2022-06-22 08:20:57.107260
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	from .soundgasm import SoundgasmProfileIE
	assert SoundgasmProfileIE().ie_key() == 'SoundgasmProfileIE'

# Generated at 2022-06-22 08:21:07.008756
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    info_dict = {
        'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
        'ext': 'm4a',
        'title': 'Piano sample',
        'description': 'Royalty Free Sample Music',
        'uploader': 'ytdl',
    }
    soundgasm = SoundgasmIE()
    assert soundgasm.suitable(url) == True
    assert soundgasm._real_extract(url) == info_dict


# Generated at 2022-06-22 08:21:09.709698
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = "http://soundgasm.net/u/ytdl"
    ie = SoundgasmProfileIE(url)

# Generated at 2022-06-22 08:21:13.294151
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Instantiation
    ie = SoundgasmProfileIE()
    # Test with a valid url
    url = 'http://soundgasm.net/u/ytdl'
    assert ie.suitable(url) == True

# Generated at 2022-06-22 08:21:30.737216
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    print("Testing instantiating SoundgasmProfileIE")
    IE = SoundgasmProfileIE()
    print("Done\n")

# Generated at 2022-06-22 08:21:42.445822
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Unit test for analyzation of url
    import unittest
    import sys

    class TestSoundgasm(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super(TestSoundgasm, self).__init__(*args, **kwargs)
            self.url1 = 'http://soundgasm.net/u/ytdl/Piano-sample'
            self.url2 = 'http://soundgasm.net/u/ytdl/Piano-sample/'
            self.url3 = 'http://www.soundgasm.net/u/ytdl/Piano-sample/'
            self.url4 = 'soundgasm.net/u/ytdl/Piano-sample/'


# Generated at 2022-06-22 08:21:46.670551
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Unit test for constructor of class SoundgasmIE."""
    test_classes = [SoundgasmIE]
    for test_class in test_classes:
        obj = test_class()
        assert(obj.ie_key() == 'Soundgasm')
        assert(obj.ie_name() == 'Soundgasm')

# Generated at 2022-06-22 08:21:58.907770
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    t = SoundgasmIE()
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert t._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:22:05.361581
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Unit test for constructor of class SoundgasmIE
    """

    url = "http://soundgasm.net/u/ytdl/Piano-sample"

    soundgasmIE = SoundgasmIE(SoundgasmIE.IE_NAME)

    print (soundgasmIE._real_extract(url))

# Generated at 2022-06-22 08:22:15.351896
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    suggasm = SoundgasmIE()
    assert suggasm.IE_NAME == 'soundgasm'
    assert suggasm._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:22:22.161626
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	sg_profile_ie = SoundgasmProfileIE()
	match = re.match(r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$', 'https://soundgasm.net/u/ytdl/')
	sg_profile_ie._match_id(match)
	sg_profile_ie._real_extract('http://soundgasm.net/u/ytdl')


# Generated at 2022-06-22 08:22:30.394242
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(None)
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl', \
                        'info_dict': {'id': 'ytdl'}, \
                        'playlist_count': 1}

# Generated at 2022-06-22 08:22:34.194422
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert SoundgasmIE(SoundgasmIE._downloader)._match_id(url) == 'Piano-sample'

# Generated at 2022-06-22 08:22:41.250760
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    s = SoundgasmProfileIE('http://soundgasm.net/u/ytdl') # profile_id = 'ytdl'
    assert (s.url == 'http://soundgasm.net/u/ytdl') # s.url == 'http://soundgasm.net/u/ytdl'
    assert (s.url_result == SoundgasmIE.url_result) # s.url_result == SoundgasmIE.url_result
    assert (s.playlist_count() == 1) # s.playlist_count() == 1

# Generated at 2022-06-22 08:23:23.373693
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-22 08:23:26.469122
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._real_extract('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-22 08:23:30.815501
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl', {}, {})
    assert ie.ie_key() == 'Soundgasm'
    assert ie.suitable('http://soundgasm.net/u/ytdl')
    assert ie.suitable('ytdl')

# Generated at 2022-06-22 08:23:42.728005
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Call SoundgasmIE constructor with None parameters
    try:
        SoundgasmIE(None);
    except TypeError:
        print("TypeError expected");
    else:
        print("No TypeError while constructing SoundgasmIE");
    # Call SoundgasmIE constructor with bad parameters
    try:
        SoundgasmIE("badParam");
    except TypeError:
        print("TypeError expected");
    else:
        print("No TypeError while constructing SoundgasmIE");
    # Call SoundgasmIE constructor with good parameters
    try:
        print("SoundgasmIE object: " + str(SoundgasmIE('travis')))
    except TypeError:
        print("TypeError not expected");
    except:
        print("Another error not expected while constructing SoundgasmIE");

# Generated at 2022-06-22 08:23:44.190636
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    assert SoundgasmProfileIE('SoundgasmProfileIE')

# Generated at 2022-06-22 08:23:54.878864
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    '''
    Test the SoundgasmIE class
    '''

    test = {
    'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
    'md5': '010082a2c802c5275bb00030743e75ad',
    'info_dict': {
        'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
        'ext': 'm4a',
        'title': 'Piano sample',
        'description': None,
        'uploader': 'ytdl',
        },
    }

    ie = SoundgasmIE()
    assert re.match(SoundgasmIE._VALID_URL, test['url'])

    # testing from the URL

# Generated at 2022-06-22 08:23:56.972030
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-22 08:23:59.919695
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    e = SoundgasmProfileIE('SoundgasmProfileIE', 'url')
    assert e._VALID_URL == SoundgasmProfileIE._VALID_URL
    assert e._TEST == SoundgasmProfileIE._TEST

# Generated at 2022-06-22 08:24:00.997866
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        ie = SoundgasmIE()
    finally:
        ie = None

# Generated at 2022-06-22 08:24:04.577561
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()

    # TODO: Unit test code should have no side-effects
    print("id: " + sg.ie_key())
    print("extractor name: " + sg.ie_name())
    print("extractor description: " + sg.ie_description())

# Generated at 2022-06-22 08:25:42.283099
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Unit test for constructor of class SoundgasmProfileIE"""
    soundgasm_profile_ie = SoundgasmProfileIE('Soundgasm')
    assert soundgasm_profile_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert soundgasm_profile_ie.IE_NAME == 'soundgasm:profile'
    return


# Generated at 2022-06-22 08:25:44.998097
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE(url)
    assert ie.display_id == 'Piano-sample'


# Generated at 2022-06-22 08:25:54.242983
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Attempt to create instance of class SoundgasmIE 
    ie = SoundgasmIE()
    # Test that it is valid
    assert(ie.suitable('http://soundgasm.net/u/ytdl/Piano-sample'))
    # Test that it is invalid
    assert(not ie.suitable('http://soundgasm.net/u/ytdl/'))
    # Test that it is invalid
    assert(not ie.suitable('http://soundgasm.net/'))
    # Test that it is valid
    assert(SoundgasmIE.suitable('http://soundgasm.net/u/ytdl/Piano-sample'))
    # Test that it is invalid
    assert(not SoundgasmIE.suitable('http://soundgasm.net/u/ytdl/'))


# Generated at 2022-06-22 08:26:05.114144
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import gmusicapi
    SoundgasmIE()._login()
    api = gmusicapi.Mobileclient()
    # client_id and client_secret are obtained from
    # https://accounts.google.com/o/oauth2/auth?client_id=305737153719-n02rua8b1ucas2idc2vf9ujqud8gfhll.apps.googleusercontent.com&redirect_uri=urn%3Aietf%3Awg%3Aoauth%3A2.0%3Aoob&response_type=code&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fyoutube.readonly&access_type=offline&prompt=consent

# Generated at 2022-06-22 08:26:07.643049
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("Testing constructor for class SoundgasmIE")
    extractor = SoundgasmIE()
    print("Successfully created class SoundgasmIE")


# Generated at 2022-06-22 08:26:17.494882
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert SoundgasmIE().IE_NAME == 'soundgasm'

# Generated at 2022-06-22 08:26:22.408867
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Sample audio URL was obtained from http://soundgasm.net/u/ytdl/Piano-sample
    # noinspection PyUnresolvedReferences
    from youtube_dl.utils import make_HTTPS_handler, DEFAULT_HEADERS
    from six.moves import urllib
    from six.moves.urllib import parse, request
    import ssl

    def report_hook(block, block_size, total_size):
        if not block:
            print('Connection opened')
        if total_size < 0:
            print('Read %d%bytes' % (block_size,))
        else:
            amount_read = block_size * block
            print('Read %d of %d bytes' % (amount_read, total_size))


# Generated at 2022-06-22 08:26:28.209293
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE()
    assert profile._playlist_title == None
    assert profile._playlist_id == None
    assert profile._TEST.get('info_dict') == {'id': 'ytdl'}
    assert profile._TEST.get('playlist_count') == 1

# Generated at 2022-06-22 08:26:29.863445
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE
    # Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-22 08:26:32.128328
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE()
    assert isinstance(instance, InfoExtractor)
