

# Generated at 2022-06-22 08:18:42.938530
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        valid_url = "http://soundgasm.net/u/foo/bar"
        regexp = SoundgasmIE._VALID_URL
        assert(re.search(regexp, valid_url) is not None)

        invalid_url = "http://soundgasm.com/u/foo/bar"
        assert(re.search(regexp, invalid_url) is None)
    except AssertionError:
        return False
    return True



# Generated at 2022-06-22 08:18:45.772899
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    inst = SoundgasmProfileIE()
    assert(inst._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')

# Generated at 2022-06-22 08:18:56.077287
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test that the constructor will assign the class variables:
    # var1 = SoundgasmIE._VALID_URL
    # var2 = SoundgasmIE._TEST
    # var3 = SoundgasmIE.IE_NAME
    # var4 = SoundgasmIE._download_webpage
    # var5 = SoundgasmIE._real_extract
    # var6 = SoundgasmIE._search_regex
    # var7 = SoundgasmIE._html_search_regex
    instance_test = SoundgasmIE()
    assert instance_test._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:18:58.286190
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl")

# Generated at 2022-06-22 08:19:06.673369
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    def mock_download_webpage():
        pass

    def mock_search_regex():
        pass
    assert SoundgasmIE(mock_download_webpage, mock_search_regex)._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:19:14.319295
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	#Constructor
	try:
		soundgasmie = SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')
	except Exception as e:
		assert(False, 'The consturctor of class SoundgasmIE threw an exception: '+str(e))
	
	assert(True, 'Passed: The constructor of class SoundgasmIE did not thrown any exception')


# Generated at 2022-06-22 08:19:24.658767
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    _Soundgasm= SoundgasmIE()
    assert _Soundgasm._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:19:30.632808
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    # Test with a valid URL
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'Soundgasm'

    # Test with an invalid URL
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'Soundgasm'

# Generated at 2022-06-22 08:19:32.309482
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-22 08:19:38.789239
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    assert IE_NAME == 'soundgasm:profile'
    assert _VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert _TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-22 08:19:44.610338
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_ie = SoundgasmProfileIE()
    print('Test constructor of class SoundgasmProfileIE is OK')


# Generated at 2022-06-22 08:19:48.189847
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie_obj = SoundgasmIE()
    assert ie_obj.valid_url(ie_obj._TEST['url'])

# Generated at 2022-06-22 08:19:57.546364
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    obj = SoundgasmIE().url_result(url)
    assert obj.result.get('id') == '88abd86ea000cafe98f96321b23cc1206cbcbcc9', "SoundgasmIE.url_result don't gives correct id"
    assert obj.result.get('display_id') == 'Piano-sample', "SoundgasmIE.url_result don't gives correct display_id"
    assert obj.result.get('url') == 'http://www.soundgasm.net/u/ytdl/Piano-sample.m4a', "SoundgasmIE.url_result don't gives correct url"

# Generated at 2022-06-22 08:19:59.725434
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('url', 'SoundgasmProfileIE')
    assert ie._VALID_URL == SoundgasmProfileIE._VALID_URL
    assert ie._TEST == SoundgasmProfileIE._TEST

# Generated at 2022-06-22 08:20:02.210317
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    global soundgasm
    soundgasm = SoundgasmIE()


# Generated at 2022-06-22 08:20:10.813485
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    expected_audio_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    expected_title = 'Piano sample'
    expected_uploader = 'ytdl'
    expected_description = 'Royalty Free Sample Music'
    expected_count = 1
    ie = SoundgasmIE()
    result = ie._real_extract(ie._TEST['url'])
    assert result['id'] == expected_audio_id
    assert result['title'] == expected_title
    assert result['uploader'] == expected_uploader
    assert result['description'] == expected_description
    assert len(result) == expected_count


# Generated at 2022-06-22 08:20:20.251977
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Tests for exception raising
    class MySoundgasmIE(SoundgasmIE):
        def _real_extract(self, url):
            return {
                'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
                'ext': 'm4a',
                'title': 'Piano sample',
                'description': 'Royalty Free Sample Music',
                'uploader': 'ytdl',
            }
    # Tests for no exception raising
    sg = MySoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    sg.to_screen()
    sg.report_download_page()
    sg.report_extraction()
    sg.to_stdout()

# Generated at 2022-06-22 08:20:29.794601
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    sound = SoundgasmIE()
    sound_result = sound._real_extract(url)
    assert sound_result['url'] == "http://a.files.d.soundgasm.net/sounds/ytdl/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a"
    assert sound_result['display_id'] == "Piano-sample"
    assert sound_result['id'] == "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
    assert sound_result['uploader'] == "ytdl"

# Generated at 2022-06-22 08:20:36.705054
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl'
        },
        'playlist_count': 1
    }

# Generated at 2022-06-22 08:20:42.508778
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Test for valid class SoundgasmProfileIE
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-22 08:20:52.124625
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    tester = SoundgasmIE()
    tester.test()

# Generated at 2022-06-22 08:20:58.185110
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert bool(re.match(SoundgasmIE._VALID_URL, 'http://soundgasm.net/u/ytdl/Piano-sample'))
    assert bool(re.match(SoundgasmIE._VALID_URL, 'http://soundgasm.net/u/ytdl/Piano-sample/'))
    assert bool(re.match(SoundgasmIE._VALID_URL, 'http://soundgasm.net/u/ytdl/Piano-sample/#'))

    assert not bool(re.match(SoundgasmIE._VALID_URL, 'http://soundgasm.net/u/ytdl/'))
    assert not bool(re.match(SoundgasmIE._VALID_URL, 'http://soundgasm.net/u/ytdl'))
    assert not bool

# Generated at 2022-06-22 08:21:10.573805
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Tests for SoundgasmProfileIE.
    
    Run: 
        py.test tests/test_SoundgasmProfileIE
    """
    # Test with one of the entries from SoundgasmProfileIE._TEST
    url = SoundgasmProfileIE._TEST['url']
    assert SoundgasmProfileIE._VALID_URL == SoundgasmProfileIE._TEST['url']
    
    # Get the page and check that it is not empty
    page = SoundgasmProfileIE()._download_webpage(url, "ytdl")
    assert len(page) > 1
    
    # Check that the number of results is 1 as specified in unit test SoundgasmProfileIE._TEST
    entries = SoundgasmProfileIE()._real_extract(url)
    assert entries['_type'] == 'playlist'


# Generated at 2022-06-22 08:21:15.637917
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info = SoundgasmIE()._call_api('89bd1b5a52d9e5b5da32b7c5f3d5bb5a69bac854')
    assert info.get('title') == 'Dreadful Purity 1'



# Generated at 2022-06-22 08:21:17.466346
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_obj = SoundgasmIE()
    assert test_obj._VALID_URL is not None


# Generated at 2022-06-22 08:21:20.443109
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from youtube_dl.extractor.SoundgasmIE import SoundgasmIE
    assert SoundgasmIE

# Generated at 2022-06-22 08:21:25.298799
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .test_downloader import TestDownloader
    downloader = TestDownloader()
    downloader.add_info_extractor('soundgasm')
    downloader.add_info_extractor(
        'soundgasm:profile')
    result = downloader.extract('http://soundgasm.net/u/ytdl')
    assert result == [{
        'id': 'ytdl',
    }]

# Generated at 2022-06-22 08:21:29.448206
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie1 = SoundgasmProfileIE()
    assert ie1.IE_NAME == 'soundgasm:profile'
    ie2 = SoundgasmProfileIE(SoundgasmIE)
    assert ie2.ie_key() == 'Soundgasm'

# Generated at 2022-06-22 08:21:31.302005
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-22 08:21:35.631821
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # test for https://github.com/rg3/youtube-dl/issues/7010
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    # simple test to make sure it doesn't crash.
    SoundgasmIE()._real_extract(url)

# Generated at 2022-06-22 08:21:52.673542
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    x = SoundgasmIE()
    assert x.IE_NAME == 'soundgasm'


# Generated at 2022-06-22 08:21:54.380742
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-22 08:22:05.543473
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Tests the constructor of class SoundgasmIE
    # This test case is kind of useless without the
    # Travis-CI task, since it doesn't use the
    # extract() method.
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE(url)
    assert ie.IE_NAME == 'soundgasm'
    assert ie.IE_DESC == 'Soundgasm'

    # Tests the _real_extract method of SoundgasmIE

# Generated at 2022-06-22 08:22:08.339219
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	soundgasm = SoundgasmIE()
	assert isinstance(soundgasm, SoundgasmIE)
	assert hasattr(soundgasm, 'IE_NAME')

# Generated at 2022-06-22 08:22:11.014373
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE()
    obj1 = ie.suitable(url)
    obj2 = ie._match_id(url)
    assert obj1 == obj2

# Generated at 2022-06-22 08:22:11.913366
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:22:13.548974
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert isinstance(SoundgasmProfileIE(), InfoExtractor)


# Generated at 2022-06-22 08:22:15.067368
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == 'soundgasm'


# Generated at 2022-06-22 08:22:20.186219
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	# The following exception is thrown:
	#	'invalid literal for float()'
	# This is the exception from the base class of SoundgasmProfileIE
	url = 'http://soundgasm.net/u/ytdl'
	ie = SoundgasmProfileIE()
	ie.extract(url)
# ------------------------------------------------------


# Generated at 2022-06-22 08:22:22.183583
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	assert SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-22 08:23:02.363957
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE(None)._download_webpage()

# Generated at 2022-06-22 08:23:04.567366
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    inst = SoundgasmIE('http://www.example.com')
    assert isinstance(inst, SoundgasmIE)


# Generated at 2022-06-22 08:23:10.060285
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # test SoundgasmProfileIE.__init__(), make sure it is legal
    SoundgasmProfileIE(SoundgasmProfileIE.ie_key(), SoundgasmProfileIE._VALID_URL)
    

# Generated at 2022-06-22 08:23:22.190656
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('', None, None)
    assert(ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')
    assert(ie._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample')
    assert(ie._TEST['md5'] == '010082a2c802c5275bb00030743e75ad')

# Generated at 2022-06-22 08:23:28.500081
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Testing if the constructor of SoundgasmProfileIE has a parameter for 'IE_NAME'
    func = getattr(SoundgasmProfileIE, '__init__')
    assert any(
        'IE_NAME' in arg.name for arg in func.__code__.co_varnames[:func.__code__.co_argcount])

# Generated at 2022-06-22 08:23:29.503445
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:23:31.217182
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
  sg=SoundgasmIE()
  assert(sg.IE_NAME=='soundgasm')


# Generated at 2022-06-22 08:23:35.093127
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Basic args
    SoundgasmIE('id', 'url', 'title', 'description')
    # Too many args
    SoundgasmIE('id', 'url', 'title', 'description', 'uploader')

# Generated at 2022-06-22 08:23:37.744291
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE(InfoExtractor())._download_webpage('http://soundgasm.net/u/ytdl/Piano-sample', 'Piano-sample')

# Generated at 2022-06-22 08:23:42.125217
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(None)
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:25:13.528462
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-22 08:25:20.584933
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	from .soundgasm.common import InfoExtractor
	from .soundgasm.soundgasm import SoundgasmIE

	assert SoundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
	assert SoundgasmIE.IE_NAME == 'soundgasm'



# Generated at 2022-06-22 08:25:22.817118
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    instance = SoundgasmIE()
    instance._download_webpage('http://soundgasm.net/u/ytdl/Piano-sample')



# Generated at 2022-06-22 08:25:28.548934
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == SoundgasmProfileIE.IE_NAME
    assert ie._VALID_URL == SoundgasmProfileIE._VALID_URL
    assert ie._TEST == SoundgasmProfileIE._TEST


# Generated at 2022-06-22 08:25:32.445201
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    if ie.__class__.__name__ == 'SoundgasmIE':
        print("Successfully created SoundgasmIE object.")
    else:
        print("Failed to create SoundgasmIE object")


# Generated at 2022-06-22 08:25:38.129573
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # This is for test purpose only
    # TODO: actually create a test case with a correct URL
    # to test get_audio_url() and get_video_id()
    ie = SoundgasmIE('http://www.soundgasm.net/u/Kuritafsheen/test-audio')
    ie.extract()

# Generated at 2022-06-22 08:25:48.458859
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    if __name__ == '__main__':
        ie = SoundgasmProfileIE()
        assert ie.IE_NAME == 'soundgasm:profile'
        assert ie.get_url_re() == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
        assert ie.get_match_id_re() == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
        assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:25:49.679678
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == 'soundgasm'

# Generated at 2022-06-22 08:26:01.278255
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.name == 'soundgasm'
    assert ie.ie_key() == 'Soundgasm'
    assert ie.valid_url('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie.valid_url('http://soundgasm.net/u/ytdl/Piano-sample/')
    assert ie.valid_url('https://soundgasm.net/u/ytdl/Piano-sample')
    assert ie.valid_url('https://soundgasm.net/u/ytdl/Piano-sample/')
    assert not ie.valid_url('https://soundgasm.net/u/ytdl/Piano-sample/abc')

# Generated at 2022-06-22 08:26:07.559735
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    st = SoundgasmIE()
    assert st.IE_NAME == 'soundgasm'
    assert st._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    return st
