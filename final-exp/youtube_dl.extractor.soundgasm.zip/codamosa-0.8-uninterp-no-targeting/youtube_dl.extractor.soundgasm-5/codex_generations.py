

# Generated at 2022-06-22 08:18:40.583518
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    inst = SoundgasmProfileIE()
    inst.IE_NAME == 'soundgasm:profile'
    assert inst._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:18:45.008083
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # If this test fails, the constructor of SoundgasmIE class
    # is broken. This test does not go through the whole
    # extraction process, just creates an instance of the class
    # and runs the test on it.
    ie = SoundgasmIE()
    assert ie.extract('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-22 08:18:46.691752
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('https://www.soundgasm.net/u/ytdl')

# Generated at 2022-06-22 08:18:57.902735
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-22 08:19:01.200192
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://example.com')
    ie.IE_NAME

# Generated at 2022-06-22 08:19:02.790542
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	ie = SoundgasmProfileIE()
	return


# Generated at 2022-06-22 08:19:09.737093
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    Test = SoundgasmProfileIE()
    assert Test.IE_NAME == 'soundgasm:profile'
    assert Test._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert Test._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}



# Generated at 2022-06-22 08:19:11.623411
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	ext = SoundgasmProfileIE()
	assert ext._TEST['playlist_count'] == 2

# Generated at 2022-06-22 08:19:18.308216
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    display_id = 'Piano-sample'
    user = 'ytdl'
    url = 'http://soundgasm.net/u/' + user + '/' + display_id
    SoundgasmIE().suitable(url) == True
    if not SoundgasmIE().suitable(url):
        raise AssertionError("URL " + url + " is not suitable")

    info = SoundgasmIE().extract(url)

    if info.get('id') != audio_id: # Different audio_id
        raise AssertionError("Audio id is not the expected one")


# Generated at 2022-06-22 08:19:18.882043
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    inst = SoundgasmIE()
    assert inst._TEST

# Generated at 2022-06-22 08:19:27.147730
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-22 08:19:33.371509
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    #pylint: disable=import-outside-toplevel
    from audiodownload.extractor import soundgasm
    ie = soundgasm.SoundgasmProfileIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:19:40.609582
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.__name__ == 'soundgasm:profile'
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}

# Generated at 2022-06-22 08:19:42.292782
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = "http://soundgasm.net/u/ytdl"
    SoundgasmProfileIE()._real_extract(url)

# Generated at 2022-06-22 08:19:52.430139
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    # match invalid urls
    assert len(sg._VALID_URL) == sg._VALID_URL.find('soundgasm')
    assert len(sg._VALID_URL) > sg._VALID_URL.find('soundgasm.net')
    assert len(sg._VALID_URL) == sg._VALID_URL.find('soundgasm.net/u')
    assert len(sg._VALID_URL) > sg._VALID_URL.find('soundgasm.net/u/')
    assert len(sg._VALID_URL) > sg._VALID_URL.find('soundgasm.net/u/ytdl')

# Generated at 2022-06-22 08:19:58.027867
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    extracted_info = SoundgasmProfileIE._real_extract(SoundgasmProfileIE(), "http://soundgasm.net/u/ytdl")
    assert extracted_info['id'] == "ytdl"
    assert len(extracted_info['entries']) == 1
    assert extracted_info['entries'][0]['url'] == "http://soundgasm.net/u/ytdl/Piano-sample"

# Generated at 2022-06-22 08:19:58.956328
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('SoundgasmProfile')

# Generated at 2022-06-22 08:20:05.165885
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Test SoundgasmProfileIE constructor"""
    IE_OBJ_LIST = [SoundgasmProfileIE]
    # Verify IE instantiation
    for ie_obj in IE_OBJ_LIST:
        obj = ie_obj()
        assert obj.ie_key() == ie_obj.IE_NAME
        assert obj.ie_key() in globals()


# Generated at 2022-06-22 08:20:06.921005
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    result = SoundgasmProfileIE()
    assert result != None, 'Could not create SoundgasmProfileIE()'

# Generated at 2022-06-22 08:20:09.006966
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    return SoundgasmIE._build_url_result('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-22 08:20:19.633831
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_object = SoundgasmIE()
    assert test_object is not None


# Generated at 2022-06-22 08:20:30.706144
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    expected_title = 'Piano sample'
    expected_description = 'Royalty Free Sample Music'
    expected_audio_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    expecter_uploader = 'ytdl'
    expected_display_id = 'Piano-sample'

    soundgasmie = SoundgasmIE()

    actual_dict = soundgasmie._real_extract(test_url) 

    if actual_dict['title'] != expected_title:
        raise Exception('Title is wrong.\n'
            'Expected: {}\n'
            'Actual: {}'.format(expected_title, actual_dict['title']))



# Generated at 2022-06-22 08:20:36.703312
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.IE_NAME == 'Soundgasm:Profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'

# Generated at 2022-06-22 08:20:42.848221
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'



# Generated at 2022-06-22 08:20:45.717041
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.profile_id == 'ytdl'
    assert ie.playlist_title == 'ytdl'

# Generated at 2022-06-22 08:20:47.641308
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    return ie

# Generated at 2022-06-22 08:20:58.389851
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    f = SoundgasmIE(None)

    URL = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mobj = re.match(f._VALID_URL, URL)
    assert mobj is not None
    assert mobj.group('user') == 'ytdl'
    assert mobj.group('display_id') == 'Piano-sample'

    URL = 'http://soundgasm.net/u/ytdl/Piano-sample/'
    mobj = re.match(f._VALID_URL, URL)
    assert mobj is not None
    assert mobj.group('user') == 'ytdl'
    assert mobj.group('display_id') == 'Piano-sample'


# Generated at 2022-06-22 08:20:59.829462
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:21:11.901440
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    #url = "http://soundgasm.net/u/ytdl/Piano-sample"
    url = input("Enter a url: ")
    #assert ie.IE_NAME == "Soundgasm"
    print("IE_NAME: ", ie.IE_NAME)
    audio = ie.extract(url)
    print("audio: ", audio)
    assert audio["id"] == "88abd86ea000cafe98f96321b23cc1206cbcbcc9"
    assert audio["display_id"] == "Piano-sample"

# Generated at 2022-06-22 08:21:21.680235
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    x = SoundgasmIE()
    assert x.IE_NAME == 'soundgasm'
    assert x._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:21:44.931068
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    extractor = SoundgasmProfileIE()
    assert extractor.IE_NAME == 'Soundgasm'
    assert extractor.IE_NAME == 'Soundgasm'
    assert extractor._VALID_URL == 'https?://(?:www\\.)?soundgasm\\.net/u/(?P<id>[^/]+)/?(?:\\#.*)?$'
    assert extractor._downloader.params['username'] == None
    assert extractor._downloader.params['password'] == None


# Generated at 2022-06-22 08:21:47.730689
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_SoundgasmIE = SoundgasmIE()
    test_SoundgasmIE._download_json_handle()
    test_SoundgasmIE._match_id()
    test_SoundgasmIE._request_webpage()
    test_SoundgasmIE._real_extract()


# Generated at 2022-06-22 08:21:55.013571
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ies = {'soundgasm:profile'}
    iem = IE_NAME_MAP.get(ies)
    assert float(str(iem)) > 0.0
    for ie in iem:
        assert ie.IE_NAME in ies
        assert ie.VALID_URL == iem.VALID_URL
        assert ie.NAME == iem.NAME
    print("Testing soundgasm:profile.py constructor passed")

test_SoundgasmProfileIE()

# Generated at 2022-06-22 08:21:59.188296
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmIE()
    soundgasm_ie = ie._downloader.get_info_extractor('Soundgasm')
    soundgasm_profile_ie = ie._downloader.get_info_extractor('SoundgasmProfile')

    assert soundgasm_ie == soundgasm_profile_ie

# Generated at 2022-06-22 08:22:04.658207
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    _ie = SoundgasmIE()
    assert _ie.ie_key() == 'Soundgasm'
    assert _ie.ie_name() == 'Soundgasm'
    assert _ie.ie_type() == 'playlist'


# Generated at 2022-06-22 08:22:14.777720
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Create an instance of the SoundgasmIE class for testing
    instance = SoundgasmIE()
    # Checks that the URL matches the VALID_URL regex
    assert instance._match_id('http://soundgasm.net/u/ytdl/Piano-sample') == 'Piano-sample'
    # Checks that the URL matches the VALID_URL regex
    assert instance._match_id('http://soundgasm.net/u/ytdl') is None
    # Checks that the URL matches the VALID_URL regex
    assert instance._match_id('https://soundgasm.net/u/ytdl/Piano-sample') == 'Piano-sample'
    # Checks that the URL matches the VALID_URL regex
    assert instance._match_id('https://soundgasm.net/u/ytdl') is None

# Generated at 2022-06-22 08:22:21.722250
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert(SoundgasmIE._TEST["title"] == 'Piano sample')
    audio_url = SoundgasmIE._TEST["url"]

# Generated at 2022-06-22 08:22:28.185393
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    instance = SoundgasmProfileIE(info_dict={})
    instance.url = url
    instance.ie_key = instance.IE_NAME
    instance.extractor = None
    result = instance._real_extract(url)
    assert('id' in result)
    assert(instance.playlist_count == result['playlist_count'])

# Generated at 2022-06-22 08:22:32.788585
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE('https:://soundgasm.net/u/ytdl')._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')

# Generated at 2022-06-22 08:22:35.658407
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    return SoundgasmProfileIE()._real_extract(
        'http://soundgasm.net/u/ytdl')

# Generated at 2022-06-22 08:23:16.160918
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE().extract('http://soundgasm.net/u/ytdl/first-test')

# Generated at 2022-06-22 08:23:20.531919
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        SoundgasmProfileIE()
        print("Unit test Successful")
    except Exception as e:
        print("Unit test has encountered an exception ", e)



# Generated at 2022-06-22 08:23:24.179738
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    IE = SoundgasmProfileIE(url)
    assert IE.playlist_count == 1
    assert IE.url == url
    assert IE.id == "ytdl"

# Generated at 2022-06-22 08:23:31.997967
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    if __name__ == "__main__":
        url = 'http://soundgasm.net/u/ytdl'
        if url.startswith("http") :
            url = url[7:]
        else:
            url = url[6:]
        if url.startswith("//"):
            url = url[2:]
        SoundgasmProfileIE._VALID_URL = r'https?://%s/u/(?P<id>[^/]+)/?(?:\#.*)?$' % re.escape(url)

# Generated at 2022-06-22 08:23:35.942563
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    wid = 'ytdl'
    obj = SoundgasmProfileIE()
    if not isinstance(obj, SoundgasmProfileIE):
        exit('Error in testing constructor of SoundgasmProfileIE')


# Generated at 2022-06-22 08:23:36.881405
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_SoundgasmIE = SoundgasmIE()

# Generated at 2022-06-22 08:23:42.966210
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Tests are for detecting and handling future changes
    IE = SoundgasmProfileIE()
    assert IE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert IE.IE_NAME == 'soundgasm:profile'

test_SoundgasmProfileIE()

# Generated at 2022-06-22 08:23:48.425859
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert SoundgasmIE().IE_NAME == 'Soundgasm'


# Generated at 2022-06-22 08:23:55.578366
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    expected_result = {'_type': 'url_transparent',
                       'url': 'http://soundgasm.net/u/ytdl/Ice-T-Cop-killer',
                       'ie_key': 'Soundgasm',
                       'id': 'Ice-T-Cop-killer'}
    actual_result = SoundgasmProfileIE._build_url_result('http://soundgasm.net/u/ytdl/Ice-T-Cop-killer')
    assert expected_result == actual_result

# Generated at 2022-06-22 08:23:59.495712
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'

    profile = SoundgasmProfileIE()

    profile_id = profile._match_id(url)

    assert(profile_id == 'ytdl')

# Generated at 2022-06-22 08:25:30.443546
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()._real_extract('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-22 08:25:33.342663
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile_id = 'ytdl'
    url = 'http://soundgasm.net/u/ytdl'
    SoundgasmProfileIE(url)
    return True

# Generated at 2022-06-22 08:25:39.019791
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-22 08:25:49.161284
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# case 1
	sndgsmObj = SoundgasmIE()
	url = 'http://soundgasm.net/u/ytdl/Piano-sample'
	# Extract video id
	video_id = sndgsmObj._match_id(url)
	assert video_id == 'Piano-sample'
	# check audio URL
	webpage = sndgsmObj._download_webpage(url, None)
	audio_url = sndgsmObj._html_search_regex(
		r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', webpage,
		'audio URL', group='url')

# Generated at 2022-06-22 08:25:58.958791
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasmProfileIE = SoundgasmProfileIE()
    assert soundgasmProfileIE._VALID_URL == 'https?://(?:www\\.)?soundgasm\\.net/u/(?P<id>[^/]+)/?(?:\\#.*)?$'
    assert soundgasmProfileIE._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-22 08:26:10.574154
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    assert soundgasm.IE_NAME == 'soundgasm'
    assert soundgasm._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert soundgasm._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert soundgasm._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-22 08:26:14.132523
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == 'soundgasm'


# Generated at 2022-06-22 08:26:21.058294
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    # Checking the valid page test
    try:
        obj = SoundgasmProfileIE()
        assert obj.ie_name == 'soundgasm:profile'
        assert obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
        assert obj._TEST['url'] == 'http://soundgasm.net/u/ytdl'
        assert obj._TEST['info_dict']['id'] == 'ytdl'
        assert obj._TEST['playlist_count'] == 1
    except Exception:
        raise

    # Creating object from a valid object

# Generated at 2022-06-22 08:26:31.011428
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """Creates an instance of SoundgasmIE and checks for consistency""" 
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    testObject = SoundgasmIE()
    output = testObject.suitable(url)
    assert output == True
    output = testObject.get_id(url)
    assert output == 'Piano-sample'
    output = testObject.get_user(url)
    assert output == 'ytdl'
    output = testObject.get_title(url)
    assert output == 'Piano sample'
    output = testObject.get_description(url)
    assert output == 'Royalty Free Sample Music'

# Generated at 2022-06-22 08:26:31.646322
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()