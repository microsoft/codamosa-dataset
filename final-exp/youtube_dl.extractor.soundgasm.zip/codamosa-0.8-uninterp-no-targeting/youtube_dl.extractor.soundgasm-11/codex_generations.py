

# Generated at 2022-06-22 08:18:33.875043
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('test', 'http://soundgasm.net/u/ytdl')

# Generated at 2022-06-22 08:18:38.256002
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('https://soundgasm.net/u/ytdl')
    assert ie.__class__ is SoundgasmIE

# Generated at 2022-06-22 08:18:42.703905
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('88abd86ea000cafe98f96321b23cc1206cbcbcc9','http://soundgasm.net/u/ytdl/Piano-sample','ytdl','Piano sample','010082a2c802c5275bb00030743e75ad')

# Generated at 2022-06-22 08:18:45.245536
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE()
    except:
        assert False, 'Constructor raised an Exception'
    else:
        assert True, 'Constructor ran without raising an Exception'


# Generated at 2022-06-22 08:18:56.305481
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class_object = SoundgasmIE()
    assert class_object.IE_NAME == 'soundgasm'
    assert class_object._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:18:58.382032
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-22 08:19:02.560694
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(None)
    ie._download_webpage = lambda url, display_id: url
    assert len(ie._extract_playlist('http://soundgasm.net/u/ytdl')) == 1

# Generated at 2022-06-22 08:19:03.653955
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()

# Generated at 2022-06-22 08:19:11.549811
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_profile = SoundgasmProfileIE()
    assert test_profile.IE_NAME == 'soundgasm:profile'
    assert test_profile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert test_profile._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert test_profile._TEST['info_dict'] == {'id': 'ytdl'}
    assert test_profile._TEST['playlist_count'] == 1

# Generated at 2022-06-22 08:19:15.798460
# Unit test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-22 08:19:28.485816
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    #Unit test part
    #Create an instance of class IE
    ie = SoundgasmProfileIE()
    #Specify the URL for unit testing
    test_url = 'http://soundgasm.net/u/ytdl'
    #call function extract from IE,
    #which is test_download_webpage.
    #The function returns a dictionary.
    result = ie._real_extract(test_url)
    #Assert if the the returned dictionary is not empty
    assert result

# Generated at 2022-06-22 08:19:30.808924
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE.__name__ == "SoundgasmIE"


# Generated at 2022-06-22 08:19:41.464440
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from UnitTester import UnitTester
    unit_tester = UnitTester()
    urlsToExtract = [
        ('http://soundgasm.net/u/ytdl/Piano-sample', '010082a2c802c5275bb00030743e75ad', '88abd86ea000cafe98f96321b23cc1206cbcbcc9')
        ]
    for urlToExtract, expectedHashcode, expectedID in urlsToExtract:
        siteClass = SoundgasmIE(unit_tester.extractor_manager)
        unit_tester.download(siteClass, urlToExtract, expectedHashcode)
        unit_tester.getInfo(siteClass, urlToExtract, expectedID)
        unit_tester.test()



# Generated at 2022-06-22 08:19:46.603467
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print('Start testing SoundgasmIE')

    ############################################################################
    #                                                                          #
    #                  Constructor Test for Class SoundgasmIE                 #
    #                                                                          #
    ############################################################################

    # Constructor 1 with valid url
    valid_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    sg_ie = SoundgasmIE()

    # Constructor 2 with invalid url
    invalid_url = 'http://soundgasm.net/invalid'
    try:
        sg_ie = SoundgasmIE()
    except:
        pass

    # Constructor 3 with None as url
    try:
        sg_ie = SoundgasmIE()
    except:
        pass

    print('Finish testing SoundgasmIE')



# Generated at 2022-06-22 08:19:56.770985
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test constructor with a dict()
    ie = SoundgasmIE(
        {
            'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
            'md5': '010082a2c802c5275bb00030743e75ad',
            'info_dict': {
                'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
                'ext': 'm4a',
                'title': 'Piano sample',
                'description': 'Royalty Free Sample Music',
                'uploader': 'ytdl',
        }
    })

    # Test constructor with a regular expression

# Generated at 2022-06-22 08:19:59.447843
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE(InfoExtractor())
    print("obj.IE_NAME is " + obj.IE_NAME)
    assert(obj.IE_NAME == 'soundgasm:profile')

# Generated at 2022-06-22 08:20:10.630340
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasmIE = SoundgasmIE()
    assert(soundgasmIE.IE_NAME == 'soundgasm')
    assert(soundgasmIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-22 08:20:20.401074
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_data = 'http://soundgasm.net/u/ytdl/Piano-sample'
    test_obj  = SoundgasmIE(test_data)
    info_dict = test_obj.extract()
    assert(info_dict.get('id') == '88abd86ea000cafe98f96321b23cc1206cbcbcc9')
    assert(info_dict.get('ext') == 'm4a')
    assert(info_dict.get('title') == 'Piano sample')
    assert(info_dict.get('description') == 'Royalty Free Sample Music')
    assert(info_dict.get('uploader') == 'ytdl')

# Generated at 2022-06-22 08:20:21.880663
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-22 08:20:32.613324
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Constructor of class SoundgasmProfileIE
    sg_profile_ie = SoundgasmProfileIE()

    # Default values
    assert sg_profile_ie.provider_key == None
    assert sg_profile_ie.provider_name == None
    assert sg_profile_ie.uploader_id == None
    assert sg_profile_ie.username == None

    # Testing with specifics values
    sg_profile_ie = SoundgasmProfileIE('provider_key', 'provider_name', 'uploader_id', 'username')

    # Specifics values
    assert sg_profile_ie.provider_key == 'provider_key'
    assert sg_profile_ie.provider_name == 'provider_name'

# Generated at 2022-06-22 08:20:44.370547
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE()._VALID_URL == SoundgasmIE._VALID_URL
    assert SoundgasmIE()._TEST == SoundgasmIE._TEST
    assert SoundgasmIE().IE_NAME == SoundgasmIE._IE_NAM


# Generated at 2022-06-22 08:20:53.236503
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    client = SoundgasmProfileIE()
    assert client.IE_NAME =='soundgasm:profile'
    assert client._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert client._TEST['url'] == 'http://soundgasm.net/u/ytdl'



# Generated at 2022-06-22 08:20:55.598510
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    SoundgasmProfileIE(url)._match_id(url)

# Generated at 2022-06-22 08:21:02.187959
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .test_common import youtube_url
    from .test_common import url_basename
    from .test_common import url_basepath

    assert url_basename(youtube_url) == 'url_basename'
    assert url_basepath(youtube_url) == 'url_basepath'

    import doctest
    doctest.testmod()

# Generated at 2022-06-22 08:21:03.848808
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    print(sg)

# Generated at 2022-06-22 08:21:07.695446
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Runs when command is python -m youtube_dl.extractor.soundgasm
    # TODO: Create a real test
    soundgasmProfileIE = SoundgasmProfileIE()

    # TODO: Test some of the functions within the class
    assert (soundgasmProfileIE is not None)

# Generated at 2022-06-22 08:21:17.842713
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	fname = 'Piano-sample.m4a'

	if __name__ == '__main__':
		import requests
		from os import path
		url = 'http://soundgasm.net/u/ytdl/Piano-sample'
		y = SoundgasmIE()

		if not path.exists(fname):
			r = requests.get(y._download_webpage(url, 'Piano-sample')['url'])
			with open(fname, 'wb') as f:
				f.write(r.content)

		y.download(url)

# End of class SoundgasmIE

# Generated at 2022-06-22 08:21:25.436856
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest
    IE = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert IE.IE_NAME == 'soundgasm:profile'
    assert IE.VALID_URL == r'http://soundgasm.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert IE.TEST == { 'url': 'http://soundgasm.net/u/ytdl', 'info_dict': { 'id': 'ytdl', }, 'playlist_count': 1,}


# Generated at 2022-06-22 08:21:27.707677
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-22 08:21:39.321861
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile_id = 'ytdl'
    webpage = '''
      <div class="jp-type-playlist">
      ...
      <a href="/u/ytdl/Piano-sample">Piano sample</a>
      ...
      </div>
    '''
    entries = [
            '/u/ytdl/Piano-sample'
            for audio_url in re.findall(r'href="([^"]+/u/%s/[^"]+)' % profile_id, webpage)]
    ie = SoundgasmProfileIE()
    assert ie._match_id(url) == profile_id
    assert ie.playlist_count == 1

# Generated at 2022-06-22 08:21:58.734787
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('https://soundgasm.net/u/ytdl')
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:22:02.754843
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    te = SoundgasmIE()
    # te.download("http://soundgasm.net/u/ytdl/Blah-blah-blah")
    # te.download("http://soundgasm.net/u/ytdl/Blah-blah-blah", "test.m4a")

test_SoundgasmIE()

# Generated at 2022-06-22 08:22:06.141442
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-22 08:22:07.627823
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    # TODO: Add unit tests


# Generated at 2022-06-22 08:22:17.010610
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    The test case for Unit test of the constructor of class SoundgasmIE.
    """
    def test_constructor_url(self, url, display_id, list_id, webpage, audio_id, title, description, uploader):
        """
        Unit test for the constructor of SoundgasmIE
        """
        self._download_webpage = lambda url, display_id: webpage
        self._html_search_regex = lambda pattern, webpage, name, group: re.search(pattern, webpage).group(group)
        self._search_regex = lambda pattern, webpage, name, default: re.search(pattern, webpage).group(0)
        SoundgasmIE._real_extract(self, url)
        self.assertEqual(self._match_id(url), display_id)

# Generated at 2022-06-22 08:22:21.231369
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .test import *
    assert isinstance(SoundgasmProfileIE(''), SoundgasmProfileIE)
    assert isinstance(SoundgasmProfileIE('Soundgasm'), SoundgasmProfileIE)
    assert isinstance(SoundgasmProfileIE(SoundgasmProfileIE), SoundgasmProfileIE)

# Generated at 2022-06-22 08:22:23.621381
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-22 08:22:24.950816
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """ Test the SoundgasmIE constructor """
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-22 08:22:33.990977
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    ie.IE_NAME == 'soundgasm:profile'
    ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-22 08:22:38.904136
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    'SoundgasmProfileIE: Test constructor of class SoundgasmProfileIE'
    sgProfile = SoundgasmProfileIE()
    if not isinstance(sgProfile, InfoExtractor):
        print('SoundgasmProfileIE:  FAIL')
    else:
        print('SoundgasmProfileIE:  PASS')
    return


# Generated at 2022-06-22 08:23:19.113814
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_soundgasmie = SoundgasmIE()
    print('Test SoundgasmIE')
    print(test_soundgasmie._VALID_URL)
    print(test_soundgasmie._TEST)

# Generated at 2022-06-22 08:23:26.453707
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.__name__ == 'SoundgasmProfileIE'

# Generated at 2022-06-22 08:23:28.921448
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE();
    ie.extract('http://soundgasm.net/u/ytdl/Piano-sample');

# Generated at 2022-06-22 08:23:33.363436
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Old constructor
    ie_obj = SoundgasmProfileIE({})
    assert type(ie_obj) == SoundgasmProfileIE

    # New constructor
    ie_obj = InfoExtractor.for_site('soundgasm.net')
    assert type(ie_obj) == SoundgasmProfileIE

# Generated at 2022-06-22 08:23:39.673903
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(InfoExtractor)
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie.extract() == None


# Generated at 2022-06-22 08:23:42.324667
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE(url, None)

# Generated at 2022-06-22 08:23:45.207887
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    a = SoundgasmIE()
    assert a.IE_NAME
    assert a._VALID_URL
    assert a._TEST

# Generated at 2022-06-22 08:23:55.975247
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Simple unit test for SoundgasmProfileIE
    """
    instance = SoundgasmProfileIE()
    expected = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert instance._VALID_URL == expected
    url = "http://soundgasm.net/u/ytdl"
    valid = instance._VALID_URL
    assert re.match(valid, url) != None
    assert isinstance(instance, InfoExtractor) == True
    assert issubclass(SoundgasmProfileIE, InfoExtractor) == True
    assert isinstance(instance, SoundgasmProfileIE) == True
    assert SoundgasmProfileIE.IE_NAME == "soundgasm:profile"
    assert SoundgasmProfileIE.IE

# Generated at 2022-06-22 08:24:01.305808
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    # From the example provided in the document, the expected result is the same as the one return by _real_extract
    assert ie._real_extract('http://soundgasm.net/u/ytdl') == ie._real_extract('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-22 08:24:04.872188
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    global pass_flag
    pass_flag = True
    try:
        SoundgasmIE()
    except:
        pass_flag = False
    if pass_flag:
        print("test_SoundgasmIE succeeded")
    else:
        print("test_SoundgasmIE failed")


# Generated at 2022-06-22 08:25:44.697675
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    test_class = SoundgasmIE
    assert test_class.ie_key() == 'Soundgasm'
    ie = test_class(test_url)
    assert test_class.working == True
    assert ie.display_id == 'Piano-sample'
    assert ie.url == test_url
    assert ie.module_name == 'Soundgasm'
    assert ie.title == 'Piano sample'
    assert ie.description == 'Royalty Free Sample Music'
    assert ie.uploader == 'ytdl'

# Generated at 2022-06-22 08:25:53.030947
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class SoundgasmIE_test(SoundgasmIE):
        def __init__(self):
            self.username = ''
            self.display_id = ''
        def _real_extract(self, url):
            mobj = re.match(self._VALID_URL, url)
            self.username = mobj.group('user')
            self.display_id = mobj.group('display_id')
            webpage = self._download_webpage(url, self.display_id)
            return self.url_result(self._html_search_regex(
                r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', webpage,
                'audio URL', group='url'))


# Generated at 2022-06-22 08:25:55.596796
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == 'Soundgasm'

# Generated at 2022-06-22 08:25:59.009590
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE()
    except:
        pass
    else:
        assert False, "Expected exception not raised when constructor of class SoundgasmIE called with no arguments."


# Generated at 2022-06-22 08:26:05.169308
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:26:07.872289
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import TestCase

    test = TestCase('SoundgasmProfileIE')
    test.run()

# Generated at 2022-06-22 08:26:09.558374
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    tmp_obj = SoundgasmIE()

# Generated at 2022-06-22 08:26:10.295156
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-22 08:26:15.466342
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from . import _StaticTestCase
    from .common import TEST_USERNAME, TEST_PASSWORD

    raise _StaticTestCase(
        SoundgasmProfileIE,
        SoundgasmProfileIE._TEST,
        # Soundgasm is a membership-based site,
        # so we need to login before accessing its playlist.
        username=TEST_USERNAME,
        password=TEST_PASSWORD)

# Generated at 2022-06-22 08:26:18.470860
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert isinstance(ie, SoundgasmProfileIE)
