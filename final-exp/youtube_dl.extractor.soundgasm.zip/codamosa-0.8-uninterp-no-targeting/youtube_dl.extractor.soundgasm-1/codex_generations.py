

# Generated at 2022-06-22 08:18:37.635269
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	url = 'http://soundgasm.net/u/ytdl/Piano-sample'
	SoundgasmIE(url)

# Generated at 2022-06-22 08:18:43.607668
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ins = SoundgasmIE()._real_extract(url)
    assert ins['url'] == 'https://soundgasm.net/u/ytdl/Piano-sample.m4a'
    assert ins['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-22 08:18:44.460427
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE("url", "name")

# Generated at 2022-06-22 08:18:55.627417
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    usrname1 = 'ytdl'
    usrname2 = 'ytdl_test'
    url1 = 'http://soundgasm.net/u/ytdl'
    url2 = 'http://soundgasm.net/u/ytdl_test'
    # Test creating SoundgasmProfileIE object with valid username
    profile1 = SoundgasmProfileIE(usrname1)
    assert profile1 is not None
    # Test creating SoundgasmProfileIE object with valid url
    profile2 = SoundgasmProfileIE(url1)
    assert profile2 is not None
    # Test creating SoundgasmProfileIE object with invalid username

# Generated at 2022-06-22 08:18:56.555756
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()


# Generated at 2022-06-22 08:18:59.415271
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-22 08:19:00.303961
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    pass

# Generated at 2022-06-22 08:19:03.011053
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE("u/ytdl")
    assert ie.IE_NAME == "soundgasm:profile"

# Generated at 2022-06-22 08:19:12.745604
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE()
    assert sg.IE_NAME == 'soundgasm'
    assert sg._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:19:17.376048
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg_profile = SoundgasmProfileIE()
    assert isinstance(sg_profile, InfoExtractor)
    assert sg_profile.IE_NAME == 'soundgasm:profile'
    assert sg_profile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert sg_profile._TEST['url'] == 'http://soundgasm.net/u/ytdl'

# Generated at 2022-06-22 08:19:24.958436
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from .common import common_test, common_playlist_results
    from . import SoundgasmProfileIE
    return common_test(SoundgasmProfileIE, [
        (common_playlist_results('SoundgasmProfileIE', [
            'http://soundgasm.net/u/ytdl',
        ]))
    ])

# Generated at 2022-06-22 08:19:28.791959
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # If a url is valid, the function _real_extract() should be called
    assert SoundgasmProfileIE()._real_extract is not None


# Generated at 2022-06-22 08:19:31.329208
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE._VALID_URL == re.compile(SoundgasmIE._VALID_URL).pattern

# Generated at 2022-06-22 08:19:34.689709
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	try:
		assert isinstance(SoundgasmIE(), InfoExtractor)
	except AssertionError as e:
		print('AssertionError raised when testing constructor of class SoundgasmIE')


# Generated at 2022-06-22 08:19:37.319005
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    k = SoundgasmProfileIE()
    assert k.IE_NAME == 'soundgasm:profile'
    assert k.IE_DESC == 'Soundgasm user profile'

# Generated at 2022-06-22 08:19:41.976886
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    # execute constructor
    ie = SoundgasmIE()

    # test the type of instance object
    assert type(ie) == SoundgasmIE

    # test the value of the instance object
    assert ie.IE_NAME == 'soundgasm'


# Generated at 2022-06-22 08:19:48.874109
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	from extractor import SoundgasmProfileIE
	SIE = SoundgasmProfileIE("Soundgasm", "http://soundgasm.net/u/ytdl")
	assert SIE.extractor_key == "Soundgasm"
	assert SIE.url == "http://soundgasm.net/u/ytdl"
	assert SIE.new_url == "http://soundgasm.net/u/ytdl/" # Should match the regular expression
	assert SIE.IE_NAME == "Soundgasm"
  

# Generated at 2022-06-22 08:19:51.449285
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    t = SoundgasmProfileIE()
    assert t._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/([^/]+)/?(?:#.*)?$'

# Generated at 2022-06-22 08:19:58.790700
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE()
    audio_url = 'http://soundgasm.net/sounds/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    audio_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    info = ie._real_extract(url)
    assert info['id'] == audio_id
    assert info['url'] == audio_url
    

# Generated at 2022-06-22 08:20:04.395220
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert SoundgasmProfileIE._TEST == {'url':'http://soundgasm.net/u/ytdl', 'info_dict':{'id': 'ytdl'}, 'playlist_count': 1}
    

# Generated at 2022-06-22 08:20:18.794309
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info = SoundgasmIE("https://soundgasm.net/u/awesomedude/cool-music")
    assert info.IE_NAME == "soundgasm"
    assert info._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)"



# Generated at 2022-06-22 08:20:29.713793
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'
    assert ie._TEST['info_dict']['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert ie

# Generated at 2022-06-22 08:20:34.021291
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
  SoundgasmIE()._real_extract('http://soundgasm.net/u/ytdl/Piano-sample')
  SoundgasmIE()._real_extract('http://soundgasm.net/u/ytdl/Piano-sample?something')

# Generated at 2022-06-22 08:20:36.986437
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert hasattr(ie, 'downloader') == False
    assert hasattr(ie, 'extractor') == False


# Generated at 2022-06-22 08:20:42.592006
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    ie = SoundgasmIE()
    ie.sound_gasm_u_info_extract(url)
    assert ie.get_value() == 88


# Generated at 2022-06-22 08:20:46.648783
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/1hx7/ytdl'
    profile_id = 'ytdl'
    profile_page = 'http://soundgasm.net/u/ytdl'
    SoundgasmProfileIE(IE_NAME,url, profile_id, profile_page)


# Generated at 2022-06-22 08:20:56.016233
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import unittest
    class TestSoundgasmProfileIE(unittest.TestCase):
        def setUp(self):
            self.ie = SoundgasmProfileIE()

        def test_constructor(self):
            """
            Simple unit test for constructor of class SoundgasmProfileIE
            """
            self.assertEqual(self.ie.ie_key(), 'Soundgasm')
            self.assertEqual(self.ie.ie_name(), 'Soundgasm')
            self.assertEqual(self.ie.ie_version(), '1.0')
            self.assertEqual(self.ie.extract('http://soundgasm.net/u/ytdl'), True)
    unittest.main()

# Generated at 2022-06-22 08:21:03.953361
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("test_SoundgasmIE: ")
    assert str(SoundgasmIE(None)._VALID_URL) == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert str(SoundgasmIE(None).IE_NAME) == 'soundgasm'


# Generated at 2022-06-22 08:21:15.729307
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    
    # Test normal constructor from soundgasm
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    mobj = re.match(SoundgasmIE._VALID_URL, url)
    assert SoundgasmIE.IE_NAME == 'soundgasm'
    assert SoundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert mobj.group('user') == 'ytdl'
    assert mobj.group('display_id') == 'Piano-sample'
    
    # Test constructor from soundgasm profile

# Generated at 2022-06-22 08:21:20.488352
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    class_name = 'SoundgasmProfileIE'
    argv = [class_name, '--test']
    output = subprocess.check_output(argv).decode('utf-8')
    expected_output = 'ERROR: Invalid URL:'
    assert expected_output in output, '{0} not in {1}'.format(expected_output, output)

# Generated at 2022-06-22 08:21:44.078770
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .test_soundgasm import expect_soundgasm_content_and_title
    SoundgasmIE.test()
    expect_soundgasm_content_and_title('http://soundgasm.net/u/ytdl/Piano-sample',
                                   '010082a2c802c5275bb00030743e75ad',
                                   '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
                                   'Piano sample')

# Generated at 2022-06-22 08:21:45.342347
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('', '')
    assert ie.playlist_count  == 1

# Generated at 2022-06-22 08:21:47.420299
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    try:
        SoundgasmIE('http://soundgasm.net/profile/ytdl/')
    except TypeError:
        print('Unit test for SoundgasmIE succeed!')


# Generated at 2022-06-22 08:21:58.660000
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Placeholder variables that can be replaced or refined in subclasses
    VALID_URL = 'http://soundgasm.net/u/ytdl'
    CONTENT_ID = 'ytdl'
    EXPECTED_IE = 'Soundgasm'
    ytdl = SoundgasmProfileIE()
    url_testcase = ytdl.url_result(VALID_URL, EXPECTED_IE)
    id_testcase = ytdl.playlist_result([url_testcase], CONTENT_ID)
    assert url_testcase == {'url': VALID_URL, 'ie_key': EXPECTED_IE}
    assert id_testcase == {'id': CONTENT_ID, 'entries': [url_testcase]}


# Generated at 2022-06-22 08:22:01.772010
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')

# Generated at 2022-06-22 08:22:05.236470
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:22:08.883488
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    URL = 'http://soundgasm.net/u/ytdl'
    playlist_count = 1

    ie = SoundgasmProfileIE(URL)
    assert ie.URL == URL
    assert ie.playlist_count == playlist_count

# Generated at 2022-06-22 08:22:09.910675
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('SoundgasmProfileIE')

# Generated at 2022-06-22 08:22:19.283471
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import odroid_utility as utility
    SoundgasmIE = utility.load_class('odroid_utility.SoundgasmIE')
    test_cases = [
            'http://soundgasm.net/u/ytdl/Piano-sample', #normal link
            'http://soundgasm.net/u/ytdl/Piano-sample/foobar', # link with subpage
            'http://www.soundgasm.net/u/ytdl/Piano-sample', #link with www.
        ]
    for test_case in test_cases:
        print('testing case: %s' % (test_case))
        soundgasm_ie = SoundgasmIE(test_case)
        assert(soundgasm_ie.match_url(test_case))


# Generated at 2022-06-22 08:22:21.005831
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	t = SoundgasmProfileIE()

# Generated at 2022-06-22 08:23:04.386212
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    Soundgasm = SoundgasmIE()
    Soundgasm._TEST = None
    assert Soundgasm != None


# Generated at 2022-06-22 08:23:13.941603
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm = SoundgasmProfileIE()
    soundgasm._match_id = re.match
    assert soundgasm._match_id(url='http://soundgasm.net/u/ytdl', pattern='http://soundgasm.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
    assert soundgasm._match_id(url='http://soundgasm.net/u/ytdl')
    assert soundgasm._match_id(url='http://soundgasm.net/u/ytdl/')
    assert soundgasm._match_id(url='http://soundgasm.net/u/ytdl/#test')
    assert soundgasm._match_id(url='http://soundgasm.net/u/ytdl/test#test')

# Generated at 2022-06-22 08:23:19.466903
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	from.common import InfoExtractor
	from.common import FileDownloader

	# This is creating instance of the SoundgasmProfileIE class 
	SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

	# This is creating instance of the FileDownloader class
	FileDownloader('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-22 08:23:23.744821
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	assert SoundgasmProfileIE('http://soundgasm.net/u/ytdl')._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:23:35.656487
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_url = 'http://soundgasm.net/u/ytdl'
    expected = SoundgasmProfileIE(InfoExtractor())
    expected.ie_key = 'Soundgasm'
    expected.ie_name = 'soundgasm:profile'
    expected.url = test_url
    expected.url_result = expected
    expected.entries = []

    test_url = 'http://soundgasm.net/u/ytdl#audio-list'
    expected = SoundgasmProfileIE(InfoExtractor())
    expected.ie_key = 'Soundgasm'
    expected.ie_name = 'soundgasm:profile'
    expected.url = test_url
    expected.url_result = expected
    expected.entries = []


# Generated at 2022-06-22 08:23:38.693404
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    m = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    #m.extractor(m.url)
    #m.extractor()

# Generated at 2022-06-22 08:23:41.409227
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    assert soundgasm.IE_NAME == 'soundgasm'

# Generated at 2022-06-22 08:23:49.844373
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test for soundgasm constructor
    mod = __import__('youtube_dl.extractor.soundgasm',globals(), locals(), ['SoundgasmIE'],-1)
    print (mod.__name__)
    assert mod.__name__ == 'youtube_dl.extractor.soundgasm'
    # Test SoundgasmIE constructor
    soundgasm = mod.SoundgasmIE()
    assert soundgasm.ie_key() == 'Soundgasm'
    assert soundgasm.ie_name() == 'Soundgasm'


# Generated at 2022-06-22 08:23:51.598785
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance = SoundgasmIE('http://soundgasm.net/u/ytdl')
    assert instance is not None

# Generated at 2022-06-22 08:24:02.356405
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    objSoundgasmIE = SoundgasmIE()
    extractInfo = InfoExtractor().extract(url)
    assert extractInfo['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert extractInfo['display_id'] == 'Piano-sample'
    assert extractInfo['url'] == 'http://storage.soundgasm.net/u/ytdl/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    assert extractInfo['vcodec'] == 'none'
    assert extractInfo['title'] == 'Piano sample'
    assert extractInfo['description'] == 'Royalty Free Sample Music'
   

# Generated at 2022-06-22 08:25:38.858693
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sg = SoundgasmIE('', {'url': 'https://soundgasm.net/u/ytdl/Piano-sample'})
    assert sg.ie_key() == 'Soundgasm'
    assert sg.suitable('') is True

# Generated at 2022-06-22 08:25:49.039301
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    unit = SoundgasmIE()

# Generated at 2022-06-22 08:25:56.292393
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE(None)
    obj.IE_NAME = 'soundgasm:profile'
    obj._VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:26:07.873041
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print('Testing SoundgasmIE')
    _TEST = {
            'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
            'md5': '010082a2c802c5275bb00030743e75ad',
            'info_dict': {
                'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
                'ext': 'm4a',
                'title': 'Piano sample',
                'description': 'Royalty Free Sample Music',
                'uploader': 'ytdl',
            }
        }
    SoundgasmIE()._real_extract(_TEST['url'])
    #assert(SoundgasmIE()._real_extract(_TEST['url']) == _TEST['info_

# Generated at 2022-06-22 08:26:13.170535
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    profile = SoundgasmProfileIE()
    profile.extract(url)
    assert profile.playlist_count == 1
    assert profile.display_id == 'ytdl'
    assert profile.id == 'ytdl'
    assert profile.title == 'ytdl'
    assert profile.url == url

# Generated at 2022-06-22 08:26:16.346638
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Unit test for constructor of class SoundgasmIE
    _dummy_soundgasmIE = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')



# Generated at 2022-06-22 08:26:19.600104
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    with pytest.raises(TypeError) as excinfo:
        SoundgasmProfileIE(None)
    assert "__init__() takes at least 2 arguments (1 given)" in str(excinfo.value)

# Generated at 2022-06-22 08:26:25.274703
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-22 08:26:27.720253
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()._download_webpage('https://soundgasm.net/u/ytdl', 'ytdl')


# Generated at 2022-06-22 08:26:37.941434
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from . import FFmpegExtractors
    from .test_common import get_testcases

    testcases = get_testcases(FFmpegExtractors)

    tests = {
        'SoundgasmIE': {
            'urls': ['https://soundgasm.net/u/ytdl/Piano-sample'],
            'info_dict': {
                'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
                'ext': 'm4a',
                'title': 'Piano sample',
                'description': 'Royalty Free Sample Music',
                'uploader': 'ytdl',
            }
        },
    }
