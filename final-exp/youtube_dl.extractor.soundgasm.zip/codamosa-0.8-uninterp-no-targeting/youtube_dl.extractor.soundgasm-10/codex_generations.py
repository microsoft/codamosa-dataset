

# Generated at 2022-06-22 08:18:38.714713
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    #url = "https://soundgasm.net/u/ytdl/Piano-Intro"
    #url = "http://soundgasm.net/u/ytdl/Piano-Intro"
    #url = "https://soundgasm.net/u/ytdl/Piano-Intro"
    #url = "https://soundgasm.net/u/ytdl/Piano-sample"
    #url = "https://soundgasm.net/u/ytdl/Piano-sample?pl=true"
    soundgasm_ie = SoundgasmIE()



# Generated at 2022-06-22 08:18:47.681431
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    def test_init():
        IE_NAME='soundgasm'

    def test_extract():
        url='http://soundgasm.net/u/ytdl/Piano-sample'
        title='Piano sample'
        description='Royalty Free Sample Music'
        uploader='ytdl'
        mobj = re.match(SoundgasmIE._VALID_URL, url)
        display_id = mobj.group('display_id')

        webpage = SoundgasmIE._download_webpage(url, display_id)

        audio_url = SoundgasmIE._html_search_regex(
            r'(?s)m4a\s*:\s*(["\'])(?P<url>(?:(?!\1).)+)\1', webpage,
            'audio URL', group='url')

       

# Generated at 2022-06-22 08:18:57.603898
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Test case for SoundgasmProfileIE
    """
    # Define function to extract id from passed URL
    def _match_id(url):
        """
        Extracts profile_id from Soundgasm URL.
        """
        m = re.match(SoundgasmProfileIE._VALID_URL, url)
        if m:
            return m.group('id')
        else:
            return None

    # Create URL input
    url = 'http://soundgasm.net/u/ytdl'

    # Construct SoundgasmProfileIE object
    soundgasm_profile_ie_obj = SoundgasmProfileIE(1)
    soundgasm_profile_ie_obj.url = url
    soundgasm_profile_ie_obj._match_id = _match_id
    soundgasm_profile_ie_

# Generated at 2022-06-22 08:19:04.192894
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-22 08:19:07.111549
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# test for constructor of class SoundgasmProfileIE

# Generated at 2022-06-22 08:19:10.032992
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()

# Generated at 2022-06-22 08:19:11.734672
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    assert soundgasm.IE_NAME == 'soundgasm'

# Generated at 2022-06-22 08:19:13.397368
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()
    assert obj.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-22 08:19:14.207980
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:19:24.566348
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = "http://soundgasm.net/u/ytdl"

    # Construct the expected result for the test
    expected_result = {
        '_type': 'playlist',
        'id': 'ytdl',
        'entries': [
            {
                '_type': 'url',
                'url': 'http://soundgasm.net/u/ytdl/Piano-sample',
                'ie_key': 'Soundgasm',
            },
            {
                '_type': 'url',
                'url': 'http://soundgasm.net/u/ytdl/foo',
                'ie_key': 'Soundgasm'
            },
        ]
    }

    # Construct the page to download

# Generated at 2022-06-22 08:19:33.467305
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class_ = SoundgasmIE()
    assert class_.IE_NAME == 'soundgasm'
    assert class_._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:19:42.671513
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'
    assert ie._TEST['info_dict']['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert ie._TEST['info_dict']['ext'] == 'm4a'
    assert ie._TEST['info_dict']['title'] == 'Piano sample'
    assert ie._TEST['info_dict']['description'] == 'Royalty Free Sample Music'

# Generated at 2022-06-22 08:19:46.272728
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl")
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl/")
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl#")

# Generated at 2022-06-22 08:19:51.924465
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

    assert ie.display_id == 'Piano-sample'
    assert ie.url == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert ie.ie_key() == 'Soundgasm'



# Generated at 2022-06-22 08:19:58.937335
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    urlbase = 'http://soundgasm.net'
    urlpath = '/u/ytdl'

    info_extractor = SoundgasmProfileIE(urlbase, urlpath)
    assert(info_extractor.IE_NAME == 'soundgasm:profile')

    urlmatch = info_extractor.URL_RE.search(urlbase + urlpath)

    assert(urlmatch.group('id') == 'ytdl')
    assert(len(urlmatch.groups()) == 1)

# Generated at 2022-06-22 08:20:03.573051
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Create an instance of SoundgasmIE
    ie = SoundgasmIE()

    # Check that URL matches
    assert ie._match_id('http://soundgasm.net/u/ytdl/Piano-sample')

    # Check if it's the correct instance of InfoExtractor
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-22 08:20:04.899396
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    extractor = SoundgasmIE()
    assert extractor.IE_NAME == 'Soundgasm'
    assert extractor.test()

# Generated at 2022-06-22 08:20:10.430621
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIE()
    # Test the method _download_webpage
    webpage = soundgasm._download_webpage('http://soundgasm.net/u/ytdl/Piano-sample', 'Piano-sample')
    assert webpage is not None
    assert len(webpage) > 0
    # Test the method _search_regex
    # Note: the list of parameters should have 3 or 4 elements
    found_title = soundgasm._search_regex(r'<div[^>]+\bclass=["\']jp-title[^>]+>([^<]+)', webpage, 'title', default='Piano-sample')
    assert found_title == 'Piano sample'
    # Test the method _real_extract

# Generated at 2022-06-22 08:20:15.023036
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    # Test constructor of class SoundgasmProfileIE
    def test_constructor():
        ie = SoundgasmProfileIE()

    try:
        # Test constructor of class SoundgasmProfileIE
        test_constructor()
    except:
        # If an exception occurred, return failure
        return False

    # Return success
    return True

# Generated at 2022-06-22 08:20:24.653028
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    webpage = '<div class="jp-title">Piano sample</div>'
    audio_url = 'http://s1.soundgasm.net/u/ytdl/Piano-sample.m4a'

    class FakeWebpage(object):
        def __init__(self, webpage, audio_url):
            self.webpage = webpage
            self.url = audio_url

        def read(self):
            return self.webpage

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            pass

    class FakeDownloader(object):
        def __init__(self, audio_url):
            self.audo_url = audio

# Generated at 2022-06-22 08:20:35.713375
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    """
    Test extraction of Soundgasm.net url.
    """
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    test = SoundgasmIE()._real_extract(url)
    print(test)


# Generated at 2022-06-22 08:20:39.967713
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print('Testing SoundgasmIE')
    SoundgasmIE._download_webpage = lambda *args, **kwargs: ''
    SoundgasmIE().extract('http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-22 08:20:42.292268
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    SoundgasmProfileIE()._real_extract(url)

# Generated at 2022-06-22 08:20:43.616602
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    #test_SoundgasmProfileIE
    SoundgasmProfileIE(None)

# Generated at 2022-06-22 08:20:47.918754
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	# to test if the constructor is working properly
	if SoundgasmProfileIE.__name__ != "SoundgasmProfileIE":
		raise AssertionError(SoundgasmProfileIE.__name__)
	# if the constructor is working properly and the class name is correct

# Generated at 2022-06-22 08:20:49.011560
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(None)

# Generated at 2022-06-22 08:20:52.568467
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasmIE= SoundgasmIE()
    soundgasmIE._VALID_URL
    soundgasmIE._TEST
    soundgasmIE._real_extract()

# Generated at 2022-06-22 08:21:02.034187
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  ie = SoundgasmProfileIE()
  url = 'http://soundgasm.net/u/ytdl'
  profile_id = 'ytdl'
  webpage = ie._download_webpage(url, profile_id)
  #print(webpage)
  entries = [
            ie.url_result(audio_url, 'Soundgasm')
            for audio_url in re.findall(r'href="([^"]+/u/%s/[^"]+)' % profile_id, webpage)]
  #print(entries)
  ie.playlist_result(entries, profile_id)

# Generated at 2022-06-22 08:21:07.380617
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    sg = SoundgasmProfileIE('SoundgasmProfileIE', 'ytdl')
    assert(sg.IE_NAME == 'SoundgasmProfileIE')
    assert(sg._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')


# Generated at 2022-06-22 08:21:17.889615
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info_dict = {
        'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
        'ext': 'm4a',
        'title': 'Piano sample',
        'description': 'Royalty Free Sample Music',
        'uploader': 'ytdl'
    }


# Generated at 2022-06-22 08:21:38.931443
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    x = SoundgasmProfileIE()
    assert x.IE_NAME.startswith('soundgasm')
    assert x._VALID_URL == SoundgasmProfileIE._VALID_URL
    Example = { "url": "http://soundgasm.net/u/ytdl", "info_dict": { "id": "ytdl" }, "playlist_count": 1 }
    assert x._TEST == Example

# Generated at 2022-06-22 08:21:49.287861
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ins = SoundgasmIE()
    assert repr(ins).startswith("<") and repr(ins).endswith(">")
    assert ins._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    ins = SoundgasmIE(URL_TEMPLATE = r'www\.example\.com/{user}/{display_id}')
    assert ins._VALID_URL == r'https?://(?:www\.)?example\.com/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

#

# Generated at 2022-06-22 08:21:50.306504
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE(InfoExtractor())

# Generated at 2022-06-22 08:21:53.707512
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE._TEST['playlist'] = ['Soundgasm']
    SoundgasmProfileIE('test', SoundgasmProfileIE._TEST)

# Generated at 2022-06-22 08:21:55.071419
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE() != None)


# Generated at 2022-06-22 08:21:56.493513
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    from . import SoundgasmProfileIE
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:21:57.389834
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	profile = SoundgasmProfileIE()

# Generated at 2022-06-22 08:22:08.769498
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.__class__.__name__ == 'SoundgasmProfileIE'

    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}

# Generated at 2022-06-22 08:22:15.669296
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/Youtube_Downloader'
    obj = SoundgasmProfileIE(url)
    assert obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert obj._TEST['url'] == 'http://soundgasm.net/u/ytdl'
    assert obj._TEST['info_dict']['id'] == 'ytdl'
    assert obj._TEST['playlist_count'] == 1

# Generated at 2022-06-22 08:22:23.234317
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    ie = SoundgasmIE()
    assert ie._VALID_URL == SoundgasmIE._VALID_URL
    assert ie._TEST == SoundgasmIE._TEST
    assert ie._TEST == SoundgasmIE._TEST
    assert ie.IE_NAME == SoundgasmIE.IE_NAME
    assert ie._real_extract(url)
    url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE()
    assert ie._real_extract(url)

# Generated at 2022-06-22 08:23:07.319114
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST['url'] == 'http://soundgasm.net/u/ytdl'

# Generated at 2022-06-22 08:23:08.579743
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-22 08:23:09.498895
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE(None)

# Generated at 2022-06-22 08:23:11.832695
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    #This passes
    i = SoundgasmIE()
    #This fails
    #i = YoutubeIE()
    i.suitable(url)

# Generated at 2022-06-22 08:23:15.642650
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        # throws AssertionError if __init__ is not available
        SoundgasmProfileIE.__init__
    except:
        assert False

# Generated at 2022-06-22 08:23:18.417405
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    playlist = SoundgasmProfileIE()
    playlist._real_extract(url)

# Generated at 2022-06-22 08:23:21.379758
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE(None)
    ie.extract(None)

# Generated at 2022-06-22 08:23:28.066198
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    class SoundgasmProfileIE(InfoExtractor):
        IE_NAME = 'soundgasm:profile'
        _VALID_URL = r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
        _TEST = {
            'url': 'http://soundgasm.net/u/ytdl',
            'info_dict': {
                'id': 'ytdl',
            },
            'playlist_count': 1,
        }

    url = 'http://soundgasm.net/u/ytdl'
    ie = SoundgasmProfileIE()

# Generated at 2022-06-22 08:23:40.194071
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():

    # Test 1
    url = 'http://soundgasm.net/u/ytdl'
    result = SoundgasmProfileIE()._real_extract(url)

    # Check if class is defined
    assert(hasattr(result, '__class__'))
    assert(result[0].__class__.__name__ == 'URLResult')

    # Test 2
    #url = 'http://soundgasm.net/u/idontlikecats'
    #result = SoundgasmProfileIE()._real_extract(url)

    # Check if class is defined
    #assert(hasattr(result, '__class__'))
    #assert(result[0].__class__.__name__ == 'URLResult')

    # Test 3
    #url = 'http://soundgasm.net/u/ytdl'

# Generated at 2022-06-22 08:23:46.059600
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test_url = 'http://soundgasm.net/u/ytdl'
    expected_title = 'ytdl'
    profile = SoundgasmProfileIE(test_url)
    assert profile.IE_NAME == 'soundgasm:profile'
    assert expected_title in profile._match_id(test_url)
    assert profile._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:25:15.505884
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    extractor = SoundgasmProfileIE()
    assert extractor.IE_NAME == 'soundgasm:profile'



# Generated at 2022-06-22 08:25:24.575800
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import requests
    import sys

    from .common import ExtractorError

    class MockRequest(object):
        def __init__(self, headers, raise_for_status, text):
            self.headers = headers
            self.raise_for_status = raise_for_status
            self.text = text
        def headers(self, headers):
            return self.headers
        def raise_for_status(self):
            return self.raise_for_status
        def text(self):
            return self.text

    def test_raises_ExtractorError():
        profile_id = 'nonsense'
        mock_requests = MockRequest(None, requests.exceptions.HTTPError('HTTP Error'), None)
        mock_sys = MockRequest(None, None, None)

# Generated at 2022-06-22 08:25:28.842510
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:25:40.482060
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert re.match(r'https?://(?:www\.)?soundgasm\.net/u/[0-9a-zA-Z_-]+/[0-9a-zA-Z_-]+', ie.VALID_URL) == None
    assert ie.IE_NAME == 'soundgasm'

    ie = SoundgasmIE('https://soundgasm.net/u/ytdl/Piano-sample')
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert ie.IE_NAME == 'soundgasm'

# Generated at 2022-06-22 08:25:45.816859
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE();
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-22 08:25:54.133358
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = "http://soundgasm.net/u/ytdl"
    profile = SoundgasmProfileIE()
    assert profile.IE_NAME == "soundgasm:profile"
    assert profile.VALID_URL_REGEX == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert re.search(r"^https?://(?:www\.)?soundgasm\.net/u/ytdl$", url)
    assert profile._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-22 08:25:54.920636
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    pass

# Generated at 2022-06-22 08:26:00.716782
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE('Soundgasm:profile', 'http://soundgasm.net/u/ytdl', 'mssuj')
    assert obj.name == 'Soundgasm:profile'
    assert obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:26:09.833379
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import sys
    import os
    print(os.path.dirname(os.path.realpath(__file__)))
    #sys.path.append(os.path.dirname(os.path.realpath(__file__))+'/../youtube-dl/')
    #import youtube_dl
    #print(dir(youtube_dl))
    #print(dir(youtube_dl.youtube_dl))
    #print(dir(youtube_dl.youtube_dl.YoutubeDL))
    #print(dir(youtube_dl.youtube_dl.YoutubeDL.__init__))
    print('Testing SoundgasmIE')
    #ydl = youtube_dl.YoutubeDL({})
    #o = SoundgasmIE(ydl)
    #print(o)
    #print(dir(o))
    #print(yd

# Generated at 2022-06-22 08:26:13.852495
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl', 'Soundgasm')

# Generated at 2022-06-22 08:27:55.164945
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE('http://soundgasm.net/u/ytdl') == None)
    assert(SoundgasmProfileIE('https://soundgasm.net/u/ytdl', 'ytdl') == None)

# Generated at 2022-06-22 08:27:57.774598
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    s = SoundgasmIE()
    assert isinstance(s, SoundgasmIE)


# Generated at 2022-06-22 08:28:00.689365
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE(InfoExtractor()).download("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-22 08:28:11.327219
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(SoundgasmProfileIE().IE_NAME == 'soundgasm:profile')
    assert(SoundgasmProfileIE()._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
    assert(SoundgasmProfileIE()._TEST['url'] == 'http://soundgasm.net/u/ytdl')
    assert(SoundgasmProfileIE()._TEST['info_dict']['id'] == 'ytdl')
    assert(SoundgasmProfileIE()._TEST['playlist_count'] == 1)

# Generated at 2022-06-22 08:28:23.606571
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import requests
    import json
    import io

    html = requests.get('http://soundgasm.net/u/ytdl').text
    m = re.search(r'href="([^"]+/u/ytdl/[^"]+)', html)
    assert m is not None

    audio_url = m.group(1)
    m = re.search(r'/(.*)\.m4a', audio_url)
    assert m is not None
    audio_id = m.group(1)

    info = json.loads(io.open('test/testdata/SoundgasmProfile/' + audio_id).read())
    info.update({'id':audio_id})
    info.update({'url':audio_url})
    info.update({'ext':'m4a'})

# Generated at 2022-06-22 08:28:26.425726
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasmie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert(soundgasmie.IE_NAME == 'soundgasm')
