

# Generated at 2022-06-22 08:18:40.632457
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'


# Generated at 2022-06-22 08:18:42.386641
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasmProfileIE = SoundgasmProfileIE()
    soundgasmProfileIE._real_extract('')

# Generated at 2022-06-22 08:18:46.643802
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    soundgasm = SoundgasmIE()
    soundgasm._downloader = 1
    result = soundgasm.extract(url)
    assert result['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-22 08:18:47.670117
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test = "test"
    assert test == "test"

# Generated at 2022-06-22 08:18:49.503326
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == SoundgasmIE.IE_NAME


# Generated at 2022-06-22 08:18:50.765752
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:18:53.777106
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
  """
  Unit test for constructor of class SoundgasmProfileIE
  """
  instance = SoundgasmProfileIE()
  assert instance is not None
  assert 'SoundgasmProfileIE' == instance.IE_NAME

# Generated at 2022-06-22 08:18:59.708712
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE(None)
    assert ie.url_result('http://soundgasm.net') is not None
    assert ie.url_result('http://soundgasm.net/u/ytdl/Piano-sample') is not None
    assert ie.url_result('http://soundgasm.net/u/ytdl') is not None

# Generated at 2022-06-22 08:19:03.759950
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    proc = SoundgasmProfileIE()
    try:
        test = proc.IE_NAME
    except AttributeError:
        test = "No IE_NAME"
    assert test == 'soundgasm:profile', 'IE_NAME attribute value incorrect!'

# Generated at 2022-06-22 08:19:09.819574
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE._download_webpage("http://soundgasm.net/u/ytdl/Piano-sample","Piano-sample")
    SoundgasmIE._html_search_regex("",'<div class="jp-title" aria-label="title">Piano sample</div>', 'title', default="")
    SoundgasmIE._search_regex("","Piano sample", 'title', default="")
    

# Generated at 2022-06-22 08:19:23.909810
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    text = "http://soundgasm.net/u/ytdl"
    profile_id = 'ytdl'
    webpage = "href='https://soundgasm.net/u/ytdl/Piano-sample' href='https://soundgasm.net/u/ytdl/Piano-sample'"
    entries = []
    entries.append(SoundgasmProfileIE.url_result('https://soundgasm.net/u/ytdl/Piano-sample', 'Soundgasm'))
    entries.append(SoundgasmProfileIE.url_result('https://soundgasm.net/u/ytdl/Piano-sample', 'Soundgasm'))

    SoundgasmProfileIE._download_webpage(SoundgasmProfileIE, text, profile_id)

# Generated at 2022-06-22 08:19:33.468586
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()

    # test1: SoundgasmProfileIE should support http://soundgasm.net/u/ytdl/
    url = "http://soundgasm.net/u/ytdl/"
    expected = {
        'id': 'ytdl'
    }
    assert ie._match_id(url) == expected['id']

    # test2: SoundgasmProfileIE should support http://soundgasm.net/u/ytdl
    url = "http://soundgasm.net/u/ytdl"
    assert ie._match_id(url) == expected['id']

# Generated at 2022-06-22 08:19:38.370263
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Testing empty playlist download
    pl_id = 'havug'  # Empty playlist test
    url = 'http://soundgasm.net/u/' + pl_id
    profile_list = SoundgasmProfileIE()._real_extract(url)
    assert profile_list['id'] == pl_id
    assert len(profile_list['entries']) == 0

# Generated at 2022-06-22 08:19:43.651778
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	#Replace with your actual URL first
	fake_url = 'http://soundgasm.net/u/ytdl'
	soundgasm = SoundgasmProfileIE(httpGet=DummyHttpGet())
	response = soundgasm._real_extract(fake_url)

# Generated at 2022-06-22 08:19:49.140493
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    sample_URL = 'http://soundgasm.net/u/ytdl/Piano-sample'
    obj=SoundgasmIE.SoundgasmIE()
    obj.extract(sample_URL)

if __name__=="__main__":
    test_SoundgasmIE()

# Generated at 2022-06-22 08:19:52.641188
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    import sys
    sys.path.append('/Users/DJC/.virtualenvs/Holberton-Bash-2/lib/python3.4/site-packages')
    from ytdl.extractor import (
        SoundgasmProfileIE,
    )
    import unittest
    import ytdl.extractor
    ytdl.extractor.list_extractors()
    suite = unittest.TestLoader().loadTestsFromTestCase(SoundgasmProfileIE)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-22 08:19:58.225841
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    info = SoundgasmIE()._call_api(url, '88abd86ea000cafe98f96321b23cc1206cbcbcc9')
    
    assert 'id' in info
    assert 'url' in info
    assert 'title' in info
    assert 'description' in info
    assert 'uploader' in info

# Generated at 2022-06-22 08:20:00.623511
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test video ID saved in constructor
    sg = SoundgasmIE('test')
    if (sg.videoid is not 'test'):
        assert False
    return

# Generated at 2022-06-22 08:20:05.694000
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    sg_profile = SoundgasmProfileIE()
    sg_profile.url = url
    assert sg_profile.url == url
        
test_SoundgasmProfileIE()


# Generated at 2022-06-22 08:20:14.075690
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Testing constructor of class SoundgasmProfileIE
    soundgasm_profile_ie = SoundgasmProfileIE()
    assert soundgasm_profile_ie.IE_NAME == 'soundgasm:profile'
    assert soundgasm_profile_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert soundgasm_profile_ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-22 08:20:23.092539
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # SoundgasmIE.__init__(self)
    SoundgasmIE()

# Generated at 2022-06-22 08:20:26.379912
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    e = SoundgasmProfileIE()
    assert e._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'

# Generated at 2022-06-22 08:20:27.820614
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	# the test case
	SoundgasmProfileIE.test()

# Generated at 2022-06-22 08:20:38.889444
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('')
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:20:42.425041
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    with open('test.html') as f:
        webpage = f.read()
    ie.extract_info(None, webpage, None)

# Generated at 2022-06-22 08:20:49.315899
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl', {'id': 'ytdl'})
    assert ie.url == 'http://soundgasm.net/u/ytdl'
    assert ie._match_id('http://soundgasm.net/u/ytdl') == 'ytdl'
    assert ie._match_id('http://soundgasm.net/u/ytdl/') == 'ytdl'
    assert ie._match_id('http://soundgasm.net/u/ytdl/#') == 'ytdl'
    assert ie._match_id('http://soundgasm.net/u/ytdl/#1') == 'ytdl'

# Generated at 2022-06-22 08:20:52.847913
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._build_url('http://soundgasm.net/u/ytdl') == 'http://soundgasm.net/u/ytdl/'

# Generated at 2022-06-22 08:21:05.153392
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from . import util
    import urlparse
    instance = SoundgasmIE()
    assert(instance.IE_NAME == 'soundgasm')
    assert(instance._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')
    test = instance._TEST
    assert(test['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample')
    assert(test['md5'] == '010082a2c802c5275bb00030743e75ad')
    InfoExtractor.test(instance, test)
    assert(isinstance(instance, InfoExtractor))

# Generated at 2022-06-22 08:21:09.363742
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import pytest
    ie = pytest.importorskip('soundgasm.SoundgasmIE')
    assert ie.IE_NAME == 'soundgasm'
    assert ie.IE_DESC == 'Soundgasm'

# Generated at 2022-06-22 08:21:10.409670
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        SoundgasmProfileIE('foo', 'bar')
    except:
        assert False

# Generated at 2022-06-22 08:21:35.532750
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Initialise class
    soundgasm_ie = SoundgasmIE()
    assert soundgasm_ie.IE_NAME == 'soundgasm'

    # Check that URL is valid
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert soundgasm_ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert re.match(soundgasm_ie._VALID_URL, url)

    # Extract information from URL
    mobj = re.match(soundgasm_ie._VALID_URL, url)

# Generated at 2022-06-22 08:21:36.488059
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    info = SoundgasmIE().IE_NAME
    assert info == 'soundgasm'

# Generated at 2022-06-22 08:21:40.640673
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmIE()._download_webpage(url, 'Piano-sample')

# Generated at 2022-06-22 08:21:44.061332
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE("http://soundgasm.net/profile/ytdl#sound-tracks")
    SoundgasmProfileIE("http://soundgasm.net/u/ytdl")

# Generated at 2022-06-22 08:21:47.474838
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    u_id = "ytdl"
    url = 'http://soundgasm.net/u/%s' % u_id
    instance = SoundgasmProfileIE()
    assert re.match(instance._VALID_URL, url)

# Generated at 2022-06-22 08:21:56.775428
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    class_SoundgasmProfileIE = SoundgasmProfileIE()
    assert class_SoundgasmProfileIE.IE_NAME == 'soundgasm:profile'
    assert class_SoundgasmProfileIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert class_SoundgasmProfileIE._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }



# Generated at 2022-06-22 08:22:02.793878
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm = SoundgasmIEWithFakeHttpAdapters()
    soundgasm._fake_http_adapter = FakeHttpAdapterForTest()
    soundgasm._real_extract("http://soundgasm.net/u/ytdl/Piano-sample")
    assert soundgasm.title ==  "Piano sample"
    assert soundgasm.display_id == "Piano-sample"
    assert soundgasm.uploader == "ytdl"
    assert soundgasm.webpage_url == "http://soundgasm.net/u/ytdl/Piano-sample"
    assert soundgasm.id == "88abd86ea000cafe98f96321b23cc1206cbcbcc9"

# Generated at 2022-06-22 08:22:07.003636
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie.__class__.__name__ == 'SoundgasmIE'

# Generated at 2022-06-22 08:22:11.353025
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    obj = SoundgasmProfileIE()
    assert obj.IE_NAME == 'soundgasm:profile'
    assert obj._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'

# Generated at 2022-06-22 08:22:19.983356
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST ==   {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }
    assert ie.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-22 08:22:58.935551
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE(downloader=None).IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-22 08:23:08.935030
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Testing constructor of SoundgasmProfileIE class"""
    ie = SoundgasmProfileIE()

    expected_id = 'ytdl'
    expected_url = 'http://soundgasm.net/u/ytdl'
    expected_title = 'ytdl'

    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST['url'] == expected_url
    assert ie._TEST['info_dict']['id'] == expected_id

    # TODO: test real download of a webpage and check the info are correctly fetched
    # assert ie.ie_key() == 'Soundgasm'
    # assert ie.suitable(url) == True
    # assert

# Generated at 2022-06-22 08:23:15.160990
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # initialize instance of class SoundgasmIE
    sg = SoundgasmIE()
    # check if instance is initialized correctly
    assert (isinstance(sg, SoundgasmIE))
    assert (isinstance(sg, InfoExtractor))


# Generated at 2022-06-22 08:23:17.737928
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Creating object of class SoundgasmProfileIE
    soundgasm = SoundgasmProfileIE()
    assert soundgasm is not None

# Generated at 2022-06-22 08:23:23.944766
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test to make sure it runs
    assert SoundgasmIE()._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:23:30.678029
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert(SoundgasmIE.IE_NAME == 'soundgasm')
    assert(SoundgasmIE.IE_DESC == 'Soundgasm sound files')
    assert(SoundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-22 08:23:41.277781
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	s1 = SoundgasmIE()
	s2 = SoundgasmIE()
	s3 = SoundgasmIE()
	n=0
	while n < 10:
		instance1 = SoundgasmIE()
		instance2 = SoundgasmIE()
		instance3 = SoundgasmIE()

# Generated at 2022-06-22 08:23:44.677363
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL == SoundgasmProfileIE._VALID_URL

# Generated at 2022-06-22 08:23:47.731808
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl/'
    ie = SoundgasmProfileIE()
    profile = ie.get_profile_url(url)
    print (profile)

# Generated at 2022-06-22 08:23:58.669567
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")
    assert(ie.IE_NAME == 'Soundgasm')
    assert(ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')

# Generated at 2022-06-22 08:25:26.280836
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == "soundgasm"


# Generated at 2022-06-22 08:25:32.029716
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert SoundgasmIE.IE_NAME == "SoundgasmIE"


# Generated at 2022-06-22 08:25:36.963449
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    if not ie._TEST == {}:
        return
    ie._TEST = {'url': 'http://soundgasm.net/u/ytdl'}
    ie._real_extract(ie._TEST)

# Generated at 2022-06-22 08:25:38.375595
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE().IE_NAME == 'Soundgasm'


# Generated at 2022-06-22 08:25:38.767814
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	SoundgasmIE()

# Generated at 2022-06-22 08:25:46.026209
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .common import dl_for_test

    # First, test downloading the test file
    dl_for_test(SoundgasmIE,
        '88abd86ea000cafe98f96321b23cc1206cbcbcc9')

    # Next, test downloading the test profile
    # Contains just one file, which has already been downloaded
    dl_for_test(SoundgasmProfileIE,
        'ytdl', count=1)

# Generated at 2022-06-22 08:25:49.679622
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    url = 'http://soundgasm.net/u/ytdl'
    SoundgasmProfileIE(url)

# Generated at 2022-06-22 08:26:01.278911
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasmIE = SoundgasmIE()
    assert soundgasmIE.IE_NAME == 'Soundgasm'
    assert soundgasmIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:26:09.865121
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test if the constructor of class SoundgasmIE is working
    import urlparse
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mobj = re.match(SoundgasmIE._VALID_URL, url)
    assert mobj is not None

    # Test if class SoundgasmIE's extractor_key is working
    assert SoundgasmIE.ie_key() == 'soundgasm'

    # Test if class SoundgasmIE's check_valid_url is working
    assert SoundgasmIE.check_valid_url(url) is True
    assert SoundgasmIE.check_valid_url('http://soundgasm.net/u/ytdl/Piano-sample/') is False

# Generated at 2022-06-22 08:26:21.338012
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # construct an instance of class SoundgasmProfileIE
    soundgasm_profile_ie = SoundgasmProfileIE("SoundgasmProfileIE")

    assert(soundgasm_profile_ie.IE_NAME == 'SoundgasmProfileIE')
    assert(soundgasm_profile_ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$')
    assert(soundgasm_profile_ie._TEST['url'] == 'http://soundgasm.net/u/ytdl')
    assert(soundgasm_profile_ie._TEST['info_dict']['id'] == 'ytdl')
    assert(soundgasm_profile_ie._TEST['playlist_count'] == 1)