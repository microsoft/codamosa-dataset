

# Generated at 2022-06-22 08:18:39.242182
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # Given a SoundgasmProfileIE instance
    SoundgasmProfileIE(InfoExtractor)
    # Then the result is not None
    assert SoundgasmProfileIE(InfoExtractor) is not None


# Generated at 2022-06-22 08:18:43.525309
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'


# Generated at 2022-06-22 08:18:45.349413
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm_profile = SoundgasmProfileIE('Soundgasm', 'http://soundgasm.net/u/ytdl')

# Generated at 2022-06-22 08:18:55.771672
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	url = 'http://www.youtube.com'
	user = 'ytdl'
	display_id = 'Piano-sample'
	expected_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
	expected_mkv = '010082a2c802c5275bb00030743e75ad'
	expected_title = 'Piano sample'
	expected_descr = 'Royalty Free Sample Music'
	expected_uploader = 'ytdl'
	actual_url = test_SoundgasmProfileIE.url_result(url, user, display_id)
	actual_mkv = test_SoundgasmProfileIE.md5
	actual_title = test_SoundgasmProfileIE.title
	actual_descr = test_SoundgasmProfileIE.description
	actual_

# Generated at 2022-06-22 08:19:05.253417
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test URL
    # This is a redirect to an actual URL
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    obj_soundgasmie = SoundgasmIE()
    # Test real url extraction
    real_url = obj_soundgasmie._real_extract(url)['url']
    # URL extracted properly
    assert '88abd86ea000cafe98f96321b23cc1206cbcbcc9' in real_url

# Generated at 2022-06-22 08:19:15.161512
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    # Test URL
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    # Test info dict
    info_dict = {
        'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
        'ext': 'm4a',
        'title': 'Piano sample',
        'description': 'Royalty Free Sample Music',
        'uploader': 'ytdl',
        'url': 'http://static.soundgasm.net/mp3/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a',
        'vcodec': 'none'
    }
    # Test
    result = ie.extract(url)

# Generated at 2022-06-22 08:19:23.157858
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()

    assert_equal(ie._VALID_URL, 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?')
    assert_equal(ie.IE_NAME, "soundgasm:profile")
    assert_equal(ie._TEST,
        {
            "url": "http://soundgasm.net/u/ytdl",
            "info_dict": {"id": "ytdl"},
            "playlist_count": 1
        }
    )


# Generated at 2022-06-22 08:19:32.521201
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    class MockExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {'id': 'test_id'}
        def check_validity(self, *args, **kwargs):
            return True
    SoundgasmIE.register_ie('mock', MockExtractor)
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert isinstance(ie, MockExtractor)
    assert ie._downloader._ies.pop() == MockExtractor

# Generated at 2022-06-22 08:19:40.261076
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ig = SoundgasmIE('http://www.soundgasm.net/u/ytdl/Piano-sample')
    test_info = {'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9',
                 'ext': 'm4a',
                 'title': 'Piano sample',
                 'description': 'Royalty Free Sample Music',
                 'uploader': 'ytdl',
                 'upload_date': None,
                 'uploader_id': 'ytdl',
                 'uploader_url': None
                 }
    assert ig == test_info

# Generated at 2022-06-22 08:19:43.976190
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    c = SoundgasmProfileIE()
    assert c.IE_NAME == SoundgasmProfileIE.IE_NAME
    assert c.VALID_URL == SoundgasmProfileIE._VALID_URL
    assert c.TEST == SoundgasmProfileIE._TEST

# Generated at 2022-06-22 08:20:01.070008
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    objIE = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert(objIE.IE_NAME == 'soundgasm')
    assert(objIE.VALID_URL == 'http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-22 08:20:07.288430
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    # This function is called everytime this file is run as a script
    # So, I am using it to test the constructor of class SoundgasmProfileIE
    # "isinstance" will tell whether the object is the instance of a class
    instance = SoundgasmProfileIE()
    assert isinstance(instance, SoundgasmProfileIE)
    print("This is the SoundgasmProfileIE: {}".format(instance))


# Generated at 2022-06-22 08:20:09.046298
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("testing SoundgasmIE")

    obj = SoundgasmIE()
    assert(isinstance(obj, SoundgasmIE))


# Generated at 2022-06-22 08:20:19.059796
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    fetch_result = {"url": url, "webpage": webpage}
    download_webpage_mock = MagicMock(return_value=fetch_result)
    instance = SoundgasmIE(download_webpage_mock)
    assert instance._download_webpage == download_webpage_mock
    assert instance.IE_NAME == 'soundgasm'
    assert instance._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:20:20.964974
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	SoundgasmIE(test_SoundgasmIE)


# Generated at 2022-06-22 08:20:24.788238
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    x = SoundgasmIE()
    assert x.IE_NAME == 'Soundgasm'
    assert x._VALID_URL == 'http://soudgasm.net/u/ytdl/Piano-sample'


# Generated at 2022-06-22 08:20:35.914674
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	from .common import mp4_id
	from .extractor import get_info_extractor
	from .youtube_dl.extractor.soundgasm import SoundgasmIE

	info_dict = SoundgasmIE()._real_extract("http://soundgasm.net/u/ytdl/Piano-sample")

# Generated at 2022-06-22 08:20:38.472513
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('SoundgasmProfileIE', 'http://soundgasm.net/u/ytdl', 'Soundgasm')

# Generated at 2022-06-22 08:20:39.508929
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:20:40.474206
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE("1", "2")

# Generated at 2022-06-22 08:21:03.442431
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    inst = SoundgasmProfileIE()
    assert inst._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/([^/]+)/?(?:\#.*)?$'
    assert inst._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-22 08:21:05.766568
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    soundgasm = SoundgasmProfileIE()
    soundgasm = SoundgasmIE()

test_SoundgasmProfileIE()

# Generated at 2022-06-22 08:21:06.470768
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	pass

# Generated at 2022-06-22 08:21:07.470629
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(dict())

# Generated at 2022-06-22 08:21:10.573162
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profile = SoundgasmProfileIE("")
    assert profile.IE_NAME == 'soundgasm:profile'
    assert profile.VALID_URL

# Generated at 2022-06-22 08:21:18.535070
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mobj = re.match(ie._VALID_URL, url)
    assert mobj.group('user') == 'ytdl'
    assert mobj.group('display_id') == 'Piano-sample'
    return

# Generated at 2022-06-22 08:21:23.099793
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('soundgasm.net')
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:21:31.405453
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE(None)._VALID_URL == SoundgasmProfileIE._VALID_URL
    assert SoundgasmProfileIE(None).IE_NAME == SoundgasmProfileIE._IE_NAME
    assert SoundgasmProfileIE(None)._TEST == SoundgasmProfileIE._TEST
    assert SoundgasmProfileIE(None)._real_extract(SoundgasmProfileIE(None)._TEST['url']) == SoundgasmProfileIE(None)._TEST['info_dict']


# Generated at 2022-06-22 08:21:41.933940
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    #First, test actual input with valid URL
    dummy_func1 = lambda x: False
    dummy_func2 = lambda x: True
    # First, test actual input with valid URL
    ie = SoundgasmIE("http://soundgasm.net/u/ytdl/Piano-sample")

    # use setattr to set function to True
    # then check if constructor of SoundgasmIE class 
    # sets all the right functions to True
    setattr(ie, '_real_extract', dummy_func2)
    ie.__init__("http://soundgasm.net/u/ytdl/Piano-sample")
    assert ie._real_extract == dummy_func2



# Generated at 2022-06-22 08:21:47.380904
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert(ie.IE_NAME == 'soundgasm')
    assert(ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')


# Generated at 2022-06-22 08:22:14.491052
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    a = "http://soundgasm.net/u/ytdl/Piano-sample"
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)', "URL validation regex should be as expected"
    assert ie.IE_NAME == 'soundgasm', "IE name should be soundgasm"
    assert ie.suitable(a), "Should be suitable"
    assert ie.suitable("http://soundgasm.net/"), "Should be suitable"
    assert not ie.suitable("http://google.com/"), "Should not be suitable"
    assert ie._real_extract

# Generated at 2022-06-22 08:22:16.313464
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	from .. import SoundgasmProfileIE
	ie = SoundgasmProfileIE()
	pass

# Generated at 2022-06-22 08:22:21.041907
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    youtube_dl_instance = YoutubeDL()
    IE_registry = youtube_dl_instance._ies
    # Get an instance of SoundgasmIE
    SoundgasmIE_instance = IE_registry.get('soundgasm')
    assert SoundgasmIE_instance is not None
    assert isinstance(SoundgasmIE_instance, SoundgasmIE)

# Generated at 2022-06-22 08:22:23.369636
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()._real_extract('http://soundgasm.net/u/ytdl/')

# Generated at 2022-06-22 08:22:35.496778
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    instance1 = SoundgasmIE()
    assert instance1._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert instance1._TEST['md5'] == '010082a2c802c5275bb00030743e75ad'
    assert instance1._TEST['info_dict'] == {'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9', 'ext': 'm4a', 'title': 'Piano sample', 'description': 'Royalty Free Sample Music', 'uploader': 'ytdl'}

# Generated at 2022-06-22 08:22:36.558532
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    unittest.main()

# Generated at 2022-06-22 08:22:47.185714
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():

    # Create a SoundgasmIE object using default constructor
    obj = SoundgasmIE()

    # Check if object is created successfully
    assert obj.SUCCESS
    assert obj.IE_NAME == 'soundgasm'
    assert obj.VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:22:48.379930
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	ie = SoundgasmProfileIE();

# Generated at 2022-06-22 08:22:49.704440
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    s = SoundgasmProfileIE()
    assert s is not None

# Generated at 2022-06-22 08:22:51.064515
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    print("Test for SoundgasmIE")



# Generated at 2022-06-22 08:23:31.927062
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # constructor of class SoundgasmIE
    ie = SoundgasmIE()
    # check if class SoundgasmIE has attr. IE_NAME
    assert hasattr(ie, 'IE_NAME')
    # check if class SoundgasmIE has attr. _VALID_URL
    assert hasattr(ie, '_VALID_URL')
    # check if class SoundgasmIE has attr. _TEST
    assert hasattr(ie, '_TEST')
    return ie


# Generated at 2022-06-22 08:23:35.900079
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Initialize an empty object
    obj = SoundgasmIE()
    # Check if the object is instatiated correctly
    assert obj.IE_NAME == 'soundgasm'


# Generated at 2022-06-22 08:23:36.839286
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:23:46.879246
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Check if SoundgasmIE is able to initialize SoundgasmIE
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    inst = SoundgasmIE()
    # Check the returned value from _check_valid_url
    assert inst._check_valid_url(url) == True
    # Check the return value for _real_extract
    assert inst._real_extract(url)
    # Check if SoundgasmIE is able to initialize SoundgasmProfileIE
    url = 'http://soundgasm.net/u/ytdl'
    inst = SoundgasmIE()
    # Check the returned value from _check_valid_url
    assert inst._check_valid_url(url) == True
    # Check the return value for _real_extract
    assert inst._real_ext

# Generated at 2022-06-22 08:23:49.455638
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Check instance of class SoundgasmIE
    assert isinstance(SoundgasmIE(), SoundgasmIE), 'The class SoundgasmIE is incorrect'


# Generated at 2022-06-22 08:23:50.447272
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE()

# Generated at 2022-06-22 08:23:54.358691
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # To perform unit test for SoundgasmIE object
    ie = SoundgasmIE()
    assert ie.suitable('http://soundgasm.net/u/ytdl/Piano-sample') == True


# Generated at 2022-06-22 08:24:02.145271
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.ie_key() == 'Soundgasm'
    assert ie.ie_name() == 'Soundgasm'

# Generated at 2022-06-22 08:24:06.043809
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-22 08:24:12.648737
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert ie.IE_NAME == 'SoundgasmProfileIE'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}
    return ie


# Generated at 2022-06-22 08:25:50.199900
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	# Init
	ie = SoundgasmIE(None)

	# Test url
	url = ie._VALID_URL

	assert re.match(url, 'http://soundgasm.net/u/ytdl/Piano-sample')
	assert re.match(url, 'https://soundgasm.net/u/ytdl/Piano-sample')
	assert not re.match(url, 'http://soundgasm.net/u/ytdl/Piano-sample/')
	assert not re.match(url, 'http://soundgasm.net/u/ytdl/')
	assert not re.match(url, 'http://soundgasm.net/u/ytdl')
	assert not re.match(url, 'http://soundgasm.net/ytdl/Piano-sample')
	

# Generated at 2022-06-22 08:25:51.949504
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE()

# Generated at 2022-06-22 08:26:00.559469
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    profileIE = SoundgasmProfileIE('http://soundgasm.net/u/ytdl')
    assert profileIE.IE_NAME == 'soundgasm:profile'
    assert profileIE._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:#.*)?$'
    assert profileIE._TEST == {'url': 'http://soundgasm.net/u/ytdl', 'info_dict': {'id': 'ytdl'}, 'playlist_count': 1}


# Generated at 2022-06-22 08:26:02.873888
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE()._VALID_URL

# Generated at 2022-06-22 08:26:10.727337
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url = "http://soundgasm.net/u/ytdl/Piano-sample"
    test_display_id = "Piano-sample"
    test_user = "ytdl"

    assert(SoundgasmIE._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')
    assert(SoundgasmIE._TEST['url'] == test_url)
    assert(SoundgasmIE._TEST['md5'] == '010082a2c802c5275bb00030743e75ad')

    ie = SoundgasmIE()


# Generated at 2022-06-22 08:26:19.484442
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    soundgasm_ie = SoundgasmIE()

    # test parameters of SoundgasmIE
    assert soundgasm_ie.ie_key() == 'soundgasm'
    assert soundgasm_ie.ie_name() == 'soundgasm'

    # test if patterns are correct
    assert soundgasm_ie._VALID_URL == 'https?://(?:www\\.)?soundgasm\\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

    # test if parameters of SoundgasmIE._TEST are correct
    assert soundgasm_ie._TEST['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert soundgasm_ie._

# Generated at 2022-06-22 08:26:24.005908
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    yt = SoundgasmIE()
    ytp = SoundgasmProfileIE()
    try:
        from IPython.core.debugger import Tracer
        Tracer()() 
    except ImportError:
        pass

# Generated at 2022-06-22 08:26:29.640266
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    res = SoundgasmProfileIE._build_url_result(
        SoundgasmProfileIE._VALID_URL, 'Soundgasm',
        ('http://soundgasm.net/u/ytdl/Piano-sample',))
    assert res == {
        'url': res['url'],
        'ie_key': 'Soundgasm',
    }

# Generated at 2022-06-22 08:26:31.710032
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    x = SoundgasmProfileIE()
    assert x.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-22 08:26:38.326635
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie._VALID_URL == 'http://soundgasm.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
