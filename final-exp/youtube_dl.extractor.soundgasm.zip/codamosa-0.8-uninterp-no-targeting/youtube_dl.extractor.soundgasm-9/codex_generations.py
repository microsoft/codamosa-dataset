

# Generated at 2022-06-22 08:18:40.081576
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    audio_id = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    display_id = 'Piano-sample'
    audio_url = 'https://audio.soundgasm.net/u/ytdl/Piano-sample/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    title = 'Piano sample'
    description = 'Royalty Free Sample Music'
    uploader = 'ytdl'
    url = 'http://soundgasm.net/u/' + uploader + '/' + display_id

    soundgasm = SoundgasmIE()


# Generated at 2022-06-22 08:18:41.530379
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-22 08:18:43.183977
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	soundgasm = SoundgasmProfileIE()
	assert(isinstance(soundgasm, SoundgasmProfileIE))

# Generated at 2022-06-22 08:18:45.008140
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    assert SoundgasmIE('Soundgasm', 'http://soundgasm.net/u/ytdl/Piano-sample')


# Generated at 2022-06-22 08:18:49.350552
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_tuple = ("http://soundgasm.net/u/ytdl/Piano-sample","Soundgasm")
    test_ie = SoundgasmIE
    assert test_ie(test_tuple[0]) == test_tuple[1]
    
    

# Generated at 2022-06-22 08:18:51.013401
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    inf = SoundgasmProfileIE()
    id = inf._match_id('http://soundgasm.net/u/test-fixture#')
    assert(id == 'test-fixture')

# Generated at 2022-06-22 08:18:57.423520
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    instance = SoundgasmProfileIE()
    assert instance.IE_NAME == "soundgasm:profile"
    assert instance._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?'
    assert instance._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-22 08:18:59.131783
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert(len(SoundgasmProfileIE._TESTS) == 1)

# Generated at 2022-06-22 08:19:01.848735
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-22 08:19:12.097873
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	print("Testing SoundgasmIE")
	
	print("\nTesting soundgasm.net/u/ytdl/Piano-sample")
	ie = SoundgasmIE()
	info = ie.extract('http://soundgasm.net/u/ytdl/Piano-sample')
	print(info)
	assert info['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
	assert info['display_id'] == 'Piano-sample'
	assert info['title'] == 'Piano sample'
	assert info['url'] == 'http://s3.soundgasm.net/u/ytdl/Piano-sample.m4a'
	assert info['uploader'] == 'ytdl'

# Generated at 2022-06-22 08:19:22.496614
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
  try:
    SoundgasmIE()
  except NameError as e:
    assert(False, e)
  except Exception as e:
    assert(True, e)

# Generated at 2022-06-22 08:19:27.331706
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    user_page = "http://soundgasm.net/u/ytdl"
    url = SoundgasmProfileIE._extract_urls(user_page)
    assert url == "http://soundgasm.net/u/ytdl"


# Generated at 2022-06-22 08:19:32.013575
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Tests the method of constructor for class SoundgasmProfileIE"""
    # Test for constructor
    ie = SoundgasmProfileIE()
    if not isinstance(ie, SoundgasmProfileIE):
        raise TypeError("Cannot constructor SoundgasmProfileIE")


# Generated at 2022-06-22 08:19:41.066638
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """Unit test for testing SoundgasmProfileIE"""

    sg_profile_ie = SoundgasmProfileIE()
    assert 'soundgasm:profile' == sg_profile_ie.IE_NAME
    assert 'https?://(?:www\.)?soundgasm\.net/u/[^/]+/?(?:\#.*)?$' == sg_profile_ie._VALID_URL

    my_test_url = 'http://soundgasm.net/u/ytdl'
    my_test_result = 'ytdl'

    my_test_mobj = re.match(sg_profile_ie._VALID_URL, my_test_url)
    assert my_test_result == my_test_mobj.group('id')

# Generated at 2022-06-22 08:19:51.716023
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    init = SoundgasmIE()
    assert init.IE_NAME == 'soundgasm'
    assert init._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    assert init.IE_DESC == 'Soundgasm'
    assert init._TEST[0]['url'] == 'http://soundgasm.net/u/ytdl/Piano-sample'
    assert init._TEST[0]['md5'] == '010082a2c802c5275bb00030743e75ad'

# Generated at 2022-06-22 08:19:54.554708
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'

    extractor = SoundgasmIE()

    extractor.extract(url)

# Generated at 2022-06-22 08:20:03.386607
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Constructor of superclass InfoExtractor
    IE = InfoExtractor
    audio_info_dict = {}
    audio_info_dict['ext'] = 'm4a'
    audio_info_dict['id'] = '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    audio_info_dict['title'] = 'Piano sample'
    audio_info_dict['description'] = 'Royalty Free Sample Music'
    audio_info_dict['uploader'] = 'ytdl'
    audio_url = 'http://d1j72xkp8twhat.cloudfront.net/88abd86ea000cafe98f96321b23cc1206cbcbcc9'

# Generated at 2022-06-22 08:20:06.112435
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Add your own test url
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    # Run test
    SoundgasmIE()._real_extract(url)

# Generated at 2022-06-22 08:20:07.808963
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    """
    Unit test for constructor of class SoundgasmProfileIE
    """
    SoundgasmProfileIE(None, None)

# Generated at 2022-06-22 08:20:14.971699
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    ie = SoundgasmProfileIE()
    assert ie.IE_NAME == 'soundgasm:profile'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert ie._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }


# Generated at 2022-06-22 08:20:32.963364
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    assert SoundgasmProfileIE('test').extract_info('http://soundgasm.net/u/ytdl') == {}

# Generated at 2022-06-22 08:20:38.842321
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
        # Basic test for constructor of class SoundgasmIE
        # Testing with a known video 'Piano sample'
        inst = SoundgasmIE({'url': 'http://soundgasm.net/u/ytdl/Piano-sample', 'id': '88abd86ea000cafe98f96321b23cc1206cbcbcc9'})
        assert inst

# Generated at 2022-06-22 08:20:40.239810
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	instance = SoundgasmIE()
	assert instance is not None


# Generated at 2022-06-22 08:20:42.904713
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .test_soundgasm import (
        SoundgasmIE as ExtractorUnitTest
    )
    ExtractorUnitTest(SoundgasmIE).run()

# Generated at 2022-06-22 08:20:52.909800
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    mobj = re.match(SoundgasmIE._VALID_URL, test_url)
    title = r'Piano sample'
    uploader = r'ytdl'
    description = r'Royalty Free Sample Music'
    display_id = r'Piano-sample'
    audio_url = r'http://soundgasm.net/f/ytdl/Piano-sample.m4a'
    audio_id = r'88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    ie = SoundgasmIE._build_settings(test_url)
    assert ie._match_id(test_url) == uploader

# Generated at 2022-06-22 08:20:55.749761
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
	info = SoundgasmProfileIE()
	print (info.IE_NAME)
	print (info._VALID_URL)
	print (info._TEST)

# Generated at 2022-06-22 08:21:06.219003
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    audio_url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    SoundgasmProfileIE._download_webpage = lambda self, url, filename: '<div><a href="%s/u/ytdl/Piano-sample">Piano-sample</a></div>' % url

    info_dict = SoundgasmProfileIE()._real_extract('http://soundgasm.net/u/ytdl')
    assert info_dict['id'] == 'ytdl'
    assert len(info_dict['entries']) == 1
    assert info_dict['entries'][0]['url'] == audio_url


# Generated at 2022-06-22 08:21:06.929339
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()

# Generated at 2022-06-22 08:21:13.475391
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    info = SoundgasmIE()._real_extract(url)

    assert info['id'] == '88abd86ea000cafe98f96321b23cc1206cbcbcc9'
    assert info['url'] == 'http://soundgasm.net/media/soundgasm/88a/88abd86ea000cafe98f96321b23cc1206cbcbcc9.m4a'
    assert info['description'] == 'Royalty Free Sample Music'
    assert info['title'] == 'Piano sample'
    assert info['uploader'] == 'ytdl'
    assert info['vcodec'] == 'none'


# Generated at 2022-06-22 08:21:16.252609
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test creation of SoundgasmIE object
    info = SoundgasmIE()
    assert info
    assert isinstance(info, SoundgasmIE)


# Generated at 2022-06-22 08:21:50.434770
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    SoundgasmIE('http:/soundgasm.net/u/ytdl/Piano-sample')

# Generated at 2022-06-22 08:22:01.381350
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie.IE_DESC == 'Soundgasm.net'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:22:04.092237
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE(dict(), "https://soundgasm.net/u/ytdl")

# Generated at 2022-06-22 08:22:07.628187
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    a = SoundgasmProfileIE()
    b = SoundgasmIE()
    assert a._VALID_URL == b._VALID_URL
    assert a.IE_NAME == 'soundgasm:profile'

# Generated at 2022-06-22 08:22:12.001076
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    from .common import InfoExtractor,ExtractorError
    ie=InfoExtractor()
    ie.register_ie(SoundgasmIE.ie_key(),SoundgasmIE)
    url="http://soundgasm.net/u/ytdl/Piano-sample"
    ie.extract(url)

# Generated at 2022-06-22 08:22:21.327438
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    r''' Constructor of class SoundgasmIE.
    '''
    ie = SoundgasmIE(SoundgasmIE.ie_key())
    assert ie.ie_key() == 'Soundgasm'
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:22:30.125737
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    m = SoundgasmProfileIE()
    m._request_webpage = lambda x, y, z: 'test'
    m._match_id = lambda x: 'test'
    m._search_regex = lambda x, y, z: 'test'
    m.url_result = lambda x, y: 'test'
    m.playlist_result = lambda x, y: 'test'
    m._real_extract('test')

    m._search_regex = lambda x, y: 'test'
    m._real_extract('test')


# Generated at 2022-06-22 08:22:41.251279
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == 'soundgasm'
    assert ie.IE_DESC == 'Soundgasm'
    assert ie._VALID_URL == r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:22:45.645671
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE()
    assert ie.IE_NAME == ie.IE_NAME
    assert ie._VALID_URL == ie._VALID_URL
    assert ie._TEST == ie._TEST


# Generated at 2022-06-22 08:22:49.042812
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = "http://soundgasm.net/u/ytdl/Piano-sample"
    SoundgasmIE().extract(url)


# Generated at 2022-06-22 08:24:13.339059
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    import unittest
    # Unit test on SoundgasmIE
    class TestSoundgasmIE(unittest.TestCase):
        def setUp(self):
            self.ie = SoundgasmIE()

        def test_soundgasm_constructor(self):
            self.assertEqual(self.ie.IE_NAME, 'soundgasm')
            self.assertEqual(self.ie._VALID_URL, r'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)')
            self.assertTrue(self.ie._TEST)
            # assert that the training_data is a dictionary

# Generated at 2022-06-22 08:24:24.032946
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    res = SoundgasmIE(url)
    '''
    print res
    instanse:
    <class '__main__.SoundgasmIE'>
    url
    'http://soundgasm.net/u/ytdl/Piano-sample'
    _VALID_URL
    'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'
    _downloader
    <youtube_dl.YoutubeDL object at 0x7f6cd4b6eed0>
    ie_key
    'Soundgasm'
    '''
    print

# Generated at 2022-06-22 08:24:32.245660
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    infoExtractor = SoundgasmProfileIE()
    assert infoExtractor.IE_NAME == 'soundgasm:profile'
    assert infoExtractor.ie_key() == 'Soundgasm'
    assert infoExtractor._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<id>[^/]+)/?(?:\#.*)?$'
    assert infoExtractor._TEST == {
        'url': 'http://soundgasm.net/u/ytdl',
        'info_dict': {
            'id': 'ytdl',
        },
        'playlist_count': 1,
    }

# Generated at 2022-06-22 08:24:38.829525
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    ie = SoundgasmIE('http://soundgasm.net/u/ytdl/Piano-sample')
    assert ie.IE_NAME == 'soundgasm'
    assert ie._VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'

# Generated at 2022-06-22 08:24:41.799466
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # SoundgasmIE(InfoExtractor) should not raise any exception.
    try:
        SoundgasmIE(None)
    except Exception as e:
        assert False, e


# Generated at 2022-06-22 08:24:44.787467
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    test = SoundgasmProfileIE()
    test_SoundgasmProfileIE.s = test
    assert test_SoundgasmProfileIE.s
    
test_SoundgasmProfileIE()

# Generated at 2022-06-22 08:24:50.623477
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    url = 'http://soundgasm.net/u/ytdl/Piano-sample'
    sg_ie = SoundgasmIE(url)
    assert sg_ie._TEST['url'] == url
    assert sg_ie.ie_key() == 'Soundgasm'
    assert sg_ie.ie_name() == 'Soundgasm'
    assert sg_ie.SUCCESS == 0
    assert sg_ie.FAILED == 1

# Generated at 2022-06-22 08:24:51.734509
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('http://soundgasm.net/u/ytdl')

# Generated at 2022-06-22 08:25:02.032380
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    test = SoundgasmIE()
    assert test.name == "SoundgasmIE"
    assert test.IE_NAME == "soundgasm"
    assert test._VALID_URL == "https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)"

# Generated at 2022-06-22 08:25:13.269247
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
    # Test the constructor
    audio = SoundgasmIE()
    assert audio.username == None
    assert audio.password == None
    assert audio.api_key == None
    assert audio.client_id == None
    assert audio.client_secret == None
    assert audio.developer_key == None
    assert audio.geo_verification_headers == None
    assert audio.geo_bypass == False
    assert audio.geo_bypass_ip_block == None
    assert audio.UI_lang == None
    assert audio.video_id == None
    assert audio.video_url == None
    assert audio.api_url == None
    assert audio.params == None
    assert audio.query == None
    assert audio.video_data == None
    assert audio.notes == []
    assert audio.extractor == None

# Generated at 2022-06-22 08:28:12.175046
# Unit test for constructor of class SoundgasmProfileIE
def test_SoundgasmProfileIE():
    SoundgasmProfileIE('Soundgasm', 'http://soundgasm.net/u/ytdl', {})

# Generated at 2022-06-22 08:28:24.319262
# Unit test for constructor of class SoundgasmIE
def test_SoundgasmIE():
	Soundgasm = SoundgasmIE(None)
	assert Soundgasm.IE_NAME == 'soundgasm'
	assert Soundgasm.VALID_URL == 'https?://(?:www\.)?soundgasm\.net/u/(?P<user>[0-9a-zA-Z_-]+)/(?P<display_id>[0-9a-zA-Z_-]+)'