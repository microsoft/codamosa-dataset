

# Generated at 2022-06-17 15:35:19.713134
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.parse import parse_qs
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.six.moves.urllib.parse import unquote
    from ansible.module_utils.six.moves.urllib.parse import quote_plus
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus

# Generated at 2022-06-17 15:35:30.321217
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:35:38.162176
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import types

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'\u2713') == u'\u2713'
    assert wrap_var(u'\u2713'.encode('utf-8')) == u'\u2713'.encode('utf-8')

# Generated at 2022-06-17 15:35:42.249251
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils.six.moves.urllib.request import urlopen
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.six.moves.urllib.parse import unquote
    from ansible.module_utils.six.moves.urllib.parse import urlencode

# Generated at 2022-06-17 15:35:50.253045
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(set()) == set()
    assert wrap_var(frozenset()) == frozenset()
    assert wrap_var(()) == ()
    assert wrap_var([]) == []
    assert wrap_var({}) == {}
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var

# Generated at 2022-06-17 15:36:01.962331
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert isinstance(wrap_var(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)

    # Test for string
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test for dict
    assert isinstance(wrap_var({'foo': 'bar'}), dict)

# Generated at 2022-06-17 15:36:09.190062
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    # Test strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test lists
    assert isinstance(wrap_var(['foo']), list)
    assert isinstance(wrap_var(['foo'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var([u'foo']), list)
    assert isinstance(wrap_var([u'foo'])[0], AnsibleUnsafeText)

# Generated at 2022-06-17 15:36:17.069766
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'

# Generated at 2022-06-17 15:36:25.455761
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1j) == 1j
    assert wrap_var(set()) == set()
    assert wrap_var(frozenset()) == frozenset()
    assert wrap_var(()) == ()
    assert wrap_var([]) == []
    assert wrap_var({}) == {}
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_

# Generated at 2022-06-17 15:36:35.811863
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')

# Generated at 2022-06-17 15:36:49.103113
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1j) == 1j
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'

# Generated at 2022-06-17 15:36:59.413818
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(set()) == set()
    assert wrap_var(set([1, 2, 3])) == set([1, 2, 3])
    assert wrap_var(frozenset()) == frozenset()
    assert wrap_var(frozenset([1, 2, 3])) == frozenset([1, 2, 3])
   

# Generated at 2022-06-17 15:37:10.242779
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys

    # Test that we can wrap a string
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)

    # Test that we can wrap a unicode string
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)

    # Test that we can wrap a list
    assert isinstance(wrap_var(['foo', 'bar']), list)
    assert isinstance(wrap_var(['foo', 'bar'])[0], AnsibleUnsafeText)

    # Test that we can wrap a tuple
    assert isinstance(wrap_var(('foo', 'bar')), tuple)

# Generated at 2022-06-17 15:37:20.074510
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    # Test for None
    assert wrap_var(None) is None

    # Test for string
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert wrap_var('foo') == 'foo'

    # Test for bytes
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert wrap_var(b'foo') == b'foo'

    # Test for int
    assert wrap_var(1) == 1

    # Test for float
    assert wrap_var(1.0) == 1.0

    # Test for bool
    assert wrap_var(True) is True


# Generated at 2022-06-17 15:37:27.308643
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types, binary_type, text_type

    # Test wrap_var with None
    assert wrap_var(None) is None

    # Test wrap_var with AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText(u'foo')) is AnsibleUnsafeText(u'foo')

    # Test wrap_var with string_types
    assert wrap_var(u'foo') is AnsibleUnsafeText(u'foo')
    assert wrap_var(b'foo') is AnsibleUnsafeBytes(b'foo')

    # Test wrap

# Generated at 2022-06-17 15:37:37.434042
# Unit test for function wrap_var
def test_wrap_var():
    import pytest
    from ansible.module_utils.six import PY3

    # Test that wrap_var returns the same object if it is already unsafe
    assert wrap_var(AnsibleUnsafeText('foo')) is AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')

    # Test that wrap_var returns the same object if it is None
    assert wrap_var(None) is None

    # Test that wrap_var returns the same object if it is not a string
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False

    # Test that wrap_var returns the same object if it

# Generated at 2022-06-17 15:37:44.468735
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    import sys

    # Test for None
    assert wrap_var(None) is None

    # Test for unsafe
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) is AnsibleUnsafeText(u'foo')

    # Test for string
    assert wrap_var(b'foo') is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') is AnsibleUnsafeText(u'foo')

    # Test for dict
    assert wrap_var({b'foo': b'bar'}) == {AnsibleUnsafeBytes(b'foo'): AnsibleUnsafeBytes(b'bar')}


# Generated at 2022-06-17 15:37:51.103331
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:38:01.863095
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:38:09.707404
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) is AnsibleUnsafeText(u'foo')

    # Test for Mapping
    assert wrap_var({}) == {}
    assert wrap_var({'a': 1}) == {'a': 1}
    assert wrap_var({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 15:38:23.408491
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText('foo')) is AnsibleUnsafeText('foo')

    # Test for string
    assert wrap_var('foo') is AnsibleUnsafeText('foo')

    # Test for dict
    assert wrap_var({'foo': 'bar'}) == {'foo': AnsibleUnsafeText('bar')}

    # Test for list
    assert wrap_var(['foo', 'bar']) == [AnsibleUnsafeText('foo'), AnsibleUnsafeText('bar')]

    # Test for tuple

# Generated at 2022-06-17 15:38:35.086847
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(set()) == set()
    assert wrap_var(set([1, 2, 3])) == set([1, 2, 3])
    assert wrap_var(set([1, 2, 3, wrap_var(4)])) == set([1, 2, 3, wrap_var(4)])

# Generated at 2022-06-17 15:38:47.051297
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    import sys

    # Test for None
    assert wrap_var(None) is None

    # Test for unsafe
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) == AnsibleUnsafeText(u'foo')

    # Test for bytes
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')

    # Test for text
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')

    # Test for native jinja text
    assert wrap_var(NativeJinjaText(u'foo')) == NativeJinjaUnsafeText(u'foo')



# Generated at 2022-06-17 15:38:57.656071
# Unit test for function wrap_var
def test_wrap_var():
    import pytest

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes('foo')) == AnsibleUnsafeBytes('foo')

    # Test for string
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')

    # Test for dict
    assert wrap_var({'foo': 'bar'}) == {AnsibleUnsafeText('foo'): AnsibleUnsafeText('bar')}

# Generated at 2022-06-17 15:39:08.377238
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    # Test for None
    assert wrap_var(None) is None

    # Test for string
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)

    # Test for bytes
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test for int
    assert wrap_var(1) == 1

    # Test for float
    assert wrap_var(1.0) == 1.0

    # Test for list
    assert isinstance(wrap_var(['foo', 'bar']), list)
    assert isinstance(wrap_var(['foo', 'bar'])[0], AnsibleUnsafeText)

# Generated at 2022-06-17 15:39:13.277459
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3

    # Test for None
    assert wrap_var(None) is None

    # Test for already wrapped
    assert wrap_var(AnsibleUnsafeText('foo')) is AnsibleUnsafeText('foo')

    # Test for string
    assert wrap_var('foo') is AnsibleUnsafeText('foo')

    # Test for bytes
    if PY3:
        assert wrap_var(b'foo') is AnsibleUnsafeBytes(b'foo')
    else:
        assert wrap_var(b'foo') is AnsibleUnsafeText(b'foo')

    # Test for dict
    assert wrap_var({'foo': 'bar'}) == {'foo': AnsibleUnsafeText('bar')}

    # Test for list

# Generated at 2022-06-17 15:39:22.891553
# Unit test for function wrap_var
def test_wrap_var():
    import copy
    import json
    import sys
    from ansible.module_utils.common.collections import is_sequence

    # Test that we can wrap a string
    assert isinstance(wrap_var("foo"), AnsibleUnsafeText)

    # Test that we can wrap a unicode string
    assert isinstance(wrap_var(u"foo"), AnsibleUnsafeText)

    # Test that we can wrap a byte string
    assert isinstance(wrap_var(b"foo"), AnsibleUnsafeBytes)

    # Test that we can wrap a list
    assert isinstance(wrap_var(["foo"]), list)
    assert isinstance(wrap_var(["foo"])[0], AnsibleUnsafeText)

    # Test that we can wrap a tuple
    assert isinstance(wrap_var(("foo",)), tuple)
    assert isinstance

# Generated at 2022-06-17 15:39:32.594753
# Unit test for function wrap_var
def test_wrap_var():
    import pytest
    from ansible.module_utils.six import PY3

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText("foo")) == AnsibleUnsafeText("foo")
    assert wrap_var(AnsibleUnsafeBytes("foo")) == AnsibleUnsafeBytes("foo")

    # Test for string
    assert wrap_var("foo") == AnsibleUnsafeText("foo")
    assert wrap_var(u"foo") == AnsibleUnsafeText("foo")
    assert wrap_var(b"foo") == AnsibleUnsafeBytes("foo")

    # Test for dict
    assert wrap_var({"foo": "bar"}) == {"foo": AnsibleUnsafeText("bar")}

# Generated at 2022-06-17 15:39:41.495617
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')

    # Test for dict
    assert wrap_var({'foo': 'bar'}) == {'foo': AnsibleUnsafeText('bar')}
    assert wrap_var({'foo': b'bar'}) == {'foo': AnsibleUnsafeBytes(b'bar')}

# Generated at 2022-06-17 15:39:51.934618
# Unit test for function wrap_var
def test_wrap_var():
    import sys
    import unittest

    class TestWrapVar(unittest.TestCase):
        def test_wrap_var_none(self):
            self.assertIsNone(wrap_var(None))

        def test_wrap_var_unsafe(self):
            self.assertIsInstance(wrap_var(AnsibleUnsafeText(u'foo')), AnsibleUnsafeText)

        def test_wrap_var_string(self):
            self.assertIsInstance(wrap_var(u'foo'), AnsibleUnsafeText)

        def test_wrap_var_dict(self):
            self.assertIsInstance(wrap_var({u'foo': u'bar'}), dict)