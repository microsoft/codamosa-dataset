

# Generated at 2022-06-17 15:35:28.926381
# Unit test for function wrap_var
def test_wrap_var():
    # Test for None
    assert wrap_var(None) is None

    # Test for string
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)

    # Test for bytes
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test for tuple
    assert isinstance(wrap_var(('foo',)), tuple)
    assert isinstance(wrap_var(('foo',))[0], AnsibleUnsafeText)

    # Test for list
    assert isinstance(wrap_var(['foo']), list)
    assert isinstance(wrap_var(['foo'])[0], AnsibleUnsafeText)

    # Test for dict

# Generated at 2022-06-17 15:35:37.725433
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'\u2713') == u'\u2713'
    assert wrap_var(u'\u2713'.encode('utf-8')) == u'\u2713'.encode('utf-8')

# Generated at 2022-06-17 15:35:45.830419
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'

# Generated at 2022-06-17 15:35:50.945578
# Unit test for function wrap_var
def test_wrap_var():
    import pytest

    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) is AnsibleUnsafeText(u'foo')

    assert wrap_var(b'foo') is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') is AnsibleUnsafeText(u'foo')

    assert wrap_var({'foo': 'bar'}) == {AnsibleUnsafeText(u'foo'): AnsibleUnsafeText(u'bar')}
    assert wrap_var(['foo', 'bar']) == [AnsibleUnsafeText(u'foo'), AnsibleUnsafeText(u'bar')]

# Generated at 2022-06-17 15:36:02.360268
# Unit test for function wrap_var
def test_wrap_var():
    import unittest
    import sys

    class TestWrapVar(unittest.TestCase):
        def test_wrap_var(self):
            # Test that wrap_var works as expected
            self.assertEqual(wrap_var(None), None)
            self.assertEqual(wrap_var(True), True)
            self.assertEqual(wrap_var(False), False)
            self.assertEqual(wrap_var(1), 1)
            self.assertEqual(wrap_var(1.0), 1.0)
            self.assertEqual(wrap_var(1j), 1j)
            self.assertEqual(wrap_var(set([1, 2, 3])), set([1, 2, 3]))

# Generated at 2022-06-17 15:36:09.338403
# Unit test for function wrap_var
def test_wrap_var():
    import pytest
    from ansible.utils.unsafe_proxy import wrap_var

    # Test wrap_var with None
    assert wrap_var(None) is None

    # Test wrap_var with AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) is AnsibleUnsafeText(u'foo')

    # Test wrap_var with string
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')

    # Test wrap_var with dict

# Generated at 2022-06-17 15:36:17.151400
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    # Test for None
    assert wrap_var(None) is None

    # Test for string
    assert isinstance(wrap_var('string'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'string'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'string'), AnsibleUnsafeText)

    # Test for list
    assert isinstance(wrap_var(['string']), list)
    assert isinstance(wrap_var(['string'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var([b'string']), list)

# Generated at 2022-06-17 15:36:25.501951
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(0) == 0
    assert wrap_var(0.0) == 0.0
    assert wrap_var(0j) == 0j
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'


# Generated at 2022-06-17 15:36:35.851770
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) == AnsibleUnsafeText(u'foo')
    assert wrap_var(NativeJinjaText(u'foo')) == NativeJinjaUnsafeText(u'foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var

# Generated at 2022-06-17 15:36:48.669406
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.collections import is_sequence

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'