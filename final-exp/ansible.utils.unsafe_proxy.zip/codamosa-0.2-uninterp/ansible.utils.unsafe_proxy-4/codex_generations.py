

# Generated at 2022-06-17 15:35:22.242110
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.1) == 1.1
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(set()) == set()
    assert wrap_var(frozenset()) == frozenset()
    assert wrap_var(()) == ()
    assert wrap_var([]) == []
    assert wrap_var({}) == {}
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var

# Generated at 2022-06-17 15:35:31.929933
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(1), type(1))
    assert isinstance(wrap_var(1.0), type(1.0))
    assert isinstance(wrap_var([]), list)
    assert isinstance(wrap_var(()), tuple)
    assert isinstance(wrap_var({}), dict)
    assert isinstance(wrap_var(set()), set)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeText(u'foo')), AnsibleUnsafeText)

# Generated at 2022-06-17 15:35:42.901279
# Unit test for function wrap_var
def test_wrap_var():
    import ansible.module_utils.basic
    import ansible.module_utils.six
    import ansible.module_utils.common.collections
    import ansible.module_utils.common._collections_compat
    import ansible.module_utils.common.text.converters
    import ansible.module_utils.common.text.formatters
    import ansible.module_utils.common.text.utils
    import ansible.module_utils.common.text.wrappers
    import ansible.module_utils.common.text.converters
    import ansible.module_utils.common.text.formatters
    import ansible.module_utils.common.text.utils
    import ansible.module_utils.common.text.wrappers
    import ansible.module_utils.common.text.converters
   

# Generated at 2022-06-17 15:35:52.239236
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:36:03.311875
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText('test')) == AnsibleUnsafeText('test')
    assert wrap_var(AnsibleUnsafeBytes('test')) == AnsibleUnsafeBytes('test')

    # Test for string
    assert wrap_var('test') == AnsibleUnsafeText('test')
    assert wrap_var(u'test') == AnsibleUnsafeText('test')
    if PY3:
        assert wrap_var(b'test') == AnsibleUnsafeBytes(b'test')

    # Test for dict
    assert wrap_var({'a': 'test'}) == {'a': AnsibleUnsafeText('test')}

# Generated at 2022-06-17 15:36:09.813575
# Unit test for function wrap_var
def test_wrap_var():
    import pytest
    from ansible.module_utils.six import PY3

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText(u'foo')) == AnsibleUnsafeText(u'foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')

    # Test for string_types
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')

    # Test for Mapping

# Generated at 2022-06-17 15:36:17.283809
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1j) == 1j
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'

# Generated at 2022-06-17 15:36:24.150094
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')

    # Test for Mapping
    assert wrap_var({'foo': 'bar'}) == {'foo': 'bar'}
    assert wrap_var({'foo': AnsibleUnsafeText('bar')}) == {'foo': AnsibleUnsafeText('bar')}

# Generated at 2022-06-17 15:36:30.452408
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys

    # test strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # test lists
    assert isinstance(wrap_var(['foo']), list)
    assert isinstance(wrap_var(['foo'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var([u'foo']), list)
    assert isinstance(wrap_var([u'foo'])[0], AnsibleUnsafeText)

# Generated at 2022-06-17 15:36:35.086824
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:36:48.774206
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    # Test that we can wrap a string
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)

    # Test that we can wrap a list
    assert isinstance(wrap_var(['foo', 'bar']), list)
    assert isinstance(wrap_var(['foo', 'bar'])[0], AnsibleUnsafeText)

    # Test that we can wrap a tuple
    assert isinstance(wrap_var(('foo', 'bar')), tuple)
    assert isinstance(wrap_var(('foo', 'bar'))[0], AnsibleUnsafeText)

    # Test that we can wrap a dict

# Generated at 2022-06-17 15:36:59.187206
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    # Test wrap_var with None
    assert wrap_var(None) is None

    # Test wrap_var with AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText(u'foo')) == AnsibleUnsafeText(u'foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')

    # Test wrap_var with str
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')

    # Test wrap_var with dict

# Generated at 2022-06-17 15:37:04.859870
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText('foo')) is not None

    # Test for dict
    assert wrap_var({'foo': 'bar'}) == {'foo': 'bar'}
    assert wrap_var({'foo': 'bar', 'baz': {'foo': 'bar'}}) == {'foo': 'bar', 'baz': {'foo': 'bar'}}

    # Test for list
    assert wrap_var([1, 2, 3]) == [1, 2, 3]
    assert wrap_var([1, 2, 3, [1, 2, 3]])

# Generated at 2022-06-17 15:37:15.379224
# Unit test for function wrap_var
def test_wrap_var():
    import pytest
    from ansible.module_utils.six import PY3

    # Test that wrap_var returns the same object if it is already unsafe
    unsafe_text = AnsibleUnsafeText('unsafe')
    assert wrap_var(unsafe_text) is unsafe_text

    # Test that wrap_var returns the same object if it is None
    assert wrap_var(None) is None

    # Test that wrap_var returns the same object if it is a bool
    assert wrap_var(True) is True
    assert wrap_var(False) is False

    # Test that wrap_var returns the same object if it is a number
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0

    # Test that wrap_var returns the same object if it is a tuple
    assert wrap_var

# Generated at 2022-06-17 15:37:24.312661
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var('foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'\u2713') == u'\u2713'
    assert wrap_var(u'\u2713'.encode('utf-8')) == u'\u2713'
    assert wrap_var(u'\u2713'.encode('utf-8')) == u'\u2713'

# Generated at 2022-06-17 15:37:30.093351
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')
    assert wrap_var(u'foo'.encode('utf-8')) == b'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')
   

# Generated at 2022-06-17 15:37:38.558071
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    # Test for None
    assert wrap_var(None) is None

    # Test for unsafe
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) is AnsibleUnsafeText(u'foo')

    # Test for string
    assert wrap_var(b'foo') is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') is AnsibleUnsafeText(u'foo')

    # Test for mapping
    assert wrap_var

# Generated at 2022-06-17 15:37:49.268260
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Test strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'\u2713'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'\u2713'.encode('utf-8')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'\u2713'.encode('utf-16')), AnsibleUnsafeBytes)

# Generated at 2022-06-17 15:37:56.777244
# Unit test for function wrap_var
def test_wrap_var():
    import ansible.module_utils.common.collections as collections

    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(NativeJinjaText(u'foo')), NativeJinjaUnsafeText)
    assert isinstance(wrap_var(NativeJinjaText(b'foo')), NativeJinjaUnsafeText)

# Generated at 2022-06-17 15:38:08.126665
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip

    # Test that wrap_var does not wrap AnsibleUnsafe types
    assert isinstance(wrap_var(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes('foo')), AnsibleUnsafeBytes)

    # Test that wrap_var wraps strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)