

# Generated at 2022-06-17 15:35:21.251148
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys

    # Test that wrap_var doesn't modify the input
    # Test that wrap_var doesn't modify the input
    # Test that wrap_var doesn't modify the input
    # Test that wrap_var doesn't modify the input
    # Test that wrap_var doesn't modify the input
    # Test that wrap_var doesn't modify the input
    # Test that wrap_var doesn't modify the input
    # Test that wrap_var doesn't modify the input
    # Test that wrap_var doesn't modify the input
    # Test that wrap_var doesn't modify the input
    # Test that wrap_var doesn't modify the input
    # Test that wrap_var doesn't modify the input
    # Test that wrap_var

# Generated at 2022-06-17 15:35:31.454428
# Unit test for function wrap_var
def test_wrap_var():
    # Test for None
    assert wrap_var(None) is None

    # Test for string
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'test'), AnsibleUnsafeBytes)

    # Test for tuple
    assert isinstance(wrap_var(('test', 'test')), tuple)
    assert isinstance(wrap_var(('test', 'test'))[0], AnsibleUnsafeText)
    assert isinstance(wrap_var(('test', 'test'))[1], AnsibleUnsafeText)
    assert isinstance(wrap_var((b'test', b'test')), tuple)

# Generated at 2022-06-17 15:35:38.672903
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes('foo')) == AnsibleUnsafeBytes('foo')
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var(['foo', 'bar']) == [AnsibleUnsafeText('foo'), AnsibleUnsafeText('bar')]
    assert wrap_var(('foo', 'bar')) == (AnsibleUnsafeText('foo'), AnsibleUnsafeText('bar'))

# Generated at 2022-06-17 15:35:46.312037
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    # Test wrapping of strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test wrapping of lists
    assert isinstance(wrap_var(['foo', 'bar']), list)
    assert isinstance(wrap_var(['foo', 'bar'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var(['foo', 'bar'])[1], AnsibleUnsafeText)

    # Test wrapping of tuples


# Generated at 2022-06-17 15:35:53.885370
# Unit test for function wrap_var
def test_wrap_var():
    import pytest
    from ansible.module_utils.six import PY3

    # Test for None
    assert wrap_var(None) is None

    # Test for already wrapped
    assert wrap_var(AnsibleUnsafeText('foo')) is AnsibleUnsafeText('foo')

    # Test for string
    assert wrap_var('foo') is AnsibleUnsafeText('foo')

    # Test for dict
    assert wrap_var({'foo': 'bar'}) == {'foo': AnsibleUnsafeText('bar')}

    # Test for list
    assert wrap_var(['foo', 'bar']) == [AnsibleUnsafeText('foo'), AnsibleUnsafeText('bar')]

    # Test for tuple

# Generated at 2022-06-17 15:36:04.589428
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.collections import is_sequence

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1j) == 1j
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'

# Generated at 2022-06-17 15:36:15.378061
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')
    assert wrap_var(u'foo'.encode('utf-8')) == b'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')

# Generated at 2022-06-17 15:36:22.480642
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Test that we can wrap a dict
    d = {'a': 'b'}
    d_wrapped = wrap_var(d)
    assert isinstance(d_wrapped, dict)
    assert isinstance(d_wrapped['a'], AnsibleUnsafeText)

    # Test that we can wrap a list
    l = ['a', 'b']
    l_wrapped = wrap_var(l)
    assert isinstance(l_wrapped, list)
    assert isinstance(l_wrapped[0], AnsibleUnsafeText)

    # Test that we can wrap a tuple
    t = ('a', 'b')
    t_wrapped = wrap_var(t)
   

# Generated at 2022-06-17 15:36:34.324891
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText('foo')) is AnsibleUnsafeText('foo')

    # Test for string_types
    assert wrap_var('foo') is AnsibleUnsafeText('foo')

    # Test for Mapping
    assert wrap_var({'foo': 'bar'}) == {'foo': AnsibleUnsafeText('bar')}

    # Test for Set

# Generated at 2022-06-17 15:36:48.136800
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    display = Display()
    display.deprecated('UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
                       version='2.13', collection_name='ansible.builtin')

    # Test wrap_var with None
    assert wrap_var(None) is None

    # Test wrap_var with AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) is AnsibleUnsafeText(u'foo')

    # Test wrap_var with string
    assert wrap_var(b'foo') is AnsibleUnsafeBytes(b'foo')

# Generated at 2022-06-17 15:36:59.852479
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    # Test strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)

    # Test dict
    assert isinstance(wrap_var({'foo': 'bar'}), dict)

# Generated at 2022-06-17 15:37:05.521360
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    import types
    import sys

    # Test for None
    assert wrap_var(None) is None

    # Test for string
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'test'), AnsibleUnsafeText)
    if PY3:
        assert isinstance(wrap_var(b'test'), AnsibleUnsafeBytes)
    else:
        assert isinstance(wrap_var(b'test'), AnsibleUnsafeText)

    # Test for list
    assert isinstance(wrap_var(['test']), list)
    assert isinstance(wrap_var(['test'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var([u'test']), list)

# Generated at 2022-06-17 15:37:15.608895
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1j) == 1j
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'

# Generated at 2022-06-17 15:37:24.378956
# Unit test for function wrap_var
def test_wrap_var():
    # Test wrap_var with different types of input
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'


# Generated at 2022-06-17 15:37:30.145761
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.1) == 1.1
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(set()) == set()
    assert wrap_var(frozenset()) == frozenset()
    assert wrap_var(()) == ()
    assert wrap_var([]) == []
    assert wrap_var({}) == {}
    assert wrap_var(builtins.range(10)) == builtins.range(10)
    assert wrap_var(set(builtins.range(10))) == set(builtins.range(10))
   

# Generated at 2022-06-17 15:37:38.585052
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) is AnsibleUnsafeText(u'foo')
    assert wrap_var(b'foo') is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') is AnsibleUnsafeText(u'foo')
    assert wrap_var(dict(a=1, b=2)) == dict(a=1, b=2)
    assert wrap_var(dict(a=1, b=2)) == dict(a=1, b=2)
    assert wrap_var(dict(a=1, b=2)) == dict(a=1, b=2)


# Generated at 2022-06-17 15:37:45.373883
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1j) == 1j
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'

# Generated at 2022-06-17 15:37:51.474653
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) is AnsibleUnsafeText(u'foo')
    assert wrap_var(u'foo') is AnsibleUnsafeText(u'foo')
    assert wrap_var(b'foo') is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(dict(foo=u'bar')) == dict(foo=AnsibleUnsafeText(u'bar'))
    assert wrap_var(dict(foo=b'bar')) == dict(foo=AnsibleUnsafeBytes(b'bar'))

# Generated at 2022-06-17 15:38:02.167228
# Unit test for function wrap_var
def test_wrap_var():
    import unittest
    import sys

    class TestWrapVar(unittest.TestCase):
        def test_wrap_var(self):
            self.assertEqual(wrap_var(None), None)
            self.assertEqual(wrap_var(1), 1)
            self.assertEqual(wrap_var(1.0), 1.0)
            self.assertEqual(wrap_var(True), True)
            self.assertEqual(wrap_var(False), False)
            self.assertEqual(wrap_var([]), [])
            self.assertEqual(wrap_var(()), ())
            self.assertEqual(wrap_var({}), {})
            self.assertEqual(wrap_var(set()), set())

# Generated at 2022-06-17 15:38:09.849310
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys

    # Test for None
    assert wrap_var(None) is None

    # Test for string
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'test'), AnsibleUnsafeText)

    # Test for bytes
    assert isinstance(wrap_var(b'test'), AnsibleUnsafeBytes)

    # Test for int
    assert wrap_var(1) == 1

    # Test for float
    assert wrap_var(1.0) == 1.0

    # Test for list
    assert isinstance(wrap_var([1, 2, 3]), list)

# Generated at 2022-06-17 15:38:23.633059
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Test for None
    assert wrap_var(None) is None

    # Test for string
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)

    # Test for bytes
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test for int
    assert wrap_var(1) == 1

    # Test for float
    assert wrap_var(1.0) == 1.0

    # Test for list
    assert isinstance(wrap_var(['foo', 'bar']), list)

# Generated at 2022-06-17 15:38:35.407015
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var([1, 2, 3]) == [1, 2, 3]
    assert wrap_var((1, 2, 3)) == (1, 2, 3)
    assert wrap_var({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

# Generated at 2022-06-17 15:38:47.067577
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six.moves import cPickle as pickle

    if PY3:
        from io import BytesIO
        from ansible.module_utils.six import binary_type
        from ansible.module_utils.six import text_type
    else:
        from cStringIO import StringIO as BytesIO
        from ansible.module_utils.six import binary_type
        from ansible.module_utils.six import text_type

    # Test that wrap_var works on a variety of types
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(1), int)

# Generated at 2022-06-17 15:38:57.656479
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var(u'\u2713') == AnsibleUnsafeText(u'\u2713')

# Generated at 2022-06-17 15:39:08.376943
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) is AnsibleUnsafeText(u'foo')

    assert wrap_var(b'foo') is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') is AnsibleUnsafeText(u'foo')

    assert wrap_var(dict(a=1, b=2)) == dict(a=1, b=2)
   

# Generated at 2022-06-17 15:39:16.126922
# Unit test for function wrap_var
def test_wrap_var():
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    # Test for None
    assert wrap_var(None) is None

    # Test for already wrapped
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes('foo')) == AnsibleUnsafeBytes('foo')

    # Test for strings
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')

    # Test for dict

# Generated at 2022-06-17 15:39:28.129135
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    # Test strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)

    # Test lists
    assert isinstance(wrap_var(['foo']), list)

# Generated at 2022-06-17 15:39:35.950522
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys

    # Test wrapping a string
    assert wrap_var('foo') == 'foo'
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)

    # Test wrapping a list
    assert wrap_var(['foo', 'bar']) == ['foo', 'bar']
    assert isinstance(wrap_var(['foo', 'bar'])[0], AnsibleUnsafeText)

    # Test wrapping a tuple
    assert wrap_var(('foo', 'bar')) == ('foo', 'bar')
    assert isinstance(wrap_var(('foo', 'bar'))[0], AnsibleUnsafeText)

    # Test wrapping a dict

# Generated at 2022-06-17 15:39:45.616454
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')
    assert wrap_var(u'foo'.encode('utf-8')) == b'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'

# Generated at 2022-06-17 15:39:53.013420
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import quote
    import datetime
    import decimal
    import fractions
    import uuid

    # Test strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test numbers
    assert isinstance(wrap_var(1), int)
    assert isinstance(wrap_var(1.0), float)
    assert isinstance(wrap_var(decimal.Decimal('1.0')), decimal.Decimal)

# Generated at 2022-06-17 15:40:08.815807
# Unit test for function wrap_var
def test_wrap_var():
    import json
    import sys
    import unittest


# Generated at 2022-06-17 15:40:17.014276
# Unit test for function wrap_var
def test_wrap_var():
    # Test for None
    assert wrap_var(None) is None

    # Test for string
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)

    # Test for bytes
    assert isinstance(wrap_var(b'test'), AnsibleUnsafeBytes)

    # Test for dict
    assert isinstance(wrap_var({'test': 'test'}), dict)
    assert isinstance(wrap_var({'test': 'test'})['test'], AnsibleUnsafeText)

    # Test for list
    assert isinstance(wrap_var(['test']), list)
    assert isinstance(wrap_var(['test'])[0], AnsibleUnsafeText)

    # Test for tuple
    assert isinstance(wrap_var(('test',)), tuple)

# Generated at 2022-06-17 15:40:24.966874
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test for None
    assert wrap_var(None) is None

    # Test for string
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    if PY3:
        assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test for dict
    assert isinstance(wrap_var({'foo': 'bar'}), dict)
    assert isinstance(wrap_var({'foo': 'bar'}).get('foo'), AnsibleUnsafeText)

# Generated at 2022-06-17 15:40:34.292396
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var('foo') == 'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(b'foo'.decode('utf-8')) == u'foo'
    assert wrap_var(b'foo'.decode('utf-8')) == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == b'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == b'foo'

# Generated at 2022-06-17 15:40:48.213025
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import range

    # Test for strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test for sequences
    assert isinstance(wrap_var(('foo',)), tuple)
    assert isinstance(wrap_var(['foo']), list)
    assert isinstance(wrap_var(set(['foo'])), set)
    assert isinstance(wrap_var(('foo',)), tuple)

# Generated at 2022-06-17 15:41:00.550662
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1j) == 1j
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'

# Generated at 2022-06-17 15:41:07.778096
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3

    # Test for None
    assert wrap_var(None) is None

    # Test for string
    assert wrap_var('foo') == 'foo'
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)

    # Test for unicode
    assert wrap_var(u'foo') == u'foo'
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)

    # Test for bytes
    assert wrap_var(b'foo') == b'foo'
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test for list
    assert wrap_var([1, 2, 3]) == [1, 2, 3]
    assert isinstance(wrap_var([1, 2, 3]), list)


# Generated at 2022-06-17 15:41:17.283277
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import quote_plus
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.parse import urlunparse
    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    from ansible.module_utils.six.moves.urllib.parse import urluns

# Generated at 2022-06-17 15:41:26.328179
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(set()) == set()
    assert wrap_var(frozenset()) == frozenset()
    assert wrap_var(()) == ()
    assert wrap_var([]) == []
    assert wrap_var({}) == {}
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'\u2713')

# Generated at 2022-06-17 15:41:35.780061
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    import sys

    # Test for dict
    assert wrap_var({'a': 'b'}) == {'a': 'b'}
    assert wrap_var({'a': 'b'}) == {'a': 'b'}
    assert wrap_var({'a': 'b'}) == {'a': 'b'}
    assert wrap_var({'a': 'b'}) == {'a': 'b'}
    assert wrap_var({'a': 'b'}) == {'a': 'b'}
    assert wrap_var({'a': 'b'}) == {'a': 'b'}
    assert wrap_var({'a': 'b'}) == {'a': 'b'}
    assert wrap_var({'a': 'b'})

# Generated at 2022-06-17 15:41:59.324674
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var('foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) == AnsibleUnsafeText(u'foo')

# Generated at 2022-06-17 15:42:08.116667
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Test wrap_var with a string
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'test'), AnsibleUnsafeText)

    # Test wrap_var with a list
    assert isinstance(wrap_var(['test']), list)
    assert isinstance(wrap_var(['test'])[0], AnsibleUnsafeText)

    # Test wrap_var with a tuple
    assert isinstance(wrap_var(('test',)), tuple)
    assert isinstance(wrap_var(('test',))[0], AnsibleUnsafeText)

    # Test wrap_var with a dict

# Generated at 2022-06-17 15:42:17.905715
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Test for None
    assert wrap_var(None) is None

    # Test for int
    assert wrap_var(1) == 1

    # Test for float
    assert wrap_var(1.0) == 1.0

    # Test for bool
    assert wrap_var(True) is True
    assert wrap_var(False) is False

    # Test for dict
    assert wrap_var({'a': 'b'}) == {'a': 'b'}

    # Test for list
    assert wrap_var(['a', 'b']) == ['a', 'b']

    # Test for tuple
    assert wrap_var(('a', 'b')) == ('a', 'b')

   

# Generated at 2022-06-17 15:42:24.970948
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3

    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(True), type(True))
    assert isinstance(wrap_var(False), type(False))
    assert isinstance(wrap_var(1), type(1))
    assert isinstance(wrap_var(1.0), type(1.0))
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'\u2713'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'\u2713'.encode('utf-8')), AnsibleUnsafeBytes)

# Generated at 2022-06-17 15:42:36.402782
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:42:43.873054
# Unit test for function wrap_var
def test_wrap_var():
    import unittest
    import sys

    class TestWrapVar(unittest.TestCase):
        def test_wrap_var(self):
            self.assertEqual(wrap_var(None), None)
            self.assertEqual(wrap_var(1), 1)
            self.assertEqual(wrap_var(1.1), 1.1)
            self.assertEqual(wrap_var(True), True)
            self.assertEqual(wrap_var(False), False)
            self.assertEqual(wrap_var([]), [])
            self.assertEqual(wrap_var(()), ())
            self.assertEqual(wrap_var({}), {})
            self.assertEqual(wrap_var(set()), set())


# Generated at 2022-06-17 15:42:57.809914
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:43:02.550690
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    import sys

    # Test for None
    assert wrap_var(None) is None

    # Test for strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)

    # Test for bytes
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test for lists
    assert isinstance(wrap_var(['foo']), list)
    assert isinstance(wrap_var(['foo'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var([u'foo']), list)
    assert isinstance(wrap_var([u'foo'])[0], AnsibleUnsafeText)

# Generated at 2022-06-17 15:43:12.901355
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:43:23.002594
# Unit test for function wrap_var
def test_wrap_var():
    import json
    import yaml
    from ansible.module_utils.six import PY3

    # Test string
    s = 'test'
    assert isinstance(wrap_var(s), AnsibleUnsafeText)
    assert wrap_var(s) == s

    # Test dict
    d = {'a': 'b'}
    assert isinstance(wrap_var(d), dict)
    assert wrap_var(d) == d
    assert isinstance(wrap_var(d)['a'], AnsibleUnsafeText)
    assert wrap_var(d)['a'] == d['a']

    # Test list
    l = ['a', 'b']
    assert isinstance(wrap_var(l), list)
    assert wrap_var(l) == l

# Generated at 2022-06-17 15:43:51.265997
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import quote

    # Test for string types
    assert isinstance(wrap_var('hello'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'hello'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'hello'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'hello'.decode('utf-8')), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'hello'.decode('utf-8').encode('utf-8')), AnsibleUnsafeBytes)

# Generated at 2022-06-17 15:43:56.282049
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import xrange

    # Test basic types
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(0) == 0
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1.1) == 1.1
    assert wrap_var(1.1 + 1.1j) == 1.1 + 1.1j

    # Test strings
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)

# Generated at 2022-06-17 15:44:03.684699
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    import sys

    if PY3:
        assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
        assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    else:
        assert isinstance(wrap_var('foo'), AnsibleUnsafeText)

    assert isinstance(wrap_var(['foo', 'bar']), list)
    assert isinstance(wrap_var(('foo', 'bar')), tuple)
    assert isinstance(wrap_var({'foo': 'bar'}), dict)

    assert isinstance(wrap_var(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes('foo')), AnsibleUnsafeBytes)

   

# Generated at 2022-06-17 15:44:11.680971
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1j) == 1j
    assert wrap_var(set()) == set()
    assert wrap_var(frozenset()) == frozenset()
    assert wrap_var(()) == ()
    assert wrap_var([]) == []
    assert wrap_var({}) == {}
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')
    assert wrap_var

# Generated at 2022-06-17 15:44:18.648750
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(['foo', 'bar']) == ['foo', 'bar']
    assert wrap_var(('foo', 'bar')) == ('foo', 'bar')
    assert wrap_var({'foo': 'bar'}) == {'foo': 'bar'}
    assert wrap_var(None) is None

# Generated at 2022-06-17 15:44:24.701182
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeText('foo')) is AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText('foo')) is not AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is not AnsibleUnsafeBytes(b'foo')

    assert wrap_var('foo') is not 'foo'

# Generated at 2022-06-17 15:44:34.735339
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.six.moves.urllib.parse import unquote
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.parse import urlunparse
    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    from ansible.module_utils.six.moves.urllib.parse import urlunsplit
   

# Generated at 2022-06-17 15:44:47.224120
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var("") == ""
    assert wrap_var("foo") == "foo"
    assert wrap_var(u"") == u""
    assert wrap_var(u"foo") == u"foo"
    assert wrap_var(b"") == b""
    assert wrap_var(b"foo") == b"foo"
    assert wrap_var(u"foo") == u"foo"
    assert wrap_var(b"foo") == b"foo"
    assert wrap_var(u"foo") == u"foo"

# Generated at 2022-06-17 15:44:56.661110
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1j) == 1j
    assert wrap_var(set()) == set()
    assert wrap_var(frozenset()) == frozenset()
    assert wrap_var(()) == ()
    assert wrap_var([]) == []
    assert wrap_var({}) == {}
    assert wrap_var(b'bytes') == AnsibleUnsafeBytes(b'bytes')
    assert wrap_var(u'unicode') == Ansible

# Generated at 2022-06-17 15:45:05.421069
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    # Test for None
    assert wrap_var(None) is None

    # Test for int
    assert wrap_var(1) == 1

    # Test for float
    assert wrap_var(1.0) == 1.0

    # Test for bool
    assert wrap_var(True) is True
    assert wrap_var(False) is False

    # Test for string
    assert isinstance(wrap_var('string'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'string'), AnsibleUnsafeText)

    # Test for bytes