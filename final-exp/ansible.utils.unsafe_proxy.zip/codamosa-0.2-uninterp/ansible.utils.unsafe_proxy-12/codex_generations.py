

# Generated at 2022-06-17 15:35:28.825256
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Test that wrap_var returns the same object
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1j) == 1j
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap

# Generated at 2022-06-17 15:35:37.697702
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')

    # Test for dict
    assert wrap_var({'foo': 'bar'}) == {'foo': AnsibleUnsafeText('bar')}
    assert wrap_var({'foo': b'bar'}) == {'foo': AnsibleUnsafeBytes(b'bar')}
    assert wrap_

# Generated at 2022-06-17 15:35:45.826595
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:35:53.550887
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'

# Generated at 2022-06-17 15:36:04.430422
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    import sys

    if PY3:
        # Python 3.x
        assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
        assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
        assert isinstance(wrap_var(b'foo'.decode('utf-8')), AnsibleUnsafeText)
        assert isinstance(wrap_var(u'foo'.encode('utf-8')), AnsibleUnsafeBytes)
    else:
        # Python 2.x
        assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
        assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)

# Generated at 2022-06-17 15:36:15.230113
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip

    # Test strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes('foo')), AnsibleUnsafeBytes)

    # Test bytes
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)
    assert isinstance

# Generated at 2022-06-17 15:36:24.413490
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'\u2713') == u'\u2713'
    assert wrap_var(u'\u2713'.encode('utf-8')) == u'\u2713'.encode('utf-8')

# Generated at 2022-06-17 15:36:34.991274
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(set()) == set()
    assert wrap_var(frozenset()) == frozenset()
    assert wrap_var(()) == ()
    assert wrap_var([]) == []
    assert wrap_var({}) == {}
    assert wrap_var(dict()) == {}
    assert wrap_var(set()) == set()
    assert wrap_var(frozenset()) == frozenset()

# Generated at 2022-06-17 15:36:48.415681
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText('foo')) is AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')

    # Test for string
    assert wrap_var('foo') is AnsibleUnsafeText('foo')
    assert wrap_var(u'foo') is AnsibleUnsafeText('foo')
    assert wrap_var(b'foo') is AnsibleUnsafeBytes(b'foo')

    # Test for Mapping

# Generated at 2022-06-17 15:36:57.532989
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes('foo')) == AnsibleUnsafeBytes('foo')
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var(NativeJinjaText('foo')) == NativeJinjaUnsafeText('foo')
    assert wrap_var(NativeJinjaText(u'foo')) == NativeJinjaUnsafeText(u'foo')