

# Generated at 2022-06-17 15:35:28.858750
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_str
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-17 15:35:34.476155
# Unit test for function wrap_var
def test_wrap_var():
    import pytest

    class TestClass(object):
        pass


# Generated at 2022-06-17 15:35:44.171453
# Unit test for function wrap_var
def test_wrap_var():
    import pytest

    # Test for None
    assert wrap_var(None) is None

    # Test for string
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'test'), AnsibleUnsafeText)

    # Test for list
    assert isinstance(wrap_var(['test']), list)
    assert isinstance(wrap_var(['test'])[0], AnsibleUnsafeText)

    # Test for tuple
    assert isinstance(wrap_var(('test',)), tuple)
    assert isinstance(wrap_var(('test',))[0], AnsibleUnsafeText)

    # Test for dict
    assert isinstance(wrap_var({'test': 'test'}), dict)

# Generated at 2022-06-17 15:35:52.401717
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy(None), AnsibleUnsafe)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText('test')), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes('test')), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(NativeJinjaText('test')), NativeJinjaUnsafeText)
    assert isinstance(UnsafeProxy(u'test'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy('test'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'test'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(dict(a=1)), dict)
    assert isinstance(UnsafeProxy(dict(a=1).values()), list)

# Generated at 2022-06-17 15:36:03.453518
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    # Test strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'\u2713'), AnsibleUnsafeText)

    # Test lists
    assert isinstance(wrap_var(['foo']), list)
    assert isinstance(wrap_var(['foo'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var([b'foo']), list)

# Generated at 2022-06-17 15:36:14.947821
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import b
    from ansible.module_utils.six import u

    if PY3:
        assert isinstance(UnsafeProxy(u('foo')), AnsibleUnsafeText)
        assert isinstance(UnsafeProxy(b('foo')), AnsibleUnsafeBytes)
    else:
        assert isinstance(UnsafeProxy(u('foo')), AnsibleUnsafeText)
        assert isinstance(UnsafeProxy(b('foo')), AnsibleUnsafeText)

    assert isinstance(UnsafeProxy(u('foo')), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b('foo')), AnsibleUnsafeText)

    assert isinstance

# Generated at 2022-06-17 15:36:24.288274
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy(None), AnsibleUnsafe)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText(u'foo')), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(u'foo'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(NativeJinjaText(u'foo')), NativeJinjaUnsafeText)
    assert isinstance(UnsafeProxy(dict(foo=u'bar')), dict)
    assert isinstance(UnsafeProxy(dict(foo=b'bar')), dict)

# Generated at 2022-06-17 15:36:34.895738
# Unit test for function wrap_var
def test_wrap_var():
    import json
    import sys

    if sys.version_info[0] == 3:
        unicode = str

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'


# Generated at 2022-06-17 15:36:48.387253
# Unit test for function wrap_var
def test_wrap_var():
    # Test for None
    assert wrap_var(None) is None

    # Test for string
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test for dict
    d = {'foo': 'bar'}
    assert isinstance(wrap_var(d), dict)
    assert isinstance(wrap_var(d)['foo'], AnsibleUnsafeText)

    # Test for list
    l = ['foo', 'bar']
    assert isinstance(wrap_var(l), list)
    assert isinstance(wrap_var(l)[0], AnsibleUnsafeText)

    # Test for tuple

# Generated at 2022-06-17 15:36:58.951079
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys

    # Test for None
    assert wrap_var(None) is None

    # Test for unsafe
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) is AnsibleUnsafeText(u'foo')

    # Test for bytes
    assert wrap_var(b'foo') is AnsibleUnsafeBytes(b'foo')

    # Test for text
    assert wrap_var(u'foo') is AnsibleUnsafeText(u'foo')

    # Test for dict