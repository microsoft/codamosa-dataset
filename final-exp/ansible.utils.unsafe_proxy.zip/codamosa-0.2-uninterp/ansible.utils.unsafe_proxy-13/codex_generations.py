

# Generated at 2022-06-17 15:35:22.115511
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    display = Display()
    display.deprecated('wrap_var is deprecated', version='2.13', collection_name='ansible.builtin')

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'

# Generated at 2022-06-17 15:35:31.868629
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    # Test for wrap_var
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')

# Generated at 2022-06-17 15:35:42.905507
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(0) == 0
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1.1) == 1.1
    assert wrap_var(1.1 + 1.1j) == 1.1 + 1.1j
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'

# Generated at 2022-06-17 15:35:50.459636
# Unit test for function wrap_var
def test_wrap_var():
    import sys
    import unittest

    class TestWrapVar(unittest.TestCase):
        def test_wrap_var(self):
            self.assertEqual(wrap_var(None), None)
            self.assertEqual(wrap_var(1), 1)
            self.assertEqual(wrap_var(1.0), 1.0)
            self.assertEqual(wrap_var(True), True)
            self.assertEqual(wrap_var(False), False)
            self.assertEqual(wrap_var([]), [])
            self.assertEqual(wrap_var(()), ())
            self.assertEqual(wrap_var({}), {})
            self.assertEqual(wrap_var(set()), set())

# Generated at 2022-06-17 15:35:56.588943
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')
    assert wrap_var(u'foo'.encode('utf-8')) == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var

# Generated at 2022-06-17 15:36:06.417623
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.1) == 1.1
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:36:16.300817
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var("") == AnsibleUnsafeText("")
    assert wrap_var(b"") == AnsibleUnsafeBytes(b"")
    assert wrap_var(u"") == AnsibleUnsafeText(u"")
    assert wrap_var(u"\u00e9") == AnsibleUnsafeText(u"\u00e9")
    assert wrap_var(u"\u00e9".encode('utf-8')) == AnsibleUnsafeText(u"\u00e9")

# Generated at 2022-06-17 15:36:25.059289
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')

    # Test for string
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText('foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')

    # Test for list
    assert wrap_var(['foo', 'bar'])

# Generated at 2022-06-17 15:36:35.480458
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:36:45.122586
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:36:58.376043
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b

# Generated at 2022-06-17 15:37:05.083309
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'bytes') == AnsibleUnsafeBytes(b'bytes')
    assert wrap_var(u'unicode') == AnsibleUnsafeText(u'unicode')
    assert wrap_var(u'unicode'.encode('utf-8')) == AnsibleUnsafeBytes(u'unicode'.encode('utf-8'))

# Generated at 2022-06-17 15:37:15.418758
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1j) == 1j
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'

# Generated at 2022-06-17 15:37:24.312593
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')

    # Test for string
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText('foo')

    # Test for bytes
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')

    # Test for dict

# Generated at 2022-06-17 15:37:31.720742
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    # Test wrapping of a dictionary
    d = {'a': 1, 'b': 2}
    d_wrapped = wrap_var(d)
    assert isinstance(d_wrapped, dict)
    assert isinstance(d_wrapped['a'], AnsibleUnsafe)
    assert isinstance(d_wrapped['b'], AnsibleUnsafe)

    # Test wrapping of a list
    l = [1, 2, 3]
    l_wrapped = wrap_var(l)
    assert isinstance(l_wrapped, list)
    assert isinstance(l_wrapped[0], AnsibleUnsafe)
    assert isinstance(l_wrapped[1], AnsibleUnsafe)


# Generated at 2022-06-17 15:37:38.927171
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.six.moves.urllib.request import urlopen
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.six.moves.urllib.parse import unquote
    from ansible.module_utils.six.moves.urllib.parse import urlsplit

# Generated at 2022-06-17 15:37:49.416847
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range
    import sys

    if PY3:
        assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
        assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    else:
        assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
        assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)

    assert isinstance(wrap_var(dict(foo=u'bar')), dict)
    assert isinstance(wrap_var(dict(foo=u'bar').items()), list)
    assert isinstance(wrap_var(dict(foo=u'bar').values()), list)

# Generated at 2022-06-17 15:37:56.874197
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    if PY3:
        builtins_str = str
    else:
        builtins_str = basestring

    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(True), type(True))
    assert isinstance(wrap_var(False), type(False))
    assert isinstance(wrap_var(1), type(1))
    assert isinstance(wrap_var(1.0), type(1.0))
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)

# Generated at 2022-06-17 15:38:07.023284
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    # Test strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'.encode('utf-8')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'.encode('utf-16')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'.encode('utf-32')), AnsibleUnsafeBytes)

    # Test lists

# Generated at 2022-06-17 15:38:16.118444
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import collections
    import datetime
    import decimal
    import fractions
    import re
    import uuid

    # Test for basic types
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(0) == 0
    assert wrap_var(1) == 1
    assert wrap_var(0.0) == 0.0
    assert wrap_var(1.0) == 1.0
    assert wrap_var(0j) == 0j
    assert wrap_var(1j) == 1j
    assert wrap_var('') == ''
    assert wrap_var('foo') == 'foo'

# Generated at 2022-06-17 15:38:27.334779
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var('foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'\u20ac') == u'\u20ac'
    assert wrap_var(b'\xe2\x82\xac') == b'\xe2\x82\xac'
    assert wrap_var(u'\u20ac'.encode('utf-8')) == b'\xe2\x82\xac'
    assert wrap_var

# Generated at 2022-06-17 15:38:38.223579
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.collections import is_sequence

    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(NativeJinjaText('foo')) == NativeJinjaUnsafeText('foo')

# Generated at 2022-06-17 15:38:48.083278
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes('foo')) == AnsibleUnsafeBytes('foo')
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(NativeJinjaText('foo')) == NativeJinjaUnsafeText('foo')
    assert wrap_var(['foo', 'bar']) == [AnsibleUnsafeText('foo'), AnsibleUnsafeText('bar')]
    assert wrap_var(('foo', 'bar')) == (AnsibleUnsafeText('foo'), AnsibleUnsafeText('bar'))
   

# Generated at 2022-06-17 15:38:58.732461
# Unit test for function wrap_var
def test_wrap_var():
    import ansible.module_utils.common.collections as collections
    import ansible.module_utils.six as six

    assert wrap_var(None) is None
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'

# Generated at 2022-06-17 15:39:09.563366
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import collections
    import datetime
    import decimal
    import fractions
    import json
    import numbers
    import random
    import re
    import uuid

    # Wrap a string
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Wrap a number
    assert isinstance(wrap_var(1), numbers.Number)
    assert isinstance(wrap_var(1.0), numbers.Number)
    assert isinstance(wrap_var(decimal.Decimal(1)), decimal.Decimal)

# Generated at 2022-06-17 15:39:14.588918
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')

    # Test for string
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText('foo')
    if PY3:
        assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    else:
        assert wrap_

# Generated at 2022-06-17 15:39:23.700390
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    import sys
    import types

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText('foo')) is not None
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is not None

    # Test for string
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test for dict
    assert isinstance(wrap_var({'foo': 'bar'}), dict)
    assert isinstance(wrap_var({'foo': 'bar'}).get('foo'), AnsibleUnsafeText)

# Generated at 2022-06-17 15:39:28.288034
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')

    # Test for dict
    assert wrap_var({'foo': 'bar'}) == {'foo': AnsibleUnsafeText('bar')}
    assert wrap_var({'foo': b'bar'}) == {'foo': AnsibleUnsafeBytes(b'bar')}
    assert wrap_

# Generated at 2022-06-17 15:39:36.057012
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:39:45.724398
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    # Test strings
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test lists
    assert isinstance(wrap_var([u'foo']), list)
    assert isinstance(wrap_var([b'foo']), list)
    assert isinstance(wrap_var([u'foo'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var([b'foo'])[0], AnsibleUnsafeBytes)

    # Test tuples