

# Generated at 2022-06-17 15:35:28.791481
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    # Test strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test lists
    assert isinstance(wrap_var(['foo', 'bar']), list)
    assert isinstance(wrap_var(['foo', 'bar'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var(['foo', 'bar'])[1], AnsibleUnsafeText)

# Generated at 2022-06-17 15:35:37.698591
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    # Test for string types
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)

    # Test for dict
    assert isinstance(wrap_var({'foo': 'bar'}), dict)

# Generated at 2022-06-17 15:35:48.909548
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'\u2713') == u'\u2713'
    assert wrap_var(u'\u2713'.encode('utf-8')) == u'\u2713'.encode('utf-8')
    assert wrap_var(u'\u2713'.encode('utf-8')) == b'\xe2\x9c\x93'

# Generated at 2022-06-17 15:35:55.634691
# Unit test for function wrap_var
def test_wrap_var():
    import json
    import datetime
    import decimal
    import collections

    # Test for None
    assert wrap_var(None) is None

    # Test for strings
    assert wrap_var('foo') == 'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'

    # Test for numbers
    assert wrap_var(1) == 1
    assert wrap_var(1.1) == 1.1
    assert wrap_var(decimal.Decimal('1.1')) == decimal.Decimal('1.1')

    # Test for lists
    assert wrap_var([1, 2, 3]) == [1, 2, 3]
    assert wrap_var([1, 2, [3, 4]]) == [1, 2, [3, 4]]

# Generated at 2022-06-17 15:36:05.856627
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:36:16.064630
# Unit test for function wrap_var
def test_wrap_var():
    import sys
    import unittest

    class TestWrapVar(unittest.TestCase):
        def test_wrap_var_none(self):
            self.assertIsNone(wrap_var(None))

        def test_wrap_var_dict(self):
            self.assertIsInstance(wrap_var({'foo': 'bar'}), dict)

        def test_wrap_var_list(self):
            self.assertIsInstance(wrap_var(['foo', 'bar']), list)

        def test_wrap_var_tuple(self):
            self.assertIsInstance(wrap_var(('foo', 'bar')), tuple)

        def test_wrap_var_set(self):
            self.assertIsInstance(wrap_var(set(['foo', 'bar'])), set)


# Generated at 2022-06-17 15:36:24.955763
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.collections import is_sequence

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.1) == 1.1
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'

# Generated at 2022-06-17 15:36:35.438860
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes('foo')) == AnsibleUnsafeBytes('foo')
    assert wrap_var(NativeJinjaText('foo')) == NativeJinjaUnsafeText('foo')
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var(['foo']) == [AnsibleUnsafeText('foo')]
    assert wrap_var(('foo',)) == (AnsibleUnsafeText('foo'),)
   

# Generated at 2022-06-17 15:36:48.559382
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    # Test for None
    assert wrap_var(None) is None

    # Test for already wrapped
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) is AnsibleUnsafeText(u'foo')

    # Test for bytes
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert wrap_var(b'foo') == b'foo'

    # Test for text
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert wrap_var(u'foo') == u'foo'



# Generated at 2022-06-17 15:36:59.028947
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys

    # Test for None
    assert wrap_var(None) is None

    # Test for string
    assert wrap_var('test') == 'test'
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)

    # Test for bytes
    assert wrap_var(b'test') == b'test'
    assert isinstance(wrap_var(b'test'), AnsibleUnsafeBytes)

    # Test for list
    assert wrap_var([1, 2, 3]) == [1, 2, 3]
    assert isinstance(wrap_var([1, 2, 3]), list)

    # Test for tuple