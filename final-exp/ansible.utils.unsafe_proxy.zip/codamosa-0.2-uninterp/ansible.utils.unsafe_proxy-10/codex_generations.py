

# Generated at 2022-06-17 15:35:27.574608
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1j) == 1j
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'

# Generated at 2022-06-17 15:35:37.273973
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.1) == 1.1
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')
    assert wrap_var(u'foo'.encode('utf-8')) == b'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == AnsibleUnsafeBytes(b'foo')

# Generated at 2022-06-17 15:35:45.565732
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) is AnsibleUnsafeText(u'foo')

    # Test for dict
    assert wrap_var({}) == {}
    assert wrap_var({'foo': 'bar'}) == {'foo': 'bar'}

# Generated at 2022-06-17 15:35:53.344345
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    # Test for None
    assert wrap_var(None) is None

    # Test for string
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)

    # Test for list

# Generated at 2022-06-17 15:36:04.311024
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(42) == 42
    assert wrap_var(42.0) == 42.0
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:36:15.071751
# Unit test for function wrap_var
def test_wrap_var():
    import pytest
    from ansible.module_utils.six import PY3

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText(u'foo')) == AnsibleUnsafeText(u'foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')

    # Test for dict
    assert wrap_var({'foo': 'bar'}) == {'foo': 'bar'}
    assert wrap_var({'foo': AnsibleUnsafeText(u'bar')}) == {'foo': AnsibleUnsafeText(u'bar')}

# Generated at 2022-06-17 15:36:24.352284
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'.encode('utf-8')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'.encode('utf-8').decode('utf-8')), AnsibleUnsafeText)

# Generated at 2022-06-17 15:36:34.945052
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:36:44.989962
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeText('foo')) is AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes('foo')) is AnsibleUnsafeBytes('foo')
    assert wrap_var(AnsibleUnsafeText('foo')) is not AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes('foo')) is not AnsibleUnsafeBytes('foo')
    assert wrap_var(NativeJinjaText('foo')) is NativeJinjaUnsafeText('foo')
    assert wrap_var(NativeJinjaText('foo')) is not NativeJinjaUnsafe

# Generated at 2022-06-17 15:36:57.772961
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys

    # Test for None
    assert wrap_var(None) is None

    # Test for string
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)

    # Test for bytes
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test for int
    assert wrap_var(1) == 1

    # Test for float
    assert wrap_var(1.1) == 1.1

    # Test for list
    assert isinstance(wrap_var(['foo', 'bar']), list)
    assert isinstance(wrap_var(['foo', 'bar'])[0], AnsibleUnsafeText)