

# Generated at 2022-06-17 15:35:21.836197
# Unit test for function wrap_var
def test_wrap_var():
    import json
    import sys
    import unittest

    class TestWrapVar(unittest.TestCase):
        def test_wrap_var_dict(self):
            d = {'a': 'b', 'c': 'd'}
            wrapped_d = wrap_var(d)
            self.assertIsInstance(wrapped_d, dict)
            self.assertIsInstance(wrapped_d['a'], AnsibleUnsafeText)
            self.assertIsInstance(wrapped_d['c'], AnsibleUnsafeText)

        def test_wrap_var_list(self):
            l = ['a', 'b', 'c']
            wrapped_l = wrap_var(l)
            self.assertIsInstance(wrapped_l, list)

# Generated at 2022-06-17 15:35:31.733174
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'.encode('utf-8')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'.encode('utf-8').decode('utf-8')), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'.encode('utf-8').decode('utf-8').encode('utf-8')), AnsibleUnsafeBytes)

# Generated at 2022-06-17 15:35:42.865354
# Unit test for function wrap_var
def test_wrap_var():
    import sys
    import unittest

    class TestWrapVar(unittest.TestCase):
        def test_wrap_var_none(self):
            self.assertIsNone(wrap_var(None))

        def test_wrap_var_string(self):
            self.assertIsInstance(wrap_var('foo'), AnsibleUnsafeText)

        def test_wrap_var_unicode(self):
            self.assertIsInstance(wrap_var(u'foo'), AnsibleUnsafeText)

        def test_wrap_var_dict(self):
            self.assertIsInstance(wrap_var({'foo': 'bar'}), dict)

        def test_wrap_var_list(self):
            self.assertIsInstance(wrap_var(['foo', 'bar']), list)


# Generated at 2022-06-17 15:35:50.440055
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.parse import parse_qs
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.six.moves.urllib.parse import unquote
    from ansible.module_utils.six.moves.urllib.parse import quote_plus
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus

# Generated at 2022-06-17 15:36:02.042193
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(set()) == set()
    assert wrap_var(frozenset()) == frozenset()
    assert wrap_var(()) == ()
    assert wrap_var([]) == []
    assert wrap_var({}) == {}
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'

# Generated at 2022-06-17 15:36:12.370476
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(set([1, 2, 3])) == set([1, 2, 3])
    assert wrap_var(tuple([1, 2, 3])) == tuple([1, 2, 3])
    assert wrap_var(list([1, 2, 3])) == list([1, 2, 3])
    assert wrap_var(dict(a=1, b=2, c=3)) == dict(a=1, b=2, c=3)
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b

# Generated at 2022-06-17 15:36:23.742805
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:36:34.568302
# Unit test for function wrap_var
def test_wrap_var():
    import sys
    import json
    import collections
    from ansible.module_utils.six import PY3

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) is AnsibleUnsafeText(u'foo')

    # Test for string
    assert wrap_var(u'foo') is AnsibleUnsafeText(u'foo')
    assert wrap_var(b'foo') is AnsibleUnsafeBytes(b'foo')

    # Test for dict

# Generated at 2022-06-17 15:36:48.235404
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'\u2713') == u'\u2713'
    assert wrap_var(u'\u2713'.encode('utf-8')) == u'\u2713'.encode('utf-8')
    assert wrap_var(u'\u2713'.encode('utf-8')) == u'\u2713'.encode('utf-8')

# Generated at 2022-06-17 15:36:58.829375
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.1) == 1.1
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var(u'\u2713') == AnsibleUnsafeText(u'\u2713')

# Generated at 2022-06-17 15:37:05.382466
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_sequence
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(True), type(True))
    assert isinstance(wrap_var(False), type(False))
    assert isinstance(wrap_var(1), type(1))
    assert isinstance(wrap_var(1.0), type(1.0))
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'.encode('utf-8')), AnsibleUnsafeBytes)

# Generated at 2022-06-17 15:37:09.540242
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys

    # Test that we can wrap a string
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)

    # Test that we can wrap a unicode string
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)

    # Test that we can wrap a list
    assert isinstance(wrap_var(['foo', 'bar']), list)
    assert isinstance(wrap_var(['foo', 'bar'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var(['foo', 'bar'])[1], AnsibleUnsafeText)

    # Test that we can wrap a tuple

# Generated at 2022-06-17 15:37:18.050821
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.collections import is_sequence

    # Test for None
    assert wrap_var(None) is None

    # Test for string
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    if PY3:
        assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test for list
    assert isinstance(wrap_var(['foo']), list)
    assert isinstance(wrap_var(['foo'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var([u'foo']), list)

# Generated at 2022-06-17 15:37:26.000640
# Unit test for function wrap_var
def test_wrap_var():
    import pytest
    from ansible.module_utils.six import PY3

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')

    # Test for string_types
    assert wrap_var('foo') == AnsibleUnsafeText('foo')

    # Test for Mapping
    assert wrap_var({'foo': 'bar'}) == {AnsibleUnsafeText('foo'): AnsibleUnsafeText('bar')}

    # Test for Set
    assert wrap_var(set(['foo', 'bar'])) == {AnsibleUnsafeText('foo'), AnsibleUnsafeText('bar')}

    # Test for sequence

# Generated at 2022-06-17 15:37:34.901156
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:37:41.284874
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3

    # Test strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test lists
    assert isinstance(wrap_var(['foo']), list)
    assert isinstance(wrap_var(['foo'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var([u'foo']), list)
    assert isinstance(wrap_var([u'foo'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var([b'foo']), list)

# Generated at 2022-06-17 15:37:47.862567
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.collections import is_sequence

    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) is AnsibleUnsafeText(u'foo')
    assert wrap_var(NativeJinjaUnsafeText(u'foo')) is NativeJinjaUnsafeText(u'foo')
    assert wrap_var(b'foo') is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') is AnsibleUnsafeText(u'foo')

# Generated at 2022-06-17 15:37:56.028771
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:38:07.609775
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')

# Generated at 2022-06-17 15:38:16.347526
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1j) == 1j
    assert wrap_var(set()) == set()
    assert wrap_var(frozenset()) == frozenset()
    assert wrap_var(()) == ()
    assert wrap_var([]) == []
    assert wrap_var({}) == {}
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_

# Generated at 2022-06-17 15:38:27.421474
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:38:38.223023
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(dict(a=1, b=2)) == dict(a=1, b=2)
    assert wrap_var(dict(a=1, b=2, c=dict(d=3, e=4))) == dict(a=1, b=2, c=dict(d=3, e=4))
    assert wrap_var(set([1, 2, 3])) == set([1, 2, 3])

# Generated at 2022-06-17 15:38:48.563905
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var('foo') == 'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'\u2713') == u'\u2713'
    assert wrap_var(u'\u2713'.encode('utf-8')) == u'\u2713'.encode('utf-8')
    assert wrap_var(u'\u2713'.encode('utf-8')).decode('utf-8') == u'\u2713'

# Generated at 2022-06-17 15:38:59.035086
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    # Test for dict
    d = {'a': 1, 'b': 2}
    d_wrapped = wrap_var(d)
    assert isinstance(d_wrapped, dict)
    assert isinstance(d_wrapped['a'], AnsibleUnsafe)
    assert isinstance(d_wrapped['b'], AnsibleUnsafe)

    # Test for list
    l = [1, 2, 3]
    l_wrapped = wrap_var(l)
    assert isinstance(l_wrapped, list)
    assert isinstance(l_wrapped[0], AnsibleUnsafe)
    assert isinstance(l_wrapped[1], AnsibleUnsafe)
    assert isinstance

# Generated at 2022-06-17 15:39:09.847059
# Unit test for function wrap_var
def test_wrap_var():
    import pytest
    from ansible.module_utils.six import PY3

    # Test with None
    assert wrap_var(None) is None

    # Test with AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')

    # Test with string
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText('foo')
    if PY3:
        assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')

    # Test with dict
    assert wrap_var({'foo': 'bar'}) == {AnsibleUnsafeText('foo'): AnsibleUnsafeText('bar')}

# Generated at 2022-06-17 15:39:14.975945
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var('a') == 'a'
    assert wrap_var(u'a') == u'a'
    assert wrap_var(b'a') == b'a'
    assert wrap_var(u'a'.encode('utf-8')) == u'a'.encode('utf-8')
    assert wrap_var(u'a'.encode('utf-8')) == u'a'.encode('utf-8')
    assert wrap_var(u'a'.encode('utf-8')).__class__ == AnsibleUnsafeBytes
    assert wrap_var

# Generated at 2022-06-17 15:39:28.034080
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.collections import is_sequence

    assert wrap_var(None) is None
    assert wrap_var('') == ''
    assert wrap_var('foo') == 'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap

# Generated at 2022-06-17 15:39:35.894751
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.collections import is_sequence

    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) == AnsibleUnsafeText(u'foo')

    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)

    assert isinstance(wrap_var(dict(foo=b'bar')), dict)
    assert isinstance(wrap_var(dict(foo=u'bar')), dict)

# Generated at 2022-06-17 15:39:49.643390
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3

    # Test for string
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'test'), AnsibleUnsafeBytes)

    # Test for list
    assert isinstance(wrap_var(['test']), list)
    assert isinstance(wrap_var(['test'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var([u'test']), list)
    assert isinstance(wrap_var([u'test'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var([b'test']), list)

# Generated at 2022-06-17 15:39:59.789818
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    import sys

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')

    # Test for string
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')

    # Test for dict
    assert wrap_var({'foo': 'bar'}) == {AnsibleUnsafeText('foo'): AnsibleUnsafeText('bar')}

# Generated at 2022-06-17 15:40:12.999438
# Unit test for function wrap_var
def test_wrap_var():
    import pytest
    from ansible.module_utils.six import PY3

    # Test for None
    assert wrap_var(None) is None

    # Test for string
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test for dict
    assert isinstance(wrap_var({u'foo': u'bar'}), dict)
    assert isinstance(wrap_var({u'foo': u'bar'})[u'foo'], AnsibleUnsafeText)
    assert isinstance(wrap_var({b'foo': b'bar'}), dict)
    assert isinstance(wrap_var({b'foo': b'bar'})[b'foo'], AnsibleUnsafeBytes)

    # Test for

# Generated at 2022-06-17 15:40:18.973645
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins
    import datetime
    import decimal
    import uuid

    # Test basic types
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1j) == 1j
    assert wrap_var(datetime.datetime.now()) == datetime.datetime.now()
    assert wrap_var(decimal.Decimal('1.0')) == decimal.Decimal('1.0')
    assert wrap_var(uuid.uuid4()) == uuid.uuid4()

   

# Generated at 2022-06-17 15:40:30.314381
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'\u2713') == u'\u2713'
    assert wrap_var(u'\u2713'.encode('utf-8')) == u'\u2713'.encode('utf-8')

# Generated at 2022-06-17 15:40:38.653951
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    # Test for string
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)

    # Test for unicode
    assert isinstance(wrap_var(u'test'), AnsibleUnsafeText)

    # Test for bytes
    if PY3:
        assert isinstance(wrap_var(b'test'), AnsibleUnsafeBytes)
    else:
        assert isinstance(wrap_var(b'test'), AnsibleUnsafeText)

    # Test for list
    assert isinstance(wrap_var(['test']), list)
    assert isinstance(wrap_var(['test'])[0], AnsibleUnsafeText)

    # Test for tuple

# Generated at 2022-06-17 15:40:50.095164
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) == AnsibleUnsafeText(u'foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var(42) == 42
    assert wrap_var(42.0) == 42.0
    assert wrap_var(dict(a=1, b=2)) == dict(a=1, b=2)
    assert wrap_var(dict(a=1, b=2, c=AnsibleUnsafeText(u'foo')))

# Generated at 2022-06-17 15:41:01.854832
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    # Test strings
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'.encode('utf-8')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'foo'.decode('utf-8')), AnsibleUnsafeText)

    # Test lists
    assert isinstance(wrap_var([u'foo']), list)
    assert isinstance(wrap_var([u'foo'])[0], AnsibleUnsafeText)
    assert isinstance

# Generated at 2022-06-17 15:41:10.750138
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) is AnsibleUnsafeText(u'foo')
    assert wrap_var(b'foo') is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') is AnsibleUnsafeText(u'foo')
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(dict(foo=b'bar')) == dict(foo=AnsibleUnsafeBytes(b'bar'))
    assert wrap

# Generated at 2022-06-17 15:41:15.299897
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    import sys

    if PY3:
        assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
        assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    else:
        assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
        assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)

    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(1), int)
    assert isinstance(wrap_var(1.0), float)
    assert isinstance(wrap_var(1j), complex)
    assert isinstance(wrap_var(set()), set)

# Generated at 2022-06-17 15:41:25.172091
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'bytes') == b'bytes'
    assert wrap_var(u'unicode') == u'unicode'
    assert wrap_var(u'unicode'.encode('utf-8')) == u'unicode'.encode('utf-8')
    assert wrap_var(u'unicode'.encode('utf-8')) == u'unicode'.encode('utf-8')
    assert wrap_var(u'unicode'.encode('utf-8')) == u'unicode'.encode('utf-8')

# Generated at 2022-06-17 15:41:34.834589
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    import sys

    # Test a simple string
    assert wrap_var('foo') == 'foo'
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)

    # Test a simple string with a unicode character
    assert wrap_var(u'foo\u2713') == u'foo\u2713'
    assert isinstance(wrap_var(u'foo\u2713'), AnsibleUnsafeText)

    # Test a simple string with a unicode character
    assert wrap_var(u'foo\u2713') == u'foo\u2713'
    assert isinstance

# Generated at 2022-06-17 15:41:51.889935
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    # Test strings
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test dict
    d = {u'foo': u'bar', b'foo': b'bar'}
    if PY3:
        assert isinstance(wrap_var(d), dict)
    else:
        assert isinstance(wrap_var(d), AnsibleUnsafeText)
    assert isinstance(wrap_var(d)[u'foo'], AnsibleUnsafeText)
    assert isinstance(wrap_var(d)[b'foo'], AnsibleUnsafeBytes)

    # Test list
    l

# Generated at 2022-06-17 15:42:01.160248
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')

# Generated at 2022-06-17 15:42:09.122620
# Unit test for function wrap_var
def test_wrap_var():
    import ansible.module_utils.basic
    import ansible.module_utils.common.collections
    import ansible.module_utils.six
    import ansible.module_utils.urls
    import ansible.module_utils.json_utils
    import ansible.module_utils.json_utils
    import ansible.module_utils.json_utils
    import ansible.module_utils.json_utils
    import ansible.module_utils.json_utils
    import ansible.module_utils.json_utils
    import ansible.module_utils.json_utils
    import ansible.module_utils.json_utils
    import ansible.module_utils.json_utils
    import ansible.module_utils.json_utils
    import ansible.module_utils.json_utils
    import ansible.module_utils

# Generated at 2022-06-17 15:42:18.546526
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.collections import is_sequence

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1j) == 1j
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'

# Generated at 2022-06-17 15:42:25.246301
# Unit test for function wrap_var
def test_wrap_var():
    import json
    import sys

    if sys.version_info[0] < 3:
        from ansible.module_utils.six import u
        from ansible.module_utils.six.moves import builtins

        builtins.unicode = unicode
        builtins.basestring = basestring
        builtins.long = long

    # Test strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u('foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test lists
    assert isinstance(wrap_var(['foo']), list)
    assert isinstance(wrap_var(['foo'])[0], AnsibleUnsafeText)

# Generated at 2022-06-17 15:42:30.892248
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) == AnsibleUnsafeText(u'foo')

# Generated at 2022-06-17 15:42:40.410653
# Unit test for function wrap_var
def test_wrap_var():
    import json
    import sys

    if sys.version_info[0] == 2:
        from ansible.module_utils.six import PY3
        if PY3:
            from ansible.module_utils.six.moves import builtins
            unicode = builtins.unicode
        else:
            unicode = builtins.unicode

    # Test wrap_var with None
    assert wrap_var(None) is None

    # Test wrap_var with a string
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)

    # Test wrap_var with a unicode string
    assert isinstance(wrap_var(unicode('test')), AnsibleUnsafeText)

    # Test wrap_var with a list
    assert isinstance(wrap_var(['test']), list)

# Generated at 2022-06-17 15:42:44.559896
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'\u20ac') == u'\u20ac'
    assert wrap_var(u'\u20ac'.encode('utf-8')) == u'\u20ac'.encode('utf-8')
    assert wrap_var(u'\u20ac'.encode('utf-8')) == b'\xe2\x82\xac'

# Generated at 2022-06-17 15:42:57.937810
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeBytes('foo')) == AnsibleUnsafeBytes('foo')
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(NativeJinjaText('foo')) == NativeJinjaUnsafeText('foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(['foo', 'bar']) == ['foo', 'bar']
    assert wrap_var(['foo', 'bar']) == ['foo', 'bar']
    assert wrap_var(('foo', 'bar')) == ('foo', 'bar')

# Generated at 2022-06-17 15:43:02.650123
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys
    import types

    # Test that we can wrap a string
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)

    # Test that we can wrap a unicode string
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)

    # Test that we can wrap a byte string
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test that we can wrap a tuple
    assert isinstance(wrap_var(('foo',)), tuple)
    assert isinstance(wrap_var(('foo',))[0], AnsibleUnsafeText)

    # Test that we can wrap a list