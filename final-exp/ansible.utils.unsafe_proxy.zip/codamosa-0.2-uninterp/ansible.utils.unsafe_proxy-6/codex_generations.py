

# Generated at 2022-06-17 15:35:29.305920
# Unit test for function wrap_var
def test_wrap_var():
    import pytest

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var('foo') == 'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')

# Generated at 2022-06-17 15:35:37.755049
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:35:48.938161
# Unit test for function wrap_var
def test_wrap_var():
    import sys
    import unittest

    class TestWrapVar(unittest.TestCase):
        def test_wrap_var(self):
            # Test that wrap_var returns the same object if it's already unsafe
            unsafe_str = AnsibleUnsafeText('unsafe')
            self.assertIs(wrap_var(unsafe_str), unsafe_str)

            # Test that wrap_var returns the same object if it's already unsafe
            unsafe_bytes = AnsibleUnsafeBytes(b'unsafe')
            self.assertIs(wrap_var(unsafe_bytes), unsafe_bytes)

            # Test that wrap_var returns the same object if it's already unsafe
            unsafe_native_jinja = NativeJinjaUnsafeText('unsafe')

# Generated at 2022-06-17 15:35:55.660995
# Unit test for function wrap_var
def test_wrap_var():
    import collections
    import jinja2
    from ansible.module_utils.six import PY3

    # Test that wrap_var returns the same object if it is already unsafe
    assert wrap_var(AnsibleUnsafeText('foo')) is AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')

    # Test that wrap_var returns the same object if it is None
    assert wrap_var(None) is None

    # Test that wrap_var returns the same object if it is not a string
    assert wrap_var(42) == 42
    assert wrap_var(42.0) == 42.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False

    # Test that wrap_var

# Generated at 2022-06-17 15:36:05.890752
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys

    # Test for strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test for lists
    assert isinstance(wrap_var(['foo']), list)
    assert isinstance(wrap_var(['foo'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var([u'foo']), list)
    assert isinstance(wrap_var([u'foo'])[0], AnsibleUnsafeText)

# Generated at 2022-06-17 15:36:16.084442
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) is AnsibleUnsafeText(u'foo')

    assert wrap_var(b'foo') is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') is AnsibleUnsafeText(u'foo')

    assert wrap_var(['foo', 'bar']) == [AnsibleUnsafeText(u'foo'), AnsibleUnsafeText(u'bar')]
    assert wrap_var(('foo', 'bar')) == (AnsibleUnsafeText(u'foo'), AnsibleUnsafeText(u'bar'))

# Generated at 2022-06-17 15:36:24.955926
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3

    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(True), type(True))
    assert isinstance(wrap_var(1), type(1))
    assert isinstance(wrap_var(1.0), type(1.0))
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'.encode('utf-8')), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'.encode('utf-16')), AnsibleUnsafeText)

# Generated at 2022-06-17 15:36:31.072837
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.six.moves.urllib.parse import unquote
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.parse import urlunparse
    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    from ansible.module_utils.six.moves.urllib.parse import urlunsplit
   

# Generated at 2022-06-17 15:36:39.462072
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    # Test strings
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'.encode('utf-8')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'foo'.decode('utf-8')), AnsibleUnsafeText)

    # Test lists
    assert isinstance(wrap_var([u'foo', u'bar']), list)
    assert isinstance(wrap_var([u'foo', u'bar'])[0], AnsibleUnsafeText)

# Generated at 2022-06-17 15:36:48.395461
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Test for None
    assert wrap_var(None) is None

    # Test for int
    assert wrap_var(1) == 1

    # Test for float
    assert wrap_var(1.1) == 1.1

    # Test for bool
    assert wrap_var(True) is True
    assert wrap_var(False) is False

    # Test for string
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert wrap_var('foo') == 'foo'

    # Test for unicode
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert wrap_var(u'foo') == u'foo'

    # Test for

# Generated at 2022-06-17 15:36:59.958133
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(set()) == set()
    assert wrap_var(frozenset()) == frozenset()
    assert wrap_var(()) == ()
    assert wrap_var([]) == []
    assert wrap_var({}) == {}
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
   

# Generated at 2022-06-17 15:37:05.586979
# Unit test for function wrap_var
def test_wrap_var():
    import ansible.module_utils.basic
    import ansible.module_utils.six
    import ansible.module_utils.common.collections
    import ansible.module_utils.common._collections_compat

    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(1), type(1))
    assert isinstance(wrap_var(1.0), type(1.0))
    assert isinstance(wrap_var(True), type(True))
    assert isinstance(wrap_var(False), type(False))
    assert isinstance(wrap_var(ansible.module_utils.basic), type(ansible.module_utils.basic))
    assert isinstance(wrap_var(ansible.module_utils.six), type(ansible.module_utils.six))

# Generated at 2022-06-17 15:37:15.645517
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.parse import parse_qs
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.six.moves.urllib.parse import unquote
    from ansible.module_utils.six.moves.urllib.parse import quote_plus
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus

# Generated at 2022-06-17 15:37:24.412173
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'

# Generated at 2022-06-17 15:37:34.661924
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    # Test for None
    assert wrap_var(None) is None

    # Test for int
    assert wrap_var(1) == 1

    # Test for str
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert wrap_var('foo') == 'foo'

    # Test for bytes
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert wrap_var(b'foo') == b'foo'

    # Test for list
    assert isinstance(wrap_var(['foo', b'bar']), list)

# Generated at 2022-06-17 15:37:47.558761
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.1) == 1.1
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:37:55.836707
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:38:00.040400
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) is AnsibleUnsafeText(u'foo')
    assert wrap_var(u'foo') is AnsibleUnsafeText(u'foo')
    assert wrap_var(b'foo') is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_

# Generated at 2022-06-17 15:38:10.790911
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(set()) == set()
    assert wrap_var(frozenset()) == frozenset()
    assert wrap_var(()) == ()
    assert wrap_var([]) == []
    assert wrap_var({}) == {}
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo')

# Generated at 2022-06-17 15:38:22.035430
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    # Test basic types
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(0) == 0
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1.0 + 0.0j) == 1.0 + 0.0j
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')

# Generated at 2022-06-17 15:38:36.174172
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1j) == 1j
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')
   

# Generated at 2022-06-17 15:38:47.522063
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:38:58.147858
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')
    assert wrap_var(u'foo'.encode('utf-8')) == b'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')

# Generated at 2022-06-17 15:39:08.944117
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types, binary_type, text_type
    from ansible.utils.native_jinja import NativeJinjaText

    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes('foo')) == AnsibleUnsafeBytes('foo')
    assert wrap_var(NativeJinjaText('foo')) == NativeJinjaUnsafeText('foo')


# Generated at 2022-06-17 15:39:13.782984
# Unit test for function wrap_var
def test_wrap_var():
    import unittest
    import sys

    class TestWrapVar(unittest.TestCase):
        def test_wrap_var(self):
            self.assertIsInstance(wrap_var(None), type(None))
            self.assertIsInstance(wrap_var(1), int)
            self.assertIsInstance(wrap_var(1.0), float)
            self.assertIsInstance(wrap_var([]), list)
            self.assertIsInstance(wrap_var(()), tuple)
            self.assertIsInstance(wrap_var({}), dict)
            self.assertIsInstance(wrap_var(set()), set)
            self.assertIsInstance(wrap_var(u'foo'), AnsibleUnsafeText)
            self.assertIsInstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
            self

# Generated at 2022-06-17 15:39:23.197974
# Unit test for function wrap_var
def test_wrap_var():
    import json
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six.moves import cPickle as pickle

    # Test strings
    assert wrap_var('foo') == 'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'

    # Test dicts
    assert wrap_var({'foo': 'bar'}) == {'foo': 'bar'}
    assert wrap_var({'foo': b'bar'}) == {'foo': b'bar'}
    assert wrap_var({'foo': u'bar'}) == {'foo': u'bar'}

# Generated at 2022-06-17 15:39:32.696667
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:39:36.879442
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    # Test for None
    assert wrap_var(None) is None

    # Test for string
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)

    # Test for bytes
    if PY3:
        assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    else:
        assert isinstance(wrap_var(b'foo'), AnsibleUnsafeText)

    # Test for dict
    assert isinstance(wrap_var({'foo': 'bar'}), dict)
    assert isinstance(wrap_var({'foo': 'bar'})['foo'], AnsibleUnsafeText)

    # Test for list

# Generated at 2022-06-17 15:39:50.310580
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'

# Generated at 2022-06-17 15:40:00.262727
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    # Test for strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)

    # Test for lists
    assert isinstance(wrap_var(['foo', 'bar']), list)
   