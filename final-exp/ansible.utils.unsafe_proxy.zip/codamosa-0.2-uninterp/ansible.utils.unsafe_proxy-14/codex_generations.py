

# Generated at 2022-06-17 15:35:19.773069
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1j) == 1j
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'

# Generated at 2022-06-17 15:35:30.715599
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.parse import parse_qs
    from ansible.module_utils.six.moves.urllib.parse import parse_qsl
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.six.moves.urllib.parse import quote_plus
    from ansible.module_utils.six.moves.urllib.parse import unquote

# Generated at 2022-06-17 15:35:38.325480
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.1) == 1.1
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:35:46.090631
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.1) == 1.1
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var(u'\u2713') == AnsibleUnsafeText(u'\u2713')
    assert wrap_var(u'\u2713'.encode('utf-8')) == AnsibleUnsafeBytes(u'\u2713'.encode('utf-8'))

# Generated at 2022-06-17 15:35:53.694930
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == to_unsafe_bytes('foo')
    assert wrap_var('foo') == to_unsafe_text('foo')
    assert wrap_var(u'foo') == to_unsafe_text('foo')
    assert wrap_var(to_unsafe_bytes('foo')) == to_unsafe_bytes('foo')
    assert wrap_var(to_unsafe_text('foo')) == to_uns

# Generated at 2022-06-17 15:35:58.778722
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Test that wrap_var returns the same object if it is already unsafe
    assert wrap_var(AnsibleUnsafeText('foo')) is AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')

    # Test that wrap_var returns the same object if it is None
    assert wrap_var(None) is None

    # Test that wrap_var returns the same object if it is a builtin
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) is 1
    assert wrap_var(1.0) is 1.0
   

# Generated at 2022-06-17 15:36:07.714578
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:36:16.832972
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys

    # Test for None
    assert wrap_var(None) is None

    # Test for already wrapped
    assert wrap_var(AnsibleUnsafeText('foo')) is AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')

    # Test for strings
    assert wrap_var('foo') is AnsibleUnsafeText('foo')
    assert wrap_var(u'foo') is AnsibleUnsafeText('foo')
    assert wrap_var(b'foo') is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'\u2713') is AnsibleUn

# Generated at 2022-06-17 15:36:25.335107
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(set()) == set()
    assert wrap_var(frozenset()) == frozenset()
    assert wrap_var(()) == ()
    assert wrap_var([]) == []
    assert wrap_var({}) == {}
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var

# Generated at 2022-06-17 15:36:35.729999
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(True), type(True))
    assert isinstance(wrap_var(False), type(False))
    assert isinstance(wrap_var(1), type(1))
    assert isinstance(wrap_var(1.0), type(1.0))
    assert isinstance(wrap_var(1j), type(1j))
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

# Generated at 2022-06-17 15:36:49.005320
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeText('foo')) is AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes('foo')) is AnsibleUnsafeBytes('foo')

    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    assert isinstance(wrap_var(dict(foo=1)), dict)

# Generated at 2022-06-17 15:36:59.337737
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.collections import is_sequence

    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes('foo')) == AnsibleUnsafeBytes('foo')
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(NativeJinjaText('foo')) == NativeJinjaUnsafeText('foo')
    assert wrap_var(NativeJinjaText(b'foo')) == NativeJinjaUnsafeText(b'foo')
    assert wrap_var

# Generated at 2022-06-17 15:37:05.341140
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(set()) == set()
    assert wrap_var(frozenset()) == frozenset()
    assert wrap_var(()) == ()
    assert wrap_var([]) == []
    assert wrap_var({}) == {}
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')

# Generated at 2022-06-17 15:37:15.495332
# Unit test for function wrap_var
def test_wrap_var():
    import unittest
    import sys

    class TestWrapVar(unittest.TestCase):
        def test_wrap_var_dict(self):
            v = {'a': 'b', 'c': 'd'}
            self.assertEqual(wrap_var(v), {'a': 'b', 'c': 'd'})

        def test_wrap_var_list(self):
            v = ['a', 'b', 'c']
            self.assertEqual(wrap_var(v), ['a', 'b', 'c'])

        def test_wrap_var_tuple(self):
            v = ('a', 'b', 'c')
            self.assertEqual(wrap_var(v), ('a', 'b', 'c'))


# Generated at 2022-06-17 15:37:24.345772
# Unit test for function wrap_var
def test_wrap_var():
    import json
    import sys
    import unittest

    from ansible.module_utils.six import PY3

    class TestWrapVar(unittest.TestCase):
        def test_wrap_var_none(self):
            self.assertIsNone(wrap_var(None))

        def test_wrap_var_unsafe(self):
            self.assertIsInstance(wrap_var(AnsibleUnsafeText(u'foo')), AnsibleUnsafeText)

        def test_wrap_var_text(self):
            self.assertIsInstance(wrap_var(u'foo'), AnsibleUnsafeText)

        def test_wrap_var_bytes(self):
            self.assertIsInstance(wrap_var(b'foo'), AnsibleUnsafeBytes)


# Generated at 2022-06-17 15:37:30.116600
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1j) == 1j
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'.encode('utf-8')
   

# Generated at 2022-06-17 15:37:37.471624
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys

    # Test for None
    assert wrap_var(None) is None

    # Test for string
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)

    # Test for bytes
    assert isinstance(wrap_var(b'test'), AnsibleUnsafeBytes)

    # Test for int
    assert wrap_var(1) == 1

    # Test for float
    assert wrap_var(1.0) == 1.0

    # Test for dict
    assert isinstance(wrap_var({'test': 'test'}), dict)
    assert isinstance(wrap_var({'test': 'test'})['test'], AnsibleUnsafeText)

    # Test for list

# Generated at 2022-06-17 15:37:44.498383
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes('foo')) == AnsibleUnsafeBytes('foo')
    assert wrap_var(NativeJinjaText('foo')) == NativeJinjaUnsafeText('foo')
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var(['foo', 'bar']) == [AnsibleUnsafeText('foo'), AnsibleUnsafeText('bar')]
    assert wrap_var(('foo', 'bar'))

# Generated at 2022-06-17 15:37:51.124840
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Test strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)

    # Test lists
    assert isinstance(wrap_var(['foo', 'bar']), list)
    assert isinstance(wrap_var(['foo', 'bar'])[0], AnsibleUnsafeText)


# Generated at 2022-06-17 15:38:01.863822
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(0) == 0
    assert wrap_var(0.0) == 0.0
    assert wrap_var(0j) == 0j
    assert wrap_var('') == AnsibleUnsafeText('')
    assert wrap_var(b'') == AnsibleUnsafeBytes(b'')
    assert wrap_var(u'') == AnsibleUnsafeText(u'')