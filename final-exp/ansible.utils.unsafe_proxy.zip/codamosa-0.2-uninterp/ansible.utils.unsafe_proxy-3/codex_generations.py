

# Generated at 2022-06-17 15:35:27.179515
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys

    # Test for strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test for dict
    assert isinstance(wrap_var({'foo': 'bar'}), dict)
    assert isinstance(wrap_var({'foo': 'bar'})['foo'], AnsibleUnsafeText)
    assert isinstance(wrap_var({'foo': u'bar'})['foo'], AnsibleUnsafeText)

# Generated at 2022-06-17 15:35:37.153309
# Unit test for function wrap_var
def test_wrap_var():
    import ansible.module_utils.common.collections as collections
    import ansible.module_utils.common.json_utils as json_utils
    import ansible.module_utils.common.text.converters as converters

    # Test for None
    assert wrap_var(None) is None

    # Test for AnsibleUnsafe
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')

    # Test for string
    assert wrap_var('foo') == AnsibleUnsafeText('foo')

    # Test for bytes
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')

    # Test for dict
    assert wrap_

# Generated at 2022-06-17 15:35:45.539545
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'\u2713') == u'\u2713'
    assert wrap_var(b'\xe2\x9c\x93') == b'\xe2\x9c\x93'
    assert wrap_var(u'\u2713'.encode('utf-8')) == u'\u2713'.encode('utf-8')

# Generated at 2022-06-17 15:35:53.345051
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    # Test wrapping a dict
    d = {'foo': 'bar', 'baz': 'qux'}
    d_wrapped = wrap_var(d)
    assert isinstance(d_wrapped, dict)
    assert isinstance(d_wrapped['foo'], AnsibleUnsafeText)
    assert isinstance(d_wrapped['baz'], AnsibleUnsafeText)

    # Test wrapping a list
    l = ['foo', 'bar', 'baz']
    l_wrapped = wrap_var(l)
    assert isinstance(l_wrapped, list)
    assert isinstance(l_wrapped[0], AnsibleUnsafeText)

# Generated at 2022-06-17 15:36:04.310342
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:36:15.072454
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.1) == 1.1
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u

# Generated at 2022-06-17 15:36:22.231590
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    # Test for None
    assert wrap_var(None) is None

    # Test for int
    assert wrap_var(1) == 1

    # Test for float
    assert wrap_var(1.0) == 1.0

    # Test for bool
    assert wrap_var(True) is True
    assert wrap_var(False) is False

    # Test for list
    assert wrap_var([1, 2, 3]) == [1, 2, 3]

    # Test for tuple
    assert wrap_var((1, 2, 3)) == (1, 2, 3)

    # Test for set
    assert wrap_var(set([1, 2, 3])) == set([1, 2, 3])



# Generated at 2022-06-17 15:36:34.227636
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(0) == 0
    assert wrap_var(1) == 1
    assert wrap_var(0.0) == 0.0
    assert wrap_var(1.0) == 1.0
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(u'foo')) == AnsibleUnsafeText(u'foo')
    assert wrap_var(NativeJinjaText(u'foo')) == NativeJinjaUnsafeText(u'foo')
    assert wrap_var(NativeJinjaText(u'foo')) == NativeJinjaUn

# Generated at 2022-06-17 15:36:48.104789
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(set()) == set()
    assert wrap_var(frozenset()) == frozenset()
    assert wrap_var(dict()) == dict()
    assert wrap_var(list()) == list()
    assert wrap_var(tuple()) == tuple()
    assert wrap_var(builtins.range(10)) == list(builtins.range(10))

# Generated at 2022-06-17 15:36:58.748616
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    # Test basic types
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(0) == 0
    assert wrap_var(1) == 1
    assert wrap_var(0.1) == 0.1
    assert wrap_var(1.1) == 1.1
    assert wrap_var(1.1 + 0.1j) == 1.1 + 0.1j
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(u'foo') == u'foo'

    # Test sequences
    assert wrap_var([]) == []
    assert wrap_var