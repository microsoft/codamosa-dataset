

# Generated at 2022-06-11 18:31:30.892577
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    class UnsafeClass(object):
        UNSAFE = True

    assert isinstance(UnsafeProxy(UnsafeClass()), UnsafeClass)

# Generated at 2022-06-11 18:31:32.471904
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy(None), type(None))



# Generated at 2022-06-11 18:31:41.342037
# Unit test for function wrap_var
def test_wrap_var():
    assert(wrap_var(None) is None)
    assert(wrap_var(1) == 1)
    assert(wrap_var(1.0) == 1.0)
    assert(wrap_var(False) is False)
    assert(wrap_var({}) == {})
    assert(wrap_var([]) == [])
    assert(wrap_var(()) == ())
    assert(wrap_var(set()) == set())
    assert(wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo'))
    assert(wrap_var('foo') == AnsibleUnsafeText('foo'))

# Generated at 2022-06-11 18:31:49.856351
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy(b'\xfc') == u'\u00fc'
    assert UnsafeProxy(u'\u00fc') == u'\u00fc'
    assert UnsafeProxy(u'\u00fc'.encode('utf-8')) == u'\u00fc'
    assert UnsafeProxy(u'\u00fc'.encode('utf-8'), encoding='utf-8') == u'\u00fc'
    assert UnsafeProxy(b'\xfc', encoding='latin1') == u'\u00fc'



# Generated at 2022-06-11 18:32:01.956808
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence, Iterable

    assert isinstance(UnsafeProxy(None), AnsibleUnsafe)
    assert isinstance(UnsafeProxy(AnsibleUnsafe()), AnsibleUnsafe)

    # Strings
    assert isinstance(UnsafeProxy(u''), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(u'Unsafe text'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'Unsafe bytes'), AnsibleUnsafeBytes)
    assert UnsafeProxy(u'Unsafe text') == u'Unsafe text'
    assert UnsafeProxy(b'Unsafe bytes') == b'Unsafe bytes'

    # Numbers and booleans
    assert UnsafeProxy(0) == 0
    assert UnsafeProxy(1)

# Generated at 2022-06-11 18:32:11.820461
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    import os
    import six
    import random
    import string
    from sys import platform as _platform
    from ansible.module_utils.six import PY3, integer_types
    from ansible.module_utils.six.moves import reload_module
    import ansible.module_utils.ansible_galaxy.api
    import ansible.module_utils.six.moves.urllib.request, ansible.module_utils.six.moves.urllib.parse, ansible.module_utils.six.moves.urllib.error
    import ansible.module_utils.urls

    reload_module(ansible.module_utils.ansible_galaxy.api)
    reload_module(ansible.module_utils.six.moves.urllib.request)

# Generated at 2022-06-11 18:32:14.934473
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    Display().deprecated(
        'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )

# Generated at 2022-06-11 18:32:26.823000
# Unit test for function wrap_var
def test_wrap_var():

    # Test wrapping types
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(bool(True)), bool)
    assert isinstance(wrap_var(int(4)), int)
    assert isinstance(wrap_var(float(4.5)), float)
    assert isinstance(wrap_var(to_bytes('bytes')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(to_text('unicode')), AnsibleUnsafeText)

    # Test wrapping dict
    dict_var = {
        'key_a': 'value_a',
        'key_b': 'value_b',
    }
    wrapped_dict = {
        'key_a': 'value_a',
        'key_b': 'value_b',
    }
    dict_result = wrap

# Generated at 2022-06-11 18:32:28.833506
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    u = UnsafeProxy("test")
    assert type(u) == text_type



# Generated at 2022-06-11 18:32:37.005257
# Unit test for function wrap_var
def test_wrap_var():
    import copy
    import jinja2

    safe_env = jinja2.Environment(autoescape=True)
    safe_env.tests['unsafe'] = lambda x: False

    jinja_env = jinja2.Environment()
    jinja_env.tests['unsafe'] = lambda x: False


# Generated at 2022-06-11 18:32:42.638837
# Unit test for function wrap_var
def test_wrap_var():
    x = {"a": "b", "c": "d"}
    y = wrap_var(x)
    assert type(y["a"]) == AnsibleUnsafeText
    assert type(y["c"]) == AnsibleUnsafeText



# Generated at 2022-06-11 18:32:51.657814
# Unit test for function wrap_var
def test_wrap_var():
    """Test if wrap_var recursivly wraps every element in an object"""
    import jinja2
    from ansible.module_utils.common.collections import Mapping

    def test_isinstance(k, t):
        if not isinstance(k, t):
            raise AssertionError("{} is not instance of {}".format(k, t))

    def test_not_instance(k, t):
        if isinstance(k, t):
            raise AssertionError("{} is instance of {}".format(k, t))

    # Basic container types
    b = wrap_var(dict(a=1, b=2))
    test_isinstance(b, Mapping)
    test_isinstance(b, AnsibleUnsafe)
    test_isinstance(b['a'], AnsibleUnsafeText)

# Generated at 2022-06-11 18:33:01.850224
# Unit test for function wrap_var
def test_wrap_var():
    '''
    This tests the wrap_var function, making sure that all the objects it should
    modify get modified, and that it does not modify objects that should be
    left alone.
    '''
    # Lists of objects that should and should not get wrapped by wrap_var.

# Generated at 2022-06-11 18:33:12.203791
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(b'hello') == b'hello'
    assert isinstance(wrap_var(b'hello'), AnsibleUnsafeBytes)
    assert wrap_var(u'hello') == u'hello'
    assert isinstance(wrap_var(u'hello'), AnsibleUnsafeText)
    assert wrap_var(None) is None
    assert wrap_var([u'hello', None, b'world', None]) == [u'hello', None, b'world', None]
    assert isinstance(wrap_var([u'hello', None, b'world', None])[2], AnsibleUnsafeBytes)
    assert isinstance(wrap_var([u'hello', None, b'world', None])[0], AnsibleUnsafeText)
    assert wrap_var(set([u'hello', None, b'world', None]))

# Generated at 2022-06-11 18:33:23.783685
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common._collections_compat import Sequence

    def assertEqualAndNotEqual(var, wrapped_var=None):
        if wrapped_var is None:
            wrapped_var = var
        assertEqual(var, wrapped_var)
        assertNotEqual(var, type(var)(wrapped_var))

    def assertEqual(var1, var2):
        assert var1 == var2, '%r == %r' % (var1, var2)

    def assertNotEqual(var1, var2):
        assert var1 != var2, '%r != %r' % (var1, var2)

    def assertEqualToUnicode(var, unicode_text):
        assertEqual(var, unicode_text)


# Generated at 2022-06-11 18:33:28.750562
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import text_type

    assert isinstance(wrap_var('a string'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'a unicode string'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'\u2030'), AnsibleUnsafeText)

    assert isinstance(wrap_var(b'a byte string'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'\xbc'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'\xff'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'\xc3\xa9'), AnsibleUnsafeBytes)

    assert isinstance(wrap_var(False), bool)
    assert isinstance(wrap_var(1), int)
   

# Generated at 2022-06-11 18:33:38.928641
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    display = Display()
    assert wrap_var('test') == 'test'
    assert wrap_var('test') == u'test'

    assert wrap_var(None) == None

    assert type(wrap_var('test')) is str
    assert type(wrap_var(u'test')) is unicode

    assert wrap_var(u'test') == u'test'
    assert type(wrap_var(u'test')) is unicode

    assert wrap_var(to_unsafe_text('test')) == u'test'
    assert type(wrap_var(to_unsafe_text('test'))) is unicode

    assert wrap_var(to_unsafe_bytes('test')) == 'test'

# Generated at 2022-06-11 18:33:50.778799
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)
    assert isinstance(wrap_var({'foo': 'test'}), dict)
    assert isinstance(wrap_var({'foo': 'test'})['foo'], AnsibleUnsafeText)
    assert isinstance(wrap_var(['test']), list)
    assert isinstance(wrap_var(('test',)), tuple)
    assert isinstance(wrap_var(['test'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var(('test',))[0], AnsibleUnsafeText)
    assert isinstance(wrap_var(set(['test'])), set)
    assert isinstance(wrap_var(set(['test'])) - set(['test']), set)

# Generated at 2022-06-11 18:34:00.662728
# Unit test for function wrap_var
def test_wrap_var():
    import types
    import copy

    test_list = [1, 2, 3]
    test_tuple = tuple(test_list)

    for test in (1, "str", test_list, test_tuple):
        assert wrap_var(test) == test

    for test in (1, "str", test_list, test_tuple):
        assert wrap_var(copy.copy(test)) == test
        assert wrap_var(copy.deepcopy(test)) == test

    for test in ("str", test_list, test_tuple):
        assert isinstance(wrap_var(test), types.UnicodeType)
        assert isinstance(wrap_var(copy.copy(test)), types.UnicodeType)
        assert isinstance(wrap_var(copy.deepcopy(test)), types.UnicodeType)



# Generated at 2022-06-11 18:34:11.896949
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import Mapping, Sequence, Set
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == b'foo'
    assert wrap_var(AnsibleUnsafeText(u'foo')) == u'foo'
    assert wrap_var(NativeJinjaUnsafeText(u'foo')) == u'foo'
    assert wrap_var(b'foo\xc3\xa9') == b'foo\xc3\xa9'
    assert wrap_var(u'foo\xc3\xa9') == u'foo\xc3\xa9'
    assert wrap_var(AnsibleUnsafeBytes(b'foo\xc3\xa9')) == b'foo\xc3\xa9'

# Generated at 2022-06-11 18:34:20.067300
# Unit test for function wrap_var
def test_wrap_var():
    test_var = [{'a': '\xc3\x9c'}]

    list_var = wrap_var(test_var)
    assert isinstance(list_var, list)

    dict_var = list_var[0]
    assert isinstance(dict_var, dict)

    bytes_var = dict_var['a']
    assert isinstance(bytes_var, AnsibleUnsafeBytes)
    assert not isinstance(bytes_var, binary_type)
    assert not isinstance(bytes_var, AnsibleUnsafeText)
    assert not isinstance(bytes_var, text_type)
    assert not isinstance(bytes_var, NativeJinjaUnsafeText)

# Generated at 2022-06-11 18:34:28.055175
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3


# Generated at 2022-06-11 18:34:32.971739
# Unit test for function wrap_var
def test_wrap_var():
    d1 = {
        'a': [1, 2, 3],
        'b': 'hello world',
        'c': {
            'c1': 'foo'
        }
    }

    d2 = wrap_var(d1)
    assert d1 == d2

# Generated at 2022-06-11 18:34:40.774196
# Unit test for function wrap_var
def test_wrap_var():
    import pytest

    # Basic test
    a = dict(
        b=1,
        c=2
        )
    assert type(wrap_var(a)) is dict
    assert type(wrap_var(a)['b']) is AnsibleUnsafeText
    assert type(wrap_var(a)['c']) is AnsibleUnsafeText

    # Nested test
    d = dict(
        e=dict(
            f=3,
            g=4
            )
    )
    assert type(wrap_var(d)) is dict
    assert type(wrap_var(d)['e']) is dict
    assert type(wrap_var(d)['e']['f']) is AnsibleUnsafeText
    assert type(wrap_var(d)['e']['g']) is AnsibleUnsafeText

# Generated at 2022-06-11 18:34:50.148987
# Unit test for function wrap_var
def test_wrap_var():
    def assert_wrapped_correctly(expected, actual):
        assert wrap_var(expected) == actual

    # Primitive types:
    assert_wrapped_correctly("foo", AnsibleUnsafeText("foo"))
    assert_wrapped_correctly(1, 1)
    assert_wrapped_correctly(1.5, 1.5)
    assert_wrapped_correctly(None, None)
    assert_wrapped_correctly(True, True)
    assert_wrapped_correctly(False, False)

    # Sets:
    assert_wrapped_correctly(set("foo"), set("foo"))
    assert_wrapped_correctly(set("foo"), set(AnsibleUnsafeText("foo")))
    assert_wrapped_correctly({1, 2, 3}, {1, 2, 3})


# Generated at 2022-06-11 18:34:58.877449
# Unit test for function wrap_var
def test_wrap_var():
    # wrap_var(string)
    assert isinstance(wrap_var("some string"), AnsibleUnsafeText)
    assert not isinstance(wrap_var("some string"), AnsibleUnsafeBytes)
    assert wrap_var("some string") == "some string"
    assert isinstance(wrap_var(u"some string"), AnsibleUnsafeText)
    assert not isinstance(wrap_var(u"some string"), AnsibleUnsafeBytes)
    assert wrap_var(u"some string") == u"some string"
    assert isinstance(wrap_var("another string"), AnsibleUnsafeText)
    assert not isinstance(wrap_var("another string"), AnsibleUnsafeBytes)
    assert wrap_var("another string") == "another string"

# Generated at 2022-06-11 18:35:05.272969
# Unit test for function wrap_var
def test_wrap_var():

    from ansible.module_utils.common.collections import is_sequence

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(0.0) == 0.0
    assert wrap_var(1.0) == 1.0
    assert isinstance(wrap_var(1), int)
    assert wrap_var(0) == 0
    assert wrap_var(1) == 1
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert wrap_var('foo') == 'foo'
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert wrap_var(b'foo') == b'foo'

# Generated at 2022-06-11 18:35:14.380823
# Unit test for function wrap_var
def test_wrap_var():
    # Test that we can wrap python text/binary types
    assert isinstance(wrap_var("a"), AnsibleUnsafeText)
    assert isinstance(wrap_var(b"a"), AnsibleUnsafeBytes)

    # Test that we can wrap custom types derived from native types
    assert isinstance(wrap_var(NativeJinjaText("a")), NativeJinjaUnsafeText)

    # Test that we don't wrap custom types derived from AnsibleUnsafeText/AnsibleUnsafeBytes
    class CustomUnsafeText(AnsibleUnsafeText):
        pass

    class CustomUnsafeBytes(AnsibleUnsafeBytes):
        pass

    assert isinstance(wrap_var(CustomUnsafeText("a")), CustomUnsafeText)

# Generated at 2022-06-11 18:35:24.730397
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(b'foo') == to_unsafe_bytes(b'foo')
    assert wrap_var(u'foo') == to_unsafe_text(u'foo')
    assert wrap_var(u'foo') == to_unsafe_text(u'foo')
    assert wrap_var(to_unsafe_text(u'foo')) == to_unsafe_text(u'foo')
    assert wrap_var(to_unsafe_text(u'foo')) == to_unsafe_text(u'foo')

    t1 = dict(a=b'foo', b=5)
    t2 = dict(a=u'foo', b=5)
    t3 = dict(a=u'foo', b=5, c=dict(d=u'bar'))

# Generated at 2022-06-11 18:35:35.446541
# Unit test for function wrap_var
def test_wrap_var():
    import types, sys

    unsafe_return = wrap_var('monkey')

    assert( isinstance(unsafe_return, AnsibleUnsafeText) )
    # This is a hack to check that the function returns the right class
    # since isinstance will return true for subclasses
    assert( sys.getrefcount(unsafe_return) == 2 )

    unsafe_return = wrap_var(unsafe_return)

    assert( isinstance(unsafe_return, AnsibleUnsafeText) )
    # This is a hack to check that the function returns the right class
    # since isinstance will return true for subclasses
    assert( sys.getrefcount(unsafe_return) == 2 )

    unsafe_return = wrap_var( b'monkey' )

    assert( isinstance(unsafe_return, AnsibleUnsafeBytes) )
   