

# Generated at 2022-06-11 18:31:43.273031
# Unit test for function wrap_var
def test_wrap_var():
    import sys
    import pytest

    # List
    assert wrap_var(["a", "b", "c"]) == ["a", "b", "c"]
    assert isinstance(wrap_var(["a", "b", "c"]), list)
    assert not isinstance(wrap_var(["a", "b", "c"]), tuple)

    # Tuples
    assert wrap_var(("a", "b", "c")) == ("a", "b", "c")
    assert isinstance(wrap_var(("a", "b", "c")), tuple)
    assert not isinstance(wrap_var(("a", "b", "c")), list)

    # Dictionaries
    assert wrap_var({"a": "b", "c": "d"}) == {"a": "b", "c": "d"}

# Generated at 2022-06-11 18:31:53.500538
# Unit test for function wrap_var
def test_wrap_var():
    import pytest

    def _wrap_dict(v):
        return dict((wrap_var(k), wrap_var(item)) for k, item in v.items())

    def _wrap_sequence(v):
        """Wraps a sequence with unsafe, not meant for strings, primarily
        ``tuple`` and ``list``
        """
        v_type = type(v)
        return v_type(wrap_var(item) for item in v)

    def _wrap_set(v):
        return set(wrap_var(item) for item in v)

    def wrap_var(v):
        if v is None or isinstance(v, AnsibleUnsafe):
            return v

        if isinstance(v, Mapping):
            v = _wrap_dict(v)
        elif isinstance(v, Set):
            v

# Generated at 2022-06-11 18:32:03.529229
# Unit test for function wrap_var
def test_wrap_var():
    import sys
    import unittest

    class TestUnsafeWrapping(unittest.TestCase):
        def test_wrap_none(self):
            self.assertEqual(None, wrap_var(None))

        def test_wrap_unicode(self):
            self.assertTrue(isinstance(wrap_var('foo'), AnsibleUnsafeText))

        def test_wrap_bytes(self):
            self.assertTrue(isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes))

        def test_wrap_set(self):
            self.assertTrue(isinstance(wrap_var(set(['foo'])), set))
            self.assertTrue(isinstance(wrap_var(set(['foo']))[0], AnsibleUnsafeText))


# Generated at 2022-06-11 18:32:13.071123
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_sequence

    ival = 123
    tval = u'this is unicode'
    bval = b'bytes here'
    dval = dict(a=1, b=2)
    lval = [1, 2, 3]
    assert ival == wrap_var(ival)
    assert tval == wrap_var(tval)
    assert bval == wrap_var(bval)
    assert dval == wrap_var(dval)
    assert lval == wrap_var(lval)
    assert isinstance(wrap_var(tval), AnsibleUnsafeText)
    assert isinstance(wrap_var(ival), int)
    assert isinstance(wrap_var(bval), AnsibleUnsafeBytes)

# Generated at 2022-06-11 18:32:25.180008
# Unit test for function wrap_var
def test_wrap_var():
    import unittest
    class TestWrapVar(unittest.TestCase):

        def test_none(self):
            val = wrap_var(None)
            self.assertIsNone(val)

        def test_dict(self):
            val = wrap_var({'key': 'value', 'k2': 1234})
            self.assertTrue(isinstance(val, dict))
            self.assertTrue(isinstance(val['key'], AnsibleUnsafeText))
            self.assertTrue(isinstance(val['k2'], AnsibleUnsafeText))
            self.assertEqual(val['key'], 'value')
            self.assertEqual(val['k2'], '1234')


# Generated at 2022-06-11 18:32:35.077311
# Unit test for function wrap_var
def test_wrap_var():

    assert wrap_var("some_foo") == AnsibleUnsafeText("some_foo")
    assert wrap_var(to_bytes("some_foo")) == AnsibleUnsafeBytes(to_bytes("some_foo"))

    # Test for text and bytes types for the following tests
    for expected_string_type in [text_type, binary_type]:
        # Test dict
        d = wrap_var({"a": expected_string_type("foo"),
                      "b": {"c": {"d": expected_string_type("bar")}}})

        assert type(d) == dict
        assert type(d["a"]) == expected_string_type
        assert type(d["b"]) == dict
        assert type(d["b"]["c"]) == dict

# Generated at 2022-06-11 18:32:46.319061
# Unit test for function wrap_var
def test_wrap_var():

    # Test byte string
    byte_str = b"abc"
    byte_str_unsafe = wrap_var(byte_str)
    assert(isinstance(byte_str_unsafe, AnsibleUnsafeBytes))
    assert(isinstance(byte_str_unsafe, binary_type))

    # Test string
    str_ = "abc"
    str_unsafe = wrap_var(str_)
    assert(isinstance(str_unsafe, AnsibleUnsafeText))
    assert(isinstance(str_unsafe, text_type))

    # Test list
    l = ["abc", "def", "ghi"]
    l_unsafe = wrap_var(l)
    assert(isinstance(l_unsafe, list))
    assert(isinstance(l_unsafe[0], AnsibleUnsafeText))
   

# Generated at 2022-06-11 18:32:53.042243
# Unit test for function wrap_var
def test_wrap_var():
    assert(wrap_var('foo') == 'foo')
    assert(wrap_var(b'foo') == b'foo')
    assert(wrap_var(AnsibleUnsafeBytes(b'foo')) == b'foo')
    assert(isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes))
    assert(wrap_var(u'foo') == u'foo')
    assert(wrap_var(AnsibleUnsafeText(u'foo')) == u'foo')
    assert(isinstance(wrap_var(u'foo'), AnsibleUnsafeText))
    assert(wrap_var({b'foo': b'bar'}) == {b'foo': b'bar'})
    assert(wrap_var({'foo': 'bar'}) == {'foo': 'bar'})

# Generated at 2022-06-11 18:33:02.274556
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import text_type, binary_type
    from ansible.module_utils.six.moves import builtins

# Generated at 2022-06-11 18:33:11.545813
# Unit test for function wrap_var
def test_wrap_var():
    import copy
    assert wrap_var(None) is None
    assert isinstance("", AnsibleUnsafeText)
    assert wrap_var("") is ""
    assert wrap_var("foo") == "foo"
    assert isinstance(wrap_var("foo"), AnsibleUnsafeText)
    assert wrap_var("foo") == "foo"
    assert wrap_var(b"") is b""
    assert wrap_var(b"foo") == b"foo"
    assert isinstance(wrap_var(b"foo"), AnsibleUnsafeBytes)
    assert wrap_var(u"") is u""
    assert wrap_var(u"foo") == u"foo"
    assert isinstance(wrap_var(u"foo"), AnsibleUnsafeText)
    assert isinstance(wrap_var({"foo": b"bar"}), dict)

# Generated at 2022-06-11 18:33:25.062050
# Unit test for function wrap_var
def test_wrap_var():
    test_cases = dict(
        list=([], []),
        tuple=((), ()),
        set=(set(), set()),
        dict={},
        dict_nested={
            'a': 'a',
            'b': ['b'],
            'c': {'c': 'c'},
            'd': [{'d': 'd'}],
        },
        str=('test', 'test'),
        text=('test', 'test'),
        str_u=('test', 'test'),
        text_u=('test', 'test'),
        str_b=('test', b'test'),
        bytes=('test', b'test'),
        njt=NativeJinjaText('test'),
        tjt=NativeJinjaText('test'),
    )


# Generated at 2022-06-11 18:33:36.749705
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence

    # Try basic wrapping
    assert wrap_var("foo") == AnsibleUnsafeText(u"foo")
    assert wrap_var(u"foo") == AnsibleUnsafeText(u"foo")

    # Check other unicode type safety
    assert wrap_var("foo") == AnsibleUnsafeText(b"foo".decode('utf-8'))
    assert wrap_var(u"foo") == AnsibleUnsafeText(b"foo".decode('utf-8'))

    # Check that wrapping a unicode string
    assert wrap_var(b"foo") == AnsibleUnsafeBytes(b"foo")

# Generated at 2022-06-11 18:33:47.096915
# Unit test for function wrap_var
def test_wrap_var():
    assert(wrap_var("") == AnsibleUnsafeText(""))
    assert(wrap_var(u"") == AnsibleUnsafeText(""))
    assert(wrap_var(AnsibleUnsafeText("")) == AnsibleUnsafeText(""))
    assert(wrap_var(AnsibleUnsafeText(u"")) == AnsibleUnsafeText(""))
    assert(wrap_var(None) == None)
    assert(wrap_var(AnsibleUnsafeBytes(b"")) == AnsibleUnsafeBytes(b""))
    assert(wrap_var(AnsibleUnsafeBytes(u"")) == AnsibleUnsafeBytes(b""))
    assert(wrap_var(b"") == AnsibleUnsafeBytes(b""))
    assert(wrap_var(1) == 1)

# Generated at 2022-06-11 18:33:58.585523
# Unit test for function wrap_var
def test_wrap_var():
    import json
    from ansible.module_utils.common.collections import is_sequence

    class TestClass(object):
        def __init__(self, value):
            self._value = value

        def get_value(self):
            return self._value

    assert wrap_var(1) is 1
    assert wrap_var(None) is None

    x = TestClass('bar')
    assert wrap_var(x) is x


# Generated at 2022-06-11 18:34:10.467595
# Unit test for function wrap_var
def test_wrap_var():
    # Test some simple values
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(0) == 0
    assert wrap_var(0.0) == 0.0
    assert wrap_var(0.0) == 0.0
    assert wrap_var(0j) == 0j
    assert wrap_var('') == ''
    assert wrap_var([]) == []
    assert wrap_var(()) == ()
    assert wrap_var({}) == {}
    assert wrap_var(set()) == set()
    assert wrap_var(range(0)) == []

    # Test a few simple recursive structures
    assert wrap_var([[], []]) == [[], []]

# Generated at 2022-06-11 18:34:18.988922
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common._collections_compat import Set

    assert isinstance(wrap_var({'b': '2'}), Mapping)
    assert isinstance(wrap_var(('a', 'b', 'c')), Sequence)
    assert isinstance(wrap_var(set(['a', 'b', 'c'])), Set)
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'bytes')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(AnsibleUnsafeText(u'text')), AnsibleUnsafeText)
    assert isinstance(wrap_var(None), type(None))
    assert isinstance

# Generated at 2022-06-11 18:34:27.727241
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3

    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(True), type(True))
    assert isinstance(wrap_var(1), type(1))
    assert isinstance(wrap_var(1.0), type(1.0))
    assert isinstance(wrap_var([]), type([]))
    assert isinstance(wrap_var({}), type({}))

    b_str = wrap_var(b'bytes')
    assert isinstance(b_str, AnsibleUnsafeBytes)
    assert isinstance(b_str, binary_type)
    u_str = wrap_var(u'unicode')
    assert isinstance(u_str, AnsibleUnsafeText)

# Generated at 2022-06-11 18:34:38.600452
# Unit test for function wrap_var
def test_wrap_var():
    import json

    class Foo():
        def __eq__(self, other):
            return True

    def is_dictionary(obj):
        return isinstance(obj, dict) and not isinstance(obj, NativeJinjaText)

    # Basic types
    value = wrap_var('hello world')
    assert isinstance(value, AnsibleUnsafeText)
    assert not is_dictionary(value)

    value = wrap_var(u'hello world')
    assert isinstance(value, AnsibleUnsafeText)
    assert not is_dictionary(value)

    value = wrap_var(b'hello world')
    assert isinstance(value, AnsibleUnsafeBytes)
    assert not is_dictionary(value)

    # Already wrapped
    value = wrap_var(AnsibleUnsafeBytes(b'hello world'))

# Generated at 2022-06-11 18:34:49.287314
# Unit test for function wrap_var
def test_wrap_var():
    """Ensure that wrap_var produces the correct types"""
    import json
    import random
    import types

    class MyObj():
        """Dummy proxyable type"""
        def __init__(self, value):
            self.value = value

    # A few encodable objects
    objects = [
        {},
        dict(one=1, two=2, three=3),
        list(range(10)),
        tuple(range(10)),
        set(range(10)),
        NativeJinjaUnsafeText('{}'),
        NativeJinjaText('{}'),
        'abc',
        u'abc',
        MyObj(10),
        [MyObj(10)],
        types.InstanceType
    ]


# Generated at 2022-06-11 18:34:58.813138
# Unit test for function wrap_var
def test_wrap_var():
    import unittest
    import sys

    class TestWrapVar(unittest.TestCase):
        def test_wrap_var(self):
            from ansible.module_utils.common._collections_compat import Sequence
            from ansible.module_utils.six import PY3
            expected_str_type = text_type if PY3 else binary_type