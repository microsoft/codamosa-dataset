

# Generated at 2022-06-11 18:31:41.530563
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_sequence
    import ansible.module_utils.six as six

    # Validate non AnsibleUnsafeBytes
    assert isinstance(wrap_var("string"), AnsibleUnsafeText)
    assert isinstance(wrap_var(six.binary_type("string")), AnsibleUnsafeBytes)

    # Validate non AnsibleUnsafeText
    assert isinstance(wrap_var(six.binary_type("string")), AnsibleUnsafeBytes)

    # Validate dict
    assert isinstance(wrap_var({"string": "string"}), dict)
    assert isinstance(wrap_var({"string": "string"})["string"], AnsibleUnsafeText)

    # Validate list
    assert isinstance(wrap_var(["string"]), list)

# Generated at 2022-06-11 18:31:47.256354
# Unit test for function wrap_var
def test_wrap_var():
    # Test for all string types
    assert isinstance(wrap_var(b''), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(''), AnsibleUnsafeText)

    # Test for all sequence types
    assert isinstance(wrap_var([]), list)
    assert isinstance(wrap_var(()), tuple)

    # Test for all types that are not strings
    assert wrap_var(None) is None
    assert isinstance(wrap_var(1), int)

    # Test for all types that are mapped to other types
    assert isinstance(wrap_var({}), dict)
    assert isinstance(wrap_var({'key': 'value'}), dict)
    assert isinstance(wrap_var({'key': 'value'}['key']), AnsibleUnsafeText)

# Generated at 2022-06-11 18:31:54.964118
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3

    wrapped_list = wrap_var(['foo', 'bar'])
    assert(isinstance(wrapped_list, list))
    assert('foo' not in wrapped_list)
    assert('bar' not in wrapped_list)
    assert('foo' in wrapped_list[0])
    assert('bar' in wrapped_list[1])

    wrapped_tuple = wrap_var(('foo', 'bar'))
    assert(isinstance(wrapped_tuple, tuple))
    assert('foo' not in wrapped_tuple)
    assert('bar' not in wrapped_tuple)
    assert('foo' in wrapped_tuple[0])
    assert('bar' in wrapped_tuple[1])

    wrapped_dict = wrap_var({'foo': 'bar'})

# Generated at 2022-06-11 18:31:58.076097
# Unit test for function wrap_var
def test_wrap_var():
    d = dict(a=1, b='foo bar')
    d2 = wrap_var(d)
    assert isinstance(d2, AnsibleUnsafe) and d2.__UNSAFE__
    assert isinstance(d['b'], AnsibleUnsafe) and d['b'].__UNSAFE__

# Generated at 2022-06-11 18:32:08.325778
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert type(wrap_var(None)) is type(None)
    assert wrap_var('foo') == 'foo'
    assert type(wrap_var('foo')) is text_type
    assert type(wrap_var(u'foo')) is text_type
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var('foo'.encode('utf8')) == b'foo'
    assert type(wrap_var('foo'.encode('utf8'))) is binary_type

    import datetime
    from decimal import Decimal
    from ansible.module_utils.common.collections import ImmutableDict

    assert type(wrap_var(datetime.datetime.utcnow())) is type(datetime.datetime.utcnow())

# Generated at 2022-06-11 18:32:16.542557
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY2
    import sys

    # if PY2:
    #    assert(isinstance(wrap_var(b"Test"), AnsibleUnsafeBytes))
    assert(isinstance(wrap_var("Test"), AnsibleUnsafeText))
    assert(wrap_var("Test") == AnsibleUnsafeText("Test"))
    assert(isinstance(wrap_var(u"Test"), AnsibleUnsafeText))
    assert(wrap_var(u"Test") == AnsibleUnsafeText(u"Test"))


# Generated at 2022-06-11 18:32:28.548858
# Unit test for function wrap_var
def test_wrap_var():
    import ansible.module_utils.six as six
    import ansible.module_utils.six.moves as smoves
    import types

    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(True), type(True))
    assert isinstance(wrap_var(False), type(False))
    assert isinstance(wrap_var(42), type(42))
    assert isinstance(wrap_var(42.0), type(42.0))
    assert isinstance(wrap_var(u"str"), type(u"str"))
    assert isinstance(wrap_var(b"str"), type(b"str"))

    assert isinstance(wrap_var({}), type({}))
    assert isinstance(wrap_var([]), type([]))

# Generated at 2022-06-11 18:32:36.882267
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(u'foo') == u'foo'
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert wrap_var(b'foo') == b'foo'
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert wrap_var(u'foo'.encode('utf-8')) == b'foo'
    assert isinstance(wrap_var(u'foo'.encode('utf-8')), AnsibleUnsafeBytes)

    assert wrap_var((u'foo', u'bar')) == (u'foo', u'bar')
    assert isinstance(wrap_var((u'foo', u'bar')), tuple)
    assert isinstance(wrap_var((u'foo', u'bar'))[0], AnsibleUnsafeText)



# Generated at 2022-06-11 18:32:47.295492
# Unit test for function wrap_var
def test_wrap_var():
    import pytest

    # wrapped types should have __UNSAFE__ attribute
    assert hasattr(wrap_var("abc"), "__UNSAFE__")
    assert hasattr(wrap_var(b"abc"), "__UNSAFE__")
    assert hasattr(wrap_var(("abc", 1, 2)), "__UNSAFE__")
    assert hasattr(wrap_var(["abc", 1, 2]), "__UNSAFE__")
    assert hasattr(wrap_var({"a": 2, "b": 3}), "__UNSAFE__")
    assert hasattr(wrap_var(set(["a", "b", "c"])), "__UNSAFE__")

    # wrap_var should not wrap values that are already marked as unsafe
    assert wrap_var(AnsibleUnsafeBytes(b"abc")) is Ansible

# Generated at 2022-06-11 18:32:58.504882
# Unit test for function wrap_var
def test_wrap_var():

    import pytest
    from ansible.vars.unsafe_proxy import wrap_var

    # Test case: normal proxy
    test_data = wrap_var("abc")
    assert isinstance(test_data, AnsibleUnsafeText)
    assert test_data == 'abc'

    # Test case: AnsibleUnsafeBytes for a normal string
    test_data = wrap_var(b"abc")
    assert isinstance(test_data, AnsibleUnsafeBytes)
    assert test_data == b'abc'

    # Test case: AnsibleUnsafeText for normal string
    test_data = wrap_var("abc")
    assert isinstance(test_data, AnsibleUnsafeText)
    assert test_data == 'abc'

    # Test case: AnsibleUnsafeText for a None value
    test_data = wrap_var

# Generated at 2022-06-11 18:33:10.544429
# Unit test for function wrap_var
def test_wrap_var():
    o = [1,2,3]
    o[0] = wrap_var(o[0])
    assert isinstance(o[0], AnsibleUnsafe), "wrap_var did not wrap the int"

    o = [1,2,3]
    o = wrap_var(o)
    assert isinstance(o[0], AnsibleUnsafe), "wrap_var did not wrap the list"

    o = {'k1': 1, 'k2': 2}
    o = wrap_var(o)
    assert isinstance(o['k1'], AnsibleUnsafe), "wrap_var did not wrap the dict"

    o = 'string'
    o = wrap_var(o)
    assert isinstance(o, AnsibleUnsafeText), "wrap_var did not wrap the string"

# Generated at 2022-06-11 18:33:17.020920
# Unit test for function wrap_var
def test_wrap_var():
    # test wrap_var for list
    test_list = ['a', 'b', 'c', 1, 2]
    assert wrap_var(test_list)[1] == 'b'
    assert isinstance(wrap_var(test_list), list)
    assert not isinstance(wrap_var(test_list)[1], AnsibleUnsafe)
    assert isinstance(wrap_var(test_list)[3], AnsibleUnsafe)

    # test wrap_var for dict
    test_dict = {'a': 1, 'b': 2, 'c': 'd', 2: '3'}
    assert wrap_var(test_dict)[2] == 'd'
    assert isinstance(wrap_var(test_dict), dict)
    assert not isinstance(wrap_var(test_dict)[2], AnsibleUnsafe)

# Generated at 2022-06-11 18:33:26.928878
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test Python2/3 safe string types
    assert isinstance(wrap_var(text_type('foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(binary_type('foo')), AnsibleUnsafeBytes)

    # Test sequence types
    assert isinstance(wrap_var(tuple('foo')), tuple)
    assert isinstance(wrap_var(set('foo')), set)

    # Test recursive wrapping
    assert isinstance(wrap_var({'foo': ['bar']})['foo'][0], AnsibleUnsafeText)
    assert isinstance(wrap_var([{'bar': 'foo'}, 1, 2, 3]), list)

# Generated at 2022-06-11 18:33:37.752484
# Unit test for function wrap_var
def test_wrap_var():
    fail_list = []
    fail_list_msg = []
    fail_dict = []
    fail_dict_msg = []
    fail_other = []
    fail_other_msg = []

    # test dict
    test_dict = {'a': 'a', 1: 'a', 'a': 1}
    assert _wrap_dict(test_dict) == test_dict
    test_dict = {'a': 'a', 1: 'a', 'a': 1, 'b': '{{test}}'}
    assert _wrap_dict(test_dict) == test_dict

    # test sequence
    test_list = ['a', '1', '2', 3, 4.0, True, None]
    assert _wrap_sequence(test_list) == test_list

# Generated at 2022-06-11 18:33:44.345898
# Unit test for function wrap_var
def test_wrap_var():
    v1 = {"a": 2, "b": None}
    v2 = ["a", "b"]
    v3 = "abc"
    v4 = AnsibleUnsafeText("abc")

    assert wrap_var(v3) == "abc"
    assert wrap_var(v1)["a"] == 2
    assert wrap_var(v2) == ["a", "b"]
    assert wrap_var(v1)["b"] is None
    assert wrap_var(v4) == v4

# Generated at 2022-06-11 18:33:56.598776
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.unsafe_proxy import wrap_var

    # This is a simple example, this should work for all types
    test_var = wrap_var("hello")
    assert isinstance(test_var, AnsibleUnsafeText)
    assert isinstance(test_var, str)
    assert not isinstance(test_var, binary_type)

    test_var = wrap_var(1)
    assert isinstance(test_var, int)
    assert not isinstance(test_var, AnsibleUnsafeText)
    assert test_var == 1

    # test tuple
    test_var = wrap_var(("hello", 1))
    assert isinstance(test_var, tuple)
    assert not isinstance(test_var[0], AnsibleUnsafeText)
    assert isinstance(test_var[1], int)

# Generated at 2022-06-11 18:34:05.503549
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(ansible_unsafe_bytes), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(ansible_unsafe_text), AnsibleUnsafeText)
    assert isinstance(wrap_var(dict()), dict)
    assert isinstance(wrap_var(set()), set)
    assert isinstance(wrap_var(list()), list)
    assert isinstance(wrap_var(NativeJinjaText('')), NativeJinjaUnsafeText)
    assert isinstance(wrap_var(''), AnsibleUnsafeText)

# Generated at 2022-06-11 18:34:13.677424
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_list

    assert isinstance(wrap_var(u"hello world"), AnsibleUnsafeText)
    assert isinstance(wrap_var(b"hello world"), AnsibleUnsafeBytes)

    assert is_list(wrap_var((u"hello world",)))
    assert is_list(wrap_var([u"hello world"]))

    assert isinstance(wrap_var((u"hello world",))[0], AnsibleUnsafeText)
    assert isinstance(wrap_var([u"hello world"])[0], AnsibleUnsafeText)

# Generated at 2022-06-11 18:34:20.967047
# Unit test for function wrap_var
def test_wrap_var():
    import datetime
    assert wrap_var(None) is None
    assert wrap_var(u'foobar') == u'foobar'
    assert wrap_var(u"¿Cómo está, señor?") == u'¿Cómo está, señor?'
    assert wrap_var(u"\u2013") == u'\u2013' # en-dash
    assert wrap_var(u"\U0001F680") == u'\U0001F680' # rocket
    assert wrap_var(u"\U0001F4A9") == u'\U0001F4A9' # pile of poo
    assert wrap_var("\xE2\x88\x9A") == u'\u221a' # square root
    assert wrap_var("\xc3\xbf") == u

# Generated at 2022-06-11 18:34:28.432445
# Unit test for function wrap_var
def test_wrap_var():
    original = 'a string'
    wrapped = wrap_var(original)
    assert isinstance(wrapped, AnsibleUnsafeText)
    assert wrapped == original

    list_original = [
        'a string',
        'another string',
    ]
    list_wrapped = wrap_var(list_original)
    assert isinstance(list_wrapped, list)
    assert isinstance(list_wrapped[0], AnsibleUnsafeText)
    assert list_wrapped == list_original

    tuple_original = (
        'a string',
        'another string',
    )
    tuple_wrapped = wrap_var(tuple_original)
    assert isinstance(tuple_wrapped, tuple)
    assert isinstance(tuple_wrapped[0], AnsibleUnsafeText)
    assert tuple_wrapped == tuple