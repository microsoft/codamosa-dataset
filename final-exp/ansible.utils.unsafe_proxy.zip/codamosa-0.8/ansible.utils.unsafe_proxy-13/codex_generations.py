

# Generated at 2022-06-11 18:31:44.154710
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_sequence

    assert wrap_var("foo") == "foo"
    assert wrap_var(b"foo") == b"foo"

    assert type(wrap_var("foo")) == text_type
    assert type(wrap_var(b"foo")) == binary_type

    assert wrap_var(None) is None
    assert type(wrap_var(None)) == type(None)

    assert is_sequence(wrap_var(("foo", "bar")))
    assert is_sequence(wrap_var([u"foo", u"bar"]))
    assert is_sequence(wrap_var([b"foo", b"bar"]))

    assert is_sequence(wrap_var((b"foo", b"bar")))

# Generated at 2022-06-11 18:31:54.024304
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('string') == 'string'
    assert wrap_var(1) == 1
    assert wrap_var([]) == []
    assert wrap_var(()) == ()
    assert wrap_var(set()) == set()
    assert wrap_var(dict()) == dict()

    assert wrap_var(AnsibleUnsafeText('string')) == AnsibleUnsafeText('string')
    assert wrap_var(AnsibleUnsafeBytes(b'string')) == AnsibleUnsafeBytes(b'string')
    assert wrap_var(AnsibleUnsafeBytes(b'string').decode()) == AnsibleUnsafeText('string')
    assert wrap_var(AnsibleUnsafeText('string').encode()) == AnsibleUnsafeBytes(b'string')


# Generated at 2022-06-11 18:32:03.767446
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils._text import to_text
    from collections import OrderedDict

    # Simple tests
    assert wrap_var(None) is None
    assert wrap_var('hi') == 'hi'
    assert wrap_var(to_bytes(u'hi')) == to_text(u'hi')

    assert wrap_var(3) == 3
    assert wrap_var(3.0) == 3.0
    assert wrap_var(True) is True
    assert wrap_var(True) is True
    assert wrap_var(()) == ()
    assert wrap_var([]) == []
    assert wrap_var({}) == {}
    assert wrap_var(set()) == set()
    assert wrap_var(OrderedDict()) == OrderedDict()

    # Sequence tests

# Generated at 2022-06-11 18:32:13.203635
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var("test") == u"test"
    assert isinstance(wrap_var("test"), AnsibleUnsafeText)
    assert wrap_var("test").__UNSAFE__

    assert wrap_var(b"test") == b"test"
    assert isinstance(wrap_var(b"test"), AnsibleUnsafeBytes)
    assert wrap_var(b"test").__UNSAFE__

    assert wrap_var(3.14) == 3.14
    assert wrap_var(u"test") == u"test"
    assert wrap_var(u"test") == u"test"
    assert wrap_var(unicode("test")) == u"test"
    assert isinstance(wrap_var(unicode("test")), AnsibleUnsafeText)
    assert wrap_var(unicode("test")).__UNSA

# Generated at 2022-06-11 18:32:25.284787
# Unit test for function wrap_var
def test_wrap_var():
    test_unsafe = to_unsafe_text("test_unsafe")
    test_native = NativeJinjaText("test_native")
    test_dict = dict(a=1, b=2)
    test_set = set(["a", "b"])
    test_list = [1, 2, 3]
    test_tuple = (1, 2, 3)

    assert wrap_var(test_unsafe) is test_unsafe
    assert wrap_var(test_native) is not test_native
    assert wrap_var(test_native) is NativeJinjaUnsafeText("test_native")

    assert wrap_var(test_dict) is not test_dict
    for k, v in wrap_var(test_dict).items():
        assert v is wrap_var(test_dict[k])
   

# Generated at 2022-06-11 18:32:35.146775
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var('UnsafeString'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'UnsafeBytes'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(1), type(1))

    result = wrap_var({'safe': 'string', 'unsafe': b'bytes', 1: 'int'})
    assert isinstance(result, dict)
    assert isinstance(result.get('safe'), AnsibleUnsafeText)
    assert isinstance(result.get('unsafe'), AnsibleUnsafeBytes)
    assert isinstance(result.get(1), AnsibleUnsafeText)

    result = wrap_var(['UnsafeString', b'UnsafeBytes', 1])
    assert isinstance(result, list)
   

# Generated at 2022-06-11 18:32:46.352155
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(23) == 23
    assert wrap_var('abc\xc3\xa9 def') == to_text('abc\xc3\xa9 def')
    assert wrap_var(b'abc\xc3\xa9 def') == AnsibleUnsafeBytes(b'abc\xc3\xa9 def')
    assert wrap_var(to_text('abc\xc3\xa9 def')) == to_text('abc\xc3\xa9 def')

    assert isinstance(wrap_var(('a', 'b', 3)), tuple)
    assert isinstance(wrap_var([1, 'abc\xc3\xa9 def', 3]), list)
    assert isinstance(wrap_var({1: 'abc\xc3\xa9 def', 3: 3}), dict)

    assert wrap_var(None) is None

   

# Generated at 2022-06-11 18:32:53.060857
# Unit test for function wrap_var
def test_wrap_var():
    import ansible.constants as C

    assert not isinstance(None, AnsibleUnsafe)
    assert not isinstance('foo', AnsibleUnsafe)
    assert not isinstance(u'foo', AnsibleUnsafe)
    assert not isinstance(b'foo', AnsibleUnsafe)

    assert isinstance(wrap_var(None), AnsibleUnsafe)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafe)
    if C.FORCE_UNSAFE_TEXT:
        assert isinstance(wrap_var(b'foo'), AnsibleUnsafe)

    assert isinstance(wrap_var([u'foo', u'bar']), AnsibleUnsafe)
    assert isinstance(wrap_var((u'foo', u'bar')), AnsibleUnsafe)



# Generated at 2022-06-11 18:33:02.274577
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import string_types
    plain_string = 'this string is not marked as unsafe'
    assert plain_string == wrap_var(plain_string)
    assert isinstance(plain_string, string_types)

    plain_unicode = u'this unicode is not marked as unsafe'
    assert plain_unicode == wrap_var(plain_unicode)
    assert isinstance(plain_unicode, string_types)

    ansible_unsafe_string = AnsibleUnsafeText('this text is marked as unsafe')
    assert ansible_unsafe_string == wrap_var(ansible_unsafe_string)
    assert isinstance(ansible_unsafe_string, string_types)

    ansible_unsafe_unicode = AnsibleUnsafeText(u'this unicode is marked as unsafe')

# Generated at 2022-06-11 18:33:11.508431
# Unit test for function wrap_var
def test_wrap_var():
    assert(wrap_var({"x": "y"}) == {"x": "y"})

    assert(isinstance(wrap_var("x"), AnsibleUnsafeText))
    assert(isinstance(wrap_var(b"x"), AnsibleUnsafeBytes))

    assert(wrap_var("x") == AnsibleUnsafeText("x"))
    assert(wrap_var("x") != "x")

    assert(wrap_var(b"x") == AnsibleUnsafeBytes(b"x"))
    assert(wrap_var(b"x") != b"x")

    assert(wrap_var(None) is None)

    assert(isinstance(wrap_var({"x": AnsibleUnsafeText("y")}), dict))
    assert(isinstance(wrap_var([AnsibleUnsafeText("x")]), list))
   