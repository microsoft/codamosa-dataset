

# Generated at 2022-06-11 18:31:41.616926
# Unit test for function wrap_var
def test_wrap_var():
    wrapped_string = wrap_var("bar")
    assert isinstance(wrapped_string, AnsibleUnsafeText)
    assert wrapped_string == "bar"

    wrapped_int = wrap_var(5)
    assert isinstance(wrapped_int, int)
    assert wrapped_int == 5

    wrapped_dict = wrap_var({"foo": "bar", "baz": 5})
    assert isinstance(wrapped_dict, dict)
    assert wrapped_dict["foo"] == "bar"
    assert wrapped_dict["baz"] == 5

    wrapped_list = wrap_var(["foo", 5])
    assert isinstance(wrapped_list, list)
    assert wrapped_list[0] == "foo"
    assert wrapped_list[1] == 5

    wrapped_tuple = wrap_var(("foo", 5))

# Generated at 2022-06-11 18:31:46.758184
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils._text import to_text
    assert isinstance(wrap_var('string'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'bstring'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var({'a': b'b'}), dict)
    assert isinstance(wrap_var({'a': 'b'}), dict)
    assert isinstance(wrap_var({'a': {'b': 'c'}}), dict)
    assert isinstance(wrap_var([1, 2]), list)
    assert isinstance(wrap_var((1, 2)), tuple)

# Generated at 2022-06-11 18:31:54.757976
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) == None
    assert wrap_var(1) == 1
    assert wrap_var(100.1) == 100.1
    assert wrap_var('answer') == AnsibleUnsafeText(u'answer')
    assert wrap_var(b'answer') == AnsibleUnsafeBytes(b'answer')
    assert wrap_var(u'answer') == AnsibleUnsafeText(u'answer')
    assert wrap_var([u'answer']) == [AnsibleUnsafeText(u'answer')]
    assert wrap_var({u'answer': [u'answer']}) == {AnsibleUnsafeText(u'answer'): [AnsibleUnsafeText(u'answer')]}

# Generated at 2022-06-11 18:32:02.748204
# Unit test for function wrap_var
def test_wrap_var():
    # Ensure we can wrap the various types of objects
    assert isinstance(wrap_var(b"test_bytes"), AnsibleUnsafeBytes)
    assert isinstance(wrap_var("test_string"), AnsibleUnsafeText)
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(True), bool)
    assert isinstance(wrap_var({}), dict)
    assert isinstance(wrap_var(set()), set)
    assert isinstance(wrap_var(()), tuple)
    assert isinstance(wrap_var([]), list)
    # Ensure we don't double wrap
    assert isinstance(wrap_var(b"test_bytes"), AnsibleUnsafeBytes)
    assert isinstance(wrap_var("test_string"), AnsibleUnsafeText)

# Generated at 2022-06-11 18:32:11.670573
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var("foo") == AnsibleUnsafeText("foo")
    assert wrap_var(b"foo") == AnsibleUnsafeBytes("foo")
    assert wrap_var([1, 2]) == [1, 2]
    assert wrap_var((1, 2)) == (1, 2)
    assert wrap_var({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert wrap_var(("a", "b")) == ("a", "b")
    assert wrap_var(set(["a", "b"])) == set(["a", "b"])

# Generated at 2022-06-11 18:32:18.515506
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    display = Display()

    # Test unicode strings
    assert wrap_var('string') == 'string'
    assert wrap_var(u'string') == 'string'
    assert isinstance(wrap_var(u'string'), AnsibleUnsafeText)
    assert isinstance(wrap_var('string'), AnsibleUnsafeText)

    # Test strings encode as utf-8
    assert wrap_var(u'Zo\xe9') == 'Zoé'
    assert isinstance(wrap_var(u'Zo\xe9'), AnsibleUnsafeText)
    assert wrap_var(u'Zo\xe9'.encode('utf-8')) == 'Zoé'

# Generated at 2022-06-11 18:32:30.674675
# Unit test for function wrap_var
def test_wrap_var():
    """Test wrap_var
    """
    # Test wrap_var using a dictionary
    v = {'key1': 'value1', 'key2': 'value2'}
    result = wrap_var(v)
    assert isinstance(result, dict)
    assert isinstance(result['key1'], text_type)
    assert isinstance(result['key2'], text_type)

    # Test wrap_var using a list
    v = ['value1', 'value2']
    result = wrap_var(v)
    assert isinstance(result, list)
    assert isinstance(result[0], text_type)
    assert isinstance(result[1], text_type)

    # Test wrap_var using a set
    v = {'value1', 'value2'}
    result = wrap_var(v)
   

# Generated at 2022-06-11 18:32:41.345181
# Unit test for function wrap_var
def test_wrap_var():
    import datetime
    import re

    # built-ins
    assert wrap_var(None) is None
    assert wrap_var(False) is False
    assert wrap_var(True) is True
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var('a') == u'a'
    assert wrap_var(u'a') == u'a'
    assert wrap_var(b'a') == u'a'
    assert wrap_var(datetime.datetime.now()) == datetime.datetime.now()

    # collections
    assert wrap_var({}) == {}
    assert wrap_var({u'a': 1}) == {u'a': 1}
    assert wrap_var({b'a': 1}) == {u'a': 1}

# Generated at 2022-06-11 18:32:51.253118
# Unit test for function wrap_var
def test_wrap_var():
    import jinja2

    t_string_bytes = b'foo'
    t_string_unicode = u'foo'
    t_dict = {u'key': t_string_bytes}
    t_list = [t_string_bytes, t_string_unicode, t_dict]
    t_tuple = (t_string_bytes, t_string_unicode, t_dict)
    t_set = {t_string_bytes, t_string_unicode, t_dict}
    t_frozenset = frozenset([t_string_bytes, t_string_unicode, t_dict])

    from ansible.utils.display import Display

# Generated at 2022-06-11 18:33:01.435952
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(42) == 42
    assert wrap_var(42.1) == 42.1
    assert wrap_var(True) is True
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var('foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var([b'foo', 'foo', 42, 42.1, True, None]) == [AnsibleUnsafeBytes(b'foo'), AnsibleUnsafeText(u'foo'), 42, 42.1, True, None]
    assert wrap_var({u'foo': b'bar', 42: True}) == {AnsibleUnsafeText(u'foo'): AnsibleUnsafeBytes(b'bar'), 42: True}
    assert wrap_var

# Generated at 2022-06-11 18:33:11.827373
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    import types

    # AnsibleUnsafe is a base class for AnsibleUnsafeText and AnsibleUnsafeBytes,
    # so an object of type AnsibleUnsafe will not pass the proxy object's
    # "isinstance" check.  AnsibleUnsafeText and AnsibleUnsafeBytes are the only
    # safe classes the proxy object will allow.
    unsafe_obj = AnsibleUnsafe()
    assert not isinstance(unsafe_obj, UnsafeProxy)

    str_obj = "foo"
    assert not isinstance(str_obj, UnsafeProxy)

    str_obj = AnsibleUnsafeText(str_obj)
    assert isinstance(str_obj, UnsafeProxy)

    bytes_obj = to_bytes(str_obj)
    bytes_obj = Ansible

# Generated at 2022-06-11 18:33:23.249731
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_sequence
    assert AnsibleUnsafeText('string') == wrap_var('string')
    assert AnsibleUnsafeBytes(b'string') == wrap_var(b'string')
    assert AnsibleUnsafeText('string') == wrap_var(AnsibleUnsafeText('string'))
    assert AnsibleUnsafeBytes(b'string') == wrap_var(AnsibleUnsafeBytes(b'string'))
    assert {'key': 'value'} == wrap_var({'key': 'value'})
    assert {'key': AnsibleUnsafeText('value')} == wrap_var({'key': 'value'})

# Generated at 2022-06-11 18:33:29.476959
# Unit test for function wrap_var
def test_wrap_var():
    import types
    from collections import OrderedDict

    assert AnsibleUnsafeText(u'text') == wrap_var(u'text')
    assert AnsibleUnsafeText(u'test123') == wrap_var(u'test123')
    assert AnsibleUnsafeText(u'') == wrap_var(u'')
    assert AnsibleUnsafeBytes(b'text') == wrap_var(b'text')
    assert AnsibleUnsafeBytes(b'test123') == wrap_var(b'test123')
    assert AnsibleUnsafeBytes(b'') == wrap_var(b'')

    assert wrap_var(None) is None
    assert wrap_var(3.14) == 3.14
    assert wrap_var(42) == 42

# Generated at 2022-06-11 18:33:39.442429
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'.encode('utf-8')), AnsibleUnsafeText)
    assert isinstance(wrap_var(1), int)

    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == b'foo'
    assert wrap_var(AnsibleUnsafeText('foo')) == u'foo'
    assert wrap_var(u'foo') == u'foo'
   

# Generated at 2022-06-11 18:33:43.334482
# Unit test for function wrap_var
def test_wrap_var():
    foo = wrap_var("foo")
    assert isinstance(foo, AnsibleUnsafeText)
    assert foo == "foo"

    foo = wrap_var(b"foo")
    assert isinstance(foo, AnsibleUnsafeBytes)
    assert foo == b"foo"

# Generated at 2022-06-11 18:33:55.897775
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'bar'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'\u2600'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'\xe2\x98\x80'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'\U0001F604'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'\xf0\x9f\x98\x84'), AnsibleUnsafeBytes)
    assert not isinstance(wrap_var({u'foo': u'bar'}), AnsibleUnsafeText)
    assert not isinstance

# Generated at 2022-06-11 18:34:03.462268
# Unit test for function wrap_var
def test_wrap_var():
    import unittest

    class TestWrapVar(unittest.TestCase):

        def setUp(self):
            self.dict_data = {'key1': 'value1', 'key2': 'value2'}
            self.list_data = [1, 2, 'test', 'data']
            self.set_data = set(self.list_data)
            self.unicode_data = to_text(u'\u6b22\u8fce\u4f7f\u7528')
            self.bytes_data = to_bytes(u'\u6b22\u8fce\u4f7f\u7528')
            self.native_jinja_text = NativeJinjaText('test')


# Generated at 2022-06-11 18:34:07.616994
# Unit test for function wrap_var
def test_wrap_var():
    result = wrap_var('test string')
    assert type(result) is AnsibleUnsafeText

    result = wrap_var(b'test string')
    assert type(result) is AnsibleUnsafeBytes

# Generated at 2022-06-11 18:34:17.149938
# Unit test for function wrap_var
def test_wrap_var():
    assert(wrap_var("\u0015") == AnsibleUnsafeBytes("\u0015"))
    assert(wrap_var(None) == None)
    assert(wrap_var(b"abc") == AnsibleUnsafeBytes("abc"))
    assert(wrap_var("abc") == AnsibleUnsafeText("abc"))
    assert(wrap_var(True) == True)
    assert(wrap_var(AnsibleUnsafeText("abc")) == AnsibleUnsafeText("abc"))
    assert(wrap_var("\u1234") == AnsibleUnsafeText("\u1234"))
    assert(wrap_var("\u1234".encode("utf-8")) == AnsibleUnsafeBytes("\u1234".encode("utf-8")))

# Generated at 2022-06-11 18:34:26.563102
# Unit test for function wrap_var
def test_wrap_var():
    import pytest

    class MyTestUnsafe(AnsibleUnsafe):
        pass

    mytu = MyTestUnsafe()
    assert(wrap_var(mytu) is mytu)

    assert(wrap_var(None) is None)

    d = wrap_var({'foo': 'bar'})
    assert(len(d) == 1)
    assert(d['foo'] == 'bar')
    assert(isinstance(d['foo'], AnsibleUnsafeText))

    l = wrap_var(['foo', 'bar'])
    assert(len(l) == 2)
    assert(l[0] == 'foo')
    assert(l[1] == 'bar')
    assert(isinstance(l[0], AnsibleUnsafeText))
    assert(isinstance(l[1], AnsibleUnsafeText))

# Generated at 2022-06-11 18:34:38.567064
# Unit test for function wrap_var
def test_wrap_var():
    # Test strings
    assert isinstance(wrap_var("abc"), AnsibleUnsafeText)
    assert isinstance(wrap_var(b"abc"), AnsibleUnsafeBytes)

    # Test list of mixed strings
    assert isinstance(wrap_var(["abc", b"def", u"ghi"]), list)
    assert isinstance(wrap_var(["abc", b"def", u"ghi"])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var(["abc", b"def", u"ghi"])[1], AnsibleUnsafeBytes)
    assert isinstance(wrap_var(["abc", b"def", u"ghi"])[2], AnsibleUnsafeText)

    # Test tuple of mixed strings

# Generated at 2022-06-11 18:34:49.286597
# Unit test for function wrap_var
def test_wrap_var():
    # custom classes
    class Test1:
        def __repr__(self): return 'Test1()'

    class Test2(AnsibleUnsafe):
        def __repr__(self): return 'Test2()'

    assert wrap_var(None) is None
    assert wrap_var('abc') == 'abc'
    assert wrap_var(b'abc') == AnsibleUnsafeBytes(b'abc')
    assert wrap_var(u'abc') == AnsibleUnsafeText(u'abc')
    assert isinstance(wrap_var(NativeJinjaText(u'abc')), NativeJinjaUnsafeText)
    assert wrap_var(Test1()) == Test1()
    assert wrap_var(Test2()) == Test2()


# Generated at 2022-06-11 18:34:58.804708
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.utils.display import Display
    from ansible.utils.unsafe_proxy import wrap_var

    result = wrap_var(to_text('', errors='surrogate_or_strict'))
    assert isinstance(result, AnsibleUnsafeText)
    assert result == ''

    result = wrap_var(to_bytes('', errors='surrogate_or_strict'))
    assert isinstance(result, AnsibleUnsafeBytes)
    assert result == b''

    result = wrap_var(Display())
    assert isinstance(result, UnsafeProxy)
    assert not isinstance(result, AnsibleUnsafeText)
    assert not isinstance(result, AnsibleUnsafeBytes)


# Generated at 2022-06-11 18:35:05.233301
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import ImmutableDict, ImmutableList

    # Use cases for None or AnsibleUnsafe
    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText('bar')) is AnsibleUnsafeText('bar')

    # Use cases for string
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var('bar') == AnsibleUnsafeText('bar')

    # Use cases for numbers
    assert wrap_var(10) == AnsibleUnsafe(10)
    assert wrap_var(10.5) == AnsibleUnsafe(10.5)

    # Use cases for

# Generated at 2022-06-11 18:35:14.381690
# Unit test for function wrap_var
def test_wrap_var():
    import pytest


# Generated at 2022-06-11 18:35:24.729850
# Unit test for function wrap_var
def test_wrap_var():
    # Test a simple string
    test_string = 'value01'
    assert type(wrap_var(test_string)) == AnsibleUnsafeText
    test_string = AnsibleUnsafeBytes(b'value01')
    assert type(wrap_var(test_string)) == AnsibleUnsafeBytes
    # Test a dictionary
    test_dict = {'key01': 'value01'}
    assert type(wrap_var(test_dict)) == dict
    assert type(wrap_var(test_dict)['key01']) == AnsibleUnsafeText
    # Test a list
    test_list = ['key01', 'value01']
    assert type(wrap_var(test_list)) == list
    assert type(wrap_var(test_list)[0]) == AnsibleUnsafeText

# Generated at 2022-06-11 18:35:35.458901
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY2, PY3
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.six import binary_type, text_type
    import sys

    # Encoding to use for sys.stdout and to_text()
    if PY2:
        encoding = 'ascii'
    else:
        encoding = 'utf-8'

    # Required to make print work when Python 2 is running with -bb
    if PY2 and sys.dont_write_bytecode:
        from ansible.module_utils.six import print_
    else:
        print_ = print

    # A

# Generated at 2022-06-11 18:35:46.172160
# Unit test for function wrap_var
def test_wrap_var():
    import copy
    import sys

    def test_dict(v):
        v['key'] = wrap_var('value')
        v['list'] = wrap_var([1, 2, 3])
        v['tuple'] = wrap_var(tuple(v['list']))
        if sys.version_info < (2, 7):
            v['dict'] = wrap_var(dict(v['list']))
        else:
            v['dict'] = wrap_var(dict(zip([1, 2, 3], [1, 2, 3])))

        # Make sure it returns a copy
        assert v is not wrap_var(v)

        # Make sure it's recursively wrapped
        assert wrap_var(v)['key'] is not v['key']

        # Make sure the type of the variable is preserved

# Generated at 2022-06-11 18:35:54.762605
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_sequence

    assert wrap_var(b'foo') == wrap_var(u'foo')
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)

    assert wrap_var({}) == {}
    assert isinstance(wrap_var({}), dict)

    assert wrap_var([]) == []
    assert isinstance(wrap_var([]), list)

    assert wrap_var(tuple([])) == tuple([])
    assert isinstance(wrap_var(tuple([])), tuple)

    assert wrap_var(set()) == set()
    assert isinstance(wrap_var(set()), set)


# Generated at 2022-06-11 18:36:04.665583
# Unit test for function wrap_var
def test_wrap_var():
    import pytest

    # Create a dictionary containing both strings and unicode strings,
    # which will be used for testing wrap_var()

    test_dict = {'a': 'aaa', 'b': u'bbb'}

    # Test wrap_var() on the dictionary. The returned dictionary should
    # contain wrapped strings.

    wrapped = wrap_var(test_dict)
    assert isinstance(wrapped, dict)
    assert isinstance(wrapped['a'], AnsibleUnsafeText) and isinstance(wrapped['b'], AnsibleUnsafeText)

    # Test __UNSAFE__ for the returned dictionary. The __UNSAFE__ attribute
    # should be set to True for all elements in the dictionary.

    assert wrapped.__UNSAFE__ is True