

# Generated at 2022-06-11 18:31:43.235783
# Unit test for function wrap_var
def test_wrap_var():
    import json

    wrapped = wrap_var('foo')
    if not isinstance(wrapped, AnsibleUnsafeText):
        raise AssertionError("Unsafe wrap failed; expected AnsibleUnsafeText")

    wrapped = wrap_var(b'foo')
    if not isinstance(wrapped, AnsibleUnsafeBytes):
        raise AssertionError("Unsafe wrap failed; expected AnsibleUnsafeBytes")

    wrapped = wrap_var(dict(foo='bar'))
    if not isinstance(wrapped, dict):
        raise AssertionError("Unsafe wrap failed; expected dict")
    elif not isinstance(wrapped.get('foo'), AnsibleUnsafeText):
        raise AssertionError("Unsafe wrap failed; expected AnsibleUnsafeText")


# Generated at 2022-06-11 18:31:53.500498
# Unit test for function wrap_var
def test_wrap_var():
    try:
        import jinja2
    except ImportError:
        raise unittest.SkipTest('jinja2 is not installed')

    class Foo(object):
        pass

    class FooUnsafe(Foo, AnsibleUnsafe):
        pass

    class Bar(object):
        pass

    class BarUnsafe(Bar, AnsibleUnsafe):
        pass

    class Baz(object):
        pass

    class BazUnsafe(Baz, AnsibleUnsafe):
        pass

    foo = Foo()
    foo_unsafe = FooUnsafe()
    bar = Bar()
    bar_unsafe = BarUnsafe()
    baz = Baz()
    baz_unsafe = BazUnsafe()
    b_foo = b'foo'
    b_foo_unsafe = AnsibleUnsafeBytes(b'foo')


# Generated at 2022-06-11 18:32:03.501533
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import Sequence
    # test for unicode string
    assert isinstance(wrap_var('name'), (text_type, AnsibleUnsafeText))
    assert isinstance(wrap_var(u'name'), (text_type, AnsibleUnsafeText))
    # test for native jinja text
    assert isinstance(wrap_var(NativeJinjaText('name')), (text_type, NativeJinjaUnsafeText))
    assert isinstance(wrap_var(NativeJinjaUnsafeText('name')), (text_type, NativeJinjaUnsafeText))
    # test for list
    assert isinstance(wrap_var(['name']), (Sequence, AnsibleUnsafe))
    assert isinstance

# Generated at 2022-06-11 18:32:12.476185
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(True), bool)
    assert isinstance(wrap_var(False), bool)
    assert isinstance(wrap_var(42), int)
    assert isinstance(wrap_var(42.0), float)
    assert isinstance(wrap_var('value'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'value'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var([1, 2, 3]), tuple)
    assert isinstance(wrap_var((1, 2, 3)), tuple)
    assert isinstance(wrap_var({'key': 'value'}), dict)
    assert isinstance(wrap_var(NativeJinjaText('value')), NativeJinjaUnsafeText)

# Generated at 2022-06-11 18:32:24.280954
# Unit test for function wrap_var
def test_wrap_var():
    # Test binary type
    class Binary:
        pass
    binary = Binary()
    binary.value = b'hello'
    assert wrap_var(binary) == binary

    # Test text type
    class Text:
        pass
    text = Text()
    text.value = 'hello'
    assert wrap_var(text) == text

    # Test unicode type
    class Unicode:
        pass
    unicode = Unicode()
    unicode.value = u'hello'
    assert wrap_var(unicode) == unicode

    # Test list
    class List:
        pass
    l = List()
    l.value = [1, 2, 3]
    assert wrap_var(l) == l

    # Test dict
    class Dict:
        pass
    d = Dict()

# Generated at 2022-06-11 18:32:34.395052
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import string_types

    assert wrap_var('foo') == 'foo'

    assert isinstance(wrap_var(u'foo'), string_types)

    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)

    assert isinstance(wrap_var(u'foo'), NativeJinjaText)

    assert isinstance(wrap_var(u'foo'), NativeJinjaUnsafeText)

    assert is_sequence(wrap_var([1, 2, 3]))


# Generated at 2022-06-11 18:32:45.843218
# Unit test for function wrap_var
def test_wrap_var():
    assert "".__class__ == wrap_var("").__class__
    assert type("") == wrap_var("").__class__
    assert type("") == wrap_var(b"").__class__
    assert type(u"") == wrap_var(u"").__class__

    assert "".__class__ != wrap_var(b"").__class__
    assert "".__class__ != wrap_var(u"").__class__

    assert AnsibleUnsafeBytes == wrap_var(b"").__class__
    assert AnsibleUnsafeBytes == wrap_var(u"").__class__
    assert AnsibleUnsafeText == wrap_var(u"").__class__
    assert AnsibleUnsafeText == wrap_var(b"").__class__

    assert [1] == wrap_var([1]).__class__
   

# Generated at 2022-06-11 18:32:52.841533
# Unit test for function wrap_var
def test_wrap_var():

    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.six.moves import input

    class TestObj(object):
        def __init__(self, name):
            self.name = name

        def __unicode__(self):
            return text_type(self.name)

        def __str__(self):
            return self.name

    assert wrap_var(None) is None

    # test str
    assert wrap_var(str('foo')) == AnsibleUnsafeText('foo')

    # test unicode
    assert wrap_var(text_type('foo')) == AnsibleUnsafeText('foo')

    # test object with __unicode__
    assert wrap_var(TestObj('foo')) == AnsibleUnsafeText('foo')

    # test object

# Generated at 2022-06-11 18:32:57.863412
# Unit test for function wrap_var
def test_wrap_var():
    x = {'a': 'abc', 'b': None, 'c': True}
    x['d'] = x
    wrapped_x = wrap_var(x)
    assert wrapped_x['a'] == AnsibleUnsafeBytes('abc')
    assert wrapped_x['b'] is None
    assert wrapped_x['c'] is True

# Generated at 2022-06-11 18:33:07.837948
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var("") is not AnsibleUnsafe
    assert not isinstance("", AnsibleUnsafe)
    assert not isinstance(wrap_var(""), AnsibleUnsafe)
    assert wrap_var("test") is not AnsibleUnsafe
    assert not isinstance("test", AnsibleUnsafe)
    assert not isinstance(wrap_var("test"), AnsibleUnsafe)
    assert wrap_var("test") == "test"
    assert wrap_var("") == ""
    assert wrap_var(["test", "test2"]) is not AnsibleUnsafe
    assert not isinstance(["test", "test2"], AnsibleUnsafe)
    assert not isinstance(wrap_var(["test", "test2"]), AnsibleUnsafe)