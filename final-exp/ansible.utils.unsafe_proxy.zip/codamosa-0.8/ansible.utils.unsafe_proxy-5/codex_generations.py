

# Generated at 2022-06-11 18:31:42.327072
# Unit test for function wrap_var
def test_wrap_var():
    class A:
        pass


# Generated at 2022-06-11 18:31:52.834415
# Unit test for function wrap_var

# Generated at 2022-06-11 18:32:03.101956
# Unit test for function wrap_var
def test_wrap_var():
    import unittest
    import copy

    class Test(unittest.TestCase):
        def test_with_string(self):
            self.assertIsInstance(wrap_var(u"test"), AnsibleUnsafeText)

        def test_with_byte_string(self):
            self.assertIsInstance(wrap_var(b"test"), AnsibleUnsafeBytes)

        def test_with_mapping(self):
            input_map = {u'a': u'b'}
            output_map = wrap_var(input_map)

            self.assertIsInstance(output_map, dict)
            self.assertIsInstance(output_map, AnsibleUnsafe)
            self.assertIsInstance(list(output_map.keys())[0], AnsibleUnsafeText)

# Generated at 2022-06-11 18:32:12.766201
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var('test') == 'test'
    assert wrap_var(u'test') == u'test'
    assert wrap_var(to_unsafe_text('test')) == to_unsafe_text('test')
    assert wrap_var(b'test') == b'test'
    # Note: We're encoding as binary here because there's no good way to get a
    #       a text string that can't be decoded
    assert wrap_var(to_unsafe_bytes(b'test')) == to_unsafe_bytes(b'test')
    assert wrap_var(["a", "b", "c"]) == ["a", "b", "c"]
    assert wrap_var((1, 2, 3)) == (1, 2, 3)
    assert wrap_

# Generated at 2022-06-11 18:32:19.819539
# Unit test for function wrap_var
def test_wrap_var():

    from ansible.module_utils.six import PY2, PY3
    from ansible.module_utils.six.moves import cPickle as pickle

    # a bunch of test objects
    x = 'foo'
    y = {'a': 'b', 'c': ['d', 'e']}

# Generated at 2022-06-11 18:32:30.573619
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'\u0000'), AnsibleUnsafeText)
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == b'foo'
    assert wrap_var(AnsibleUnsafeText(u'foo')) == u'foo'
    assert isinstance(wrap_var(1), int)
    assert isinstance(wrap_var(['a', 'b']), list)
    assert isinstance(wrap_var(('a', 'b')), tuple)
    assert isinstance(wrap_var({'a': 1, 'b': 2}), dict)

# Generated at 2022-06-11 18:32:41.146358
# Unit test for function wrap_var
def test_wrap_var():
    my_tuple = (b"a", "b", 2)
    my_dict = {"key1": 123, "key2": my_tuple}
    my_dict["key3"] = my_dict
    my_dict["key4"] = "value4"
    my_dict["key5"] = AnsibleUnsafeText("value5")
    my_dict["key6"] = "value6"
    my_dict["key7"] = [1, 2, 3]
    my_dict["key8"] = AnsibleUnsafeBytes(b"value8")

    wrapped_dict = wrap_var(my_dict)

    assert isinstance(wrapped_dict["key1"], int)
    assert wrapped_dict["key1"] == 123

    assert isinstance(wrapped_dict["key2"], tuple)

# Generated at 2022-06-11 18:32:51.188219
# Unit test for function wrap_var
def test_wrap_var():
    from collections import OrderedDict
    from ansible.module_utils.six.moves import UserDict
    # collections.namedtuple copies types exactly and so needs to be treated as a special case
    from collections import namedtuple
    class TestNamedTuple(namedtuple('TestNamedTuple', ['a', 'b'])):
        pass


# Generated at 2022-06-11 18:33:01.296848
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_sequence, namedtuple
    # assert no change for already-marked-unsafe types
    assert isinstance(wrap_var(AnsibleUnsafeText(b'foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes(u'foo')), AnsibleUnsafeBytes)
    # assert no change for already-marked-safe types
    assert isinstance(wrap_var(NativeJinjaText(u'foo')), NativeJinjaText)
    # assert no change for basic types
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(0) == 0
    assert wrap_var(1) == 1
    assert wrap

# Generated at 2022-06-11 18:33:10.780197
# Unit test for function wrap_var
def test_wrap_var():
    input = [
        "a",
        'b',
        None,
        {1:2},
        {"a": 1},
        ["a"],
        (1,2),
        {1,2},
        {"a": 1, "b": {"c": [1,2]}}
    ]