

# Generated at 2022-06-11 18:31:40.828683
# Unit test for function wrap_var
def test_wrap_var():
    from collections import OrderedDict
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleSequence, AnsibleMapping

    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(True), type(True))
    assert isinstance(wrap_var(0), type(0))
    assert isinstance(wrap_var(0.0), type(0.0))
    assert isinstance(wrap_var(0 + 0j), type(0 + 0j))
    assert isinstance(wrap_var('a'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'a'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(AnsibleUnsafeText(u'a')), AnsibleUnsafeText)

# Generated at 2022-06-11 18:31:51.613849
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils._text import to_bytes
    unsafe_text = "unsafe"
    input_dict = {"a": unsafe_text}
    input_list = [unsafe_text]
    input_tuple = (unsafe_text)
    input_set = set(input_list)

    assert wrap_var(input_dict) == {"a": AnsibleUnsafeText("unsafe")}
    assert wrap_var(input_list) == [AnsibleUnsafeText("unsafe")]
    assert wrap_var(input_tuple) == (AnsibleUnsafeText("unsafe"),)
    assert wrap_var(input_set) == set([AnsibleUnsafeText("unsafe")])
    assert wrap_var("unicode") == AnsibleUnsafeText("unicode")
    assert wrap_var

# Generated at 2022-06-11 18:32:02.506088
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(123), int)
    assert isinstance(wrap_var(123.4), float)

    assert isinstance(wrap_var('test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'test'), AnsibleUnsafeBytes)

    l_var = [1, 2, 3]
    assert isinstance(wrap_var(l_var), list)
    assert isinstance(wrap_var(l_var)[0], int)
    assert isinstance(wrap_var(l_var)[1], int)
    assert isinstance(wrap_var(l_var)[2], int)

    l_var = [1, 2, '3']

# Generated at 2022-06-11 18:32:10.567444
# Unit test for function wrap_var
def test_wrap_var():
    sequence = ["string", 1, 2, None, {}]
    assert wrap_var(sequence) == ["string", 1, 2, None, {}]

    sequence_unsafe = ["string", 1, 2, None, {}]
    sequence_unsafe[0] = AnsibleUnsafeText("string")
    assert wrap_var(sequence_unsafe) == ["string", 1, 2, None, {}]

    assert wrap_var("string") == "string"
    assert wrap_var(AnsibleUnsafeText("string")) == "string"
    assert wrap_var(AnsibleUnsafeBytes("bytes")) == b"bytes"

# Generated at 2022-06-11 18:32:20.231174
# Unit test for function wrap_var

# Generated at 2022-06-11 18:32:32.043242
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('string') == AnsibleUnsafeText('string')
    assert wrap_var(b'bytes') == AnsibleUnsafeBytes(b'bytes')

    assert wrap_var(u'string') == AnsibleUnsafeText(u'string')
    assert wrap_var(u'bytes') == AnsibleUnsafeBytes(b'bytes')

    assert wrap_var(u'string'.encode('utf-16')) == AnsibleUnsafeBytes(u'string'.encode('utf-16'))
    assert wrap_var(u'string'.encode('utf-16-le')) == AnsibleUnsafeBytes(u'string'.encode('utf-16-le'))

# Generated at 2022-06-11 18:32:42.479416
# Unit test for function wrap_var
def test_wrap_var():
    # noinspection PyProtectedMember
    from ansible.module_utils._text import to_bytes, to_text

    try:
        # noinspection PyUnusedLocal,PyStatementEffect
        from ansible.parsing.yaml.loader import AnsibleLoader
    except ImportError:
        # Lazy loader wasn't added until 2.4
        AnsibleLoader = None

    # Python 3.5 needed for safe_load
    # noinspection PyUnresolvedReferences,PyCompatibility
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # noinspection PyUnresolvedReferences
    from yaml import safe_load, safe_dump

    # flake8 is wrongly reporting to_bytes and to_text as undefined names
    # noinspection PyTypeChecker,PyUnresolvedReferences
    wrapped

# Generated at 2022-06-11 18:32:51.604257
# Unit test for function wrap_var
def test_wrap_var():

    class TestClass(object):
        pass

    class TestSubClass(TestClass):
        pass

    # Sample data set

# Generated at 2022-06-11 18:33:01.778147
# Unit test for function wrap_var
def test_wrap_var():
    import ansible.module_utils.common.collections
    # test when v is None.
    assert(wrap_var(None) is None)
    # test when v is an AnsibleUnsafe* object.
    assert(isinstance(wrap_var(AnsibleUnsafeBytes(b"foo")), AnsibleUnsafeBytes))
    assert(isinstance(wrap_var(AnsibleUnsafeText("foo")), AnsibleUnsafeText))
    # test when v is a mapping object
    assert(isinstance(wrap_var(ansible.module_utils.common.collections.ImmutableDict(foo=b'bar')), ansible.module_utils.common.collections.ImmutableDict))
    # test when v is a list
    assert(isinstance(wrap_var(['foo', b'bar']), list))


# Generated at 2022-06-11 18:33:11.168720
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) == None
    assert wrap_var(False) == False
    assert wrap_var(True) == True
    assert wrap_var(1) == 1
    assert wrap_var('') == u''
    assert wrap_var('test') == u'test'
    assert wrap_var(u'test') == u'test'
    assert wrap_var(u'\u0001') == u'\u0001'
    assert wrap_var(b'\x01') == b'\x01'
    assert isinstance(wrap_var(b'\x01'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'\u0001'), AnsibleUnsafeText)
    assert isinstance(wrap_var({u'a': u'b'}), dict)

# Generated at 2022-06-11 18:33:24.456115
# Unit test for function wrap_var
def test_wrap_var():
    from collections import namedtuple

    assert wrap_var('abc') == 'abc'
    assert wrap_var(b'abc') == b'abc'
    assert isinstance(wrap_var(b'abc'), AnsibleUnsafeBytes)
    assert wrap_var(AnsibleUnsafeText(b'abc')) == b'abc'
    assert wrap_var(AnsibleUnsafeBytes(b'abc')) == b'abc'
    assert wrap_var(123) == 123
    assert wrap_var(['foo', 'bar']) == ['foo', 'bar']
    assert isinstance(wrap_var(['foo', 'bar']), list)
    assert wrap_var(('foo', 'bar')) == ('foo', 'bar')
    assert isinstance(wrap_var(('foo', 'bar')), tuple)
    assert wrap

# Generated at 2022-06-11 18:33:36.474262
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes, AnsibleUnsafeText, NativeJinjaUnsafeText

    # Test for text strings
    assert isinstance(wrap_var('test_text'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'test_text'), AnsibleUnsafeText)
    assert isinstance(wrap_var('test_text'), NativeJinjaUnsafeText)

    # Test for binary strings
    assert isinstance(wrap_var(b'test_binary'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'test_binary'), NativeJinjaUnsafeText)

    # Test for Mapping

# Generated at 2022-06-11 18:33:46.468958
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(1), type(1))
    assert isinstance(wrap_var('1'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'1'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var({}), dict)
    assert isinstance(wrap_var({'a': 'b'}), dict)
    assert isinstance(wrap_var(['a', 'b']), list)
    assert isinstance(wrap_var(('a', 'b')), tuple)
    assert isinstance(wrap_var(set(['a', 'b'])), set)
    assert isinstance(wrap_var(NativeJinjaText('a')), NativeJinjaUnsafeText)

# Generated at 2022-06-11 18:33:58.232460
# Unit test for function wrap_var

# Generated at 2022-06-11 18:34:10.138977
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var("hello"), text_type)
    assert isinstance(wrap_var(b"hello"), binary_type)
    assert isinstance(wrap_var(u"hello"), text_type)
    assert isinstance(wrap_var([u"hello"]), list)
    assert isinstance(wrap_var([b"hello"]), list)
    assert isinstance(wrap_var([u"hello"])[0], text_type)
    assert isinstance(wrap_var([b"hello"])[0], binary_type)
    assert isinstance(wrap_var({u"hello": u"world"}), dict)
    assert isinstance(wrap_var({b"hello": u"world"}), dict)
    assert isinstance(wrap_var({b"hello": b"world"}), dict)

# Generated at 2022-06-11 18:34:18.774075
# Unit test for function wrap_var
def test_wrap_var():
    import datetime
    import re
    import dateutil.parser
    import dateutil.tz

    class C:
        pass

    NoneType = type(None)
    #This is supposed to be a list of all un-wrappable data types that should be returned as is
    un_wrappable_types = [int,
                          float,
                          bool,
                          C,
                          type,
                          type(re.compile('')),
                          NoneType,
                          type(None),
                          datetime.datetime,
                          datetime.timedelta,
                          datetime.time,
                          datetime.date,
                          dateutil.parser.parse('now'),
                          type(dateutil.tz.tzutc()),
                          ]

# Generated at 2022-06-11 18:34:27.592529
# Unit test for function wrap_var
def test_wrap_var():
    import pytest
    from ansible import context
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

    def dict_from_list(list_):
        # Return a dict from the values contained in the passed list.
        return dict((wrap_var(el), wrap_var(el)) for el in list_)

    def dict_from_list_of_tuples(tuples):
        # Return a dict from the values contained in tuple pairs.
        return dict((wrap_var(k), wrap_var(v)) for k, v in tuples)


# Generated at 2022-06-11 18:34:38.500934
# Unit test for function wrap_var
def test_wrap_var():
    # test basic types
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(True), type(True))
    assert isinstance(wrap_var(1), type(1))
    assert isinstance(wrap_var("one"), AnsibleUnsafeText)

    # test list
    assert isinstance(wrap_var(["one", "two"]), list)
    assert isinstance(wrap_var(["one", "two"])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var(["one", "two"])[1], AnsibleUnsafeText)

    # test tuple
    assert isinstance(wrap_var(("one", "two")), tuple)
    assert isinstance(wrap_var(("one", "two"))[0], AnsibleUnsafeText)
    assert isinstance

# Generated at 2022-06-11 18:34:48.438347
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var([u"a", u"b", u"c"]) == [u"a", u"b", u"c"]
    assert wrap_var(u"a") == u"a"
    assert wrap_var(u"a".encode("utf-8")) == u"a"
    assert u"a" == wrap_var(u"a")
    assert u"a" == wrap_var(u"a".encode("utf-8"))
    assert "a" == wrap_var("a")

# Generated at 2022-06-11 18:34:58.497820
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None  # None should stay None
    assert wrap_var('') == ''  # Empty strings should stay empty strings
    assert wrap_var(b'') == b''  # Empty bytes should stay empty
    assert wrap_var(0) == 0  # Numeric values should stay numeric
    assert wrap_var('0') == '0'  # Numeric strings should stay numeric
    assert wrap_var(b'0') == b'0'  # Numeric bytes should stay numeric

    assert wrap_var(AnsibleUnsafeText('foo')) == 'foo'
    assert wrap_var(AnsibleUnsafeBytes(b'bar')) == b'bar'

    assert wrap_var({'foo': 'bar'}) == {'foo': 'bar'}