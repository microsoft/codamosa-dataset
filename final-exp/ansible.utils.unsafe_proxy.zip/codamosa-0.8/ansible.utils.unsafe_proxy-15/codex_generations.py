

# Generated at 2022-06-11 18:31:41.384835
# Unit test for function wrap_var
def test_wrap_var():
    import unittest
    import sys

    import ansible.module_utils.basic

    if sys.version_info < (2, 7):
        import unittest2 as unittest

    class TestWrapVar(unittest.TestCase):

        def test_wrap_var_none(self):
            v = wrap_var(None)
            self.assertIsNone(v, 'Failed to wrap None')

        def test_wrap_var_bool(self):
            v = wrap_var(True)
            self.assertTrue(v, 'Failed to wrap True')

        def test_wrap_var_bytes(self):
            v = wrap_var(b'foo')
            self.assertIsInstance(v, AnsibleUnsafeBytes, 'Failed to wrap bytes')


# Generated at 2022-06-11 18:31:52.090404
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    Display().deprecated(
        'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )

    def assert_unsafe_type(v):
        assert isinstance(v, AnsibleUnsafe)

    v1 = UnsafeProxy('foo')
    v2 = UnsafeProxy(b'bar')
    v12 = UnsafeProxy([v1, v2])

    # Redefine assert unsafe text to convert a value to text
    def assert_unsafe_text(v):
        v = to_text(v)
        assert isinstance(v, AnsibleUnsafeText)


# Generated at 2022-06-11 18:32:02.826801
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    display = Display()

    # Wrap an integer
    result = wrap_var(10)
    display.debug("Result: '%s'", result)
    assert result == 10

    # Wrap an integer in a sequence
    result = wrap_var([10, 'key', 'value'])
    display.debug("Result: '%s'", result)
    assert isinstance(result, list)
    assert result == [10, u'key', u'value']

    # Wrap an integer in a tuple
    result = wrap_var((10, 'key', 'value'))
    display.debug("Result: '%s'", result)
    assert isinstance(result, tuple)
    assert result == (10, u'key', u'value')

    # Wrap an integer in a set
    result

# Generated at 2022-06-11 18:32:12.544819
# Unit test for function wrap_var
def test_wrap_var():
    import pytest

    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common.collections import is_sequence

    class DummyUnsafe(object):
        __UNSAFE__ = True

    class DummyUnsafeBytes(binary_type, DummyUnsafe):
        def decode(self, *args, **kwargs):
            return DummyUnsafeText(super(DummyUnsafeBytes, self).decode(*args, **kwargs))

    class DummyUnsafeText(text_type, DummyUnsafe):
        def encode(self, *args, **kwargs):
            return DummyUnsafeBytes(super(DummyUnsafeText, self).encode(*args, **kwargs))



# Generated at 2022-06-11 18:32:24.383728
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(False) is False
    assert wrap_var(123) == 123
    assert isinstance(wrap_var(u"test"), AnsibleUnsafeText)
    assert isinstance(wrap_var(b"test"), AnsibleUnsafeBytes)
    assert wrap_var(u"test") == u"test"
    assert wrap_var(b"test") == b"test"
    assert wrap_var(u"test") != b"test"
    assert isinstance(wrap_var(u"test".encode('utf-8')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var({'foo': 'bar'}), dict)
    assert isinstance(wrap_var({'foo': 'bar'})['foo'], AnsibleUnsafeText)

# Generated at 2022-06-11 18:32:32.392291
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var("foo") is not "foo"
    assert wrap_var(u"foo") is not u"foo"
    assert wrap_var(None) is None
    assert wrap_var(1) is 1
    assert wrap_var(['one', 'two']) is not ['one', 'two']
    assert wraps_var(('one', 'two')) is not ('one', 'two')
    assert wrap_var({'key': 'value'}) is not {'key': 'value'}
    assert wrap_var({"key": "value"}) is not {"key": "value"}


# Generated at 2022-06-11 18:32:38.658509
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(42) == 42
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var({'foo': 'bar'}) == dict(foo=AnsibleUnsafeText('bar'))
    assert wrap_var(['foo', 42, {'bar': b'baz'}]) == [AnsibleUnsafeText('foo'), 42, dict(bar=AnsibleUnsafeBytes(b'baz'))]

# Generated at 2022-06-11 18:32:47.801982
# Unit test for function wrap_var
def test_wrap_var():
    import jinja2

    number_data = 0
    string_data = b"Test Bytes\x01\x02\x03"
    text_data = u"Test Unicode"
    jinja_data = jinja2.Markup("Testing Jinja2")

    list_data = [number_data, string_data, text_data, jinja_data]
    tuple_data = tuple(list_data)
    dict_data = {1: list_data, 2: tuple_data}
    set_data = set(list_data)

    for obj in (number_data, string_data, text_data, jinja_data, list_data, tuple_data, dict_data, set_data):
        assert wrap_var(obj) == obj


# Generated at 2022-06-11 18:32:58.921946
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import string_types

    assert isinstance(wrap_var(None), AnsibleUnsafe)
    assert isinstance(wrap_var('bytes'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'text'), AnsibleUnsafeText)

    # Test sequences
    assert isinstance(wrap_var([]), list)
    assert isinstance(wrap_var(()), tuple)
    assert isinstance(wrap_var({}), dict)
    assert isinstance(wrap_var(set()), set)

    l = [None, 'bytes', u'text', [None], ('bytes',), ({u'text': None},)]
    l2 = ('bytes', u'text', [None], ('bytes',), ({u'text': None},))

# Generated at 2022-06-11 18:33:08.120957
# Unit test for function wrap_var
def test_wrap_var():
    def safe_str(x):
        return isinstance(x, AnsibleUnsafe)

    def safe_dict(d):
        for v in d.values():
            if not safe_str(v):
                return False
        return True

    assert safe_str(wrap_var('foo'))
    assert safe_dict(wrap_var({'foo': 'bar'}))
    assert safe_str(wrap_var(u'bar'))
    assert safe_dict(wrap_var({u'bar': 'foo'}))
    assert not safe_str(wrap_var(b'bar'))
    assert not safe_dict(wrap_var({b'bar': 'foo'}))
    assert safe_dict(wrap_var({b'bar': b'foo'}))


# ----------------
# function mock_inject_content


# Generated at 2022-06-11 18:33:16.564569
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import string_types
    import copy
    # Check various strings types
    test_str = 'test'
    wrapped = wrap_var(test_str)
    assert isinstance(wrapped, string_types)
    assert wrapped == 'test'
    assert isinstance(copy.copy(wrapped), string_types)

    wrapped = wrap_var(b'test')
    assert isinstance(wrapped, string_types)
    assert wrapped == 'test'
    assert isinstance(copy.copy(wrapped), string_types)

    wrapped = wrap_var(u'test')
    assert isinstance(wrapped, string_types)
    assert wrapped == 'test'
    assert isinstance(copy.copy(wrapped), string_types)

# Generated at 2022-06-11 18:33:26.901367
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(True) == True
    assert wrap_var(False) == False
    assert wrap_var('noop') == b'noop'
    assert wrap_var(u'noop') == b'noop'
    assert wrap_var(b'noop') == u'noop'
    assert wrap_var(1) == 1
    assert wrap_var(2.0) == 2.0
    assert wrap_var([1, 2, 3]) == [1, 2, 3]
    assert wrap_var(u'test') == u'test'
    assert wrap_var('test') == u'test'
    assert wrap_var('\u00f6\u00e4\u00fc') == u'\xf6\xe4\xfc'

# Generated at 2022-06-11 18:33:37.750238
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    display = Display()
    a = {b"name1": b"value1", b"name2": b"value2"}
    b1 = b"value1"
    b2 = b"value2"
    c = {'name1': 'value1', 'name2': 'value2'}
    d = {b"name1": b"value1", 'name2': 'value2'}
    e = {b"name1": {b"name1": b"value2"}, 'name2': 'value2'}

    res1 = wrap_var(a)
    res2 = wrap_var(b1)
    res3 = wrap_var(b2)
    res4 = wrap_var(c)
    res5 = wrap_var(d)

# Generated at 2022-06-11 18:33:48.792377
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import string_types, binary_type, text_type
    from ansible.utils.display import Display

    try:
        from ansible.utils.unsafe_proxy import UnsafeProxy as _UnsafeProxy
        Display().deprecated(
            'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
            version='2.13', collection_name='ansible.builtin'
        )
    except ImportError:
        _UnsafeProxy = wrap_var

    assert wrap_var(None) is None


# Generated at 2022-06-11 18:33:53.411508
# Unit test for function wrap_var
def test_wrap_var():
    import datetime

    print("Starting test_wrap_var")

    # Normal string should be unchanged
    wrapped_str = wrap_var("test")
    assert isinstance(wrapped_str, AnsibleUnsafeText)
    assert isinstance(wrapped_str, text_type)
    assert wrapped_str == "test"

    # Unicode string should be unchanged
    wrapped_unicode = wrap_var(u"test")
    assert isinstance(wrapped_unicode, AnsibleUnsafeText)
    assert isinstance(wrapped_unicode, text_type)
    assert wrapped_unicode == u"test"

    # Lists should be wrapped
    wrapped_list = wrap_var([1, 2, 3])
    assert isinstance(wrapped_list, list)
    assert wrapped_list[0] == 1
    assert wrapped_list

# Generated at 2022-06-11 18:34:02.447376
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(u'\u4321') == u'\u4321'
    assert wrap_var(b'\xed\xa0\x80') == b'\xed\xa0\x80'
    assert wrap_var([1, 2]) == [1, 2]
    assert wrap_var({u'\u4321': u'\u4322'}) == {u'\u4321': u'\u4322'}
    assert wrap_var([b'\xed\xa0\x80']) == [b'\xed\xa0\x80']

# Generated at 2022-06-11 18:34:14.003393
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY2, PY3
    from collections import Mapping, Set

    u_map = {"key": u"beta", u"key2": [u"beta", u"charlie"]}
    if PY2:
        b_map = {"key": "beta", "key2": ["beta", "charlie"]}
    if PY3:
        b_map = {"key": "beta", "key2": [b"beta", b"charlie"]}

    u_wrapped_map = _wrap_dict(u_map)
    b_wrapped_map = _wrap_dict(b_map)

    assert isinstance(u_wrapped_map[u"key"], text_type)

# Generated at 2022-06-11 18:34:24.253903
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    display = Display()
    # the use of the ++ operator has been deprecated in the development version of python and
    # generates a warning for py3
    # let's disable the warning for py3 so we don't confuse users if they run the test suite
    if display.verbosity > 5:
        import warnings
        warnings.filterwarnings(action='ignore', module='.*', category=DeprecationWarning)
    import pytest
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import string_types, binary_type, text_type
    assert not isinstance(UnsafeProxy('hello'), AnsibleUnsafe)
    assert UnsafeProxy('hello') == 'hello'
    assert wrap_var('hello') == 'hello'

# Generated at 2022-06-11 18:34:30.206795
# Unit test for function wrap_var
def test_wrap_var():
    import json
    unittest = AnsibleUnsafeText('{"k1": "v1", "k2": "v2"}')
    unittest2 = json.loads(to_text(unittest))
    assert not isinstance(unittest2, AnsibleUnsafe)
    assert isinstance(wrap_var(unittest), AnsibleUnsafe)

# Generated at 2022-06-11 18:34:39.980195
# Unit test for function wrap_var
def test_wrap_var():
    strings = [
        u'string',
        b'string'
    ]

    for s in strings:
        assert wrap_var(s) == s

    assert wrap_var(None) is None

    # Test mapping
    from ansible.utils.display import Display
    from ansible.module_utils.common.collections import is_sequence

    display = Display()
    modules = display._ipython_display_formatter_default.module_formatter

    f = modules.formatters[modules.text_type_key]
    assert isinstance(f(None, wrap_var({})), NativeJinjaUnsafeText)

    # Test list
    assert is_sequence(wrap_var([]))
    assert is_sequence(wrap_var(()))


# Generated at 2022-06-11 18:34:50.535742
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class TestWrapVar(unittest.TestCase):
        def test_wrap_none(self):
            # Check that wrap_var(None) returns AnsibleUnsafe object
            self.assertTrue(isinstance(wrap_var(None), AnsibleUnsafe))

        def test_wrap_string(self):
            # Check that wrap_var(str) returns AnsibleUnsafeText object
            self.assertTrue(isinstance(wrap_var('foo'), AnsibleUnsafeText))


# Generated at 2022-06-11 18:34:58.922277
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence

    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(1) == 1
    assert wrap_var(b'foobar') == b'foobar'
    assert isinstance(wrap_var(u'foobar'), text_type)

    assert isinstance(wrap_var(dict(foo=u'foobar')), MutableMapping)
    assert isinstance(wrap_var(dict(foo=u'foobar').values()), MutableSequence)

    assert isinstance(wrap_var([u'foobar']), MutableSequence)
    assert isinstance(wrap_var((u'foobar',)), tuple)


# Generated at 2022-06-11 18:35:05.289784
# Unit test for function wrap_var
def test_wrap_var():
    a = 'abc'
    b = wrap_var(a)
    assert a == b
    assert type(b) == AnsibleUnsafeText

    a = b'abc'
    b = wrap_var(a)
    assert a == b
    assert type(b) == AnsibleUnsafeBytes

    a = (1, 2, 'abc')
    b = wrap_var(a)
    assert a == b
    assert type(b) == tuple

    b0 = b[0]
    assert a[0] == b0
    assert type(b0) == int

    b2 = b[2]
    assert a[2] == b2
    assert type(b2) == AnsibleUnsafeText

    a = [1, 2, 'abc']
    b = wrap_var(a)
    assert a == b

# Generated at 2022-06-11 18:35:14.415780
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import is_sequence

    # test Python 3.5 dict ordering
    dict5 = dict([(i, i) for i in range(5)])
    dict5_wrapped = wrap_var(dict5)
    assert dict5 == dict5_wrapped
    assert isinstance(dict5_wrapped[0], AnsibleUnsafeText)

    # test Python 2.7 dict ordering
    dict2 = dict([(to_bytes(i), to_bytes(i)) for i in range(2)])
    dict2_wrapped = wrap_var(dict2)
    assert dict2 == dict2_wrapped

# Generated at 2022-06-11 18:35:24.767176
# Unit test for function wrap_var
def test_wrap_var():
    import datetime
    orig = dict(
        a=1234,
        b=[1, 2, 3, 4],
        c=True,
        d=object(),
        e=to_bytes('\x80'),
        f=to_bytes('\x80'.decode('utf-8')),
        g=1.0,
        h=set([1, 2, 3, 4]),
        i={'a': 1, 'b': 2},
        j=datetime.datetime(2012, 12, 12),
    )

    safe = wrap_var(orig)

    assert isinstance(safe['a'], AnsibleUnsafeBytes)
    assert safe['a'] == orig['a']

    assert isinstance(safe['b'], list)
    assert safe['b'] == orig['b']


# Generated at 2022-06-11 18:35:35.446673
# Unit test for function wrap_var
def test_wrap_var():
    import sys
    import json
    if sys.version_info > (3,):
        unicode = str

# Generated at 2022-06-11 18:35:46.172248
# Unit test for function wrap_var
def test_wrap_var():
    for test_item in [b'foo', u'bar', [b'baz', u'qux'], {b'key1': b'the quick brown fox'}, {u'key2': u'jumps over'}]:
        assert wrap_var(test_item) is not test_item

    assert wrap_var(False) is False
    assert wrap_var(True) is True
    assert wrap_var(0) is 0
    assert wrap_var(1) is 1

    assert type(wrap_var(b'foo')) is AnsibleUnsafeBytes
    assert type(wrap_var(u'bar')) is AnsibleUnsafeText
    assert type(wrap_var([b'baz', u'qux'])) is tuple

# Generated at 2022-06-11 18:35:54.766632
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader

    module = AnsibleModule(
        argument_spec = dict(
            # Dict
            d1 = dict(type='dict'),
            # List
            d2 = dict(type='list'),
            # String
            d3 = dict(type='str'),
        )
    )

    inputs = dict(
        d1 = {'a': 1, 'b': 2, 'c': 3},
        d2 = ['a', 'b', 'c'],
        d3 = 'd',
    )

    loader = DataLoader()
    module.params.update(loader.load(module.params, inputs, {}))

    # Test that we can wrap a dict and that it comes out as a dict
   

# Generated at 2022-06-11 18:36:02.081905
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(1) == 1
    assert wrap_var([1, 'foo']) == [1, u'foo']
    assert wrap_var({'bam': 'bar'}) == {u'bam': u'bar'}
    assert wrap_var(u'foo') == u'foo'
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert not isinstance(wrap_var(1), AnsibleUnsafeText)

# Generated at 2022-06-11 18:36:11.235928
# Unit test for function wrap_var
def test_wrap_var():
    import pytest
    as_bytes = to_unsafe_bytes(b'\x00\xff')
    as_text = to_unsafe_text(u'\u0000\uffff')

    assert isinstance(as_bytes, AnsibleUnsafeBytes)
    assert isinstance(as_text, AnsibleUnsafeText)

    assert isinstance(wrap_var(b'\x00\xff'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'\u0000\uffff'), AnsibleUnsafeText)

    assert wrap_var(as_bytes) is as_bytes
    assert wrap_var(as_text) is as_text

    assert wrap_var([b'\x00\xff'])[0] is as_bytes

# Generated at 2022-06-11 18:36:21.748384
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var("hello"), binary_type)
    assert isinstance(wrap_var(to_unsafe_bytes("hello")), binary_type)
    assert isinstance(wrap_var(to_unsafe_text("hello")), text_type)
    assert isinstance(wrap_var({b"k": b"v"}), dict)
    assert isinstance(wrap_var({b"k": b"v"})[b"k"], binary_type)
    assert isinstance(wrap_var([b"v"]), list)
    assert isinstance(wrap_var([b"v"])[0], binary_type)
    assert isinstance(wrap_var({"k": "v"}), dict)

# Generated at 2022-06-11 18:36:29.819990
# Unit test for function wrap_var
def test_wrap_var():
    import ansible.module_utils.six as six
    assert isinstance(wrap_var('hello'), six.text_type)
    assert isinstance(wrap_var(u'hello'), six.text_type)
    assert isinstance(wrap_var(b'hello'), six.binary_type)
    assert isinstance(wrap_var(b'\xc3\xbc'), six.text_type)
    assert isinstance(wrap_var(u'\xc3\xbc'), six.text_type)
    assert isinstance(wrap_var({'hello': 'world'}), dict)
    assert isinstance(wrap_var([1, 2]), list)
    assert isinstance(wrap_var((1, 2)), tuple)


# Generated at 2022-06-11 18:36:37.652930
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None

    # wrap strings
    assert isinstance('', AnsibleUnsafeText)
    assert wrap_var('') == AnsibleUnsafeText('')
    assert isinstance(wrap_var(''), AnsibleUnsafeText)

    # wrap list
    assert isinstance([], list)
    assert wrap_var([]) == []
    assert isinstance(wrap_var([]), list)

    # wrap dictionary
    assert isinstance({}, dict)
    assert wrap_var({}) == {}
    assert isinstance(wrap_var({}), dict)

    # wrap boolean
    assert isinstance(True, bool)
    assert wrap_var(True) is True
    assert isinstance(wrap_var(True), bool)

    # wrap numeric
    assert isinstance(1, int)
    assert wrap

# Generated at 2022-06-11 18:36:48.977208
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.compat.tests import unittest
    from ansible.utils.unsafe_proxy import wrap_var, AnsibleUnsafeText
    import json

    class TestSafeProxy(unittest.TestCase):
        def setUp(self):
            self.input = {
                'key': 'value',
                'key2': [2, 3, 4],
                'key3': {
                    'key5': 'value5'
                }
            }
            self.output = {
                'key': AnsibleUnsafeText('value'),
                'key2': [AnsibleUnsafeText('2'), AnsibleUnsafeText('3'), AnsibleUnsafeText('4')],
                'key3': {
                    'key5': AnsibleUnsafeText('value5')
                }
            }


# Generated at 2022-06-11 18:36:58.033183
# Unit test for function wrap_var
def test_wrap_var():
    import copy
    import ansible.module_utils.six as six
    from types import ModuleType
    from ansible.module_utils.common.collections import Mapping, Sequence

    # Test None value
    result = wrap_var(None)
    assert result == None

    # Test unicode value
    result = wrap_var(six.u('unicøde'))
    assert isinstance(result, AnsibleUnsafeText)
    assert six.u('unicøde') == result

    # Test bytes value
    result = wrap_var(six.b('unicøde'))
    assert isinstance(result, AnsibleUnsafeBytes)
    assert six.b('unicøde') == result

    # Test empty mapping
    result = wrap_var({})
    assert isinstance(result, dict)
    assert result == {}

    #

# Generated at 2022-06-11 18:37:09.172650
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import assertCountEqual, assertSequenceEqual, assertIsInstance, assertIsInstance
    from ansible.module_utils.six.moves import set

    assertCountEqual([wrap_var(item) for item in [1, 2, 3]], [1, 2, 3])

    test = (1, 2, 3)
    assertSequenceEqual(wrap_var(test), test)
    test = [1, 2, 3]
    assertSequenceEqual(wrap_var(test), test)
    test = set([1, 2, 3])
    assertCountEqual(wrap_var(test), test)

    test = {'foo': 'bar', 'aaa': 'bbb', 'x': 5}
    assertCountEqual(wrap_var(test), test)

# Generated at 2022-06-11 18:37:14.867777
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(1), int)
    assert isinstance(wrap_var(1), int)
    assert isinstance(wrap_var(True), bool)
    assert isinstance(wrap_var([]), list)
    assert isinstance(wrap_var(()), tuple)
    assert isinstance(wrap_var({}), dict)
    assert isinstance(wrap_var(u'foobar'), text_type)
    assert isinstance(wrap_var('\x00\xFF'), AnsibleUnsafeBytes)



# Generated at 2022-06-11 18:37:24.005871
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import Mapping, Set
    assert isinstance(wrap_var("foobar"), AnsibleUnsafeText)
    assert isinstance(wrap_var(u"foobar"), AnsibleUnsafeText)
    assert isinstance(wrap_var({"foobar": "baz"}), dict)
    assert isinstance(wrap_var({"foobar": u"baz"}), dict)
    assert isinstance(wrap_var(["foobar", "baz"]), list)
    assert isinstance(wrap_var([u"foobar", "baz"]), list)
    assert isinstance(wrap_var(("foobar", "baz")), tuple)
    assert isinstance(wrap_var((u"foobar", "baz")), tuple)

# Generated at 2022-06-11 18:37:32.384207
# Unit test for function wrap_var
def test_wrap_var():

    assert(wrap_var(None) is None)

    assert(wrap_var("") == "")
    assert(wrap_var("foo") == "foo")
    assert(wrap_var(b"") == b"")
    assert(wrap_var(b"foo") == b"foo")
    assert(wrap_var(AnsibleUnsafeText("")) == "")
    assert(wrap_var(AnsibleUnsafeBytes(b"")) == b"")

    assert(wrap_var(NativeJinjaText("foo")) == "foo")

    assert(wrap_var(u"") == "")
    assert(wrap_var(u"foo") == "foo")
    assert(wrap_var(NativeJinjaText(u"foo")) == "foo")


# Generated at 2022-06-11 18:37:37.885062
# Unit test for function wrap_var