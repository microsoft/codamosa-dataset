

# Generated at 2022-06-11 18:31:41.484550
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')

    assert wrap_var({'foo': 'bar'}) == {AnsibleUnsafeText('foo'): AnsibleUnsafeText('bar')}
    assert wrap_var({AnsibleUnsafeText('foo'): AnsibleUnsafeText('bar')}) == {AnsibleUnsafeText('foo'): AnsibleUnsafeText('bar')}

# Generated at 2022-06-11 18:31:47.397000
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('text') == AnsibleUnsafeText('text')
    assert wrap_var(b'bytes') == AnsibleUnsafeBytes(b'bytes')

    assert wrap_var(dict(a=1, b=2)) == dict(a=1, b=2)
    assert wrap_var([1, 2, 3]) == [1, 2, 3]
    assert wrap_var(set([1, 2, 3])) == set([1, 2, 3])
    assert wrap_var((1, 2, 3)) == (1, 2, 3)

    assert wrap_var(dict(a=1, b='text')) == dict(a=1, b=AnsibleUnsafeText('text'))
    assert wrap_var([1, 'text', 3]) == [1, AnsibleUnsafeText('text'), 3]

# Generated at 2022-06-11 18:31:55.020620
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.basic import AnsibleUnsafeText, AnsibleUnsafeBytes, AnsibleUnsafe
    import types


# Generated at 2022-06-11 18:32:03.173860
# Unit test for function wrap_var
def test_wrap_var():
    import json
    import jinja2

    # Test that the items in the returned dict is wrapped
    result = wrap_var({1: 2, 'a': 'b'})
    assert isinstance(result, dict)
    assert isinstance(result[1], AnsibleUnsafeBytes)
    assert isinstance(result['a'], AnsibleUnsafeBytes)
    assert result['a'] == AnsibleUnsafeBytes(b'b')

    # Test that the items in the returned list is wrapped
    result = wrap_var([1, 2, 'a', 'b'])
    assert isinstance(result, list)
    assert isinstance(result[2], AnsibleUnsafeBytes)
    assert result[2] == AnsibleUnsafeBytes(b'a')
    assert isinstance(result[3], AnsibleUnsafeBytes)
    assert result

# Generated at 2022-06-11 18:32:11.784200
# Unit test for function wrap_var
def test_wrap_var():
    # Some values should return the original value
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(True) is True
    assert wrap_var(False) is False

    # Mappings and UnsafeText should return the same type
    assert isinstance(wrap_var({}), dict)
    assert isinstance(wrap_var(AnsibleUnsafeText('')), AnsibleUnsafeText)

    # Sequences should return the same type
    assert isinstance(wrap_var(()), tuple)
    assert isinstance(wrap_var([]), list)
    assert isinstance(wrap_var(set()), set)

# Generated at 2022-06-11 18:32:19.192243
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(to_bytes("cow")), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(to_text("cow")), AnsibleUnsafeText)
    assert wrap_var(to_unsafe_bytes("cow")) is to_unsafe_bytes("cow")
    assert wrap_var(to_unsafe_text("cow")) is to_unsafe_text("cow")
    d = {'a': {'b': to_text('c')},
         'd': [to_text('e'), 'f'],
         'g': {'h': to_unsafe_text('i')}}

    wrapped = wrap_var(d)
    assert isinstance(wrapped, Mapping)
    assert isinstance(wrapped['a'], Mapping)

# Generated at 2022-06-11 18:32:31.098386
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var('abc') == AnsibleUnsafeText('abc')
    assert wrap_var(b'abc') == AnsibleUnsafeBytes(b'abc')
    assert wrap_var(u'abc') == AnsibleUnsafeText(u'abc')
    assert wrap_var(u'{{a}}') == NativeJinjaUnsafeText(u'{{a}}')
    assert wrap_var(['a', 'b', 'c']) == [AnsibleUnsafeText('a'), AnsibleUnsafeText('b'), AnsibleUnsafeText('c')]

# Generated at 2022-06-11 18:32:38.059376
# Unit test for function wrap_var
def test_wrap_var():
    from unittest import TestCase

    class WrapVarTest(TestCase):

        def test_basic(self):
            target = AnsibleUnsafeText(b'foo')
            result = wrap_var(target)
            self.assertEqual(result, target)

        def test_none(self):
            result = wrap_var(None)
            self.assertEqual(result, None)

        def test_dict(self):
            d = {'k': 'v'}
            result = wrap_var(d)
            self.assertNotEqual(result, d)
            self.assertEqual(dict, type(result))
            self.assertTrue(isinstance(result['k'], AnsibleUnsafeText))

        def test_list(self):
            l = ['k']
            result = wrap_var(l)

# Generated at 2022-06-11 18:32:47.599533
# Unit test for function wrap_var
def test_wrap_var():
    import pytest
    from ansible.module_utils.six import PY3

    def unwrap(v):
        """Wrapper for testing 'unwrapped' values, this is needed so that
        we can detect when non-string types are not converted to a string.
        """
        return v.__dict__.get('_obj') if not isinstance(v, string_types) else v

    # Test simple strings
    assert unwrap(wrap_var('hi')) == 'hi'

    # Test simple tuples and lists
    assert unwrap(wrap_var(('a', 'b', 'c'))) == ('a', 'b', 'c')
    assert unwrap(wrap_var(['a', 'b', 'c'])) == ['a', 'b', 'c']

    # Test sets

# Generated at 2022-06-11 18:32:58.758823
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common.collections import is_sequence

    def test_unsafe_types(v):
        if isinstance(v, string_types):
            assert isinstance(v, AnsibleUnsafeText)
        elif is_sequence(v):
            assert isinstance(v, (tuple, list))
            for el in v:
                test_unsafe_types(el)
        elif isinstance(v, dict):
            for k, v2 in v.items():
                test_unsafe_types(k)
                test_unsafe_types(v2)


# Generated at 2022-06-11 18:33:07.002574
# Unit test for function wrap_var
def test_wrap_var():
    v_test_list = [
        {'a': 'test1', 'b': 'test2', 'c': [1, 2, 3], 'd': {'a': 'testd'}, 'e': True, 'f': u'test', 'g': b'test'},
        'test',
        [1, 2, 3, 4],
        1,
        u'test',
        b'test',
        True
    ]

    for v in v_test_list:
        assert wrap_var(v) != v
        assert wrap_var(wrap_var(v)) == wrap_var(v)

# Generated at 2022-06-11 18:33:14.526175
# Unit test for function wrap_var
def test_wrap_var():
    assert(wrap_var('foo') == AnsibleUnsafe('foo'))
    assert(wrap_var('foo'.encode()) == AnsibleUnsafe(b'foo'))
    assert(wrap_var('foo'.encode()).decode() == AnsibleUnsafe('foo'))
    assert(wrap_var(['foo', 'foo1']) == AnsibleUnsafe(['foo', 'foo1']))
    assert(wrap_var(('foo', 'foo1')) == AnsibleUnsafe(('foo', 'foo1')))
    assert(wrap_var({'foo': 'foo'}) == AnsibleUnsafe({'foo': 'foo'}))

# Generated at 2022-06-11 18:33:19.821663
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(42), int)
    assert isinstance(wrap_var({42: None}), dict)
    assert isinstance(wrap_var([]), list)
    assert isinstance(wrap_var(()), tuple)
    assert isinstance(wrap_var({}), dict)
    assert isinstance(wrap_var(set()), set)

# Generated at 2022-06-11 18:33:28.368670
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(None), AnsibleUnsafe)

    assert isinstance(wrap_var('test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'test'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'test'), AnsibleUnsafeText)

    assert isinstance(wrap_var(1), int)
    assert isinstance(wrap_var(1), AnsibleUnsafe)

    assert isinstance(wrap_var({"test": "test"}), dict)
    assert isinstance(wrap_var({"test": "test"}), AnsibleUnsafe)
    assert isinstance(wrap_var({"test": "test"})["test"], AnsibleUnsafeText)


# Generated at 2022-06-11 18:33:38.648074
# Unit test for function wrap_var
def test_wrap_var():
    n_unsafe_text = to_unsafe_text('foo')

    assert isinstance(n_unsafe_text, AnsibleUnsafeText)
    assert n_unsafe_text == 'foo'
    assert isinstance(wrap_var(n_unsafe_text), AnsibleUnsafeText)

    n_unsafe_bytes = to_unsafe_bytes('bar')

    assert isinstance(n_unsafe_bytes, AnsibleUnsafeBytes)
    # On Python 2 bytes are the same as str type, otherwise they are not
    if isinstance(n_unsafe_bytes, str):
        assert n_unsafe_bytes == 'bar'
    assert isinstance(wrap_var(n_unsafe_bytes), AnsibleUnsafeBytes)


# Generated at 2022-06-11 18:33:50.443776
# Unit test for function wrap_var
def test_wrap_var():
    """Ensure the wrap_var function behaves as expected
    """

    class SafeVar(object):
        pass

    s = SafeVar()
    assert wrap_var(s) is s

    s = SafeVar()
    s.__UNSAFE__ = True
    assert wrap_var(s) is s

    assert wrap_var(None) is None

    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    assert isinstance(wrap_var(u'foo'.encode('utf-8')), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'.decode('utf-8')), AnsibleUnsafeBytes)


# Generated at 2022-06-11 18:34:00.146422
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('foo') == to_unsafe_text('foo')
    assert wrap_var(1) == 1
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(None) is None
    assert wrap_var({'foo': 'bar', 'a': 5}) == {to_unsafe_text('foo'): to_unsafe_text('bar'), to_unsafe_text('a'): 5}
    assert wrap_var(['foo', 'bar', 5]) == [to_unsafe_text('foo'), to_unsafe_text('bar'), 5]
    assert wrap_var(set(['foo', 'bar'])) == set([to_unsafe_text('foo'), to_unsafe_text('bar')])

# Generated at 2022-06-11 18:34:09.522717
# Unit test for function wrap_var
def test_wrap_var():

    class Test(object):
        a = 1

    test_dict = {'a': {'b': 1}, 'c': [1, 2, 3], 'd': {1, 2, 3}, 'e': Test()}

    assert isinstance(wrap_var(test_dict), dict)
    assert isinstance(wrap_var(test_dict)['a'], dict)
    assert isinstance(wrap_var(test_dict)['c'], list)
    assert isinstance(wrap_var(test_dict)['d'], set)
    assert isinstance(wrap_var(test_dict)['e'], Test)



# Generated at 2022-06-11 18:34:18.390765
# Unit test for function wrap_var
def test_wrap_var():
    import sys
    # see http://docs.python.org/2/library/unittest.html
    import unittest
    import copy

    class TestWrapVar(unittest.TestCase):

        def setUp(self):
            self.longMessage = None
            self.maxDiff = None

        def test_wrap_basics(self):
            """wrap_var basics"""
            self.assertTrue(isinstance(wrap_var(None), type(None)))
            self.assertTrue(isinstance(wrap_var(1), type(1)))
            self.assertTrue(isinstance(wrap_var(1.1), type(1.1)))
            if sys.version_info >= (3, 0):
                self.assertTrue(isinstance(wrap_var(True), type(True)))

# Generated at 2022-06-11 18:34:26.594374
# Unit test for function wrap_var
def test_wrap_var():
    # Test values of all types that are wrapped
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'test'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(2), int)
    assert isinstance(wrap_var(dict(test='test')), dict)
    assert isinstance(wrap_var(list(['test'])), list)
    assert isinstance(wrap_var(set(['test'])), set)
    # Test the case where a value is already wrapped
    assert isinstance(wrap_var(wrap_var('test')), AnsibleUnsafeText)

# Generated at 2022-06-11 18:34:39.374068
# Unit test for function wrap_var
def test_wrap_var():
    class Foo(object):
        pass

    class Bar(object):
        pass

    class Baz(object):
        pass

    bar = Bar()

    def assert_wrap(value, unsafe_class):
        assert isinstance(wrap_var(value), unsafe_class)

    assert_wrap(42, int)
    assert_wrap({}, dict)
    assert_wrap(set(), set)
    assert_wrap([], list)
    assert_wrap((), tuple)
    assert_wrap(1.0, float)
    assert_wrap(None, type(None))
    assert_wrap(False, bool)
    assert_wrap(bar, Bar)
    assert_wrap(bar, AnsibleUnsafe)

    foo = Foo()
    wrapped_foo = wrap_var(foo)
    assert isinstance(wrapped_foo, Foo)

# Generated at 2022-06-11 18:34:49.451926
# Unit test for function wrap_var
def test_wrap_var():
    from collections import Mapping, Set, Sequence
    from ansible.module_utils.common.collections import is_sequence

    assert wrap_var(None) is None

    # test for AnsibleUnsafeBytes
    assert isinstance(wrap_var(b'123'), AnsibleUnsafeBytes)

    # test for AnsibleUnsafeText
    assert isinstance(wrap_var(u'123'), AnsibleUnsafeText)

    # test for NativeJinjaUnsafeText
    assert isinstance(wrap_var(NativeJinjaText(u'123')), NativeJinjaUnsafeText)

    # test for wrap_var in dictionaries
    assert isinstance(wrap_var({1: 2}), Mapping)
    assert isinstance(wrap_var({u'1': 2}), Mapping)

# Generated at 2022-06-11 18:34:58.806425
# Unit test for function wrap_var
def test_wrap_var():
    """unit test for wrap_var(v) method
    """
    # Declare a group of unsafe variables
    unsafe_var_list = [
        'string',
        12345,
        1.2345,
        [1, 2, 3],
        (1, 2, 3),
        {'key': 1},
    ]

    # Declare a group of safe variables

# Generated at 2022-06-11 18:35:05.233204
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(b'foo') == b'foo'
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert wrap_var('foo') == 'foo'
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert wrap_var('foo') == 'foo'
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert wrap_var([1, 2, 3]) == [1, 2, 3]
    assert wrap_var(set((1, 2, 3))) == set((1, 2, 3))
    assert wrap_var(dict(a=1, b=2, c=3)) == dict(a=1, b=2, c=3)
    assert wrap_var(AnsibleUnsafeText('foo')) == 'foo'

# Generated at 2022-06-11 18:35:11.676485
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)
    assert isinstance(wrap_var('test'.encode()), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(['test', 'test2']), list)
    assert isinstance(wrap_var(('test', 'test2')), tuple)
    assert isinstance(wrap_var({'test': 'test2'}), dict)
    assert isinstance(wrap_var(set(['test', 'test2'])), set)
    assert isinstance(wrap_var(1), int)

# Generated at 2022-06-11 18:35:23.073808
# Unit test for function wrap_var
def test_wrap_var():
    import types
    import ast
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.template import Templar

    class MyTemplate(object):
        def __init__(self):
            self.environment = 'unittest'

        def _get_tmp_path(self):
            return '/tmp'

        @property
        def basedir(self):
            return '/tmp'

        def _basedir_from_searchpath(self):
            return '/tmp'

        def add_data_context(self, data):
            self.data = data

        def add_file_searchpath(self, searchpath):
            self.searchpath = searchpath


# Generated at 2022-06-11 18:35:34.507501
# Unit test for function wrap_var
def test_wrap_var():
    import collections
    import os
    import sys
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class MyYAMLObject(AnsibleBaseYAMLObject):
        pass

    class OldStyleClass:
        pass

    class MyClass(object):
        pass

    # Wrap values

# Generated at 2022-06-11 18:35:45.432589
# Unit test for function wrap_var
def test_wrap_var():
    # First a string
    s = u"\u1234"
    assert isinstance(s, text_type)
    assert isinstance(wrap_var(s), AnsibleUnsafeText)

    # Now wrap a list of string
    l = [u"\u1234", u"\u5678"]
    assert isinstance(wrap_var(l), list)
    assert all(isinstance(item, AnsibleUnsafeText) for item in wrap_var(l))

    # Wrap a dict
    d = dict(one=u"\u1234", two=u"\u5678")
    assert isinstance(wrap_var(d), dict)
    assert all(isinstance(item, AnsibleUnsafeText) for item in wrap_var(d).values())

# Generated at 2022-06-11 18:35:54.159413
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('foo') == u'foo'
    assert wrap_var(1) == 1
    assert wrap_var(None) is None

    assert wrap_var(u'\ufeff') == u'\ufeff'

    a = wrap_var(u'foo')
    assert isinstance(a, AnsibleUnsafeText)
    assert not isinstance(a, NativeJinjaUnsafeText)
    assert a == u'foo'
    assert isinstance(a.encode('utf-8'), AnsibleUnsafeBytes)

    a = wrap_var(u'{{')
    assert isinstance(a, NativeJinjaUnsafeText)
    assert a == u'{{'
    assert isinstance(a.encode('utf-8'), AnsibleUnsafeBytes)

    assert wrap_var(u"\u2013")

# Generated at 2022-06-11 18:36:03.801041
# Unit test for function wrap_var
def test_wrap_var():
    import copy, io, tempfile
    from ansible.module_utils.six import PY3

    def check(x):
        y = wrap_var(x)
        assert x == y
        assert type(x) == type(y)
        return y

    def check_str(x):
        y = check(x)
        assert isinstance(y, text_type)
        return y

    def check_bytes(x):
        y = check(x)
        assert isinstance(y, binary_type)
        return y

    check_str('string')
    check_bytes(b'bytes')
    check_str('123')
    check_bytes(b'123')
    check_str(u'unicode')
    check(io.BytesIO(b'bytesio'))