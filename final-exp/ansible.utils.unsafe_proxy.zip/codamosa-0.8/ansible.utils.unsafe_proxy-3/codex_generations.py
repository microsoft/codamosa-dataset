

# Generated at 2022-06-11 18:31:39.482587
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.display import Display
    display = Display()
    play_context = PlayContext(new_stdin=False)


# Generated at 2022-06-11 18:31:50.426073
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(True), type(True))
    assert isinstance(wrap_var(1), type(1))
    assert isinstance(wrap_var(1.1), type(1.1))
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'.decode()), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'.decode('utf-8')), AnsibleUnsafeText)
    assert isinstance(wrap_var({b'foo': b'bar'}), dict)

# Generated at 2022-06-11 18:31:56.099896
# Unit test for function wrap_var
def test_wrap_var():
    unsafe = 'unsafe text'
    safe = wrap_var(unsafe)
    assert hasattr(safe, '__UNSAFE__')
    safe = wrap_var({unsafe: 0})
    assert hasattr(safe[unsafe], '__UNSAFE__')

# Generated at 2022-06-11 18:31:57.489484
# Unit test for function wrap_var
def test_wrap_var():
    # TODO: how to unit test this function?
    pass

# Generated at 2022-06-11 18:32:02.391304
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var('foo'.encode('utf-8')), AnsibleUnsafe)
    assert isinstance(wrap_var('foo'), AnsibleUnsafe)
    assert isinstance(wrap_var({'foo': 'bar'}), dict)
    assert isinstance(wrap_var([1, 2, 3]), list)
    assert isinstance(wrap_var((1, 2, 3)), tuple)

# Generated at 2022-06-11 18:32:12.183491
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types

    # basic string wrap test
    assert isinstance(wrap_var(""), string_types)

    # Test wrapping lists and tuples
    my_list = ["a", "b"]
    my_tuple = ("c", "d")
    my_set = set([1, 2, 3])
    assert isinstance(wrap_var(my_list), list)
    assert isinstance(wrap_var(my_tuple), tuple)
    assert isinstance(wrap_var(my_set), set)

    # test wrapping of lists of tuples
    my_list_of_tuples = [("a", "b"), ("c", "d")]
    wraped_list_of_tuples = wrap

# Generated at 2022-06-11 18:32:19.472009
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    # Note that in Python 2 safe_str is a ascii text type, not a unicode type,
    # however it is a subclass of str, so we need to check that as well.
    assert isinstance(wrap_var('foobar'), NativeJinjaUnsafeText)
    assert isinstance(wrap_var(u'foobar'), NativeJinjaUnsafeText)
    assert isinstance(wrap_var(b'foobar'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(1), int)
    assert isinstance(wrap_var(1.2), float)
    assert isinstance(wrap_var(1j), complex)
    assert isinstance(wrap_var([1, 2]), list)
    assert isinstance(wrap_var((1, 2)), tuple)
   

# Generated at 2022-06-11 18:32:31.324819
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_sequence

    test_value = "Test String"
    assert isinstance(wrap_var(test_value), AnsibleUnsafeText)
    assert wrap_var(wrap_var(test_value)) == wrap_var(test_value)
    assert wrap_var(wrap_var(test_value)) is wrap_var(test_value)

    test_value = AnsibleUnsafeText("Another String")
    assert isinstance(wrap_var(test_value), AnsibleUnsafeText)
    assert wrap_var(wrap_var(test_value)) == wrap_var(test_value)
    assert wrap_var(wrap_var(test_value)) is wrap_var(test_value)

    test_value = "Test String".encode('utf-8')

# Generated at 2022-06-11 18:32:42.140186
# Unit test for function wrap_var
def test_wrap_var():
    # Test for dict
    dict_test = {'str': 'foo', 'int': 5, 'list': [1, 2, 3], 'tset': {'foo'}, 'dict': {'foo': 'bar'}, 'text': NativeJinjaText('text1'), 'jinja': NativeJinjaUnsafeText('text2')}
    wrapped_dict = _wrap_dict(dict_test)
    assert isinstance(wrapped_dict['str'], AnsibleUnsafeText)
    assert wrapped_dict['int'] == 5
    assert isinstance(wrapped_dict['list'], list)
    assert isinstance(wrapped_dict['tset'], set)
    assert isinstance(wrapped_dict['dict'], dict)
    assert isinstance(wrapped_dict['text'], NativeJinjaUnsafeText)


# Generated at 2022-06-11 18:32:51.465173
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeText(u'foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var((u'foo', b'foo')), tuple)
    assert isinstance(wrap_var(['foo', b'foo']), list)
    assert isinstance(wrap_var({u'foo': b'foo'}), dict)
    assert isinstance(wrap_var({'foo': 'foo'}), dict)