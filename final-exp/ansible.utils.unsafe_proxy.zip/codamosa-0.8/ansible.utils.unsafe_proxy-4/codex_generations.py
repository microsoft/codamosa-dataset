

# Generated at 2022-06-11 18:31:41.304272
# Unit test for function wrap_var
def test_wrap_var():
    # Testing text strings
    assert isinstance(wrap_var(u'my string'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'1234'), AnsibleUnsafeText)

    # Testing binary strings
    assert isinstance(wrap_var(b'my string'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'1234'), AnsibleUnsafeBytes)

    # Testing lists, tuples, sets
    assert isinstance(wrap_var([]), list)
    assert isinstance(wrap_var(()), tuple)
    assert isinstance(wrap_var({}), dict)
    assert isinstance(wrap_var(set()), set)

    # Testing AnsibleUnsafe text
    assert isinstance(wrap_var(AnsibleUnsafeText('test')), AnsibleUnsafeText)
   

# Generated at 2022-06-11 18:31:52.023021
# Unit test for function wrap_var
def test_wrap_var():
    import ansible.module_utils.six as six
    d = {'a': 'b', 'n': None}
    d2 = wrap_var(d)
    assert d2 is not d
    assert d2['a'].__UNSAFE__
    assert d2['n'] is None
    assert d2['a'] == d['a']
    b = six.b('bytes')
    b2 = wrap_var(b)
    assert b2 is not b
    assert b2.__UNSAFE__
    assert b2 == b
    s = 'string'
    s2 = wrap_var(s)
    assert s2 is not s
    assert s2.__UNSAFE__
    assert s2 == s

    u = u'string'
    u2 = wrap_var(u)
    assert u

# Generated at 2022-06-11 18:32:02.825955
# Unit test for function wrap_var
def test_wrap_var():
    assert type(wrap_var((2, 3))) is tuple
    assert type(wrap_var('hello')) is text_type
    assert type(wrap_var(u'hello')) is text_type
    assert type(wrap_var(b'hello')) is binary_type
    assert type(wrap_var(b'hello')) is binary_type

    assert type(wrap_var({'a': 1, 'b': 2})) is dict
    assert type(wrap_var({'a': 1, 'b': 2}).keys()) is set
    assert type(wrap_var({'a': 1, 'b': 2}).values()) is set

    assert type(wrap_var({'a': 1, 'b': 2}.keys())) is set
    assert type(wrap_var([1,2,'a'])) is list

# Generated at 2022-06-11 18:32:12.544816
# Unit test for function wrap_var
def test_wrap_var():
    _long_int = 9999999999999999999999999999999999999999999999
    _large_int = 9999999999999999999999999999999999
    _int = 9999999999999999999999999999999999
    _short_int = 99999999999999999
    _small_int = 999999999999999
    _tiny_int = 9999999
    _float = 9999999999999999999999999999999999999999999999.99
    _string = "The quick brown fox jumped over the lazy dog"
    _unicode = "The quick brown fox jumped over the lazy dog"


# Generated at 2022-06-11 18:32:24.377931
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.compat.tests import mock
    import unittest2 as unittest
    from ansible.module_utils.six.moves import builtins

    class TestWrapVar(unittest.TestCase):

        def setUp(self):
            self.mock_terminal_size = mock.MagicMock()
            self.mock_terminal_size.return_value = (80, 24)
            builtins.__terminal_size__ = self.mock_terminal_size

            self.mock_open = mock.mock_open()
            self.builtin_open = 'ansible.module_utils.six.moves.builtins.open'
            self.mock_open_patch = mock.patch(self.builtin_open, self.mock_open, create=True)


# Generated at 2022-06-11 18:32:34.516524
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var('test'), text_type)
    assert isinstance(wrap_var(b'test'), binary_type)
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(1), type(1))
    assert isinstance(wrap_var(2.0), type(2.0))
    assert isinstance(wrap_var(dict()), type(dict()))
    assert isinstance(wrap_var(dict()['a']), type(dict()['a']))
    assert isinstance(wrap_var(list()), type(list()))
    assert isinstance(wrap_var(list()[0]), type(list()[0]))
    assert isinstance(wrap_var(tuple()), type(tuple()))

# Generated at 2022-06-11 18:32:45.927400
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(['foo']) == [to_unsafe_text(u'foo')]
    assert wrap_var(('foo',)) == (to_unsafe_text(u'foo'),)
    assert wrap_var(set(['foo', 'bar'])) == set([to_unsafe_text(u'foo'), to_unsafe_text(u'bar')])
    assert wrap_var(u'foo') == to_unsafe_text(u'foo')

    assert wrap_var({u'key': u'value'}) == {to_unsafe_text(u'key'): to_unsafe_text(u'value')}

# Generated at 2022-06-11 18:32:52.889063
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('test') == 'test'
    assert wrap_var(u'test') == u'test'
    assert wrap_var(u'test'.encode('utf-8')) == u'test'.encode('utf-8')
    assert wrap_var({'a': 'test', 'b': {'c': 'test'}}) == {'a': 'test', 'b': {'c': 'test'}}
    assert wrap_var(['test', {'a': 'test'}]) == ['test', {'a': 'test'}]
    assert wrap_var(('test', {'a': 'test'})) == ('test', {'a': 'test'})
    assert wrap_var({'test', {'a': 'test'}}) == {'test', {'a': 'test'}}


# Generated at 2022-06-11 18:33:02.274850
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(123) == 123
    assert wrap_var(AnsibleUnsafe(123)) == AnsibleUnsafe(123)
    assert wrap_var(b'test') == AnsibleUnsafeBytes(b'test')
    assert wrap_var('test') == AnsibleUnsafeText('test')
    assert wrap_var(tuple(range(3))) == (0, AnsibleUnsafe(1), AnsibleUnsafe(2))
    assert wrap_var(set(range(3))) == set([0, AnsibleUnsafe(1), AnsibleUnsafe(2)])
    assert wrap_var(list(range(3))) == [0, AnsibleUnsafe(1), AnsibleUnsafe(2)]

# Generated at 2022-06-11 18:33:12.675824
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types

    assert wrap_var('a_string') == 'a_string'
    assert isinstance(wrap_var('a_string'), string_types)
    assert wrap_var(b'a_bytes') == b'a_bytes'
    assert isinstance(wrap_var(b'a_bytes'), (string_types, AnsibleUnsafe))
    assert isinstance(wrap_var('a_string'), string_types)
    assert wrap_var(('a_tuple',)) == ('a_tuple',)
    assert isinstance(wrap_var(('a_tuple',)), tuple)
    assert wrap_var(['a_list']) == ['a_list']

# Generated at 2022-06-11 18:33:25.217843
# Unit test for function wrap_var
def test_wrap_var():
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    x = dict(a=1, b=2)
    y = wrap_var(x)

    # make sure that unwrapping does not work
    with pytest.raises(TypeError):
        dict((k, item) for k, item in y.items())

    # make sure that is a wrapped dict
    assert isinstance(y, dict)

    # make sure that we can access the wrapped dict
    assert y['a'] == 1
    assert y['b'] == 2

    y = wrap_var([1, 2])
    assert is_sequence(y)

    s = {1, 2}
    y = wrap_var(s)
    assert isinstance(y, set)

# Generated at 2022-06-11 18:33:36.927333
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(b'test') == u'test'
    assert wrap_var(u'test') == u'test'
    assert isinstance(wrap_var(u'test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'test'), AnsibleUnsafeText)
    assert wrap_var(u'test'.encode('utf-8')) == u'test'
    assert wrap_var(u'test'.encode('utf-8')).__UNSAFE__ is True
    assert isinstance(wrap_var(u'test'.encode('utf-8')), AnsibleUnsafeText)

# Generated at 2022-06-11 18:33:47.250740
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(42) == 42
    assert wrap_var(42.42) == 42.42
    assert wrap_var('42') == '42'
    assert isinstance(wrap_var(b'42'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'42'), AnsibleUnsafeText)
    assert isinstance(wrap_var(dict(key=u'value')), dict)
    assert isinstance(wrap_var(dict(key=u'value').values()), list)
    assert isinstance(wrap_var(dict(key=u'value').values())[0], AnsibleUnsafeText)

# Generated at 2022-06-11 18:33:57.311994
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('hello') == 'hello'
    assert isinstance(wrap_var(b'hello'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'hello'), AnsibleUnsafeText)
    assert isinstance(wrap_var(dict(a=1)), dict)
    assert isinstance(wrap_var(dict(a=1).values()), tuple)
    assert isinstance(wrap_var(dict(a=1).keys()), tuple)
    assert isinstance(wrap_var({'a'}), set)
    assert isinstance(wrap_var(['a']), list)
    assert isinstance(wrap_var((1, 2)), tuple)

# Generated at 2022-06-11 18:34:09.025040
# Unit test for function wrap_var
def test_wrap_var():
    import json
    import collections

    test_data = dict(
        boolean=True,
        integer=10,
        list=['apple', 'orange', 'banana'],
        nested_list=['apple', ['orange', 'cherry'], 'banana'],
        dict={'name': 'john', 'age': 30, 'cars': ['Ford', 'BMW', 'Fiat']},
        nested_dict={'name': 'john', 'age': 30,
                     'cars': {'a': 'Ford', 'b': 'BMW', 'c': 'Fiat'}},
        tuple=(1, 2, 3),
    )

    unsafe = wrap_var(test_data)
    assert json.dumps(unsafe) == json.dumps(test_data)

    # tuple and list have different types, so they need to

# Generated at 2022-06-11 18:34:18.030780
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) == None
    assert wrap_var(u'foo') == u'foo'
    assert isinstance(wrap_var(u'foo'), text_type)
    assert wrap_var(u'foo') == u'foo'
    assert isinstance(wrap_var(b'foo'), binary_type)
    assert wrap_var([]) == []
    assert wrap_var(()) == ()
    assert wrap_var({}) == {}
    assert wrap_var(set([])) == set([])
    assert wrap_var(set([1])) == set([1])
    assert wrap_var({'foo': 'bar'}) == {'foo': 'bar'}
    assert wrap_var([1, 2]) == [1, 2]

# Generated at 2022-06-11 18:34:27.069679
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import PY2

    assert not isinstance(wrap_var('foo'), AnsibleUnsafe)
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafe)
    assert isinstance(wrap_var(AnsibleUnsafeText('foo')), AnsibleUnsafe)

    def convert_to_bytes(obj):
        if PY2:
            return obj.encode()
        else:
            return obj.encode('utf-8')

    # wrap_var(x) should return the same type as x
    assert type(wrap_var('foo')) == str
    assert type(wrap_var(u'foo')) == str

# Generated at 2022-06-11 18:34:38.224190
# Unit test for function wrap_var
def test_wrap_var():
    import re

    # Pass in a string and check if it wraps a AnsibleUnsafeString
    # Test both python 2 and 3.
    assert re.search(r'^<ansible\.module_utils\.basic\.AnsibleUnsafe(Bytes|Text) object', str(wrap_var('abc')))

    # Pass in a AnsibleUnsafeString and lets see if it is returned as is.
    assert str(wrap_var(wrap_var('abc'))) == str(wrap_var('abc'))

    # Pass in a tuple and check if it wraps a AnsibleUnsafeString
    assert re.search(r'^<ansible\.module_utils\.basic\.AnsibleUnsafe(Bytes|Text) object', str(wrap_var(('a', 'b'))))

    # Pass in a list and check if it wraps a AnsibleUnsafe

# Generated at 2022-06-11 18:34:49.113247
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.unsafe_proxy import wrap_var
    import types

    assert wrap_var("") == AnsibleUnsafeText("")
    assert wrap_var(1) == 1
    assert wrap_var(None) is None

    assert wrap_var({}) == {}
    assert wrap_var({1: 2}) == {1: 2}

    assert isinstance(wrap_var(""), AnsibleUnsafeText)
    assert isinstance(wrap_var("1"), AnsibleUnsafeText)
    assert wrap_var("1") == AnsibleUnsafeText("1")

    assert isinstance(wrap_var({"1": "2"}), dict)
    assert isinstance(wrap_var({"1": "2"})[AnsibleUnsafeText("1")], AnsibleUnsafeText)


# Generated at 2022-06-11 18:34:58.777504
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.common.collections import is_sequence

    safe_str = "safe_str"
    safe_bytes = to_bytes(safe_str)
    safe_unicode_str = to_text(safe_str)
    safe_unicode_bytes = to_bytes(safe_unicode_str)
    unsafe_unicode_str = AnsibleUnsafeText(safe_unicode_str)
    unsafe_bytes = AnsibleUnsafeBytes(safe_bytes)
    unsafe_str = AnsibleUnsafeText(safe_str)

    safe_dict = {'a': '1', 'b': '2'}

# Generated at 2022-06-11 18:35:11.749566
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common._collections_compat import MutableSequence, Mapping

    import collections
    import types

    # Test strings - unicode
    x = u'foo'
    assert isinstance(wrap_var(x), AnsibleUnsafeText)
    assert isinstance(wrap_var(x), NativeJinjaUnsafeText)

    # Test strings - str
    x = 'bar'
    assert isinstance(wrap_var(x), AnsibleUnsafeText)
    assert isinstance(wrap_var(x), NativeJinjaUnsafeText)

    # Test bytes
    x = b'baz'
    assert isinstance(wrap_var(x), AnsibleUnsafeBytes)

    # Test ints
    x = 42
    assert wrap_var(x) == 42

# Generated at 2022-06-11 18:35:19.449816
# Unit test for function wrap_var
def test_wrap_var():
    import unittest
    import ansible
    class TestWrapVar(unittest.TestCase):
        def test_wrap_single_val(self):
            self.assertIsInstance(wrap_var('string'), AnsibleUnsafeText)
            self.assertIsInstance(wrap_var(b'bytes'), AnsibleUnsafeBytes)
            self.assertIsInstance(wrap_var(1), int)
            self.assertIsInstance(wrap_var(1.0), float)
            self.assertIsInstance(wrap_var(None), type(None))
            self.assertIsInstance(wrap_var(u'unicode'), AnsibleUnsafeText)
            self.assertIsInstance(wrap_var(ansible.module_utils.native_jinja.NativeJinjaText('jinja')), NativeJinjaUnsafeText)

       

# Generated at 2022-06-11 18:35:30.045094
# Unit test for function wrap_var
def test_wrap_var():
    # Test for AnsibleUnsafeBytes
    u_bytes = wrap_var(b'Hello World')
    assert isinstance(u_bytes, binary_type)
    assert isinstance(u_bytes, AnsibleUnsafe)
    # Test that the returned object can always convert back to a bytes object
    assert isinstance(u_bytes.encode(), AnsibleUnsafeBytes)

    # Test for AnsibleUnsafeText
    u_text = wrap_var(u'Hello World')
    assert isinstance(u_text, text_type)
    assert isinstance(u_text, AnsibleUnsafe)
    # Test that the returned object can always convert back to a text object
    assert isinstance(u_text.decode(), AnsibleUnsafeText)

    # Test for NativeJinjaUnsafeText

# Generated at 2022-06-11 18:35:37.579833
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(u'foo') == u'foo'

    # wrap an already wrapped string
    assert wrap_var(wrap_var(u'foo')) == u'foo'

    # wrap an already wrapped unicode string
    assert wrap_var(wrap_var(wrap_var(u'foo'))) == u'foo'

    # wrap a wrapped string and unwrap it
    assert wrap_var(wrap_var(u'foo')).__UNSAFE__ is True

    # wrap a wrapped unicode string and unwrap it
    assert wrap_var(wrap_var(wrap_var(u'foo'))).__UNSAFE__ is True

    # wrap a string to bytes and unwrap it
    assert wrap_var(wrap_var(b'foo')).__UNSAFE__ is True

    # wrap a unicode str to bytes

# Generated at 2022-06-11 18:35:47.906885
# Unit test for function wrap_var
def test_wrap_var():
    from unittest import TestCase

    class TestWrapVar(TestCase):
        def test_dict_wrap(self):
            d = {u'foo': u'bar', u'\u1f4a9': u'bar'}
            d2 = _wrap_dict(d)
            self.assertIsInstance(d2, dict)
            self.assertIsInstance(list(d2.keys())[0], AnsibleUnsafeText)

        def test_sequence_wrap(self):
            sq = (u'foo', u'bar', u'\u1f4a9')
            sq2 = _wrap_sequence(sq)
            self.assertIsInstance(sq2, tuple)
            self.assertIsInstance(sq2[0], AnsibleUnsafeText)

        def test_set_wrap(self):
            s

# Generated at 2022-06-11 18:35:55.739662
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    test_dict = dict(
        simple_str=u"simple str",
        simple_bytes=u"simple bytes".encode(),
        list_str=[u"list str"],
        list_bytes=[u"simple list bytes".encode()],
        dict_str=dict(key=u"dict str"),
        dict_bytes=dict(key=u"dict bytes".encode()),
        set_str={u"set str"},
        set_bytes={u"set bytes".encode()},
    )
    # Test the dict and it's contents
    wrapped_test_dict = wrap_var(test_dict)
    assert isinstance(wrapped_test_dict, dict)
    assert isinstance(wrapped_test_dict['simple_str'], AnsibleUnsafeText)


# Generated at 2022-06-11 18:36:05.924397
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.unsafe_proxy import wrap_var
    import ansible.utils.unsafe_proxy
    import types
    import sys

    # test creation of an unsafe proxy object
    class TestClass(object):
        pass

    instance = TestClass()
    instance.attr = 1234

    proxy_instance = wrap_var(instance)
    assert(isinstance(proxy_instance, types.InstanceType))
    assert(hasattr(proxy_instance, 'attr'))
    assert(getattr(proxy_instance, 'attr') == 1234)

    # test creation of an unsafe proxy object with attributes
    class TestClass(object):
        pass

    instance = TestClass()
    instance.attr = 1234

    proxy_instance = wrap_var(instance)
    assert(isinstance(proxy_instance, types.InstanceType))


# Generated at 2022-06-11 18:36:13.262534
# Unit test for function wrap_var
def test_wrap_var():
    import sys
    #import requests
    from ansible.utils.display import Display
    from ansible.module_utils.common.text.converters import to_unicode
    Display.verbosity = 5
    Display.deprecated('foo')
    Display.deprecated('foo')
    Display.deprecated('foo')
    Display.deprecated('foo', version='2.13')
    Display.deprecated('foo', version='2.12')
    Display.deprecated('This is a long message that should be truncated because it is over 80 characters long')
    Display.display('foo', color='blue')
    #Display.vv('foo')
    #Display.v('foo')
    #Display.vvv('foo')
    #Display.vvvv('foo')
    #Display.vvvvv('foo')
    #Display.warning('

# Generated at 2022-06-11 18:36:22.401255
# Unit test for function wrap_var
def test_wrap_var():
    # Test different inputs

    # None/AnsibleUnsafe should always return the same object
    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeText()) is AnsibleUnsafeText()
    assert wrap_var(AnsibleUnsafeBytes()) is AnsibleUnsafeBytes()

    # Strings should be wrapped with AnsibleUnsafeText
    assert isinstance(wrap_var('str'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'unicode'), AnsibleUnsafeText)

    # Bytes/buffers should be wrapped with AnsibleUnsafeBytes
    assert isinstance(wrap_var(b'bytes'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(bytearray(b'bytearray')), AnsibleUnsafeBytes)

    # NativeJin

# Generated at 2022-06-11 18:36:26.803286
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(0) == 0
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var('foo') == 'foo'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var('foo') == 'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var([u'foo', b'foo']) == ['foo', b'foo']
    assert wrap_var((u'foo', b'foo')) == ('foo', b'foo')