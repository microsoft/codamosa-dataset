

# Generated at 2022-06-11 18:31:43.270931
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('test') == u'test'
    assert wrap_var(u'test') == u'test'
    assert wrap_var(b'test') == u'test'
    assert wrap_var(1) == 1
    assert wrap_var({'test': 'dict'}) == {'test': u'dict'}
    assert wrap_var([u'list', b'dict']) == [u'list', u'dict']
    assert wrap_var((u'tuple', b'dict')) == (u'tuple', u'dict')
    assert wrap_var({'test': u'dict'}) == {'test': u'dict'}
    assert wrap_var(['list', b'dict']) == [u'list', u'dict']

# Generated at 2022-06-11 18:31:53.533397
# Unit test for function wrap_var
def test_wrap_var():
    import sys
    import json

    if sys.version_info[0] < 3:
        from cStringIO import StringIO
    else:
        from io import StringIO

    class test_safe:
        pass

    class test_unsafe:
        __UNSAFE__ = True

    class test_safe_string(str):
        pass

    class test_unsafe_string(str):
        __UNSAFE__ = True

    class test_json_safe:
        def __str__(self):
            return json.dumps(self.__dict__)

    class test_json_unsafe:
        __UNSAFE__ = True
        def __str__(self):
            return json.dumps(self.__dict__)


# Generated at 2022-06-11 18:32:02.236877
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var({}) == {}
    assert isinstance(wrap_var({}), dict)
    assert wrap_var([]) == []
    assert isinstance(wrap_var([]), list)
    assert wrap_var(set()) == set()
    assert isinstance(wrap_var(set()), set)
    assert wrap_var(tuple()) == tuple()
    assert isinstance(wrap_var(tuple()), tuple)
    assert wrap_var(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert isinstance(wrap_var(['a', 'b', 'c']), list)

# Generated at 2022-06-11 18:32:12.055771
# Unit test for function wrap_var
def test_wrap_var():
    assert not wrap_var(None)
    assert wrap_var('') == ''
    assert wrap_var(b'') == b''
    assert wrap_var(u'') == u''

    assert wrap_var('abcd') == 'abcd'
    assert wrap_var(b'abcd') == b'abcd'
    assert wrap_var(u'abcd') == u'abcd'

    # NOTE: tupes and lists are converted to lists only!
    assert wrap_var([]) == []
    assert wrap_var(()) == []
    assert not wrap_var('')

    assert wrap_var([1, 2]) == [1, 2]
    assert wrap_var((1, 2)) == [1, 2]
    assert wrap_var(b'abbc') == b'abbc'

    assert wrap

# Generated at 2022-06-11 18:32:23.268380
# Unit test for function wrap_var
def test_wrap_var():
    import pytest

    def verify(obj, expected_type, expected_val=None):
        assert isinstance(obj, expected_type), "expected %r to be of type %r but was %r" % (obj, expected_type, type(obj))
        if expected_val is not None:
            assert obj == expected_val, "expected %r to equal %r" % (obj, expected_val)

    # Test that we can wrap various types
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(['f', 'o', 'o']), list)
    assert isinstance(wrap_var(('f', 'o', 'o')), tuple)

# Generated at 2022-06-11 18:32:33.868599
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.unsafe_proxy import wrap_var

    assert isinstance(wrap_var(u'test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'test'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var({u'test': u'test2'}), dict)
    assert isinstance(wrap_var({u'test': u'test2'})[u'test'], AnsibleUnsafeText)
    assert isinstance(wrap_var([u'test', u'test2']), list)
    assert isinstance(wrap_var([u'test', u'test2'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var((u'test', u'test2')), tuple)

# Generated at 2022-06-11 18:32:42.139798
# Unit test for function wrap_var
def test_wrap_var():
    f = wrap_var
    assert isinstance(f('foo'), AnsibleUnsafeText)
    assert isinstance(f(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(f(u'foo'), AnsibleUnsafeText)
    assert isinstance(f(('foo', 'bar')), tuple)
    assert isinstance(f(['foo', 'bar']), list)
    assert isinstance(f({'foo': 'bar'}), dict)

    x = AnsibleUnsafeText('foo')
    assert x is f(x)

# Generated at 2022-06-11 18:32:51.465205
# Unit test for function wrap_var
def test_wrap_var():
    # test None
    assert wrap_var(None) is None

    # test string
    assert isinstance(wrap_var("abc"), AnsibleUnsafeText)
    assert wrap_var("abc") == "abc"

    # test AnsibleUnsafe
    assert isinstance(wrap_var(AnsibleUnsafeText(u"abc")), AnsibleUnsafeText)
    assert wrap_var(AnsibleUnsafeText(u"abc")) == u"abc"

    # test dict
    assert isinstance(wrap_var({"a": "b"}), dict)
    assert isinstance(wrap_var({"a": "b"})["a"], AnsibleUnsafeText)
    assert wrap_var({"a": "b"})["a"] == u"b"

    # test list

# Generated at 2022-06-11 18:33:01.665961
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3

    v = dict(a=1, b=dict(c=[True, False]))
    v2 = wrap_var(v)
    assert isinstance(v2, dict)
    if PY3:
        assert isinstance(v2['b']['c'], list)
    else:
        assert isinstance(v2['b']['c'], tuple)
    assert isinstance(v2['b']['c'][0], bool)
    assert isinstance(v2['b']['c'][1], bool)

    v = dict(a=1, b=dict(c=(True, False)))
    v2 = wrap_var(v)
    assert isinstance(v2, dict)

# Generated at 2022-06-11 18:33:10.468765
# Unit test for function wrap_var
def test_wrap_var():
    import re
    assert isinstance('foo', AnsibleUnsafeText)
    assert isinstance(b'foo', AnsibleUnsafeBytes)
    assert wrap_var('foo') is not 'foo'
    assert wrap_var(b'foo') is not b'foo'
    seq = ['foo', b'foo']
    wrapped_seq = wrap_var(seq)
    assert seq is not wrapped_seq
    assert isinstance(wrapped_seq[0], AnsibleUnsafeText)
    assert isinstance(wrapped_seq[1], AnsibleUnsafeBytes)

    # This will be the bytes version of the raw string
    assert isinstance(re.compile(r'foo', re.MULTILINE), AnsibleUnsafeBytes)

# Generated at 2022-06-11 18:33:16.094347
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(2) == 2
    assert wrap_var({'a': 2}) == {'a': 2}
    assert isinstance(wrap_var('a'), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes('a')), AnsibleUnsafeBytes)

# Generated at 2022-06-11 18:33:26.636336
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import test_wrap_var

    # test for unsafe strings

# Generated at 2022-06-11 18:33:37.672338
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var("foo") == "foo"
    assert isinstance(wrap_var("foo"), AnsibleUnsafeText)
    assert wrap_var(b"foo") == b"foo"
    assert isinstance(wrap_var(b"foo"), AnsibleUnsafeBytes)

    assert wrap_var(["foo", "bar"]) == ["foo", "bar"]
    assert wrap_var(("foo", "bar")) == ("foo", "bar")
    assert wrap_var(set(["foo", "bar"])) == set(["foo", "bar"])

    assert wrap_var({"foo": "bar"}) == {"foo": "bar"}
    assert isinstance(wrap_var({"foo": "bar"}), dict)

# Generated at 2022-06-11 18:33:48.450035
# Unit test for function wrap_var
def test_wrap_var():
    import operator
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types, binary_type, text_type

    # Test wrap_var()
    assert(wrap_var(None) is None)

    assert(isinstance(wrap_var(1), AnsibleUnsafe))

    assert(isinstance(wrap_var(u'string'), AnsibleUnsafeText))
    assert(isinstance(wrap_var(b'string'), AnsibleUnsafeBytes))

    assert(isinstance(wrap_var(u'\u00f1'), AnsibleUnsafeText))
    assert(isinstance(wrap_var(b'\xc3\xb1'), AnsibleUnsafeBytes))

    # Test wrap_var() with a dict

# Generated at 2022-06-11 18:33:55.700270
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import text_type
    original_string = "this is unsafe"
    unsafe_text = wrap_var(original_string)
    assert isinstance(unsafe_text, string_types)
    assert unsafe_text.__UNSAFE__
    assert unsafe_text == original_string
    assert isinstance(unsafe_text, text_type)
    assert isinstance(wrap_var(None), type(None))

# Generated at 2022-06-11 18:34:03.303536
# Unit test for function wrap_var
def test_wrap_var():
    import datetime
    import pytz
    import re
    import ansible.module_utils.six.moves.builtins
    import datetime
    import hashlib
    import re
    import ruamel.yaml as ruamel_yaml
    import ruamel.yaml.comments
    import types
    import collections

    def check_wrap_var(value):
        assert wrap_var(value) is value

    def check_wrap_var_raise(value):
        try:
            wrap_var(value)
        except TypeError:
            raise AssertionError
        raise AssertionError

    # from ansible.module_utils._text import to_bytes, to_text
    ansible_text = ansible.module_utils._text.to_text
    from ansible.module_utils.six import text_type, binary

# Generated at 2022-06-11 18:34:14.704205
# Unit test for function wrap_var
def test_wrap_var():
    '''
    This function tests the wrap_var function in module_utils.common
    '''
    import copy


# Generated at 2022-06-11 18:34:25.081485
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(10) == 10
    assert isinstance(wrap_var(10), int)
    assert wrap_var(10.5) == 10.5
    assert isinstance(wrap_var(10.5), float)
    assert wrap_var(True)
    assert isinstance(wrap_var(True), bool)
    assert wrap_var([1, 2]) == [1, 2]
    assert isinstance(wrap_var([1, 2]), list)
    assert wrap_var([1, 2, {'a': 'b'}]) == [1, 2, {'a': 'b'}]
    assert wrap_var([1, 2, {'a': 'b'}]) == [1, 2, {'a': 'b'}]

# Generated at 2022-06-11 18:34:37.350599
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import u, PY3

    assert isinstance(wrap_var(u("blah")), AnsibleUnsafeText)
    assert isinstance(wrap_var(u("blah").encode('utf-8')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(None), type(None))

    # Dicts
    assert isinstance(wrap_var({'test': 'blah'}), Mapping)
    assert isinstance(wrap_var({'test': 'blah'})['test'], AnsibleUnsafeText)
    assert isinstance(wrap_var({'test': 'blah'.encode('utf-8')})['test'], AnsibleUnsafeBytes)


# Generated at 2022-06-11 18:34:48.647508
# Unit test for function wrap_var
def test_wrap_var():
    import unittest

    class TestWrapVar(unittest.TestCase):
        def setUp(self):
            pass

        def test_wrap_dict(self):
            v = {'a': 'b', 'c': 'd'}
            w = wrap_var(v)
            self.assertEquals(type(w), type(v))
            self.assertTrue(isinstance(w.get('a'), AnsibleUnsafeText))
            self.assertTrue(isinstance(w.get('c'), AnsibleUnsafeText))

        def test_wrap_tuple(self):
            v = ('a', 'b', 'c')
            w = wrap_var(v)
            self.assertEquals(type(w), type(v))

# Generated at 2022-06-11 18:34:58.877259
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var("test"), AnsibleUnsafeText) is True
    assert isinstance(wrap_var(u"test"), AnsibleUnsafeText) is True
    assert isinstance(wrap_var("test"), AnsibleUnsafe) is True
    assert isinstance(wrap_var(u"test"), AnsibleUnsafe) is True
    assert isinstance(wrap_var("test"), AnsibleUnsafeText) is True
    assert isinstance(wrap_var(u"test"), AnsibleUnsafeText) is True
    assert isinstance(wrap_var("test"), AnsibleUnsafe) is True
    assert isinstance(wrap_var(u"test"), AnsibleUnsafe) is True
    assert wrap_var({"test": "test"}) == {"test": "test"}

# Generated at 2022-06-11 18:35:05.275679
# Unit test for function wrap_var
def test_wrap_var():

    from ansible.module_utils.six import assertCountEqual, assertIsInstance
    from ansible.module_utils.six.moves import range

    # Test that AnsibleUnsafe is not wrapped
    assert wrap_var(AnsibleUnsafeText('AnsibleUnsafeText')) == AnsibleUnsafeText('AnsibleUnsafeText')

    # Test string wrappings
    assert isinstance(wrap_var(b'bytes'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'unicode'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'unicode'.encode('utf-8')), AnsibleUnsafeBytes)

    # Test other types
    assert isinstance(wrap_var(True), type(True))
    assert isinstance(wrap_var(3), type(3))


# Generated at 2022-06-11 18:35:14.381499
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils._text import to_unicode
    from ansible.utils.display import Display
    from ansible.parsing.utils.jsonify import jsonify
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    display = Display()
    templar = Templar(display=display)

# Generated at 2022-06-11 18:35:24.729206
# Unit test for function wrap_var
def test_wrap_var():

    # Test cases:
    #    input   expected result
    #    ------  ----------------
    #    None    None
    #    v       <instance of AnsibleUnsafe>
    #    {}      <instance of AnsibleUnsafe> with type dict
    #    []      <instance of AnsibleUnsafe> with type list
    #    str     <instance of AnsibleUnsafe> with type str
    #    tuple   <instance of AnsibleUnsafe> with type tuple
    #    set     <instance of AnsibleUnsafe> with type set
    #    bytes   <instance of AnsibleUnsafe> with type bytes

    # test_case1: input is None
    assert wrap_var(None) is None

    # test_case2: input is AnsibleUnsafe
    unsafe = AnsibleUnsafeText('unsafe')

# Generated at 2022-06-11 18:35:34.473134
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(u'a'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'a'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var([u'a']), tuple)
    assert isinstance(wrap_var([u'a'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var({u'a': u'b'}), dict)
    assert isinstance(wrap_var({u'a': u'b'})[u'a'], AnsibleUnsafeText)
    assert isinstance(wrap_var(NativeJinjaText(u'a')), NativeJinjaUnsafeText)

# Generated at 2022-06-11 18:35:45.701676
# Unit test for function wrap_var
def test_wrap_var():
    import json

    from ansible.module_utils.six import PY2

    # Test AnsibleUnsafeBytes
    val = wrap_var(b'{{ val }}')
    assert isinstance(val, AnsibleUnsafeBytes)

    # Test dict conversion
    val = wrap_var({'val': '{{ val }}'})
    assert isinstance(val['val'], AnsibleUnsafeBytes) if PY2 else isinstance(val['val'], AnsibleUnsafeText)

    # Test list conversion
    val = wrap_var([b'{{ val }}'])
    assert isinstance(val[0], AnsibleUnsafeBytes)

    # Test tuple conversion
    val = wrap_var((b'{{ val }}',))
    assert isinstance(val[0], AnsibleUnsafeBytes)

    # Test set conversion
    val = wrap

# Generated at 2022-06-11 18:35:54.395746
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.unsafe_proxy import wrap_var
    assert wrap_var('hello') == 'hello'
    assert wrap_var('') == ''
    assert wrap_var(0) == 0
    assert wrap_var(1) == 1
    assert wrap_var(1.1) == 1.1
    assert wrap_var({}) == {}
    assert wrap_var({1: 2}) == {1: 2}
    assert wrap_var({'1': 2}) == {'1': 2}
    assert wrap_var({'1': u'2'}) == {'1': u'2'}
    assert wrap_var({u'1': '2'}) == {u'1': '2'}
    assert wrap_var([]) == []
    assert wrap_var([1]) == [1]
    assert wrap

# Generated at 2022-06-11 18:36:04.153032
# Unit test for function wrap_var
def test_wrap_var():
    # Tests for _wrap_dict, _wrap_sequence, _wrap_set
    assert _wrap_dict({'a': 'b'}) == {'a': 'b'}
    assert _wrap_dict({'a': 'b', 'c': 'd'}) == {'a': 'b', 'c': 'd'}
    assert _wrap_sequence([1, 2]) == [1, 2]
    assert _wrap_sequence([1, 2, 3]) == [1, 2, 3]
    assert _wrap_set(['a', 'b']) == {'a', 'b'}
    assert _wrap_set(['a', 'b', 'c']) == {'a', 'b', 'c'}

    # Tests for types that don't need wrapping
    assert wrap_var(None) is None
    assert wrap_

# Generated at 2022-06-11 18:36:12.487147
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from collections import OrderedDict

    assert wrap_var(None) is None
    assert wrap_var('') == AnsibleUnsafeText('')
    assert wrap_var(b'') == AnsibleUnsafeBytes(b'')
    assert wrap_var(u'') == AnsibleUnsafeText(u'')
    assert wrap_var(b'hello') == AnsibleUnsafeBytes(b'hello')
    assert wrap_var(u'test') == AnsibleUnsafeText(u'test')
    if PY3:
        assert wrap_var(u'\N{SNOWMAN}') == AnsibleUnsafeText(u'\N{SNOWMAN}')
    assert wrap_var([]) == []
    assert wrap_var(()) == ()
   

# Generated at 2022-06-11 18:36:21.715890
# Unit test for function wrap_var
def test_wrap_var():
    # Test basic strings
    test = wrap_var('test')
    assert isinstance(test, AnsibleUnsafeText)

    # Test basic integer and float
    test = wrap_var(1)
    assert isinstance(test, int)
    test = wrap_var(1.0)
    assert isinstance(test, float)

    # Test already wrapped objects
    test = wrap_var(UnsafeProxy('test'))
    assert isinstance(test, AnsibleUnsafeText)

    # Test native_jinja_text
    test = wrap_var(NativeJinjaText('test'))
    assert isinstance(test, NativeJinjaUnsafeText)

    # Test basic list
    test = wrap_var(['test'])
    assert isinstance(test, list)