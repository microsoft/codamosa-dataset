

# Generated at 2022-06-11 18:31:43.234261
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common._collections_compat import OrderedDict
    odict = OrderedDict([(u'fòô', u'bàř'), (u'bãż', u'qux'), (u'cøŧę', u'quux')])
    s = [u'fòô', u'bãż', u'cøŧę']
    s2 = set(s)
    s3 = (u'fòô', u'bãż', u'cøŧę')
    str = 'fòô'
    str2 = u'fòô'

    import sys
    PY3 = sys.version_info[0] == 3

    # Check that you can override the superclass by passing an argument.

# Generated at 2022-06-11 18:31:53.468579
# Unit test for function wrap_var
def test_wrap_var():
    # Test wrapped_var containers
    assert isinstance(_wrap_sequence((1, 2, 3)), tuple)
    assert isinstance(_wrap_sequence([1, 2, 3]), list)
    assert isinstance(_wrap_set({1, 2, 3}), set)
    assert isinstance(_wrap_dict({'a': 1, 'b': 2}), dict)

    # Test wrapped_var types
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var('abc'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'abc'), AnsibleUnsafeBytes)
    assert type(wrap_var(u'abc')) is AnsibleUnsafeText
    assert type(wrap_var(r'abc')) is AnsibleUnsafeText

# Generated at 2022-06-11 18:32:03.502049
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils._text import to_text

    assert wrap_var(to_text('foo')) == to_text('foo')
    assert wrap_var(to_text('foo')).__UNSAFE__

    assert wrap_var(to_text('foo')) == wrap_var(to_text('foo'))

    assert wrap_var([1, 2, 3]) == [1, 2, 3]
    assert wrap_var(['foo', 'bar']) == ['foo', 'bar']
    assert wrap_var(['foo', 'bar']).__UNSAFE__

    assert wrap_var([1, 2, 3]) == wrap_var([1, 2, 3])

    assert wrap_var((1, 2, 3)) == (1, 2, 3)

# Generated at 2022-06-11 18:32:13.038987
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(1), int)
    assert isinstance(wrap_var(1.0), float)
    assert isinstance(wrap_var('string'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'binary'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var({}), dict)
    assert isinstance(wrap_var([]), list)
    assert isinstance(wrap_var(set()), set)
    assert isinstance(wrap_var({1: 1}), dict)
    assert isinstance(wrap_var([1]), list)
    assert isinstance(wrap_var(set([1])), set)
    assert isinstance(wrap_var((1,)), tuple)
    assert isinstance(wrap_var({1: 'string'}), dict)

# Generated at 2022-06-11 18:32:25.113614
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY2
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)

    if PY2:
        assert isinstance(wrap_var(long('1')), AnsibleUnsafeText)
        assert isinstance(wrap_var(unicode('foo')), AnsibleUnsafeText)
    else:
        assert not isinstance(wrap_var(int('1')), AnsibleUnsafeText)
        assert isinstance(wrap_var(u'abc'), AnsibleUnsafeText)

    assert isinstance(wrap_var({'foo': 'bar'}), dict)

# Generated at 2022-06-11 18:32:35.040706
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import string_types, binary_type
    from ansible.module_utils.six.moves import cStringIO

    class FakeStream(object):
        def __init__(self, *args, **kwargs):
            pass

    class FakeStreamBinary(FakeStream):
        def __init__(self, *args, **kwargs):
            super(FakeStreamBinary, self).__init__()
            self._data = to_bytes('foo')

        def read(self):
            return to_bytes('foo')

    class FakeStreamText(FakeStream):
        def __init__(self, *args, **kwargs):
            super(FakeStreamText, self).__init__()
            self._data = 'foo'

        def read(self):
            return 'foo'


# Generated at 2022-06-11 18:32:46.319517
# Unit test for function wrap_var
def test_wrap_var():
    assert(isinstance(wrap_var('helloworld'), AnsibleUnsafeText))
    assert(isinstance(wrap_var(u'helloworld'), AnsibleUnsafeText))
    assert(isinstance(wrap_var(b'helloworld'), AnsibleUnsafeBytes))
    assert(isinstance(wrap_var(['helloworld']), list))
    assert(isinstance(wrap_var(['helloworld'])[0], AnsibleUnsafeText))
    assert(isinstance(wrap_var(['helloworld', u'helloworld']), list))
    assert(isinstance(wrap_var(['helloworld', u'helloworld'])[1], AnsibleUnsafeText))
    assert(isinstance(wrap_var(('helloworld',)), tuple))

# Generated at 2022-06-11 18:32:53.046986
# Unit test for function wrap_var
def test_wrap_var():  # pragma: no cover
    import json

    example = dict(
        foo="bar",
        bar=[1, 2, 3],
        baz=u"b\u00e4z",
        bam=dict(
            bar=[1, 2, 3],
            baz=u"b\u00e4z",
        ),
        baz1=dict(
            bar=[1, 2, 3],
            baz=u"b\u00e4z",
        )
    )

    wrapped = wrap_var(example)
    assert isinstance(wrapped, dict)
    assert isinstance(wrapped["foo"], type(u" "))
    assert isinstance(wrapped["bar"], list)
    assert isinstance(wrapped["bar"][0], int)

# Generated at 2022-06-11 18:33:01.994149
# Unit test for function wrap_var
def test_wrap_var():
    example = dict(example=True, dict=dict(a=1, b=2, c=3), list=[1, 2, 3], set=set([1, 2, 3]))
    converted = wrap_var(example)
    assert converted == example
    assert isinstance(list(converted.values())[0], AnsibleUnsafe)
    assert isinstance(list(converted.values())[1]['a'], AnsibleUnsafe)
    assert isinstance(list(converted.values())[2][0], AnsibleUnsafe)
    assert isinstance(list(converted.values())[3][0], AnsibleUnsafe)

    example = "example"
    converted = wrap_var(example)
    assert converted == example
    assert isinstance(converted, AnsibleUnsafe)

# Generated at 2022-06-11 18:33:07.295441
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(True)
    assert wrap_var(b'haha') == to_unsafe_bytes('haha')
    assert wrap_var('haha') == to_unsafe_text('haha')
    assert wrap_var([123456]) == [123456]
    assert wrap_var({1: 2}) == {1: 2}
    assert wrap_var((1, 2)) == (1, 2)

# Generated at 2022-06-11 18:33:16.247794
# Unit test for function wrap_var
def test_wrap_var():

    import pytest
    from ansible.module_utils.six.moves import builtins

    # test wrap string
    assert wrap_var("abc") == AnsibleUnsafeText("abc")
    # test wrap unicode
    assert wrap_var(u"abc") == AnsibleUnsafeText(u"abc")

    # test wrap list
    assert wrap_var([u"abc", u"def"]) == [AnsibleUnsafeText(u"abc"), AnsibleUnsafeText(u"def")]
    # test wrap dict
    assert wrap_var({u"abc": u"def"}) == {AnsibleUnsafeText(u"abc"): AnsibleUnsafeText(u"def")}

    # test wrap unsafe text
    assert wrap_var(AnsibleUnsafeText("abc")) == AnsibleUnsafeText("abc")

# Generated at 2022-06-11 18:33:26.696590
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import string_types, binary_type, text_type

    assert isinstance(wrap_var(None), type(None))
    for s in string_types:
        assert isinstance(wrap_var(s), AnsibleUnsafeText)
    assert isinstance(wrap_var(str('')), AnsibleUnsafeText)
    assert isinstance(wrap_var(binary_type(b'')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(text_type(u'')), AnsibleUnsafeText)
    assert isinstance(wrap_var(NativeJinjaText(u'')), NativeJinjaUnsafeText)
    assert isinstance(wrap_var(u''), AnsibleUnsafeText)
    assert isinstance(wrap_var(''), AnsibleUnsafeText)

# Generated at 2022-06-11 18:33:37.672794
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.unsafe_proxy import wrap_var
    assert wrap_var('a') == 'a'
    assert wrap_var(5) == 5
    assert wrap_var(b'a') == b'a'
    assert wrap_var(None) is None
    assert isinstance(wrap_var(b'a'), AnsibleUnsafeBytes)

    assert wrap_var(dict(foo='bar')) == dict(foo='bar')
    assert isinstance(wrap_var(dict(foo=b'bar')), dict)
    assert isinstance(wrap_var(dict(foo='bar').keys()), list)
    assert isinstance(wrap_var(dict(foo='bar').values()), list)
    assert isinstance(wrap_var(dict(foo='bar').items()), list)

# Generated at 2022-06-11 18:33:48.534380
# Unit test for function wrap_var

# Generated at 2022-06-11 18:33:59.479295
# Unit test for function wrap_var
def test_wrap_var():

    assert wrap_var(5) == 5
    assert wrap_var(5.5) == 5.5
    assert wrap_var(True) is True
    assert isinstance(wrap_var("string"), AnsibleUnsafeText)
    assert isinstance(wrap_var(UnsafeProxy("string")), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'string'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'string'), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeText(u'string')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeText('string')), AnsibleUnsafeText)
    assert wrap_var(None) is None


# Generated at 2022-06-11 18:34:05.734905
# Unit test for function wrap_var
def test_wrap_var():

    # Wrap_var, a recursive function that wraps each element of a dictionary
    # or, if the element is itself a dictionary, it calls wrap_var on that element
    # Primarily used in conjunction with JSON de-serialization.

    # Test Strings, bytes, and text
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(text_type('foo')), AnsibleUnsafeText)

    # Test dictionaries
    d1 = wrap_var({'foo': 'bar', 1: 2})
    assert isinstance(d1, dict)
    assert isinstance(d1['foo'], AnsibleUnsafeText)
    assert isinstance(d1[1], int)

    # Test lists and tuples

# Generated at 2022-06-11 18:34:15.948042
# Unit test for function wrap_var
def test_wrap_var():
    # Simple value
    assert wrap_var(u'foo') == to_unsafe_text(u'foo')
    assert wrap_var(b'foo') == to_unsafe_bytes(b'foo')
    assert wrap_var(1) == 1
    assert wrap_var(None) is None
    assert isinstance(wrap_var(to_unsafe_text(u'foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(to_unsafe_bytes(b'foo')), AnsibleUnsafeBytes)

    # String type sequences
    assert wrap_var(('foo', 'bar')) == ('foo', 'bar')
    assert wrap_var(('foo', b'bar')) == (to_unsafe_text('foo'), to_unsafe_bytes(b'bar'))
    assert wrap_var

# Generated at 2022-06-11 18:34:25.744701
# Unit test for function wrap_var
def test_wrap_var():
    import collections
    import sys
    import types

    if sys.version_info[0] == 2:
        from ansible.module_utils.pycompat24 import get_native_type
        # Need to set the doctest namespace to work correctly in Python 2
        import __builtin__
        __builtin__.__test_ns = {'AnsibleUnsafe': AnsibleUnsafe,
                                 'AnsibleUnsafeBytes': AnsibleUnsafeBytes,
                                 'AnsibleUnsafeText': AnsibleUnsafeText,
                                 'NativeJinjaUnsafeText': NativeJinjaUnsafeText}

    # Test safe input
    assert wrap_var(None) is None
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText

# Generated at 2022-06-11 18:34:37.905608
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(123) == 123

    # wrap_var(AnsibleUnsafe) returns original object
    unsafe = AnsibleUnsafe()
    assert wrap_var(unsafe) is unsafe

    # wrap_var(dict)
    assert wrap_var({}) == {}
    assert wrap_var({"a": "A"}) == {"a": wrap_var("A")}
    assert wrap_var({"a": "A", "0": 1}) == {"a": wrap_var("A"), "0": wrap_var(1)}

    # wrap_var(list)
    assert wrap_var([]) == []
    assert wrap_var(["A"]) == [wrap_var("A")]

# Generated at 2022-06-11 18:34:44.096592
# Unit test for function wrap_var
def test_wrap_var():
    for data in ({'str': 'str', 'list': ['str', 'list'], 'dict': {'str': 'str', 'list': ['str', 'list']}, 'None': None}, ['str', ['str', 'list'], {'str': 'str', 'list': ['str', 'list']}, None], 'str', 1, [], ()):
        assert wrap_var(data) == wrap_var(wrap_var(data))

