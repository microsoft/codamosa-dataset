

# Generated at 2022-06-11 18:31:43.013465
# Unit test for function wrap_var
def test_wrap_var():
    # wrap_var of strings and other types
    assert isinstance(wrap_var("Some_Test_String"), AnsibleUnsafeText)
    assert isinstance(wrap_var(1), int)
    assert isinstance(wrap_var(True), bool)
    assert isinstance(wrap_var([]), list)
    assert isinstance(wrap_var({}), dict)
    assert isinstance(wrap_var({'key': 'value'}), dict)

    # wrap_var list and dict
    assert isinstance(wrap_var([1, '2', 3]), list)
    assert isinstance(wrap_var(['1', '2', '3']), list)
    assert isinstance(wrap_var({'a': 1, 'b': '2', 'c': 3}), dict)

# Generated at 2022-06-11 18:31:52.322845
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import string_types

    assert wrap_var("foo bar")
    assert wrap_var("foo bar") == AnsibleUnsafeText("foo bar")
    assert isinstance(wrap_var("foo bar"), AnsibleUnsafeText)
    assert isinstance(wrap_var("foo bar"), string_types)
    assert wrap_var('value') == 'value'
    assert wrap_var(['value']) == ['value']
    assert isinstance(wrap_var(['value']), list)
    assert wrap_var({'key': 'value'}) == {'key': 'value'}
    assert isinstance(wrap_var({'key': 'value'}), dict)

# Generated at 2022-06-11 18:32:02.921831
# Unit test for function wrap_var
def test_wrap_var():
    # Test variable wrapping of different python data types,
    # * Sequence: list, tuple, set
    # * Mapping: dictionary
    # * Native type: string, unicode
    # * Built-in types: integer, float, bool
    # * Native jinja text(NativeJinjaText)
    from ansible.utils.display import Display
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.native_jinja import NativeJinjaText

    display = Display()
    data_type = [
        list,
        tuple,
        set,
        dict,
        str,
        text_type,
        int,
        float,
        bool,
        NativeJinjaText
    ]

    # Generate test case base on data type
    test_cases = []

# Generated at 2022-06-11 18:32:12.639869
# Unit test for function wrap_var
def test_wrap_var():
    import types

    a = [NativeJinjaText('I think I am a Jinja template'), 'I am just a string']
    expected_wrapped_str = [NativeJinjaUnsafeText('I think I am a Jinja template'), AnsibleUnsafeText('I am just a string')]
    expected_wrapped_tuple = (NativeJinjaUnsafeText('I think I am a Jinja template'), AnsibleUnsafeText('I am just a string'))

    actual_wrapped_str = wrap_var(a)
    actual_wrapped_tuple = wrap_var(tuple(a))
    actual_wrapped_bytes = wrap_var(to_bytes(a))
    actual_wrapped_text = wrap_var(to_text(a))


# Generated at 2022-06-11 18:32:24.527520
# Unit test for function wrap_var
def test_wrap_var():
    assert tuple == type(wrap_var(tuple()))
    assert list == type(wrap_var(list()))
    assert dict == type(wrap_var(dict()))
    assert set == type(wrap_var(set()))
    assert frozenset == type(wrap_var(frozenset()))

    assert tuple == type(wrap_var((1, 2)))
    assert list == type(wrap_var([1, 2]))
    assert dict == type(wrap_var({1: 2}))
    assert set == type(wrap_var({1, 2}))
    assert frozenset == type(wrap_var(frozenset((1, 2))))

    assert 2 == len(wrap_var((1, 2)))
    assert 2 == len(wrap_var([1, 2]))

# Generated at 2022-06-11 18:32:34.627903
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(u"foo"), AnsibleUnsafeText)
    assert isinstance(wrap_var(to_text(b"foo", errors='surrogate_or_strict')), AnsibleUnsafeText)
    assert isinstance(wrap_var({u"foo": u"bar"}), dict)
    assert isinstance(wrap_var({b"foo": b"bar"}), dict)
    assert isinstance(wrap_var({u"foo": u"bar"})[u"foo"], AnsibleUnsafeText)
    assert isinstance(wrap_var({b"foo": b"bar"})[b"foo"], AnsibleUnsafeBytes)
    assert isinstance(wrap_var([u"foo", u"bar"]), list)
    assert isinstance(wrap_var([b"foo", b"bar"]), list)
   

# Generated at 2022-06-11 18:32:45.964124
# Unit test for function wrap_var
def test_wrap_var():
    # Test for text_type
    assert isinstance(wrap_var("Test For text_type"), AnsibleUnsafeText)
    # Test for binary_type
    assert isinstance(wrap_var(b"Test For binary_type"), AnsibleUnsafeBytes)
    # Test for tuple
    assert isinstance(wrap_var(('Test', 'For', 'Tuple')), tuple)
    assert isinstance(wrap_var(('Test', 'For', 'Tuple'))[0], AnsibleUnsafeText)
    # Test for list
    assert isinstance(wrap_var(['Test', 'For', 'List']), list)
    assert isinstance(wrap_var(['Test', 'For', 'List'])[0], AnsibleUnsafeText)
    # Test for dict

# Generated at 2022-06-11 18:32:52.889707
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.urls import open_url
    from collections import namedtuple

    from ansible.module_utils.common.validation import check_password
    from ansible.parsing.splitter import parse_kv
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves import shlex_quote

    TestNone = wrap_var(None)
    assert isinstance(TestNone, type(None))

    TestByte = wrap_var(b"BinaryString")
    assert isinstance(TestByte, AnsibleUnsafeBytes)


# Generated at 2022-06-11 18:33:02.274358
# Unit test for function wrap_var
def test_wrap_var():
    import time
    import datetime
    import json

    class Useless(object):
        pass

    class Useful(object):
        def __str__(self):
            return 'foo'

    class UsefulBytes(object):
        def __bytes__(self):
            return b'foo'

    class UsefulText(object):
        def __unicode__(self):
            return u'foo'

    assert wrap_var(None) is None
    assert wrap_var(3) == 3
    assert wrap_var(3.4) == 3.4
    assert wrap_var(Useful()) == 'foo'
    assert wrap_var(UsefulBytes()) == b'foo'
    assert wrap_var(UsefulText()) == u'foo'
    assert isinstance(wrap_var(True), bool)

# Generated at 2022-06-11 18:33:11.782287
# Unit test for function wrap_var
def test_wrap_var():
    import jinja2
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(1), int)
    assert isinstance(wrap_var([1, 2]), tuple)
    assert isinstance(wrap_var({1: 2}), dict)
    assert isinstance(wrap_var(jinja2.Markup('foo')), NativeJinjaUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes('foo')), AnsibleUnsafeBytes)