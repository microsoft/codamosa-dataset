

# Generated at 2022-06-11 18:31:40.460402
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import string_types, binary_type, text_type

    # Simply wrap everything in unsafe
    expected = AnsibleUnsafeText('foo')
    actual = wrap_var('foo')
    assert type(actual) == AnsibleUnsafeText
    assert actual == expected

    expected = AnsibleUnsafeBytes('foo')
    actual = wrap_var(b'foo')
    assert type(actual) == AnsibleUnsafeBytes
    assert actual == expected

    # Wrap dict
    expected = dict(
        foo=AnsibleUnsafeText('foo'),
        bar=AnsibleUnsafeText('bar')
    )
    actual = wrap_var({'foo': 'foo', 'bar': 'bar'})
    assert type(actual) == dict
    assert actual == expected

    # Wrap list

# Generated at 2022-06-11 18:31:49.452602
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert isinstance(wrap_var(b'foobarbaz'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foobarbaz'), AnsibleUnsafeText)
    assert isinstance(wrap_var(12345), int)
    assert isinstance(wrap_var(dict(a=1)), dict)
    assert isinstance(wrap_var(tuple(range(10))), tuple)
    assert isinstance(wrap_var(set(range(10))), set)
    assert isinstance(wrap_var(set(b'foobarbaz')), set)

# Generated at 2022-06-11 18:32:01.832885
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence
    import datetime
    import decimal
    import fractions

    class MyObject:
        def __init__(self, answer):
            self.answer = answer

    assert wrap_var(42) == 42
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(None) is None

    assert wrap_var(MyObject(42)) == MyObject(42)

    assert wrap_var(u'hello') == AnsibleUnsafeText(u'hello')
    assert wrap_var('hello') == AnsibleUnsafeText(to_text(b'hello'))
    assert wrap_var(b'hello') == AnsibleUnsafe

# Generated at 2022-06-11 18:32:04.820945
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(1) == 1
    assert wrap_var(['a', 'b']) == ['a', 'b']

# Generated at 2022-06-11 18:32:13.823049
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(NativeJinjaText('foo')), NativeJinjaUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeText(u'foo')), AnsibleUnsafeText)

# Generated at 2022-06-11 18:32:25.783869
# Unit test for function wrap_var
def test_wrap_var():
    import ansible.module_utils.common.ast as ast
    import ansible.module_utils.common.collections as collections

    # Test text string
    assert(isinstance(wrap_var("str"), AnsibleUnsafeText))

    # Test byte string
    assert(isinstance(wrap_var(b"bytes"), AnsibleUnsafeBytes))

    # Test binary_type
    assert(isinstance(wrap_var(binary_type(b"byte")), AnsibleUnsafeBytes))

    # Test text_type
    assert(isinstance(wrap_var(text_type("text")), AnsibleUnsafeText))

    # Test dict
    dict_value = {"k1": "v1", "k2": 2}
    result = wrap_var(dict_value)
    assert(isinstance(result, dict))

# Generated at 2022-06-11 18:32:35.465987
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils._text import to_text
    import jinja2
    import copy
    some_dict = {'some': 'value', 'another': {'foo': 'bar'}}
    some_dict_copy = copy.deepcopy(some_dict)
    # Test some_dict is unmodified
    assert some_dict == some_dict_copy
    # Test wrap_var with dict
    wrapped = wrap_var(some_dict)
    assert wrapped == some_dict_copy
    assert isinstance(wrapped, dict)
    # Test some_dict is unmodified
    assert some_dict == some_dict_copy
    # Test each item in the dict
    for k, v in wrapped.items():
        # Ensure keys are of type unicode
        assert isinstance(k, text_type)
        # Ensure values have been

# Generated at 2022-06-11 18:32:46.516002
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import string_types, binary_type, text_type
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    r = wrap_var(None)
    assert r is None

    r = wrap_var(AnsibleUnsafeText())
    assert isinstance(r, AnsibleUnsafeText)

    r = wrap_var(AnsibleUnsafeBytes())
    assert isinstance(r, AnsibleUnsafeBytes)

    r = wrap_var('unsafe')
    assert isinstance(r, AnsibleUnsafeText)
    assert isinstance(r, string_types)
    assert isinstance(r, text_type)

    r = wrap_var(b'unsafe')


# Generated at 2022-06-11 18:32:53.112485
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var('TEST'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'TEST'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'TEST'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(123), int)
    assert isinstance(wrap_var('123'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'123'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'123'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(True), bool)

    assert isinstance(wrap_var([u'TEST']), list)
    assert isinstance(wrap_var([u'TEST'])[0], AnsibleUnsafeText)

# Generated at 2022-06-11 18:33:02.307065
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    display = Display()

    _mydict = dict()
    _mydict['foo'] = 'bar'
    _mydict['faz'] = {'fiz': 'buz', 'biz': 10}
    _mydict['fap'] = ['apa', 'bepa']
    plain_text = 'foo bar'
    plain_bytes = to_bytes('foo bar')
    native_jinja_text = NativeJinjaText(to_text('foo bar'))

    input_values = [_mydict, plain_text, plain_bytes, native_jinja_text]

    # Case 1: This is a normal run of wrap_var
    for v in input_values:
        output_value = wrap_var(v)