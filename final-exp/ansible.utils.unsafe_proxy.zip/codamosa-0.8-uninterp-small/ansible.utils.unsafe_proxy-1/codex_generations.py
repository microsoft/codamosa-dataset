

# Generated at 2022-06-25 13:44:52.106703
# Unit test for function wrap_var
def test_wrap_var():
    ansible_unsafe_0 = AnsibleUnsafe()
    data = {
        'foo': 'foo',
        'bar': ansible_unsafe_0,
        'baz': {
            'foo': [1, 2, 'foo'],
            'bar': ansible_unsafe_0,
        },
        'qux': {
            'foo': [1, 2, 'foo'],
            'bar': [3, 4, 'bar'],
            'baz': {
                'foo': 'foo',
                'bar': ansible_unsafe_0,
            },
        }
    }

    result = wrap_var(data)
    assert result['bar'] is ansible_unsafe_0
    assert result['baz']['bar'] is ansible_unsafe_0

# Generated at 2022-06-25 13:44:56.531365
# Unit test for function wrap_var
def test_wrap_var():
    obj = {}
    obj_wrapped = wrap_var(obj)

    assert obj != obj_wrapped

    assert not isinstance(obj, dict)
    assert isinstance(obj_wrapped, dict)

    assert not isinstance(obj, AnsibleUnsafe)
    assert isinstance(obj_wrapped, AnsibleUnsafe)



# Generated at 2022-06-25 13:45:07.076927
# Unit test for function wrap_var
def test_wrap_var():
    ansible_unsafe_bytes_0 = AnsibleUnsafeBytes("I am a string")
    ansible_unsafe_bytes_1 = AnsibleUnsafeBytes("I am a string")
    ansible_unsafe_bytes_2 = AnsibleUnsafeBytes("I am a string")
    ansible_unsafe_bytes_3 = AnsibleUnsafeBytes("I am a string")
    ansible_unsafe_text_0 = AnsibleUnsafeText("I am a string")
    native_jinja_unsafe_text_0 = NativeJinjaUnsafeText("I am a string")
    # Assemble a list of tests
    # This list is meant to serve as a master list of tests to run. Once we
    # have the patterns of what tests to run, we can generate tests
    # automatically from the patterns.
    # There should

# Generated at 2022-06-25 13:45:13.691193
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(AnsibleUnsafe()) == AnsibleUnsafe()

    assert wrap_var(None) == None
    assert wrap_var({}) == {}
    assert wrap_var([]) == []
    assert wrap_var(set()) == set()
    assert wrap_var('a') == AnsibleUnsafeText(u'a')

    assert wrap_var(NativeJinjaText(u'a')) == NativeJinjaUnsafeText(u'a')



# Generated at 2022-06-25 13:45:24.117299
# Unit test for function wrap_var
def test_wrap_var():
    # Test function wrap_var with dict, set, string, int, None and list input arguments
    # Test function wrap_var with None and string input arguments

    assert wrap_var(None) == None

    # Test function wrap_var with dict input argument

    assert wrap_var({}) == dict()
    assert wrap_var({'key_0': 'val_0'}) == dict({'key_0': 'val_0'})

    # Test function wrap_var with set input argument

    assert wrap_var(set()) == set()
    assert wrap_var(set([b'val_0', b'val_1'])) == set([b'val_0', b'val_1'])

    # Test function wrap_var with string input argument

    assert wrap_var(b'val_0') == b'val_0'

    # Test

# Generated at 2022-06-25 13:45:35.979334
# Unit test for function wrap_var
def test_wrap_var():
    assert 1
    # TODO: Enable test(s)
    # # UnsafeProxy is deprecated and only exists to maintain backwards
    # # compatibility.
    # assert AnsibleUnsafe == UnsafeProxy
    #
    # # Test wrap_var
    # assert wrap_var(True) is True
    # assert wrap_var(False) is False
    #
    # # Test various iterables
    # my_list = [1, 2, 3]
    # my_tuple = (4, 5, 6)
    # my_set = set([7, 8, 9])
    # assert wrap_var(my_list) is my_list
    # assert wrap_var(my_tuple) is my_tuple
    # assert wrap_var(my_set) is my_set
    #
    # my_list[0]

# Generated at 2022-06-25 13:45:47.569919
# Unit test for function wrap_var
def test_wrap_var():
    ansible_unsafe_0 = AnsibleUnsafe()
    dict_0 = {}
    test_0 = wrap_var(dict_0)
    ansible_unsafe_text_0 = AnsibleUnsafeText('test')
    test_1 = wrap_var(ansible_unsafe_text_0)
    test_2 = wrap_var(test_1)
    ansible_unsafe_bytes_0 = AnsibleUnsafeBytes(b'test_1')
    test_3 = wrap_var(ansible_unsafe_bytes_0)
    test_4 = wrap_var(test_3)
    ansible_unsafe_0 = AnsibleUnsafe()
    test_5 = wrap_var(ansible_unsafe_0)
    test_6 = wrap_var(test_5)
    native_jin

# Generated at 2022-06-25 13:45:56.762165
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var("Hello, world!\n") == AnsibleUnsafeText("Hello, world!\n")
    assert wrap_var("Hello, world!\n") == AnsibleUnsafeText("Hello, world!\n")
    assert wrap_var("Hello, world!\n") == AnsibleUnsafeText("Hello, world!\n")
    assert wrap_var("Hello, world!") == AnsibleUnsafeText("Hello, world!")
    assert wrap_var("Hello, world!") == AnsibleUnsafeText("Hello, world!")
    assert wrap_var("Hello, world!") == AnsibleUnsafeText("Hello, world!")
    assert wrap_var("Hello, world!") == AnsibleUnsafeText("Hello, world!")

# Generated at 2022-06-25 13:46:02.537666
# Unit test for function wrap_var
def test_wrap_var():
    d = wrap_var("Hello world W00T!!")
    assert(isinstance(d, AnsibleUnsafeText))

    class MyClass(object):
        pass

    d = wrap_var("Hello world W00T!!")
    assert(not isinstance(d, MyClass))

    d = wrap_var("Hello world W00T!!")
    assert(not isinstance(d, str))

    d = wrap_var("Hello world W00T!!")
    assert(isinstance(d, text_type))
    assert(isinstance(d, AnsibleUnsafeText))

    d = wrap_var(b"Hello world W00T!!")
    assert(isinstance(d, AnsibleUnsafeBytes))

# Generated at 2022-06-25 13:46:11.779862
# Unit test for function wrap_var
def test_wrap_var():
    ansible_unsafe_1 = AnsibleUnsafe()
    dict_1 = {}
    to_byte_1 = b'Binary string'
    to_text_1 = 'Unicode string'
    dict_1['ansible_unsafe'] = ansible_unsafe_1
    dict_1['dict'] = {}
    dict_1['dict']['to_byte'] = to_byte_1
    dict_1['dict']['to_text'] = to_text_1

    wrapped_dict_1 = wrap_var(dict_1)
    assert isinstance(wrapped_dict_1['dict']['to_byte'], type(b'')) == True
    assert isinstance(wrapped_dict_1['dict']['to_text'], type(u'')) == True
