

# Generated at 2022-06-25 13:44:55.738671
# Unit test for function wrap_var
def test_wrap_var():
    # Node types
    assert type(wrap_var(None)) is type(None)
    assert type(wrap_var(True)) is type(True)
    assert type(wrap_var(1)) is type(1)
    assert type(wrap_var(1.0)) is type(1.0)

    # Sequence types
    test_list = ["foo", "bar", "baz"]
    test_list_wrapped = wrap_var(test_list)
    assert is_sequence(test_list_wrapped)
    assert type(test_list_wrapped) is type(test_list)
    assert len(test_list) == len(test_list_wrapped)
    assert test_list_wrapped[0] is test_list[0]

# Generated at 2022-06-25 13:45:06.415752
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('hello') == b'hello'
    assert wrap_var(b'bye') == b'bye'
    assert wrap_var(1) == 1
    assert wrap_var(1.5) == 1.5
    assert wrap_var(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert wrap_var(['a', 1, 'c']) == ['a', 1, 'c']
    assert wrap_var(('a', 'b', 'c')) == ('a', 'b', 'c')
    assert wrap_var(('a', 1, 'c')) == ('a', 1, 'c')
    assert wrap_var({'a': 'b'}) == {'a': 'b'}

# Generated at 2022-06-25 13:45:08.648244
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(to_text('test')) == 'test'
    assert wrap_var(to_bytes('test')) == b'test'

# Generated at 2022-06-25 13:45:12.504772
# Unit test for function wrap_var
def test_wrap_var():
    empty_dict_unicode_text = {'empty_dict': {}}
    print(wrap_var(empty_dict_unicode_text))
    if __name__ == "__main__":
        import sys
        sys.exit(1)

# Generated at 2022-06-25 13:45:23.113935
# Unit test for function wrap_var
def test_wrap_var():
    # Test case: Empty string is wrapped as unsafe
    assert type(wrap_var('')) is AnsibleUnsafeText
    # Test case: Safe string is also wrapped as unsafe
    assert type(wrap_var(AnsibleUnsafeText('test'))) is AnsibleUnsafeText
    # Test case: Test dictionary is protected against unsafe recursion
    test_var = {'test': 'test'}
    assert type(wrap_var(test_var)['test']) is AnsibleUnsafeText
    # Test case: Test list is protected against unsafe recursion
    test_var = ['test']
    assert type(wrap_var(test_var)[0]) is AnsibleUnsafeText
    # Test case: Test tuple is protected against unsafe recursion
    test_var = ('test',)

# Generated at 2022-06-25 13:45:34.910225
# Unit test for function wrap_var
def test_wrap_var():
    class Test1(object):
        def __init__(self):
            self.data = {'a': 1}

    # test unicode
    string_type = u'foo'
    assert isinstance(wrap_var(string_type), AnsibleUnsafeText)

    # test dict
    dict_type = dict(a=1)
    assert isinstance(wrap_var(dict_type), dict)
    assert isinstance(wrap_var(dict_type)['a'], AnsibleUnsafe)

    # test boolean
    boolean_type = True
    assert wrap_var(boolean_type) is True

    # test custom object
    custom_object_type = Test1()
    assert isinstance(wrap_var(custom_object_type), Test1)

# Generated at 2022-06-25 13:45:39.913285
# Unit test for function wrap_var
def test_wrap_var():
    ansible_unsafe = AnsibleUnsafe()
    ansible_unsafe_1 = AnsibleUnsafe()

    assert wrap_var('-') == '-'
    assert wrap_var(-1) == -1
    assert wrap_var(None) == None
    assert wrap_var(ansible_unsafe) == ansible_unsafe
    assert wrap_var('-') is not ansible_unsafe
    assert wrap_var(ansible_unsafe) is ansible_unsafe
    assert wrap_var(ansible_unsafe) is ansible_unsafe_1

    # Test tuples
    assert wrap_var((1, 2, 3)) == (1, 2, 3)
    assert wrap_var((1, 2, 3)) != (1, 2, '3')
    assert wrap_var((1, 2, 3))

# Generated at 2022-06-25 13:45:51.971333
# Unit test for function wrap_var
def test_wrap_var():
    import types
    import json
    import random
    random.seed(0)

    def random_data(depth):
        if random.randint(0, 5) == 0 or depth > 1:
            if random.random() < 0.5:
                return wrap_var(random.randint(0, 100))
            else:
                return wrap_var(random.random())
        elif random.random() < 0.2:
            return wrap_var([])
        elif random.random() < 0.4:
            return wrap_var(())
        else:
            return wrap_var({})

    def random_fill(container):
        if isinstance(container, dict):
            while len(container) < random.randint(0, 5):
                container[random_data(0)] = random_data(0)
       

# Generated at 2022-06-25 13:46:00.242736
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(False) is False
    assert wrap_var(0) == 0
    assert wrap_var(0.0) == 0.0
    assert wrap_var(0j) == 0j
    assert wrap_var("") == ""
    assert wrap_var(b"") == b""
    assert wrap_var(()) == ()
    assert wrap_var([]) == []
    assert wrap_var({}) == {}
    assert wrap_var({'key': 'value'}) == {'key': 'value'}
    assert wrap_var({'key': 'value'}) == {'key': 'value'}
    assert isinstance(wrap_var("unsafe"), AnsibleUnsafeText)

# Generated at 2022-06-25 13:46:10.530191
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafe()) is AnsibleUnsafe
    assert isinstance(wrap_var(1), int)
    assert isinstance(wrap_var(1.0), float)
    assert isinstance(wrap_var(""), text_type)
    assert isinstance(wrap_var(u""), text_type)
    assert isinstance(wrap_var(b""), binary_type)
    assert isinstance(wrap_var(bytearray(b"")), binary_type)
    assert isinstance(wrap_var([1]), list)
    assert isinstance(wrap_var((1,)), tuple)
    assert isinstance(wrap_var({}), dict)
    assert isinstance(wrap_var({1: 2}), dict)

# Generated at 2022-06-25 13:46:24.325572
# Unit test for function wrap_var
def test_wrap_var():
    print("Testing wrap_var()")

    # Test 1: None
    expected_result = None
    result = wrap_var(None)
    assert expected_result == result

    # Test 2: String
    expected_result = to_text(b'AnsibleUnsafeText(u\'foobar\')')
    result = wrap_var(b'foobar')
    assert expected_result == to_text(result)

    # Test 3: Dict
    input_dict = {'foo':'bar'}
    expected_result = to_text(input_dict)
    result = wrap_var(input_dict)
    assert expected_result == to_text(result)

    # Test 4: List
    input_list = ['foo','bar']
    expected_result = to_text(['foo','bar'])

# Generated at 2022-06-25 13:46:28.517901
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(to_bytes('Hello World')) == to_unsafe_bytes('Hello World')
    assert wrap_var(to_bytes('Hello World', encoding='utf-8')) == to_unsafe_bytes('Hello World')


if __name__ == '__main__':
    # Unit tests for wrapped types
    test_case_0()
    test_wrap_var()
    pass

# Generated at 2022-06-25 13:46:34.074916
# Unit test for function wrap_var
def test_wrap_var():
    # Test with normal string
    assert wrap_var(NativeJinjaText('test')) == NativeJinjaUnsafeText('test')

    seq = [NativeJinjaText('test')]
    assert wrap_var(seq) == seq

    assert wrap_var(None) is None

    assert wrap_var(dict(a=NativeJinjaText('test'))) == dict(a=NativeJinjaUnsafeText('test'))

    assert wrap_var(set([NativeJinjaText('test')])) == set([NativeJinjaUnsafeText('test')])

# Generated at 2022-06-25 13:46:43.370855
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(True), type(True))
    assert isinstance(wrap_var(1), type(1))
    assert isinstance(wrap_var(1.0), type(1.0))
    assert isinstance(wrap_var(AnsibleUnsafe()), AnsibleUnsafe)
    assert isinstance(wrap_var(['a']), type(['a']))
    assert isinstance(wrap_var(('a',)), type(('a',)))
    assert isinstance(wrap_var({'a': 'a'}), type({'a': 'a'}))
    assert wrap_var(AnsibleUnsafeText(u'foo')) is AnsibleUnsafeText(u'foo')

# Generated at 2022-06-25 13:46:51.434003
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.unsafe_proxy import wrap_var

    dl = DataLoader()
    vars_manager = VariableManager()
    result = wrap_var("{{ local_var_0 }}")

    assert isinstance(result, AnsibleUnsafeText)

    result = wrap_var({"{{ local_var_0 }}": "{{ local_var_1 }}"})

    assert isinstance(result, dict)
    assert isinstance(next(iter(result.keys())), AnsibleUnsafeText)
    assert isinstance(next(iter(result.values())), AnsibleUnsafeText)

# Generated at 2022-06-25 13:47:01.690008
# Unit test for function wrap_var
def test_wrap_var():
    # Test wraps a string
    test_string = 'test_string'
    assert wrap_var(test_string) == AnsibleUnsafeText('test_string')

    # Test wraps a byte
    test_byte = b'$test_byte'
    assert wrap_var(test_byte) == AnsibleUnsafeBytes(b'$test_byte')
    
    # Test wraps a dictionary with a string as a value
    test_dict_string_value = {'test_dict': 'test_string'}
    assert wrap_var(test_dict_string_value) == {'test_dict': AnsibleUnsafeText('test_string')}

    # Test wraps a list of strings
    test_list_strings = ['test_string_0', 'test_string_1']

# Generated at 2022-06-25 13:47:08.585808
# Unit test for function wrap_var
def test_wrap_var():
    # Check a wrapped var
    assert isinstance(wrap_var(1), AnsibleUnsafe)

    # Check that an already wrapped var just returns the original
    wrapped_var = wrap_var(1)
    assert id(wrap_var(wrapped_var)) == id(wrapped_var)

    # Nested dict of AnsibleUnsafe
    assert wrap_var(_wrap_dict({
        1: 'hello',
        2: {
            'world': 'goodbye'
        },
        3: (1, 2, 3)
    })) == {
        1: 'hello',
        2: {
            'world': 'goodbye'
        },
        3: (1, 2, 3)
    }

    # Tuple of AnsibleUnsafe

# Generated at 2022-06-25 13:47:17.850250
# Unit test for function wrap_var
def test_wrap_var():
    # Test when v is Falsy
    test_vals = [None, False, 0, 0.0]
    for test_val in test_vals:
        assert wrap_var(test_val) == test_val

    # Test when v is string
    test_vals = [to_bytes("test"), to_text("test")]
    for test_val in test_vals:
        assert isinstance(wrap_var(test_val), AnsibleUnsafe)

    # Test when v is mapping
    test_val = {"test_key": "test_value"}
    assert isinstance(wrap_var(test_val), dict)
    assert isinstance(list(wrap_var(test_val).values())[0], AnsibleUnsafe)

    # Test when v is sequence

# Generated at 2022-06-25 13:47:25.002045
# Unit test for function wrap_var
def test_wrap_var():
    ansible_unsafe_1 = wrap_var('testing123')
    assert(isinstance(ansible_unsafe_1, AnsibleUnsafeText))
    ansible_unsafe_2 = wrap_var(b'testing123')
    assert(isinstance(ansible_unsafe_2, AnsibleUnsafeBytes))
    ansible_unsafe_3 = wrap_var(['testing', '123'])
    assert(isinstance(ansible_unsafe_3, list))
    assert(isinstance(ansible_unsafe_3[0], AnsibleUnsafeText))


# Generated at 2022-06-25 13:47:33.164659
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafe()) is AnsibleUnsafe()
    assert isinstance(wrap_var(1), int)
    assert wrap_var(1) == 1
    assert wrap_var(1.1) == 1.1
    assert isinstance(wrap_var(False), bool)
    assert wrap_var(False) is False
    assert isinstance(wrap_var(True), bool)
    assert wrap_var(True) is True
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert wrap_var(b'foo') == b'foo'