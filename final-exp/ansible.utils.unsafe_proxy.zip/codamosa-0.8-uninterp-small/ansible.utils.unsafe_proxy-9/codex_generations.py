

# Generated at 2022-06-25 13:44:54.018639
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) == None
    assert wrap_var("") == u''
    assert wrap_var(u"") == u''
    assert wrap_var("some string") == u'some string'
    assert wrap_var(dict(a=1, b=2)) == {u'a': 1, u'b': 2}
    assert wrap_var([1, 2, 3]) == [1, 2, 3]
    assert wrap_var(set([1, 2, 3])) == set([1, 2, 3])
    assert wrap_var(tuple([1, 2, 3])) == (1, 2, 3)
    assert wrap_var(NativeJinjaText(u"hello")) == NativeJinjaUnsafeText(u'hello')

# Generated at 2022-06-25 13:45:02.896166
# Unit test for function wrap_var
def test_wrap_var():
    var_1 = "this is a string"
    var_2 = {'key_1': 'this is a string', 'key_2': 'this is a string'}
    var_3 = ['this is a string', 'this is a string']
    var_4 = ('this is a string', 'this is a string')

    assert isinstance(wrap_var(var_1), AnsibleUnsafe)
    assert isinstance(wrap_var(var_2), dict)
    assert isinstance(wrap_var(var_3), list)
    assert isinstance(wrap_var(var_4), tuple)


if __name__ == '__main__':
    test_wrap_var()

# Generated at 2022-06-25 13:45:13.637831
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = to_unsafe_bytes()
    var_1 = to_unsafe_bytes(var_0)
    var_2 = to_unsafe_bytes(var_0, encoding='utf-8')
    var_3 = to_unsafe_bytes(var_0, errors='strict')
    var_4 = to_unsafe_bytes(var_0, errors='surrogate_or_strict')
    var_5 = to_unsafe_text()
    var_6 = to_unsafe_text(var_5)
    var_7 = to_unsafe_text(var_5, encoding='utf-8')
    var_8 = to_unsafe_text(var_5, errors='strict')

# Generated at 2022-06-25 13:45:24.032361
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var("test") == "test"
    assert wrap_var("0") == "0"
    assert wrap_var("test@example.com") == "test@example.com"
    assert wrap_var("test.example.com") == "test.example.com"
    assert wrap_var("test-example.com") == "test-example.com"
    assert wrap_var("test_example.com") == "test_example.com"
    assert wrap_var("test!@example.com") == "test!@example.com"
    assert wrap_var("this is a sentence") == "this is a sentence"
    assert wrap_var("this is a sentence with a ! in it") == "this is a sentence with a ! in it"

# Generated at 2022-06-25 13:45:25.602909
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None

# Generated at 2022-06-25 13:45:36.821633
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var() is None
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var('') is ''
    assert wrap_var(0) == 0
    assert wrap_var(0.0) == 0.0
    assert wrap_var(0.0) == 0.0
    assert wrap_var(['foo', 'bar', 'baz']) == ['foo', 'bar', 'baz']
    assert wrap_var(['foo', ['bar', 'baz'], 'baz']) == ['foo', ['bar', 'baz'], 'baz']

# Generated at 2022-06-25 13:45:37.527058
# Unit test for function wrap_var
def test_wrap_var():
    pass



# Generated at 2022-06-25 13:45:45.460621
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = type('str', (), {})()
    var_0.__UNSAFE__ = None
    var_0._UNSAFE_PROXY__ = True
    var_0.playbook_dir = ''
    var_1 = wrap_var(var_0)
    var_2 = wrap_var(var_1)
    assert var_2 is var_1
    assert var_1._UNSAFE_PROXY__ is True



# Generated at 2022-06-25 13:45:55.919635
# Unit test for function wrap_var
def test_wrap_var():
    var_1 = to_unsafe_bytes()
    var_2 = 'fake'
    var_3 = dict()
    var_5 = to_unsafe_text()
    var_6 = u'fake'
    var_7 = dict()
    var_9 = 'fake'
    var_10 = dict()
    var_12 = u'fake'
    var_13 = dict()
    var_15 = dict()
    var_17 = list()
    var_19 = tuple()
    var_20 = set()
    var_21 = NativeJinjaUnsafeText()
    var_22 = 'fake'
    var_23 = dict()
    var_25 = u'fake'
    var_26 = dict()
    var_28 = dict()
    var_30 = list()
    var_32 = tuple

# Generated at 2022-06-25 13:46:02.604759
# Unit test for function wrap_var
def test_wrap_var():
    assert(wrap_var(1) == 1)
    assert(type(wrap_var(1)) is int)
    assert(type(wrap_var("1")).__name__ == "AnsibleUnsafeText")
    assert(type(wrap_var([1])).__name__ == "list")
    assert(type(wrap_var((1,))).__name__ == "tuple")
    assert(wrap_var((1,"1"))[1] == "1")
    assert(type(wrap_var({'key': 'value'})) == dict)
    assert(wrap_var({'key': 'value'})['key'] == "value")
    assert(type(wrap_var({'key': 'value'})['key']).__name__ == "AnsibleUnsafeText")