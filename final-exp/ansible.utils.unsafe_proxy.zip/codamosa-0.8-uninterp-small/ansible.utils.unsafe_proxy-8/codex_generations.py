

# Generated at 2022-06-25 13:44:54.020249
# Unit test for function wrap_var
def test_wrap_var():
    res = wrap_var(None)
    assert res == None

    res = wrap_var('None')
    assert isinstance(res, unicode)
    assert res == 'None'

    res = wrap_var(b'foo')
    assert isinstance(res, binary_type)
    assert res == b'foo'

    res = wrap_var({'foo': 'bar'})
    assert isinstance(res, dict)
    assert isinstance(res['foo'], unicode)
    assert res['foo'] == 'bar'

    res = wrap_var(set(['foo', 'bar']))
    assert isinstance(res, set)
    assert isinstance(res, AnsibleUnsafe)
    assert isinstance(list(res)[0], unicode)

    res = wrap_var(('foo', 'bar'))
   

# Generated at 2022-06-25 13:45:04.603493
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(1) == 1

    assert wrap_var(None) == None

    data = {
        'a': 'b',
        'c': 1
    }
    assert wrap_var(data) == {
        'a': AnsibleUnsafeText('b'),
        'c': 1
    }

    data = ['a', 'b']
    assert wrap_var(data) == ['a', 'b']
    assert wrap_var(tuple(data)) == (AnsibleUnsafeText('a'), AnsibleUnsafeText('b'))

    data = {
        'a': ['b', 'c']
    }
    assert wrap_var(data) == {
        'a': [AnsibleUnsafeText('b'), AnsibleUnsafeText('c')]
    }


# Generated at 2022-06-25 13:45:12.815861
# Unit test for function wrap_var
def test_wrap_var():
    test_dict = dict(a=1, b=2, c=3)
    test_dict_unsafe = wrap_var(test_dict)
    assert test_dict == test_dict_unsafe
    assert isinstance(test_dict_unsafe, dict)
    for key, val in test_dict_unsafe.items():
        assert isinstance(key, AnsibleUnsafe)
        assert isinstance(key, AnsibleUnsafeText)
        assert isinstance(val, AnsibleUnsafe)

if __name__ == "__main__":
    test_case_0()
    test_wrap_var()

# Generated at 2022-06-25 13:45:23.334459
# Unit test for function wrap_var
def test_wrap_var():

    ansible_unsafe_test = AnsibleUnsafe()
    wrapped_variable_1 = wrap_var(ansible_unsafe_test)
    assert wrapped_variable_1 is ansible_unsafe_test, 'wrap_var failed to wrap an Ansible Unsafe variable'

    wrapped_variable_2 = wrap_var(tuple('abc'))
    assert isinstance(wrapped_variable_2, tuple), 'wrap_var failed to wrap a tuple'
    assert isinstance(wrapped_variable_2[0], AnsibleUnsafe), 'wrap_var failed to wrap a tuple'

    wrapped_variable_3 = wrap_var('str')
    assert isinstance(wrapped_variable_3, AnsibleUnsafe), 'wrap_var failed to wrap a str'

    wrapped_variable_4 = wrap_var(u'unicode string')


# Generated at 2022-06-25 13:45:34.763124
# Unit test for function wrap_var
def test_wrap_var():
    ansible_unsafe_0 = AnsibleUnsafe()
    test_string_0 = 'this_is_a_string'
    test_string_1 = wrap_var(test_string_0)
    assert isinstance(test_string_1, AnsibleUnsafeText)

    test_dict_0 = {'this': 'is_a_dict'}
    test_dict_1 = wrap_var(test_dict_0)
    assert isinstance(test_dict_1, dict)

    test_string_2 = 'this_is_a_string'
    test_list_0 = ['this_is_a_list']
    test_list_1 = wrap_var(test_list_0)
    assert isinstance(test_list_1, list)



# Generated at 2022-06-25 13:45:42.218702
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None

    my_unsafe_0 = AnsibleUnsafe()
    assert wrap_var(my_unsafe_0) is my_unsafe_0

    my_unsafe_1 = AnsibleUnsafeBytes(b"This is safe!")
    assert wrap_var(my_unsafe_1) is my_unsafe_1

    by = to_unsafe_bytes(b'This is bytes!')
    assert isinstance(by, AnsibleUnsafe)
    assert isinstance(by, binary_type)
    assert by == b'This is bytes!'

    tx = to_unsafe_text(u"This is unicode!")
    assert isinstance(tx, AnsibleUnsafe)
    assert isinstance(tx, text_type)
    assert tx == "This is unicode!"

   

# Generated at 2022-06-25 13:45:53.702783
# Unit test for function wrap_var
def test_wrap_var():
    # type: () -> None
    """Test wrap_var with different types. If the test fails, it should throw an
    exception.
    """

    # Test a dict with AnsibleUnsafe values
    dict_0 = dict({})
    dict_0['item'] = AnsibleUnsafeText('item')
    dict_0['item_0'] = AnsibleUnsafeBytes('item_0')
    dict_1 = wrap_var(dict_0)
    assert dict_1['item'] == dict_0['item']
    assert dict_1['item_0'] == dict_0['item_0']

    # Test a dict with non-AnsibleUnsafe values
    dict_0 = dict({})
    dict_0['item'] = 'item'
    dict_0['item_0'] = 'item_0'
    dict_

# Generated at 2022-06-25 13:46:01.204748
# Unit test for function wrap_var
def test_wrap_var():
    from types import MethodType
    from textwrap import dedent

    from ansible.module_utils.common.json_utils import AnsibleJSONEncoder

    run_test = False
    if run_test:
        # this just verifies that structs are kept in tact
        from ansible.module_utils.common.text.converters import to_json
        class CustomJSONEncoder(AnsibleJSONEncoder):
            def default(self, obj):
                if isinstance(obj, set):
                    return list(obj)
                else:
                    return super(CustomJSONEncoder, self).default(obj)

        # custom class on dict
        json_data_0 = {"ansible_unsafe_0": wrap_var(ansible_unsafe_0), "raw_sequence_0": [1, "2", 3]}

# Generated at 2022-06-25 13:46:10.994997
# Unit test for function wrap_var
def test_wrap_var():
    v = 'some text'
    assert(isinstance(wrap_var(v), AnsibleUnsafeText))

    v = True
    assert(not isinstance(wrap_var(v), AnsibleUnsafe))

    v = {}
    assert(not isinstance(wrap_var(v), AnsibleUnsafe))

    v = {'test': 'some text'}
    assert(not isinstance(wrap_var(v), AnsibleUnsafe))

    v = {'test': b'some binary'}
    assert(not isinstance(wrap_var(v), AnsibleUnsafe))

    v = {'test': AnsibleUnsafeText('some text')}
    assert(not isinstance(wrap_var(v), AnsibleUnsafe))


# Generated at 2022-06-25 13:46:22.764736
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var('test') == 'test'
    assert wrap_var(u'test') == u'test'
    assert isinstance(wrap_var(b'test'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeText(u'test')), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'\xe9'), AnsibleUnsafeText)
    assert isinstance(wrap_var('\xe9'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'\xe9'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(dict(key=u'\xe9')), Mapping)

# Generated at 2022-06-25 13:46:31.906565
# Unit test for function wrap_var
def test_wrap_var():
    test_case_0()

    test_value_0 = to_unsafe_bytes("abc")
    assert isinstance(test_value_0, AnsibleUnsafeBytes)
    assert not isinstance(test_value_0, AnsibleUnsafeText)
    assert not isinstance(test_value_0, NativeJinjaUnsafeText)

    test_value_1 = to_unsafe_text("abc")
    assert isinstance(test_value_1, AnsibleUnsafeText)
    assert not isinstance(test_value_1, AnsibleUnsafeBytes)
    assert not isinstance(test_value_1, NativeJinjaUnsafeText)

    test_value_2 = wrap_var("abc")
    assert isinstance(test_value_2, AnsibleUnsafeText)

# Generated at 2022-06-25 13:46:32.367674
# Unit test for function wrap_var
def test_wrap_var():
  pass


# Generated at 2022-06-25 13:46:42.473777
# Unit test for function wrap_var
def test_wrap_var():

    # Test AnsibleUnsafeText wraps on strings
    ansible_unsafe_text = wrap_var('foobar')
    assert isinstance(ansible_unsafe_text, AnsibleUnsafeText)

    # Test AnsibleUnsafeText wraps on Unicode strings
    ansible_unsafe_text = wrap_var(u'foobar')
    assert isinstance(ansible_unsafe_text, AnsibleUnsafeText)

    # Test AnsibleUnsafeBytes wraps on bytestrings
    ansible_unsafe_bytes = wrap_var(b'foobar')
    assert isinstance(ansible_unsafe_bytes, AnsibleUnsafeBytes)

    # Test AnsibleUnsafeText does not double wrap
    ansible_unsafe_text = AnsibleUnsafeText(u'foobar')
    ansible_unsafe_text = wrap_

# Generated at 2022-06-25 13:46:48.468465
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(u'abc') == u'abc'
    assert wrap_var(u'abc'.encode('utf-8')) == u'abc'
    assert wrap_var(dict(a=1, b=2)) == dict(a=1, b=2)
    assert wrap_var([1, 2, 3]) == [1, 2, 3]
    assert wrap_var(tuple([1, 2, 3])) == (1, 2, 3)


# Ensure we can call wrap_var with bytes and it will return AnsibleUnsafeBytes and not AnsibleUnsafeText

# Generated at 2022-06-25 13:46:55.813287
# Unit test for function wrap_var
def test_wrap_var():
    test_dict = {'key1': 'value1'}
    test_dict_unsafe = wrap_var(test_dict)

    assert test_dict_unsafe == test_dict
    assert isinstance(test_dict_unsafe, AnsibleUnsafe)

    test_list = ['value1', 'value2']
    test_list_unsafe = wrap_var(test_list)

    assert test_list_unsafe == test_list
    assert isinstance(test_list_unsafe, AnsibleUnsafe)

# Generated at 2022-06-25 13:47:04.999278
# Unit test for function wrap_var
def test_wrap_var():
    unsafedict_0 = wrap_var({})
    assert(isinstance(unsafedict_0, dict))
    assert(isinstance(unsafedict_0, AnsibleUnsafe))
    assert(unsafedict_0 == {})

    unsafe_0 = wrap_var("x")
    assert(isinstance(unsafe_0, str))
    assert(isinstance(unsafe_0, AnsibleUnsafe))
    assert(unsafe_0 == "x")

    unsafe_1 = wrap_var("y")
    assert(isinstance(unsafe_1, str))
    assert(isinstance(unsafe_1, AnsibleUnsafe))
    assert(unsafe_1 == "y")

    unsafelist_0 = wrap_var([unsafe_0, unsafe_1])

# Generated at 2022-06-25 13:47:13.634280
# Unit test for function wrap_var
def test_wrap_var():

    # Empty
    v_complex = {}
    wrapped = wrap_var(v_complex)
    assert wrapped == v_complex

    # Nested
    v_complex = {'a': {'b': {'c': {'d': {}}, 'e': {'f': {}}, 'g': {}}}}
    wrapped = wrap_var(v_complex)
    assert wrapped == v_complex

    # Simple
    v_complex = {'a': {'b': {'c': {'d': 'd'}, 'e': {'f': 'f'}, 'g': {'h': 'h'}}}}
    wrapped = wrap_var(v_complex)
    assert wrapped == v_complex

    # String
    v_str = 'This is a string'
    wrapped = wrap_var(v_str)
    assert wrapped

# Generated at 2022-06-25 13:47:21.804049
# Unit test for function wrap_var
def test_wrap_var():
    assert 'AnsibleUnsafeText' == wrap_var('pk').__class__.__name__
    assert 'AnsibleUnsafeText' == wrap_var('pk').__class__.__name__
    assert 'AnsibleUnsafeText' == wrap_var(u'pk').__class__.__name__

    assert 'unicode' == wrap_var('pk').__class__.__mro__[2].__name__
    assert 'unicode' == wrap_var('pk').__class__.__mro__[2].__name__
    assert 'unicode' == wrap_var(u'pk').__class__.__mro__[2].__name__



# Generated at 2022-06-25 13:47:30.135361
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test with None
    v = wrap_var(None)
    assert v is None

    # Test with basic string
    v = wrap_var('foo')
    assert isinstance(v, string_types)

    # Test with unicode
    v = wrap_var(u'foo')
    assert isinstance(v, string_types)

    # Test with byte string
    v = wrap_var(b'bar')
    assert isinstance(v, binary_type)

    # Test with float
    v = wrap_var(0.1)
    assert v == 0.1

    # Test with integer

# Generated at 2022-06-25 13:47:30.947119
# Unit test for function wrap_var
def test_wrap_var():
    pass

# Generated at 2022-06-25 13:47:43.175276
# Unit test for function wrap_var
def test_wrap_var():
    str_0 = 'abc'
    str_result = wrap_var(str_0)
    assert isinstance(str_result, AnsibleUnsafeText)

    # bytes
    bytes_0 = b'abc'
    bytes_result = wrap_var(bytes_0)
    assert isinstance(bytes_result, AnsibleUnsafeBytes)

    # set
    set_0 = set([1, 2, 3])
    set_result = wrap_var(set_0)
    assert isinstance(set_result, set)
    assert all(isinstance(v, AnsibleUnsafeBytes) for v in set_result)

    # list
    list_0 = ['abc', 123]
    list_result = wrap_var(list_0)
    assert isinstance(list_result, list)

# Generated at 2022-06-25 13:47:45.158855
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = 'abc'
    var_1 = wrap_var(var_0)
    assert var_1 == var_0



# Generated at 2022-06-25 13:47:53.071073
# Unit test for function wrap_var
def test_wrap_var():
    arg1 = 'abc'
    arg2 = {'abc': 'abc'}
    arg3 = ['abc']
    arg4 = ('abc', )
    arg5 = set('abc')

    # Call function
    ans = wrap_var(arg1)
    assert isinstance(ans, AnsibleUnsafeText)
    assert ans == 'abc'

    # Call function
    ans = wrap_var(arg2)
    assert isinstance(ans, dict)
    assert isinstance(ans['abc'], AnsibleUnsafeText)

    # Call function
    ans = wrap_var(arg3)
    assert isinstance(ans, list)
    assert isinstance(ans[0], AnsibleUnsafeText)

    # Call function
    ans = wrap_var(arg4)
    assert isinstance(ans, tuple)

# Generated at 2022-06-25 13:47:54.359109
# Unit test for function wrap_var
def test_wrap_var():
    str_0 = 'abc'
    var_0 = wrap_var(str_0)



# Generated at 2022-06-25 13:48:01.774979
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = wrap_var('abc')
    assert isinstance(var_0, AnsibleUnsafeText) and len(var_0) == 3

    var_1 = wrap_var(var_0)
    assert isinstance(var_1, AnsibleUnsafeText) and len(var_1) == 3

    var_2 = wrap_var(['a', 'b'])
    assert isinstance(var_2, list) and len(var_2) == 2
    assert isinstance(var_2[0], AnsibleUnsafeText) and len(var_2[0]) == 1
    assert isinstance(var_2[1], AnsibleUnsafeText) and len(var_2[1]) == 1

    var_3 = wrap_var((('a', 'b'), ('c', 'd')))
    assert isinstance

# Generated at 2022-06-25 13:48:02.455161
# Unit test for function wrap_var
def test_wrap_var():
    assert True

# Generated at 2022-06-25 13:48:10.452495
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common._collections_compat import Mapping, MutableSequence
    from ansible.module_utils.common.collections import is_sequence

    var_0 = wrap_var({False : 'abc', True : 'abc'})
    var_1 = wrap_var({False : 'abc', True : 'abc'})
    var_2 = wrap_var({False : 'abc', True : 'abc'})
    var_3 = wrap_var({False : 'abc', True : 'abc'})
    var_4 = wrap_var([{False : 'abc', True : 'abc'}])
    var_5 = wrap_var([{False : 'abc', True : 'abc'}])
    var_6 = wrap_var([{False : 'abc', True : 'abc'}])
    var_

# Generated at 2022-06-25 13:48:17.531223
# Unit test for function wrap_var
def test_wrap_var():
    str_data = 'abc'
    bytes_data = b'abc'
    list_data = ['abc', 'def']
    list_wrap = [wrap_var(str_data), wrap_var(bytes_data), wrap_var(list_data)]
    assert wrap_var(str_data) == AnsibleUnsafeText(str_data)
    assert wrap_var(bytes_data) == AnsibleUnsafeBytes(bytes_data)
    assert wrap_var(list_data) == AnsibleUnsafe(_wrap_sequence(list_data))
    assert wrap_var(list_wrap) == AnsibleUnsafe(_wrap_sequence(list_wrap))

# Generated at 2022-06-25 13:48:26.367369
# Unit test for function wrap_var
def test_wrap_var():
    str_0 = 'abc'
    str_1 = 'py'
    str_2 = 'py'
    str_3 = '//fwrxsdhfg'
    str_4 = '//fwrxsdhfg'
    str_5 = '//fwrxsdhfg'
    str_6 = '4'
    var_0 = wrap_var(str_0)
    var_1 = wrap_var(str_1)
    var_2 = wrap_var(str_2)
    var_3 = wrap_var(str_3)
    var_4 = wrap_var(str_4)
    var_5 = wrap_var(str_5)
    var_6 = wrap_var(str_6)
    var_7 = wrap_var(var_3)
    var_8 = wrap

# Generated at 2022-06-25 13:48:34.605089
# Unit test for function wrap_var
def test_wrap_var():
    str_0 = 'abc'
    str_1 = 'abc'
    int_0 = 0
    int_1 = 0
    float_0 = 1.0
    float_1 = 1.0
    bytearray_0 = bytearray(b'\x00')
    bytearray_1 = bytearray(b'\x00')
    tuple_0 = (0,)
    tuple_1 = (0,)
    list_0 = [0]
    list_1 = [0]
    set_0 = {0}
    set_1 = {0}
    dict_0 = {0: 0}
    dict_1 = {0: 0}
    None_0 = None
    None_1 = None

    var_0 = wrap_var(str_0)

# Generated at 2022-06-25 13:48:40.464713
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(str_0)

# Test the Python version

# Generated at 2022-06-25 13:48:50.339497
# Unit test for function wrap_var
def test_wrap_var():
    # tests for:
    # None type
    test_value = None
    assert wrap_var(test_value) == test_value
    # dict type
    test_value = {'key_0': 'value_0', 'key_1': 'value_1', 'key_2': 'value_0'}
    assert isinstance(wrap_var(test_value), dict)
    assert wrap_var(test_value) == test_value
    # tuple type
    test_value = ('value_0', 'value_1', 'value_0')
    assert isinstance(wrap_var(test_value), tuple)
    assert wrap_var(test_value) == test_value
    # list type
    test_value = ['value_0', 'value_1', 'value_0']

# Generated at 2022-06-25 13:49:00.912729
# Unit test for function wrap_var
def test_wrap_var():

    # First call of function wrap_var
    str_0 = 'abc'
    var_0 = wrap_var(str_0)

    # Second call of function wrap_var
    str_1 = 'abc'
    var_1 = wrap_var(str_1)

    # Third call of function wrap_var
    str_2 = 'abc'
    var_2 = wrap_var(str_2)

    # Fourth call of function wrap_var
    tup_0 = ('abc',)
    var_3 = wrap_var(tup_0)

    # Fifth call of function wrap_var
    tup_1 = ('abc',)
    var_4 = wrap_var(tup_1)

    # Sixth call of function wrap_var
    dic_0 = {"abc": None}
    var_5 = wrap

# Generated at 2022-06-25 13:49:08.814338
# Unit test for function wrap_var
def test_wrap_var():
    assert var_0 == str_0
    assert isinstance(var_0, AnsibleUnsafeText) is True
    str_1 = '123'
    var_1 = wrap_var(str_1)
    assert var_1 == str_1
    assert isinstance(var_1, AnsibleUnsafeText) is True
    str_2 = '123'
    var_2 = wrap_var(str_2)
    assert var_2 == str_2
    assert isinstance(var_2, AnsibleUnsafeText) is True
    list_0 = []
    var_3 = wrap_var(list_0)
    assert var_3 == list_0
    dict_0 = {}
    var_4 = wrap_var(dict_0)
    assert var_4 == dict_0
    var_5 = wrap_

# Generated at 2022-06-25 13:49:15.623477
# Unit test for function wrap_var
def test_wrap_var():
    # Test case with a correct Unicode string
    str_0 = 'abc'
    var_0 = wrap_var(str_0)
    assert isinstance(var_0, AnsibleUnsafeText)
    # Test case with a correct binary string
    str_1 = b'abc'
    var_1 = wrap_var(str_1)
    assert isinstance(var_1, AnsibleUnsafeBytes)
    # Test case with a correct Unicode string with unsafe characters
    str_2 = '<script>'
    var_2 = wrap_var(str_2)
    assert isinstance(var_2, AnsibleUnsafeText)
    # Test case with a correct binary string with unsafe characters
    str_3 = b'<script>'
    var_3 = wrap_var(str_3)

# Generated at 2022-06-25 13:49:23.485815
# Unit test for function wrap_var
def test_wrap_var():
    str_0 = 'abc'
    var_0 = wrap_var(str_0)
    assert isinstance(var_0, str)
    assert str(var_0) == 'abc'
    assert not var_0.__UNSAFE__
    str_1 = u'abc'
    var_1 = wrap_var(str_1)
    assert isinstance(var_1, text_type)
    assert var_1 == u'abc'
    assert not var_1.__UNSAFE__
    str_2 = b'abc'
    var_2 = wrap_var(str_2)
    assert isinstance(var_2, binary_type)
    assert var_2 == b'abc'
    assert not var_2.__UNSAFE__
    str_3 = u'abc'
    str_4

# Generated at 2022-06-25 13:49:29.497167
# Unit test for function wrap_var
def test_wrap_var():
    # Test cases:
    var_0 = wrap_var('abc')
    var_1 = wrap_var(b'abc')
    var_2 = wrap_var(set(['abc']))
    var_3 = wrap_var(['abc'])
    var_4 = wrap_var({'a': 'b'})
    var_5 = wrap_var(None)
    var_6 = wrap_var(['a', 'b'])
    var_7 = wrap_var('a')

# Generated at 2022-06-25 13:49:36.448023
# Unit test for function wrap_var
def test_wrap_var():
    # First case
    str_0 = 'abc'
    var_0 = wrap_var(str_0)
    assert isinstance(var_0, str)
    assert var_0 == 'abc'

    # Second case
    str_0 = 'abc'
    var_0 = wrap_var(str_0)
    assert isinstance(var_0, str)
    assert var_0 == 'abc'

    # Third case
    str_0 = 'abc'
    var_0 = wrap_var(str_0)
    assert isinstance(var_0, str)
    assert var_0 == 'abc'

    # Fourth case
    str_0 = 'abc'
    var_0 = wrap_var(str_0)
    assert isinstance(var_0, str)
    assert var_0 == 'abc'

# Generated at 2022-06-25 13:49:45.218892
# Unit test for function wrap_var
def test_wrap_var():
    assert not isinstance(wrap_var(None), AnsibleUnsafe)
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(1), AnsibleUnsafe)
    assert isinstance(wrap_var(1), int)
    assert isinstance(wrap_var(1.0), AnsibleUnsafe)
    assert isinstance(wrap_var(1.0), float)
    assert isinstance(wrap_var(True), AnsibleUnsafe)
    assert isinstance(wrap_var(True), bool)
    assert isinstance(wrap_var(b'123'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'123'), AnsibleUnsafe)
    assert isinstance(wrap_var(u'123'), AnsibleUnsafeText)

# Generated at 2022-06-25 13:49:48.687945
# Unit test for function wrap_var
def test_wrap_var():
    str_0 = 'abc'
    var_0 = wrap_var(str_0)
    assert str_0 is not var_0
    assert not isinstance(str_0, AnsibleUnsafe)
    assert isinstance(var_0, AnsibleUnsafe)
    assert str_0 == var_0



# Generated at 2022-06-25 13:49:59.776186
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var is not None



# Generated at 2022-06-25 13:50:02.782120
# Unit test for function wrap_var
def test_wrap_var():
    try:
        str_0 = 'abc'
        var_0 = wrap_var(str_0)
        assert type(var_0) ==  AnsibleUnsafeText
    except AssertionError as e:
        raise AssertionError(str(e))

# Generated at 2022-06-25 13:50:12.122258
# Unit test for function wrap_var
def test_wrap_var():
    """
    Function to test function wrap_var()
    """
    # -------------------------------------------------------------------------------------
    # Array / dictionary of different kinds of values.
    arr_test_0 = [1, 2, 3]
    arr_test_1 = {'A': 1, 'B': 2}
    arr_test_2 = ['A', 'B']
    arr_test_3 = {'A': ['A', 'B'], 'B': ['C', 'D']}
    assert wrap_var(arr_test_0) == arr_test_0
    assert wrap_var(arr_test_1) == arr_test_1
    assert wrap_var(arr_test_2) == arr_test_2
    assert wrap_var(arr_test_3) == arr_test_3
    # -------------------------------------------------------------------------------------
    # Empty array
   

# Generated at 2022-06-25 13:50:19.426868
# Unit test for function wrap_var
def test_wrap_var():
    import sys
    import inspect
    from collections import OrderedDict, Counter

    # Disabled pending clarification on whether wrap_var should wrap OrderedDict or not
    # func_arg_0 = OrderedDict()
    # func_arg_0['a'] = 'a'
    # func_arg_0['b'] = 'b'
    # func_arg_0['c'] = 'c'
    # var_0 = wrap_var(func_arg_0)
    # assert isinstance(var_0, OrderedDict), "Expected type {} to be instance of {}".format(type(var_0), OrderedDict)
    # assert var_0.__class__.__name__ == "OrderedDict", "Expected type {} to be a type of {}".format(type(var_0), "OrderedD

# Generated at 2022-06-25 13:50:25.726573
# Unit test for function wrap_var
def test_wrap_var():
    str_0 = 'abc'
    var_0 = wrap_var(str_0)
    assert isinstance(var_0, AnsibleUnsafeText)

    str_1 = b'\x00\x01\x02'
    var_1 = wrap_var(str_1)
    assert isinstance(var_1, AnsibleUnsafeBytes)

    str_2 = AnsibleUnsafeText('abc')
    var_2 = wrap_var(str_2)
    assert isinstance(var_2, AnsibleUnsafeText)

    str_3 = AnsibleUnsafeBytes(b'abc')
    var_3 = wrap_var(str_3)
    assert isinstance(var_3, AnsibleUnsafeBytes)


# Generated at 2022-06-25 13:50:32.804243
# Unit test for function wrap_var
def test_wrap_var():
    # Sanity test: make sure the function can wrap a string
    str_0 = 'abc'
    str_0_unsafe = wrap_var(str_0)
    assert(isinstance(str_0_unsafe, AnsibleUnsafeText))
    assert(str_0_unsafe == str_0)

    # Sanity test: make sure the function can wrap a byte string
    str_0 = b'abc'
    str_0_unsafe = wrap_var(str_0)
    assert(isinstance(str_0_unsafe, AnsibleUnsafeBytes))
    assert(str_0_unsafe == str_0)

    # Another sanity test: wrap a unicode string and make sure it comes back as unicode
    str_1 = u'1234'

# Generated at 2022-06-25 13:50:43.177508
# Unit test for function wrap_var
def test_wrap_var():

    test_dict = dict()
    test_dict['a'] = 1
    test_dict['b'] = 2
    test_dict['c'] = wrap_var("def")
    test_dict['d'] = wrap_var(wrap_var("hij"))
    test_dict['e'] = "klm"
    test_dict['f'] = wrap_var("nop")
    test_dict['g'] = wrap_var("qrs")
    test_dict['h'] = 8
    test_dict['i'] = 9
    assert test_dict == _wrap_dict(test_dict)

    for i in [1, 2, 3]:
        assert wrap_var(i) == i

    for s in ['abc', 'def', 'ghi']:
        assert wrap_var(s) == s
        assert wrap_var

# Generated at 2022-06-25 13:50:44.919187
# Unit test for function wrap_var
def test_wrap_var():
    print('Test wrap_var')
    # Test case 0
    print('Test case 0')
    test_case_0()


# Generated at 2022-06-25 13:50:52.568904
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert isinstance(wrap_var(None), type(None))
    assert wrap_var('abc') == 'abc'
    assert isinstance(wrap_var('abc'), text_type)
    assert isinstance(wrap_var(b'abc'), binary_type)
    assert wrap_var('abc') == 'abc'
    assert isinstance(wrap_var(['abc']), list)
    assert wrap_var(['abc']) == ['abc']
    assert wrap_var((1, 2, 3)) == (1, 2, 3)
    assert wrap_var({'a': 'b'}) == {'a': 'b'}
    assert isinstance(wrap_var({'a': 'b'}), dict)

# Generated at 2022-06-25 13:50:54.752659
# Unit test for function wrap_var
def test_wrap_var():
    # Test type str
    var_0 = wrap_var('abc')
    assert issubclass(type(var_0), AnsibleUnsafeText)


# Generated at 2022-06-25 13:51:23.530680
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(str) == str
    assert wrap_var(u'abc') == u'abc'
    assert wrap_var(u'abc').__UNSAFE__
    assert wrap_var(u'abc').encode('utf-8').__UNSAFE__
    assert wrap_var(b'abc').__UNSAFE__
    assert wrap_var(b'abc').decode('utf-8').__UNSAFE__
    assert wrap_var(dict([('a',1)]))[u'a'] == 1
    assert wrap_var(dict([('a',1)])).__UNSAFE__
    assert wrap_var((1,2,3))[2] == 3
    assert wrap_var((1,2,3)).__UNSAFE__
    assert wrap_var(set([3,4,5]))

# Generated at 2022-06-25 13:51:33.437381
# Unit test for function wrap_var
def test_wrap_var():
    str_0 = 'abc'
    var_0 = wrap_var(str_0)
    var_0_type = type(var_0)
    assert 0 == cmp(str_0, var_0), "cannot compare str with %s" % var_0_type.__name__

    dict_0 = dict(abc='abc')
    dict_0_orig = dict_0
    dict_0 = wrap_var(dict_0)
    var_1_type = type(dict_0)
    assert 0 == cmp(dict_0_orig, dict_0), "%s should equal dict_0_orig" % var_1_type.__name__
    assert 0 == cmp({'abc': 'abc'}, dict_0), "cannot compare dict with %s" % var_1_type.__name__



# Generated at 2022-06-25 13:51:38.107992
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = wrap_var('abc')
    assert isinstance(var_0, AnsibleUnsafeText)
    assert var_0 == 'abc'

    from ansible.module_utils.six import StringIO
    var_1 = wrap_var(StringIO('abc'))
    assert isinstance(var_1, StringIO)
    assert var_1.getvalue() == 'abc'

    var_2 = wrap_var(dict(a='b', c='d'))
    assert isinstance(var_2, dict)
    assert isinstance(var_2[u'a'], AnsibleUnsafeText)
    assert var_2['a'] == 'b'
    assert var_2[u'c'] == 'd'

    var_3 = wrap_var(set(['a', 'b', 'c']))


# Generated at 2022-06-25 13:51:47.556783
# Unit test for function wrap_var
def test_wrap_var():
    '''Wrap a string in an unsafe proxy'''
    var_1 = wrap_var("abc")
    assert(isinstance(var_1, text_type))
    assert(isinstance(var_1, AnsibleUnsafe))
    assert(repr(var_1).startswith(type('abc').__name__))

    '''Wrap a dict in an unsafe proxy'''
    var_1 = wrap_var({'x': 'abc'})
    assert(isinstance(var_1, dict))
    assert(isinstance(var_1, AnsibleUnsafe))
    assert(repr(var_1).startswith(type({'x': 'abc'}).__name__))

    '''Wrap a dict in an unsafe proxy'''
    var_1 = wrap_var((('x', 'abc'),))

# Generated at 2022-06-25 13:51:48.772494
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('abc') == AnsibleUnsafeText('abc')



# Generated at 2022-06-25 13:51:53.832029
# Unit test for function wrap_var
def test_wrap_var():
    # Make sure wrap_var returns a variable with the __UNSAFE__ attribute
    assert(hasattr(wrap_var(None), '__UNSAFE__'))
    assert(hasattr(wrap_var(''), '__UNSAFE__'))

    # Make sure wrap_var does not return an AnsibleUnsafe object
    assert(wrap_var(None) is None)
    assert(wrap_var('') == '')

    # Make sure wrap_var returns a variable with the __UNSAFE__ attribute
    # when given an AnsibleUnsafe object
    assert(hasattr(wrap_var(wrap_var('')), '__UNSAFE__'))

    # Make sure wrap_var returns an AnsibleUnsafe object when given
    # a variable with the __UNSAFE__ attribute

# Generated at 2022-06-25 13:51:57.806299
# Unit test for function wrap_var

# Generated at 2022-06-25 13:52:07.886397
# Unit test for function wrap_var
def test_wrap_var():
    assert type(wrap_var(None)) is type(None)
    assert type(wrap_var('')) is type(AnsibleUnsafeText())
    assert type(wrap_var('1')) is type(AnsibleUnsafeText())
    assert type(wrap_var(1)) is type(1)
    assert type(wrap_var({})) is type({})
    assert type(wrap_var([])) is type([])
    assert type(wrap_var(set())) is type(set())
    assert type(wrap_var(u'')) is type(AnsibleUnsafeText())

    t = AnsibleUnsafeText()
    b = AnsibleUnsafeBytes()
    assert type(wrap_var(t)) is type(AnsibleUnsafeText())

# Generated at 2022-06-25 13:52:16.300172
# Unit test for function wrap_var
def test_wrap_var():
    # TODO: This code is not getting executed, but may still be useful as an example or template for the future.
    # Test data:
    str_0 = 'abc'
    str_1 = 'cba'
    str_2 = 'xyz'
    str_3 = 'zyx'
    str_4 = 'def'
    str_5 = 'fed'
    str_6 = 'ghi'
    str_7 = 'ihg'
    byte_str_0 = b'abc'
    byte_str_1 = b'cba'
    byte_str_2 = b'xyz'
    byte_str_3 = b'zyx'
    byte_str_4 = b'def'
    byte_str_5 = b'fed'
    byte_str_6 = b'ghi'
   

# Generated at 2022-06-25 13:52:23.889402
# Unit test for function wrap_var
def test_wrap_var():
    assert to_text(wrap_var('abc')) == u'abc'
    assert to_text(wrap_var(123)) == u'123'
    assert to_text(wrap_var(5.5)) == u'5.5'
    assert to_text(wrap_var({'a': 'b'})) == u"{'a': 'b'}"
    assert to_text(wrap_var(['a', 'b', 'c'])) == u"['a', 'b', 'c']"
    assert to_text(wrap_var(('a', 'b', 'c'))) == u"('a', 'b', 'c')"
    assert to_text(wrap_var(set(['a', 'b', 'c']))) == u"{'a', 'c', 'b'}"
    assert wrap_var

# Generated at 2022-06-25 13:52:52.872304
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(2.0) == 2.0
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(('foo',)), tuple)
    assert isinstance(wrap_var(('foo',))[0], AnsibleUnsafeText)
    assert isinstance(wrap_var(['foo']), list)
    assert isinstance(wrap_var(['foo'])[0], AnsibleUnsafeText)
    assert isinstance

# Generated at 2022-06-25 13:53:00.136322
# Unit test for function wrap_var
def test_wrap_var():
    # Make sure the basic types are wrapped properly
    # string_types should be the union of text_type and binary_type
    for str_type in string_types:
        assert isinstance(wrap_var(str_type()), AnsibleUnsafe)
    # Mapping is the base class for dict
    assert isinstance(wrap_var(Mapping()), Mapping)
    # Sequence is the base class for all sequence types
    assert isinstance(wrap_var(Sequence()), Sequence)

    # Explicitly test the subclasses of sequence and mapping
    # note: (we don't test MutableSequence or MutableMapping)
    assert isinstance(wrap_var(list()), list)
    assert isinstance(wrap_var(tuple()), tuple)
    assert isinstance(wrap_var(set()), set)
    assert isinstance

# Generated at 2022-06-25 13:53:09.511387
# Unit test for function wrap_var
def test_wrap_var():

    # Pass 1:
    str_0 = 'abc'
    var_0 = wrap_var(str_0)
    str_1 = 'def'
    var_1 = wrap_var(str_1)
    str_2 = 'ghi'
    var_2 = wrap_var(str_2)

    assert isinstance(var_0, AnsibleUnsafeText)
    assert isinstance(var_1, AnsibleUnsafeText)
    assert isinstance(var_2, AnsibleUnsafeText)

    assert var_0 == 'abc'
    assert var_1 == 'def'
    assert var_2 == 'ghi'

    # Pass 2:
    bytes_0 = to_bytes('abc')
    var_0 = wrap_var(bytes_0)
    bytes_1 = to_bytes('def')


# Generated at 2022-06-25 13:53:19.231011
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import Mapping, Set
    from ansible.utils.unsafe_proxy import _wrap_dict, _wrap_sequence, _wrap_set, wrap_var
    safe_str = '123'
    safe_unicode = u'123'
    safe_int = 123
    safe_list = ['123']
    safe_tuple = ('123')
    safe_dict = {'key': '123'}
    safe_set = set(['123'])

    unsafe_str = wrap_var(safe_str)
    unsafe_unicode = wrap_var(safe_unicode)
    unsafe_int = wrap_var(safe_int)
    unsafe_list = wrap_var(safe_list)
    unsafe_tuple = wrap_var(safe_tuple)
    unsafe_

# Generated at 2022-06-25 13:53:27.156816
# Unit test for function wrap_var
def test_wrap_var():
    assert(wrap_var('abc') == 'abc')
    assert(wrap_var(b'abc') == b'abc')

    assert(wrap_var(u'abc') == u'abc')
    assert(wrap_var(b'abc') == b'abc')

    ## Python 3 representation of u'abc'
    assert(wrap_var('abc') == 'abc')

    assert(wrap_var(AnsibleUnsafeText(b'abc')) == AnsibleUnsafeText(b'abc'))
    assert(wrap_var(AnsibleUnsafeText('abc')) == AnsibleUnsafeText('abc'))
    assert(wrap_var(AnsibleUnsafeText(u'abc')) == AnsibleUnsafeText(u'abc'))

    assert(wrap_var(u'abc') == u'abc')


# Generated at 2022-06-25 13:53:29.762595
# Unit test for function wrap_var
def test_wrap_var():
    str_0 = 'abc'
    var_0 = wrap_var(str_0)

    actual_result = isinstance(var_0, AnsibleUnsafeText)
    expected_result = True
    assert actual_result == expected_result


# Generated at 2022-06-25 13:53:31.796727
# Unit test for function wrap_var
def test_wrap_var():
    # Assert type
    assert isinstance(test_case_0(), AnsibleUnsafeText)

# Generated at 2022-06-25 13:53:32.972694
# Unit test for function wrap_var
def test_wrap_var():
    test_case_0()

# Generated at 2022-06-25 13:53:35.382683
# Unit test for function wrap_var
def test_wrap_var():
    str_0 = 'abc'
    var_0 = wrap_var(str_0)
    assert type(var_0) == AnsibleUnsafeText



# Generated at 2022-06-25 13:53:43.084236
# Unit test for function wrap_var
def test_wrap_var():
    str_0 = 'abc'
    var_0 = wrap_var(str_0)
    assert str_0, var_0
    assert var_0.__class__.__name__ == 'AnsibleUnsafeText'
    # function call with 1 parameter
    str_0 = 'abc'
    var_0 = wrap_var(str_0)
    assert str_0, var_0
    assert var_0.__class__.__name__ == 'AnsibleUnsafeText'
    # function call with 2 parameter
    str_0 = 'abc'
    str_1 = 'def'
    var_0 = wrap_var(str_0, str_1)
    assert str_0, var_0
    assert var_0.__class__.__name__ == 'AnsibleUnsafeText'
    #

# Generated at 2022-06-25 13:54:26.104709
# Unit test for function wrap_var
def test_wrap_var():
    assert type(test_case_0()) is AnsibleUnsafeText
    assert wrap_var(AnsibleUnsafeText('abc')) == 'abc'
    assert wrap_var(AnsibleUnsafeBytes(b'abc')) == b'abc'
    assert isinstance(wrap_var(NativeJinjaText('abc')), NativeJinjaUnsafeText)
    assert wrap_var(None) is None

# Generated at 2022-06-25 13:54:27.335561
# Unit test for function wrap_var
def test_wrap_var():
    str_0 = 'abc'
    var_0 = wrap_var(str_0)

# Generated at 2022-06-25 13:54:31.902216
# Unit test for function wrap_var
def test_wrap_var():
    str_0 = 'abc'
    var_0 = wrap_var(str_0)
    var_1 = wrap_var(var_0)
    # var_0 should be unchanged - hashing should be the same
    assert (var_0 is var_1)
    var_2 = wrap_var(var_1)
    # var_1 should be unchanged - hashing should be the same
    assert (var_1 is var_2)

# Generated at 2022-06-25 13:54:40.704416
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) == None

    # Assert that wrap_var does not wrap already wrapped objects
    str_0 = 'abc'
    var_0 = wrap_var(str_0)
    var_1 = wrap_var(var_0)
    assert var_0 is var_1

    assert isinstance(var_0, AnsibleUnsafeText)
    assert not isinstance(var_0, str)
    assert var_0 == str_0

    # Test that it works with sequence types
    ints = (1, 2, 3,)
    wrapped_ints = wrap_var(ints)
    assert isinstance(wrapped_ints, tuple)
    for item in wrapped_ints:
        assert item == 1 or item == 2 or item == 3

    # Test that it works with dicts

# Generated at 2022-06-25 13:54:47.288299
# Unit test for function wrap_var
def test_wrap_var():
    try:
        test_case_0()
    except Exception as exc:
        print('AnsibleUnsafeBytes test failed')
        print('Exception: %s' %(exc))
        raise exc
    try:
        test_case_1()
    except Exception as exc:
        print('AnsibleUnsafeText test failed')
        print('Exception: %s' %(exc))
        raise exc
    try:
        test_case_2()
    except Exception as exc:
        print('AnsibleUnsafeText test failed')
        print('Exception: %s' %(exc))
        raise exc
