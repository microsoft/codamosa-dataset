

# Generated at 2022-06-25 13:44:41.156251
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = wrap_var(5)
    assert var_0 == 5



# Generated at 2022-06-25 13:44:49.018550
# Unit test for function wrap_var
def test_wrap_var():
    var_1 = to_unsafe_text('hello')
    assert isinstance(var_1, AnsibleUnsafeText)
    var_2 = to_unsafe_bytes('hello')
    assert isinstance(var_2, AnsibleUnsafeBytes)
    var_3 = to_unsafe_text('hi')
    var_4 = [var_1, var_3]
    var_5 = wrap_var(var_4)
    obj_var_1 = var_5[0]
    obj_var_2 = var_5[1]
    assert isinstance(obj_var_1, AnsibleUnsafeText)
    assert isinstance(obj_var_2, AnsibleUnsafeText)
    var_6 = {'key1': var_1, 'key2': var_3}
    var_7 = wrap

# Generated at 2022-06-25 13:44:56.272723
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var('Hello World!'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'Hello World!'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(AnsibleUnsafeText('Hello World!')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'Hello World!')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(tuple(['Hello', 'World!'])), tuple)
    assert isinstance(wrap_var(['Hello', 'World!']), list)
    assert isinstance(wrap_var(set(['Hello', 'World!'])), set)


# Generated at 2022-06-25 13:45:06.697192
# Unit test for function wrap_var
def test_wrap_var():
    # Test case with all types of values
    t = UnsafeProxy(1)
    assert(not isinstance(t, AnsibleUnsafe))
    t = UnsafeProxy(1.0)
    assert(not isinstance(t, AnsibleUnsafe))

# Generated at 2022-06-25 13:45:17.405335
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(1), type(1))
    assert isinstance(wrap_var(1.0), type(1.0))
    assert isinstance(wrap_var(1 + 1j), type(1 + 1j))
    assert isinstance(wrap_var(True), type(True))

    # Wrap a string
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    # Wrap a list of strings
    assert isinstance(wrap_var([b'foo', b'bar']), type([]))

# Generated at 2022-06-25 13:45:21.695318
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = {}
    var_0 = wrap_var(var_0)
    var_1 = "test"
    var_1 = wrap_var(var_1)
    var_2 = 2
    var_2 = wrap_var(var_2)

# Generated at 2022-06-25 13:45:28.214102
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    import ansible.utils.unsafe_proxy

    # test wrap_var return type
    assert type(wrap_var("")) == AnsibleUnsafeText
    assert type(wrap_var(b"")) == AnsibleUnsafeBytes

    # test wrap_var(AnsibleUnsafe)
    assert type(wrap_var(AnsibleUnsafeText(""))) == AnsibleUnsafeText
    assert type(wrap_var(AnsibleUnsafeBytes(b""))) == AnsibleUnsafeBytes



# Generated at 2022-06-25 13:45:35.058880
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(b"foo") is to_unsafe_bytes(b"foo")
    assert wrap_var(u"foo") is to_unsafe_text(u"foo")
    assert wrap_var(to_unsafe_bytes(b"foo")) is to_unsafe_bytes(b"foo")
    assert wrap_var(to_unsafe_text(u"foo")) is to_unsafe_text(u"foo")



# Generated at 2022-06-25 13:45:45.508330
# Unit test for function wrap_var
def test_wrap_var():
    foo = "foo"
    bar = "bar"
    foo_bar_list = [foo, bar]
    foo_bar_tuple = (foo, bar)
    foo_bar_dict = {foo: bar, bar: foo}
    foo_bar_set = set(foo_bar_list)
    case_0 = AnsibleUnsafeText("hello world")
    case_1 = wrap_var(case_0)
    case_2 = wrap_var(foo)
    case_3 = wrap_var(foo_bar_list)
    case_4 = wrap_var(foo_bar_tuple)
    case_5 = wrap_var(foo_bar_dict)
    case_6 = wrap_var(foo_bar_set)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:45:52.976705
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    display = Display()
    display.deprecated(
        'test_wrap_var is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )
    var_0 = UnsafeProxy('')
    assert var_0 == to_unsafe_text('')
    result = wrap_var('')
    assert var_0 == result

# Generated at 2022-06-25 13:46:01.419918
# Unit test for function wrap_var
def test_wrap_var():
  assert wrap_var(None) == None
  assert wrap_var(to_unsafe_bytes()) == AnsibleUnsafeBytes()
  assert wrap_var(to_unsafe_text()) == AnsibleUnsafeText()
  assert wrap_var(False) == False
  assert wrap_var(True) == True
  assert wrap_var(0) == 0
  assert wrap_var(-1) == -1
  assert wrap_var(1.1) == 1.1
  assert wrap_var(b'bytes') == AnsibleUnsafeBytes(b'bytes')
  assert wrap_var('str') == AnsibleUnsafeText('str')
  assert wrap_var(u'unicode') == AnsibleUnsafeText('unicode')
  assert wrap_var(NativeJinjaText(u'unicode')) == NativeJinjaUn

# Generated at 2022-06-25 13:46:11.064654
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(1) == 1
    assert wrap_var("hello") == 'hello'
    assert wrap_var(to_unsafe_text("hello")) == 'hello'

    assert wrap_var({"a": 1}) == {"a": 1}
    assert wrap_var({"a": to_unsafe_text("hello")}) == {"a": 'hello'}

    assert wrap_var(["a", 1]) == ['a', 1]
    assert wrap_var(["a", to_unsafe_text("hello")]) == ['a', 'hello']

    assert wrap_var((1, to_unsafe_text("hello"))) == (1, 'hello')
    assert wrap_var((to_unsafe_text("hello"), 1)) == ('hello', 1)


# Generated at 2022-06-25 13:46:12.398491
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = wrap_var('')
    assert var_0.__UNSAFE__ == True


# Generated at 2022-06-25 13:46:24.405351
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils._text import to_text

    # Test case 0
    var_0 = wrap_var('abcdef')
    assert isinstance(var_0, AnsibleUnsafeText)

    # Test case 1
    var_1 = wrap_var(b'abcdef')
    assert isinstance(var_1, AnsibleUnsafeBytes)

    # Test case 2
    var_2 = wrap_var('\xe3\x81')
    assert isinstance(var_2, AnsibleUnsafeText)

    # Test case 3
    var_3 = wrap_var({'a': 'b'})
    assert isinstance(var_3, dict)
    for k, v in var_3.items():
        assert isinstance(k, AnsibleUnsafeText)

# Generated at 2022-06-25 13:46:31.549445
# Unit test for function wrap_var
def test_wrap_var():
    class _TestClass(object):
        def __unsafe__(self):
            return True


# Generated at 2022-06-25 13:46:41.244997
# Unit test for function wrap_var
def test_wrap_var():
    val = b''
    assert wrap_var(val) == to_text(val, errors='surrogate_or_strict')
    val = u''
    assert wrap_var(val) == val
    # assert wrap_var(val) == val.encode('utf-8', 'surrogate_or_strict')
    val = [1, 2, 3]
    assert wrap_var(val) == val
    val = [u'foo', u'bar']
    assert wrap_var(val) == val
    assert wrap_var([1, u'foo']) == [1, u'foo']
    val = {u'bar': True, u'foo': None}
    assert wrap_var(val) == val
    val = {u'bar': True, u'foo': [1, 2, 3]}
   

# Generated at 2022-06-25 13:46:48.208464
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var("This is a string") == AnsibleUnsafeText("This is a string")
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(['a', None, 1]) == [AnsibleUnsafeText('a'), None, 1]
    assert wrap_var(['a', [1, 2, 3], 'b']) == [AnsibleUnsafeText('a'), [1, 2, 3], AnsibleUnsafeText('b')]

    assert wrap_var(['a', [1, 2, 3], 'b']) == [AnsibleUnsafeText('a'), [1, 2, 3], AnsibleUnsafeText('b')]

# Generated at 2022-06-25 13:46:59.019333
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = UnsafeProxy(u"") # <type 'unicode'>
    var_1 = wrap_var(var_0)
    assert isinstance(var_1, AnsibleUnsafeText)
    assert var_1 == u""

    var_2 = UnsafeProxy(b"") # <type 'str'>
    var_3 = wrap_var(var_2)
    assert isinstance(var_3, AnsibleUnsafeBytes)
    assert var_3 == to_unsafe_bytes(b"")

    var_4 = UnsafeProxy([]) # <type 'list'>
    var_5 = wrap_var(var_4)
    assert isinstance(var_5, list)
    assert var_5 == []

    var_6 = UnsafeProxy(()) # <type 'tuple'>

# Generated at 2022-06-25 13:47:04.736209
# Unit test for function wrap_var
def test_wrap_var():
    # fail if not a AnsibleUnsafe
    with pytest.raises(AssertionError):
        var_0 = wrap_var(1)
    # fail if not a AnsibleUnsafe
    with pytest.raises(AssertionError):
        var_1 = wrap_var(1.0)
    # fail if not a AnsibleUnsafe
    with pytest.raises(AssertionError):
        var_2 = wrap_var((1))
    # fail if not a AnsibleUnsafe
    with pytest.raises(AssertionError):
        var_3 = wrap_var([1])
    # fail if not a AnsibleUnsafe
    with pytest.raises(AssertionError):
        var_4 = wrap_var({'a' : 'b'})

    var_5 = wrap

# Generated at 2022-06-25 13:47:13.293006
# Unit test for function wrap_var
def test_wrap_var():
    #Tests for function wrap_var
    var_11 = to_unsafe_text("It's unsafe")
    var_12 = to_unsafe_bytes("It's safe")
    var_13 = _wrap_dict({1:2, 2:5})
    var_14 = wrap_var(var_11)
    var_15 = wrap_var(var_12)
    var_16 = wrap_var(var_13)
    var_17 = wrap_var(var_14)
    var_18 = wrap_var(var_15)
    var_19 = wrap_var(var_16)
    assert var_11 == var_14
    assert var_12 == var_15 == to_unsafe_bytes("It's safe")
    assert var_13 == var_16 == {1:2, 2:5}
