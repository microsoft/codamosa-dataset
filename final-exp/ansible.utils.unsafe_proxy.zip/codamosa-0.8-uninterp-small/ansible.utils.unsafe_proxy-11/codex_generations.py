

# Generated at 2022-06-25 13:44:50.114296
# Unit test for function wrap_var
def test_wrap_var():
    arg_0 = [3, 'zygote\u0000', (1, 2, 3), {'asdf'}, {'tore\u0000': {'asdf', 1, 'zygote\u0000'}}, {1, 'zygote\u0000'}]
    arg_1 = [1, 'Yf5\\i\t?x', (1, 2, 3), {'asdf'}, {'asdf'}, {1}]
    ret_0 = wrap_var(arg_0)
    print(ret_0)
    print(arg_0)
    print(arg_1)
    # assert_equal(ret_0, arg_1)
    # assert_equal(ret_0, arg_1)


# Generated at 2022-06-25 13:45:01.297357
# Unit test for function wrap_var

# Generated at 2022-06-25 13:45:11.575273
# Unit test for function wrap_var
def test_wrap_var():
    str_0 = 'f8D'
    var_0 = wrap_var(str_0)
    assert var_0.__UNSAFE__
    assert isinstance(var_0, AnsibleUnsafeBytes)

    str_0 = 'O{A\nB'
    var_0 = wrap_var(str_0)
    assert var_0.__UNSAFE__
    assert isinstance(var_0, AnsibleUnsafeText)

    str_0 = 'caV'
    var_0 = wrap_var(str_0)
    assert var_0.__UNSAFE__
    assert isinstance(var_0, NativeJinjaUnsafeText)

    str_0 = 'B5[f?Qh/'

# Generated at 2022-06-25 13:45:15.264221
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('\x00\x1eadmin\x11Yf5\\i\t?x') == u'\x00\x1eadmin\x11Yf5\\i\t?x'

# Generated at 2022-06-25 13:45:25.316697
# Unit test for function wrap_var
def test_wrap_var():
    # String
    var_0 = wrap_var('Yf5\\i\t?x')
    assert var_0.startswith(b'Yf5\\i\t?x')
    # Dict
    var_1 = wrap_var({'a': 'Yf5\\i\t?x', 'b': 'Yf5\\i\t?x', 'c': 'Yf5\\i\t?x', 'd': 'Yf5\\i\t?x', 'e': 'Yf5\\i\t?x'})
    assert var_1['a'].startswith(b'Yf5\\i\t?x')
    # List

# Generated at 2022-06-25 13:45:27.401357
# Unit test for function wrap_var
def test_wrap_var():
    str_0 = 'Yf5\\i\t?x'
    assert wrap_var(str_0) is not None


# Generated at 2022-06-25 13:45:38.366598
# Unit test for function wrap_var
def test_wrap_var():
    str_0 = 'Yf5\\i\t?x'
    var_0 = wrap_var(str_0)
    assert isinstance(var_0, AnsibleUnsafeBytes)
    var_1 = wrap_var(var_0)
    assert var_0 is var_1

    # Test wrapping binary
    var_2 = wrap_var(b'x')
    assert isinstance(var_2, AnsibleUnsafeBytes)
    assert var_2 == b'x'

    # Test wrapping text
    var_3 = wrap_var(u'x')
    assert isinstance(var_3, AnsibleUnsafeText)
    assert var_3 == u'x'

    # Test wrapping a non-string and non-mapping
    var_4 = wrap_var(123)
    assert var_4 == 123


# Generated at 2022-06-25 13:45:50.827026
# Unit test for function wrap_var
def test_wrap_var():
    # TODO: Write unit test
    var = None
    v = wrap_var(var)
    assert v == var
    var = {}
    v = wrap_var(var)
    assert v == var
    var = AnsibleUnsafeBytes("")
    v = wrap_var(var)
    assert v == var
    var = {'Yf5\\i\t?x': 'z\x15\xa5\x17\xfb\xf4@\xa4\xae\x01\x03\xae'}
    v = wrap_var(var)
    assert v == var

# Generated at 2022-06-25 13:45:53.703309
# Unit test for function wrap_var
def test_wrap_var():
    # Input:
    #   v => An item to be wrapped in unsafe context
    # Output:
    #   (bool) => True
    pass



# Generated at 2022-06-25 13:46:00.041331
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var("a") == "a"
    assert wrap_var("a".encode("utf8")) == b"a"
    assert wrap_var("a".encode("utf8")).__class__ == AnsibleUnsafeBytes
    assert wrap_var("a".encode("utf8")).decode("utf8") == "a"
    assert wrap_var("a".encode("utf8")).decode("utf8").encode("utf8") == b"a"
    assert wrap_var("a".encode("utf8")).decode("utf8").encode("utf8").__class__ == AnsibleUnsafeBytes

# Generated at 2022-06-25 13:46:10.995608
# Unit test for function wrap_var
def test_wrap_var():
    import sys
    import datetime
    import collections
    import types
    # test for invalid input
    try:
        wrap_var(1)
        assert 0, "invalid input did not raise exception"
    except Exception as e:
        pass
    # test for tuple
    test_tuple = ("one", 1)
    assert isinstance(wrap_var(test_tuple), tuple)
    assert isinstance(wrap_var(test_tuple)[0], AnsibleUnsafeText)
    assert isinstance(wrap_var(test_tuple)[1], AnsibleUnsafeText)
    # test for list
    test_list = ["one", 1]
    assert isinstance(wrap_var(test_list), list)
    assert isinstance(wrap_var(test_list)[0], AnsibleUnsafeText)

# Generated at 2022-06-25 13:46:11.778513
# Unit test for function wrap_var
def test_wrap_var():
    assert True



# Generated at 2022-06-25 13:46:22.006053
# Unit test for function wrap_var
def test_wrap_var():
    input = ["test", u"test", b"test", [1, 2, 3], (4, 5, 6), {'a': 'b'}]
    expected_output = [AnsibleUnsafeText(u"test"), AnsibleUnsafeText(u"test"), AnsibleUnsafeBytes(b"test"), (1, 2, 3), (4, 5, 6),
                       {'a': u'b'}]

    for in_value, expected in zip(input, expected_output):
        value = wrap_var(in_value)
        assert value == expected and isinstance(value, expected.__class__)

# Generated at 2022-06-25 13:46:22.521177
# Unit test for function wrap_var
def test_wrap_var():
    assert True

# Generated at 2022-06-25 13:46:27.729339
# Unit test for function wrap_var
def test_wrap_var():
    # Test num cases
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0

    # Test string cases
    assert wrap_var('string') == u'string'
    assert wrap_var(b'string') == b'string'
    assert type(wrap_var('string')) is AnsibleUnsafeText
    assert type(wrap_var(b'string')) is AnsibleUnsafeBytes
    assert type(wrap_var(AnsibleUnsafeText('foo'))) is AnsibleUnsafeText
    assert type(wrap_var(AnsibleUnsafeBytes(b'foo'))) is AnsibleUnsafeBytes

    # Test sequence cases
    assert wrap_var([]) == []
    assert wrap_var(()) == ()

# Generated at 2022-06-25 13:46:35.668444
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.parsing.vault import VaultLib

    set_0 = set()
    var_0 = wrap_var(set_0)
    assert isinstance(var_0, set)
    bytes_0 = b"omg"
    var_1 = wrap_var(bytes_0)
    assert isinstance(var_1, AnsibleUnsafeBytes)
    dict_0 = dict()
    var_2 = wrap_var(dict_0)
    assert isinstance(var_2, dict)
    list_0 = list()
    var_3 = wrap_var(list_0)
    assert isinstance(var_3, list)
    tuple_0 = tuple()
    var_4 = wrap_var(tuple_0)
    assert isinstance(var_4, tuple)
    test_0 = Native

# Generated at 2022-06-25 13:46:36.719602
# Unit test for function wrap_var
def test_wrap_var():
    assert True  # TODO: implement your test here


# Generated at 2022-06-25 13:46:45.771531
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common._collections_compat import OrderedDict
    # dict
    dict_0 = OrderedDict()
    dict_0['dict_0 key_0'] = 'dict_0 value_0'
    dict_0['dict_0 key_1'] = 'dict_0 value_1'
    dict_0['dict_0 key_2'] = 'dict_0 value_2'
    # list
    list_0 = []
    list_0.append('list_0 value_0')
    list_0.append('list_0 value_1')
    list_0.append('list_0 value_2')
    list_0.append('list_0 value_3')
    # str
    str_0 = 'str_0'
    # tuple

# Generated at 2022-06-25 13:46:46.304593
# Unit test for function wrap_var
def test_wrap_var():
    pass

# Generated at 2022-06-25 13:46:51.745717
# Unit test for function wrap_var
def test_wrap_var():
    # Try to raise AttributeError(Exception)
    # Try to raise ReferenceError(Exception)
    try:
        var_0 = set()
        wrap_var(var_0)
    except TypeError as err:
        assert (err.args[0] == "object has no attribute '__getattr__'")
    # Try to raise ReferenceError(Exception)
    try:
        var_1 = set()
        wrap_var(var_1)
    except TypeError as err:
        assert (err.args[0] == "object has no attribute '__getattr__'")
    # Try to raise TypeError(Exception)
    # Try to raise ReferenceError(Exception)

# Generated at 2022-06-25 13:46:55.067043
# Unit test for function wrap_var
def test_wrap_var():
    assert True


# Generated at 2022-06-25 13:47:04.517082
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(NativeJinjaText('foo')), NativeJinjaUnsafeText)
    assert isinstance(wrap_var(dict()), dict)
    assert isinstance(wrap_var(set()), set)
    assert isinstance(wrap_var(tuple()), tuple)
    assert isinstance(wrap_var(list()), list)
    assert isinstance(wrap_var(dict(foo=AnsibleUnsafeText('foo'))), dict)
    assert isinstance(wrap_var(set(AnsibleUnsafeText('foo'))), set)

# Generated at 2022-06-25 13:47:05.507452
# Unit test for function wrap_var
def test_wrap_var():
    set_0 = set()
    var_0 = wrap_var(set_0)

# Generated at 2022-06-25 13:47:14.270694
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import string_types

# Generated at 2022-06-25 13:47:19.674483
# Unit test for function wrap_var
def test_wrap_var():
    set_0 = set()
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(set_0), type(set_0))
    assert isinstance(wrap_var(1), int)
    assert isinstance(wrap_var(True), type(True))
    assert isinstance(wrap_var(1.0), float)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

# Generated at 2022-06-25 13:47:28.261848
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert isinstance(wrap_var(None), type(None))

    assert wrap_var('abc') == 'abc'
    assert isinstance(wrap_var('abc'), type('abc'))
    assert isinstance(wrap_var('abc'), AnsibleUnsafeText)

    test_val = b'abc'
    assert wrap_var(test_val) == test_val
    assert isinstance(wrap_var(test_val), type(test_val))
    assert isinstance(wrap_var(test_val), AnsibleUnsafeBytes)

    assert wrap_var(u'abc') == 'abc'
    assert isinstance(wrap_var(u'abc'), type('abc'))
    assert isinstance(wrap_var(u'abc'), AnsibleUnsafeText)


# Generated at 2022-06-25 13:47:37.761755
# Unit test for function wrap_var
def test_wrap_var():
    '''
    Test wrap_var function
    '''

    from ansible_collections.ansible.builtin.plugins.module_utils.common._collections_compat import Mapping, Set

    safe_text = wrap_var("")
    assert isinstance(safe_text, AnsibleUnsafeText)
    assert not safe_text.__UNSAFE__

    safe_text = wrap_var(u"")
    assert isinstance(safe_text, AnsibleUnsafeText)
    assert not safe_text.__UNSAFE__

    safe_text = wrap_var({"f": "123"})
    assert isinstance(safe_text, dict)
    assert not safe_text.__UNSAFE__

    safe_text = wrap_var({"f": "123"})

# Generated at 2022-06-25 13:47:47.291019
# Unit test for function wrap_var
def test_wrap_var():

    # From openstack/ironic/common/common_utils.py:144
    assert wrap_var(None) is None

    # From openstack/ironic/common/common_utils.py:145
    assert wrap_var('this should stay this way') == to_text('this should stay this way')

    # From openstack/ironic/common/common_utils.py:147
    a_dict = {'my_key': 'my_value'}
    assert wrap_var(a_dict) == {'my_key': 'my_value'}

    # From openstack/ironic/common/common_utils.py:148
    a_list = [0, 1, 2]
    assert wrap_var(a_list) == [0, 1, 2]

    # From openstack/ironic/common/common_utils

# Generated at 2022-06-25 13:47:53.017467
# Unit test for function wrap_var
def test_wrap_var():
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence, sequence_like

    with pytest.raises(AttributeError, match="'int' object has no attribute 'items'"):
        wrap_var(123)

    with pytest.raises(AttributeError, match="'float' object has no attribute 'items'"):
        wrap_var(123.45)

    assert wrap_var(True) is True
    assert wrap_var(False) is False

    assert isinstance(wrap_var('test'), AnsibleUnsafeText)
    assert not isinstance(wrap_var(to_bytes('test')), AnsibleUnsafeBytes)

# Generated at 2022-06-25 13:48:00.469083
# Unit test for function wrap_var
def test_wrap_var():
    import copy
    from ansible.module_utils.six import PY3

    var_0 = None
    var_1 = wrap_var(var_0)
    var_2 = wrap_var(var_1)

    assert var_2 is var_1

    var_0 = AnsibleUnsafeText(u'foo')
    var_1 = wrap_var(var_0)
    var_2 = wrap_var(var_1)

    assert var_2 is var_1

    var_0 = u'foo'
    var_1 = wrap_var(var_0)
    var_2 = wrap_var(var_1)

    assert var_2 is var_1

    var_0 = b'foo'
    if PY3:
        var_1 = wrap_var(var_0)
        var