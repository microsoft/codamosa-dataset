

# Generated at 2022-06-25 13:44:53.860869
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(0), type(0))
    assert isinstance(wrap_var(0.0), type(0.0))
    assert isinstance(wrap_var(0j), type(0j))
    assert isinstance(wrap_var([]), type([]))
    assert isinstance(wrap_var(()), type(()))
    assert isinstance(wrap_var(set()), type(set()))
    assert isinstance(wrap_var(AnsibleUnsafeBytes()), type(AnsibleUnsafeBytes()))
    assert isinstance(wrap_var(AnsibleUnsafeText()), type(AnsibleUnsafeText()))
    assert isinstance(wrap_var(b''), AnsibleUnsafeBytes)
    assert isinstance

# Generated at 2022-06-25 13:45:04.415166
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('foo') == 'foo'
    assert wrap_var('foo'[0]) == 'f'
    assert wrap_var(b'foo') == b'foo'
    assert wrap_var(b'foo'[0]) == 98
    assert wrap_var(['foo', 'bar']) == ['foo', 'bar']
    assert wrap_var(['foo', 'bar'][0]) == 'foo'
    assert wrap_var({'a': 'foo', 'b': 'bar'}) == {'a': 'foo', 'b': 'bar'}
    assert wrap_var(set(['foo', 'bar'])) == set(['foo', 'bar'])
    assert wrap_var(NativeJinjaText('foo')) == NativeJinjaUnsafeText('foo')

# Generated at 2022-06-25 13:45:15.030398
# Unit test for function wrap_var

# Generated at 2022-06-25 13:45:25.175891
# Unit test for function wrap_var
def test_wrap_var():
    ansible_unsafe_bytes_0 = AnsibleUnsafeBytes('aGVsbG8=')
    assert wrap_var(ansible_unsafe_bytes_0) == ansible_unsafe_bytes_0
    ansible_unsafe_text_0 = AnsibleUnsafeText('aGVsbG8=')
    assert wrap_var(ansible_unsafe_text_0) == ansible_unsafe_text_0
    ansible_jinja_unsafe_text_0 = NativeJinjaUnsafeText('aGVsbG8=')
    assert wrap_var(ansible_jinja_unsafe_text_0) == ansible_jinja_unsafe_text_0

    # Wrap binary already wrapped as unsafe_bytes
    # this should not raise an exception

# Generated at 2022-06-25 13:45:36.430644
# Unit test for function wrap_var
def test_wrap_var():
    import os
    import sys
    import types
    import unittest
    import collections

    ##############
    # Parameters #
    ##############
    t0 = None
    t1 = type(None)
    t2 = bool
    t3 = int
    t4 = float
    t5 = complex
    t6 = str
    t7 = bytes
    t8 = type(type)
    t9 = types.ModuleType
    t10 = types.FunctionType
    t11 = types.BuiltinFunctionType
    t12 = types.MethodType
    t13 = types.BuiltinMethodType
    t14 = types.CodeType
    t15 = types.TracebackType
    t16 = types.FrameType
    t17 = types.GetSetDescriptorType
    t18 = types.MemberDescript

# Generated at 2022-06-25 13:45:48.455044
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(1) == 1, 'Expected value does not match wrap_var(1)'
    assert wrap_var('a') == 'a', 'Expected value does not match wrap_var("a")'
    assert wrap_var(None) is None, 'Expected value does not match wrap_var(None)'
    assert wrap_var(True) is True, 'Expected value does not match wrap_var(True)'
    assert wrap_var(False) is False, 'Expected value does not match wrap_var(False)'
    assert wrap_var(['a','b','c']) == ['a','b','c'], 'Expected value does not match wrap_var(["a","b","c"])'

# Generated at 2022-06-25 13:45:57.874132
# Unit test for function wrap_var
def test_wrap_var():
    assert (UnsafeProxy.__new__(AnsibleUnsafeText, '') == AnsibleUnsafeText())
    assert (UnsafeProxy.__new__(AnsibleUnsafeText, '') == AnsibleUnsafeText())
    assert (UnsafeProxy.__new__(AnsibleUnsafeText, 'string') == AnsibleUnsafeText('string'))
    assert (UnsafeProxy.__new__(AnsibleUnsafeText, 'string') == AnsibleUnsafeText('string'))
    assert (UnsafeProxy.__new__(AnsibleUnsafeText, ' ') == AnsibleUnsafeText(' '))
    assert (UnsafeProxy.__new__(AnsibleUnsafeText, ' ') == AnsibleUnsafeText(' '))

# Generated at 2022-06-25 13:46:06.949505
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var('foo') == to_unsafe_text('foo')
    assert wrap_var({'foo': 'bar'}) == _wrap_dict({'foo': 'bar'})
    assert wrap_var(set(['foo', 'bar'])) == _wrap_set(['foo', 'bar'])
    assert wrap_var(['foo', 'bar']) == ['foo', 'bar']
    assert wrap_var(('foo', 'bar')) == ('foo', 'bar')
    assert wrap_var(NativeJinjaText('foo')) == NativeJinjaUnsafeText('foo')



# Generated at 2022-06-25 13:46:12.882647
# Unit test for function wrap_var
def test_wrap_var():
    # Unicode string
    ansible_unsafe_text_0 = wrap_var('test_value')
    assert isinstance(ansible_unsafe_text_0, AnsibleUnsafeText)
    assert ansible_unsafe_text_0 == 'test_value'

    # Nested structure
    ansible_unsafe_text_1 = wrap_var({'key_0': 'test_value'})
    assert isinstance(ansible_unsafe_text_1, dict)
    assert ansible_unsafe_text_1['key_0'] == 'test_value'

# Generated at 2022-06-25 13:46:24.873208
# Unit test for function wrap_var
def test_wrap_var():
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()

    dict_0['test_key_0'] = 'value_0'
    dict_0['test_key_1'] = 'value_1'
    dict_0['test_key_2'] = 'value_2'
    dict_0['test_key_3'] = 'value_3'
    dict_0['test_key_4'] = 'value_4'
    dict_0['test_key_5'] = 'value_5'
    dict_0['test_key_6']

# Generated at 2022-06-25 13:46:27.443146
# Unit test for function wrap_var
def test_wrap_var():
    pass


# Generated at 2022-06-25 13:46:35.151156
# Unit test for function wrap_var
def test_wrap_var():
    assert to_unsafe_text(None) is None
    assert to_unsafe_bytes(None) is None

    assert isinstance(to_unsafe_text(to_text(b'')), AnsibleUnsafeText)
    assert isinstance(to_unsafe_bytes(to_bytes('')), AnsibleUnsafeBytes)

    assert isinstance(to_unsafe_text(to_text(b'foo')), AnsibleUnsafeText)
    assert isinstance(to_unsafe_bytes(to_bytes('foo')), AnsibleUnsafeBytes)

    assert isinstance(to_unsafe_text(NativeJinjaText('foo')), NativeJinjaUnsafeText)
    assert isinstance(to_unsafe_bytes(NativeJinjaText('foo')), NativeJinjaUnsafeText)

# Generated at 2022-06-25 13:46:41.901782
# Unit test for function wrap_var
def test_wrap_var():
    # Input parameters
    # dict v = {"test_key": "test_value"}
    v = {"test_key": "test_value"}

    # Invoke method
    result = wrap_var(v)
    expected = AnsibleUnsafeText({'test_key': 'test_value'})

    # Check for constructor
    assert result['test_key'] == expected['test_key']
    assert result['test_key'] == expected['test_key']


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 13:46:49.943789
# Unit test for function wrap_var
def test_wrap_var():
    # Test cases for function wrap_var
    from ansible.utils.display import Display
    Display().deprecated(
        'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )
    unsafe_proxy_0 = UnsafeProxy(None)
    unsafe_proxy_1 = UnsafeProxy(None)
    unsafe_proxy_2 = UnsafeProxy(True)
    unsafe_proxy_3 = UnsafeProxy(0)
    try:
        unsafe_proxy_4 = UnsafeProxy(len)
    except TypeError as exception:
        assert exception
    else:
        assert False, "Did not fail as expected"
    unsafe_proxy_5 = UnsafeProxy("foo")
    unsafe_proxy

# Generated at 2022-06-25 13:47:00.441454
# Unit test for function wrap_var
def test_wrap_var():
    text = AnsibleUnsafeText('test')
    utf8 = AnsibleUnsafeText(u'\u20ac')
    unicode = AnsibleUnsafeText(u'unicode')
    bytestring = AnsibleUnsafeBytes(b'bytes')
    binary = AnsibleUnsafeBytes(b'\xff')
    list_ = [b'bytes', u'unicode', b'\xff']
    wrapped_list = _wrap_sequence(list_)
    assert isinstance(text, AnsibleUnsafeText)
    assert isinstance(utf8, AnsibleUnsafeText)
    assert isinstance(unicode, AnsibleUnsafeText)
    assert isinstance(bytestring, AnsibleUnsafeBytes)
    assert isinstance(binary, AnsibleUnsafeBytes)

# Generated at 2022-06-25 13:47:07.286122
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None

    assert wrap_var(AnsibleUnsafeText()) is not None
    assert wrap_var(AnsibleUnsafeText()) is not AnsibleUnsafeText()

    assert wrap_var(AnsibleUnsafeBytes()) is not None
    assert wrap_var(AnsibleUnsafeBytes()) is not AnsibleUnsafeBytes()

    # Test tuple
    t = (None, 'foo', 'bar')
    assert wrap_var(t) is not t
    assert t[0] is wrap_var(None)
    assert t[1] is not wrap_var('foo')
    assert t[2] is not wrap_var('bar')

    # Test list
    l = [None, 'foo', 'bar']
    assert wrap_var(l) is not l
    assert l[0]

# Generated at 2022-06-25 13:47:16.119939
# Unit test for function wrap_var
def test_wrap_var():
    v = 'hello'
    result = wrap_var(v)
    assert isinstance(result, AnsibleUnsafeText)

    v = 'hello'
    result = wrap_var(v)
    assert isinstance(result, AnsibleUnsafeText)

    v = ['hello1','hello2','hello3']
    result = wrap_var(v)
    assert isinstance(result[0], AnsibleUnsafeText)
    assert isinstance(result[1], AnsibleUnsafeText)
    assert isinstance(result[2], AnsibleUnsafeText)

    v = {'hello1':'world1','hello2':'world2'}
    result = wrap_var(v)
    assert isinstance(list(result.keys())[0], AnsibleUnsafeText)

# Generated at 2022-06-25 13:47:20.913464
# Unit test for function wrap_var
def test_wrap_var():
    assert "AnsibleUnsafeText('test-string')" == str(wrap_var("test-string"))
    assert str(wrap_var(5)) == "5"
    assert str(wrap_var(dict(test=5))) == "{'test': 5}"
    assert str(wrap_var(list([1, 2, 3]))) == "[1, 2, 3]"


# Generated at 2022-06-25 13:47:29.301719
# Unit test for function wrap_var
def test_wrap_var():
    # Testing Values
    test_dict = {'test_key': 'test_value'}
    test_bin = b'\x00\x01\x02'
    test_text = u'\u00ff\u01fe\u02fd'
    test_list = ['test_1', 'test_2']
    test_tuple = ('test_3', 'test_4')
    test_set = {'test_5', 'test_6'}

    # Testing expected results
    expected_dict = {to_unsafe_text('test_key'): to_unsafe_text('test_value')}
    expected_bin = AnsibleUnsafeBytes(test_bin)
    expected_text = AnsibleUnsafeText(test_text)

# Generated at 2022-06-25 13:47:39.059948
# Unit test for function wrap_var
def test_wrap_var():
    x = {
        "a": {
            "value": [
                "test_case_0",
            ],
            "test_case_1": "text"
        },
        "b": {
            "c": {
                "text": "test_case_2"
            },
            "test_case_3": "text"
        }
    }
    y = wrap_var(x)
    assert isinstance(y, dict) == True
    assert isinstance(y["a"]["value"][0], AnsibleUnsafeText) == True
    assert isinstance(y["a"]["test_case_1"], AnsibleUnsafeText) == True
    assert isinstance(y["b"]["c"]["text"], AnsibleUnsafeText) == True