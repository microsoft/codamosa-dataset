

# Generated at 2022-06-25 13:44:53.956676
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) == None
    assert wrap_var(5) == 5

    assert isinstance(wrap_var(5), int)
    assert isinstance(wrap_var(5.5), float)

    assert isinstance(wrap_var([]), list)
    assert isinstance(wrap_var({}), dict)
    assert isinstance(wrap_var(set()), set)

    assert wrap_var(True)
    assert not wrap_var(False)

    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)

    uniq_by = lambda x: sorted(set(x))
    assert uniq_by(wrap_var([1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-25 13:45:00.592766
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var("unicode_text") == "unicode_text"
    assert wrap_var(b"bytes_text") == b"bytes_text"
    assert isinstance(wrap_var(b"bytes_text"), AnsibleUnsafeBytes)
    assert isinstance(wrap_var("unicode_text"), AnsibleUnsafeText)
    assert isinstance(wrap_var(NativeJinjaText("native_jinja_text")), NativeJinjaUnsafeText)



# Generated at 2022-06-25 13:45:05.551011
# Unit test for function wrap_var
def test_wrap_var():
    for obj in [
        "test",
        1,
        1.0,
        True,
        None,
        [1, 2, 3],
        (1, 2, 3),
        {"a": 1, "b": 2},
    ]:
        wrapped = wrap_var(obj)
        unmodified = wrap_var(wrapped)
        assert obj == unmodified



# Generated at 2022-06-25 13:45:16.145967
# Unit test for function wrap_var
def test_wrap_var():
    # wrap_var should return the same value as input
    assert wrap_var(3) == 3

    # wrap_var should return the same value as input with empty string
    assert wrap_var('') == ''

    # wrap_var should not return the same value as input with unsafe unicode
    unsafe_unicode = NativeJinjaText('{{ foo }}')
    unsafe_unicode_wrapped = wrap_var(unsafe_unicode)

    # wrap_var should return the same value as input with unsafe byte
    unsafe_byte = b'{{ foo }}'
    unsafe_byte_wrapped = wrap_var(unsafe_byte)

    # wrap_var should return the same value as input with unsafe dict
    unsafe_dict = {'key1': '{{ foo }}', 'key2': 3}
    unsafe_dict_wrapped = wrap

# Generated at 2022-06-25 13:45:25.990281
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var('') == ''
    assert wrap_var(u'') == u''
    assert wrap_var(AnsibleUnsafeBytes(b'')) == b''
    assert wrap_var(AnsibleUnsafeText(u'')) == u''
    assert wrap_var(AnsibleUnsafeText(u'')) == u''
    assert wrap_var(NativeJinjaUnsafeText(u'')) == u''
    assert wrap_var(NativeJinjaUnsafeText(u'')) == u''
    assert wrap_var(2) == 2
    assert wrap_var(2.0) == 2.0
    assert wrap_var([]) == []
    assert wrap_var(()) == ()
    assert wrap_var({}) == {}

# Generated at 2022-06-25 13:45:37.155820
# Unit test for function wrap_var
def test_wrap_var():
    s = 'hi'
    assert wrap_var(s) == s

    assert isinstance(wrap_var(s), AnsibleUnsafeText)
    assert isinstance(wrap_var(s), text_type)

    s = u'hi'
    assert wrap_var(s) == s

    assert isinstance(wrap_var(s), AnsibleUnsafeText)
    assert isinstance(wrap_var(s), text_type)

    s = b'hi'
    assert wrap_var(s) == s

    assert isinstance(wrap_var(s), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(s), binary_type)

    s = {'hi': 'there'}
    assert wrap_var(s) == s

    assert isinstance(wrap_var(s), dict)


# Generated at 2022-06-25 13:45:43.552917
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('ansible') is not None
    assert isinstance(wrap_var('ansible'), AnsibleUnsafeBytes)
    assert wrap_var((1, 2, 3)) is not None
    assert isinstance(wrap_var((1, 2, 3)), tuple)
    assert isinstance(wrap_var(set((1, 2, 3))), set)
    assert wrap_var(['item1', 'item2']) is not None
    assert isinstance(wrap_var(['item1', 'item2']), list)
    assert wrap_var({'key1': 'val1', 'key2': 'val2'}) is not None
    assert isinstance(wrap_var({'key1': 'val1', 'key2': 'val2'}), dict)
    assert wrap_var(str('ansible')) is not None

# Generated at 2022-06-25 13:45:54.766769
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(1) == 1
    assert wrap_var("") == AnsibleUnsafeText("")
    assert wrap_var(u"") == AnsibleUnsafeText(u"")
    assert wrap_var(None) is None

    assert wrap_var("a string") == AnsibleUnsafeText("a string")
    assert wrap_var(u"a string") == AnsibleUnsafeText(u"a string")
    assert wrap_var("a string").__class__ == AnsibleUnsafeText
    assert wrap_var(u"a string").__class__ == AnsibleUnsafeText

    assert wrap_var({}) == {}
    assert wrap_var({'a':'a', 'b':'b'}) == {'a': AnsibleUnsafeText('a'), 'b': AnsibleUnsafeText('b')}

# Generated at 2022-06-25 13:46:01.884446
# Unit test for function wrap_var
def test_wrap_var():
    # Tests both functions.
    # This is technically a unit test not an integration test.
    # We're testing the internal functions.
    # When we refactor wrap_var to be a function that operates on a
    # single item, separate from handling jinja objects, this will become
    # a unit test.
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var("hello"), AnsibleUnsafeText)
    assert isinstance(wrap_var("hello".encode("utf-8")), AnsibleUnsafeBytes)

    assert isinstance(wrap_var({"a": "b"}), dict)
    assert isinstance(wrap_var({"a": "b"}).get("a"), AnsibleUnsafeText)

    assert isinstance(wrap_var(["a"]), list)
    assert isinstance

# Generated at 2022-06-25 13:46:11.342415
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var("hello") == to_unsafe_text("hello")
    assert wrap_var("hello") is not "hello"

    # Mapping type should be unwrapped if it is not
    my_dict = {"key1": "value1", "key2": "value2"}
    assert wrap_var(my_dict) is not my_dict
    assert wrap_var(my_dict) == my_dict
    new_dict = wrap_var(my_dict)
    assert isinstance(new_dict, dict)
    assert new_dict["key1"] == to_unsafe_text("value1")
    assert new_dict["key2"] == to_unsafe_text("value2")

    # Set type should be unwrapped if it is not
    my_set = set()