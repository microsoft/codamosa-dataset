

# Generated at 2022-06-25 13:44:52.701265
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = wrap_var()
    var_1 = wrap_var(u"Hello")
    var_2 = wrap_var(v=u"Hello")
    var_3 = wrap_var([u"Hello", 1])
    var_4 = wrap_var((u"Hello", 1))
    var_5 = wrap_var(v={u"Hello": 1})
    var_6 = wrap_var(v={u"Hello": [u"World", 2]})
    var_7 = wrap_var(None)
    var_8 = wrap_var("Hello")
    var_9 = wrap_var("Hello", v=0)
    var_10 = wrap_var("Hello", [0, 1, 2])
    var_11 = wrap_var("Hello", (0, 1, 2))
    var_12 = wrap_

# Generated at 2022-06-25 13:44:58.432038
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import OrderedDict

    assert wrap_var('foo') == to_unsafe_text('foo')
    assert wrap_var(b'foo') == to_unsafe_bytes('foo')
    assert wrap_var(b'foo') != to_unsafe_text('foo')

    assert wrap_var(to_unsafe_text('foo')) == to_unsafe_text('foo')
    assert wrap_var(to_unsafe_bytes('foo')) == to_unsafe_bytes('foo')
    assert wrap_var(to_unsafe_bytes('foo')) != to_unsafe_text('foo')

    assert wrap_var(u'foo') == to_unsafe_text('foo')
    assert wrap_var(u'foo') != to_unsafe_bytes

# Generated at 2022-06-25 13:45:06.130140
# Unit test for function wrap_var
def test_wrap_var():
    # Create dict 'b' containing unsafe elements
    # Wrap dict 'b' with unsafe proxy
    b = dict(a=1, b=2)
    b_proxy = wrap_var(b)
    assert b_proxy == dict(a=1, b=2)

    # Create dict 'c' containing safe elements
    # Wrap dict 'c' with unsafe proxy
    c = dict(a=to_unsafe_bytes(1), b=to_unsafe_bytes(2))
    c_proxy = wrap_var(c)
    assert c_proxy == dict(a=1, b=2)

# Generated at 2022-06-25 13:45:09.500949
# Unit test for function wrap_var
def test_wrap_var():
    var_1 = dict(a=dict(b=dict(c='hi')))
    var_0 = wrap_var(var_1)
    assert var_0['a']['b']['c'] == u'hi'



# Generated at 2022-06-25 13:45:20.744989
# Unit test for function wrap_var
def test_wrap_var():
    # Tuple Case
    var_0 = wrap_var((1, 2, "test"))
    expected_0 = (1, 2, "test")
    assert var_0 == expected_0

    # List Case
    var_1 = wrap_var(["test", "test", 1, 2])
    expected_1 = ["test", "test", 1, 2]
    assert var_1 == expected_1

    # String Case
    var_2 = wrap_var("test")
    expected_2 = "test"
    assert var_2 == expected_2

    # String Case
    var_3 = wrap_var("test")
    expected_3 = "test"
    assert var_3 == expected_3

    # Dict Case and Samples

# Generated at 2022-06-25 13:45:28.304305
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var({}) == {}
    assert wrap_var("") == b''
    assert wrap_var("") == ""
    assert wrap_var("a") == b'a'
    assert wrap_var("a") == "a"
    assert wrap_var("abc") == b'abc'
    assert wrap_var("abc") == "abc"
    assert wrap_var("") == ""
    assert wrap_var("") == ""
    assert wrap_var("a") == "a"
    assert wrap_var("a") == "a"
    assert wrap_var("abc") == "abc"
    assert wrap_var("abc") == "abc"
    assert wrap_var("xxxxx") == "xxxxx"

# Generated at 2022-06-25 13:45:38.916900
# Unit test for function wrap_var
def test_wrap_var():
    import ansible.module_utils.common.json_utils as json_utils
    import ansible.module_utils.common.text.converters as text_converters
    var_1 = wrap_var({})
    assert isinstance(var_1, dict)
    assert var_1 == {}
    var_2 = wrap_var([])
    assert isinstance(var_2, list)
    assert var_2 == []
    var_3 = wrap_var({'key': 'value'})
    assert isinstance(var_3, dict)
    assert var_3 == {'key': 'value'}
    assert isinstance(var_3['key'], text_type)
    assert var_3['key'] == 'value'
    var_4 = wrap_var([1, 2, 3])

# Generated at 2022-06-25 13:45:51.200993
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('ansible') == 'ansible'
    assert wrap_var(b'ansible') == b'ansible'
    assert wrap_var(u'ansible') == u'ansible'

    assert wrap_var({'k': 'ansible'}) == {'k': 'ansible'}
    assert wrap_var({u'k': u'ansible'}) == {u'k': u'ansible'}
    assert wrap_var({b'k': b'ansible'}) == {b'k': b'ansible'}

    assert wrap_var(['ansible', 'ansible']) == ['ansible', 'ansible']
    assert wrap_var([u'ansible', u'ansible']) == [u'ansible', u'ansible']

# Generated at 2022-06-25 13:45:59.857621
# Unit test for function wrap_var
def test_wrap_var():
    res = wrap_var('AnsibleUnsafeText')
    assert res == 'AnsibleUnsafeText'
    res = wrap_var(b'AnsibleUnsafeBytes')
    assert res == b'AnsibleUnsafeBytes'
    res = wrap_var(['AnsibleUnsafeText', 1, True, b'AnsibleUnsafeText', 1.0])
    assert res == ['AnsibleUnsafeText', 1, True, b'AnsibleUnsafeText', 1.0]
    res = wrap_var({'AnsibleUnsafeText': 'AnsibleUnsafeText', 'AnsibleUnsafeBytes': 1, 'AnsibleUnsafeText': True, 'AnsibleUnsafeText': b'AnsibleUnsafeText', 'AnsibleUnsafeBytes': 1.0})

# Generated at 2022-06-25 13:46:10.083796
# Unit test for function wrap_var
def test_wrap_var():

    # Test that an argument of None is returned unchanged
    assert wrap_var(None) is None

    # Test that a native json string is return unchanged
    assert wrap_var(u'this is a string') == u'this is a string'

    # Test that a json string is return unchanged
    assert wrap_var(u'this is a string') == u'this is a string'

    # Test that a native string is returned as unsafe unicode
    assert isinstance(wrap_var(b'this is a string'), AnsibleUnsafeBytes)

    # Test that a native unicode string is returned as unsafe unicode
    assert isinstance(wrap_var(b'this is a string'.decode('utf-8')), AnsibleUnsafeText)

    # Test that a native tuple is returned as unsafe unicode

# Generated at 2022-06-25 13:46:24.088802
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = wrap_var(to_text("test"))
    assert isinstance(var_0, AnsibleUnsafeText), "wrap_var test failed"

    var_1 = wrap_var(to_bytes("test"))
    assert isinstance(var_1, AnsibleUnsafeBytes), "wrap_var test failed"

    var_2 = wrap_var(to_text("test"))
    assert isinstance(var_2, AnsibleUnsafeText), "wrap_var test failed"

    var_3 = wrap_var(to_text("test"))
    assert isinstance(var_3, AnsibleUnsafeText), "wrap_var test failed"

    var_4 = wrap_var([to_text("test"), to_text("test")])
    assert isinstance(var_4, list), "wrap_var test failed"

   

# Generated at 2022-06-25 13:46:29.549895
# Unit test for function wrap_var
def test_wrap_var():
    import json
    import random
    dict_0 = {}
    dict_1 = {random.choice(range(10)): wrap_var(random.choice(range(10))), random.choice(range(10)): wrap_var(random.choice(range(10))), random.choice(range(10)): wrap_var(random.choice(range(10))), random.choice(range(10)): wrap_var(random.choice(range(10)))}
    list_0 = [random.choice(range(10)) for i in range(random.choice(range(10)))]
    tuple_0 = (random.choice(range(10)) for i in range(random.choice(range(10))))
    set_0 = {random.choice(range(10)) for i in range(random.choice(range(10)))}
    var_

# Generated at 2022-06-25 13:46:38.262089
# Unit test for function wrap_var
def test_wrap_var():
    # Test empty types
    assert wrap_var(None) is None
    assert wrap_var(False) is False
    assert wrap_var(True) is True
    assert wrap_var(0) == 0
    assert wrap_var(0.0) == 0.0
    assert wrap_var('') == ''
    assert wrap_var(b'') == b''

    # Test dict
    dict_0 = dict(a=1, b=2, c=3)
    dict_1 = wrap_var(dict_0)
    assert dict_0 is not dict_1
    assert dict_1 == dict_0

    dict_0 = dict(a=dict(aa=1))
    dict_1 = wrap_var(dict_0)
    assert dict_0 is not dict_1
    assert dict_1 == dict_0

# Generated at 2022-06-25 13:46:39.219034
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = wrap_var('foo')
    assert isinstance(var_0, AnsibleUnsafeText)

# Generated at 2022-06-25 13:46:45.516015
# Unit test for function wrap_var
def test_wrap_var():

    var_0 = u"test_unicode"
    assert(var_0 == wrap_var(var_0).decode())
    assert(var_0 == wrap_var(var_0.encode()).decode())

    var_1 = to_text({u"test_unicode_key": u"test_unicode_value"}, errors='surrogate_or_strict')
    assert(var_1 == wrap_var(var_1))

    var_2 = {u"test_unicode_dict_key_1": u"test_unicode_dict_value_1", u"test_unicode_dict_key_2": u"test_unicode_dict_value_2"}

    for key, value in var_2.items():
        assert(value == wrap_var(var_2)[key])

# Generated at 2022-06-25 13:46:53.392493
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(1) == 1
    assert wrap_var(u"test") == u"test"
    assert wrap_var(u'\u2019') == u'\u2019'
    assert wrap_var(u'\u2019'.encode('utf-8')) == u'\u2019'
    assert wrap_var(u'\u2019'.encode('utf-8'), errors='strict') == u'\u2019'.encode('utf-8')

    # TODO: Test for bytes
    # TODO: Test for NativeJinjaText, NativeJinjaUnsafeText

# Generated at 2022-06-25 13:47:03.125347
# Unit test for function wrap_var
def test_wrap_var():

    # Input data for this testcase
    input_0 = dict
    input_1 = u'\u0041'
    input_2 = b'\x00'
    input_3 = list
    input_4 = u'\u0041'
    input_5 = b'\x00'
    input_6 = set
    input_7 = u'\u0041'
    input_8 = b'\x00'
    input_9 = None
    input_10 = u'\u0041'
    input_11 = b'\x00'
    input_12 = u'\u0041'
    input_13 = b'\x00'
    input_14 = dict
    input_15 = u'\u0041'
    input_16 = b'\x00'

# Generated at 2022-06-25 13:47:05.042479
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = to_unsafe_text('bar')
    var_1 = wrap_var(var_0)
    assert isinstance(var_1, AnsibleUnsafeText)



# Generated at 2022-06-25 13:47:13.675712
# Unit test for function wrap_var
def test_wrap_var():
    var_1 = {}
    var_1 = wrap_var(var_1)
    var_2 = to_unsafe_text('ping')
    var_2 = wrap_var(var_2)
    var_3 = to_unsafe_text('ping')
    var_3 = wrap_var(var_3)
    var_4 = 'pong'
    var_4 = wrap_var(var_4)
    var_5 = to_unsafe_bytes('ping')
    var_5 = wrap_var(var_5)
    var_6 = to_unsafe_bytes(b'ping')
    var_6 = wrap_var(var_6)
    var_7 = b'ping'
    var_7 = wrap_var(var_7)

# Generated at 2022-06-25 13:47:22.833923
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(dict()).__class__.__name__ == 'dict'
    assert wrap_var(set()).__class__.__name__ == 'set'
    assert wrap_var(list()).__class__.__name__ == 'list'
    assert wrap_var(tuple()).__class__.__name__ == 'tuple'
    assert wrap_var(to_text('test')).__class__.__name__ == 'AnsibleUnsafeText'
    assert not wrap_var(to_text('test')).__UNSAFE__
    assert wrap_var(to_text('test')).__class__.__bases__ == (text_type, )
    assert wrap_var(None).__class__.__name__ == 'NoneType'

# Generated at 2022-06-25 13:47:32.281556
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = wrap_var(None)
    # assert

    var_0 = wrap_var(b"")
    # assert

    var_0 = wrap_var(True)
    # assert

    var_0 = wrap_var(1500)
    # assert

    var_0 = wrap_var(to_unsafe_bytes())
    # assert

    var_0 = wrap_var(to_unsafe_bytes(b"a"))
    # assert

    var_0 = wrap_var(to_unsafe_bytes(b"a", b"b"))
    # assert

    var_0 = wrap_var(to_unsafe_bytes(b"a", b"b", 1, 2, 3))
    # assert


# Generated at 2022-06-25 13:47:42.294561
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common._collections_compat import MutableSequence

    # dict
    assert wrap_var({}) == {}
    assert wrap_var({u'k0': u'v0', u'k1': u'v1'}) == {u'k0': AnsibleUnsafeText(u'v0'), u'k1': AnsibleUnsafeText(u'v1')}

    # list
    assert wrap_var([]) == []
    assert wrap_var([u'v0', u'v1']) == [AnsibleUnsafeText(u'v0'), AnsibleUnsafeText(u'v1')]

# Generated at 2022-06-25 13:47:49.252357
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = wrap_var(bytes())
    var_1 = wrap_var(dict())
    var_2 = wrap_var(float())
    var_3 = wrap_var(int())
    var_4 = wrap_var(list())
    var_5 = wrap_var(None)
    var_6 = wrap_var(set())
    var_7 = wrap_var(tuple())
    var_8 = wrap_var(unicode())
    var_9 = wrap_var(set(list()))
    var_10 = wrap_var(dict(dict()))


# Generated at 2022-06-25 13:47:56.549884
# Unit test for function wrap_var
def test_wrap_var():
    example_dict = to_unsafe_text(b"{'a': 1, 'b': 2}")
    example_list = to_unsafe_text(b"['a', 'b', 'c']")
    example_set = to_unsafe_text(b"set(['a', 'b', 'c'])")
    example_unicode = to_unsafe_text(b"{'a': 1, 'b': 2}")
    example_string = to_unsafe_text(b"{'a': 1, 'b': 2}")
    example_int = to_unsafe_text(1)
    example_long = to_unsafe_text(1)
    example_float = to_unsafe_text(1.0)

# Generated at 2022-06-25 13:48:03.685965
# Unit test for function wrap_var
def test_wrap_var():
    var_1 = to_unsafe_bytes()
    var_2 = to_unsafe_text()
    var_3 = to_unsafe_text()
    var_4 = to_unsafe_text()
    var_5 = to_unsafe_text()
    var_6 = to_unsafe_text()
    var_7 = to_unsafe_text()
    var_8 = to_unsafe_text()
    var_9 = to_unsafe_text()
    var_10 = to_unsafe_text()
    var_11 = to_unsafe_text()
    var_12 = to_unsafe_text()
    var_13 = to_unsafe_text()
    var_14 = to_unsafe_text()
    var_15 = to_unsafe_text()
    var_16

# Generated at 2022-06-25 13:48:11.780506
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var("hello"), AnsibleUnsafeText)
    assert isinstance(wrap_var(to_text("hello")), AnsibleUnsafeText)
    assert isinstance(wrap_var("hello".encode("utf-8")), AnsibleUnsafeBytes)
    assert isinstance(wrap_var({"a": "hello"}), dict)
    assert isinstance(wrap_var({"a": "hello"}).values()[0], AnsibleUnsafeText)
    assert isinstance(wrap_var(["hello"]), list)
    assert isinstance(wrap_var(["hello"])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var(("hello",)), tuple)
    assert isinstance(wrap_var(("hello",))[0], AnsibleUnsafeText)

# Generated at 2022-06-25 13:48:20.948301
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(set()), type(set()))
    assert isinstance(wrap_var(dict()), type(dict()))
    assert isinstance(wrap_var(list()), type(list()))
    assert isinstance(wrap_var(tuple()), type(tuple()))
    assert isinstance(wrap_var(str()), type(str()))
    assert isinstance(wrap_var(bytes()), type(bytes()))
    assert isinstance(wrap_var(u''), type(u''))
    assert isinstance(wrap_var('a'), type('a'))

# Generated at 2022-06-25 13:48:27.637622
# Unit test for function wrap_var
def test_wrap_var():
    # Test when None is passed
    assert wrap_var(None) is None

    # Test when a string is passed
    assert isinstance(wrap_var('abcd'), AnsibleUnsafeText)

    # Test when a dictionary is passed
    assert isinstance(wrap_var({'key1': 'abcd'}), dict)

    # Test when a list is passed
    assert isinstance(wrap_var(['abcd']), list)

    # Test when an integer is passed
    assert wrap_var(123) == 123

    # Test when a float is passed
    assert wrap_var(123.4) == 123.4



# Generated at 2022-06-25 13:48:36.833386
# Unit test for function wrap_var
def test_wrap_var():

    var_1 = to_unsafe_bytes()
    var_2 = to_unsafe_text()
    from ansible.module_utils.six.moves import StringIO
    var_3 = StringIO()

    test0 = wrap_var('')
    assert not isinstance(test0, string_types), "wrap_var returned a string when it shouldn't have: %r" % test0
    assert isinstance(test0, AnsibleUnsafeBytes), "wrap_var should have returned an AnsibleUnsafeBytes: %r" % test0
    # We expect this because we're passing to text_type
    assert isinstance(test0, text_type), "wrap_var should return unicode when passed unicode: %r" % test0

    test1 = wrap_var(var_1)

# Generated at 2022-06-25 13:48:47.278106
# Unit test for function wrap_var
def test_wrap_var():
    # empty dict
    var_1 = wrap_var({})
    assert isinstance(var_1, dict)

    # dict with string val
    var_2 = wrap_var({'a': 'b'})
    assert isinstance(var_2['a'], AnsibleUnsafeText)

    # dict with bytes val
    var_3 = wrap_var({'a': b'b'})
    assert isinstance(var_3['a'], AnsibleUnsafeBytes)

    # regular string
    var_4 = wrap_var('abc')
    assert isinstance(var_4, AnsibleUnsafeText)

    # regular bytes
    var_5 = wrap_var(b'abc')
    assert isinstance(var_5, AnsibleUnsafeBytes)

    # regular int
    var_6 = wrap_var(1)

# Generated at 2022-06-25 13:48:51.464641
# Unit test for function wrap_var
def test_wrap_var():
    # Check 0 length parameter
    try:
        test_case_0()
        test_status = True
    except Exception:
        test_status = False
    assert test_status



# Generated at 2022-06-25 13:49:02.405528
# Unit test for function wrap_var

# Generated at 2022-06-25 13:49:08.691962
# Unit test for function wrap_var
def test_wrap_var():
    var_1 = 'foo'
    var_2 = ()
    var_3 = {}
    var_4 = b'bar'
    var_5 = []
    var_6 = set()
    var_7 = AnsibleUnsafeBytes()
    var_8 = AnsibleUnsafeText()
    var_9 = NativeJinjaUnsafeText()

    var_10 = to_unsafe_bytes()

    for x in [var_1, var_2, var_3, var_4, var_5, var_6, var_7, var_8, var_9, var_10]:
        assert isinstance(wrap_var(x), AnsibleUnsafe)

# Generated at 2022-06-25 13:49:15.540942
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'foo'.decode('utf-8')), AnsibleUnsafeText)
    assert isinstance(wrap_var(None), type(None))

    assert isinstance(wrap_var({u'foo': u'bar'}), dict)
    assert isinstance(wrap_var({u'foo': u'bar'}).get(u'foo'), AnsibleUnsafeText)

    assert isinstance(wrap_var({b'foo': b'bar'}), dict)
    assert isinstance(wrap_var({b'foo': b'bar'}).get(b'foo'), AnsibleUnsafeBytes)


# Generated at 2022-06-25 13:49:23.395959
# Unit test for function wrap_var
def test_wrap_var():
    var_1 = AnsibleUnsafeText('test_case')
    var_2 = AnsibleUnsafeBytes('test_case')
    var_3 = NativeJinjaUnsafeText('test_case')
    var_4 = to_unsafe_text('test_case')
    var_5 = to_unsafe_bytes('test_case')
    var_6 = [AnsibleUnsafeText('test_case_0'),
             AnsibleUnsafeText('test_case_1'),
             AnsibleUnsafeText('test_case_2')]
    var_7 = [var_1, var_2, var_3, var_4, var_5, var_6]
    var_8 = ('test_case', [var_1, var_2, var_3, var_4, var_5, var_6])

# Generated at 2022-06-25 13:49:31.591147
# Unit test for function wrap_var
def test_wrap_var():
    # Test case 0
    var_0 = wrap_var(u'foo')
    assert(isinstance(var_0, AnsibleUnsafeText))

    var_1 = wrap_var(u'foo')
    assert(isinstance(var_1, AnsibleUnsafeText))

    var_2 = wrap_var(u'foo')
    assert(isinstance(var_2, AnsibleUnsafeText))

    var_3 = wrap_var(u'foo')
    assert(isinstance(var_3, AnsibleUnsafeText))

    var_4 = wrap_var(u'foo')
    assert(isinstance(var_4, AnsibleUnsafeText))

    var_5 = wrap_var(u'foo')
    assert(isinstance(var_5, AnsibleUnsafeText))

    var_6 = wrap_

# Generated at 2022-06-25 13:49:32.716059
# Unit test for function wrap_var
def test_wrap_var():
    # These lines of code tests the wrap_var function, but are not required.
    pass

# Generated at 2022-06-25 13:49:40.306676
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert wrap_var(['a', to_unsafe_text('b'), 'c']) == ['a', to_unsafe_text('b'), 'c']
    assert wrap_var({'a': 'b'}) == {'a': 'b'}
    assert wrap_var({'a': to_unsafe_bytes('b')}) == {'a': to_unsafe_bytes('b')}
    assert wrap_var(to_unsafe_text('')) == to_unsafe_text('')

# Generated at 2022-06-25 13:49:48.971631
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(''), AnsibleUnsafeBytes)
    assert isinstance(wrap_var('hello'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(123), int)
    assert isinstance(wrap_var(u'hello'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'hello'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'\u2603'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'\xe2\x98\x83'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var('hello'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'\u2603'), AnsibleUnsafeText)

# Generated at 2022-06-25 13:49:53.142659
# Unit test for function wrap_var
def test_wrap_var():
    # Test for string
    assert wrap_var("string") == AnsibleUnsafeText("string")
    # Test for unicode
    assert wrap_var(u"unicode") == AnsibleUnsafeText("unicode")
    # Test for int
    assert wrap_var(1) == 1
    # Test for float
    assert wrap_var(1.0) == 1.0
    # Test for bool
    assert wrap_var(True) == True
    assert wrap_var(False) == False
    # Test for None
    assert wrap_var(None) is None
    # Test for dict
    assert wrap_var({}) == AnsibleUnsafeText(u'{}')
    assert wrap_var({'a': 'b'}) == AnsibleUnsafeText(u"{'a': 'b'}")
    assert wrap_var

# Generated at 2022-06-25 13:50:02.669268
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.display import Display
    display = Display()
    log = []

    def log_debug(msg):
        log.append(msg)

    display.verbosity = 3
    display.debug = log_debug

    var_1 = test_wrap_var()
    var_2 = test_wrap_var()
    var_3 = test_wrap_var()
    var_4 = test_wrap_var()
    # Test if var_5 is an instance of tuple
    assert isinstance(var_5, tuple)
    # Test if var_6 is an instance of str
    assert isinstance(var_6, str)
    # Test if var_7 is an instance of list
    assert isinstance(var_7, list)
    #

# Generated at 2022-06-25 13:50:11.523757
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    assert isinstance(wrap_var(b'ansible'), AnsibleUnsafe)
    assert isinstance(wrap_var(u'ansible'), AnsibleUnsafe)
    assert isinstance(wrap_var('ansible'), AnsibleUnsafe)
    assert isinstance(wrap_var(u'\x00ansible'), AnsibleUnsafe)
    assert isinstance(wrap_var(u'\u0000ansible'), AnsibleUnsafe)
    assert isinstance(wrap_var(u'\U00000000ansible'), AnsibleUnsafe)
    assert isinstance(wrap_var(None), type(None))



# Generated at 2022-06-25 13:50:18.875576
# Unit test for function wrap_var
def test_wrap_var():
    # byte string test case
    var_1 = b'string'
    # for test case, just use the same var for all variable types
    var_2, var_3, var_4, var_5, var_6, var_7, var_8, var_9, var_10, var_11, var_12, var_13, var_14, var_15, var_16, var_17, var_18, var_19, var_20, var_21, var_22, var_23, var_24, var_25, var_26, var_27, var_28, var_29, var_30, var_31, var_32, var_33, var_34, var_35, var_36, var_37, var_38, var_39, var_40, var_41, var_42,

# Generated at 2022-06-25 13:50:25.313719
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('str') == AnsibleUnsafeText(u'str')
    assert wrap_var(u'unicode') == AnsibleUnsafeText(u'unicode')
    assert wrap_var(b'bytes') == AnsibleUnsafeBytes(b'bytes')
    assert wrap_var(1) == 1
    assert wrap_var(True) == True
    assert wrap_var(None) is None
    assert wrap_var(['a', 'list']) == ['a', 'list']
    assert wrap_var(('a', 'tuple')) == ('a', 'tuple')
    assert wrap_var({
        'a': 1,
        'dict': 'value'
    }) == {
        'a': 1,
        'dict': 'value'
    }

# Generated at 2022-06-25 13:50:32.546610
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    Display().deprecated(
        'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )
    assert len(_wrap_dict({"a": 1, "b": 2})) == 2
    assert len(_wrap_sequence([1, 2, 3, 4])) == 4
    assert len(_wrap_set(set([1, 2, 3, 3, 4]))) == 4
    assert wrap_var(1) == 1
    assert wrap_var("foo") == "foo"
    assert wrap_var("foo") == "foo"
    assert wrap_var("foo".encode()) == b"foo"

# Generated at 2022-06-25 13:50:43.102079
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var('foo') == 'foo'
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert wrap_var(b'foo') == b'foo'
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    input_str = to_text(b'foo', errors='surrogate_or_strict')
    assert wrap_var(input_str) == input_str
    assert isinstance(wrap_var(input_str), AnsibleUnsafeText)

    input_dict = {
        b'key': 'value',
        b'list': [b'foo', b'bar', b'baz'],
        b'tuple': (b'foo', b'bar', b'baz')
    }

   

# Generated at 2022-06-25 13:50:51.142458
# Unit test for function wrap_var
def test_wrap_var():
    """
    wrap_var(v)
    Recursively wrap an object in a proxy that marks it unsafe.
    Intended to mark native python data types as unsafe so they will not be
    further processed by jinja2.
    String types and None are wrapped directly.
    Mappings have their values wrapped.
    Sequences are wrapped in a list.
    """

    assert wrap_var(None) == None
    assert wrap_var(u'hello') == AnsibleUnsafeText(u'hello')

    assert wrap_var([1, 2, 3]) == [AnsibleUnsafeText('1'), AnsibleUnsafeText('2'), AnsibleUnsafeText('3')]

    # wrap_var({'a': 1})
    # AnsibleUnsafeText('a'): AnsibleUnsafeText('1')
    # wrap_var({'

# Generated at 2022-06-25 13:50:55.180765
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import Sequence
    import string

    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(Sequence()) == Sequence()
    assert wrap_var(string.ascii_letters) == string.ascii_letters

    var_1 = dict()
    var_1['k1'] = 'v1'
    var_1['k2'] = 'v2'
    var_1['k3'] = 'v3'
    var_1['k4'] = 'v4'
    var_1['k5'] = 'v5'
    var_1['k6'] = 'v6'
    var_1['k7'] = 'v7'
    var_1['k8'] = 'v8'
   

# Generated at 2022-06-25 13:50:57.042065
# Unit test for function wrap_var
def test_wrap_var():
    # TODO(Ansibot): Implement
    assert False

# Generated at 2022-06-25 13:50:58.744871
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('foo') == 'foo'
    assert wrap_var(123) == 123


# Generated at 2022-06-25 13:51:12.929119
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = wrap_var(None)
    assert var_0 is None
    var_1 = wrap_var(dict({'key_1': wrap_var('value_1')}))
    assert isinstance(var_1, dict), "var_1 should be dict"
    assert dict({'key_1': wrap_var('value_1')}) == var_1
    var_2 = wrap_var([wrap_var('value_1'), wrap_var('value_2'), wrap_var('value_3')])
    assert isinstance(var_2, list), "var_2 should be list"
    assert [wrap_var('value_1'), wrap_var('value_2'), wrap_var('value_3')] == var_2
    var_3 = wrap_var('value_1')

# Generated at 2022-06-25 13:51:17.277999
# Unit test for function wrap_var

# Generated at 2022-06-25 13:51:28.407501
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('var_0') == b'var_0'
    assert 'var_0' == AnsibleUnsafeText(wrap_var('var_0'))
    assert wrap_var(b'var_0') == b'var_0'
    assert 'var_0' == AnsibleUnsafeText(wrap_var(b'var_0'))
    assert wrap_var(True) is True
    assert wrap_var(None) is None
    assert wrap_var(10) == 10
    assert wrap_var(10.0) == 10.0
    assert wrap_var(dict(var_0='var_0')) == dict(var_0='var_0')
    assert wrap_var(dict(var_0=b'var_0')) == dict(var_0='var_0')
    assert wrap

# Generated at 2022-06-25 13:51:37.564326
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(AnsibleUnsafeText('test')) == 'test'
    assert wrap_var(AnsibleUnsafeText('test'),
        wrap_all=False, unsafe_proxy=True) == 'test'
    assert wrap_var(AnsibleUnsafeText('test'),
        wrap_all=False, unsafe_proxy=False) == 'test'
    assert wrap_var(AnsibleUnsafeBytes('test')) == 'test'
    assert wrap_var(AnsibleUnsafeBytes('test'),
        wrap_all=False, unsafe_proxy=True) == 'test'
    assert wrap_var(AnsibleUnsafeBytes('test'),
        wrap_all=False, unsafe_proxy=False) == 'test'
    assert wrap_var('test') == AnsibleUnsafeText('test')
    assert wrap

# Generated at 2022-06-25 13:51:46.835820
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3

    # Wrap an AnsibleUnsafeItem
    wrap_var(AnsibleUnsafeBytes('6c2a6b7eeb6c5d1cf5f564250'))
    wrap_var(AnsibleUnsafeText('6c2a6b7eeb6c5d1cf5f564250'))

    # Wrap an AnsibleUnsafeItem contained in another AnsibleUnsafeItem
    wrap_var(AnsibleUnsafeText(AnsibleUnsafeText('6c2a6b7eeb6c5d1cf5f564250')))
    wrap_var(AnsibleUnsafeBytes(AnsibleUnsafeBytes('6c2a6b7eeb6c5d1cf5f564250')))

    #

# Generated at 2022-06-25 13:51:51.703745
# Unit test for function wrap_var
def test_wrap_var():
    result = wrap_var()
    assert result is None
    result = wrap_var(arg=None)
    assert result is None
    result = wrap_var(arg=None, valid=None)
    assert result is None
    result = wrap_var(arg=None, valid=None, allow_unsafe=None)
    assert result is None
    assert result is not None
    assert result is None
    assert result is not None

# Generated at 2022-06-25 13:51:57.087889
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY2
    import pytest
    # No casting to ansible unsafe types
    test_value = "test_value"
    assert wrap_var(test_value) == test_value

    # Casting to ansible unsafe bytes if a byte string
    test_value = b"test_value"
    assert isinstance(wrap_var(test_value), AnsibleUnsafeBytes)
    assert wrap_var(test_value) == to_unsafe_bytes("test_value")

    # Casting to unsafe text if a text string
    if PY2:
        test_value = u"test_value"
    else:
        test_value = "test_value"
    assert isinstance(wrap_var(test_value), AnsibleUnsafeText)
    assert wrap_var(test_value)

# Generated at 2022-06-25 13:52:06.899458
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import string_types
    from ansible.utils.unsafe_proxy import wrap_var, AnsibleUnsafeBytes, AnsibleUnsafeText, NativeJinjaUnsafeText

    # Test all the built-in types
    # FIXME: We are missing the support for wrapping the following types:
    # complex, float, int, long, str
    #
    # We are also missing the support for wrapping user defined types,
    # but it is a much lower priority
    assert(isinstance(wrap_var(None), type(None)))
    assert(isinstance(wrap_var(False), bool))
    assert(isinstance(wrap_var(True), bool))

# Generated at 2022-06-25 13:52:15.306396
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = to_unsafe_bytes('foo')
    expected_0 = AnsibleUnsafeBytes('foo')
    assert var_0 == expected_0

    var_0 = to_unsafe_text('foo')
    expected_0 = AnsibleUnsafeText('foo')
    assert var_0 == expected_0

    var_0 = to_unsafe_bytes('a')
    var_1 = to_unsafe_bytes('b')
    var_0 = var_0 + var_1
    expected_0 = AnsibleUnsafeBytes('ab')
    assert var_0 == expected_0

    var_0 = to_unsafe_text('a')
    var_1 = to_unsafe_text('b')
    var_0 = var_0 + var_1

# Generated at 2022-06-25 13:52:23.236793
# Unit test for function wrap_var
def test_wrap_var():
  # Test case 0 - Ensure that a string passed in gets the correct type wrapper
  string = 'test string'
  assert type(wrap_var(string)) == AnsibleUnsafeText

  # Test case 1 - Ensure that a AnsibleUnsafe type passed in returns the original
  unsafestring = AnsibleUnsafeText('test string')
  assert type(wrap_var(unsafestring)) == AnsibleUnsafeText

  # Test case 2 - Ensure that a integer passed in returns unchanged
  int = 1
  assert type(wrap_var(int)) == type(int)

  # Test case 3 - Ensure that a float passed in returns unchanged
  float = 1.1
  assert type(wrap_var(float)) == type(float)

  # Test case 4 - Ensure that a list passed in returns a new list with all its items wrapped
  # This is

# Generated at 2022-06-25 13:52:41.607974
# Unit test for function wrap_var

# Generated at 2022-06-25 13:52:49.080935
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = wrap_var(None)
    var_1 = wrap_var(u'test')
    var_2 = wrap_var(u'\u00e9')
    var_3 = wrap_var(u'\u00e9'.encode('latin-1'))
    var_4 = wrap_var(b'\xe9')
    var_5 = wrap_var({"key_1": u"value_1", "key_2": u"value_2"})
    var_6 = wrap_var([u"value_1", u"value_2"])


# Generated at 2022-06-25 13:52:51.121670
# Unit test for function wrap_var
def test_wrap_var():
    assert(wrap_var('123') == '123')
    assert(type(wrap_var('123')) == AnsibleUnsafeText)


# Generated at 2022-06-25 13:52:58.767003
# Unit test for function wrap_var
def test_wrap_var():
    # Test with list
    var_1 = [2, 3, 4]
    var_1_expected = [2, 3, 4]
    var_1_actual = wrap_var(var_1)
    msg = "Expected: %s, Actual: %s" % (var_1_expected, var_1_actual)
    assert isinstance(var_1_actual, list), msg
    assert var_1_actual == var_1_expected, msg

    # Test with dict
    var_2 = {1: 2, 3: 4}
    var_2_expected = {1: 2, 3: 4}
    var_2_actual = wrap_var(var_2)
    msg = "Expected: %s, Actual: %s" % (var_2_expected, var_2_actual)
    assert isinstance

# Generated at 2022-06-25 13:53:04.904949
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = AnsibleUnsafeText()
    var_1 = wrap_var(var_0)
    assert var_1 is var_0
    var_2 = wrap_var('')
    assert var_2 == ''
    var_3 = wrap_var('')
    assert var_3 is var_2
    var_4 = wrap_var(u'')
    assert var_4 == ''
    assert var_4 is not var_3
    var_5 = wrap_var(u'')
    assert var_5 == ''
    assert var_5 is var_4

    # Test strings are not wrapped
    var_6 = (1, u'foo')
    assert wrap_var(var_6) is var_6
    var_8 = {'foo': u'bar'}
    var_9 = wrap_

# Generated at 2022-06-25 13:53:14.965332
# Unit test for function wrap_var
def test_wrap_var():
    class TestClass:
        pass
    import collections
    # Testing when var is int
    var_1 = 10
    result = wrap_var(var_1)
    assert result == 10

    # Testing when var is string
    var_1 = "test string"
    result = wrap_var(var_1)
    assert result == "test string"

    # Testing when var is tuple
    var_1 = (1, 2, 3)
    result = wrap_var(var_1)
    assert result == (1, 2, 3)

    # Testing when var is list
    var_1 = [1, 2, 3]
    result = wrap_var(var_1)
    assert result == [1, 2, 3]

    # Testing when var is dictionary
    var_1 = {"key": "value"}
    result = wrap

# Generated at 2022-06-25 13:53:23.924626
# Unit test for function wrap_var
def test_wrap_var():
    var = _wrap_dict({"ansible_local": 
                            {"hello": 
                                {"world": 
                                    {"bar": "yes"}}}})
    assert var["ansible_local"]["hello"]["world"]["bar"] == "yes"
    assert var.__class__.__name__ == "dict"
    assert isinstance(var, Mapping)

    var = _wrap_dict({u"ansible_local": 
                            {u"hello": 
                                {u"world": 
                                    {u"bar": u"yes"}}}})
    assert var[u"ansible_local"][u"hello"][u"world"][u"bar"] == u"yes"
    assert var.__class__.__name__ == "dict"

# Generated at 2022-06-25 13:53:26.706178
# Unit test for function wrap_var
def test_wrap_var():
    ret_val = wrap_var()
    assert ret_val is None



# Generated at 2022-06-25 13:53:36.002533
# Unit test for function wrap_var
def test_wrap_var():
    # Test AnsibleUnsafeBytes
    val = to_unsafe_bytes("asdf", "utf8")
    assert(isinstance(val, AnsibleUnsafeBytes))
    # Test AnsibleUnsafeText
    val = to_unsafe_text("asdf", "utf8")
    assert(isinstance(val, AnsibleUnsafeText))
    # Test None
    val = wrap_var(None)
    assert(val is None)
    # Test list of AnsibleUnsafeBytes
    val = wrap_var(["asdf", "123"])
    assert(isinstance(val, list))
    assert(isinstance(val[0], AnsibleUnsafeText))
    assert(isinstance(val[1], AnsibleUnsafeText))
    # Test list of AnsibleUnsafeText

# Generated at 2022-06-25 13:53:39.038727
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(to_text('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(to_bytes('foo')) == AnsibleUnsafeBytes(b'foo')

# Generated at 2022-06-25 13:53:55.932813
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var([1, 2, 3]) == [1, 2, 3]
    assert isinstance(wrap_var({1: "ansible"}), dict)
    assert isinstance(wrap_var("ansible"), AnsibleUnsafeText)
    assert isinstance(wrap_var(b"ansible"), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(None), type(None))
    assert wrap_var(b"ansible") == b"ansible"
    assert wrap_var(["ansible"]) == ["ansible"]
    assert isinstance(wrap_var({"ansible": 1}), dict)


# Generated at 2022-06-25 13:54:04.280014
# Unit test for function wrap_var
def test_wrap_var():
    # Test with a bytes object
    value = b'Ansible is a leading IT automation platform'
    wrapped_var = wrap_var(value)
    assert wrapped_var == AnsibleUnsafeBytes(value)

    # Test with a unicode object
    value = u'Ansible is a leading IT automation platform'
    wrapped_var = wrap_var(value)
    assert wrapped_var == AnsibleUnsafeText(value)

    # Test with a tuple of bytes and unicode objects
    bytes_value = b'Ansible is a leading IT automation platform'
    unicode_value = u'Ansible is a leading IT automation platform'
    tuple_value = (bytes_value, unicode_value)
    wrapped_var = wrap_var(tuple_value)

# Generated at 2022-06-25 13:54:11.353828
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('a') == AnsibleUnsafeText(u'a')
    assert wrap_var(1) == 1
    assert wrap_var(None) is None
    assert wrap_var(['a']) == [AnsibleUnsafeText(u'a')]
    assert wrap_var({'a': 'b'}) == {AnsibleUnsafeText(u'a'): AnsibleUnsafeText(u'b')}
    assert wrap_var({'a': ['b']}) == {AnsibleUnsafeText(u'a'): [AnsibleUnsafeText(u'b')]}
    assert wrap_var((['a'], 'b')) == ([AnsibleUnsafeText(u'a')], AnsibleUnsafeText(u'b'))
    assert wrap_var(u'a') == Ans

# Generated at 2022-06-25 13:54:21.250073
# Unit test for function wrap_var
def test_wrap_var():
    v = wrap_var('test')
    assert isinstance(v, AnsibleUnsafeText)
    v = wrap_var(u'test')
    assert isinstance(v, AnsibleUnsafeText)
    v = wrap_var(b'test')
    assert isinstance(v, AnsibleUnsafeBytes)
    v = wrap_var(['test'])
    assert isinstance(v[0], AnsibleUnsafeText)
    v = wrap_var(('test',))
    assert isinstance(v[0], AnsibleUnsafeText)
    v = wrap_var(set(['test']))
    assert isinstance(v.pop(), AnsibleUnsafeText)
    v = wrap_var({'key': 'test'})
    assert isinstance(v.get('key'), AnsibleUnsafeText)

# Generated at 2022-06-25 13:54:30.248177
# Unit test for function wrap_var
def test_wrap_var():
    # Create a test instance of the input param
    for instance in test_wrap_var.instances:
        # Verify the type of the input data
        if not isinstance(instance, test_wrap_var.types):
            continue

        # Verify the input data is in the expected format
        if not test_wrap_var.validator(instance):
            continue

        returned = wrap_var(instance)

        # Verify the function result
        assert isinstance(returned, test_wrap_var.types)

        # Verify the function result meets expectation
        assert test_wrap_var.validator(returned)


test_wrap_var.types = [
    dict,
    list,
    set,
    AnsibleUnsafeText,
    NativeJinjaUnsafeText
    ]

# Generated at 2022-06-25 13:54:39.072661
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = to_unsafe_bytes('hello world!')
    var_1 = to_unsafe_bytes('hello world!')
    assert var_0 == var_1
    var_0 = to_unsafe_bytes('hello world!')
    var_1 = to_unsafe_text('hello world!')
    assert var_0 != var_1
    var_0 = to_unsafe_bytes('hello world!')
    var_1 = to_unsafe_bytes('hello world!?')
    assert var_0 != var_1
    var_0 = to_unsafe_text('hello world!')
    var_1 = to_unsafe_text('hello world!')
    assert var_0 == var_1
    var_0 = to_unsafe_text('hello world!')

# Generated at 2022-06-25 13:54:40.160704
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(['aa']) == ['aa']

