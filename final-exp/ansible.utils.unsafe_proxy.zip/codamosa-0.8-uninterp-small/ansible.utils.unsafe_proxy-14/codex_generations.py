

# Generated at 2022-06-25 13:44:52.956568
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy(1), UnsafeProxy) == False # No value for 'obj' provided.
    assert isinstance(UnsafeProxy("asdf"), UnsafeProxy) == False # No value for 'obj' provided.
    assert isinstance(UnsafeProxy([1, 2, 3]), UnsafeProxy) == False # No value for 'obj' provided.
    assert isinstance(UnsafeProxy((1, 2, 3)), UnsafeProxy) == False # No value for 'obj' provided.
    assert isinstance(UnsafeProxy({"a": 1, "b": 2, "c": 3}), UnsafeProxy) == False # No value for 'obj' provided.


# Generated at 2022-06-25 13:44:54.262493
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    unsafe_proxy_0 = UnsafeProxy()
    print(type(unsafe_proxy_0))


# Generated at 2022-06-25 13:44:55.134473
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    unsafe_proxy_0 = UnsafeProxy()


# Generated at 2022-06-25 13:45:02.246409
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    unsafe_proxy_0_0 = UnsafeProxy(__builtins__.list)
    unsafe_proxy_0_1 = UnsafeProxy(__builtins__.dict)
    unsafe_proxy_0_2 = UnsafeProxy(__builtins__.set)
    unsafe_proxy_0_3 = UnsafeProxy(__builtins__.tuple)
    unsafe_proxy_0_4 = UnsafeProxy(__builtins__.str)
    unsafe_proxy_0_5 = UnsafeProxy(None)


# Generated at 2022-06-25 13:45:05.305508
# Unit test for function wrap_var
def test_wrap_var():
    input_string = "value"
    returned_value = wrap_var(input_string)
    expected_outcome = AnsibleUnsafeText("value")
    assert returned_value == expected_outcome



# Generated at 2022-06-25 13:45:11.219459
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(123) == 123
    assert wrap_var(123.456) == 123.456
    assert wrap_var(True) is True
    assert wrap_var('test_wrap_var') == b'test_wrap_var'
    assert wrap_var([123456, 789]) == [123456, 789]
    assert wrap_var({'test_wrap_var': 123456}) == {'test_wrap_var': 123456}

# Generated at 2022-06-25 13:45:22.164935
# Unit test for function wrap_var
def test_wrap_var():
    foo = "foo"
    bar = AnsibleUnsafeText('bar')
    baz = AnsibleUnsafeBytes('baz')
    foo_wrapped = wrap_var(foo)
    assert isinstance(foo_wrapped, AnsibleUnsafeText)
    assert foo == foo_wrapped
    assert bar == wrap_var(bar)
    assert baz == wrap_var(baz)

    a_string = "somestring"
    a_bytes = AnsibleUnsafeBytes(a_string)
    a_string_wrapped = wrap_var(a_string)
    a_bytes_wrapped = wrap_var(a_bytes)
    assert isinstance(a_string_wrapped, AnsibleUnsafeText)
    assert isinstance(a_bytes_wrapped, AnsibleUnsafeBytes)
    assert a

# Generated at 2022-06-25 13:45:34.051065
# Unit test for function wrap_var
def test_wrap_var():
    class TestClass():
        pass

    assert isinstance(wrap_var(None), type(None))
    assert wrap_var('Hello World') == 'Hello World'
    assert isinstance(wrap_var('Hello World'), string_types)
    assert isinstance(wrap_var(500), int)
    assert wrap_var(500) == 500
    assert isinstance(wrap_var(500.500), float)
    assert wrap_var(500.500) == 500.500
    assert isinstance(wrap_var(True), bool)
    assert wrap_var(True) is True
    assert isinstance(wrap_var(False), bool)
    assert wrap_var(False) is False
    assert wrap_var(()) == ()
    assert isinstance(wrap_var(()), tuple)

# Generated at 2022-06-25 13:45:41.838557
# Unit test for function wrap_var

# Generated at 2022-06-25 13:45:53.411293
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    unsafe_proxy_0 = UnsafeProxy()
    assert isinstance(type(unsafe_proxy_0), type)
    assert not isinstance(UnsafeProxy, Mapping)
    assert not isinstance(UnsafeProxy, Set)
    assert not isinstance(UnsafeProxy, Sequence)
    assert issubclass(UnsafeProxy, object)
    assert not issubclass(UnsafeProxy, object)
    assert not issubclass(UnsafeProxy, object)
    assert not issubclass(UnsafeProxy, object)
    assert not issubclass(UnsafeProxy, object)
    assert not issubclass(UnsafeProxy, object)
    assert not issubclass(UnsafeProxy, object)
    assert not issubclass(UnsafeProxy, object)
    assert not issubclass(UnsafeProxy, object)
    assert not issub

# Generated at 2022-06-25 13:46:01.934562
# Unit test for function wrap_var
def test_wrap_var():
    # test wrap_var(Mapping)
    a = {"b": "c"}
    a2 = wrap_var(a)
    assert isinstance(a2, dict)
    assert isinstance(a2["b"], AnsibleUnsafeText)

    # test wrap_var(None)
    a3 = wrap_var(None)
    assert a3 is None

    # test wrap_var(AnsibleUnsafe)
    a4 = wrap_var(AnsibleUnsafeText("a"))
    assert isinstance(a4, AnsibleUnsafeText)

    # test wrap_var(sequence)
    a5 = wrap_var(["a", b"b"])
    assert isinstance(a5, list)
    assert isinstance(a5[0], AnsibleUnsafeText)

# Generated at 2022-06-25 13:46:11.375763
# Unit test for function wrap_var
def test_wrap_var():

    # Test getting a string out of the mixin
    text = AnsibleUnsafeText('test_string')
    assert wrap_var(text) == 'test_string', "UnsafeText type was not returned as string"

    # Test getting a bytes out of the mixin
    sample_bytes = AnsibleUnsafeBytes(b'test_bytes')
    assert wrap_var(sample_bytes) == b'test_bytes', "UnsafeBytes type was not returned as bytes"

    # Test getting a native jinja text out of the mixin
    native_jinja = NativeJinjaUnsafeText('test_native_jinja')
    assert wrap_var(native_jinja) == 'test_native_jinja', "UnsafeNativeJinjaText type was not returned as string"

    # Test getting a dict of the mixin
    sample_

# Generated at 2022-06-25 13:46:23.226302
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(u'foo') == to_unsafe_text(u'foo')
    assert wrap_var(to_text(b'foo')) == to_unsafe_text(u'foo')
    assert wrap_var(to_bytes(u'foo')) == to_unsafe_bytes(b'foo')
    assert wrap_var(b'foo') == to_unsafe_bytes(b'foo')

    assert wrap_var(['foo', 'bar']) == to_unsafe_text([u'foo', u'bar'])
    assert wrap_var([123, 234]) == [123, 234]
    assert wrap_var(dict(foo='bar')) == {to_unsafe_text('foo', 'ascii'): to_unsafe_text(u'bar')}


# Generated at 2022-06-25 13:46:30.667584
# Unit test for function wrap_var
def test_wrap_var():
    o = object()
    assert o == wrap_var(o)

    assert AnsibleUnsafeText('foo') == wrap_var(AnsibleUnsafeText('foo'))
    assert AnsibleUnsafeBytes(b'foo') == wrap_var(AnsibleUnsafeBytes(b'foo'))

    assert AnsibleUnsafeText('foo') == wrap_var('foo')
    assert AnsibleUnsafeBytes(b'foo') == wrap_var(b'foo')

    assert AnsibleUnsafeText('foo') == wrap_var(AnsibleUnsafeText(b'foo').encode('utf-8'))
    assert AnsibleUnsafeBytes(b'foo') == wrap_var(AnsibleUnsafeBytes('foo').encode('utf-8'))


# Generated at 2022-06-25 13:46:39.932108
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import NativeJinjaUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    assert(isinstance(wrap_var('String Test'), AnsibleUnsafeText))
    assert(isinstance(wrap_var(u'String Test'), AnsibleUnsafeText))
    assert(isinstance(wrap_var(AnsibleUnsafeText('String Test')), AnsibleUnsafeText))
    assert(isinstance(wrap_var(AnsibleUnsafeBytes(b'String Test')), AnsibleUnsafeBytes))

# Generated at 2022-06-25 13:46:48.031204
# Unit test for function wrap_var
def test_wrap_var():
    to_wrap = {
        'a': 'foo', 'b': [1, {'c': 'bar'}], 'd': {'key': (1, 2, 3)}, 'e': 'bar', 'f': {'key2': [1, 2, 3]},
        'g': set([1, 2, 3]), 'h': b'raw', 'i': u'unicode', 'j': NativeJinjaText(u'raw'), 'k': '_raw',
        'l': {'key3': u'unicode'}, 'm': b'unsafe', 'n': AnsibleUnsafeText(u'unsafe'), 'o': UnsafeProxy(u'unsafe')
    }

# Generated at 2022-06-25 13:46:59.017229
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var('hello') == AnsibleUnsafeText(u'hello')
    assert wrap_var(u'hello') == AnsibleUnsafeText(u'hello')
    assert wrap_var(AnsibleUnsafeText(u'hello')) == AnsibleUnsafeText(u'hello')
    assert wrap_var(b'hello') == AnsibleUnsafeBytes(b'hello')
    assert wrap_var(AnsibleUnsafeBytes(b'hello')) == AnsibleUnsafeBytes(b'hello')
    assert wrap_var({u'k1': u'v1'}) == {AnsibleUnsafeText(u'k1'): AnsibleUnsafeText(u'v1')}

# Generated at 2022-06-25 13:47:04.674633
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import string_types

    # Test 1, wrap a text
    text_test_1 = "This is a test"
    wrapped_text_test_1 = wrap_var(text_test_1)
    assert wrapped_text_test_1.__class__ == AnsibleUnsafeText
    assert text_test_1 == wrapped_text_test_1

    # Test 2, wrap a binary
    binary_test_2 = b"This is a binary test"
    wrapped_binary_test_2 = wrap_var(binary_test_2)
    assert wrapped_binary_test_2.__class__ == AnsibleUnsafeBytes
    assert isinstance(wrapped_binary_test_2, string_types)
    assert binary_test_

# Generated at 2022-06-25 13:47:13.162937
# Unit test for function wrap_var
def test_wrap_var():
    assert(wrap_var(None) == None)

    my_dict = {u'key_1': u'value_1', u'key_2': u'value_2'}
    wrapped_dict = _wrap_dict(my_dict)
    assert(wrapped_dict == {AnsibleUnsafeText(u'key_1'): AnsibleUnsafeText(u'value_1'), AnsibleUnsafeText(u'key_2'): AnsibleUnsafeText(u'value_2')})

    my_list = [u'value_1', u'value_2']
    wrapped_list = _wrap_sequence(my_list)
    assert(wrapped_list == [AnsibleUnsafeText(u'value_1'), AnsibleUnsafeText(u'value_2')])


# Generated at 2022-06-25 13:47:22.346301
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var("Test") == "Test"
    assert wrap_var("Test") == "Test"
    assert wrap_var("Test") == "Test"
    assert wrap_var("Test") == "Test"
    assert wrap_var("Test") == "Test"
    assert wrap_var("Test") == "Test"
    assert wrap_var("Test") == "Test"
    assert wrap_var("Test") == "Test"
    assert wrap_var("Test") == "Test"
    assert wrap_var("Test") == "Test"
    assert wrap_var("Test") == "Test"
    assert wrap_var("Test") == "Test"
    assert wrap_var("Test") == "Test"
    assert wrap_var("Test") == "Test"
    assert wrap_var("Test") == "Test"

    assert wrap_