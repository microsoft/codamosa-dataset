

# Generated at 2022-06-25 13:44:54.262803
# Unit test for function wrap_var
def test_wrap_var():
    arg_0 = {u'a': u'value a', u'b': u'value b'}
    arg_1 = to_text(u'value c')
    arg_2 = to_text(u'value d')
    arg_3 = AnsibleUnsafeText(u'value e')
    expected_0 = wrap_var(arg_0)
    expected_1 = wrap_var(arg_1)
    expected_2 = wrap_var(arg_2)
    expected_3 = wrap_var(arg_3)
    assert expected_0 == {u'a': u'value a', u'b': u'value b'}
    assert expected_1 == u'value c'
    assert expected_2 == u'value d'
    assert expected_3 == u'value e'

# Generated at 2022-06-25 13:45:04.840082
# Unit test for function wrap_var
def test_wrap_var():
    try:
        from ansible.utils.display import Display
        import sys
        if sys.version_info < (2, 7):
            raise ImportError
        has_display = True
    except ImportError:
        has_display = False

    # The following test case is taken from the `python's documentation
    # on class `dict`.
    # https://docs.python.org/3.5/library/stdtypes.html#dict

    # Initializing the dictionary
    phone_book = {
        'bob': 7387,
        'alice': 3719,
        'jack': 7052,
    }

    # Output value of `phone_book`
    # {'alice': 3719, 'bob': 7387, 'jack': 7052}

# Generated at 2022-06-25 13:45:07.124256
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = to_unsafe_bytes()
    assert var_0.__UNSAFE__ == True



# Generated at 2022-06-25 13:45:07.744290
# Unit test for function wrap_var
def test_wrap_var():
    pass

# Generated at 2022-06-25 13:45:18.197900
# Unit test for function wrap_var
def test_wrap_var():
    '''
    Unit test for function wrap_var
    '''
    expected = [
        b'',
        42,
        '',
        {b'foo': b'bar'},
        [b'foo', b'bar', b'baz'],
        (b'foo', b'bar', b'baz'),
    ]
    actual = [
        wrap_var(''),
        wrap_var(42),
        wrap_var(''),
        wrap_var({'foo': 'bar'}),
        wrap_var(['foo', 'bar', 'baz']),
        wrap_var(('foo', 'bar', 'baz'))
    ]
    assert [type(i) for i in actual] == [type(i) for i in expected]



# Generated at 2022-06-25 13:45:27.114741
# Unit test for function wrap_var
def test_wrap_var():
    import json
    # Wrap a string in unsafe
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    # Wrap a list of string in unsafe
    assert wrap_var([b'foo', b'bar']) == [AnsibleUnsafeBytes('foo'), AnsibleUnsafeBytes('bar')]
    # Wrap a tuple of string in unsafe
    assert wrap_var((b'foo', b'bar')) == (AnsibleUnsafeBytes('foo'), AnsibleUnsafeBytes('bar'))
    # Wrap a dict with string natively wrapped in unsafe
    assert wrap_var({b'foo': 'bar'}) == {AnsibleUnsafeBytes('foo'): 'bar'}
    # Wrap a nested dict with string natively wrapped in unsafe

# Generated at 2022-06-25 13:45:31.083237
# Unit test for function wrap_var
def test_wrap_var():
    # Test case 0
    var_0 = 'foobar'
    var_0 = wrap_var(var_0)
    var_0 = wrap_var(var_0)
    assert type(var_0) == AnsibleUnsafeText

# Generated at 2022-06-25 13:45:40.496578
# Unit test for function wrap_var
def test_wrap_var():
    # Test set 1
    var_1 = "str_0"
    var_2 = wrap_var(var_1)
    assert var_2 is var_1

    # Test set 2
    var_1 = b"str_1"
    var_2 = wrap_var(var_1)
    assert var_2 is not var_1

    # Test set 3
    status = False
    var_1 = []
    var_2 = wrap_var(var_1)
    if isinstance(var_2, AnsibleUnsafeBytes):
        status = True
    assert status

    # Test set 4
    status = False
    var_1 = ()
    var_2 = wrap_var(var_1)
    if isinstance(var_2, AnsibleUnsafeText):
        status = True
    assert status

   

# Generated at 2022-06-25 13:45:52.483249
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None

    assert isinstance(wrap_var(''), AnsibleUnsafeText)
    assert isinstance(wrap_var('0'), AnsibleUnsafeText)

    assert isinstance(wrap_var(b''), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'0'), AnsibleUnsafeBytes)

    # Use an object that is a string subclass that doesn't define
    # __getattribute__
    class PartiallyBrokenString(str):
        pass
    assert isinstance(wrap_var(PartiallyBrokenString('0')), AnsibleUnsafeText)

    # Use an object that a subclass of str that sets __getattribute__ to None

# Generated at 2022-06-25 13:45:56.707591
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = {'a':'a'}
    wrap_var(var_0)
    var_1 = ['a', 'b', 'c']
    wrap_var(var_1)
    var_2 = 'abc'
    wrap_var(var_2)

# Generated at 2022-06-25 13:46:07.822139
# Unit test for function wrap_var
def test_wrap_var():
    # No output when assert is true
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var([]) == []
    assert wrap_var(u'unicode') == u'unicode'
    assert wrap_var(u'unicode') == u'unicode'
    assert wrap_var({}) == {}
    assert wrap_var({'key1': 'value1', 'key2': 'value2'}) == {'key1': 'value1', 'key2': 'value2'}
    assert wrap_var((1, 2, 3)) == (1, 2, 3)
    # Test if error raises when assert is false
    try:
        wrap_var(1) != 1
    except AssertionError:
        pass

# Generated at 2022-06-25 13:46:17.831824
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.native_jinja import to_yaml

    mock_data = """
foo: 123
bar: [1, 2, "3", {"foo": "bar"}]
bam:
  - 1
  - 3
  - "bam"
  -
    - 1
    - 2
    - {"foo": "bar"}
  -
    baz:
      - 1
      - "2"
    foo: bar
"""
    mock_data = to_unsafe_bytes(mock_data)
    ansible_data = AnsibleLoader(mock_data).get_single_data()
    wrapped_data = wrap_

# Generated at 2022-06-25 13:46:26.768867
# Unit test for function wrap_var
def test_wrap_var():
    # We explicitly return to our original state at the end of each test so we
    # don't accidentally affect future tests.
    mock_module = Mock()

    fake_module = type(mock_module)

    # TODO: This is broken.
    # var_0 = wrap_var(fake_module)
    # assert var_0 == mock_module
#
    # var_1 = wrap_var(AnsibleUnsafeBytes())
    # assert var_1 == AnsibleUnsafeBytes()
#
    # var_2 = wrap_var("string")
    # assert var_2 == AnsibleUnsafeText("string")
#
    # var_3 = wrap_var(tuple())
    # assert var_3 == tuple()
#
    # var_4 = wrap_var([])
    # assert var_4 == []


# Generated at 2022-06-25 13:46:28.927718
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('foo.bar') == AnsibleUnsafeText('foo.bar')
    assert isinstance(wrap_var(b'foo.bar'), AnsibleUnsafeBytes)
    assert wrap_var('foo.bar') != 'foo.bar'

# Generated at 2022-06-25 13:46:37.060685
# Unit test for function wrap_var
def test_wrap_var():
    import math
    # The function should work with unicode
    var_1 = u'Test string'
    var_1 = wrap_var(var_1)
    assert(isinstance(var_1, AnsibleUnsafeText))
    assert(isinstance(var_1, text_type))
    assert(var_1 == u'Test string')
    assert(var_1 == 'Test string')
    assert(str(var_1) == 'Test string')

    # The function should work with byte strings
    var_2 = b'Test string'
    var_2 = wrap_var(var_2)
    assert(isinstance(var_2, AnsibleUnsafeBytes))
    assert(isinstance(var_2, binary_type))
    assert(var_2 == b'Test string')

# Generated at 2022-06-25 13:46:46.066554
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var("") == b""
    assert wrap_var("plaintext") == b'plaintext'
    assert wrap_var(b"plainbytes") == b'plainbytes'

    # Test non-string
    val = wrap_var(True)
    assert val is True
    assert val.__UNSAFE__ is not True

    val = wrap_var(u"unicodetext")
    assert val == b'unicodetext'
    assert val.__UNSAFE__ is True
    assert val.encode() == b'unicodetext'
    assert val.encode().__UNSAFE__ is True

    val = wrap_var(b"bytes")
    assert val == b'bytes'
    assert val.__UNSAFE__ is True
    assert val.decode() == 'bytes'
    assert val

# Generated at 2022-06-25 13:46:56.633160
# Unit test for function wrap_var

# Generated at 2022-06-25 13:47:00.574712
# Unit test for function wrap_var
def test_wrap_var():
    obj = []
    for item in obj:
        assert isinstance(item, AnsibleUnsafeBytes)

    obj = {}
    for key, item in obj.items():
        assert isinstance(key, AnsibleUnsafeText)
        assert isinstance(item, AnsibleUnsafeText)


# Generated at 2022-06-25 13:47:08.417967
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = '0'
    var_1 = 1
    var_2 = []
    var_2.append(var_0)
    var_2.append(var_1)
    var_2.append(var_0)
    var_3 = {}
    var_3['0'] = var_0
    var_3['1'] = var_1
    var_3['2'] = var_2
    var_4 = {}
    var_4['0'] = var_0
    var_4['1'] = var_1
    var_4['2'] = var_2
    var_4['3'] = var_3
    var_5 = '0'
    var_6 = 1
    var_7 = []
    var_7.append(var_5)

# Generated at 2022-06-25 13:47:17.645167
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var('') == ''
    assert wrap_var(u'') == u''
    assert wrap_var(1) == 1
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var('foo') == 'foo'
    assert wrap_var(b'foo') == b'foo'

    assert wrap_var({'foo': 'bar'}) == {'foo': 'bar'}
    assert wrap_var([1, 2, 3]) == [1, 2, 3]
    assert wrap_var((1, 2, 3)) == (1, 2, 3)

    native_jinja_text_var = NativeJinjaText(u'foo')

    assert wrap_var(native_jinja_text_var) == native_jinja_text