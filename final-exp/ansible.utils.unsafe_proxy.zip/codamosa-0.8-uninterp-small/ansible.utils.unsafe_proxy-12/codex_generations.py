

# Generated at 2022-06-25 13:44:51.543484
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)

    assert isinstance(wrap_var(dict(a='b')), dict)
    assert isinstance(wrap_var(set(['a'])), set)
    assert isinstance(wrap_var((1, 2)), tuple)
    assert isinstance(wrap_var([1, 2]), list)

    assert isinstance(wrap_var(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)


# Generated at 2022-06-25 13:44:55.498002
# Unit test for function wrap_var
def test_wrap_var():
    assert _wrap_dict(dict(a=1, b=2)) == dict(a=1, b=2)
    assert _wrap_sequence(tuple([1, 2])) == tuple([1, 2])


if __name__ == "__main__":
    test_wrap_var()

# Generated at 2022-06-25 13:45:06.176568
# Unit test for function wrap_var
def test_wrap_var():
    ansible_unsafe_bytes_0 = AnsibleUnsafeBytes()
    assert wrap_var(ansible_unsafe_bytes_0) == ansible_unsafe_bytes_0, \
        "wrap_var() returned wrong result."

    ansible_unsafe_text_0 = AnsibleUnsafeText()
    assert wrap_var(ansible_unsafe_text_0) == ansible_unsafe_text_0, \
        "wrap_var() returned wrong result."

    ansible_unsafe_text_1 = AnsibleUnsafeText()
    assert _wrap_dict({ansible_unsafe_text_0: ansible_unsafe_text_1}) == {ansible_unsafe_text_0: ansible_unsafe_text_1}, \
        "wrap_var() returned wrong result."

    ansible

# Generated at 2022-06-25 13:45:09.548396
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(u'foo') == u'foo'
    # If we don't work with the type, we can't know what the original
    # type was
    assert type(wrap_var(u'foo')) == AnsibleUnsafeText


# Generated at 2022-06-25 13:45:20.794458
# Unit test for function wrap_var
def test_wrap_var():
    ansible_unsafe_bytes_0 = AnsibleUnsafeBytes()
    ansible_unsafe_text_0 = AnsibleUnsafeText()
    ansible_unsafe_bytes_1 = wrap_var('data')
    ansible_unsafe_bytes_2 = wrap_var(b'data')
    ansible_unsafe_bytes_3 = wrap_var(ansible_unsafe_text_0)
    ansible_unsafe_text_1 = wrap_var('data')
    ansible_unsafe_text_2 = wrap_var(b'data')
    ansible_unsafe_text_3 = wrap_var(ansible_unsafe_text_0)
    ansible_unsafe_text_4 = wrap_var(ansible_unsafe_bytes_0)
    ansible_unsafe_text_

# Generated at 2022-06-25 13:45:28.324218
# Unit test for function wrap_var
def test_wrap_var():
    # It might be better to just test a single case, but we can also test that
    # our wrap_var is behaving as expected
    original = {
        'key': 'value',
        'key2': 'value2',
        'key3': [
            {
                'key': 'value',
                'key2': 'value2',
                'key3': [],
                'key4': {},
            }
        ],
        'key4': {
            'key': 'value',
            'key2': 'value2',
            'key3': [],
            'key4': {},
        },
    }

    # if the original is not mutated, we need not recurse
    wrapped = wrap_var(original)
    assert type(wrapped) == type(original)
    assert wrapped['key'] == 'value'

# Generated at 2022-06-25 13:45:38.916615
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('this is a test string') == 'this is a test string'
    assert wrap_var(['this is a test string', 'this is a test string2']) == ['this is a test string', 'this is a test string2']
    assert wrap_var({'k':'v'}) == {'k':'v'}
    assert wrap_var('this is a test string') == 'this is a test string'
    assert wrap_var(['this is a test string', 'this is a test string2']) == ['this is a test string', 'this is a test string2']
    assert wrap_var({'k':'v'}) == {'k':'v'}

# Generated at 2022-06-25 13:45:45.123397
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var("") == ""
    assert wrap_var(None) == None
    assert wrap_var(AnsibleUnsafeText("")) == AnsibleUnsafeText("")
    assert wrap_var(AnsibleUnsafeText("1")) == AnsibleUnsafeText("1")
    assert wrap_var("1") == AnsibleUnsafeText("1")

# Generated at 2022-06-25 13:45:55.613396
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert _wrap_dict({}) == dict()
    assert _wrap_dict({'key0': 'value0'}) == {'key0': 'value0'}
    assert _wrap_sequence(()) == tuple()
    assert _wrap_sequence(['value0']) == tuple(['value0'])
    assert _wrap_set(set([])) == set([])
    assert _wrap_set(set(['value0'])) == set(['value0'])
    assert isinstance(wrap_var(AnsibleUnsafeBytes()), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(AnsibleUnsafeText()), AnsibleUnsafeText)

# Generated at 2022-06-25 13:46:02.393754
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(u'foo') == AnsibleUnsafeText(u'foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(None) is None
    # Test conversion to list
    assert wrap_var([1, 2, 3]) == [AnsibleUnsafeBytes(b'1'), AnsibleUnsafeBytes(b'2'), AnsibleUnsafeBytes(b'3')]
    assert wrap_var(set([1, 2, 3])) == set([AnsibleUnsafeBytes(b'1'), AnsibleUnsafeBytes(b'2'), AnsibleUnsafeBytes(b'3')])

# Generated at 2022-06-25 13:46:06.300658
# Unit test for function wrap_var
def test_wrap_var():
    ansible_unsafe_text_0 = wrap_var(None)


# Generated at 2022-06-25 13:46:12.168348
# Unit test for function wrap_var
def test_wrap_var():
    input_var = dict()
    ansible_unsafe_0 = AnsibleUnsafe()
    ansible_unsafe_0.__UNSAFE__ = False
    input_var['ansible_unsafe_0'] = ansible_unsafe_0
    expected = dict()
    expected['ansible_unsafe_0'] = ansible_unsafe_0
    actual = wrap_var(input_var)
    assert actual == expected, 'Expected: %s, Actual: %s' % (expected, actual)


# Generated at 2022-06-25 13:46:17.957907
# Unit test for function wrap_var
def test_wrap_var():
    obj = AnsibleUnsafe()
    assert isinstance(UnsafeProxy(obj), AnsibleUnsafe)

    obj = {'a': 'a'}
    assert isinstance(UnsafeProxy(obj), AnsibleUnsafe)


# Generated at 2022-06-25 13:46:26.882708
# Unit test for function wrap_var
def test_wrap_var():
    test_value = {u'foo': u'bar'}
    expected_value = {u'foo': u'bar'}
    assert wrap_var(test_value) == expected_value, 'Failed to wrap_var'

    test_value = {u'foo': u'bar'}
    expected_value = {u'foo': u'bar'}
    assert wrap_var(test_value) == expected_value, 'Failed to wrap_var'

    test_value = {u'foo': u'bar'}
    expected_value = {u'foo': u'bar'}
    assert wrap_var(test_value) == expected_value, 'Failed to wrap_var'

    test_value = {u'foo': u'bar'}
    expected_value = {u'foo': u'bar'}

# Generated at 2022-06-25 13:46:34.260157
# Unit test for function wrap_var
def test_wrap_var():
    # Test for a bytes type
    b_obj = b'b_obj'
    bytes_v = wrap_var(b_obj)
    assert isinstance(b_obj, bytes)
    assert isinstance(bytes_v, AnsibleUnsafeBytes)

    # Test for a text type
    text_obj = u'text_obj'
    text_v = wrap_var(text_obj)
    assert isinstance(text_obj, str)
    assert isinstance(text_v, AnsibleUnsafeText)

    # Test for a jinja text type
    jinja_text_obj = NativeJinjaText(u'jinja_text_obj')
    jinja_text_v = wrap_var(jinja_text_obj)
    assert isinstance(jinja_text_obj, NativeJinjaText)

# Generated at 2022-06-25 13:46:43.533913
# Unit test for function wrap_var
def test_wrap_var():
    ansible_unsafe_text_0 = AnsibleUnsafeText()
    assert wrap_var(ansible_unsafe_text_0) == ansible_unsafe_text_0
    ansible_unsafe_text_1 = AnsibleUnsafeText()
    assert wrap_var(ansible_unsafe_text_1) == ansible_unsafe_text_1
    ansible_unsafe_text_2 = AnsibleUnsafeText()
    assert wrap_var(ansible_unsafe_text_2) == ansible_unsafe_text_2
    ansible_unsafe_text_3 = AnsibleUnsafeText()
    assert wrap_var(ansible_unsafe_text_3) == ansible_unsafe_text_3
    ansible_unsafe_text_4 = AnsibleUnsafeText()
   

# Generated at 2022-06-25 13:46:53.045595
# Unit test for function wrap_var
def test_wrap_var():
    # Ensure that the wrap_var function works for the following types:
    # text, binary, None, AnsibleUnsafe, tuple, list, set, dict
    data_set = [
        b'foo',
        u'foo',
        None,
        (b'foo', b'bar', u'baz'),
        [b'foo', b'bar', u'baz'],
        {b'foo': b'bar', u'baz': u'wibble'},
        AnsibleUnsafeText(u'foo'),
        AnsibleUnsafeBytes(b'bar'),
    ]
    for original_item in data_set:
        assert wrap_var(original_item) is not original_item
        assert isinstance(original_item, type(wrap_var(original_item)))

# Generated at 2022-06-25 13:47:02.820808
# Unit test for function wrap_var
def test_wrap_var():
    """
    :return: N/A:
    """
    assert wrap_var('ansible unsafe text') == AnsibleUnsafeText('ansible unsafe text')
    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeText('ansible unsafe text')) == AnsibleUnsafeText('ansible unsafe text')
    assert wrap_var(u'ansible unsafe text') == AnsibleUnsafeText(u'ansible unsafe text')
    assert wrap_var(1) == 1
    assert wrap_var(b'ansible unsafe bytes') == AnsibleUnsafeBytes(b'ansible unsafe bytes')

    assert wrap_var([1]) == [1]
    assert wrap_var({1: 1}) == {1: 1}
    assert wrap_var((1,)) == (1,)

# Generated at 2022-06-25 13:47:08.946458
# Unit test for function wrap_var
def test_wrap_var():
    assert _wrap_dict({'key1': 'val1'}) == {'key1': AnsibleUnsafeText('val1')}
    assert _wrap_sequence(['key1', 'val1']) == [AnsibleUnsafeText('key1'), AnsibleUnsafeText('val1')]
    assert _wrap_set(['key1', 'val1']) == {AnsibleUnsafeText('key1'), AnsibleUnsafeText('val1')}
    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeText()) is not None
    assert wrap_var(AnsibleUnsafeBytes()) is not None



# Generated at 2022-06-25 13:47:16.496881
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeBytes()) == AnsibleUnsafeBytes()
    assert wrap_var(AnsibleUnsafeText()) == AnsibleUnsafeText()

    assert isinstance(_wrap_dict({'a': 1}), dict)
    assert isinstance(_wrap_sequence([1]), list)
    assert isinstance(_wrap_set([1]), set)

    assert isinstance(wrap_var(NativeJinjaText()), NativeJinjaUnsafeText)

    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)