

# Generated at 2022-06-25 13:44:53.544795
# Unit test for function wrap_var
def test_wrap_var():
    msg = 'wrap_var(input) returned incorrect output'
    assert 'AnsibleUnsafeText' in str(wrap_var(str())), msg
    assert 'AnsibleUnsafeBytes' in str(wrap_var(bytes())), msg
    assert 'AnsibleUnsafeText' in str(wrap_var('unicode')), msg
    assert 'AnsibleUnsafeBytes' in str(wrap_var(b'bytes')), msg
    assert 'AnsibleUnsafeText' in str(wrap_var(AnsibleUnsafeBytes(b'bytes'))), msg
    assert 'AnsibleUnsafeBytes' in str(wrap_var(AnsibleUnsafeText('unicode'))), msg
    assert 'AnsibleUnsafeText' in str(wrap_var(AnsibleUnsafeText('unicode'))), msg

# Generated at 2022-06-25 13:44:55.543209
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var("")
    assert wrap_var([])
    assert wrap_var({})
    assert wrap_var((""))


# Generated at 2022-06-25 13:45:06.223615
# Unit test for function wrap_var
def test_wrap_var():
    # Note that these are all intentionally different types for ease of testing
    test_vars = {
        'foo': 'foo',
        (): (),
        []: [],
        'is_unsafe': True,
        'is_not_unsafe': False,
        'bar': AnsibleUnsafeText(),
    }

    for key, value in test_vars.items():
        wrapped = wrap_var(value)
        assert type(wrapped) != type(value)  # We should have wrapped it
        if hasattr(value, '__UNSAFE__'):
            assert hasattr(wrapped, '__UNSAFE__')  # We should still have the UNSAFE flag
        else:
            assert not hasattr(wrapped, '__UNSAFE__')  # We should not have the UNSAFE flag


#

# Generated at 2022-06-25 13:45:16.938890
# Unit test for function wrap_var
def test_wrap_var():
    # Test for no args and no return.
    assert wrap_var() == None

    # Test for one arg and no return
    assert wrap_var('Ansible') == AnsibleUnsafeText('Ansible')

    # Test for multiple args and no return.
    assert wrap_var(['Ansible', None]) == ['Ansible', None]

    # Test for kwargs and no return
    assert wrap_var(s=['Ansible', None]) == {'s': ['Ansible', None]}

    # Test for no args and one return.
    assert wrap_var(return_arg=1) == 1

    # Test for one arg and one return.
    assert wrap_var('Ansible', return_arg='1') == AnsibleUnsafeText('Ansible')

    # Test for multiple args and one return


# Generated at 2022-06-25 13:45:26.457028
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'
    assert type(wrap_var(b'foo')).__name__ == 'AnsibleUnsafeBytes'
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(NativeJinjaText(u'foo')), NativeJinjaUnsafeText)
    assert wrap_var({'a': {'b': {'c': 'd'}}, 'e': ['f', 'g']}) == {u'a': {u'b': {u'c': u'd'}}, u'e': [u'f', u'g']}

# Generated at 2022-06-25 13:45:27.040062
# Unit test for function wrap_var
def test_wrap_var():
    pass

# Generated at 2022-06-25 13:45:29.800497
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('ansible') == AnsibleUnsafeText()
    assert wrap_var(['ansible']) == AnsibleUnsafeText()

# Generated at 2022-06-25 13:45:39.724667
# Unit test for function wrap_var
def test_wrap_var():
    # Test for example
    input_value = 'Base string'
    expected_value = AnsibleUnsafeText(input_value)
    output_value = wrap_var(input_value)
    assert output_value == expected_value

    # Test for type
    output_type = type(wrap_var(input_value))
    assert output_type == type(AnsibleUnsafeText(input_value))

    # Test for type conversion
    input_value = b'Base string'
    expected_value = AnsibleUnsafeText(input_value)
    output_value = wrap_var(input_value)
    assert output_value == expected_value

    # Test for type
    output_type = type(wrap_var(input_value))
    assert output_type == type(AnsibleUnsafeText(input_value))

   

# Generated at 2022-06-25 13:45:51.527077
# Unit test for function wrap_var
def test_wrap_var():
    # Ensure that a basic Unicode string is wrapped as AnsibleUnsafeText
    assert isinstance(wrap_var('some string'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'some string'), AnsibleUnsafeText)

    # Ensure that a unicode string with non-ASCII characters is wrapped as AnsibleUnsafeText
    assert isinstance(wrap_var(u'somé strįng'), AnsibleUnsafeText)

    # Ensure that a non-Unicode string is wrapped as AnsibleUnsafeBytes
    assert isinstance(wrap_var(b'some string'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'\x00\x01\x02'), AnsibleUnsafeBytes)

    # Ensure that a non-Unicode string with non-ASCII characters is wrapped as AnsibleUnsafeBytes

# Generated at 2022-06-25 13:45:59.710517
# Unit test for function wrap_var
def test_wrap_var():
    ansible_unsafe_text_0 = wrap_var(AnsibleUnsafeText)
    ansible_unsafe_text_1 = wrap_var(AnsibleUnsafeText)
    ansible_unsafe_text_2 = wrap_var(AnsibleUnsafeText)
    ansible_unsafe_text_3 = wrap_var(AnsibleUnsafeText)
    ansible_unsafe_text_4 = wrap_var(AnsibleUnsafeText)
    ansible_unsafe_text_5 = wrap_var(AnsibleUnsafeText)
    ansible_unsafe_text_6 = wrap_var(AnsibleUnsafeText)
    ansible_unsafe_text_7 = wrap_var(AnsibleUnsafeText)