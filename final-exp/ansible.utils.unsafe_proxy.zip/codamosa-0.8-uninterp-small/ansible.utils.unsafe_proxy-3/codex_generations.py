

# Generated at 2022-06-25 13:44:54.291905
# Unit test for function wrap_var
def test_wrap_var():
    assert _wrap_dict({}) == {}
    assert _wrap_dict({'foo': 'bar'}) == _wrap_dict({'foo': 'bar'})
    assert _wrap_dict({'foo': 'bar'}) == _wrap_dict({'foo': to_unsafe_text('bar')})
    assert _wrap_dict({'foo': 'bar'}) == _wrap_dict({'foo': to_unsafe_bytes('bar')})
    assert _wrap_dict({'foo': 'bar'}) == _wrap_dict({'foo': AnsibleUnsafeText(to_unsafe_text('bar'))})
    assert _wrap_dict({'foo': 'bar'}) == _wrap_dict({'foo': AnsibleUnsafeBytes(to_unsafe_bytes('bar'))})

# Generated at 2022-06-25 13:44:56.273454
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = wrap_var(None)
    var_1 = wrap_var(to_unsafe_bytes())

# Generated at 2022-06-25 13:45:06.698992
# Unit test for function wrap_var
def test_wrap_var():
    var_input = {'input': {'input': 'string'}}
    var_res = _wrap_dict(var_input)
    var_res_expected = {'input': {'input': AnsibleUnsafeText('string')}}
    assert var_res == var_res_expected, "Wrap dict failed"

    var_input = ['input', 'string']
    var_res = _wrap_sequence(var_input)
    var_res_expected = [AnsibleUnsafeText('input'), AnsibleUnsafeText('string')]
    assert var_res == var_res_expected, "Wrap sequence failed"

    var_input = set(['input', 'string'])
    var_res = _wrap_set(var_input)

# Generated at 2022-06-25 13:45:09.689378
# Unit test for function wrap_var
def test_wrap_var():
    arg = {'a': 1, 'b': 2}
    expected = {wrap_var('a'): 1, wrap_var('b'): 2}

    actual = wrap_var(arg)

    assert actual == expected

# Generated at 2022-06-25 13:45:20.888506
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = wrap_var("\u0434\u0432\u0430")
    assert var_0 == AnsibleUnsafeText("два")

    var_1 = wrap_var("\u0434\u0432\u0430".encode("utf-8"))
    assert var_1 == AnsibleUnsafeBytes("два")

    var_2 = wrap_var("\u0434\u0432\u0430".encode("utf-8"), errors="ignore")
    assert var_2 == AnsibleUnsafeBytes("\u0434\u0432\u0430")

    var_3 = wrap_var(["\u0434\u0432\u0430", "\u0434\u0432\u0430".encode("utf-8")])

# Generated at 2022-06-25 13:45:28.362383
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(123) == 123
    assert wrap_var("123") == AnsibleUnsafeText("123")
    assert wrap_var("123") == to_unsafe_text("123")
    assert wrap_var("123") == u"123"
    assert wrap_var(b"123") == AnsibleUnsafeBytes(b"123")
    assert wrap_var(b"123") == to_unsafe_bytes(b"123")
    assert wrap_var(b"123") == b"123"
    assert wrap_var(u"123") == AnsibleUnsafeText(u"123")
    assert wrap_var(u"123") == to_unsafe_text(u"123")
    assert wrap_var(u"123") == u"123"

# Generated at 2022-06-25 13:45:32.486028
# Unit test for function wrap_var
def test_wrap_var():
    var_1 = {
        1: 2,
        '3': 4,
        '5': [6, 7, 8],
        '9': {11: 12}
    }
    var_1 = wrap_var(var_1)



# Generated at 2022-06-25 13:45:41.137950
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var("Test string") is not None
    assert wrap_var("Test string") == AnsibleUnsafeText("Test string")
    assert isinstance(wrap_var("Test string"), AnsibleUnsafeText)

    assert wrap_var(u"Test unicode string") is not None
    assert wrap_var(u"Test unicode string") == AnsibleUnsafeText("Test unicode string")
    assert isinstance(wrap_var(u"Test unicode string"), AnsibleUnsafeText)

    assert wrap_var(b"Test binary string") is not None
    assert wrap_var(b"Test binary string") == AnsibleUnsafeBytes("Test binary string")
    assert isinstance(wrap_var(b"Test binary string"), AnsibleUnsafeBytes)


# Generated at 2022-06-25 13:45:46.247475
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = to_unsafe_bytes('test_str')
    var_1 = to_unsafe_bytes('test_str_2')

    # Test proper function of bytes unsafe text
    assert var_0 == var_1
    assert var_0 is not var_1



# Generated at 2022-06-25 13:45:55.413436
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = {
        "foo": to_unsafe_text("xyz"),
        "abc": to_unsafe_text("hello"),
    }
    var_1 = _wrap_dict(var_0)

    # function_wrapping_test_0
    assert var_1["foo"] == to_unsafe_text("xyz")

    # function_wrapping_test_1
    assert var_1["abc"] == to_unsafe_text("hello")
    var_2 = to_unsafe_text("hello")
    var_3 = wrap_var(var_2)

    # function_wrapping_test_2
    assert var_3 == to_unsafe_text("hello")

# Generated at 2022-06-25 13:46:02.932585
# Unit test for function wrap_var
def test_wrap_var():
    # Check that the following snippets when executed have no traceback:
    test_case_0()
    # Check for the expected exception for the following snippet:
    # (AssertionError raised when try to wrap safe var)
    from ansible.module_utils.common.collections import is_sequence
    assert isinstance(wrap_var([1]), list)
    assert isinstance(wrap_var({1: 1}), dict)
    assert isinstance(wrap_var(set([1])), set)
    assert isinstance(wrap_var(to_unsafe_text()), AnsibleUnsafeText)
    assert isinstance(wrap_var(to_unsafe_bytes()), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(NativeJinjaText('hallo')), NativeJinjaUnsafeText)

# Generated at 2022-06-25 13:46:12.042226
# Unit test for function wrap_var
def test_wrap_var():
    """Assert that wrap_var works correctly"""
    var_0 = wrap_var(None)
    assert var_0 is None

    var_1 = wrap_var("test")
    assert isinstance(var_1, AnsibleUnsafeText)

    var_2 = wrap_var(AnsibleUnsafeBytes(b"test"))
    assert isinstance(var_2, binary_type)

    var_3 = wrap_var(AnsibleUnsafeText("test"))
    assert isinstance(var_3, AnsibleUnsafeText)

    var_4 = wrap_var(["test"])
    assert isinstance(var_4, list)
    assert isinstance(var_4[0], AnsibleUnsafeText)

    var_5 = wrap_var(set(["test"]))

# Generated at 2022-06-25 13:46:16.974766
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = to_unsafe_text("ansible")
    var_1 = wrap_var(var_0)
    assert var_1 == "ansible"



# Generated at 2022-06-25 13:46:25.790345
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = {'0': {'a': 'b', 'c': 'd'},
             '1': ['a', 'b', 'c'],
             '2': ['a', 'b', 5, 'c'],
             '3': 'abcd',
             '4': {'a': {'b': 'c'}},
             '5': {'a': ['b', 'c']}}

    var_1 = wrap_var(var_0)
    # First var_0 and var_1 are identical
    assert var_0 == var_1
    # Then they become different when we wrap the var
    var_2 = wrap_var(var_0)
    assert var_0 == var_1
    assert var_0 != var_2



# Generated at 2022-06-25 13:46:31.743307
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = wrap_var(to_text(u'"'))
    assert_equal(var_0, to_text(u'"'))
    var_1 = wrap_var(to_text(u'""'))
    assert_equal(var_1, to_text(u'""'))
    var_2 = wrap_var(to_text(u'`'))
    assert_equal(var_2, to_text(u'`'))
    var_3 = wrap_var(to_text(u'``'))
    assert_equal(var_3, to_text(u'``'))
    var_4 = wrap_var(to_text(u'\n'))
    assert_equal(var_4, to_text(u'\n'))

# Generated at 2022-06-25 13:46:41.511533
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = 'Test string'
    assert(wrap_var(var_0) == AnsibleUnsafeText(var_0))

    var_1 = b'Test string'
    assert(wrap_var(var_1) == AnsibleUnsafeBytes(var_1))

    var_2 = AnsibleUnsafeText(var_0)
    assert(wrap_var(var_2) == var_2)

    var_3 = AnsibleUnsafeBytes(var_1)
    assert(wrap_var(var_3) == var_3)

    var_4 = (var_1, var_2)
    assert(wrap_var(var_4) == (AnsibleUnsafeBytes(var_1), AnsibleUnsafeText(var_0)))

    var_5 = [var_1, var_2]
   

# Generated at 2022-06-25 13:46:43.897783
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = to_unsafe_text()
    var_1 = wrap_var(var_0)
    res_0 = var_1
    assert res_0 is not None

# Generated at 2022-06-25 13:46:50.286488
# Unit test for function wrap_var
def test_wrap_var():
    # Sequence insertion test
    var_10 = wrap_var((1, 2, 3, 4, 5))
    # Sequence access test
    var_11 = wrap_var((1, 2, 3, 4, 5))[2]
    # Error test
    try:
        var_12 = wrap_var({"hello": "goodbye"}).test
    except AttributeError:
        pass
    # Dictionary insertion test
    var_14 = wrap_var({'1': 1, '2': 2, '3': 3})
    # Dictionary access test
    var_15 = wrap_var({'1': 1, '2': 2, '3': 3})['1']
    # String test
    var_16 = wrap_var("string")
    # String access test
    var_17 = wrap_var("string")[2]
    # String

# Generated at 2022-06-25 13:46:58.788769
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = _wrap_dict({"foo": "bar"})
    print(var_0)

    var_1 = _wrap_dict({u"aaa": u"bbb"})
    print(var_1)

    var_2 = _wrap_set({"foo"})
    print(var_2)

    var_3 = _wrap_set({u"aaa"})
    print(var_3)

    var_4 = _wrap_sequence(["foo"])
    print(var_4)

    var_5 = _wrap_sequence([u"aaa"])
    print(var_5)


# Generated at 2022-06-25 13:47:07.258583
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(""), AnsibleUnsafeText)
    assert wrap_var(b"").__UNSAFE__ == True
    assert wrap_var(u"").__UNSAFE__ == True
    assert wrap_var({"a":"b"}).__UNSAFE__ == True
    assert wrap_var([{"a":"b"}]).__UNSAFE__ == True
    assert wrap_var(None) == None
    assert wrap_var({"a":None})["a"] == None
    assert wrap_var({"a":u"b"})["a"].__UNSAFE__ == True

    # To test compatibility with previous code we also add tests for wrap_var
    assert wrap_var(u"\t").__class__ == text_type
    assert wrap_var(b"\t").__class__ == binary_type