

# Generated at 2022-06-25 13:44:46.794813
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    obj = []
    args = []
    kwargs = {}
    UnsafeProxy(obj, *args, **kwargs)


# Generated at 2022-06-25 13:44:51.391597
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    list_0 = []
    unsafe_proxy_0 = UnsafeProxy()
    unsafe_proxy_0.__new__(AnsibleUnsafe)
    unsafe_proxy_0.__new__(AnsibleUnsafeBytes, "")
    unsafe_proxy_0.__new__(AnsibleUnsafeText, "")
    unsafe_proxy_0.__new__(NativeJinjaUnsafeText, "")

# Generated at 2022-06-25 13:44:53.065820
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    list_0 = []
    unsafe_proxy_0 = UnsafeProxy()
    # Assert.
    assert True


# Generated at 2022-06-25 13:44:56.533585
# Unit test for function wrap_var
def test_wrap_var():
    obj_0 = 'y'
    # TODO: assertion
    # assert wrap_var(obj_0) == AnsibleUnsafeText(obj_0)

    obj_1 = []
    # TODO: assertion
    # assert wrap_var(obj_1) == AnsibleUnsafeText(obj_1)


if __name__ == '__main__':
    test_wrap_var()
    test_case_0()

# Generated at 2022-06-25 13:44:58.410673
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    list_0 = []
    unsafe_proxy_0 = UnsafeProxy()

# Generated at 2022-06-25 13:45:08.500451
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    list_0 = []
    unsafe_proxy_0 = UnsafeProxy()
    safe_proxy_0 = UnsafeProxy(list_0)
    safe_proxy_1 = UnsafeProxy(safe_proxy_0)
    safe_proxy_2 = UnsafeProxy(safe_proxy_1)
    safe_proxy_3 = UnsafeProxy(safe_proxy_2)
    safe_proxy_4 = UnsafeProxy(safe_proxy_3)
    safe_proxy_5 = UnsafeProxy(safe_proxy_4)
    safe_proxy_6 = UnsafeProxy(safe_proxy_5)
    safe_proxy_7 = UnsafeProxy(safe_proxy_6)
    safe_proxy_8 = UnsafeProxy(safe_proxy_7)
    safe_proxy_9 = UnsafeProxy(safe_proxy_8)
    safe

# Generated at 2022-06-25 13:45:09.884647
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    list_0 = []
    unsafe_proxy_0 = UnsafeProxy()


# Generated at 2022-06-25 13:45:14.245022
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    list_0 = []
    unsafe_proxy_0 = UnsafeProxy()
    str_0 = to_unsafe_text('')

    assert str(type(unsafe_proxy_0.__new__(UnsafeProxy))) == "<type 'UnsafeProxy'>"



# Generated at 2022-06-25 13:45:24.569279
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.six import ensures_str
    # Test-0
    assert type(wrap_var(u'string_0')) == AnsibleUnsafeText
    # Test-1
    assert type(wrap_var(u'unicode_0')) == AnsibleUnsafeText
    # Test-2
    assert type(wrap_var(123)) == int
    # Test-3
    assert type(wrap_var(list())) == list
    # Test-4
    assert type(wrap_var(tuple())) == tuple
    # Test-5
    assert type(wrap_var(set())) == set
    #

# Generated at 2022-06-25 13:45:28.422234
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    val_0 = {}
    UnsafeProxy_inst_0 = UnsafeProxy(val_0)
    ret_0 = isinstance(UnsafeProxy_inst_0, AnsibleUnsafeBytes)
    assert ret_0 and (ret_0 is True)

# Generated at 2022-06-25 13:45:39.724660
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = {}
    var_1 = set("")
    var_2 = set("")
    var_3 = {}
    var_4 = tuple("")
    var_5 = "abcd"
    var_6 = set("")
    var_7 = "abcd"
    var_8 = "abcd"
    var_9 = {}
    var_10 = {}
    var_11 = set("")
    var_12 = "abcd"
    var_13 = {}
    var_14 = "abcd"
    var_15 = {}
    var_16 = tuple("")
    var_17 = tuple("")
    var_18 = {}
    var_19 = tuple("")
    var_20 = "abcd"
    var_21 = {}
    var_22 = set("")
    var

# Generated at 2022-06-25 13:45:51.526667
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

    var_1 = ['one', 'two', 'three']
    var_2 = {'one': 1, 'two': 2}
    var_3 = ['a', var_1, var_2]
    var_4 = ['1', '2', '3']
    var_5 = ['a', var_4, var_2]
    var_6 = u'one'
    var_7 = u'two'
    var_8 = u'three'
    var_9 = u'a'
    var_10 = u'1'
    var_11

# Generated at 2022-06-25 13:45:53.324904
# Unit test for function wrap_var
def test_wrap_var():
    assert type(wrap_var(var_0)) == type({})

# Generated at 2022-06-25 13:46:00.953108
# Unit test for function wrap_var
def test_wrap_var():
    assert_equal(wrap_var(var_0), var_0)
    assert_equal(wrap_var(var_1), var_1)
    assert_equal(wrap_var(var_2), var_2)
    assert_equal(wrap_var(var_3), var_3)
    assert_equal(wrap_var(var_4), var_4)
    assert_equal(wrap_var(var_5), var_5)
    assert_not_equal(wrap_var(var_6), var_6)
    assert_equal(wrap_var(var_7), var_7)
    assert_not_equal(wrap_var(var_8), var_8)
    assert_equal(wrap_var(var_9), var_9)

# Generated at 2022-06-25 13:46:10.843907
# Unit test for function wrap_var
def test_wrap_var():
    import ansible.module_utils.common.collections as collections
    from ansible.module_utils.pycompat24 import get_exception
    import ansible.module_utils.six as six

    # Get the type of 'var_0'
    # var_0 = {}
    var_0 = {}

    # Wrap the type of var_0 and ensure it is safe
    var_0 = wrap_var(var_0)

    # Get the type of 'var_1'
    # var_1 = 'this is unicode text'
    var_1 = 'this is unicode text'

    # Wrap the type of var_1 and ensure it is safe
    var_1 = wrap_var(var_1)

    # Get the type of 'var_2'
    # var_2 = b'this is a binary string'


# Generated at 2022-06-25 13:46:13.140386
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = wrap_var(test_case_0())

    assert(str(type(var_0)).find("AnsibleUnsafe") > 0)


if __name__ == "__main__":
    test_wrap_var()

# Generated at 2022-06-25 13:46:20.453350
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = {}
    
    res_0 = wrap_var(var_0)
    assert res_0 == '{}'
    assert isinstance(res_0, dict)

    var_1 = _wrap_set(set())
    assert var_1 == {}
    assert isinstance(var_1, set)


# Generated at 2022-06-25 13:46:24.085852
# Unit test for function wrap_var
def test_wrap_var():
    # For example
    if wrap_var(
            var_0) == {} and wrap_var(
                var_0) is not None:  # Changed
        print("Passed test")
    else:
        print("Failed test")

# Call function wrap_var
test_wrap_var()

# Generated at 2022-06-25 13:46:26.528789
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = {}
    var_0 = wrap_var(var_0)


if __name__ == '__main__':
    test_case_0()
    test_wrap_var()

# Generated at 2022-06-25 13:46:28.978563
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = {}
    _wrap_dict(var_0)
    var_1 = {}
    _wrap_dict(var_1)
    var_2 = {}
    _wrap_dict(var_2)

# Generated at 2022-06-25 13:46:32.770839
# Unit test for function wrap_var
def test_wrap_var():
    # Prepare test data
    passed_argument_0 = {}

    # Test code
    test_func_0 = wrap_var(passed_argument_0)

    assert passed_argument_0 == {}
    assert test_func_0 == {}


# Generated at 2022-06-25 13:46:42.991095
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = {}
    assert wrap_var(var_0) == {}

    # Test with a tuple
    var_1 = (1, 2, 3, 4, 5)
    assert wrap_var(var_1) == (1, 2, 3, 4, 5)

    # Test with a NativeJinjaText
    var_2 = NativeJinjaText(u"Hello World")
    assert wrap_var(var_2) == u"Hello World"

    # Test with a string
    var_3 = "foo"
    assert wrap_var(var_3) == "foo"

    # Test with a set
    var_4 = set([1, 2, 3])
    assert wrap_var(var_4) == {1, 2, 3}

    # Test with a list

# Generated at 2022-06-25 13:46:45.733501
# Unit test for function wrap_var
def test_wrap_var():
    assert type(wrap_var(var_0)) == dict, "wrap_var function failed to return correct data type"
    assert wrap_var(var_0) == {}, "wrap_var function failed to return correct output"


# Generated at 2022-06-25 13:46:47.057217
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = {}
    var_1 = var_0
    assert var_1 == {}


# Generated at 2022-06-25 13:46:48.030002
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(var_0) is not False



# Generated at 2022-06-25 13:46:51.537029
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = {}
    var_0 = wrap_var(var_0)
    assert var_0 == {}

if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-25 13:46:53.631244
# Unit test for function wrap_var
def test_wrap_var():
    # Output all values
    test_case_0()

# Boilerplate function to run all of the tests

# Generated at 2022-06-25 13:46:56.440976
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = {}

    # Call function
    wrapped = wrap_var(var_0)

    # Check Results
    assert wrapped == {}



# Generated at 2022-06-25 13:46:58.544185
# Unit test for function wrap_var
def test_wrap_var():
    print('Test wrap_var')
    assert wrap_var(var_0) == {}, 'Variable var_0 is not a dictionary'


# Generated at 2022-06-25 13:47:02.041072
# Unit test for function wrap_var
def test_wrap_var():
    var_0 = {}
    test_case = var_0
    if (test_case == var_0):
        var_1 = wrap_var(test_case)
        print(var_1)
    else:
        print('Empty test case')
