

# Generated at 2022-06-25 13:44:42.195937
# Unit test for function wrap_var
def test_wrap_var():
    assert True


# Generated at 2022-06-25 13:44:49.841568
# Unit test for method __new__ of class UnsafeProxy

# Generated at 2022-06-25 13:44:53.355805
# Unit test for function wrap_var
def test_wrap_var():
    ansible_unsafe_text_0 = AnsibleUnsafeText()
    test_result = wrap_var(ansible_unsafe_text_0)
    assert test_result == ansible_unsafe_text_0
    test_result = wrap_var("Hello World")
    assert test_result == "Hello World"


# Generated at 2022-06-25 13:44:57.532314
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    ansible_unsafe_bytes_0 = AnsibleUnsafeBytes()
    ansible_unsafe_bytes_1 = AnsibleUnsafeBytes()

    result = UnsafeProxy(ansible_unsafe_bytes_0)
    assert result == ansible_unsafe_bytes_0, "The result should be the same reference as ansible_unsafe_bytes_0"

    result = UnsafeProxy(ansible_unsafe_bytes_1)
    assert result == ansible_unsafe_bytes_1, "The result should be the same reference as ansible_unsafe_bytes_1"

# Generated at 2022-06-25 13:45:07.736590
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(text_type('foo')) == AnsibleUnsafeText(text_type('foo'))
    assert wrap_var(text_type('foo'.encode('utf8'))) == AnsibleUnsafeText(text_type('foo'))
    assert wrap_var(binary_type('foo')) == AnsibleUnsafeBytes(binary_type('foo'))
    assert wrap_var(binary_type('foo'.encode('utf8'))) == AnsibleUnsafeBytes(binary_type('foo'))
    assert wrap_var(None) is None
    assert wrap_var(dict(foo='bar')) == dict(foo=AnsibleUnsafeText(text_type('bar')))

# Generated at 2022-06-25 13:45:12.214631
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    ansible_unsafe_bytes_0 = AnsibleUnsafeBytes()
    # UnsafeProxy.__new__(<class UnsafeProxy>, str(ansible_unsafe_bytes_0))
    UnsafeProxy.__new__(UnsafeProxy, str(ansible_unsafe_bytes_0))


# Generated at 2022-06-25 13:45:14.189457
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(['foo', 'bar', 'baz']) == ['foo', 'bar', 'baz']

# Generated at 2022-06-25 13:45:24.489775
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    ansible_unsafe_bytes_0 = AnsibleUnsafeBytes()
    assert UnsafeProxy(ansible_unsafe_bytes_0).__class__ is AnsibleUnsafeBytes
    ansible_unsafe_text_0 = AnsibleUnsafeText()
    assert UnsafeProxy(ansible_unsafe_text_0).__class__ is AnsibleUnsafeText

    class Foo: pass
    foo_0 = Foo()
    assert UnsafeProxy(foo_0).__class__ is Foo

    # Tests if a string can be converted to an unsafe string
    unsafe_str_0 = UnsafeProxy('test string')
    assert unsafe_str_0.__class__ is AnsibleUnsafeText

    class FooUnsafe(AnsibleUnsafe): pass
    assert UnsafeProxy(FooUnsafe()).__class__ is FooUnsafe

# Generated at 2022-06-25 13:45:31.083799
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    proxy_0 = UnsafeProxy()
    ansible_unsafe_bytes_0 = proxy_0.AnsibleUnsafeBytes()
    ansible_unsafe_text_0 = proxy_0.AnsibleUnsafeText()
    ansible_unsafe_text_1 = ansible_unsafe_text_0.decode()
    ansible_unsafe_bytes_1 = ansible_unsafe_bytes_0.encode()


# Generated at 2022-06-25 13:45:32.435414
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    pass



# Generated at 2022-06-25 13:45:45.273091
# Unit test for function wrap_var
def test_wrap_var():
    cases = [
        { 'wrapping_type': None,     'native_type': type(None)                 },
        { 'wrapping_type': AnsibleUnsafeBytes,  'native_type': text_type      },
        { 'wrapping_type': AnsibleUnsafeText,   'native_type': binary_type    },
        { 'wrapping_type': AnsibleUnsafeText,   'native_type': text_type      },
        { 'wrapping_type': NativeJinjaUnsafeText,'native_type': NativeJinjaText },
    ]

    for case in cases:
        wrapping_type = case['wrapping_type']
        native_type = case['native_type']

        # Instanciate a native type
        obj = native_type()

        wrapped_obj = wrap_var(obj)
       

# Generated at 2022-06-25 13:45:55.766910
# Unit test for function wrap_var
def test_wrap_var():
    # Test for boolean
    test_var = True
    result = wrap_var(test_var)
    assert type(result) == bool
    assert result == True
    test_var = False
    result = wrap_var(test_var)
    assert type(result) == bool
    assert result == False

    # Test for number
    test_var = 1
    result = wrap_var(test_var)
    assert type(result) == int
    assert result == 1
    test_var = 1.0
    result = wrap_var(test_var)
    assert type(result) == float
    assert result == 1.0

    # Test for text
    test_var = "hello world"
    result = wrap_var(test_var)
    assert type(result) == AnsibleUnsafeText

# Generated at 2022-06-25 13:46:02.488531
# Unit test for function wrap_var
def test_wrap_var():
    test_dict = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': {'key4': 'value4'},
        'key5': ['list_item1', 'list_item2'],
        'key6': ('tuple_item1', 'tuple_item2')
    }
    assert wrap_var(test_dict)['key3']['key4'] == 'value4'
    assert wrap_var(test_dict)['key5'][1] == 'list_item2'
    assert wrap_var(test_dict)['key6'][1] == 'tuple_item2'

    test_set = set(['set_item1', 'set_item2'])
    assert wrap_var(test_set) == test_set

# Generated at 2022-06-25 13:46:06.648512
# Unit test for function wrap_var
def test_wrap_var():
    print(wrap_var(dict()))
    print(wrap_var(set()))
    print(wrap_var([1,2,3]))
    print(wrap_var(NativeJinjaText()))
    print(wrap_var(AnsibleUnsafeText()))



# Generated at 2022-06-25 13:46:07.565245
# Unit test for function wrap_var
def test_wrap_var():
    test_case_0()

# Generated at 2022-06-25 13:46:14.891341
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    Display().deprecated(
        'wrap_var is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )

    ansible_unsafe_text_0 = AnsibleUnsafeText()
    var_0 = wrap_var(ansible_unsafe_text_0)
    assert type(var_0) == AnsibleUnsafeText, "wrap_var(): missed"
    ansible_unsafe_bytes_0 = AnsibleUnsafeBytes()
    var_1 = wrap_var(ansible_unsafe_bytes_0)
    assert type(var_1) == AnsibleUnsafeBytes, "wrap_var(): missed"
    native_jinja_unsafe

# Generated at 2022-06-25 13:46:19.802061
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(1) == 1
    assert wrap_var(u'foobar\u1234') == u'foobar\u1234'
    assert wrap_var(b'foobar') == b'foobar'
    assert isinstance(wrap_var(u'foobar\u1234'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foobar'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(AnsibleUnsafeText(u'foobar\u1234')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'foobar')), AnsibleUnsafeBytes)
    assert wrap_var([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-25 13:46:28.177942
# Unit test for function wrap_var
def test_wrap_var():
    # These examples were copied from the docs.
    ret = wrap_var(u'This is a test')
    assert isinstance(ret, AnsibleUnsafeText)
    assert isinstance(ret, str)

    ret = wrap_var(u'This is a test'.encode(u'utf-8'))
    assert isinstance(ret, AnsibleUnsafeBytes)
    assert isinstance(ret, bytes)

    ret = wrap_var(u'This is a test'.encode(u'utf-8').decode(u'utf-8'))
    assert isinstance(ret, AnsibleUnsafeText)
    assert isinstance(ret, str)

    ret = wrap_var(u'This is a test'.encode(u'utf-8').decode(u'utf-8').encode(u'utf-8'))

# Generated at 2022-06-25 13:46:36.060423
# Unit test for function wrap_var
def test_wrap_var():
    v = {'a': 2, 'b': 3}
    _wrap_dict(v)
    # FIX Bug#31897: wrap_var should not return a dict
    assert isinstance(v, dict)

    v = [1, 2, 3]
    v_type = type(v)
    _wrap_sequence(v)
    # FIX Bug#31897: wrap_var should not return a list
    assert isinstance(v, v_type)

    v = (1, 2, 3)
    v_type = type(v)
    _wrap_sequence(v)
    # FIX Bug#31897: wrap_var should not return a tuple
    assert isinstance(v, v_type)

    v = set([1, 2, 3])
    v_type = type(v)
    _wrap_set(v)

# Generated at 2022-06-25 13:46:37.329028
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('') == AnsibleUnsafeText('')