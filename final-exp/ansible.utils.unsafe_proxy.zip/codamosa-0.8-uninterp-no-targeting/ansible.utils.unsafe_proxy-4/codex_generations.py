

# Generated at 2022-06-21 09:06:27.546930
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    import unittest

    class TestAnsibleUnsafeBytesDecode(unittest.TestCase):
        def test_single_line_decode(self):
            b = to_unsafe_bytes('This is a test')
            b_decoded = b.decode('utf-8')
            self.assertTrue(isinstance(b_decoded, AnsibleUnsafeText))
            self.assertEqual(b_decoded, to_unsafe_text('This is a test'))

    unittest.main(exit=False)      # Stop after tests


# Generated at 2022-06-21 09:06:31.344345
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    jt = NativeJinjaUnsafeText("{{a+1}}")
    # We should be able to call `from_string` on data of type NativeJinjaUnsafeText
    env = jt.from_string()
    assert env.globals.get("a") is not None

# Generated at 2022-06-21 09:06:37.247305
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    t_str = "hello world"
    t_obj = AnsibleUnsafeText(t_str)
    t_bad_type = 3
    assert(isinstance(t_obj, text_type))
    assert(t_obj == t_str)
    try:
        AnsibleUnsafeText(t_bad_type)
    except TypeError:
        assert(True)
    except Exception:
        assert(False)

# Generated at 2022-06-21 09:06:48.518660
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    import pytest
    from ansible.module_utils.six import text_type, binary_type
    from ansible.module_utils.six import PY3

    validate_str = 'foo'

    assert UnsafeProxy(validate_str) == validate_str
    assert type(UnsafeProxy(validate_str)) is text_type

    if PY3:
        assert type(UnsafeProxy(binary_type(validate_str, encoding='utf-8'))) is binary_type
    else:
        assert type(UnsafeProxy(binary_type(validate_str, encoding='utf-8'))) is text_type

    with pytest.raises(TypeError) as exp:
        UnsafeProxy(None)
    assert "expected string or bytes-like object" in text_type(exp.value)



# Unit

# Generated at 2022-06-21 09:06:59.460606
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    import unittest
    test_cases = [
        ('hello', AnsibleUnsafeText),
        ('hello', ('hello', AnsibleUnsafeText)),
        (b'hello', AnsibleUnsafeBytes),
        (b'hello', (b'hello', AnsibleUnsafeBytes)),
    ]

# Generated at 2022-06-21 09:07:03.554724
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    result = to_unsafe_text(None)
    assert result is None

    result = to_unsafe_text('test')
    assert isinstance(result, AnsibleUnsafeText)



# Generated at 2022-06-21 09:07:08.791534
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    ansible_unsafe_bytes = AnsibleUnsafeBytes('Hello World!'.encode())
    ansible_unsafe_text = ansible_unsafe_bytes.decode()
    assert isinstance(ansible_unsafe_text, AnsibleUnsafeText)
    assert not isinstance(ansible_unsafe_text, AnsibleUnsafeBytes)
    assert not isinstance(ansible_unsafe_text, binary_type)
    assert isinstance(ansible_unsafe_text, text_type)
    assert str(ansible_unsafe_text) == 'Hello World!'


# Generated at 2022-06-21 09:07:12.001283
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    _test = AnsibleUnsafeText('test')
    assert _test.encode('utf-8') == 'test'
    assert _test.__UNSAFE__


# Generated at 2022-06-21 09:07:15.920336
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    text = u'Unicode string'
    byte_version = AnsibleUnsafeBytes(text.encode('utf-8'))
    assert isinstance(byte_version.decode(), AnsibleUnsafeText)



# Generated at 2022-06-21 09:07:18.835107
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    text = to_unsafe_bytes(b'hello world!')
    assert isinstance(text, AnsibleUnsafeBytes)
    assert isinstance(text.decode(), AnsibleUnsafeText)



# Generated at 2022-06-21 09:07:21.388884
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text("bar"), text_type)
    assert type(AnsibleUnsafeText("foo")) == type(to_unsafe_text("bar"))

# Generated at 2022-06-21 09:07:34.055601
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy(None), type(None))
    assert isinstance(UnsafeProxy(1), int)
    assert isinstance(UnsafeProxy(1.1), float)
    assert isinstance(UnsafeProxy({}), dict)
    assert isinstance(UnsafeProxy([]), list)
    assert isinstance(UnsafeProxy(()), tuple)
    assert isinstance(UnsafeProxy(set()), set)
    assert isinstance(UnsafeProxy('string'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'bytes'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(to_text(b'unicode')), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(to_bytes(u'unicode')), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:07:36.469853
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert type(AnsibleUnsafeBytes(b'Test')) == AnsibleUnsafeBytes


# Generated at 2022-06-21 09:07:48.114339
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    from ansible.module_utils.common._collections_compat import Sequence
    assert isinstance(AnsibleUnsafeText('foo').encode('utf-8'), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeBytes(b'foo').decode('utf-8'), AnsibleUnsafeText)
    assert not isinstance(wrap_var(b'foo').decode('utf-8'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'foo').decode('utf-8'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo').decode('utf-8').encode('utf-8'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo').encode('utf-8').decode('utf-8'), AnsibleUnsafeText)

# Generated at 2022-06-21 09:07:53.180721
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    utf8_bytes = to_bytes('\xe9')
    wrapped_bytes = to_unsafe_text(utf8_bytes)
    assert isinstance(wrapped_bytes, AnsibleUnsafeText)
    assert isinstance(wrapped_bytes, text_type)
    assert wrapped_bytes == utf8_bytes.decode()

# Generated at 2022-06-21 09:07:56.977122
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    new_str = "foobar"
    new_str_as_text = to_text(new_str)
    assert isinstance(new_str_as_text, AnsibleUnsafeText)
    assert str(new_str_as_text) == new_str

# Generated at 2022-06-21 09:07:59.672194
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    try:
        s = AnsibleUnsafeText('hello')
        assert s == 'hello'
        assert isinstance(s, AnsibleUnsafeText)
    except:
        print('test_AnsibleUnsafeText() failed!')


# Generated at 2022-06-21 09:08:03.431090
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    text = u'unic\xf8de'
    result = AnsibleUnsafeText(text).encode('ascii', 'ignore')
    assert isinstance(result, AnsibleUnsafeBytes)
    assert result == text.encode('ascii', 'ignore')


# Generated at 2022-06-21 09:08:12.687820
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import string_types

    class Foo(object):
        pass

    assert isinstance(UnsafeProxy('foo'), string_types)
    assert isinstance(UnsafeProxy(u'foo'), string_types)
    assert isinstance(UnsafeProxy(b'foo'), string_types)
    assert isinstance(UnsafeProxy(1.0), float)
    assert isinstance(UnsafeProxy([1, 2, 3]), list)
    assert isinstance(UnsafeProxy((1, 2, 3)), tuple)
    assert isinstance(UnsafeProxy({'a': '1'}), dict)
    assert isinstance(UnsafeProxy(Foo()), Foo)
    assert isinstance(UnsafeProxy(None), type(None))



# Generated at 2022-06-21 09:08:17.736388
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    us = AnsibleUnsafeBytes(to_bytes('some string'))
    assert isinstance(us.decode(), AnsibleUnsafeText)


# Generated at 2022-06-21 09:08:27.670823
# Unit test for function wrap_var
def test_wrap_var():
    import pytest

    # Test to ensure that wrap_var actually wraps a string, instead of just returning it
    assert isinstance(wrap_var("test"), AnsibleUnsafeText)
    assert isinstance(wrap_var(None), type(None))

    # Test to ensure that wrap_var will not wrap a class that is already flagged as AnsibleUnsafe
    assert isinstance(wrap_var(AnsibleUnsafeText("test")), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes("test")), AnsibleUnsafeBytes)

    # Test to ensure that wrap_var will wrap all items in a dictionary
    test_dict = {
        "key1": "val1",
        "key2": "val2"
    }

# Generated at 2022-06-21 09:08:32.301482
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert(isinstance(AnsibleUnsafeBytes(b'abc'), AnsibleUnsafeBytes))
    assert(type(AnsibleUnsafeBytes(b'abc')) is AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:08:33.767180
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert str(UnsafeProxy(1)) == '1'



# Generated at 2022-06-21 09:08:41.602501
# Unit test for method decode of class AnsibleUnsafeBytes

# Generated at 2022-06-21 09:08:53.378396
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    import sys

    if sys.version_info < (3, 0):
        from ansible.module_utils.six import PY3
        assert not PY3
        assert isinstance(to_unsafe_bytes('a string'), AnsibleUnsafeText)
        assert not isinstance(to_unsafe_bytes('a string'), AnsibleUnsafeBytes)

        assert isinstance(to_unsafe_bytes(u'a unicode string'), AnsibleUnsafeText)
        assert not isinstance(to_unsafe_bytes(u'a unicode string'), AnsibleUnsafeBytes)

        assert isinstance(to_unsafe_bytes('a string', encoding='ascii'), AnsibleUnsafeBytes)
        assert not isinstance(to_unsafe_bytes('a string', encoding='ascii'), AnsibleUnsafeText)

        assert isinstance

# Generated at 2022-06-21 09:08:59.198189
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    text_obj = 'some_string'
    unsafe_obj = AnsibleUnsafeText(text_obj)
    bytes_obj = b'some_string'
    unsafe_bytes = unsafe_obj.encode()
    assert unsafe_bytes == bytes_obj
    assert isinstance(unsafe_bytes, AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:09:01.185641
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes("foo"), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:09:10.428138
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    import pytest
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import u, PY3

    assert UnsafeProxy(u('')) is None
    assert isinstance(UnsafeProxy(u('text')), text_type)
    assert isinstance(UnsafeProxy(u('text')), AnsibleUnsafe)
    assert isinstance(UnsafeProxy(u(r'\\')), text_type)
    assert isinstance(UnsafeProxy(u(r'\\')), AnsibleUnsafe)
    assert isinstance(UnsafeProxy(u('')), text_type)
    assert isinstance(UnsafeProxy(u('')), AnsibleUnsafe)
    assert UnsafeProxy(u('text')).__UNSAFE__ is True

# Generated at 2022-06-21 09:09:23.119813
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    import unittest

    try:
        from ansible.utils.display import Display
        display = Display()
    except ImportError:
        class Display:
            def deprecated(self): pass
        display = Display()

    class UnsafeProxyTest(unittest.TestCase):

        def test___new__(self):
            # __new__() is defined in other modules, but we want to unit test it
            from ansible.utils.unsafe_proxy import UnsafeProxy
            self.assertEqual('abc', UnsafeProxy('abc'))
            self.assertIsInstance('abc', AnsibleUnsafeText)
            self.assertIsInstance(UnsafeProxy('abc'), AnsibleUnsafeText)
            self.assertIsInstance(UnsafeProxy(wrap_var('abc')), AnsibleUnsafeText)


# Generated at 2022-06-21 09:09:24.954936
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(
        AnsibleUnsafeBytes('ansible').decode('utf-8'),
        AnsibleUnsafeText
    )


# Generated at 2022-06-21 09:09:31.846278
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    bytes_val = to_unsafe_bytes('This is a string')
    ans_bytes = AnsibleUnsafeBytes(bytes_val)
    assert ans_bytes == bytes_val
    assert type(ans_bytes) == AnsibleUnsafeBytes
    assert isinstance(ans_bytes, binary_type)



# Generated at 2022-06-21 09:09:40.801790
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # Constructor without argument
    unsafe_bytes = AnsibleUnsafeBytes()
    if unsafe_bytes:
         raise Exception('AnsibleUnsafeBytes should be empty string')

    # Constructor with one argument
    unsafe_bytes = AnsibleUnsafeBytes('Hello World')
    if unsafe_bytes != 'Hello World':
         raise Exception('AnsibleUnsafeBytes constructor failed')

    # Constructor with multiple arguments
    try:
        unsafe_bytes = AnsibleUnsafeBytes('Hello', ' ', 'World')
        raise Exception('AnsibleUnsafeBytes constructor with multiple arguments should fail')
    except TypeError:
        pass


# Generated at 2022-06-21 09:09:45.574406
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    t = ansible_unsafe_bytes("hello")
    assert(t.__UNSAFE__)
    assert(t == b"hello")
    assert(isinstance(t, AnsibleUnsafeBytes))


# Generated at 2022-06-21 09:09:58.243564
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text('foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'foo'.encode('utf-8')), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(42), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text([u'foo', u'bar']), list)
    assert isinstance(to_unsafe_text([u'foo', u'bar'])[0], AnsibleUnsafeText)
    assert isinstance(to_unsafe_text({u'foo': u'bar'}), dict)


# Generated at 2022-06-21 09:10:00.897269
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    bstring = b'\xc3\xbcnic\xc3\xb8de'
    value1 = AnsibleUnsafeBytes(bstring)
    value2 = AnsibleUnsafeBytes(bstring.decode('utf-8'))
    assert value1.decode() == value2

# Generated at 2022-06-21 09:10:10.113324
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    """
    Tests the AnsibleUnsafe constructor.
    """
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import NativeJinjaUnsafeText

    test_unicode = u"Test unicode"
    test_byte = b"Test byte"
    test_jinja = AnsibleUnsafeText(u"Test jinja")

    # Testing native types.
    assert AnsibleUnsafe(u"Test unicode") is test_unicode
    assert AnsibleUnsafe(b"Test byte") is test_byte

    # Testing AnsibleUnsafe types.

# Generated at 2022-06-21 09:10:22.669418
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(None), type(None))
    assert isinstance(to_unsafe_text(''), str)
    assert isinstance(to_unsafe_text('', encoding='ascii'), str)
    assert isinstance(to_unsafe_text(u'', encoding='ascii'), str)
    assert isinstance(to_unsafe_text(None, encoding='ascii'), type(None))
    assert isinstance(to_unsafe_text('', errors='surrogate_or_strict'), str)
    assert isinstance(to_unsafe_text(b'', errors='surrogate_or_strict'), str)
    assert isinstance(to_unsafe_text(u'', errors='surrogate_or_strict'), str)

# Generated at 2022-06-21 09:10:29.155430
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    # Test string
    test_str = u"python ansible-mock"
    # Test bytes without encoding
    test_bytes = AnsibleUnsafeBytes(test_str)
    assert isinstance(test_bytes, AnsibleUnsafeBytes)
    # Test bytes with encoding
    test_bytes = AnsibleUnsafeBytes(test_str, 'utf-8')
    assert isinstance(test_bytes, AnsibleUnsafeBytes)
    # Test encode bytes and decode bytes
    assert test_bytes.decode('utf-8') == test_str
    assert test_bytes.encode('utf-8') == test_str.encode('utf-8')

# Generated at 2022-06-21 09:10:32.278507
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    unsafe_bytes = AnsibleUnsafeBytes('foo'.encode('utf-8'))
    assert unsafe_bytes.decode('utf-8') == 'foo'

# Generated at 2022-06-21 09:10:38.897138
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var("foo") == wrap_var("foo")
    assert wrap_var("foo") == AnsibleUnsafeText(u"foo")
    assert wrap_var("foo") != "foo"
    assert wrap_var(None) == None
    assert wrap_var("foo") != AnsibleUnsafeText(u"bar")
    assert wrap_var(None) == AnsibleUnsafeText(u"bar")

# Generated at 2022-06-21 09:10:45.085221
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # Test success
    value = "it's ok"
    assert type(value) == str
    result = AnsibleUnsafeBytes(value)
    assert type(result) == AnsibleUnsafeBytes

    # Test failure
    result = AnsibleUnsafeBytes(1)
    assert type(result) == AnsibleUnsafeBytes



# Generated at 2022-06-21 09:10:47.233596
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:10:55.469723
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    import re
    test1 = NativeJinjaUnsafeText("Hello")
    assert test1 == "Hello"
    assert isinstance(test1, NativeJinjaUnsafeText)
    assert isinstance(test1, AnsibleUnsafeText)
    assert isinstance(test1, text_type)
    assert not isinstance(test1, NativeJinjaText)
    assert not isinstance(test1, text_type)
    assert re.sub(r'[aeiou]', 'X', test1) == "HXllo"



# Generated at 2022-06-21 09:11:03.308211
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    """
    Test __new__ method of UnsafeProxy
    """
    from ansible.module_utils.six import PY3

    if PY3:
        # Python 3
        assert wrap_var(b'foo') == b'foo'
        assert wrap_var(u'foo') == u'foo'
    else:
        # Python 2
        assert wrap_var(b'foo') == 'foo'
        assert wrap_var(u'foo') == u'foo'


# Generated at 2022-06-21 09:11:08.113244
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy('abcd'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'abcd'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText('abcd')), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes(b'abcd')), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:11:16.195980
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text('a'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'a'), AnsibleUnsafeText)

    # Test that the function handles various types
    from ansible.utils.display import Display
    from datetime import datetime

    things = [
        42,
        42.5,
        datetime.utcnow(),
        Display(),
    ]

    for thing in things:
        assert to_unsafe_text(thing) == to_text(thing)

# Generated at 2022-06-21 09:11:26.632005
# Unit test for function wrap_var
def test_wrap_var():
    import unittest
    DictType = type({})
    UnsafeBytes = AnsibleUnsafeBytes
    UnsafeText = AnsibleUnsafeText

    class WrapVarTest(unittest.TestCase):
        def _check(self, val, expected):
            self.assertEqual(wrap_var(val), expected)
            self.assertEqual(type(wrap_var(val)), type(expected))

        def test_wrap_none(self):
            self._check(None, None)

        def test_wrap_unsafe(self):
            self._check(UnsafeBytes('asdf'), UnsafeBytes('asdf'))
            self._check(UnsafeText('asdf'), UnsafeText('asdf'))

# Generated at 2022-06-21 09:11:34.093460
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.utils.display import Display
    display = Display()
    display.deprecated(
        'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )
    assert UnsafeProxy('test').__class__.__name__ == 'AnsibleUnsafeText'
    assert UnsafeProxy(None) is None
    a_str = to_text('This is a str')
    assert UnsafeProxy(a_str) is a_str

# Generated at 2022-06-21 09:11:41.580879
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    import decimal

    # Create a list of test cases for each type of object
    # (input, expected output)
    test_cases = []
    test_cases.append(({}, {}))
    test_cases.append(({u'a': u'b', u'c': u'd'}, {u'a': u'b', u'c': u'd'}))
    test_cases.append(({u'e': ({u'f': u'g', u'h': u'i'}), u'j': u'k'}, {u'e': ({u'f': u'g', u'h': u'i'}), u'j': u'k'}))
    test_cases.append(([], []))

# Generated at 2022-06-21 09:11:44.178470
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # Constructor
    assert isinstance(AnsibleUnsafeBytes(b'foo'), AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:11:52.957673
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    s = UnsafeProxy("s")
    assert type(s) is AnsibleUnsafeText
    assert s == "s"

    s = UnsafeProxy(b"s")
    assert type(s) is AnsibleUnsafeBytes
    assert s == b"s"

    s = UnsafeProxy(b"\xc3\xb1")
    assert type(s) is AnsibleUnsafeBytes
    assert s == b"\xc3\xb1"
    assert s.decode("utf-8") == u"\xf1"
    assert type(s.decode("utf-8")) is AnsibleUnsafeText

    s = UnsafeProxy(u"\xf1")
    assert type(s) is AnsibleUnsafeText
    assert s == u"\xf1"
    assert s.encode("utf-8") == b

# Generated at 2022-06-21 09:11:54.532252
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # Constructor of class AnsibleUnsafeBytes should return a AnsibleUnsafeBytes object
    assert isinstance(AnsibleUnsafeBytes(b'binary string'), AnsibleUnsafeBytes) is True


# Generated at 2022-06-21 09:11:55.521161
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    pass

# Generated at 2022-06-21 09:11:58.847716
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes('unsafe_bytes').decode(), AnsibleUnsafeText)



# Generated at 2022-06-21 09:12:11.341587
# Unit test for function wrap_var
def test_wrap_var():
    import unittest
    import inspect
    import types

    class TestWrapVar(unittest.TestCase):
        """
        Unit test for the function wrap_var
        """

        def test_wrap_var_return(self):
            """
            Tests the return types of wrap_var for all primitive types
            """
            self.assertIsInstance(wrap_var(0), int)
            self.assertIsInstance(wrap_var(0.0), float)
            self.assertIsInstance(wrap_var(True), bool)
            self.assertIsInstance(wrap_var("hello world"), AnsibleUnsafeText)
            self.assertIsInstance(wrap_var(b"hello world"), AnsibleUnsafeBytes)
            self.assertIsInstance(wrap_var({"foo": "bar"}), dict)
            self.assertIsInstance

# Generated at 2022-06-21 09:12:13.377623
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    '''Check if UnsafeProxy' constructor with string argument works fine'''
    assert isinstance(UnsafeProxy('foo'), AnsibleUnsafeText)



# Generated at 2022-06-21 09:12:17.446159
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    ansible_unsafe = AnsibleUnsafe()
    assert (ansible_unsafe.__UNSAFE__ == True)


# Generated at 2022-06-21 09:12:20.476528
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # Test that decode method returns AnsibleUnsafeText instance
    assert isinstance(AnsibleUnsafeBytes(b'foo').decode(), AnsibleUnsafeText)



# Generated at 2022-06-21 09:12:32.642123
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    from ansible.module_utils.six import PY3
    if PY3:
        unsafe_s = AnsibleUnsafeBytes(b"\x80".decode("utf-8", "surrogatepass"))
        assert isinstance(unsafe_s, AnsibleUnsafeBytes)
        unsafe_s_decoded = unsafe_s.decode("utf-8", "surrogatepass")
        assert isinstance(unsafe_s_decoded, AnsibleUnsafeText)
        unsafe_s_decoded_encoded = unsafe_s_decoded.encode("utf-8")
        assert isinstance(unsafe_s_decoded_encoded, AnsibleUnsafeBytes)
        assert unsafe_s_decoded_encoded == unsafe_s

# Generated at 2022-06-21 09:12:41.540694
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    try:
        NativeJinjaUnsafeText()
    except:
        assert False, "No args constructor of class NativeJinjaUnsafeText throws exception"

    try:
        NativeJinjaUnsafeText('hello')
    except:
        assert False, "Single argument constructor of class NativeJinjaUnsafeText throws exception"

    try:
        NativeJinjaUnsafeText(1)
    except:
        assert False, "Single argument constructor of class NativeJinjaUnsafeText throws exception"

    try:
        NativeJinjaUnsafeText([])
    except:
        assert False, "Single argument constructor of class NativeJinjaUnsafeText throws exception"


# Generated at 2022-06-21 09:12:46.365059
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(u"string"), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u"string".encode('utf-8')), AnsibleUnsafeText)


# Generated at 2022-06-21 09:12:52.938759
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    test_string = "hello world"
    test_string_ascii = b"hello world"
    assert isinstance(AnsibleUnsafeText(test_string).encode('ascii'), AnsibleUnsafeBytes)
    assert AnsibleUnsafeText(test_string).encode('ascii') == AnsibleUnsafeBytes(test_string_ascii)


# Generated at 2022-06-21 09:13:02.755520
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six.moves import builtins
    # TODO: test wrap_var(None)
    # TODO: test wrap_var(ansible_unsafe_object)
    # TODO: test wrap_var(text_type)
    # TODO: test wrap_var(binary_type)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'123'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'123'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(123), int)
    assert isinstance(wrap_var(1.2), float)

# Generated at 2022-06-21 09:13:04.890660
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert AnsibleUnsafeBytes("abc").decode("utf-8") == AnsibleUnsafeText("abc")

# Generated at 2022-06-21 09:13:06.989171
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert AnsibleUnsafeBytes(b'123').decode('utf-8') == u'123'


# Generated at 2022-06-21 09:13:08.887441
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    a = AnsibleUnsafe()
    assert a.__UNSAFE__


# Generated at 2022-06-21 09:13:18.421498
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    """
    Test function to_unsafe_text.
    """
    from ansible.utils.display import Display
    Display().deprecated(
        'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    class fake_display(object):
        stdout = StringIO()
        stderr = StringIO()
        deprecation_warnings = 0

    # Test for ascii
    result_text = to_unsafe_text('123456')
    if PY3:
        assert type(result_text) == type('123456')

# Generated at 2022-06-21 09:13:30.317433
# Unit test for function wrap_var
def test_wrap_var():
    # Non-Unsafe strings
    v = "string"
    v_from_func = wrap_var(v)
    assert v == v_from_func
    assert not isinstance(v, AnsibleUnsafe)
    assert isinstance(v_from_func, AnsibleUnsafeText)
    assert v_from_func == "string"

    v = u"Unicode"
    v_from_func = wrap_var(v)
    assert v == v_from_func
    assert not isinstance(v, AnsibleUnsafe)
    assert isinstance(v_from_func, AnsibleUnsafeText)
    assert v_from_func == u"Unicode"

    # Unsafe strings
    v = b"Bytes"
    v_from_func = wrap_var(v)
    assert v == v_from

# Generated at 2022-06-21 09:13:31.528111
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe()


# Generated at 2022-06-21 09:13:39.371878
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # Constructor with bytes
    u = AnsibleUnsafeBytes(b'\xe9')
    # Constructor with int
    u = AnsibleUnsafeBytes(0xe9)
    # Corner case and int overflow
    u = AnsibleUnsafeBytes(-10)
    # Constructor with str
    u = AnsibleUnsafeBytes('toto')

    # Test with constructor of AnsibleUnsafeText
    t = AnsibleUnsafeText(u)
    u = AnsibleUnsafeBytes(t)



# Generated at 2022-06-21 09:13:44.048133
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    ansibleunsafe_bytes = AnsibleUnsafeBytes(b'foo')
    assert isinstance(ansibleunsafe_bytes, binary_type)


# Generated at 2022-06-21 09:13:44.927578
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert(AnsibleUnsafe)



# Generated at 2022-06-21 09:13:46.118799
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert issubclass(AnsibleUnsafeText, AnsibleUnsafe)

# Generated at 2022-06-21 09:13:49.615392
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    if not isinstance(UnsafeProxy(None), type(None)):
        raise AssertionError('UnsafeProxy(None).__class__ is not type(None)')

# Generated at 2022-06-21 09:13:54.283416
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():

    # Call method
    result = UnsafeProxy(u"Üöä")
    # Check result
    assert result == u"Üöä"
    assert result.__class__ == AnsibleUnsafeText
    assert result.__UNSAFE__ is True



# Generated at 2022-06-21 09:14:03.956482
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    a = AnsibleUnsafeText(u"foo")
    assert a == u"foo"
    assert isinstance(a, text_type)
    assert isinstance(a, AnsibleUnsafe)

    # Make sure all methods on native string also exist on AnsibleUnsafeText
    for method in dir(builtins.str):
        b = getattr(a, method)
        assert callable(b)

    # Make sure all of our overridden methods exist on Python 3
    if PY3:
        assert hasattr(a, 'encode')
    else:
        assert not hasattr(a, 'encode')


# Generated at 2022-06-21 09:14:07.905332
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_bytes(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(to_bytes(u'foo'), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:14:15.216583
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    import jinja2
    from ansible.vars.unsafe_proxy import NativeJinjaUnsafeText

    en = jinja2.Environment(extensions=['jinja2.ext.do'])
    t = en.from_string("{{ '1234567890'|do }}")
    assert(isinstance(t.render(), text_type))
    assert(isinstance(t.render(), NativeJinjaUnsafeText))

# Generated at 2022-06-21 09:14:17.354382
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert(type(AnsibleUnsafeBytes(b'hello')) == AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:14:19.590004
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    proxy = AnsibleUnsafeBytes("AnsibleUnsafeBytes(binary_type, AnsibleUnsafe)")



# Generated at 2022-06-21 09:14:31.217620
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    proxy = UnsafeProxy('123')
    assert isinstance(proxy, AnsibleUnsafeText)
    assert(str(proxy) == '123')

    proxy = UnsafeProxy('123'.encode('utf-8'))
    assert isinstance(proxy, AnsibleUnsafeBytes)
    assert(str(proxy) == '123')

    proxy = UnsafeProxy(123)
    assert(isinstance(proxy, int) and (proxy == 123))


# Generated at 2022-06-21 09:14:34.022411
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    if AnsibleUnsafeBytes().__UNSAFE__ == True:
        return True
    else: 
        return False


# Generated at 2022-06-21 09:14:36.772812
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    obj = "abcd"
    result = AnsibleUnsafeText(obj).encode()
    assert(result == b'abcd')


# Generated at 2022-06-21 09:14:46.108032
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    def test_helper(cls, obj, *args, **kwargs):
        return obj
    old___new__ = UnsafeProxy.__new__

# Generated at 2022-06-21 09:14:51.544936
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(b'foo') == u'foo'
    assert not isinstance(to_unsafe_text(b'foo'), binary_type)
    assert isinstance(to_unsafe_text(b'foo'), AnsibleUnsafeText)

# Generated at 2022-06-21 09:14:55.456202
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    method = AnsibleUnsafeBytes.decode
    assert isinstance(method('unicode_fixture'.encode(), 'utf-8'), AnsibleUnsafeText)

# Generated at 2022-06-21 09:14:56.772689
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert AnsibleUnsafeText('ok') == 'ok'

# Generated at 2022-06-21 09:14:59.230457
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    data_string = to_unsafe_bytes(u"你好")
    assert isinstance(data_string, AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:15:00.859109
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert hasattr(AnsibleUnsafe, '__UNSAFE__')

# Generated at 2022-06-21 09:15:03.640577
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    my_unsafe_bytes = AnsibleUnsafeBytes(b'UnsafeBytes')
    assert isinstance(my_unsafe_bytes, AnsibleUnsafe)
    assert isinstance(my_unsafe_bytes, binary_type)



# Generated at 2022-06-21 09:15:19.607459
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    a = wrap_var('あいうえお')
    assert(type(a) == AnsibleUnsafeText)

    b = a.encode()
    assert(type(b) == AnsibleUnsafeBytes)

    c = a.encode('ascii')
    assert(type(c) == AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:15:29.382979
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    import sys
    import os

    if not os.path.exists('/asciifile'):
        with open('/asciifile', 'w') as testfile:
            testfile.write('this file contains only ascii characters')

    def assert_is_type(obj, type_):
        assert type(obj) is type_, "Unexpected type %s" % type(obj).__name__

    assert_is_type(to_unsafe_bytes(), AnsibleUnsafeBytes)
    assert_is_type(to_unsafe_bytes('asciistring'), AnsibleUnsafeBytes)

    assert_is_type(to_unsafe_bytes(b'asciibytes'), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:15:31.588442
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    text = u"Some text"
    unsafe_text = AnsibleUnsafeText(text)
    assert isinstance(unsafe_text, AnsibleUnsafeText)



# Generated at 2022-06-21 09:15:35.442280
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    import sys
    if sys.version_info[0] < 3:
        NativeJinjaUnsafeText('foo')

# Generated at 2022-06-21 09:15:37.780407
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes(b"AnsibleUnsafeBytes"), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:15:45.114243
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes(u'unicode string') == AnsibleUnsafeBytes(b"unicode string")
    assert to_unsafe_bytes(u'unicode string').decode('utf-8') == "unicode string"
    assert to_unsafe_bytes(b"bytes") == b"bytes"
    assert to_unsafe_bytes(b"bytes").decode('utf-8') == "bytes"


# Generated at 2022-06-21 09:15:47.699452
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert type(AnsibleUnsafeBytes('test_string'.encode()).decode()).__name__ == "AnsibleUnsafeText"


# Generated at 2022-06-21 09:15:50.489775
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    t = AnsibleUnsafeBytes("foo")
    assert(t.__UNSAFE__ == True)
    assert(t == "foo")
    assert(isinstance(t, AnsibleUnsafeBytes))


# Generated at 2022-06-21 09:15:52.321073
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    a=AnsibleUnsafeText("1")
    assert a == "1"


# Generated at 2022-06-21 09:15:53.941584
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('abc'), AnsibleUnsafeBytes)
