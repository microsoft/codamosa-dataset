

# Generated at 2022-06-21 09:06:28.494238
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert type(UnsafeProxy(None)) is None
    assert type(UnsafeProxy(1)) is int
    assert type(UnsafeProxy(1.2)) is float
    assert type(UnsafeProxy(True)) is bool
    assert type(UnsafeProxy(set())) is set
    assert type(UnsafeProxy([1, 2])) is list
    assert type(UnsafeProxy({"1": 1})) is dict
    assert type(UnsafeProxy(AnsibleUnsafeText(""))) is AnsibleUnsafeText
    assert type(UnsafeProxy(AnsibleUnsafeBytes(b""))) is AnsibleUnsafeBytes


# Generated at 2022-06-21 09:06:36.504800
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():

    import ansible.module_utils.common.collections
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types, binary_type, text_type
    from ansible.module_utils.common.collections import Mapping, Set

    # Test 1: Simple test to ensure that the function - to_unsafe_bytes,
    # is returning type AnsibleUnsafeBytes.
    value = "test"
    unsafe_bytes = to_unsafe_bytes(value)
    assert isinstance(unsafe_bytes, AnsibleUnsafeBytes)

    # Test 2: Ensure that the value that is returned is not of type AnsibleUnsafe.
    # A value of type AnsibleUnsafeBytes, will always be of type AnsibleUnsafe.

# Generated at 2022-06-21 09:06:47.933143
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import unittest
    import ansible.module_utils.six as six

    class TestToUnsafeText(unittest.TestCase):
        def test_to_unsafe_text(self):
            if six.PY2:
                self.assertTrue(isinstance(to_unsafe_text(u"test"), AnsibleUnsafeText))
                self.assertTrue(isinstance(to_unsafe_text(u"test".encode()), AnsibleUnsafeText))
                self.assertTrue(isinstance(to_unsafe_text(b"test"), AnsibleUnsafeText))
            else:
                self.assertTrue(isinstance(to_unsafe_text("test"), AnsibleUnsafeText))

# Generated at 2022-06-21 09:06:52.303281
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.utils.display import Display
    Display().deprecated(
        'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )

# Generated at 2022-06-21 09:07:01.880589
# Unit test for function wrap_var
def test_wrap_var():

    test_list = [1,2,3]
    test_unsafe_list = wrap_var(test_list)
    assert type(test_unsafe_list) == list
    assert type(test_unsafe_list[0]) == int

    test_string = 'string'
    test_unsafe_string = wrap_var(test_string)
    assert type(test_unsafe_string) == ansible.module_utils.six.text_type
    assert type(test_unsafe_string) != str

    test_dict = {'key':'value'}
    test_unsafe_dict = wrap_var(test_dict)
    assert type(test_unsafe_dict) == dict
    assert type(test_unsafe_dict['key']) == ansible.module_utils.six.text_type
   

# Generated at 2022-06-21 09:07:05.431687
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    ansibleUnsafeText = AnsibleUnsafeText("hello")
    assert isinstance(ansibleUnsafeText, text_type)
    assert isinstance(ansibleUnsafeText, AnsibleUnsafe)


# Generated at 2022-06-21 09:07:06.507263
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy('1') == '1'

# Generated at 2022-06-21 09:07:16.375659
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeBytes)

    assert to_unsafe_bytes('foo') == to_unsafe_bytes(u'foo')
    assert type(to_unsafe_bytes('foo')) != type(to_unsafe_bytes(u'foo'))

    inp = {'foo': 'bar'}
    outp = to_unsafe_bytes(inp)
    assert outp == to_unsafe_bytes({'foo': 'bar'})
    assert type(outp) != type(to_unsafe_bytes({'foo': 'bar'}))

    inp = ('str1', u'ünicode')
    outp = to_unsafe_bytes(inp)
    assert outp == to_unsafe_bytes(('str1', u'ünicode'))


# Generated at 2022-06-21 09:07:20.435568
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    """Test for constructor of class AnsibleUnsafeBytes"""
    x = AnsibleUnsafeBytes(b'1234')
    if x != b'1234':
        raise AssertionError('Test for constructor of class AnsibleUnsafeBytes FAILED!')



# Generated at 2022-06-21 09:07:25.673352
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    test_string = "123"
    test_instance = AnsibleUnsafeBytes(test_string)
    assert isinstance(test_instance, AnsibleUnsafeBytes)
    assert test_instance == test_string


# Generated at 2022-06-21 09:07:29.669097
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert isinstance(AnsibleUnsafeText(u''), AnsibleUnsafeText)


# Generated at 2022-06-21 09:07:38.553217
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text({'some_key': 'value'}) == {'some_key': 'value'}
    assert to_unsafe_text([[0, 1], 2, 3]) == [[0, 1], 2, 3]
    assert to_unsafe_text(set([0, 1])) == set([0, 1])
    assert to_unsafe_text(0) == 0
    assert to_unsafe_text(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert to_unsafe_text(AnsibleUnsafeBytes('foo')) == AnsibleUnsafeBytes('foo')

# Generated at 2022-06-21 09:07:49.678224
# Unit test for function wrap_var
def test_wrap_var():
    import ansible.module_utils.six
    from ansible.module_utils.six import PY3

    assert wrap_var('hello') == u'hello', 'String not wrapped correctly'
    assert wrap_var(b'hello') == b'hello', 'Byte string not wrapped correctly'
    assert isinstance(wrap_var('hello'), ansible.module_utils.six.text_type), 'String not wrapped correctly'
    assert isinstance(wrap_var(b'hello'), ansible.module_utils.six.binary_type), 'Byte string not wrapped correctly'
    assert isinstance(wrap_var(u'hello'), AnsibleUnsafeText), 'String not wrapped correctly'
    assert isinstance(wrap_var(b'hello'), AnsibleUnsafeBytes), 'Byte string not wrapped correctly'

# Generated at 2022-06-21 09:08:00.313048
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    '''verify that AnsibleUnsafeText.encode produces AnsibleUnsafeBytes'''

    # create native jinja text
    njt = NativeJinjaText('my secret')

    # create AnsibleUnsafeText from njt
    aus = AnsibleUnsafeText(njt)

    # check type of aus
    if not isinstance(aus, AnsibleUnsafeText):
        raise AssertionError('unexpected result for AnsibleUnsafeText(' + repr(njt) + ')')

    # hacky way to check that encode resulted in AnsibleUnsafeBytes
    aus_bytes = aus.encode()

# Generated at 2022-06-21 09:08:08.941802
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(''), AnsibleUnsafeText)
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(AnsibleUnsafeText(u'foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(NativeJinjaText(u'foo')), NativeJinjaUnsafeText)
    assert isinstance(wrap_var({'foo': 'bar'}), dict)

# Generated at 2022-06-21 09:08:10.839519
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    test_string = 'test'
    assert isinstance(to_unsafe_text(test_string), AnsibleUnsafeText)



# Generated at 2022-06-21 09:08:14.194050
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    expect = 'AnsibleUnsafeText'
    unsafeBytes = AnsibleUnsafeBytes('QW5zaWJsZVVuc2FmZVRleHQ='.encode('utf-8'))
    result = unsafeBytes.decode('ascii')
    assert expect == result



# Generated at 2022-06-21 09:08:17.565437
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    ans_unsafe = AnsibleUnsafe()
    assert ans_unsafe.__UNSAFE__ == True


# Generated at 2022-06-21 09:08:26.865481
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY2

    # Check for unchanged case
    assert(wrap_var(None) is None)
    assert(wrap_var(True) is True)
    assert(wrap_var(False) is False)
    assert(wrap_var(1) == 1)

    # Ensure strings wrap
    if PY2:
        assert(type(wrap_var(b'Ascii')) == AnsibleUnsafeBytes)
    else:
        assert(type(wrap_var('Ascii')) == AnsibleUnsafeText)

    # Mapping
    # Tests dictionaries, tuple is a subclass of list in Python 3
    assert(type(wrap_var({'a': 1})) == dict)
    assert(type(wrap_var([1, 2, 3])) == list)

# Generated at 2022-06-21 09:08:38.350318
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.six import PY3
    import unittest

    class ToUnsafeTextTestCase(unittest.TestCase):
        def test_safe_text_types(self):
            for safe_type in (text_type, AnsibleUnsafeText):
                a = safe_type('just a test')
                b = to_unsafe_text(a)
                self.assertIs(a, b)

        if PY3:
            def test_byte_types(self):
                for bytes_type in (binary_type, AnsibleUnsafeBytes):
                    a = bytes_type('just a test', 'utf-8')
                    b = to_unsafe_text(a)
                    self.assertIsInstance(a, bytes_type)