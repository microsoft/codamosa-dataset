

# Generated at 2022-06-21 09:06:28.538523
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    unsafe_string = AnsibleUnsafeBytes(b"foo")
    assert isinstance(unsafe_string, AnsibleUnsafeBytes)
    assert isinstance(unsafe_string, AnsibleUnsafeText) == False
    assert unsafe_string.decode('utf-8') == u"foo"
    assert isinstance(unsafe_string.decode('utf-8'), AnsibleUnsafeText)

    unsafe_string = AnsibleUnsafeText(u"foo")
    assert isinstance(unsafe_string, AnsibleUnsafeText)
    assert isinstance(unsafe_string, AnsibleUnsafeBytes) == False
    assert unsafe_string.encode('utf-8') == b"foo"
    assert isinstance(unsafe_string.encode('utf-8'), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:06:40.144040
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text('test'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(5), AnsibleUnsafe)
    assert isinstance(to_unsafe_text(u'some unicode'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(dict(a=1, b=2)), dict)
    assert isinstance(to_unsafe_text(dict(a=u'abc', b=2)), dict)
    assert isinstance(to_unsafe_text(dict(a=u'abc', b=u'def')), dict)
    assert isinstance(to_unsafe_text(dict(a=u'abc', b=dict(c=u'def'))), dict)

# Generated at 2022-06-21 09:06:50.036997
# Unit test for function wrap_var
def test_wrap_var():
    # Test for wrapping strings
    assert isinstance(wrap_var('abc'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'abc'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'abc'), AnsibleUnsafeBytes)

    # Test for wrapping list
    assert isinstance(wrap_var([b'abc', b'def']), list)
    assert isinstance(wrap_var(['abc', 'def']), list)
    assert isinstance(wrap_var([u'abc', u'def']), list)
    assert isinstance(wrap_var([b'abc', u'def']), list)
    assert isinstance(wrap_var([u'abc', b'def']), list)
    assert isinstance(wrap_var(['abc', b'def']), list)
    assert isinstance

# Generated at 2022-06-21 09:06:52.034077
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    teststr = AnsibleUnsafeText('hello, world')
    assert teststr.encode() == b'hello, world'

# Generated at 2022-06-21 09:06:58.533134
# Unit test for function wrap_var
def test_wrap_var():
    import pytest

    assert wrap_var(123) == 123
    assert wrap_var(1.2) == 1.2
    assert wrap_var("foo") == b"foo"
    assert wrap_var("foo") == u"foo"

    assert isinstance(wrap_var("foo"), AnsibleUnsafeBytes)
    assert isinstance(wrap_var("foo"), AnsibleUnsafeText)

    assert wrap_var(None) is None

# Generated at 2022-06-21 09:07:10.507354
# Unit test for function wrap_var
def test_wrap_var():
    class MyFancyString(text_type):
        pass

    # Test with Mapping
    d = {
        2: 'two',
        3: 'three',
        'f': 'four',
        MyFancyString('my fancy'): 'five',
    }
    d2 = wrap_var(d)
    for key, value in d.items():
        assert(isinstance(key, AnsibleUnsafe) and
               isinstance(value, AnsibleUnsafe) and
               not isinstance(key, NativeJinjaUnsafeText))

    # Test with sequences
    s = [2,
         3,
         'f',
         MyFancyString('my fancy')]
    s2 = wrap_var(s)

# Generated at 2022-06-21 09:07:13.325388
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text("test"), text_type)
    assert isinstance(to_unsafe_text("test"), AnsibleUnsafeText)


# Generated at 2022-06-21 09:07:15.507832
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('\x7f'), AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:07:27.289555
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():

    from ansible.utils.display import Display
    import os
    import sys

    # Finding the current dir where modules are residing
    parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    values = (parent_dir, "test", "units", "test_module_utils")
    lib_path = os.path.join(*values)
    sys.path.insert(0, lib_path)
    # Adding a context manager to supress the print of DeprecationWarning message
    display = Display()
    with display._suppress_deprecation_messages():
        obj = NativeJinjaUnsafeText('{% if 1 == 1 %}Hello World{% endif %}')
        assert isinstance(obj, NativeJinjaUnsafeText)

# Generated at 2022-06-21 09:07:37.617708
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.common.text.converters import to_text
    assert to_unsafe_bytes('foo') == b'foo'
    assert to_unsafe_bytes('foo'.encode('utf-8')) == b'foo'

    # test_options
    # {'encoding': None, 'errors': 'strict', 'nonstring': 'simplerepr'}
    assert to_text('foo', encoding=None, errors='strict') == 'foo'
    assert to_text('foo'.encode('utf-16'), encoding=None, errors='strict') == 'foo'
    assert to_text('foo', encoding=None, errors='surrogate_or_strict') == 'foo'
    assert to_text('foo', encoding=None, errors='surrogateescape') == 'foo'



# Generated at 2022-06-21 09:07:50.598985
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common._collections_compat import Mapping, MutableMapping
    from ansible.module_utils.six.moves import configparser


# Generated at 2022-06-21 09:07:53.633177
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    obj = AnsibleUnsafeBytes(b"Hello world!")
    assert isinstance(obj.decode(), AnsibleUnsafeText)
    assert obj.decode() == "Hello world!"


# Generated at 2022-06-21 09:07:54.689323
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # no error
    return AnsibleUnsafe()

# Generated at 2022-06-21 09:07:56.849800
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText('test').encode(), type(AnsibleUnsafeBytes()))


# Generated at 2022-06-21 09:08:01.942449
# Unit test for function to_unsafe_text
def test_to_unsafe_text():

    assert(to_unsafe_text(None) is None)
    assert(to_unsafe_text('foo') == AnsibleUnsafeText('foo'))
    assert(type(to_unsafe_text(b'foo')) is AnsibleUnsafeText)
    assert(type(to_unsafe_text(u'foo')) is AnsibleUnsafeText)

# Generated at 2022-06-21 09:08:04.305384
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    if __name__ == '__main__':
        testArg = 5
        njut = NativeJinjaUnsafeText(testArg)
        print("Test passed")

# Generated at 2022-06-21 09:08:11.774250
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    display = Display()
    # Check if wrap_var returns same object with type same as old object
    assert wrap_var(None) is None
    assert isinstance(wrap_var(""), text_type)
    assert isinstance(wrap_var(b""), binary_type)
    assert isinstance(wrap_var(AnsibleUnsafeText("")), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes("")), AnsibleUnsafeBytes)
    assert isinstance(wrap_var({"a": "a"}), type({"a": "a"}))
    assert isinstance(wrap_var({"a": AnsibleUnsafeBytes("")}), type({"a": AnsibleUnsafeBytes("")}))

# Generated at 2022-06-21 09:08:18.020280
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import re
    import sys
    import traceback

    msg = "This is a message"
    assert repr(to_unsafe_text(msg)) == repr(msg)
    assert repr(to_unsafe_text(msg, "utf-8")) == repr(msg)
    assert repr(to_unsafe_text(msg, errors="replace")) == repr(msg)

    try:
        to_unsafe_text(b"\xa1")
    except TypeError:
        pass
    except Exception:
        traceback.print_exception(*sys.exc_info())
        print('%s got raised instead of TypeError' % sys.exc_info()[0].__name__)
    else:
        raise AssertionError('Exception not raised')


# Generated at 2022-06-21 09:08:27.097455
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():

    def test_class_from_constructor(cls, args, expected_type):
        """Test for equivalence of class types of objs in args and expected_type"""
        for obj in args:
            result = cls(obj)
            assert isinstance(result, expected_type)

    # Test 1: test for type equivalence of result of constructor and
    #         type 'str' of argument
    test_class_from_constructor(UnsafeProxy,
                                ["str"],
                                AnsibleUnsafeText)

    # Test 2: test for type equivalence of result of constructor and
    #         type 'unicode' of argument
    test_class_from_constructor(UnsafeProxy,
                                [u"unicode"],
                                AnsibleUnsafeText)

    # Test 3: test for type equivalence of result of constructor

# Generated at 2022-06-21 09:08:30.984380
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    b = AnsibleUnsafeBytes(b"hello")
    result = b.decode()
    assert(isinstance(result, AnsibleUnsafeText))


# Generated at 2022-06-21 09:08:37.703537
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    """
    There is no way to check the instance of class AnsibleUnsafeText, so we have to check the content in the instance.
    """
    ANSIBLE_UNSAFE_BYTES = AnsibleUnsafeBytes(b'There is no way to check the instance of class AnsibleUnsafeText.')
    ANSIBLE_UNSAFE_TEXT = AnsibleUnsafeText('So we have to check the content in the instance.')

    # Tests methods of class AnsibleUnsafeText
    assert isinstance(ANSIBLE_UNSAFE_TEXT, text_type)
    assert isinstance(ANSIBLE_UNSAFE_TEXT, AnsibleUnsafe)
    assert isinstance(ANSIBLE_UNSAFE_TEXT.encode(), AnsibleUnsafeBytes)

    # Tests the type of the created instance

# Generated at 2022-06-21 09:08:51.202923
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    import os
    import sys

    # Test that AnsibleUnsafe() can be called without arguments
    unsafe = AnsibleUnsafe()

    # Test that AnsibleUnsafe() can be called with a string (with trailing newline)
    unsafe = AnsibleUnsafe("with trailing newline")
    if unsafe != "with trailing newline":
        raise(AssertionError("expected string with trailing newline, got %s" % unsafe))

    # Test that AnsibleUnsafeBytes() can be called without arguments
    unsafe = AnsibleUnsafeBytes()

    # Test that AnsibleUnsafeBytes() can be called with a string ('with trailing newline')
    unsafe = AnsibleUnsafeBytes("with trailing newline")

# Generated at 2022-06-21 09:08:53.066607
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(u'foo') == u'foo'



# Generated at 2022-06-21 09:09:00.239463
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    some_strings = [u'hello', u'\u2019', 'hello', b'hello']
    unsafe_wrap = [u'hello', u'\u2019', AnsibleUnsafeText('hello'), AnsibleUnsafeBytes('hello')]
    for i in range(0, len(some_strings)):
        result = to_unsafe_bytes(some_strings[i])
        assert result == unsafe_wrap[i]



# Generated at 2022-06-21 09:09:09.790285
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():

    # Testing if the object is of type ansible unsafe bytes
    assert isinstance(UnsafeProxy('Hello World'), AnsibleUnsafeBytes)

    # Testing if the object is of type ansible unsafe string
    assert isinstance(UnsafeProxy(u'Hello World'), AnsibleUnsafeText)

    # Testing if the object is of type ansible unsafe
    assert isinstance(UnsafeProxy(u'Hello World'), AnsibleUnsafe)

    # Testing if the object is of type ansible unsafe bytes
    assert isinstance(UnsafeProxy(b'Hello World'), AnsibleUnsafeBytes)

    # Testing if the object is of type ansible unsafe string
    assert isinstance(UnsafeProxy(b'Hello World'.decode('utf-8')), AnsibleUnsafeText)

    # Testing if the object is of type ansible unsafe

# Generated at 2022-06-21 09:09:12.660220
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b"test").decode("utf-8"), AnsibleUnsafeText)


# Generated at 2022-06-21 09:09:22.383446
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    text = b"test_bytes"
    encoding = "utf-8"

    # Since decoding a byte string results in a binary string,
    # we expect the type to be unicode string
    t = AnsibleUnsafeText(text, encoding)
    assert isinstance(t, text_type)
    assert t == "test_bytes"

    # Since we're passing in a unicode string,
    # we expect the type to be unicode string
    t = AnsibleUnsafeText(u"test_unicode")
    assert isinstance(t, text_type)
    assert t == "test_unicode"



# Generated at 2022-06-21 09:09:28.544162
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('AnsibleUnsafeBytes') == AnsibleUnsafeBytes(b'AnsibleUnsafeBytes')
    assert not isinstance(to_unsafe_bytes('AnsibleUnsafeBytes'), str)
    assert isinstance(to_unsafe_bytes('AnsibleUnsafeBytes'), AnsibleUnsafeBytes)
    assert to_unsafe_bytes('AnsibleUnsafeBytes').decode('utf-8') == 'AnsibleUnsafeBytes'
    assert isinstance(to_unsafe_bytes('AnsibleUnsafeBytes').decode('utf-8'), AnsibleUnsafeText)


# Generated at 2022-06-21 09:09:38.905965
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.module_utils.six import PY3
    assert issubclass(NativeJinjaUnsafeText, text_type)
    assert issubclass(NativeJinjaUnsafeText, AnsibleUnsafe)
    assert issubclass(NativeJinjaUnsafeText, NativeJinjaText)
    text = NativeJinjaUnsafeText(u'UnsafeText')
    assert text is not None
    if PY3:
        assert isinstance(text, str)
    else:
        assert isinstance(text, unicode)
    assert isinstance(text, AnsibleUnsafe)
    assert isinstance(text, NativeJinjaText)

# Generated at 2022-06-21 09:09:43.646771
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    text = 'Hello, world!'
    unsafe_text = NativeJinjaUnsafeText(text)
    assert type(unsafe_text) == NativeJinjaUnsafeText
    assert unsafe_text.__str__() == 'Hello, world!'

# Generated at 2022-06-21 09:09:59.420363
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    import copy
    from ansible.module_utils.six import PY3

    class object:
        pass

    class object2:
        pass

    class object3:
        pass

    class object4:
        pass

    class object5:
        pass

    class object6:
        pass

    # Test for code path UnsafeProxy.__new__(UnsafeProxy, obj, *args, **kwargs)

    # obj is a instance of object.
    # args is a tuple.
    # kwargs is a dict.
    # The return value is a instance of object.
    obj = object()
    arg = object()
    kwarg = object()
    ans = UnsafeProxy.__new__(UnsafeProxy, obj, arg, key=kwarg)
    assert isinstance(ans, object)

# Generated at 2022-06-21 09:10:06.157211
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    text = AnsibleUnsafeText("\u05d0")
    assert(text == "\u05d0")
    assert(text.__UNSAFE__ == True)
    assert(text.encode() == b"\xd7\x90")
    assert(text.encode().__UNSAFE__ == True)
    assert(text.encode().decode() == "\u05d0")
    assert(text.encode().decode().__UNSAFE__ == True)


# Generated at 2022-06-21 09:10:10.571934
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    v = AnsibleUnsafeBytes("foo")
    # Test that v is an AnsibleUnsafeBytes object
    assert isinstance(v, AnsibleUnsafeBytes)
    # Test that v is an instance of AnsibleUnsafe
    assert isinstance(v, AnsibleUnsafe)
    # Test that v is an instance of bytes
    assert isinstance(v, binary_type)


# Generated at 2022-06-21 09:10:13.249648
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    obj = AnsibleUnsafeBytes(b'hello')
    exp = AnsibleUnsafeText('hello')
    act = obj.decode()
    assert act == exp


# Generated at 2022-06-21 09:10:17.463490
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():

    decoded_value = AnsibleUnsafeBytes(b"foo").decode('utf-8')
    assert decoded_value == AnsibleUnsafeText("foo")


# Generated at 2022-06-21 09:10:21.153147
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    unsafe_text = AnsibleUnsafeText('foo')
    ansible_unsafe_bytes = unsafe_text.encode('utf-8')
    assert isinstance(ansible_unsafe_bytes, AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:10:25.284445
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    ansible_unsafe_text = AnsibleUnsafeText()
    assert isinstance(ansible_unsafe_text, AnsibleUnsafe)
    assert isinstance(ansible_unsafe_text, text_type)


# Generated at 2022-06-21 09:10:28.103725
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes('\xe2\x98\x83') == '\xe2\x98\x83'

# Generated at 2022-06-21 09:10:35.618118
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(b'bytes'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'bytes', encoding='utf-8'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'unicode'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'unicode', errors='strict'), AnsibleUnsafeText)



# Generated at 2022-06-21 09:10:38.808294
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    a = AnsibleUnsafeBytes('foo')
    assert a == b'foo'
    assert not isinstance(a, str)
    assert not isinstance(a, AnsibleUnsafeText)



# Generated at 2022-06-21 09:10:52.049616
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes("foo"), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeBytes("foo").decode(), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeBytes("foo").decode("utf-8"), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeBytes("foo").decode("utf-8", "ignore"), AnsibleUnsafeText)


# Generated at 2022-06-21 09:10:53.633920
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    NativeJinjaUnsafeText("This is for unit test")

# Generated at 2022-06-21 09:10:55.590754
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy('foo'), AnsibleUnsafeText)

# Generated at 2022-06-21 09:10:57.821283
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    inst = AnsibleUnsafe()
    assert(isinstance(inst, AnsibleUnsafe))
    assert(AnsibleUnsafe.__UNSAFE__)

# Generated at 2022-06-21 09:11:04.044303
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    from ansible.module_utils.six import PY3

    if PY3:
        assert isinstance(to_unsafe_text(b"foobar").decode(errors='surrogate_or_strict'), AnsibleUnsafeText)
    # Testing for Python 2.x not required as Behavior of decode() is removed in Python 3.x


# Generated at 2022-06-21 09:11:05.383425
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert ''.encode() == AnsibleUnsafeBytes(b'')



# Generated at 2022-06-21 09:11:14.340189
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import string_types
    val = 'test_val'
    # test plain string
    val_proxy = UnsafeProxy(val)
    assert isinstance(val_proxy, AnsibleUnsafeText)
    assert type(val) == type(val_proxy)
    val_proxy = UnsafeProxy(val)
    # test str
    assert isinstance(val_proxy, AnsibleUnsafeText)
    assert type(val) == type(val_proxy)
    # test unsafe text
    val_proxy = UnsafeProxy(AnsibleUnsafeText(val))
    assert isinstance(val_proxy, AnsibleUnsafeText)
    assert type(val) == type(val_proxy)
    # test unsafe bytes
    val_proxy = UnsafeProxy(AnsibleUnsafeBytes(val))


# Generated at 2022-06-21 09:11:25.420813
# Unit test for function wrap_var
def test_wrap_var():
    x = {
        "foo": 1,
        "bar": True,
        "bat": False,
        "baz": "foobar",
        "qux": ["foo", "bar", "baz"],
        "quux": ["foo", "bar", "baz", 1, True, False],
        "corge": None,
        "grault": ["foo", ["bar", "baz"], "qux", "quux", "corge", "garply"],
    }
    orig_x = x.copy()

    wrapped_x = wrap_var(x)

    assert wrapped_x["foo"] == x["foo"], "'foo' was mutated in wrapping"
    assert wrapped_x["bar"] == x["bar"], "'bar' was mutated in wrapping"

# Generated at 2022-06-21 09:11:29.408438
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    from ansible.module_utils.six import PY3
    obj = AnsibleUnsafeBytes('foo')
    if PY3:
        assert type(obj) == AnsibleUnsafeText
    else:
        assert type(obj) == AnsibleUnsafeBytes


# Generated at 2022-06-21 09:11:31.947395
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    ansible = AnsibleUnsafeText('€')
    result = ansible.encode('utf-8')
    assert result[0] == '\xe2'

# Generated at 2022-06-21 09:11:46.505754
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    unsafe_text = AnsibleUnsafeText(u'test123')
    assert isinstance(unsafe_text, AnsibleUnsafeText)
    unsafe_bytes = unsafe_text.encode()
    assert isinstance(unsafe_bytes, AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:11:53.668942
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance("mystring".encode('utf-8'), binary_type)
    assert isinstance(to_unsafe_text("mystring"), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b"mystring"), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u"mystring"), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(to_bytes("mystring")), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(to_text("mystring")), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u"mystring".encode('utf-8')), AnsibleUnsafeText)

# Generated at 2022-06-21 09:11:55.441354
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    ans_unsafe_text = AnsibleUnsafeText

    assert issubclass(ans_unsafe_text, text_type)
    assert issubclass(ans_unsafe_text, AnsibleUnsafe)


# Generated at 2022-06-21 09:11:56.738080
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert NativeJinjaUnsafeText

# Generated at 2022-06-21 09:12:04.511567
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():

    def test_values():
        return ["test string"]

    test_str = "test string"
    for val in test_values():
        obj = AnsibleUnsafeText(val)
        assert(obj)
        assert(isinstance(obj, AnsibleUnsafeText))
        assert(isinstance(obj, text_type))
        assert(isinstance(obj, AnsibleUnsafe))
        assert(obj == test_str)



# Generated at 2022-06-21 09:12:15.357332
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.utils.collection_loader import AnsibleCollectionLoader, _COLLECTION_PATHS
    from ansible.utils.display import Display

    display = Display()
    module_name = 'copy'
    display.debug("Loading module %s" % module_name)

    if not _COLLECTION_PATHS:
        raise Exception("\n\nThe collection_paths option was not set in ansible.cfg or the environment\n")

    loader = AnsibleCollectionLoader()
    loader._set_collection_paths(collections_paths=_COLLECTION_PATHS)

    collection_namespace = loader.get_collection_namespace(module_name)

    if not collection_namespace:
        display.warning("No namespace found for module %s" % module_name)


# Generated at 2022-06-21 09:12:18.151910
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes(b"test").__class__.__name__ == "AnsibleUnsafeBytes"


# Generated at 2022-06-21 09:12:26.109346
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import text_type
    data = dict(
        foo='bar',
        baz='qux',
        fiz='buz',
        dict=dict(
            foo='bar',
        ),
        list=[1, 2, 3],
        string='hello world!',
        bool=True,
        integer=23,
    )
    new_data = to_unsafe_bytes(data)
    assert isinstance(new_data, dict)
    assert isinstance(new_data, Mapping)
    for k, v in new_data.items():
        assert isinstance(k, text_type)

# Generated at 2022-06-21 09:12:31.928776
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    import os
    import sys
    if sys.version_info[0] < 3:
        assert(type(UnsafeProxy(u"string")) is AnsibleUnsafeText)
    else:
        assert(type(UnsafeProxy(u"string")) is AnsibleUnsafeText)
        assert(type(UnsafeProxy(b"string")) is AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:12:35.770369
# Unit test for function to_unsafe_text
def test_to_unsafe_text():

    text_in = "Foo | Bar | baz"
    text_out = to_unsafe_text(text_in)
    assert text_out == "Foo | Bar | baz"
    assert isinstance(text_out, AnsibleUnsafeText)



# Generated at 2022-06-21 09:13:04.985312
# Unit test for function wrap_var
def test_wrap_var():
    import unittest
    class TestWrapVar(unittest.TestCase):
        def test_text_types(self):
            self.assertEqual(wrap_var('foo'), AnsibleUnsafeText('foo'))
            self.assertEqual(wrap_var(b'foo'), AnsibleUnsafeBytes(b'foo'))
            self.assertEqual(wrap_var(u'foo'), AnsibleUnsafeText(u'foo'))

        def test_dict_types(self):
            self.assertEqual(wrap_var({'foo': 'bar'}), {'foo': AnsibleUnsafeText('bar')})
            self.assertEqual(wrap_var({'foo': b'bar'}), {'foo': AnsibleUnsafeBytes(b'bar')})

# Generated at 2022-06-21 09:13:07.958683
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # pylint: disable=unused-argument
    assert isinstance(AnsibleUnsafeText('foo').encode('utf-8'), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:13:17.981605
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.utils.unsafe_proxy import UnsafeProxy

    u_str = u'Parmenides'
    b_str = b'Parmenides'

    # Dict
    assert isinstance(wrap_var({}), dict)
    assert isinstance(wrap_var({u_str: u_str}), dict)
    assert wrap_var({u_str: u_str})[u_str] == AnsibleUnsafeText('Parmenides')
    assert isinstance(wrap_var({b_str: b_str}), dict)

# Generated at 2022-06-21 09:13:28.780544
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    class Test:
        pass
    t = Test()
    t.__str__ = lambda: 'test string'
    object_dict = {'int': 1, 'str': 'I am a string', 'bytes': b'I am a byte',
                   'unicode': '\u2713', 'null': None, 'test': t}
    expected_result = {'int': b'1', 'str': b'I am a string', 'bytes': b'I am a byte',
                       'unicode': b'\\xe2\\x9c\\x93', 'null': None, 'test': b'test string'}
    result = to_unsafe_bytes(object_dict, errors='surrogate_or_strict')
    assert result == expected_result


# Generated at 2022-06-21 09:13:37.568550
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.unsafe_proxy import UnsafeProxy
    assert isinstance(UnsafeProxy('test'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText('test')), AnsibleUnsafeText)
    assert UnsafeProxy('test') == 'test'
    assert UnsafeProxy(AnsibleUnsafeText('test')) == 'test'
    a = UnsafeProxy('test')
    b = UnsafeProxy(AnsibleUnsafeText('test'))
    assert a == b


# Generated at 2022-06-21 09:13:41.906774
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    a = AnsibleUnsafeText()
    if not isinstance(a, text_type):
        raise AssertionError
    if not isinstance(a, AnsibleUnsafe):
        raise AssertionError

if __name__ == "__main__":
    test()

# Generated at 2022-06-21 09:13:45.959211
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy(None), AnsibleUnsafe)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText('')), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b''), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(u''), AnsibleUnsafeText)

# Generated at 2022-06-21 09:13:51.334347
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    str_bytes = to_bytes("hello world")
    ansible_unsafe_bytes = AnsibleUnsafeBytes(str_bytes)
    assert(isinstance(ansible_unsafe_bytes, binary_type))
    assert(isinstance(ansible_unsafe_bytes, AnsibleUnsafeBytes))


# Generated at 2022-06-21 09:14:02.403116
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert "'arg3' " == to_unsafe_text("arg3")
    assert "'a1' 'a2' " == to_unsafe_text("a1\na2")
    assert "'a1' 'b1' " == to_unsafe_text({'a1': 'b1'})
    assert "'a1' 'b1' " == to_unsafe_text({'a1': 'b1', 'a2': 'b2'})
    assert "'a1' 'b1' 'a2' 'b2' " == to_unsafe_text({'a1': 'b1', 'a2': 'b2'})

# Generated at 2022-06-21 09:14:15.285486
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import string_types, binary_type, text_type
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeBytes()) is AnsibleUnsafeBytes()
    assert wrap_var(AnsibleUnsafeText()) is AnsibleUnsafeText()

    assert isinstance(wrap_var(to_text(b"foo")), AnsibleUnsafeText)
    assert wrap_var(to_text(b"foo")) == to_text(b"foo")

    assert isinstance(wrap_var(b"foo"), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:15:06.611851
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    """ Test with base class, ValueError is expected
    Call __new__ method of AnsibleUnsafeText
    Call __new__ method of AnsibleUnsafeText with args
    Call __new__ method of AnsibleUnsafeText with kwargs
    Call __new__ method of AnsibleUnsafeText with args and kwargs
    """
    from ansible.module_utils.common.text.converters import to_text
    from ansible.utils.display import Display
    display = Display()
    with display.quashing():
        # Test with base class
        try:
            AnsibleUnsafeText()
        except TypeError as e:
            if "object.__new__() takes no parameters" in to_text(e):
                pass
            else:
                raise
        except Exception as e:
            raise

        # Test with args


# Generated at 2022-06-21 09:15:08.928278
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    a = AnsibleUnsafeText("abc")
    b = a.encode()
    assert(type(b) == AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:15:15.080743
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # Helper function to check if a class is a sub-class of another
    def isa(a, b):
        return issubclass(a, b)

    # Check if the class AnsibleUnsafeBytes is a subclass of base_class
    # ansible_unsafe_bytes_base_class and another_base_class
    if not isa(AnsibleUnsafeBytes, (AnsibleUnsafe, binary_type)):
        raise Exception("AnsibleUnsafeBytes is not a subclass of AnsibleUnsafe or binary_type")



# Generated at 2022-06-21 09:15:20.199046
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    for safe_val in [None, 1, 2.0, 'foo', u'unicode foo', AnsibleUnsafeBytes(b'foo'), AnsibleUnsafeText(u'foo')]:
        assert wrap_var(safe_val) is safe_val


# Generated at 2022-06-21 09:15:21.034468
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    NativeJinjaUnsafeText("Test for constructor of class NativeJinjaUnsafeText")

# Generated at 2022-06-21 09:15:25.348915
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance("test".encode("utf-8"), binary_type)
    assert isinstance(AnsibleUnsafeText("test").encode("utf-8"), binary_type)
    assert isinstance(to_unsafe_text("test").encode("utf-8"), binary_type)



# Generated at 2022-06-21 09:15:32.855602
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    from ansible.module_utils.common._collections_compat import OrderedDict

    # __UNSAFE__ is True
    assert AnsibleUnsafe.__UNSAFE__ is True
    assert AnsibleUnsafeBytes('test string').__UNSAFE__ is True
    assert AnsibleUnsafeText('test string').__UNSAFE__ is True
    assert NativeJinjaUnsafeText('test string').__UNSAFE__ is True
    assert UnsafeProxy(AnsibleUnsafeText('test string')).__UNSAFE__ is True

    # Equality
    assert UnsafeProxy(AnsibleUnsafeText('test string')) == 'test string'
    assert 'test string' == UnsafeProxy(AnsibleUnsafeText('test string'))

    # Wrap a string

# Generated at 2022-06-21 09:15:35.887894
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    a = NativeJinjaUnsafeText('{{ a }}')
    assert a == '{{ a }}'

# Generated at 2022-06-21 09:15:47.572501
# Unit test for function wrap_var
def test_wrap_var():
    import unittest

    class TestWrapVar(unittest.TestCase):
        def setUp(self):
            pass

        def test_wrap_dict(self):
            dict_val = dict(a=1, b=2)
            wrapped_dict = wrap_var(dict_val)
            self.assertNotEqual(dict_val, wrapped_dict)
            self.assertEqual(dict_val['a'], wrapped_dict['a'])
            self.assertEqual(dict_val['b'], wrapped_dict['b'])

        def test_wrap_list(self):
            list_val = [1, 2, 3]
            wrapped_list = wrap_var(list_val)
            self.assertNotEqual(list_val, wrapped_list)

# Generated at 2022-06-21 09:15:48.538794
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe
