

# Generated at 2022-06-21 09:06:30.006988
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    import sys
    import os
    import unittest
    import ansible.module_utils.common
    from ansible.module_utils.common._collections_compat import Mapping, Set

    class TestUnsafeProxy(unittest.TestCase):

        def setUp(self):
            self.data = {
                'text': 'unicode text',
                'bytes': b'bytes data',
                'tuple': ('tuple', (1, 2, 3)),
                'list': ['list', ['nested', (1, 2, 3,), 'list']],
                'dict': {
                    'embedded_dict': {},
                },
                'set': set(range(1, 6)),
            }

        def test_UnsafeProxy(self):
            data = UnsafeProxy(self.data)

# Generated at 2022-06-21 09:06:32.997201
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    unsafe_bytes = AnsibleUnsafeBytes(b'abc')
    assert isinstance(unsafe_bytes.decode(), AnsibleUnsafeText)


# Generated at 2022-06-21 09:06:37.463915
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('Hello World'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u'Hello World'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'Hello World'), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:06:41.698173
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Check, that the __new__ method returns a new AnsibleUnsafeText object.
    u = UnsafeProxy('Hello, World!')
    assert isinstance(u, AnsibleUnsafeText)
    assert u == 'Hello, World!'

# Generated at 2022-06-21 09:06:51.183667
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.text.converters import to_text, to_bytes
    from ansible.module_utils.common.collections import is_sequence

    # Basic test to check the wrap_var with type of string
    # No Exception otherwise it is failed
    try:
        wrap_var('')
    except Exception as e:
        raise Exception('wrap_var is failed with type of string, exception:\n{0}'.format(e))

    # Test with dict
    dict_test = dict(a=1, b=2)
    dict_test_str = 'dict_test'
    wrap_dict_test = wrap_var(dict_test)
    wrap_dict_test_str = wrap_var(dict_test_str)


# Generated at 2022-06-21 09:06:55.049403
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    string = 'test'
    assert isinstance(string, str)
    string = to_unsafe_bytes(string)
    assert isinstance(string, AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:06:56.648507
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert(to_unsafe_bytes(b'foo') == b'foo')

# Generated at 2022-06-21 09:07:00.773144
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    expected = AnsibleUnsafeText(u'test_AnsibleUnsafeText')
    result = AnsibleUnsafeText(u'test_AnsibleUnsafeText')

    assert expected == result
    assert expected.__class__ == result.__class__


# Generated at 2022-06-21 09:07:03.099217
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert AnsibleUnsafeText('hello world')


# Generated at 2022-06-21 09:07:09.726362
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import binary_type, text_type
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'test'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(['test']), list)
    assert isinstance(wrap_var(['test'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var({'a': 'test', 'b': '1'}), dict)
    assert isinstance(wrap_var({'a': 'test', 'b': '1'}).keys()[0], AnsibleUnsafeText)

# Generated at 2022-06-21 09:07:15.984045
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes(b'abc'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u'abc'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(AnsibleUnsafeText('abc')), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(to_unsafe_text('abc')), AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:07:28.586359
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('12345') == b'12345'
    assert isinstance(to_unsafe_bytes('12345'), AnsibleUnsafeBytes)
    assert to_unsafe_bytes(b'12345') == b'12345'
    assert isinstance(to_unsafe_bytes(b'12345'), AnsibleUnsafeBytes)
    assert to_unsafe_bytes(u'12345') == b'12345'
    assert isinstance(to_unsafe_bytes(u'12345'), AnsibleUnsafeBytes)
    assert to_unsafe_bytes(b'12345', errors='strict') == b'12345'
    assert isinstance(to_unsafe_bytes(b'12345', errors='strict'), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:07:33.754847
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text('string'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'byte'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'unicode'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(AnsibleUnsafeText('unsafe text')), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(NativeJinjaText('native jinja text')), AnsibleUnsafeText)

# Generated at 2022-06-21 09:07:36.581133
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # Decodes an unsafe string back to a regular string
    assert AnsibleUnsafeBytes(b"foo").decode() == "foo"


# Generated at 2022-06-21 09:07:38.373769
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    obj = AnsibleUnsafeText(b'foo')
    assert isinstance(obj, AnsibleUnsafeText)
    assert isinstance(obj, AnsibleUnsafe)


# Generated at 2022-06-21 09:07:49.520500
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert UnsafeProxy('abc') == wrap_var('abc')
    assert UnsafeProxy(u'abc') == wrap_var('abc')
    assert isinstance(UnsafeProxy(u'abc'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy('a\nb\nc'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(u'a\nb\nc'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText(u'a\nb\nc')), AnsibleUnsafeText)


from ansible.module_utils import basic
from ansible.module_utils.common._collections_compat import MutableMapping
from ansible.module_utils.parsing.convert_bool import boolean
from ansible.utils.unsafe_proxy import UnsafeProxy as _

# Generated at 2022-06-21 09:07:56.503364
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    string = "string"
    ansibleUnsafeString = AnsibleUnsafeBytes(string)
    assert(ansibleUnsafeString.decode() == "string")
    # Test with not default arguments
    assert(ansibleUnsafeString.decode(errors="ignore") == "string")
    # Test with not supported arguments
    try:
        ansibleUnsafeString.decode(errors="ignore", encoding="UTF-8")
        assert(False)
    except TypeError:
        assert(True)


# Generated at 2022-06-21 09:08:00.387486
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    text = AnsibleUnsafeText(u'Unsafe Unicode: \u20ac')
    encoded = text.encode('utf-8')

    assert isinstance(encoded, AnsibleUnsafeBytes)
    assert isinstance(encoded, bytes)



# Generated at 2022-06-21 09:08:09.011669
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():

    # Check for string type (unicode in py2, str in py3)
    assert isinstance(UnsafeProxy(u'string'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'bytes'), AnsibleUnsafeBytes)

    # Check for Mapping type
    assert isinstance(UnsafeProxy(dict()), dict)
    assert isinstance(UnsafeProxy(dict()).get(u'key'), AnsibleUnsafeText)

    # Check for sequences except strings
    assert isinstance(UnsafeProxy(list()), list)
    assert isinstance(UnsafeProxy(list())[0], AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(tuple()), tuple)
    assert isinstance(UnsafeProxy(tuple())[0], AnsibleUnsafeText)

# Generated at 2022-06-21 09:08:13.252040
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.utils.display import Display
    Display().deprecated(
        'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )
    obj = UnsafeProxy('test')
    assert(isinstance(obj, AnsibleUnsafeText))

# Generated at 2022-06-21 09:08:15.579867
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    NativeJinjaUnsafeText('hello world')

# Generated at 2022-06-21 09:08:19.108769
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    s = AnsibleUnsafeBytes('\x00')
    assert isinstance(s, binary_type)
    assert isinstance(s, AnsibleUnsafe)



# Generated at 2022-06-21 09:08:23.776719
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('bytestr'.encode()), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes('bytestr'.encode(), errors='strict'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes('bytestr'.encode(), errors='surrogate_or_strict'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes('bytestr'.encode(), errors='strict'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes('bytestr'.encode(), errors='surrogate_or_strict'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(True), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:08:36.414396
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-21 09:08:39.424713
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText(u'test').encode('utf-8'), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:08:43.056583
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    ansibleUnsafeBytes = AnsibleUnsafeBytes()
    ansibleUnsafeBytes.decode('utf-8')


# Generated at 2022-06-21 09:08:45.858947
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    mytext = 'hello_world'
    unsafe_text = AnsibleUnsafeText(mytext)
    assert unsafe_text == 'hello_world'

# Generated at 2022-06-21 09:08:55.388980
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from collections import namedtuple
    from ansible.module_utils.six.moves import UserString

    assert UnsafeProxy(object()) is object()

    # Test dict is properly wrapped
    d = dict(a=1, b=2)
    p = UnsafeProxy(d)
    assert p['a'] == 1
    assert p['b'] == 2

    for k in p:
        assert isinstance(p[k], AnsibleUnsafe)

    assert isinstance(p, dict)

    # Test list is properly wrapped
    l = [1, 2]
    p = UnsafeProxy(l)
    assert p[0] == 1
    assert p[1] == 2

    for item in p:
        assert isinstance(item, AnsibleUnsafe)

    assert isinstance(p, list)

    # Test tuple is

# Generated at 2022-06-21 09:08:57.998646
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    '''UnsafeProxy test case'''
    assert isinstance(UnsafeProxy('UnsafeProxy'), AnsibleUnsafeText)

# Generated at 2022-06-21 09:09:03.425238
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(None), type(None))
    assert isinstance(to_unsafe_text(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text('foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(bytes('foo')), AnsibleUnsafeText)