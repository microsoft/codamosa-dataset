

# Generated at 2022-06-21 09:06:27.298932
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    alphabets = 'abcdefghijklmnopqrstuvwxyz'
    string = AnsibleUnsafeText(alphabets)
    binary = string.encode('utf-8')
    assert isinstance(binary, AnsibleUnsafeBytes), "Object returned by encode must be unicode"
    assert binary.decode('utf-8') == string, "Object returned by encode must be AnsibleUnsafeText"



# Generated at 2022-06-21 09:06:35.896953
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert not isinstance(UnsafeProxy('hello'), AnsibleUnsafe)

    assert isinstance(UnsafeProxy(b'hello'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(b'hello', errors='surrogate_or_strict'), AnsibleUnsafeBytes)

    assert isinstance(UnsafeProxy(u'hello'), AnsibleUnsafeText)

    assert isinstance(UnsafeProxy(NativeJinjaText('hello')), NativeJinjaUnsafeText)
    assert isinstance(UnsafeProxy(NativeJinjaText(u'hello')), NativeJinjaUnsafeText)


# Generated at 2022-06-21 09:06:41.095829
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    input_str = 'a'
    native_jinja_unsafe_text = NativeJinjaUnsafeText(input_str)
    assert input_str == native_jinja_unsafe_text
    assert isinstance(native_jinja_unsafe_text, NativeJinjaUnsafeText)

# Generated at 2022-06-21 09:06:44.952711
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    x = UnsafeProxy('foo')
    assert x == 'foo'
    assert isinstance(x, AnsibleUnsafeText)

    b = UnsafeProxy(b'foo')
    assert b == 'foo'
    assert isinstance(b, AnsibleUnsafeText)

    u = UnsafeProxy(u'foo')
    assert u == 'foo'
    assert isinstance(u, AnsibleUnsafeText)



# Generated at 2022-06-21 09:06:49.812036
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    t = NativeJinjaUnsafeText('test value')
    assert t.__UNSAFE__ == True
    assert isinstance(t, NativeJinjaText)
    assert t.value == 'test value'
    assert t.__dict__ == NativeJinjaText('test value').__dict__

# Unit tests for constructors of class AnsibleUnsafeBytes and AnsibleUnsafeText

# Generated at 2022-06-21 09:07:00.428886
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert not UnsafeProxy("foo") is AnsibleUnsafeText("foo")
    assert not UnsafeProxy("foo") is AnsibleUnsafeBytes(b"foo")

    assert not UnsafeProxy(None) is None
    assert not UnsafeProxy(True) is True
    assert not UnsafeProxy(False) is False
    assert not UnsafeProxy(1) == 1
    assert not UnsafeProxy(1.1) == 1.1

    assert UnsafeProxy(AnsibleUnsafeText("foo")) is AnsibleUnsafeText("foo")
    assert UnsafeProxy(AnsibleUnsafeBytes("foo")) is AnsibleUnsafeBytes("foo")
    assert UnsafeProxy("foo") is not AnsibleUnsafeText("foo")
    assert UnsafeProxy("foo") is not AnsibleUnsafeBytes("foo")

# Generated at 2022-06-21 09:07:12.718138
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    def test_runner(module):
        # Test with different objects and types
        data = [None, 1234, u"\N{SNOWMAN}", "1234", b"1234", sys.maxsize + 1, 2 ** 64 + 1, u"\U0001F620", b"\xf0\x9f\x98\xa0"]
        for d in data:
            module.exit_json(ansible_facts=dict(test_data=d))

    def get_result(data):
        m = AnsibleModule(
            argument_spec=dict(
                test_data=dict(required=True, type='str'),
            )
        )
        test_runner(m)
        return m.params['test_data']

    expected

# Generated at 2022-06-21 09:07:19.611193
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy('test').__UNSAFE__ is True
    assert UnsafeProxy(b'test').__UNSAFE__ is True
    assert UnsafeProxy(u'test').__UNSAFE__ is True
    assert UnsafeProxy(AnsibleUnsafeText('test')).__UNSAFE__ is True
    assert UnsafeProxy(AnsibleUnsafeBytes(b'test')).__UNSAFE__ is True
    assert UnsafeProxy(NativeJinjaUnsafeText('test')).__UNSAFE__ is True

# Generated at 2022-06-21 09:07:22.372698
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    test_obj = AnsibleUnsafe()
    assert(test_obj.__UNSAFE__ == True)


# Generated at 2022-06-21 09:07:32.631554
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # test method decode, it returns an AnsibleUnsafeText
    import sys
    if sys.version_info[0] < 3:
        bytestr = b'\xcf\x85\xce\xb1\xcf\x86\xce\xb6\xcf\x81'
        b = AnsibleUnsafeBytes(bytestr)
        t = b.decode('utf-8')
        assert t.startswith(u'\u03a5\u03b1\u03c6\u03b6\u03c1')
        assert isinstance(t, AnsibleUnsafeText)