

# Generated at 2022-06-21 09:06:25.747192
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():

    bytestr = 'bytestring'
    ansibytes = AnsibleUnsafeBytes(bytestr)

    assert isinstance(ansibytes, AnsibleUnsafeBytes)
    assert isinstance(ansibytes, AnsibleUnsafe)
    assert ansibytes.decode() == 'bytestring'
    assert isinstance(ansibytes.decode(), AnsibleUnsafeText)
    assert isinstance(ansibytes.decode(), AnsibleUnsafe)


# Generated at 2022-06-21 09:06:34.857646
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from six.moves.builtins import unicode

    # Test with a number
    assert type(UnsafeProxy(5)) == int
    # Test with a string
    assert isinstance(UnsafeProxy('hello world'), AnsibleUnsafeText)
    # Test with a list
    assert isinstance(UnsafeProxy([1, 2, 3]), list)
    assert isinstance(UnsafeProxy([1, 2, 'hello', [1, 2, 3], {'a': 'b', 'c': 2}]), list)
    # Test with a dict
    assert isinstance(UnsafeProxy({'a': 'b', 'c': 2}), dict)
    assert isinstance(UnsafeProxy({'a': 'b', 'c': 2}), dict)

# Generated at 2022-06-21 09:06:36.585877
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(b"foo", AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:06:40.571324
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    import pdb; pdb.set_trace()
    unsafe = AnsibleUnsafeText("unsafe")
    result =  unsafe.encode("utf-8")
    assert(result == "unsafe")

# Generated at 2022-06-21 09:06:50.362806
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY3, PY2
    from ansible.module_utils._text import native, to_bytes

    if PY2:
        test_string = u'example\xac\u1234\u20ac\U00008000'
        expected_bytes = 'example\xc2\xac\xe1\x88\xb4\xe2\x82\xac\xed\xa0\x80\xed\xbd\x80'
    else:
        test_string = 'example\xac\u1234\u20ac\U00008000'
        expected_bytes = 'example\xac\xe1\x88\xb4\xe2\x82\xac\xed\xa0\x80\xed\xbd\x80'


# Generated at 2022-06-21 09:06:52.413840
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    cls = AnsibleUnsafe()
    assert isinstance(cls, object)



# Generated at 2022-06-21 09:06:57.738919
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.utils.unsafe_proxy import (
        NativeJinjaUnsafeText,
        AnsibleUnsafeText,
    )

    njut = NativeJinjaUnsafeText('hello')
    assert isinstance(njut, NativeJinjaUnsafeText)
    assert isinstance(njut, AnsibleUnsafeText)

# Generated at 2022-06-21 09:07:05.225775
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():

    # AnsibleModule
    module = UnsafeProxy('{}')
    assert isinstance(module, text_type)
    assert isinstance(module, AnsibleUnsafe)
    assert module == '{}'

    # JinjaStrictUndefined
    from ansible.template import JinjaStrictUndefined
    js = UnsafeProxy(JinjaStrictUndefined('', optional=True))
    assert isinstance(js, JinjaStrictUndefined)
    assert not js



# Generated at 2022-06-21 09:07:13.282507
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from jinja2.sandbox import SandboxedEnvironment

    env = SandboxedEnvironment()
    txt = "{% raw %}<script>console.log('hi')</script>{% endraw %}"
    template = env.from_string(txt)
    unsafe_text = NativeJinjaUnsafeText(template.render())
    assert isinstance(unsafe_text, NativeJinjaUnsafeText)


if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-21 09:07:16.546706
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    def fail_AnsibleUnsafe():
        return AnsibleUnsafe()

    try:
        fail_AnsibleUnsafe()
    except TypeError:
        # Expected
        pass


# Generated at 2022-06-21 09:07:20.127565
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    rv = to_unsafe_text("unicode是")

    assert rv == u"unicode是"

# Generated at 2022-06-21 09:07:33.152526
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.module_utils.six import PY2

    if PY2:
        safe_str = u"ěščřžýáíéúůťďňžý"
    else:
        safe_str = "ěščřžýáíéúůťďňžý"

    input_str = safe_str.encode('utf-8')
    assert to_unsafe_bytes(input_str) == input_str

    input_list = [input_str, safe_str, b"abc", "abc", ["abc", 1], "abc"]

# Generated at 2022-06-21 09:07:37.430946
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('foo') == 'foo'
    assert to_unsafe_bytes('foo') != 'bar'
    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeText)


# Generated at 2022-06-21 09:07:39.221284
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe()

# Generated at 2022-06-21 09:07:45.633496
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes(b"abc"), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(123), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u"abc"), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes([1,2,3]), list)
    assert isinstance(to_unsafe_bytes({"a": 1}), dict)


# Generated at 2022-06-21 09:07:56.682901
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils import basic
    import collections
    import copy
    import operator
    import random
    import string

    random.seed()

    def random_string(length):
        return "".join(random.choice(string.ascii_letters) for _ in range(length))

    def random_bytes(length):
        return "".join(random.choice(string.ascii_letters) for _ in range(length)).encode('utf-8')

    def random_generator(length):
        for _ in range(length):
            yield random.choice(string.ascii_letters)

    def random_iterable(length):
        return (random.choice(string.ascii_letters) for _ in range(length))


# Generated at 2022-06-21 09:07:59.708424
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes(b"some bytes") == b"some bytes"
    assert isinstance(AnsibleUnsafeBytes(b"some bytes"), binary_type)
    assert isinstance(AnsibleUnsafeBytes(b"some bytes"), AnsibleUnsafe)


# Generated at 2022-06-21 09:08:05.449667
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.compat.tests import unittest

    class TestToUnsafeBytes(unittest.TestCase):

        def test_binary(self):
            self.assertTrue(isinstance(to_unsafe_bytes(b'test string'), AnsibleUnsafeBytes))

        def test_plain_string(self):
            self.assertTrue(isinstance(to_unsafe_bytes('test string'), AnsibleUnsafeBytes))

        def test_unicode(self):
            self.assertTrue(isinstance(to_unsafe_bytes(u'test string'), AnsibleUnsafeBytes))

        def test_safe_bytes(self):
            self.assertTrue(isinstance(to_unsafe_bytes(to_unsafe_bytes(b"test string")), AnsibleUnsafeBytes))


# Generated at 2022-06-21 09:08:09.174476
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    class A: pass
    assert(not hasattr(A(), '__UNSAFE__'))
    assert(not hasattr(UnsafeProxy(A()), '__UNSAFE__'))
    assert(hasattr(UnsafeProxy(b'abc'), '__UNSAFE__'))


# Generated at 2022-06-21 09:08:16.523603
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.utils.display import Display
    display = Display()
    display.deprecated('test_to_unsafe_text', '2.13', collection_name='ansible.module_utils.basic')
    assert isinstance(to_unsafe_text('foo'), text_type), "to_unsafe_text() should return a text type"
    assert isinstance(to_unsafe_text(b'foo'), text_type), "to_unsafe_text() should return a text type"
    assert isinstance(to_unsafe_text(to_unsafe_text(b'foo')), text_type), "to_unsafe_text() should return a text type"

# Generated at 2022-06-21 09:08:20.728346
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert NativeJinjaUnsafeText(AnsibleUnsafeText(u'123456\u2603')) == u'123456\u2603'

# Generated at 2022-06-21 09:08:28.279588
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import ensure_text, ensure_bytes
    from ansible.module_utils.common.collections import is_sequence

    # List of all supported types
    class Type(object):
        def __str__(self):
            return type(self).__name__
        def __repr__(self):
            return str(self)

    class Unicode(UnicodeObject, Type): pass
    class Bytes(BytesObject, Type): pass
    class StringType(StringObject, Type): pass
    class IntegerType(IntegerObject, Type): pass
    class FloatType(FloatObject, Type): pass
    class ComplexType(ComplexObject, Type): pass
    class BooleanType(BooleanObject, Type): pass
    class ListType(ListObject, Type): pass
    class DictionaryType(DictionaryObject, Type): pass

# Generated at 2022-06-21 09:08:31.687714
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    text = AnsibleUnsafeText('Ansible Unsafe Text')
    assert isinstance(text.encode(), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:08:33.530799
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    data = "test"
    x = AnsibleUnsafeBytes(data)
    assert isinstance(x, binary_type)
    assert x.decode() == "test"
    assert isinstance(x.decode(), AnsibleUnsafeText)


# Generated at 2022-06-21 09:08:35.461311
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    a = AnsibleUnsafe()
    assert a.__UNSAFE__ is True

# Generated at 2022-06-21 09:08:40.306469
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    unsafe_bytes = to_unsafe_bytes('foo')
    assert(isinstance(unsafe_bytes, AnsibleUnsafeBytes))
    assert(unsafe_bytes == 'foo')
    assert(isinstance(unsafe_bytes.decode(), AnsibleUnsafeText))
    assert(isinstance(unsafe_bytes.decode().encode(), AnsibleUnsafeBytes))
    assert(wrap_var(unsafe_bytes) is unsafe_bytes)


# Generated at 2022-06-21 09:08:43.151774
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText('test').encode(), AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:08:48.011397
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    obj = AnsibleUnsafeText('test')
    assert isinstance(obj, AnsibleUnsafeText)
    assert isinstance(obj, binary_type)
    assert isinstance(obj, text_type)
    assert isinstance(obj, AnsibleUnsafe)


# Generated at 2022-06-21 09:08:51.247850
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    ansible_unsafe_bytes = AnsibleUnsafeBytes(b'AnsibleUnsafeBytes')
    assert isinstance(ansible_unsafe_bytes, AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:08:54.595364
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    NativeJinjaUnsafeText()
    print('success')


if __name__ == '__main__':
    test_NativeJinjaUnsafeText()

# Generated at 2022-06-21 09:09:07.367787
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # Test a non-empty bytes object
    bs = b"some text"
    ub = AnsibleUnsafeBytes(bs)
    assert ub == bs

    # Test empty bytes
    bs = b""
    ub = AnsibleUnsafeBytes(bs)
    assert ub == bs

    # Test a non-empty unicode string
    s = u"some text"
    ub = AnsibleUnsafeBytes(s)
    assert ub == b"some text"

    # Test empty unicode string
    s = u""
    ub = AnsibleUnsafeBytes(s)
    assert ub == b""

    # Test ascii unicode string
    s = u"abc123"
    ub = AnsibleUnsafeBytes(s)
    assert ub == b"abc123"

    # Test bytes string with non-ascii characters

# Generated at 2022-06-21 09:09:10.621223
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    a_unsafe_bytes = AnsibleUnsafeBytes("test unsafe bytes")
    assert isinstance(a_unsafe_bytes, AnsibleUnsafeBytes)
    assert isinstance(a_unsafe_bytes, binary_type)
    assert isinstance(a_unsafe_bytes, AnsibleUnsafe)


# Generated at 2022-06-21 09:09:13.546456
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    foo = b'foo'
    foo_u = AnsibleUnsafeBytes(foo)
    assert foo == foo_u


# Generated at 2022-06-21 09:09:16.050846
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    UnsafeProxy(AnsibleUnsafeBytes)
    UnsafeProxy(AnsibleUnsafeText)

# Generated at 2022-06-21 09:09:26.360480
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(42) == 42
    assert isinstance(wrap_var('42'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'42'), AnsibleUnsafeBytes)
    assert wrap_var(b'42') == b'42'
    assert isinstance(wrap_var(NativeJinjaText('42')), NativeJinjaUnsafeText)
    assert isinstance(wrap_var({'42': 'forty-two'}), dict)
    assert isinstance(wrap_var({'42': 'forty-two'}).get('42'), AnsibleUnsafeText)
    assert isinstance(wrap_var(('42',)), tuple)
    assert isinstance(wrap_var(('42',)).__getitem__(0), AnsibleUnsafeText)

# Generated at 2022-06-21 09:09:28.041730
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
  assert AnsibleUnsafe().__UNSAFE__


# Generated at 2022-06-21 09:09:38.080559
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes(b'a string') == b'a string'
    assert AnsibleUnsafeBytes(u'a string').encode('utf-8') == b'a string'
    assert AnsibleUnsafeBytes(b'a string').decode('utf-8') == 'a string'
    assert AnsibleUnsafeBytes(u'a string').decode('utf-8') == 'a string'
    assert type(AnsibleUnsafeBytes(b'a string')) == AnsibleUnsafeBytes
    assert type(AnsibleUnsafeBytes(u'a string')).__base__ == AnsibleUnsafeBytes

# Generated at 2022-06-21 09:09:39.039282
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    x = NativeJinjaUnsafeText("asd")

# Generated at 2022-06-21 09:09:42.134318
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    b = NativeJinjaUnsafeText("b")
    assert b.__UNSAFE__ is True and type(b) is NativeJinjaUnsafeText

# Generated at 2022-06-21 09:09:43.995283
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    t = AnsibleUnsafeText()
    print(t)
