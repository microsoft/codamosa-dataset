

# Generated at 2022-06-21 09:06:29.866287
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    '''
    Unit test for method __new__ of class UnsafeProxy
    '''
    import sys
    import os
    import pytest
    hostname = os.uname()[1]
    systype = os.uname()[0]
    sysarch = os.uname()[4]
    if ( systype == 'Linux' ) and ( sysarch == 'x86_64' ):
        if hostname == 'build01':
            pytest.skip('Test cannot be run on build server')
    elif ( systype == 'Linux' ) and ( sysarch == 'aarch64' ):
        if hostname == 'build02':
            pytest.skip('Test cannot be run on build server')

# Generated at 2022-06-21 09:06:42.046148
# Unit test for function wrap_var
def test_wrap_var():
    import pytest
    import tests.utils

    v_list_list = [[1, 2, 3], [4, 5, 6]]
    v_list_list_wrap = [[wrap_var(1), wrap_var(2), wrap_var(3)], [wrap_var(4), wrap_var(5), wrap_var(6)]]
    v_list_list_dict = [[wrap_var(d) for d in l] for l in v_list_list]
    assert wrap_var(v_list_list) == v_list_list_dict

    v_list_dict_wrap = [wrap_var(d) for d in v_list_list]
    with pytest.raises(AssertionError):
        assert v_list_list_wrap == v_list_dict_wrap


# Generated at 2022-06-21 09:06:51.417834
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(u'You are seeing this'), AnsibleUnsafeText)
    assert to_unsafe_text(u'You are seeing this') == u'You are seeing this'
    assert isinstance(to_unsafe_text(b'You are seeing this'), AnsibleUnsafeText)
    assert to_unsafe_text(b'You are seeing this') == u'You are seeing this'

    # See https://github.com/ansible/ansible/issues/40137
    # "to_unsafe_text should explicitly convert strings to unicode first"
    # Make sure that we have explicitly converted strings to Unicode before
    # we wrap them in AnsibleUnsafeText.  This also helps ensure that we
    # catch any implicit conversions that might happen in the future.

# Generated at 2022-06-21 09:06:54.945163
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    var_string = 'string'
    var_string_unsafe = NativeJinjaUnsafeText(var_string)

# Generated at 2022-06-21 09:06:59.128132
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    """
    This unit test checks the new object returned by the __new__ method of class UnsafeProxy.
    The expected result is an instance of class AnsibleUnsafeText, which is a subclass of AnsibleUnsafe class.
    """
    assert isinstance(UnsafeProxy('test'), AnsibleUnsafeText)

# Generated at 2022-06-21 09:07:03.041591
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    unsafe_bytes = AnsibleUnsafeBytes(b'foo')
    assert isinstance(unsafe_bytes.decode(), AnsibleUnsafeText), "Expected AnsibleUnsafeText type"


# Generated at 2022-06-21 09:07:07.042569
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText('asdf').encode('utf-8'), binary_type), "type ok"
    assert isinstance(AnsibleUnsafeText('asdf').encode('utf-8'), AnsibleUnsafeBytes), "context ok"
    assert AnsibleUnsafeText('asdf').encode('utf-8') == b"asdf", "value ok"


# Generated at 2022-06-21 09:07:10.124265
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    import jinja2
    template = NativeJinjaUnsafeText('Foo {{ name }}')
    assert template.render(name='Bob') == 'Foo Bob'
    assert isinstance(template, NativeJinjaUnsafeText)
    assert isinstance(template, jinja2.Template)
    assert isinstance(template, text_type)


# Unit tests for wrap_var

# Generated at 2022-06-21 09:07:18.451452
# Unit test for function wrap_var
def test_wrap_var():
    # Test on bytes
    my_input = b"input as bytes"
    assert isinstance(wrap_var(my_input), AnsibleUnsafeBytes)

    # Test on text
    my_input = u"input as text"
    assert isinstance(wrap_var(my_input), AnsibleUnsafeText)

    # Double wrap
    my_input = u"input as text"
    assert isinstance(wrap_var(wrap_var(my_input)), AnsibleUnsafeText)

    # Test on integer
    my_input = 1
    assert wrap_var(my_input) == 1
    assert isinstance(wrap_var(my_input), int)

    # Test on tuple
    my_input = (u"input as text", )
    assert isinstance(wrap_var(my_input), tuple)
    assert isinstance

# Generated at 2022-06-21 09:07:22.100425
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    result = AnsibleUnsafeBytes(b'hello world').decode('utf-8')
    assert isinstance(result, AnsibleUnsafeText)
    assert result == AnsibleUnsafeText('hello world')


# Generated at 2022-06-21 09:07:33.104966
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # Test unicode to bytes
    assert(isinstance(AnsibleUnsafeBytes(b'a').decode('ascii'), AnsibleUnsafeBytes))
    assert(isinstance(AnsibleUnsafeBytes(b'a').decode(), AnsibleUnsafeText))

    # Test bytes to text
    assert(isinstance(AnsibleUnsafeText(u'a').encode('ascii'), AnsibleUnsafeText))
    assert(isinstance(AnsibleUnsafeText(u'a').encode(), AnsibleUnsafeBytes))


# Generated at 2022-06-21 09:07:41.132998
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy('test'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'test'), AnsibleUnsafeBytes)
    assert UnsafeProxy('test') == 'test'
    assert UnsafeProxy(b'test') == b'test'
    assert UnsafeProxy(AnsibleUnsafeText('test')) == 'test'
    assert UnsafeProxy(AnsibleUnsafeBytes(b'test')) == b'test'



# Generated at 2022-06-21 09:07:49.093919
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():

    ##
    # Test if the function correctly wrap an unsafe object.
    #
    unsafe_string = "Unsafe string"
    proxy_unsafe_string = UnsafeProxy(unsafe_string)
    assert isinstance(proxy_unsafe_string, AnsibleUnsafeText)

    ##
    # Test if the function correctly wrap a safe object.
    #
    unsafe_string = "Unsafe string"
    proxy_safe_string = UnsafeProxy(unsafe_string)
    assert isinstance(proxy_safe_string, AnsibleUnsafeText)


# Generated at 2022-06-21 09:07:56.750894
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy(""), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b""), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(u""), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(None), type(None))
    assert isinstance(UnsafeProxy(AnsibleUnsafeText("")), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes("")), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:07:58.250531
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    test = AnsibleUnsafe()
    assert not test.__UNSAFE__



# Generated at 2022-06-21 09:08:02.927362
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    test_text = 'Test Encode'
    ansible_unsafe_text = AnsibleUnsafeText(test_text)
    result_bytes = ansible_unsafe_text.encode()
    assert type(result_bytes) == AnsibleUnsafeBytes
    assert result_bytes.decode() == test_text


# Generated at 2022-06-21 09:08:07.373560
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    test_string = 'test text'
    unicode_string = '{"test": "text", "test2": "text2"}'
    unicode_result = '{"test": "text", "test2": "text2"}'
    NativeJinjaUnsafeText(test_string)
    NativeJinjaUnsafeText(unicode_string)
    NativeJinjaUnsafeText(unicode_result)

# Generated at 2022-06-21 09:08:10.108325
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    u = AnsibleUnsafeBytes(b'this is an AnsibleUnsafeBytes')
    assert isinstance(u, AnsibleUnsafeBytes)
    assert isinstance(u, AnsibleUnsafe)
    assert isinstance(u, binary_type)


# Generated at 2022-06-21 09:08:12.428764
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    up = UnsafeProxy('ansible')
    assert(up == 'ansible')
    up = UnsafeProxy(u'ansible')
    assert(up == 'ansible')

# Generated at 2022-06-21 09:08:18.074984
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    obj1 = AnsibleUnsafeBytes('\x00\x01\x02')
    obj2 = AnsibleUnsafeBytes(obj1)
    assert obj1 == obj2


# Generated at 2022-06-21 09:08:27.751061
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    try:
        unsafe_var = AnsibleUnsafeText(u'this is unsafe')
        unsafe_var.test
        raise AssertionError
    except Exception:
        # we expect an exception
        pass

    assert u'this is unsafe' == unsafe_var
    assert b'this is unsafe' == unsafe_var.encode()

    try:
        unsafe_var = AnsibleUnsafeBytes(b'this is unsafe')
        unsafe_var.test
        raise AssertionError
    except Exception:
        # we expect an exception
        pass

    assert u'this is unsafe' == unsafe_var.decode()
    assert b'this is unsafe' == unsafe_var


# Generated at 2022-06-21 09:08:31.203687
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b'foo').decode(), AnsibleUnsafeText), "Unsafe bytes when decoded return unsafe text"

# Generated at 2022-06-21 09:08:34.700562
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert str(AnsibleUnsafe()) == '<ansible.module_utils.common.unsafe.AnsibleUnsafe object at 0x7f764fd9b710>'


# Generated at 2022-06-21 09:08:36.458973
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(b'abc'), AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:08:43.262874
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text('foo') == 'foo'
    assert to_unsafe_text(u'foo') == u'foo'
    assert isinstance(to_unsafe_text('foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'foo'), AnsibleUnsafeText)



# Generated at 2022-06-21 09:08:46.561620
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # Call constructor AnsibleUnsafeText
    unsafe_text1 = AnsibleUnsafeText("UnsafeText")
    assert(unsafe_text1 == "UnsafeText")



# Generated at 2022-06-21 09:08:49.285949
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b'foo').decode('utf-8'), AnsibleUnsafeText)


# Generated at 2022-06-21 09:08:52.202899
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    ansible_unsafe_text = AnsibleUnsafeText('UnsafeText')
    assert ansible_unsafe_text.encode() == AnsibleUnsafeBytes(b'UnsafeText')


# Generated at 2022-06-21 09:08:59.002392
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # test for AnsibleUnsafeText
    result = AnsibleUnsafeText("test")
    assert result == "test"
    assert isinstance(result, AnsibleUnsafeText)
    # test for AnsibleUnsafeBytes
    result = AnsibleUnsafeBytes("test")
    assert result == "test"
    assert isinstance(result, AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:09:00.610881
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    t = 'test'
    assert t == NativeJinjaUnsafeText(t)

# Generated at 2022-06-21 09:09:10.905249
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import types
    # Test safe conversion to bytes
    unsafe_bytes = to_unsafe_bytes(b"test")
    assert isinstance(unsafe_bytes, AnsibleUnsafeBytes)
    assert unsafe_bytes == b"test"
    # Test safe conversion to text
    unsafe_text = to_unsafe_text(u"test")
    assert isinstance(unsafe_text, AnsibleUnsafeText)
    assert unsafe_text == u"test"
    # Test safe conversion to text from bytes
    unsafe_text = to_unsafe_text(b"test")
    assert isinstance(unsafe_text, AnsibleUnsafeText)
    assert unsafe_text == b"test".decode('utf-8')
    # Test unsafe conversion to bytes

# Generated at 2022-06-21 09:09:15.176458
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    unsafe_text = AnsibleUnsafeText(to_text(b"test string", errors='surrogate_or_strict'))
    assert isinstance(unsafe_text.encode(), AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:09:21.483371
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    ansible_unsafe_bytes = AnsibleUnsafeBytes('สังขยา')
    print('AnsibleUnsafeBytes_decode')
    print('  assert:', type(ansible_unsafe_bytes.decode()).__name__ == 'AnsibleUnsafeText')


# Generated at 2022-06-21 09:09:29.100772
# Unit test for function wrap_var
def test_wrap_var():
    import ansible.module_utils.basic
    jinja_template = "{{ foo }}"
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={'foo': {'type': 'str', 'default': jinja_template}}
    )

    assert(isinstance(module.params['foo'], NativeJinjaText) and
           isinstance(UnsafeProxy(module.params['foo']), NativeJinjaUnsafeText))

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={'foo': {'type': 'str', 'default': jinja_template}},
        bypass_checks=True
    )

# Generated at 2022-06-21 09:09:33.065739
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    value = "value"
    obj = AnsibleUnsafeBytes(value)
    decoded_obj = obj.decode()
    assert(decoded_obj == AnsibleUnsafeText(value))


# Generated at 2022-06-21 09:09:34.592823
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    string = AnsibleUnsafeText("test string")
    assert string == "test string"
    assert isinstance(string, text_type)
    assert isinstance(string, AnsibleUnsafe)


# Generated at 2022-06-21 09:09:36.297659
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    string = 'Hello'
    test_string = NativeJinjaUnsafeText(string)
    assert isinstance(test_string, NativeJinjaUnsafeText) == True, "Unexpected result"


# Generated at 2022-06-21 09:09:44.538065
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Just test what happens with type conversion
    # converting to unicode:
    result = UnsafeProxy('UnsafeProxy')
    assert isinstance(result, AnsibleUnsafeText)

    # converting to bytes:
    result = UnsafeProxy('UnsafeProxy'.encode('utf-8'))
    assert isinstance(result, AnsibleUnsafeBytes)

    # Wrap a list of strings
    result = UnsafeProxy(['UnsafeProxy', 'UnsafeProxy'])
    for x in result:
        assert isinstance(x, AnsibleUnsafeText)

    # Wrap a list of bytes
    result = UnsafeProxy(['UnsafeProxy'.encode('utf-8'), 'UnsafeProxy'.encode('utf-8')])
    for x in result:
        assert isinstance(x, AnsibleUnsafeBytes)


# Unit test

# Generated at 2022-06-21 09:09:57.075407
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_text(b'\xe3\x80\x80') == to_unsafe_text(b'\xe3\x80\x80')
    assert to_text(u'\u3000') == to_unsafe_text(u'\u3000')
    assert to_text(u'\u3000', encoding='cp932') == to_unsafe_text(u'\u3000', encoding='cp932')
    assert to_text(u'\u3000', errors='surrogate_or_strict') == to_unsafe_text(u'\u3000', errors='surrogate_or_strict')
    assert to_text(u'\u3000', nonstring='simplerepr') == to_unsafe_text(u'\u3000', nonstring='simplerepr')
    assert to_

# Generated at 2022-06-21 09:10:01.787525
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert issubclass(AnsibleUnsafeText, AnsibleUnsafe)
    assert not issubclass(AnsibleUnsafeText, AnsibleUnsafeBytes)
    assert not issubclass(binary_type, AnsibleUnsafe)
    assert issubclass(AnsibleUnsafeBytes, AnsibleUnsafe)

# Generated at 2022-06-21 09:10:05.534629
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    aub = AnsibleUnsafeBytes('test')
    aub = aub.decode()
    assert isinstance(aub, AnsibleUnsafeText)


# Generated at 2022-06-21 09:10:06.463041
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert UnsafeProxy(None) is None



# Generated at 2022-06-21 09:10:08.703822
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import text_type
    b = to_unsafe_bytes("abc")
    assert isinstance(b, text_type)



# Generated at 2022-06-21 09:10:20.786435
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    import unittest
    import os
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    class TestAnsibleMethods(unittest.TestCase):
        '''testing UnsafeProxy'''

        def setUp(self):
            self.mocked_args = {
                'ANSIBLE_MODULE_ARGS': {
                    'arg1': 'foo',
                    'arg2': 'bar'
                }
            }


# Generated at 2022-06-21 09:10:27.507033
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    bytes_input = b'\x41\x53\x43\x49\x49\x20\x77\x68\x61\x74\x20\x79\x6f\x75\x20\x64\x69\x64\x20\x74\x68\x65\x72\x65\x3f'
    bytes_ouput = AnsibleUnsafeBytes(bytes_input).decode()
    assert bytes_input == bytes_ouput.encode()
    assert bytes_ouput.__UNSAFE__


# Generated at 2022-06-21 09:10:39.763517
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var({'1': 1}) == {'1': 1}
    assert type(wrap_var({'1': 1})) == dict
    assert wrap_var({'1': 1})['1'] == 1
    assert isinstance(wrap_var({'1': 1})['1'], int)

    assert wrap_var({'1': '1'}) == {'1': '1'}
    assert type(wrap_var({'1': '1'})) == dict
    assert wrap_var({'1': '1'})['1'] == '1'
    assert isinstance(wrap_var({'1': '1'})['1'], AnsibleUnsafeText)

    assert wrap_var(['1']) == ['1']
    assert type(wrap_var(['1'])) == list
    assert wrap_var

# Generated at 2022-06-21 09:10:46.097805
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_sequence
    # Python 3
    assert isinstance(wrap_var("abc".encode('utf-8')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var("abc"), AnsibleUnsafeText)
    assert isinstance(wrap_var(("abc",)), tuple)
    assert isinstance(wrap_var(("abc",)), tuple)
    assert isinstance(wrap_var([("abc",)]), list)
    assert isinstance(wrap_var({"a": "b"}), dict)
    assert is_sequence(wrap_var(("abc",)))
    assert is_sequence(wrap_var(["abc"]))

    # Python 2
    import sys

# Generated at 2022-06-21 09:10:48.730953
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert(AnsibleUnsafeText("text").encode() == b"text")



# Generated at 2022-06-21 09:10:52.049484
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    new_string = to_unsafe_text('test')
    assert type(new_string) == AnsibleUnsafeText
    assert '__UNSAFE__' in dir(new_string)

# Generated at 2022-06-21 09:10:55.395625
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy('a string'), AnsibleUnsafeText)



# Generated at 2022-06-21 09:11:07.700238
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('1234') == b'1234'
    assert to_unsafe_bytes('1234', errors='strict') == b'1234'
    assert to_unsafe_bytes(123) == b'123'
    assert to_unsafe_bytes([1, 2, 3]) == [1, 2, 3]
    assert to_unsafe_bytes((1, 2, 3)) == (1, 2, 3)
    assert to_unsafe_bytes(b'1234') == b'1234'
    assert to_unsafe_bytes(u'1234') == b'1234'
    assert isinstance(to_unsafe_bytes(u'1234'), binary_type)
    assert to_unsafe_bytes(u'1234', errors='strict', encoding='utf-8') == b

# Generated at 2022-06-21 09:11:10.691569
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    _AnsibleUnsafeBytesObject = AnsibleUnsafeBytes(b"Test")
    assert type(_AnsibleUnsafeBytesObject.decode()) is AnsibleUnsafeText
    assert _AnsibleUnsafeBytesObject.decode() == u"Test"


# Generated at 2022-06-21 09:11:16.255149
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    val = 'hello world'
    bval = to_unsafe_bytes(val)
    assert isinstance(bval, AnsibleUnsafeBytes)
    assert bval == val
    assert bval.__UNSAFE__ == True
    assert isinstance(bval, binary_type)

# Generated at 2022-06-21 09:11:18.966251
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes(b"test"), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:11:20.492133
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    raw_bytes = to_bytes(u'\u2020', errors='surrogate_or_strict')
    unsafe_bytes = AnsibleUnsafeBytes(raw_bytes)
    assert(isinstance(unsafe_bytes, AnsibleUnsafe))


# Generated at 2022-06-21 09:11:22.671513
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    au = AnsibleUnsafeBytes('foo')
    dis = au.decode().encode()
    assert b'foo' == dis


# Generated at 2022-06-21 09:11:30.668981
# Unit test for constructor of class AnsibleUnsafeText

# Generated at 2022-06-21 09:11:34.386702
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # Tests for ``AnsibleUnsafeText.encode``
    t = AnsibleUnsafeText(to_text('foo', encoding='utf-8'))
    result = t.encode('utf-8')
    assert isinstance(result, AnsibleUnsafeBytes)
    assert result == to_bytes('foo')



# Generated at 2022-06-21 09:11:36.206061
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    unsafe = AnsibleUnsafe()
    assert unsafe.__UNSAFE__
    assert isinstance(unsafe, AnsibleUnsafe)


# Generated at 2022-06-21 09:11:45.795413
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.six import PY3

    assert isinstance(wrap_var('unsafe'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'bytes'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'bytes'.decode('utf-8')), AnsibleUnsafeText)

    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(False), type(False))
    assert isinstance(wrap_var(0), type(0))

# Generated at 2022-06-21 09:11:51.440063
# Unit test for function wrap_var
def test_wrap_var():
    test_strings = ('test message', u'test message', b'test message', b'\xe7\xbd\x91\xe7\xbb\x9c', u'\u7f51\u7edc')
    for s in test_strings:
        assert isinstance(wrap_var(s), AnsibleUnsafeText)

# Generated at 2022-06-21 09:11:53.047965
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert isinstance(AnsibleUnsafeBytes(b''), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeBytes(b''), AnsibleUnsafeBytes)
    AnsibleUnsafeText(to_unsafe_bytes(b''))

# Generated at 2022-06-21 09:11:57.545102
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    class A(unicode): pass
    class B(unicode): pass
    class C(unicode): pass

    srcs = [u'abc', A(u'abc'), [u'abc', A(u'abc')], {u'abc': A(u'abc')}]

    for s in srcs:
        assert isinstance(s, unicode)
        assert not isinstance(s, str)
        assert not isinstance(s, (A, B, C))

        b = to_unsafe_bytes(s, errors='strict')

        assert isinstance(b, str)
        assert not isinstance(b, unicode)
        assert not isinstance(b, (A, B, C))

        b = to_unsafe_bytes(s, errors='strict', nonstring='passthru')

        assert isinstance

# Generated at 2022-06-21 09:12:06.378617
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():

    class MockEncodingError(Exception):
        pass

    def mock_encode(self, *args, **kwargs):
        raise MockEncodingError('Test exception')

    class MockText(text_type):
        __UNSAFE__ = True

        # Monkey-patch to allow unit-testing exception handling
        encode = mock_encode

    # Create an unsafe string and call encode
    t = MockText('Test Encoding')
    with pytest.raises(MockEncodingError):
        t.encode('utf-8')

# Generated at 2022-06-21 09:12:11.801559
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from jinja2 import Markup
    str = Markup("<strong>Hello</strong>")
    assert type(str) == NativeJinjaText
    assert type(NativeJinjaUnsafeText(str)) == NativeJinjaUnsafeText
    assert NativeJinjaUnsafeText(str) == "<strong>Hello</strong>"

# Generated at 2022-06-21 09:12:13.465178
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    s = AnsibleUnsafe()
    assert s.__UNSAFE__


# Generated at 2022-06-21 09:12:18.871217
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    b_str = b"string\x01\x02\x12\x14"
    ansible_unsafe_bytes = AnsibleUnsafeBytes(b_str)
    assert ansible_unsafe_bytes == b_str


# Generated at 2022-06-21 09:12:21.594832
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    obj = UnsafeProxy("\xC3\xA9.txt")
    assert isinstance(obj, AnsibleUnsafeText)
    assert obj == u"\u00c3\u00a9.txt"
    assert obj == to_text("\xC3\xA9.txt")


# Unit tests for constructor of class AnsibleUnsafeBytes

# Generated at 2022-06-21 09:12:33.423894
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    # Test some expected types
    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeBytes(b"foo")) == AnsibleUnsafeBytes(b"foo")
    assert wrap_var(AnsibleUnsafeText(u"foo")) == AnsibleUnsafeText(u"foo")
    assert wrap_var(AnsibleUnsafeText(u"foo")) != AnsibleUnsafeBytes(b"foo")
    assert wrap_var(u"foo") == AnsibleUnsafeText(u"foo")
    assert wrap_var(b"foo") == AnsibleUnsafeBytes(b"foo")

# Generated at 2022-06-21 09:12:34.065253
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    pass

# Generated at 2022-06-21 09:12:42.511560
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    x = AnsibleUnsafeBytes(b'Hello World')
    assert(x.__UNSAFE__ == True)
    assert(type(x) == bytes)


# Generated at 2022-06-21 09:12:54.211832
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.basic import AnsibleModule

    print("Testing __new__ method of class UnsafeProxy")
    try:
        """
        Checking whether input that has type of AnsibleUnsafe is returned unchanged
        """
        ansibleunsafetext = AnsibleUnsafeText('ABCD')
        ansibleunsafebytes = AnsibleUnsafeBytes('EFGH')
        assert(ansibleunsafetext == UnsafeProxy(ansibleunsafetext))
        assert(ansibleunsafebytes == UnsafeProxy(ansibleunsafebytes))
    except Exception as e:
        module = AnsibleModule(argument_spec={})
        module.fail_json(msg=e)
    else:
        print('Test for UnsafeProxy.__new__ passed.')


# Generated at 2022-06-21 09:13:03.450390
# Unit test for function wrap_var
def test_wrap_var():

    ansible_unsafe_bytes = AnsibleUnsafeBytes(b"ansible unsafe bytes")
    assert wrap_var(ansible_unsafe_bytes) == ansible_unsafe_bytes

    ansible_unsafe_text = AnsibleUnsafeText(u"ansible unsafe text")
    assert wrap_var(ansible_unsafe_text) == ansible_unsafe_text

    ASCII_STRING = "test"
    assert wrap_var(ASCII_STRING) == AnsibleUnsafeText(to_text(ASCII_STRING, errors='surrogate_or_strict'))

    UNICODE_STRING = u"test"
    assert wrap_var(UNICODE_STRING) == AnsibleUnsafeText(UNICODE_STRING)

    BINARY_STRING = b"test"
   

# Generated at 2022-06-21 09:13:05.436875
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(1) == AnsibleUnsafeText(u'1')

# Generated at 2022-06-21 09:13:16.443454
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import string_types, binary_type, text_type
    from ansible.module_utils.common.collections import is_sequence

    # Test safe types
    assert wrap_var(None) is None
    assert wrap_var(1) is 1
    assert wrap_var(1.1) is 1.1

    # Test unsafe conversions
    assert isinstance(wrap_var(to_text(b'foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(to_bytes(u'foo')), AnsibleUnsafeBytes)

    # Test wrapping of dicts and conversion of unsafe inside dict

# Generated at 2022-06-21 09:13:28.070376
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils._text import to_text
    test_input_values = [
        (None, None),
        ('abc', b'abc'),
        (b'abc', b'abc'),
        (r'c:\windows', b'c:\\windows'),
        (r'c:\windows', b'c:\\windows'),
        (r'\\unc\path', b'\\\\unc\\path'),
        (r'\\unc\path', b'\\\\unc\\path'),
        ('\r\n', b'\r\n'),
        ('\r\n', b'\r\n'),
    ]
    for input_value, expected_output in test_input_values:
        result = to_unsafe_bytes(input_value)
        assert type(result) is AnsibleUnsafeBytes

# Generated at 2022-06-21 09:13:32.528821
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert type(NativeJinjaUnsafeText(to_bytes('foo'))) is NativeJinjaUnsafeText
    assert type(NativeJinjaUnsafeText(to_text('foo'))) is NativeJinjaUnsafeText

# Generated at 2022-06-21 09:13:43.739559
# Unit test for function to_unsafe_text
def test_to_unsafe_text():

    import os
    import sys
    import pwd
    import subprocess
    import shutil
    import traceback
    import json
    import sys
    import shlex
    import copy
    import collections
    import inspect

    import socket
    import time
    import string
    import base64
    import re

    import _ast

    import types
    import errno
    import datetime

    import fcntl

    import textwrap

    import unicodedata

    import logging
    import logging.handlers
    import tempfile
    from ansible import utils
    from ansible import errors
    from ansible.parsing.utils.yaml import from_yaml
    from ansible.parsing.utils.addresses import parse_address
    from ansible.utils.display import Display

# Generated at 2022-06-21 09:13:50.398347
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    import unittest
    import sys

    class TestAnsibleUnsafe(unittest.TestCase):
        def test_ansi_unsafe_bytes(self):
            data = b"This is a byte string"
            ansi_unsafe_bytes = AnsibleUnsafeBytes(data)
            self.assertEqual(b"This is a byte string", ansi_unsafe_bytes)

        def test_ansi_unsafe_text(self):
            data = "This is a unicode string"
            ansi_unsafe_text = AnsibleUnsafeText(data)
            self.assertEqual(u"This is a unicode string", ansi_unsafe_text)

    suite = unittest.TestLoader().loadTestsFromModule(TestAnsibleUnsafe())
    result = unittest.TextTest

# Generated at 2022-06-21 09:13:52.147747
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    a = AnsibleUnsafe()
    assert a.__UNSAFE__



# Generated at 2022-06-21 09:14:06.398609
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # GIVEN
    b = AnsibleUnsafeBytes('foo')
    # WHEN
    b_decode = b.decode()
    # THEN
    assert isinstance(b_decode, AnsibleUnsafeText) is True

# Generated at 2022-06-21 09:14:11.496021
# Unit test for function wrap_var
def test_wrap_var():
    for x in (None, True, False, 1, 1.0, ''):
        assert wrap_var(x) == x
    assert isinstance(wrap_var(u'foo'), text_type)
    assert isinstance(wrap_var(b'foo'), binary_type)
    assert wrap_var(b'foo').__UNSAFE__ == True
    assert wrap_var(u'foo').__UNSAFE__ == True
    assert wrap_var(UnsafeProxy(u'foo')).__UNSAFE__ == True
    assert wrap_var({}).__UNSAFE__ == True
    assert wrap_var({u'foo': b'foo'}).__UNSAFE__ == True
    assert wrap_var({u'foo': b'foo'})[u'foo'].__UNSAFE__ == True
    assert wrap_

# Generated at 2022-06-21 09:14:17.140552
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    obj = UnsafeProxy("")
    assert(isinstance(obj, AnsibleUnsafe))

    obj = UnsafeProxy(None)
    assert(isinstance(obj, AnsibleUnsafe))

    obj = UnsafeProxy(AnsibleUnsafeText(""))
    assert(isinstance(obj, AnsibleUnsafe))


# Generated at 2022-06-21 09:14:19.990137
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    ansible_unsafe_bytes = b'foo'
    ansible_unsafe_bytes = AnsibleUnsafeBytes(ansible_unsafe_bytes)
    assert isinstance(ansible_unsafe_bytes, binary_type)
    assert isinstance(ansible_unsafe_bytes, AnsibleUnsafe)


# Generated at 2022-06-21 09:14:21.745843
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text('\xc3\xa9'), AnsibleUnsafeText)



# Generated at 2022-06-21 09:14:28.310330
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    example_string = to_unsafe_bytes("Hello world")
    assert isinstance(example_string, binary_type)
    assert isinstance(example_string, AnsibleUnsafe)

    # This is an unfortunate name collision. I don't think we should remove it
    # because that would be backwards incompatible, but we should avoid
    # intentionally using it.
    assert to_unsafe_bytes("Hello world") == to_bytes("Hello world")


# Generated at 2022-06-21 09:14:32.901293
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    """
    Test the constructor of class UnsafeProxy.
    """
    # Create an UnsafeProxy object.
    test_obj = UnsafeProxy("test-string")

    if type(test_obj) is not AnsibleUnsafeText:
        raise Exception("UnsafeProxy should return an AnsibleUnsafeText object.")

# Generated at 2022-06-21 09:14:43.049847
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    uobj = UnsafeProxy('test')
    assert isinstance(uobj, AnsibleUnsafe)
    assert isinstance(uobj, AnsibleUnsafeText)
    assert not isinstance(uobj, AnsibleUnsafeBytes)
    assert uobj == 'test'
    assert (uobj + 'appended') == 'testappended'
    # The following is to make sure we are not converting the object
    # to a unicode object.
    assert isinstance(uobj, AnsibleUnsafeText)
    assert isinstance(uobj, AnsibleUnsafe)
    assert 'AnsibleUnsafe' in repr(uobj)
    assert 'AnsibleUnsafe' in str(uobj)



# Generated at 2022-06-21 09:14:45.885541
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    # Create an instance of class NativeJinjaUnsafeText
    t = NativeJinjaUnsafeText()
    # Verify that the object created is an instance of NativeJinjaUnsafeText
    assert isinstance(t, NativeJinjaUnsafeText)


# Generated at 2022-06-21 09:14:49.981963
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    test_str = '{{ inf }}'
    unrest_text = NativeJinjaUnsafeText(test_str)
    assert unrest_text == '{{ inf }}'
    assert unrest_text.__UNSAFE__ == True

# Generated at 2022-06-21 09:15:13.268256
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert isinstance(NativeJinjaUnsafeText("foo"), NativeJinjaUnsafeText)
    assert isinstance(NativeJinjaUnsafeText("bar{% if True %}baz{% endif %}"), NativeJinjaUnsafeText)

# Generated at 2022-06-21 09:15:25.208906
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert issubclass(AnsibleUnsafeText, object)
    assert issubclass(AnsibleUnsafeText, text_type)
    assert issubclass(AnsibleUnsafeText, AnsibleUnsafe)
    assert AnsibleUnsafeText.__name__ == "AnsibleUnsafeText"
    assert AnsibleUnsafeText.__UNSAFE__ == True
    assert isinstance(AnsibleUnsafeText, type)
    assert isinstance(AnsibleUnsafeText('hello'), AnsibleUnsafeText)
    assert issubclass(NativeJinjaUnsafeText, object)
    assert issubclass(NativeJinjaUnsafeText, text_type)
    assert issubclass(NativeJinjaUnsafeText, NativeJinjaText)

# Generated at 2022-06-21 09:15:32.351908
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # class AnsibleUnsafeText
    # def encode(self, *args, **kwargs):
    #     """Wrapper method to ensure type conversions maintain unsafe context"""
    #     return AnsibleUnsafeBytes(super(AnsibleUnsafeText, self).encode(*args, **kwargs))
    t = "abc"
    assert(isinstance(t, text_type))
    a = AnsibleUnsafeText(t)
    assert(isinstance(a, text_type))
    assert(isinstance(a, AnsibleUnsafeText))
    b = a.encode('ascii')
    assert(isinstance(b, binary_type))
    assert(isinstance(b, AnsibleUnsafeBytes))


# Generated at 2022-06-21 09:15:45.329208
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(False), bool)
    assert isinstance(wrap_var(1), int)
    assert isinstance(wrap_var({}), dict)
    assert isinstance(wrap_var([]), list)
    assert isinstance(wrap_var(set()), set)
    assert isinstance(wrap_var(b'my string'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'my string'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'my string'), AnsibleUnsafeText)
    assert isinstance(wrap_var(NativeJinjaText(b"{{1}}")), NativeJinjaUnsafeText)


# Generated at 2022-06-21 09:15:52.100048
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    """
    The __new__() method of UnsafeProxy is to ensure type conversions.
    Both AnsibleUnsafeText and AnsibleUnsafeBytes are derived from str and bytes, so both of them are instances of
    AnsibleUnsafe, and UnsafeProxy.__new__() will returns the input directly.
    """
    p = UnsafeProxy(AnsibleUnsafeText('test str'))
    assert isinstance(p, AnsibleUnsafeText)
    p = UnsafeProxy(AnsibleUnsafeBytes('test str'.encode('utf-8')))
    assert isinstance(p, AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:15:53.510473
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    t=NativeJinjaUnsafeText('hello world')
    assert  'hello world' == t



# Generated at 2022-06-21 09:15:56.853568
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    test_obj = AnsibleUnsafeBytes('Abc')
    assert_result = ansible_unsafe_bytes(test_obj)
    assert_obj = b'Abc'
    assert assert_result == assert_obj


# Generated at 2022-06-21 09:16:06.549172
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert(isinstance(UnsafeProxy(b'foo'), AnsibleUnsafeBytes))
    assert(isinstance(UnsafeProxy(b'foo'.decode('utf-8')), AnsibleUnsafeText))
    assert(isinstance(UnsafeProxy(b'foo'), AnsibleUnsafeBytes))
    assert(isinstance(UnsafeProxy(b'foo'.decode('utf-8')), AnsibleUnsafeText))
    assert(isinstance(UnsafeProxy(b'foo'.decode('utf-8').decode('utf-8')), AnsibleUnsafeText))
    assert(isinstance(UnsafeProxy(b'foo'.decode('utf-8').decode('utf-8')), AnsibleUnsafeText))

# Generated at 2022-06-21 09:16:08.899570
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    ansibleUnsafeText = AnsibleUnsafeText()
    assert ansibleUnsafeText.__class__.__UNSAFE__ == True


# Generated at 2022-06-21 09:16:10.995591
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy("any string"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b"any string"), AnsibleUnsafeBytes)

