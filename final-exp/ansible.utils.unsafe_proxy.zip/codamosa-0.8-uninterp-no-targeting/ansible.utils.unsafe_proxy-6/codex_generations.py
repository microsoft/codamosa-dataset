

# Generated at 2022-06-21 09:06:33.008635
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    val = AnsibleUnsafeBytes(b'\xc3\x9e')
    assert isinstance(val, AnsibleUnsafeBytes)
    assert isinstance(val, binary_type)
    assert not isinstance(val, AnsibleUnsafeText)
    assert not isinstance(val, text_type)

    val2 = val.decode('utf-8')
    assert isinstance(val2, AnsibleUnsafeText)
    assert isinstance(val2, text_type)
    assert not isinstance(val2, AnsibleUnsafeBytes)
    assert not isinstance(val2, binary_type)

    val3 = val2.encode('utf-8')
    assert isinstance(val3, AnsibleUnsafeBytes)
    assert isinstance(val3, binary_type)

# Generated at 2022-06-21 09:06:45.125556
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():

    x = AnsibleUnsafeBytes()
    assert(isinstance(x, binary_type))
    assert(isinstance(x, AnsibleUnsafe))
    assert(len(x) == 0)

    x = AnsibleUnsafeBytes(b"foobar")
    assert(isinstance(x, binary_type))
    assert(isinstance(x, AnsibleUnsafe))
    assert(x == b"foobar")

    y = x.decode()
    assert(isinstance(y, text_type))
    assert(isinstance(y, AnsibleUnsafe))
    assert(y == "foobar")

    x = AnsibleUnsafeBytes(u"foobar")
    assert(isinstance(x, binary_type))
    assert(isinstance(x, AnsibleUnsafe))
    assert(x == b"foobar")

# Generated at 2022-06-21 09:06:48.999109
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    """Unit test for constructor of class AnsibleUnsafeText"""
    assert AnsibleUnsafeText(u"123").__class__.__name__ == 'AnsibleUnsafeText'
    assert AnsibleUnsafeText('').__class__.__name__ == 'AnsibleUnsafeText'


# Generated at 2022-06-21 09:06:54.944893
# Unit test for function wrap_var
def test_wrap_var():
    x = {'a': {'a': 'a', 'b': 'b'}, 'b': [1, 2, 3]}
    y = wrap_var(x)
    assert y['a']['b'] == AnsibleUnsafeText('b')
    assert y['a']['a'] == AnsibleUnsafeText('a')
    assert y['b'][1] == 2

# Generated at 2022-06-21 09:06:57.318048
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    expects = AnsibleUnsafeBytes(b'123')
    assert type(expects) == AnsibleUnsafeBytes


# Generated at 2022-06-21 09:07:01.823427
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Test the first if clause
    # Test the third if clause
    assert isinstance(UnsafeProxy("abc"), AnsibleUnsafeText)
    # Test the second if clause
    assert isinstance(UnsafeProxy(AnsibleUnsafeText("abc")), AnsibleUnsafeText)

# Generated at 2022-06-21 09:07:07.585223
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils._text import to_text

    # test to_unsafe_bytes with nothing, with a string, and with a safe string
    assert to_unsafe_bytes() is None
    assert to_unsafe_bytes("testing") == "testing"
    assert isinstance(to_unsafe_bytes(u"testing"), AnsibleUnsafeText)



# Generated at 2022-06-21 09:07:13.104829
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    obj = {'a':'test'}
    class Tester(object):
        def __init__(self, obj, *args, **kwargs):
            self.obj = obj
    t = Tester(obj)
    assert t.obj == obj
    up = UnsafeProxy(t)
    assert up.obj == obj
    assert up.obj is not obj

# Generated at 2022-06-21 09:07:16.370480
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    unsafe_proxy = UnsafeProxy('test')
    assert isinstance(unsafe_proxy, text_type) is True
    assert isinstance(unsafe_proxy, AnsibleUnsafeText) is True



# Generated at 2022-06-21 09:07:29.100890
# Unit test for function to_unsafe_text

# Generated at 2022-06-21 09:07:38.767523
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence, Set
    from ansible.module_utils.six import text_type as six_text_type
    from ansible.module_utils.six import binary_type as six_binary_type
    from ansible.utils.display import Display
    from ansible.utils.native_jinja import NativeJinjaText
    from ansible.module_utils.common.collections import is_sequence

    # Test what we get from a string
    assert isinstance(UnsafeProxy("hello"), AnsibleUnsafeText)
    assert UnsafeProxy("hello") == "hello"
    assert not isinstance(UnsafeProxy(six_text_type("hello")), AnsibleUnsafeText)
    assert UnsafeProxy(six_text_type("hello")) == "hello"



# Generated at 2022-06-21 09:07:42.068971
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    test_str = NativeJinjaUnsafeText("abc")
    print("str:" + test_str)


if __name__ == '__main__':
    test_NativeJinjaUnsafeText()

# Generated at 2022-06-21 09:07:46.329116
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    text = 'a test string'
    unsafe_text = AnsibleUnsafeText(text)
    if (unsafe_text != text):
        raise AssertionError('Class AnsibleUnsafeText does not encode'
                             'text as expected')



# Generated at 2022-06-21 09:07:49.095218
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    try:
        a = AnsibleUnsafe()
    except TypeError:
        print('AnsibleUnsafe() object not created successfully')
        assert False


# Generated at 2022-06-21 09:07:56.850707
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert AnsibleUnsafeText('test') == 'test'
    assert AnsibleUnsafeText(b'test') == 'test'
    assert AnsibleUnsafeText(b'test'.encode()) == 'test'
    assert AnsibleUnsafeText(AnsibleUnsafeText('test')) == 'test'
    assert AnsibleUnsafeText(AnsibleUnsafeBytes(b'test')) == 'test'
    assert AnsibleUnsafeText(NativeJinjaUnsafeText(b'test')) == 'test'

#Unit test for constructor of class AnsibleUnsafeBytes

# Generated at 2022-06-21 09:08:03.733405
# Unit test for function wrap_var
def test_wrap_var():
    import pytest

    # Currently we only test if the higher level collection types (dict, list, set) are wrapped correctly
    # Other possible types (such as str or tuple) will be tested in a future PR

    # Define a test dict
    test_dict = {'key1': 1,
                 'key2': 'string',
                 'key3': ['a', 'b', 'c']}

    # Define a test set
    test_set = {'key1', 1, 'string', ['a', 'b', 'c']}

    # Define a test list
    test_list = ['key1', 1, 'string', ['a', 'b', 'c']]

    # Assert type of wrapped dict
    assert isinstance(wrap_var(test_dict), dict)

    # Assert type of items are as expected

# Generated at 2022-06-21 09:08:07.444380
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    """Tests that the constructor of class NativeJinjaUnsafeText works """
    a = NativeJinjaUnsafeText("{% if foo %} foo is a defined var {% else %} foo is not defined {% endif %}")
    assert a is not None

# Generated at 2022-06-21 09:08:10.921090
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    data = AnsibleUnsafeText('ěščřžýáíéúůďť').encode('utf-8')
    assert(isinstance(data, binary_type))
    assert(isinstance(data, AnsibleUnsafeBytes))


# Generated at 2022-06-21 09:08:13.126230
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    expected = b'foo\xc3\xa7\xc3\xb5es\xc3\x83'
    assert to_unsafe_bytes('fooçaões\xc3\x83') == expected



# Generated at 2022-06-21 09:08:25.311444
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    from ansible.utils.encrypt import do_encrypt
    from ansible.module_utils.parsing.convert_bool import boolean
    data = '12345'
    bdata = AnsibleUnsafeBytes(data)
    assert isinstance(bdata, AnsibleUnsafeBytes)
    assert isinstance(bdata.decode('utf-8'), AnsibleUnsafeText)
    assert boolean(bdata.decode('utf-8')) is False
    assert isinstance(do_encrypt(bdata, 'bar', 'baz', 1), AnsibleUnsafeBytes)
    data = AnsibleUnsafeBytes('True')
    assert isinstance(data, AnsibleUnsafeBytes)
    assert isinstance(data.decode('utf-8'), AnsibleUnsafeText)

# Generated at 2022-06-21 09:08:31.946776
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    unsafe_text = NativeJinjaUnsafeText('hello world')
    assert(isinstance(unsafe_text, NativeJinjaText))
    assert(isinstance(unsafe_text, text_type))
    assert(isinstance(unsafe_text, AnsibleUnsafe))

# Generated at 2022-06-21 09:08:34.259332
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'unsafe': {'type': 'str', 'default': 'Hi \x7f'}})
    module.exit_json(changed=False, unsafe=to_unsafe_bytes('Hi \x7f'))



# Generated at 2022-06-21 09:08:36.342496
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert type(UnsafeProxy('test')) == AnsibleUnsafeText
    assert type(UnsafeProxy(AnsibleUnsafeText('test'))) == AnsibleUnsafeText
    assert UnsafeProxy(u'baba').decode('utf-8') == u'baba'


# Generated at 2022-06-21 09:08:45.434326
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    my_var = AnsibleUnsafeBytes('value')
    assert my_var == b'value'
    assert isinstance(my_var, binary_type)
    assert isinstance(my_var, AnsibleUnsafe)
    my_var = 'value'
    assert not isinstance(my_var, AnsibleUnsafeBytes)
    assert not isinstance(my_var, AnsibleUnsafe)
    assert not isinstance(my_var, AnsibleUnsafeText)


# Generated at 2022-06-21 09:08:53.153735
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert isinstance(AnsibleUnsafeText('abcdefg'), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeText(u'abcdefg'), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeText(AnsibleUnsafeText('abcdefg')), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeText('abcdefg').encode('utf-8'), AnsibleUnsafeBytes)

    with pytest.raises(TypeError):
        AnsibleUnsafeText(123456)


# Generated at 2022-06-21 09:08:56.564512
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes(b"this is a string"), AnsibleUnsafeBytes)
    assert AnsibleUnsafeBytes(b"this is a string").__UNSAFE__


# Generated at 2022-06-21 09:09:07.589214
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    import six
    import builtins
    assert builtins.__dict__.get('UnsafeProxy') is None
    assert isinstance(UnsafeProxy('a'), six.text_type)

    text_obj = 'u'
    assert isinstance(UnsafeProxy(text_obj), six.text_type)

    text_obj = text_obj + 'n'
    assert isinstance(UnsafeProxy(text_obj), six.text_type)

    text_obj = text_obj + 's'
    assert isinstance(UnsafeProxy(text_obj), six.text_type)

    text_obj = text_obj + 'a'
    assert isinstance(UnsafeProxy(text_obj), six.text_type)

    text_obj = text_obj + 'f'

# Generated at 2022-06-21 09:09:09.430622
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    u = AnsibleUnsafe()
    assert u.__UNSAFE__ == True



# Generated at 2022-06-21 09:09:11.139385
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert hasattr(AnsibleUnsafe(), '__UNSAFE__')

# Generated at 2022-06-21 09:09:23.745156
# Unit test for function wrap_var
def test_wrap_var():

    def test_val(val, val_type):
        wrapped_val = wrap_var(val)
        assert isinstance(wrapped_val, val_type)
        assert wrapped_val.__UNSAFE__ is True

    test_cases = dict(
        dict_=dict(
            val=dict(a='a', b='b'),
            val_type=dict,
        ),
        list_=dict(
            val=['a', 'b'],
            val_type=list,
        ),
        tuple_=dict(
            val=('a', 'b'),
            val_type=tuple,
        ),
        set_=dict(
            val=set(['a', 'b']),
            val_type=set,
        ),
    )


# Generated at 2022-06-21 09:09:28.761782
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    # Test non-string argument
    result = UnsafeProxy(None)
    assert result is None

    # Test with string argument
    result = UnsafeProxy("Test String")
    assert isinstance(result, AnsibleUnsafeText)

# Generated at 2022-06-21 09:09:40.656251
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    #TODO: this could use an actual test against the class dict
    class UnsafeProxyTest():
        def __init__(self, v):
            self._v = UnsafeProxy(v)
        def get_v(self):
            return self._v
    assert UnsafeProxyTest(None).get_v() is None
    assert UnsafeProxyTest('one').get_v() == 'one'
    assert str(UnsafeProxyTest(1)) == '1'
    assert str(UnsafeProxyTest(1.1)) == '1.1'
    assert UnsafeProxyTest(True).get_v() == True
    assert UnsafeProxyTest(['one', 'two']).get_v() == ['one', 'two']

# Generated at 2022-06-21 09:09:45.854929
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    _str = "MyTestString"
    _AnsibleUnsafeTextObj = AnsibleUnsafeText(_str)
    assert(_AnsibleUnsafeTextObj.encode('utf-8') == _str.encode('utf-8'))
    assert(isinstance(_AnsibleUnsafeTextObj, AnsibleUnsafe))


# Generated at 2022-06-21 09:09:48.435621
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.module_utils.common.jinja2 import NativeJinjaUnsafeText
    # Create a test NativeJinjaUnsafeText object
    test_obj = NativeJinjaUnsafeText("This is a test string.")
    # Check that it is an instance of AnsibleUnsafe
    assert isinstance(test_obj, AnsibleUnsafe)

# Generated at 2022-06-21 09:09:59.231494
# Unit test for function wrap_var
def test_wrap_var():
    assert AnsibleUnsafeText('foo') == wrap_var('foo')
    assert AnsibleUnsafeText('foo') != wrap_var(u'foo')
    assert AnsibleUnsafeBytes(b'foo') == wrap_var(b'foo')
    assert {b'foo': b'bar'} != wrap_var({b'foo': b'bar'})
    assert AnsibleUnsafeBytes(b'foo') != wrap_var(b'foo'.decode(errors='surrogate_or_strict'))
    assert {b'foo': b'bar'} == wrap_var({b'foo': b'bar'.decode(errors='surrogate_or_strict')})

# Generated at 2022-06-21 09:10:09.004466
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves.urllib.parse import quote
    for v in (0, 1, 2, 3, "4", "5", b"6", b"7", u"8", u"9", b"10", quote(b"11"), quote(u"12")):
        assert v == wrap_var(v)
    for v in [0, 1, 2, 3, "4", "5", b"6", b"7", u"8", u"9", b"10", quote(b"11"), quote(u"12")]:
        assert is_sequence(v)

# Generated at 2022-06-21 09:10:11.538496
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    b = AnsibleUnsafeBytes(b'foo')
    assert isinstance(b, AnsibleUnsafe)
    t = AnsibleUnsafeText('foo')
    assert isinstance(t, AnsibleUnsafe)

# Generated at 2022-06-21 09:10:14.919440
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    obj = NativeJinjaUnsafeText('test')
    assert type(obj) == NativeJinjaUnsafeText
    assert obj.__UNSAFE__ == True



# Generated at 2022-06-21 09:10:18.624740
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    try:
        foo = to_unsafe_bytes('foo')
    except:
        assert False, 'to_unsafe_bytes does not work'



# Generated at 2022-06-21 09:10:20.684707
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    a = UnsafeProxy('hello')
    assert type(a) == AnsibleUnsafeText

# Generated at 2022-06-21 09:10:25.281868
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b'test').decode(), AnsibleUnsafeText)



# Generated at 2022-06-21 09:10:33.434985
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec={'value': {'type': 'str', 'no_log': True}})
    try:
        mod.exit_json(**{'value': AnsibleUnsafe('value')})
    except Exception as e:
        assert 'AnsibleUnsafe object has no element \'value\'' in str(e)
    else:
        assert False

# Generated at 2022-06-21 09:10:34.539245
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    o = AnsibleUnsafeText('testing')
    assert o == 'testing'

# Generated at 2022-06-21 09:10:37.532736
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert type(AnsibleUnsafeBytes('foo').decode()) is AnsibleUnsafeText
    assert AnsibleUnsafeBytes('foo').decode() == 'foo'



# Generated at 2022-06-21 09:10:44.890649
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import wrap_var

    class MyJinjaObj(AnsibleBaseYAMLObject):
        def __init__(self, data):
            super(MyJinjaObj, self).__init__()
            self._data = data

        def __repr__(self):
            return 'Mine: %s' % self._data

        def __str__(self):
            return self._data

        def __unicode__(self):
            return self._data

        def __deepcopy__(self, memo):
            return self

        def __getattr__(self, name):
            return

# Generated at 2022-06-21 09:10:56.559345
# Unit test for function to_unsafe_text

# Generated at 2022-06-21 09:11:07.575509
# Unit test for constructor of class UnsafeProxy

# Generated at 2022-06-21 09:11:19.462377
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    """Ensure that the UnsafeProxy class converts all strings to the unsafe context"""
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import xrange

    my_string = u"String containing unicode char with accent: déjà vu"

    # Test unicode string
    result = UnsafeProxy(my_string)
    assert isinstance(result, AnsibleUnsafeText)

    # Test normal string
    result = UnsafeProxy(my_string.encode('utf-8'))
    assert isinstance(result, AnsibleUnsafeBytes)

    # Test another string type (python3)
    result = UnsafeProxy(to_text(my_string))

# Generated at 2022-06-21 09:11:28.196878
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():

    class TestClass():
        def __call__(self, *args, **kwargs):
            if 'foo' in kwargs:
                return kwargs['foo']

        def __getitem__(self, key):
            if key == 'foo':
                return 'bar'

        def __getattr__(self, name):
            if name == 'foo':
                return 'bar'

    testclass = TestClass()
    testinstance = NativeJinjaUnsafeText('42')

    try:
        testinstance + testclass
        raise AssertionError('NativeJinjaUnsafeText can not be added to TestClass.')
    except TypeError:
        pass

# Generated at 2022-06-21 09:11:30.088219
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe().__UNSAFE__


# Generated at 2022-06-21 09:11:36.678543
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # pylint: disable=protected-access
    assert AnsibleUnsafeText('x').encode() == AnsibleUnsafeBytes(b'x')
    assert isinstance(AnsibleUnsafeText('x').encode(), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText('x').encode('utf-8'), AnsibleUnsafeBytes)
    assert AnsibleUnsafeText('x').encode('utf-8', 'strict') == b'x'


# Generated at 2022-06-21 09:11:41.026208
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    class TestClass(object):
        pass

    obj = UnsafeProxy(TestClass())
    assert isinstance(obj, TestClass)

    obj = UnsafeProxy(AnsibleUnsafe())
    assert isinstance(obj, AnsibleUnsafe)

    obj = UnsafeProxy("abc")
    assert isinstance(obj, AnsibleUnsafeText)
    assert not isinstance(obj, binary_type)

    obj = UnsafeProxy(u"abc")
    assert isinstance(obj, AnsibleUnsafeText)
    assert not isinstance(obj, binary_type)

    obj = UnsafeProxy(b"abc")
    assert isinstance(obj, AnsibleUnsafeBytes)
    assert not isinstance(obj, text_type)

# Generated at 2022-06-21 09:11:50.368962
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy(None), type(None))
    assert isinstance(UnsafeProxy(1), type(1))
    assert isinstance(UnsafeProxy("abc"), type("abc"))
    assert isinstance(UnsafeProxy(b"abc"), type(b"abc"))
    assert isinstance(UnsafeProxy(u"abc"), type(u"abc"))
    assert isinstance(UnsafeProxy(dict()), type(dict()))
    assert isinstance(UnsafeProxy(list()), type(list()))
    assert isinstance(UnsafeProxy(tuple()), type(tuple()))
    assert isinstance(UnsafeProxy(set()), type(set()))
    assert isinstance(UnsafeProxy(NativeJinjaText("abc")), type(NativeJinjaText("abc")))


# Generated at 2022-06-21 09:11:55.441209
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    input_str = b"abc"
    # Create a AnsibleUnsafeBytes
    ansible_safe_bytes = AnsibleUnsafeBytes(input_str)
    assert isinstance(ansible_safe_bytes, AnsibleUnsafeBytes)
    assert isinstance(ansible_safe_bytes, binary_type)

    # Creat a AnsibleUnsafeText
    ansible_safe_text = AnsibleUnsafeText(input_str)
    assert isinstance(ansible_safe_text, AnsibleUnsafeText)
    assert isinstance(ansible_safe_text, AnsibleUnsafe)
    assert isinstance(ansible_safe_text, text_type)

    # Create a NativeJinjaUnsafeText
    ansible_safe_text = NativeJinjaUnsafeText(input_str)

# Generated at 2022-06-21 09:12:08.168438
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('TEST'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'TEST'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'TEST', errors='strict'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'TEST', errors='surrogate_or_strict'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'\xff'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'\xff', errors='strict'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'\xff', errors='surrogate_or_strict'), AnsibleUnsafeBytes)
   

# Generated at 2022-06-21 09:12:12.758496
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy('a') == 'a'
    assert UnsafeProxy(1) == 1
    assert UnsafeProxy(b'a') == AnsibleUnsafeBytes(b'a')
    assert UnsafeProxy(u'a') == AnsibleUnsafeText(u'a')

# Generated at 2022-06-21 09:12:20.687718
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    import unittest
    from ansible.module_utils.six import StringIO
    from ansible.module_utils import basic

    from ansible.module_utils import _unsafe as unsafe_utils

    class UnsafeProxyTestCase(unittest.TestCase):

        def test_string_input(self):
            # print('test_string_input')
            obj = unsafe_utils.UnsafeProxy('Hello World')
            self.assertTrue(obj.__UNSAFE__)
            self.assertTrue(isinstance(obj, text_type))
            self.assertTrue(obj == 'Hello World')

        def test_bytes_input(self):
            # print('test_bytes_input')
            obj = unsafe_utils.UnsafeProxy(b'Hello World')
            self.assertTrue(obj.__UNSAFE__)


# Generated at 2022-06-21 09:12:24.142139
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    test_string = "test"
    ansible_unsafe_object = AnsibleUnsafeBytes(test_string)
    assert(ansible_unsafe_object == test_string)


# Generated at 2022-06-21 09:12:33.710972
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    old_text = AnsibleUnsafeBytes(b'\xd0\xb8\xd1\x83\xd1\x80\xd0\xbe\xd0\xbf\xd0\xb0 \xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82')
    new_text = old_text.decode('utf_8')
    assert isinstance(new_text, AnsibleUnsafeText)
    assert new_text.__unwrapped__ == 'Иуропа привет'


# Generated at 2022-06-21 09:12:37.307057
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils import ansible_unsafe
    wrapped = ansible_unsafe.UnsafeProxy("hello world")
    assert isinstance(wrapped, ansible_unsafe.AnsibleUnsafeText)