

# Generated at 2022-06-21 09:06:26.806795
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert wrap_var("hello") == "hello"
    assert type(wrap_var("hello")) == AnsibleUnsafeText
    assert wrap_var("hello") == AnsibleUnsafeText("hello")
    assert wrap_var("hello") == to_unsafe_text("hello")



# Generated at 2022-06-21 09:06:31.385897
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert wrap_var(u'a') == u'a'
    assert wrap_var(b'a') == b'a'
    assert wrap_var(u'\u2022') == u'\u2022'
    assert wrap_var(b'\xe2\x80\xa2') == b'\xe2\x80\xa2'

# Generated at 2022-06-21 09:06:36.119265
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    from ansible.module_utils.six import text_type, binary_type
    a = AnsibleUnsafeBytes(b"this is a test")
    assert isinstance(a.decode(),text_type)
    assert isinstance(a.decode(),AnsibleUnsafeText)


# Generated at 2022-06-21 09:06:47.572850
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    _NATIVE_JINJA_UNSAFE_TEXT_EXPECTED = '''ansible_test_j2[first_name]=Joe
ansible_test_j2[last_name]=Smith
ansible_test_j2[age]=25
ansible_test_j2[is_admin]=False
'''

# Generated at 2022-06-21 09:06:50.840734
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text("foo", encoding='utf-8') == "foo"
    assert isinstance(to_unsafe_text("foo", encoding='utf-8'), AnsibleUnsafeText)


# Generated at 2022-06-21 09:06:53.683092
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert issubclass(AnsibleUnsafeText, AnsibleUnsafe)
    assert issubclass(AnsibleUnsafeText, text_type)

# Generated at 2022-06-21 09:06:56.701863
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    from ansible.module_utils.common.text_match import text_match
    assert isinstance(AnsibleUnsafeBytes('test').decode(), AnsibleUnsafe)

# Generated at 2022-06-21 09:07:07.001152
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils._text import to_bytes
    # 1. test for None
    assert to_unsafe_bytes(None) is None
    # 2. test for AnsibleUnsafeText
    assert isinstance(to_unsafe_bytes(AnsibleUnsafeText('To be encoded')), AnsibleUnsafeBytes)
    # 3. test for AnsibleUnsafeBytes
    assert isinstance(to_unsafe_bytes(AnsibleUnsafeBytes('Already encoded')), AnsibleUnsafeBytes)
    # 4. test for non-unicode string
    assert isinstance(to_unsafe_bytes('Non-unicode string'), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:07:12.199026
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    test_value = "test_value"
    test_error = "surrogate_then_replace"
    test_obj = AnsibleUnsafeBytes(test_value)
    assert test_obj.decode(errors=test_error) == AnsibleUnsafeText(test_value.decode(errors=test_error))


# Generated at 2022-06-21 09:07:14.202710
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    class AnsibleUnsafeObj(AnsibleUnsafe):
        pass
    assert AnsibleUnsafeObj().__UNSAFE__


# Generated at 2022-06-21 09:07:20.810225
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text('str'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'bytes'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'bytes', encoding='utf-8', errors='strict'), AnsibleUnsafeText)



# Generated at 2022-06-21 09:07:30.331677
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # test decoding bytes to utf-8
    assert isinstance(AnsibleUnsafeBytes(b'\xe2\x82\xac').decode(), text_type)

    # test encoding utf-8 to bytes
    assert isinstance(AnsibleUnsafeBytes('\xe2\x82\xac').encode(), binary_type)

    # test encoding utf-8 to bytes without encoding parameters
    assert isinstance(AnsibleUnsafeBytes('\xe2\x82\xac').encode(), binary_type)



# Generated at 2022-06-21 09:07:33.833060
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import assertRaisesRegex
    assertRaisesRegex(
        AssertionError,
        'A non-safe string was passed to UnsafeProxy constructor',
        UnsafeProxy,
        '\xff'
    )

# Generated at 2022-06-21 09:07:45.754394
# Unit test for function wrap_var
def test_wrap_var():
    seq_types = [
        list(),
        tuple(),
        set(),
        frozenset(),
        bytearray(),
        bytes()
    ]

    # Test sequence types
    for seq_type in seq_types:
        obj_seq_type = wrap_var(seq_type)
        assert isinstance(obj_seq_type, seq_type.__class__)

    # Test dict type
    obj_dict_type = wrap_var({})
    assert isinstance(obj_dict_type, dict)

    # Test string types
    obj_binary_type = wrap_var(b'hello')
    assert isinstance(obj_binary_type, binary_type)

    obj_text_type = wrap_var(u'hello')
    assert isinstance(obj_text_type, text_type)

    # Test native

# Generated at 2022-06-21 09:07:56.681344
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    def do_test(value, expected):
        actual = to_unsafe_text(value)
        assert isinstance(actual, AnsibleUnsafeText)
        assert actual == expected

    do_test(u'', u'')
    do_test(u'hello', u'hello')
    do_test(u'\u2603', u'\u2603')
    do_test('', u'')
    do_test('hello', u'hello')
    do_test('\xe2\x98\x83', u'\u2603')
    # Test binary values:
    do_test(b'', u'')
    do_test(b'hello', u'hello')
    do_test(b'\xe2\x98\x83', u'\u2603')
    # Test surrogate pairs:

# Generated at 2022-06-21 09:08:03.615847
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.unsafe_proxy import wrap_var
    from six import string_types
    import sys
    import types

    if sys.version_info < (3,):
        string_types = string_types + (types.UnicodeType,)

    def check_type(o, t):
        assert type(o) is t, 'type {} not {}'.format(o, t)

    class Foo(object):
        """A non-string class"""
        pass

    obj = Foo()
    check_type(wrap_var(obj), Foo)

    obj = {}
    check_type(wrap_var(obj), dict)

    obj = []
    check_type(wrap_var(obj), list)

    obj = ()
    check_type(wrap_var(obj), tuple)

    obj = set()
   

# Generated at 2022-06-21 09:08:06.126919
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    my_text = NativeJinjaUnsafeText("hello")
    assert isinstance(my_text,NativeJinjaUnsafeText)

# Generated at 2022-06-21 09:08:14.571169
# Unit test for method __new__ of class UnsafeProxy

# Generated at 2022-06-21 09:08:24.647043
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    """This will only instantiate one of the three class"""
    test_string = "I'm a test string"
    test_unicode = "\u8bcd\u6c49\u5b57.\n"
    test_dict = {'a': 1, 'b': 2}
    test_list = [1, 2, 3, 4, 5]

    assert isinstance(UnsafeProxy(test_string), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(test_unicode), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(test_dict), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(test_list), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:08:37.197999
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    # Test 1: Unsafe text
    s = UnsafeProxy('test')
    assert(isinstance(s, AnsibleUnsafeText) == True)
    s = UnsafeProxy(s)
    assert(isinstance(s, AnsibleUnsafeText) == True)
    s = UnsafeProxy(None)
    assert(s == None)

    t = to_text('test')
    s = UnsafeProxy(t)
    assert(isinstance(s, AnsibleUnsafeText) == True)

    s = UnsafeProxy(t.encode('utf-8'))
    assert(isinstance(s, AnsibleUnsafeBytes) == True)

    # Test 2: Lists
    l = [1, 2, 3]
    s = UnsafeProxy(l)
    assert(isinstance(s, list) == True)


# Generated at 2022-06-21 09:08:42.042406
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.display import Display
    Display.deprecated = lambda self, msg, version, **kwargs: None

# Generated at 2022-06-21 09:08:49.392428
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(u' '), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u' ', errors='ignore'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u' '), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u' ', errors='ignore'), AnsibleUnsafeText)

# Generated at 2022-06-21 09:08:52.921428
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    bytes = to_unsafe_bytes(u'\xe0')
    assert isinstance(bytes, AnsibleUnsafeBytes)
    assert bytes == b'\xe0'
    assert isinstance(bytes.decode('utf8'), AnsibleUnsafeText)


# Generated at 2022-06-21 09:08:55.054659
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    obj = UnsafeProxy('test_string')
    assert isinstance(obj, AnsibleUnsafe)

# Generated at 2022-06-21 09:09:06.471344
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    # First with text:
    assert isinstance(to_unsafe_text(u"root"), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u"root"), text_type)
    assert isinstance(to_unsafe_text(u"root"), AnsibleUnsafeText)

    # Now with bytes:
    assert isinstance(to_unsafe_text(b"root"), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b"root"), text_type)
    assert isinstance(to_unsafe_text(b"root"), AnsibleUnsafeText)

    # Now with non-binary type:
    assert isinstance(to_unsafe_text(u'@' * 1000), AnsibleUnsafeText)

# Generated at 2022-06-21 09:09:11.263601
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    unsafe_bytes = wrap_var("b'\xfc\xe4\xdf'")

    if isinstance(unsafe_bytes, AnsibleUnsafeBytes):
        assert isinstance(unsafe_bytes.decode('utf8'), AnsibleUnsafeText)
    else:
        assert False



# Generated at 2022-06-21 09:09:23.787403
# Unit test for function wrap_var
def test_wrap_var():
    import copy
    import json
    from ansible.module_utils.common.collections import ImmutableDict

    a = {"omg": "bbq", "unicode": u'\u2713', "foo": {"old": "new", "new": "old"}}
    b = copy.deepcopy(a)

    assert a == b
    assert a.keys() == b.keys()
    assert a.items() == b.items()
    assert a['foo']['old'] == b['foo']['old']

    a['foo'] = wrap_var(a['foo'])
    assert a == b
    assert a.keys() == b.keys()
    assert a.items() == b.items()
    assert wrap_var(a['foo']['old']) == b['foo']['old']

   

# Generated at 2022-06-21 09:09:26.493059
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    unsafe_bytes = AnsibleUnsafeBytes(b'\xc4\x85')
    assert isinstance(unsafe_bytes.decode('utf-8'), AnsibleUnsafeText) is True



# Generated at 2022-06-21 09:09:39.172421
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(u"foo") == u"foo"
    assert isinstance(to_unsafe_text(u"foo"), unicode)
    assert to_unsafe_text(b"foo") == u"foo"
    assert isinstance(to_unsafe_text(b"foo"), unicode)
    assert to_unsafe_text(u"f\xe9e") == u"f\xe9e"
    assert isinstance(to_unsafe_text(u"f\xe9e"), unicode)
    assert to_unsafe_text(b"f\xc3\xa9e") == u"f\xe9e"
    assert isinstance(to_unsafe_text(b"f\xc3\xa9e"), unicode)

# Generated at 2022-06-21 09:09:40.772677
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe()



# Generated at 2022-06-21 09:09:46.335887
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    test_input_string = "This is a test string"
    unsafe_bytes = AnsibleUnsafeBytes(test_input_string)
    decoded_string = unsafe_bytes.decode()
    assert isinstance(decoded_string, AnsibleUnsafeText)


# Generated at 2022-06-21 09:09:59.038583
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    # Test with a string
    assert isinstance(to_unsafe_text('foo'), AnsibleUnsafeText)

    # Test with a number
    assert isinstance(to_unsafe_text(1), AnsibleUnsafeText)

    # Test with a dict
    assert isinstance(to_unsafe_text({'foo': 'bar'}), dict)
    assert isinstance(to_unsafe_text({'foo': 'bar'})['foo'], AnsibleUnsafeText)

    # Test with a list
    assert isinstance(to_unsafe_text(['foo']), list)
    assert isinstance(to_unsafe_text(['foo'])[0], AnsibleUnsafeText)

    # Test with a tuple
    assert isinstance(to_unsafe_text(('foo',)), tuple)

# Generated at 2022-06-21 09:10:02.730767
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.six import string_types

    for s in string_types:
        assert isinstance(UnsafeProxy(s()), (AnsibleUnsafeBytes, AnsibleUnsafeText))



# Generated at 2022-06-21 09:10:04.596569
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    text = "{{ foo }}"
    unsafe_text = NativeJinjaUnsafeText(text)


# Generated at 2022-06-21 09:10:12.285980
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import json
    import six

    # --- Python 3
    if six.PY3:
        # Python 3 - non-unicode
        input_str = b'\xed\xa0\xbd\xed\xb0\x80foot'
        expected_output_str = '\ud852\udf62foot'
        output_str = to_unsafe_text(input_str, errors='surrogateescape')
        assert output_str == expected_output_str
        assert type(output_str) is NativeJinjaUnsafeText

        # Python 3 - unicode
        input_str = '\ud852\udf62foot'
        expected_output_str = '\ud852\udf62foot'

# Generated at 2022-06-21 09:10:19.149463
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    test_unsafe = AnsibleUnsafeBytes("Hello World")
    test_encoding = test_unsafe.encode()
    assert type(test_encoding) == bytes
    test_decoding = test_encoding.decode()
    assert type(test_decoding) == str
    assert test_unsafe == test_decoding.encode()



# Generated at 2022-06-21 09:10:21.962883
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    v = AnsibleUnsafeText('my string')
    c = AnsibleUnsafeText(u'my string')
    assert v == c

# Generated at 2022-06-21 09:10:29.962901
# Unit test for function wrap_var
def test_wrap_var():
    """
    Unit test for function wrap_var
    """

# Generated at 2022-06-21 09:10:35.021962
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    an_unsafe_byte = AnsibleUnsafeBytes(b'keyword')
    assert type(an_unsafe_byte) is AnsibleUnsafeBytes
    assert type(an_unsafe_byte.decode()) is AnsibleUnsafeText



# Generated at 2022-06-21 09:10:37.894663
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    unp = UnsafeProxy("value")
    if not isinstance(unp,AnsibleUnsafeText):
        raise Exception("UnsafeProxy is not instance of unsafe string")

# Generated at 2022-06-21 09:10:40.441892
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert UnsafeProxy('test') is not None



# Generated at 2022-06-21 09:10:43.375354
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text('abc').startswith(u"b'abc'"), 'to_unsafe_text returned %s' % to_unsafe_text('abc')

# Generated at 2022-06-21 09:10:46.636883
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    val = AnsibleUnsafeBytes('abc')
    assert isinstance(val, AnsibleUnsafeBytes)
    assert isinstance(val.decode(), AnsibleUnsafeText)



# Generated at 2022-06-21 09:10:51.583311
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils._text import to_bytes
    b = to_unsafe_bytes('foo')
    assert isinstance(b, AnsibleUnsafeBytes)
    assert to_bytes(b) == b'foo'



# Generated at 2022-06-21 09:10:59.418529
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    """
    The function to_unsafe_bytes should return a AnsibleUnsafeBytes object

    The function to_unsafe_bytes should return an AnsibleUnsafeBytes object
    when given a unicode string or a encoded byte string.

    The function to_unsafe_bytes should return the parameter unchanged if it
    is not a string.
    """
    from ansible.module_utils.six import binary_type

    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes('foo'.encode('utf-8')), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(None), type(None))
    assert isinstance(to_unsafe_bytes(u'foo'), AnsibleUnsafeText)

# Generated at 2022-06-21 09:11:08.402650
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type
    from ansible.module_utils._text import to_text

    s = b'uname \xe2\x80\xa2'
    r = to_text(s, errors='surrogate_then_replace')
    assert type(r) == text_type
    assert r == u'uname \ufffd'

    u = AnsibleUnsafeBytes(s)
    assert type(u) == AnsibleUnsafeBytes
    assert u == s

    u = u.decode('utf-8')
    assert type(u) == AnsibleUnsafeText
    assert u == r


# Generated at 2022-06-21 09:11:14.332901
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    def check(input, output):
        assert to_unsafe_text(input) == output
        assert isinstance(to_unsafe_text(input), AnsibleUnsafeText)

    check(None, None)
    check(u'', u'')
    check(u'1', u'1')
    check(u'\u2265', u'\u2265')
    check(1, u'1')
    check(True, u'True')
    check(b'1', u'1')
    check(None, None)
    check(b'\xc3\xa9', u'\xe9')
    check(b'\xc3\x83\xc2\xa9', u'\xc3\xa9')
    check(1, u'1')
    check(True, u'True')


# Generated at 2022-06-21 09:11:25.378339
# Unit test for function wrap_var
def test_wrap_var():
    # import unit test framework
    import unittest

    # define test class
    class TestWrapVar(unittest.TestCase):
        def setUp(self):
            # properties
            self.safe_tests = [
                ('safe', 'safe'),
                (u'safe', u'safe'),
                (b'safe', b'safe'),
                (1, 1),
                ({'a': 1}, {'a': 1}),
                ({'a': 1, 'b': {'c': 3}}, {'a': 1, 'b': {'c': 3}}),
            ]
            self.unsafe_test_str = 'unsafe'
            self.unsafe_test_bytes = b'unsafe'
            self.unsafe_test_unicode = u'unsafe'
            self.unsafe_test

# Generated at 2022-06-21 09:11:35.440292
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import pytest
    fname = 'test_to_unsafe_text'
    in_list = [
        u'\u00e9',
        '\xc3\xa9',
        b'\xc3\xa9',
        u'\u2603',
        '\xe2\x98\x83',
        b'\xe2\x98\x83'
    ]
    for i in in_list:
        assert type(to_unsafe_text(i)) == type(u'unicode')
        assert to_unsafe_text(i) == u'\u2603'
    for i in in_list:
        assert type(to_unsafe_bytes(i)) == type(b'bytes')

# Generated at 2022-06-21 09:11:36.927123
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    data = {'a': {'b': 'c', 'd': 'e'}}
    assert wrap_var(to_text(data)) == data

# Generated at 2022-06-21 09:11:39.402029
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe()

# Generated at 2022-06-21 09:11:49.124802
# Unit test for function wrap_var
def test_wrap_var():
    failure = False

# Generated at 2022-06-21 09:11:55.283533
# Unit test for function to_unsafe_text
def test_to_unsafe_text():

    # pylint: disable=unused-import
    from ansible.module_utils.six import PY2

    assert to_unsafe_text(None) is None

    u_obj = to_unsafe_text(u'foo')
    assert isinstance(u_obj, AnsibleUnsafeText)

    u_obj = to_unsafe_text('foo')
    assert isinstance(u_obj, AnsibleUnsafeText)

    u_obj = to_unsafe_text(u'\u2019')
    assert isinstance(u_obj, AnsibleUnsafeText)

    u_obj = to_unsafe_text(u'\u2019'.encode('utf-8'))
    assert isinstance(u_obj, AnsibleUnsafeText)

    if PY2:
        u_obj = to_uns

# Generated at 2022-06-21 09:12:08.125799
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    b1 = b'\xF0\x9F\x98\x95'
    u1 = u'\U0001F495'
    s = b1
    s = AnsibleUnsafeBytes(s)
    assert isinstance(s, AnsibleUnsafeBytes)
    assert isinstance(s, binary_type)
    assert isinstance(s, AnsibleUnsafe)
    assert s == b1
    assert s == u1
    s = s.decode()
    assert isinstance(s, AnsibleUnsafeText)
    assert isinstance(s, text_type)
    assert isinstance(s, AnsibleUnsafe)
    assert s == b1
    assert s == u1
    s = s.encode()
    assert isinstance(s, AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:12:10.444436
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe().__UNSAFE__ is True



# Generated at 2022-06-21 09:12:19.144944
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    primitive_types = [None, True, False, 1, 2.3]
    for t in primitive_types:
        assert wrap_var(t) == t

    assert isinstance(wrap_var(u"testing"),  AnsibleUnsafeText)
    assert isinstance(wrap_var("testing"),  AnsibleUnsafeText)
    assert isinstance(wrap_var(b"testing"), AnsibleUnsafeBytes)

    assert isinstance(wrap_var({"testing": "data"}), dict)
    assert isinstance(wrap_var({"testing": "data"}).keys()[0], AnsibleUnsafeText)
    assert isinstance(wrap_var({"testing": "data"}).values()[0], AnsibleUnsafeText)


# Generated at 2022-06-21 09:12:32.415873
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    import sys

    if PY3:
        str_types = (str, bytes)
    else:
        str_types = (str, unicode)

    # Test None
    assert wrap_var(None) is None

    # Test unsafe classes
    for unsafe_type in (AnsibleUnsafeBytes, AnsibleUnsafeText):
        assert isinstance(wrap_var(unsafe_type(b'foo')), unsafe_type)
        assert isinstance(wrap_var(unsafe_type(u'foo')), unsafe_type)

    # Test unsafe base classes
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)

    # Test unsafe wrappers
   

# Generated at 2022-06-21 09:12:41.391617
# Unit test for function wrap_var
def test_wrap_var():
    # Test that some basic types are converted correctly
    assert isinstance(wrap_var(True), bool)
    assert isinstance(wrap_var(1), int)
    assert isinstance(wrap_var(1.0), float)

    # Basic string types should be returned unchanged
    assert wrap_var('foo') == 'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')

    # Test that strings get converted to safe
    assert isinstance(wrap_var(to_bytes('foo')), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:12:46.141555
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    some_string = b"\xc2\xabLa\xc2\xbb pe\xc3\xb1a"
    assert AnsibleUnsafeBytes(some_string).decode("utf-8") == u"\u00abLa\u00bb pe\u00f1a"


# Generated at 2022-06-21 09:12:58.622283
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.six import string_types

    assert wrap_var(None) is None
    assert wrap_var(False) is False
    assert wrap_var(42) == 42
    assert wrap_var(2.0) == 2.0
    assert isinstance(wrap_var(u'foobar'), AnsibleUnsafeText)
    assert wrap_var(u'foobar').__UNSAFE__ is True
    assert isinstance(wrap_var(b'foobar'), AnsibleUnsafeBytes)
    assert wrap_var(b'foobar').__UNSAFE__ is True

# Generated at 2022-06-21 09:13:03.135722
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    sample = 'sample'
    assert AnsibleUnsafeBytes(sample).decode() == AnsibleUnsafeText(sample)


# Generated at 2022-06-21 09:13:06.916802
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafeBytes('foo') == AnsibleUnsafeBytes('foo')
    assert AnsibleUnsafeText(u'foo') == AnsibleUnsafeText(u'foo')


# Unit tests for wrap_var

# Generated at 2022-06-21 09:13:17.366863
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    import sys
    import os
    import pytest

    # Get the directory containing the current script
    scriptBaseDir = os.path.dirname(os.path.abspath(__file__))
    # Add the directory containing the Python2 module to the system path
    sys.path.append(scriptBaseDir + "/../../lib/python2.7/site-packages/")
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.text.converters import to_unicode

    testObj1 = AnsibleUnsafeText("test")
    testObj2 = AnsibleUnsafeText(b"test")

    assert(isinstance(testObj1, AnsibleUnsafeText))
    assert(isinstance(testObj2, AnsibleUnsafeText))


# Generated at 2022-06-21 09:13:28.860761
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import is_sequence
    # Test for string_types
    assert(isinstance(UnsafeProxy("not_a_safe_string"), AnsibleUnsafeText))
    assert(isinstance(UnsafeProxy(u"not_a_safe_string"), AnsibleUnsafeText))
    assert(isinstance(UnsafeProxy(b"not_a_safe_string"), AnsibleUnsafeBytes))
    # Test for list
    assert(isinstance(UnsafeProxy(["a", "b"]), tuple))
    # Test for tuple
    assert(isinstance(UnsafeProxy(("a", "b")), tuple))
    # Test for dict
    test_dict = dict()
    test_dict["key1"] = "a"


# Generated at 2022-06-21 09:13:38.821238
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.unsafe_proxy import UnsafeProxy
    import json
    import os
    os.environ["TEST_UNSAFE_PROXY_NEW"] = "1"
    try:
        import warnings
        warnings.filterwarnings("error")
        data = json.loads('{"key":"value"}')
        ret = UnsafeProxy(data)
        assert type(ret) == type(data)
        assert ret["key"] == "value"
        assert type(ret["key"]) == type(data["key"])
    finally:
        del os.environ["TEST_UNSAFE_PROXY_NEW"]



# Generated at 2022-06-21 09:13:47.958519
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    import unittest
    class TestCase(unittest.TestCase):
        def setUp(self):
            self.t = AnsibleUnsafe()
            self.b = AnsibleUnsafeBytes(b'Just testing')
            self.s = AnsibleUnsafeText(u'Just testing')

        def test_isUnsafe(self):
            self.assertTrue(isinstance(self.t, AnsibleUnsafe))
            self.assertTrue(isinstance(self.b, AnsibleUnsafe))
            self.assertTrue(isinstance(self.s, AnsibleUnsafe))

        def test_toUnsafe(self):
            self.assertEqual(AnsibleUnsafe(), AnsibleUnsafe())

# Generated at 2022-06-21 09:13:50.270908
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    AnsibleUnsafeBytes("test_AnsibleUnsafeBytes")

# Generated at 2022-06-21 09:14:01.708404
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():

    x = b'x'
    x_safe = AnsibleUnsafeBytes(x)

    # Test identity: object x is not x_safe
    assert x is not x_safe

    # Test equality. UnsafeProxy should not override equality.
    assert x == x_safe
    assert x is x

    # Test identity: object x is x
    assert x is x

    # Test identity: object x_safe is x_safe
    assert x_safe is x_safe

    # Test type: object x is of type bytes
    assert isinstance(x, bytes)

    # Test type: object x_safe is of type bytes
    assert isinstance(x_safe, bytes)

    # Test type: object x is not of type str
    assert not isinstance(x, str)

    # Test type: object x_safe is not of type str


# Generated at 2022-06-21 09:14:03.839126
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from __main__ import t
    assert isinstance(t, text_type)
    assert t.islower()
    assert isinstance(t, AnsibleUnsafeText)

# Generated at 2022-06-21 09:14:05.793809
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    unsafe_text = AnsibleUnsafeText("AnsibleUnsafeText")
    assert isinstance(unsafe_text.encode(), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:14:20.626463
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(None) is None
    assert to_unsafe_text(AnsibleUnsafeBytes(b'')) is AnsibleUnsafeBytes(b'')
    assert isinstance(to_unsafe_text(b''), AnsibleUnsafeText)
    assert to_unsafe_text(AnsibleUnsafeText(u'')) is AnsibleUnsafeText(u'')
    assert isinstance(to_unsafe_text(u''), AnsibleUnsafeText)

    # noinspection PyTypeChecker
    for s in [42, 42.0, dict(), list(), set(), frozenset(), tuple()]:
        assert to_unsafe_text(s) is s

# Generated at 2022-06-21 09:14:26.755196
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY3
    # Test for str (unicode) input
    if PY3:
        assert type(to_unsafe_bytes('test', encoding='utf-8')) == AnsibleUnsafeText
    # Test for bytes input
    else:
        assert type(to_unsafe_bytes('test', encoding='utf-8')) == AnsibleUnsafeBytes


# Generated at 2022-06-21 09:14:30.461980
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    test_bytes = b'foo'
    encoded_bytes = AnsibleUnsafeBytes(test_bytes)
    decoded_text = encoded_bytes.decode()
    assert isinstance(decoded_text, AnsibleUnsafeText)


# Generated at 2022-06-21 09:14:31.751520
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes('a') == b'a'



# Generated at 2022-06-21 09:14:43.393432
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    # Test case1: unicode
    src = u"bytes, é"
    res = to_unsafe_text(src)
    assert isinstance(res, AnsibleUnsafeText)
    assert res == src

    # Test case2: bytes (in utf-8 encoding)
    src = u"bytes, é".encode('utf-8')
    res = to_unsafe_text(src)
    assert isinstance(res, AnsibleUnsafeText)
    assert res == u"bytes, é"

    # Test case3: bytes (not in utf-8 encoding)
    src = u"bytes, é".encode('latin-1')
    res = to_unsafe_text(src)
    assert isinstance(res, AnsibleUnsafeText)
    assert res == u"bytes, \xE9"

# Generated at 2022-06-21 09:14:48.293629
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    text = NativeJinjaUnsafeText("{%")
    assert text == "{%"
    assert text.startswith("{%")
    assert text.endswith("{%")
    assert text[1] == "%"
    assert isinstance(text, text_type)
    assert isinstance(text, AnsibleUnsafeText)
    assert isinstance(text, NativeJinjaUnsafeText)

# Generated at 2022-06-21 09:14:55.968050
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    text = NativeJinjaUnsafeText(u"safe text.")

    assert isinstance(text, NativeJinjaUnsafeText)
    assert isinstance(text, AnsibleUnsafeText)
    assert not isinstance(text, AnsibleUnsafeBytes)
    assert isinstance(text, NativeJinjaText)
    assert isinstance(text, text_type)
    assert not isinstance(text, binary_type)

# Generated at 2022-06-21 09:15:05.954517
# Unit test for constructor of class NativeJinjaUnsafeText

# Generated at 2022-06-21 09:15:13.797216
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_bytes
    ansible_unsafe = AnsibleUnsafeBytes("unsafe_text")
    assert not ansible_unsafe.__UNSAFE__
    ansible_unsafe = to_text("unsafe_text").encode("utf-8")
    assert not ansible_unsafe.__UNSAFE__
    ansible_unsafe = to_bytes("unsafe_text")
    assert not ansible_unsafe.__UNSAFE__
    ansible_unsafe = bytes("unsafe_text", "utf-8")
    assert not ansible_unsafe.__UNSAFE__


# Generated at 2022-06-21 09:15:19.252186
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes(""), AnsibleUnsafe)
    assert isinstance(AnsibleUnsafeBytes("", encoding="utf-8"), AnsibleUnsafe)
    assert isinstance(AnsibleUnsafeBytes("", errors="strict"), AnsibleUnsafe)


# Generated at 2022-06-21 09:15:25.804386
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert type(UnsafeProxy("foo")) == AnsibleUnsafeText

# Generated at 2022-06-21 09:15:28.435866
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    from ansible.module_utils.six import u
    val = u('text')
    ans_unsafe_text = AnsibleUnsafeText(val)
    assert val == ans_unsafe_text


# Generated at 2022-06-21 09:15:31.061612
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText(u'abc').encode(), AnsibleUnsafeBytes)
    assert isinstance(NativeJinjaUnsafeText(u'abc').encode(), AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:15:40.884817
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # test case 1
    bytes_obj = AnsibleUnsafeBytes(b'test_bytes')
    ret_value = bytes_obj.decode()
    assert AnsibleUnsafeText(b'test_bytes').__eq__(ret_value)

    # test case 2
    with pytest.raises(UnicodeDecodeError):
        ansible_unsafe_bytes_obj = AnsibleUnsafeBytes(b'\xf1')
        ret_value = ansible_unsafe_bytes_obj.decode()


# Generated at 2022-06-21 09:15:47.132638
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert isinstance(NativeJinjaUnsafeText(u'foobar'), NativeJinjaUnsafeText)
    assert isinstance(NativeJinjaUnsafeText(u'foobar'.encode('utf-8')), NativeJinjaUnsafeText)
    assert not isinstance(NativeJinjaUnsafeText(u'foobar').encode('utf-8'), NativeJinjaUnsafeText)

# Generated at 2022-06-21 09:15:55.690395
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    display = Display()

    def _assert_types(v):
        """Assert that specific types are wrapped"""
        assert isinstance(v, AnsibleUnsafeBytes)
        assert isinstance(v.decode('utf-8'), AnsibleUnsafeText)
        assert isinstance(v[0], AnsibleUnsafeBytes)
        assert isinstance(v[0].decode('utf-8'), AnsibleUnsafeText)

    # Bytes
    v = wrap_var(b'\x00')
    _assert_types(v)

    # String
    v = wrap_var('test')
    _assert_types(v)

    # NativeJinjaText
    v = wrap_var(NativeJinjaText(u'{{ foo }}'))

# Generated at 2022-06-21 09:16:04.216816
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    text = to_unsafe_text(b'\xe5\x90\x8d\xe5\xad\x97')
    assert isinstance(text, AnsibleUnsafeText)
    assert text == u'\u540d\u5b57'
    text = to_unsafe_text(text)
    assert isinstance(text, AnsibleUnsafeText)
    assert text == u'\u540d\u5b57'
    text = to_unsafe_text(u'\u540d\u5b57')
    assert isinstance(text, AnsibleUnsafeText)
    assert text == u'\u540d\u5b57'

# Generated at 2022-06-21 09:16:12.835693
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # Assert that AnsibleUnsafeText is a subclass of both text_type and AnsibleUnsafe
    assert issubclass(AnsibleUnsafeText, text_type) and issubclass(AnsibleUnsafeText, AnsibleUnsafe)
    # Create an instance of AnsibleUnsafeText
    unsafeText1 = AnsibleUnsafeText("This is a test string and it is to be converted to bytes")
    # Assert that it is an instance of AnsibleUnsafeText
    assert isinstance(unsafeText1, AnsibleUnsafeText)
    # Convert to bytes and assert that the converted object is an instance of AnsibleUnsafeBytes
    unsafeBytes1 = unsafeText1.encode()
    assert isinstance(unsafeBytes1, AnsibleUnsafeBytes)
    # Create an instance of AnsibleUnsafeBytes
    unsafeBytes2 = Ans

# Generated at 2022-06-21 09:16:23.495361
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var("some_text"), AnsibleUnsafeText)
    assert isinstance(wrap_var(b"some_text"), AnsibleUnsafeBytes)
    assert isinstance(wrap_var({1: "1", 2: "2"}), dict)
    assert isinstance(wrap_var({"1": 1, "2": 2}), dict)
    assert isinstance(wrap_var({"1": 1, "2": 2}.values()), list)
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes('foo')), AnsibleUnsafeBytes)