

# Generated at 2022-06-21 09:06:24.365201
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    val = b'\xe4\xbd\xa0\xe5\xa5\xbd'
    val = AnsibleUnsafeBytes(val)
    assert isinstance(val, AnsibleUnsafeBytes)
    val_decoded = val.decode('utf-8')
    assert isinstance(val_decoded, AnsibleUnsafeText)
    assert val_decoded == u'你好'


# Generated at 2022-06-21 09:06:30.858006
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    import ansible.module_utils.basic
    # In our usage we should only receive unicode strings.
    # This conditional and conversion exists to sanity check the values
    # we're given but we may want to take it out for testing and sanitize
    # our input instead.
    if isinstance("", string_types):
        string = ansible.module_utils.basic.AnsibleUnsafeText("test")
        assert string == UnsafeProxy("test")

# Generated at 2022-06-21 09:06:42.684307
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import PY3
    class UnsafeProxy_Test:
        pass

    # Test: __new__ constructor using a string
    # Expect: string type object, return value depends on Python 2 or Python 3
    # Python 2: <type 'unicode'>
    # Python 3: <class '__main__.AnsibleUnsafeText'>
    test_str = UnsafeProxy('test')
    if PY3:
        assert isinstance(test_str, AnsibleUnsafeText)
    else:
        assert type(test_str) == text_type

    # Test: __new__ constructor using an int
    # Expect: int type object, return value depends on Python 2 or Python 3
    # Python 2: <type 'int'>
    # Python 3: <type 'int'>
    test_int = Un

# Generated at 2022-06-21 09:06:51.815671
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(''), AnsibleUnsafeText)
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'unicode'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'\u2713'), AnsibleUnsafeText)
    assert isinstance(wrap_var(['foo']), list)
    assert isinstance(wrap_var(['foo'])[0], AnsibleUnsafeBytes)
    assert isinstance(wrap_var([u'foo']), list)
    assert isinstance(wrap_var([u'foo'])[0], AnsibleUnsafeText)

# Generated at 2022-06-21 09:06:54.304045
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert to_unsafe_bytes("test") == AnsibleUnsafeBytes(b"test")



# Generated at 2022-06-21 09:06:55.055256
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    pass

# Generated at 2022-06-21 09:07:06.849220
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    import unittest
    import six

    class UnsafeProxyTestCase(unittest.TestCase):
        def test_string(self):
            self.assertTrue(isinstance(UnsafeProxy('some string'), six.string_types))

        def test_unsafe_string(self):
            self.assertTrue(isinstance(UnsafeProxy(UnsafeProxy('some string')), six.string_types))

        def test_number(self):
            self.assertTrue(isinstance(UnsafeProxy(100), six.integer_types))

        def test_unsafe_number(self):
            self.assertTrue(isinstance(UnsafeProxy(UnsafeProxy(100)), six.integer_types))

        def test_mutable(self):
            result = UnsafeProxy([1, 2, 3])

# Generated at 2022-06-21 09:07:09.074329
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    # basic
    x = UnsafeProxy('hello')
    assert isinstance(x, AnsibleUnsafeText)
    asser

# Generated at 2022-06-21 09:07:11.808187
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    s = NativeJinjaUnsafeText("some string")
    assert isinstance(s, NativeJinjaUnsafeText)



# Generated at 2022-06-21 09:07:14.865000
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    test_string = u'\u4f60\u597d'
    obj = AnsibleUnsafeText(test_string)
    assert isinstance(obj, AnsibleUnsafeText)
    assert obj.__UNSAFE__ == True


# Generated at 2022-06-21 09:07:17.122389
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    pass

# Generated at 2022-06-21 09:07:30.056883
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils._text import to_text
    # Test with empty string
    assert isinstance(UnsafeProxy(''), AnsibleUnsafeText)
    # Test with empty bytes
    assert isinstance(UnsafeProxy(b''), AnsibleUnsafeBytes)
    # Test with Unicode
    assert isinstance(UnsafeProxy(u'foobar'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(to_text('foobar')), AnsibleUnsafeText)
    # Test with Bytes
    assert isinstance(UnsafeProxy(b'foobar'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(to_bytes('foobar')), AnsibleUnsafeBytes)
    # Test with None
    assert UnsafeProxy(None) is None
    # Test with Dict

# Generated at 2022-06-21 09:07:33.699659
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    try:
        assert to_unsafe_text(b'foo').__class__ == AnsibleUnsafeText
    except AssertionError:
        raise AssertionError('byte string should convert to unsafe text')



# Generated at 2022-06-21 09:07:38.778789
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    unsafe_string = wrap_var("superstring")
    assert isinstance(unsafe_string, AnsibleUnsafeText)
    unsafe_bytes = unsafe_string.encode('utf-8')
    assert isinstance(unsafe_bytes, AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:07:41.412582
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    my_str = 'This is a test string'
    my_str_unsafe = UnsafeProxy(my_str)
    assert(isinstance(my_str_unsafe, AnsibleUnsafeText))
    assert(my_str_unsafe == my_str)

# Generated at 2022-06-21 09:07:52.537069
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.six import PY2
    import sys

    if PY2:
        text_type = unicode  # noqa, pylint: disable=undefined-variable
    else:
        text_type = str

    # Test case 1:
    # str is always converted to `unicode` in python2.7
    # and should be converted to `AnsibleUnsafeText`
    value = 'foo'
    ret = UnsafeProxy(value)
    assert(isinstance(ret, text_type))
    assert(isinstance(ret, AnsibleUnsafeText))
    assert(isinstance(ret, AnsibleUnsafe))
    assert(ret == 'foo')

    # Test case 2:
    # `unicode` should be converted to `AnsibleUnsafeText`
    value = text_

# Generated at 2022-06-21 09:08:02.845832
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(u"Hello World!"), AnsibleUnsafeText)

    # Test that the resulting text is still usable
    assert isinstance(to_unsafe_text(u"Hello World!"), text_type)
    assert isinstance(to_unsafe_text(u"Hello World!").encode("utf-8"), binary_type)

    # Test that it is still possible to use custom errors
    assert isinstance(to_unsafe_text(u"\ufffd", errors="ignore"), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text("\xff", encoding="latin-1", errors="ignore"), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text("\xff", encoding="utf-8", errors="strict"), AnsibleUnsafeText)

    #

# Generated at 2022-06-21 09:08:06.000168
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafeText(u"a")
    assert AnsibleUnsafeBytes(b"a")
    assert AnsibleUnsafeBytes(to_bytes(u"a"))
    assert AnsibleUnsafeText(to_text(b"a"))



# Generated at 2022-06-21 09:08:07.213548
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert UnsafeProxy("a") is not None


# Generated at 2022-06-21 09:08:13.950526
# Unit test for function wrap_var
def test_wrap_var():
    # Wrap an existing unsafe
    res = wrap_var(AnsibleUnsafeText(u'test'))
    assert(res.__class__ is AnsibleUnsafeText)

    # Wrap a string
    res = wrap_var(u'test')
    assert(res.__class__ is AnsibleUnsafeText)

    # Wrap a string in a list
    res = wrap_var([u'test'])
    assert(res[0].__class__ is AnsibleUnsafeText)

    # Wrap a unicode in a list
    res = wrap_var([AnsibleUnsafeText(u"test")])
    assert(res[0].__class__ is AnsibleUnsafeText)

    # Wrap a string in a dict value
    res = wrap_var({u"test": u"value"})

# Generated at 2022-06-21 09:08:20.572726
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text('test'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'test'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'test'), AnsibleUnsafeText)

# Generated at 2022-06-21 09:08:28.221311
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.utils.unsafe_proxy import to_unsafe_text
    from ansible.utils.unsafe_proxy import wrap_var
    _dict = {'a': 'b', 'c': 'd'}
    _list = ['e', 'f', 'g']
    _tuple = ('h', 'i', 'j')
    _set = {'k', 'l', 'm'}

    _dict_expect = {'a': 'b', 'c': 'd'}
    _list_expect = ['e', 'f', 'g']
    _tuple_expect = ('h', 'i', 'j')
    _set_expect = {'k', 'l', 'm'}


# Generated at 2022-06-21 09:08:39.180822
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    testObj = NativeJinjaUnsafeText()
    testObj = NativeJinjaUnsafeText(u'Hello World')
    testObj = NativeJinjaUnsafeText(u'Hello World', 'utf8')
    testObj = NativeJinjaUnsafeText(u'Hello World', 'utf8', 'strict')
    testObj = NativeJinjaUnsafeText(b'Hello World')
    testObj = NativeJinjaUnsafeText(b'Hello World', 'utf8')
    testObj = NativeJinjaUnsafeText(b'Hello World', 'utf8', 'strict')
    testObj = NativeJinjaUnsafeText(b'Hello World', errors='strict')
    testObj = NativeJinjaUnsafeText(u'Hello World', errors='strict')

# Generated at 2022-06-21 09:08:44.148334
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    ansible_safe_bytes = AnsibleUnsafeBytes(b"This is Ansible safe")
    assert isinstance(ansible_safe_bytes, binary_type)
    assert isinstance(ansible_safe_bytes, AnsibleUnsafe)

# Generated at 2022-06-21 09:08:46.490385
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    x = AnsibleUnsafe()
    print(x, x.__UNSAFE__)


# Generated at 2022-06-21 09:08:48.726550
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    with pytest.raises(TypeError):
        AnsibleUnsafeBytes(None)


# Generated at 2022-06-21 09:08:56.706345
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(set()) == set()
    assert wrap_var(set([1, 2, 3])) == set([1, 2, 3])
    assert wrap_var(frozenset()) == frozenset()
    assert wrap_var(frozenset([1, 2, 3])) == frozenset([1, 2, 3])
    assert wrap_var({}) == {}
    assert wrap_var({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert wrap_var([]) == []
    assert wrap_var([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-21 09:09:07.589178
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.module_utils.six import b, string_types

    expected = u'Unicode: \xe4\xf6\xfc \u20ac'
    result = to_unsafe_bytes(expected)
    assert isinstance(result, AnsibleUnsafeBytes)
    assert result == b(expected)

    expected = u'Unicode: \xe4\xf6\xfc \u20ac'
    result = to_unsafe_bytes(expected, encoding='utf-8')
    assert result == b(expected)

    expected = u'Unicode: \xe4\xf6\xfc \u20ac'
    result = to_unsafe_bytes(expected, errors='ignore')

# Generated at 2022-06-21 09:09:14.912635
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY2
    iu = b'This is a test string \xc3\x85'
    ius = AnsibleUnsafeBytes(iu)
    bv = to_unsafe_bytes(iu)
    assert(isinstance(bv, AnsibleUnsafeBytes))
    if PY2:
        bv = to_unsafe_bytes(ius)
        assert(isinstance(bv, AnsibleUnsafeBytes))



# Generated at 2022-06-21 09:09:18.178166
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy('test') == 'test'
    assert type(UnsafeProxy('test')) == text_type



# Generated at 2022-06-21 09:09:28.734849
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import abc, u
    import types

    my_str = 'Hello, World'
    my_unicode = u('Hello, World')
    my_bin = b('Hello, World')
    my_int = 123
    my_none = None

    test_str = types.UnicodeType('Hello, World')
    assert isinstance(test_str, AnsibleUnsafeText)
    assert isinstance(test_str, abc.Text)

    test_bin = types.StringType('Hello, World')
    assert isinstance(test_bin, AnsibleUnsafeBytes)
    assert isinstance(test_bin, abc.Bytes)

    # Test that existing unsafe string is not wrapped
    assert UnsafeProxy(my_unicode) is my_unicode

# Generated at 2022-06-21 09:09:40.657172
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.common._collections_compat import Mapping, Set

    import json

    # This is a dict that has all of the various types of objects we will test with
    test_data = {
        'None': None,
        'Dict': {'foo': 'bar'},
        'List': [1, 2, 3],
        'Tuple': (1, 2, 3),
        'Set': {1, 2, 3},
        'Bytes': to_bytes('foobar'),
        'Text': to_text('foobar'),
        'Unicode': to_text('foobar'),
        'NativeJinjaText': to_text('foobar'),
    }

    # first we convert the test_dict to json and back
    # Note that trying to create a json object from a Set will raise TypeError

# Generated at 2022-06-21 09:09:42.341360
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert AnsibleUnsafeBytes('test').decode() == 'test'

# Generated at 2022-06-21 09:09:46.678609
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    ans_unsafe_bytes = AnsibleUnsafeBytes(u'\x00\x01\x02\x03'.encode('utf-8'))
    assert ans_unsafe_bytes.decode('utf-8') == u'\x00\x01\x02\x03'

# Generated at 2022-06-21 09:09:53.401481
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(123), int)
    assert isinstance(wrap_var('zzz'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'zzz'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var({}), dict)
    assert isinstance(wrap_var([]), list)
    assert isinstance(wrap_var(((1, 2),)), tuple)
    assert isinstance(wrap_var(set()), set)

# Generated at 2022-06-21 09:10:05.711597
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    # Check for basic functionality
    assert type(to_unsafe_bytes('a')) == AnsibleUnsafeBytes
    assert to_unsafe_bytes('a') == b"a"

    # Make sure it can handle non-standard argument formats
    assert type(to_unsafe_bytes(b'a', encoding='ascii', errors='strict')) == AnsibleUnsafeBytes
    assert type(to_unsafe_bytes('a', encoding='ascii', errors='strict')) == AnsibleUnsafeBytes

    # Check that it can still raise exceptions
    try:
        to_unsafe_bytes('¼', encoding='ascii')
        assert False, 'Converted invalid string'
    except UnicodeEncodeError:
        pass


# Generated at 2022-06-21 09:10:16.939983
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes(None) == None
    assert isinstance(to_unsafe_bytes("abc"), text_type)
    assert isinstance(to_unsafe_bytes(to_text("abc")), text_type)
    assert isinstance(to_unsafe_bytes(ansible_unsafe_text), text_type)
    assert isinstance(to_unsafe_bytes(ansible_unsafe_bytes), text_type)
    assert isinstance(to_unsafe_bytes(ansible_unsafe_text.encode("utf-8")), text_type)
    assert isinstance(to_unsafe_bytes(ansible_unsafe_bytes.decode("utf-8")), text_type)

ansible_unsafe_bytes = AnsibleUnsafeBytes("abc")

# Generated at 2022-06-21 09:10:21.870462
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy("abc"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b"abc"), AnsibleUnsafeBytes)
    assert UnsafeProxy("abc").__UNSAFE__ is True
    assert UnsafeProxy(b"abc").__UNSAFE__ is True

# Generated at 2022-06-21 09:10:29.907481
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.six import string_types
    # Check that the standard __new__ method results in an
    # UnsafeProxy if obj is unicode.
    x = u'foo'
    y = UnsafeProxy(x)
    assert isinstance(y, string_types)
    assert y.__UNSAFE__
    # Check that __new__ returns strings that are already unsafe,
    # unchanged.
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    x = AnsibleUnsafeText(u'foo')
    y = UnsafeProxy(x)
    assert isinstance(y, AnsibleUnsafeText)
    assert y.__UNSAFE__
    # Check that a instance of AnsibleUnsafeText, after being wrapped and
    # unwrapped maintains it's type.

# Generated at 2022-06-21 09:10:38.850841
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeBytes)
    assert to_unsafe_bytes('foo') == AnsibleUnsafeBytes('foo')
    # Testing for memory leaks
    for item in ['foo', b'foo', AnsibleUnsafeText('foo'), AnsibleUnsafeBytes('foo')]:
        assert id(to_unsafe_bytes(item)) == id(item)
    # Testing invalid types
    for item in [None, 5, 2.3, [], {}, ()]:
        assert to_unsafe_bytes(item) == item



# Generated at 2022-06-21 09:10:54.529786
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils._text import to_text
    test_string = to_text(b'foo', errors='surrogate_or_strict')
    assert isinstance(test_string, text_type)
    test_string = to_text(u'foo')
    assert isinstance(test_string, text_type)
    test_string = to_unsafe_text(b'foo', errors='surrogate_or_strict')
    assert isinstance(test_string, AnsibleUnsafeText)
    test_string = to_unsafe_text(u'foo')
    assert isinstance(test_string, AnsibleUnsafeText)



# Generated at 2022-06-21 09:11:05.968851
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert str(UnsafeProxy("hello")) == str("hello")
    assert isinstance(UnsafeProxy("hello"), UnsafeProxy)
    assert isinstance(UnsafeProxy("hello"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(1), UnsafeProxy)
    assert not isinstance(UnsafeProxy(1), AnsibleUnsafeText)
    assert str(UnsafeProxy(b"hello")) == str("hello")
    assert isinstance(UnsafeProxy(b"hello"), UnsafeProxy)
    assert isinstance(UnsafeProxy(b"hello"), AnsibleUnsafeText)
    assert str(UnsafeProxy(UnsafeProxy(b"hello"))) == str("hello")
    assert isinstance(UnsafeProxy(UnsafeProxy(b"hello")), UnsafeProxy)

# Generated at 2022-06-21 09:11:06.987487
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy("abc"), AnsibleUnsafeText)

# Generated at 2022-06-21 09:11:18.264485
# Unit test for function wrap_var
def test_wrap_var():
    import jinja2

    t0 = None
    t1 = 1
    t2 = 'I am string'
    t3 = {1:2, 'a':'b'}
    t4 = ['a', 1]
    t5 = ('a', 1)
    t6 = {'a':'b'}
    t7 = jinja2.Markup('I am safe string')

    t0 = wrap_var(t0)
    t1 = wrap_var(t1)
    t2 = wrap_var(t2)
    t3 = wrap_var(t3)
    t4 = wrap_var(t4)
    t5 = wrap_var(t5)
    t6 = wrap_var(t6)
    t7 = wrap_var(t7)

    assert t0 is None

# Generated at 2022-06-21 09:11:21.704655
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(test_data=dict(type='str', required=True)))
    module.exit_json(**module.params)

# Generated at 2022-06-21 09:11:30.105015
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    import unittest

    class TestUnsafeProxy(unittest.TestCase):
        def test_class(self):
            p = UnsafeProxy("Test")
            self.assertIsInstance(p, AnsibleUnsafeText)
            self.assertIsInstance(p, text_type)
            self.assertIsInstance(p, string_types)
            with self.assertRaises(UnicodeEncodeError):
                p.encode("ascii")

        def test_super(self):
            p = UnsafeProxy("Test")
            self.assertEqual(p[0], "T")
            self.assertEqual(p[1], "e")
            self.assertEqual(p[2], "s")
            self.assertEqual(p[3], "t")


# Generated at 2022-06-21 09:11:32.538968
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    instance = AnsibleUnsafeText("safe")
    assert type(instance) == AnsibleUnsafeText
    assert instance.__UNSAFE__ == True


# Generated at 2022-06-21 09:11:38.962855
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    test_values = [
        (1, b'1'),
        (True, b'true'),
        ([1, 2], b'[1, 2]'),
        ({'a':1}, b"{'a': 1}"),
        (b'password', b'password'),
        (u'password', b'password'),
    ]
    for test_value, expected in test_values:
        result = to_unsafe_bytes(test_value)
        assert result == expected, "%r == %r failed" % (result, expected)
        assert isinstance(result, AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:11:48.757507
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from types import UnboundMethodType
    from ansible.module_utils.six import string_types
    assert UnsafeProxy(None) == None
    assert UnsafeProxy('') == ''
    assert UnsafeProxy('hello') == u'hello'
    assert type(UnsafeProxy('')) in string_types
    assert type(UnsafeProxy('hello')) in string_types
    assert type(UnsafeProxy(u'hello')) in string_types
    assert UnsafeProxy(u'hello') == u'hello'
    assert UnsafeProxy(b'hello') == u'hello'
    assert UnsafeProxy(AnsibleUnsafeText('hello')) == AnsibleUnsafeText('hello')
    assert UnsafeProxy(AnsibleUnsafeBytes(b'hello')) == AnsibleUnsafeBytes(b'hello')

# Generated at 2022-06-21 09:11:49.611424
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text('foo'), AnsibleUnsafeText)


# Generated at 2022-06-21 09:12:02.280587
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText('test').encode(), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:12:13.735327
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.utils.display import Display
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.utils._text import to_text
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves.jinja2.native import NativeEnvironment
    from ansible.module_utils.common.collections import is_sequence

    d = Display()
    i = 1
    # test if the exception is thrown
    try:
        i = UnsafeProxy(1)
    except Exception as e:
        d.deprecated("Wrong UnsafeProxy!")
    # test if all strings is wrapped
    assert isinstance(UnsafeProxy(""), AnsibleUnsafeText)

# Generated at 2022-06-21 09:12:25.289058
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(b'test'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var([]), AnsibleUnsafe)
    assert isinstance(wrap_var(()), AnsibleUnsafe)
    assert isinstance(wrap_var({}), AnsibleUnsafe)
    assert isinstance(wrap_var(set()), AnsibleUnsafe)
    assert isinstance(wrap_var(5), AnsibleUnsafe)
    assert isinstance(wrap_var(5.5), AnsibleUnsafe)
    assert isinstance(wrap_var(u'test'), AnsibleUnsafeText)

# Generated at 2022-06-21 09:12:34.569831
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils._text import to_bytes
    # Test with a str object
    result = UnsafeProxy("a")
    assert isinstance(result, AnsibleUnsafeText)
    # Test with an AnsibleUnsafeBytes object
    result = UnsafeProxy(AnsibleUnsafeBytes("a"))
    assert isinstance(result, AnsibleUnsafeBytes)
    # Test with an AnsibleUnsafeText object
    result = UnsafeProxy(AnsibleUnsafeText("a"))
    assert isinstance(result, AnsibleUnsafeText)
    # Test with an int object
    result = UnsafeProxy(2)
    assert result == 2


# Generated at 2022-06-21 09:12:43.348628
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes, AnsibleUnsafeText
    from ansible.utils.native_jinja import NativeJinjaText

    assert isinstance(wrap_var("test"), AnsibleUnsafeText)
    assert isinstance(wrap_var(u"test"), AnsibleUnsafeText)
    assert isinstance(wrap_var(b"test"), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var([]), list)
    assert isinstance(wrap_var(["test", "test"]), list)
    assert isinstance(wrap_var(["test", u"test"]), list)

# Generated at 2022-06-21 09:12:52.835358
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.display import Display
    from ansible.utils.unsafe_proxy import UnsafeProxy

    display = Display()
    unsafe_proxy = UnsafeProxy(u'foo')

    assert isinstance(unsafe_proxy, AnsibleUnsafeText)
    assert display.deprecations[0].message == 'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead'
    assert display.deprecations[0].version == '2.13'
    assert display.deprecations[0].collection_name == 'ansible.builtin'

# Generated at 2022-06-21 09:12:56.808660
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    test_str = "str"
    ans_str = AnsibleUnsafeText(test_str)
    assert isinstance(ans_str, AnsibleUnsafeText)
    assert isinstance(ans_str, text_type)


# Generated at 2022-06-21 09:13:04.716790
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(u"süsse") == u"süsse"
    assert to_unsafe_text(b"s\xc3\xbcsse", errors="surrogate_or_strict") == u"süsse"
    assert to_unsafe_text(b"s\xc3\xbcsse", errors="surrogate_then_replace") == u"s\ufffd\ufffdss\ufffd"
    assert to_unsafe_text(b"s\xc3\xbcsse", errors="surrogate_then_ignore") == u"sss"
    # bytes(b"susse") is not equal to unicode(u"susse") in Python 2.7.

# Generated at 2022-06-21 09:13:06.916978
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert AnsibleUnsafeBytes(b'foo').decode() == AnsibleUnsafeText('foo')


# Generated at 2022-06-21 09:13:10.035100
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    in_text=text_type("any string")
    assert isinstance(wrap_var(in_text).encode('utf-8'), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:13:41.906739
# Unit test for function wrap_var
def test_wrap_var():
    assert not getattr(wrap_var('hello'), '__UNSAFE__', None)
    assert getattr(wrap_var(b'hello'), '__UNSAFE__', None)
    assert getattr(wrap_var(AnsibleUnsafeBytes(b'hello')), '__UNSAFE__', None)
    assert getattr(wrap_var({'a': b'hello'}), '__UNSAFE__', None)
    assert getattr(wrap_var({'a': AnsibleUnsafeBytes(b'hello')}), '__UNSAFE__', None)
    assert getattr(wrap_var({'a': {'b': b'hello'}}), '__UNSAFE__', None)

# Generated at 2022-06-21 09:13:43.866073
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    obj = NativeJinjaUnsafeText('/c/Hex/Saved')
    if not obj:
        raise AssertionError('constructor of class NativeJinjaUnsafeText failed')

# Generated at 2022-06-21 09:13:47.008274
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    test_data = 'This is the test data'
    test_res_obj = AnsibleUnsafeText(test_data)
    assert all(isinstance(test_res_obj, AnsibleUnsafeText) for test_res_obj in [test_res_obj])


# Generated at 2022-06-21 09:13:55.700131
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    ansi_unsafe_text_test = AnsibleUnsafeText('test_string')
    ansi_unsafe_text_test_encoded = ansi_unsafe_text_test.encode()
    assert isinstance(ansi_unsafe_text_test_encoded, binary_type) is True
    assert isinstance(ansi_unsafe_text_test_encoded, AnsibleUnsafeBytes) is True
    assert ansi_unsafe_text_test_encoded == b'test_string'

# Generated at 2022-06-21 09:13:59.560635
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text('abc'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'abc'), AnsibleUnsafeText)
    assert to_unsafe_text(u'abc') == u'abc'

# Generated at 2022-06-21 09:14:02.521185
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    if NativeJinjaUnsafeText('a') == 'a':
        print("True")
    else:
        print("False")

if __name__ == '__main__':
    test_NativeJinjaUnsafeText()

# Generated at 2022-06-21 09:14:08.230098
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(u'hello'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(to_unsafe_text(u'hello')), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(to_unsafe_bytes('hello')), AnsibleUnsafeText)
    assert to_unsafe_text(u'hello') == u'hello'
    assert to_unsafe_text(to_unsafe_text(u'hello')) == u'hello'
    assert to_unsafe_text(to_unsafe_bytes('hello')) == u'hello'


# Generated at 2022-06-21 09:14:17.089709
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # Test valid encoding
    plaintext = to_unsafe_text(b"\xCB\xFF")
    assert(isinstance(plaintext.encode('utf-8'), AnsibleUnsafeBytes))

    # Test exceptions while encoding
    try:
        assert(isinstance(plaintext.encode('utf-16'), AnsibleUnsafeBytes))
    except UnicodeDecodeError:
        pass
    else:
        raise AssertionError(
            "UnicodeDecodeError was not thrown for invalid encoding."
        )


# Generated at 2022-06-21 09:14:19.017238
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    wrapped_var = UnsafeProxy("test")
    assert(isinstance(wrapped_var, AnsibleUnsafeText))

# Generated at 2022-06-21 09:14:23.820707
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    class A(object):
        pass

    obj1 = UnsafeProxy(A)
    obj2 = UnsafeProxy('a')
    assert(isinstance(obj1, A))
    assert(obj1.__UNSAFE__)
    assert(isinstance(obj2, text_type))
    assert(obj2.__UNSAFE__)

# Generated at 2022-06-21 09:15:06.130991
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert NativeJinjaUnsafeText("foo").__str__() == "foo"

# Generated at 2022-06-21 09:15:10.148974
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    text_obj = AnsibleUnsafeText(u'foo')
    text_obj_encoded = text_obj.encode()
    assert type(text_obj_encoded) == AnsibleUnsafeBytes
    # test that the original object is unchanged
    assert type(text_obj) == AnsibleUnsafeText


# Generated at 2022-06-21 09:15:11.598130
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert(isinstance(to_unsafe_text("some string"), AnsibleUnsafeText))

# Generated at 2022-06-21 09:15:17.317765
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    import random

    for i in range(10):
        n = random.randint(0, 255)
        test_bytes = bytes([n])
        test_decoded = AnsibleUnsafeBytes(test_bytes).decode('utf-8')
        assert test_decoded == AnsibleUnsafeText(chr(n)), "Test failed at value: %d" % n


# Generated at 2022-06-21 09:15:27.968269
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes('foo') == b'foo'
    assert AnsibleUnsafeBytes('foo').decode() == 'foo'
    assert isinstance(AnsibleUnsafeBytes('foo'), AnsibleUnsafeBytes)
    assert AnsibleUnsafeBytes('foo').decode().encode() == b'foo'
    assert not isinstance(AnsibleUnsafeBytes('foo').decode(), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeBytes('foo').decode(), AnsibleUnsafeText)
    assert AnsibleUnsafeBytes('foo').decode().encode().decode().encode() == b'foo'
    assert not isinstance(AnsibleUnsafeBytes('foo').decode().encode().decode(), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:15:33.314155
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    s = AnsibleUnsafeText('Ansible is great')
    assert isinstance(s, AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(s), AnsibleUnsafeText)
    assert isinstance(to_unsafe_bytes(s), AnsibleUnsafeBytes)
    assert str(s) == 'Ansible is great'


# Generated at 2022-06-21 09:15:43.234878
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert wrap_var(u"string") == u"string"
    assert wrap_var(u"str\u0069ng") == u"str\u0069ng"
    assert wrap_var("string") == u"string"
    assert wrap_var("str\u0069ng") == u"str\u0069ng"

    # Test that we get an exception if the text is unable to be properly encoded
    try:
        wrap_var("str\u0069ng".encode('ascii'))
        assert False == True
    except UnicodeEncodeError:
        assert True == True



# Generated at 2022-06-21 09:15:45.572081
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    for val in ("", "toto", 123):
        x = AnsibleUnsafeText(val)
        assert x == val

# Generated at 2022-06-21 09:15:49.418904
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    proxy = UnsafeProxy("foo")
    assert proxy == "foo"
    assert isinstance(proxy, AnsibleUnsafeText)
    proxy = UnsafeProxy("foo".encode("utf-8"))
    assert proxy == "foo"
    assert isinstance(proxy, AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:15:52.124047
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    o = AnsibleUnsafeBytes(b'xyz')
    assert isinstance(o.decode('UTF-8'), AnsibleUnsafeText)

