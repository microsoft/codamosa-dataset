

# Generated at 2022-06-21 09:06:32.281976
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.collections import to_text

    # Test for unicode strings
    unicode_string = to_text(u'abc')
    assert isinstance(UnsafeProxy(unicode_string), AnsibleUnsafeText)

    # Test for text strings
    text_string = to_text(b'abc')
    assert isinstance(UnsafeProxy(text_string), AnsibleUnsafeText)

    # Test for binary strings
    binary_string = to_text(b'abc')
    assert isinstance(UnsafeProxy(binary_string), AnsibleUnsafeText)

    # Test for object that are already unsafe
    assert UnsafeProxy(text_string) is UnsafeProxy(unicode_string)


# Generated at 2022-06-21 09:06:35.213139
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    class A(AnsibleUnsafe):
        pass
    a = A()
    assert a.__UNSAFE__

# Unit tests for wrap_var method

# Generated at 2022-06-21 09:06:38.567126
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    t = AnsibleUnsafeText("test")
    assert isinstance(t.encode('utf-8'), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:06:40.458012
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(u'foo'), text_type)



# Generated at 2022-06-21 09:06:42.220300
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    proxy_obj = UnsafeProxy('test')
    assert isinstance(proxy_obj, AnsibleUnsafeText)

# Generated at 2022-06-21 09:06:51.555479
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # Test for AnsibleUnsafeBytes() with initial value which is the most direct way to construct an AnsibleUnsafeBytes object
    # Test for bytes type
    foo = AnsibleUnsafeBytes(b"test string 1")
    if not isinstance(foo, AnsibleUnsafeBytes):
        raise AssertionError('Test failed with test string: %s, as %s' % (str(foo), 'bytes type'))

    # Test for str type
    foo = AnsibleUnsafeBytes("test string 2")
    if not isinstance(foo, AnsibleUnsafeBytes):
        raise AssertionError('Test failed with test string: %s, as %s' % (str(foo), 'str type'))

    # Test for iterable input
    foo = AnsibleUnsafeBytes([1, 2, 3, 4])

# Generated at 2022-06-21 09:06:59.938962
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import text_type
    utf = to_text(b'\xc3\xa4\xc3\xa4\xc3\xa4')
    ans = AnsibleUnsafeText(utf)
    res = ans.encode()
    assert isinstance(res, AnsibleUnsafeBytes)
    assert res == b'\xc3\xa4\xc3\xa4\xc3\xa4'


# Generated at 2022-06-21 09:07:02.649991
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert(isinstance(NativeJinjaUnsafeText(u''), NativeJinjaUnsafeText))

# Generated at 2022-06-21 09:07:11.565117
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import text_type
    import sys
    import copy

    if sys.version_info < (3, 0):
        test_text = "\xc3\xa9"
        test_binary = "e\xf1"
    else:
        test_text = "é"
        test_binary = b"\xc3\xa9"

    # Test conditional in __new__ which handles unicode strings.
    assert isinstance(UnsafeProxy(test_text), text_type)
    assert isinstance(UnsafeProxy(test_binary), AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:07:22.695106
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    dict1 = dict()
    dict1['test'] = 'test'
    list1 = list()
    list1.append("test1")
    list1.append("test2")
    list1.append("test3")
    assert isinstance(AnsibleUnsafe(), AnsibleUnsafe)
    assert isinstance(AnsibleUnsafeText("test"), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeBytes("test"), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText("test"), AnsibleUnsafe)
    assert isinstance(AnsibleUnsafeBytes("test"), AnsibleUnsafe)
    assert isinstance(AnsibleUnsafeText({'test'}), AnsibleUnsafe)
    assert isinstance(AnsibleUnsafeBytes({'test'}), AnsibleUnsafe)

# Generated at 2022-06-21 09:07:29.668492
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    b = to_unsafe_bytes('test')
    assert isinstance(b, AnsibleUnsafeBytes)
    assert type(b).__name__ == 'AnsibleUnsafeBytes'
    assert b == to_bytes('test', errors='surrogate_or_strict')


# Generated at 2022-06-21 09:07:40.945239
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    _bytes = b"some bytes here"
    _str = u"some string here"
    _unicode = u"some unicode character \u201c here"
    _int = 1
    _float = 1.0
    _bool = True
    _dict = {u'foo': u'bar'}
    _list = [u'foo', u'bar']
    _set = set([u'foo', u'bar'])
    _None = None
    _SafeText = AnsibleUnsafeText(u'safe Text')
    _SafeBytes = AnsibleUnsafeBytes(u'safe Bytes'.encode())


# Generated at 2022-06-21 09:07:42.691677
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert not hasattr(AnsibleUnsafe, '__UNSAFE__')



# Generated at 2022-06-21 09:07:53.033927
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    class NewStyleSafeStr(str):
        pass

    class NewStyleSafeUnicode(unicode):
        pass

    class NewStyleSafeBytes(bytes):
        pass

    assert isinstance(UnsafeProxy("test"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(NewStyleSafeStr("test")), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(NewStyleSafeUnicode("test")), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(NewStyleSafeBytes("test")), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(b"test"), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(u"test"), AnsibleUnsafeText)



# Generated at 2022-06-21 09:07:56.072441
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    obj = AnsibleUnsafeText('hello')
    ansibleUnsafe = AnsibleUnsafe()
    text_type = text_type()
    assert isinstance(obj, AnsibleUnsafe)
    assert isinstance(obj, text_type)

# Generated at 2022-06-21 09:08:03.151748
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    t = AnsibleUnsafeText("test string")
    assert t.encode("utf-8") == AnsibleUnsafeText("test string").encode("utf-8")
    assert t.encode("utf-8").decode("utf-8") == AnsibleUnsafeText("test string")
    assert t.encode("utf-16") == AnsibleUnsafeText("test string").encode("utf-16")
    assert t.encode("utf-16").decode("utf-16") == AnsibleUnsafeText("test string")
    assert t.encode("utf-32") == AnsibleUnsafeText("test string").encode("utf-32")
    assert t.encode("utf-32").decode("utf-32") == AnsibleUnsafeText("test string")



# Generated at 2022-06-21 09:08:07.586285
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b"sample").decode(), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeBytes(b"sample").decode(encoding="ascii"), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeBytes(b"sample").decode(encoding="ascii", errors="strict"), AnsibleUnsafeText)


# Generated at 2022-06-21 09:08:10.045295
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    '''
    >>> u = AnsibleUnsafeText('a')
    >>> type(u.encode('utf-8'))
    <class 'ansible.module_utils.six.binary_type'>
    '''
    pass

# Generated at 2022-06-21 09:08:16.165132
# Unit test for function wrap_var
def test_wrap_var():
    # Test the base functions
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(""), text_type)
    assert isinstance(wrap_var("foo"), text_type)
    assert isinstance(wrap_var("foo"), AnsibleUnsafeText)
    assert isinstance(wrap_var("foo".encode("ascii")), binary_type)
    assert isinstance(wrap_var("foo".encode("ascii")), AnsibleUnsafeBytes)
    assert isinstance(wrap_var({"1": "2"}), dict)
    assert isinstance(wrap_var(("1", "2")), tuple)
    assert isinstance(wrap_var((1, 2)), tuple)
    assert isinstance(wrap_var([1, 2]), list)

# Generated at 2022-06-21 09:08:19.703770
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # Create an instance of the class
    unsafeObj = AnsibleUnsafe()
    # Verify that the __UNSAFE__ attribute is set
    assert hasattr(unsafeObj, '__UNSAFE__')

# Generated at 2022-06-21 09:08:25.423014
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # Create test AnsibleUnsafeText object
    x = AnsibleUnsafeText('x')
    # Call method encode
    result = x.encode()
    # Check result is correct type
    assert isinstance(result, AnsibleUnsafeBytes)
    assert result.__UNSAFE__
    # Check value is correct
    assert result == b'x'


# Generated at 2022-06-21 09:08:32.516147
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    import string
    import random
    ansible_unsafe_bytes = AnsibleUnsafeBytes(bytes(random.choice(string.printable.encode()) for i in range(0, 9)))
    assert isinstance(ansible_unsafe_bytes, AnsibleUnsafe)
    assert isinstance(ansible_unsafe_bytes, binary_type)



# Generated at 2022-06-21 09:08:36.465959
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    res = UnsafeProxy("test")
    assert res == b"test"
    import ansible.module_utils.six
    assert isinstance(res, ansible.module_utils.six.binary_type)
    assert isinstance(res, AnsibleUnsafe)



# Generated at 2022-06-21 09:08:50.173899
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text_utils import to_text
    #Test with unicode
    test_ansible_module = AnsibleModule(supports_check_mode=True)
    test_unicode = u'\xe1\xbc\xb8\xce\xbc\xce\xb5\xcf\x84\xce\xbf\x20\xce\xb5\xce\xb9\xce' \
                   u'\xbb\xce\xac\xcf\x84\xce\xb5\xcf\x85\xcf\x82'

# Generated at 2022-06-21 09:08:56.153714
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy(1), int)
    assert isinstance(UnsafeProxy(1.1), float)
    assert isinstance(UnsafeProxy(True), bool)
    assert type(UnsafeProxy(1)) == int
    assert type(UnsafeProxy(1.1)) == float
    assert type(UnsafeProxy(True)) == bool

    assert type(UnsafeProxy(b'byte')) == AnsibleUnsafeBytes
    assert type(UnsafeProxy('str')) == AnsibleUnsafeText
    assert type(UnsafeProxy(u'uni')) == AnsibleUnsafeText



# Generated at 2022-06-21 09:09:01.434170
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.six import PY2
    text = to_unsafe_text('test')
    assert isinstance(text, AnsibleUnsafeText)
    assert text == 'test'
    if PY2:
        assert isinstance(text.encode('utf-8'), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:09:05.472256
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    ba = AnsibleUnsafeBytes(b'\xa1')
    decoded_ba = ba.decode('latin-1')

    assert isinstance(decoded_ba, AnsibleUnsafeText)
    assert decoded_ba == u'\xa1'


# Generated at 2022-06-21 09:09:12.851531
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeBytes(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeBytes(AnsibleUnsafeText('foo')), AnsibleUnsafeBytes)
    assert hasattr(AnsibleUnsafeBytes(b'foo'), '__UNSAFE__')
    assert hasattr(AnsibleUnsafeBytes(AnsibleUnsafeBytes(b'foo')), '__UNSAFE__')
    assert hasattr(AnsibleUnsafeBytes(AnsibleUnsafeText('foo')), '__UNSAFE__')
    assert isinstance(AnsibleUnsafeBytes(b'foo').decode(), AnsibleUnsafeText)
    assert isinstance

# Generated at 2022-06-21 09:09:25.263243
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    import sys
    # Test text
    text = 'hello world'
    text_result = UnsafeProxy(text)
    assert isinstance(text_result, AnsibleUnsafeText)
    # Test bytes
    bytes_ = b'hello world'
    bytes_result = UnsafeProxy(bytes_)
    assert isinstance(bytes_result, AnsibleUnsafeBytes)
    # Test native strings
    if sys.version_info < (3, 0):
        native_string = str('hello world')
        assert isinstance(native_string, str)
        native_string_result = UnsafeProxy(native_string)
        assert isinstance(native_string_result, AnsibleUnsafeText)
    # Test lists

# Generated at 2022-06-21 09:09:31.401231
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    check_text = 'Test'
    bytes = to_bytes(check_text, errors='surrogate_or_strict')
    ansible_text = AnsibleUnsafeBytes(bytes).decode(errors='surrogate_or_strict')
    assert isinstance(ansible_text, AnsibleUnsafeText)
    assert ansible_text == check_text


# Generated at 2022-06-21 09:09:35.413257
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText('hello world').encode(), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:09:39.477439
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    # Data
    data = '\xe2\x82\xac'.decode('utf-8')

    # Expected result
    expected = wrap_var('\xe2\x82\xac')

    result = to_unsafe_text(data)
    assert expected == result



# Generated at 2022-06-21 09:09:43.995401
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(u"hello world"), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u"hello world", encoding="utf8", errors='ignore'), AnsibleUnsafeText)



# Generated at 2022-06-21 09:09:45.755040
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes("blah"), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:09:47.914791
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    input = "mock-input"
    unsafe_text = AnsibleUnsafeText(input)
    unsafe_bytes = unsafe_text.encode()
    assert isinstance(unsafe_text, AnsibleUnsafeText)
    assert isinstance(unsafe_bytes, AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:09:51.348886
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    obj = AnsibleUnsafeText('this is a test')
    bytes = obj.encode()
    assert(type(bytes) is AnsibleUnsafeBytes)
    assert(bytes == b"this is a test")


# Generated at 2022-06-21 09:09:54.849521
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    s = 'Hello world!'
    # Call function to test and assert result
    result = UnsafeProxy(s)
    assert isinstance(result, AnsibleUnsafeText)
    assert result == s


# Generated at 2022-06-21 09:09:58.610833
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    input = "foo"
    assert UnsafeProxy(input) == input
    assert UnsafeProxy(input).__UNSAFE__ == True



# Generated at 2022-06-21 09:10:08.511586
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY2
    if PY2:
        # Strings and Unicode Strings
        assert isinstance(to_unsafe_bytes('str'), AnsibleUnsafeBytes)
        assert isinstance(to_unsafe_bytes(u'str'), AnsibleUnsafeBytes)
        # List of Strings
        assert isinstance(to_unsafe_bytes(['str']), list)
        assert isinstance(to_unsafe_bytes(['str'])[0], AnsibleUnsafeBytes)
        # List of Unicode Strings
        assert isinstance(to_unsafe_bytes([u'str']), list)
        assert isinstance(to_unsafe_bytes([u'str'])[0], AnsibleUnsafeBytes)
        # List of Lists of Strings

# Generated at 2022-06-21 09:10:20.167842
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    import unittest
    from ansible.module_utils.common.text_utils import to_bytes, to_bytes
    from ansible.module_utils.six import BytesIO
    class TestAnsibleUnsafeBytes(unittest.TestCase):
        def setUp(self):
            self.byte_string = to_bytes("abc")
            self.unsafe_byte = AnsibleUnsafeBytes(self.byte_string)

        def test_encode(self):
            result = self.unsafe_byte.encode('utf-8')
            self.assertIsInstance(result, AnsibleUnsafeBytes)
            self.assertEqual(self.byte_string, result)

        def test_decode(self):
            result = self.unsafe_byte.decode('utf-8')
            self.assertIsInstance

# Generated at 2022-06-21 09:10:29.649471
# Unit test for function wrap_var
def test_wrap_var():
    import json
    import yaml
    text = "this is a test"
    text_u = wrap_var(text)
    assert isinstance(text_u, AnsibleUnsafeText)
    assert text == text_u

    d = {"a": "b"}
    d_u = wrap_var(d)
    assert isinstance(d_u, dict)
    d_u_1 = wrap_var(d_u)
    assert text == text_u

    l = ["a", "b"]
    l_u = wrap_var(l)
    assert isinstance(l_u, list)
    l_u_1 = wrap_var(l_u)
    assert text == text_u

    t = ("a", "b")
    t_u = wrap_var(t)

# Generated at 2022-06-21 09:10:38.808346
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    testStr = 'test string'
    testUnsafeBytes = AnsibleUnsafeBytes(testStr.encode('utf-8'))

    # assert testUnsafeBytes is of type AnsibleUnsafeBytes
    assert isinstance(testUnsafeBytes, AnsibleUnsafeBytes)

    # assert testUnsafeBytes is instance of class AnsibleUnsafe
    assert isinstance(testUnsafeBytes, AnsibleUnsafe)

    # assert calling decode returns an instance of class AnsibleUnsafeText
    assert isinstance(testUnsafeBytes.decode('utf-8'), AnsibleUnsafeText)


# Generated at 2022-06-21 09:10:40.492254
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert isinstance(AnsibleUnsafeText('some string'), AnsibleUnsafeText)



# Generated at 2022-06-21 09:10:48.425233
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    class TUnicode(object):
        def __unicode__(self):
            return u'foo'

    u = TUnicode()
    assert isinstance(u, TUnicode)
    assert isinstance(u, string_types)
    assert not isinstance(u, AnsibleUnsafe)

    UnsafeProxy(u)
    assert isinstance(u, AnsibleUnsafe)
    assert isinstance(u, string_types)
    assert not isinstance(u, TUnicode)

# Generated at 2022-06-21 09:10:58.103180
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils._text import to_text
    from ansible.utils.vars import merge_hash
    from ansible.plugins.loader import should_filter_data_structure
    assert wrap_var(u'hello') == u'hello'
    assert isinstance(wrap_var(u'hello'), AnsibleUnsafeText)
    assert wrap_var(None) is None
    assert wrap_var(u'hello') == to_unsafe_text(u'hello')
    assert wrap_var(u'hello') == to_unsafe_bytes(u'hello')
    assert wrap_var(b'hello') == AnsibleUnsafeBytes(b'hello')
    assert wrap_var(AnsibleUnsafeText(u'hello')) == AnsibleUnsafeText(u'hello')

# Generated at 2022-06-21 09:11:02.791448
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    ansible_unsafe_string = AnsibleUnsafeText("Hello")
    assert(ansible_unsafe_string.__UNSAFE__ == True)
    assert(ansible_unsafe_string == u"Hello")



# Generated at 2022-06-21 09:11:06.620996
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    test_str = '{{ some_var }}'
    from ansible.vars.unsafe_proxy import NativeJinjaUnsafeText
    ujt = NativeJinjaUnsafeText(test_str)
    assert isinstance(ujt, NativeJinjaUnsafeText)


# Generated at 2022-06-21 09:11:10.493280
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('foo') == b'foo'
    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:11:16.863523
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    a = AnsibleUnsafeBytes(b"Test")
    b = AnsibleUnsafeText('Test')
    assert(a == b'Test')
    assert(b == 'Test')
    assert(not hasattr(a, '__UNSAFE__'))
    assert(b.__UNSAFE__)


# Generated at 2022-06-21 09:11:27.060107
# Unit test for function wrap_var
def test_wrap_var():
    my_dict = {u'item1': u'value1', u'item2': u'value2'}
    my_list = [u'value3', u'value4']
    my_set = set([u'value3', u'value4'])
    my_str = u'my str'
    my_bytes = b'my bytes'

    assert isinstance(wrap_var(my_dict), dict)
    assert isinstance(wrap_var(my_dict)[u'item1'], AnsibleUnsafeText)
    assert isinstance(wrap_var(my_dict)[u'item2'], AnsibleUnsafeText)

    assert isinstance(wrap_var(my_list), list)
    assert isinstance(wrap_var(my_list)[0], AnsibleUnsafeText)

# Generated at 2022-06-21 09:11:29.714450
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy(u"hi"), AnsibleUnsafeText)



# Generated at 2022-06-21 09:11:31.055255
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert(AnsibleUnsafeBytes('string') == 'string')


# Generated at 2022-06-21 09:11:39.509121
# Unit test for function wrap_var
def test_wrap_var():
    import json
    import pytest
    from ansible.utils.unsafe_proxy import _wrap_dict, _wrap_sequence, _wrap_set, wrap_var

    tests = {
        'string': wrap_var('1'),
        'int': wrap_var(1),
        'list': wrap_var([1, 2, 3]),
        'dict': wrap_var({'a': 'b'}),
        'tuple': wrap_var(('a', 'b'))
    }

    expected = json.loads('''{
        "string": "1",
        "int": 1,
        "list": [1, 2, 3],
        "dict": {"a": "b"},
        "tuple": ["a", "b"]
    }''')

    assert tests == expected

    tuple_expected = json.loads

# Generated at 2022-06-21 09:11:41.243831
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__(): # pylint: disable=missing-function-docstring
    assert UnsafeProxy("str") == AnsibleUnsafeText("str")

# Generated at 2022-06-21 09:11:50.464117
# Unit test for function wrap_var
def test_wrap_var():
    # Mapping
    assert wrap_var({}) == {}
    assert wrap_var({'a': 'b'}) == {'a': 'b'}
    assert wrap_var({'a': ('b', 'c')}) == {'a': ('b', 'c')}

    # Sequence
    assert wrap_var(('a', 'b')) == ('a', 'b')
    assert wrap_var(['a', 'b']) == ['a', 'b']
    assert wrap_var(u'a') == 'a'
    assert wrap_var('a') == 'a'
    assert wrap_var(b'a') == b'a'
    assert wrap_var(set(['a', 'b'])) == set(['a', 'b'])


# Generated at 2022-06-21 09:11:55.117345
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text('foo') == u'foo'
    assert to_unsafe_text(None) is None
    assert to_unsafe_text('\u2019') == u'\u2019'
    assert to_unsafe_text(u'\u2019') == u'\u2019'
    assert isinstance(to_unsafe_text('\u2019'), text_type)
    assert isinstance(to_unsafe_text(u'\u2019'), text_type)
    assert to_unsafe_text('foo'.encode('utf-8')) == u'foo'
    assert to_unsafe_text(u'foo'.encode('utf-8')) == u'foo'
    assert isinstance(to_unsafe_text('foo'.encode('utf-8')), text_type)
   

# Generated at 2022-06-21 09:12:02.999268
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    test_data = [
        (u'Unsafe', u'Unsafe'),
        (b'Unsafe', u'Unsafe'),
        (AnsibleUnsafeText('Unsafe'), u'Unsafe'),
        (AnsibleUnsafeBytes(b'Unsafe'), u'Unsafe')
    ]

    for data, expected in test_data:
        assert(AnsibleUnsafeBytes(data).decode() == expected)



# Generated at 2022-06-21 09:12:10.694835
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    class AnsibleUnsafeBytes_decode(unittest.TestCase):
        def test_should_return_AnsibleUnsafeText_when_called(self):
            ansible_unsafe_bytes = AnsibleUnsafeBytes_decode(b'hello')

            result = ansible_unsafe_bytes.decode()

            assert isinstance(result, AnsibleUnsafeText)
            assert result == u'hello'

    return AnsibleUnsafeBytes_decode()



# Generated at 2022-06-21 09:12:12.402859
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b'yaml').decode(), AnsibleUnsafeText)

# Generated at 2022-06-21 09:12:18.895412
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # Given
    input_bytes = b"a\xb1\xb2\xb3\xbd"

    # When
    actual_ansible_text = AnsibleUnsafeBytes(input_bytes).decode('utf-8', 'surrogateescape')

    # Then
    expected_ansible_text = b"a\xe2\x80\x81\xe2\x80\x82\xe2\x80\x83\xe2\x80\xbc".decode('utf-8', 'surrogateescape')
    assert actual_ansible_text == expected_ansible_text



# Generated at 2022-06-21 09:12:23.970018
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    my_t = AnsibleUnsafeText('abc')
    my_b = my_t.encode('utf-8')
    assert isinstance(my_b, AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:12:26.038525
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert type(AnsibleUnsafeBytes()) is AnsibleUnsafeBytes


# Generated at 2022-06-21 09:12:37.135430
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.unit.compat.mock import MagicMock, patch

    with patch.object(to_text, '__name__') as mock_to_text:
        mock_to_text.return_value = 'to_text'

        assert isinstance(to_unsafe_text(b'test string'), AnsibleUnsafeText)
        assert isinstance(to_unsafe_text(u'test string'), AnsibleUnsafeText)
        assert isinstance(to_unsafe_text(AnsibleUnsafeBytes(b'test string')), AnsibleUnsafeText)
        assert isinstance(to_unsafe_text(AnsibleUnsafeText(u'test string')), AnsibleUnsafeText)


# Generated at 2022-06-21 09:12:41.785954
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    test_cases = [
        ('foo', b'foo', 'foo'),
        (b'\xff', '\\xff', '\\xff'),
        (b'\x81', '\\x81', '\\x81'),
        (b'foo', 'foo', 'foo'),
    ]
    for tc in test_cases:
        assert AnsibleUnsafeBytes(tc[0]) == tc[1]
        assert AnsibleUnsafeText(tc[2]) == tc[2]

# Generated at 2022-06-21 09:12:53.804478
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    input_text = '123'
    output_text = AnsibleUnsafeText(input_text).encode()

    assert output_text == b'123'
    assert isinstance(output_text, AnsibleUnsafeBytes)
    assert type(output_text).__name__ == 'AnsibleUnsafeBytes'


# Actual use case for AnsibleUnsafeText in the code base.
# The following code will be moved to a separate unit test file once the
# module_utils/basic.py code is broken up into separate files.
if __name__ == '__main__':
    s = AnsibleUnsafeText(u'{{"hello"}}')
    assert s == u'{{"hello"}}'
    assert isinstance(s, str)

# Generated at 2022-06-21 09:12:55.579506
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText('abc').encode(), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:13:04.376691
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import sys
    import types
    if sys.version_info[0] >= 3:
        long = int

    assert wrap_var("foo") == "foo"
    assert isinstance(wrap_var("foo"), AnsibleUnsafeText)

    assert wrap_var(b"foo") == b"foo"
    assert isinstance(wrap_var(b"foo"), AnsibleUnsafeBytes)

    assert wrap_var(123) == 123
    assert isinstance(wrap_var(123), int)

    assert wrap_var(123.4) == 123.4
    assert isinstance(wrap_var(123.4), float)

    assert wrap_var(long(123.4)) == long(123.4)

# Generated at 2022-06-21 09:13:06.065186
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
	a = AnsibleUnsafeText ("Hi")
	assert a == "Hi"

# Generated at 2022-06-21 09:13:07.302192
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    pass


# Generated at 2022-06-21 09:13:11.982054
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    data = b'\x00\x01\x02'
    aub = AnsibleUnsafeBytes(data)

    assert isinstance(aub, AnsibleUnsafe)
    assert isinstance(aub, binary_type)
    assert aub == data



# Generated at 2022-06-21 09:13:25.729657
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    import unittest
    import sys

    # Test that the function is idempotent
    def test_idempotent(self):
        self.assertIs(to_unsafe_bytes('foo'), to_unsafe_bytes('foo'))

    # Test that a str is converted to a unicode object
    def test_str_to_text(self):
        for encoding in ('utf-8', 'ascii', 'latin1'):
            self.assertEqual(unicode, type(to_unsafe_text(u'foo', encoding=encoding)))

    # Test that a unicode object is not altered
    def test_text_unchanged(self):
        self.assertEqual(u'foo', to_unsafe_text(u'foo'))

    # Test that a binary string is converted to a unicode object


# Generated at 2022-06-21 09:13:30.455688
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy('test'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy('test'), text_type)
    assert isinstance(UnsafeProxy(b'test'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(b'test'), binary_type)

    # Test handling of unicode strings
    assert isinstance(UnsafeProxy(u'test'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(u'test'), text_type)
    # Test handling of byte strings which can be represented as unicode
    assert isinstance(UnsafeProxy(b'test'.decode('utf-8')), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'test'.decode('utf-8')), text_type)



# Generated at 2022-06-21 09:13:32.978318
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    unsafe_proxy = UnsafeProxy('foo')
    assert unsafe_proxy == 'foo'

# Helper to allow us to mock wrap_var in tests

# Generated at 2022-06-21 09:13:35.337033
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('hi'), AnsibleUnsafeByte)



# Generated at 2022-06-21 09:13:37.250668
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('trololo') == b'trololo'


# Generated at 2022-06-21 09:13:47.045971
# Unit test for function wrap_var
def test_wrap_var():
    # Test for type string
    val = 'hello'
    assert isinstance(wrap_var(val), AnsibleUnsafeText)
    # Test for type unicode
    val = u'hello'
    assert isinstance(wrap_var(val), AnsibleUnsafeText)
    # Test for type integer
    val = 1
    assert wrap_var(val) == 1
    # Test for type float
    val = 1.5
    assert wrap_var(val) == 1.5
    # Test for type List
    val = [1, 2, 3]
    assert isinstance(wrap_var(val), list)
    assert isinstance(wrap_var(val)[0], AnsibleUnsafeText)
    # Test for type Set
    val = set([1, 2, 3])

# Generated at 2022-06-21 09:13:48.579120
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert AnsibleUnsafeText('test') is not None


# Generated at 2022-06-21 09:13:57.243990
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # Input data
    ansible_unsafe_text = AnsibleUnsafeText("Test String")
    ansible_unsafe_bytes = AnsibleUnsafeBytes("Test String")

    # Test Case 1
    test_case_1 = ansible_unsafe_text
    assert(test_case_1.__UNSAFE__ == True)

    # Test Case 2
    test_case_2 = ansible_unsafe_bytes
    assert(test_case_2.__UNSAFE__ == True)



# Generated at 2022-06-21 09:14:04.613608
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    a = AnsibleUnsafe()
    assert a.__UNSAFE__
    a = AnsibleUnsafeBytes(b'a')
    assert a.__UNSAFE__
    a = AnsibleUnsafeText(u'a')
    assert a.__UNSAFE__
    a = NativeJinjaUnsafeText(u'a')
    assert a.__UNSAFE__
    a = AnsibleUnsafeBytes(b'a').decode()
    assert a.__UNSAFE__
    a = AnsibleUnsafeText(u'a').encode()
    assert a.__UNSAFE__



# Generated at 2022-06-21 09:14:09.670728
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    test_string = 'test_string'
    test_UnsafeProxy = UnsafeProxy(test_string)

    assert isinstance(test_UnsafeProxy, AnsibleUnsafeText)
    assert test_string not in vars(test_UnsafeProxy)



# Generated at 2022-06-21 09:14:13.847680
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes(b'bytes') == b'bytes'


# Generated at 2022-06-21 09:14:24.047407
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # First, test if the call to str returns a value
    test_str1 = AnsibleUnsafeText("This is a jinja template {{var}}")
    test_str2 = AnsibleUnsafeText("This is not a jinja template")
    assert(test_str1.encode() == b'This is a jinja template {{var}}')
    assert(test_str2.encode() == b'This is not a jinja template')
    try:
        test_str1.encode(encoding="us-ascii")
    except UnicodeError:
        assert(False)
    try:
        test_str2.encode(encoding="utf-8")
    except UnicodeError:
        assert(False)



# Generated at 2022-06-21 09:14:35.781677
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.display import Display
    from ansible.utils.unsafe_proxy import UnsafeProxy
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import to_unsafe_bytes, to_unsafe_text

    display = Display()
    UnsafeProxy('test')

    assert to_unsafe_bytes('test') == wrap_var('test')
    assert to_unsafe_text('test') == wrap_var('test')
    d1 = dict(a=1, b=2)
    d2 = dict(a=wrap_var(1), b=wrap_var(2))
    d3 = wrap_var(dict(a=1, b=2))
    assert d1 == d2
    assert d1 == d3

# Generated at 2022-06-21 09:14:42.696907
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import BytesIO
    assert isinstance(to_unsafe_bytes(b'hello world', errors='surrogate_or_strict'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u'hello world', errors='surrogate_or_strict'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(BytesIO(u'hello world'), errors='surrogate_or_strict'), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:14:44.274953
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert hasattr(AnsibleUnsafe(), '__UNSAFE__')


# Generated at 2022-06-21 09:14:49.666125
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    ansible_unsafe_bytes = AnsibleUnsafeBytes("this is unsafe bytes")
    assert ansible_unsafe_bytes == b"this is unsafe bytes"
    assert isinstance(ansible_unsafe_bytes, binary_type)
    assert isinstance(ansible_unsafe_bytes, AnsibleUnsafe)


# Generated at 2022-06-21 09:14:57.000172
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # expected success
    assert isinstance(AnsibleUnsafeText(u"hello"), AnsibleUnsafeText)

    # assert exception with wrong number of args
    try:
        AnsibleUnsafeText()
        assert False, "Should not get here"
    except TypeError:
        pass
    except Exception as e:
        assert False, "Wrong exception type: " + str(e)


# Generated at 2022-06-21 09:14:59.099179
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert repr(AnsibleUnsafeText('abc')) == "AnsibleUnsafeText(u'abc')"

# Generated at 2022-06-21 09:15:00.707002
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert issubclass(AnsibleUnsafeText, text_type)

# Generated at 2022-06-21 09:15:08.658868
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.six import PY3

    if PY3:
        assert type(to_unsafe_text('str')) is AnsibleUnsafeText
        assert type(to_unsafe_text(u'str')) is AnsibleUnsafeText
        assert type(to_unsafe_text(b'str')) is AnsibleUnsafeText
        assert type(to_unsafe_text(AnsibleUnsafeText('foo'))) is AnsibleUnsafeText
        assert type(to_unsafe_text(AnsibleUnsafeBytes('foo'))) is AnsibleUnsafeText
        assert type(to_unsafe_text(u'foo')) is AnsibleUnsafeText
        assert type(to_unsafe_text(b'foo')) is AnsibleUnsafeText

# Generated at 2022-06-21 09:15:25.572468
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(b'foo') is AnsibleUnsafeBytes(b'foo')
    assert wrap_var(unicode('foo')) is AnsibleUnsafeText(u'foo')
    assert wrap_var(u'föö') is AnsibleUnsafeText(u'föö')

    assert wrap_var({unicode('foo'): b'bar'}) == {u'foo': AnsibleUnsafeBytes(b'bar')}
    assert wrap_var({b'foo': b'bar'}) == {AnsibleUnsafeBytes(b'foo'): AnsibleUnsafeBytes(b'bar')}
    assert wrap_var([b'foo', b'bar']) == [AnsibleUnsafeBytes(b'foo'), AnsibleUnsafeBytes(b'bar')]

# Generated at 2022-06-21 09:15:27.194240
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    s = NativeJinjaUnsafeText('{{#')
    assert isinstance(s, NativeJinjaUnsafeText)

# Generated at 2022-06-21 09:15:29.688722
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    ansible_unsafe = AnsibleUnsafe()
    assert ansible_unsafe.__UNSAFE__ == True
    assert isinstance(ansible_unsafe, AnsibleUnsafe)


# Generated at 2022-06-21 09:15:30.502070
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    u = NativeJinjaUnsafeText('123')

# Generated at 2022-06-21 09:15:33.756513
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    x = AnsibleUnsafeBytes('abc')
    y = AnsibleUnsafeBytes('abc', encoding='utf-8')


# Generated at 2022-06-21 09:15:46.520143
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY3, text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.configparser import ConfigParser
    import sys

    # normal string value in PY3
    assert isinstance(to_unsafe_bytes('test'), AnsibleUnsafeBytes)

    # None value in PY3
    assert to_unsafe_bytes(None) is None

    # unicode string value in PY2
    if PY3:
        with open('/dev/null', 'wt') as f:
            assert isinstance(to_unsafe_bytes(u'test', errors='strict'), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:15:51.247186
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert issubclass(AnsibleUnsafe, object)
    assert issubclass(NativeJinjaUnsafeText, NativeJinjaText)
    assert issubclass(NativeJinjaUnsafeText, AnsibleUnsafeText)
    assert issubclass(AnsibleUnsafeText, text_type)
    assert issubclass(AnsibleUnsafeText, AnsibleUnsafe)
    assert issubclass(AnsibleUnsafeBytes, binary_type)
    assert issubclass(AnsibleUnsafeBytes, AnsibleUnsafe)


# Generated at 2022-06-21 09:15:58.554050
# Unit test for function wrap_var
def test_wrap_var():
    r_dict = {b'unsafe': b'value'}
    r_list = [b'unsafe']
    r_set = {b'item'}
    r_string = b'unsafe'
    r_regex = b'^aaa'
    r_none = None

    # Assert that all values are wrapped in the appropriate type
    assert isinstance(wrap_var(r_dict), dict)
    assert isinstance(wrap_var(r_list), list)
    assert isinstance(wrap_var(r_set), set)
    assert isinstance(wrap_var(r_string), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(r_regex), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(r_none), type(None))

    # Assert that all values

# Generated at 2022-06-21 09:16:04.130634
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Create an instance of class UnsafeProxy
    unsafe_proxy_instance = UnsafeProxy('string')

    # Check the type of unsafe_proxy_instance is AnsibleUnsafeText
    assert isinstance(unsafe_proxy_instance, AnsibleUnsafeText)
    # Check that unsafe_proxy_instance.__UNSAFE__ is True
    assert unsafe_proxy_instance.__UNSAFE__



# Generated at 2022-06-21 09:16:09.695732
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    native_jinja_unsafe_text_obj = NativeJinjaUnsafeText("test_unsafe_jinja_text")
    assert native_jinja_unsafe_text_obj.__class__.__name__ == "NativeJinjaUnsafeText"
    assert native_jinja_unsafe_text_obj.__class__.__mro__ == (NativeJinjaUnsafeText, NativeJinjaText, AnsibleUnsafeText, str, object)