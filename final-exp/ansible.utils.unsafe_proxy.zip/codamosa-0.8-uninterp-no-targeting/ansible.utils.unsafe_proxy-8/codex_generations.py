

# Generated at 2022-06-21 09:06:25.233485
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert(to_unsafe_text(None) is None)
    assert(isinstance(to_unsafe_text(b"\xff"), AnsibleUnsafeBytes))
    assert(to_unsafe_text(b"\xff") == u"\u00ff")
    assert(to_unsafe_text(u"\u00ff") == u"\u00ff")
    assert(isinstance(to_unsafe_text(u"\u00ff"), AnsibleUnsafeBytes))
    assert(to_unsafe_text(u"\u00ff").encode("utf-8") == b"\xc3\xbf")



# Generated at 2022-06-21 09:06:28.353723
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # parameter string
    b = b'test'
    b_type = AnsibleUnsafeBytes(b)
    assert(isinstance(b_type, AnsibleUnsafeBytes))


# Generated at 2022-06-21 09:06:35.958330
# Unit test for function wrap_var
def test_wrap_var():
    import nose

    # Test case for string
    # Test case for unicode
    # Test case for tuple
    # Test case for list
    # Test case for dictionary
    # Test case for set
    assert_equal(AnsibleUnsafeText, type(wrap_var('string')))
    assert_equal(AnsibleUnsafeText, type(wrap_var(u'unicode')))
    assert_equal(tuple, type(wrap_var((1, 2, 3))))
    assert_equal(list, type(wrap_var([1, 2, 3])))
    assert_equal(dict, type(wrap_var({1: 2, 3: 4})))
    assert_equal(set, type(wrap_var({1, 2, 3})))
    return

# Generated at 2022-06-21 09:06:47.475626
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(b""), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u""), AnsibleUnsafeText)
    assert isinstance(wrap_var([b"key", b"value"]), AnsibleUnsafeBytes)
    assert isinstance(wrap_var([u"key", u"value"]), AnsibleUnsafeText)
    assert isinstance(wrap_var((b"key", b"value")), AnsibleUnsafeBytes)
    assert isinstance(wrap_var((u"key", u"value")), AnsibleUnsafeText)
    assert isinstance(wrap_var({u"key": u"value"}), AnsibleUnsafeText)
    assert isinstance(wrap_var({b"key": b"value"}), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:06:49.817911
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    Assertions.assertEqual(AnsibleUnsafeText('abc').encode('utf-8'), b'abc')



# Generated at 2022-06-21 09:06:56.346290
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    u_str = b'\x00\x01\x02\x03'
    a = AnsibleUnsafeBytes(u_str)
    assert a == b'\x00\x01\x02\x03'

    result = a.decode()
    assert isinstance(result, str)
    assert result == u'\x00\x01\x02\x03'



# Generated at 2022-06-21 09:06:59.085903
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    a = AnsibleUnsafeBytes('asas')
    assert isinstance(a, AnsibleUnsafeBytes)

    assert a == b'asas'
    assert a != 'asas'



# Generated at 2022-06-21 09:07:04.116576
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    import pytest

    obj = 'safe'
    expected_result = 'safe'

    # Call method __new__ of class UnsafeProxy
    actual_result = UnsafeProxy.__new__(UnsafeProxy, obj)

    assert actual_result == expected_result

# Generated at 2022-06-21 09:07:06.404797
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    import doctest
    doctest.testmod()

if __name__ == '__main__':
    test_AnsibleUnsafeText()

# Generated at 2022-06-21 09:07:09.074896
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert("unsafe text" == AnsibleUnsafeBytes("dW5zYWZlIHRleHQ=").decode("base64"))


# Generated at 2022-06-21 09:07:12.347328
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert AnsibleUnsafeBytes(b'foo').decode('utf-8') == u'foo'

# Generated at 2022-06-21 09:07:22.531756
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.six import binary_type
    assert issubclass(UnsafeProxy(None), AnsibleUnsafe) is True
    assert issubclass(UnsafeProxy(b'foo'), AnsibleUnsafeBytes) is True
    assert issubclass(UnsafeProxy(binary_type(b'foo')), AnsibleUnsafeBytes) is True
    assert issubclass(UnsafeProxy(u'foo'), AnsibleUnsafeText) is True
    assert issubclass(UnsafeProxy(AnsibleUnsafeText(u'foo')), AnsibleUnsafeText) is True
    assert issubclass(UnsafeProxy(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes) is True

# Generated at 2022-06-21 09:07:25.012356
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    s = NativeJinjaUnsafeText("abc", "abc")
    assert str(s) == "abc"

# Generated at 2022-06-21 09:07:29.337101
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    s = AnsibleUnsafeBytes("data")
    assert(isinstance(s, binary_type))
    assert(isinstance(s, AnsibleUnsafe))
    assert(s == b"data")


# Generated at 2022-06-21 09:07:38.343338
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    print("test_AnsibleUnsafeText begin ...")
    # test init
    s = "abc"
    a = AnsibleUnsafeText(s)
    print(a)
    if isinstance(a, AnsibleUnsafeText):
        print("test_AnsibleUnsafeText init OK!")
    else:
        print("test_AnsibleUnsafeText init Failed!")
    # test encode
    a = AnsibleUnsafeText(s)
    b = a.encode()
    if isinstance(b, AnsibleUnsafeBytes):
        print("test_AnsibleUnsafeText encode OK!")
    else:
        print("test_AnsibleUnsafeText encode Failed!")
    # test decode
    a = AnsibleUnsafeText(s)
    b = a.encode()
    c

# Generated at 2022-06-21 09:07:42.495539
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe.__UNSAFE__ is True
    assert AnsibleUnsafeBytes.__UNSAFE__ is True
    assert AnsibleUnsafeText.__UNSAFE__ is True
    assert NativeJinjaUnsafeText.__UNSAFE__ is True



# Generated at 2022-06-21 09:07:45.684886
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # check that decode method of AnsibleUnsafeBytes returns instance of class AnsibleUnsafeText
    assert isinstance(AnsibleUnsafeBytes(b'untrusted').decode(), AnsibleUnsafeText)

# Generated at 2022-06-21 09:07:48.597446
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    x = AnsibleUnsafe()
    assert(x.__UNSAFE__ == True)
    assert(AnsibleUnsafe.__UNSAFE__ == True)


# Generated at 2022-06-21 09:07:51.803231
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    expected = '${A}'
    result = NativeJinjaUnsafeText(expected)
    assert expected == result

# Generated at 2022-06-21 09:08:00.569075
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    '''test function to_unsafe_bytes'''
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class MyYAMLObject(AnsibleBaseYAMLObject):
        pass

    myobj = MyYAMLObject('testing')
    assert to_unsafe_bytes(myobj) == b'testing'
    assert isinstance(to_unsafe_bytes(myobj), AnsibleUnsafeBytes)

    assert to_unsafe_bytes('hello world') == b'hello world'
    assert isinstance(to_unsafe_bytes('hello world'), AnsibleUnsafeBytes)

    assert b'hello world' == b'hello world'
    assert isinstance(b'hello world', AnsibleUnsafeBytes)

    assert b'testing' == b'testing'

# Generated at 2022-06-21 09:08:09.694470
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    class_name="NativeJinjaUnsafeText"
    dunder_class="ansible.module_utils.basic.NativeJinjaUnsafeText"
    import types
    import sys
    import os
    orig_path = sys.path
    sys.path = sys.path[1:]
    import ansible.module_utils.basic
    sys.path = orig_path
    assert dunder_class in str(ansible.module_utils.basic.__dict__["NativeJinjaUnsafeText"])
    assert class_name in str(ansible.module_utils.basic.__dict__["NativeJinjaUnsafeText"])
    assert isinstance(ansible.module_utils.basic.__dict__["NativeJinjaUnsafeText"], type)


# Generated at 2022-06-21 09:08:16.889963
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert_equal = 'assert '
    assert_type = 'type'
    assert_type_error = 'TypeError'
    assert_not_type = 'not type'
    assert_true = 'True'
    s = "Every normal man must be tempted, at times, to spit on his hands, hoist the black flag, and begin slitting throats."
    assert_equal += '({}, {}(str))'.format(
        assert_type, assert_not_type
    )
    with assert_raises(TypeError):
        NativeJinjaUnsafeText(s=s)
    assert_equal += '({}, NativeJinjaUnsafeText(u"{}"))'.format(
        assert_type, s
    )
    assert_equal += '({}, NativeJinjaUnsafeText(str(u"{}")))'.format

# Generated at 2022-06-21 09:08:26.531952
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(b'abc') == 'abc'
    assert to_unsafe_text(b'\xc3\xbc'.decode('utf-8')) == '\xfc'
    assert to_unsafe_text(b'\xc3\xbc', errors='strict') == '\xfc'
    assert to_unsafe_text(b'\xc3\xbc', errors='ignore') == ''
    assert to_unsafe_text(b'\xc3\xbc', errors='replace') == '?'
    assert to_unsafe_text(b'\xc3\xbc', errors='surrogate_or_strict') == '\xfc'
    assert to_unsafe_text(b'\xc3\xbc', errors='surrogate_or_replace') == '?'

# Generated at 2022-06-21 09:08:38.140943
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    import inspect, os, sys
    # Save the real stdout
    stdout = sys.stdout

    # Capture output
    mystdout = []
    sys.stdout = mystdout

    # Instantiate the class and pass a value
    sampleval = "SampleValue"
    sampleval_upper = sampleval.upper()
    sampleval_lower = sampleval.lower()
    expected = sampleval.upper()
    obj = UnsafeProxy(sampleval)

    # Assert that the value is correctly wrapped
    assert(obj == expected)

    # Capture output again
    mystdout_upper = []
    sys.stdout = mystdout_upper
    # Call the upper method on the object
    obj_upper = obj.upper()

    # Assert that the call to upper works as expected

# Generated at 2022-06-21 09:08:41.516789
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText(u"foo").encode("utf-8"), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:08:53.319413
# Unit test for function wrap_var
def test_wrap_var():
    # simple test
    assert isinstance(wrap_var('unsafe'), AnsibleUnsafeText)
    assert isinstance(wrap_var('unsafe'.encode('utf-8')), AnsibleUnsafeBytes)

    # list
    test_list = ['item1', 'item2']
    assert isinstance(wrap_var(test_list), list)
    assert isinstance(wrap_var(test_list)[0], AnsibleUnsafeText)
    assert isinstance(wrap_var(test_list)[1], AnsibleUnsafeText)

    # dict
    test_dict = {'item1': 'item2', 'item3': 'item4'}
    assert isinstance(wrap_var(test_dict), dict)
    assert isinstance(wrap_var(test_dict)['item1'], AnsibleUnsafeText)
   

# Generated at 2022-06-21 09:08:55.891905
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText('HelloWorld').encode('utf-8'), AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:08:58.501467
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert(isinstance(to_unsafe_text("string"), AnsibleUnsafeText))


# Generated at 2022-06-21 09:09:08.606181
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from six import string_types, binary_type, text_type
    assert isinstance(UnsafeProxy(1), int)
    assert isinstance(UnsafeProxy(u'hello'), string_types)
    assert isinstance(UnsafeProxy('hello'), binary_type)
    assert isinstance(UnsafeProxy(u'hello'), text_type)
    assert isinstance(UnsafeProxy(b'hello'), binary_type)
    assert isinstance(UnsafeProxy(b'hello'), binary_type)

    assert isinstance(UnsafeProxy(b'hello'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(u'hello'), AnsibleUnsafeText)

    assert isinstance(UnsafeProxy(u'hello').encode(), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:09:21.695156
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.six import PY3
    from ansible.utils import pycompat
    pycompat_unicode = pycompat.unicode


# Generated at 2022-06-21 09:09:36.773099
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert(isinstance(UnsafeProxy("a"), AnsibleUnsafeBytes))
    assert(UnsafeProxy("a") == AnsibleUnsafeBytes(b'a'))
    assert(isinstance(UnsafeProxy(1), AnsibleUnsafe))
    assert(UnsafeProxy(1) == 1)
    assert(isinstance(UnsafeProxy(1.0), AnsibleUnsafe))
    assert(UnsafeProxy(1.0) == 1.0)
    assert(isinstance(UnsafeProxy((1, 2, 3)), AnsibleUnsafe))
    assert(UnsafeProxy((1, 2, 3)) == (1, 2, 3))
    assert(isinstance(UnsafeProxy(['a', 'b', 'c']), AnsibleUnsafe))

# Generated at 2022-06-21 09:09:40.884963
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    try:
        a = AnsibleUnsafeBytes(b'123')
        a = AnsibleUnsafeBytes(b'123').encode('utf-8')
    except TypeError:
        print ("test_AnsibleUnsafeBytes failed")
    else:
        print ("test_AnsibleUnsafeBytes success")


# Generated at 2022-06-21 09:09:52.450803
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.utils.display import Display
    Display().deprecated(
        'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )
    # In our usage we should only receive unicode strings.
    # This conditional and conversion exists to sanity check the values
    # we're given but we may want to take it out for testing and sanitize
    # our input instead.
    assert isinstance(UnsafeProxy(AnsibleUnsafeText('test')), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes('test')), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:09:58.242492
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    instance = NativeJinjaUnsafeText('foo')
    assert isinstance(instance, text_type)
    assert isinstance(instance, NativeJinjaText)
    assert isinstance(instance, AnsibleUnsafeText)
    assert not isinstance(instance, binary_type)
    assert str(instance) == 'foo'

# Generated at 2022-06-21 09:10:04.233484
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy(None), type(None))
    # TODO: Test more types in the future - including other unsafe classes
    assert isinstance(UnsafeProxy(AnsibleUnsafeText("hello")), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(None), type(None))
    assert isinstance(UnsafeProxy(None), type(None))


# Generated at 2022-06-21 09:10:07.978329
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # Converts to AnsibleUnsafeBytes
    assert isinstance(AnsibleUnsafeText('text').encode('utf8'), AnsibleUnsafeBytes)
    # Converts to native string to binary.
    assert isinstance(AnsibleUnsafeText('text').encode('utf8'), binary_type)

# Generated at 2022-06-21 09:10:09.052776
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(u'foo') is not None

# Generated at 2022-06-21 09:10:12.398846
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    ansible_unsafe_text_instance = AnsibleUnsafeText('abc')
    result = ansible_unsafe_text_instance.encode()

    assert(isinstance(result, AnsibleUnsafeBytes))
    assert(result == 'abc')


# Generated at 2022-06-21 09:10:15.389254
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    nu = NativeJinjaUnsafeText('mamamia')
    assert nu.__UNSAFE__ == True
    assert nu == 'mamamia'

# Generated at 2022-06-21 09:10:17.737228
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert isinstance(AnsibleUnsafe(), AnsibleUnsafe)



# Generated at 2022-06-21 09:10:25.406838
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    jinja_template = NativeJinjaUnsafeText('{{ a | from_yaml }}')
    values = dict(a='ansible')
    assert jinja_template.render(**values) == 'ansible'

# Generated at 2022-06-21 09:10:38.545898
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    class A(object):
        def __init__(self, enc):
            self.enc = enc

        def encode(self, *args, **kwargs):
            return self.enc

    test_obj1 = A(u'\u8fd9\u662f\u6d4b\u8bd5')
    test_obj2 = A('\xe8\xbf\x99\xe6\x98\xaf\xe6\xb5\x8b\xe8\xaf\x95')
    test_obj3 = A(b'\xe8\xbf\x99\xe6\x98\xaf\xe6\xb5\x8b\xe8\xaf\x95')


# Generated at 2022-06-21 09:10:48.838465
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
  import os
  import subprocess
  test_file = os.path.realpath(__file__)
  test_dir = os.path.dirname(test_file)
  test_file_path = os.path.join(test_dir, 'test_to_unsafe_text.py')
  p = subprocess.Popen(['python', '-m', 'unittest', test_file_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=test_dir)
  (stdout, stderr) = p.communicate()
  if p.returncode != 0:
      raise Exception('%s' % stderr)

# Generated at 2022-06-21 09:10:58.102708
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var("foo") == to_native("foo")
    assert wrap_var([to_bytes("foo"), b"bar", "baz", 3]) == [to_native("foo"), to_native("bar"), to_native("baz"), 3]
    assert wrap_var({"foo": to_bytes("bar"), "baz": "quz", "qiz": 42}) == {"foo": to_native("bar"), "baz": to_native("quz"), "qiz": 42}
    assert wrap_var([{"foo": to_bytes("bar"), "baz": "quz", "qiz": 42}, "bar"]) == [{"foo": to_native("bar"), "baz": to_native("quz"), "qiz": 42}, to_native("bar")]

# Generated at 2022-06-21 09:11:05.382414
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():

    # create object of the class UnsafeProxy
    obj = UnsafeProxy(obj="test_UnsafeProxy")
    # test the type of the object created
    if isinstance(obj, AnsibleUnsafeText):
        print("test__UnsafeProxy___new__ passed")
        return True
    print("test__UnsafeProxy___new__ failed")
    return False


if __name__ == '__main__':
    # call the test-function
    test_UnsafeProxy___new__()

# Generated at 2022-06-21 09:11:10.832380
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    ansiblesafe_str = AnsibleUnsafeText('a')
    assert(isinstance(ansiblesafe_str, AnsibleUnsafeText))
    assert(isinstance(ansiblesafe_str, text_type))
    assert(isinstance(ansiblesafe_str, AnsibleUnsafe))

    ansiblesafe_bytes = AnsibleUnsafeBytes(b'a')
    assert(isinstance(ansiblesafe_bytes, AnsibleUnsafeBytes))
    assert(isinstance(ansiblesafe_bytes, binary_type))
    assert(isinstance(ansiblesafe_bytes, AnsibleUnsafe))

# Generated at 2022-06-21 09:11:13.694711
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # TODO: Implement unit test to confirm that __new__ properly proxies
    assert False, "Implement me"

# Generated at 2022-06-21 09:11:16.534504
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    a = AnsibleUnsafeText("This is a test string.")
    assert isinstance(a.encode(), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:11:26.847307
# Unit test for function wrap_var
def test_wrap_var():
    import types
    import collections
    import ansible_unsafe

    assert(wrap_var(False) == False)
    assert(wrap_var(True) == True)
    assert(wrap_var(1) == 1)
    assert(wrap_var(3.14) == 3.14)
    assert(wrap_var(1.0) == 1.0)
    assert(wrap_var(None) == None)
    assert(wrap_var(float('inf')) == float('inf'))
    assert(wrap_var(float('-inf')) == float('-inf'))
    assert(wrap_var(float('nan')) == float('nan'))

    # String types should be wrapped
    assert(isinstance(wrap_var('foo'), ansible_unsafe.AnsibleUnsafeText))

# Generated at 2022-06-21 09:11:36.694046
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var('unsafe'), AnsibleUnsafeText)
    assert isinstance(wrap_var(123), int)
    assert isinstance(wrap_var(1.23), float)
    assert isinstance(wrap_var(b'bytes'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'unicode').decode('utf-8'), AnsibleUnsafeText)
    assert isinstance(wrap_var({'foo': 'bar'}), dict)
    assert isinstance(wrap_var(['foo', 'bar']), list)
    assert isinstance(wrap_var(('foo', 'bar')), tuple)
    assert isinstance(wrap_var(set(['foo', 'bar'])), set)
    assert isinstance(wrap_var(None), type(None))

# Generated at 2022-06-21 09:11:49.097313
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    from ansible.module_utils.six import binary_type, unichr
    assert isinstance(AnsibleUnsafeBytes(binary_type(unichr(128))), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:11:52.811236
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes("1.23"), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes("1.23", encoding='utf-8'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(1.23), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(1.23, encoding='utf-8'), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:11:53.951936
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe().__class__.__name__ == 'AnsibleUnsafe'



# Generated at 2022-06-21 09:11:54.930582
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    result = AnsibleUnsafeBytes('unit test')
    assert result == b'unit test'



# Generated at 2022-06-21 09:12:01.409756
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    import unittest
    class TestAnsibleUnsafeBytes(unittest.TestCase):
        def test_to_str(self):
            bytes_str = AnsibleUnsafeBytes("Hello World!")
            self.assertEqual('Hello World!', bytes_str.decode('utf-8'))
    unittest.main()

# Generated at 2022-06-21 09:12:02.952191
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert type(to_unsafe_text('hello')) == AnsibleUnsafeText

# Generated at 2022-06-21 09:12:11.042954
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import string_types

    reference = "reference"
    if PY3:
        assert(isinstance(UnsafeProxy(reference), AnsibleUnsafeText))
        assert(isinstance(UnsafeProxy(reference), string_types))
    else:
        assert(isinstance(UnsafeProxy(reference), AnsibleUnsafeBytes))
        assert(isinstance(UnsafeProxy(reference), string_types))



# Generated at 2022-06-21 09:12:19.620072
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    import copy
    import json
    import sys

    # Make sure that AnsibleUnsafeBytes has the proper slots set
    assert AnsibleUnsafeBytes.__slots__ == ()

    test_str = to_unsafe_bytes("hi there")
    assert isinstance(test_str, AnsibleUnsafeBytes)

    test_str2 = test_str.decode('ascii')
    assert isinstance(test_str2, AnsibleUnsafeText)

    test_dict = {
        b'foo': b'bar',
        'utf8': u'utf8',
        '\xa2': u'\xa2',
    }
    test_dict_nob = copy.deepcopy(test_dict)
    test_dict_nob['utf8'] = test_dict_nob['utf8'].encode('utf-8')

# Generated at 2022-06-21 09:12:26.661546
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText('foo').encode('utf-8'), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText(b'foo').encode('utf-8'), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText('foo').encode('utf-8'), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText('foo').encode('utf-8'), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText(u'foo').encode('utf-8'), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText(b'foo').encode('utf-8'), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:12:28.479619
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(b'foo') == u'foo'

# Generated at 2022-06-21 09:12:49.774368
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes(b'hello') == b'hello'

# Generated at 2022-06-21 09:13:01.260655
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import text_type
    import json
    import yaml
    example_dict = {'a': 1, 'b': 2, 'c': 'something'}
    example_json = json.dumps(example_dict)
    example_yaml = yaml.safe_dump(example_dict)
    assert type(to_unsafe_bytes(example_dict)) == AnsibleUnsafeBytes
    assert type(to_unsafe_bytes(example_json)) == AnsibleUnsafeBytes
    assert type(to_unsafe_bytes(example_yaml)) == AnsibleUnsafeBytes
    assert type(to_unsafe_bytes(example_yaml, errors='surrogate_or_strict')) == AnsibleUnsafeBytes

# Generated at 2022-06-21 09:13:13.113248
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils._text import to_bytes, to_text
    class SafeObject:
        __UNSAFE__ = False

    class UnsafeObject:
        __UNSAFE__ = True

    safe_object = SafeObject()
    unsafe_object = UnsafeObject()

    byte_object = to_bytes('bytes')
    text_object = to_text('text')
    native_jinja_text_object = NativeJinjaText('jinja text')

    assert UnsafeProxy(safe_object) is safe_object
    assert UnsafeProxy(unsafe_object) is unsafe_object
    assert isinstance(UnsafeProxy(byte_object), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(text_object), AnsibleUnsafeText)

# Generated at 2022-06-21 09:13:25.729234
# Unit test for function wrap_var
def test_wrap_var():
    import unittest
    import json

    class TestAnsibleUnsafe(unittest.TestCase):

        def test_native_jinja_text_type(self):
            # Testing wrap_var()
            expected_unsafe_text = NativeJinjaUnsafeText('{{ var }}')
            self.assertEqual(wrap_var(NativeJinjaText('{{ var }}')), expected_unsafe_text, "Failed for wrap_var()")

            # Testing to_unsafe_text()
            expected_unsafe_text = NativeJinjaUnsafeText('{{ var }}')
            self.assertEqual(to_unsafe_text(NativeJinjaText('{{ var }}')), expected_unsafe_text, "Failed for to_unsafe_text()")

            # Testing wrap_var()
            expected_

# Generated at 2022-06-21 09:13:37.467139
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins

    class Test(object):
        def __init__(self, d):
            self.__dict__ = d

    def _test_UnsafeProxy_produces_UnsafeText_for_unicode_input():
        res = UnsafeProxy(u'test')
        assert isinstance(res, AnsibleUnsafeText)

    def _test_UnsafeProxy_produces_UnsafeText_for_bytes_input_on_python2():
        if PY2:
            res = UnsafeProxy('test')
            assert isinstance(res, AnsibleUnsafeText)


# Generated at 2022-06-21 09:13:41.950984
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy(None) is None
    assert UnsafeProxy('foo') == "foo"
    assert UnsafeProxy(u'foo') == u"foo"
    assert isinstance(UnsafeProxy(u'foo'), unicode)
    assert isinstance(UnsafeProxy(u'foo'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy('foo'), str)
    assert isinstance(UnsafeProxy('foo'), AnsibleUnsafeText)
    assert UnsafeProxy(AnsibleUnsafeText(u'foo')) == u"foo"
    assert isinstance(UnsafeProxy(AnsibleUnsafeText(u'foo')), unicode)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText(u'foo')), AnsibleUnsafeText)

# Generated at 2022-06-21 09:13:47.421433
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.hashing import checksum
    for var in [
        None,
        b'',
        u'',
        1,
        2.5,
        {},
        {'k': 1},
        [123, [456, '789']],
        (1, 2, ('3', {'4': '5'}))
    ]:
        assert isinstance(wrap_var(var), type(var))

# Generated at 2022-06-21 09:13:59.342321
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    b = AnsibleUnsafeBytes(b'foo')
    assert isinstance(b, AnsibleUnsafeBytes)
    assert isinstance(b, binary_type)
    assert isinstance(b, AnsibleUnsafe)

    t = AnsibleUnsafeText(u'foo')
    assert isinstance(t, AnsibleUnsafeText)
    assert isinstance(t, text_type)
    assert isinstance(t, AnsibleUnsafe)

    njt = NativeJinjaUnsafeText(u'foo')
    assert isinstance(njt, NativeJinjaUnsafeText)
    assert isinstance(njt, text_type)
    assert isinstance(njt, AnsibleUnsafe)


# Generated at 2022-06-21 09:14:01.381795
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy(u'test'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText('test')), AnsibleUnsafeText)
    assert not isinstance(UnsafeProxy('test'), AnsibleUnsafeText)

# Generated at 2022-06-21 09:14:03.677846
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    it = AnsibleUnsafeBytes([65, 66, 67])
    assert 'ABC' == it.decode('utf-8')
