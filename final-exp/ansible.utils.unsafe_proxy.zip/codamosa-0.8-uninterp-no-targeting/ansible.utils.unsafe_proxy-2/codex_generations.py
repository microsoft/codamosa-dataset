

# Generated at 2022-06-21 09:06:32.442770
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('string') == b'string'
    assert to_unsafe_bytes(b'string') == b'string'
    assert to_unsafe_bytes(u'string') == b'string'
    assert to_unsafe_bytes(['this', 'is', 'a', 'list']) == [b'this', b'is', b'a', b'list']
    assert to_unsafe_bytes(('this', 'is', 'a', 'list')) == (b'this', b'is', b'a', b'list')
    assert to_unsafe_bytes({'this': 'is', 'a': 'dict'}) == {b'this': b'is', b'a': b'dict'}



# Generated at 2022-06-21 09:06:37.246592
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    unsafe_text = AnsibleUnsafeText("test")
    assert unsafe_text == "test"
    assert isinstance(unsafe_text, AnsibleUnsafe)
    assert isinstance(unsafe_text, text_type)
    assert isinstance(unsafe_text, str)


# Generated at 2022-06-21 09:06:43.938658
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    assert isinstance(UnsafeProxy('a'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(u'a'), AnsibleUnsafeText)
    assert UnsafeProxy('a') == u'a'

    if PY3:
        assert isinstance(UnsafeProxy(b'a'), AnsibleUnsafeBytes)
        assert isinstance(UnsafeProxy(bytearray(b'a')), AnsibleUnsafeBytes)
        assert UnsafeProxy(b'a') == b'a'
        assert UnsafeProxy(bytearray(b'a')) == b'a'

    assert UnsafeProxy(None) == None

    # Truthy and falsy
    assert UnsafeProxy

# Generated at 2022-06-21 09:06:48.558623
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    """Tests that NativeJinjaUnsafeText is not being overwritten"""
    x = NativeJinjaUnsafeText("hello")
    assert(x == "hello")
    assert(x.__class__ is NativeJinjaUnsafeText)


if __name__ == '__main__':
    test_NativeJinjaUnsafeText()

# Generated at 2022-06-21 09:06:53.855339
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    text = 'hello'
    btext = b'hello'
    assert isinstance(btext, binary_type)

    # We need to make sure that both types are properly wrapped
    assert isinstance(UnsafeProxy(text), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(btext), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:06:56.449568
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():

    txt = "text"
    assert AnsibleUnsafeText(txt).__repr__() == "text"


# Generated at 2022-06-21 09:07:04.280821
# Unit test for function wrap_var
def test_wrap_var():
    """Sanity test for the wrap_var function"""
    assert wrap_var(None) is None
    assert wrap_var("text") is not "text"
    assert wrap_var("text") == "text"
    assert isinstance(wrap_var("text"), AnsibleUnsafeText)
    assert wrap_var(1) == 1
    assert wrap_var(True) == True
    assert wrap_var(b'ascii') is not b'ascii'
    assert wrap_var(b'ascii') == "ascii"
    assert isinstance(wrap_var(b'ascii'), AnsibleUnsafeText)
    assert isinstance(wrap_var([1, 2, b"ascii"]), list)

# Generated at 2022-06-21 09:07:07.001277
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    class AnsibleUnsafe(object):
        __UNSAFE__ = True
    string = AnsibleUnsafe()
    assert string.__UNSAFE__ == True


# Generated at 2022-06-21 09:07:14.364994
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('foo', 'utf-8'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_bytes(u'foo', 'utf-8'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_bytes(None), type(None))
    assert isinstance(to_unsafe_bytes(123), int)
    assert isinstance(to_unsafe_bytes(123.5), float)
    assert isinstance(to_unsafe_bytes(list('foo')), list)



# Generated at 2022-06-21 09:07:26.169755
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes("foo") == "foo"
    assert isinstance(to_unsafe_bytes("foo"), AnsibleUnsafeBytes)

    assert to_unsafe_bytes("foo", errors='strict') == "foo"
    assert isinstance(to_unsafe_bytes("foo", errors='strict'), AnsibleUnsafeBytes)

    assert to_unsafe_bytes("foo", errors='replace') == "foo"
    assert isinstance(to_unsafe_bytes("foo", errors='replace'), AnsibleUnsafeBytes)

    assert to_unsafe_bytes("foo", errors='backslashreplace') == "foo"
    assert isinstance(to_unsafe_bytes("foo", errors='backslashreplace'), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:07:31.827217
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    test_cases = ['{{ variable }}', '{{ variable | filter }}', '{{ variable.member }}', '{{ variable[index] }}']
    for case in test_cases:
        obj = NativeJinjaUnsafeText(case)
        assert isinstance(obj, NativeJinjaUnsafeText)
        assert isinstance(obj, NativeJinjaText)
        assert isinstance(obj, text_type)
        assert isinstance(obj, AnsibleUnsafeText)
        assert isinstance(obj, AnsibleUnsafe)

# Generated at 2022-06-21 09:07:37.314263
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # Create unsafe bytes
    unsafe_bytes = AnsibleUnsafeBytes(u'\u84bc\u84bc\u84bc')
    # Check length
    assert len(unsafe_bytes) == 3
    assert unsafe_bytes.__class__ == AnsibleUnsafeBytes


# Generated at 2022-06-21 09:07:48.988748
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # Test with True and False values
    assert isinstance(AnsibleUnsafeText(True), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeText(False), AnsibleUnsafeText)

    # Test with valid unicode string
    string = "This is a valid unicode string"
    assert isinstance(AnsibleUnsafeText(string), AnsibleUnsafeText)

    # Test with valid byte string
    try:
        string = "This is a valid byte string".encode("utf-8")
    except UnicodeEncodeError:
        pytest.skip("Failed to encode test string to UTF-8")
    assert isinstance(AnsibleUnsafeText(string), AnsibleUnsafeText)

    # Test with valid UnicodeException

# Generated at 2022-06-21 09:07:51.903308
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    test_text = 'Test string'
    proxy = UnsafeProxy(test_text)

    assert isinstance(proxy, AnsibleUnsafeText)
    assert str(proxy) == test_text

# Generated at 2022-06-21 09:08:00.601323
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    # Handle not passing any arguments
    assert(isinstance(to_unsafe_text(), AnsibleUnsafeText))

    # Decode utf-8, utf-16, and utf-32
    result = to_unsafe_text(b'\xff')
    assert(isinstance(result, AnsibleUnsafeText))
    assert(result == u'\ufffd')

    result = to_unsafe_text(b'\xff', errors='surrogate_or_strict')
    assert(isinstance(result, NativeJinjaUnsafeText))
    assert(result == u'\ufffd')

    result = to_unsafe_text(u'\ufffd', errors='surrogate_or_strict')
    assert(isinstance(result, NativeJinjaUnsafeText))

# Generated at 2022-06-21 09:08:09.150677
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    import json
    assert to_text(UnsafeProxy(1)) == "1"
    assert to_text(UnsafeProxy(1.0)) == "1.0"
    assert to_text(UnsafeProxy("1")) == "1"
    assert to_text(UnsafeProxy(b"1")) == "1"
    assert to_text(UnsafeProxy(tuple(["1"]))) == "(u'1',)"
    assert to_text(UnsafeProxy(["1"])) == "[u'1']"
    assert to_text(UnsafeProxy({"a": "1"})) == "{u'a': u'1'}"
    assert to_text(UnsafeProxy(True)) == "True"
    assert to_text(UnsafeProxy(None)) == "None"

# Generated at 2022-06-21 09:08:16.523912
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3

    assert wrap_var(None) is None
    assert isinstance(wrap_var(u"foo"), AnsibleUnsafeText)
    assert isinstance(wrap_var("foo"), AnsibleUnsafeText)
    assert isinstance(wrap_var("foo".encode("utf-8")), AnsibleUnsafeBytes)

    if PY3:
        assert isinstance(wrap_var("foo".encode("latin-1")), AnsibleUnsafeBytes)
        assert isinstance(wrap_var("foo".encode("oem")), AnsibleUnsafeBytes)

    assert isinstance(wrap_var({"foo": "bar"}), dict)
    assert isinstance(wrap_var({"foo": "bar"})["foo"], AnsibleUnsafeText)


# Generated at 2022-06-21 09:08:26.346559
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import BytesIO, StringIO
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.parsing.convert_bool import BOOLEANS
    from ansible.module_utils.parsing.convert_bool import boolean
    import socket
    import dbm.ndbm
    import os
    import hashlib
    import hmac
    import random
    import select
    import struct
    import threading
    import time
    import zipfile
    import fcntl
    import locale
    import posixpath
    import _posixsubprocess
    import _subprocess
    import tarfile
    import tempfile
    import array
    import bz2
    import os
    import tempfile
    import shutil

# Generated at 2022-06-21 09:08:32.889078
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    a = u"This is some test Unicode text: \u21af"
    b = to_unsafe_bytes(a)
    assert isinstance(b, AnsibleUnsafeBytes)
    c = b.decode(encoding='utf-8')
    assert isinstance(c, AnsibleUnsafeText)
    assert a == c



# Generated at 2022-06-21 09:08:37.283780
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(u'hello world') == to_unsafe_text(u'hello world')
    assert wrap_var(u'hello world'.encode('utf-8')) == to_unsafe_text(u'hello world').encode('utf-8')
    assert wrap_var({"a": "b", "c": "d"}) == {"a": to_unsafe_text("b"), "c": to_unsafe_text("d")}
    assert wrap_var([u'hello world', u'hello world2'.encode('utf-8')]) == [to_unsafe_text(u'hello world'), to_unsafe_text(u'hello world2').encode('utf-8')]

# Generated at 2022-06-21 09:08:51.866809
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    result = UnsafeProxy(to_unsafe_text(u'Unsafe text'))
    assert isinstance(result, AnsibleUnsafeText)
    assert result.__UNSAFE__ is True
    assert result == u'Unsafe text'

    result = UnsafeProxy(to_unsafe_bytes(b'Unsafe text'))
    assert isinstance(result, AnsibleUnsafeBytes)
    assert result.__UNSAFE__ is True
    assert result == b'Unsafe text'

    result = UnsafeProxy(None)
    assert result is None

    expected_display_message = r"UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes\/AnsibleUnsafeText directly instead"
    result = UnsafeProxy(to_unsafe_text(u'Unsafe text'))

# Generated at 2022-06-21 09:08:53.492570
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert(AnsibleUnsafe)

# Generated at 2022-06-21 09:08:58.511598
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    ansibleUnsafeText = AnsibleUnsafeText("Hello World")
    assert ansibleUnsafeText == "Hello World"
    assert isinstance(ansibleUnsafeText, AnsibleUnsafeText)
    assert isinstance(ansibleUnsafeText, AnsibleUnsafe)


# Generated at 2022-06-21 09:08:59.655804
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    unsafe_text = AnsibleUnsafeText('python')
    assert unsafe_text.encode('utf-8') == b'python'


# Generated at 2022-06-21 09:09:09.425972
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    from ansible import constants as C
    from ansible.errors import AnsibleUnicodeDecodeError
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes, wrap_var

    str_safe = 'i am safe'
    str_unsafe = to_unsafe_text(str_safe)
    assert str_unsafe == wrap_var(str_safe)

    byte_safe = b'i am safe'
    byte_unsafe = to_unsafe_bytes(byte_safe)
    assert byte_unsafe == wrap_var(byte_safe)

    assert str_safe == to_text(str_unsafe)
    assert str_safe == to_text(str_unsafe, errors='surrogate_or_strict')

    assert byte_safe == to_bytes(byte_unsafe)

# Generated at 2022-06-21 09:09:13.734976
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    ustr = "\u0080abcdef"  # Invalid UTF-8 bytes
    bstr = ustr.encode('utf-8', 'surrogateescape')
    assert isinstance(bstr, AnsibleUnsafeBytes)
    assert isinstance(bstr.decode("utf-8", "strict"), AnsibleUnsafeText)
    assert isinstance(bstr.decode("utf-8", "replace"), AnsibleUnsafeText)
    assert isinstance(bstr.decode("utf-8", "ignore"), AnsibleUnsafeText)



# Generated at 2022-06-21 09:09:25.262563
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    class Test(NativeJinjaUnsafeText):
        pass
    # Test with native string type
    test_cases = [
        {'case': 'ansible_unsafe string', 'input': u'test', 'expected_output': u'test'},
        {'case': 'ansible_unsafe_bytes string', 'input': u'\xe9', 'expected_output': u'\xe9'},
        {'case': 'empty string', 'input': u'', 'expected_output': u''},
        {'case': 'int', 'input': 123, 'expected_output': u'123'},
        {'case': 'empty string', 'input': u'', 'expected_output': u''},
    ]
    for test_case in test_cases:
        assert Test(test_case['input']) == test_

# Generated at 2022-06-21 09:09:31.400586
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    class TestUnsafeBytes(AnsibleUnsafeBytes):
        def __init__(self, *args, **kwargs):
            AnsibleUnsafeBytes.__init__(self, *args, **kwargs)
            self.arg = 1
            self.kwarg = 2

    t = TestUnsafeBytes()
    assert t.arg == 1
    assert t.kwarg == 2

# Generated at 2022-06-21 09:09:35.249902
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    a = NativeJinjaUnsafeText()
    assert isinstance(a, NativeJinjaUnsafeText)


# Unit test to test dict used ansible safe text

# Generated at 2022-06-21 09:09:42.207475
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # Test AnsibleUnsafeText.encode() with latin string
    # Should return AnsibleUnsafeText object
    import sys
    if sys.version_info[0] > 2:
        assert isinstance(AnsibleUnsafeText('abc').encode(), AnsibleUnsafeBytes)
    else:
        assert isinstance(AnsibleUnsafeText('abc').encode(), AnsibleUnsafeText)

    # Test AnsibleUnsafeText.encode() with none string
    # Should raise AttributeError
    # assert_raises(AttributeError, AnsibleUnsafeText(None).encode)



# Generated at 2022-06-21 09:09:49.336471
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    string = 'test'
    assert UnsafeProxy(string) == 'test'
    assert type(UnsafeProxy(string)) is AnsibleUnsafeText
    assert UnsafeProxy(string) == AnsibleUnsafeText('test')



# Generated at 2022-06-21 09:10:01.833507
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.unsafe_proxy import wrap_var

    # Python 2.x byte string
    if isinstance(b'', binary_type):
        b1 = b'bytes with %(var)s'
        b2 = b'bytes with %(var)s'
        b3 = 'bytes with %(var)s'
        b4 = AnsibleUnsafeBytes(b'bytes with %(var)s')
        assert wrap_var(b1) == b4
        assert wrap_var(b2) == b4
        assert wrap_var(b3) == b4

        b5 = ('bytes with %(var1)s', 'and %(var2)s')
        b6 = AnsibleUnsafeBytes(b'bytes with %(var1)s')

# Generated at 2022-06-21 09:10:10.704878
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():

    # Testing a binary string
    result = to_unsafe_bytes(b"\x00\x01\x02\x03")
    assert(isinstance(result, AnsibleUnsafeBytes))
    assert(result == b"\x00\x01\x02\x03")

    # Testing a text string
    result = to_unsafe_bytes("\u0001\u0002\u0003\u0004")
    assert(isinstance(result, AnsibleUnsafeBytes))
    assert(result == b"\x01\x02\x03\x04")

    # Testing a object that is wrapping a binary string
    class MockAnsibleUnsafeBytes(AnsibleUnsafeBytes):
        pass

# Generated at 2022-06-21 09:10:16.577673
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    obj = NativeJinjaUnsafeText('abc')
    assert 'abc' == obj
    assert obj.__UNSAFE__

    obj = NativeJinjaUnsafeText(['abc', 'def'])
    assert ['abc', 'def'] == obj
    assert obj.__UNSAFE__


# Generated at 2022-06-21 09:10:21.964655
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    try:
        txt = NativeJinjaUnsafeText('This is test text')
    except Exception as e:
        print(str(e))
        assert False

    assert len(txt) == 17
    assert txt == 'This is test text'
    assert "Unsafe" in str(txt)
    assert txt.__UNSAFE__ == True

# Generated at 2022-06-21 09:10:24.880512
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy(None), type(None))
    assert isinstance(UnsafeProxy(""), AnsibleUnsafe)
    assert isinstance(UnsafeProxy("hello"), AnsibleUnsafe)
    assert isinstance(UnsafeProxy("hello".encode("utf-8")), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy("hello".encode("utf-8").decode("utf-8")), AnsibleUnsafeText)

# Generated at 2022-06-21 09:10:31.415534
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    up = UnsafeProxy('a')
    assert isinstance(up, AnsibleUnsafe), "Should be AnsibleUnsafe"
    assert up.__UNSAFE__, "Should be marked as __UNSAFE__"
    assert isinstance(up, text_type), "Should be a string type"
    up = UnsafeProxy(b'a')
    assert isinstance(up, AnsibleUnsafe), "Should be AnsibleUnsafe"
    assert up.__UNSAFE__, "Should be marked as __UNSAFE__"
    assert isinstance(up, binary_type), "Should be a bytes type"
    assert str(up) == 'a', "str() conversion should match"
    assert repr(up) == "b'a'", "repr() conversion should match"

# Generated at 2022-06-21 09:10:42.115267
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    # Convert string to bytes
    expected = b'string_to_bytes'
    actual = to_unsafe_bytes(expected)
    assert isinstance(actual, AnsibleUnsafeBytes)
    assert actual == expected

    # Convert bytes to bytes
    expected = b'bytes_to_bytes'
    actual = to_unsafe_bytes(expected)
    assert isinstance(actual, AnsibleUnsafeBytes)
    assert actual == expected

    # Convert unicode to bytes
    expected = u'unicode_to_bytes'
    actual = to_unsafe_bytes(expected)
    assert isinstance(actual, AnsibleUnsafeBytes)
    assert actual == expected.encode('utf-8')

    # Convert bytes to different encoding
    expected = u'bytes_to_unicode'

# Generated at 2022-06-21 09:10:43.419510
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    NativeJinjaUnsafeText('test', unsafe=True)

# Generated at 2022-06-21 09:10:46.273018
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    obj_unsafe = AnsibleUnsafeBytes('test')
    obj_safe = AnsibleUnsafeText('test')
    assert obj_unsafe.decode() == obj_safe

# Generated at 2022-06-21 09:10:53.819023
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe().__UNSAFE__



# Generated at 2022-06-21 09:11:05.562222
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.utils.hashing import checksum

    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeBytes)
    assert checksum(to_unsafe_bytes('foo')) == checksum(b'foo'), checksum(b'foo')

    test_dict = dict(foo=to_unsafe_bytes('foo'))
    assert isinstance(test_dict['foo'], AnsibleUnsafeBytes)
    assert checksum(test_dict['foo']) == checksum(b'foo')

    test_list = [to_unsafe_bytes('foo')]
    assert isinstance(test_list[0], AnsibleUnsafeBytes)
    assert checksum(test_list[0]) == checksum(b'foo')

    test_set = set([to_unsafe_bytes('foo')])
   

# Generated at 2022-06-21 09:11:14.924651
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.unsafe_proxy import wrap_var, to_unsafe_bytes, to_unsafe_text

    # Test that a top level AnsibleUnsafe doesn't wrap
    assert(wrap_var(to_unsafe_bytes('foo')) == to_unsafe_bytes('foo'))
    assert(wrap_var(to_unsafe_text('foo')) == to_unsafe_text('foo'))

    # Test that an AnsibleUnsafe in a container is wrapped
    assert(wrap_var([to_unsafe_bytes('foo')]) == [to_unsafe_bytes('foo')])
    assert(wrap_var([to_unsafe_text('foo')]) == [to_unsafe_text('foo')])

# Generated at 2022-06-21 09:11:18.654743
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    #verify that an exception is thrown if constructor is called with arguments
    try:
        AnsibleUnsafe(1)
    except TypeError as e:
        pass



# Generated at 2022-06-21 09:11:26.286852
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six import text_type
    from ansible.utils.hashing import md5
    test_str = to_unsafe_bytes('Привет')
    assert isinstance(test_str, AnsibleUnsafeBytes)
    md5.update(test_str)
    assert isinstance(md5.hexdigest(), AnsibleUnsafeText)
    assert isinstance(test_str, AnsibleUnsafeBytes)
    assert isinstance(cStringIO(test_str).getvalue(), text_type)



# Generated at 2022-06-21 09:11:30.713947
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    f = AnsibleUnsafeText("\N{LEFT-POINTING ANGLE BRACKET}\N{RIGHT-POINTING ANGLE BRACKET}")
    assert isinstance(f.encode("UTF-8"), AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:11:32.652839
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # expect
    assert type(AnsibleUnsafeBytes('test').decode()) == AnsibleUnsafeText


# Generated at 2022-06-21 09:11:35.351445
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    bytes_string = 'foo'
    bytes_string_unsafe = AnsibleUnsafeBytes('foo')

    assert bytes_string_unsafe.decode('utf-8') == bytes_string


# Generated at 2022-06-21 09:11:36.889591
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    string = NativeJinjaUnsafeText("{{ hello }}")
    assert string == "{{ hello }}"

# Generated at 2022-06-21 09:11:41.714083
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.display import Display
    from ansible.module_utils.six import wraps
    import mock
    with mock.patch.object(Display, 'deprecated') as mock_obj:
        assert wrap_var(u'Hello World') == u'Hello World'
        assert wrap_var(u'Hello World') == u'Hello World'
        assert wrap_var(b'Hello World') == b'Hello World'
        assert wrap_var(b'Hello World') == b'Hello World'
        assert wrap_var([u'Hello World', u'Hello World']) == [u'Hello World', u'Hello World']
        assert wrap_var(['a', 'b']) == ['a', 'b']
        assert wrap_var({'a': 'b'}) == {'a': 'b'}
        assert wrap_var

# Generated at 2022-06-21 09:11:53.154808
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    teststring = AnsibleUnsafeText('hello world')
    assert isinstance(teststring.encode('utf-8'), AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:11:57.630059
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('foo') == 'foo'
    assert wrap_var('foo') == u'foo'
    assert wrap_var('foo') == b'foo'
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(None), type(None))

    assert wrap_var(['foo', 'bar']) == ['foo', 'bar']
    assert wrap_var(['foo', 'bar']) == (u'foo', u'bar')
    assert wrap_var(['foo', 'bar']) == (b'foo', b'bar')

# Generated at 2022-06-21 09:12:01.689190
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes(b'unsafe_text') == b'unsafe_text'
    assert AnsibleUnsafeBytes(b'unsafe_text').__UNSAFE__


# Generated at 2022-06-21 09:12:06.613914
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    result = to_unsafe_text(u"foo")
    assert result == "foo"
    assert isinstance(result, AnsibleUnsafeText)
    result = to_unsafe_text(b"foo")
    assert result == "foo"
    assert isinstance(result, AnsibleUnsafeText)


# Generated at 2022-06-21 09:12:16.934276
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.utils.unsafe_proxy import to_unsafe_text
    assert to_unsafe_text('test') == AnsibleUnsafeText('test')
    assert to_unsafe_text(None) == None
    assert to_unsafe_text(u'test') == AnsibleUnsafeText(u'test')
    assert to_unsafe_text('\xc3\xa9') == AnsibleUnsafeText('\xc3\xa9')
    assert to_unsafe_text('\xc3\xa9'.decode('utf-8')) == AnsibleUnsafeText(u'\xe9')
    assert to_unsafe_text('\xe9') == AnsibleUnsafeText(u'\xe9')
    assert to_unsafe_text('\xe9'.decode('latin-1')) == Ans

# Generated at 2022-06-21 09:12:25.562219
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    class TestAnsibleUnsafeText():
        def __init__(self, arg1):
            self.arg1 = arg1
        def check_type(self):
            assert isinstance(self.arg1, AnsibleUnsafeText)
        def check_text(self):
            assert self.arg1 == 'unsafe_text'

    test_obj = AnsibleUnsafeText('unsafe_text')
    assert isinstance(test_obj, AnsibleUnsafeText)
    assert isinstance(test_obj, text_type)
    assert test_obj == 'unsafe_text'
    assert test_obj.decode() == 'unsafe_text'
    assert test_obj.encode() == to_bytes('unsafe_text')
    test_obj_2 = TestAnsibleUnsafeText(test_obj)
   

# Generated at 2022-06-21 09:12:30.480774
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    import ansible.module_utils.basic
    # Test with bytes
    assert type(to_unsafe_bytes(b'bytes')) is AnsibleUnsafeBytes

    # Test with unicode
    assert type(to_unsafe_bytes('unicode')) is AnsibleUnsafeBytes



# Generated at 2022-06-21 09:12:33.467001
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(b'a'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(to_unsafe_text(b'a')), AnsibleUnsafeText)

# Generated at 2022-06-21 09:12:34.517257
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert UnsafeProxy("abcd") == "abcd"

# Generated at 2022-06-21 09:12:43.298713
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    pytest.importorskip('yaml')
    pytest.importorskip('jinja2')

    input_text = to_unsafe_text('Ansible is a really cool tool')
    output_text = input_text.encode()
    assert output_text == b'Ansible is a really cool tool'
    assert isinstance(output_text, AnsibleUnsafeBytes)

    input_text = to_unsafe_text('Ansible is a really cool tool')
    output_text = input_text.encode(errors='surrogate_or_strict')
    assert output_text == b'Ansible is a really cool tool'
    assert isinstance(output_text, AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:13:08.774443
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy('test'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(u'test2'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'test3'), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:13:17.158763
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes(b"Hello World"), AnsibleUnsafeBytes)
    assert not isinstance(to_unsafe_bytes(b"Hello World"), AnsibleUnsafe)
    assert isinstance(to_unsafe_bytes(b"Hello World", 'utf-8'), AnsibleUnsafeText)
    assert not isinstance(to_unsafe_bytes(b"Hello World", 'utf-8'), AnsibleUnsafe)
    assert to_unsafe_bytes('Hello World') == b'Hello World'
    assert not isinstance(to_unsafe_bytes('Hello World'), AnsibleUnsafe)



# Generated at 2022-06-21 09:13:28.777219
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    a = UnsafeProxy('+')
    b = UnsafeProxy(a)
    c = UnsafeProxy(123)
    d = UnsafeProxy([1, 2, 3])
    e = UnsafeProxy({1: 2, 3: 4})

    assert a is b
    assert not a == b
    assert a == '+'
    assert not a is 123
    assert a is not 123
    assert a is not [1, 2, 3]
    assert a is not {1: 2, 3: 4}
    assert a is not None
    assert a is not b'+'
    assert a is not u'+'
    assert a is not NativeJinjaText('+')

    assert c is not 123
    assert c is not '123'

    assert [1, 2, 3] == d

# Generated at 2022-06-21 09:13:37.102542
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    obj = to_unsafe_text(42)
    assert isinstance(obj, AnsibleUnsafeText)

    obj = to_unsafe_text(b'\xf0\x9f\x92\xa9')
    assert isinstance(obj, AnsibleUnsafeText)

    obj = to_unsafe_bytes(42)
    assert isinstance(obj, AnsibleUnsafeBytes)
    obj = to_unsafe_bytes('42')
    assert isinstance(obj, AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:13:40.480809
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    ansi_unsafe_bytes = AnsibleUnsafeBytes('test','utf-8')
    assert(isinstance(ansi_unsafe_bytes.decode(), AnsibleUnsafeText))


# Generated at 2022-06-21 09:13:48.673058
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # Unicode string
    a = AnsibleUnsafeText("你好")
    assert(type(a.encode()) == AnsibleUnsafeBytes)
    assert(type(a.encode("utf-8")) == AnsibleUnsafeBytes)

    # Sequence
    a = AnsibleUnsafeText(["你好", "Hello"])
    assert(type(a.encode()) == AnsibleUnsafeBytes)
    assert(type(a.encode("utf-8")) == AnsibleUnsafeBytes)

    # Mapping
    a = AnsibleUnsafeText({1: "你好", 2: "Hello"})
    assert(type(a.encode()) == AnsibleUnsafeBytes)
    assert(type(a.encode("utf-8")) == AnsibleUnsafeBytes)

    # Set
    a

# Generated at 2022-06-21 09:13:54.337405
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import pytest
    assert isinstance(to_unsafe_text('a'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'a'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'a'), AnsibleUnsafeText)


# Generated at 2022-06-21 09:13:56.442239
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    unsafeproxy=UnsafeProxy("Hello World")
    assert unsafeproxy == "Hello World"



# Generated at 2022-06-21 09:14:00.256368
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe().__UNSAFE__
    assert AnsibleUnsafeBytes('foo').__UNSAFE__
    assert AnsibleUnsafeText('foo').__UNSAFE__

# Unit tests for wrap_var

# Generated at 2022-06-21 09:14:04.070823
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    ansible_unsafe_bytes = AnsibleUnsafeBytes("test")
    ansible_unsafe_bytes = ansible_unsafe_bytes.decode("utf-8")
    assert isinstance(ansible_unsafe_bytes, AnsibleUnsafeText)
    assert ansible_unsafe_bytes == "test"

