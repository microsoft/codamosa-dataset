

# Generated at 2022-06-21 09:06:25.412220
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    proxy = UnsafeProxy('fake_unsafe_data')
    if isinstance(proxy, AnsibleUnsafe):
        assert proxy == 'fake_unsafe_data'
        assert isinstance(proxy, AnsibleUnsafe)
    else:
        raise AssertionError


# Generated at 2022-06-21 09:06:30.097572
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    import six

    data = dict((to_unsafe_text(k), to_unsafe_text(item)) for k, item in dict(key='value').items())
    data = to_unsafe_bytes(data)

    assert isinstance(data, six.binary_type)
    assert isinstance(data, AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:06:40.145009
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    unsafe_str = u'Hello World\n'
    utf8_str = unsafe_str.encode('utf-8')
    bytes_str = b'Hello World\n'
    unsafe_bytes_str = to_unsafe_bytes(bytes_str)

    assert isinstance(unsafe_bytes_str, AnsibleUnsafeBytes)
    assert isinstance(to_bytes(unsafe_bytes_str), binary_type)

    assert unsafe_bytes_str == to_bytes(unsafe_str)
    assert unsafe_bytes_str == utf8_str
    assert unsafe_bytes_str == bytes_str


# Generated at 2022-06-21 09:06:41.545021
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():

    assert issubclass(AnsibleUnsafe, AnsibleUnsafe)


# Generated at 2022-06-21 09:06:49.275954
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    """Tests whether the constructor of NativeJinjaUnsafeText raises an exception if
    the argument is not a str"""
    from ansible.module_utils.six import PY3


    if PY3:
        test_cases = (100, "100")
    else:
        test_cases = (100, u"100")

    for test_case in test_cases:
        try:
            NativeJinjaUnsafeText(test_case)
        except TypeError:
            pass
        else:
            assert False, "%s: should have raised an exception" % test_case

    assert True

# Generated at 2022-06-21 09:06:50.750927
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    test = AnsibleUnsafeText('test')
    assert('test' == test)

# Generated at 2022-06-21 09:07:00.977285
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY2

    assert isinstance(to_unsafe_bytes('foo'), binary_type)
    assert isinstance(to_unsafe_bytes(b'\xe2\x98\x83'), binary_type)
    if PY2:
        assert isinstance(to_unsafe_bytes(u'\u2603'), binary_type)
    else:
        assert isinstance(to_unsafe_bytes('\u2603'), binary_type)
    assert isinstance(to_unsafe_bytes(b'\xe2\x98\x83', encoding='utf-8'), binary_type)
    assert isinstance(to_unsafe_bytes(b'\xe2\x98\x83', encoding='utf-8', errors='strict'), binary_type)
    assert isinstance

# Generated at 2022-06-21 09:07:08.120634
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    from ansible.module_utils.six import binary_type
    assert AnsibleUnsafeBytes(b'').__class__.__name__ == "AnsibleUnsafeBytes"
    assert AnsibleUnsafeText(u'').__class__.__name__ == "AnsibleUnsafeText"

    try:
        AnsibleUnsafeBytes(u'')
        assert 1 == 0
    except TypeError:
        assert 1 == 1

    try:
        AnsibleUnsafeText(b'')
        assert 1 == 0
    except TypeError:
        assert 1 == 1

    assert AnsibleUnsafeBytes(b'').decode('utf-8').__class__.__name__ == "AnsibleUnsafeText"

# Generated at 2022-06-21 09:07:12.453956
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    data = AnsibleUnsafeText('aa')
    result = data.encode('utf-8')
    assert type(result.__class__) == type(AnsibleUnsafeBytes('')), "Failed AnsibleUnsafeText.encode()"


# Generated at 2022-06-21 09:07:18.024939
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(AnsibleUnsafeText('foo')), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(NativeJinjaUnsafeText('foo')), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(AnsibleUnsafeBytes('foo')), AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:07:21.692013
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert type(AnsibleUnsafeBytes(b'test')) == AnsibleUnsafeBytes


# Generated at 2022-06-21 09:07:25.056386
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    my_ansible_unsafe_text = AnsibleUnsafeText("test")
    assert my_ansible_unsafe_text == "test"


# Generated at 2022-06-21 09:07:29.903748
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    test_value = wrap_var(to_text(b'\xcf\x92\xef\xbf\xbf', encoding='utf-8'))
    assert test_value == to_unsafe_bytes(test_value)

# Generated at 2022-06-21 09:07:32.023462
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe().__UNSAFE__


# Instance methods of class AnsibleUnsafeBytes

# Generated at 2022-06-21 09:07:36.581107
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe.__UNSAFE__ is True
    assert AnsibleUnsafeBytes.__UNSAFE__ is True
    assert AnsibleUnsafeText.__UNSAFE__ is True



# Generated at 2022-06-21 09:07:44.186611
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    for s in ("test", "\xc3\xa9\xc3\xac\xc3\xbb\xc3\xbf", u"\xc3\xa9\xc3\xac\xc3\xbb\xc3\xbf"):
        b = AnsibleUnsafeBytes(s)
        assert isinstance(b, AnsibleUnsafe)
        assert isinstance(b, binary_type)
        assert b.decode('utf-8') == s
    return True


# Generated at 2022-06-21 09:07:55.353825
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types, binary_type, text_type
    from ansible.utils.display import Display
    from ansible.utils.native_jinja import NativeJinjaText

    test_list = ['ansible', 'ansible']
    test_str_list = ['ansible', 'ansible']
    test_dict = {'ansible': 'ansible'}
    test_sequence = ['ansible', 'ansible']
    test_str_sequence = ['ansible', 'ansible']
    test_set = set(['ansible', 'ansible'])
    test_bin = b'ansible'

# Generated at 2022-06-21 09:08:02.566859
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.text.converters import to_text
    if PY3:
        from ansible.module_utils.common.text.converters import to_native
    # Basic test
    test_str = 'hello world'
    proxy = UnsafeProxy(test_str)
    assert isinstance(proxy, AnsibleUnsafeText)
    # Ensure that UnsafeProxy(AnsibleUnsafe(obj)) returns obj
    proxy = UnsafeProxy(AnsibleUnsafeText(test_str))
    assert isinstance(proxy, AnsibleUnsafeText)
    # Ensure unicode strings are converted to py3 strings

# Generated at 2022-06-21 09:08:07.334794
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    #Case1:  Normal case where input string is an instance of text_type
    obj = AnsibleUnsafeText("AnsibleUnsafeText")
    assert isinstance(obj.encode(), AnsibleUnsafeBytes)

    #Case2:  input string is not an instance of text_type
    obj = AnsibleUnsafeText(b"AnsibleUnsafeText")
    assert isinstance(obj.encode(), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:08:14.035108
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types, binary_type, text_type
    from ansible.module_utils._text import to_bytes, to_text

    assert isinstance(to_unsafe_bytes(None), type(None))
    assert isinstance(to_unsafe_bytes(b'abc'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes('abc'), AnsibleUnsafeBytes)

    assert isinstance(to_unsafe_bytes({"a": "b"}), Mapping)
    assert isinstance(to_unsafe_bytes(["a", "b"]), is_sequence)

# Generated at 2022-06-21 09:08:26.055254
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    doc = "Testing AnsibleUnsafeBytes"

    def _test(obj, isinstance_error, eq_error):
        if isinstance(obj, AnsibleUnsafeText):
            if isinstance_error:
                print("isinstance AnsibleUnsafeText failed")
                return False
        else:
            if not isinstance_error:
                print("isinstance AnsibleUnsafeText succeed but should fail")
                return False

        if isinstance(obj, AnsibleUnsafeBytes):
            if isinstance_error:
                print("isinstance AnsibleUnsafeBytes failed")
                return False
        else:
            if not isinstance_error:
                print("isinstance AnsibleUnsafeBytes succeed but should fail")
                return False


# Generated at 2022-06-21 09:08:28.368251
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    a = AnsibleUnsafeText("Hello")
    assert(a == "Hello")
    return a


# Generated at 2022-06-21 09:08:35.071509
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    # Creating an unsafe object
    unsafe_obj = UnsafeProxy("someString")

    # Sanity check
    assert(isinstance(unsafe_obj, AnsibleUnsafe))

    # Check for string type
    assert(isinstance(unsafe_obj, string_types))

    # Check for original type
    assert(isinstance(unsafe_obj, text_type))



# Generated at 2022-06-21 09:08:40.412939
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    bytes_str = b"test string"
    unsafe_bytes = AnsibleUnsafeBytes(bytes_str)
    assert isinstance(unsafe_bytes, AnsibleUnsafeBytes)
    assert isinstance(unsafe_bytes, AnsibleUnsafe)
    assert isinstance(unsafe_bytes, binary_type)

# Generated at 2022-06-21 09:08:52.646048
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('foo') == AnsibleUnsafeText('foo')
    assert wrap_var(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText('foo')) == AnsibleUnsafeText('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes(b'foo')
    assert wrap_var(AnsibleUnsafeText(b'foo')) == AnsibleUnsafeText(b'foo')
    assert wrap_var(None) is None

    assert wrap_var({'foo': 'bar'}) == {'foo': AnsibleUnsafeText('bar')}
    assert wrap_var({'foo': b'bar'}) == {'foo': AnsibleUnsafeBytes(b'bar')}
    assert wrap

# Generated at 2022-06-21 09:09:00.450729
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    # Test conversion of safe string to unsafe bytes
    safe_string = 'safe string'
    unsafe_bytes = to_unsafe_bytes(safe_string)
    assert isinstance(unsafe_bytes, AnsibleUnsafeBytes)

    # Test conversion of unsafe bytes
    unsafe_bytes = 'unsafe bytes'
    unsafe_bytes = to_unsafe_bytes(unsafe_bytes)
    assert isinstance(unsafe_bytes, AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:09:04.489254
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    ans = AnsibleUnsafeText('abc')
    if not isinstance(ans.encode('utf-8'), AnsibleUnsafeBytes):
        raise AssertionError("'{}' is not '.encode()' result".format(ans.encode('utf-8')))


# Generated at 2022-06-21 09:09:12.303231
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    from ansible.utils import string_utils
    # Note: these tests are temporary. They are replacing the tests removed in #33391.
    # These tests are also temporary because the byte/string types will be changing.
    class TestableAnsibleUnsafeBytes(AnsibleUnsafeBytes):
        def __new__(cls, string, *args, **kwargs):
            return super(TestableAnsibleUnsafeBytes, cls).__new__(cls, string)

    result = TestableAnsibleUnsafeBytes(b'foo').decode('ascii')
    assert isinstance(result, string_utils.AnsibleUnsafeText) and result == 'foo'
    result = TestableAnsibleUnsafeBytes(b'foo').decode('utf-8')

# Generated at 2022-06-21 09:09:24.238868
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    import datetime
    import json

    test_dict, test_seq, test_str, test_set, test_date \
            = { 'test_key1': 'test_value1', 'test_key2': 'test_value2', 'test_key3': 'test_value3' }, \
            [ 'test_value1', 'test_value2', 'test_value3' ], \
            'test_value1', \
            { 'test_value1', 'test_value2', 'test_value3' }, \
            datetime.date.today()

    test_dict = UnsafeProxy(test_dict)
    test_seq = UnsafeProxy(test_seq)
    test_str = UnsafeProxy(test_str)
    test_set = UnsafeProxy(test_set)
    test_date = Un

# Generated at 2022-06-21 09:09:25.915613
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes('b').decode(), AnsibleUnsafeText)

# Generated at 2022-06-21 09:09:40.505779
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy(u'foobar') == u'foobar'
    assert UnsafeProxy('foobar') == u'foobar'
    assert UnsafeProxy(u'foobar').encode('utf-8') == 'foobar'
    assert UnsafeProxy('foobar').encode('utf-8') == 'foobar'
    assert UnsafeProxy(b'foobar') == b'foobar'
    assert UnsafeProxy(b'foobar').encode('utf-8') == 'foobar'
    assert UnsafeProxy(u'foobar').encode('utf-8') == 'foobar'
    assert UnsafeProxy('foobar').encode('utf-8') == 'foobar'

# Generated at 2022-06-21 09:09:51.896843
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    import jinja2
    from ansible.parsing.vault import VaultLib
    from ansible.template import AnsibleJ2
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    Display().deprecated(
        'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )
    raw_obj = 'This is my plaintext string!'
    obj = NativeJinjaUnsafeText(raw_obj)
    assert unicode(obj) == u'This is my plaintext string!'

    vault = VaultLib("hunter2")
    vault_str = vault.encode("test string")
    # create jinja2 environment
    j2_

# Generated at 2022-06-21 09:09:56.355192
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    '''
    Check that AnsibleUnsafe and its subclasses are always considered
    unsafe by Ansible's wrappers.
    '''
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    class DummyYAMLObject(AnsibleBaseYAMLObject):
        '''Dummy YAML object that is not recognized by Ansible's YAML parser,
        only the base constructor is used, making testing simpler.'''

    dummy_yaml_loader = AnsibleConstructor(None)
    dummy_yaml_loader.add_constructor(None, AnsibleBaseYAMLObject.yaml_constructor)

    # AnsibleUnsafe is not considered safe
    assert not dummy_yaml_loader.construct

# Generated at 2022-06-21 09:10:04.994030
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    content = u'Hello world, 您好'
    content_utf8 = content.encode('utf-8')
    content_gbk = content.encode('gbk')
    assert content_gbk != content_utf8

    b = AnsibleUnsafeText(content).encode('utf-8')
    assert isinstance(b, AnsibleUnsafeBytes)
    assert b == content_utf8

    b = AnsibleUnsafeText(content).encode('gbk')
    assert isinstance(b, AnsibleUnsafeBytes)
    assert b == content_gbk


# Generated at 2022-06-21 09:10:08.060744
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    unsafe_string = AnsibleUnsafeText("An Unsafe String")
    try:
        unsafe_string.encode()
    except UnicodeDecodeError:
        assert False
    else:
        assert True


# Generated at 2022-06-21 09:10:11.050944
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # Test class instantiation
    c = AnsibleUnsafe()
    results = (c is None, c.__UNSAFE__, c.__class__.__name__)
    assert results == (False, True, 'AnsibleUnsafe')


# Generated at 2022-06-21 09:10:20.944941
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    unicode_test_case = "Some unicode string"
    unsafe_test_case = AnsibleUnsafeBytes("Some unsafe binary string")
    unsafe_unicode_test_case = AnsibleUnsafeText("Some unsafe unicode string")
    assert(UnsafeProxy(unicode_test_case) == "Some unicode string")
    assert(UnsafeProxy(unsafe_test_case) == AnsibleUnsafeBytes("Some unsafe binary string"))
    assert(UnsafeProxy(unsafe_unicode_test_case) == AnsibleUnsafeText("Some unsafe unicode string"))



# Generated at 2022-06-21 09:10:23.644426
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    """
    Test __new__ of class UnsafeProxy
    """
    obj = {'1':2}
    assert UnsafeProxy(obj) == obj



# Generated at 2022-06-21 09:10:28.007250
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText('blah').encode('utf-8'), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText('blah').encode('utf-8'), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText('blah').encode('utf-8').encode('utf-8'), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:10:31.099569
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes(b'foo') == b'foo'
    assert isinstance(to_unsafe_bytes(b'foo'), binary_type)



# Generated at 2022-06-21 09:10:43.299349
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():

    assert isinstance(AnsibleUnsafeBytes('123'), AnsibleUnsafeBytes)
    assert AnsibleUnsafeBytes.__UNSAFE__ == True
    assert isinstance(AnsibleUnsafeBytes('123').decode(), AnsibleUnsafeText)
    assert AnsibleUnsafeText.__UNSAFE__ == True
    assert isinstance(AnsibleUnsafeText('123').encode(), AnsibleUnsafeBytes)
    assert AnsibleUnsafeBytes.__UNSAFE__ == True
    assert isinstance(AnsibleUnsafeText('{{ test }}'), NativeJinjaUnsafeText)
    assert NativeJinjaUnsafeText.__UNSAFE__ == True


# Generated at 2022-06-21 09:10:47.753144
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            value=dict(type='str'),
        )
    )
    value = module.params['value']
    assert value == UnsafeProxy(value)

# Generated at 2022-06-21 09:10:57.888212
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    a = AnsibleUnsafeText("foo")
    assert type(a) == AnsibleUnsafeText
    assert a == "foo"
    assert a.encode() == b"foo"

    a = AnsibleUnsafeText(b"foo")
    assert type(a) == AnsibleUnsafeText
    assert a == "foo"
    assert a.encode() == b"foo"

    a = AnsibleUnsafeText(a)
    assert type(a) == AnsibleUnsafeText
    assert a == "foo"
    assert a.encode() == b"foo"

    assert a.mro() == [AnsibleUnsafeText, text_type, object]

    d = { "a": a }
    wrap_var(d)
    assert d == { "a": a }

# Generated at 2022-06-21 09:11:00.371088
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    a = AnsibleUnsafeText("a")
    assert a == "a"

# Generated at 2022-06-21 09:11:08.113041
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('hello') == b'hello'

    b = b'\xe5\x95\x8a\x80\x9c\x9a\xe6\x96\xa4\xe8\xa1\x8c\xe4\xbb\xa3\xe7\xa2\xbc\xe5\x8c\x96\xe5\xaf\xab\xe8\xaf\x8d\xe5\x85\xa8\xe8\xb7\xaf'
    assert to_unsafe_bytes('hello').decode('ascii') == 'hello'

# Generated at 2022-06-21 09:11:10.128934
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy("hello world"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText("hello world")), AnsibleUnsafeText)


# Generated at 2022-06-21 09:11:11.521802
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    value = AnsibleUnsafeBytes('hello world')
    value = value.decode()
    assert value == 'hello world'



# Generated at 2022-06-21 09:11:15.825945
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    # type(v) == AnsibleUnsafeBytes -> v (pass-through)
    assert to_unsafe_bytes(AnsibleUnsafeBytes(b'foobar')) == AnsibleUnsafeBytes(b'foobar')

    # type(v) == AnsibleUnsafeText -> to_unsafe_bytes(v)
    assert to_unsafe_bytes(AnsibleUnsafeText(u'foobar')) == AnsibleUnsafeBytes(b'foobar')

    # type(v) != AnsibleUnsafe -> to_unsafe_bytes(v)
    assert to_unsafe_bytes(u'foobar') == AnsibleUnsafeBytes(b'foobar')


# Generated at 2022-06-21 09:11:25.123025
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    import sys

    if sys.version_info[0] == 3:
        string_type = str
    else:
        string_type = unicode

    assert isinstance(UnsafeProxy(string_type()), string_type)
    assert isinstance(UnsafeProxy(u'foo'), string_type)
    assert isinstance(UnsafeProxy('foo'), string_type)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText(u'foo')), string_type)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes(b'foo')), string_type)
    assert isinstance(UnsafeProxy(UnsafeProxy(b'foo')), string_type)

# Generated at 2022-06-21 09:11:26.875699
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeText("").decode("UTF-8"), AnsibleUnsafeText)

# Generated at 2022-06-21 09:11:42.808364
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    class Test(object):
        def __init__(self, txt):
            self.txt = txt

        def decode(self, *args, **kwargs):
            return AnsibleUnsafeText(self.txt)

    safe_bytes = AnsibleUnsafeBytes('foo')
    assert safe_bytes == 'foo'
    assert safe_bytes.decode() == 'foo'
    assert safe_bytes.decode().encode() == 'foo'
    with_obj = AnsibleUnsafeBytes(Test(safe_bytes))
    assert with_obj == 'foo'
    assert with_obj.decode() == 'foo'
    assert with_obj.decode().encode() == 'foo'


# Generated at 2022-06-21 09:11:45.272114
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    in_val = AnsibleUnsafeBytes("Test String", 'utf-8')
    out_val = in_val.decode()
    assert out_val == AnsibleUnsafeText("Test String", 'utf-8')

# Generated at 2022-06-21 09:11:46.617653
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    s = AnsibleUnsafe()
    assert s == ""


# Generated at 2022-06-21 09:11:51.320781
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    # test 1
    assert(isinstance(NativeJinjaUnsafeText("abc"), NativeJinjaUnsafeText))

    # test 2
    assert(isinstance(NativeJinjaUnsafeText("abc"), AnsibleUnsafeText))

    # test 3
    assert(isinstance(NativeJinjaUnsafeText("abc"), NativeJinjaText))

    # test 4
    assert(isinstance(NativeJinjaUnsafeText("abc"), AnsibleUnsafe))


# Generated at 2022-06-21 09:11:56.054862
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    # Standard case
    assert isinstance(UnsafeProxy('Hello World'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'some bytes'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText('some text')), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes(b'some bytes')), AnsibleUnsafeBytes)

    # Must fail
    try:
        UnsafeProxy(None)
    except Exception:
        pass
    else:
        raise AssertionError("UnsafeProxy(None) must fail")

    try:
        UnsafeProxy(list)
    except Exception:
        pass
    else:
        raise AssertionError("UnsafeProxy(list) must fail")


# Generated at 2022-06-21 09:12:09.363782
# Unit test for function wrap_var
def test_wrap_var():
    import unittest
    import sys


# Generated at 2022-06-21 09:12:14.345216
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    ansibleunsafetext_instance = AnsibleUnsafeText(u"AnsibleUnsafeTest")
    ansibleunsafetext_instance.encode()
    assert isinstance(ansibleunsafetext_instance.encode(), AnsibleUnsafeBytes)
    assert ansibleunsafetext_instance.encode() == b"AnsibleUnsafeTest"



# Generated at 2022-06-21 09:12:16.982418
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy('foo'), AnsibleUnsafeText)

# Generated at 2022-06-21 09:12:20.562939
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
  st = 'secret'
  s = AnsibleUnsafeBytes(st)
  s = s.decode()
  assert(isinstance(s, AnsibleUnsafeText))



# Generated at 2022-06-21 09:12:32.642262
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    from ansible.module_utils._text import to_bytes, to_text
    # test_bytes = to_bytes(u'ansible \u2713', encoding=None, errors='strict')
    test_bytes = b'ansible \xe2\x9c\x93'
    assert isinstance(test_bytes, binary_type)
    # test_text = to_text(test_bytes, encoding=None, errors='strict')
    test_text = u'ansible \u2713'
    assert isinstance(test_text, text_type)
    test_safe_text = AnsibleUnsafeText("test_safe_text")
    assert isinstance(test_safe_text, text_type)
    assert isinstance(test_safe_text, AnsibleUnsafe)


# Generated at 2022-06-21 09:12:56.461217
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    b = AnsibleUnsafeBytes(b'abc')
    t = b.decode()
    assert t.__class__ == AnsibleUnsafeText
    assert str(t) == 'abc'


# Generated at 2022-06-21 09:13:00.555099
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    class MyAnsibleUnsafe(AnsibleUnsafe):
        def __init__(self, name):
            self.name = name

    myobj = MyAnsibleUnsafe('foo')
    assert myobj.name == 'foo'
    assert myobj.__UNSAFE__ is True

# Generated at 2022-06-21 09:13:12.156245
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(u'foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'foo'), AnsibleUnsafeText)

    assert isinstance(to_unsafe_text(u'foo', encoding='ascii'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'foo', encoding='ascii'), AnsibleUnsafeText)

    assert isinstance(to_unsafe_text(u'foo', errors='strict'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'foo', errors='strict'), AnsibleUnsafeText)

    assert isinstance(to_unsafe_text(u'foo', nonstring='simplerepr'), AnsibleUnsafeText)

# Generated at 2022-06-21 09:13:19.782831
# Unit test for function wrap_var
def test_wrap_var():
    import sys

    class MyObj:
        pass

    # Unsafe objects are passed through
    unsafe_bytes = b"foo\x00"
    unsafe_text = u"foo\x00"
    unsafelist = [unsafe_bytes, unsafe_text]
    assert wrap_var(unsafe_bytes) is unsafe_bytes
    assert wrap_var(unsafe_text) is unsafe_text
    assert wrap_var(unsafelist) is unsafelist

    # Unicode strings are wrapped in AnsibleUnsafeText
    assert isinstance(wrap_var(u"hello world"), AnsibleUnsafeText)

    # Bytes are wrapped in AnsibleUnsafeBytes
    assert isinstance(wrap_var(b"hello world"), AnsibleUnsafeBytes)

    # NativeJinjaText is wrapped in NativeJinjaUnsafeText

# Generated at 2022-06-21 09:13:24.487564
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    aub = AnsibleUnsafeBytes(b"test")
    assert isinstance(aub, AnsibleUnsafeBytes)
    res = aub.decode()
    assert isinstance(res, AnsibleUnsafeText)
    assert res == 'test'



# Generated at 2022-06-21 09:13:36.014202
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import ImmutableDict
    import jinja2
    import os

    # test string
    assert wrap_var('abc') == AnsibleUnsafeText(u'abc')

    # test mapping
    assert wrap_var({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert wrap_var(ImmutableDict({'a': 1, 'b': 2})) == ImmutableDict({'a': 1, 'b': 2})

    # test bytes
    assert wrap_var(b'abc') == AnsibleUnsafeBytes(b'abc')

    # test sequence

# Generated at 2022-06-21 09:13:46.238726
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.six import PY2, PY3

    if PY2:
        assert to_unsafe_bytes('unicode') == AnsibleUnsafeBytes(to_bytes(b'unicode'))
        assert to_unsafe_bytes(u'unicode') == AnsibleUnsafeBytes(to_bytes(b'unicode'))
        assert to_unsafe_bytes(b'ascii') == AnsibleUnsafeBytes(b'ascii')
        assert to_unsafe_bytes(42) == AnsibleUnsafeBytes(to_bytes(42))
        assert to_unsafe_bytes(42) == AnsibleUn

# Generated at 2022-06-21 09:13:48.181194
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('1234') == to_bytes('1234')


# Generated at 2022-06-21 09:14:00.657672
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils._text import to_native
    import ansible.module_utils.six as six
    import ansible.module_utils.six.moves.builtins as __builtin__
    import sys

    # Save the builtin '__build_class__'
    __real_builtin_build_class__ = __builtin__.__build_class__

    # Mock '__build_class__' during the test

# Generated at 2022-06-21 09:14:08.091687
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Test passing a string type
    assert isinstance(UnsafeProxy("foo"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(u"foo"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b"bar"), AnsibleUnsafeBytes)

    # Passing a non-string type should return the objects unaltered
    assert UnsafeProxy(int(1)) is 1
    assert UnsafeProxy(MyObject(1)) is MyObject(1)

    # Passing an AnsibleUnsafe should return it without modification
    assert UnsafeProxy(AnsibleUnsafeText("foo")) is AnsibleUnsafeText("foo")
    assert UnsafeProxy(AnsibleUnsafeBytes("bar")) is AnsibleUnsafeBytes("bar")


# Test for method __new__ of class UnsafeProxy
# This test was previously a class method

# Generated at 2022-06-21 09:15:01.198386
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():

    # AnsibleUnsafeBytes should accept bytes objects. Checks if it is
    # accepted.
    unsafe_bytes = AnsibleUnsafeBytes(b'bytes')
    assert unsafe_bytes == b'bytes'

    # AnsibleUnsafeBytes should return bytes objects. Checks if it does.
    assert type(unsafe_bytes) == AnsibleUnsafeBytes

    # AnsibleUnsafeBytes should accept text objects. Checks if it is accepted.
    unsafe_text = unsafe_bytes.decode('utf-8')
    assert unsafe_text == u'bytes'

    # AnsibleUnsafeBytes have a method decode that returns text objects. Checks
    # if it does.
    assert type(unsafe_text) == AnsibleUnsafeText

    # AnsibleUnsafeBytes have method decode which has to be a proxy method to
    # bytes. Checks if it is inherited

# Generated at 2022-06-21 09:15:04.920616
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    from ansible.utils.hashing import secure_hash
    hashed = secure_hash(b'coucou')
    assert hashed == b'4df67dcd737f8e463b65c0efa0f94a7b84d29385'


# Generated at 2022-06-21 09:15:09.537117
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert UnsafeProxy(None) == None
    assert UnsafeProxy(True) == True
    assert UnsafeProxy(100) == 100
    assert UnsafeProxy("hello world") == "hello world"
    assert UnsafeProxy(b"hello world") == b"hello world"
    assert UnsafeProxy("hello world", encoding='utf-8') == u"hello world"

# Generated at 2022-06-21 09:15:10.570599
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe()
test_AnsibleUnsafe()


# Generated at 2022-06-21 09:15:17.000882
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    byte_string = b'\xc3\xad\xc3\xad\xc3\xad'
    ansible_unsafe_bytes = AnsibleUnsafeBytes(byte_string)
    assert ansible_unsafe_bytes.decode() == to_unsafe_text(byte_string)
    try:
        assert ansible_unsafe_bytes.decode('utf-8') == to_unsafe_text(byte_string, 'utf-8')
        assert ansible_unsafe_bytes.decode('windows-1251') == to_unsafe_text(byte_string, 'windows-1251')
    except LookupError:
        pass


# Generated at 2022-06-21 09:15:27.841889
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText('abc').encode(), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText(b'abc').encode(), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText('abc').encode(encoding='utf-8'), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText(b'abc').encode(encoding='utf-8'), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText('abc').encode(encoding='utf-8', errors='ignore'), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText(b'abc').encode(encoding='utf-8', errors='ignore'), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:15:29.852121
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    from nose.tools import assert_equal
    actual = AnsibleUnsafeText('hello')
    expected = u'hello'
    assert_equal(actual, expected)



# Generated at 2022-06-21 09:15:43.140773
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import unittest
    import os

    if os.getenv('ANSIBLE_UNSAFE_TEXT_UNIT_TEST', '0') != '1':
        raise unittest.SkipTest("ANSIBLE_UNSAFE_TEXT_UNIT_TEST not set")

# Generated at 2022-06-21 09:15:53.232316
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
  import codecs
  from ansible.module_utils._text import to_bytes,to_text
  from ansible.module_utils.six import binary_type, text_type
  from ansible.module_utils.common.collections import is_sequence
  
  str1 = "Hello World"
  str2 = """Hello World"""
  str3 = u"""Hello World"""

  # There are three types of data types with which the user can call to_text()
  # 
  # If the user gives a byte string (str)
  # If the user gives a unicode string (unicode)
  # If the user does not give anything (None)
  #
  # We will test for the following possibilities for each of these data types:
  #
  # 1. The user gives an encoding that is not None or invalid
  # 2.

# Generated at 2022-06-21 09:16:03.023451
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from copy import copy
    from ansible.utils.display import Display
    from ansible.utils import native_jinja
    from ansible.module_utils.common.text.converters import escape_unsafe_text, escape_unsafe_bytes
    from ansible.module_utils.common.warnings import DeprecationWarning
    from ansible.utils import common

    # Test: Test if no arguments are passed, returns AnsibleUnsafe()
    test_obj = UnsafeProxy()