

# Generated at 2022-06-21 09:06:19.884100
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert type(UnsafeProxy('ansible')) is AnsibleUnsafeText

# Generated at 2022-06-21 09:06:27.002009
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    var = 'This is unsafe text'
    from ansible.module_utils.common._collections_compat import Sequence
    assert type(var) is str
    assert type(AnsibleUnsafeText(var)) is AnsibleUnsafeText
    assert type(AnsibleUnsafeText(var)) is text_type
    assert type(AnsibleUnsafeText(var)) is not str
    assert type(AnsibleUnsafeText(var)) is not Sequence

# Generated at 2022-06-21 09:06:35.716329
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    from ansible.compat.tests.mock import patch
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest


# Generated at 2022-06-21 09:06:41.743628
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    bs = to_bytes("föö", encoding='utf-8')
    assert isinstance(bs, binary_type)
    bs = AnsibleUnsafeBytes(bs)
    assert isinstance(bs, AnsibleUnsafeBytes)
    bs = bs.decode("utf-8")
    assert isinstance(bs, AnsibleUnsafeText)


# Generated at 2022-06-21 09:06:44.724673
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    instance = AnsibleUnsafeBytes()
    expected_output = AnsibleUnsafeText
    assert isinstance(instance.decode(), expected_output)



# Generated at 2022-06-21 09:06:54.994171
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import xrange

    # Test normal types
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(float) == float
    assert wrap_var(True) is True

    # Test unsafe types
    assert wrap_var(AnsibleUnsafeText('test string')) == AnsibleUnsafeText('test string')
    assert wrap_var(AnsibleUnsafeBytes(b'test bytes')) == AnsibleUnsafeBytes(b'test bytes')
    assert wrap_var(NativeJinjaUnsafeText('{{ test }}')) == NativeJinjaUnsafeText('{{ test }}')
    assert wrap

# Generated at 2022-06-21 09:07:03.439387
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy(21), int)
    assert isinstance(UnsafeProxy(u"String"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b"String"), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText(u"String")), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes(b"String")), AnsibleUnsafeBytes)
    assert UnsafeProxy(AnsibleUnsafeText(u"String")).__UNSAFE__
    assert UnsafeProxy(AnsibleUnsafeBytes(b"String")).__UNSAFE__
    assert not UnsafeProxy(u"String").__UNSAFE__
    assert not UnsafeProxy(b"String").__UNSAFE__


# Generated at 2022-06-21 09:07:06.710533
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.six import PY3

# Generated at 2022-06-21 09:07:11.155880
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    from operator import methodcaller
    if AnsibleUnsafeText('safe').encode('utf-8') != b'safe':
        raise AssertionError()
    if methodcaller('encode', 'utf-8')('safe') != b'safe':
        raise AssertionError()

# Generated at 2022-06-21 09:07:14.638555
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    text = AnsibleUnsafeText('TESTING 123')
    assert text == 'TESTING 123'
    assert isinstance(text, AnsibleUnsafeText)
    assert isinstance(text, str)

# Generated at 2022-06-21 09:07:28.251522
# Unit test for constructor of class AnsibleUnsafe

# Generated at 2022-06-21 09:07:37.845862
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    from ansible.module_utils._text import to_bytes, to_text
    import ansible.module_utils.unsafe_proxy

    # Test with ASCII unicode character
    test_ansibleunsafebytes = ansible.module_utils.unsafe_proxy.AnsibleUnsafeBytes(b'a')
    assert isinstance(test_ansibleunsafebytes, ansible.module_utils.unsafe_proxy.AnsibleUnsafeBytes)
    test_ansibleunsafebytes2 = test_ansibleunsafebytes.decode('ascii')
    assert isinstance(test_ansibleunsafebytes2, ansible.module_utils.unsafe_proxy.AnsibleUnsafeText)
    assert test_ansibleunsafebytes2 == 'a'

    # Test with non-ASCII unicode character
    test_ans

# Generated at 2022-06-21 09:07:44.082435
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.ansible_local_record import record_facts

    res = wrap_var("abc")
    assert isinstance(res, text_type)
    assert hasattr(res, '__UNSAFE__')
    assert getattr(res, '__UNSAFE__') is True

    res = wrap_var("abc".encode("utf-8"))
    assert isinstance(res, binary_type)
    assert hasattr(res, '__UNSAFE__')
    assert getattr(res, '__UNSAFE__') is True

    res = wrap_var(record_facts("localhost", ansible_facts={'a': 1}))
    assert isinstance(res, Mapping)

# Generated at 2022-06-21 09:07:48.334242
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert not isinstance(wrap_var('test'), AnsibleUnsafe)
    assert isinstance(wrap_var(AnsibleUnsafeText('test')), AnsibleUnsafe)
    assert isinstance(wrap_var(AnsibleUnsafeBytes('test')), AnsibleUnsafe)

# Generated at 2022-06-21 09:07:51.752364
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    try:
        AnsibleUnsafe()
    except TypeError as e:
        assert 'this is an abstract class' in str(e)
    except:
        raise AssertionError('this should raise an exception')

# Generated at 2022-06-21 09:07:53.985629
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes(u'AnsibleUnsafeBytes') == b'AnsibleUnsafeBytes'


# Generated at 2022-06-21 09:07:55.038682
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe.__UNSAFE__ == True

# Generated at 2022-06-21 09:08:03.517420
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import sys
    import unittest

    class TestCase(unittest.TestCase):
        text = b"test"

        def test_type(self):
            self.assertTrue(isinstance(to_unsafe_text(self.text), AnsibleUnsafeText))

        def test_conversion(self):
            self.assertEqual(to_unsafe_text(self.text), u"test")

        def test_utf8(self):
            self.assertEqual(to_unsafe_text(u"\u2019".encode("utf-8"), "utf-8"), u"\u2019")

    sys.modules[__name__] = unittest

# Generated at 2022-06-21 09:08:05.356975
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    x = AnsibleUnsafeText('foo')
    assert(x == 'foo')
    assert(type(x) == AnsibleUnsafeText)

# Generated at 2022-06-21 09:08:07.494859
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    a = 'abc'
    assert(a == AnsibleUnsafeText(a))
    assert(a == AnsibleUnsafeText(AnsibleUnsafeText(a)))


# Generated at 2022-06-21 09:08:12.211964
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert(isinstance(to_unsafe_text(123), AnsibleUnsafeText))
    assert(isinstance(to_unsafe_text('foo'), AnsibleUnsafeText))
    assert(isinstance(to_unsafe_text(u'foo'), AnsibleUnsafeText))

# Generated at 2022-06-21 09:08:14.930508
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    raw = AnsibleUnsafeBytes(b"raw string")
    assert isinstance(raw, AnsibleUnsafeBytes)
    assert isinstance(raw, binary_type)
    assert isinstance(raw, AnsibleUnsafe)
    assert raw.__UNSAFE__ is True


# Generated at 2022-06-21 09:08:19.463751
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    v = AnsibleUnsafeText("foo")
    assert isinstance(v, AnsibleUnsafeText)
    assert v == "foo"
    assert v.__UNSAFE__ is True
    assert isinstance(v, text_type)



# Generated at 2022-06-21 09:08:23.517537
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.utils.display import Display
    Display().deprecated('UnsafeProxy is being deprecated, use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
                         version='2.13', collection_name='ansible.builtin')



# Generated at 2022-06-21 09:08:35.557850
# Unit test for function wrap_var
def test_wrap_var():

    assert isinstance(wrap_var(None), type(None))
    assert wrap_var(None) is None
    assert isinstance(wrap_var(''), AnsibleUnsafeText)
    assert isinstance(wrap_var(u''), AnsibleUnsafeText)
    assert isinstance(wrap_var(b''), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(dict()), dict)
    assert isinstance(wrap_var(dict(a=1)), dict)
    assert isinstance(wrap_var(['a']), list)
    assert isinstance(wrap_var((1,)), tuple)
    assert isinstance(wrap_var(set()), set)
    assert isinstance(wrap_var(set([])), set)

# Generated at 2022-06-21 09:08:38.140887
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # Define string
    test_str = "test"

    # Test class constructor
    assert isinstance(AnsibleUnsafeText(test_str), AnsibleUnsafeText) == True


# Generated at 2022-06-21 09:08:51.473542
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # test normal use
    result = AnsibleUnsafeText("hello")
    assert result == 'hello'
    assert isinstance(result, text_type)
    assert isinstance(result, AnsibleUnsafe)

    # test str() use
    result = AnsibleUnsafeText(str("hello"))
    assert result == 'hello'
    assert isinstance(result, text_type)
    assert isinstance(result, AnsibleUnsafe)

    # make sure wrapping a dummy class does not inherit from AnsibleUnsafe
    from ansible.module_utils.six import with_metaclass
    class Dummy(with_metaclass(type)):
        pass

    result = AnsibleUnsafeText(Dummy())
    assert isinstance(result, Dummy)
    assert not isinstance(result, AnsibleUnsafe)

# Generated at 2022-06-21 09:09:00.822088
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(AnsibleUnsafeText('foo')), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes('foo'.encode('utf8')), AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:09:02.730560
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    my_unsafe = AnsibleUnsafe()
    assert my_unsafe.__UNSAFE__


# Generated at 2022-06-21 09:09:06.514935
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    # creating an object of class NativeJinjaUnsafeText
    test_obj = NativeJinjaUnsafeText()
    assert test_obj.__UNSAFE__ is True, "NativeJinjaUnsafeText.__UNSAFE__ is not set to True"

# Generated at 2022-06-21 09:09:14.967787
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    try:
        class TestAnsibleUnsafe(AnsibleUnsafe):
            pass
    except TypeError as e:
        assert(False)
    except AttributeError as e:
        assert(False)
    except Exception as e:
        assert(False)
    else:
        assert(True)


# Generated at 2022-06-21 09:09:20.450805
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # when
    ansible_unsafe_bytes = AnsibleUnsafeBytes('abc')
    # then
    assert isinstance(ansible_unsafe_bytes, AnsibleUnsafeBytes)
    assert isinstance(ansible_unsafe_bytes, binary_type)


# Generated at 2022-06-21 09:09:28.603497
# Unit test for function wrap_var
def test_wrap_var():
    import sys

    class Dummy(object):
        """Dummy class for test"""
        __UNSAFE__ = True

    one = AnsibleUnsafeText('dummy')
    assert wrap_var(one) is one
    two = Dummy()
    assert wrap_var(two) is two
    assert wrap_var(Dummy) is Dummy
    if sys.version_info[0] == 2:
        assert wrap_var(long(3)) == long(3)
    else:
        assert wrap_var(3) == 3

    assert wrap_var('string') == 'string'
    assert isinstance(wrap_var(b'bytes'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'unicode'), AnsibleUnsafeText)

# Generated at 2022-06-21 09:09:40.578773
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    v_1 = "test1"
    v_2 = "test2"
    v_3 = "test3"
    v_4 = "test4"

    test_1 = NativeJinjaUnsafeText(v_1)
    assert type(test_1) is NativeJinjaUnsafeText
    assert test_1.__UNSAFE__ == True

    test_2 = NativeJinjaUnsafeText(v_2, encoding="utf8")
    assert type(test_2) is NativeJinjaUnsafeText
    assert test_2.__UNSAFE__ == True
    assert test_2.encoding == "utf8"

    test_3 = NativeJinjaUnsafeText(v_3, errors="strict")
    assert type(test_3) is NativeJinjaUnsafeText

# Generated at 2022-06-21 09:09:44.724158
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    text = AnsibleUnsafeText('latin-1')
    assert text.encode('utf-8').__UNSAFE__
    assert not isinstance(text.encode('utf-8'), AnsibleUnsafeText)


# Generated at 2022-06-21 09:09:47.896152
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    input = b'ascii'
    b = AnsibleUnsafeBytes(input)
    assert isinstance(b.decode(), AnsibleUnsafe)



# Generated at 2022-06-21 09:09:55.167416
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    up = UnsafeProxy('string')
    assert isinstance(up, AnsibleUnsafeText)
    up = UnsafeProxy(AnsibleUnsafeText('string'))
    assert isinstance(up, AnsibleUnsafeText)
    up = UnsafeProxy(b'string')
    assert isinstance(up, AnsibleUnsafeBytes)
    up = UnsafeProxy(AnsibleUnsafeBytes(b'string'))
    assert isinstance(up, AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:10:06.824022
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    # case 1: instance of AnsibleUnsafe is given
    case1 = AnsibleUnsafeText('Hi')
    assert isinstance(case1, UnsafeProxy)

    # case 2: unicode string is given
    case2 = u'Hi'
    assert isinstance(UnsafeProxy(case2), AnsibleUnsafeText)

    # case 3: str is given
    case3 = 'Hi'
    assert isinstance(UnsafeProxy(case3), AnsibleUnsafeText)

    # case 4: bytearray is given
    case4 = bytearray(b'Hi')
    assert isinstance(UnsafeProxy(case4), AnsibleUnsafeBytes)

    # case 5: bytes is given
    case5 = bytes(b'Hi')
    assert isinstance(UnsafeProxy(case5), AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:10:11.313453
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    from ansible.module_utils.six import PY3
    if PY3:
        assert issubclass(str, AnsibleUnsafeText)
        assert issubclass(bytes, AnsibleUnsafeBytes)
    else:
        assert issubclass(unicode, AnsibleUnsafeText)
        assert issubclass(str, AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:10:25.281986
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.six import string_types, binary_type, text_type
    from ansible.utils.unsafe_proxy import wrap_var, to_unsafe_bytes

    # test case #1 - value as unicode - should return AnsibleUnsafeText
    a, b, c = to_unsafe_bytes("123456"), to_unsafe_bytes("abcdef"), to_unsafe_bytes("ABCDEF")
    assert isinstance(a, AnsibleUnsafeBytes)
    assert isinstance(b, AnsibleUnsafeBytes)
    assert isinstance(c, AnsibleUnsafeBytes)

    # test case #2 - value as int - should return AnsibleUnsafeText
    a, b, c = to_unsafe_

# Generated at 2022-06-21 09:10:31.774642
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    pass


# Generated at 2022-06-21 09:10:33.433642
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    NativeJinjaUnsafeText('test string')

# Generated at 2022-06-21 09:10:40.402650
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    # Check for empty string case
    assert isinstance(to_unsafe_text(''), AnsibleUnsafeText)

    # Check for unicode string case
    assert isinstance(to_unsafe_text(u'unicode'), AnsibleUnsafeText)

    # Check for bytes string case
    assert isinstance(to_unsafe_text('bytes'), AnsibleUnsafeText)

    # Check for non-string type
    assert to_unsafe_text(u'some unicode string', non_string='someval') is None

# Generated at 2022-06-21 09:10:45.910003
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_bytes(u'foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_bytes(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(None), type(None))



# Generated at 2022-06-21 09:10:50.500366
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    result = (NativeJinjaUnsafeText('foo'))
    assert(isinstance(result, NativeJinjaText))
    assert(isinstance(result, AnsibleUnsafeText))
    assert(isinstance(result, text_type))

# Generated at 2022-06-21 09:10:57.006539
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY3, binary_type
    assert isinstance(to_unsafe_bytes('a', 'utf-8'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes('a'), AnsibleUnsafeBytes)
    assert to_unsafe_bytes(to_unsafe_bytes('a', 'utf-8'),
                           encoding='utf-8', errors='strict') == to_unsafe_bytes('a', 'utf-8')
    if not PY3:
        assert isinstance(to_unsafe_bytes(u'a'), unicode)
        assert isinstance(to_unsafe_bytes(u'a', 'utf-8'), unicode)

# Generated at 2022-06-21 09:10:58.412421
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert AnsibleUnsafeText(u'hello') == u'hello'

# Generated at 2022-06-21 09:11:01.295393
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    a = 'test'
    b = AnsibleUnsafeText(a)
    assert b.__UNSAFE__

# Generated at 2022-06-21 09:11:06.841558
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    """
    Construct NativeJinjaUnsafeText with a unicode value.
    """
    from ansible.module_utils.six import u
    a = NativeJinjaUnsafeText(u('hello'))

    assert(a is not None)
    assert(a == u('hello'))
    assert(a.__UNSAFE__ is True)
    assert(isinstance(a, AnsibleUnsafeText) is True)


# Generated at 2022-06-21 09:11:07.958704
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes(b"foobar"), AnsibleUnsafe)



# Generated at 2022-06-21 09:11:22.178173
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible import module_utils
    from ansible.module_utils._text import to_native, to_text
    from ansible.template import Templar
    from ansible.parsing.ajson import AnsibleJSONEncoder, AnsibleJSONDecoder

    class DummyModule(object):
        class DummyParams(object):
            def __init__(self, dict):
                self.__dict__ = dict

        def __init__(self, dict):
            self.params = self.DummyParams(dict)
            self._templar = Templar(loader=None)

        def fail_json(self, *args, **kwargs):
            raise Exception(kwargs)

        def exit_json(self, *args, **kwargs):
            raise Exception(kwargs)

    # Not a native string, so it should not

# Generated at 2022-06-21 09:11:24.735308
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    obj=AnsibleUnsafe()
    assert isinstance(obj,AnsibleUnsafe), \
    "Failed to create instance of the class AnsibleUnsafe"

# Generated at 2022-06-21 09:11:26.853034
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    result = isinstance(b'foo'.decode('utf-8'), AnsibleUnsafeText)
    assert result == True


# Generated at 2022-06-21 09:11:31.320907
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # Invalid argument, should raise an exception.
    try:
        AnsibleUnsafe(AnsibleUnsafe)
        assert False
    except:
        assert True
    # Valid argument, should return a new object.
    assert AnsibleUnsafe(AnsibleUnsafeText) is not None


# Generated at 2022-06-21 09:11:34.136983
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('abc'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(to_unsafe_bytes('abc')), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:11:36.801576
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # Don't need to do anything, just make sure no exceptions
    u_str = AnsibleUnsafeText('This is a test Unicode string')
    b_str = AnsibleUnsafeBytes(b'This is a test bytes string')



# Generated at 2022-06-21 09:11:41.637499
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():

    # test with a string
    ansible_text = "This is a ansible_text"
    jinja_unsafe_text = NativeJinjaUnsafeText(ansible_text)
    assert ansible_text == jinja_unsafe_text

    # test with a Unicode
    ansible_text = u"This is a ansible_text"
    jinja_unsafe_text = NativeJinjaUnsafeText(ansible_text)
    assert ansible_text == jinja_unsafe_text

    # test with a unsafe Unicode
    ansible_text = u"This is a unsafe text"
    jinja_unsafe_text = NativeJinjaUnsafeText(AnsibleUnsafeText(ansible_text))
    assert ansible_text == jinja_unsafe_text

    #

# Generated at 2022-06-21 09:11:49.334940
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes(b'spam') == AnsibleUnsafeBytes(b'spam')
    assert to_unsafe_bytes('spam') == AnsibleUnsafeBytes(b'spam')
    assert to_unsafe_bytes('spam', errors='strict') == AnsibleUnsafeBytes(b'spam')
    assert to_unsafe_bytes(AnsibleUnsafeBytes(b'spam')) is AnsibleUnsafeBytes(b'spam')
    assert to_unsafe_bytes(NativeJinjaUnsafeText(b'spam')) is AnsibleUnsafeBytes(b'spam')



# Generated at 2022-06-21 09:11:50.961099
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    expectResult = 'lalala'
    actualResult = NativeJinjaUnsafeText(expectResult)
    assert actualResult == expectResult
    assert isinstance(actualResult, NativeJinjaUnsafeText)


# Generated at 2022-06-21 09:11:52.419573
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # Test two decode calls
    cls = AnsibleUnsafeBytes()
    cls = cls.decode()
    cls = cls.decode()
    assert isinstance(cls, AnsibleUnsafeText)



# Generated at 2022-06-21 09:12:24.640837
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('hello') == AnsibleUnsafeText(u'hello')
    assert isinstance(wrap_var('hello'), AnsibleUnsafeText)
    assert wrap_var(u'hello') == AnsibleUnsafeText(u'hello')
    assert isinstance(wrap_var(u'hello'), AnsibleUnsafeText)
    assert wrap_var(b'hello') == AnsibleUnsafeBytes('hello')
    assert isinstance(wrap_var(b'hello'), AnsibleUnsafeBytes)
    assert wrap_var([1, 2, 3]) == [1, 2, 3]
    assert isinstance(wrap_var([1, 2, 3]), list)
    assert wrap_var(tuple([1, 2, 3])) == tuple([1, 2, 3])

# Generated at 2022-06-21 09:12:36.037108
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('test') == 'test'
    assert wrap_var(1) == 1
    assert wrap_var(1.00) == 1.0
    assert wrap_var([1, 2, 3]) == [1, 2, 3]
    assert wrap_var(['1', '2', '3']) == ['1', '2', '3']
    assert wrap_var(['1', '2', '3']) == ['1', '2', '3']
    assert wrap_var({1: '1', 2: '2', 3: '3'}) == {1: '1', 2: '2', 3: '3'}
    assert wrap_var({1: '1', 2: '2', 3: '3'}) == {1: '1', 2: '2', 3: '3'}
    assert wrap

# Generated at 2022-06-21 09:12:37.476866
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert AnsibleUnsafeText(UnsafeProxy('foo')) == 'foo'

# Generated at 2022-06-21 09:12:39.524315
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text('Hello'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'Hello'), AnsibleUnsafeText)

# Generated at 2022-06-21 09:12:46.004759
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # convert string
    assert isinstance(UnsafeProxy('foo'), AnsibleUnsafeText)
    # no-op on unsafe text
    assert isinstance(UnsafeProxy(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    # no-op on unsafe bytes
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes('foo')), AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:12:49.726382
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    s = "Testing NativeJinjaUnsafeText"
    j = NativeJinjaUnsafeText(s)

    def test_member():
        assert s == j.unjinja

    def test_method():
        assert s == j.unjinja()

# Generated at 2022-06-21 09:12:55.198332
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.utils.display import Display
    Display().deprecated(
        'to_unsafe_text is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )

# Generated at 2022-06-21 09:13:04.123475
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.module_utils.six import string_types

    # Check text type
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeText)

    # Check dict type
    assert isinstance(wrap_var({'foo': 'bar'}), Mapping)
    assert isinstance(wrap_var({'foo': 'bar'}).get('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var({'foo': b'bar'}).get('foo'), AnsibleUnsafeText)

# Generated at 2022-06-21 09:13:15.754988
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # Test with empty string
    x = AnsibleUnsafeText()
    assert isinstance(x, AnsibleUnsafeText) and x == ""

    # Test with simple string
    x = AnsibleUnsafeText('test')
    assert isinstance(x, AnsibleUnsafeText) and isinstance(x, text_type) and x == 'test'

    # Test with bytes string
    x = AnsibleUnsafeText(b'test')
    assert isinstance(x, AnsibleUnsafeText) and isinstance(x, text_type) and x == 'test'

    # Test with unicode string
    x = AnsibleUnsafeText(u'test')
    assert isinstance(x, AnsibleUnsafeText) and isinstance(x, text_type) and x == 'test'

    # Test with None
    x = AnsibleUn

# Generated at 2022-06-21 09:13:21.806779
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    """
    Test the function 'to_unsafe_text' and make sure the result is instance of 'AnsibleUnsafeText'
    """
    text_unsafe = to_unsafe_text("test to_unsafe_text")
    assert isinstance(text_unsafe, AnsibleUnsafeText), 'Result should be instance of AnsibleUnsafeText'

# Generated at 2022-06-21 09:13:50.142132
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import pytest

    unsafe_text_utf8 = to_unsafe_text(u'\u6d4b\u8bd5')
    assert isinstance(unsafe_text_utf8, AnsibleUnsafeText)
    assert unsafe_text_utf8 == u'\u6d4b\u8bd5'

    unsafe_text_ascii = to_unsafe_text(u'abc123')
    assert isinstance(unsafe_text_ascii, AnsibleUnsafeText)
    assert unsafe_text_ascii == u'abc123'

    # Let's add an invalid byte to the utf-8 string to test the default error handling of to_text

# Generated at 2022-06-21 09:14:01.624976
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    import sys
    import ansible.module_utils.basic
    import ansible.module_utils.six
    tmp_argv = sys.argv
    # This value is not a unicode string, but bytes that represent utf-8 encoded
    # string.
    sys.argv = ['ansible', u"\u6240\u6709\u5143\u7d20\u306fstr\u3067\u3042\u308b\u3079\u304f".encode('utf-8')]
    result = to_unsafe_bytes(sys.argv)
    assert isinstance(result[0], AnsibleUnsafeBytes)
    assert isinstance(result[1], AnsibleUnsafeBytes)
    sys.argv = tmp_argv
    # This value is unicode string
    result = to

# Generated at 2022-06-21 09:14:08.784507
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    foo = AnsibleUnsafeBytes('Foo')
    assert isinstance(foo, AnsibleUnsafe)

    # Test that the __UNSAFE__ attribute is set
    assert foo.__UNSAFE__

    # Test that decoding returns an AnsibleUnsafeText
    bar = foo.decode()
    assert isinstance(bar, AnsibleUnsafeText)
    assert isinstance(bar, NativeJinjaUnsafeText)



# Generated at 2022-06-21 09:14:12.631662
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    bytes_type = AnsibleUnsafeBytes(b"test")
    assert isinstance(bytes_type.decode(), AnsibleUnsafeText)


# Generated at 2022-06-21 09:14:16.057011
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    string_in = u'Hello World'
    bytes_out = AnsibleUnsafeBytes(string_in)

    assert type(bytes_out.decode('utf-8')) is AnsibleUnsafeText



# Generated at 2022-06-21 09:14:19.677410
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    # try to create a new instance of UnsafeProxy
    proxy = UnsafeProxy('hello')
    assert isinstance(proxy, AnsibleUnsafeText)
    assert proxy == 'hello'
    assert proxy.__UNSAFE__



# Generated at 2022-06-21 09:14:22.212650
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    b = AnsibleUnsafeBytes('ascii')
    t = b.decode()
    assert isinstance(t, AnsibleUnsafeText)


# Generated at 2022-06-21 09:14:31.924522
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.module_utils.common.collections import is_collection
    unsafe_text = NativeJinjaUnsafeText('hello')
    assert len(unsafe_text) == len('hello')
    assert str(unsafe_text) == 'hello'
    assert unsafe_text.__class__.__name__ == 'NativeJinjaUnsafeText'
    assert unsafe_text.__len__() == len(str(unsafe_text))
    assert unsafe_text.__str__() == str(unsafe_text)
    assert is_collection(unsafe_text) == False
    assert is_sequence(unsafe_text) == False
    assert is_sequence(unsafe_text) == False


# Generated at 2022-06-21 09:14:36.144019
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text('test string') == AnsibleUnsafeText("test string")
    assert to_unsafe_text(b'test string') == AnsibleUnsafeText("test string")


# Generated at 2022-06-21 09:14:44.081168
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Test with normal variable
    unsafe_normal = UnsafeProxy(u"unsafe string")
    assert isinstance(unsafe_normal, AnsibleUnsafeText)

    # Test with AnsibleUnsafe variable
    unsafe_ansible = UnsafeProxy(AnsibleUnsafeText(u"unsafe"))
    assert unsafe_ansible == u"unsafe"
    assert isinstance(unsafe_ansible, AnsibleUnsafeText)

    # Test with empty variable
    # If no return in __new__, NoneType is returned
    unsafe_empty = UnsafeProxy()
    assert unsafe_empty is None



# Generated at 2022-06-21 09:15:29.497800
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert not isinstance('test', AnsibleUnsafe)
    assert isinstance(UnsafeProxy('test'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'test'), AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:15:37.907892
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.common.collections import ImmutableDict

    x = u'\u20ac'
    y = ImmutableDict({
        to_unsafe_text('a'): x,
        u'b': to_unsafe_text(x)
    })
    assert y[u'a'] == x
    assert y[u'b'] == x
    assert len(y[u'a']) == 1
    assert len(y[u'b']) == 1

# Generated at 2022-06-21 09:15:43.236647
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    string = u'lañch'
    want = AnsibleUnsafeText(u'lañch')
    got = to_unsafe_bytes(string)
    assert want == got
    # ensure we're on python 2
    from sys import version_info
    assert version_info.major < 3

# Generated at 2022-06-21 09:15:45.114795
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    x = AnsibleUnsafe()
    assert x



# Generated at 2022-06-21 09:15:50.231870
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={}
    )

    obj = {}
    proxy = UnsafeProxy(obj)
    o = module.from_json(module.to_json(proxy))

    assert(o == obj)
    assert(isinstance(o, dict))


# Generated at 2022-06-21 09:15:52.083723
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    a = "Test value"
    assert type(NativeJinjaUnsafeText(a)) == NativeJinjaUnsafeText

# Generated at 2022-06-21 09:16:01.633501
# Unit test for function wrap_var
def test_wrap_var():
    result = wrap_var(None)
    assert result is None

    result = wrap_var(['a', 'b'])
    assert isinstance(result, list)
    assert isinstance(result[0], AnsibleUnsafeText)

    result = wrap_var(('a', 'b'))
    assert isinstance(result, tuple)
    assert isinstance(result[0], AnsibleUnsafeText)

    result = wrap_var({'a': 'b'})
    assert isinstance(result, dict)
    assert isinstance(result['a'], AnsibleUnsafeText)

    result = wrap_var({'a': 'b', 'c': ['d', 'e']})
    assert isinstance(result, dict)
    assert isinstance(result['a'], AnsibleUnsafeText)

# Generated at 2022-06-21 09:16:05.376196
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b'\x01\x02').decode(), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeBytes(b'\x01\x02').decode('utf-8'), AnsibleUnsafeText)


# Generated at 2022-06-21 09:16:08.226983
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    s = AnsibleUnsafeBytes('test')
    assert isinstance(s, AnsibleUnsafeBytes)
    assert isinstance(s, AnsibleUnsafe)
    s = AnsibleUnsafeText('test')
    assert isinstance(s, AnsibleUnsafeText)
    assert isinstance(s, AnsibleUnsafe)

# Generated at 2022-06-21 09:16:14.114985
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    # simple cases for strings
    assert isinstance(UnsafeProxy("bla"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(u"bla"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b"bla"), AnsibleUnsafeBytes)
    # safety first: even if error is raised, output should be safe
    assert isinstance(UnsafeProxy('\xc3\x28', errors='ignore'), AnsibleUnsafeText)

