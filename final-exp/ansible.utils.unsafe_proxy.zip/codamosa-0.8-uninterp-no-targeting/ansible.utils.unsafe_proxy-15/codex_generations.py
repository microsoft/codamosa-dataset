

# Generated at 2022-06-21 09:06:21.690804
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    try:
        NativeJinjaUnsafeText(None)
    except TypeError:
        pass
    else:
        raise Exception("Failed to raise TypeError")

# Generated at 2022-06-21 09:06:32.767959
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():

    # Test with a string
    assert '__UNSAFE__' in dir(UnsafeProxy(u'hello'))
    assert UnsafeProxy(u'hello').__UNSAFE__

    # Test with a bytestring
    assert '__UNSAFE__' in dir(UnsafeProxy(b'hello'))
    assert UnsafeProxy(b'hello').__UNSAFE__

    # Test with a native jinja template
    assert '__UNSAFE__' in dir(UnsafeProxy('{%- set hello = "hello" %}{{ hello }}'))
    assert UnsafeProxy('{%- set hello = "hello" %}{{ hello }}').__UNSAFE__

    # Test with an unsafe proxy
    assert '__UNSAFE__' in dir(UnsafeProxy(UnsafeProxy(u'hello')))
    assert Unsafe

# Generated at 2022-06-21 09:06:38.883330
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert(isinstance(to_unsafe_text(b'hello'), AnsibleUnsafeText))
    assert(isinstance(to_unsafe_text(to_text('hello', errors='surrogate_or_strict')), AnsibleUnsafeText))
    assert(isinstance(to_unsafe_text(6), int))

# Generated at 2022-06-21 09:06:49.123999
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('test') == AnsibleUnsafeText(u'test')
    assert wrap_var('test') == to_unsafe_text('test')

    assert wrap_var(b'test') == AnsibleUnsafeBytes(b'test')
    assert wrap_var(b'test') == to_unsafe_bytes(b'test')

    assert wrap_var({'test': 'test'}) == {AnsibleUnsafeText(u'test'): AnsibleUnsafeText(u'test')}
    assert wrap_var([AnsibleUnsafeText(u'test')]) == [AnsibleUnsafeText(u'test')]

    assert wrap_var(set([AnsibleUnsafeText(u'test')])) == set([AnsibleUnsafeText(u'test')])


# Generated at 2022-06-21 09:06:59.901654
# Unit test for function wrap_var
def test_wrap_var():
    import json
    from ansible.module_utils.six import string_types

    def check_unsafe(val):
        """check if val is marked __UNSAFE__"""
        if isinstance(val, AnsibleUnsafe):
            return True

        if isinstance(val, string_types):
            val = AnsibleUnsafeText(to_text(val, errors='surrogate_or_strict'))

        if isinstance(val, Mapping):
            for v in val.values():
                if not check_unsafe(v):
                    return False
        elif isinstance(val, Set):
            for v in val:
                if not check_unsafe(v):
                    return False
        elif is_sequence(val):
            for v in val:
                if not check_unsafe(v):
                    return False

# Generated at 2022-06-21 09:07:07.103195
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes(1), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(True), AnsibleUnsafeBytes)
    res = to_unsafe_bytes(['a', 1])
    assert isinstance(res[0], AnsibleUnsafeBytes)
    assert res[0].decode() == 'a'
    assert res[1] == b'1'



# Generated at 2022-06-21 09:07:14.092010
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    '''
    Test to_unsafe_bytes
    '''
    assert isinstance(to_unsafe_bytes(), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'\xee', encoding='latin-1'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u'\u20ac', encoding='latin-1'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u'\u20ac', encoding='utf-8'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes('foo', errors='surrogate_or_strict'), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:07:16.511747
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Testing the correct behavior of __new__
    assert UnsafeProxy('Hello').__UNSAFE__ is True


# Generated at 2022-06-21 09:07:29.264240
# Unit test for function wrap_var
def test_wrap_var():

    # The function wrap_var is recursive.
    # The function handles lists, dictionaries, sets and strings.
    # This test handles the cases of lists and dictionaries.

    # The test should return a dictionary with ansible_unsafe as the value
    # whenever the key of the dictionary is something that is handled by wrap_var.
    # The test should also make sure that the original value is not altered.

    dict_orig = dict(string='string', ansible_unsafe='ansible_unsafe')
    dict_test = dict(string='string', ansible_unsafe=wrap_var('ansible_unsafe'))

    test_dict = wrap_var(dict_orig)

    assert all(test_dict[key] == value for key, value in dict_test.items())

# Generated at 2022-06-21 09:07:38.315380
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes(b'TestClass') == b'TestClass'
    assert AnsibleUnsafeBytes(b'TestClass').__UNSAFE__
    assert AnsibleUnsafeBytes(b'TestClass').encode('utf-8') == AnsibleUnsafeBytes(b'TestClass')
    assert isinstance(AnsibleUnsafeBytes(b'TestClass'), AnsibleUnsafeText)
    assert AnsibleUnsafeBytes(b'TestClass').decode('utf-8') == 'TestClass'
    assert isinstance(AnsibleUnsafeBytes(b'TestClass').decode('utf-8'), AnsibleUnsafeText)
    assert AnsibleUnsafeBytes(b'TestClass').decode('utf-8').encode('utf-8') == AnsibleUnsafeBytes(b'TestClass')


# Generated at 2022-06-21 09:07:41.696878
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    teststr = 'hello world'
    assert(to_unsafe_bytes(teststr) == b'hello world')

# Generated at 2022-06-21 09:07:52.830291
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert(NativeJinjaUnsafeText(AnsibleUnsafeText('abc')) == 'abc')
    assert(NativeJinjaUnsafeText(AnsibleUnsafeText('')) == '')
    assert(NativeJinjaUnsafeText('') == '')
    assert(NativeJinjaUnsafeText(AnsibleUnsafeText(b'abc')) == 'abc')
    assert(NativeJinjaUnsafeText(AnsibleUnsafeText(b'abc')) != 'abcd')
    assert(NativeJinjaUnsafeText(to_unsafe_text(b'abc')) == 'abc')
    assert(AnsibleUnsafeText(NativeJinjaUnsafeText('abc')) == 'abc')

# Generated at 2022-06-21 09:07:56.314354
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    s = 'foo'
    u = AnsibleUnsafeBytes(s)
    assert vars(u) == vars(s)
    assert u.__Unsafe__
    assert u.__class__ is AnsibleUnsafeBytes



# Generated at 2022-06-21 09:07:57.428964
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert repr(UnsafeProxy('test')) == repr('test')

# Generated at 2022-06-21 09:08:04.029380
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableSequence
    from ansible.module_utils.common.collections import ImmutableMapping
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import xrange

    if PY3:
        text_super = str
    else:
        text_super = basestring

    assert text_super(type(UnsafeProxy('hello'))) == text_super(type(AnsibleUnsafeText('hello')))

# Generated at 2022-06-21 09:08:08.467130
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import binary_type, text_type
    my_unicode = text_type('My unicode')
    my_bytes = binary_type('My bytes')

    assert isinstance(UnsafeProxy(my_unicode), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(my_bytes), AnsibleUnsafeBytes)



# Generated at 2022-06-21 09:08:16.284176
# Unit test for function wrap_var
def test_wrap_var():
    print(wrap_var(b'unicode'))
    print(wrap_var(b'unicode').__class__)
    print(wrap_var(b'unicode').encode())
    print(wrap_var(b'unicode').encode().__class__)
    print(wrap_var(u'unicode'))
    print(wrap_var(u'unicode').__class__)
    print(wrap_var(u'unicode').encode())
    print(wrap_var(u'unicode').encode().__class__)
    print(wrap_var(['unicode']))
    print(wrap_var(['unicode']).__class__)
    print(wrap_var(['unicode']).__class__.__name__)

# Generated at 2022-06-21 09:08:21.326929
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import unittest
    import ansible.module_utils.six

    class TestToUnsafeText(unittest.TestCase):
        if not ansible.module_utils.six.PY3:
            def test_str_to_str(self):
                result = to_unsafe_text(u'h\xe9')
                self.assertTrue(isinstance(result, unicode))
                self.assertEqual(result, u'h\xe9')

        def test_bytes_to_str(self):
            result = to_unsafe_text(b'h\xc3\xa9')
            self.assertTrue(isinstance(result, unicode))
            self.assertEqual(result, u'h\xe9')

        def test_text_to_str(self):
            result = to_unsafe

# Generated at 2022-06-21 09:08:25.027929
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy('hello'), text_type)
    assert isinstance(UnsafeProxy(b'hello'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(b'hello'), binary_type)

# Generated at 2022-06-21 09:08:26.281710
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    a = AnsibleUnsafe()

# Generated at 2022-06-21 09:08:33.820019
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text('hello, world!') == AnsibleUnsafeText('hello, world!')
    assert to_unsafe_text(AnsibleUnsafeText('hello, world!')) == AnsibleUnsafeText('hello, world!')

# Generated at 2022-06-21 09:08:38.600298
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    a = NativeJinjaUnsafeText('hello world')
    assert isinstance(a, NativeJinjaUnsafeText)
    assert isinstance(a, AnsibleUnsafeText)
    assert isinstance(a, text_type)
    assert isinstance(a, AnsibleUnsafe)
    assert not isinstance(a, binary_type)
    assert not isinstance(a, AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:08:41.673508
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    a1 = b"a test"
    a2 = AnsibleUnsafeBytes(a1)
    assert a2 == a1

# Generated at 2022-06-21 09:08:45.165485
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText("foo").encode("utf-8"), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:08:50.915514
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(b'hello'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'hello'), AnsibleUnsafeText)
    assert to_unsafe_text(b'hello').__UNSAFE__ == True
    assert to_unsafe_text(u'hello').__UNSAFE__ == True

# Generated at 2022-06-21 09:09:03.146212
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    # Test methods available for ansible unsafe byte None values
    assert to_unsafe_bytes(None).__class__.__name__ == 'NoneType'
    assert to_unsafe_bytes(None).__UNSAFE__ == True
    assert to_unsafe_bytes(None).__str__() == 'None'
    assert to_unsafe_bytes(None).__repr__() == 'None'
    assert to_unsafe_bytes(None).__len__() == 0
    assert to_unsafe_bytes(None).__bool__() == False

    # Test methods available for ansible unsafe byte values
    assert to_unsafe_bytes('test').__class__.__name__ == 'AnsibleUnsafeBytes'
    assert to_unsafe_bytes('test').__UNSAFE__ == True
    assert to_unsafe_

# Generated at 2022-06-21 09:09:11.583486
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    test_string = to_unsafe_bytes('ABC')
    assert isinstance(test_string, AnsibleUnsafeBytes)
    assert 'A' == test_string[0]
    assert isinstance(test_string.decode(), AnsibleUnsafeText)
    assert 'A' == test_string.decode()[0]
    assert isinstance(test_string.decode('utf-8'), AnsibleUnsafeText)
    assert 'A' == test_string.decode('utf-8')[0]
    assert isinstance(test_string.decode('ascii'), AnsibleUnsafeText)
    assert 'A' == test_string.decode('ascii')[0]
    assert isinstance(test_string.decode(encoding='utf-8', errors='replace'), AnsibleUnsafeText)
   

# Generated at 2022-06-21 09:09:17.708472
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    unsafe_bytes = b'abc\x07\x08def'
    unsafe_bytes = AnsibleUnsafeBytes(unsafe_bytes)
    decoded = unsafe_bytes.decode()
    assert isinstance(decoded, AnsibleUnsafe)
    assert decoded == 'abc\x07\x08def'


# Generated at 2022-06-21 09:09:23.352733
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert(isinstance(AnsibleUnsafeText("Test AnsibleUnsafeText"), AnsibleUnsafeText))
    assert(isinstance(AnsibleUnsafeText(b"Test AnsibleUnsafeText"), AnsibleUnsafeText))
    assert(isinstance(AnsibleUnsafeText(u"Test AnsibleUnsafeText"), AnsibleUnsafeText))


# Generated at 2022-06-21 09:09:29.960227
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(None), type(None))
    assert isinstance(to_unsafe_text(u'foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'foo'.encode('utf-8')), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'foo'.decode('utf-8')), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'foo', errors='surrogate_or_strict'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'foo', errors='surrogate_or_strict').encode(), AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:09:37.564786
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('abcde') == u'abcde'
    assert to_unsafe_bytes(u'abcde') == u'abcde'



# Generated at 2022-06-21 09:09:40.272432
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    data = b'test'
    result = AnsibleUnsafeText(data).encode()
    assert isinstance(result, AnsibleUnsafeBytes)
    assert result == data


# Generated at 2022-06-21 09:09:51.392685
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    """
    This function is a unit test for to_unsafe_text
    """
    from ansible.utils.display import Display
    original_display = Display()
    class MockDisplay(object):
        """
        Mock class for display
        """
        @staticmethod
        def deprecated(msg, version, collection_name):
            """
            Mock for display.deprecated
            """
            assert msg == 'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead'
            assert version == '2.13'
            assert collection_name == 'ansible.builtin'

    Display.__class__ = MockDisplay
    to_unsafe_text('foo')
    # Reset display
    Display.__class__ = original_display

# Generated at 2022-06-21 09:09:53.073591
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert isinstance(AnsibleUnsafeText(), text_type)

# Generated at 2022-06-21 09:09:57.741057
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    a = AnsibleUnsafeBytes('my str')
    b = a.decode('utf-8')
    assert isinstance(b, AnsibleUnsafeText)
    assert b == 'my str'

# Generated at 2022-06-21 09:10:06.639386
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():

    from ansible.utils.unsafe_proxy import UnsafeProxy
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    txt = 'test'

    assert isinstance(UnsafeProxy(txt), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText(txt)), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes(txt)), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes(txt.encode('utf-8'))), AnsibleUnsafeText)



# Generated at 2022-06-21 09:10:11.170645
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    njut = NativeJinjaUnsafeText("test")
    assert(njut == "test")
    assert(njut == b"test")
    assert(type(njut) == text_type)
    assert(type(njut) == NativeJinjaUnsafeText)
    assert(type(njut) != NativeJinjaText)

# Generated at 2022-06-21 09:10:23.934096
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import PY3
    # for python 2.6 compat, importing unicode_literals
    from ansible.module_utils.six.moves import builtins
    if PY3:
        unicode = getattr(builtins, "unicode")

    # If we are given a string that is not unicode, coerce the value to
    # unicode.
    assert issubclass(UnsafeProxy(u"foo"), unicode)
    assert UnsafeProxy("foo") == "foo"

    # If we are given a string that is already unicode, return the string
    # unchanged.
    assert UnsafeProxy(unicode("foo")) == "foo"

    # If we are given a byte string, make sure it is safe

# Generated at 2022-06-21 09:10:30.947093
# Unit test for function wrap_var
def test_wrap_var():
    # AnsibleUnsafe (Types)
    assert isinstance(wrap_var(AnsibleUnsafe()), AnsibleUnsafe)

    # AnsibleUnsafe (Strings)
    assert isinstance(wrap_var('Hello World, '), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'Hello World, '), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'Hello World, '), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeText('Hello World, ')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes('Hello World, ')), AnsibleUnsafeText)

    # Unicode
    assert isinstance(wrap_var(u'Hello World,'), AnsibleUnsafeText)

    # Bytes

# Generated at 2022-06-21 09:10:39.025629
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text('1'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text({u'1': u'2'}), dict)
    assert isinstance(to_unsafe_text(['1']), list)
    assert isinstance(to_unsafe_text(('1')), tuple)
    assert isinstance(to_unsafe_text(1), int)
    assert isinstance(to_unsafe_text(u'1'), AnsibleUnsafeText)

# Generated at 2022-06-21 09:10:51.033965
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    AnsibleUnsafeText('test')
    assert True


# Generated at 2022-06-21 09:10:59.174657
# Unit test for function wrap_var
def test_wrap_var():
    import pytest

    # Basic string test
    assert isinstance(wrap_var(None), type(None))

    assert isinstance(wrap_var(''), AnsibleUnsafeText)
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b''), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Bytes returns safe text
    assert isinstance(wrap_var(to_bytes('')), AnsibleUnsafeText)
    assert isinstance(wrap_var(to_bytes('foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(to_bytes(b'')), AnsibleUnsafeText)

# Generated at 2022-06-21 09:11:05.243481
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(None) is None
    assert to_unsafe_text(123) == "123"
    assert to_unsafe_text(0x0550) == u'\u0550'
    assert to_unsafe_text(bytearray(b'foo')) == u'foo'
    assert to_unsafe_text(b'foo') == u'foo'



# Generated at 2022-06-21 09:11:13.517568
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # Create an instance of class AnsibleUnsafeText with an argument of type AnsibleUnsafeBytes
    a = AnsibleUnsafeText(AnsibleUnsafeBytes(b"test"))
    # Create an instance of class AnsibleUnsafeText with an argument of type AnsibleUnsafeText
    b = AnsibleUnsafeText(AnsibleUnsafeText("test"))
    # Create an instance of class AnsibleUnsafeText with an argument of type unicode
    c = AnsibleUnsafeText(u"test")
    # Create an instance of class AnsibleUnsafeText with an argument of type string
    d = AnsibleUnsafeText("test")

    # Test the value of the instance is a string
    assert isinstance(a, string_types)
    assert isinstance(b, string_types)
    assert isinstance(c, string_types)


# Generated at 2022-06-21 09:11:20.104929
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance("foo", AnsibleUnsafeText)
    assert isinstance("foo".encode("utf-8"), AnsibleUnsafeBytes)
    assert not isinstance("foo".decode("utf-8"), AnsibleUnsafe)
    assert isinstance("foo".encode("utf-8").decode("utf-8"), AnsibleUnsafeText)


# Generated at 2022-06-21 09:11:26.555614
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy(""), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b""), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(u""), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText(u"")), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes(b"")), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(None), type(None))



# Generated at 2022-06-21 09:11:32.277093
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    unsafe_byte = AnsibleUnsafeBytes(b'y')

    # Test if it is a string and if it's instance is AnsibleUnsafe
    assert(isinstance(unsafe_byte, string_types))
    assert(isinstance(unsafe_byte, AnsibleUnsafe))

    # Test if it's __UNSAFE__ instance variable is True
    assert(unsafe_byte.__UNSAFE__)

# Generated at 2022-06-21 09:11:33.916288
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    a = AnsibleUnsafe()
    assert a.__UNSAFE__


# Generated at 2022-06-21 09:11:41.464038
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    import six
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common.text.converters import to_bytes as to_unsafe_bytes, to_text as to_unsafe_text
    from ansible.module_utils.common.text.converters import assert_native_str

    # Test with 'utf-8'
    v1 = "test"
    au1 = AnsibleUnsafeText(v1)
    # On Python 2, we should get the same value back.
    # On Python 3, we should get the same value back but already as a binary type
    if not PY3:
        assert isinstance(au1, TextType)
    assert au1.en

# Generated at 2022-06-21 09:11:45.179054
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import u

    assert isinstance(AnsibleUnsafeText(u('a')).encode(), binary_type)


# Generated at 2022-06-21 09:12:16.204269
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    """test for AnsibleUnsafeText"""
    # test of AnsibleUnsafeText.__new__
    text = to_text(u"test")
    assert isinstance(text, unicode)
    assert text == u"test"
    assert not isinstance(text, AnsibleUnsafeText)

    text = to_unsafe_text(u"test")
    assert isinstance(text, unicode)
    assert text == u"test"
    assert isinstance(text, AnsibleUnsafeText)

    # test of AnsibleUnsafeText.encode
    byte = b"test"
    assert isinstance(byte, bytes)
    assert byte == b"test"
    assert not isinstance(byte, AnsibleUnsafeBytes)

    byte = to_unsafe_bytes(u"test")

# Generated at 2022-06-21 09:12:20.119664
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    u = AnsibleUnsafeText("AnsibleUnsafeText")
    assert(u.__UNSAFE__ == True)
    assert(type(u).__name__ == "AnsibleUnsafeText")



# Generated at 2022-06-21 09:12:26.174280
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    data = AnsibleUnsafeText(u"\u039A\u0391\u03A3\u03A3\u0395")
    assert data.encode('utf-8') == b'\xce\x9a\xce\x91\xce\xa3\xce\xa3\xce\x95'

# Generated at 2022-06-21 09:12:37.263763
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    import sys
    a = AnsibleUnsafeText('世界')
    #print(a)
    #print(type(a))
    print(sys.getdefaultencoding())
    print(a.encode('cp936').decode(sys.getdefaultencoding()))
    print(type(a.encode('cp936').decode(sys.getdefaultencoding())))
    print(type(a))
    print(type(AnsibleUnsafeText('世界')))


if __name__ == '__main__':
    #test_AnsibleUnsafeText()
    from ansible.utils.display import Display
    display = Display()

# Generated at 2022-06-21 09:12:41.145379
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import u
    result = UnsafeProxy(u("text"))
    assert isinstance(result, AnsibleUnsafeText) and result == u("text")
    result = UnsafeProxy(b("text"))
    assert isinstance(result, AnsibleUnsafeBytes) and result == b("text")
    result = UnsafeProxy(None)
    assert result is None

# Generated at 2022-06-21 09:12:47.685891
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    UnsafeProxy("str")
    assert(UnsafeProxy("str") == "str")
    assert(UnsafeProxy(None) is None)
    assert(UnsafeProxy(None) is None)
    assert(isinstance(UnsafeProxy("str"), text_type))
    assert(isinstance(UnsafeProxy(b"str"), binary_type))
    assert(isinstance(UnsafeProxy(1), int))


# Generated at 2022-06-21 09:12:56.809788
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('ansible'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'ansible'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u'ansible'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(AnsibleUnsafeBytes('ansible')), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(AnsibleUnsafeText('ansible')), AnsibleUnsafeBytes)


# Generated at 2022-06-21 09:13:04.717040
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Test the case of AnsibleUnsafe argument.
    s_unsafe = UnsafeProxy(AnsibleUnsafeBytes(b'Unsafe bytes'))
    assert isinstance(s_unsafe, binary_type)
    assert isinstance(s_unsafe, AnsibleUnsafe)
    assert s_unsafe == b'Unsafe bytes'

    s_unsafe = UnsafeProxy(AnsibleUnsafeText(to_text(b'Unsafe text')))
    assert isinstance(s_unsafe, text_type)
    assert isinstance(s_unsafe, AnsibleUnsafe)
    assert s_unsafe == to_text(b'Unsafe text')

    # Test the case of string argument.
    s_unsafe = UnsafeProxy(b'Unsafe bytes')

# Generated at 2022-06-21 09:13:06.916978
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy("foo") == "foo"
    assert UnsafeProxy("foo") != "bar"

# Generated at 2022-06-21 09:13:10.035249
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    test_b = b"\xC3\xBC"
    unsafe = AnsibleUnsafeBytes(test_b)
    unsafe.decode('utf-8')

# Generated at 2022-06-21 09:13:56.211112
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    class TestClass: pass
    assert issubclass(AnsibleUnsafeBytes, binary_type)
    assert issubclass(AnsibleUnsafeBytes, AnsibleUnsafe)
    assert not issubclass(AnsibleUnsafeBytes, TestClass)
    assert AnsibleUnsafeBytes.__UNSAFE__


# Generated at 2022-06-21 09:14:05.476441
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy(u'foo'), AnsibleUnsafeText)
    assert UnsafeProxy(u'foo') == u'foo'
    assert isinstance(UnsafeProxy(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    assert UnsafeProxy(AnsibleUnsafeText('foo')) == 'foo'
    assert isinstance(UnsafeProxy(b'foo'), AnsibleUnsafeBytes)
    assert UnsafeProxy(b'foo') == b'foo'
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes('foo')), AnsibleUnsafeBytes)
    assert UnsafeProxy(AnsibleUnsafeBytes('foo')) == b'foo'
    assert isinstance(UnsafeProxy(NativeJinjaText('foo')), NativeJinjaUnsafeText)
    assert UnsafeProxy

# Generated at 2022-06-21 09:14:18.134536
# Unit test for function wrap_var
def test_wrap_var():
    a = NativeJinjaText('abc')
    assert isinstance(wrap_var(a), NativeJinjaUnsafeText)

    a = b'abc'
    assert isinstance(wrap_var(a), AnsibleUnsafeBytes)

    a = 'abc'
    assert isinstance(wrap_var(a), AnsibleUnsafeText)

    a = ('a', 'b', 'c')
    for i in a:
        assert isinstance(i, AnsibleUnsafeText)

    a = ['a', 'b', 'c']
    for i in a:
        assert isinstance(i, AnsibleUnsafeText)

    a = {'a': 1, 'b': 2, 'c': 3}
    for k, v in a.items():
        assert isinstance(k, AnsibleUnsafeText)

# Generated at 2022-06-21 09:14:22.642646
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    b_val = to_unsafe_bytes('test')
    assert type(b_val) == AnsibleUnsafeBytes
    assert b_val == b'test'
    assert not b_val.__class__.__UNSAFE__
    assert b_val.__class__.__bases__[0].__UNSAFE__


# Generated at 2022-06-21 09:14:29.883010
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.utils.unsafe_proxy import UnsafeProxy
    x = UnsafeProxy('abc')
    assert isinstance(x, UnsafeProxy)
    assert isinstance(x, AnsibleUnsafeText)
    assert x == u'abc'

    y = UnsafeProxy(u'abc')
    assert isinstance(y, UnsafeProxy)
    assert isinstance(y, AnsibleUnsafeText)
    assert y == u'abc'



# Generated at 2022-06-21 09:14:31.880781
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # Ensure that by default, binary strings will be unsafe
    assert AnsibleUnsafeBytes(b'This is a test string')



# Generated at 2022-06-21 09:14:43.566131
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(None), type(None))
    assert isinstance(to_unsafe_text(42), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(42.2), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(to_bytes(b'a\xf1b')), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(['1', b'a\xf1b']), tuple)

    assert isinstance(to_unsafe_text(u'a\xf1b'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text((b'a', u'b\xf1c')), tuple)

# Generated at 2022-06-21 09:14:55.657538
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    __UNSAFE__ = True
    assert isinstance(AnsibleUnsafeBytes('foo'), AnsibleUnsafeBytes)


if __name__ == "__main__":
    import sys
    from ansible.utils.display import Display
    from ansible.module_utils.six import integer_types

    display = Display()

    display.display('Testing __UNSAFE__ attribute')
    # We should be able to attach "__UNSAFE__" to anything ...
    a = 1
    assert not isinstance(a, AnsibleUnsafe)
    a.__UNSAFE__ = True
    assert isinstance(a, AnsibleUnsafe)

    display.display('Testing to_unsafe_bytes')
    b = to_unsafe_bytes('hello')
    assert isinstance(b, AnsibleUnsafeBytes)

# Generated at 2022-06-21 09:15:04.926177
# Unit test for function wrap_var
def test_wrap_var():
    foo = {
        'bar': [
            "baz",
            "baz1",
            "baz2"
        ]
    }
    foo = wrap_var(foo)
    assert isinstance(foo, dict)
    assert isinstance(foo['bar'], list)
    assert isinstance(foo['bar'][0], AnsibleUnsafeText)
    assert isinstance(foo['bar'][1], AnsibleUnsafeText)
    assert isinstance(foo['bar'][2], AnsibleUnsafeText)

    foo = {
        'bar': {
            'baz': 'one',
            'baz1': 'two',
            'baz2': 'three'
        }
    }
    foo = wrap_var(foo)
    assert isinstance(foo, dict)

# Generated at 2022-06-21 09:15:07.072184
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.utils.display import Display
    with Display().override_display(verbosity=2):
        UnsafeProxy(u'UnsafeProxy')