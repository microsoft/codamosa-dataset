

# Generated at 2022-06-23 14:38:17.061843
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence

    isinstance(UnsafeProxy(None), type(None))
    isinstance(UnsafeProxy(True), bool)
    isinstance(UnsafeProxy(5), int)
    isinstance(UnsafeProxy('hello'), AnsibleUnsafeText)
    isinstance(UnsafeProxy(u'hello'), text_type)
    isinstance(UnsafeProxy(b'hello'), AnsibleUnsafeBytes)
    isinstance(UnsafeProxy([1, 2, 3]), MutableSequence)
    isinstance(UnsafeProxy((1, 2, 3)), tuple)
    isinstance(UnsafeProxy({1: 2}), MutableMapping)
    isinstance(UnsafeProxy({'a': 'b'}), MutableMapping)


# Generated at 2022-06-23 14:38:20.084201
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text("a"), AnsibleUnsafeText)



# Generated at 2022-06-23 14:38:28.535010
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    unsafe_text = AnsibleUnsafeText('abc')
    assert unsafe_text == 'abc', 'AnsibleUnsafeText should be initialized with str'
    assert not isinstance(unsafe_text, bytes), 'AnsibleUnsafeText should not be initialized with bytes'
    assert not isinstance(unsafe_text, NativeJinjaText), 'AnsibleUnsafeText should not be initialized with NativeJinjaText'
    try:
        unsafe_text = AnsibleUnsafeText(b'abc')
        assert False, 'AnsibleUnsafeText should not be initialized with bytes'
    except UnicodeError as ex:
        assert str(ex) == "decoding Unicode is not supported", 'AnsibleUnsafeText should not be initialized with bytes'

# Generated at 2022-06-23 14:38:30.581710
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text('abc'), AnsibleUnsafeText)


# Generated at 2022-06-23 14:38:39.112469
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    a = AnsibleUnsafe()
    b = AnsibleUnsafeBytes(b"which is a byte string")
    c = AnsibleUnsafeText(u"which is a unicode string")

    assert(a.__UNSAFE__ is True)
    assert(b.__UNSAFE__ is True)
    assert(c.__UNSAFE__ is True)

    # test for AnsibleUnsafeBytes()
    a = AnsibleUnsafeBytes(b"which is a byte string in class AnsibleUnsafeBytes")
    assert(isinstance(a, str))
    assert(isinstance(a, binary_type))
    assert(isinstance(a, AnsibleUnsafe))
    assert(a.__UNSAFE__ is True)

# Generated at 2022-06-23 14:38:40.911089
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    ansible_text = AnsibleUnsafeText('foo')
    ansible_text_encoded = ansible_text.encode()
    assert isinstance(ansible_text_encoded, AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:38:45.005917
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    inputValue = b"This is a byte string"
    expectedResult = u"This is a byte string"
    actualResult = AnsibleUnsafeBytes(inputValue).decode('utf-8')
    assert actualResult == expectedResult
    assert isinstance(actualResult, AnsibleUnsafeText) == True

# Generated at 2022-06-23 14:38:57.671952
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy(AnsibleUnsafeText('')), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes(b'')), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(''), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b''), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy('foo'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'foo'), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:38:59.666421
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    safe_text = "I'm safe"
    safe_text2 = u"I'm safe"
    assert (
        isinstance(to_unsafe_bytes(safe_text), AnsibleUnsafeBytes) and
        isinstance(to_unsafe_bytes(safe_text2), AnsibleUnsafeBytes)
    )

# Generated at 2022-06-23 14:39:04.475109
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    test_string = b"some_string_bytes"
    unsafe_bytes = AnsibleUnsafeBytes(test_string)
    # Ensure AnsibleUnsafeBytes.decode returns an AnsibleUnsafeText type
    assert isinstance(unsafe_bytes.decode(), AnsibleUnsafeText)


# Generated at 2022-06-23 14:39:09.921267
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy('foo'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText('foo')), AnsibleUnsafeText)



# Generated at 2022-06-23 14:39:18.497039
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import b
    assert to_unsafe_bytes(u'foo') == b('foo')
    assert isinstance(to_unsafe_bytes(u'foo'), AnsibleUnsafeBytes)
    assert to_unsafe_bytes(b'foo') == b('foo')
    assert to_unsafe_bytes('foo') == b('foo')
    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeBytes)
    assert to_unsafe_bytes(bytearray(b'foo')) == b('foo')
    assert isinstance(to_unsafe_bytes(bytearray(b'foo')), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:39:30.229302
# Unit test for function wrap_var
def test_wrap_var():
    # string
    assert isinstance(wrap_var('hello'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'hello'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'hello'), AnsibleUnsafeText)

    # list
    assert isinstance(wrap_var([1, 2, 3]), list)
    assert isinstance(wrap_var([u'hello', u'world']), list)
    assert isinstance(wrap_var([b'hello', b'world']), list)
    assert isinstance(wrap_var([b'hello', u'world']), list)
    assert isinstance(wrap_var([u'hello', b'world']), list)

    # tuple
    assert isinstance(wrap_var((1, 2, 3)), tuple)

# Generated at 2022-06-23 14:39:35.767242
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy(b'blah') == AnsibleUnsafeText('blah')
    assert UnsafeProxy('blah') == AnsibleUnsafeText('blah')
    assert type(UnsafeProxy(b'blah')) is AnsibleUnsafeText
    assert type(UnsafeProxy('blah')) is AnsibleUnsafeText



# Generated at 2022-06-23 14:39:37.927470
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes(b''), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:39:39.984823
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.utils.unsafe_proxy import NativeJinjaUnsafeText
    unsafe = NativeJinjaUnsafeText('some text')
    assert unsafe == 'some text'
    assert not unsafe.__UNSAFE__

# Generated at 2022-06-23 14:39:50.040224
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var({u'foo': u'bar'}), dict)
    assert isinstance(wrap_var({u'foo': u'bar'})[u'foo'], AnsibleUnsafeText)
    assert isinstance(wrap_var({b'foo': b'bar'}), dict)
    assert isinstance(wrap_var({b'foo': b'bar'})[b'foo'], AnsibleUnsafeBytes)
    assert isinstance(wrap_var([u'foo', u'bar']), list)

# Generated at 2022-06-23 14:39:59.885512
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    """Test conversion of the string to unsafe bytes"""
    from ansible.module_utils.six import text_type

    to_bytes_unsafe_str = '\u0410\u0411\u0412'.encode('utf-8')
    to_bytes_unsafe = to_unsafe_bytes('\u0410\u0411\u0412')
    assert(isinstance(to_bytes_unsafe, binary_type))

    assert(to_bytes_unsafe_str == to_bytes_unsafe)

    to_bytes_unsafe_unicode = '\u0410\u0411\u0412'
    to_bytes_unsafe_unicode_bytes = to_bytes_unsafe_unicode.encode('utf-8')
    to_bytes_unsafe_unicode_unsafe = to_

# Generated at 2022-06-23 14:40:02.490704
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    text = 'test_text'
    unsafe_bytes = to_unsafe_bytes(text)
    assert isinstance(unsafe_bytes, AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:40:05.950151
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    b = to_bytes('test')
    ub = AnsibleUnsafeBytes(b)
    assert ub == 'test'
    assert isinstance(ub, AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:40:11.928255
# Unit test for function wrap_var
def test_wrap_var():
    import collections
    assert wrap_var(u'unicode_in_wrap_var') is not None
    assert wrap_var('string_in_wrap_var') is not None
    assert wrap_var({'key': 'value'}) is not None
    assert wrap_var([1, 2, 3]) is not None
    assert wrap_var(collections.OrderedDict()) is not None

# Generated at 2022-06-23 14:40:23.325987
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils._text import to_text
    import unittest

    class TestUnsafeProxy(unittest.TestCase):

        def test_init(self):

            proxy = UnsafeProxy('test')
            self.assertIsInstance(proxy, AnsibleUnsafeText)
            self.assertEqual(proxy, 'test')
            self.assertNotEqual(proxy, u'test')

            proxy = UnsafeProxy(b'test')
            self.assertIsInstance(proxy, AnsibleUnsafeBytes)
            self.assertEqual(proxy, b'test')
            self.assertNotEqual(proxy, u'test')

            proxy = UnsafeProxy({'key': 'test', 'key2': b'test'})
            self.assertIsInstance(proxy, dict)

# Generated at 2022-06-23 14:40:25.441481
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b'hello').decode(), AnsibleUnsafeText)


# Generated at 2022-06-23 14:40:31.924183
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():

    obj = AnsibleUnsafeText("I am unsafe")
    assert isinstance(obj, AnsibleUnsafe), "Should be an instance of AnsibleUnsafe"

    obj = AnsibleUnsafeText("I am unsafe".encode("utf-8"))
    assert isinstance(obj, AnsibleUnsafeBytes), "Should be an instance of AnsibleUnsafe"


# Test for wrap_var for different type of python objects

# Generated at 2022-06-23 14:40:33.340596
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy('foo'), AnsibleUnsafeText)



# Generated at 2022-06-23 14:40:36.658639
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    u = AnsibleUnsafeBytes("foobarbaz")
    s = u.decode("utf-8")
    assert isinstance(s, AnsibleUnsafeText)
    assert str(s) == "foobarbaz"



# Generated at 2022-06-23 14:40:48.066458
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.display import Display
    from ansible.utils.unsafe_proxy import UnsafeProxy

    class Func():
        @classmethod
        def deprecated(self, msg, version='', collection_name=''):
            self.msg = msg
            self.version = version
            self.collection_name = collection_name

    # AnsibleUnsafeBytes/AnsibleUnsafeText has been assigned to "obj"
    def _unsafe_proxy_test(obj):
        # __new__ of UnsafeProxy can be called in two ways:
        # 1. _UnsafeProxy(obj, *args, **kwargs)
        # 2. _UnsafeProxy(obj)
        # Create an instance of UnsafeProxy class
        proxy = UnsafeProxy(obj, *args, **kwargs)

        # Same instance as above


# Generated at 2022-06-23 14:40:50.081334
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    obj = AnsibleUnsafeText("test")
    assert obj == "test"
    assert obj.__UNSAFE__ == True

# Generated at 2022-06-23 14:40:57.631696
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    test_data = {
        u'Hello': u'Hello'
    }
    for raw_string, expected_decoded_string in test_data.items():
        # Test default decode
        unsafe_bytes = AnsibleUnsafeBytes(raw_string)
        decoded_bytes = unsafe_bytes.decode()
        assert isinstance(decoded_bytes, AnsibleUnsafeText)
        assert decoded_bytes == expected_decoded_string
        # Test encode(encoding='utf-8')
        decoded_bytes = unsafe_bytes.decode(encoding='utf-8')
        assert isinstance(decoded_bytes, AnsibleUnsafeText)
        assert decoded_bytes == expected_decoded_string


# Generated at 2022-06-23 14:40:59.871691
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # A simple text variable
    test_var = "Testing"
    # Type check
    assert(type(test_var) == AnsibleUnsafeText)


# Generated at 2022-06-23 14:41:01.086239
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe() is not None

# Generated at 2022-06-23 14:41:11.829701
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var({'foo': 'bar'}), dict)
    assert isinstance(wrap_var(['foo', 'bar']), list)
    assert isinstance(wrap_var(('foo', 'bar')), tuple)
    assert isinstance(wrap_var(set(['foo', 'bar'])), set)

    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u'foo'), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:41:15.128688
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    # "Unsafe" property should be retained after the constructor call
    text = 'TEST'
    unsafe_text = NativeJinjaUnsafeText(text)
    assert unsafe_text.__UNSAFE__



# Generated at 2022-06-23 14:41:27.558003
# Unit test for function wrap_var
def test_wrap_var():

    assert(isinstance(wrap_var(u'x'), AnsibleUnsafeText))
    assert(isinstance(wrap_var(b'x'), AnsibleUnsafeBytes))
    assert(isinstance(wrap_var([b'x']), tuple))
    assert(isinstance(wrap_var({b'x': 1}), dict))
    assert(isinstance(wrap_var(set(b'xyz')), set))
    assert(isinstance(wrap_var(('x', 'y', 'z')), tuple))
    assert(isinstance(wrap_var(['x', 'y', 'z']), list))
    assert(isinstance(wrap_var({b'x': 1, 'y': 2, b'z': 3}), dict))

# Generated at 2022-06-23 14:41:32.211008
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.unsafe_proxy import UnsafeProxy
    assert isinstance(UnsafeProxy('text'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'bytes'), AnsibleUnsafeBytes)
    assert UnsafeProxy(None) is None
    assert UnsafeProxy(UnsafeProxy('text'))

# Generated at 2022-06-23 14:41:35.405628
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    txt = NativeJinjaUnsafeText(u'{{ foo }}')
    assert txt == u'{{ foo }}'
    assert txt.__UNSAFE__ is True

# Generated at 2022-06-23 14:41:44.031236
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.utils.display import Display
    display = Display()
    t = display.indent("test_1", 3)
    assert isinstance(t, AnsibleUnsafeText)
    t = display.indent(b"test_2", 3)
    assert isinstance(t, AnsibleUnsafeText)
    t = display.indent(u"test_3", 3)
    assert isinstance(t, AnsibleUnsafeText)
    t = to_unsafe_text(u"test_4")
    assert isinstance(t, AnsibleUnsafeText)
    t = to_unsafe_text(b"test_5")
    assert isinstance(t, AnsibleUnsafeText)

# Generated at 2022-06-23 14:41:51.723015
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var("abc") == "abc"
    assert wrap_var("abc".encode('ascii')) == AnsibleUnsafeBytes("abc")
    assert wrap_var(("a", "b")) == ("a", "b")
    assert wrap_var(["a", "b"]) == ["a", "b"]
    assert wrap_var(("a", "b").__class__("a")) == ("a",)

# Generated at 2022-06-23 14:42:02.175127
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy(b""), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(u""), AnsibleUnsafeText)

    obj = {
        "a": ["b", "c"],
        "b": {u"x": u"y"},
        "c": ("c", "d"),
        "d": set(["e", "f"]),
        "e": [b"e", b"f"],
        "f": [1, 2],
        "g": b"g",
        u"h": u"h",
        "i": {
            "j": [1, 2],
            "k": "l",
            u"m": u"n",
            "o": b"p",
        }
    }
    safe_obj = UnsafeProxy(obj)

# Generated at 2022-06-23 14:42:13.682357
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import binary_type, text_type

    def testfunc(a):
        msg = ''
        if not isinstance(a, text_type):
            msg = "value of a is not of type text_type"
        if not isinstance(a, AnsibleUnsafeText):
            msg = "value of a is not of type AnsibleUnsafeText"
        return msg

    module = AnsibleModule(
        argument_spec=dict(
            a=dict(type='str'),
        ),
        supports_check_mode=True,
    )
    module.exit_json(msg=testfunc(to_unsafe_text(module.params['a'])))

# Generated at 2022-06-23 14:42:16.862798
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy(AnsibleUnsafeText(text_type('to_text'))), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(to_text('to_text')), AnsibleUnsafeText)

# Generated at 2022-06-23 14:42:18.841714
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert isinstance(AnsibleUnsafeText('foo'), AnsibleUnsafeText)


# Generated at 2022-06-23 14:42:26.057649
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    test_str = '\xc3\xa4\xc3\xb6\xc3\xbc'
    ans_unsafe_bytes = AnsibleUnsafeBytes(test_str)
    ans_unsafe_text = ans_unsafe_bytes.decode()
    assert isinstance(ans_unsafe_text, AnsibleUnsafeText)
    assert ans_unsafe_text == 'äöü'
    assert len(ans_unsafe_text) == 3


# Generated at 2022-06-23 14:42:28.271251
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    bytes_1 = b'dummy'
    bytes_2 = AnsibleUnsafeBytes(bytes_1)
    assert bytes_2.decode() == to_text(bytes_1)
    assert bytes_2.__UNSAFE__


# Generated at 2022-06-23 14:42:29.346050
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 14:42:38.482254
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import binary_type, text_type

    a = "test"
    a_bytes = b"test"
    a_unicode = u"test"
    a_list = ["test"]
    a_tuple = ("test",)
    a_dict = {"a":"test"}
    a_set = set(a_tuple)

    assert isinstance(to_unsafe_text(a), text_type)
    assert isinstance(to_unsafe_text(a_bytes), text_type)
    assert isinstance(to_unsafe_text(a_unicode), text_type)
    assert isinstance(to_unsafe_text(a_list), list)

# Generated at 2022-06-23 14:42:42.776707
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    value = AnsibleUnsafeText('test')
    assert value.encode() == AnsibleUnsafeBytes('test')
    assert value.encode('utf-8') == AnsibleUnsafeBytes('test')
    assert value.encode('utf-8', 'ignore') == AnsibleUnsafeBytes('test')


# Generated at 2022-06-23 14:42:51.105405
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    native_jinja_unsafe_text = NativeJinjaUnsafeText('test_str')
    assert native_jinja_unsafe_text == 'test_str'
    assert type(native_jinja_unsafe_text) == NativeJinjaUnsafeText

    test_str = 'test_unsafe_text'
    native_jinja_unsafe_text = wrap_var(test_str)
    assert native_jinja_unsafe_text == test_str
    assert type(native_jinja_unsafe_text) == NativeJinjaUnsafeText

# Generated at 2022-06-23 14:43:03.170055
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import u
    x = u('text')
    assert x is UnsafeProxy(x)
    x = ['item1', 'item2']
    assert x == UnsafeProxy(x)
    x = {'key1': 'value1', 'key2': 'value2'}
    assert x == UnsafeProxy(x)

    x = AnsibleUnsafeText(u('text'))
    assert x is UnsafeProxy(x)
    x = AnsibleUnsafeText(u('value2'))
    assert x is UnsafeProxy(x)
    x = AnsibleUnsafeBytes(b'item1')
    assert x is UnsafeProxy(x)
    x = AnsibleUnsafeBytes(b'value2')
    assert x is UnsafeProxy(x)

# Generated at 2022-06-23 14:43:07.812595
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy('pw1'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'pw2'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(u'pw3'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:43:10.464952
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    instance = AnsibleUnsafeBytes(b"test_AnsibleUnsafeBytes_decode")
    assert isinstance(instance.decode("ascii"), AnsibleUnsafeText)



# Generated at 2022-06-23 14:43:22.035782
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    original = "this is a test"
    u = UnsafeProxy(original)
    assert(u == original)
    assert(isinstance(u, AnsibleUnsafeText))
    u = UnsafeProxy(original.decode("utf-8"))
    assert(u == original.decode("utf-8"))
    assert(isinstance(u, AnsibleUnsafeText))

    assert(isinstance(UnsafeProxy(None), type(None)))
    assert(isinstance(UnsafeProxy(True), type(True)))
    assert(isinstance(UnsafeProxy(False), type(False)))
    assert(isinstance(UnsafeProxy(123), type(123)))
    assert(isinstance(UnsafeProxy(123.456), type(123.456)))
    assert(isinstance(UnsafeProxy([1, 2, 3]), list))
   

# Generated at 2022-06-23 14:43:30.522516
# Unit test for function wrap_var
def test_wrap_var():
    import json
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.collections import is_sequence

    # Test wrap_var for primitive types
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(10), type(10))
    assert isinstance(wrap_var(10.0), type(10.0))

    # Test wrap_var for data types which should be wrapped

# Generated at 2022-06-23 14:43:34.639752
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    text = AnsibleUnsafeText(u'This is AnsibleUnsafeText')
    # text.encode('utf-8')
    # AnsibleUnsafeBytes(b'This is AnsibleUnsafeText')


# Generated at 2022-06-23 14:43:42.918421
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.unsafe_proxy import to_unsafe_bytes, is_unsafe
    assert is_unsafe(to_unsafe_bytes('test'))
    assert is_unsafe(to_unsafe_bytes(u'test'))
    assert is_unsafe(to_unsafe_bytes(u'test'.encode('utf-8')))
    assert not is_unsafe(to_bytes('test'))

# Generated at 2022-06-23 14:43:54.429817
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six.moves import StringIO

    # Test for unicode string
    im_dict = ImmutableDict({'1': b'2'})
    assert isinstance(im_dict, Mapping) is True
    assert isinstance(im_dict['1'], text_type) is False
    assert isinstance(im_dict['1'], AnsibleUnsafe) is False

    im_dict = wrap_var(im_dict)
    assert isinstance(im_dict, Mapping) is True
    assert isinstance(im_dict['1'], text_type) is True
    assert isinstance(im_dict['1'], AnsibleUnsafe) is True

    # Test for bytestring
    im_dict = Imm

# Generated at 2022-06-23 14:43:56.057063
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    test_obj = NativeJinjaUnsafeText('test')
    assert test_obj == 'test'


# Generated at 2022-06-23 14:43:59.302380
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():

    # AnsibleUnsafe class doesn't do anything except tag the object as unsafe
    class MyClass(AnsibleUnsafe):
        pass

    assert MyClass('foo') is not None



# Generated at 2022-06-23 14:44:02.125366
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(b"test"), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u"test"), AnsibleUnsafeText)

# Generated at 2022-06-23 14:44:06.670129
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    class UnitTestText(AnsibleUnsafeText):
        def encode(self, *args, **kwargs):
            return super(UnitTestText, self).encode(*args, **kwargs)

    assert UnitTestText('ansible_test').encode('utf-8') == AnsibleUnsafeBytes('ansible_test')



# Generated at 2022-06-23 14:44:09.485963
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # Constructor should set "__UNSAFE__" property to True
    assert AnsibleUnsafeText('foo').__UNSAFE__ is True
    assert AnsibleUnsafeText('foo').__class__.__UNSAFE__ is True

# Generated at 2022-06-23 14:44:12.156635
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    uobj = to_unsafe_bytes("123")
    assert isinstance(uobj, binary_type)
    assert uobj.__class__.__name__ == 'AnsibleUnsafeBytes'
    assert uobj.__class__.__UNSAFE__ is True



# Generated at 2022-06-23 14:44:16.061915
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    unsafe_bytes = AnsibleUnsafeBytes("yaml is easy".encode("utf-8"))
    unsafe_text = unsafe_bytes.decode("utf-8")

    assert(unsafe_bytes.__UNSAFE__ == unsafe_text.__UNSAFE__)


# Generated at 2022-06-23 14:44:24.601989
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    b_str = b"abc"
    u_str = u"abc"
    u_str_wrap = wrap_var(u"abc")
    assert isinstance(u_str_wrap, AnsibleUnsafeText), "Input is of form u'xxx'"
    assert isinstance(UnsafeProxy(u_str), AnsibleUnsafeText), "Input is of form u'xxx'"
    assert UnsafeProxy(u_str_wrap) == u_str_wrap, "Input is of form u'xxx'"
    return True


# Generated at 2022-06-23 14:44:29.660175
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert not AnsibleUnsafe().__UNSAFE__

    assert AnsibleUnsafeText('foo').__UNSAFE__
    assert AnsibleUnsafeText('foo').encode().__UNSAFE__
    assert AnsibleUnsafeText('foo').encode().decode().__UNSAFE__

# Generated at 2022-06-23 14:44:35.872108
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    test_string = u"This is a simple string"
    test_string_bytes = b"This is a simple string"
    test_string_bytes_unsafe = to_unsafe_bytes(test_string)
    assert isinstance(test_string_bytes_unsafe, AnsibleUnsafeBytes)
    assert test_string_bytes_unsafe == test_string_bytes
    assert isinstance(test_string_bytes_unsafe.decode(errors="surrogate_or_strict"), AnsibleUnsafeText)



# Generated at 2022-06-23 14:44:41.611871
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('a'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'a'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'a', encoding='utf-8'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_bytes(b'a', errors='strict'), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:44:52.117469
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text

    assert isinstance(to_unsafe_bytes(b"foo"), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u"foo"), AnsibleUnsafeBytes)

    if PY3:
        assert type(to_text(b"foo")) == str
    else:
        assert type(to_text(b"foo")) == unicode
    assert type(to_unsafe_text(b"foo")) == NativeJinjaUnsafeText

    assert isinstance(to_unsafe_bytes(b"foo", encoding='utf-16'), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:44:53.513656
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    ans=AnsibleUnsafeText("a")
    assert ans.__UNSAFE__ == True


# Generated at 2022-06-23 14:45:02.489477
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    short_bytes = b'string'
    short_text = u'string'
    long_bytes = b'string' * 1000
    long_text = u'string' * 1000
    not_safe_bytes = AnsibleUnsafeBytes(short_bytes)
    not_safe_text = AnsibleUnsafeText(short_text)

    assert isinstance(to_unsafe_bytes(short_bytes), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(short_text), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(long_bytes), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(long_text), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(not_safe_bytes), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:45:12.646233
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six.moves.builtins import unicode
    s = b"hello world!"
    assert isinstance(UnsafeProxy(s), unicode)
    assert isinstance(UnsafeProxy(s), AnsibleUnsafeText)
    assert UnsafeProxy(s) == u"hello world!"

    s = u"hello world!"
    assert isinstance(UnsafeProxy(s), unicode)
    assert isinstance(UnsafeProxy(s), AnsibleUnsafeText)
    assert UnsafeProxy(s) == u"hello world!"

    s = b"\xe3\x81\x82"
    assert isinstance(UnsafeProxy(s), unicode)
    assert isinstance(UnsafeProxy(s), AnsibleUnsafeText)
    assert UnsafeProxy(s) == u"\u3042"

# Generated at 2022-06-23 14:45:14.990654
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # Test of instance
    object = AnsibleUnsafe()
    assert(isinstance(object, AnsibleUnsafe))


# Generated at 2022-06-23 14:45:27.171364
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    # This tests that we can create a NativeJinjaUnsafeText object with Unicode characters.
    s = NativeJinjaUnsafeText(u'\u0041\u0072\u0065\u0020\u0079\u006f\u0075\u0020\u0072\u006f\u0063\u006b\u0073\u0073\u0061\u0072\u0020\u0065\u006e\u0074\u0068\u0075\u0073\u0069\u0061\u0073\u0074\u0073\u003f')
    assert isinstance(s, NativeJinjaUnsafeText)

# Generated at 2022-06-23 14:45:30.607699
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b"").decode('utf-8', errors='strict'), text_type)
    assert isinstance(AnsibleUnsafeBytes(b"").decode('utf-8', errors='strict'), AnsibleUnsafeText)


# Generated at 2022-06-23 14:45:33.272852
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # create object
    a = AnsibleUnsafe()
    # check object
    assert a.__dict__ == {}
    assert a.__UNSAFE__ is True


# Generated at 2022-06-23 14:45:43.782874
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    name = "Fred"
    jinja_text_safe = NativeJinjaText(u"Hi there {{name}}")
    jinja_text_unsafe = NativeJinjaUnsafeText(u"Hi there {{name}}")

    assert_true(type(jinja_text_safe) is NativeJinjaText)
    assert_true(type(jinja_text_unsafe) is NativeJinjaUnsafeText)

    if hasattr(jinja_text_safe, '__UNSAFE__'):
        assert_true(jinja_text_safe.__UNSAFE__ is False)
    else:
        assert_true(False)

    assert_true(jinja_text_unsafe.__UNSAFE__ is True)


# Generated at 2022-06-23 14:45:52.767952
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    class Test():
        def __init__(self):
            self.foo = 1
            self.bar = 2
            self.baz = 3
            self.blah = {'blah': 'blah'}

    answer = [type(AnsibleUnsafeBytes(b'this is a test')), AnsibleUnsafeBytes(b'this is a test')]
    result = [type(AnsibleUnsafeBytes(b"this is a test")), AnsibleUnsafeBytes(b"this is a test")]
    assert answer == result, "should return ['this is a test', 1, 2, 3, {'blah': 'blah'}] but returned '%s'" % result



# Generated at 2022-06-23 14:46:00.480627
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    str = 'myValue'
    assert type(UnsafeProxy(str)) is type(str)
    assert to_text(UnsafeProxy(str)) == str

    bstr = b'myValue'
    assert type(UnsafeProxy(bstr)) is type(bstr)
    assert to_bytes(UnsafeProxy(bstr)) == bstr

    assert type(UnsafeProxy(UnsafeProxy(str))) is type(str)



# Generated at 2022-06-23 14:46:02.680889
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe()
    assert AnsibleUnsafeBytes(b"Test")
    assert AnsibleUnsafeText(u"Test")


# Generated at 2022-06-23 14:46:06.225988
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    njut = NativeJinjaUnsafeText('test')
    assert njut.__class__.__name__ == 'NativeJinjaUnsafeText'

# Generated at 2022-06-23 14:46:13.788642
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes(123) == b'123'
    assert to_unsafe_bytes('123') == b'123'
    assert to_unsafe_bytes(u'123') == b'123'
    assert to_unsafe_bytes(123, u'utf-8') == b'123'
    assert to_unsafe_bytes('123', u'utf-8') == b'123'
    assert to_unsafe_bytes(u'123', u'utf-8') == b'123'


# Generated at 2022-06-23 14:46:16.986716
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    s = NativeJinjaUnsafeText('Hello')
    assert(isinstance(s, NativeJinjaUnsafeText))
    assert(isinstance(s, AnsibleUnsafeText))


# Generated at 2022-06-23 14:46:19.236513
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    obj = NativeJinjaUnsafeText('Jinja text')
    print(obj)
    print(obj.__class__)

# Generated at 2022-06-23 14:46:26.436365
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    u_bytes = b"\xce\xbb\xe1\xbd\xb9\xcf\x83\xce\xbc\xce\xb5" # lambda + omega =  λωμε
    a_unsafe_bytes = AnsibleUnsafeBytes(u_bytes)
    a_text = a_unsafe_bytes.decode("utf-8")
    assert isinstance(a_text, AnsibleUnsafeText)
    assert a_text == "λωμε"



# Generated at 2022-06-23 14:46:28.510853
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert AnsibleUnsafeBytes(b'foo').decode() == u'foo'

# Generated at 2022-06-23 14:46:36.246739
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes('foo'.encode('utf-8')), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(dict(foo='bar')), dict)
    assert isinstance(to_unsafe_bytes(dict(foo='bar')).get('foo'), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:46:40.001639
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    # Check default behavior
    assert (to_unsafe_bytes('+') == b'+')
    # Check that wrap_var does not wrap the result
    assert (to_unsafe_bytes('+', errors='surrogate_or_strict') == b'+')

# Generated at 2022-06-23 14:46:43.525184
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # Arrange
    aub = AnsibleUnsafeBytes(b'aa')

    # Act
    res = aub.decode()

    # Assert
    assert res == AnsibleUnsafeText('aa')



# Generated at 2022-06-23 14:46:47.325823
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # Test instantiating class AnsibleUnsafeText with empty string
    assert AnsibleUnsafeText("") == ""
    # Test instantiating class AnsibleUnsafeText with non-empty string
    assert AnsibleUnsafeText("Hello!") == "Hello!"

test_AnsibleUnsafeText()

# Generated at 2022-06-23 14:46:49.927138
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert isinstance(to_unsafe_text(b'foo'), AnsibleUnsafeText)


# Generated at 2022-06-23 14:47:01.954904
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(u'foo'.encode('utf-8')) == u'foo'
    assert isinstance(wrap_var(u'foo'.encode('utf-8')), AnsibleUnsafeText)
    assert wrap_var(u'\x00') == u'\x00'
    assert isinstance(wrap_var(u'\x00'.encode('utf-8')), AnsibleUnsafeText)
    assert wrap_var([1, 2, 3]) == [1, 2, 3]
    assert wrap_var((1, 2, 3)) == (1, 2, 3)

# Generated at 2022-06-23 14:47:13.056357
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common.collections import is_sequence

    # Test wrap_var for collections
    test_list = _wrap_sequence([1, 2, 3])
    assert(is_sequence(test_list))
    assert(isinstance(test_list, list))

    test_dict = _wrap_dict({'a': 1, 'b': 2})
    assert(isinstance(test_dict, dict))
    assert(isinstance(test_dict['a'], AnsibleUnsafe))

    test_set = _wrap_set({'a', 'b', 'c'})
    assert(isinstance(test_set, Set))

    # Test wrap_var for strings and objects
    test_text = wrap_var('test text')

# Generated at 2022-06-23 14:47:14.504849
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('test'), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:47:26.674860
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    import types
    from ansible.module_utils.common.collections import is_sequence

    # Make sure that input strings are converted to the proper context
    assert isinstance(wrap_var(b"foo"), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u"foo"), AnsibleUnsafeText)

    # Make sure that all elements of Mapping types are converted to the proper
    # context
    assert isinstance(wrap_var({"foo": {"bar": "baz"}}), dict)
    assert isinstance(wrap_var({"foo": {"bar": "baz"}})["foo"], dict)
    assert isinstance(wrap_var({"foo": {"bar": "baz"}})["foo"]["bar"], AnsibleUnsafeText)
   

# Generated at 2022-06-23 14:47:31.834797
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy is not AnsibleUnsafe
    assert UnsafeProxy('foo') == 'foo'
    assert isinstance(UnsafeProxy('foo'), AnsibleUnsafeText)
    assert UnsafeProxy('foo') is not 'foo'

    # Check that this is no-op
    val = wrap_var('foo')
    assert UnsafeProxy(val) == val

# Generated at 2022-06-23 14:47:33.709311
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    unsafe = AnsibleUnsafe()
    assert unsafe.__UNSAFE__ is True


# Generated at 2022-06-23 14:47:44.944761
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(u"foo") == u"foo"
    assert to_unsafe_text(u"foo", encoding="utf-8") == u"foo"
    assert isinstance(to_unsafe_text(u"foo", errors="strict"), unicode)
    assert isinstance(to_unsafe_text(u"foo", errors="strict"), unicode)
    assert isinstance(to_unsafe_text(u"foo", encoding="ascii", errors="strict"), unicode)
    assert isinstance(to_unsafe_text(u"foo".encode("utf-8"), errors="strict"), unicode)
    assert isinstance(to_unsafe_text(u"foo".encode("utf-8"), encoding="utf-8", errors="strict"), unicode)

# Generated at 2022-06-23 14:47:47.638092
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    obj = NativeJinjaUnsafeText('abc')
    assert len(obj) == 3
    assert str(obj) == 'abc'

# Generated at 2022-06-23 14:47:49.312552
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    s = AnsibleUnsafeText('foo')
    s.encode()
    return True

# Generated at 2022-06-23 14:47:52.024268
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():

    assert(isinstance(to_unsafe_bytes('test'), AnsibleUnsafeBytes))
    assert(to_unsafe_bytes('test') == b'test')

# Generated at 2022-06-23 14:48:01.592347
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    # Test with instances of built-in types
    test_obj_list = [
        0, 1.0, 100,
        0xAF1F, 0b10001,
        's', b'b',
        tuple(), list(), set()
    ]
    correct_class_list = [
        int, float, int,
        int, int,
        AnsibleUnsafeText, AnsibleUnsafeBytes,
        tuple, list, set
    ]
    for test_obj, correct_class in zip(test_obj_list, correct_class_list):
        assert isinstance(UnsafeProxy(test_obj), correct_class)



# Generated at 2022-06-23 14:48:06.985688
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text({'k': 'v'}) == {'k': 'v'}
    assert isinstance(to_unsafe_text({'k': 'v'}), dict)
    assert to_unsafe_text('s') == 's'
    assert isinstance(to_unsafe_text('s'), text_type)