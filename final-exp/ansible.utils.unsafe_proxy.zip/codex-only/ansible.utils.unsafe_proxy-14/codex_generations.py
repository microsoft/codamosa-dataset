

# Generated at 2022-06-23 14:38:07.212122
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    result = UnsafeProxy('test')
    assert(result)



# Generated at 2022-06-23 14:38:14.639102
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import PY3

    try:
        d = UnsafeProxy('hello')
        if not PY3:
            assert isinstance(d, AnsibleUnsafeText)
        else:
            assert isinstance(d, AnsibleUnsafeBytes)
    except Exception as e:
        print('Error: %s' % e)
        raise


# Unit tests for constructor of class NativeJinjaUnsafeText

# Generated at 2022-06-23 14:38:16.340961
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert AnsibleUnsafeBytes('hi').decode('ASCII') == 'hi'



# Generated at 2022-06-23 14:38:20.303225
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # Arrange
    unsafe_text = AnsibleUnsafeText('foo')
    expected_object = AnsibleUnsafeBytes(unsafe_text.encode())

    # Act
    actual_object = unsafe_text.encode()

    # Assert
    assert type(actual_object) == type(expected_object)
    assert actual_object == expected_object


# Generated at 2022-06-23 14:38:23.571937
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    jinja_text = NativeJinjaUnsafeText("NativeJinjaUnsafeText Test")
    assert jinja_text == "NativeJinjaUnsafeText Test"


# Generated at 2022-06-23 14:38:34.243942
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # GIVEN: Method __new__ of class UnsafeProxy
    #  AND: Value to proxy is a string
    string_val = 'test_value'

    # WHEN: Method __new__ of class UnsafeProxy is called with parameter string_val
    _ = UnsafeProxy(string_val)

    # THEN: The returned value is an instance of AnsibleUnsafeText
    assert isinstance(UnsafeProxy(string_val), AnsibleUnsafeText)

    # GIVEN: Method __new__ of class UnsafeProxy
    #  AND: Value to proxy is an AnsibleUnsafeText
    unsafe_text_val = AnsibleUnsafeText('test_value')

    # WHEN: Method __new__ of class UnsafeProxy is called with parameter unsafe_text_val
    _ = UnsafeProxy(unsafe_text_val)

    #

# Generated at 2022-06-23 14:38:41.194610
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    test_unsafe_text = AnsibleUnsafeText("test unsafe text")
    assert test_unsafe_text == "test unsafe text"
    assert test_unsafe_text.__UNSAFE__ == True

    test_unsafe_bytes = AnsibleUnsafeBytes(b"test unsafe bytes")
    assert test_unsafe_bytes == b"test unsafe bytes"
    assert test_unsafe_bytes.__UNSAFE__ == True


# Generated at 2022-06-23 14:38:49.240898
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY2, text_type, binary_type
    from ansible.module_utils.common._collections_compat import OrderedDict

    # Test results if we convert a ``text_type`` bytestring
    assert isinstance(to_unsafe_bytes('text'), AnsibleUnsafeBytes)

    # Test results if we convert a ``binary_type`` bytestring
    assert isinstance(to_unsafe_bytes(b'binary'), AnsibleUnsafeBytes)

    # Check the results of use encoding of the the above string
    assert isinstance(to_unsafe_bytes(b'binary', encoding='utf-8'), AnsibleUnsafeText)

    # Check the results of use encoding of the the above string

# Generated at 2022-06-23 14:38:54.641697
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    # Test unsafe strings
    unsafe_str_in = 'unsafe'
    unsafe_unproxied = AnsibleUnsafeText(unsafe_str_in)
    unsafe_proxied = UnsafeProxy(unsafe_str_in)
    assert(unsafe_unproxied == unsafe_proxied)

    # Test safe strings
    safe_str = "safe"
    safe_unproxied = safe_str
    safe_proxied = UnsafeProxy(safe_str)
    assert(safe_unproxied == safe_proxied)

    # Test safe lists
    safe_list = ["safe_list_item"]
    safe_list_unproxied = safe_list


# Generated at 2022-06-23 14:39:00.082691
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    with open ('./../../lib/ansible/module_utils/basic.py','rb') as f:
        a = f.read()
        f.close()
    u = AnsibleUnsafeText(a.decode('utf-8'))
    v = u.encode('utf-8')

# Generated at 2022-06-23 14:39:07.359134
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.utils import display
    try:
        display.Display()
        b = UnsafeProxy(b'b')
        u = UnsafeProxy(u'u')
        j = UnsafeProxy(NativeJinjaText('n'))
        assert isinstance(b, AnsibleUnsafeBytes)
        assert isinstance(u, AnsibleUnsafeText)
        assert isinstance(j, NativeJinjaUnsafeText)
    finally:
        display.DeprecatedCall.remove_warnings()

# Generated at 2022-06-23 14:39:11.461147
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text('ABC') is 'ABC'
    assert isinstance(to_unsafe_text(b'ABC'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'ABC'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:39:18.189716
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Ensure object returns when obj is instance of AnsibleUnsafe
    obj = AnsibleUnsafeBytes(b'\x01\x02\x03')
    assert obj == UnsafeProxy(obj)

    # Ensure object returns when obj is instance of str
    obj = u"Test String"
    assert obj == UnsafeProxy(obj)

    # Ensure object returns when obj is instance of unicode
    obj = u"Test String"
    assert obj == UnsafeProxy(obj)


# Generated at 2022-06-23 14:39:19.957048
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert isinstance(NativeJinjaUnsafeText("hello world"), NativeJinjaUnsafeText)

# Generated at 2022-06-23 14:39:26.416361
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    """Tests that class NativeJinjaUnsafeText exists as we use it in
    ansible.module_utils.common.dict_transformations.
    The constructor must be tested with a valid string as parameter,
    otherwise it will throw an exception.
    """
    test_string = b'\x80'
    NativeJinjaUnsafeText(test_string)

# Generated at 2022-06-23 14:39:27.362355
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    obj = AnsibleUnsafe()
    assert obj.__UNSAFE__ == True

# Generated at 2022-06-23 14:39:38.153458
# Unit test for function wrap_var
def test_wrap_var():
    expected_result = dict(
        dict1=dict(
            dict2=dict(
                dict3=dict(
                    int1=42,
                    int2=65,
                    int3=30,
                    list1=['Hello World', ],
                    tuple1=('Hello World', )
                )
            )
        )
    )

    input_data = dict(
        dict1=dict(
            dict2=dict(
                dict3=dict(
                    int1=42,
                    int2=65,
                    int3=30,
                    list1=['Hello World', ],
                    tuple1=('Hello World', )
                )
            )
        )
    )

    actual_result = wrap_var(input_data)

    assert actual_result == expected_result


# Generated at 2022-06-23 14:39:40.598117
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert type(to_unsafe_text('foo')) == AnsibleUnsafeText



# Generated at 2022-06-23 14:39:44.151718
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    v = AnsibleUnsafeText(u"Testing")
    assert isinstance(v, text_type)
    assert isinstance(v, AnsibleUnsafe)



# Generated at 2022-06-23 14:39:45.444461
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe()


# Generated at 2022-06-23 14:39:57.172324
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO

    filename = __file__

    module = type('TestModule', (object, ), {})
    module.no_log_values = \
        module.ANSIBLE_MODULE_NO_LOG_VALUES = frozenset(('Password', 'secret'))
    module.AnsibleUnsafeBytes = AnsibleUnsafeBytes
    module.AnsibleUnsafeText = AnsibleUnsafeText
    module.AnsibleUnsafe = AnsibleUnsafe
    module.wrap_var = wrap_var
    module.to_bytes = to_bytes
    module.to_text = to_text
    module.StringIO = StringIO

# Generated at 2022-06-23 14:40:08.988123
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    string_test_cases = ['UnsafeProxy', 'SafeProxy', '', 'test', 'This is a test!!']
    dict_test_cases = [{}, {'test': 'UnsafeProxy', 'safe': 'SafeProxy'}, {'UnsafeProxy': {'UnsafeProxy': 'UnsafeProxy'}, 'SafeProxy': {'UnsafeProxy': 'UnsafeProxy'}}]
    tuple_test_cases = [(), (1,), (1, 2, 3), (1, '2', 3), ((1,),), ((1,), (2,), (3,))]
    set_test_cases = [set(), {1, 2, 3}, {1, 'a', 'b', 'c'}]

# Generated at 2022-06-23 14:40:20.884812
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    class A(object): pass
    a = A()
    a.__str__ = lambda *args, **kwargs: 'foo'

    assert to_unsafe_bytes('foo') == AnsibleUnsafeBytes(b'foo')
    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeBytes)
    assert to_unsafe_bytes(None) is None
    assert to_unsafe_bytes(a) == AnsibleUnsafeBytes(b'foo')
    assert to_unsafe_bytes('1') == AnsibleUnsafeBytes(b'1')
    assert to_unsafe_bytes(1) == AnsibleUnsafeBytes(b'1')
    assert to_unsafe_bytes(True) == AnsibleUnsafeBytes(b'True')



# Generated at 2022-06-23 14:40:23.340449
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(b"a") == 'a'
    assert isinstance(to_unsafe_text(b"a"), AnsibleUnsafeText)

# Generated at 2022-06-23 14:40:25.118858
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert isinstance(AnsibleUnsafeText(u'foo'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:40:31.930800
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes("asdf"), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes("asdf", encoding='utf-8'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes("asdf", errors='surrogate_or_strict'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes("asdf", errors='ignore'), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:40:41.910210
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy('str') == u'str'
    assert UnsafeProxy('str').__UNSAFE__ == True
    assert UnsafeProxy(u'str') == u'str'
    assert UnsafeProxy(u'str').__UNSAFE__ == True
    assert UnsafeProxy(u'str') == u'str'
    assert UnsafeProxy(u'str').__UNSAFE__ == True
    assert UnsafeProxy(b'str') == 'str'
    assert UnsafeProxy(b'str').__UNSAFE__ == True
    assert UnsafeProxy(b'str').decode() == 'str'
    assert UnsafeProxy(b'str').decode().__UNSAFE__ == True

    my_int = 4
    assert UnsafeProxy(my_int) == 4

# Generated at 2022-06-23 14:40:47.030635
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes(u'\u2019') == b"'"
    assert to_unsafe_bytes(u'\u2028') == b'\xe2\x80\xa8'
    assert b'\xe2\x80\xa8' in to_unsafe_bytes(u'\u2028')



# Generated at 2022-06-23 14:40:51.958656
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    from ansible.module_utils.six import u

    my_UnsafeText = AnsibleUnsafeBytes(u("this is a test"))
    encoding = 'ascii'
    print(my_UnsafeText.encode(encoding))
    assert(
        my_UnsafeText.encode('ascii') == b'this is a test'
        )


# Generated at 2022-06-23 14:40:52.921963
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    return UnsafeProxy("test string")

# Generated at 2022-06-23 14:41:01.320407
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.six import text_type
    from ansible.module_utils.common.collections import is_sequence
    assert isinstance(to_unsafe_text('...'), text_type)
    assert isinstance(to_unsafe_text(b'...'), text_type)
    assert isinstance(to_unsafe_text(u'...'), text_type)
    assert isinstance(to_unsafe_text(42), text_type)
    assert isinstance(to_unsafe_text(42.5), text_type)
    assert isinstance(to_unsafe_text(None), text_type)

    assert is_sequence(to_unsafe_text(['a', 1, None]))
    assert is_sequence(to_unsafe_text(('a', 1, None)))

# Generated at 2022-06-23 14:41:12.003103
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import string_types, binary_type
    data = {
        'hello': 'world',
        'ansible': b'rocks',
        'foo': {
            'bar': b'foobar',
            'baz': b'foobaz',
            'zoo': {
                'hello': b'world'
            }
        }
    }

    def assert_wrapper(data, wrapper):
        for key, value in data.items():
            if isinstance(value, string_types):
                assert wrapper[key] == value
            elif isinstance(value, binary_type):
                assert isinstance(wrapper[key], AnsibleUnsafeBytes)
                assert wrapper[key] == value
            elif isinstance(value, dict):
                assert isinstance(wrapper[key], dict)

# Generated at 2022-06-23 14:41:23.906952
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.unsafe_proxy import wrap_var

    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var('\n'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'\n'), AnsibleUnsafeText)
    assert isinstance(wrap_var(str('\n')), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'\n'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(1), int)

    assert isinstance(wrap_var([]), list)
    assert isinstance(wrap_var([1, 2]), list)
    assert isinstance(wrap_var([1, '2']), list)
    assert isinstance(wrap_var(['1', '2']), list)

# Generated at 2022-06-23 14:41:35.682806
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.common.collections import is_sequence

    # Unit tests for function to_unsafe_bytes
    # Test case 1: path is a text_type object, version is a text_type object, default is False
    path = u"path/\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0A\x0B\x0C\x0D\x0E\x0F\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1A\x1B\x1C\x1D\x1E\x1F"

# Generated at 2022-06-23 14:41:40.205790
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    if not isinstance(AnsibleUnsafeText(u'This is a test').encode('utf-8'), AnsibleUnsafeBytes):
        raise AssertionError('Encode method of AnsibleUnsafeText does not return AnsibleUnsafeBytes!')

    # If encode method of AnsibleUnsafeText was called properly, the test will pass.

# Generated at 2022-06-23 14:41:52.348958
# Unit test for function wrap_var
def test_wrap_var():
    '''
    This function tests the wrap_var function for tuple and dict input where
    the tuple/dict contains string.
    '''
    assert wrap_var((b'test',)) == (to_unsafe_bytes('test'), )
    assert wrap_var((b"test",b"test1")) == (to_unsafe_bytes('test'), to_unsafe_bytes('test1'))
    assert wrap_var({b'test':b'test1'}) == {to_unsafe_bytes('test'):to_unsafe_bytes('test1')}

# Generated at 2022-06-23 14:42:00.363266
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # Check that AnsibleUnsafeBytes is subclass of AnsibleUnsafe
    assert issubclass(AnsibleUnsafeBytes, AnsibleUnsafe)
    assert issubclass(AnsibleUnsafeText, AnsibleUnsafe)
    assert issubclass(NativeJinjaUnsafeText, AnsibleUnsafe)

    # Check that decode returns a AnsibleUnsafeText without altering its value
    test_str = "unicode_str"
    unsafe_bytes = AnsibleUnsafeBytes(test_str).encode('utf-8')
    assert unsafe_bytes.decode('utf-8') == to_unsafe_text(test_str)



# Generated at 2022-06-23 14:42:03.435309
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    unsafe_proxy = UnsafeProxy("abc")
    assert isinstance(unsafe_proxy, UnsafeProxy)

# Generated at 2022-06-23 14:42:07.165030
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    ansi_u_t = AnsibleUnsafeText(to_text('test_AnsibleUnsafeText_encode'))

    assert isinstance(ansi_u_t.encode(to_text('ascii')), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:42:17.862761
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_sequence

    assert wrap_var('test') == AnsibleUnsafeText('test')
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)
    assert wrap_var(b'test') == AnsibleUnsafeBytes(b'test')
    assert isinstance(wrap_var(b'test'), AnsibleUnsafeBytes)
    assert wrap_var(None) is None
    assert wrap_var(list(range(10))) == AnsibleUnsafeText('[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]')
    assert isinstance(wrap_var(list(range(10))), list)

# Generated at 2022-06-23 14:42:28.462842
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(u'foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text('foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(None), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'foo', errors='surrogate_or_strict'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text('foo', errors='surrogate_or_strict'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(None, errors='surrogate_or_strict'), AnsibleUnsafeText)



# Generated at 2022-06-23 14:42:34.971706
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(b'\x80\xff', errors='surrogate_or_strict'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_text(b'\x80\xff', encoding='utf-8', errors='surrogate_or_strict'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'\x80\xff', encoding='ascii', errors='surrogate_or_strict'), AnsibleUnsafeText)



# Generated at 2022-06-23 14:42:45.041089
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    class MyClass:
        def __init__(self, val=1):
            self.value = val

    assert isinstance(UnsafeProxy(1), int)
    assert isinstance(UnsafeProxy("a"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy({'a':1}), dict)
    assert isinstance(UnsafeProxy(b'a'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(u'a'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy([1]), list)
    assert isinstance(UnsafeProxy((1,)), tuple)
    assert isinstance(UnsafeProxy({1}), set)
    assert isinstance(UnsafeProxy(MyClass()), MyClass)

# Generated at 2022-06-23 14:42:55.878305
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six.moves import UserDict
    import collections
    import types

    assert wrap_var('foo') == 'foo'
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var({'a': 'b'}), dict)
    assert isinstance(wrap_var(UserDict({'a': 'b'})), UserDict)
    assert isinstance(wrap_var(collections.OrderedDict({'a': 'b'})), collections.OrderedDict)
    assert isinstance(wrap_var({'a': 'b'}.items()), list)

# Generated at 2022-06-23 14:43:00.516491
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    from ansible.module_utils.common.text.converters import to_bytes
    teststring = to_bytes('foooo')
    result = AnsibleUnsafeBytes.decode(teststring)
    assert teststring == result.encode()


# Generated at 2022-06-23 14:43:11.144879
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vault import VaultLib
    b_unsafe = b'unsafe'
    u_unsafe = u'unsafe'

# Generated at 2022-06-23 14:43:15.288039
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    import types

    o = {'a':'a', 'b':'b'}
    assert isinstance(UnsafeProxy(o), types.DictType)
    assert isinstance(UnsafeProxy(o), UnsafeProxy)

# Generated at 2022-06-23 14:43:17.691628
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    try:
        NativeJinjaUnsafeText()
    except:
        print("test_NativeJinjaUnsafeText:Fail")

# Generated at 2022-06-23 14:43:27.227069
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.display import Display
    from ansible.module_utils.six import PY3

    display = Display()
    v = 'ansible'
    # Validate that __new__ doesn't return a new object, ansible a singleton
    assert UnsafeProxy(v) is UnsafeProxy(v)

    # Given unicode, __new__ should return AnsibleUnsafeText
    assert isinstance(UnsafeProxy(v), AnsibleUnsafeText)

    # Ensure that native string class is not wrapped
    if PY3:
        assert type(UnsafeProxy(v)) is text_type
    else:
        assert type(UnsafeProxy(v)) is unicode

    # Given bytes, __new__ should return AnsibleUnsafeBytes

# Generated at 2022-06-23 14:43:31.208355
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    txt = NativeJinjaUnsafeText(to_unsafe_text("test"))
    # If the above line has no error, it means the constructor of NativeJinjaUnsafeText has no error
    if txt.__class__ == NativeJinjaUnsafeText:
        print("NativeJinjaUnsafeText constructor is OK!")
    else:
        print("NativeJinjaUnsafeText constructor is NG!")

# Generated at 2022-06-23 14:43:43.436460
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from pytest import raises
    s = "foo"
    u = UnsafeProxy(s)
    assert type(u) is AnsibleUnsafeText
    assert u.__UNSAFE__
    assert u.__class__ == AnsibleUnsafeText
    assert isinstance(u, AnsibleUnsafeBytes) == False
    assert u == u"foo"

    with raises(AttributeError):
        u.__dict__

    assert isinstance(u, UnsafeProxy)
    assert isinstance(u, AnsibleUnsafeText)
    assert isinstance(u, (AnsibleUnsafeText, AnsibleUnsafeBytes))
    assert isinstance(u, object)
    assert isinstance(u, (AnsibleUnsafeText, object, AnsibleUnsafeBytes))


# Generated at 2022-06-23 14:43:45.299045
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafeBytes('test')
    assert AnsibleUnsafeText('test')

# Generated at 2022-06-23 14:43:56.240533
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # test class attribute __UNSAFE__
    assert isinstance(UnsafeProxy("").__UNSAFE__, bool)
    assert UnsafeProxy("").__UNSAFE__ == True

    # test method __new__
    assert isinstance(UnsafeProxy(""), UnsafeProxy)
    assert isinstance(UnsafeProxy(""), AnsibleUnsafeText)

    assert isinstance(UnsafeProxy("pytest"), UnsafeProxy)
    assert isinstance(UnsafeProxy("pytest"), AnsibleUnsafeText)

    assert isinstance(UnsafeProxy(u"pytest"), UnsafeProxy)
    assert isinstance(UnsafeProxy(u"pytest"), AnsibleUnsafeText)

    # test method decode
    assert UnsafeProxy("pytest").decode() == "pytest"
    assert UnsafeProxy(b"pytest").decode()

# Generated at 2022-06-23 14:44:01.338052
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    s = AnsibleUnsafeBytes("hello".encode("utf-8"))
    assert isinstance(s, AnsibleUnsafeBytes)
    assert isinstance(s, binary_type)
    assert isinstance(s, AnsibleUnsafe)
    assert isinstance(s.decode("utf-8"), AnsibleUnsafeText)


# Generated at 2022-06-23 14:44:04.755519
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy("ABC"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b"ABC"), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(u"ABC"), AnsibleUnsafeText)



# Generated at 2022-06-23 14:44:12.110768
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.six import PY3
    if PY3:
        from io import StringIO
        import sys
        from contextlib import contextmanager

        @contextmanager
        def captured_output():
            new_out, new_err = StringIO(), StringIO()
            old_out, old_err = sys.stdout, sys.stderr
            try:
                sys.stdout, sys.stderr = new_out, new_err
                yield sys.stdout, sys.stderr
            finally:
                sys.stdout, sys.stderr = old_out, old_err

        with captured_output() as (outputs, errors):
            assert not isinstance(UnsafeProxy("foo"), UnsafeProxy)
            assert isinstance(UnsafeProxy("foo"), AnsibleUnsafeText)


# Generated at 2022-06-23 14:44:24.074296
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY3
    if PY3:
        import codecs
        codecs.register(lambda name: codecs.lookup('utf-8') if name == 'cp65001' else None)
        assert b'\xe6\x89\x8e\xe7\x85\xa7' == to_unsafe_bytes(u'\u624e\u7257')
        assert b'\xe6\x89\x8e\xe7\x85\xa7' == to_unsafe_bytes(u'\u624e\u7257').__class__

# Generated at 2022-06-23 14:44:29.712299
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(u'hello'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'hello'.encode('utf-8')), AnsibleUnsafeText)
    assert to_unsafe_text(u'hello') == u'hello'


# Generated at 2022-06-23 14:44:36.915108
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    as_bytes = to_unsafe_bytes(u'hello')
    assert isinstance(as_bytes, AnsibleUnsafeBytes)
    assert isinstance(as_bytes, binary_type)
    assert not isinstance(as_bytes, AnsibleUnsafeText)
    assert not isinstance(as_bytes, text_type)

    as_text = as_bytes.decode('utf-8')
    assert isinstance(as_text, AnsibleUnsafeText)
    assert not isinstance(as_text, AnsibleUnsafeBytes)
    assert isinstance(as_text, text_type)
    assert not isinstance(as_text, binary_type)


# Generated at 2022-06-23 14:44:46.124370
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import u

    assert wrap_var(u('foo')) == u('foo')
    assert wrap_var(u('foo')) == to_unsafe_text(b'foo')
    assert isinstance(wrap_var(u('foo')), AnsibleUnsafe)
    assert wrap_var(None) is None
    assert isinstance(wrap_var({u('key'): u('value')}), dict)
    assert isinstance(wrap_var([u('item')]), list)
    assert isinstance(wrap_var((u('item'),)), tuple)
    assert isinstance(wrap_var({u('item')}), set)
    assert isinstance(wrap_var({u('key'): u('value')}), Mapping)

# Generated at 2022-06-23 14:44:48.170739
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    aus = AnsibleUnsafe()
    assert aus.__class__ == AnsibleUnsafe


# Generated at 2022-06-23 14:44:52.685938
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    test_value1 = 'test-string-value'
    test_value2 = u'test-unicode-value'

    proxy1 = UnsafeProxy(test_value1)
    proxy2 = UnsafeProxy(test_value2.encode('utf-8'))

    assert test_value1 == proxy1
    assert test_value2 == proxy2

# Generated at 2022-06-23 14:45:01.959347
# Unit test for function wrap_var
def test_wrap_var():
    # Enter here any conditions that needs to be tested
    # E.g. wrap_var(string)
    #      wrap_var([list])
    #      wrap_var({dict})
    str_val = "Test string"
    assert isinstance(wrap_var(str_val), AnsibleUnsafeText)

    list_val = ["test string", 123]
    assert isinstance(wrap_var(list_val), list)
    assert isinstance(wrap_var(list_val)[0], AnsibleUnsafeText)
    assert isinstance(wrap_var(list_val)[1], int)


# Generated at 2022-06-23 14:45:05.866273
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # Test with good value
    b1 = AnsibleUnsafeBytes('abcdef')
    s1 = b1.decode()
    assert(type(s1) is AnsibleUnsafeText)
    assert(s1 == 'abcdef')

# Generated at 2022-06-23 14:45:10.358304
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    string = 'abcdefg'
    unsafe_bytes = AnsibleUnsafeBytes(string, 'utf-8')
    decode_unsafe_bytes = unsafe_bytes.decode('utf-8')
    assert unsafe_bytes is decode_unsafe_bytes
    assert isinstance(decode_unsafe_bytes, AnsibleUnsafeText)


# Generated at 2022-06-23 14:45:11.827865
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    text = 'test'
    unsafe_text = AnsibleUnsafeText(text)
    assert unsafe_text == text

# Generated at 2022-06-23 14:45:23.704359
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(UnsafeProxy(AnsibleUnsafeText('hello'))) == 'hello'
    assert wrap_var(UnsafeProxy('hello')) == 'hello'
    assert wrap_var('hello') == 'hello'
    assert wrap_var(AnsibleUnsafeText(u'hello')) == u'hello'
    assert wrap_var(AnsibleUnsafeBytes(b'hello')) == b'hello'

    assert wrap_var(AnsibleUnsafeText(u'hello')) == u'hello'
    assert type(wrap_var(AnsibleUnsafeText(u'hello'))) is text_type

    assert wrap_var(AnsibleUnsafeBytes(b'hello')) == b'hello'
    assert type(wrap_var(AnsibleUnsafeBytes(b'hello'))) is binary

# Generated at 2022-06-23 14:45:26.594077
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert isinstance(AnsibleUnsafeText(u''), AnsibleUnsafe)
    assert isinstance(AnsibleUnsafeBytes(b''), AnsibleUnsafe)



# Generated at 2022-06-23 14:45:33.337080
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.display import Display
    import sys
    import types

    class DummyDisplay:
        def __init__(self):
            self.deprecated_called = False

        def deprecated(self, *args, **kwargs):
            self.deprecated_called = True

    display = DummyDisplay()

    old_display_instance = Display._instance
    Display._instance = display

    # Object is already AnsibleUnsafe
    obj = AnsibleUnsafeText('test')
    assert isinstance(UnsafeProxy(obj), AnsibleUnsafeText)
    assert not display.deprecated_called

    # Object is an instance of string_types
    obj = 'test'
    assert isinstance(UnsafeProxy(obj), AnsibleUnsafeText)
    assert display.deprecated_called

    Display._instance = old_display_

# Generated at 2022-06-23 14:45:42.387539
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    test_str_1 = 'test'
    test_str_2 = u'test'
    test_str_3 = b'test'
    test_str_4 = AnsibleUnsafeText(u'test')
    test_str_5 = AnsibleUnsafeBytes(b'test')

    assert isinstance(test_str_1, string_types)
    assert isinstance(test_str_2, string_types)
    assert isinstance(test_str_3, binary_type)
    assert isinstance(test_str_4, text_type)
    assert isinstance(test_str_5, binary_type)

    assert isinstance(to_unsafe_text(test_str_1), text_type)
    assert isinstance(to_unsafe_text(test_str_2), text_type)

# Generated at 2022-06-23 14:45:44.927356
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # the method __str__() will be implicitly called when print(obj)
    assert repr(AnsibleUnsafeText('abc')) == repr(u'abc')


# Generated at 2022-06-23 14:45:52.617723
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # Case 1 : b'abc' --> b'abc'
    assert AnsibleUnsafeText('abc').encode() == b'abc'

    # Case 2 : b'abc' --> b'abc', encoding='utf-8'
    assert AnsibleUnsafeText('abc').encode('utf-8') == b'abc'

    # Case 3 : b'\xe7\x94\xb5\xe8\xaf\x9d' --> b'\xe7\x94\xb5\xe8\xaf\x9d', encoding='utf-8'
    assert AnsibleUnsafeText('\xe7\x94\xb5\xe8\xaf\x9d').encode('utf-8') == b'\xe7\x94\xb5\xe8\xaf\x9d'


# Generated at 2022-06-23 14:45:58.772318
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.six import PY3, text_type
    if PY3:
        result = to_unsafe_text("foo", encoding='ascii')
        assert isinstance(result, text_type)
        assert len(result) == 3
        assert isinstance(result[0], AnsibleUnsafeText)

# Generated at 2022-06-23 14:46:07.052695
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    ans_unsafe_str_val = AnsibleUnsafeBytes(b'\xe2\x98\x83')
    assert '%s' % ans_unsafe_str_val == repr(ans_unsafe_str_val), "Expected representation without quotes '?' is '%s'" % repr(ans_unsafe_str_val)
    ans_unsafe_str_val = ans_unsafe_str_val.decode(encoding='utf-8')
    assert isinstance(ans_unsafe_str_val, AnsibleUnsafeText), "Expected AnsibleUnsafeText but found %s" % type(ans_unsafe_str_val)
    assert '%s' % ans_unsafe_str_val == '?'
    assert repr(ans_unsafe_str_val) == "'?'"


# Generated at 2022-06-23 14:46:16.174855
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert UnsafeProxy(u"foo") == AnsibleUnsafeText(u"foo")
    assert UnsafeProxy(b"foo") == AnsibleUnsafeBytes(b"foo")
    # compound types
    assert UnsafeProxy(u"foo") == u"foo"
    assert UnsafeProxy(u"foo") == b"foo"
    assert UnsafeProxy(u"foo") == u"foo".encode('utf-8')
    assert UnsafeProxy(u"bar") == {u"foo": u"bar"}
    assert UnsafeProxy(u"baz") == [u"foo", u"bar", {u"foo": u"baz"}]



# Generated at 2022-06-23 14:46:18.484494
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    obj = NativeJinjaUnsafeText('Test')
    assert isinstance(obj, AnsibleUnsafe)


# Generated at 2022-06-23 14:46:19.462467
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe()

# Generated at 2022-06-23 14:46:21.032048
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    test = AnsibleUnsafeText('this is a test')
    assert str(test) == 'this is a test'

# Generated at 2022-06-23 14:46:23.260427
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    u = AnsibleUnsafe()
    if not isinstance(u,AnsibleUnsafe):
        raise Exception("AnsibleUnsafe constructor failed")


# Generated at 2022-06-23 14:46:31.321364
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert type(AnsibleUnsafeText('\xc3\xa9').encode('utf-8').decode('utf-8')) == AnsibleUnsafeText
    assert type(AnsibleUnsafeText('\xc3\xa9').encode('utf-8').decode('utf-8').encode('utf-8')) == AnsibleUnsafeBytes
    assert type(AnsibleUnsafeBytes('\xc3\xa9').decode('utf-8')) == AnsibleUnsafeText
    assert type(AnsibleUnsafeBytes('\xc3\xa9').decode('utf-8').encode('utf-8')) == AnsibleUnsafeBytes
    assert type(UnsafeProxy('\xc3\xa9').encode('utf-8').decode('utf-8')) == AnsibleUnsafeText

# Generated at 2022-06-23 14:46:40.541163
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import binary_type
    assert isinstance(to_bytes(u'TEST', errors='surrogate_or_strict'), binary_type)
    assert isinstance(to_bytes(AnsibleUnsafeText(u'TEST'), errors='surrogate_or_strict'), binary_type)
    assert isinstance(to_bytes(AnsibleUnsafeText(u'TEST').encode('utf-8'), errors='surrogate_or_strict'), binary_type)

# Generated at 2022-06-23 14:46:43.315865
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    ansible_unsafe_text = AnsibleUnsafeText('abc')
    assert isinstance(ansible_unsafe_text.encode(), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:46:45.978876
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    str1 = "ABCDEF"
    str2 = AnsibleUnsafeText(str1)
    assert str2.encode() == str1.encode()


# Generated at 2022-06-23 14:46:55.150762
# Unit test for function wrap_var
def test_wrap_var():
    ''' test_wrap_var
    '''
    from .common import removed_module
    if removed_module('collections'):
        # nothing else to test
        return

    from collections import OrderedDict
    assert isinstance(wrap_var('hello'), AnsibleUnsafeText)
    assert isinstance(wrap_var(10), int)
    assert isinstance(wrap_var(10.1), float)
    assert isinstance(wrap_var(True), bool)
    assert isinstance(wrap_var({'a': 'b'}), OrderedDict)
    assert isinstance(wrap_var(['a', 'b']), tuple)
    assert isinstance(wrap_var(('a', 'b')), tuple)
    assert isinstance(wrap_var(set()), set)

# Generated at 2022-06-23 14:46:58.412407
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText("foo").encode("utf-8"), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:47:00.911932
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    ansible_unsafe = AnsibleUnsafe()
    assert isinstance(ansible_unsafe, AnsibleUnsafe)



# Generated at 2022-06-23 14:47:03.738345
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert AnsibleUnsafeText('test').encode('utf-8') == AnsibleUnsafeBytes(b'test')
    assert AnsibleUnsafeText('test').encode() == AnsibleUnsafeBytes(b'test')

# Generated at 2022-06-23 14:47:07.048561
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    t = AnsibleUnsafeText()
    assert(t == "")

    t1 = AnsibleUnsafeText("123")
    assert(t1 == "123")

# Generated at 2022-06-23 14:47:08.002472
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    ji = NativeJinjaUnsafeText("")

# Generated at 2022-06-23 14:47:13.002276
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    from ansible.module_utils.six import PY3
    if PY3:
        # On Python 3 this is the same as Unicode string
        return
    unsafe_bytes = AnsibleUnsafeBytes("string")
    assert isinstance(unsafe_bytes, text_type)
    assert unsafe_bytes == "string"


# Generated at 2022-06-23 14:47:21.421821
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    # pylint: disable=unused-variable
    safe_bytes = to_unsafe_bytes('\xc2\xad')
    safe_text = to_unsafe_text('\xc2\xad')
    unsafe_bytes = to_unsafe_bytes('a\xc2\xad')
    unsafe_text = to_unsafe_text('a\xc2\xad')
    unsafe_other = to_unsafe_text('a\xc2\xad')
    # pylint: enable=unused-variable



# Generated at 2022-06-23 14:47:23.467590
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    jinjatem = "{{ item }}"
    jinjatem = NativeJinjaUnsafeText(jinjatem)

# Generated at 2022-06-23 14:47:27.156806
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    a = AnsibleUnsafe()
    if hasattr(a, '__UNSAFE__') and a.__UNSAFE__ is True:
        print("Pass")
    else:
        print("Fail")


# Generated at 2022-06-23 14:47:33.265714
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    import sys
    sys.modules['ansible.utils.unsafe_proxy'] = sys.modules[__name__]

    import ansible.template.template as t
    assert isinstance(wrap_var(t.NativeJinjaText('{{ x }}')), NativeJinjaUnsafeText)

    del sys.modules['ansible.utils.unsafe_proxy']
    del sys.modules['ansible.template.template']



# Generated at 2022-06-23 14:47:37.268944
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    obj_1 = UnsafeProxy("hi")
    obj_2 = UnsafeProxy("hi")
    obj_3 = UnsafeProxy("hj")

    # Both object should not be same
    assert obj_1 != obj_2
    assert obj_2 != obj_3



# Generated at 2022-06-23 14:47:48.852343
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafe)
    assert isinstance(to_unsafe_bytes(u'foo'), AnsibleUnsafe)
    assert isinstance(to_unsafe_bytes('foo'.encode('utf-8')), AnsibleUnsafe)
    assert to_unsafe_bytes('foo') == b'foo'
    assert to_unsafe_bytes(u'\u4f60\u597d') == b'\xe4\xbd\xa0\xe5\xa5\xbd'
    assert to_unsafe_bytes('\xe4\xbd\xa0\xe5\xa5\xbd'.decode('utf-8')) == b'\xe4\xbd\xa0\xe5\xa5\xbd'

# Generated at 2022-06-23 14:47:49.936867
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe.__UNSAFE__
    assert type(AnsibleUnsafe()) is AnsibleUnsafe



# Generated at 2022-06-23 14:47:51.438056
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    s = AnsibleUnsafe()
    assert s.__UNSAFE__

# Generated at 2022-06-23 14:47:55.373296
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    unsafe_proxy_instance = UnsafeProxy("obj")
    assert unsafe_proxy_instance.__class__.__name__ == "AnsibleUnsafeText"
    assert unsafe_proxy_instance == "obj"



# Generated at 2022-06-23 14:48:07.337324
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    test_str = b'a%c3%a8b%c3%a9d%c3%a8e%c3%a9'
    assert isinstance(test_str, binary_type), "%r is not binary_type" % test_str
    assert not isinstance(test_str, text_type), "%r is text_type" % test_str
    assert not isinstance(test_str, AnsibleUnsafeText), "%r is AnsibleUnsafeText" % test_str
    assert not isinstance(test_str, AnsibleUnsafeBytes), "%r is AnsibleUnsafeBytes" % test_str
    assert isinstance(AnsibleUnsafeBytes(test_str), AnsibleUnsafeBytes), "Can't convert %r to AnsibleUnsafeBytes" % test_str