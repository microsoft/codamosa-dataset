

# Generated at 2022-06-23 14:38:02.915879
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    test_str = to_unsafe_text('test')
    assert test_str is not None

    test_str = UnsafeProxy(test_str)
    assert test_str is not None

    assert test_str.__UNSAFE__

# Generated at 2022-06-23 14:38:06.169503
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    test_unsafe_text = AnsibleUnsafeText(u"test_unsafe_text")
    test_unsafe_text.encode()

# Generated at 2022-06-23 14:38:09.549744
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert str(type(UnsafeProxy('string'))) == "<class 'ansible.module_utils.six.text_type'>"

# Generated at 2022-06-23 14:38:15.316199
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    ### test for method that is similar to wrap_var ###
    test_str = "test string"
    testing_unsafe_text = AnsibleUnsafeText(test_str)
    test_instance = UnsafeProxy(test_str)
    assert isinstance(test_instance, AnsibleUnsafeText)
    assert test_instance == testing_unsafe_text

# Generated at 2022-06-23 14:38:15.789759
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    NativeJinjaUnsafeText("{{foo}}")

# Generated at 2022-06-23 14:38:19.614140
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy('foo').__class__.__name__ == 'AnsibleUnsafeText', "__new__ does not wrap unsafe string in AnsibleUnsafeText"
    assert UnsafeProxy(b'foo').__class__.__name__ == 'AnsibleUnsafeBytes', "__new__ does not wrap unsafe bytes in AnsibleUnsafeBytes"

# Generated at 2022-06-23 14:38:22.307897
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(b'\x00'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'\x00', errors='surrogate_or_strict'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:38:27.997010
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # Given:
    unsafe_text = 'my_unsafe_text'
    ansible_unsafe_text = AnsibleUnsafeText(unsafe_text)

    # When:
    ansible_unsafe_bytes = ansible_unsafe_text.encode()

    # Then:
    assert isinstance(ansible_unsafe_bytes, AnsibleUnsafeBytes)
    assert ansible_unsafe_bytes == unsafe_text.encode()



# Generated at 2022-06-23 14:38:37.728058
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.utils.unsafe_proxy import to_unsafe_text
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    b = b'foobar'
    u = u'foobar'
    assert isinstance(to_unsafe_text(b), AnsibleUnsafeText)
    assert to_unsafe_text(b) == u
    assert isinstance(to_unsafe_text(u), AnsibleUnsafeText)
    assert to_unsafe_text(u) == u
    assert isinstance(to_unsafe_text(u, encoding='utf-8'), AnsibleUnsafeText)
    assert to_unsafe_text(u, encoding='utf-8') == u
    assert isinstance(to_unsafe_text(u, encoding='ascii'), AnsibleUnsafeText)


# Generated at 2022-06-23 14:38:47.673152
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY2
    class TestClass(object):
        pass

    obj = TestClass()

    assert wrap_var("test") == "test"
    assert wrap_var(u"test") == u"test"
    if PY2:
        assert isinstance(wrap_var("test"), AnsibleUnsafeBytes)
    else:
        assert isinstance(wrap_var("test"), AnsibleUnsafeText)

    assert wrap_var(obj) == obj
    assert wrap_var(None) is None
    assert wrap_var(1) == 1

    assert wrap_var(dict()) == {}
    assert wrap_var(dict(a="a")) == {"a": "a"}
    assert wrap_var(dict(a=obj)) == {"a": obj}

    assert wrap_var([])

# Generated at 2022-06-23 14:39:00.451246
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.template.template import _is_native_jinja
    from ansible.template.safe_eval import safe_eval

    # Ensure that NativeJinjaUnsafeText creates a string
    # which is marked as __UNSAFE__ so that it will be
    # treated as unsafe strings by the Jinja templating
    # engine.
    s = NativeJinjaUnsafeText("{{ test }}")
    assert s.__UNSAFE__
    assert isinstance(s, text_type)

    # Ensure that safe_eval can also handle values marked as
    # __UNSAFE__.
    assert safe_eval(s) == '{{ test }}'

    # Ensure that _is_native_jinja can handle values marked
    # as __UNSAFE__.
    assert _is_native_jinja(s) is True

# Generated at 2022-06-23 14:39:02.494013
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    a = AnsibleUnsafe()
    assert a.__UNSAFE__


# Generated at 2022-06-23 14:39:08.710444
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    a = AnsibleUnsafeText('huihuihuihuihuihuihuihuihuihuihuihuihui')
    # type(a) = class '__main__.AnsibleUnsafeText'
    b = a.encode()
    # type(b) = class '__main__.AnsibleUnsafeBytes'
    assert isinstance(b, AnsibleUnsafeBytes) and isinstance(a, AnsibleUnsafeText)



# Generated at 2022-06-23 14:39:19.813544
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    # if object is already an instance of AnsibleUnsafeText return the object
    assert to_unsafe_text(AnsibleUnsafeText('unit test')) == AnsibleUnsafeText('unit test')
    # if object is Python 2 str object
    if isinstance('', str) and sys.version_info[0] != 3:
        assert type(to_unsafe_text('unit test')) is AnsibleUnsafeText
    # if object is Python 3 str
    if isinstance('', str) and sys.version_info[0] == 3:
        assert type(to_unsafe_text('unit test')) is AnsibleUnsafeText
    # if object is Python 2 unicode

# Generated at 2022-06-23 14:39:27.058639
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # Test case 1: Test constructor with string and unicode
    assert type(AnsibleUnsafeBytes("test")) is AnsibleUnsafeBytes
    assert type(AnsibleUnsafeBytes(u"test")) is AnsibleUnsafeBytes

    # Test case 2: Test constructor with other objects, including None
    assert type(AnsibleUnsafeBytes(10)) is AnsibleUnsafeBytes
    assert type(AnsibleUnsafeBytes()) is AnsibleUnsafeBytes
    assert type(AnsibleUnsafeBytes(None)) is AnsibleUnsafeBytes

    # Test case 3: Test constructor with a AnsibleUnsafe type
    assert type(AnsibleUnsafeBytes(AnsibleUnsafeText(u"test"))) is AnsibleUnsafeBytes
    assert type(AnsibleUnsafeBytes(AnsibleUnsafeBytes("test"))) is Ansible

# Generated at 2022-06-23 14:39:28.846036
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(b'\xed\xa0\x80') == u'\U0010ffff'

# Generated at 2022-06-23 14:39:30.766333
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    y = AnsibleUnsafe()
    assert y.__UNSAFE__ == True


# Generated at 2022-06-23 14:39:35.898256
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils import six
    if six.PY3:
        s = to_unsafe_text(b"\xc3\x80")
    else:
        s = to_unsafe_text(u"\xc3\x80")
    assert isinstance(s, AnsibleUnsafeText), s

# Generated at 2022-06-23 14:39:47.596964
# Unit test for function wrap_var
def test_wrap_var():
    # Wrapping a native string
    assert wrap_var('hello') == AnsibleUnsafeText('hello')
    assert type(wrap_var('hello')) == AnsibleUnsafeText

    # Wrapping an unsafe string
    assert wrap_var(AnsibleUnsafeText('hello')) == AnsibleUnsafeText('hello')
    assert type(wrap_var(AnsibleUnsafeText('hello'))) == AnsibleUnsafeText

    # Wrapping a list
    assert wrap_var(['hello']) == [AnsibleUnsafeText('hello')]
    assert wrap_var(['hello', 'world']) == [AnsibleUnsafeText('hello'), AnsibleUnsafeText('world')]

    # Wrapping a set
    assert wrap_var(set(['hello'])) == set([AnsibleUnsafeText('hello')])

# Generated at 2022-06-23 14:39:55.694927
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    u = AnsibleUnsafeBytes(b'This is a test')
    assert u.__UNSAFE__ == True
    w = u.decode('utf-8')
    assert w.__UNSAFE__ == True
    assert w.encode('utf-8').__UNSAFE__ == True
    assert w == u.decode('utf-8')
    assert w == AnsibleUnsafeText(u)
    assert w == AnsibleUnsafeText(u.decode('utf-8'))

# Generated at 2022-06-23 14:40:02.925275
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    raw_text = 'this is text'
    result = AnsibleUnsafeText(to_text(raw_text))
    assert result == raw_text
    assert isinstance(result, text_type)
    assert isinstance(result, AnsibleUnsafeText)

    result = AnsibleUnsafeText(to_text(raw_text)).encode('utf-8')
    assert result == raw_text.encode('utf-8')
    assert isinstance(result, binary_type)
    assert isinstance(result, AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:40:15.437207
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Test for normal value
    assert UnsafeProxy("hello") == "hello"
    # Test for unsafe value
    assert UnsafeProxy(AnsibleUnsafeBytes("hello")) == AnsibleUnsafeBytes("hello") is True
    assert UnsafeProxy(AnsibleUnsafeText("hello")) == AnsibleUnsafeText("hello") is True
    # Test with native jinja text
    assert UnsafeProxy(NativeJinjaText("hello")) == NativeJinjaUnsafeText("hello") is True
    assert type(UnsafeProxy(NativeJinjaText("hello"))) == NativeJinjaUnsafeText
    # Test with native jinja unsafe text
    assert UnsafeProxy(NativeJinjaUnsafeText("hello")) == NativeJinjaUnsafeText("hello") is True

# Generated at 2022-06-23 14:40:17.767694
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    native_jinja_unsafe_text = NativeJinjaUnsafeText("text")
    assert native_jinja_unsafe_text == "text"

# Generated at 2022-06-23 14:40:19.835437
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes(b"data"), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:40:22.008131
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    result = AnsibleUnsafeBytes('hello').decode()
    assert isinstance(result, AnsibleUnsafeText)



# Generated at 2022-06-23 14:40:33.166954
# Unit test for function wrap_var
def test_wrap_var():
    """Unit test for function wrap_var"""
    import json
    import ansible.module_utils.common.text.converters

    assert wrap_var("Hello") == u'Hello'
    assert wrap_var(u"Hello") == u'Hello'

    assert wrap_var(b"Hello") == u'Hello'
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0

    l = [u"Hello", 1, 2]
    ul = wrap_var(l)
    assert l is ul
    assert isinstance(ul, list)
    assert isinstance(ul[0], text_type)

    s = set([u"Hello", 1, 2])
    us = wrap_var(s)
    assert s is us
    assert isinstance(us, set)

# Generated at 2022-06-23 14:40:40.607059
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(1234) == '1234'
    assert to_unsafe_text(1234.56) == '1234.56'
    assert to_unsafe_text(True) == 'True'
    assert to_unsafe_text(None) is None
    assert isinstance(to_unsafe_text(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_text(u'foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(UnsafeProxy(u'foo')), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(NativeJinjaText('foo')), NativeJinjaUnsafeText)

# Generated at 2022-06-23 14:40:47.824243
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    # utf-8 should be validated as unsafe.
    assert isinstance(u"test".encode('utf-8'), AnsibleUnsafeBytes)
    # ascii should be safe.
    assert not isinstance(u"test".encode('ascii'), AnsibleUnsafeBytes)
    # bytes should be unsafe.
    assert isinstance(b"test", AnsibleUnsafeBytes)
    # text should be safe.
    assert not isinstance(u"test", AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:40:55.116391
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.six import PY2

    assert to_unsafe_bytes(u'\u2713') == to_unsafe_bytes(u'\u2713')
    assert to_unsafe_bytes('\xe2\x9c\x93') == to_unsafe_bytes(u'\u2713')
    assert to_unsafe_bytes(b'\xe2\x9c\x93') == to_unsafe_bytes(u'\u2713')

    if PY2:
        assert to_unsafe_bytes('\xe2\x9c\x93') == to_unsafe_bytes(b'\xe2\x9c\x93')

# Generated at 2022-06-23 14:40:56.828140
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert isinstance(AnsibleUnsafe(), AnsibleUnsafe)



# Generated at 2022-06-23 14:41:08.590682
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes('foo'), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeBytes('foo'.encode('utf-8')), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeBytes(u'foo'), AnsibleUnsafeBytes)
    assert not isinstance(AnsibleUnsafeBytes(u'foo'), AnsibleUnsafeText)
    # Test AnsibleUnsafeBytes is unsafe
    assert AnsibleUnsafeBytes(u'foo').__UNSAFE__
    # Test decode for AnsibleUnsafeBytes
    assert isinstance(AnsibleUnsafeBytes(u'foo').decode('utf-8'), AnsibleUnsafeText)
    # Test encode for AnsibleUnsafeBytes

# Generated at 2022-06-23 14:41:10.594665
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-23 14:41:18.070582
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    v = AnsibleUnsafeBytes(b'abc\x00\x01\x02\x7f\x80\x81\xff')
    assert v == b'abc\x00\x01\x02\x7f\x80\x81\xff'
    assert isinstance(v, AnsibleUnsafeBytes)
    assert not isinstance(v, AnsibleUnsafeText)


# Generated at 2022-06-23 14:41:24.332196
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    from ansible.module_utils._text import to_bytes, to_text

    source = to_text(b"binary data\n", errors='surrogate_or_strict')
    assert isinstance(source, text_type)
    assert isinstance(source, AnsibleUnsafeText)

    dest = source.encode()
    assert isinstance(dest, binary_type)
    assert isinstance(dest, AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:41:36.048379
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.utils.display import Display
    Display().deprecated(
        'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )

    before = b"ansible bytes"
    after = NativeJinjaUnsafeText(before)
    assert isinstance(after, NativeJinjaUnsafeText), "NativeJinjaUnsafeText was not instanciated"
    assert isinstance(after, AnsibleUnsafeText), "NativeJinjaUnsafeText was not instanciated"
    assert isinstance(after, AnsibleUnsafe), "NativeJinjaUnsafeText was not instanciated"

# Generated at 2022-06-23 14:41:41.830308
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    test_string = 'abc123'
    my_unsafe_text = AnsibleUnsafeText(test_string)
    test_string_bytes = test_string.encode('utf-8')

    assert isinstance(my_unsafe_text.encode(), AnsibleUnsafeBytes)
    assert my_unsafe_text.encode() == test_string_bytes
    assert my_unsafe_text.encode('utf-8') == test_string_bytes



# Generated at 2022-06-23 14:41:44.683368
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert isinstance(AnsibleUnsafeText('string'), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeText(str('string')), AnsibleUnsafeText)

# Generated at 2022-06-23 14:41:56.273056
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy(b'\xde\xad\xbe\xef').__UNSAFE__
    assert isinstance(UnsafeProxy(b'\xde\xad\xbe\xef'), AnsibleUnsafeBytes)
    assert UnsafeProxy(to_unsafe_bytes(b'\xde\xad\xbe\xef')).__UNSAFE__
    assert isinstance(UnsafeProxy(to_unsafe_bytes(b'\xde\xad\xbe\xef')), AnsibleUnsafeBytes)
    assert UnsafeProxy(u'\xd4\xef\xbe\xad').__UNSAFE__
    assert isinstance(UnsafeProxy(u'\xd4\xef\xbe\xad'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:42:03.761082
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # Check the type of decoded object
    # An AnsibleUnsafeBytes object is decoded to an AnsibleUnsafeText object
    obj = AnsibleUnsafeBytes('abc123')
    obj2 = obj.decode()
    assert(isinstance(obj, AnsibleUnsafeBytes))
    assert(isinstance(obj2, AnsibleUnsafeText))

    # Check that encode and decode are inverses
    obj_encoded = obj.encode()
    obj_decoded = obj_encoded.decode()
    assert(obj == obj_encoded)
    assert(obj2 == obj_decoded)

    # Check decoding a constant object using AnsibleUnsafeBytes.decode
    obj_const = AnsibleUnsafeText('abc123')
    assert(obj_const == obj_decoded)



# Generated at 2022-06-23 14:42:12.004553
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.utils._text import to_text

    assert isinstance(to_unsafe_text("Hello"), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text("Hello".encode("utf-8")), AnsibleUnsafeText)
    assert to_unsafe_text("Hello") == "Hello"
    assert to_unsafe_text("Hello".encode("utf-8")) == "Hello"
    assert to_unsafe_text("Hello") == to_unsafe_text("Hello".encode("utf-8"))



# Generated at 2022-06-23 14:42:15.396319
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    aub = AnsibleUnsafeBytes(to_bytes(u'ÿÒ€'))
    assert aub.decode('utf-8') == u'ÿÒ€'


# Generated at 2022-06-23 14:42:21.037601
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    bs = to_unsafe_bytes("foo", encoding='utf-8')
    assert isinstance(bs, AnsibleUnsafeBytes)
    assert "foo" == bs.decode('ascii')
    assert isinstance(bs.decode('ascii'), AnsibleUnsafeText)
    assert "foo" == bs.decode('utf-8')


# Generated at 2022-06-23 14:42:23.833721
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    value = UnsafeProxy('foo')
    assert value == u'foo'
    assert isinstance(value, text_type)
    assert isinstance(value, AnsibleUnsafe)



# Generated at 2022-06-23 14:42:30.618506
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    data = AnsibleUnsafeText('Кирилица.').encode('utf-8')
    assert(isinstance(data, AnsibleUnsafeBytes))
    assert(data == b'\xd0\x9a\xd0\xb8\xd1\x80\xd0\xb8\xd0\xbb\xd0\xb8\xd1\x86\xd0\xb0.')


# Generated at 2022-06-23 14:42:38.735127
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    import types
    assert isinstance(UnsafeProxy(1, 2, 3), int)
    assert isinstance(UnsafeProxy(1.5, 2, 3), float)
    assert isinstance(UnsafeProxy([1, 2, 3], 1, 2), list)
    assert isinstance(UnsafeProxy({'a': 1, 'b': 2}, 1, 2), dict)

    assert isinstance(UnsafeProxy(b'abcd'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(u'abcd'), AnsibleUnsafeText)

    # Test that subclassing AnsibleUnsafe is not affected by UnsafeProxy
    assert isinstance(UnsafeProxy(AnsibleUnsafeText(u'abcd')), AnsibleUnsafeText)

# Generated at 2022-06-23 14:42:42.321231
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    t = AnsibleUnsafeText(u'\u00e9')
    assert t.encode('utf8') == AnsibleUnsafeBytes(u'\u00e9'.encode('utf8'))



# Generated at 2022-06-23 14:42:49.126985
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    t = AnsibleUnsafeText("test")
    # Checks if the constructor created a valid text object
    assert hasattr(t, 'encode')
    assert hasattr(t, 'decode')
    # Checks if the constructor created an unsafe object
    assert hasattr(t, '__UNSAFE__')
    assert t.__UNSAFE__
    # Check if the constructor created an object of the right class
    assert isinstance(t, AnsibleUnsafeText)


# Generated at 2022-06-23 14:42:59.123463
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    class Unicode:
        def __eq__(self, other):
            return isinstance(other, Unicode)
        def __ne__(self, other):
            return not isinstance(other, Unicode)

    def assert_unicode_equal(text1, text2):
        assert text1.encode('utf-8') == text2.encode('utf-8')

    text1 = AnsibleUnsafeText('aaaa')
    assert text1 == 'aaaa'
    assert isinstance(text1, AnsibleUnsafeText)
    assert text1 != Unicode()

    text2 = text1.encode('utf-8')
    assert isinstance(text2, AnsibleUnsafeBytes)
    assert text2 != 'aaaa'
    assert text2 == b'aaaa'
    assert text2 != Unicode()

    text3 = text2.decode

# Generated at 2022-06-23 14:43:08.389463
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import is_sequence

    class unsafe_class(AnsibleUnsafe):
        pass

    ret = unsafe_class()
    assert ret.__dict__ == {}

    ret.foo = 'bar'
    assert ret.foo == 'bar'

    ret_json = to_text(ret)
    assert ret_json == '{"foo": "bar"}'

    ret_list = [ret]
    assert is_sequence(ret_list)
    assert ret_list[0].foo == 'bar'



# Generated at 2022-06-23 14:43:16.217773
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    import unittest
    import sys
    class TestAnsibleUnsafe(unittest.TestCase):
        def test_AnsibleUnsafe(self):
            # Arrange
            unsafe = AnsibleUnsafe()
            # Assert
            self.assertTrue(unsafe)
    # execute the unit test
    unittest.main(module=sys.modules[__name__], failfast=True, exit=False, verbosity=2)


# Generated at 2022-06-23 14:43:21.126319
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    import pytest

    assert isinstance(AnsibleUnsafeText('test').encode(), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText('test').encode().encode(), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText('test').encode().decode(), AnsibleUnsafeText)

# Generated at 2022-06-23 14:43:22.696594
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    val = b'a'
    obj = AnsibleUnsafeBytes(val)
    assert obj == val
    assert obj.__class__ is AnsibleUnsafeBytes



# Generated at 2022-06-23 14:43:32.795365
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils._text import to_text
    assert to_unsafe_text(u'test') == u'test'
    assert to_unsafe_text(u'test', encoding='ascii') == u'test'
    assert to_unsafe_text(b'test') == u'test'
    assert to_unsafe_text(b'test', encoding='ascii') == u'test'
    assert to_unsafe_text(u'test', errors='surrogate_or_strict') == u'test'
    assert to_unsafe_text(b'test', errors='surrogate_or_strict') == u'test'
    assert to_unsafe_text(b'\x80test') == u'\x80test'

# Generated at 2022-06-23 14:43:45.087514
# Unit test for function wrap_var
def test_wrap_var():
    # we need to test:
    # - None, int, float, text, bytes, tuples, lists, dicts, sets
    unwrapped_var = {
        'none': None,
        'int': 123,
        'float': 123.0,
        'text': "Hello",
        'text_unsafe': AnsibleUnsafeText("Hello"),
        'bytes': b"World",
        'bytes_unsafe': AnsibleUnsafeBytes(b"World"),
        'tuples': ('a', 'b'),
        'lists': ['a', 'b'],
        'dicts': {'a': 'b'},
        'sets': {'a'},
    }

    assert unwrapped_var['none'] is None
    assert type(unwrapped_var['none']) == type(None)


# Generated at 2022-06-23 14:43:48.971351
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    x = AnsibleUnsafeText()
    assert type(x) == AnsibleUnsafeText, "test_AnsibleUnsafeText failed"


if __name__ == "__main__":
    test_AnsibleUnsafeText()

# Generated at 2022-06-23 14:43:59.612528
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    def test_type(uni_str, charset):
        unsafe_bytes = AnsibleUnsafeBytes(uni_str.encode(charset))
        ans = unsafe_bytes.decode(charset)
        # ans must be an instance of class AnsibleUnsafeText
        assert isinstance(ans, AnsibleUnsafeText)
        assert ans == uni_str
        # verify the reverse operation of encode
        assert ans.encode(charset) == unsafe_bytes

    def test_with_errors(uni_str, charset):
        unsafe_bytes = AnsibleUnsafeBytes(uni_str.encode(charset,
                                                         errors='surrogate_or_strict'))
        ans = unsafe_bytes.decode(charset)
        # ans must be an instance of class AnsibleUnsafeText

# Generated at 2022-06-23 14:44:02.394555
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    expected_result = AnsibleUnsafeText(u'foo')
    result = UnsafeProxy(u'foo')
    assert result == expected_result


# Generated at 2022-06-23 14:44:08.578471
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    text_obj = UnsafeProxy(u'This is a text')
    binary_obj = UnsafeProxy(u'This is a text'.encode('utf-8'))
    native_jinja_obj = UnsafeProxy(NativeJinjaText(u'This is a text'))

    assert isinstance(text_obj, AnsibleUnsafeText)
    assert isinstance(binary_obj, AnsibleUnsafeBytes)
    assert isinstance(native_jinja_obj, NativeJinjaUnsafeText)

# Generated at 2022-06-23 14:44:09.715930
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe.__UNSAFE__


# Generated at 2022-06-23 14:44:17.134364
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    '''
    Check if to_unsafe_text returns an AnsibleUnsafeText object
    '''
    import ansible.module_utils.common.unsafe_proxy
    import sys
    if sys.version_info.major == 3:
        assert isinstance(ansible.module_utils.common.unsafe_proxy.to_unsafe_text('abc'), ansible.module_utils.common.unsafe_proxy.AnsibleUnsafeText)


# Generated at 2022-06-23 14:44:21.301832
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    dummy_text = 'dummy'
    rv = AnsibleUnsafeText(dummy_text)
    assert rv == dummy_text
    assert isinstance(rv, text_type)


# Generated at 2022-06-23 14:44:24.111510
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    my_unsafe = AnsibleUnsafe('safe')
    assert isinstance(my_unsafe, AnsibleUnsafe)
    assert isinstance(my_unsafe, string_types)

# Generated at 2022-06-23 14:44:26.470122
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    a = AnsibleUnsafe()
    assert isinstance(a, AnsibleUnsafe)


# Generated at 2022-06-23 14:44:30.323320
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    inst = NativeJinjaUnsafeText("foo")
    assert inst.__UNSAFE__ == True
    ret = inst.__html__()
    assert ret == "<span class=\"k\">'foo'</span>"

# Generated at 2022-06-23 14:44:32.432468
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy("hello").startswith("UnsafeProxy") is False
    assert isinstance("hello", AnsibleUnsafeText) is False
    assert isinstance("hello", AnsibleUnsafe) is False
    assert UnsafeProxy("hello").__UNSAFE__ is True

# Generated at 2022-06-23 14:44:42.082591
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    import ansible.module_utils.unsafe_proxy as proxy_module
    my_str = "foo"

    # first, a regular string
    assert isinstance(my_str, str)
    assert not isinstance(my_str, proxy_module.AnsibleUnsafe)

    # now, a wrapped string
    my_str_wrapped = proxy_module.UnsafeProxy(my_str)
    assert isinstance(my_str_wrapped, str)
    assert isinstance(my_str_wrapped, proxy_module.AnsibleUnsafe)
    assert isinstance(my_str_wrapped, proxy_module.AnsibleUnsafeText)

    # test that the proxy object wraps all inputs to string types
    my_bytes = b"bar"

# Generated at 2022-06-23 14:44:44.739577
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    nju = NativeJinjaUnsafeText(b'abc')
    assert nju == b'abc'
    assert nju == u'abc'

# Generated at 2022-06-23 14:44:47.014540
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    object = AnsibleUnsafe()
    if object.__UNSAFE__ != True:
        raise NameError('AnsibleUnsafe is not a safe object')

# Generated at 2022-06-23 14:44:51.126666
# Unit test for function wrap_var
def test_wrap_var():
    import copy
    x = {'a': '1', 'b': '2', 'c': 3}
    y = copy.deepcopy(x)
    y['a'] = AnsibleUnsafeBytes(y['a'])
    y['b'] = AnsibleUnsafeText(y['b'])
    y['c'] = 3
    assert wrap_var(x) == y

# Generated at 2022-06-23 14:44:52.117367
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe()



# Generated at 2022-06-23 14:44:55.364729
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b'foo').decode(), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeBytes(b'foo').decode('ascii'), AnsibleUnsafeText)


# Generated at 2022-06-23 14:45:00.873038
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    class AlmostBytes:
        def __bytes__(self):
            return b'test'

    assert to_unsafe_bytes(AlmostBytes()) == b'test'

    if hasattr(unicode, '__bytes__'):
        assert to_unsafe_bytes(unicode()) == b''
    else:
        assert to_unsafe_bytes(unicode()) == ''

# Generated at 2022-06-23 14:45:05.923513
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    a = AnsibleUnsafeBytes(u"str")
    for i in a:
        assert isinstance(i, AnsibleUnsafeBytes)
    assert isinstance(a.encode(), AnsibleUnsafeBytes)
    assert isinstance(a.decode(), AnsibleUnsafeText)



# Generated at 2022-06-23 14:45:13.549004
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    value1 = None
    value2 = b'hello world'
    value3 = u'hello world'
    value4 = 1

    assert to_unsafe_bytes(value1) == value1
    assert to_unsafe_bytes(value2) == value2
    assert to_unsafe_bytes(value3) == b'hello world'
    assert to_unsafe_bytes(value4) == b'1'

    assert isinstance(to_unsafe_bytes(value2), binary_type)
    assert isinstance(to_unsafe_bytes(value3), binary_type)
    assert isinstance(to_unsafe_bytes(value4), binary_type)


# Generated at 2022-06-23 14:45:25.680467
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    """Verify that to_unsafe_text is a wrapper around to_text
    and wrap_var."""

    # Test string input
    assert to_unsafe_text('test') == wrap_var(to_text('test'))
    assert to_unsafe_text('test'.encode()) == wrap_var(to_text('test'.encode()))

    # Test native_jinja_text input
    native_jinja_text = NativeJinjaText('test')
    assert to_unsafe_text(native_jinja_text) == wrap_var(to_text(native_jinja_text))

    # Test that the function will be called recursively if necessary

# Generated at 2022-06-23 14:45:28.908758
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    test_str = AnsibleUnsafeText(u"test")
    test_str_encoded = test_str.encode('utf-8')
    assert isinstance(test_str_encoded, AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:45:32.636227
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # Check if AnsibleUnsafe is a subclass of str (Python 2) or str (Python 3)
    assert issubclass(AnsibleUnsafeText, string_types)

    assert issubclass(AnsibleUnsafeText, AnsibleUnsafe)



# Generated at 2022-06-23 14:45:43.732407
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import os
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    # Make a text stream available in the fake sys module to capture stdout
    stdout = StringIO()
    sys.stdout = stdout

    # Create a fake module object
    module = AnsibleModule(argument_spec={})

    # Capture original stdout
    old_stdout = sys.stdout

    # Generate and test values
    for value in ('foo', u'\u00E4\u00F6\u00FC', b'bar'):
        result = to_unsafe_text(value)

# Generated at 2022-06-23 14:45:45.778499
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    x = AnsibleUnsafeBytes(b'foo')
    assert isinstance(x, AnsibleUnsafeBytes)
    assert isinstance(x, AnsibleUnsafe)


# Generated at 2022-06-23 14:45:49.773341
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    data = b'\x80\x00\x01\x02\x03\x04'
    us_bytes = AnsibleUnsafeBytes(data)
    assert us_bytes == data
    us_text = us_bytes.decode('utf8')
    assert isinstance(us_text, AnsibleUnsafeText)



# Generated at 2022-06-23 14:45:51.518837
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert AnsibleUnsafeText('test') == u'test'

# Generated at 2022-06-23 14:46:03.749908
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes(None) is None
    assert to_unsafe_bytes(123) == b'123'
    assert to_unsafe_bytes('abc') == b'abc'
    assert to_unsafe_bytes(b'abc') == b'abc'
    assert to_unsafe_bytes(u'abc') == b'abc'
    assert isinstance(to_unsafe_bytes(u'abc'), AnsibleUnsafeBytes)
    assert to_unsafe_bytes(u'abc', errors='strict') == b'abc'
    assert to_unsafe_bytes(u'abc', errors='replace') == b'abc'
    assert to_unsafe_bytes(u'abc', errors='surrogate_or_strict') == b'abc'

# Generated at 2022-06-23 14:46:06.176463
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    obj = AnsibleUnsafe()
    assert obj.__UNSAFE__ is True


# Generated at 2022-06-23 14:46:17.088730
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():

    # in this file
    #import AnsibleUnsafeBytes
    #from ansible.utils._text import to_text
    #import wrap_var

    #from ansible.module_utils.six import string_types, binary_type, text_type
    from .common.six import string_types, binary_type, text_type
    #from ansible.utils.unsafe_proxy import UnsafeProxy

    #from ansible.module_utils._text import to_bytes
    from ansible.utils._text import to_bytes

    # Unit test for method __new__ of class UnsafeProxy
    # Unit test for method __new__ of class UnsafeProxy
    # Unit test for method __new__ of class UnsafeProxy
    # test when obj is string

# Generated at 2022-06-23 14:46:20.121783
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    t1 = AnsibleUnsafeBytes('hello')
    assert isinstance(t1, AnsibleUnsafeBytes)
    assert t1 == 'hello'
    assert t1.__Unsafe__ is True


# Generated at 2022-06-23 14:46:29.017102
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    # This is used to test with mutable types (dict and list)
    # that we are recursively wrapping and not returning a copy.
    def _test_recursive(obj, expected_obj):
        assert expected_obj is obj

    # Test that we are wrapping everything.
    # This may seem excessive but this was rewritten to handle
    # wrapping all cases.
    # Python 3 only has one string type which is always unicode.
    # Python 2 str returns bytestring and unicode returns unicode.
    # In both cases to_text handles these differences.

    # Short text strings
    assert isinstance(to_unsafe_text(u'foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text('foo'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:46:39.913401
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    ansible_unsafe_bytes = AnsibleUnsafeBytes(b"\xe7\xb5\x84\xe5\x8a\xa0\xe5\x9c\xa8\xef\xbc\x8c\xe7\xb5\x84\xe5\x8a\xa0\xe6\x88\x90\xe5\x8a\x9f")
    ansible_unsafe_text = ansible_unsafe_bytes.decode()
    assert ansible_unsafe_text == AnsibleUnsafeText(u"\u7ec4\u52a0\u5728\uff0c\u7ec4\u52a0\u6210\u529f")


# Generated at 2022-06-23 14:46:48.300874
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text('test'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text('test'[0]), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text('test'.encode('utf-8')), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text('test'.encode('utf-8')[0]), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'\xff'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text('\xff'), AnsibleUnsafeText)



# Generated at 2022-06-23 14:46:52.654621
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    class Test:
        def __str__(self):
            return "NativeJinjaUnsafeText"

    try:
        assert str(NativeJinjaUnsafeText(Test())) == "NativeJinjaUnsafeText"
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-23 14:46:57.312638
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert isinstance(AnsibleUnsafe(), AnsibleUnsafe)
    assert isinstance(AnsibleUnsafe(), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafe(), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:46:59.992827
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert isinstance(AnsibleUnsafeText('unsafe'), AnsibleUnsafeText), "AnsibleUnsafeText object created properly"
    assert isinstance(AnsibleUnsafeText('unsafe'), AnsibleUnsafe), "AnsibleUnsafeText object created properly"

# Generated at 2022-06-23 14:47:08.181628
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy(AnsibleUnsafeText()), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes()), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(NativeJinjaUnsafeText()), NativeJinjaUnsafeText)

    assert isinstance(UnsafeProxy(to_unsafe_bytes('test1')), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(to_unsafe_text('test2')), AnsibleUnsafeText)

    assert isinstance(UnsafeProxy(to_unsafe_bytes(u'test1')), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(to_unsafe_text(u'test2')), AnsibleUnsafeText)


# Generated at 2022-06-23 14:47:09.486965
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    s = UnsafeProxy("foo")
    assert s == "foo"
    assert isinstance(s, AnsibleUnsafeText)

# Generated at 2022-06-23 14:47:13.509024
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes(b"u"), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_text(b"u"), AnsibleUnsafeText)

test_to_unsafe_bytes()

# Generated at 2022-06-23 14:47:18.087562
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    test_string = AnsibleUnsafeText('my string')
    new_string = test_string.encode('utf-8')

    assert isinstance(new_string, AnsibleUnsafeBytes)
    assert not isinstance(new_string, AnsibleUnsafeText)



# Generated at 2022-06-23 14:47:19.173563
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    AnsibleUnsafeText("Test")

# Generated at 2022-06-23 14:47:25.948005
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    def to_unsafe_bytes(*args, **kwargs):
        return wrap_var(to_bytes(*args, **kwargs))

    assert to_unsafe_bytes('a') == AnsibleUnsafeBytes('a')
    assert to_unsafe_bytes('a', errors='strict') == AnsibleUnsafeBytes('a')
    assert isinstance(to_unsafe_bytes('a', errors='strict'), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:47:28.615105
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    obj = UnsafeProxy('ansible')
    assert isinstance(obj, AnsibleUnsafeText), 'UnsafeProxy class is a subclass of AnsibleUnsafeText'



# Generated at 2022-06-23 14:47:37.121908
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    text = "some text"
    ansible_unsafe_text = AnsibleUnsafeText(text)
    assert ansible_unsafe_text.__UNSAFE__
    assert isinstance(ansible_unsafe_text, AnsibleUnsafe)
    assert isinstance(ansible_unsafe_text, AnsibleUnsafeText)
    assert isinstance(ansible_unsafe_text, text_type)
    assert not isinstance(ansible_unsafe_text, binary_type)
    assert not isinstance(ansible_unsafe_text, AnsibleUnsafeBytes)
    assert text == ansible_unsafe_text
    assert ansible_unsafe_text.__repr__() == text



# Generated at 2022-06-23 14:47:40.384157
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert type(AnsibleUnsafeBytes('foo').decode()) is AnsibleUnsafeText
    assert type(AnsibleUnsafeBytes('foo').decode('utf-8')) is AnsibleUnsafeText

# Generated at 2022-06-23 14:47:51.878423
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.playbook.play_context import PlayContext
    assert wrap_var("password") == "password"
    assert wrap_var("password") == "_ansible_unsafe_bytes"
    assert wrap_var("password").encode("utf-8") == "_ansible_unsafe_bytes"
    assert wrap_var("password").encode("utf-8").decode("utf-8") == "_ansible_unsafe_text"
    assert wrap_var({"name":"password"}) == "_ansible_unsafe_dict"
    assert wrap_var(["password"]) == "_ansible_unsafe_list"
    assert wrap_var(("password",)) == "_ansible_unsafe_tuple"
    assert wrap_var({'pass': 'word'}, unsafe=True) is not None

# Generated at 2022-06-23 14:48:04.538566
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types
    u_str = u'test_string'
    unsafe_text1 = AnsibleUnsafeText(u_str)
    assert(isinstance(unsafe_text1, string_types))
    assert(is_sequence(unsafe_text1))
    assert(isinstance(unsafe_text1, AnsibleUnsafe))
    assert(unsafe_text1 == u_str)
    b_str = b'test_string'
    unsafe_text2 = AnsibleUnsafeText(b_str)
    assert(isinstance(unsafe_text2, string_types))
    assert(is_sequence(unsafe_text2))