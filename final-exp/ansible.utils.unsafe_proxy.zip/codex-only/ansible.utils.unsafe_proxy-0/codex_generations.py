

# Generated at 2022-06-23 14:38:05.427244
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    Display().deprecated(
        'wrap_var is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )
    # Test None
    assert wrap_var(None) is None

    # Test already unsafe
    assert isinstance(wrap_var(AnsibleUnsafeText('foo')), AnsibleUnsafeText)

    # Test strings
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test lists
    test_list = [1, 2, 3, 4]
    assert isinstance(wrap_var(test_list), list)

# Generated at 2022-06-23 14:38:11.003313
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b'hello').decode('utf-8'), AnsibleUnsafeText)
    assert AnsibleUnsafeBytes(b'hello') == b'hello'
    assert AnsibleUnsafeBytes(b'hello').decode('utf-8') == u'hello'


# Generated at 2022-06-23 14:38:13.869559
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    var = AnsibleUnsafeText(b"unicode")
    assert type(var) == AnsibleUnsafeText


# Generated at 2022-06-23 14:38:18.128667
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    """
    1. create a str.
    2. create an instance of AnsibleUnsafeBytes
    3. verify the type of v is AnsibleUnsafeBytes
    """
    v = b"testBytes"
    unsafev = AnsibleUnsafeBytes(v)
    assert isinstance(unsafev, AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:38:25.978746
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    import sys

    if sys.version_info[0] == 2:
        assert isinstance(AnsibleUnsafeBytes(b'success').decode(), AnsibleUnsafeText)
        assert isinstance(AnsibleUnsafeBytes('success').decode(), AnsibleUnsafeText)
    else:
        assert isinstance(AnsibleUnsafeBytes(b'success').decode(), AnsibleUnsafeText)
        assert isinstance(AnsibleUnsafeBytes('success').decode(), AnsibleUnsafeText)



# Generated at 2022-06-23 14:38:30.716835
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    s = AnsibleUnsafeBytes('foo')
    assert(s == 'foo')
    assert(isinstance(s, binary_type))
    assert(isinstance(s, AnsibleUnsafe))
    assert(s.__UNSAFE__ is True)
    assert(s.decode(encoding='utf8') == 'foo')


# Generated at 2022-06-23 14:38:36.742337
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    """ NativeJinjaUnsafeText returns NativeJinjaText object with added attribute __UNSAFE__ = True to it """
    from ansible.module_utils.common.collections import is_sequence
    test_string = 'testing'
    test_string_obj = NativeJinjaUnsafeText(test_string)
    assert is_sequence(test_string_obj)
    assert test_string_obj.__UNSAFE__
    assert test_string_obj == test_string

# Generated at 2022-06-23 14:38:47.118715
# Unit test for function wrap_var
def test_wrap_var():
    # Tests for string
    # Tests for AnsibleUnsafe
    safe = AnsibleUnsafeText(u"Allons-y")
    assert wrap_var(safe) == safe
    # Tests for unicode
    string = u"Allons-y"
    assert wrap_var(string) == AnsibleUnsafeText(string)
    # Tests for str
    string = "Allons-y"
    assert wrap_var(string) == AnsibleUnsafeText(string)
    # Tests for sequence (list, tuple and set)

    # Tests for list
    string_list = [u"Allons-y", u"Geronimo!"]
    assert wrap_var(string_list) == _wrap_sequence(string_list)
    # Tests for tuple

# Generated at 2022-06-23 14:38:50.741466
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from nose.plugins.skip import SkipTest
    raise SkipTest('UnsafeProxy is being deprecated.'
                   'Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead')



# Generated at 2022-06-23 14:38:54.130405
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # This should return an instance of AnsibleUnsafeBytes
    assert isinstance(AnsibleUnsafeBytes(b""), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:39:06.044603
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('foo') == 'foo'
    assert wrap_var(b'foo') == b'foo'

    assert isinstance(wrap_var(u'unicode'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'bytes'), AnsibleUnsafeBytes)

    assert isinstance(wrap_var(NativeJinjaText('native jinja')), NativeJinjaUnsafeText)

    assert wrap_var(None) is None

    assert wrap_var([1, 'foo', b'bar']) == [1, 'foo', b'bar']
    assert wrap_var(['foo', b'bar']) == ['foo', b'bar']
    assert wrap_var(['foo', b'bar'])[0] == 'foo'

# Generated at 2022-06-23 14:39:14.823198
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('test'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u'test'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'test'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(1), AnsibleUnsafeBytes)
    assert to_unsafe_bytes('test') == b'test'
    assert to_unsafe_bytes(u'test') == b'test'
    assert to_unsafe_bytes(b'test') == b'test'
    assert to_unsafe_bytes(1) == b'1'
    assert isinstance(to_unsafe_bytes('test', errors='strict'), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:39:16.155550
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    string = 'test'
    assert isinstance(to_unsafe_text(string), AnsibleUnsafeText)

# Generated at 2022-06-23 14:39:20.610667
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    try:
        AnsibleUnsafeText()
        raise AssertionError('AnsibleUnsafeText() without arguments must fail')
    except TypeError:
        pass

    actual = AnsibleUnsafeText('abc')
    assert isinstance(actual, AnsibleUnsafeText)
    assert actual == 'abc'



# Generated at 2022-06-23 14:39:27.113379
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    import argparse
    a = 'AnsibleUnsafeBytes test'
    aa = AnsibleUnsafeBytes(a)
    args = argparse.Namespace(a=a)
    parser = argparse.ArgumentParser()
    parser.add_argument('--a', default=aa)
    parser.parse_args(namespace=args)
    assert args.a == a

# Generated at 2022-06-23 14:39:29.786767
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(b'\xff'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'foo'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:39:39.771565
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(u'hello') == u'hello'
    assert wrap_var(u'\N{SNOWMAN}') == u'\N{SNOWMAN}'
    assert wrap_var(b'hello') == b'hello'
    assert wrap_var(b'\xe2\x98\x83') == b'\xe2\x98\x83'
    assert wrap_var(u'\u2603') == u'\u2603'
    assert wrap_var([u'a', u'b']) == [u'a', u'b']
    assert wrap_var([b'a', b'b'])

# Generated at 2022-06-23 14:39:41.673401
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert isinstance(NativeJinjaUnsafeText("test"), NativeJinjaUnsafeText)

# Generated at 2022-06-23 14:39:47.882240
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():

    # Test for valid constructor of class AnsibleUnsafeText
    ansible_unsafe_text = AnsibleUnsafeText('ansible_unsafe_text_string')
    assert ansible_unsafe_text

    # Test for negative constructor of class AnsibleUnsafeText
    # assert true negative test case
    try:
        AnsibleUnsafeText(1)
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-23 14:39:55.400816
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():

    assert not isinstance(None, AnsibleUnsafe)
    assert str(AnsibleUnsafe()) == ''

    x = AnsibleUnsafe()
    assert x.__UNSAFE__ == True

    x = AnsibleUnsafe()
    assert isinstance(x, AnsibleUnsafe)

    x = AnsibleUnsafe()
    assert isinstance(x, AnsibleUnsafe)

    x = AnsibleUnsafe()
    assert isinstance(x, AnsibleUnsafe)



# Generated at 2022-06-23 14:39:59.319205
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    ansible_unsafe_bytes_obj = AnsibleUnsafeBytes(b'MyString')
    try:
        print(ansible_unsafe_bytes_obj)
    except Exception as e:
        print(e)
        print(type(e))

# test_AnsibleUnsafeBytes()

# Generated at 2022-06-23 14:40:11.163112
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(0) == 0
    assert wrap_var(b'a') == AnsibleUnsafeBytes(b'a')
    assert wrap_var(u'a') == AnsibleUnsafeText(u'a')
    assert wrap_var(b'a'.decode('ascii')) == AnsibleUnsafeBytes(b'a')
    assert wrap_var(u'a'.encode('ascii')) == AnsibleUnsafeText(u'a')
    assert wrap_var(AnsibleUnsafeBytes(b'b')) == AnsibleUnsafeBytes(b'b')
    assert wrap_var(AnsibleUnsafeText(u'b')) == AnsibleUnsafeText(u'b')


# Generated at 2022-06-23 14:40:16.478423
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy(u"hello"), AnsibleUnsafeText)
    assert UnsafeProxy(u"hello").__UNSAFE__ is True
    assert UnsafeProxy(u"hello").encode('utf-8').__UNSAFE__ is True


# Tests for wrap_var

# Generated at 2022-06-23 14:40:17.654439
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert isinstance(AnsibleUnsafeText('Unsafe text'), AnsibleUnsafeText)


# Generated at 2022-06-23 14:40:20.203553
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    ansibleunsafetext_inst = AnsibleUnsafeText('something')
    assert ansibleunsafetext_inst == 'something'


# Generated at 2022-06-23 14:40:22.704331
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    test_text = AnsibleUnsafeBytes(b'Hello World')
    test_result = test_text.decode()
    assert test_result == 'Hello World'

# Generated at 2022-06-23 14:40:27.166177
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    class Foo(str):
        __UNSAFE__ = True
    f = Foo(b'bar')
    r = to_unsafe_bytes(f)
    assert isinstance(r, AnsibleUnsafeBytes)
    assert not isinstance(r, Foo)
    assert isinstance(r, binary_type)

# Generated at 2022-06-23 14:40:32.751350
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    ust = AnsibleUnsafeText('some value')
    try:
        assert isinstance(ust, AnsibleUnsafeText)
    except:
        print("AnsibleUnsafeText result not an AnsibleUnsafeText object")
        raise
    print("AnsibleUnsafeText() constructor unit test passed")


# Generated at 2022-06-23 14:40:34.789128
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    """Unit test for method decode of class AnsibleUnsafeBytes"""
    assert isinstance(AnsibleUnsafeBytes('abc').decode(), AnsibleUnsafeText)



# Generated at 2022-06-23 14:40:42.391685
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set

    assert wrap_var(b"foo") == b"foo"
    assert isinstance(wrap_var(b"foo"), AnsibleUnsafeBytes)

    assert wrap_var(u"foo") == u"foo"
    assert isinstance(wrap_var(u"foo"), AnsibleUnsafeText)

    assert wrap_var(['foo', b'foo', u'foo']) == ['foo', b'foo', u'foo']
    assert isinstance(wrap_var(['foo', b'foo', u'foo'])[1], AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:40:44.942068
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    a = AnsibleUnsafe()
    assert isinstance(a, object)
    assert isinstance(a, AnsibleUnsafe)


# Generated at 2022-06-23 14:40:53.256876
# Unit test for function wrap_var
def test_wrap_var():

    # Tests the wrapper function works on the known unsafes
    assert wrap_var(None) is None
    assert isinstance(wrap_var(to_text(u'\u2019')), AnsibleUnsafeText)
    assert wrap_var(to_text(u'\u2019')) == to_unsafe_text(u'\u2019')
    assert isinstance(wrap_var(to_bytes('\xe2\x80\x99')), AnsibleUnsafeBytes)
    assert wrap_var(to_bytes('\xe2\x80\x99')) == to_unsafe_bytes('\xe2\x80\x99')

    # Tests basic primitive wrapping
    assert wrap_var('string') == to_unsafe_text('string')
    assert wrap_var(1) == 1

# Generated at 2022-06-23 14:40:56.155854
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    ut = AnsibleUnsafeText(to_text(b"foo"))
    assert isinstance(ut, AnsibleUnsafeText)
    assert isinstance(ut, text_type)
    assert ut == "foo"

# Generated at 2022-06-23 14:40:58.289783
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe()


# Generated at 2022-06-23 14:41:09.362343
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    text = "This is AnsibleUnsafeText"
    v = AnsibleUnsafeText(text)
    assert isinstance(v, AnsibleUnsafeText)
    assert isinstance(v, AnsibleUnsafe)
    assert isinstance(v, text_type)
    assert v == text
    assert str(v) == text
    assert repr(v) == "'" + text + "'"
    assert list(v) == ["T", "h", "i", "s", " ", "i", "s", " ", "A", "n", "s", "i", "b", "l", "e", "U", "n", "s", "a", "f", "e", "T", "e", "x", "t"]
    assert v.encode() == b"This is AnsibleUnsafeText"
    assert v.en

# Generated at 2022-06-23 14:41:21.771375
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('string') == AnsibleUnsafeBytes(to_bytes('string'))
    assert to_unsafe_bytes(123) == AnsibleUnsafeBytes(to_bytes(123))
    assert to_unsafe_bytes({b'key': b'value'}) == AnsibleUnsafeBytes({b'key': AnsibleUnsafeBytes(b'value')})
    assert to_unsafe_bytes([b'list', b'of', b'bytes']) == AnsibleUnsafeBytes([AnsibleUnsafeBytes(b'list'), AnsibleUnsafeBytes(b'of'), AnsibleUnsafeBytes(b'bytes')])

# Generated at 2022-06-23 14:41:24.142620
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert AnsibleUnsafeText('°C').encode('ascii') == AnsibleUnsafeBytes(b'\xc2\xb0C')

# Generated at 2022-06-23 14:41:35.914649
# Unit test for function wrap_var
def test_wrap_var():
    assert(wrap_var(None) is None)

    assert(wrap_var('abc') is not 'abc')
    assert(type(wrap_var('abc')) == AnsibleUnsafeText)
    assert(wrap_var(u'abc') is not u'abc')
    assert(type(wrap_var(u'abc')) == AnsibleUnsafeText)
    assert(wrap_var(b'abc') is not b'abc')
    assert(type(wrap_var(b'abc')) == AnsibleUnsafeBytes)

    assert(wrap_var({'a': 'a'}) is not {'a': 'a'})
    assert(type(wrap_var({'a': 'a'})) == dict)

    assert(wrap_var(['a', 'b']) is not ['a', 'b'])
   

# Generated at 2022-06-23 14:41:45.776737
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import input

    def test_class(cls):
        if not issubclass(cls, text_type):
            return
        for method in dir(cls):
            obj = getattr(cls, method, None)
            if callable(obj) and isinstance(obj, text_type):
                assert isinstance(to_unsafe_text(obj), AnsibleUnsafeText)

    for name in dir(builtins):
        test_class(getattr(builtins, name))

    if input == builtins.input:
        assert isinstance(to_unsafe_text(input), AnsibleUnsafeText)

# Generated at 2022-06-23 14:41:50.345721
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    text = b'Some bytes'
    assert isinstance(AnsibleUnsafeBytes(text), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeBytes(text), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:42:00.268575
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.utils.display import Display
    from ansible.module_utils.six import StringIO

    display = Display()
    display.verbosity = None
    buf = StringIO()
    display.vvvv = display.display(msg='hi', color='green', stderr=False, screen_only=True, log_only=False, log_file=buf)
    my_unsafe_text = NativeJinjaUnsafeText('foo')

    assert isinstance(my_unsafe_text, text_type)
    assert isinstance(my_unsafe_text, NativeJinjaText)
    assert isinstance(my_unsafe_text, AnsibleUnsafe)
    assert isinstance(my_unsafe_text, AnsibleUnsafeText)

# Generated at 2022-06-23 14:42:06.818312
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(u'foo') == u'foo'
    assert to_unsafe_text('foo') == u'foo'
    assert to_unsafe_text(u'foo'.encode('utf-8')) == u'foo'
    assert to_unsafe_text('foo'.encode('utf-8')) == u'foo'

# Generated at 2022-06-23 14:42:10.031254
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    obj = AnsibleUnsafeBytes('#ansible')
    ret = obj.decode()
    assert type(obj) == AnsibleUnsafeBytes
    assert isinstance(ret, AnsibleUnsafeText)


# Generated at 2022-06-23 14:42:12.640371
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    ansible_unsafe_bytes = AnsibleUnsafeBytes(b'123')
    assert(ansible_unsafe_bytes == b'123')


# Generated at 2022-06-23 14:42:23.390991
# Unit test for function wrap_var
def test_wrap_var():
    test_map = {
        # input, expected output
        b'foo': AnsibleUnsafeBytes(to_bytes('foo')),
        'foo': AnsibleUnsafeText(to_text('foo')),
        ('foo',): ('foo',),
        ('foo', 'bar'): ('foo', 'bar'),
        {'a': 'b'}: {'a': 'b'},
        ['a']: ['a'],
        [u'a']: ['a'],
        set([]): set([]),
        set([u'a']): set([u'a']),
        None: None,
        True: True,
        1: 1
    }
    for input, expected in test_map.items():
        result = wrap_var(input)

# Generated at 2022-06-23 14:42:26.431365
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText("test").encode(), AnsibleUnsafeBytes)
    return True



# Generated at 2022-06-23 14:42:32.877741
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    if AnsibleUnsafeBytes(b'foobar') != b'foobar':
        raise AssertionError('AssertionError')
    
    if type(AnsibleUnsafeBytes(b'foobar')) is not AnsibleUnsafeBytes:
        raise AssertionError('AssertionError')
    
    if type(AnsibleUnsafeBytes(b'foobar').decode()) is not AnsibleUnsafeText:
        raise AssertionError('AssertionError')


# Generated at 2022-06-23 14:42:38.618055
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    print('Testing AnsibleUnsafe constructor...')
    try:
        u = AnsibleUnsafe()
    except Exception as e:
        print(str(e))
        print('Failed to create AnsibleUnsafe object')
        return False

    print('AnsibleUnsafe constructor passed!')
    return True



# Generated at 2022-06-23 14:42:40.988366
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    t = AnsibleUnsafeText("a")
    b = t.encode()
    assert isinstance(b, AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:42:43.791205
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert issubclass(UnsafeProxy, AnsibleUnsafe)
    assert issubclass(UnsafeProxy, AnsibleUnsafeText)
    assert issubclass(UnsafeProxy, AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:42:54.978089
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    proxy = UnsafeProxy('text')
    assert isinstance(proxy, AnsibleUnsafeText)
    assert isinstance(proxy, text_type)
    assert not isinstance(proxy, binary_type)

    proxy = UnsafeProxy(b'bytes')
    assert isinstance(proxy, AnsibleUnsafeBytes)
    assert isinstance(proxy, binary_type)
    assert not isinstance(proxy, text_type)

    proxy = UnsafeProxy(b'Unicode text\xc3\xb6\xc3\xa4\xc3\xb1'.decode('utf-8'))
    assert isinstance(proxy, AnsibleUnsafeText)
    assert isinstance(proxy, text_type)
    assert not isinstance(proxy, binary_type)


# Generated at 2022-06-23 14:43:06.917562
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY3

    assert isinstance(to_unsafe_bytes('hello world'), AnsibleUnsafeBytes)

    bytes_str = to_unsafe_bytes(b'hello world', errors='strict')
    assert isinstance(bytes_str, AnsibleUnsafeBytes)
    if PY3:
        assert isinstance(bytes_str, binary_type)
    else:
        assert isinstance(bytes_str, text_type)

    assert to_unsafe_bytes(b'hello world') == b'hello world'
    assert to_unsafe_bytes('hello world', encoding='utf-8') == b'hello world'
    assert to_unsafe_bytes(u'hello world') == b'hello world'
    assert to_unsafe_bytes(3) == b'3'


# Generated at 2022-06-23 14:43:14.240795
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # AnsibleUnsafeText.encode()
    # A AnsibleUnsafeText should remain AnsibleUnsafe after encode is called.
    ansibleUnsafText = AnsibleUnsafeText("unsafetext")
    newAnsibleUnsafText = ansibleUnsafText.encode("utf-8")
    assert isinstance(newAnsibleUnsafText, AnsibleUnsafeBytes)
    assert newAnsibleUnsafText.__UNSAFE__


# Generated at 2022-06-23 14:43:18.394928
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    unsafe_bytes = to_unsafe_bytes('Hello\n')
    assert isinstance(unsafe_bytes, binary_type)
    assert isinstance(unsafe_bytes, AnsibleUnsafeBytes)
    assert unsafe_bytes == b'Hello\n'


# Generated at 2022-06-23 14:43:25.588544
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from jinja2 import Template
    from ansible.module_utils.common._collections_compat import Mapping
    t = Template('{{ var }}')
    jinja_var = t.render(var=None)
    assert isinstance(jinja_var, str)
    assert jinja_var == "None"
    assert isinstance(wrap_var(jinja_var), NativeJinjaUnsafeText)
    assert isinstance(wrap_var(jinja_var), Mapping)
    assert not isinstance(wrap_var(jinja_var), AnsibleUnsafe)

# Generated at 2022-06-23 14:43:27.034838
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert AnsibleUnsafeBytes(b'abc').decode() == u'abc'

# Generated at 2022-06-23 14:43:36.672585
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    if not isinstance(to_unsafe_text(u'foo'), AnsibleUnsafeText):
        raise Exception()
    if not isinstance(to_unsafe_text(to_unsafe_text(u'foo')), AnsibleUnsafeText):
        raise Exception()
    if not isinstance(to_unsafe_text(u'foo', errors='surrogate_or_strict'), AnsibleUnsafeText):
        raise Exception()
    if not isinstance(to_unsafe_text(u'foo', errors='surrogate_or_strict'), AnsibleUnsafeText):
        raise Exception()



# Generated at 2022-06-23 14:43:43.910270
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    test_input = [
        ('', '', '', None),
        ('', '\u0168', '', 'á'),
        ('IGNORE', '\ufffd', '', '?'),
        ('IGNORE', '\u0168', '', 'á'),
    ]
    for error, input_, encoding, expected in test_input:
        ret = UnsafeProxy(input_, encoding=encoding, errors=error).force_text()
        assert ret == expected

# Generated at 2022-06-23 14:43:46.661238
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert type(to_unsafe_bytes('abc', errors='surrogate_or_strict')) is AnsibleUnsafeBytes



# Generated at 2022-06-23 14:43:49.816830
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    """Test ability to create an AnsibleUnsafeText object"""
    s = "hello world"
    unsafe = AnsibleUnsafeText(s)
    assert unsafe == s

# Generated at 2022-06-23 14:43:55.381851
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils._text import to_text
    text_string = to_text(b'This is a test string')
    unsafe_text_string = to_unsafe_text(text_string)
    assert(unsafe_text_string.__UNSAFE__)
    assert(unsafe_text_string == text_string)
    assert(unsafe_text_string is not text_string)

# Generated at 2022-06-23 14:43:58.199374
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes(b'foo'), AnsibleUnsafeBytes)
    assert to_unsafe_bytes(b'foo') == b'foo'


# Generated at 2022-06-23 14:44:02.263058
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert UnsafeProxy(AnsibleUnsafeText())
    assert UnsafeProxy(AnsibleUnsafeText('foo'))
    assert UnsafeProxy(AnsibleUnsafeBytes())
    assert UnsafeProxy(AnsibleUnsafeBytes(b'foo'))



# Generated at 2022-06-23 14:44:11.156742
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    # Test Unicode
    assert isinstance(to_unsafe_text(u'a'), AnsibleUnsafeText)

    # Test Bytes
    assert isinstance(to_unsafe_text(b'a'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'\xe2\x98\x83'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'\xff'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'\xff', errors='strict'), AnsibleUnsafeText)

    # Test None
    assert isinstance(to_unsafe_text(None), type(None))

    # Test other non-string types
    assert isinstance(to_unsafe_text(3.14), float)

# Generated at 2022-06-23 14:44:17.622030
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    a = AnsibleUnsafeBytes(b'\x01\x02\x03')
    assert a == b'\x01\x02\x03'
    assert type(a) is AnsibleUnsafeBytes
    assert type(a.decode("utf-8")) is AnsibleUnsafeText
    assert a.decode("utf-8") == u'\u0001\u0002\u0003'


# Generated at 2022-06-23 14:44:19.947963
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert hasattr(AnsibleUnsafe(), '__UNSAFE__')

# Generated at 2022-06-23 14:44:21.930609
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert type(AnsibleUnsafeBytes(b'abc').decode()) is AnsibleUnsafeText


# Generated at 2022-06-23 14:44:26.039386
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    class A:
        pass

    r = AnsibleUnsafeBytes(A())
    assert len(r) == 0

    r = AnsibleUnsafeBytes('ansible')
    assert isinstance(r, AnsibleUnsafeBytes)
    assert r == 'ansible'
    assert r.decode() == 'ansible'
    assert len(r) == 6


# Generated at 2022-06-23 14:44:34.651217
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    value = "Test string"
    # Test 1: When using UnsafeProxy with a string should return a AnsibleUnsafeText
    assert isinstance(UnsafeProxy(value), AnsibleUnsafeText)

    value_bytes = AnsibleUnsafeBytes(value)
    # Test 2: When using UnsafeProxy with a AnsibleUnsafeBytes should return the same object
    assert UnsafeProxy(value_bytes) is value_bytes

    value_text = AnsibleUnsafeText(value)
    # Test 3: When using UnsafeProxy with a AnsibleUnsafeText should return the same object
    assert UnsafeProxy(value_text) is value_text

# Generated at 2022-06-23 14:44:37.664989
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    a_str = "a str"
    foo = UnsafeProxy(a_str)
    assert type(foo) is AnsibleUnsafeText
    assert foo == a_str

# Generated at 2022-06-23 14:44:39.369506
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert isinstance(NativeJinjaUnsafeText(''), NativeJinjaUnsafeText)

# Generated at 2022-06-23 14:44:50.673516
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():

    # base test case
    x = UnsafeProxy("this is a string")
    assert x == "this is a string"
    x = UnsafeProxy(u"this is a string")
    assert x == "this is a string"
    assert (type(x) == AnsibleUnsafeText)

    # test with other types
    x = UnsafeProxy(None)
    assert x == None
    assert (type(x) == None)
    x = UnsafeProxy(True)
    assert x == True
    assert (type(x) == bool)
    x = UnsafeProxy(1)
    assert x == 1
    assert (type(x) == int)
    x = UnsafeProxy(1.2)
    assert x == 1.2
    assert (type(x) == float)

    # test with iterables
    x

# Generated at 2022-06-23 14:44:53.874295
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    """check if we can create a class of AnsibleUnsafeText"""
    try:
        x = AnsibleUnsafeText("hello world")
    except UnicodeDecodeError:
        print("Caught UnicodeDecodeError")
        raise
    except:
        raise

# Generated at 2022-06-23 14:45:00.153577
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy(""), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(u""), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(42), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText()), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes()), AnsibleUnsafeBytes)
    assert UnsafeProxy(AnsibleUnsafeText()) is AnsibleUnsafeText()


# Generated at 2022-06-23 14:45:05.030976
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes(b"foo"), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u"foo"), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes("foo"), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:45:14.000846
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    # Test for string
    assert isinstance(UnsafeProxy('hello'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy('hello'), AnsibleUnsafe)
    assert UnsafeProxy('hello') == 'hello'

    # Test for unicode string
    assert isinstance(UnsafeProxy(u'hello'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(u'hello'), AnsibleUnsafe)
    assert UnsafeProxy('hello') == 'hello'

    # Test for already unsafe object
    assert isinstance(UnsafeProxy(AnsibleUnsafeText('hello')), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText('hello')), AnsibleUnsafe)
    assert UnsafeProxy(AnsibleUnsafeText('hello')) == 'hello'

    # Test for sequence

# Generated at 2022-06-23 14:45:15.486293
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    result_var = UnsafeProxy("hello")

    print(type(result_var))

# Generated at 2022-06-23 14:45:18.622507
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # Given
    ans = AnsibleUnsafeText("some text")

    # When
    result = ans.encode()

    # Then
    assert type(result) is AnsibleUnsafeBytes

# Generated at 2022-06-23 14:45:29.692473
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import collections
    import pytest
    from ansible.module_utils._text import to_text

    assert isinstance(to_unsafe_text('hello'), AnsibleUnsafeText)

    assert isinstance(to_unsafe_text(b'hello'), AnsibleUnsafeText)

    assert isinstance(to_unsafe_text(dict(a=1)), dict)
    assert isinstance(to_unsafe_text(dict(a=1)).get('a'), AnsibleUnsafeText)

    assert isinstance(to_unsafe_text([1, 2]), list)
    assert isinstance(to_unsafe_text([1, 2])[0], AnsibleUnsafeText)

    assert isinstance(to_unsafe_text(collections.OrderedDict(a=1)), collections.OrderedDict)
    assert isinstance

# Generated at 2022-06-23 14:45:37.931123
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.utils.display import Display
    import ansible.module_utils.common

    class MyModule(ansible.module_utils.common.AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(MyModule, self).__init__(*args, **kwargs)
            self.display = Display()

    m = MyModule(argument_spec={})

    # Test that the deprecated message is correctly displayed
    v = b"unsafe!"
    assert isinstance(UnsafeProxy(v), AnsibleUnsafeBytes)
    assert m.display.deprecations

# Generated at 2022-06-23 14:45:40.631607
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    njut = NativeJinjaUnsafeText('Testing unit test of NativeJinjaUnsafeText')
    assert isinstance(njut, NativeJinjaUnsafeText)

# Generated at 2022-06-23 14:45:42.896317
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    #TODO: Implement test_AnsibleUnsafeText_encode
    pass


# Generated at 2022-06-23 14:45:44.971833
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    t = AnsibleUnsafeText(u"test text")
    assert isinstance(t.encode(), AnsibleUnsafeBytes) == True


# Generated at 2022-06-23 14:45:52.638878
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={
            'test': {'default': None},
        }
    )

    # test with valid utf-8 data
    utf8_data = module.params['test'] = '\xa3'
    safe_string = AnsibleUnsafeText(utf8_data)
    basic.json_dict_unicode_to_bytes(safe_string)
    assert isinstance(safe_string, AnsibleUnsafeText)

    # test with invalid data
    invalid_data = module.params['test'] = b'\x80'
    safe_string = AnsibleUnsafeText(invalid_data)

# Generated at 2022-06-23 14:45:59.255325
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    # Test that to_unsafe_bytes() works on objects of type {binary_type, text_type}
    # and returns an object of type AnsibleUnsafeBytes
    assert isinstance(to_unsafe_bytes(u'string'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'string'), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:46:03.070303
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    unsafe_proxy_obj = UnsafeProxy("test_UnsafeProxy___new__")
    assert type(unsafe_proxy_obj) is AnsibleUnsafeText
    assert unsafe_proxy_obj == "test_UnsafeProxy___new__"


# Generated at 2022-06-23 14:46:14.364500
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy(None), AnsibleUnsafe)
    assert isinstance(UnsafeProxy("None"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(u"None"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy("None").encode("utf-8"), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy("None".encode("utf-8")), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(UnsafeProxy("None")), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy("None".decode("utf-8")), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(UnsafeProxy("None").decode("utf-8")), AnsibleUnsafeText)

# Generated at 2022-06-23 14:46:25.081601
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY2, PY3, string_types
    from ansible.module_utils.six.moves import builtins

    assert wrap_var(AnsibleUnsafeText('foo')) is wrap_var('foo')
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is wrap_var(b'foo')

    if PY3:
        assert isinstance(wrap_var('foo'), builtins.str)
        assert isinstance(wrap_var(b'foo'), builtins.bytes)
    else:
        assert isinstance(wrap_var('foo'), string_types)
        assert isinstance(wrap_var(b'foo'), builtins.str)

    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:46:36.136401
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy("abc"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy("abc".encode("utf-8")), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(b"abc"), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy({"a": "b"}), dict)
    assert isinstance(UnsafeProxy({"a": "b".encode("utf-8")}), dict)
    assert isinstance(UnsafeProxy({"a": b"b"}), dict)
    assert isinstance(UnsafeProxy(("a".encode("utf-8"), "b")), tuple)


# Generated at 2022-06-23 14:46:40.627253
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    a = AnsibleUnsafeText("abc")
    assert isinstance(a.encode(), binary_type)
    assert isinstance(a.encode(errors="unicode_escape"), binary_type)
    assert isinstance(a.encode(errors="ignore"), binary_type)


# Generated at 2022-06-23 14:46:44.646248
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():

    input_str = "My string with latin characters: áÁñÑ"
    output_str = "My string with latin characters: áÁñÑ"
    assert to_unsafe_bytes(input_str) == output_str


# Generated at 2022-06-23 14:46:51.090903
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert(isinstance(to_unsafe_bytes(u""), AnsibleUnsafeText))
    assert(isinstance(to_unsafe_bytes(123), AnsibleUnsafeText))
    assert(isinstance(to_unsafe_bytes(123456789012345), AnsibleUnsafeText))

    assert(isinstance(to_unsafe_bytes(u"string"), AnsibleUnsafeText))
    assert(isinstance(to_unsafe_bytes("string"), AnsibleUnsafeText))


# Generated at 2022-06-23 14:46:59.012264
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # Testing decode method for an AnsibleUnsafeBytes with a valid encoding
    assert isinstance(AnsibleUnsafeBytes(b'hello').decode('utf-8'), AnsibleUnsafeText)
    # Testing decode method for an AnsibleUnsafeBytes with an invalid encoding
    try:
        AnsibleUnsafeBytes(b'hel\x90lo').decode('utf-8')
    except UnicodeDecodeError:
        pass
    else:
        assert False


# Generated at 2022-06-23 14:47:00.081804
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe()



# Generated at 2022-06-23 14:47:02.628971
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    bytes_test = to_unsafe_bytes(b"\x80\x81\x82")
    assert isinstance(bytes_test, AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:47:10.200892
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes(True) == b"True"
    assert to_unsafe_bytes(False) == b"False"
    assert to_unsafe_bytes(42) == b"42"
    assert to_unsafe_bytes(42.0) == b"42.0"
    assert isinstance(to_unsafe_bytes(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)
    assert to_unsafe_bytes(to_bytes(u'foo')) == b"foo"


# Generated at 2022-06-23 14:47:20.693149
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    test_input = 'This is a test'
    test_input_utf8 = 'This is a test'.encode('utf-8')
    test_input_unicode = u'This is a test'
    actual_output_1 = AnsibleUnsafeBytes(test_input)
    actual_output_2 = AnsibleUnsafeBytes(test_input_utf8)
    actual_output_3 = AnsibleUnsafeBytes(test_input_unicode)
    assert test_input == actual_output_1.data
    assert test_input == actual_output_2.data
    assert test_input_utf8 == actual_output_3.data


# Generated at 2022-06-23 14:47:23.623269
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('foo') == to_bytes('foo')
    assert type(to_unsafe_bytes('foo')) == AnsibleUnsafeBytes


# Generated at 2022-06-23 14:47:32.024955
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes, to_text

# Generated at 2022-06-23 14:47:34.573982
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes('\xe4\xf6\xfc'.encode()).decode(), AnsibleUnsafeText)



# Generated at 2022-06-23 14:47:37.334508
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    unsafe_proxy = UnsafeProxy('test')
    assert isinstance(unsafe_proxy, AnsibleUnsafeText)


# Generated at 2022-06-23 14:47:41.846193
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    u = AnsibleUnsafeBytes(b'\xc3\xbc')
    assert u == b'\xc3\xbc'
    assert u.__UNSAFE__
    assert isinstance(u, binary_type)
    assert isinstance(u, AnsibleUnsafe)


# Generated at 2022-06-23 14:47:53.093983
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    class Test:
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return 'STR: ' + str(self.value)

        def __repr__(self):
            return 'REPR: ' + repr(self.value)

    class Subclass(Test, AnsibleUnsafe):
        pass

    a = AnsibleUnsafe()
    assert 'AnsibleUnsafe object' == a.__repr__()
    assert 'AnsibleUnsafe object' == a.__str__()

    z = Subclass(3)
    assert z.__UNSAFE__
    assert 'REPR: 3' == z.__repr__()
    assert 'STR: 3' == z.__str__()
    assert 3 == z.value




# Generated at 2022-06-23 14:47:56.475098
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert (isinstance(AnsibleUnsafeText('hello').encode(), binary_type))
    assert (isinstance(AnsibleUnsafeText('hello').encode(), AnsibleUnsafeBytes))


# Generated at 2022-06-23 14:48:00.934426
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert issubclass(AnsibleUnsafeText, text_type)
    assert hasattr(AnsibleUnsafeText, '__UNSAFE__')
    assert 'encode' in dir(AnsibleUnsafeText)


# Generated at 2022-06-23 14:48:03.870701
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    str_obj = 'test_string'
    NativeJinjaUnsafeText(str_obj)