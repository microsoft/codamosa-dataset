

# Generated at 2022-06-23 14:38:08.152214
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    # We want to ensure that the following is a string and unsafe
    assert isinstance(to_unsafe_text('test'), AnsibleUnsafeText)
    assert not isinstance(to_unsafe_text('test'), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:38:12.212664
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    input_str = "Test String"
    output_str = UnsafeProxy(input_str)
    assert(isinstance(output_str, AnsibleUnsafeText))
    assert(output_str == input_str)


# Generated at 2022-06-23 14:38:16.069735
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # A test to ensure that creating an AnsibleUnsafe object does not raise an error
    try:
        AnsibleUnsafe()
    except Exception as e:
        # There should not be any exception raised
        print(e)



# Generated at 2022-06-23 14:38:22.297299
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text('abc') == u'abc'
    assert to_unsafe_text(b'abc') == u'abc'
    assert to_unsafe_text(b'\xe4') == u'\u00e4'
    assert isinstance(to_unsafe_text(b'\xe4'), text_type)
    assert to_unsafe_text(b'\xe4', errors='strict') == u'\u00e4'
    assert to_unsafe_text(b'\xe4', errors='ignore') == u''
    assert to_unsafe_text(b'\xe4', errors='replace') == u'?'



# Generated at 2022-06-23 14:38:23.471209
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    x = NativeJinjaUnsafeText("a")

# Generated at 2022-06-23 14:38:28.114942
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    test_data = to_bytes("#!/bin/bash\r\n")
    assert isinstance(test_data, AnsibleUnsafeBytes)
    assert test_data == AnsibleUnsafeBytes("#!/bin/bash\r\n")

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 14:38:30.582017
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert(NativeJinjaUnsafeText('abc') == 'abc')
    assert(NativeJinjaUnsafeText('abc').__UNSAFE__)

# Generated at 2022-06-23 14:38:35.137432
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.common._collections_compat import OrderedDict

    assert isinstance(OrderedDict({'a': to_unsafe_bytes('foo')})['a'], AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:38:40.958724
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # First, we need to convert a string to bytes
    bytes_string = "bytes_string".encode('utf-8')
    ansible_unsafe_bytes = AnsibleUnsafeBytes(bytes_string)
    assert type(ansible_unsafe_bytes) == AnsibleUnsafeBytes
    assert ansible_unsafe_bytes.decode('utf-8') == "bytes_string"

# Generated at 2022-06-23 14:38:43.248841
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    """
    Tests for method AnsibleUnsafeText.encode
    """
    unsafe_text = AnsibleUnsafeText('将符号转换为字节')
    result = unsafe_text.encode('utf-8')
    assert isinstance(result, AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:38:47.425798
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    x = AnsibleUnsafeText('hello')
    assert x == 'hello', 'constructor of class AnsibleUnsafeText "hello" failed'


# Generated at 2022-06-23 14:38:50.477284
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    up = UnsafeProxy("test")
    assert(isinstance(up, text_type))
    assert(isinstance(up, AnsibleUnsafe))



# Generated at 2022-06-23 14:38:57.672049
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # This function should be invoked by the unit test module,
    # assuming the current module has been imported.
    import ansible.module_utils.common.unsafe_proxy
    if not hasattr(ansible.module_utils.common.unsafe_proxy, "_AnsibleUnsafeText__UNSAFE__"):
        raise(AssertionError("Failed to create class AnsibleUnsafeText"))



# Generated at 2022-06-23 14:39:02.072404
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(42), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'foo'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:39:11.418826
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import ImmutableDict
    test_dict = {'foo': 1, 'bar': 2, u'baz': 3, None: 4}
    test_list = [0, 'foo', u'bar', None]
    test_tuple = (0, 'foo', u'bar', None)
    test_set = {0, 'foo', u'bar', None}
    test_all = [test_dict, test_list, test_tuple, test_set]

    # test that the output of wrap_var is actually a list
    assert isinstance(wrap_var(test_all), list)

    # test that each item inside the list is wrapped as a dictionary
    for item in wrap_var(test_all):
        assert isinstance(item, ImmutableDict)

   

# Generated at 2022-06-23 14:39:20.027075
# Unit test for function wrap_var
def test_wrap_var():
    '''
    Sanity test to ensure the functionality of
    wrap_var
    '''
    unsafe_unicode = "This is a test unicode string."
    unsafe_byte = b"This is a test byte string"
    safe_unicode = "This is also a test unicode string"

    # I want to test that the strings and byte strings
    # come out unsafely wrapped.
    assert isinstance(wrap_var(unsafe_byte), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(unsafe_unicode), AnsibleUnsafeText)
    assert isinstance(wrap_var(safe_unicode), AnsibleUnsafeText)

    # And that if it's safe, it's just returned
    assert wrap_var(safe_unicode) == safe_unicode

    import jinja2
    jinja

# Generated at 2022-06-23 14:39:24.828078
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe.__UNSAFE__
    assert not hasattr(AnsibleUnsafe, '__UNSAFE__')  # class variable
    assert hasattr(AnsibleUnsafe(), '__UNSAFE__')  # instance variable


# Generated at 2022-06-23 14:39:29.642292
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    from ansible.utils.display import Display
    display = Display()
    assert '_AnsibleUnsafe__UNSAFE__' in dir(AnsibleUnsafe())
    display.deprecated('Deprecated test_AnsibleUnsafe', version='2.13', collection_name='ansible.builtin')

# Generated at 2022-06-23 14:39:38.626506
# Unit test for function wrap_var
def test_wrap_var():
    b_data = b'\xf0'
    u_data = b_data.decode('utf-8', 'surrogateescape')
    assert u_data.encode('utf-8') == b_data
    data = {'bytes': b_data, 'text': u_data, 'int': 1}
    data_wrapped = wrap_var(data)
    assert isinstance(data_wrapped, dict)
    assert isinstance(data_wrapped['bytes'], AnsibleUnsafeBytes)
    assert isinstance(data_wrapped['text'], AnsibleUnsafeText)
    assert isinstance(data_wrapped['int'], int)



# Generated at 2022-06-23 14:39:41.055333
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    u = UnsafeProxy('unsafe')
    assert isinstance(u, AnsibleUnsafeText)



# Generated at 2022-06-23 14:39:44.150648
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.utils.unsafe_proxy import UnsafeProxy
    assert(UnsafeProxy('some text') == 'some text')


# Generated at 2022-06-23 14:39:48.207822
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    test_str = 'testit'
    t = NativeJinjaUnsafeText(test_str)
    assert type(t) == NativeJinjaUnsafeText
    assert t == 'testit'
    assert t.__class__.__name__ == 'NativeJinjaUnsafeText'
    assert t.__UNSAFE__ == True

# Generated at 2022-06-23 14:39:59.074347
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    test_string = "Hello world!"
    test_string1 = "Hello world!"
    test_string2 = "12345!@#$%^"
    test_string3 = "12345!@#$%^"
    test_unsafe_text_load_string = AnsibleUnsafeText(test_string)
    assert isinstance(test_unsafe_text_load_string, text_type)
    assert isinstance(test_unsafe_text_load_string, AnsibleUnsafe)
    assert isinstance(test_unsafe_text_load_string, AnsibleUnsafeText)
    assert test_unsafe_text_load_string == test_string1
    assert test_unsafe_text_load_string != test_string2
    # test for __init__ method
    test_unsafe_text_init = Ansible

# Generated at 2022-06-23 14:40:01.870024
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('bar') == b'bar'
    assert to_unsafe_bytes('bar').__UNSAFE__ == True


# Generated at 2022-06-23 14:40:13.741120
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import wrap_var

    assert wrap_var(42) == 42
    assert wrap_var(42) is not 42
    assert isinstance(wrap_var(42), int)
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1.0) is not 1.0
    assert isinstance(wrap_var(1.0), float)
    a = AnsibleDumper()
    assert wrap_var('Hello, World!') == AnsibleUnsafeText('Hello, World!')
    assert wrap_var(b'Hello, World!') == AnsibleUnsafeBytes(b'Hello, World!')
    assert wrap_var('42') == AnsibleUnsafeText('42')


# Generated at 2022-06-23 14:40:20.833218
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    a = AnsibleUnsafeText(b"123")
    assert a.__UNSAFE__ == True
    assert isinstance(a, binary_type) == False
    assert isinstance(a, text_type) == True
    assert isinstance(a, binary_type) == False
    try:
        b = AnsibleUnsafeText("123")
        assert True
    except Exception as e:
        assert False


# Generated at 2022-06-23 14:40:27.417321
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.utils.display import Display
    display = Display()
    display.deprecated('UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead', version='2.13', collection_name='ansible.builtin')

    # Test for method __new__
    assert(UnsafeProxy(u'foo') == AnsibleUnsafeText(u'foo'))

    # Test for method __new__
    test_obj = UnsafeProxy(u'foo')
    assert(test_obj.encode() == u'foo'.encode())

    # Test for method __new__
    assert(UnsafeProxy(b'bar') == AnsibleUnsafeText(u'bar'))

    # Test for method

# Generated at 2022-06-23 14:40:29.638630
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert isinstance(NativeJinjaUnsafeText(''), NativeJinjaUnsafeText)

# Generated at 2022-06-23 14:40:36.266541
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert type(UnsafeProxy('test')) is AnsibleUnsafeText
    assert type(UnsafeProxy(b'test')) is AnsibleUnsafeBytes
    assert type(UnsafeProxy(u'test')) is AnsibleUnsafeText
    assert type(UnsafeProxy(AnsibleUnsafeBytes(b'test'))) is AnsibleUnsafeBytes
    assert type(UnsafeProxy(AnsibleUnsafeText(u'test'))) is AnsibleUnsafeText

# Generated at 2022-06-23 14:40:38.319311
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert isinstance(NativeJinjaUnsafeText('hello'), NativeJinjaUnsafeText)

# Generated at 2022-06-23 14:40:45.857622
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():

    '''
    This test is too slow, skipping
    @pytest.mark.parametrize('value, expected_result', [
        ('Hello', b'Hello'),
        ('Hello World', b'Hello World'),
        ('Hello, World!', b'Hello, World!')
    ])
    def test_AnsibleUnsafeText_encode(self, value, expected_result):
        assert AnsibleUnsafeText(value).encode('utf-8') == expected_result
    '''
    assert True

# Generated at 2022-06-23 14:40:48.788036
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    result = AnsibleUnsafeText('test').encode('utf-8')
    assert isinstance(result, AnsibleUnsafeBytes)
    assert (result == b'test')


# Generated at 2022-06-23 14:40:58.396937
# Unit test for function wrap_var
def test_wrap_var():
    # Strings
    assert wrap_var(None) is None
    assert wrap_var('') == u''
    assert wrap_var('foo') == u'foo'

    # Unicode
    assert wrap_var(u'') == u''
    assert wrap_var(u'foo') == u'foo'

    # Byte string
    assert wrap_var(b'') == u''
    assert wrap_var(b'foo') == b'foo'

    # Mapping (Dict)
    assert wrap_var(dict()) == dict()
    assert wrap_var(dict(foo='bar')) == dict(foo=u'bar')
    assert wrap_var(dict(foo=dict(bar='baz'))) == dict(foo=dict(bar=u'baz'))

    # Sequence (List)
    assert wrap_var

# Generated at 2022-06-23 14:41:05.186182
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.six import PY3
    if PY3:
        assert isinstance(to_unsafe_text('test'), AnsibleUnsafeText)
        assert isinstance(to_unsafe_text(b'test'), AnsibleUnsafeText)
        assert isinstance(to_unsafe_bytes('test'), AnsibleUnsafeBytes)
        assert isinstance(to_unsafe_bytes(b'test'), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:41:12.697933
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils._text import to_text
    assert isinstance(to_unsafe_text(""), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u""), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text("", encoding='utf-8'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u"", encoding='utf-8'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(None), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u"{{ foo }}"), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text("{{ foo }}"), AnsibleUnsafeText)

# Generated at 2022-06-23 14:41:24.571195
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():

    from ansible.module_utils.six import PY3
    # Test string
    assert isinstance(UnsafeProxy(u'hello'), AnsibleUnsafeText)
    assert not isinstance(UnsafeProxy(b'hello'), AnsibleUnsafeText)

    # Test None
    assert isinstance(UnsafeProxy(None), type(None))

    # Test Float
    assert isinstance(UnsafeProxy(1.1), type(1.1))

    # Test tuple
    assert isinstance(UnsafeProxy(tuple()), tuple)
    if PY3:
        assert isinstance(UnsafeProxy((1, 2, b'hello')), tuple)
    else:
        assert isinstance(UnsafeProxy((1, 2, 'hello')), tuple)

    # Test list
    assert isinstance(UnsafeProxy(list()), list)

# Generated at 2022-06-23 14:41:31.739881
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    import yaml
    yaml_input = '"test_string"'
    obj = yaml.load(yaml_input)
    obj_new = AnsibleUnsafeBytes(obj)
    obj_new1 = AnsibleUnsafeText(obj_new)
    assert type(obj_new) == AnsibleUnsafeBytes
    assert type(obj_new1) == AnsibleUnsafeText
    assert obj_new1.__UNSAFE__ == True


# Generated at 2022-06-23 14:41:42.019942
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY3
    if PY3:
        assert to_unsafe_bytes('foo') == b'foo'
        assert to_unsafe_bytes('foo', encoding='ascii') == b'foo'
        assert to_unsafe_bytes('föö', encoding='latin-1') == b'f\xf6\xf6'
        assert to_unsafe_bytes(u'föö', encoding='latin-1') == b'f\xf6\xf6'
        assert to_unsafe_bytes('föö', encoding='utf-8') == b'f\xc3\xb6\xc3\xb6'

# Generated at 2022-06-23 14:41:47.942538
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes(None), type(None))
    assert isinstance(to_unsafe_bytes(1), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'x'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes('x'), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:41:55.972307
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    # test case with NativeJinjaUnsafeText
    name = "test_NativeJinjaUnsafeText"
    my_test = NativeJinjaUnsafeText('test_NativeJinjaUnsafeText')
    assert my_test.__str__() == name, "Failed test - to string conversion of NativeJinjaUnsafeText"
    assert my_test.__repr__() == "NativeJinjaUnsafeText(" + name + ")", "Failed test - representation string of NativeJinjaUnsafeText"
    assert str(my_test.__len__()) == "19", "Failed test - length of NativeJinjaUnsafeText"

# Generated at 2022-06-23 14:41:58.808806
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.module_utils.six import text_type
    assert issubclass(NativeJinjaUnsafeText, text_type) is True
    assert issubclass(NativeJinjaUnsafeText, AnsibleUnsafe) is True

# Generated at 2022-06-23 14:42:02.324186
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    s = AnsibleUnsafeBytes(b"abc")
    assert isinstance(s, AnsibleUnsafe)
    assert isinstance(s, binary_type)
    assert s == b"abc"
    assert s.decode() == "abc"
    assert isinstance(s.decode(), AnsibleUnsafeText)


# Generated at 2022-06-23 14:42:14.593759
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text('test') == AnsibleUnsafeText('test')
    assert to_unsafe_text('test', errors='ignore') == AnsibleUnsafeText('test', errors='ignore')
    assert to_unsafe_text('test', nonstring='simplerepr') == AnsibleUnsafeText('test', nonstring='simplerepr')
    assert to_unsafe_text(to_unsafe_text('test')) == AnsibleUnsafeText('test')
    assert to_unsafe_text(UnsafeProxy('test')) == AnsibleUnsafeText('test')
    assert to_unsafe_text(UnsafeProxy('test'), 'utf-8', 'surrogate_or_strict') == AnsibleUnsafeText('test', 'utf-8', 'surrogate_or_strict')
    assert to_

# Generated at 2022-06-23 14:42:26.484353
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import binary_type, text_type
    assert UnsafeProxy(None) is None
    assert UnsafeProxy(42) == 42
    assert UnsafeProxy(42.0) == 42.0

    assert isinstance(UnsafeProxy(b""), binary_type)
    assert isinstance(UnsafeProxy(u""), text_type)

    assert UnsafeProxy(b"") == b""
    assert UnsafeProxy(u"") == u""

    assert UnsafeProxy(b"hello") == b"hello"
    assert UnsafeProxy(u"hello") == u"hello"

    assert isinstance(UnsafeProxy(b"hello"), binary_type)
    assert isinstance(UnsafeProxy(u"hello"), text_type)


# Generated at 2022-06-23 14:42:33.256557
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    to_unsafe_bytes(u'abcdefg')
    to_unsafe_bytes(b'abcdefg')
    to_unsafe_bytes(1)
    to_unsafe_bytes(1.0)
    to_unsafe_bytes([])
    to_unsafe_bytes(())
    to_unsafe_bytes(None)
    to_unsafe_bytes(True)
    to_unsafe_bytes(False)
    to_unsafe_bytes({})
    to_unsafe_bytes(set())


# Generated at 2022-06-23 14:42:36.511489
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert not hasattr(UnsafeProxy(''), '__UNSAFE__')
    assert UnsafeProxy('faked_password').__UNSAFE__


# Generated at 2022-06-23 14:42:46.178506
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    b1 = b'plain-text'
    b2 = b'\xe4\xb8\xad\xe6\x96\x87'
    b3 = b'\xe7\xbb\xb4\xe5\xa0\xb4'
    u1 = u'plain-text'
    u2 = u'\u4e2d\u6587'
    u3 = u'\u7ec4\u57df'
    assert(u1 == AnsibleUnsafeBytes(b1).decode())
    assert(u2 == AnsibleUnsafeBytes(b2).decode())
    assert(u3 == AnsibleUnsafeBytes(b3).decode())
    assert(u1 == AnsibleUnsafeBytes(b1, encoding='utf-8').decode())

# Generated at 2022-06-23 14:42:57.323578
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # Test binary handling
    assert isinstance(AnsibleUnsafeBytes(b'hey'), AnsibleUnsafe)
    assert isinstance(AnsibleUnsafeBytes(b'hey').decode(), AnsibleUnsafe)
    assert not isinstance(b'hey', AnsibleUnsafe)
    assert isinstance(to_bytes(AnsibleUnsafeBytes(b'hey')), binary_type)
    assert isinstance(to_text(AnsibleUnsafeBytes(b'hey')), text_type)
    # Test text handling
    assert isinstance(AnsibleUnsafeText('hey'), AnsibleUnsafe)
    assert isinstance(AnsibleUnsafeText('hey').encode(), AnsibleUnsafe)
    assert not isinstance('hey', AnsibleUnsafe)

# Generated at 2022-06-23 14:43:08.657966
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.module_utils.six import PY3
    from ansible.utils.native_jinja import NativeJinja
    nj = NativeJinja(
        undefined=NativeJinja.Undefined,
        bytecode_cache=NativeJinja.BytecodeCache,
        extensions=['jinja2.ext.do', 'jinja2.ext.loopcontrols'])
    string_2 = "string2"
    template_string = "{{string1}}{{string2}}"
    context = dict(string1="string1", string2=string_2)
    if PY3:
        assert NativeJinjaUnsafeText(template_string, nj, context=context) == template_string

# Generated at 2022-06-23 14:43:11.717626
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b'hi').decode('utf-8'), AnsibleUnsafeText)



# Generated at 2022-06-23 14:43:20.173392
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy("Hello"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy("Hello"), text_type)
    assert isinstance(UnsafeProxy("Hello"), string_types)
    assert isinstance(UnsafeProxy("Hello".encode("utf-8")), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy("Hello".encode("utf-8")), binary_type)
    assert isinstance(UnsafeProxy("Hello".encode("utf-8")), string_types)
    assert isinstance(UnsafeProxy(None), None)



# Generated at 2022-06-23 14:43:25.711307
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy('test'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText('test2')), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes('test3')), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(None), type(None))
    assert isinstance(UnsafeProxy(AnsibleUnsafeText(None)), type(None))

# Generated at 2022-06-23 14:43:27.144150
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text("foo"), AnsibleUnsafeText)

# Generated at 2022-06-23 14:43:28.971415
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    x = AnsibleUnsafeText()
    assert x == ''


# Generated at 2022-06-23 14:43:30.458713
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes(b"hello") == b"hello"


# Generated at 2022-06-23 14:43:32.795006
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    try:
        a = AnsibleUnsafeBytes('abcdefg')
    except Exception:
        assert False
    assert True


# Generated at 2022-06-23 14:43:45.087498
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    import io
    from ansible.module_utils.six._six import StringIO
    from ansible.module_utils.six import text_type
    from ansible.module_utils.common.collections import is_sequence

    def ans_print(v, is_nested=False):
        if isinstance(v, AnsibleUnsafeText):
            print("{}AnsibleUnsafeText(".format("    " * is_nested), end="")
            ans_print(v, is_nested + 1)
            print("{})".format("    " * is_nested), end="")
        elif isinstance(v, string_types):
            print("{}{}".format("    " * is_nested, v), end="")

# Generated at 2022-06-23 14:43:48.016269
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    base = AnsibleUnsafeBytes(b'bytes_value')
    assert base.decode() == AnsibleUnsafeText(b'bytes_value'.decode())


# Generated at 2022-06-23 14:43:58.776847
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.utils.hashing import md5s
    import json

    assert to_unsafe_text(b"foo") == u"foo"
    assert to_unsafe_text(u"foo") == u"foo"

    assert md5s(b'foo') == md5s(u'foo')
    assert md5s(b'foo') == md5s(to_unsafe_bytes(u'foo'))
    assert md5s(b'foo') == md5s(to_unsafe_text(b'foo'))
    assert md5s(b'foo') == md5s(to_unsafe_text(u'foo'))

    assert json.dumps(b"foo") == json.dumps(u"foo")

# Generated at 2022-06-23 14:44:02.033615
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    safe_string = "Safe"
    unsafe_string = AnsibleUnsafe()
    assert(unsafe_string.__UNSAFE__)
    assert(not safe_string.__UNSAFE__)


# Generated at 2022-06-23 14:44:03.742170
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b'abc').decode(), AnsibleUnsafeText)

# Generated at 2022-06-23 14:44:07.151198
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    bytes_obj = AnsibleUnsafeBytes('AnsibleUnsafeBytes_test')
    assert bytes_obj == b'AnsibleUnsafeBytes_test'
    assert hasattr(bytes_obj, '__UNSAFE__') == True


# Generated at 2022-06-23 14:44:09.936337
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert isinstance(AnsibleUnsafeText(""), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeText(""), text_type)


# Generated at 2022-06-23 14:44:22.532113
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import is_sequence

    str1 = to_text('привет')
    str2 = to_text('привет')
    str3 = to_text('привет ')
    str4 = to_text('привет ', errors='surrogate_or_strict')
    str5 = to_text('привет', errors='surrogate_or_strict')

    assert isinstance(str1, AnsibleUnsafeText)
    assert isinstance(str2, AnsibleUnsafeText)
    assert isinstance(str3, AnsibleUnsafeText)

# Generated at 2022-06-23 14:44:25.887876
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    obj = AnsibleUnsafeBytes('test')
    assert obj == 'test'
    assert isinstance(obj, binary_type)
    assert isinstance(obj, AnsibleUnsafe)


# Generated at 2022-06-23 14:44:27.933865
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    text = NativeJinjaUnsafeText('testtext')
    assert text == 'testtext'

# Generated at 2022-06-23 14:44:35.946958
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    a = AnsibleUnsafeText(b'a')
    assert isinstance(a, binary_type), "AnsibleUnsafeText does not derive from the native binary type"
    assert isinstance(a, text_type), "AnsibleUnsafeText does not derive from the native text type"
    assert isinstance(a, AnsibleUnsafe), "AnsibleUnsafeText does not derive from the AnsibleUnsafe base class"
    assert a == b'a', "AnsibleUnsafeText does not behave as a binary type at the Python level"
    assert a == u'a', "AnsibleUnsafeText is not a subclass of the native text type"

# Generated at 2022-06-23 14:44:45.439664
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import integer_types
    import struct

    import unittest2 as unittest
    from ansible.module_utils.six import PY3, text_type

    from ansible.module_utils.six.moves import StringIO, StringIO as BytesIO
    from ansible.module_utils.six.moves import xrange as range
    from ansible.utils.native_jinja import NativeJinjaText

    def assert_not_equal(left, right):
        # We don't want to use assertNotEqual because it is an unknown member
        # of the builtins for some older Python versions
        if left == right:
            raise AssertionError('%r should not be equal to %r' % (left, right))


# Generated at 2022-06-23 14:44:50.852833
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text('ascii') == 'ascii'
    assert to_unsafe_text(b'bytes') == to_text(b'bytes')
    assert to_unsafe_text(None) is None
    assert to_unsafe_text('') == ''
    assert to_unsafe_text(123) == u'123'
    assert to_unsafe_text([]) == []

# Generated at 2022-06-23 14:45:00.441492
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import text_type
    from ansible.module_utils.common.collections import is_sequence

    assert isinstance(UnsafeProxy('foo'), AnsibleUnsafeText)
    assert not isinstance(UnsafeProxy(42), AnsibleUnsafeText)
    assert not isinstance(UnsafeProxy(42), AnsibleUnsafeBytes)

    # Sanity check: only accept unicode strings
    assert isinstance(UnsafeProxy(to_text('this is a unicode string', errors='surrogate_or_strict')), text_type)
    assert not isinstance(UnsafeProxy(to_text('this is a unicode string', errors='surrogate_or_strict')), AnsibleUnsafeText)

# Generated at 2022-06-23 14:45:10.129214
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    unsafe_proxy_1 = UnsafeProxy('hello')
    unsafe_proxy_2 = UnsafeProxy('hello')
    unsafe_proxy_3 = UnsafeProxy(unsafe_proxy_1)
    unsafe_proxy_4 = UnsafeProxy(None)
    assert (unsafe_proxy_1 == unsafe_proxy_2 and unsafe_proxy_1 is not unsafe_proxy_2)
    assert (unsafe_proxy_1 == unsafe_proxy_3 and unsafe_proxy_1 is unsafe_proxy_3)
    assert (unsafe_proxy_4 is None)
    assert isinstance(unsafe_proxy_1, AnsibleUnsafeText)
    assert issubclass(UnsafeProxy, AnsibleUnsafeText)

# Generated at 2022-06-23 14:45:20.753133
# Unit test for function to_unsafe_text

# Generated at 2022-06-23 14:45:30.833997
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    # Test raises exception without wrap_var
    try:
        to_unsafe_bytes(u'\u239b')
    except UnicodeDecodeError:
        pass
    else:
        assert False, "to_unsafe_bytes should raise UnicodeDecodeError when called with unicode"

    # Test works with wrap_var
    assert to_unsafe_bytes('Unicode') == b'Unicode'

    # Test works on bytes object
    assert to_unsafe_bytes(b'Bytes') == b'Bytes'

    # Test works on AnsibleUnsafeBytes
    assert to_unsafe_bytes(AnsibleUnsafeBytes()) == AnsibleUnsafeBytes()

    # Test works on Python 2.x unicode
    assert to_unsafe_bytes(u'Unicode') == b'Unicode'

    # Test

# Generated at 2022-06-23 14:45:42.222098
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    b1 = b'abc123'
    b2 = b'abc123'
    expected_1 = b1
    expected_2 = AnsibleUnsafeText(u'abc123')
    expected_3 = AnsibleUnsafeBytes(b'abc123')
    expected_4 = AnsibleUnsafeText(u'abc123')
    expected_5 = AnsibleUnsafeText(u'abc123')

    actual_1 = UnsafeProxy(expected_1)
    actual_2 = UnsafeProxy(expected_2)
    actual_3 = UnsafeProxy(expected_3)
    actual_4 = UnsafeProxy(expected_4)
    actual_5 = UnsafeProxy(expected_5)
    assert actual_1 == expected_1
    assert actual_2 == expected_2
    assert actual_3 == expected_3
    assert actual

# Generated at 2022-06-23 14:45:51.113871
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    import sys
    assert(UnsafeProxy(None) is None)
    assert(UnsafeProxy(42) == 42)

    # Test that UnsafeProxy objects are immutable.
    # This is an essential characteristic of this class.
    try:
        x = UnsafeProxy('foo')
        x.bar = 'bar'
    except AttributeError:
        pass
    else:
        assert False, 'UnsafeProxy objects must be immutable'

    # Test that the __UNSAFE__ attribute is preserved
    # when wrapping iterables.
    unsafe_dict = UnsafeProxy({'a': 'b'})
    assert(unsafe_dict['a'] == 'b')
    assert(unsafe_dict['a'].__UNSAFE__)
    unsafe_list = UnsafeProxy(['a'])

# Generated at 2022-06-23 14:45:53.791237
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    u = UnsafeProxy("Unsafe")
    assert isinstance(u, AnsibleUnsafeText)



# Generated at 2022-06-23 14:45:55.412414
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert AnsibleUnsafeText('') == ''


# Generated at 2022-06-23 14:45:56.186508
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert(isinstance(UnsafeProxy('test'), AnsibleUnsafeText))

# Generated at 2022-06-23 14:45:58.988217
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():

    ans1 = AnsibleUnsafeBytes(b"test")
    ans2 = AnsibleUnsafeBytes(ans1)

    assert ans1 == ans2

# Generated at 2022-06-23 14:46:02.592649
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    unsafe_bytes = AnsibleUnsafeBytes("bytes")
    assert isinstance(unsafe_bytes, AnsibleUnsafeBytes)
    assert isinstance(unsafe_bytes, binary_type)


# Generated at 2022-06-23 14:46:14.316201
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.common.text_compat import to_bytes
    from ansible.module_utils.common.text_compat import to_text

    # Make sure to_bytes works
    b_val = to_bytes('test')
    t_val = to_text('test', errors='surrogate_or_strict')

    # Make sure to_unsafe_bytes properly wraps bytes values and preserves them
    u_b_val = to_unsafe_bytes('test')
    assert isinstance(u_b_val, AnsibleUnsafeBytes)
    assert u_b_val == b_val

    # Make sure to_unsafe_bytes properly wraps unicode values
    u_t_val = to_unsafe_bytes('test', errors='surrogate_or_strict')

# Generated at 2022-06-23 14:46:22.164506
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    bytes_str = b'Text'
    test_str = AnsibleUnsafeBytes(bytes_str)
    assert test_str == b'Text'
    assert isinstance(test_str, AnsibleUnsafeBytes)

    str_str = u'Text'
    test_str = AnsibleUnsafeText(str_str)
    assert test_str == u'Text'
    assert isinstance(test_str, AnsibleUnsafeText)

    # test __UNSAFE__ attribute
    assert AnsibleUnsafe.__UNSAFE__
    assert not AnsibleUnsafeBytes.__UNSAFE__
    assert not AnsibleUnsafeText.__UNSAFE__

# Generated at 2022-06-23 14:46:25.398149
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # Prepare test data
    text = to_text('this is a test')
    result = AnsibleUnsafeText(text).encode()

    # Verify
    assert(isinstance(result, AnsibleUnsafeBytes))



# Generated at 2022-06-23 14:46:28.247136
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    x = AnsibleUnsafeBytes(b'abc')
    assert isinstance(x, AnsibleUnsafe)


# Generated at 2022-06-23 14:46:33.887756
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    string = "123"
    string_encoded_utf8 = "123"
    string_encoded_ansibleunsafetext = AnsibleUnsafeText("123")

    assert string == string_encoded_utf8
    assert string_encoded_utf8 == string_encoded_ansibleunsafetext

# Generated at 2022-06-23 14:46:36.190433
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert type(AnsibleUnsafeBytes(b'abc').decode()) == AnsibleUnsafeText

# Generated at 2022-06-23 14:46:47.485630
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import ImmutableDict

    assert(isinstance(wrap_var(None), type(None)))
    assert(isinstance(wrap_var(1), AnsibleUnsafe))

    assert(isinstance(wrap_var(b'bytes'), AnsibleUnsafeBytes))
    assert(isinstance(wrap_var(u'unicode'), AnsibleUnsafeText))
    assert(isinstance(wrap_var(u'unicode'.encode('utf-8')), AnsibleUnsafeBytes))

    assert(isinstance(wrap_var({}), ImmutableDict))
    assert(isinstance(wrap_var({u'key': 'value'}), ImmutableDict))

    assert(isinstance(wrap_var({b'key': b'value'}), ImmutableDict))

# Generated at 2022-06-23 14:46:50.461899
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    string_value = NativeJinjaUnsafeText("{{ }}")
    # Assert that the object has been instantiated and the results are as expected.
    assert string_value == "{{ }}", "String value is not as expected!"

# Generated at 2022-06-23 14:47:00.235898
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    input_1 = u"\u00E9couter"
    result_1 = AnsibleUnsafeText(input_1)
    assert result_1 == u"\u00E9couter"
    assert result_1.__class__ == AnsibleUnsafeText
    assert result_1.__UNSAFE__
    input_2 = "test"
    result_2 = AnsibleUnsafeText(input_2)
    assert result_2 == "test"
    assert result_2.__class__ == AnsibleUnsafeText
    assert result_2.__UNSAFE__



# Generated at 2022-06-23 14:47:02.046332
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    value = AnsibleUnsafeBytes(b'foo')
    assert value == value.encode('utf-8')

# Generated at 2022-06-23 14:47:13.146370
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert not isinstance(to_unsafe_bytes('foo'), AnsibleUnsafe)
    assert isinstance(to_unsafe_bytes(u'foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'foo'), AnsibleUnsafeBytes)
    assert not isinstance(to_unsafe_bytes(b'foo'), AnsibleUnsafeText)

    assert isinstance(to_unsafe_bytes('foo', encoding='utf-8'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u'foo', encoding='utf-8'), AnsibleUnsafeBytes)
    assert not isinstance(to_unsafe_bytes(b'foo', encoding='utf-8'), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:47:15.715739
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert(isinstance(UnsafeProxy('test_UnsafeProxy'), AnsibleUnsafeText))
    assert(isinstance(UnsafeProxy(AnsibleUnsafeText('test_UnsafeProxy')), AnsibleUnsafeText))


# Generated at 2022-06-23 14:47:20.118538
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    obj1 = NativeJinjaUnsafeText('test text')
    assert(isinstance(obj1, NativeJinjaUnsafeText))
    assert(isinstance(obj1, AnsibleUnsafeText))
    assert(isinstance(obj1, text_type))


# Generated at 2022-06-23 14:47:30.222301
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    from ansible.module_utils.common.text.converters import to_bytes
    # The constructor of AnsibleUnsafeBytes can take any type
    # of sequence to be converted to bytes.
    #     >>> AnsibleUnsafeBytes()
    #     Traceback (most recent call last):
    #       File "<stdin>", line 1, in <module>
    #     TypeError: __new__() missing 1 required positional argument: 'object'
    #     >>> AnsibleUnsafeBytes([])
    #     b''
    #     >>> AnsibleUnsafeBytes(10)
    #     b'10'
    #     >>> AnsibleUnsafeBytes(None)
    #     b''
    #     >>> AnsibleUnsafeBytes(True)
    #     b'True'
    #     >>> AnsibleUnsafeBytes((1,2

# Generated at 2022-06-23 14:47:34.574367
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    ansible_unsafe = AnsibleUnsafeText("Test")
    if isinstance(ansible_unsafe.encode("utf-8"), AnsibleUnsafeBytes):
        print("So far so good")
    else:
        print("Failed")

test_AnsibleUnsafeText_encode()

# Generated at 2022-06-23 14:47:36.277029
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe().__UNSAFE__ is True


# Generated at 2022-06-23 14:47:40.018764
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(u'a') == u'a'
    assert to_unsafe_text(b'a') == u'a'
    assert to_unsafe_text(1) == u'1'



# Generated at 2022-06-23 14:47:41.517101
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert NativeJinjaUnsafeText('abc')



# Generated at 2022-06-23 14:47:52.881031
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    test_string = to_text(u"\u6d4b\u8bd5")
    unsafe = AnsibleUnsafeText(test_string)

    assert isinstance(unsafe, AnsibleUnsafeText)
    assert isinstance(unsafe, AnsibleUnsafe)
    assert isinstance(unsafe, text_type)
    assert unsafe == test_string
    assert test_string == unsafe
    assert test_string == unsafe.rstrip(to_unsafe_text(u'\u6d4b'))

    unsafe_bytes = unsafe.encode('utf-8')
    assert isinstance(unsafe_bytes, AnsibleUnsafeBytes)
    assert isinstance(unsafe_bytes, AnsibleUnsafe)
    assert isinstance(unsafe_bytes, binary_type)

# Generated at 2022-06-23 14:48:05.519431
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes
    import sys
    FOO_TEXT = u'foo'
    FOO_BYTES_PY2 = b'foo'
    FOO_BYTES_PY3 = u'foo'.encode('utf-8')

    assert isinstance(to_unsafe_bytes(FOO_TEXT), AnsibleUnsafeText)
    if PY2:
        assert to_unsafe_bytes(FOO_TEXT) == FOO_BYTES_PY2
    else:
        assert to_unsafe_bytes(FOO_TEXT) == FOO_BYTES_PY3
