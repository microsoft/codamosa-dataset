

# Generated at 2022-06-23 14:38:13.765210
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    test_str = 'i am a test string'
    v = UnsafeProxy(test_str)
    assert(isinstance(v, AnsibleUnsafeText))
    assert(test_str == v)

    test_bytes = 'i am a test string'.encode('utf-8')
    v = UnsafeProxy(test_bytes)
    assert(isinstance(v, AnsibleUnsafeBytes))
    assert(test_bytes == v)


# Generated at 2022-06-23 14:38:21.843211
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import os

    def _test(test_str, expected_str):
        test_obj = to_text(test_str)
        wrapped = to_unsafe_text(test_obj)
        assert isinstance(wrapped, AnsibleUnsafeText)
        assert to_text(wrapped) == expected_str

    _test('abc', 'abc')
    _test(u'abc', u'abc')
    _test(b'abc', b'abc')
    _test('á', 'á')
    _test(u'á', u'á')
    _test(b'\xc3\xa1', b'\xc3\xa1')
    _test(b'\xc3\xa1', u'á')

    _test(b'\x00', u'\x00')

# Generated at 2022-06-23 14:38:27.834027
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import text_type
    x = NativeJinjaUnsafeText({"foo": "bar"})
    x.__UNSAFE__ = True
    x = to_text(x) # x is now unicode
    assert isinstance(x, text_type)
    assert x.__UNSAFE__

# Generated at 2022-06-23 14:38:29.979348
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # sanity check to make sure we can construct AnsibleUnsafe
    a = AnsibleUnsafe()

# Generated at 2022-06-23 14:38:35.735098
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    str1 = "str1"
    str2 = "str2"
    ut = AnsibleUnsafeText(str1)
    if type(ut) is not AnsibleUnsafeText:
        raise AssertionError("AnsibleUnsafeText constructor did not work")
    ut2 = ut + str2
    if ut2 == "str1str2":
        raise AssertionError("AnsibleUnsafeText constructor did not work")


# Generated at 2022-06-23 14:38:39.018601
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    try:
        ANSIBLE_UNSAFE_TEXT.encode('ascii')
    except Exception as e:
        assert False
    else:
        assert True


# Generated at 2022-06-23 14:38:48.181366
# Unit test for function wrap_var
def test_wrap_var():
    import sys

    assert wrap_var('string') is not 'string'

    # Test tuples
    assert type(wrap_var(('tuple', 'tuple'))) == tuple
    assert type(wrap_var(('tuple', 'tuple'))[0]) == AnsibleUnsafeText
    assert type(wrap_var(('tuple', 'tuple'))[1]) == AnsibleUnsafeText

    # Test lists
    assert type(wrap_var(['list', 'list'])) == list
    assert type(wrap_var(['list', 'list'])[0]) == AnsibleUnsafeText
    assert type(wrap_var(['list', 'list'])[1]) == AnsibleUnsafeText

    # Test list of lists
    assert type(wrap_var(['list', ['list']])) == list

# Generated at 2022-06-23 14:38:52.717398
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    from ansible.module_utils.six import text_type, binary_type
    un = AnsibleUnsafeText("test")
    assert(isinstance(un, AnsibleUnsafeText))
    assert(isinstance(un, binary_type))

# Generated at 2022-06-23 14:39:02.175214
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    from ansible_collections.ansible.builtin.plugins.module_utils._text import to_text
    assert isinstance(AnsibleUnsafe(), AnsibleUnsafe)
    assert AnsibleUnsafe.__UNSAFE__
    assert isinstance(AnsibleUnsafeBytes(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText(u'bar'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_bytes(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_text(u'bar'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:39:12.124308
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    import unittest
    import sys
    import ansible.module_utils.common

    class UnsafeProxyTest(unittest.TestCase):
        """
        Unit tests for method:
            __new__
        """

        def test_UnsafeProxy___new__(self):
            """
            Test for proper handling of:
                unicode
                binary
                dict
                list
                tuple
                set
            """
            from ansible.utils.display import Display
            Display().deprecated(
                'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
                version='2.13', collection_name='ansible.builtin'
            )
            s = UnsafeProxy("foo")

# Generated at 2022-06-23 14:39:20.485246
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.six import text_type
    assert isinstance(to_unsafe_text('123', encoding='utf-8'), text_type)
    assert isinstance(to_unsafe_text(b'123', encoding='utf-8'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text('123'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'123'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(AnsibleUnsafeText('')), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'foo'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:39:26.567008
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    result = AnsibleUnsafeBytes()
    assert result == b''
    result = AnsibleUnsafeBytes(b'abc')
    assert result == b'abc'
    result = AnsibleUnsafeBytes(1)
    assert result == b'1'
    result = AnsibleUnsafeBytes('abc')
    assert result == b'abc'


# Generated at 2022-06-23 14:39:28.587292
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    u = UnsafeProxy("Hello World")
    assert isinstance(u, AnsibleUnsafeText)
    assert isinstance(u, AnsibleUnsafeBytes)
    assert u == "Hello World"



# Generated at 2022-06-23 14:39:39.049585
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():

    # Strings
    assert isinstance(UnsafeProxy('foo'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy('foo').__UNSAFE__, bool)
    assert isinstance(UnsafeProxy(u'foo'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(u'foo').__UNSAFE__, bool)
    assert isinstance(UnsafeProxy(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(b'foo').__UNSAFE__, bool)

    # Unsafe bytes
    assert isinstance(UnsafeProxy(b'foo'.decode('utf-8')), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'foo'.decode('utf-8')).__UNSAFE__, bool)

# Generated at 2022-06-23 14:39:49.659076
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():

    # Test case 1: String is "b'hello world'"
    print("\n[Test Case 1]")
    givenString = "b'hello world'"
    testAnsibleUnsafeBytes = AnsibleUnsafeBytes(givenString)

    # Answer should be "hello world"
    expectedString = "hello world"

    assert(testAnsibleUnsafeBytes == expectedString, "answer should be "+expectedString)


    # Test case 2: String is "b'hello world'"
    print("\n[Test Case 2]")
    givenString = "b'hello world'"
    testAnsibleUnsafeBytes = AnsibleUnsafeBytes(givenString)

    # Answer should be True
    expectedBoolean = True


# Generated at 2022-06-23 14:39:59.755549
# Unit test for function wrap_var
def test_wrap_var():
    import unittest
    import types

    class TestWrapVar(unittest.TestCase):
        def test_wrap_var(self):
            # Test type Mapping
            self.assertIsInstance(wrap_var({}), dict)
            self.assertIsInstance(wrap_var({'a': {}}), dict)
            self.assertIsInstance(wrap_var({'a': {'b': 'c'}}), dict)
            self.assertIsInstance(wrap_var({'a': 'b'}), dict)

            # Test type Sequence
            self.assertIsInstance(wrap_var([]), list)
            self.assertIsInstance(wrap_var(tuple()), tuple)
            self.assertIsInstance(wrap_var([{}]), list)

# Generated at 2022-06-23 14:40:05.160414
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    test_string = "this is a test string"
    try:
        unsafe_string = UnsafeProxy(test_string)
    except:
        assert(False)

    assert(isinstance(unsafe_string, AnsibleUnsafeText))
    assert(isinstance(unsafe_string, text_type))
    assert(unsafe_string == test_string)


# Generated at 2022-06-23 14:40:09.774563
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes("\xc2\xa1Hola, se\xc3\xb1or!"), binary_type)
    assert isinstance(AnsibleUnsafeBytes("\xc2\xa1Hola, se\xc3\xb1or!"), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:40:21.963068
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Now we replace UnsafeProxy.__new__ with the original one
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import PY3

    class DictSubclass(MutableMapping):
        def __init__(self, initial_data):
            self._data = initial_data

        def __getitem__(self, key):
            return self._data[key]

        def __setitem__(self, key, value):
            self._data[key] = value

        def __delitem__(self, key):
            del self._data[key]

        def __iter__(self):
            return iter(self._data)

        def __len__(self):
            return len(self._data)


# Generated at 2022-06-23 14:40:23.754427
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    import doctest
    failed, tests = doctest.testmod(AnsibleUnsafe)
    if failed:
        raise AssertionError(tests)

# Generated at 2022-06-23 14:40:28.644379
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    # checkcase 1: the value of superclass is Unicode
    assert NativeJinjaUnsafeText(u'1') == u'1'
    # checkcase 2: wrong type of parameter
    try:
        NativeJinjaUnsafeText(1)
    except TypeError:
        assert True


# Generated at 2022-06-23 14:40:36.311527
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY3

    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(to_bytes('foo')), AnsibleUnsafeBytes)
    if PY3:
        assert isinstance(to_unsafe_bytes(to_text('foo')), AnsibleUnsafeBytes)
    else:
        assert isinstance(to_unsafe_bytes(to_text('foo')), text_type)



# Generated at 2022-06-23 14:40:39.079343
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # Test the constructor of class AnsibleUnsafeText
    assert(isinstance(AnsibleUnsafeText(u'Hello World'), AnsibleUnsafeText))



# Generated at 2022-06-23 14:40:42.134202
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('foo', errors='surrogate_or_strict') == to_bytes('foo', errors='surrogate_or_strict')



# Generated at 2022-06-23 14:40:51.817155
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    # Make sure we get back the same value with some simple types
    assert to_unsafe_text(b'test') == b'test'
    assert to_unsafe_text(u'test') == u'test'
    assert to_unsafe_text(1) == 1

    # Make sure we get back the same value with a dict
    assert to_unsafe_text({'a': 1, b'test': u'test'}) == {'a': 1, b'test': u'test'}
    assert to_unsafe_text({'unwrap': u'test'}) == {'unwrap': u'test'}
    assert to_unsafe_text({'a': {b'test': u'test'}}) == {'a': {b'test': u'test'}}

# Generated at 2022-06-23 14:40:55.835195
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    text = b"abcdef"
    ansible_unsafe_byte = AnsibleUnsafeBytes(text)
    assert(isinstance(ansible_unsafe_byte.decode(), type(str())))
    assert(ansible_unsafe_byte.decode() == "abcdef")


# Generated at 2022-06-23 14:41:00.308469
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    text = AnsibleUnsafeText("this is the text")
    encoded = text.encode("utf-8")
    assert isinstance(encoded, AnsibleUnsafeBytes), "encoded should be a AnsibleUnsafeBytes"


# Generated at 2022-06-23 14:41:05.327739
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    test_class = UnsafeProxy("test_string")

    # Check if the return type is AnsibleUnsafeText
    assert type(test_class) is AnsibleUnsafeText

    # Check the value of the return type
    assert test_class == "test_string"


# Generated at 2022-06-23 14:41:09.138303
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # Should be a safe string
    a = AnsibleUnsafeText("Secret string")
    b = AnsibleUnsafeText("Secret string")

    # The secret string should be equal
    if not (a == b):
        raise AssertionError('Fail')

    return True



# Generated at 2022-06-23 14:41:15.393474
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    import pytest
    from ansible.module_utils.six import PY2

    text = to_text('test')
    if PY2:
        # For py2 bytes are an instance of str and str are instances of basestring.
        # `AnsibleUnsafeBytes(text)` will raise a TypeError.
        with pytest.raises(TypeError) as error:
            UnsafeProxy(text)
        assert error.value.args[0] == "bad argument type for built-in operation"
    else:
        ansible_unsafe_text = UnsafeProxy(text)
        assert type(ansible_unsafe_text) is AnsibleUnsafeText
        assert ansible_unsafe_text == text



# Generated at 2022-06-23 14:41:21.379736
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert str(AnsibleUnsafeBytes('A')) == 'A'
    assert repr(AnsibleUnsafeBytes('A')) == "b'A'"
    assert str(AnsibleUnsafeBytes('A').decode()) == 'A'
    assert repr(AnsibleUnsafeBytes('A').decode()) == 'A'



# Generated at 2022-06-23 14:41:32.816253
# Unit test for function wrap_var
def test_wrap_var():
    class DstClass:
        pass

    var1 = 'a'
    var2 = "a"
    var3 = u'a'
    var4 = b'a'
    var5 = '''a
    a'''
    var6 = u'''a
    a'''
    var7 = 'a\na'
    var8 = u'a\na'
    var9 = 'a\\na'
    var10 = u'a\\na'
    var11 = [var1, var2, var3, var4, var5, var6, var7, var8, var9, var10]
    var12 = (var1, var2, var3, var4, var5, var6, var7, var8, var9, var10)

# Generated at 2022-06-23 14:41:36.984976
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert type(to_unsafe_bytes('foo')) is AnsibleUnsafeBytes
    assert type(to_unsafe_bytes(u'foo')) is AnsibleUnsafeBytes
    assert type(to_unsafe_bytes(1)) is AnsibleUnsafeBytes



# Generated at 2022-06-23 14:41:43.750617
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # Test the case where the object's type is actually text,
    # but the object is instance of class AnsibleUnsafeText
    data = b'\xc2\xa9'
    s = AnsibleUnsafeText(data.decode('utf-8'))
    assert (isinstance(s, text_type)), "The object's type is not text"
    assert (isinstance(s, AnsibleUnsafeText)), "The object is not instance of AnsibleUnsafeText"
    assert (isinstance(s.encode('utf-8'), AnsibleUnsafeBytes)), "The encoded object is not instance of AnsibleUnsafeBytes"

# Generated at 2022-06-23 14:41:55.610889
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    test_string = b'aGVsbG8gd29ybGQ='
    test_string_decoded = b'hello world'
    # do the base64 decoding to get original bytes
    base64_decoded = test_string.decode('base64')
    # wrap the base64 decoded bytes
    wrapped = AnsibleUnsafeBytes(base64_decoded)
    # ensure that the wrapped object is unsafe
    assert hasattr(wrapped, '__UNSAFE__'), "wrapped object is not unsafe"
    # do decoding of the wrapped object
    unsafe_decoded = wrapped.decode('base64')
    # ensure that the output is bytes
    assert isinstance(unsafe_decoded, AnsibleUnsafeBytes), "output is not an AnsibleUnsafeBytes object"
    # ensure we get the original string after decoding


# Generated at 2022-06-23 14:41:57.600623
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    var = AnsibleUnsafe()
    assert var.__UNSAFE__ is True, "AnsibleUnsafe() is not safe"

# Generated at 2022-06-23 14:41:59.896363
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes(b'test').__class__ == AnsibleUnsafeBytes


# Generated at 2022-06-23 14:42:03.336044
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    ansi_unsafe = AnsibleUnsafe()
    assert isinstance(ansi_unsafe, AnsibleUnsafe)


# Generated at 2022-06-23 14:42:08.326443
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    a = AnsibleUnsafeText('abc')
    assert type(a) is AnsibleUnsafeText
    assert type(a.encode()) is AnsibleUnsafeBytes
    b = AnsibleUnsafeText(123)
    assert type(b) is AnsibleUnsafeText
    assert type(b.encode()) is AnsibleUnsafeBytes


# Generated at 2022-06-23 14:42:12.218274
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # type: () -> None
    ansible_unsafe = AnsibleUnsafe()
    assert ansible_unsafe.__UNSAFE__ is True
    assert isinstance(ansible_unsafe, AnsibleUnsafe)



# Generated at 2022-06-23 14:42:13.693774
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe()


# Generated at 2022-06-23 14:42:16.780815
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert(isinstance(AnsibleUnsafeBytes('test'), AnsibleUnsafe))
    assert(AnsibleUnsafeBytes.__UNSAFE__)


# Generated at 2022-06-23 14:42:19.734688
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    ubs = AnsibleUnsafeBytes()
    assert type(ubs) == AnsibleUnsafeBytes
    assert isinstance(ubs.decode(), text_type)


# Generated at 2022-06-23 14:42:21.990015
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    a = "Dummy"
    result = AnsibleUnsafeText(a).encode()
    assert result == a



# Generated at 2022-06-23 14:42:26.933667
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.six import PY3

    input_string = 'abc äéï'
    expected_result = input_string if PY3 else input_string.decode('utf-8')

    assert to_unsafe_text(input_string) == expected_result

# Generated at 2022-06-23 14:42:35.247889
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    # Check result type
    assert isinstance(to_unsafe_bytes(u"hello"), AnsibleUnsafeBytes)

    # Check encoding
    assert to_text(to_unsafe_bytes(u"hello", encoding='ascii'), errors='surrogate_or_strict') == u"hello"

    # Check errors
    try:
        to_unsafe_bytes(u"\u20ac")
        assert False, "to_unsafe_bytes should have failed to encode unsupported unicode character"
    except UnicodeEncodeError:
        pass

    # Check for no change for other types
    assert to_unsafe_bytes(b"hello") == b"hello"
    assert to_unsafe_bytes(u"hello") == u"hello".encode(errors='strict')
    assert to_unsafe_bytes(None)

# Generated at 2022-06-23 14:42:37.402480
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():

    s = NativeJinjaUnsafeText('<html>Hello!</html>')
    result = s.title()
    assert result == '<html>Hello!</html>'

# Generated at 2022-06-23 14:42:39.084207
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    txt = 'a'
    res = UnsafeProxy(txt)
    assert(isinstance(res, AnsibleUnsafe))

# Generated at 2022-06-23 14:42:43.039737
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    class TestAnsibleUnsafeText_encode(AnsibleUnsafeText):
        pass
    a = TestAnsibleUnsafeText_encode()
    b = AnsibleUnsafeBytes()
    assert b == a.encode('utf-8')


# Generated at 2022-06-23 14:42:44.869073
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert isinstance(AnsibleUnsafeText("hi"), AnsibleUnsafe)


# Generated at 2022-06-23 14:42:53.716303
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils._text import to_text

    test_string = "This is a test string"
    test_bytes = to_unsafe_bytes(test_string)
    assert isinstance(test_bytes, AnsibleUnsafeBytes)
    assert test_bytes.__UNSAFE__
    assert test_bytes == to_bytes(test_string)
    assert test_bytes == "This is a test string".encode('utf-8')
    assert test_bytes == b"This is a test string"
    assert to_text(test_bytes) == to_text(test_string)



# Generated at 2022-06-23 14:43:05.745048
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import PY2

    foo = "foo"

    if PY2:
        assert isinstance(foo, str)
        assert isinstance(UnsafeProxy(foo), str)
    else:
        assert isinstance(UnsafeProxy(foo), str)

    assert isinstance(UnsafeProxy(None), type(None))
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes(b"foo")), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText("foo")), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(NativeJinjaUnsafeText("foo")), NativeJinjaUnsafeText)

    # UnsafeProxy is not meant for non-string data types, ensure this is the case

# Generated at 2022-06-23 14:43:09.723306
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # Creating an instance of class AnsibleUnsafeBytes
    bytes_obj = AnsibleUnsafeBytes(b'ABC')
    bytes_obj_decoded = bytes_obj.decode()

    assert isinstance(bytes_obj, AnsibleUnsafeBytes)
    assert isinstance(bytes_obj_decoded, AnsibleUnsafeText)
    assert bytes_obj_decoded == 'ABC'



# Generated at 2022-06-23 14:43:13.729352
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    test_text = "This is a test, see if it works."
    test_obj = NativeJinjaUnsafeText(test_text)
    assert isinstance(test_obj, AnsibleUnsafeText)
    assert isinstance(test_obj, NativeJinjaUnsafeText)
    assert test_obj == test_text

test_NativeJinjaUnsafeText()

# Generated at 2022-06-23 14:43:16.977995
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    try:
        ignore = AnsibleUnsafe()
    except TypeError as e:
        assert "object.__new__(AnsibleUnsafe)" in to_text(e)


# Generated at 2022-06-23 14:43:17.749277
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    pass

# Generated at 2022-06-23 14:43:27.263487
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.module_utils.common.text.converters import to_text, to_bytes

    utf8_char = '\xc3\x98'
    utf8_bytes = utf8_char.encode('utf-8')
    utf16_bytes = utf8_char.encode('utf-16-le')
    invalid_utf8_byte = b'\x80'

    def test_that_wraps_an_unsafe_string_or_native_jinja2_text(def_str):
        utf8_str = to_text(utf8_bytes, errors='surrogate_or_strict')

        assert type(def_str) == type(utf8_str)
       

# Generated at 2022-06-23 14:43:33.664180
# Unit test for function wrap_var
def test_wrap_var():
    # Test binary object
    binary_obj = to_bytes("abcd")
    unsafe_bytes_obj = wrap_var(binary_obj)
    assert unsafe_bytes_obj == AnsibleUnsafeBytes("abcd")
    assert isinstance(unsafe_bytes_obj, AnsibleUnsafeBytes)
    # Test unicode object
    text_obj = to_text("abcd")
    unsafe_text_obj = wrap_var(text_obj)
    assert unsafe_text_obj == AnsibleUnsafeText("abcd")
    assert isinstance(unsafe_text_obj, AnsibleUnsafeText)
    # Test a tuple
    tup_obj = (1,2,3)
    unsafe_tuple = wrap_var(tup_obj)
    assert unsafe_tuple == (1, 2, 3)

# Generated at 2022-06-23 14:43:45.202562
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    import ansible.module_utils.common.collections as cc
    from ansible.module_utils.six import PY3

    for obj in [1, 1.2, 3.14j, True, False, None, [], {}, set(), 'unicode']:
        assert isinstance(NativeJinjaUnsafeText(obj), NativeJinjaUnsafeText)
        assert isinstance(NativeJinjaUnsafeText(obj), cc.NativeJinjaText)
        if PY3:
            assert isinstance(NativeJinjaUnsafeText(obj), str)
        else:
            assert isinstance(NativeJinjaUnsafeText(obj), unicode)  # noqa F821
        assert isinstance(NativeJinjaUnsafeText(obj), AnsibleUnsafe)

# Generated at 2022-06-23 14:43:56.189554
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import BytesIO

    in_str = u'\u2713' #CHECK MARK
    in_bytes = b'\xe2\x9c\x93' #CHECK MARK in utf-8
    in_list = [in_str, in_str]
    in_dict = {in_str: in_str, in_str: in_list}
    in_tuple = (in_str, in_str)
    in_set = {in_str, in_str}
    in_file = BytesIO(in_bytes)
    in_file_iter = iter(in_file)
    in_file_iter_line = next(in_file_iter)

    result = UnsafeProxy(in_str)
    print(result.__class__)
    assert isinstance

# Generated at 2022-06-23 14:43:59.979078
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    test_string = b"test"
    test = AnsibleUnsafeBytes(test_string)
    assert test == test_string
    assert type(test) == AnsibleUnsafeBytes
    assert test.__UNSAFE__ == True

# Generated at 2022-06-23 14:44:02.634569
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    aub = AnsibleUnsafeBytes('ansible')
    assert isinstance(aub, AnsibleUnsafeBytes)
    assert 'ansible'.encode() == aub


# Generated at 2022-06-23 14:44:09.717652
# Unit test for function wrap_var
def test_wrap_var():
    # Wrap a unicode string
    assert type(wrap_var(u'foo')) is NativeJinjaUnsafeText

    # Wrap a byte string
    assert type(wrap_var(b'foo')) is AnsibleUnsafeBytes

    # Wrap a set
    assert type(wrap_var(set((u'foo', )))) is set

    # Wrap a tuple
    assert type(wrap_var((u'foo', ))) is tuple

    # Wrap a dict
    assert type(wrap_var({'k': u'foo'})) is dict

    # Wrap a list
    assert type(wrap_var(['foo'])) is list

# Generated at 2022-06-23 14:44:12.383009
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    import pytest
    j = NativeJinjaUnsafeText(u'{{ test }}')
    assert j.UNSAFE == True

# Generated at 2022-06-23 14:44:24.278418
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.six import string_types, binary_type, text_type
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE

    non_string_types = (
        int,
        float,
        BOOLEANS_TRUE,
        BOOLEANS_FALSE
    )
    non_string_dict_types = (
        Mapping,
    )

    # test args
    for non_string_type in non_string_types:
        assert isinstance(to_unsafe_bytes(non_string_type()), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:44:35.143713
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types
    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(1), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(dict()), Mapping)
    assert isinstance(to_unsafe_bytes([]), list)
    assert isinstance(to_unsafe_bytes(set()), set)
    assert is_sequence(to_unsafe_bytes(set()))
    assert isinstance(to_unsafe_bytes(u'foo'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:44:38.144706
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    class AnsibleUnsafe(object):
        pass

    ansibleUnsafe = AnsibleUnsafe()
    assert ansibleUnsafe is not None



# Generated at 2022-06-23 14:44:39.330408
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    s = '123'
    assert UnsafeProxy(s).__UNSAFE__

# Generated at 2022-06-23 14:44:41.421601
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    obj = AnsibleUnsafe()
    assert obj.__UNSAFE__


# Generated at 2022-06-23 14:44:44.054877
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText("abc").encode("ascii"), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:44:54.014793
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    import io

    class UnicodeProxy:
        def __init__(self, obj):
            self._obj = obj

        def __getattr__(self, name):
            value = getattr(self._obj, name)
            if isinstance(value, string_types):
                value = to_text(value)
            return value

        def __setattr__(self, name, value):
            if '_obj' not in self.__dict__:
                self.__dict__[name] = value
            else:
                if isinstance(value, string_types):
                    value = to_text(value)
                setattr(self._obj, name, value)

        def __str__(self):
            return str(self._obj)

        __repr__ = __str__


# Generated at 2022-06-23 14:45:02.823315
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils._text import to_bytes, to_text

    assert to_unsafe_text("crédit-card") == u"crédit-card", "Must be the original string"
    assert to_unsafe_text("crédit-card", encoding='utf-8') == "crédit-card", "Must be converted to bytestring"
    assert isinstance(to_unsafe_text("crédit-card", encoding='utf-8'), AnsibleUnsafeBytes), "Must be AnsibleUnsafeBytes"
    assert to_unsafe_text("crédit-card".encode('utf-8')) == "crédit-card".encode('utf-8'), "Must be the original string"

# Generated at 2022-06-23 14:45:12.835618
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.utils.unsafe_proxy import wrap_var, to_unsafe_bytes, to_unsafe_text

    def _remove_u(var):
        try:
            return var.replace('u', '')
        except AttributeError:
            return var

    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(42), type(42))
    assert isinstance(wrap_var(42.5), type(42.5))
    assert isinstance(wrap_var([]), list)
    assert isinstance(wrap_var(()), tuple)

# Generated at 2022-06-23 14:45:25.194807
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    # test string
    unsafeData = UnsafeProxy("this is not safe")
    assert isinstance(unsafeData, AnsibleUnsafeText)

    # test list
    unsafeData = UnsafeProxy([1, 2, 3])
    assert isinstance(unsafeData, list)
    for e in unsafeData:
        assert isinstance(e, AnsibleUnsafe)

    # test dict
    unsafeData = UnsafeProxy({"key1": "value1", "key2": "value2"})
    assert isinstance(unsafeData, dict)
    for e in unsafeData:
        assert isinstance(unsafeData[e], AnsibleUnsafeText)

    # test number and bool
    unsafeData = UnsafeProxy(1)
    assert isinstance(unsafeData, AnsibleUnsafe)


# Generated at 2022-06-23 14:45:32.817830
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible import constants as C

    test_string_list = [
        'test string',
        'test string with quotes "',
        'test string with quotes \'',
        'test string with quotes \"',
        'test string with quotes \\"',
        'test string with quotes \\'
    ]

    for test_string in test_string_list:
        if isinstance(test_string, text_type):
            test_string = test_string.encode('utf-8')
        test_native_jinja_unsafe_text = NativeJinjaUnsafeText(test_string, strict_undefined=True)
        if isinstance(test_native_jinja_unsafe_text, text_type):
            test_native_jinja_unsafe_text = test_native_jinja_unsafe_text.encode

# Generated at 2022-06-23 14:45:36.956480
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    import sys
    mystr = AnsibleUnsafeText(u"Hello World")
    assert isinstance(mystr.encode('utf-8'), AnsibleUnsafeBytes)
    assert isinstance(mystr.encode('utf-8').decode('utf-8'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:45:40.012757
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    unsafe_str = AnsibleUnsafeText('This is unsafe')
    assert unsafe_str == 'This is unsafe'
    assert isinstance(unsafe_str, AnsibleUnsafeText)


# Generated at 2022-06-23 14:45:42.741580
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    unsafe_proxy = UnsafeProxy(u'foo')
    assert type(unsafe_proxy) == AnsibleUnsafeText


# Generated at 2022-06-23 14:45:48.295187
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    s = 'text to convert'
    assert to_unsafe_bytes(s) == AnsibleUnsafeBytes(s)
    assert isinstance(to_unsafe_bytes(s), AnsibleUnsafeBytes)
    assert type(to_unsafe_bytes(s)) == AnsibleUnsafeBytes
    assert to_unsafe_bytes(s) == b'text to convert'
    assert to_unsafe_bytes(s, errors='surrogate_or_strict') == b'text to convert'

# Generated at 2022-06-23 14:46:01.612205
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(u'foo') == u'foo'
    assert isinstance(wrap_var(u'foo'), text_type)
    assert wrap_var(b'foo') == b'foo'
    assert isinstance(wrap_var(b'foo'), binary_type)
    assert wrap_var(u'foo') == u'foo'
    assert isinstance(wrap_var(u'foo'), text_type)
    assert wrap_var(1) == 1
    assert isinstance(wrap_var(1), int)
    assert wrap_var(1.0) == 1.0
    assert isinstance(wrap_var(1.0), float)
    assert wrap_var({'foo': u'bar'}) == {'foo': u'bar'}

# Generated at 2022-06-23 14:46:11.976201
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert(isinstance(to_unsafe_bytes('xyz'), AnsibleUnsafeBytes))
    assert(isinstance(to_unsafe_bytes(u'xyz'), AnsibleUnsafeBytes))
    assert(isinstance(to_unsafe_bytes(b'xyz'), AnsibleUnsafeBytes))
    assert(isinstance(to_unsafe_bytes(None), type(None)))
    assert(isinstance(to_unsafe_bytes(AnsibleUnsafeBytes(b'xyz')), AnsibleUnsafeBytes))
    assert(isinstance(to_unsafe_bytes(AnsibleUnsafeText(u'xyz')), AnsibleUnsafeBytes))


# Generated at 2022-06-23 14:46:16.241315
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    string = 'This is a test string'
    jinja_text = NativeJinjaUnsafeText(string)
    assert isinstance(jinja_text, NativeJinjaUnsafeText)
    assert isinstance(jinja_text, text_type)
    assert isinstance(jinja_text, AnsibleUnsafe)

# Generated at 2022-06-23 14:46:27.156418
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    #test with bytes
    s = b'This is a test'
    au = AnsibleUnsafeBytes(s)
    assert isinstance(au, binary_type)
    assert isinstance(au, AnsibleUnsafe)
    assert au == s
    assert au.decode() == s.decode()
    assert isinstance(au.decode(), AnsibleUnsafeText)
    #test with AnsibleUnsafeBytes
    au = AnsibleUnsafeBytes(au)
    assert isinstance(au, binary_type)
    assert isinstance(au, AnsibleUnsafe)
    assert au == s
    assert au.decode() == s.decode()
    assert isinstance(au.decode(), AnsibleUnsafeText)
    #test with bytes and unsafe_bytes=False

# Generated at 2022-06-23 14:46:34.797328
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    from ansible.module_utils.common.compat import PY2

    content_string = "Hello World"
    unsafe_text = AnsibleUnsafeText(content_string)

    assert isinstance(unsafe_text, text_type)

    if PY2:
        assert isinstance(unsafe_text.encode(), binary_type)
    else:
        assert unsafe_text.encode() == unsafe_text



# Generated at 2022-06-23 14:46:37.328420
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    expected_result = 'Abcd'
    result = UnsafeProxy(expected_result)
    assert result == expected_result


# Generated at 2022-06-23 14:46:43.217574
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    ansi_text = AnsibleUnsafeText('test')
    ansi_bytes = ansi_text.encode('utf-8')
    assert( isinstance(ansi_bytes, AnsibleUnsafeBytes))
    ansi_text = ansi_bytes.decode('utf-8')
    assert( isinstance(ansi_text, AnsibleUnsafeText))

# Generated at 2022-06-23 14:46:53.392470
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from unittest import TestCase

    class TestUnsafes(TestCase):
        def test_unsafe_bytes(self):
            data = wrap_var(b'\xe9')

# Generated at 2022-06-23 14:47:04.820284
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text('this string'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(None), type(None))
    assert isinstance(to_unsafe_text(''), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'bytes'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(0), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(dict(a=1)), dict)
    assert isinstance(to_unsafe_text([1, 2]), list)
    assert isinstance(to_unsafe_text(set([1, 2])), set)
    assert isinstance(to_unsafe_text(AnsibleUnsafeText('test')), AnsibleUnsafeText)

# Generated at 2022-06-23 14:47:16.944561
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils._text import to_bytes, to_text

    assert wrap_var(None) is None
    assert wrap_var('hello') == AnsibleUnsafeText(u'hello')
    assert wrap_var(u'hello') == AnsibleUnsafeText(u'hello')
    assert wrap_var(b'hello') == AnsibleUnsafeBytes(b'hello')
    assert wrap_var(b'\x00\x7f\xff') == AnsibleUnsafeBytes(b'\x00\x7f\xff')
    assert wrap_var(dict(a=1, b='foo')) == AnsibleUnsafeText(u"{'a': 1, 'b': u'foo'}")

# Generated at 2022-06-23 14:47:25.995355
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy(None), AnsibleUnsafe)
    assert isinstance(UnsafeProxy("str"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy("str".encode("utf-8")), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy({}), dict)
    assert isinstance(UnsafeProxy([]), list)
    assert isinstance(UnsafeProxy(()), tuple)
    assert isinstance(UnsafeProxy(set()), set)
    assert isinstance(UnsafeProxy(NativeJinjaText("str")), NativeJinjaUnsafeText)

# Generated at 2022-06-23 14:47:27.814934
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText(u'abc').encode(), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:47:31.504643
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    ansible_unsafe_bytes = AnsibleUnsafeBytes(b'test')
    assert isinstance(ansible_unsafe_bytes, AnsibleUnsafe)
    assert isinstance(ansible_unsafe_bytes, binary_type)


# Generated at 2022-06-23 14:47:32.712274
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    t = AnsibleUnsafeText("Test")
    assert(isinstance(t.encode("utf8"), AnsibleUnsafeBytes))


# Generated at 2022-06-23 14:47:40.042382
# Unit test for function wrap_var
def test_wrap_var():
    import json
    import unittest

    class Test(unittest.TestCase):
        def _assert_equal(self, v1, v2):
            self.assertTrue(isinstance(v1, AnsibleUnsafeBytes))
            self.assertTrue(isinstance(v2, AnsibleUnsafeBytes))
            self.assertEqual(v1, v2)
            v1_decoded = v1.decode('utf-8')
            v2_decoded = v2.decode('utf-8')
            self.assertEqual(v1_decoded, v2_decoded)
            self.assertTrue(isinstance(v1_decoded, text_type))
            self.assertTrue(isinstance(v2_decoded, text_type))


# Generated at 2022-06-23 14:47:43.456155
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    ansible_unsafe_bytes = AnsibleUnsafeBytes()
    result = ansible_unsafe_bytes.decode()
    assert isinstance(result, AnsibleUnsafeText)


# Generated at 2022-06-23 14:47:50.093712
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    ansible_unsafe_text = UnsafeProxy('foo')
    assert isinstance(ansible_unsafe_text, AnsibleUnsafeText)
    assert not isinstance(ansible_unsafe_text, AnsibleUnsafeBytes)
    assert ansible_unsafe_text == 'foo'
    assert ansible_unsafe_text.__UNSAFE__ is True
    assert id(ansible_unsafe_text) != id('foo')

# Generated at 2022-06-23 14:47:57.324729
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    UNSAFE_STR = b'\xe4\xbd\xa0\xe5\xa5\xbd'
    UNSAFE_STR_DECODE_UTF8 = to_text(UNSAFE_STR)
    UNSAFE_STR_DECODE_GBK = to_text(UNSAFE_STR, encoding='gbk', errors='ignore')
    UNSAFE_STR_DECODE_GBK_UNICODE = to_text(UNSAFE_STR_DECODE_GBK)

    assert UNSAFE_STR_DECODE_GBK_UNICODE == to_text(UNSAFE_STR, encoding='gbk', errors='ignore')


# Generated at 2022-06-23 14:48:06.228308
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    """Check that to_unsafe_text is idempotent"""
    from ansible.utils._text import to_text
    from ansible.module_utils.six import text_type
    assert to_unsafe_text(to_unsafe_text(to_text(b'hi'))) == to_text(b'hi')
    assert to_unsafe_text(to_unsafe_text(u'hi')) == u'hi'
    assert isinstance(to_unsafe_text(to_text(b'hi')), text_type)