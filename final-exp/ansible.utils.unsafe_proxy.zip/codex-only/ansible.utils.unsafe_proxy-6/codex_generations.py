

# Generated at 2022-06-23 14:38:15.122821
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy(None), type(None))
    assert isinstance(UnsafeProxy(1), type(1))
    assert isinstance(UnsafeProxy(1.1), type(1.1))
    assert isinstance(UnsafeProxy(u'foobar'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy('foobar'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy([]), list)
    assert isinstance(UnsafeProxy((None,)), tuple)
    assert isinstance(UnsafeProxy(set()), set)
    assert isinstance(UnsafeProxy({}), dict)



# Generated at 2022-06-23 14:38:22.620451
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    import unittest

    class Test_AnsibleUnsafeText_encode(unittest.TestCase):
        def test_AnsibleUnsafeText_encode_from_unicode(self):
            u_str = u'test_str'
            ansi_unsafe_text = AnsibleUnsafeText(u_str)
            b_str = ansi_unsafe_text.encode(encoding='utf-8')
            self.assertTrue(isinstance(b_str, AnsibleUnsafeBytes))

        def test_AnsibleUnsafeText_encode_from_AnsibleUnsafeText(self):
            u_str = u'test_str'
            ansi_unsafe_text = AnsibleUnsafeText(u_str)
            b_str = ansi_unsafe_text.encode

# Generated at 2022-06-23 14:38:32.935489
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(b'\xe7\xb6\x9c\xe8\x97\x85'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'\u7d22\u8def'), AnsibleUnsafeText)

    # -*- Encoding: Latin-1 -*-
    assert isinstance(to_unsafe_text(b'\xe7\xb6\x9c\xe8\x97\x85', encoding='latin-1'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'\u7d22\u8def', encoding='latin-1'), AnsibleUnsafeText)


# Generated at 2022-06-23 14:38:39.324647
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    string = "Hello World!"
    s = AnsibleUnsafeText(string)
    assert (isinstance(s, AnsibleUnsafeText))
    assert (isinstance(s, AnsibleUnsafe))
    assert (isinstance(s, text_type))
    assert (s == string)
    assert (s == "Hello World!")


# Generated at 2022-06-23 14:38:41.325983
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    unsafe_text = AnsibleUnsafeText('foo')
    result = unsafe_text.encode()
    assert type(result) == AnsibleUnsafeBytes
    assert result == b'foo'



# Generated at 2022-06-23 14:38:48.919184
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    t=AnsibleUnsafeText("Hello_AnsibleUnsafeText")
    t.encode("UTF-8")
    ansible_unsafe_str=str(t);
    if ansible_unsafe_str == "Hello_AnsibleUnsafeText":
        return 1
    return 0
try:
    if test_AnsibleUnsafeText_encode():
        print("\nSuccessfully tested the method encode of class AnsibleUnsafeText")
    else:
        print("\nMethod encode of class AnsibleUnsafeText failed to pass the test")
except NameError:
    print("\nFile 'ansible_unsafe.py' missing the class AnsibleUnsafeText and/or method encode")
    pass


# Generated at 2022-06-23 14:38:53.420623
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():

    s = NativeJinjaUnsafeText("{}")
    assert '__UNSAFE__' in dir(s)
    assert 'encode' in dir(s)
    assert type(s) is NativeJinjaUnsafeText


# Generated at 2022-06-23 14:38:57.778721
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    unsafe_b = to_unsafe_bytes('é')
    assert isinstance(unsafe_b, AnsibleUnsafeBytes)
    assert isinstance(unsafe_b.decode(), AnsibleUnsafeText)


# Generated at 2022-06-23 14:39:08.947507
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    import ansible.module_utils.basic
    class MyModule:
        def __init__(self):
            self.module_args = {}
            self.check_mode = False
            self.debug = True
    mymodule = MyModule()
    mymodule.module_args['validate_certs'] = False
    assert to_unsafe_bytes(mymodule, 'validate_certs') is False
    mymodule.module_args['validate_certs'] = True
    assert to_unsafe_bytes(mymodule, 'validate_certs') is True
    mymodule.module_args['validate_certs'] = 'yes'
    assert to_unsafe_bytes(mymodule, 'validate_certs') is True
    mymodule.module_args['force'] = 'yes'
    assert to_unsafe

# Generated at 2022-06-23 14:39:19.993823
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy(42), int)
    assert isinstance(UnsafeProxy('ansible'), str)
    assert isinstance(UnsafeProxy(text_type('ansible')), text_type)
    assert isinstance(UnsafeProxy(binary_type('ansible')), binary_type)
    assert isinstance(UnsafeProxy(tuple('ansible')), tuple)
    assert isinstance(UnsafeProxy(set('ansible')), set)
    assert isinstance(UnsafeProxy(list('ansible')), list)
    assert isinstance(UnsafeProxy(dict(a=1, b=2)), dict)
    assert isinstance(UnsafeProxy(dict(a=1, b=2).items()), list)
    assert isinstance(UnsafeProxy(dict(a=1, b=2).items()), list)

# Generated at 2022-06-23 14:39:28.892669
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    a=AnsibleUnsafeText("test")
    assert isinstance(a,AnsibleUnsafeText)
    assert a == "test"
    assert isinstance(a.encode('utf-8'), AnsibleUnsafeBytes)
    #assert a.encode('utf-8') == b'test'
    #assert isinstance(a.encode('utf-8').decode('utf-8'), AnsibleUnsafeText)
    #assert a.encode('utf-8').decode('utf-8') == "test"


test_AnsibleUnsafeText()

# Generated at 2022-06-23 14:39:38.235180
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text

    utf8_b_obj = b'foo'
    utf8_native_string = 'foo'
    utf8_unicode_string = to_text(utf8_b_obj)
    utf8_jinja_text_string = NativeJinjaText('foo')
    utf8_unsafe_string = AnsibleUnsafeText('foo')
    utf8_jinja_unsafe_string = NativeJinjaUnsafeText('foo')

    ascii_b_obj = b'bar'
    ascii_native_string = 'bar'
    ascii_unicode_string = to_text(ascii_b_obj)
    ascii_jin

# Generated at 2022-06-23 14:39:46.525873
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():

    unsafe_proxy1 = UnsafeProxy("my string")
    assert isinstance(unsafe_proxy1,  AnsibleUnsafeText)

    unsafe_proxy2 = UnsafeProxy("my string".encode('utf-8'))
    assert isinstance(unsafe_proxy2,  AnsibleUnsafeBytes)

    unsafe_proxy3 = UnsafeProxy(None)
    assert unsafe_proxy3 is None

    unsafe_proxy4 = UnsafeProxy("my value")
    assert UnsafeProxy(unsafe_proxy4) == unsafe_proxy4


# Generated at 2022-06-23 14:39:57.722661
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('bytes') == b'bytes'
    assert to_unsafe_bytes('unicode', encoding='utf-8') == b'unicode'
    assert to_unsafe_bytes('unicode', encoding='utf-8', errors='strict') == b'unicode'
    assert to_unsafe_bytes(u'unicode', encoding='utf-8', errors='strict') == b'unicode'
    assert to_unsafe_bytes({'x': 'y'}, encoding='utf-8', errors='strict') == b"{'x': 'y'}"
    assert to_unsafe_bytes(u'\ua000', encoding='utf-8', errors='strict') == u'\ua000'.encode('utf-8')

# Generated at 2022-06-23 14:40:02.388251
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    # Call constructor of class UnsafeProxy
    u = UnsafeProxy('xx')
    # Check if object is of class AnsibleUnsafeText
    assert isinstance(u, AnsibleUnsafeText)
    # Check if object is of class AnsibleUnsafe
    assert isinstance(u, AnsibleUnsafe)


# Generated at 2022-06-23 14:40:06.689676
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(None), type(None)), 'The result of None input should be None'
    assert isinstance(to_unsafe_text('abc'), AnsibleUnsafeText), 'The result of unsafe string input should be unsafetext'

# Generated at 2022-06-23 14:40:19.150221
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():

    test_str = "test string"
    test_bytes = b"test string"
    test_unicode = u"test string"
    test_list = ['test', 'string']
    test_dict = {'key': 'value'}
    test_tuple = ('test', 'string')

    assert isinstance(UnsafeProxy(test_str), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(test_bytes), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(test_unicode), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(test_list), list)
    assert isinstance(UnsafeProxy(test_dict), dict)
    assert isinstance(UnsafeProxy(test_tuple), list)


# Generated at 2022-06-23 14:40:22.201492
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    class AnsibleUnsafeChild(AnsibleUnsafe):
        pass
    assert AnsibleUnsafe().__UNSAFE__ == True
    assert AnsibleUnsafeChild().__UNSAFE__ == True


# Generated at 2022-06-23 14:40:29.400739
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.module_utils.six import StringIO

    # Test for to_text
    try:
        to_text(1)
    except TypeError as e:
        if e.args[0] == "'int' object is not iterable":
            pass
        else:
            assert(False)

    # Test for to_text
    try:
        to_text(Mapping())
    except TypeError as e:
        if e.args[0] == "'collections.Mapping' object is not iterable":
            pass
        else:
            assert(False)

    # Test for to_text

# Generated at 2022-06-23 14:40:34.273394
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    sample_text = 'test'
    if isinstance(sample_text, text_type):
        assert isinstance(to_unsafe_text(sample_text), AnsibleUnsafeText)
    else:
        assert isinstance(to_unsafe_text(sample_text), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:40:39.251196
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(u'foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(AnsibleUnsafeText(u'foo')), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeText)

# Generated at 2022-06-23 14:40:49.930647
# Unit test for function wrap_var
def test_wrap_var():
    """
    This unit test should be modified whenever new functionality is added to
    wrap_var.

    This checks that the variable conversion functions all behave as expected.
    """
    import types
    import os
    import tempfile
    import unittest
    from ansible.module_utils._text import to_bytes, to_text

    class TestWrapVar(unittest.TestCase):
        # Unfortunately the proxy object is not comparable, so we have to
        # wrap the assertEqual to unwrap the objects before comparing.
        def assertEqualX(self, arg1, arg2):
            self.assertEqual(arg1, arg2)


# Generated at 2022-06-23 14:40:52.225934
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    expectedClass = AnsibleUnsafeText
    actualClass = AnsibleUnsafeText("test")
    assert type(actualClass) == expectedClass


# Generated at 2022-06-23 14:40:53.896239
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # type: () -> None
    assert str(AnsibleUnsafe()) == "<AnsibleUnsafe>"



# Generated at 2022-06-23 14:41:01.884339
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.utils.display import Display
    display = Display()
    test_input = {u'warble': u'test'}
    result = to_unsafe_bytes(test_input)
    if not isinstance(result, dict):
        display.error("to_unsafe_bytes dict conversion failed")
    elif not isinstance(result[u'warble'], AnsibleUnsafeBytes):
        display.error("to_unsafe_bytes value conversion failed")
    test_input = [b'garbletest']
    result = to_unsafe_bytes(test_input)
    if not isinstance(result, list):
        display.error("to_unsafe_bytes list conversion failed")

# Generated at 2022-06-23 14:41:04.683266
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    s = AnsibleUnsafeText("test")
    assert s.encode("utf-8") == b"test"
    assert s == "test"

# Generated at 2022-06-23 14:41:10.977857
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.errors import AnsibleError

    # Test constructor with value
    assert 'Right' == str(NativeJinjaUnsafeText('Right'))
    # Test constructor with value and name
    assert 'Right' == str(NativeJinjaUnsafeText('Right', name='Answer'))
    # Test constructor without value
    try:
        NativeJinjaUnsafeText()
    except AnsibleError as e:
        assert 'value must be provided' in str(e)


# Generated at 2022-06-23 14:41:23.305045
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    import unittest
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.utils.native_jinja import Template

    class TestNativeJinjaUnsafeText(unittest.TestCase):
        def test_1(self):
            jinja_code = "${{ a }}"
            a = 'x'
            assert str(NativeJinjaUnsafeText(jinja_code, variables={'a': a})) == 'x'

        def test_2(self):
            jinja_code = "${{ a }}"
            a = 'x'
            assert str(NativeJinjaUnsafeText(jinja_code, variables={'a': a})) == 'x'

# Generated at 2022-06-23 14:41:29.277052
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # UnsafeProxy(obj: Any) -> AnsibleUnsafe
    # Tests that no matter what is passed in, it returns an AnsibleUnsafe

    # test_proxy_string
    assert isinstance(UnsafeProxy("test"), AnsibleUnsafe)

    # test_proxy_int
    assert isinstance(UnsafeProxy(1), AnsibleUnsafe)

    # test_proxy_float
    assert isinstance(UnsafeProxy(1.0), AnsibleUnsafe)

    # test_proxy_bytes
    assert isinstance(UnsafeProxy(b"test"), AnsibleUnsafe)

    # test_proxy_none
    assert isinstance(UnsafeProxy(None), AnsibleUnsafe)

    # test_proxy_dict
    assert isinstance(UnsafeProxy({"a": "b"}), AnsibleUnsafe)

    # test_proxy

# Generated at 2022-06-23 14:41:36.985340
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    """
    Validate that to_unsafe_bytes() does not return unsafe strings when
    converting from text to bytes and vice-versa
    """
    from ansible.utils.unsafe_proxy import UnsafeText, UnsafeBytes

    # convert from text to bytes
    result = to_unsafe_bytes('a')
    assert not isinstance(result, UnsafeBytes)

    # convert from bytes to text
    result = to_unsafe_bytes(b'a')
    assert not isinstance(result, UnsafeText)


# Generated at 2022-06-23 14:41:44.760972
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    str1 = b'Hello World'
    str2 = 'Hello World'
    str3 = u'Hello World'
    str4 = AnsibleUnsafeText(str2)
    str5 = AnsibleUnsafeBytes(str1)
    assert to_unsafe_text(str1) is str5
    assert to_unsafe_text(str2) is str4
    assert to_unsafe_text(str3) is str3
    assert str5 is str1
    assert str4 is str2
    assert str3 is str3
    assert to_unsafe_bytes(str4) is str4
    assert to_unsafe_bytes(str3) is str3
    assert str4 is str2
    assert str3 is str3

# Generated at 2022-06-23 14:41:56.352024
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    """
    Tests that the __new__ method in UnsafeProxy is instantiating the
    correct class based on the type and subclass of the passed in obj
    """
    class TestBinary(binary_type):
        pass

    class TestText(text_type):
        pass

    assert isinstance(UnsafeProxy(b"foo"), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(u"foo"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(TestBinary(b"foo")), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(TestText(u"foo")), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy("foo"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(u"foo"), AnsibleUnsafeText)

    # Test that an unsafe object

# Generated at 2022-06-23 14:42:08.281618
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.unsafe_proxy import UnsafeProxy
    from ansible.utils.hashing import checksum_s

    # Create a simple data structure to test on
    data = {
        'b': -1,
        'c': [1, 2],
        'd': {
            'e': [3, 4],
            'f': {
                'g': 5,
                'h': [],
            }
        }
    }

    # Validate that the data structure was created correctly
    assert checksum_s(data) == 'e622d789b19a49d9da9b8a91b1a70c73f591e53c'

    # Check that the data structure is not unsafe
    assert not hasattr(data, '__UNSAFE__')

    # Wrap the data structure and validate that

# Generated at 2022-06-23 14:42:17.483968
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # test without argument
    obj = AnsibleUnsafeText()
    assert obj is not None
    assert obj.__UNSAFE__ == True
    assert obj == ""
    # test with argument
    obj = AnsibleUnsafeText("hello world!")
    assert obj is not None
    assert obj.__UNSAFE__ == True
    assert obj == "hello world!"
    # test encode
    b = obj.encode()
    assert isinstance(b, AnsibleUnsafeBytes)
    assert b == b"hello world!"
    # test decode
    s = b.decode()
    assert isinstance(s, AnsibleUnsafeText)
    assert s == "hello world!"

# Generated at 2022-06-23 14:42:21.190219
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    in_str = u'test'
    out_str = to_unsafe_text(in_str)
    assert isinstance(out_str, AnsibleUnsafeText)
    assert out_str == in_str


# Generated at 2022-06-23 14:42:24.441885
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    """Test the constructor of AnsibleUnsafeBytes"""
    obj = AnsibleUnsafeBytes('foo')
    assert isinstance(obj, binary_type)
    assert isinstance(obj, AnsibleUnsafe)


# Generated at 2022-06-23 14:42:35.132570
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils._text import to_bytes, to_text

    test_unicode = to_text(u'unicode: \u2713')
    test_bytes = to_bytes(b'bytes: \xe2\x9c\x93')

    test_ansible_unsafe_bytes = to_unsafe_bytes(test_bytes)
    test_ansible_unsafe_unicode = to_unsafe_text(test_unicode)

    test_unsafe_proxy_bytes = UnsafeProxy(test_bytes)
    test_unsafe_proxy_unicode = UnsafeProxy(test_unicode)

    assert isinstance(test_unsafe_proxy_bytes, AnsibleUnsafeBytes)
    assert isinstance

# Generated at 2022-06-23 14:42:36.997745
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy is not None
    # TODO: Write this unit test!
    print('Test not implemented')



# Generated at 2022-06-23 14:42:39.014501
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    test_str = NativeJinjaUnsafeText("{{test}}")
    assert test_str == "{{test}}"
    assert isinstance(test_str, AnsibleUnsafeText)

# Generated at 2022-06-23 14:42:40.009211
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert "UnsafeProxy is being deprecated" in UnsafeProxy(None)

# Generated at 2022-06-23 14:42:43.547443
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert to_unsafe_text('{"foo": "bar"}') == to_text('{"foo": "bar"}')
    assert to_unsafe_bytes('{"foo": "bar"}') == to_bytes('{"foo": "bar"}')



# Generated at 2022-06-23 14:42:54.770067
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.display import Display
    from mock import patch
    import ansible.module_utils.common.warnings
    from contextlib import nested
    Display_instance = Display()
    Display.deprecated = Display_instance.deprecated
    Display.deprecated.__code__ = Display_instance.deprecated.__code__
    Display.deprecated.__defaults__ = Display_instance.deprecated.__defaults__
    Display.deprecated.__kwdefaults__ = Display_instance.deprecated.__kwdefaults__
    Display.deprecated.__closure__ = Display_instance.deprecated.__closure__

# Generated at 2022-06-23 14:43:00.670010
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert(AnsibleUnsafe().__UNSAFE__)
    assert(AnsibleUnsafeText("").__UNSAFE__)
    assert(AnsibleUnsafeBytes("").__UNSAFE__)
    assert(AnsibleUnsafeText("").__UNSAFE__)
    assert(AnsibleUnsafeBytes("").__UNSAFE__)

# Generated at 2022-06-23 14:43:04.322720
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    text = AnsibleUnsafeText("test")

    if not isinstance(text, text_type):
        raise AssertionError("Text created by AnsibleUnsafeText is not an instance of text_type!")

    if not isinstance(text, AnsibleUnsafe):
        raise AssertionError("Text created by AnsibleUnsafeText is not an instance of AnsibleUnsafe!")



# Generated at 2022-06-23 14:43:08.296112
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    s = to_bytes('test')
    assert not s.__UNSAFE__
    assert UnsafeProxy(s).encode() == s
    assert UnsafeProxy(s).__UNSAFE__
    assert UnsafeProxy(s).encode() == s

# Generated at 2022-06-23 14:43:10.252286
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    foo = AnsibleUnsafeText('foo').encode('utf-8')
    assert isinstance(foo, AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:43:17.379830
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # test for AnsibleUnsafeText is subclass of AnsibleUnsafe
    assert issubclass(AnsibleUnsafeText, AnsibleUnsafe)
    # test for AnsibleUnsafeText is subclass of str
    assert issubclass(AnsibleUnsafeText, str)
    # test for AnsibleUnsafeText is subclass of text_type
    assert issubclass(AnsibleUnsafeText, text_type)


# Generated at 2022-06-23 14:43:19.689317
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    unsafe_text = AnsibleUnsafeText("abc")
    assert isinstance(unsafe_text.encode(), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:43:21.126413
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes('test') == 'test'.encode()


# Generated at 2022-06-23 14:43:26.432543
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert(AnsibleUnsafeBytes('test') == b'test')

    assert(AnsibleUnsafeBytes('test').decode() == 'test')

    assert(isinstance(AnsibleUnsafeBytes('test'), AnsibleUnsafeBytes))
    assert(isinstance(AnsibleUnsafeBytes('test'), binary_type))
    assert(isinstance(AnsibleUnsafeBytes('test'), AnsibleUnsafe))


# Generated at 2022-06-23 14:43:36.939830
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.unsafe_proxy import UnsafeProxy
    assert issubclass(AnsibleUnsafeText, text_type)
    assert issubclass(AnsibleUnsafeBytes, binary_type)

    assert UnsafeProxy('bytes').startswith('bytes')
    assert UnsafeProxy('string').startswith('string')
    assert UnsafeProxy(b'bytes').startswith('bytes')
    assert isinstance(UnsafeProxy('bytes'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy('string'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'bytes'), AnsibleUnsafeText)



# Generated at 2022-06-23 14:43:38.851526
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    unsafeText = "unsafe"
    a = AnsibleUnsafeText(unsafeText)
    assert a == unsafeText

# Generated at 2022-06-23 14:43:44.214766
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    ansible_unsafe_bytes = AnsibleUnsafeBytes(b'bytes')
    ansible_unsafe_text = ansible_unsafe_bytes.decode()
    assert isinstance(ansible_unsafe_text, AnsibleUnsafeText)
    assert ansible_unsafe_text == 'bytes'



# Generated at 2022-06-23 14:43:49.445601
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    s = AnsibleUnsafeBytes(b'foo')
    assert isinstance(s, AnsibleUnsafeBytes)
    assert isinstance(s, binary_type)
    assert isinstance(s, AnsibleUnsafe)
    assert s == b'foo'
    assert s.decode() == 'foo'



# Generated at 2022-06-23 14:43:55.025542
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    import pytest
    assert isinstance(to_unsafe_bytes(b'hi'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u'hi'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(None), type(None))
    with pytest.raises(TypeError):
        to_unsafe_bytes(['a', 'list'])



# Generated at 2022-06-23 14:44:04.896941
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    import unittest
    import types

    class AnsibleProxyTestCase(unittest.TestCase):

        def test_UnsafeProxy(self):
            self.assertTrue(isinstance(UnsafeProxy('foo'), text_type))
            self.assertTrue(isinstance(UnsafeProxy(b'foo'), binary_type))
            self.assertTrue(isinstance(UnsafeProxy(u'foo'), text_type))
            proxy = UnsafeProxy('foo')
            self.assertTrue(isinstance(proxy.__class__, types.ClassType))

    suite = unittest.TestLoader().loadTestsFromTestCase(AnsibleProxyTestCase)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-23 14:44:12.166972
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():

    from ansible.module_utils.six import b
    assert to_unsafe_bytes("abc") == b("abc")
    assert to_unsafe_bytes("abc", "utf-8") == b("abc")
    assert to_unsafe_bytes("abc", "ascii") == b("abc")
    assert to_unsafe_bytes("a\xe7", "utf-8") == b("a\xe7")
    assert to_unsafe_bytes("a\xe7", "ascii") == b("a\xe7")
    assert to_unsafe_bytes("ß", "latin-1") == b("\xdf")
    assert to_unsafe_bytes("ß", "latin-1", errors="surrogate_or_strict") == b("\xdf")

    # Issue 10991
   

# Generated at 2022-06-23 14:44:21.075062
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    # Test with multiple input arguments
    assert isinstance(to_unsafe_text('Hello', 'World'), AnsibleUnsafeText)
    # Test with no input arguments
    assert isinstance(to_unsafe_text(), AnsibleUnsafeText)
    # Test with **kwargs
    assert isinstance(to_unsafe_text(errors='ignore'), AnsibleUnsafeText)
    # Test for error returned by module_utils._text.to_text
    assert isinstance(to_unsafe_text(errors='surrogate'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:44:22.142318
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe()



# Generated at 2022-06-23 14:44:33.378358
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    bytes_obj = AnsibleUnsafeBytes()
    assert isinstance(bytes_obj, binary_type)
    assert isinstance(bytes_obj, AnsibleUnsafe)
    assert bytes_obj == b''

    bytes_obj2 = AnsibleUnsafeBytes(b'hello')
    assert bytes_obj2 == b'hello'

    # test the decode method
    txt_obj = bytes_obj2.decode()
    assert isinstance(txt_obj, text_type)
    assert isinstance(txt_obj, AnsibleUnsafe)
    assert txt_obj == u''

    # test the encode method
    bytes_obj3 = txt_obj.encode()
    assert isinstance(bytes_obj3, binary_type)
    assert isinstance(bytes_obj3, AnsibleUnsafe)
    assert bytes_obj3

# Generated at 2022-06-23 14:44:38.459115
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    n_text = NativeJinjaUnsafeText("test")
    assert isinstance(n_text, binary_type)
    assert isinstance(n_text, AnsibleUnsafeText)
    assert isinstance(n_text, NativeJinjaText)
    assert isinstance(n_text, NativeJinjaUnsafeText)



# Generated at 2022-06-23 14:44:41.934207
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafeText(u'abc')
    assert AnsibleUnsafeText('abc')
    assert AnsibleUnsafeBytes(u'abc')
    assert AnsibleUnsafeBytes('abc')



# Generated at 2022-06-23 14:44:52.422101
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text('foo') == wrap_var(to_text('foo'))
    assert to_unsafe_text(u'foo') == wrap_var(to_text(u'foo'))
    assert to_unsafe_text('foo'.encode()) == wrap_var(to_text('foo'))
    assert to_unsafe_text(b'foo') == wrap_var(to_text('foo'))
    assert to_unsafe_text(u'foo'.encode()) == wrap_var(to_text('foo'))
    assert to_unsafe_text(b'foo'.decode()) == wrap_var(to_text('foo'))
    assert to_unsafe_text(u'foo', errors="strict") == wrap_var(to_text(u'foo', errors="strict"))

# Generated at 2022-06-23 14:44:55.306829
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    result = NativeJinjaUnsafeText('hello world')
    assert isinstance(result, NativeJinjaUnsafeText)
    assert str(result) == 'hello world'
    assert result.__UNSAFE__ == True

# Generated at 2022-06-23 14:45:01.856421
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes(b'to_unsafe_bytes') == b'to_unsafe_bytes'
    assert to_unsafe_bytes(u'to_unsafe_bytes') == b'to_unsafe_bytes'
    assert to_unsafe_bytes(1000) == b'1000'
    assert to_unsafe_bytes([1000]) == b'[1000]'
    assert to_unsafe_bytes({"a": 100}) == b"{'a': 100}"
    assert to_unsafe_bytes(True) == b'True'


# Generated at 2022-06-23 14:45:08.693427
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():

    from nose.tools import assert_equal
    from ansible.module_utils.common.collections import is_sequence

    test_dict = {'k1': 'v1', 'k2': 'v2'}
    test_list = [1, 2, 3]
    test_set = set([1, 2, 3])
    test_text = 'test'

    assert_equal(test_dict, wrap_var(test_dict))
    assert_equal(test_list, wrap_var(test_list))
    assert_equal(test_set, wrap_var(test_set))
    assert_equal(test_text, wrap_var(test_text))

    # Test recursive wrapping
    test_list = wrap_var(test_list)
    assert_equal(test_list, wrap_var(test_list))
   

# Generated at 2022-06-23 14:45:09.709097
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe.__UNSAFE__ is True

# Generated at 2022-06-23 14:45:14.582356
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    testtext = 'this is a test'
    testbytes = bytes(testtext.encode('utf-8'))
    assert isinstance(testbytes, bytes)
    testobj = AnsibleUnsafeBytes(testbytes)
    assert isinstance(testobj, AnsibleUnsafeBytes)
    resultobj = testobj.decode()
    assert isinstance(resultobj, AnsibleUnsafeText)
    resulttext = resultobj
    assert isinstance(resulttext, str)
    assert resulttext == testtext



# Generated at 2022-06-23 14:45:18.200851
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    foo = b'foo'
    foo_unsafe = AnsibleUnsafeBytes(foo)
    assert foo_unsafe.decode() == foo.decode()
    assert foo_unsafe.decode() == foo

# Generated at 2022-06-23 14:45:22.262876
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    import sys

    if sys.version_info[1] >= 6 and sys.version_info[0] >= 3:
        assert isinstance(NativeJinjaUnsafeText(""), NativeJinjaText)

# Generated at 2022-06-23 14:45:24.548072
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    test = AnsibleUnsafeText(u'test')
    assert(test.encode() == b"test")


# Generated at 2022-06-23 14:45:26.536193
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    txt = 'testing'
    utxt = AnsibleUnsafeText(txt)
    assert utxt == txt


# Generated at 2022-06-23 14:45:33.320338
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    # Test that a str converts to an AnsibleUnsafe
    s = "test"
    assert isinstance(to_unsafe_text(s), AnsibleUnsafeText)
    s = b"test"
    assert isinstance(to_unsafe_text(s), AnsibleUnsafeText)
    # Test that an AnsibleUnsafe doesn't get converted
    s = AnsibleUnsafeText("test")
    assert isinstance(to_unsafe_text(s), AnsibleUnsafeText)
    # Test that a list of strings is properly converted
    s = [b"test", "test"]
    assert isinstance(to_unsafe_text(s)[0], AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(s)[1], AnsibleUnsafeText)
    # Test that a list of AnsibleUnsafe

# Generated at 2022-06-23 14:45:38.138172
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.utils.unsafe_proxy import NativeJinjaUnsafeText
    a = '\u8fc8\u514b\u4e4b\u6d77'.encode('u8')
    b = NativeJinjaUnsafeText(a)
    c = b.encode('u8')
    assert c == a

# Generated at 2022-06-23 14:45:48.433083
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():

    class TestClass():
        def __init__(self, val):
            self.val = val

        def __eq__(self, other):
            return self.val == other.val

    obj = TestClass('test')
    unsafe_proxy = UnsafeProxy(obj)

    # TestClass might not be a text_type or bytes type, but it should
    # not be an AnsibleUnsafe type
    assert isinstance(obj, TestClass)
    assert not isinstance(obj, (text_type, bytes))
    assert not isinstance(obj, AnsibleUnsafe)

    # After creation, the object should be an AnsibleUnsafe type
    assert isinstance(unsafe_proxy, TestClass)
    assert not isinstance(unsafe_proxy, (text_type, bytes))
    assert isinstance(obj, AnsibleUnsafe)


# Generated at 2022-06-23 14:45:48.998755
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert True

# Generated at 2022-06-23 14:45:49.847850
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    AnsibleUnsafeBytes('hello').decode()

# Generated at 2022-06-23 14:45:54.500360
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b"foobar").decode(), AnsibleUnsafeText)
    assert AnsibleUnsafeBytes(b"foobar").decode() == AnsibleUnsafeText(u"foobar")

# Generated at 2022-06-23 14:46:05.121897
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    # test text type
    str_var = 'This is a test sentence'
    str_var_unsafe = '{{ var }}'
    safe_str_var = to_unsafe_text(str_var)
    safe_str_var2 = to_unsafe_text(str_var_unsafe)
    # text type
    assert isinstance(safe_str_var, AnsibleUnsafeText)
    assert isinstance(safe_str_var2, AnsibleUnsafeText)
    # content
    assert safe_str_var == str_var
    assert safe_str_var2 == str_var_unsafe

    # test binary type
    binary_var = b'This is a test sentence'
    binary_var_unsafe = b'{{ var }}'

# Generated at 2022-06-23 14:46:15.073240
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY3, b
    data = '\xc3\xa9\xc3\xa0'
    if PY3:
        # unicode string, surrogateescape encoding, surrogateescape errors
        assert isinstance(to_unsafe_bytes(data, 'unicode_escape', 'surrogateescape'), AnsibleUnsafeBytes)

        # bytes string, surrogateescape encoding, surrogateescape errors
        assert isinstance(to_unsafe_bytes(data.encode('unicode_escape'), 'surrogateescape', 'surrogateescape'), AnsibleUnsafeBytes)

        # bytes string, utf-8 encoding, surrogateescape errors
        assert isinstance(to_unsafe_bytes(data.encode('utf-8'), 'utf-8', 'surrogateescape'), AnsibleUnsafeBytes)

        #

# Generated at 2022-06-23 14:46:17.278332
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    mytext = AnsibleUnsafeText("hello")
    assert isinstance(mytext.encode("ascii"), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:46:26.828646
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    # UnsafeProxy(obj)
    # obj: object
    # return: object.
    # UnsafeProxy() returns object itself if obj is already unsafe.
    # UnsafeProxy() convert unicode string to unsafe unicode string.
    obj = 'I am string'
    result = UnsafeProxy(obj)
    assert to_text(result) is obj
    assert result == 'I am string'

    obj = u'I am unsafe unicode string'
    result = UnsafeProxy(obj)
    assert result is obj

    obj = b'I am bytes string'
    result = UnsafeProxy(obj)
    assert result is obj

    obj = 'I am string'
    assert UnsafeProxy(obj) is obj

    # Example for ansible's usage
    # result['stdout'] = UnsafeProxy(result['stdout'])


# Generated at 2022-06-23 14:46:30.495892
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # Test encoding
    a = AnsibleUnsafeText('UnsafeString')
    b = AnsibleUnsafeText('UnsafeString').encode('utf-8')
    assert(isinstance(a, AnsibleUnsafeText))
    assert(isinstance(b, AnsibleUnsafeBytes))
    assert(a == b.decode('utf-8'))


# Generated at 2022-06-23 14:46:41.869453
# Unit test for function wrap_var
def test_wrap_var():
    # Ensure text types are converted to unsafe text
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'test'), AnsibleUnsafeText)

    # Test invalid text is wrapped
    assert isinstance(wrap_var(b'\xba\xba\xba'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'\xc3\x28'), AnsibleUnsafeText)

    # Ensure functions still get called correctly
    from ansible.module_utils._text import to_native
    f = to_native
    assert isinstance(f('test'), text_type)
    f = wrap_var(f)

# Generated at 2022-06-23 14:46:43.217125
# Unit test for function wrap_var
def test_wrap_var():
    # TODO
    pass

# Generated at 2022-06-23 14:46:50.240842
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(b'unsafe text'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(AnsibleUnsafeText('safe text')), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text('safe text'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'safe text'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(AnsibleUnsafeBytes(b'safe text')), AnsibleUnsafeText)

# Generated at 2022-06-23 14:46:52.453500
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    ansible_unsafe_text = AnsibleUnsafeText()
    assert ansible_unsafe_text is not None

# Generated at 2022-06-23 14:46:55.334139
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    bytes_instance = AnsibleUnsafeBytes(b'foo')
    bytes_instance = bytes_instance.encode("utf-8")
    bytes_instance.decode("utf-8")

# Generated at 2022-06-23 14:46:57.312940
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    s = NativeJinjaUnsafeText()

# Generated at 2022-06-23 14:46:59.355931
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText('test').encode(), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:47:01.671029
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    txt = 'ALana'
    unsafe = AnsibleUnsafeText(txt)
    assert isinstance(unsafe, text_type)

# Generated at 2022-06-23 14:47:12.775006
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    """Unit test for method __new__ of class UnsafeProxy"""
    from ansible.utils.display import Display
    class AnsibleModule:
        def __init__(self, *args, **kwargs):
            self.params = {}
            self.args = args
            self.kwargs = kwargs
    m = AnsibleModule()
    Display.deprecated = lambda *x, **y: None
    assert isinstance(UnsafeProxy('test_string', m), AnsibleUnsafeText)
    assert UnsafeProxy('test_string', m) == 'test_string'
    assert isinstance(UnsafeProxy(b'test_bytes', m), AnsibleUnsafeBytes)
    assert UnsafeProxy(b'test_bytes', m) == b'test_bytes'
    assert UnsafeProxy(42, m) == 42

# Generated at 2022-06-23 14:47:25.101014
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(1), int)
    assert isinstance(wrap_var(1.0), float)
    assert isinstance(wrap_var([1, 2, 3]), list)
    assert isinstance(wrap_var(['a', 'b', 'c']), list)
    assert isinstance(wrap_var((1, 2, 3)), tuple)
    assert isinstance(wrap_var((u'a', u'b', u'c')), tuple)

# Generated at 2022-06-23 14:47:33.212636
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    from ansible.module_utils.six import PY3

    test_text = 'foo'
    unsafe_text = AnsibleUnsafeText(test_text)

    # Check the type of the instance
    assert isinstance(unsafe_text, AnsibleUnsafeText)

    # Check that the type of the instance matches the Python version
    if PY3:
        assert isinstance(unsafe_text, text_type)
    else:
        assert isinstance(unsafe_text, text_type)

    # Check the value of the instance
    assert unsafe_text == test_text

# Generated at 2022-06-23 14:47:36.137369
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    bytes_string = to_unsafe_bytes("test")
    assert isinstance(bytes_string, AnsibleUnsafeBytes)
    assert bytes_string.encode() == b"test"


# Generated at 2022-06-23 14:47:42.339973
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    str1 = AnsibleUnsafeText("test")
    assert str1 == "test" and str1.__UNSAFE__
    str2 = AnsibleUnsafeBytes(str1.encode("utf-8"))
    assert str2 == b"test" and str2.__UNSAFE__
    str3 = AnsibleUnsafeText("test")
    assert str3 == AnsibleUnsafeText("test")


# Generated at 2022-06-23 14:47:45.101999
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    s = 'abc'
    res = to_unsafe_bytes(s).decode('utf-8')
    assert isinstance(res, AnsibleUnsafeText)


# Generated at 2022-06-23 14:47:47.746070
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    s = "abc"
    unsafe_text = UnsafeProxy(s)
    assert s == str(unsafe_text)


# Generated at 2022-06-23 14:47:53.959075
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    # Test with ansible_unsafe_text input
    assert isinstance(wrap_var(to_unsafe_text('foobar')), AnsibleUnsafeText)

    # Test with unicode input
    assert isinstance(wrap_var(to_unsafe_text(u'foobar')), AnsibleUnsafeText)

    # Test with bytestring input
    assert isinstance(wrap_var(to_unsafe_text(b'foobar')), AnsibleUnsafeText)

# Generated at 2022-06-23 14:47:58.706816
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    my_unsafe_string = "hello"
    expected_result = my_unsafe_string
    actual_result = UnsafeProxy(my_unsafe_string)
    assert expected_result == actual_result
    assert type(actual_result) is type(expected_result)

# Generated at 2022-06-23 14:48:04.303323
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    e = AnsibleUnsafeText('a')
    assert type(e) == AnsibleUnsafeText
    e = e.encode()
    assert type(e) == AnsibleUnsafeBytes
    e = e.encode()
    assert type(e) == AnsibleUnsafeText
