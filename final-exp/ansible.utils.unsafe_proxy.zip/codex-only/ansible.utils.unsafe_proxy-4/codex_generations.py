

# Generated at 2022-06-23 14:38:16.344065
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Test variable
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six import PY3

    if PY3:
        from importlib import util as import_util
        module_spec = import_util.spec_from_loader('sys', loader=import_util.find_loader('sys'))
        sys_module = import_util.module_from_spec(module_spec)
        module_spec.loader.exec_module(sys_module)
    else:
        import imp
        sys_module = imp.load_module('sys', *imp.find_module('sys'))


    # Test function
    string_data = sys_module.stdout = StringIO()
    orig_data = string_data
    data = 'abc'

# Generated at 2022-06-23 14:38:18.884663
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert isinstance(AnsibleUnsafeText(b"test"), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeText(None), AnsibleUnsafeText)


# Generated at 2022-06-23 14:38:22.286268
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # try to create instance of class UnsafeProxy
    # with argument to_text("str"),
    # should return AnsibleUnsafeText
    assert isinstance(UnsafeProxy(to_text("str")), AnsibleUnsafeText)


# Generated at 2022-06-23 14:38:26.075315
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    b1 = b'foo'
    u_b1 = AnsibleUnsafeBytes(b1)
    assert type(u_b1) == AnsibleUnsafeBytes
    assert u_b1 == b'foo'



# Generated at 2022-06-23 14:38:28.589170
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    ansible_unsafe = AnsibleUnsafe()
    assert ansible_unsafe is not None


# Generated at 2022-06-23 14:38:32.191785
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    class TestClass(object):
        __UNSAFE__ = True

    test = TestClass()
    assert UnsafeProxy(test) is not TestClass
    assert UnsafeProxy(test) is test

# Generated at 2022-06-23 14:38:34.705665
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    d = AnsibleUnsafeBytes("abc")
    assert isinstance(d.decode(), AnsibleUnsafeText)


# Generated at 2022-06-23 14:38:40.516498
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    from ansible.module_utils.six import u
    assert AnsibleUnsafeText(u("42")) == u("42")
    assert AnsibleUnsafeText(u("42")) != u("asd")
    assert AnsibleUnsafeText(u("42")) == 42
    assert AnsibleUnsafeText(u("42")) != 12



# Generated at 2022-06-23 14:38:42.777977
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    try:
        NativeJinjaUnsafeText('testing \u5E93')
    except Exception:
        # fail
        assert False

# Generated at 2022-06-23 14:38:46.169082
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    text = 'test string'
    unsafe_text = AnsibleUnsafeText(text)
    assert isinstance(unsafe_text, text_type)
    assert isinstance(unsafe_text, AnsibleUnsafe)
    assert text == unsafe_text



# Generated at 2022-06-23 14:38:48.223540
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    teststring = "foobar"
    AnsibleUnsafe(teststring)

# Generated at 2022-06-23 14:38:53.661493
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # Create a class
    class AnsiClass(AnsibleUnsafe):
        def __init__(self, value):
            self.value = value
    # Test the class
    assert AnsiClass.__UNSAFE__
    assert AnsiClass("Hello").value == "Hello"


# Generated at 2022-06-23 14:39:05.582054
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.display import Display
    from ansible.utils.unsafe_proxy import UnsafeProxy
    from ansible.utils.safe_types import AnsibleUnsafeBytes
    from ansible.utils.safe_types import AnsibleUnsafeText

    # Tests that UnsafeProxy is deprecated
    with patch.object(Display, 'deprecated') as mock_deprecated:
        s = 'hello'
        p = UnsafeProxy(s, wrap_strings=True)
        mock_deprecated.assert_called_with(
            'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
            version='2.13', collection_name='ansible.builtin'
        )

    # Test if UnsafeProxy passes strings as AnsibleUnsafeText
    s = 'hello'

# Generated at 2022-06-23 14:39:07.623526
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    s = 'My string'
    assert isinstance(UnsafeProxy(s), AnsibleUnsafeText)

# Generated at 2022-06-23 14:39:18.765346
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    from ansible.module_utils.common.text.converters import to_bytes

    try:
        to_bytes('猫')
    except UnicodeError as e:
        error = e

    unsafe_text = AnsibleUnsafeText('猫')
    result = unsafe_text.encode('ascii', 'surrogateescape')

    assert result == b'\xed\xa0\xbd\xed\xb6\x82'
    assert type(result) == AnsibleUnsafeBytes
    assert result.decode('utf-8', 'surrogateescape') == '猫'

    # This is how AnsibleUnsafeBytes should behave

# Generated at 2022-06-23 14:39:26.407704
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY3

    string_var = u'abcd'
    if PY3:
        assert isinstance(to_unsafe_bytes(string_var), AnsibleUnsafeBytes)
    else:
        assert isinstance(to_unsafe_bytes(string_var), AnsibleUnsafeText)

    string_var = 'abcd'
    assert isinstance(to_unsafe_bytes(string_var), AnsibleUnsafeBytes)

    unicode_var = u'abcd'
    if PY3:
        assert isinstance(to_unsafe_bytes(unicode_var), AnsibleUnsafeText)
    else:
        assert isinstance(to_unsafe_bytes(unicode_var), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:39:27.821736
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe.__UNSAFE__


# Generated at 2022-06-23 14:39:38.515007
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import sys
    import unittest

    class TestToUnsafeText(unittest.TestCase):
        """
        Test the to_unsafe_text function.
        """
        def test_ansible_unsafe(self):
            """
            Convert an AnsibleUnsafe to a string.
            """
            self.assertIsInstance(to_unsafe_text("test_string"), str)
            self.assertIsInstance(to_unsafe_text("test_string"), AnsibleUnsafeText)

        def test_ansible_unsafe_bytes(self):
            """
            Convert AnsibleUnsafeBytes to a string.
            """
            self.assertIsInstance(to_unsafe_text(b"test_string"), text_type)

# Generated at 2022-06-23 14:39:40.544775
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert AnsibleUnsafeText("abc") == u"abc"

# Generated at 2022-06-23 14:39:44.525524
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.module_utils.common.collections import to_native_safe
    assert isinstance(to_native_safe("{{ myvar }}"), NativeJinjaUnsafeText)


# Generated at 2022-06-23 14:39:56.345073
# Unit test for function wrap_var
def test_wrap_var():
    import os
    import pytest
    from six import PY3
    from ansible.module_utils.six import binary_type, text_type

    # Create a text string with UTF encoding
    t_str = to_text('\xe1\xbc\xb8\xce\xbf\xe1\xbd\xba \xcf\x83\xcf\x84\xce\xb9\xce\xbb\xce\xb9\xcf\x82')
    # Create a binary string with UTF encoding
    b_str = to_bytes('\xe1\xbc\xb8\xce\xbf\xe1\xbd\xba \xcf\x83\xcf\x84\xce\xb9\xce\xbb\xce\xb9\xcf\x82')

   

# Generated at 2022-06-23 14:40:07.630849
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():

    # Ensure that a literal string input is preserved with type AnsibleUnsafeBytes
    expected = b'test'
    actual = to_unsafe_bytes(expected)
    assert isinstance(actual, AnsibleUnsafeBytes)
    assert actual == expected

    # Ensure that a tuple containing a literal string is converted to a tuple containing an AnsibleUnsafeBytes
    expected = (b'test',)
    actual = to_unsafe_bytes(expected)
    assert isinstance(actual, tuple)
    assert isinstance(actual[0], AnsibleUnsafeBytes)
    assert actual == expected

    # Ensure that a dict containing a literal string is converted to a dict with that string as an AnsibleUnsafeBytes
    expected = {b'test': b'test1'}
    actual = to_unsafe_bytes(expected)

# Generated at 2022-06-23 14:40:13.691105
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.display import Display
    from ansible.utils.unsafe_proxy import UnsafeProxy
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    test_ansible_unsafe=UnsafeProxy('test_ansible_unsafe')
    assert type(test_ansible_unsafe)==AnsibleUnsafeText

# Generated at 2022-06-23 14:40:17.146098
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    x = "abcd"
    y = to_unsafe_text(x)
    assert isinstance(y, AnsibleUnsafeText)
    assert y == to_text(x)

# Generated at 2022-06-23 14:40:20.097527
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    s = NativeJinjaUnsafeText("test")
    assert s == "test"
    assert type(s) == NativeJinjaUnsafeText

# Generated at 2022-06-23 14:40:25.548408
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes("").decode(), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeBytes("").decode("ascii"), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeBytes("").decode("ascii", "replace"), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeBytes("").decode("ascii", "replace", "strict"), AnsibleUnsafeText)


# Generated at 2022-06-23 14:40:28.554267
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy(u'abc').__unicode__() == u'abc'
    assert UnsafeProxy(u'abc').__str__() == b'abc'



# Generated at 2022-06-23 14:40:38.862860
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy('test', 1, 2), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'test', 1, 2), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(b'test', 1, 2), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'test'.decode('ascii'), 1, 2), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'test'.decode('ascii'), 1, 2), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy({'test': b'test'}, 1, 2), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(['test1', b'test2'], 1, 2), AnsibleUnsafeText)

# Generated at 2022-06-23 14:40:49.790444
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.display import Display
    with Display.override(False):
        # Test non-wrapping strings
        assert UnsafeProxy('foo') == 'foo'
        assert UnsafeProxy(u'foo') == 'foo'

        # Test non-wrapping byte strings
        b_foo = b'foo'
        assert UnsafeProxy(b_foo) == b'foo'

        # Test wrapped unicode strings
        assert UnsafeProxy(AnsibleUnsafeText('foo')) == 'foo'

        # Test wrapped byte strings
        b_foo = AnsibleUnsafeBytes(b'foo')
        assert UnsafeProxy(b_foo) == b'foo'

        # Test wrapping unicode strings
        assert UnsafeProxy(u'foo') is not None

        # Test wrapping byte strings

# Generated at 2022-06-23 14:40:52.086940
# Unit test for function to_unsafe_text
def test_to_unsafe_text():

    result = to_unsafe_text(b'hello there')
    assert isinstance(result, AnsibleUnsafeText)



# Generated at 2022-06-23 14:40:55.740216
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    a = AnsibleUnsafeText("test AnsibleUnsafeText")
    assert( isinstance(a, text_type ) )
    assert( not isinstance(a, binary_type ) )
    assert( isinstance(a, AnsibleUnsafe ) )


# Generated at 2022-06-23 14:41:01.139354
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    string = 'some string'
    bytes = string.encode('utf-8')
    bytes_unsafe = AnsibleUnsafeBytes(bytes)
    str_unsafe = bytes_unsafe.decode('utf-8')
    assert(type(str_unsafe) == AnsibleUnsafeText)


# Generated at 2022-06-23 14:41:05.185768
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    instance1 = UnsafeProxy('hello world')
    assert isinstance(instance1, AnsibleUnsafeText)
    instance2 = UnsafeProxy(instance1)
    assert isinstance(instance2, AnsibleUnsafeText)

# Generated at 2022-06-23 14:41:08.637755
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('test') == b'test'
    assert isinstance(to_unsafe_bytes('test'), binary_type)
    assert isinstance(to_unsafe_bytes('test'), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:41:16.953629
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText('abc').encode(), AnsibleUnsafeBytes)

    #Test encode with no args
    assert AnsibleUnsafeText(b'abc').encode() == b'abc'

    assert AnsibleUnsafeText(b'abc').encode('utf-8', 'surrogateescape') == b'abc'

    # Test for named arguments
    assert AnsibleUnsafeText('abc').encode(encoding='utf-8', errors='surrogateescape') == b'abc'



# Generated at 2022-06-23 14:41:28.502477
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('test') is not 'test'
    assert wrap_var(to_text('test')) is not 'test'
    assert wrap_var(to_bytes('test')) is not 'test'
    assert wrap_var(u'test') is not 'test'
    assert wrap_var(u'test') is not u'test'
    assert wrap_var(b'test') is not b'test'
    assert wrap_var('test') == 'test'
    assert wrap_var(to_text('test')) == 'test'
    assert wrap_var(to_bytes('test')) == 'test'
    assert wrap_var(u'test') == 'test'
    assert wrap_var(b'test') == 'test'
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)


# Generated at 2022-06-23 14:41:39.638987
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert AnsibleUnsafeText('') == UnsafeProxy('')
    assert AnsibleUnsafeText('Alice') == UnsafeProxy('Alice')
    assert AnsibleUnsafeText('Alice') == UnsafeProxy(AnsibleUnsafeText('Alice'))
    assert AnsibleUnsafeBytes(b'Alice') == UnsafeProxy(b'Alice')
    assert AnsibleUnsafeBytes(b'Alice') == UnsafeProxy(AnsibleUnsafeBytes(b'Alice'))
    assert AnsibleUnsafeText('') == UnsafeProxy(AnsibleUnsafeBytes(b''))
    assert AnsibleUnsafeText('') == UnsafeProxy(AnsibleUnsafeText(''))
    assert AnsibleUnsafeText('') == UnsafeProxy(AnsibleUnsafeBytes(b''))

# Generated at 2022-06-23 14:41:44.683371
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    class test: pass
    unicode_class = UnsafeProxy(test())
    assert isinstance(unicode_class, test) is True
    assert isinstance(unicode_class, AnsibleUnsafe) is True

    byte_class = UnsafeProxy(u'test')
    assert isinstance(byte_class, AnsibleUnsafeText) is True

# Generated at 2022-06-23 14:41:56.273105
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    """
    Unit tests that ensure the UnsafeProxy class functions correctly.
    """
    from ansible.module_utils.basic import AnsibleModule

    UNSAFE_STRING = b'unsafe_string'
    UNSAFE_DICT = {b'key': b'value'}
    UNSAFE_LIST = [b'item_1', b'item_2']

    def test_wrap(unsafe_string=UNSAFE_STRING, unsafe_dict=UNSAFE_DICT, unsafe_list=UNSAFE_LIST):
        import copy
        unsafe_string = copy.deepcopy(unsafe_string)
        unsafe_dict = copy.deepcopy(unsafe_dict)
        unsafe_list = copy.deepcopy(unsafe_list)


# Generated at 2022-06-23 14:41:59.344970
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    ansib_unsafe_bytes_instance = AnsibleUnsafeBytes(b'hello')
    print(ansib_unsafe_bytes_instance.__dict__)
    ansib_unsafe_bytes_instance.decode('utf-8')


# Generated at 2022-06-23 14:42:00.277200
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe()

# Generated at 2022-06-23 14:42:12.588170
# Unit test for function wrap_var
def test_wrap_var():
    import unittest

    class TestUnsafeVar(unittest.TestCase):
        def test_unsafe_var(self):
            self.assertTrue(AnsibleUnsafe())
            self.assertTrue(wrap_var(None))

        def test_type_wrap_var(self):
            self.assertTrue(isinstance(wrap_var(None), type(None)))

        def test_mapping(self):
            self.assertTrue(isinstance(wrap_var({}), dict))

        def test_sequence(self):
            self.assertTrue(isinstance(wrap_var([]), list))
            self.assertTrue(isinstance(wrap_var(()), tuple))
            # Test Set
            self.assertTrue(isinstance(wrap_var(set()), set))
            # Test FrozenSet

# Generated at 2022-06-23 14:42:21.314390
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(1.0j) == 1.0j

    # NOTE: strings should be wrapped with the AnsibleUnsafeText or
    #       AnsibleUnsafeBytes class directly, not via wrap_var.
    #       The assert below is not a good example to emulate.
    assert wrap_var(u'abc') == u'abc'
    assert wrap_var('abc') == 'abc'
    assert wrap_var(b'abc') == b'abc'

    assert wrap_var([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert wrap_var((1, 2, 3, 4)) == (1, 2, 3, 4)


# Generated at 2022-06-23 14:42:23.234597
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert(to_unsafe_text(b'foo') == to_unsafe_text(u'foo'))

# Generated at 2022-06-23 14:42:27.359676
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    import jinja2
    assert isinstance(NativeJinjaUnsafeText(jinja2.Template('{{ foo }}').render(foo=NativeJinjaText('bar'))), AnsibleUnsafeText)

# Generated at 2022-06-23 14:42:30.350613
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes('foo').decode(), AnsibleUnsafeText)
    assert not isinstance(AnsibleUnsafeBytes('foo').decode(), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:42:33.810064
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    from ansible.module_utils.six import u
    assert isinstance(AnsibleUnsafeBytes(u('toto').encode()).decode(), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeBytes(u('toto').encode()).decode().encode(), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:42:35.402793
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert(b"abc" == AnsibleUnsafeText('abc').encode())


# Generated at 2022-06-23 14:42:42.475789
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # Unicode string that can be easily encoded
    v = u'\U000FE4DD'
    # "Encode" the string to UTF-8
    v = v.encode('utf-8')
    # Wrap the string
    v = wrap_var(v)
    # Unicode string that CANNOT be easily encoded
    u = u'\U000FE4DD\U000FE4DE\U000FE4DF'
    # "Encode" the string to UTF-8
    u = u.encode('utf-8')
    # Wrap the string
    u = wrap_var(u)
    # "Encode" the string to ascii
    # This will fail to encode the non ascii characters

# Generated at 2022-06-23 14:42:48.440088
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    b = to_unsafe_bytes('abc')
    assert isinstance(b, AnsibleUnsafeBytes)
    assert not isinstance(b, AnsibleUnsafeText)
    assert b == b'test'
    s = to_unsafe_text(b)
    assert isinstance(s, AnsibleUnsafeText)
    assert not isinstance(s, AnsibleUnsafeBytes)
    assert s == u'test'

# Generated at 2022-06-23 14:42:52.335870
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('hi', encoding='utf8') == u'hi'
    assert isinstance(to_unsafe_bytes('hi', encoding='utf8'), AnsibleUnsafeText)



# Generated at 2022-06-23 14:43:04.449099
# Unit test for method __new__ of class UnsafeProxy

# Generated at 2022-06-23 14:43:08.435731
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    var = AnsibleUnsafeText()
    assert isinstance(var, AnsibleUnsafeText)
    assert isinstance(var, text_type)
    assert not isinstance(var, AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:43:09.727012
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    up1 = UnsafeProxy('a string')
    assert(isinstance(up1, AnsibleUnsafeText))
    up2 = UnsafeProxy(b'a string')
    assert(isinstance(up2, AnsibleUnsafeBytes))

# Generated at 2022-06-23 14:43:11.560277
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    """Test whether AnsibleUnsafeBytes' constructor accepts bytes() argument."""
    AnsibleUnsafeBytes(b'foo')



# Generated at 2022-06-23 14:43:13.927404
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert type(to_unsafe_bytes('test')) == binary_type


# Generated at 2022-06-23 14:43:24.515020
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.module_utils.six import u
    s = u("This is a unicode string")
    class FakeDisplay():
        class Deprecation():
            version = "2.13"
            collection_name = 'ansible.builtin'

    display = FakeDisplay()
    class FakeJinjaEnv():
        display = display

        class NativeJinjaText:
            def __init__(self, *args, **kwargs):
                self.args = args
                self.kwargs = kwargs

    NativeJinjaEnv.NativeJinjaText = NativeJinjaUnsafeText
    native_str = NativeJinjaUnsafeText(s, jinja_env=FakeJinjaEnv())

    assert native_str.args == (u("This is a unicode string"),)
    assert native

# Generated at 2022-06-23 14:43:28.270532
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    wrapped = AnsibleUnsafeBytes('abc')
    unwrapped = wrapped.decode('utf-8').encode('utf-8')
    assert(unwrapped == b'abc')


# Generated at 2022-06-23 14:43:30.459045
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert type(UnsafeProxy("abcd")) == text_type
    assert type(UnsafeProxy(u"abcd")) == text_type

# Generated at 2022-06-23 14:43:43.157030
# Unit test for function wrap_var
def test_wrap_var():

    assert wrap_var(u"x") == u"x"
    assert wrap_var(b"x") == b"x"
    assert wrap_var(u"x") == "x"
    assert wrap_var(b"x") == b"x"
    assert wrap_var(1) == 1
    assert wrap_var(1.2) == 1.2
    assert wrap_var(NG) == NG


    assert wrap_var([1,2]) == [1, 2]
    assert wrap_var([1,2]) == (1, 2)
    assert wrap_var([1,2]) == set([1, 2])
    assert wrap_var([1,2]) == {1:1, 2:2}
    assert wrap_var([1,2]) == NG



# Generated at 2022-06-23 14:43:46.660671
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    a = UnsafeProxy(b'foo')
    assert isinstance(a, binary_type)
    assert isinstance(a, AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:43:55.181608
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # valid input
    a = AnsibleUnsafeText('a')
    b = AnsibleUnsafeBytes(b'a')
    valid_inputs = [a, b]
    for i in valid_inputs:
        test = AnsibleUnsafeText(i)
        assert test.__UNSAFE__ == True

    # invalid input
    invalid_inputs = ['a', 100, 1.0, None]
    for i in invalid_inputs:
        try:
            AnsibleUnsafeText(i)
        except TypeError as e:
            assert e  # expected TypeError exception



# Generated at 2022-06-23 14:43:56.645963
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    with pytest.raises(TypeError):
        AnsibleUnsafe()

# Generated at 2022-06-23 14:44:07.110934
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six import text_type, binary_type

    for i in range(-128,128):
        a = to_unsafe_text(chr(i))
        assert a == text_type(chr(i))
        assert isinstance(a, AnsibleUnsafeText)

    for i in range(0x10000):
        a = to_unsafe_text(chr(i))
        assert a == text_type(chr(i))
        assert isinstance(a, AnsibleUnsafeText)

    for i in range(0x10000):
        a = to_unsafe_text(unichr(i))
        assert a == unichr(i)


# Generated at 2022-06-23 14:44:09.310079
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b"foo").decode(), AnsibleUnsafeText)


# Generated at 2022-06-23 14:44:10.109385
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe()

# Generated at 2022-06-23 14:44:13.590799
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('text'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_bytes(u'bytestring'), AnsibleUnsafeText)



# Generated at 2022-06-23 14:44:17.394122
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    ansible_unsafe_text = AnsibleUnsafeText("unsafe string")
    print(ansible_unsafe_text)
    print(type(ansible_unsafe_text))
    return False


# Generated at 2022-06-23 14:44:20.711195
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText(to_text(u"test_string")).encode(), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:44:23.639926
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    bytes_unsafe = AnsibleUnsafeBytes(b'abcd')
    text = bytes_unsafe.decode()
    assert text == AnsibleUnsafeText(u'abcd')


# Generated at 2022-06-23 14:44:30.141228
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text('foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'foo'), AnsibleUnsafeText)


# Generated at 2022-06-23 14:44:31.872089
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    result = wrap_var('this is a test')
    assert isinstance(result, AnsibleUnsafeText)

# Generated at 2022-06-23 14:44:40.985715
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    unicode_var = u'\u2318'
    assert(unicode_var == to_unsafe_text(unicode_var))
    assert(isinstance(unicode_var, AnsibleUnsafeText))
    assert(isinstance(u"a", AnsibleUnsafeText))
    assert(isinstance(u"", AnsibleUnsafeText))
    assert(isinstance(u"$$$", AnsibleUnsafeText))
    assert(isinstance(u"$${a}", AnsibleUnsafeText))
    assert(isinstance(u"$${a}$${b}", AnsibleUnsafeText))
    assert(isinstance(u"$${a}a${b}", AnsibleUnsafeText))
    assert(isinstance(u"${a}a$${b}", AnsibleUnsafeText))

# Generated at 2022-06-23 14:44:45.557955
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    jinja_string = {{a}}
    native_jinja_text = 'a'
    unsafe_text = NativeJinjaUnsafeText(native_jinja_text)
    assert(jinja_string == unsafe_text)
    assert(unsafe_text.__UNSAFE__)

# Generated at 2022-06-23 14:44:47.382929
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('message'), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:44:49.136825
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert AnsibleUnsafeBytes(b'1234').decode() == '1234'


# Generated at 2022-06-23 14:44:51.332858
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    test_str = u'unicode test'
    p = UnsafeProxy(test_str)
    assert test_str == p
    assert isinstance(p, AnsibleUnsafeText)


# Generated at 2022-06-23 14:44:53.781822
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    unsafe_proxy = UnsafeProxy("foo")
    assert unsafe_proxy.__class__.__name__ == "AnsibleUnsafeText"

# Generated at 2022-06-23 14:44:57.315075
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    test_object = AnsibleUnsafe()
    assert hasattr(test_object, '__UNSAFE__')
    assert test_object.__UNSAFE__ is True

# Unittest for constructor of class AnsibleUnsafeBytes

# Generated at 2022-06-23 14:45:01.532145
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import is_sequence
    byte = AnsibleUnsafeBytes('abc')
    assert byte == b'abc'
    assert byte.__UNSAFE__
    text = to_text('abc')
    assert text == u'abc'
    assert not text.__UNSAFE__

# Generated at 2022-06-23 14:45:12.227533
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert issubclass(AnsibleUnsafeText, text_type)
    assert issubclass(AnsibleUnsafeText, AnsibleUnsafe)

    assert AnsibleUnsafeText('a', 'utf-8') == 'a'
    assert isinstance(AnsibleUnsafeText('a', 'utf-8'), AnsibleUnsafe)
    assert AnsibleUnsafeText('a', 'utf-8').encode('utf-8') == b'a'
    assert AnsibleUnsafeText('a', 'utf-8').encode('utf-8').decode('utf-8') == u'a'
    assert isinstance(AnsibleUnsafeText('a', 'utf-8').encode('utf-8'), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:45:14.509118
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():

    unsafe_proxy = UnsafeProxy("testing")
    assert isinstance(unsafe_proxy, AnsibleUnsafeText)



# Generated at 2022-06-23 14:45:26.754934
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():

    v_str = "str"
    v_str_unsafe = "str"
    v_str_unsafe_proxy = UnsafeProxy(v_str)
    v_int = 1
    v_int_unsafe = 1
    v_int_unsafe_proxy = UnsafeProxy(v_int)

    assert v_str == v_str_unsafe_proxy
    assert v_str is not v_str_unsafe_proxy
    assert isinstance(v_str_unsafe_proxy, AnsibleUnsafeText)
    assert isinstance(v_str_unsafe_proxy, text_type)

    assert v_int == v_int_unsafe_proxy
    assert v_int is not v_int_unsafe_proxy
    assert isinstance(v_int_unsafe_proxy, AnsibleUnsafeText)


# Generated at 2022-06-23 14:45:28.434289
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
   AnsibleUnsafeBytes(b'UnsafeBytestring')



# Generated at 2022-06-23 14:45:31.410078
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    x1 = NativeJinjaUnsafeText('{% if True %}True{% else %}False{% endif %}')
    assert(str(x1) == str('True'))
    assert(x1.__UNSAFE__ == True)

# Generated at 2022-06-23 14:45:34.726056
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    ansible_unsafe_text_object = AnsibleUnsafeText(u"abc")
    assert (type(ansible_unsafe_text_object) is type(u"abc"))

# Generated at 2022-06-23 14:45:42.430452
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    """
    Unit test code for testing the constructor of class NativeJinjaUnsafeText.
    """
    njut = NativeJinjaUnsafeText('Foo\nBar')

    assert njut == 'Foo\nBar'
    assert isinstance(njut, NativeJinjaUnsafeText)
    assert isinstance(njut, NativeJinjaText)
    assert isinstance(njut, AnsibleUnsafeText)
    assert not isinstance(njut, NativeJinjaText)


# Generated at 2022-06-23 14:45:52.191047
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes(), AnsibleUnsafe)
    assert isinstance(to_unsafe_bytes('123'), AnsibleUnsafe)
    assert isinstance(to_unsafe_bytes(b'123'), AnsibleUnsafe)
    assert isinstance(to_unsafe_bytes('123', encoding='utf-8'), AnsibleUnsafe)
    assert isinstance(to_unsafe_bytes(b'123'.decode('utf-8')), AnsibleUnsafe)
    assert isinstance(to_unsafe_bytes('123', encoding='utf-8', errors='surrogate_or_strict'), AnsibleUnsafe)
    assert isinstance(to_unsafe_bytes(b'123'.decode('utf-8'), encoding='utf-8', errors='surrogate_or_strict'), AnsibleUnsafe)


# Generated at 2022-06-23 14:45:54.399587
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert type(to_unsafe_text('hello')) == AnsibleUnsafeText

# Generated at 2022-06-23 14:45:56.070039
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert issubclass(NativeJinjaUnsafeText, NativeJinjaText)

# Generated at 2022-06-23 14:46:05.874573
# Unit test for constructor of class AnsibleUnsafe

# Generated at 2022-06-23 14:46:10.433715
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    ansible_unsafe_text = AnsibleUnsafeText('abc')
    unsafe_bytes = ansible_unsafe_text.encode('utf-8')
    assert isinstance(unsafe_bytes, AnsibleUnsafeBytes)
    assert unsafe_bytes == b'abc'


# Generated at 2022-06-23 14:46:12.898132
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    testObj = UnsafeProxy("TestString")
    assert isinstance(testObj, AnsibleUnsafeText)


# Generated at 2022-06-23 14:46:19.669081
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    # Test unsafe values
    unsafe_text = UnsafeProxy('UnsafeText')
    assert isinstance(unsafe_text, AnsibleUnsafeText)

    unsafe_bytes = UnsafeProxy(b'UnsafeBytes')
    assert isinstance(unsafe_bytes, AnsibleUnsafeBytes)

    # Test safe values
    safe_text = UnsafeProxy(UnknownSafeText())
    assert isinstance(safe_text, UnknownSafeText)

    safe_bytes = UnsafeProxy(UnknownSafeBytes())
    assert isinstance(safe_bytes, UnknownSafeBytes)



# Generated at 2022-06-23 14:46:21.598262
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    unsafe_text = AnsibleUnsafeText('Test')
    assert isinstance(unsafe_text.encode(), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:46:30.159999
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    def check_decode(s, encoding, errors):
        if encoding is None:
            encoding = 'ascii'
        if errors is None:
            errors = 'strict'
        assert isinstance(s, binary_type)
        assert isinstance(encoding, string_types)
        assert isinstance(errors, string_types)
        a = AnsibleUnsafeBytes(s)
        b = a.decode(encoding, errors)
        assert isinstance(b, AnsibleUnsafeText)
        assert a == to_bytes(b, encoding, errors)

    check_decode('abc', None, None)
    check_decode(b'\xc3\xa9', 'utf-8', None)
    check_decode(b'\xc3\xa9', 'utf-8', 'strict')
   

# Generated at 2022-06-23 14:46:33.008723
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    ansibleunsafetext=AnsibleUnsafeText("hello")
    assert ansibleunsafetext == "hello"


# Generated at 2022-06-23 14:46:37.112938
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    st = AnsibleUnsafeText(u"This is a test")
    assert isinstance(st, text_type)
    assert isinstance(st, AnsibleUnsafe)
    assert st == u"This is a test"


# Generated at 2022-06-23 14:46:38.554349
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    obj = AnsibleUnsafe()
    assert obj.__UNSAFE__



# Generated at 2022-06-23 14:46:46.930704
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var([]) == []
    assert wrap_var(1) == 1
    assert wrap_var({'k': 'v'}) == {'k': 'v'}
    assert wrap_var(('tuple',)) == ('tuple',)

    assert isinstance(wrap_var('mystring'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'mystring'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(AnsibleUnsafeText('mystring')), AnsibleUnsafeText)
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'mystring')), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:46:55.111163
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.module_utils.six import PY2
    v = [{'a': 'a', 1: 2}, [1, 2], (1, 2), {1, 2}, {'a', 'b'}]
    # v is list of dictionaries and sets
    for i in v:
        if PY2:
            base_type = to_bytes(i)
        else:
            base_type = to_text(i)
        assert type(base_type) == type(i)
        assert type(to_unsafe_text(i)) == AnsibleUnsafeText


# Generated at 2022-06-23 14:47:04.298490
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    result=UnsafeProxy('a string')
    assert result == 'a string'
    assert type(result)==AnsibleUnsafeText
    assert result.__UNSAFE__==True

    result=UnsafeProxy(AnsibleUnsafeBytes('some bytes'))
    assert result == 'some bytes'
    assert type(result)==AnsibleUnsafeBytes
    assert result.__UNSAFE__==True

    result=UnsafeProxy(AnsibleUnsafeText('some text'))
    assert result == 'some text'
    assert type(result)==AnsibleUnsafeText
    assert result.__UNSAFE__==True


# Generated at 2022-06-23 14:47:06.913099
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText('a').encode('ascii'), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:47:10.467274
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    u = AnsibleUnsafeText(u'\u00E9')

    assert(isinstance(u, text_type))
    assert(isinstance(u, AnsibleUnsafe))
    assert(u == u'\u00E9')



# Generated at 2022-06-23 14:47:17.771357
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    """Test AnsibleUnsafeBytes type is returned when calling AnsibleUnsafeText's encode method"""
    from ansible.module_utils._text import to_bytes

    ansible_text = AnsibleUnsafeText(to_bytes("ansible test text"))
    assert(isinstance(ansible_text, AnsibleUnsafeText))
    assert(isinstance(ansible_text.encode(), AnsibleUnsafeBytes))



# Generated at 2022-06-23 14:47:22.673755
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    test_str = u'\u0bf8'
    assert isinstance(test_str, unicode)
    test_str = to_unsafe_bytes(test_str)
    assert isinstance(test_str, AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:47:31.504283
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    data = ['hello']

    def side_effect(self, *args, **kwargs):
        return data.pop()

    class AnsibleUnsafeTextMock(AnsibleUnsafeText):
        def __new__(cls, *args, **kwargs):
            return AnsibleUnsafeText.__new__(cls, *args, **kwargs)

        def encode(self, *args, **kwargs):
            return side_effect(self, *args, **kwargs)

    obj = AnsibleUnsafeTextMock()
    assert AnsibleUnsafeBytes is type(obj.encode())

    data.pop()
    data.append(AnsibleUnsafeBytes('bhello'))
    assert AnsibleUnsafeBytes is type(obj.encode())

    data.pop()

# Generated at 2022-06-23 14:47:35.652876
# Unit test for function wrap_var
def test_wrap_var():

    # Check None
    wrapped_var = wrap_var(None)
    assert wrapped_var is None, repr(wrapped_var)

    # Check a string type
    string = 'string'
    wrapped_var = wrap_var(string)
    assert isinstance(wrapped_var, AnsibleUnsafeText), repr(wrapped_var)

    # Check a list type
    items = [1, 2, 3, 4]
    wrapped_var = wrap_var(items)
    assert isinstance(wrapped_var, list), repr(wrapped_var)
    assert isinstance(wrapped_var[0], AnsibleUnsafeText), repr(wrapped_var[0])

    # Check a tuple type
    items = (1, 2, 3, 4)
    wrapped_var = wrap_var(items)
    assert isinstance

# Generated at 2022-06-23 14:47:39.109456
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    result = UnsafeProxy("")
    assert result is not None
    assert str(result) == "UnsafeProxy(<class 'ansible.module_utils.basic.AnsibleUnsafeText'>,)"


# Generated at 2022-06-23 14:47:41.291605
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    text = u"\u2019"
    result_text = AnsibleUnsafeText(text).encode()
    assert isinstance(result_text, AnsibleUnsafeBytes)
    assert result_text == text.encode()



# Generated at 2022-06-23 14:47:52.662092
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(0) == u'0'
    assert to_unsafe_text(0, errors='strict') == u'0'
    assert to_unsafe_text(None) is None
    assert to_unsafe_text('foo') == u'foo'
    assert to_unsafe_text(u'foo') == u'foo'
    assert to_unsafe_text(b'foo') == u'foo'
    assert to_unsafe_text(b'foo', errors='strict') == u'foo'
    assert to_unsafe_text(b'\xff') == u'\ufffd'
    assert to_unsafe_text(b'\xff', errors='strict') == u''

# Generated at 2022-06-23 14:48:05.294967
# Unit test for function wrap_var
def test_wrap_var():
    import unittest

    class TestWrapVar(unittest.TestCase):
        def test_dict(self):
            v = {'example_key': 'example_value'}
            u = wrap_var(v)
            self.assertIsInstance(u, dict)
            self.assertEquals(u, v)
            self.assertTrue(u is not v)

        def test_list(self):
            v = [1, 2, '3']
            u = wrap_var(v)
            self.assertEquals(u, v)
            self.assertTrue(u is not v)

        def test_tuple(self):
            v = (1, 2, '3')
            u = wrap_var(v)
            self.assertEquals(u, v)