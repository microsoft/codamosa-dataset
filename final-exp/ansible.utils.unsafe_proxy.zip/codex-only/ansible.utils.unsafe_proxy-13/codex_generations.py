

# Generated at 2022-06-23 14:38:14.789640
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # UnsafeProxy.__new__(obj, *args, **kwargs) -> a new object.
    #
    #  Creates and returns a new object.  See help(type) for accurate signature.
    #  See also UnsafeProxy.__init__()
    #
    # Return:
    #   a new object.
    # Raises:
    #   TypeError.

    # Test TypeError
    # with pytest.raises(TypeError):
    #     UnsafeProxy(u'x', u'x', u'x')

    # Test me
    pass

# Generated at 2022-06-23 14:38:15.550785
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b'abc').decode(), AnsibleUnsafeText)


# Generated at 2022-06-23 14:38:24.762244
# Unit test for function to_unsafe_text
def test_to_unsafe_text():

    from ansible.module_utils.six import PY3

    assert(isinstance(to_unsafe_text(b'text'), AnsibleUnsafeText))
    assert(to_unsafe_text(b'text') == AnsibleUnsafeText('text'))
    if PY3:
        assert(isinstance(to_unsafe_text(b'text', errors='surrogate_or_strict'), AnsibleUnsafeText))
        assert(to_unsafe_text(b'text', errors='surrogate_or_strict') == AnsibleUnsafeText('text'))
    else:
        assert(isinstance(to_unsafe_text(b'text', errors='surrogate_or_strict'), AnsibleUnsafeText))

# Generated at 2022-06-23 14:38:29.739025
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    a = AnsibleUnsafeBytes('hello')
    assert(isinstance(a, binary_type))
    assert(isinstance(a, AnsibleUnsafe))
    assert('__UNSAFE__' in dir(a))
    assert(a.decode('utf8') == AnsibleUnsafeText('hello'))



# Generated at 2022-06-23 14:38:32.697086
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    unsafe_text = NativeJinjaUnsafeText('test')
    assert isinstance(unsafe_text, NativeJinjaUnsafeText)
    assert unsafe_text == 'test'

# Generated at 2022-06-23 14:38:35.346755
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    actual = AnsibleUnsafeBytes(b'bytes')
    expected = AnsibleUnsafeBytes


# Generated at 2022-06-23 14:38:36.782514
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert isinstance(AnsibleUnsafe(), AnsibleUnsafe)



# Generated at 2022-06-23 14:38:40.161975
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert isinstance(NativeJinjaUnsafeText("fda"), NativeJinjaUnsafeText) and str("fda") == "fda"

# Generated at 2022-06-23 14:38:48.694090
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY3

    # Test different types of input
    assert isinstance(to_unsafe_bytes(None), type(None))
    assert isinstance(to_unsafe_bytes(0), type(0))
    assert isinstance(to_unsafe_bytes(1), type(1))
    assert isinstance(to_unsafe_bytes(1.0), type(1.0))
    assert isinstance(to_unsafe_bytes('test'), type('test'))

    # Test that we are marking input as unsafe
    assert to_unsafe_bytes('test').__class__ == AnsibleUnsafeBytes

    # If on Python 3 ensure that if we try and encode input it is marked
    # as unsafe

# Generated at 2022-06-23 14:38:50.191363
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text('foo'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:39:02.852118
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes(b'abc') == AnsibleUnsafeBytes(b'abc')

    # Attempt to pass an unsafe string
    unsafe_bytes = AnsibleUnsafeBytes(b'abc')
    assert to_unsafe_bytes(unsafe_bytes) == unsafe_bytes

    # Attempt to pass a string
    string_bytes = b'abc'
    assert to_unsafe_bytes(string_bytes) == AnsibleUnsafeBytes(string_bytes)

    # Attempt to pass a str
    string = 'abc'
    assert to_unsafe_bytes(string) == AnsibleUnsafeBytes(to_bytes(string, 'ascii'))

    # Attempt to pass a list
    string_list = [b'abc', b'123']
    assert to_unsafe_bytes(string_list) == _wrap_sequence

# Generated at 2022-06-23 14:39:11.482650
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(b'foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'foo', 'utf-8'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'foo', 'utf-8'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'foo', 'utf-8', 'strict'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'foo', 'utf-8', 'strict'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:39:14.438980
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    unsafe_bytes_input = AnsibleUnsafeBytes(b"hello world")
    unsafe_text_expected_output = AnsibleUnsafeText(u"hello world")
    assert unsafe_bytes_input.decode() == unsafe_text_expected_output



# Generated at 2022-06-23 14:39:16.114647
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert isinstance(AnsibleUnsafe(), AnsibleUnsafe)


# Generated at 2022-06-23 14:39:19.150520
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    s = AnsibleUnsafeText("Ansible Unsafe Text Test")
    assert isinstance(s, text_type)
    assert isinstance(s, AnsibleUnsafe)



# Generated at 2022-06-23 14:39:20.774235
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    with pytest.raises(TypeError):
        ansibleUnsafe1 = AnsibleUnsafe()



# Generated at 2022-06-23 14:39:24.223927
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    ansible_unsafe_bytes_obj=AnsibleUnsafeBytes("abH")
    assert(ansible_unsafe_bytes_obj=="abH")


# Generated at 2022-06-23 14:39:28.605104
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    my_str = AnsibleUnsafeBytes("Binary String")
    assert isinstance(my_str, binary_type)
    assert isinstance(my_str, AnsibleUnsafe)
    assert my_str.decode() == "Binary String"


# Generated at 2022-06-23 14:39:39.081062
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    utf_8_sample = AnsibleUnsafeText('こんにちは ワールド。')
    ascii_sample = AnsibleUnsafeText('hello world.')
    assert(utf_8_sample.encode('utf-8') == b'\xe3\x81\x93\xe3\x82\x93\xe3\x81\xab\xe3\x81\xa1\xe3\x81\xaf \xe3\x83\xaf\xe3\x83\xbc\xe3\x83\xab\xe3\x83\x89\xe3\x80\x82')

# Generated at 2022-06-23 14:39:43.769218
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import b
    assert to_unsafe_bytes('Hello', 'utf-8') == b('Hello')
    assert type(to_unsafe_bytes('Hello', 'utf-8')) == AnsibleUnsafeBytes
    assert to_unsafe_bytes(u'Привет', 'utf-8') == b('\xd0\x9f\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82')
    assert type(to_unsafe_bytes(u'Привет', 'utf-8')) == AnsibleUnsafeBytes


# Generated at 2022-06-23 14:39:51.875634
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    import six

    data = {'lxd_profile_config': {
        'name': 'default',
        'config': {
            'security.nesting': 'true',
            'security.privileged': 'true',
        }
    }}

    templar = Templar(loader=None, variables={'hostvars':data})

# Generated at 2022-06-23 14:39:54.695755
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert AnsibleUnsafeText('Hello World!').encode() == AnsibleUnsafeBytes('Hello World!')


# Generated at 2022-06-23 14:40:01.125833
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    s = AnsibleUnsafe()
    assert not hasattr(s, '__UNSAFE__')

    s = AnsibleUnsafeBytes(b'Hello')
    assert s.__UNSAFE__

    s = AnsibleUnsafeText(u'Hello')
    assert s.__UNSAFE__

    s = NativeJinjaUnsafeText(u'Hello')
    assert s.__UNSAFE__

    s = AnsibleUnsafeBytes(b'Hello').decode()
    assert s.__UNSAFE__

    s = AnsibleUnsafeText(u'Hello').encode()
    assert s.__UNSAFE__

# Generated at 2022-06-23 14:40:12.947771
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils._text import to_bytes
    import sys

    assert isinstance(to_unsafe_bytes(u"hello"), binary_type)
    assert isinstance(to_unsafe_bytes(u"hello".encode('utf-8')), binary_type)
    assert isinstance(to_unsafe_bytes(1), binary_type)
    assert isinstance(to_unsafe_bytes(u"1"), binary_type)
    assert isinstance(to_unsafe_bytes(u"1".encode('utf-8')), binary_type)

    if sys.version_info >= (3, 0):
        assert isinstance(to_unsafe_bytes(u"12345678"), binary_type)

# Generated at 2022-06-23 14:40:13.996842
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    AnsibleUnsafeBytes("test")


# Generated at 2022-06-23 14:40:16.097819
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    x = UnsafeProxy('my string')
    assert(x == 'my string')

# Generated at 2022-06-23 14:40:25.839157
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Test if __new__ returns an instance of AnsibleUnsafeText, when called with a unicode string
    assert isinstance(UnsafeProxy('foo'), AnsibleUnsafeText) == True

    # Test if __new__ returns an instance of UnsafeProxy, when called with an instance of AnsibleUnsafeText
    assert isinstance(UnsafeProxy(AnsibleUnsafeText('foo')), AnsibleUnsafeText) == True

    # Test if __new__ returns an instance of UnsafeProxy, when called with an instance of AnsibleUnsafeBytes
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes) == True

    # Test if __new__ returns an instance of UnsafeProxy, when called with an instance of NativeJinjaText

# Generated at 2022-06-23 14:40:35.365683
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert UnsafeProxy('foo').__UNSAFE__
    assert UnsafeProxy(AnsibleUnsafeBytes('foo')).__UNSAFE__
    assert UnsafeProxy(AnsibleUnsafeText('foo')).__UNSAFE__
    # Can't construct from non-str/unicode
    try:
        UnsafeProxy(False)
        raise AssertionError("UnsafeProxy should not be able to construct from non-str/unicode")
    except TypeError:
        pass
    try:
        UnsafeProxy(None)
        raise AssertionError("UnsafeProxy should not be able to construct from non-str/unicode")
    except TypeError:
        pass


# Generated at 2022-06-23 14:40:46.791528
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Test whether UnsafeProxy.__new__ performs correctly under normal circumstances
    from ansible.utils.unsafe_proxy import UnsafeProxy
    assert isinstance(UnsafeProxy("foo"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy("foo"), AnsibleUnsafe)
    assert isinstance(UnsafeProxy("foo",), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy("foo",), AnsibleUnsafe)

    # Test whether UnsafeProxy.__new__ performs correctly when unsafety is inherited
    assert isinstance(UnsafeProxy(AnsibleUnsafeText("foo")), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes("foo")), AnsibleUnsafeText)

    # Test whether UnsafeProxy.__new__ performs correctly when unsafety is explicit
    assert isinstance

# Generated at 2022-06-23 14:40:50.814161
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    t = b'test'
    assert to_unsafe_text(t)
    unsafe_t = to_unsafe_text(t)
    assert isinstance(unsafe_t, AnsibleUnsafeText)
    assert unsafe_t == u'test'

test_to_unsafe_text()

# Generated at 2022-06-23 14:41:00.243048
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from unittest.case import TestCase  # pylint: disable=import-error
    from ansible.module_utils.six.moves import range

    class TestUnsafeProxy(TestCase):

        def setUp(self):
            self.display = Display()
            self.display.verbosity = 0
            self.default_msg = 'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead'

        def tearDown(self):
            self.display = None
            self.default_msg = None

        def test_new_unicode_string(self):
            expected = AnsibleUnsafeText(to_text(b'___unicode_string___', errors='surrogate_or_strict'))

# Generated at 2022-06-23 14:41:11.299591
# Unit test for function wrap_var
def test_wrap_var():
    var = 'hello'
    var = wrap_var(var)
    assert isinstance(var, AnsibleUnsafeText)
    assert var.__class__.__name__ == 'AnsibleUnsafeText'
    assert var == 'hello'

    var = b'hello'
    var = wrap_var(var)
    assert isinstance(var, AnsibleUnsafeBytes)
    assert var.__class__.__name__ == 'AnsibleUnsafeBytes'
    assert var == b'hello'

    var = tuple([1, 2, 3])
    var = wrap_var(var)
    assert isinstance(var, tuple)
    assert var == (1, 2, 3)

    var = [1, 2, 3]
    var = wrap_var(var)
    assert isinstance(var, list)

# Generated at 2022-06-23 14:41:12.975938
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes(b"foo"), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:41:18.477300
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    unsafe_utf8_string = "本身"
    unsafe_utf8 = AnsibleUnsafeText(unsafe_utf8_string)
    assert isinstance(unsafe_utf8, AnsibleUnsafeText)
    assert unsafe_utf8.encode() == AnsibleUnsafeBytes(unsafe_utf8)

# Generated at 2022-06-23 14:41:28.449958
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # Test 1:
    # Test that a instantiated AnsibleUnsafeBytes object has the attribute
    # __UNSAFE__ set to True
    unsafe_bytes = AnsibleUnsafeBytes()
    assert unsafe_bytes.__UNSAFE__ == True

    # Test 2:
    # Test that a instantiated AnsibleUnsafeBytes object has the method
    # decode.
    assert hasattr(unsafe_bytes, 'decode')

    # Test 3:
    # Test that a instantiated AnsibleUnsafeBytes object decoded with
    # the method decode returns an AnsibleUnsafeText object
    unsafe_text = unsafe_bytes.decode()
    assert isinstance(unsafe_text, AnsibleUnsafeText)



# Generated at 2022-06-23 14:41:32.210806
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    value = AnsibleUnsafeBytes(b'abc')
    value_decoded = value.decode()

    assert isinstance(value_decoded, AnsibleUnsafeText)
    assert value_decoded == 'abc'


# Generated at 2022-06-23 14:41:34.981663
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText("abc").encode('ascii'), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:41:41.316641
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Create a mock Display object because Display.deprecated uses it
    # and it is not available in a unit test.
    class Display(object):
        def deprecated(self, *args, **kwargs):
            pass

    u = UnsafeProxy('test1', Display())
    assert isinstance(u, AnsibleUnsafeText)

    # This will be a no-op, so we don't expect another unsafe
    u = UnsafeProxy(u, Display())
    assert isinstance(u, AnsibleUnsafeText)



# Generated at 2022-06-23 14:41:42.828159
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    AnsibleUnsafeBytes.decode('привет')

# Generated at 2022-06-23 14:41:47.080198
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    text_unsafe = b"this is a test"
    test_unsafe_text = text_unsafe.decode('utf-8')
    assert isinstance(test_unsafe_text, AnsibleUnsafeText) is True
    assert isinstance(test_unsafe_text, AnsibleUnsafe) is True
    test_unsafe_text_new = AnsibleUnsafeText()
    assert isinstance(test_unsafe_text_new, AnsibleUnsafeText) is True

# Generated at 2022-06-23 14:41:51.813061
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    # Test where the input is not a string
    class TestClass():
        pass

    assert isinstance(UnsafeProxy(TestClass), TestClass)

    # Test where the input is a string
    assert isinstance(UnsafeProxy("test"), AnsibleUnsafeText)

# Generated at 2022-06-23 14:41:54.269864
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    s = b'abc'
    a = AnsibleUnsafeBytes(s)
    assert type(a) == AnsibleUnsafeBytes
    assert a == s


# Generated at 2022-06-23 14:41:58.628843
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    v = 'z'
    assert isinstance(v, string_types)
    p = UnsafeProxy(v)
    assert isinstance(p, binary_type)

    v = b'zz'
    assert isinstance(v, binary_type)
    p = UnsafeProxy(v)
    assert isinstance(p, binary_type)



# Generated at 2022-06-23 14:42:07.541286
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # test for python interpreter 2.7
    assert isinstance("str", AnsibleUnsafeText)
    assert isinstance(u"str", AnsibleUnsafeText)
    a = AnsibleUnsafeText("str")
    assert isinstance(a, AnsibleUnsafeText)
    # test for python 3.2
    assert isinstance(b"str", bytes)
    b = AnsibleUnsafeText(b"str")
    assert isinstance(b, AnsibleUnsafeText)
    assert isinstance(b.encode('utf-8'), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:42:10.295541
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    ans_unsafe_bytes = AnsibleUnsafeBytes("Bytes")
    assert(ans_unsafe_bytes.decode("UTF-8") == "Bytes")


# Generated at 2022-06-23 14:42:12.862891
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    ansible_unsafe = AnsibleUnsafe()
    assert ansible_unsafe.__UNSAFE__ == True


# Generated at 2022-06-23 14:42:15.307582
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b"test_case").decode(), AnsibleUnsafeText)



# Generated at 2022-06-23 14:42:21.885967
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    test_AnsibleUnsafeBytes = b'AnsibleUnsafeBytes'
    # test_AnsibleUnsafeBytes is created by adding a b in front of the string.
    # if we decode it, it will return a unicode type
    testvar = 'testvar'
    result = AnsibleUnsafeBytes.decode(test_AnsibleUnsafeBytes, testvar)
    assert isinstance(result, AnsibleUnsafeText)



# Generated at 2022-06-23 14:42:26.110020
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert(isinstance(AnsibleUnsafeText(b"somebytes").encode(), AnsibleUnsafeBytes))
    assert(isinstance(AnsibleUnsafeText("somestr").encode(), AnsibleUnsafeBytes))



# Generated at 2022-06-23 14:42:37.010467
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    import sys
    import io
    import ansible.module_utils.basic
    ansible.module_utils.basic.AnsibleModule = ansible.module_utils.basic.AnsibleModuleStub

    # Capture standard out and standard error.
    stdout = io.StringIO()
    stderr = io.StringIO()
    sys.stdout = stdout
    sys.stderr = stderr

    # Execute the constructor.
    unsafe_text = AnsibleUnsafeText("unsafe_text")

    # Uncapture standard out and standard error.
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__

    # Decide whether the test passed.

# Generated at 2022-06-23 14:42:38.785525
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('foo') == AnsibleUnsafeText(u'foo')

# Generated at 2022-06-23 14:42:44.069255
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes("abc"), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b"abc"), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u"abc"), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u"\u2222"), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:42:46.036097
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert(AnsibleUnsafeBytes(b'hi').decode() == 'hi')



# Generated at 2022-06-23 14:42:55.506988
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # Test to see if constructor copies the bytes correctly
    b = AnsibleUnsafeBytes(b"test")
    assert b == b"test"

    # Test to see if constructor copies the bytes correctly (with integer)
    b = AnsibleUnsafeBytes(1)
    assert b == b'1'

    # Test to see if constructor copies the bytes correctly (with string)
    b = AnsibleUnsafeBytes("test")
    assert b == b"test"

    # Test to see if constructor copies the bytes correctly (with AnsibleUnsafeText object)
    b = AnsibleUnsafeBytes(AnsibleUnsafeText("test"))
    assert b == b"test"


# Generated at 2022-06-23 14:43:03.839958
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('foo') == 'foo'
    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeBytes)
    assert to_unsafe_bytes('foo', encoding='utf-8') == 'foo'
    assert isinstance(to_unsafe_bytes('foo', encoding='utf-8'), AnsibleUnsafeBytes)
    assert to_unsafe_bytes(b'bar') == b'bar'
    assert isinstance(to_unsafe_bytes(b'bar'), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:43:13.454627
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import text_type
    class Foo:
        __str__ = lambda _: 'foo'

    # string doesn't change
    assert isinstance(to_unsafe_bytes('foo'), binary_type)

    # unicode + ascii bytes don't change
    assert isinstance(to_unsafe_bytes(u'foo'), binary_type)
    assert isinstance(to_unsafe_bytes(u'foo', encoding='ascii'), binary_type)

    # unicode + utf-8 bytes change to unicode
    assert isinstance(to_unsafe_bytes(u'foo', encoding='utf-8'), text_type)

    # int, float, bool don't change
    assert isinstance(to_unsafe_bytes(1), int)

# Generated at 2022-06-23 14:43:16.611499
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    # Create a safe string
    data = 'This is a safe string'

    # Construct a unsafe string using UnsafeProxy
    data2 = UnsafeProxy(data)

    # Check if it's is marked as being unsafe
    assert data2.__UNSAFE__

    # Check if the type is AnsibleUnsafeText
    assert isinstance(data2, AnsibleUnsafeText)

# Generated at 2022-06-23 14:43:26.549936
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.common._collections_compat import Sequence

    # Successful case
    assert isinstance(UnsafeProxy(""), AnsibleUnsafeText)
    # But keep string.__new__ behavior of returning *single* instance on repeated calls
    assert UnsafeProxy("") is UnsafeProxy("")

    assert isinstance(UnsafeProxy(""), text_type)
    assert isinstance(UnsafeProxy(""), AnsibleUnsafe)

    # Mapping
    assert isinstance(UnsafeProxy({}), Mapping)
    assert isinstance(UnsafeProxy({}), AnsibleUnsafe)

    # Sequence
    assert isinstance(UnsafeProxy(()), Sequence)
    assert isinstance(UnsafeProxy((1,)), Sequence)
    assert isinstance(UnsafeProxy([]), Sequence)

# Generated at 2022-06-23 14:43:28.425978
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    s = AnsibleUnsafeText("hello")
    assert(s == "hello")

# Generated at 2022-06-23 14:43:32.749041
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes(b'foo'), AnsibleUnsafeBytes)
    assert AnsibleUnsafeBytes(b'foo').__UNSAFE__

    assert isinstance(AnsibleUnsafeBytes(), AnsibleUnsafeBytes)
    assert AnsibleUnsafeBytes().__UNSAFE__



# Generated at 2022-06-23 14:43:35.525918
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    u = AnsibleUnsafe()
    assert u.__UNSAFE__ is True



# Generated at 2022-06-23 14:43:38.273046
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    result = AnsibleUnsafeText("Hello World")
    assert(result == "Hello World")

    result = AnsibleUnsafeText(None)
    assert(result == None)

    result = AnsibleUnsafeText(1)
    assert(result == 1)



# Generated at 2022-06-23 14:43:47.632878
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    assert to_unsafe_bytes(u'hello') == b'hello', "Expected to_unsafe_bytes to return a AnsibleUnsafeBytes"
    assert isinstance(to_unsafe_bytes(u'hello'), AnsibleUnsafeBytes), "Expected to_unsafe_bytes to return a AnsibleUnsafeBytes"
    assert isinstance(to_unsafe_bytes({'a': {'b': u'hello'}}), dict), "Expected to_unsafe_bytes to return a dict"

# Generated at 2022-06-23 14:43:58.414256
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    import sys
    import unittest

    def to_bytes(text, encoding=None, errors='strict'):
        """
        Return the binary representation of `text`. If `text`
        is already a bytes object, return it as-is."""
        if isinstance(text, binary_type):
            return text
        if not isinstance(text, text_type):
            raise TypeError('to_bytes must receive a unicode, got %s' % type(text))
        if encoding is None:
            encoding = sys.getdefaultencoding()
        return text.encode(encoding, errors)


# Generated at 2022-06-23 14:44:00.423081
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert not hasattr(AnsibleUnsafe(), '__UNSAFE__')



# Generated at 2022-06-23 14:44:08.486798
# Unit test for function wrap_var
def test_wrap_var():
    import pytest

    assert wrap_var("foo") == u"foo"
    assert wrap_var("foo") == "foo"

    # Ensure we don't convert
    assert wrap_var(u"foo") == u"foo"
    assert wrap_var(u"foo") == "foo"
    assert wrap_var(b"foo") == b"foo"
    assert wrap_var(b"foo") == u"foo"

    assert wrap_var(1) == 1
    assert wrap_var(1) == 1

    assert wrap_var([1, "foo"]) == [1, u"foo"]
    assert wrap_var([1, "foo"]) == [1, "foo"]

    assert wrap_var({1: "foo"}) == {1: u"foo"}
    assert wrap_var({1: "foo"})

# Generated at 2022-06-23 14:44:11.631795
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    x = NativeJinjaUnsafeText('{{ 0.1 + 0.2 }}')

    y = NativeJinjaUnsafeText('{{ 0.1 + 0.2 }}')
    assert(x == y)

    z = NativeJinjaUnsafeText('{{ 0.1 + 0.2 }}')
    assert(x is z)

# Generated at 2022-06-23 14:44:13.396519
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert AnsibleUnsafeBytes(b"abc123").decode() == "abc123"


# Generated at 2022-06-23 14:44:25.104603
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.six import PY2
    if PY2:
        assert isinstance(UnsafeProxy('foo'), AnsibleUnsafeText)
        assert isinstance(UnsafeProxy(u'foo'), AnsibleUnsafeText)
        assert isinstance(UnsafeProxy(b'foo'), AnsibleUnsafeBytes)
    else:
        assert isinstance(UnsafeProxy('foo'), str)
        assert isinstance(UnsafeProxy(u'foo'), str)
        assert isinstance(UnsafeProxy(b'foo'), bytes)

    assert isinstance(UnsafeProxy(UnsafeProxy('foo')), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(UnsafeProxy(u'foo')), AnsibleUnsafetext)

# Generated at 2022-06-23 14:44:35.650709
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    my_string = 'This is a test for UnsafeText'
    my_byte = b'This is a test for UnsafeBytes'
    my_unicode = u'This is a test for UnsafeText'
    my_int = 100
    my_float = 100.00
    my_list = ['abc', 'xyz']
    my_dict = {'abc': 'xyz', '123': 123}

    assert isinstance(to_unsafe_text(my_string), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(my_byte), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(my_unicode), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(my_int), AnsibleUnsafeText)

# Generated at 2022-06-23 14:44:40.753425
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.utils.unsafe_proxy import UnsafeProxy
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    assert isinstance(UnsafeProxy(u"text"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b"binary"), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:44:44.552886
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText('test').encode(), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText('test').encode().decode(), AnsibleUnsafeText)



# Generated at 2022-06-23 14:44:46.599455
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    ansible_unsafe_object = AnsibleUnsafe()
    assert isinstance(ansible_unsafe_object, AnsibleUnsafe)


# Generated at 2022-06-23 14:44:48.544894
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    a = AnsibleUnsafeText("test")
    assert a == "test"


# Generated at 2022-06-23 14:44:58.557635
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Test direct calls to the method
    assert isinstance(UnsafeProxy('test'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'test'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(None), type(None))
    assert isinstance(UnsafeProxy(1), type(1))
    assert isinstance(UnsafeProxy(0.0), type(0.0))
    assert isinstance(UnsafeProxy([0]), list)
    assert isinstance(UnsafeProxy({'test': 'test'}), dict)

    # Test calls to the method via __new__
    assert isinstance(UnsafeProxy.__new__(UnsafeProxy, 'test'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy.__new__(UnsafeProxy, b'test'), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:45:09.362626
# Unit test for function to_unsafe_text
def test_to_unsafe_text():

    assert isinstance(to_unsafe_text('foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(None), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'foo'), AnsibleUnsafeText)

    assert isinstance(to_unsafe_text(text_type(None)), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(binary_type('foo'), encoding='utf-8'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text('foo', errors='surrogate_or_strict'), AnsibleUnsafeText)

    assert isinstance(to_unsafe_text(123), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text([1, 2, 3]), List)
    assert isinstance

# Generated at 2022-06-23 14:45:16.564215
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    from ansible.module_utils.six import text_type, binary_type
    from ansible.module_utils.six.moves import StringIO
    import json

    # ANSIBLE_TEST_DATA_ROOT environment variable is used for testing
    # if set, data files are loaded from there
    # otherwise, files are loaded from ../../test/units/module_utils/test_collections_compat.py
    test_data_root = os.environ.get('ANSIBLE_TEST_DATA_ROOT')

# Generated at 2022-06-23 14:45:27.968508
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), AnsibleUnsafe)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var({'foo': 'bar'}), dict)
    assert isinstance(wrap_var([1, 2, 3]), list)
    assert isinstance(wrap_var((1, 2, 3)), tuple)

    for var in [1, 1.0, 1.1, ['foo'], ('foo', 'bar'), {'foo': 'bar'}, set(['foo']), True, False]:
        assert isinstance(wrap_var(var), type(var))

# Generated at 2022-06-23 14:45:38.393646
# Unit test for function wrap_var
def test_wrap_var():
    import collections
    import sys

    test_dict = dict(
        a=1,
        b='string',
        c=u'string2',
        d=[1, 2, 3],
        e=dict(a=1, b=2, c=3)
    )

    def test_unwrap(unsafe_obj, non_unsafe_obj):
        if sys.version_info < (2, 7):
            import unittest2 as unittest
        else:
            import unittest

        class UnsafeProxyTest(unittest.TestCase):
            def test_isinstance(self):
                self.assertIsInstance(unsafe_obj, AnsibleUnsafe)

            def test_equals(self):
                self.assertEqual(unsafe_obj, non_unsafe_obj)

        un

# Generated at 2022-06-23 14:45:46.131411
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    b = to_bytes("123")
    ansible_unsafe_bytes = AnsibleUnsafeBytes(b)
    assert isinstance(ansible_unsafe_bytes, binary_type), "Did not create binary_type."
    assert isinstance(ansible_unsafe_bytes, AnsibleUnsafe), "Did not create AnsibleUnsafe."
    assert ansible_unsafe_bytes.decode() == "123", "Did not convert binary_type to AnsibleUnsafeText correctly."
    return True

if __name__ == "__main__":
    test_AnsibleUnsafeBytes()

# Generated at 2022-06-23 14:45:48.514116
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    test_object = AnsibleUnsafeBytes('test')
    assert isinstance(test_object.decode('utf-8'), AnsibleUnsafeText)



# Generated at 2022-06-23 14:45:50.351972
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe.__UNSAFE__ is True


# Generated at 2022-06-23 14:46:02.769561
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils._text import to_text

    assert isinstance(to_unsafe_text('foo'), AnsibleUnsafeText)
    assert to_unsafe_text('foo') == 'foo'
    assert isinstance(to_unsafe_text(u'foo'), AnsibleUnsafeText)
    assert to_unsafe_text(u'foo') == u'foo'
    assert to_text(to_unsafe_text(u'foo')) == u'foo'
    assert isinstance(to_unsafe_text(b'foo'), AnsibleUnsafeText)
    assert to_unsafe_text(b'foo') == b'foo'
    assert to_text(to_unsafe_text(b'foo')) == b'foo'

# Generated at 2022-06-23 14:46:05.504144
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert type(AnsibleUnsafeBytes(b'abc').decode()) is AnsibleUnsafeText


# Generated at 2022-06-23 14:46:07.396014
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText("test").encode(), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:46:18.342287
# Unit test for function wrap_var
def test_wrap_var():
    # All of the following tests are expected to pass.
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(False) is False
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(b'abc') == b'abc'
    assert wrap_var(u'abc') == u'abc'
    assert wrap_var(set([u'abc'])) == set([u'abc'])
    assert wrap_var(set([b'abc'])) == set([b'abc'])
    assert wrap_var([b'abc']) == [b'abc']
    assert wrap_var([u'abc']) == [u'abc']

# Generated at 2022-06-23 14:46:20.037473
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    a=NativeJinjaUnsafeText("test")
    assert isinstance(a, NativeJinjaUnsafeText)

# Generated at 2022-06-23 14:46:28.940402
# Unit test for function wrap_var
def test_wrap_var():
    import sys

    class Foo(object):
        pass

    assert type(wrap_var(None)) is type(None)
    assert type(wrap_var(1)) is type(1)
    assert type(wrap_var(True)) is type(True)
    assert type(wrap_var(1.0)) is type(1.0)
    assert type(wrap_var('foo')) is type('foo')
    assert type(wrap_var([1, 2])) is list
    assert type(wrap_var(['foo', 'bar'])) is list
    assert type(wrap_var(('foo', 'bar'))) is tuple
    assert type(wrap_var(set(['foo', 'bar']))) is set
    assert type(wrap_var({'foo': 'bar', 'no': 'way'})) is dict
    assert type

# Generated at 2022-06-23 14:46:34.275043
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy('hi'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'hi'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy('hi'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'hi'), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:46:37.851583
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes(u'foo'), AnsibleUnsafeBytes)

if __name__ == "__main__":
    import pytest
    pytest.main("-v")

# Generated at 2022-06-23 14:46:47.839744
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert isinstance(wrap_var(1), int)
    assert isinstance(wrap_var(1.0), float)
    assert isinstance(wrap_var(dict()), dict)
    assert isinstance(wrap_var(list()), list)
    assert wrap_var(UnsafeProxy(None)) is None
    assert isinstance(wrap_var(UnsafeProxy(1)), int)
    assert isinstance(wrap_var(UnsafeProxy(1.0)), float)
    assert isinstance(wrap_var(UnsafeProxy(dict())), dict)
    assert isinstance(wrap_var(UnsafeProxy(list())), list)
    assert isinstance(wrap_var(""), AnsibleUnsafeText)

# Generated at 2022-06-23 14:46:49.692812
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    njut = NativeJinjaUnsafeText('test string')
    assert njut.__UNSAFE__ == True

# Generated at 2022-06-23 14:47:01.724591
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import ansible.constants as C
    from ansible.module_utils.six import PY3
    C.DEFAULT_LOCALE_ENCODING = 'UTF-8'
    assert to_unsafe_text('abc') == 'abc'
    assert to_unsafe_text(b'abc') == 'abc'
    if PY3:
        assert to_unsafe_text(b'\x80'.decode('latin-1')) == '\ufffd\ufffd'
    else:
        assert to_unsafe_text(b'\x80') == '\ufffd\ufffd'
    assert to_unsafe_text('ä') == 'ä'
    assert to_unsafe_text(b'\xc3\xa4') == 'ä'

# Generated at 2022-06-23 14:47:12.820608
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    ansible_text = AnsibleUnsafeText('AnsibleUnsafeText')
    assert isinstance(ansible_text, AnsibleUnsafeText)
    assert hasattr(ansible_text, '__UNSAFE__') and ansible_text.__UNSAFE__
    assert isinstance(ansible_text, AnsibleUnsafe)
    assert isinstance(ansible_text, text_type)
    assert isinstance(ansible_text, string_types)
    ansible_text_converted_to_bytes = ansible_text.encode()
    assert isinstance(ansible_text_converted_to_bytes, AnsibleUnsafeBytes)
    assert isinstance(ansible_text_converted_to_bytes, AnsibleUnsafe)

# Generated at 2022-06-23 14:47:14.690658
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert AnsibleUnsafeBytes(b'foo').decode() == 'foo'


# Generated at 2022-06-23 14:47:24.416680
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # Check that AnsibleUnsafeText(text).encode(encoding, errors)
    # returns AnsibleUnsafeBytes
    text = u'\u6b22\u8fce'  # hello in chinese
    ansibletext = AnsibleUnsafeText(text)
    encoding = 'utf-8'
    errors = 'surrogate_or_strict'
    ansiblebytes = ansibletext.encode(encoding, errors)
    assert isinstance(ansiblebytes, AnsibleUnsafeBytes)
    assert ansiblebytes == b'\xe6\xb0\xb4\xe9\x9d\xa2'

# Generated at 2022-06-23 14:47:35.041204
# Unit test for function wrap_var
def test_wrap_var():
    ''' Test wrap_var function'''
    from string import ascii_letters, digits
    from six import integer_types, binary_type, text_type
    from random import choice

    def random_string(length=8, chars=ascii_letters + digits):
        ''' Generate a random string '''
        return ''.join(choice(chars) for _ in range(length))

    # Generate a random string
    random_str = random_string()

    # Test for function wrap_var
    assert isinstance(wrap_var(random_str), text_type)
    assert isinstance(wrap_var(random_str), AnsibleUnsafeText)
    assert wrap_var(to_text(random_str)).__UNSAFE__

    # Create a dictionary to test wrap_var

# Generated at 2022-06-23 14:47:41.354969
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import unittest

    class TestToUnsafeText(unittest.TestCase):
        def test_to_unsafe_text(self):
            self.assertIsInstance(to_unsafe_text('test_string'), str)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestToUnsafeText)
    unittest.TextTestRunner(verbosity=2).run(suite)


# Generated at 2022-06-23 14:47:43.029338
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes(b'bytes') == b'bytes'



# Generated at 2022-06-23 14:47:53.219078
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():

    arg = 'arg'
    kwarg = 'kwarg'

    class TestException(Exception):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    class TestAnsibleUnsafeBytes(AnsibleUnsafeBytes):
        def decode(*args, **kwargs):
            raise TestException(*args, **kwargs)

    try:
        TestAnsibleUnsafeBytes().decode(arg, kwarg=kwarg)
    except TestException as e:
        assert arg in e.args
        assert e.kwargs == {'kwarg': kwarg}
    else:
        raise AssertionError('TestException not thrown')



# Generated at 2022-06-23 14:47:55.373389
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    au = AnsibleUnsafeText('a')
    assert au.__UNSAFE__ == True



# Generated at 2022-06-23 14:47:58.070156
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert to_text(UnsafeProxy(b'\xc3\xbc'), encoding='utf-8') in [u'ü', u'\xfc']

# Generated at 2022-06-23 14:48:04.632247
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    unsafe_text = NativeJinjaUnsafeText("Test text")
    assert(isinstance(unsafe_text, NativeJinjaUnsafeText))
    assert(isinstance(unsafe_text, NativeJinjaText))
    assert(isinstance(unsafe_text, AnsibleUnsafeText))
    assert(isinstance(unsafe_text, text_type))


# Generated at 2022-06-23 14:48:06.985411
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes("YnVpbGRfZW5naW5lX2lw", "utf-8"), AnsibleUnsafeBytes)

