

# Generated at 2022-06-23 14:38:02.249090
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    s = "This is a string"
    assert wrap_var(s).__UNSAFE__



# Generated at 2022-06-23 14:38:05.657758
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    s = AnsibleUnsafeBytes(b"foo")
    assert(s == b"foo")


# Generated at 2022-06-23 14:38:11.279250
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.utils.display import Display
    Display().deprecated(
        'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )


# Generated at 2022-06-23 14:38:20.677471
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes(), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u'foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u'foo'.encode('utf-8')), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'foo'.decode('utf-8')), AnsibleUnsafeBytes)
    assert to_unsafe_bytes(
        u'The \u263a character'.encode('utf-8')
    ) == AnsibleUnsafeBytes(
        u'The \u263a character'.encode('utf-8')
    )
    assert to_unsafe_bytes(b'foo')

# Generated at 2022-06-23 14:38:26.952014
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert issubclass(AnsibleUnsafeBytes, binary_type)
    assert isinstance(AnsibleUnsafeBytes(b''), binary_type)
    assert isinstance(AnsibleUnsafeBytes(b''), AnsibleUnsafe)
    assert isinstance(AnsibleUnsafeBytes(b''), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeBytes(b''), AnsibleUnsafeText)



# Generated at 2022-06-23 14:38:37.028701
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.common.collections import is_sequence

    assert isinstance(to_unsafe_text(u'Foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'Foo'), AnsibleUnsafeText)

    # this tests the _wrap_dict function
    dict_val = {u'foo': u'bar', b'baz': u'faz'}
    wrapped = to_unsafe_text(dict_val)
    assert isinstance(wrapped, dict)
    assert isinstance(wrapped.keys()[0], AnsibleUnsafeText)
    assert isinstance(wrapped.keys()[1], AnsibleUnsafeText)
    assert isinstance(wrapped.values()[0], AnsibleUnsafeText)

# Generated at 2022-06-23 14:38:47.231011
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import unittest

    class TestToUnsafeText(unittest.TestCase):
        def test_text_string(self):
            self.assertEqual(isinstance(to_unsafe_text(u"hello"), AnsibleUnsafeText), True)

        def test_unicode_string(self):
            self.assertEqual(isinstance(to_unsafe_text(u"hello"), AnsibleUnsafeText), True)

        def test_byte_string(self):
            self.assertEqual(isinstance(to_unsafe_text(b"hello"), AnsibleUnsafeText), True)

        def test_list_string(self):
            self.assertEqual(isinstance(to_unsafe_text([u"hello"]), AnsibleUnsafeBytes), True)


# Generated at 2022-06-23 14:38:51.511598
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    class DummyModule:
        pass

    m = DummyModule()
    m.argument_spec = {}
    tmp = AnsibleUnsafeText('testing')
    assert isinstance(tmp.encode(), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:39:03.884759
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('some test str') == 'some test str'
    assert isinstance(wrap_var(u'some test str'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'some test str'), AnsibleUnsafeBytes)
    assert wrap_var(to_text(u'some test str')) == 'some test str'
    assert isinstance(wrap_var(to_text(u'some test str')), AnsibleUnsafeText)
    assert wrap_var(to_bytes(u'some test str')) == b'some test str'
    assert isinstance(wrap_var(to_bytes(u'some test str')), AnsibleUnsafeBytes)

    assert wrap_var([u'some test str', u'some test str']) == ['some test str', 'some test str']
    assert isinstance

# Generated at 2022-06-23 14:39:13.171540
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b''.join([chr(i) for i in range(256)])), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u''.join([chr(i) for i in range(0, 65536, 1000)])), AnsibleUnsafeText)
    assert isinstance(wrap_var(NativeJinjaText('{{ foo }}')), NativeJinjaUnsafeText)
    assert isinstance(wrap_var(dict(foo='bar', baz=1)), dict)


# Generated at 2022-06-23 14:39:20.856821
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    # Test transformation of a string
    assert(isinstance(to_unsafe_bytes('abc'), AnsibleUnsafeBytes))
    # Nothing should happen to a byte literal
    assert(isinstance(to_unsafe_bytes(b'abc'), AnsibleUnsafeBytes))
    # Test conversion from a safe unicode string
    assert(isinstance(to_unsafe_bytes(u"abc"), AnsibleUnsafeBytes))
    # Test conversion from an unsafe string
    assert(isinstance(to_unsafe_bytes(AnsibleUnsafeText(u"abc")), AnsibleUnsafeBytes))


# Generated at 2022-06-23 14:39:23.499085
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy('this is a string'), AnsibleUnsafeText)



# Generated at 2022-06-23 14:39:25.568314
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    x = UnsafeProxy("test string")
    assert(type(x) == type(AnsibleUnsafeText("")))

# Generated at 2022-06-23 14:39:30.324719
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    # Test to_unsafe_text when no conversion done
    assert isinstance(to_unsafe_text("foo"), AnsibleUnsafeText)

    # Test to_unsafe_text when conversion from binary to text done
    assert isinstance(to_unsafe_text(to_bytes("foo")), AnsibleUnsafeText)

# Generated at 2022-06-23 14:39:33.660062
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes("foo"), AnsibleUnsafeText)
    assert isinstance(to_unsafe_bytes("foo".encode("utf-8")), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:39:35.453481
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    class Foo(AnsibleUnsafe):
        def __init__(self):
            pass
    pass


# Generated at 2022-06-23 14:39:47.178089
# Unit test for function wrap_var
def test_wrap_var():
    import io
    import sys

    import ansible.module_utils.psutil_common

    if sys.version_info[0] == 2:
        # https://github.com/ansible/ansible/pull/46938 Addition of "from_utf8" support added in ansible 2.8
        import ansible.module_utils.six.moves.StringIO as StringIO
        StringIO_Class = StringIO.StringIO
    else:
        StringIO_Class = io.StringIO

    class StreamObj(StringIO_Class):
        '''class to test if wrapping works correctly when a value is passed
        that has a .fileno() method
        '''
        def fileno(self):
            return 1

    class DummyModule(object):
        def __init__(self, *args, **kwargs):
            self

# Generated at 2022-06-23 14:39:49.395962
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe().__UNSAFE__ == True



# Generated at 2022-06-23 14:39:51.844560
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText(u'\x00').encode(), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:39:54.267563
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText('hi').encode('utf-8'), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:39:56.345147
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    new_dict_proxied = AnsibleUnsafe()
    assert new_dict_proxied.__UNSAFE__ == True


# Generated at 2022-06-23 14:39:59.267057
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    obj = NativeJinjaUnsafeText("test")
    t = wrap_var(obj)
    assert(type(t) == NativeJinjaUnsafeText)



# Generated at 2022-06-23 14:40:01.293869
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert type(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes


# Generated at 2022-06-23 14:40:03.185132
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText("hi").encode(), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:40:05.790898
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert isinstance(AnsibleUnsafeText('foo'), text_type)  # pylint: disable=unidiomatic-typecheck



# Generated at 2022-06-23 14:40:11.771225
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    from ansible.module_utils.six import PY3
    b = AnsibleUnsafeBytes('foo')
    assert isinstance(b, binary_type)
    assert isinstance(b, AnsibleUnsafe)
    if PY3:
        assert isinstance(b, bytes)
    else:
        assert isinstance(b, str)



# Generated at 2022-06-23 14:40:13.740299
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b'x').decode(), AnsibleUnsafeText)


# Generated at 2022-06-23 14:40:24.677067
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.native_jinja import NativeJinjaText
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import range

    assert None is wrap_var(None)
    assert True is wrap_var(True)
    assert 1 is wrap_var(1)
    assert u"test" is wrap_var(u"test")
    assert b"test" is wrap_var(b"test")
    assert u"test" is wrap_var(b"test")
    assert [1,2] is wrap_var([1,2])
    assert (1,2) is wrap_var((1,2))
    assert dict(foo=1, bar=2) is wrap_var(dict(foo=1, bar=2))

# Generated at 2022-06-23 14:40:29.096401
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    a = UnsafeProxy('pymysql')
    print(a)
    b = UnsafeProxy(123)
    print(b)
    assert a == 'pymysql'
    assert b == 123

if __name__ == '__main__':
    test_UnsafeProxy()

# Generated at 2022-06-23 14:40:39.285746
# Unit test for function wrap_var
def test_wrap_var():
    import pytest


# Generated at 2022-06-23 14:40:49.919331
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import PY3

    str_type = string_types if PY3 else text_type

    a = wrap_var(1)
    assert(a == 1)

    a = wrap_var('a')
    assert(isinstance(a, AnsibleUnsafeText))
    assert(isinstance(a, str_type))

    a = wrap_var(u'a')
    assert(isinstance(a, str_type))

    a = wrap_var({'a': 1})
    assert(isinstance(a, dict))
    assert(isinstance(a.get('a'), AnsibleUnsafeText))

    a = wrap_var([u'a', 1])
    assert(isinstance(a, list))

# Generated at 2022-06-23 14:40:52.634075
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    obj = UnsafeProxy("foobar")
    assert isinstance(obj, AnsibleUnsafeText)
    assert obj == to_unsafe_text("foobar")


# Generated at 2022-06-23 14:40:56.601525
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes("test") == "test"
    assert AnsibleUnsafeBytes("test").decode("utf-8") == u"test"
    assert AnsibleUnsafeBytes("test").decode("utf-8").encode("utf-8") == b"test"


# Generated at 2022-06-23 14:41:02.769263
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert type(to_unsafe_text('hello')) is AnsibleUnsafeText
    assert type(to_text('hello')) is text_type
    assert type(to_unsafe_text(u'hello')) is AnsibleUnsafeText
    assert type(to_text(u'hello')) is text_type



# Generated at 2022-06-23 14:41:05.744473
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert not hasattr(UnsafeProxy(u"Just string"), '__UNSAFE__')
    assert not hasattr(UnsafeProxy(b"Just string"), '__UNSAFE__')
    assert hasattr(UnsafeProxy(AnsibleUnsafeText(u'Just string')), '__UNSAFE__')
    assert hasattr(UnsafeProxy(AnsibleUnsafeBytes(b'Just string')), '__UNSAFE__')

# Generated at 2022-06-23 14:41:07.124540
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
   a = NativeJinjaUnsafeText("Hello World")
   assert a != None

# Generated at 2022-06-23 14:41:10.114135
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    obj_passed_in = AnsibleUnsafeText("foo")
    obj_created = UnsafeProxy(obj_passed_in)
    assert(obj_passed_in is obj_created)

# Generated at 2022-06-23 14:41:11.384122
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes('abc') == 'abc'


# Generated at 2022-06-23 14:41:22.115231
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # Test passing nothing in.
    assert AnsibleUnsafeText() == ""
    # Test passing a string in
    assert AnsibleUnsafeText("Testing") == "Testing"
    # Test passing a unicode string in
    assert AnsibleUnsafeText(u"Testing") == "Testing"
    # Test passing an AnsibleUnsafeText in
    assert AnsibleUnsafeText(AnsibleUnsafeText("Testing")) == "Testing"
    # Test passing a AnsibleUnsafeBytes in
    assert AnsibleUnsafeText(AnsibleUnsafeBytes("Testing")) == "Testing"
    # Test passing a binary string in
    assert AnsibleUnsafeText("Testing".encode('utf8')) == "Testing"


# Generated at 2022-06-23 14:41:30.476286
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.display import Display
    Display().deprecated(
        'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )
    import types

    test_value = 'abc中文'
    result = UnsafeProxy(test_value)

    # check result type
    assert isinstance(result, AnsibleUnsafeText)

    # check origin value are converted to unsafe text
    assert isinstance(test_value, text_type)

# Generated at 2022-06-23 14:41:34.370387
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    '''
    Test to_unsafe_bytes function.
    '''
    assert to_unsafe_bytes('test') == AnsibleUnsafeBytes(b'test')
    assert to_unsafe_bytes(u'test') == AnsibleUnsafeBytes(b'test')
    assert to_unsafe_bytes(b'test') == AnsibleUnsafeBytes(b'test')
    assert to_unsafe_bytes({}) is None
    assert to_unsafe_bytes([]) is None


# Generated at 2022-06-23 14:41:36.319548
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    a = AnsibleUnsafe()
    assert a.__UNSAFE__ == True;



# Generated at 2022-06-23 14:41:44.060378
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    def check(s):
        assert isinstance(s, AnsibleUnsafeBytes)
        assert isinstance(s, binary_type)
        assert isinstance(s, AnsibleUnsafe)
        assert AnsibleUnsafe.__UNSAFE__

    check(AnsibleUnsafeBytes(b'hello'))
    check(AnsibleUnsafeBytes(b'hello', encoding='utf-8'))
    check(AnsibleUnsafeBytes(b'hello', encoding='utf-8', errors='ignore'))
    assert AnsibleUnsafeBytes(b'hello', encoding='utf-8').decode() == 'hello'
    assert AnsibleUnsafeBytes.__name__ == 'AnsibleUnsafeBytes'



# Generated at 2022-06-23 14:41:52.504954
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(None) is None
    assert isinstance(to_unsafe_text('foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(to_unsafe_text('foo')), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(to_unsafe_text(b'foo')), AnsibleUnsafeText)


# Generated at 2022-06-23 14:42:03.774540
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.common.text.converters import to_text

    UNSAFE_TEXT = u"Plugin for foo_bar"
    UNSAFE_BYTES = b"Plugin for foo_bar"
    UNSAFE_NATIVE_JINJA = NativeJinjaUnsafeText(
        UNSAFE_TEXT,
        'tests/template.j2',
    )

    assert isinstance(UnsafeProxy(UNSAFE_TEXT), AnsibleUnsafeText)
    assert UnsafeProxy(UNSAFE_TEXT).__UNSAFE__
    assert UnsafeProxy(UNSAFE_TEXT) == UNSAFE_TEXT
    assert isinstance(UnsafeProxy(to_text(UNSAFE_BYTES, errors='surrogate_or_strict')), AnsibleUnsafeText)
    assert Un

# Generated at 2022-06-23 14:42:06.275961
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(b"expect unicode"), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b"expect unicode", encoding="utf-8"), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(AnsibleUnsafeBytes(b"expect unsafe unicode")), AnsibleUnsafeText)



# Generated at 2022-06-23 14:42:08.275537
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:42:13.417779
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy("a") == "a"
    assert UnsafeProxy("a") != b"a"
    assert UnsafeProxy(AnsibleUnsafeBytes("a".encode("utf-8"))) == b"a"
    assert UnsafeProxy(AnsibleUnsafeText("a")) == "a"

# Generated at 2022-06-23 14:42:21.555333
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    # Test function object
    def test_func(*args, **kwargs):
        pass

    assert isinstance(UnsafeProxy("my_string"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(123), int)
    assert isinstance(UnsafeProxy(None), type(None))
    assert isinstance(UnsafeProxy(dict(a=1, b=2)), dict)
    assert isinstance(UnsafeProxy(test_func), type(test_func))
    assert isinstance(UnsafeProxy(dict(a=1, b=UnsafeProxy("my_string"))), dict)

    assert UnsafeProxy("my_string") == "my_string"
    assert UnsafeProxy(123) == 123
    assert UnsafeProxy(None) is None
    assert UnsafeProxy(test_func) == test_func

# Generated at 2022-06-23 14:42:27.782549
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    test_str = 'Hello, World!'
    unsafe_jinja_test_str = NativeJinjaUnsafeText(test_str)
    assert unsafe_jinja_test_str == test_str
    assert unsafe_jinja_test_str.__class__ == NativeJinjaUnsafeText
    assert unsafe_jinja_test_str.__UNSAFE__ == True

# Generated at 2022-06-23 14:42:29.241346
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert isinstance(AnsibleUnsafe(), AnsibleUnsafe)



# Generated at 2022-06-23 14:42:35.950811
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    s = AnsibleUnsafeText("useless text")

    # added to prevent beaking of the existing tests
    # we want to make sure that the method __UNSAFE__ will
    # be present in the class AnsibleUnsafeText

    assert s.__UNSAFE__ == True
    test_text = to_unsafe_text("test text")
    assert test_text.__UNSAFE__ == True

    test_text = AnsibleUnsafeText("test text")
    assert test_text.__UNSAFE__ == True


# Generated at 2022-06-23 14:42:45.831164
# Unit test for function wrap_var
def test_wrap_var():
    def check(obj):
        if isinstance(obj, (unicode, str)):
            assert isinstance(obj, AnsibleUnsafeText), "Expected AnsibleUnsafeText, got %s" % type(obj)
            return True
        elif isinstance(obj, (tuple, list)):
            for item in obj:
                check(item)
            return True
        elif isinstance(obj, dict):
            for k, v in obj.items():
                check(k)
                check(v)
            return True
        return False

    # Test basic type
    assert check(wrap_var('foo'))
    assert check(wrap_var(u'foo'))

    # Test basic type that ansible will never create
    assert check(wrap_var(b'foo'))

# Generated at 2022-06-23 14:42:53.581834
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    import os
    import sys

    my_file = open(os.path.realpath(__file__))
    my_file_text = my_file.read()
    my_file_lines = my_file_text.split('\n')
    module_name = my_file_lines[0]
    my_file.close()

    assert AnsibleUnsafeText(module_name) == sys.modules[__name__].__doc__.split('\n')[0]



# Generated at 2022-06-23 14:42:57.527175
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    aub = AnsibleUnsafeBytes("test")
    assert isinstance(aub, AnsibleUnsafeBytes)
    assert aub.__UNSAFE__


# Generated at 2022-06-23 14:42:59.099256
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert isinstance(AnsibleUnsafe(), AnsibleUnsafe)


# Generated at 2022-06-23 14:43:03.783706
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    safe_string = text_type('foo')
    unsafe_bytes = AnsibleUnsafeBytes(safe_string.encode('utf-8'))
    decoded_string = unsafe_bytes.decode('utf-8')
    assert isinstance(decoded_string, AnsibleUnsafeText)


# Generated at 2022-06-23 14:43:13.418769
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():

    # Generate cases
    cases = ['abc', [123, 345], {'foo': 'bar'}, '']
    cases = [case for case in cases]
    cases += [{case: case} for case in cases]
    cases += [[case] for case in cases]
    cases += [[case, case] for case in cases]
    cases += [[case, case] for case in cases]
    cases += [('abc', 'xyz')]
    cases += [['abc', 'xyz']]
    # Iterate over test cases
    for case in cases:
        # Ensure that instance of a unsafe type is returned unchanged
        case_unsafe = wrap_var(case)
        assert case_unsafe is case

        # Generate cases
        case_bytes = to_bytes(case)
        case_text = to_text(case)

# Generated at 2022-06-23 14:43:18.887401
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('test'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u'test'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'test'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(AnsibleUnsafeText('test')), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(AnsibleUnsafeBytes('test')), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(NativeJinjaText('test')), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(NativeJinjaUnsafeText('test')), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:43:28.128641
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert not hasattr(AnsibleUnsafe, "__UNSAFE__")
    assert hasattr(AnsibleUnsafeBytes, "__UNSAFE__")
    assert hasattr(AnsibleUnsafeText, "__UNSAFE__")
    assert hasattr(NativeJinjaUnsafeText, "__UNSAFE__")

    assert not vars(AnsibleUnsafe)
    assert vars(AnsibleUnsafeBytes)
    assert vars(AnsibleUnsafeText)
    assert vars(NativeJinjaUnsafeText)

    assert isinstance(AnsibleUnsafeBytes(b""), binary_type)
    assert isinstance(AnsibleUnsafeText(""), text_type)
    assert isinstance(NativeJinjaUnsafeText(""), NativeJinjaText)


# Generated at 2022-06-23 14:43:34.131692
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Check that when passing a string to UnsafeProxy
    # the result is an object of type AnsibleUnsafeText
    test_string = "string_test"
    test_object = UnsafeProxy(test_string)
    assert isinstance(test_object, AnsibleUnsafeText)
    # Check that when passing an object of type AnsibleUnsafeText
    # the result is an object of type AnsibleUnsafeText
    test_object = UnsafeProxy(AnsibleUnsafeText("string_test"))
    assert isinstance(test_object, AnsibleUnsafeText)
    # Check that when passing an object of type AnsibleUnsafeBytes
    # the result is an object of type AnsibleUnsafeBytes
    test_object = UnsafeProxy(AnsibleUnsafeBytes("string_test".encode("utf-8")))

# Generated at 2022-06-23 14:43:42.573894
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes("abc"), AnsibleUnsafeText)
    assert isinstance(to_unsafe_bytes(u"abc"), AnsibleUnsafeText)
    assert isinstance(to_unsafe_bytes(u"abc".encode("utf-8")), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u"abc".encode("utf-8"), errors='surrogate_or_strict'), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:43:54.126744
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    import base64
    from ansible.module_utils._text import to_text, to_bytes

    # create a unicode string with special characters
    str1 = "abcdeĕfghĳklmnopqrstuvwxyzàáâãäåæçèéêëìíîïðñòóôõöøùúûüýþÿ"

# Generated at 2022-06-23 14:43:58.946371
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert isinstance(AnsibleUnsafe(), AnsibleUnsafe)
    assert isinstance(AnsibleUnsafeBytes(), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText(), AnsibleUnsafeText)
    assert isinstance(NativeJinjaUnsafeText(), NativeJinjaUnsafeText)


# Generated at 2022-06-23 14:44:06.313257
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.unsafe_proxy import UnsafeProxy
    assert isinstance(UnsafeProxy(None), type(None))
    assert isinstance(UnsafeProxy(True), type(True))
    assert isinstance(UnsafeProxy(1), type(1))
    assert isinstance(UnsafeProxy(1.0), type(1.0))
    assert isinstance(UnsafeProxy(b'abc'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy('abc'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(['a']), list)
    assert isinstance(UnsafeProxy(['a']), list)
    assert isinstance(UnsafeProxy(['a']), list)

# Generated at 2022-06-23 14:44:07.535443
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    return NativeJinjaUnsafeText(ansible_unsafe_bytes, "latin-1")

# Generated at 2022-06-23 14:44:10.788035
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    ansible_unsafe_bytes = AnsibleUnsafeBytes(b"Test string")
    assert ansible_unsafe_bytes.__UNSAFE__

    ansible_unsafe_text = AnsibleUnsafeText(u"Test string")
    assert ansible_unsafe_text.__UNSAFE__

# Generated at 2022-06-23 14:44:13.873491
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    u = u"\u30a9"
    assert isinstance(to_unsafe_text(u), AnsibleUnsafeText)
    assert u in to_unsafe_text(u)

# Generated at 2022-06-23 14:44:22.088573
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    import unittest
    import sys

    class UnsafeProxy_Test(unittest.TestCase):

        def test_UnsafeProxy___new___unicode(self):
            v = text_type('test')
            p = UnsafeProxy(v)
            self.assertTrue(isinstance(p, AnsibleUnsafeText))
            self.assertEqual(v, p)

    unittest.main(verbosity=2, exit=False)
    return



# Generated at 2022-06-23 14:44:25.376029
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    test_string = "testing"
    unsafe_string = UnsafeProxy(test_string)
    assert unsafe_string == test_string
    assert isinstance(unsafe_string, AnsibleUnsafeText) is True
    assert isinstance(unsafe_string, text_type) is True

# Generated at 2022-06-23 14:44:27.515124
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert '__UNSAFE__' in dir(AnsibleUnsafe())


# Generated at 2022-06-23 14:44:36.944557
# Unit test for method decode of class AnsibleUnsafeBytes

# Generated at 2022-06-23 14:44:40.710213
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    testObj = NativeJinjaUnsafeText(b"hello world")
    assert testObj == "hello world"
    assert testObj.encode() == b"hello world"
    assert testObj.__UNSAFE__ == True
    assert isinstance(testObj, AnsibleUnsafe)

# Generated at 2022-06-23 14:44:45.746686
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    """AnsibleUnsafeBytes.decode is a wrapper for unicode.decode
    that returns AnsibleUnsafeText
    """
    str_safe = u'unicode string'
    b = AnsibleUnsafeBytes(str_safe.encode('ascii'))
    assert(b.decode('ascii') == str_safe)

# Generated at 2022-06-23 14:44:49.846769
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text('abc') == 'abc'
    assert isinstance(to_unsafe_text('abc'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'abc'), AnsibleUnsafeText)
    assert to_unsafe_text(u'abc') == 'abc'



# Generated at 2022-06-23 14:44:52.291817
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    bytes_obj = b'foo'
    result = AnsibleUnsafeBytes(bytes_obj).decode()
    assert '__UNSAFE__' in result.__dict__.keys()

# Generated at 2022-06-23 14:44:56.599136
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text("A string") == "A string"
    assert type(to_unsafe_text("A string")) == text_type
    assert to_unsafe_text("A string") == to_text("A string")
    assert type(to_unsafe_text("A string")) == AnsibleUnsafeText

# Generated at 2022-06-23 14:45:00.918417
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    unsafe_text = AnsibleUnsafeBytes(b"testing")
    assert isinstance(unsafe_text, AnsibleUnsafeBytes)

    unsafe_text_1 = AnsibleUnsafeText(u"testing")
    assert isinstance(unsafe_text_1, AnsibleUnsafeText)

# Generated at 2022-06-23 14:45:09.894057
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    from ansible.module_utils.six import PY3

    errmsg = "Unexpected type for AnsibleUnsafeBytes"
    obj = AnsibleUnsafeBytes()
    assert isinstance(obj, AnsibleUnsafe) is True, errmsg
    assert isinstance(obj, binary_type) is True, errmsg

    if PY3:
        errmsg = "Unexpected type for AnsibleUnsafeBytes"
        obj = AnsibleUnsafeBytes(None, encoding='utf-8')
        assert isinstance(obj, AnsibleUnsafe) is True, errmsg
        assert isinstance(obj, binary_type) is True, errmsg


# Generated at 2022-06-23 14:45:18.253525
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.utils.unsafe_proxy import to_unsafe_text
    from .common.unsafe_proxy import assert_equal

    # Assert conversion of bytes to text with AnsibleUnsafeText
    assert_equal(to_unsafe_text(b'value'), u'value')
    assert_equal(type(to_unsafe_text(b'value')), AnsibleUnsafeText)

    # Assert conversion of text to text with AnsibleUnsafeText
    assert_equal(to_unsafe_text(u'value'), u'value')
    assert_equal(type(to_unsafe_text(u'value')), AnsibleUnsafeText)

# Generated at 2022-06-23 14:45:23.596091
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # Test to instantiate a Unsafe object of class AnsibleUnsafe
    unsafe = AnsibleUnsafe()
    assert unsafe

    # Test the type of Unsafe Object created
    if isinstance(unsafe, AnsibleUnsafe):
        assert True
    else:
        assert False



# Generated at 2022-06-23 14:45:32.103876
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy('foo'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(u'foo'), AnsibleUnsafeText)
    assert UnsafeProxy(u'foo').__UNSAFE__
    assert UnsafeProxy(b'foo').__UNSAFE__
    assert isinstance(UnsafeProxy('foo'.decode('utf-8')), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(u'foo'.encode('utf-8')), AnsibleUnsafeBytes)
    assert UnsafeProxy(u'foo'.encode('utf-8')).decode('utf-8').__UNSAFE__

# Generated at 2022-06-23 14:45:41.917971
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText("nothing to do").encode("utf-8"), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText("nothing to do").encode("ascii"), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText("nothing to do").encode("utf-8", "strict"), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText("nothing to do").encode("utf-8", errors="strict"), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText("nothing to do").encode("utf-8", errors="ignore"), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:45:51.349096
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.text.converters import to_bytes

    # Basic test
    val = b'foo'
    res = to_unsafe_bytes(val)
    assert isinstance(res, AnsibleUnsafeBytes)
    assert res == val

    # Test with an unsafe value
    unsafe_val = b'foo'
    val = 'bar'
    res = to_unsafe_bytes(unsafe_val, val)
    assert isinstance(res, AnsibleUnsafeBytes)

    # Test with a safe value
    unsafe_val = b'foo'
    val = b'bar'
    res = to_unsafe_bytes(unsafe_val, val)
    assert isinstance(res, AnsibleUnsafeBytes)

    #

# Generated at 2022-06-23 14:45:55.412449
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert isinstance(AnsibleUnsafeText(u'\u2600'), text_type)
    assert isinstance(AnsibleUnsafeText(u'\u2600'), AnsibleUnsafeText)



# Generated at 2022-06-23 14:46:05.569334
# Unit test for function wrap_var
def test_wrap_var():
    # Testing dicts
    test_dict = dict(
        key1='value1',
        key2='value2'
    )
    wrapped_dict = wrap_var(test_dict)
    assert(type(wrapped_dict) == dict)
    assert(type(wrapped_dict['key1']) == AnsibleUnsafeText)
    assert(type(wrapped_dict['key2']) == AnsibleUnsafeText)

    # Testing lists
    test_list = [
        'list_key1',
        'list_key2'
    ]
    wrapped_list = wrap_var(test_list)
    assert(type(wrapped_list) == list)
    assert(type(wrapped_list[0]) == AnsibleUnsafeText)

# Generated at 2022-06-23 14:46:12.021473
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText('').encode('utf-8'), AnsibleUnsafeBytes)
    assert AnsibleUnsafeText('').encode('utf-8') == b''
    assert isinstance(AnsibleUnsafeText('test').encode('utf-8'), AnsibleUnsafeBytes)
    assert AnsibleUnsafeText('test').encode('utf-8') == b'test'


# Generated at 2022-06-23 14:46:14.822635
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert(isinstance(to_unsafe_bytes("\xFC"), AnsibleUnsafeBytes))
    assert(to_unsafe_bytes("\xFC").__UNSAFE__)

# Generated at 2022-06-23 14:46:17.038153
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert AnsibleUnsafeText("abc") == "abc"
    assert AnsibleUnsafeText("abc").encode("utf8") == b"abc"

# Generated at 2022-06-23 14:46:23.791887
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    # Test to_unsafe_bytes
    assert to_unsafe_bytes('123') == AnsibleUnsafeBytes('123')
    assert to_unsafe_bytes(None) is None
    assert to_unsafe_bytes(AnsibleUnsafeText('test')) == AnsibleUnsafeBytes('test')
    assert to_unsafe_bytes(AnsibleUnsafeBytes('test')) == AnsibleUnsafeBytes('test')
    assert to_unsafe_bytes(NativeJinjaUnsafeText('test')) == AnsibleUnsafeBytes('test')



# Generated at 2022-06-23 14:46:26.123773
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    v = AnsibleUnsafeBytes('1234')
    assert isinstance(v, AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:46:38.602329
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():

    # Create string and int
    a = b'foo'
    b = b'bar'
    c = 1
    d = 2
    # Try to wrap string and int
    wrap_a = wrap_var(a)
    wrap_b = wrap_var(b)
    wrap_c = wrap_var(c)
    wrap_d = wrap_var(d)

    # Check types
    assert isinstance(wrap_a, AnsibleUnsafe)
    assert isinstance(wrap_b, AnsibleUnsafe)
    assert isinstance(wrap_c, AnsibleUnsafeBytes)
    assert isinstance(wrap_d, AnsibleUnsafeBytes)
    assert not isinstance(wrap_a, AnsibleUnsafeText)
    assert not isinstance(wrap_c, AnsibleUnsafeText)

# Generated at 2022-06-23 14:46:45.829538
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    # In our usage we should only receive unicode strings.
    # This conditional and conversion exists to sanity check the values
    # we're given but we may want to take it out for testing and sanitize
    # our input instead.
    string_test_cases = [
        to_text('hello world'),
        u'hello world',
        b'hello world',
        (u'hello world')
    ]

    for string in string_test_cases:
        assert isinstance(UnsafeProxy(string), AnsibleUnsafeText)



# Generated at 2022-06-23 14:46:48.098495
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    usafe = AnsibleUnsafeBytes("123")
    assert type(usafe.decode("utf-8")) == AnsibleUnsafeText

# Generated at 2022-06-23 14:46:50.927518
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    encoded_str = 'Hello World!'
    unsafe_text = AnsibleUnsafeText(encoded_str)
    assert isinstance(unsafe_text.encode(), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:46:57.630965
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # Ensures the type AnsibleUnsafeText is unicode
    unsafe_text = to_unsafe_text(b'\xd0\x9e\xd0\x9d\xd0\x9d\xd0\x9e')
    assert isinstance(unsafe_text, text_type)
    assert unsafe_text.__UNSAFE__ is True


# Generated at 2022-06-23 14:47:04.859428
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():

    from ansible.module_utils.six import PY3, PY2
    import sys

    # Test 1: UnsafeProxy takes a normal string
    foo = 'bar'
    bar = UnsafeProxy(foo)
    assert isinstance(bar, AnsibleUnsafeText)

    # Test 2: UnsafeProxy takes a byte string
    # and returns a byte string
    if sys.version_info >= (3, 0):
        foo = b'bar'
        bar = UnsafeProxy(foo)
        assert isinstance(bar, AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:47:05.795940
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert 'abc' == UnsafeProxy('abc')

# Generated at 2022-06-23 14:47:08.843415
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    text = AnsibleUnsafeText(u"foo")
    assert AnsibleUnsafeBytes(b"foo") == text.encode()

    text = AnsibleUnsafeText(u"föö")
    assert AnsibleUnsafeBytes(b"f\xc3\xb6\xc3\xb6") == text.encode()



# Generated at 2022-06-23 14:47:10.650851
# Unit test for function wrap_var
def test_wrap_var():
    v = u"{{hello}}"
    wrapped_v = wrap_var(v)
    assert isinstance(wrapped_v, NativeJinjaUnsafeText)

# Generated at 2022-06-23 14:47:16.583968
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import jinja2
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import get_file_vault_secret
    import sys
    import pytest
    from ansible.module_utils.six import PY3

    # Test the text in byte sequences
    assert to_unsafe_text(b'foo') == 'foo'
    assert isinstance(to_unsafe_text(b'foo'), AnsibleUnsafeText)

    # Test the text
    assert to_unsafe_text('foo') == 'foo'
    assert isinstance(to_unsafe_text('foo'), AnsibleUnsafeText)

    # Test the Unicode
    if PY3:
        assert to_unsafe_text('é')

# Generated at 2022-06-23 14:47:19.529231
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    a = wrap_var('foo')
    b = a.encode('utf-8')
    assert isinstance(b, AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:47:29.839922
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.display import Display
    Display().deprecated(
        'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )

    # This variable exists to make sure we don't use the same
    # variable for each test
    test_unsafe_text = AnsibleUnsafeText(u"test_unsafe_text")
    test_unsafe_bytes = AnsibleUnsafeBytes(u"test_unsafe_bytes")
    test_native_jinja_unsafe_text = NativeJinjaUnsafeText(u"test_native_jinja_unsafe_text")
    test_str = "test_str"

    assert UnsafeProxy(test_unsafe_text)

# Generated at 2022-06-23 14:47:31.834316
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():

    # Testing constructor of class UnsafeProxy
    assert(type(UnsafeProxy("Testing")) == AnsibleUnsafeText)

# Generated at 2022-06-23 14:47:33.749003
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes('abc'), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:47:39.673619
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils._text import to_bytes, to_text
    result1 = to_unsafe_text(u"\u00A2")
    result2 = to_unsafe_text("\xc2\xa2")
    result3 = to_unsafe_text(b"\xc2\xa2")
    assert result1 == result2 == result3 == u"\u00A2"

# Generated at 2022-06-23 14:47:51.226244
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import PY3
    class A: pass
    class B(A): pass
    class C(B): pass

    a = A()
    b = B()
    c = C()

    # a, b and c are instances of A, B and C respectively
    assert isinstance(a, A) and isinstance(b, B) and isinstance(c, C)

    # proxy of a, b and c
    pa, pb, pc = map(UnsafeProxy, (a, b, c))

    # They are all proxies
    assert all(isinstance(obj, UnsafeProxy) for obj in (pa, pb, pc))

    # They are instances of their respective classes.
    assert isinstance(pa, A) and isinstance(pb, B) and isinstance(pc, C)



# Generated at 2022-06-23 14:47:52.435024
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    NativeJinjaUnsafeText('test')

# Generated at 2022-06-23 14:47:54.459119
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText("foo").encode(), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:47:56.901780
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText(u'test').encode(encoding='utf-8'), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:48:04.058693
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    from ansible.module_utils.six import PY2
    unicode_string = 'unicode string'
    ut = AnsibleUnsafeText(unicode_string)
    if PY2:
        assert isinstance(ut, text_type) and isinstance(ut, AnsibleUnsafeText)
    else:
        assert ut == unicode_string

