

# Generated at 2022-06-23 14:38:17.062889
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import to_unsafe_text
    from ansible.utils.unsafe_proxy import to_unsafe_bytes
    import json

    unicode_str = u"a unicode string"
    unicode_str_unsafe = wrap_var(unicode_str)
    assert(isinstance(unicode_str_unsafe, AnsibleUnsafeText))
    assert(unicode_str_unsafe == unicode_str)
    assert(unicode_str_unsafe.__UNSAFE__)

    byte_str = b"a byte string"
    byte_str_unsafe = wrap_var(byte_str)
    assert(isinstance(byte_str_unsafe, AnsibleUnsafeBytes))

# Generated at 2022-06-23 14:38:28.805051
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    bytes_obj = AnsibleUnsafeBytes('Test1')
    text_obj = AnsibleUnsafeText('Test2')
    list_obj = _wrap_sequence([1, 2, 3])
    dict_obj = _wrap_dict({'key1': 'value1', 'key2': 'value2'})
    jnja_text = NativeJinjaUnsafeText('Test3')
    set_obj = _wrap_set([4, 5, 6])
    assert bytes_obj.__UNSAFE__
    assert text_obj.__UNSAFE__
    assert list_obj.__UNSAFE__
    assert dict_obj.__UNSAFE__
    assert jnja_text.__UNSAFE__
    assert set_obj.__UNSAFE__
    # __UNSAFE__ should be False if it falls to

# Generated at 2022-06-23 14:38:38.147186
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.unsafe_proxy import wrap_var

    a_dict = {'a': {'b': 'c'}, 'd': 'e'}
    a_dict = wrap_var(a_dict)
    assert isinstance(a_dict, dict)
    assert isinstance(a_dict['a'], dict)
    assert isinstance(a_dict['a']['b'], AnsibleUnsafeText)
    assert isinstance(a_dict['d'], AnsibleUnsafeText)
    assert a_dict['a']['b'] == 'c'
    assert a_dict['d'] == 'e'

    a_list = [1, 'a', {'b': ['c', 'd']}]
    a_list = wrap_var(a_list)

# Generated at 2022-06-23 14:38:39.277822
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert isinstance(wrap_var("abc"), AnsibleUnsafeText) is True


# Generated at 2022-06-23 14:38:41.441139
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    t = NativeJinjaUnsafeText('{% set test = "test" %}')
    assert isinstance(t, NativeJinjaText)
    assert isinstance(t, AnsibleUnsafeText)


# Generated at 2022-06-23 14:38:48.564552
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.module_utils.common.text.converters import to_text
    x = NativeJinjaUnsafeText('str')
    assert x.__class__.__name__ == 'NativeJinjaUnsafeText'
    assert to_text(x) == 'str'
    assert x.startswith('s')
    assert x.endswith('r')
    assert x.split(',') == ['str']
    assert x.find('t') == 1
    assert x.count('t') == 1
    assert x.index('t') == 1
    assert x.replace('t', ' ') == 's r'
    assert x.rfind('t') == 1

# Generated at 2022-06-23 14:38:49.326732
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    v = wrap_var(1)
    assert v == 1


# Generated at 2022-06-23 14:39:02.175345
# Unit test for function to_unsafe_bytes

# Generated at 2022-06-23 14:39:03.010377
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    NativeJinjaUnsafeText('name')

# Generated at 2022-06-23 14:39:12.353765
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    class MyAnsibleUnsafe(AnsibleUnsafe):
        pass
    s = "this is a string"
    ansible_unsafe_str = UnsafeProxy(s)
    assert isinstance(ansible_unsafe_str, AnsibleUnsafeText)
    assert str(ansible_unsafe_str) == s
    ansible_unsafe_bytes = UnsafeProxy(s.encode('utf-8'))
    assert isinstance(ansible_unsafe_bytes, AnsibleUnsafeBytes)
    assert str(ansible_unsafe_bytes) == s
    ansible_unsafe_my_class = UnsafeProxy(MyAnsibleUnsafe())
    assert isinstance(ansible_unsafe_my_class, MyAnsibleUnsafe)



# Generated at 2022-06-23 14:39:17.839180
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    test_string = 'pandas'
    unsafe_bytes = AnsibleUnsafeBytes(test_string)
    assert unsafe_bytes == b'pandas'

    # Check that an instance of AnsibleUnsafeBytes can be decoded to an instance of AnsibleUnsafeText
    assert isinstance(unsafe_bytes.decode(), AnsibleUnsafeText)



# Generated at 2022-06-23 14:39:19.067769
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text("abc"), AnsibleUnsafeText)

# Generated at 2022-06-23 14:39:26.609579
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert b'a' in AnsibleUnsafeBytes(b'a')
    assert b'a' in AnsibleUnsafeBytes(b'ac')
    assert AnsibleUnsafeBytes(b'a')[0] == b'a'
    assert AnsibleUnsafeBytes(b'a')[1:] == b'c'
    assert len(AnsibleUnsafeBytes(b'abc')) == 3
    assert AnsibleUnsafeBytes(b'abc') == AnsibleUnsafeBytes(b'abc')
    assert bool(AnsibleUnsafeBytes(b'abc'))

    assert AnsibleUnsafeBytes(b'a') != b'a'
    assert b'a' != AnsibleUnsafeBytes(b'a')
    assert AnsibleUnsafeBytes(b'a') != AnsibleUnsafeBytes(b'ac')



# Generated at 2022-06-23 14:39:37.409614
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    import unittest
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # test method of class AnsibleUnsafeText
    class TestAnsibleUnsafeTextEncode(unittest.TestCase):
        # test method encode
        def test_encode(self):
            # test unicode string
            a = AnsibleUnsafeText("test")
            self.assertEqual(a.encode('utf-8'), "test")
            # test ascii string
            a = AnsibleUnsafeText("test")
            self.assertEqual(a.encode('utf-8'), "test")
            # test byte string
            a = AnsibleUnsafeText("test")
            self.assertEqual(a.encode('utf-8'), "test")

    # run test
    suite = unitt

# Generated at 2022-06-23 14:39:39.967577
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    if UnsafeProxy(u'UnsafeProxy_test') != b'UnsafeProxy_test':
        raise AssertionError('UnsafeProxy(u\'UnsafeProxy_test\').decode() != \'UnsafeProxy_test\'')

# Generated at 2022-06-23 14:39:42.148460
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    t = AnsibleUnsafeText("test")
    assert t.encode() == b'test'

# Generated at 2022-06-23 14:39:51.193641
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.utils.display import Display
    Display().deprecated(
        'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )
    def create_str(is_unicode=False):
        if is_unicode:
            return u'foo'
        else:
            return 'foo'

    for i in range(2):
        s = create_str(i)
        p = UnsafeProxy(s)
        assert isinstance(p, AnsibleUnsafeText)
        assert p == s
        assert isinstance(p, text_type)
        assert p.decode('utf-8') == s.decode('utf-8')

# Generated at 2022-06-23 14:39:53.855408
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    a = AnsibleUnsafeBytes(b"12345")
    assert isinstance(a.decode(), AnsibleUnsafeText)

# Generated at 2022-06-23 14:39:55.139414
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b'b').decode(), AnsibleUnsafeText)


# Generated at 2022-06-23 14:40:02.765103
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import u

    # Test for different input data types
    assert to_unsafe_bytes(u'foo') == b'foo'
    assert to_unsafe_bytes(u'こんにちは') == b'\xe3\x81\x93\xe3\x82\x93\xe3\x81\xab\xe3\x81\xa1\xe3\x81\xaf'
    assert to_unsafe_bytes('foo') == b'foo'
    assert to_unsafe_bytes('こんにちは') == b'\xe3\x81\x93\xe3\x82\x93\xe3\x81\xab\xe3\x81\xa1\xe3\x81\xaf'
    assert to_unsafe_

# Generated at 2022-06-23 14:40:15.173826
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    import sys
    import imp

    with open('ansible/module_utils/native_jinja.py') as fp:
        sys.modules['ansible.module_utils.native_jinja'] = imp.load_module(
            'ansible.module_utils.native_jinja', fp, 'ansible/module_utils/native_jinja.py',
            ('.py', 'r', imp.PY_SOURCE))

    with open('ansible/module_utils/_text.py') as fp:
        sys.modules['ansible.module_utils._text'] = imp.load_module(
            'ansible.module_utils._text', fp, 'ansible/module_utils/_text.py',
            ('.py', 'r', imp.PY_SOURCE))

    x = NativeJinjaUnsafe

# Generated at 2022-06-23 14:40:21.133026
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # Check creation of object
    assert isinstance(AnsibleUnsafeText('Test string'), AnsibleUnsafeText)
    # Check for __UNSAFE__ attribute
    assert hasattr(AnsibleUnsafeText('Test string'), '__UNSAFE__')
    # Check for __UNSAFE__ value
    assert AnsibleUnsafeText('Test string').__UNSAFE__ == True



# Generated at 2022-06-23 14:40:22.191944
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert type(AnsibleUnsafeText('some_string').encode()) == AnsibleUnsafeBytes


# Generated at 2022-06-23 14:40:23.716973
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText('test').encode(), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:40:31.010844
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes('foo'), AnsibleUnsafe)
    assert isinstance(AnsibleUnsafeBytes('foo', errors='replace'), AnsibleUnsafe)
    assert isinstance(AnsibleUnsafeBytes(b'foo', encoding='ascii', errors='replace'), AnsibleUnsafe)
    assert isinstance(AnsibleUnsafeBytes(iterable=b'foo', encoding='ascii', errors='replace'), AnsibleUnsafe)


# Generated at 2022-06-23 14:40:40.189612
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(u'abc'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(to_text(b'abc', errors='surrogate_or_strict')), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(to_unsafe_text(u'abc')), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'abc', encoding='ascii'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(to_text(b'abc', errors='surrogate_or_strict'), encoding='ascii'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:40:50.645553
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    str1 = 'This string is safe'
    str2 = UnsafeProxy(str1)
    assert str2 == str1
    assert type(str2) is AnsibleUnsafeText
    bytes1 = b'This string is safe'
    bytes2 = UnsafeProxy(bytes1)
    assert bytes2 == bytes1
    assert type(bytes2) is AnsibleUnsafeBytes
    none = None
    none2 = UnsafeProxy(none)
    assert none2 is none
    assert type(none2) is type(none)
    unsafe_text_obj = AnsibleUnsafeText('This is an unsafe string')
    unsafe_bytes_obj = AnsibleUnsafeBytes(b'This is an unsafe byte string')
    unsafe_text_obj2 = UnsafeProxy(unsafe_text_obj)
    unsafe_bytes_obj2 = Un

# Generated at 2022-06-23 14:41:00.115906
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Test case 1
    from ansible.utils.display import Display
    Display().deprecated(
        'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )
    obj = UnsafeProxy(None)
    assert obj == None

    # Test case 2
    obj = UnsafeProxy("string")
    assert obj.__UNSAFE__ == True

    # Test case 3
    obj = UnsafeProxy("string")
    assert obj.__UNSAFE__ == True

    # Test case 4
    obj = UnsafeProxy("string")
    assert obj.__UNSAFE__ == True

    # Test case 5
    obj = UnsafeProxy("string")
    assert obj.__UNSAFE

# Generated at 2022-06-23 14:41:03.443357
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    try:
        ans = AnsibleUnsafe()
    except:
        assert False, 'AnsibleUnsafe constructor failed'


# Generated at 2022-06-23 14:41:12.534377
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.utils.display import Display
    display = Display()
    from ansible.parsing.yaml.objects import AnsibleUnicode
    display.deprecated('use this function', version='2.13', collection_name='ansible.builtin')
    unsafe = NativeJinjaUnsafeText(AnsibleUnicode(u'abc'))
    if not isinstance(unsafe, NativeJinjaUnsafeText):
        raise TypeError('NativeJinjaUnsafeText type is wrong')
    if to_text(unsafe) != 'abc':
        raise ValueError('NativeJinjaUnsafeText value is wrong')
    if not isinstance(unsafe, AnsibleUnsafe):
        raise TypeError('NativeJinjaUnsafeText is not marked as unsafe')

# Generated at 2022-06-23 14:41:14.705534
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    x = AnsibleUnsafeText("AnsibleUnsafeText")
    assert x.encode("ascii").__class__ == AnsibleUnsafeBytes

# Generated at 2022-06-23 14:41:18.699178
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    unsafe = AnsibleUnsafeBytes('10.0.2.2')
    assert(unsafe.decode() == u'10.0.2.2')


# Generated at 2022-06-23 14:41:19.729388
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    pass


# Generated at 2022-06-23 14:41:23.508003
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    text = AnsibleUnsafeText("This is a string.")
    bytestring = text.encode('utf-8')
    assert type(bytestring) == AnsibleUnsafeBytes
    assert bytestring == b'This is a string.'
    assert type(bytestring.decode('utf-8')) == AnsibleUnsafeText
    assert bytestring.decode('utf-8') == AnsibleUnsafeText('This is a string.')


# Generated at 2022-06-23 14:41:26.965570
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    ansible_unsafe_text = AnsibleUnsafeText('test_ansible_unsafe_text')
    assert ansible_unsafe_text == 'test_ansible_unsafe_text'

# Generated at 2022-06-23 14:41:32.976582
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import os
    import tempfile
    import ansible.module_utils.six as six

    tf = tempfile.NamedTemporaryFile(delete=False)
    tf.write(six.b('unicode string'))
    with tf.name as test_file:
        os.fstat(tf.file.fileno())
        assert wrap_var(test_file) == to_unsafe_text(test_file)

# Generated at 2022-06-23 14:41:42.821656
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(u'happy') == u'happy'
    assert wrap_var(u'happy').__class__ == AnsibleUnsafeText
    assert wrap_var(u'happy') == AnsibleUnsafeText(u'happy')
    assert wrap_var(b'happy').__class__ == AnsibleUnsafeBytes
    assert wrap_var(b'happy') == AnsibleUnsafeBytes(b'happy')
    assert wrap_var(AnsibleUnsafeText('happy')).__class__ == AnsibleUnsafeText
    assert wrap_var(AnsibleUnsafeBytes('happy')).__class__ == AnsibleUnsafeBytes
    # Do not wrap already wrapped variables
    assert wrap_var(AnsibleUnsafeText(u'happy')).__class__ == AnsibleUnsafeText

# Generated at 2022-06-23 14:41:44.775295
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes("foobar"), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:41:48.018890
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert AnsibleUnsafeText("hello").encode("utf-8") == AnsibleUnsafeBytes("hello")


# Generated at 2022-06-23 14:41:56.141106
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():

    assert isinstance(UnsafeProxy(u"123\u00a6"), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b"123\xc2\xa6"), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(None), AnsibleUnsafe)
    assert isinstance(UnsafeProxy({}), dict)
    assert isinstance(UnsafeProxy([]), list)
    assert isinstance(UnsafeProxy(set()), set)

    assert isinstance(UnsafeProxy(u"123\u00a6".encode('utf-8')), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(u"123\u00a6".encode('utf-8')).decode('utf-8'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:42:03.674199
# Unit test for function wrap_var
def test_wrap_var():
    # Test the function wrap_var
    # wrap_var(None)
    assert wrap_var(None) is None
    # wrap_var(AnsibleUnsafe)
    assert wrap_var(AnsibleUnsafeText(u'foo')) is not None
    # wrap_var(mapping)
    assert isinstance(wrap_var({}), dict)
    assert isinstance(wrap_var({u'foo': u'bar'}), dict)
    assert isinstance(wrap_var({u'foo': u'bar', u'boo': AnsibleUnsafeText(u'baz')}), dict)
    assert wrap_var({u'foo': u'bar'})[u'foo'] == u'bar'

# Generated at 2022-06-23 14:42:09.507081
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('Test') == b'Test'
    assert to_unsafe_bytes({'test': 'TEST'}) == {'test': b'TEST'}
    assert to_unsafe_bytes([b'Test', 'TEST', {'test': 'TEST'}]) == [b'Test', b'TEST', {'test': b'TEST'}]

# Generated at 2022-06-23 14:42:14.206247
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    try:
        x = AnsibleUnsafeText('my text string')
    except Exception as e:
        print(e)

    if x is None:
        print('Failing w AnsibleUnsafeText.__new__')
        exit(1)


# Generated at 2022-06-23 14:42:20.260217
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    class TestAnsibleUnsafe(AnsibleUnsafe):
        def __init__(self, name):
            self.name = name
    test = TestAnsibleUnsafe('foo')
    assert test.name == 'foo'
    assert test.__UNSAFE__ == True
    assert type(test.__UNSAFE__) is bool


# Generated at 2022-06-23 14:42:23.390335
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    text = AnsibleUnsafeText("not safe")
    byte = text.encode()
    assert isinstance(byte, AnsibleUnsafeBytes), "Encoded byte should be unsafe"


# Generated at 2022-06-23 14:42:34.410592
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # Test without errors
    result = AnsibleUnsafeBytes('\xC3\xA1 \xC3\xA9 \xC3\xAD \xC3\xB3 \xC3\xBA \xC5\xBE').decode()
    assert len(result) == 11
    assert isinstance(result, AnsibleUnsafeText)
    assert isinstance(result, AnsibleUnsafe)
    assert result == 'á é í ó ú ž'

    # Test with errors
    result = AnsibleUnsafeBytes('\xC3\xA1 \xC3\xA9 \xC3\xAD \xC3\xB3 \xC3\xBA x').decode()
    assert len(result) == 12
    assert isinstance(result, AnsibleUnsafeText)

# Generated at 2022-06-23 14:42:36.314064
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    test_obj = AnsibleUnsafeText('test string')
    assert test_obj.encode() == b'test string'


# Generated at 2022-06-23 14:42:43.037894
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():

    class A(object):
        def __repr__(self):
            return "A_OBJECT"

    # normal string
    assert isinstance(UnsafeProxy("hello"), AnsibleUnsafeText)
    assert UnsafeProxy("hello") == u"hello"

    # unicode string
    assert isinstance(UnsafeProxy(u"hello"), AnsibleUnsafeText)
    assert UnsafeProxy(u"hello") == u"hello"

    # object that's not a string
    assert isinstance(UnsafeProxy(A()), AnsibleUnsafe)
    assert UnsafeProxy(A()) == A()

    # already wrapped string
    a = AnsibleUnsafeText(b"hello")
    assert isinstance(UnsafeProxy(a), AnsibleUnsafeText)
    assert UnsafeProxy(a) == u"hello"

    # already

# Generated at 2022-06-23 14:42:54.160252
# Unit test for constructor of class UnsafeProxy

# Generated at 2022-06-23 14:42:56.545308
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    u = UnsafeProxy('test string')
    assert  isinstance(u, AnsibleUnsafeText)
    assert u == 'test string'
    assert  isinstance(u, UnsafeProxy)


# Generated at 2022-06-23 14:43:00.469162
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # given
    input = u'test'

    # when
    result = AnsibleUnsafeText(input).encode()

    # then
    assert isinstance(result, AnsibleUnsafeBytes)
    assert result == b'test'


# Generated at 2022-06-23 14:43:11.145178
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.utils.display import Display
    Display().deprecated(
        'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )
    obj = UnsafeProxy(123)
    assert (type(obj) == int and obj == 123)
    assert (not hasattr(obj, "__UNSAFE__"))

    obj = UnsafeProxy(True)
    assert (type(obj) == bool and obj)
    assert (not hasattr(obj, "__UNSAFE__"))

    obj = UnsafeProxy("123")
    assert (type(obj) == AnsibleUnsafeText and obj == "123")
    assert (hasattr(obj, "__UNSAFE__"))

    obj

# Generated at 2022-06-23 14:43:14.876046
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    class Foo(object):
        def test(self, arg):
            return arg

    a = Foo()
    b = AnsibleUnsafeText('bar')
    assert(a.test(b) == 'bar')

# Generated at 2022-06-23 14:43:18.549676
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    assert hasattr(AnsibleUnsafe, '__UNSAFE__')
    assert AnsibleUnsafe.__UNSAFE__ is True


# Generated at 2022-06-23 14:43:24.005637
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    jinja_unsafe_text = NativeJinjaUnsafeText('test_string')
    assert jinja_unsafe_text == 'test_string'
    assert type(jinja_unsafe_text) is NativeJinjaUnsafeText
    assert jinja_unsafe_text is not 'test_string'
    assert not jinja_unsafe_text.__UNSAFE__

# Generated at 2022-06-23 14:43:31.689196
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import to_unsafe_bytes
    from ansible.utils.unsafe_proxy import to_unsafe_text
    from ansible.module_utils.six import PY2, PY3

    b = to_unsafe_bytes('hello')
    t = to_unsafe_text('hello')

    assert b == t
    assert isinstance(b, AnsibleUnsafeBytes)
    assert isinstance(t, AnsibleUnsafeText)

    if PY2:
        assert isinstance(b, str)
        assert isinstance(t, unicode)
    elif PY3:
        assert isinstance(b, bytes)
        assert isinstance(t, str)

    assert wrap_var(b) == b

# Generated at 2022-06-23 14:43:41.842179
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    output = NativeJinjaUnsafeText(b'foo')
    assert output.__class__.__name__ == 'NativeJinjaUnsafeText'
    assert output.__class__.__bases__[0].__name__ == 'NativeJinjaText'
    assert output.__class__.__bases__[1].__name__ == 'AnsibleUnsafeText'
    assert output.__class__.__bases__[2].__name__ == 'str'
    assert output.__class__.__bases__[2].__bases__[0].__name__ == 'object'

# Generated at 2022-06-23 14:43:48.967542
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    import collections
    import ansible.module_utils.six as six
    from ansible.module_utils.six.moves import collections_abc

    # Test with a None
    assert UnsafeProxy(None) is None

    # Test with other (non-tuple) types, plus a proxy as a value
    test_data = [
        (1, 2, 3),
        [4, 5, 6],
        {'a': 'b', 'c': 'd'},
        collections_abc.Mapping,
        collections.Mapping,
        six.MutableMapping,
        UnsafeProxy(collections.Mapping),
    ]

    for data in test_data:
        assert data is UnsafeProxy(data)

    # Test with tuples

# Generated at 2022-06-23 14:43:57.138129
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    unicode_string = u"unicode string"
    assert isinstance(UnsafeProxy(unicode_string), AnsibleUnsafeText)

    string = "a string"
    assert isinstance(UnsafeProxy(string), AnsibleUnsafeText)

    string_list = [u"unicode string", "a string"]
    for string in string_list:
        assert isinstance(UnsafeProxy(string), AnsibleUnsafeText)

    string_dict = {u"a": u"unicode string", "b": "a string"}
    for string in string_dict.keys():
        assert isinstance(UnsafeProxy(string), AnsibleUnsafeText)
    for string in string_dict.values():
        assert isinstance(UnsafeProxy(string), AnsibleUnsafeText)

    empty_tuple = ()

# Generated at 2022-06-23 14:43:59.783985
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    value = AnsibleUnsafeBytes(b'abc')
    assert isinstance(value.decode('utf-8'), AnsibleUnsafeText)



# Generated at 2022-06-23 14:44:01.365366
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # Test the case that the constructor of class AnsibleUnsafe is called directly.
    AnsibleUnsafe()



# Generated at 2022-06-23 14:44:08.271864
# Unit test for function wrap_var
def test_wrap_var():
    # test simple strings
    assert wrap_var('string') == b'string'
    assert isinstance(wrap_var('string'), AnsibleUnsafeText)

    # test list
    assert wrap_var(['string1', 'string2']) == [b'string1', b'string2']
    assert wrap_var(['string1', 'string2']) == [(b'string1', b'string2')]

    # test dict
    assert wrap_var({'string': '1'}) == {b'string': b'1'}
    assert wrap_var({'string': {'nested': '1'}}) == {b'string': {b'nested': b'1'}}

# Generated at 2022-06-23 14:44:09.570857
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    value = 'value'
    assert(UnsafeProxy(value) == value)

# Generated at 2022-06-23 14:44:22.697937
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    tests = (
        (b'\xc2\xa9 \xc2\xae', 'utf-8', '\xa9 \xae'),
        (b'\xc2\xe9 \xc2\xae', 'utf-8', '\xe9 \xae'),
        (b'\xc2\xae \xc2\xbd', 'utf-8', '\xae \xbd'),
        (b'\xc2\xae \xc2\xbd', 'ascii', '\xae \xbd'),
    )
    for in_buf, encoding, expected in tests:
        actual = AnsibleUnsafeBytes(in_buf).decode(encoding)
        assert actual == expected, 'wrong decoded output, got {0}, expected: {1}'.format(
            repr(actual), repr(expected))

# Generated at 2022-06-23 14:44:26.791004
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy("foo").__class__ == AnsibleUnsafeText
    assert UnsafeProxy({'foo': 'bar'})['foo'].__class__ == AnsibleUnsafeText
    assert UnsafeProxy(AnsibleUnsafeText("foo")).__class__ == AnsibleUnsafeText

# Generated at 2022-06-23 14:44:29.816319
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    unsafe_bytes = AnsibleUnsafeBytes(b"hello")
    assert(isinstance(unsafe_bytes.decode(), AnsibleUnsafeText))

# Generated at 2022-06-23 14:44:31.548445
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    text = NativeJinjaUnsafeText('hello world')
    assert text.__UNSAFE__ == True

# Generated at 2022-06-23 14:44:35.968227
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    # coverage isn't picking up on this function, so we'll test it manually
    assert isinstance(to_unsafe_bytes('foo'), binary_type)
    assert isinstance(to_unsafe_bytes('foo', errors='strict'), binary_type)
    assert isinstance(to_unsafe_bytes('foo', errors='surrogate_or_strict'), binary_type)



# Generated at 2022-06-23 14:44:45.482344
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    from ansible.module_utils.six import PY3
    # This test is only needed for Python3 due to the unicode behavior of Python2
    # Python3 has different behavior for unicode/bytestrings
    if PY3:
        # Bytestring
        b = b'\x00\x01\x7f\x80\xff'
        assert(isinstance(b, AnsibleUnsafeBytes))
        assert(isinstance(b, binary_type))
        assert(isinstance(b, AnsibleUnsafe))
        assert(b.__UNSAFE__)
        assert(b.__UNSAFE__ is True)
        assert(b == b'\x00\x01\x7f\x80\xff')
        # Decoded bytestring
        t = b.decode('utf-8')
       

# Generated at 2022-06-23 14:44:55.650200
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert(AnsibleUnsafeText('s') == 's')
    assert(AnsibleUnsafeText(u's') == u's')
    assert(AnsibleUnsafeText(b's') == u's')
    assert(isinstance(AnsibleUnsafeText('s'), AnsibleUnsafeText))
    assert(isinstance(AnsibleUnsafeText(u's'), AnsibleUnsafeText))
    assert(isinstance(AnsibleUnsafeText(b's'), AnsibleUnsafeText))
    assert(isinstance(AnsibleUnsafeText('s'), text_type))
    assert(isinstance(AnsibleUnsafeText(u's'), text_type))
    assert(isinstance(AnsibleUnsafeText(b's'), text_type))

# Generated at 2022-06-23 14:45:00.597348
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    test_string = '0123456789ABCDEF'
    ansible_unsafe_bytes = b'0123456789ABCDEF'
    aub = AnsibleUnsafeBytes(ansible_unsafe_bytes)
    result = aub.decode()
    assert(result == test_string)


# Generated at 2022-06-23 14:45:11.384307
# Unit test for constructor of class AnsibleUnsafeBytes

# Generated at 2022-06-23 14:45:21.653658
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.utils.display import Display
    with Display():
        unsafe_text = UnsafeProxy("Unsafe text")
        assert isinstance(unsafe_text, AnsibleUnsafeText), "UnsafeProxy does not return AnsibleUnsafeText when given a string."
        unsafe_bytes = UnsafeProxy(b"Unsafe bytes")
        assert isinstance(unsafe_bytes, AnsibleUnsafeBytes), "UnsafeProxy does not return AnsibleUnsafeBytes when given a byte string."
        unsafe_object = UnsafeProxy(unsafe_text)
        assert isinstance(unsafe_object, AnsibleUnsafeText), "UnsafeProxy does not return AnsibleUnsafeText when given a AnsibleUnsafeText."

# Generated at 2022-06-23 14:45:27.564800
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    # Set up
    input_data = {u"key1": u"value1", u"key2": u"value2"}
    # Execute
    output_data = to_unsafe_bytes(input_data)
    # Verify
    assert isinstance(output_data, dict)
    for value in output_data.values():
        assert isinstance(value, AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:45:29.964185
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    uss = AnsibleUnsafeBytes(b'\xc3\xbc')
    assert isinstance(uss.decode('utf-8'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:45:40.809937
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    UNSAFE_STR = u"INSECURE string"
    UNSAFE_BYTE = to_bytes(UNSAFE_STR)
    UNSAFE_TEXT = to_text(UNSAFE_BYTE)

    # By default it should wrap a string with an UnsafeText and
    # turn it into UnsafeBytes
    new_proxy = UnsafeProxy(UNSAFE_STR)

    assert isinstance(new_proxy, AnsibleUnsafeBytes)
    assert type(new_proxy) is AnsibleUnsafeBytes

    assert isinstance(new_proxy, AnsibleUnsafeText)
    assert type(new_proxy) is not AnsibleUnsafeText

    # For bytes object it should turn it into UnsafeBytes
    new_proxy = UnsafeProxy(UNSAFE_BYTE)

# Generated at 2022-06-23 14:45:44.200522
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    obj = AnsibleUnsafeText("foo")
    assert obj.__UNSAFE__
    assert obj == "foo"

    assert isinstance(obj, text_type)
    assert isinstance(obj, AnsibleUnsafe)

# Generated at 2022-06-23 14:45:49.659061
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    """
    Adds dummy bytes object to be overridden by wrap_unsafe decorator.
    """
    if sys.version_info >= (3, 0):
        # python3
        assert to_unsafe_bytes(b"foo") == b'foo', "to_unsafe_bytes method did not wrap input bytes object"
    else:
        # python2
        assert to_unsafe_bytes("foo") == 'foo', "to_unsafe_bytes method did not wrap input bytes object"

# Generated at 2022-06-23 14:45:52.346132
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance('123'.encode(), binary_type)
    assert isinstance(AnsibleUnsafeText('123').encode(), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:46:03.419242
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    from ansible.module_utils.six.moves import builtins
    assert hasattr(builtins, '__UNSAFE__') == False

    assert hasattr(AnsibleUnsafe, '__UNSAFE__') == True
    assert AnsibleUnsafe.__UNSAFE__ == True

    class TestA(AnsibleUnsafe):
        pass

    assert hasattr(TestA, '__UNSAFE__') == True
    assert TestA.__UNSAFE__ == True

    class TestB(AnsibleUnsafe):
        __UNSAFE__ = False

    assert hasattr(TestB, '__UNSAFE__') == True
    assert TestB.__UNSAFE__ == False

# Generated at 2022-06-23 14:46:11.768251
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():

    proxy_instance = UnsafeProxy("test")
    # TODO : self.assertTrue(isinstance(proxy_instance, AnsibleUnsafe))
    assert isinstance(proxy_instance, AnsibleUnsafe)

    from ansible.module_utils.common.text.converters import to_str

    proxy_instance = UnsafeProxy(to_str("test"))
    # TODO : self.assertTrue(isinstance(proxy_instance, AnsibleUnsafe))
    assert isinstance(proxy_instance, AnsibleUnsafe)



# Generated at 2022-06-23 14:46:21.688638
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.six import u, b
    # Test for function 'UnsafeProxy_new'
    d = UnsafeProxy(a = u"a", b = b"b", c = 1, d = [u"a", b"b", 1], e = {u"a": u"a", u"b": b"b", u"c": 1}, f = [u"a", b"b", 1], g = {u"a": u"a", u"b": b"b", u"c": 1}, h = {u"a": u"a", u"b": b"b", u"c": 1})
    assert isinstance(d, dict)
    assert isinstance(d["a"], AnsibleUnsafeText)
    assert isinstance(d["b"], AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:46:23.301421
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    input = b'test'
    output = AnsibleUnsafeBytes(input)
    assert input == output


# Generated at 2022-06-23 14:46:31.347612
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.common.text import to_text
    assert to_unsafe_text('foo') == to_text('foo')
    assert type(to_unsafe_text('foo')) == type(to_text('foo'))
    assert isinstance(to_unsafe_text('foo'), AnsibleUnsafeText)
    assert to_unsafe_text(b'foo') == to_text(b'foo')
    assert type(to_unsafe_text(b'foo')) == type(to_text(b'foo'))
    assert isinstance(to_unsafe_text(b'foo'), AnsibleUnsafeText)
    assert to_unsafe_text(u'foo') == to_text(u'foo')

# Generated at 2022-06-23 14:46:33.720149
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    obj = AnsibleUnsafe()
    assert(isinstance(obj, AnsibleUnsafe))


# Generated at 2022-06-23 14:46:43.485226
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    u1 = AnsibleUnsafeText(u'汉字')
    assert isinstance(u1, text_type)
    assert u1.startswith(u'汉')
    assert isinstance(u1, AnsibleUnsafe)
    # Make sure that encode maintains type
    u1_bytes = u1.encode('utf-8')
    assert isinstance(u1_bytes, AnsibleUnsafeBytes)
    assert isinstance(u1_bytes, binary_type)
    assert u1_bytes.startswith(b'\xe6\xb1\x89')
    # Make sure decode maintains type
    u2 = u1_bytes.decode('utf-8')
    assert isinstance(u2, AnsibleUnsafeText)
    assert isinstance(u2, text_type)

# Generated at 2022-06-23 14:46:48.206453
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    result = AnsibleUnsafeBytes(b"test")
    assert result == b"test"
    assert result.decode() == "test"

    result = AnsibleUnsafeBytes(b"test").decode()
    assert result == "test"
    assert result.encode() == b"test"


#######################################################################################

# Generated at 2022-06-23 14:46:56.589968
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type
    # Unsafe objects should be returned as is
    assert wrap_var(AnsibleUnsafeBytes(b'unsafe bytes')) == b'unsafe bytes'
    assert wrap_var(AnsibleUnsafeText('unsafe text')) == 'unsafe text'

    # Bytes are converted to unsafe bytes
    assert wrap_var(b'bytes') == b'bytes'
    assert isinstance(wrap_var(b'bytes'), binary_type)
    # Text is converted to unsafe text
    assert wrap_var('text') == 'text'
    assert isinstance(wrap_var('text'), text_type)
    # None is returned as is


# Generated at 2022-06-23 14:47:06.177269
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('foo'), binary_type)
    assert isinstance(to_unsafe_bytes(u'foo'), binary_type)
    assert isinstance(to_unsafe_bytes(b'foo'), binary_type)
    assert isinstance(to_unsafe_bytes(42), binary_type)
    assert isinstance(to_unsafe_bytes([1,2,3]), list)
    assert isinstance(to_unsafe_bytes({'k': 'v'}), dict)
    assert isinstance(to_unsafe_bytes(['foo', u'bar']), list)
    assert isinstance(to_unsafe_bytes([u'foo', 'bar']), list)
    assert isinstance(to_unsafe_bytes([b'foo', u'bar']), list)

# Generated at 2022-06-23 14:47:17.984839
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    d = Display()

    # Test binary string
    assert wrap_var(b'foo') == b'foo'
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)

    # Test text string
    assert wrap_var('foo') == 'foo'
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)

    # Test that old proxy class creates an AnsibleUnsafeText
    assert wrap_var(UnsafeProxy('foo')) == 'foo'
    assert isinstance(wrap_var(UnsafeProxy('foo')), AnsibleUnsafeText)

    # Test list
    assert wrap_var(['foo', 'bar']) == ['foo', 'bar']

# Generated at 2022-06-23 14:47:21.065158
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    u = '你好'
    assert isinstance(AnsibleUnsafeBytes(u.encode('utf-8')), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:47:22.498654
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(to_unsafe_bytes(u'foo').decode('ascii'), AnsibleUnsafeText)


# Generated at 2022-06-23 14:47:29.979502
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    import types

    def test_proxy(value, expected_proxy_type=AnsibleUnsafeText):
        result = UnsafeProxy(value)
        assert isinstance(result, expected_proxy_type)
        assert isinstance(result.__class__, types.DynamicClassAttribute)
        assert result.__UNSAFE__

    test_proxy('1234')
    test_proxy(1234)
    test_proxy(AnsibleUnsafeText('foo'))
    test_proxy(AnsibleUnsafeBytes('foo'))


# These methods don't appear to be used in Ansible itself and are not tested

# Generated at 2022-06-23 14:47:36.301254
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.utils.display import Display
    from ansible.module_utils.six import print_
    njut = NativeJinjaUnsafeText('foo')
    assert isinstance(njut, NativeJinjaUnsafeText)
    assert isinstance(njut, AnsibleUnsafeText)
    assert isinstance(njut, text_type)
    assert isinstance(njut, NativeJinjaText)
    assert isinstance(njut, AnsibleUnsafe)

# Generated at 2022-06-23 14:47:40.883875
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    ansi_unsafe_bytes = AnsibleUnsafeBytes('\xc2\xab\xc2\xbb')
    ansi_unsafe_text = ansi_unsafe_bytes.decode('utf-8')
    assert isinstance(ansi_unsafe_text, AnsibleUnsafeText)



# Generated at 2022-06-23 14:47:44.988594
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.common.collections import is_sequence
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'test')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'test'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(['test']), list)
    assert isinstance(wrap_var(['test'])[0], AnsibleUnsafeText)
    assert isinstance(wrap_var((b'test',)), tuple)
    assert isinstance(wrap_var((b'test',))[0], AnsibleUnsafeBytes)
    assert isinstance(wrap_var({'test':b'test', 'a':[b'test']}), dict)

# Generated at 2022-06-23 14:47:47.116531
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    t = AnsibleUnsafeText("foo")
    assert(t == "foo")



# Generated at 2022-06-23 14:47:54.186662
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # object to be proxied
    obj = {'a': '1', 'b': '2', 'c': '3'}
    # test case1: obj is a dict
    # expected results: dict
    p1 = UnsafeProxy(obj)
    assert isinstance(p1, dict) == True
    # test case2: obj is a string
    # expected results: string
    obj = 'hello'
    p2 = UnsafeProxy(obj)
    assert isinstance(p2, str) == True


# Generated at 2022-06-23 14:47:59.487573
# Unit test for function wrap_var
def test_wrap_var():
    try:
        from ansible.utils.unsafe_proxy import wrap_var
        print("[INFO] Function wrap_var is loaded")
    except:
        print("[WARN] Function wrap_var must be implemented")

if __name__ == "__main__":
    test_wrap_var()

# Generated at 2022-06-23 14:48:02.137834
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    s = AnsibleUnsafeBytes('AnsibleUnsafeBytes')
    assert isinstance(s.decode(), AnsibleUnsafeText)



# Generated at 2022-06-23 14:48:11.035327
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    class TestAnsibleUnsafeBytes(object):
        def test_instance_of_AnsibleUnsafe(self):
            # GIVEN
            input_string = 'foo'
            # WHEN
            ansible_unsafe_bytes_object = AnsibleUnsafeBytes(input_string)
            # THEN
            assert isinstance(ansible_unsafe_bytes_object, AnsibleUnsafe)

        def test_input_value_is_returned_unchanged(self):
            # GIVEN
            input_string = 'foo'
            # WHEN
            ansible_unsafe_bytes_object = AnsibleUnsafeBytes(input_string)
            # THEN
            assert ansible_unsafe_bytes_object == input_string

    test_AnsibleUnsafeBytes().test_instance_of_AnsibleUnsafe()
