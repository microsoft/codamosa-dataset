

# Generated at 2022-06-23 14:38:17.914804
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # Create an instance of AnsibleUnsafeBytes
    try:
        test_AnsibleUnsafeBytes = AnsibleUnsafeBytes("test string")
    except Exception as e:
        raise AssertionError("Unexpected error {0} while creating instance of AnsibleUnsafeBytes".format(e))
    # Verify below attributes of AnsibleUnsafeBytes
    if not isinstance(test_AnsibleUnsafeBytes, binary_type):
        raise AssertionError("test_AnsibleUnsafeBytes is not of type basestring")
    if not isinstance(test_AnsibleUnsafeBytes, AnsibleUnsafe):
        raise AssertionError("test_AnsibleUnsafeBytes is not of type AnsibleUnsafe")

# Generated at 2022-06-23 14:38:22.374102
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    a = wrap_var("{{test}}")
    assert isinstance(a, NativeJinjaUnsafeText)
    assert isinstance(a, NativeJinjaText)
    assert isinstance(a, AnsibleUnsafeText)
    assert isinstance(a, text_type)

# Generated at 2022-06-23 14:38:32.243376
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    """Unit test for class AnsibleUnsafe"""
    assert AnsibleUnsafe.__UNSAFE__
    if hasattr(AnsibleUnsafe, '__UNSAFE_ORIGINAL_TYPES__'):
        assert 'AnsibleUnsafe' in AnsibleUnsafe.__UNSAFE_ORIGINAL_TYPES__
    else:
        assert 'AnsibleUnsafe' in AnsibleUnsafe.__UNSAFE_TYPE_NAMES__
    assert issubclass(AnsibleUnsafeBytes, AnsibleUnsafe)
    assert issubclass(AnsibleUnsafeText, AnsibleUnsafe)
    assert issubclass(NativeJinjaUnsafeText, AnsibleUnsafe)



# Generated at 2022-06-23 14:38:43.904479
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy(None) is None
    assert UnsafeProxy(True) is True
    assert UnsafeProxy(False) is False
    assert UnsafeProxy(10) == 10
    assert UnsafeProxy(0.0) == 0.0
    assert UnsafeProxy(1.2) == 1.2
    assert UnsafeProxy('string') == 'string'
    assert UnsafeProxy(b'bytes') == b'bytes'
    assert UnsafeProxy(u'unicode') == u'unicode'
    assert UnsafeProxy(u'Unicode String') == u'Unicode String'
    assert isinstance(UnsafeProxy(u'unicode'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(u'Unicode String'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:38:48.852372
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    test_string = "test_string"
    a = AnsibleUnsafeBytes(test_string)
    b = to_bytes(test_string)
    assert a == b
    assert a is not b

# Generated at 2022-06-23 14:39:00.250641
# Unit test for function wrap_var
def test_wrap_var():
    # list and tuple
    assert isinstance(wrap_var([1, 2, 3]), list)
    assert isinstance(wrap_var((1, 2, 3)), tuple)

    # dict
    assert isinstance(wrap_var({1: 'a', 2: 'b'}), dict)

    # str
    assert isinstance(wrap_var('abc'), AnsibleUnsafeText)

    # bytes
    assert isinstance(wrap_var(b'abc'), AnsibleUnsafeBytes)

    # None
    assert wrap_var(None) is None

    # NativeJinjaText
    assert isinstance(wrap_var(NativeJinjaText('{{ a }}')), NativeJinjaUnsafeText)

# Generated at 2022-06-23 14:39:10.849611
# Unit test for function wrap_var
def test_wrap_var():
    import datetime
    import copy

    u_str = to_unsafe_text("hello")
    u_bytes = to_unsafe_bytes("hello")

    assert u_str is wrap_var(u_str)
    assert u_bytes is wrap_var(u_bytes)
    assert u_bytes is wrap_var(u"hello")
    assert u_bytes is wrap_var(b"hello")

    for t in [1, 1.0, datetime.datetime.now()]:
        assert t is wrap_var(t)

    # Immutable sequences
    for t in [(), [], set()]:
        assert t is wrap_var(t)
    assert (1, 2) is wrap_var((1, 2))

# Generated at 2022-06-23 14:39:12.759264
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b"foo").decode(), AnsibleUnsafeText)



# Generated at 2022-06-23 14:39:15.115188
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    import ansible.module_utils.basic
    ansible.module_utils.basic.UnsafeProxy(1)

# Generated at 2022-06-23 14:39:16.795485
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    s = "Hallo!"
    up = UnsafeProxy(s)
    assert up.__UNSAFE__



# Generated at 2022-06-23 14:39:19.571045
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    input_value = 'This is a string'
    expected_output = 'This is a string'
    output = AnsibleUnsafeText(input_value).encode()
    assert output == expected_output



# Generated at 2022-06-23 14:39:26.953602
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # test when input is an instance of AnsibleUnsafeText
    u = AnsibleUnsafeBytes('abc')
    assert isinstance(u.decode(), AnsibleUnsafeText)
    assert isinstance(u.decode(encoding='utf-8'), AnsibleUnsafeText)
    assert isinstance(u.decode(encoding='utf-8', errors='strict'), AnsibleUnsafeText)
    # test when input is an instance of AnsibleUnsafeBytes
    u = AnsibleUnsafeText(u'abc')
    assert isinstance(u.encode(), AnsibleUnsafeBytes)
    assert isinstance(u.encode(encoding='utf-8'), AnsibleUnsafeBytes)
    assert isinstance(u.encode(encoding='utf-8', errors='strict'), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:39:32.855278
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.six import text_type
    value = to_text(b'text', errors='surrogate_or_strict', nonstring='passthru')
    assert isinstance(value, text_type)
    assert isinstance(value, AnsibleUnsafeText)

# Generated at 2022-06-23 14:39:44.706692
# Unit test for function wrap_var
def test_wrap_var():
    foo = {
        'a': 'foo',
        'b': [],
        'c': {},
        'd': (1, 2, 3),
    }

    assert wrap_var(foo) == wrap_var(foo)
    assert (isinstance(wrap_var(foo), Mapping))
    assert isinstance(wrap_var(foo)['a'], AnsibleUnsafeText)
    assert not isinstance(wrap_var(foo)['b'], AnsibleUnsafeText)
    assert (isinstance(wrap_var(foo)['b'], list))
    assert (isinstance(wrap_var(foo)['c'], dict))
    assert (isinstance(wrap_var(foo)['d'], tuple))


# Generated at 2022-06-23 14:39:56.565014
# Unit test for function wrap_var
def test_wrap_var():
    """Test if wrap_var does not alter the data unless it's marked as safe"""
    import itertools
    import collections
    import string

    unsafe_values = [
        AnsibleUnsafeBytes(),
        NativeJinjaUnsafeText(),
        AnsibleUnsafeText(),
        AnsibleUnsafe()
    ]


# Generated at 2022-06-23 14:40:00.566959
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy(None) is None
    expected_result = AnsibleUnsafeText(u'foo')
    assert UnsafeProxy(u'foo') == expected_result
    assert UnsafeProxy(b'foo') == expected_result



# Generated at 2022-06-23 14:40:02.925272
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert(isinstance(AnsibleUnsafeText('test').encode(), AnsibleUnsafeBytes) == True)


# Generated at 2022-06-23 14:40:04.655111
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    test = AnsibleUnsafe()
    assert test.__UNSAFE__ == True

# Generated at 2022-06-23 14:40:16.936288
# Unit test for method __new__ of class UnsafeProxy

# Generated at 2022-06-23 14:40:22.161566
# Unit test for function wrap_var

# Generated at 2022-06-23 14:40:33.387927
# Unit test for function wrap_var
def test_wrap_var():

    import json
    import sys


# Generated at 2022-06-23 14:40:34.873385
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe().__UNSAFE__ is True


# Generated at 2022-06-23 14:40:40.831121
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    from ansible.module_utils.six import assertCountEqual
    import sys

    if sys.version_info >= (3, 0):
        assert isinstance(AnsibleUnsafe(), object)
    else:
        assert issubclass(AnsibleUnsafe, object)

    assertCountEqual(dir(AnsibleUnsafe()), dir(object()))



# Generated at 2022-06-23 14:40:47.643795
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.errors import AnsibleDeprecationWarning
    import warnings
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        UnsafeProxy('foo')
        assert len(w) == 1
        assert issubclass(w[-1].category, AnsibleDeprecationWarning)
        assert 'wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText' in str(w[-1].message)


# Generated at 2022-06-23 14:40:57.207834
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_text

    if PY2:
        assert isinstance(to_unsafe_text('test', encoding='utf-8'), AnsibleUnsafeText)
        assert isinstance(to_unsafe_text(u'test', encoding='utf-8'), AnsibleUnsafeText)
        assert isinstance(to_unsafe_text('test', encoding='ascii'), AnsibleUnsafeText)
        assert isinstance(to_unsafe_text(u'test', encoding='ascii'), AnsibleUnsafeText)

        assert isinstance(to_unsafe_text(b'test', encoding='utf-8'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:41:05.423276
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy('foo'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'foo'), AnsibleUnsafeBytes)
    # Using AnsibleUnsafeText should not cause it to be wrapped as unsafe
    assert isinstance(UnsafeProxy(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    # Using AnsibleUnsafeBytes should not cause it to be wrapped as unsafe
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:41:07.558661
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    unsafe_text = AnsibleUnsafeText("test")
    assert isinstance(unsafe_text.encode(), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:41:18.764638
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(b'\xff'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'\xff', errors='strict'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'\xff', errors='surrogate_or_strict'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'\xff', errors='surrogate_then_replace'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'\xff', errors='surrogate_or_strict', nonstring='passthru'), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:41:23.768571
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    strings = [
        (u'This is a string', u'This is a string'),
        (b'\xed\xae\x9d\n', u'\udce4\udc9d\n'),
        (b'\xed\xae\n', '\udce4\n'),
        (b'\xed\n', '\udce4\n'),
        (b'\xed', '\udce4'),
    ]
    for test_tuple in strings:
        assert to_unsafe_text(test_tuple[0]) == test_tuple[1]

# Generated at 2022-06-23 14:41:35.509198
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import Iterable

    # If PY3 - convert string argument to bytes and call wrap_var,
    # for unicode argument call wrap_var and then .encode.
    if PY3:
        result_bytes = to_unsafe_bytes(u'Test')
        assert isinstance(result_bytes, AnsibleUnsafeBytes)
        assert isinstance(result_bytes, binary_type)
        assert result_bytes == b'Test'
        assert len(result_bytes) == 4

        result_text = to_unsafe_bytes(b'Test')
        assert isinstance(result_text, AnsibleUnsafeBytes)
        assert isinstance(result_text, binary_type)
        assert result_text

# Generated at 2022-06-23 14:41:39.193765
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert hasattr(AnsibleUnsafeBytes, '__UNSAFE__')
    assert AnsibleUnsafeBytes(b"ansible").decode() == u"ansible"
    assert AnsibleUnsafeBytes(b"ansible").decode().startswith(u"ansible")


# Generated at 2022-06-23 14:41:51.492054
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(u'abc') == AnsibleUnsafeText(u'abc')
    assert to_unsafe_text(u'abc'.encode('utf-8')) == AnsibleUnsafeText(u'abc')
    assert to_unsafe_text(u'abc'.encode('ascii')) == AnsibleUnsafeText(u'abc')
    assert to_unsafe_text(u'abc'.encode('utf-8'), 'ascii') == AnsibleUnsafeText(u'abc')
    assert to_unsafe_text(u'abc'.encode('utf-8'), 'nonutf8') == AnsibleUnsafeText(u'abc')

# Generated at 2022-06-23 14:41:54.789553
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    instance = AnsibleUnsafeText('test')
    # Test for a return value of None, which is an indicator of a bug.
    assert instance.encode('UTF-8'), "bug in AnsibleUnsafeText.encode()"



# Generated at 2022-06-23 14:42:02.914414
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # Test constructor with a bytes-like object
    # Create a class that looks like a byte array
    class byteslike:
        def __init__(self, array):
            self.array = array

        def __getitem__(self, key):
            return self.array[key]

        def __len__(self):
            return len(self.array)

    a_bytes_object = byteslike([1, 2, 3, 4, 5])

    # Test that the constructor of AnsibleUnsafeBytes works for bytes-like objects
    t_AnsibleUnsafeBytes = AnsibleUnsafeBytes(a_bytes_object)
    assert t_AnsibleUnsafeBytes == b'\x01\x02\x03\x04\x05'

    # Test that the constructor of AnsibleUnsafeText works for bytes-like objects
   

# Generated at 2022-06-23 14:42:05.016763
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    result = str(AnsibleUnsafeBytes('foo'))
    assert result == "b'foo'"


# Generated at 2022-06-23 14:42:07.017403
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes('foo').decode(), AnsibleUnsafeText)



# Generated at 2022-06-23 14:42:12.162497
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert AnsibleUnsafeText('Unsafe') == 'Unsafe', 'String "Unsafe" should be converted to AnsibleUnsafeText'
    assert isinstance(AnsibleUnsafeText(u'Unsafe'), text_type), 'AnsibleUnsafeText should be converted to unicode'

# Test for methods of class AnsibleUnsafeText

# Generated at 2022-06-23 14:42:20.566655
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    class AnsibleUnsafeTest(object):
        __UNSAFE__ = True

    assert AnsibleUnsafeTest().__class__.__name__ == "AnsibleUnsafeTest"
    assert UnsafeProxy(AnsibleUnsafeTest()).__class__.__name__ == "AnsibleUnsafeTest"

    assert AnsibleUnsafeTest == UnsafeProxy(AnsibleUnsafeTest())
    assert AnsibleUnsafeTest() == UnsafeProxy(AnsibleUnsafeTest())
    assert AnsibleUnsafeTest.__dict__ is UnsafeProxy(AnsibleUnsafeTest()).__dict__
    assert AnsibleUnsafeTest().__dict__ is UnsafeProxy(AnsibleUnsafeTest()).__dict__



# Generated at 2022-06-23 14:42:31.778677
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import ansible.module_utils.six as six
    assert to_unsafe_text(six.text_type('test')) == six.text_type('test')
    assert to_unsafe_text('test') == six.text_type('test')
    assert isinstance(to_unsafe_text(six.text_type('test')), six.text_type)
    assert isinstance(to_unsafe_text('test'), six.text_type)
    assert isinstance(to_unsafe_text('test'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(six.text_type('test')), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeText, AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeText(), AnsibleUnsafeText)
   

# Generated at 2022-06-23 14:42:42.952947
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.six import string_types, binary_type
    from ansible.utils.display import Display
    from ansible.module_utils.common.collections import is_sequence

    def wrap_sequence(v):
        v_type = type(v)
        return v_type(wrap_var(item) for item in v)

    # Test None value
    assert wrap_var(None) is None

    # Test string types
    # Test byte strings
    byte_string = to_bytes(u'bytes')
    ansible_unsafe_bytes = AnsibleUnsafeBytes(byte_string)
    assert wrap_var(byte_string) == ansible

# Generated at 2022-06-23 14:42:54.160518
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    """
    Tests the constructor of class NativeJinjaUnsafeText
    """
    class_name = "NativeJinjaUnsafeText"
    class_methods = ["__init__"]
    class_methods_args = {"__init__": {"v": "str"}}

    # Instantiation of objects
    namespace_obj = {}
    exec("from ansible.module_utils.unsafe_proxy import NativeJinjaUnsafeText as %s" % class_name, namespace_obj)

    class_obj = namespace_obj[class_name]

    # Iterate over class methods
    for method in class_methods:
        method_obj = getattr(class_obj, method)

# Generated at 2022-06-23 14:43:04.244997
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.compat.tests.mock import patch
    from ansible.module_utils.six import PY3

    mock_var = b'wibble'
    if PY3:
        # under python3 we should get back an AnsibleUnsafeText object
        mock_return = to_unsafe_bytes(mock_var)
        assert isinstance(mock_return, AnsibleUnsafeText)
    else:
        # under python2 we should get back an AnsibleUnsafeBytes object
        mock_return = to_unsafe_bytes(mock_var)
        assert isinstance(mock_return, AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:43:07.455984
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    t = AnsibleUnsafeText("abc")
    assert isinstance(t, AnsibleUnsafeText)
    assert t.__UNSAFE__

# Generated at 2022-06-23 14:43:11.898000
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert issubclass(UnsafeProxy(''), text_type)
    assert issubclass(UnsafeProxy(u''), text_type)
    assert issubclass(UnsafeProxy(b''), binary_type)
    assert issubclass(UnsafeProxy(b''), AnsibleUnsafe)



# Generated at 2022-06-23 14:43:17.485272
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    byte = b'abc'
    byte = AnsibleUnsafeBytes(byte)
    assert byte[0] == b'a'
    assert byte[1] == b'b'
    assert byte[2] == b'c'
    assert byte.decode() == 'abc'
    assert type(byte) == AnsibleUnsafeBytes


# Generated at 2022-06-23 14:43:19.675170
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u'foo'), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:43:22.749152
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    """Test constructor of class AnsibleUnsafeBytes
    """
    ansi_unsafe_bytes_obj = AnsibleUnsafeBytes(b'string')
    assert ansi_unsafe_bytes_obj



# Generated at 2022-06-23 14:43:26.223230
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert not hasattr(AnsibleUnsafe(), '__UNSAFE__')
    assert hasattr(AnsibleUnsafeBytes(), '__UNSAFE__')
    assert hasattr(AnsibleUnsafeText(), '__UNSAFE__')


# Generated at 2022-06-23 14:43:38.479693
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.vars.unsafe_proxy import to_unsafe_text
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    assert isinstance(to_unsafe_text('abc'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'ABC'), AnsibleUnsafeText)

    assert isinstance(to_unsafe_text('abc'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text('\xae'), AnsibleUnsafeText)

    try:
        to_unsafe_text('\x81')
    except UnicodeDecodeError:
        pass
    else:
        raise AssertionError("UnicodeDecodeError expected on bad input")


# Generated at 2022-06-23 14:43:45.314012
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u'foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u'foo'.encode('utf-8')), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u'f\xe3o'.encode('utf-8')), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:43:50.078487
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    Foo = AnsibleUnsafe()
    # This is a Python2 trick to dynamically create a new class and make it inherit from AnsibleUnsafe
    Bar = type('Bar', (AnsibleUnsafe,), {})
    assert Foo.__UNSAFE__
    assert Bar.__UNSAFE__


# Generated at 2022-06-23 14:43:53.249270
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    value = AnsibleUnsafeText(u'test')
    assert isinstance(value, text_type)
    assert isinstance(value, AnsibleUnsafe)
    assert 'test' == value


# Generated at 2022-06-23 14:43:54.630506
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert isinstance(NativeJinjaUnsafeText('foo bar'), AnsibleUnsafe)

# Generated at 2022-06-23 14:44:01.338430
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert to_unsafe_bytes(b'foo') is not None
    assert to_unsafe_text(u'foo') is not None

    o = UnsafeProxy(b'foo')
    assert isinstance(o, AnsibleUnsafeBytes)

    o = UnsafeProxy(u'foo')
    assert isinstance(o, AnsibleUnsafeText)

    o = UnsafeProxy(o)
    assert isinstance(o, AnsibleUnsafeText)



# Generated at 2022-06-23 14:44:10.440369
# Unit test for function wrap_var
def test_wrap_var():

    try:
        from numpy import array
    except:
        import warnings
        warnings.warn("numpy not installed, cannot run ansible module "
                      "unit tests")
        raise

    assert wrap_var(None) is None
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert wrap_var('foo') == 'foo'
    assert wrap_var(u'foo') == 'foo'
    assert wrap_var(b'foo') == 'foo'

    assert isinstance(wrap_var({'foo': 'bar'}), dict)

# Generated at 2022-06-23 14:44:17.989728
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    unsafe_bytes = AnsibleUnsafeBytes(b'\xc3\xb1') # \xc3\xb1 is the UTF-8 encoding of ñ
    unsafe_text = unsafe_bytes.decode('utf-8')
    if isinstance(unsafe_text, AnsibleUnsafeText):
        print("Unit test for method decode of class AnsibleUnsafeBytes: OK")
    else:
        print("Unit test for method decode of class AnsibleUnsafeBytes: ERROR")



# Generated at 2022-06-23 14:44:22.836464
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY2
    if PY2:
        from ansible.module_utils.six import string_types as basestring
    else:
        from ansible.module_utils.six import string_types as basestring

    assert wrap_var(None) is None
    assert type(wrap_var(u"test")) == AnsibleUnsafeText
    assert type(wrap_var(b"test")) == AnsibleUnsafeBytes
    assert type(wrap_var(AnsibleUnsafeText(u"test"))) == AnsibleUnsafeText
    assert type(wrap_var([1,2,3])) == list
    assert type(wrap_var({'a': 1})) == dict
    assert type(wrap_var(set([1,2,3]))) == set

# Generated at 2022-06-23 14:44:33.940172
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    ERROR_STRING = u'\uFFFD'
    TEST_BYTES = b'\x96'

    def _convert(val):
        return to_bytes(val, errors='replace')

    def _decode_safe(val):
        return to_text(val, errors='replace')

    def _decode_unsafe(val):
        return wrap_var(val).decode()

    assert _convert(TEST_BYTES) == to_unsafe_bytes(TEST_BYTES)
    assert _decode_safe(TEST_BYTES) == to_unsafe_text(TEST_BYTES)
    assert _decode_safe(TEST_BYTES) == _decode_unsafe(TEST_BYTES)

# Generated at 2022-06-23 14:44:41.852279
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    test_data = [
        ('a_binary_string', 'ansible.module_utils.unsafe_proxy.AnsibleUnsafeText', (b'a_binary_string',), {}),
        ('a_unicode_string', 'ansible.module_utils.unsafe_proxy.AnsibleUnsafeText', (u'a_unicode_string',), {}),
    ]

    for test in test_data:
        expected = test[1]
        actual = AnsibleUnsafeBytes(test[0]).decode().__class__.__name__
        assert actual == expected, "%s != %s" % (actual, expected)

# Generated at 2022-06-23 14:44:44.508492
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    bin = AnsibleUnsafeBytes('hello')
    assert(bin == 'hello')
    assert(bin.__UNSAFE__)


# Generated at 2022-06-23 14:44:51.130502
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    u = AnsibleUnsafe()
    assert u.__UNSAFE__ == True
    assert str(u) == '<ansible.module_utils.basic.AnsibleUnsafe>'
    assert repr(u) == '<ansible.module_utils.basic.AnsibleUnsafe>'
    assert isinstance(u, AnsibleUnsafe)
    assert not isinstance(u, AnsibleUnsafeBytes)
    assert not isinstance(u, AnsibleUnsafeText)


# Generated at 2022-06-23 14:45:00.781705
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    import types

    def _testfunc():return

    v = UnsafeProxy('hello')
    assert isinstance(v, text_type)
    assert isinstance(v, AnsibleUnsafeText)

    v = UnsafeProxy(b'hello')
    assert isinstance(v, binary_type)
    assert isinstance(v, AnsibleUnsafeBytes)

    v = UnsafeProxy(123)
    assert isinstance(v, (int, long))

    v = UnsafeProxy(u'hello')
    assert isinstance(v, text_type)
    assert isinstance(v, AnsibleUnsafeText)

    v = UnsafeProxy(UnsafeProxy(u'hello'))
    assert isinstance(v, text_type)
    assert isinstance(v, AnsibleUnsafeText)


# Generated at 2022-06-23 14:45:11.555749
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    if PY3:
        # assertIsInstance in py3 doesn't take a tuple of types
        from ansible.module_utils.six.moves import unittest
    else:
        import unittest

    class TestWrapVar(unittest.TestCase):

        def test_wrap_bytes(self):
            value = b"value"
            self.assertIsInstance(wrap_var(value), AnsibleUnsafeBytes)

        def test_wrap_text(self):
            value = "value"
            self.assertIsInstance(wrap_var(value), AnsibleUnsafeText)

        def test_wrap_dict(self):
            value = {"key": "value"}
            self.assertIsInstance(wrap_var(value), dict)

# Generated at 2022-06-23 14:45:20.599258
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.utils.display import Display
    display = Display()
    display.colorize('black','white')
    display.deprecated(
            'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
            version='2.13', collection_name='ansible.builtin'
        )
    wrap_var(AnsibleUnsafeText('hello'))
    wrap_var(AnsibleUnsafeBytes(b'hello'))
    wrap_var(NativeJinjaUnsafeText('hello'))
    wrap_var(NativeJinjaUnsafeText(b'hello'))

# Generated at 2022-06-23 14:45:23.487375
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    obj = AnsibleUnsafeText("str")
    assert isinstance(obj.encode("utf8"), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:45:33.316310
# Unit test for function wrap_var
def test_wrap_var():
    import json

    # Test a simple string
    res = wrap_var("Test string")
    assert isinstance(res, AnsibleUnsafeText)
    assert str(res) == "Test string"

    # Test a dict
    res = wrap_var({'a': 'b', 'c': 'd'})
    assert str(res) == str({"a": "b", "c": "d"})
    assert isinstance(res, dict)
    assert isinstance(res['a'], AnsibleUnsafeText)
    assert isinstance(res['c'], AnsibleUnsafeText)

    # Test a set
    res = wrap_var(set(['a', 'b', 'c']))
    assert len(res) == 3
    assert isinstance(res, set)

# Generated at 2022-06-23 14:45:35.562906
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    unsafe_text = AnsibleUnsafeText("unsafe_text")
    assert "unsafe_text" == unsafe_text


# Generated at 2022-06-23 14:45:37.558528
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    s = u'Test string'
    njut = NativeJinjaUnsafeText(s)

# Generated at 2022-06-23 14:45:47.941736
# Unit test for method decode of class AnsibleUnsafeBytes

# Generated at 2022-06-23 14:45:54.805591
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.common.text.converters import to_text
    assert isinstance(UnsafeProxy('hello'), text_type)
    assert UnsafeProxy('hello') == 'hello'
    assert UnsafeProxy(to_text('hello')) == 'hello'
    assert UnsafeProxy(['hello', 'world']) == ['hello', 'world']
    assert UnsafeProxy({'a': 'hello', 'b': 'world'}) == {'a': 'hello', 'b': 'world'}
    assert isinstance(UnsafeProxy(['hello', 'world']), list)
    assert isinstance(UnsafeProxy({'a': 'hello', 'b': 'world'}), dict)

# Generated at 2022-06-23 14:45:56.891628
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes(b"test"), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:45:59.828284
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes("ansible").decode("utf-8"), AnsibleUnsafeText)


# Generated at 2022-06-23 14:46:11.051255
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    # Test all unsafe types
    bad_inputs = [b'',
                  '',
                  b'unsafe',
                  'unsafe',
                  [],
                  [b''],
                  [''],
                  [b'unsafe'],
                  [''],
                  {},
                  {b'k': ''},
                  {b'k': 'unsafe'},
                  {'': ''},
                  {'': 'unsafe'},
                  {'k': b''},
                  {'k': b'unsafe'}]


# Generated at 2022-06-23 14:46:15.721775
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes('this is a safe string'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(None), type(None))
    assert isinstance(to_unsafe_bytes(b'\x00'), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:46:26.485470
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    import builtins
    import types

    class Foo:
        bar = None

        def __init__(self):
            self.bar = "This should be AnsibleUnsafe"

    # Case 1: Proxy an object that is not a string
    foo = Foo()
    assert isinstance(UnsafeProxy(foo), Foo) == True

    # Case 2: Proxy a string that doesn't contain any jinja stuff
    assert isinstance(UnsafeProxy("foo"), AnsibleUnsafeText) == True

    # Case 3: Proxy a string that contains jinja stuff
    # We need to mock the jinja module for this to work
    # and make sure our proxy class will return the
    # template object
    builtins.__dict__['jinja2'] = types.ModuleType('jinja2')
    jinja2 = builtins.__dict

# Generated at 2022-06-23 14:46:38.976054
# Unit test for function wrap_var
def test_wrap_var():
    # Check if wrap_var wrap all the types
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(True), type(True))
    assert isinstance(wrap_var(1), type(1))
    assert isinstance(wrap_var(1.0), type(1.0))
    assert isinstance(wrap_var(b""), type(b""))
    assert isinstance(wrap_var(""), type(""))
    assert isinstance(wrap_var([]), type([]))
    assert isinstance(wrap_var({}), type({}))
    assert isinstance(wrap_var(()), type(()))
    assert isinstance(wrap_var({1, 2}), type({1, 2}))

    # Check the type of object after wrap_var

# Generated at 2022-06-23 14:46:49.103760
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    # Test default
    assert wrap_var(to_bytes("test\uFFFD")) == to_unsafe_bytes("test\uFFFD")
    # Test errors='surrogate_or_strict'
    assert wrap_var(to_bytes("test\xff\xff\xff", errors='surrogate_or_strict')) == to_unsafe_bytes("test\xff\xff\xff", errors='surrogate_or_strict')
    # Test errors='surrogate_or_strict' with safe_text=True
    assert wrap_var(to_bytes("test\xff\xff\xff", errors='surrogate_or_strict', safe_text=True)) == to_unsafe_bytes("test\xff\xff\xff", errors='surrogate_or_strict', safe_text=True)


# Generated at 2022-06-23 14:46:54.749084
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # test decode pass through
    enc = 'utf8'
    v = wrap_var(u'abc')
    assert isinstance(v, AnsibleUnsafeText)
    assert v.encode(enc) == b'abc'

    # test conversion to unsafe
    b = v.encode(enc)
    assert isinstance(b, binary_type)
    assert b.decode(enc) == v



# Generated at 2022-06-23 14:46:59.927133
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    my_str = u'some unsafe data'
    assert AnsibleUnsafeText(my_str) == my_str
    my_str = b'some unsafe data'
    assert AnsibleUnsafeText(my_str) == u'some unsafe data'


# Generated at 2022-06-23 14:47:08.116524
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    from ansible.module_utils.compat.ipaddress import ip_network
    from ansible.module_utils.six import binary_type, text_type
    assert issubclass(AnsibleUnsafeBytes, binary_type)
    assert issubclass(AnsibleUnsafeText, text_type)
    assert issubclass(NativeJinjaUnsafeText, text_type)
    # Since this is just a marker class, the constructor takes no arguments
    assert issubclass(AnsibleUnsafe, type)

    # Ensure that we don't get duplicate __UNSAFE__ attributes
    u_bytes = AnsibleUnsafeBytes('127.0.0.1')
    assert 1 == len(dir(u_bytes))
    u_text = AnsibleUnsafeText('127.0.0.1')

# Generated at 2022-06-23 14:47:12.725968
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    test_string = to_text('test_string')
    my_NativeJinjaUnsafeText = NativeJinjaUnsafeText(test_string)
    assert isinstance(my_NativeJinjaUnsafeText, text_type)
    assert my_NativeJinjaUnsafeText == test_string


# Generated at 2022-06-23 14:47:15.558705
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    test_str = 'hello world'
    test_str_unsafe = AnsibleUnsafeBytes(test_str)
    assert isinstance(test_str_unsafe, AnsibleUnsafeBytes)
    assert isinstance(test_str_unsafe, binary_type)
    assert isinstance(test_str_unsafe, AnsibleUnsafe)
    assert test_str_unsafe == test_str
    assert test_str_unsafe.decode() == test_str


# Generated at 2022-06-23 14:47:27.113717
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.ansible_unsafe import AnsibleUnsafe, UnsafeProxy

    obj = to_text(b'\x00\x01\x02\x03\x04\x05', errors='surrogate_or_strict')
    obj_type = type(obj)
    assert(obj_type == AnsibleUnsafeText)

    obj = UnsafeProxy(obj)
    obj_type = type(obj)
    assert(obj_type == AnsibleUnsafeText)
    assert(obj.startswith(u'\x00\x01\x02\x03\x04\x05'))

    obj = obj.encode

# Generated at 2022-06-23 14:47:35.955308
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    '''Test constructor of class AnsibleUnsafeBytes'''
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    ustring = 'test'
    Ustring = ustring
    if isinstance(ustring, text_type):
        Ustring = ustring.encode('utf-8')
    # Test with no optional parameters
    test_obj = AnsibleUnsafeBytes(Ustring)
    assert test_obj.__UNSAFE__ == True

    # Test with optional parameter encoding
    test_obj = AnsibleUnsafeBytes(ustring, encoding='utf-8')
    assert test_obj.__UNSAFE__ == True


# Generated at 2022-06-23 14:47:38.229697
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert(isinstance(AnsibleUnsafeText('abc').encode('utf-8'), AnsibleUnsafeBytes))

# Generated at 2022-06-23 14:47:49.680020
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(1) == "'1'"
    assert to_unsafe_text(None) is None
    assert to_unsafe_text("foo") == "foo"
    assert to_unsafe_text("foo", keep_trailing_newline=True) == "foo\n"
    assert to_unsafe_text("foo\n", keep_trailing_newline=True) == "foo\n"
    assert to_unsafe_text("foo\n") == "foo"
    assert to_unsafe_text("foo\n", errors='surrogate_or_strict') == "foo"
    assert to_unsafe_text("foo\n", errors='surrogate_or_strict', keep_trailing_newline=True) == "foo\n"
    assert to_unsafe_

# Generated at 2022-06-23 14:47:53.997674
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    test_string = AnsibleUnsafeText('abc')
    assert isinstance(test_string.encode('ascii'), AnsibleUnsafeBytes)
    test_string = AnsibleUnsafeText('イロハ')
    assert isinstance(test_string.encode('utf-8'), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:48:06.315467
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u'bar'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'baz', errors='surrogate_or_strict'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u'qux', errors='surrogate_or_strict'), AnsibleUnsafeBytes)
    assert to_unsafe_bytes(b'foo') == b'foo'
    assert to_unsafe_bytes(u'bar') == b'bar'
    assert to_unsafe_bytes(b'baz', errors='surrogate_or_strict') == b'baz'