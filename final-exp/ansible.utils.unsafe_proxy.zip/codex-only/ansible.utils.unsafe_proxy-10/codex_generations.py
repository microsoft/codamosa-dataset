

# Generated at 2022-06-23 14:38:06.905081
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.utils.display import Display

    display = Display()
    display.deprecated(
        'UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin'
    )
    assert isinstance(to_unsafe_bytes('str'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:38:12.212322
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    from ansible.utils.display import Display

    Display().deprecated(
        'AnsibleUnsafeText is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
    )

    assert type(AnsibleUnsafeText("teststring")) is AnsibleUnsafeText

# Generated at 2022-06-23 14:38:19.067016
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.six import PY2
    import pickle

    if PY2:
        # On Python 2 to_unicode method is not overriden,
        # so it continues to return instance of str.
        # Therefore, we can't test pickling.
        assert isinstance(UnsafeProxy('a'), str)
        return

    assert isinstance(UnsafeProxy('a'), str)
    assert pickle.loads(pickle.dumps(UnsafeProxy('foo')), encoding='bytes') == b'foo'

# Generated at 2022-06-23 14:38:29.692861
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.six import integer_types

    # test for unicode
    assert(isinstance(UnsafeProxy(u''), AnsibleUnsafeText))

    # test for non-Unsafe types: Sequence, int, float
    assert(isinstance(UnsafeProxy(Sequence()), Sequence))
    assert(isinstance(UnsafeProxy(10), integer_types))
    assert(isinstance(UnsafeProxy(10.5), float))

    # test for unsafe types: AnsibleUnsafe, AnsibleUnsafeText, AnsibleUnsafeBytes
    assert(isinstance(UnsafeProxy(AnsibleUnsafe()), AnsibleUnsafe))

# Generated at 2022-06-23 14:38:32.644504
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    obj = AnsibleUnsafeText('aup')
    assert isinstance(obj, text_type)
    assert isinstance(obj, AnsibleUnsafe)


# Generated at 2022-06-23 14:38:37.828622
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():

    s = AnsibleUnsafeText(u'blah')

    assert isinstance(s, text_type)
    assert s == u'blah'
    assert s.__len__() == 4
    assert isinstance(s, AnsibleUnsafe)
    assert s.__UNSAFE__ is True


# Generated at 2022-06-23 14:38:40.673523
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    s = AnsibleUnsafeText('abc')
    assert isinstance(s.encode(), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:38:45.472442
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    val = UnsafeProxy('foo')
    assert isinstance(val, AnsibleUnsafeText)
    assert val == 'foo'
    assert val.__UNSAFE__

    val = UnsafeProxy(UnsafeProxy('foo'))
    assert isinstance(val, AnsibleUnsafeText)
    assert val == 'foo'
    assert val.__UNSAFE__

# Generated at 2022-06-23 14:38:50.083353
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert isinstance(AnsibleUnsafeText(u'test'), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeText(u'\u03BCnico\u0394\xab'), AnsibleUnsafeText)


# Generated at 2022-06-23 14:38:52.163841
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert(isinstance(AnsibleUnsafe(), AnsibleUnsafe))

# Generated at 2022-06-23 14:38:59.368179
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    byte_string = b'This should be converted to text type'
    byte_unsafe_string = to_unsafe_bytes(byte_string)
    # the instance should be of class AnsibleUnsafeBytes
    assert isinstance(byte_unsafe_string, AnsibleUnsafeBytes)
    # check if the decoding works
    assert isinstance(byte_unsafe_string.decode(), AnsibleUnsafeText)



# Generated at 2022-06-23 14:39:06.402887
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # Test AnsibleUnsafeBytes
    test_obj = AnsibleUnsafeBytes(b'This is unsafe bytes')
    assert isinstance(test_obj, binary_type)
    assert isinstance(test_obj, AnsibleUnsafe)

    # Test AnsibleUnsafeText
    test_obj = AnsibleUnsafeText(u'This is unsafe text')
    assert isinstance(test_obj, text_type)
    assert isinstance(test_obj, AnsibleUnsafe)



# Generated at 2022-06-23 14:39:12.863152
# Unit test for function wrap_var
def test_wrap_var():
    import json

    d = dict(foo='bar', bar=dict(qux='qux', baz='baz'))
    d = wrap_var(d)
    j = json.dumps(d, ensure_ascii=False)
    j_out = '{"foo": "bar", "bar": {"qux": "qux", "baz": "baz"}}'
    print('wrap_var json: %s' % j)
    print('wrap_var j_out: %s' % j_out)
    assert j == j_out

# Generated at 2022-06-23 14:39:15.237144
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe().__UNSAFE__ is True
    assert AnsibleUnsafeBytes().__UNSAFE__ is True
    assert AnsibleUnsafeText().__UNSAFE__ is True


# Generated at 2022-06-23 14:39:24.126477
# Unit test for function wrap_var
def test_wrap_var():
    import sys

    if sys.version_info.major > 2:
        bytes_t = bytes
        text_t = str
    else:
        bytes_t = str
        text_t = unicode


# Generated at 2022-06-23 14:39:35.938996
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.module_utils.six import PY2
    import collections
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types, text_type
    from ansible.module_utils.basic import AnsibleUnsafe, wrap_var

    assert issubclass(NativeJinjaUnsafeText, AnsibleUnsafe)
    assert issubclass(NativeJinjaUnsafeText, text_type)
    assert issubclass(NativeJinjaUnsafeText, string_types)
    if PY2:
        assert issubclass(NativeJinjaUnsafeText, (unicode, str))
    else:
        assert issubclass(NativeJinjaUnsafeText, (str,))

# Generated at 2022-06-23 14:39:39.906862
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    x = AnsibleUnsafeBytes(u'abc'.encode('utf-8'))
    assert x == 'abc'
    assert isinstance(x, AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:39:41.232036
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert AnsibleUnsafeText('ABCDEF').encode() == AnsibleUnsafeBytes(b'ABCDEF')


# Generated at 2022-06-23 14:39:42.985769
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text('foo') == u'foo'


# Generated at 2022-06-23 14:39:51.678874
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert wrap_var(AnsibleUnsafeText(u'foo')) is u'foo'
    assert wrap_var(AnsibleUnsafeBytes(b'foo')) is b'foo'
    assert wrap_var(AnsibleUnsafeText(u'foo')) == AnsibleUnsafeText(u'foo')
    assert not isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert not isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'foo'), text_type)
    assert isinstance(wrap_var(b'foo'), binary_type)
    assert wrap_var(u'foo') == u'foo'
    assert wrap_var(b'foo') == b'foo'


# Generated at 2022-06-23 14:39:54.048538
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    ansible_unsafe = AnsibleUnsafe()
    assert ansible_unsafe


# Generated at 2022-06-23 14:39:56.163433
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    try:
        NativeJinjaUnsafeText()
    except TypeError:
        assert False, 'NativeJinjaUnsafeText() throws TypeError'

# Generated at 2022-06-23 14:39:57.203698
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert (AnsibleUnsafeText() == AnsibleUnsafeText)

# Generated at 2022-06-23 14:40:00.975469
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Check that we return same object if it is already instance of AnsibleUnsafe
    assert UnsafeProxy(AnsibleUnsafeText("ansible")) is AnsibleUnsafeText("ansible")


# Generated at 2022-06-23 14:40:03.290332
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert(isinstance(AnsibleUnsafeBytes(b'Test').decode(), AnsibleUnsafeText))


# Generated at 2022-06-23 14:40:15.892548
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():

    # test calling __new__ directly
    s = UnsafeProxy("foo")
    assert(s == "foo")
    assert(isinstance(s, AnsibleUnsafe))

    # test calling via the constructor
    u = UnsafeProxy(s)
    assert(u == "foo")
    assert(isinstance(u, AnsibleUnsafe))

    # test with a native string
    s = "foo"
    assert(s == "foo")
    assert(isinstance(s, str))

    # test calling __new__ directly
    u = UnsafeProxy(s)
    assert(u == "foo")
    assert(isinstance(u, AnsibleUnsafe))

    # test calling via the constructor
    u = UnsafeProxy(u)
    assert(u == "foo")

# Generated at 2022-06-23 14:40:25.695905
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils._text import to_text
    from ansible.utils.unsafe_proxy import to_unsafe_bytes, wrap_var
    assert wrap_var(to_unsafe_bytes(u'\xe9', encoding='utf-8')) == u'\xe9'
    assert to_unsafe_bytes(u'\xe9', encoding='utf-8') == u'\xe9'
    assert to_text(to_unsafe_bytes(u'\xe9', encoding='utf-8')) == u'\xe9'
    assert to_text(to_unsafe_bytes(u'\xe9', encoding='utf-8'), encoding='utf-8') == u'\xe9'

# Generated at 2022-06-23 14:40:30.000438
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes(b'foo') == b'foo'
    assert type(AnsibleUnsafeBytes(b'foo')) == AnsibleUnsafeBytes
    assert isinstance(AnsibleUnsafeBytes(b'foo'), AnsibleUnsafe)
    assert AnsibleUnsafeBytes(b'foo').decode('utf-8') == 'foo'
    assert type(AnsibleUnsafeBytes(b'foo').decode('utf-8')) == AnsibleUnsafeText


# Generated at 2022-06-23 14:40:34.722774
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    '''
    This test has been created to ensure that when we call the method "encode" of the class
    AnsibleUnsafeText, we are still in the unsafe context.
    '''
    string = "this is a string"
    class_instance = AnsibleUnsafeText(string)
    assert isinstance(class_instance.encode(), AnsibleUnsafeBytes)
    assert isinstance(class_instance.encode().decode(), AnsibleUnsafeText)
    assert not isinstance(class_instance.encode().decode(encoding="utf-8"), AnsibleUnsafeText)


# Generated at 2022-06-23 14:40:38.358887
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    ansibleUnsafeBytes = AnsibleUnsafeBytes(b'AnsibleUnsafeBytes')
    assert isinstance(ansibleUnsafeBytes.decode(), AnsibleUnsafeText)


# Generated at 2022-06-23 14:40:45.379518
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    """This test will pass when the constructor of class AnsibleUnsafeText
    is working correctly.
    """
    my_unsafe_bytes_1 = AnsibleUnsafeBytes(b"This is an unsafe text")

    assert isinstance(my_unsafe_bytes_1, binary_type)
    assert isinstance(my_unsafe_bytes_1, AnsibleUnsafe)
    assert isinstance(my_unsafe_bytes_1, AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:40:49.790170
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    import sys
    import types
    my_unicode_string = u'test'
    my_text = to_unsafe_bytes(my_unicode_string, encoding=sys.getdefaultencoding())
    assert isinstance(my_text, binary_type)
    assert isinstance(my_text, AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:40:59.237181
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var('test'), AnsibleUnsafeText)
    assert isinstance(wrap_var('test').encode(), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'test'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'test').decode(), AnsibleUnsafeText)
    assert isinstance(wrap_var({"a": 1}), Mapping)
    assert isinstance(wrap_var({"a": 1})["a"], AnsibleUnsafeText)
    assert isinstance(wrap_var(("1", 2)), tuple)
    assert isinstance(wrap_var(("1", 2))[0], AnsibleUnsafeText)
    assert isinstance(wrap_var(("1", 2))[1], AnsibleUnsafeText)

# Generated at 2022-06-23 14:41:10.423892
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert hasattr(AnsibleUnsafeBytes, '__UNSAFE__'), \
        "AnsibleUnsafeBytes should have '__UNSAFE__' attribute"
    assert issubclass(AnsibleUnsafeBytes, binary_type), \
        "AnsibleUnsafeBytes should derive from binary_type"
    assert issubclass(AnsibleUnsafeBytes, AnsibleUnsafe), \
        "AnsibleUnsafeBytes should derive from AnsibleUnsafe"
    aub = AnsibleUnsafeBytes(b"test")
    assert isinstance(aub, binary_type), \
        "AnsibleUnsafeBytes should be of type binary_type"
    assert isinstance(aub, AnsibleUnsafe), \
        "AnsibleUnsafeBytes should be of type AnsibleUnsafe"

# Generated at 2022-06-23 14:41:16.279330
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes(b'Foo'), AnsibleUnsafeBytes)
    assert AnsibleUnsafeBytes(b'Foo').decode() == u'Foo'
    assert AnsibleUnsafeBytes(b'Foo').encode() == b'Foo'


# Generated at 2022-06-23 14:41:26.660265
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    # demonstrate the basic functionality of NativeJinjaUnsafeText
    # creating a NativeJinjaUnsafeText object from a string
    exampleString = 'example'
    exampleNativeJinjaUnsafeText = NativeJinjaUnsafeText(exampleString)
    assert(isinstance(exampleNativeJinjaUnsafeText, NativeJinjaUnsafeText))
    # ensure the string value of the NativeJinjaUnsafeText object matches the original string
    assert(exampleString == exampleNativeJinjaUnsafeText)
    # also ensure that the NativeJinjaUnsafeText object is of an AnsibleUnsafe class
    assert(isinstance(exampleNativeJinjaUnsafeText, AnsibleUnsafe))

# Generated at 2022-06-23 14:41:35.958158
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    test_cases = [
        {
            'args': ['abc'],
            'obj': AnsibleUnsafeBytes('abc')
        },
        {
            'args': [],
            'obj': AnsibleUnsafeBytes()
        },
        {
            'args': [None],
            'obj': AnsibleUnsafeBytes()
        },
        {
            'args': ['', 'def'],
            'obj': AnsibleUnsafeBytes('', 'def')
        },
    ]

    for case in test_cases:
        assert isinstance(AnsibleUnsafeBytes(*case['args']), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:41:38.407191
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    a = UnsafeProxy("sdfsdfsdfsdfsdf")
    assert isinstance(a, AnsibleUnsafeText)
    assert isinstance(a, AnsibleUnsafe)

# Generated at 2022-06-23 14:41:44.609713
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from unittest import TestCase

    class TestUnsafeProxy___new__(TestCase):
        def setUp(self):
            from ansible.utils.unsafe_proxy import UnsafeProxy
            self.proxy = UnsafeProxy

        def tearDown(self):
            del self.proxy

        def test_init(self):
            self.assertEqual(self.proxy(''), u'')
            self.assertEqual(self.proxy(u'utf8'), u'utf8')
            self.assertEqual(self.proxy(u'utf8'.encode('utf-8')), u'utf8')

# Generated at 2022-06-23 14:41:46.336436
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafeBytes
    assert AnsibleUnsafeText


# Generated at 2022-06-23 14:41:57.381552
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    import ansible.module_utils.basic as basic
    import os

    basic.ANSIBLE_FORCE_COLOR = "false"      # force to display colored message in this unit test
    basic.display.warning('[DEPRECATION WARNING]: Warning unit test')
    if not os.path.exists('/tmp/ansible_unsafe_text.log'):
        a = ansible.module_utils.basic.AnsibleUnsafeText(u'success')
        basic.display.warning('[DEPRECATION WARNING]: Successfully created instance of class AnsibleUnsafeText')
        os.mknod('/tmp/ansible_unsafe_text.log')

# Generated at 2022-06-23 14:42:09.613448
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types
    # Test with a string that cannot be converted to bytes.
    # This should not fail.
    assert isinstance(AnsibleUnsafeText("some utf-8 string: ä").encode(), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText(to_text("some utf-8 string: ä")).encode(), AnsibleUnsafeBytes)
    # Test with an integer.
    # This should not fail.
    assert isinstance(AnsibleUnsafeText(42).encode(), AnsibleUnsafeBytes)
    # Test with a dict that contains a string that cannot be converted to bytes

# Generated at 2022-06-23 14:42:15.738896
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    try:
        # Verify the class creation works
        foo = NativeJinjaUnsafeText('bar')
        # Verify the class has the right attributes
        assert foo.__UNSAFE__
        foo = NativeJinjaUnsafeText(b'bar')
        assert foo.__UNSAFE__
    except Exception:
        raise AssertionError("Class definition and constructor of NativeJinjaUnsafeText failed")

# Generated at 2022-06-23 14:42:27.571891
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import b, u

    # Test that we can pass in a string, unicode or None
    assert type(UnsafeProxy(None)) == AnsibleUnsafeText
    assert type(UnsafeProxy(b('foo'))) == AnsibleUnsafeBytes
    assert type(UnsafeProxy(u('foo'))) == AnsibleUnsafeText

    # Test that we can pass in an unsafe object
    obj = AnsibleUnsafeText('foo')
    assert type(UnsafeProxy(obj)) == AnsibleUnsafeText
    assert UnsafeProxy(obj) == 'foo'

    # Test that we can pass in a regular object without error
    try:
        UnsafeProxy(object())
    except Exception:
        assert False, "UnsafeProxy() should not throw an error on a regular object"

# Generated at 2022-06-23 14:42:29.439187
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe.__UNSAFE__


# Unit tests for AnsibleUnsafeBytes

# Generated at 2022-06-23 14:42:32.763973
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b'foo').decode(), AnsibleUnsafeText)
    assert AnsibleUnsafeBytes(b'foo').decode() == 'foo'


# Generated at 2022-06-23 14:42:37.241637
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text('string'), AnsibleUnsafeText), "Value should be a AnsibleUnsafeText"
    assert not isinstance(to_unsafe_text('string'), NativeJinjaText), "Value should not be a NativeJinjaText"

# Generated at 2022-06-23 14:42:46.568171
# Unit test for function wrap_var
def test_wrap_var():
    # Test None
    assert wrap_var(None) is None

    # Test dict
    dict_v = dict(z='z', a='a')
    assert type(wrap_var(dict_v)) is dict
    # Make sure the dict is wrapped
    assert type(wrap_var(dict_v).keys()[0]) is text_type
    # Wrap dict at higher level
    higher_dict = dict(dict_v=dict_v, dict_v2=dict_v)
    assert type(wrap_var(higher_dict)) is dict
    assert type(wrap_var(higher_dict)['dict_v']) is dict
    assert type(wrap_var(higher_dict)['dict_v2']) is dict
    # Wrap dict with other type

# Generated at 2022-06-23 14:42:57.608245
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    import types
    assert(isinstance(UnsafeProxy("ansible"), AnsibleUnsafeText))
    assert(isinstance(UnsafeProxy(AnsibleUnsafeText("ansible")), AnsibleUnsafeText))
    assert(isinstance(UnsafeProxy(u"ansible"), AnsibleUnsafeText))
    assert(isinstance(UnsafeProxy(b"ansible"), AnsibleUnsafeText))
    assert(isinstance(UnsafeProxy(AnsibleUnsafeBytes(b"ansible")), AnsibleUnsafeText))
    assert(isinstance(UnsafeProxy(types.StringType("ansible")), AnsibleUnsafeText))
    assert(isinstance(UnsafeProxy(types.UnicodeType(u"ansible")), AnsibleUnsafeText))

# Generated at 2022-06-23 14:43:00.227146
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    a = AnsibleUnsafeText("test")
    assert a == "test"
    assert isinstance(a, AnsibleUnsafeText)

    b = a.encode()
    assert b == "test"
    assert isinstance(b, AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:43:06.876715
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(u"foo"), NativeJinjaUnsafeText)
    assert isinstance(wrap_var(u"foo".encode('utf-8')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var({b"foo": b"bar"}), dict)
    assert isinstance(wrap_var({u"foo": u"bar"}), dict)
    assert isinstance(wrap_var({u"foo": u"bar"})[u"foo"], NativeJinjaUnsafeText)
    assert isinstance(wrap_var({b"foo": b"bar"})[b"foo"], AnsibleUnsafeBytes)
    assert isinstance(wrap_var([u"foo"]), list)
    assert isinstance(wrap_var([u"foo"])[0], NativeJinjaUnsafeText)

# Generated at 2022-06-23 14:43:14.550933
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy('text'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText(u'foo')), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy('hello'.encode('utf-8')), AnsibleUnsafeText)

# Generated at 2022-06-23 14:43:19.889493
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import sys
    if sys.version_info[0] == 2 and sys.version_info[1] == 6:
        # Workaround.  sys.getdefaultencoding() on python2.6 returns ascii
        # which causes problems testing to_unsafe_text 
        del sys.setdefaultencoding
        sys.getdefaultencoding = lambda: 'utf8'
    assert(isinstance(to_unsafe_text(u"hello world"), AnsibleUnsafeText))
    assert(isinstance(to_unsafe_text(b"hello world", encoding='utf8', errors='surrogate_then_replace'), AnsibleUnsafeText))
    assert(isinstance(to_unsafe_text(u"hello world", encoding='utf8', errors='surrogate_then_replace'), AnsibleUnsafeText))

# Unit test

# Generated at 2022-06-23 14:43:20.924918
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert NativeJinjaUnsafeText(u"test")

# Generated at 2022-06-23 14:43:23.500756
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    result = wrap_var('whatever').encode('utf-8')
    assert isinstance(result, AnsibleUnsafeBytes)
    assert result.__UNSAFE__


# Generated at 2022-06-23 14:43:27.869989
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(b'\xe9'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'\xe9', errors='surrogate_then_replace'), AnsibleUnsafeText)


# Generated at 2022-06-23 14:43:40.118859
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.six import binary_type, text_type
    # call the method
    result = UnsafeProxy('foo')
    assert isinstance(result, AnsibleUnsafeText)
    assert result == 'foo'

    # call the method
    result = UnsafeProxy(b'foo')
    assert isinstance(result, AnsibleUnsafeBytes)
    assert result == b'foo'

    # call the method again with a few different types
    result = UnsafeProxy([binary_type(b'foo'), text_type('foo')])
    assert isinstance(result, list)
    assert isinstance(result[0], AnsibleUnsafeBytes)
    assert isinstance(result[1], AnsibleUnsafeText)
    assert result == [b'foo', 'foo']

    # call the method again with a few different types

# Generated at 2022-06-23 14:43:44.513423
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    x = AnsibleUnsafeText("Test")
    y = x.encode("utf-8")
    assert str(y).startswith("b'Test'")
    assert str(y).endswith("utf-8'")
    assert isinstance(y, AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:43:55.734866
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    b_str = b'foo'
    assert isinstance(AnsibleUnsafeBytes(b_str), AnsibleUnsafeBytes), "b'too', AnsibleUnsafeBytes -> AnsibleUnsafeBytes"
    assert isinstance(AnsibleUnsafeBytes(b_str), binary_type), "b'too', AnsibleUnsafeBytes -> binary_type"
    assert isinstance(AnsibleUnsafeBytes(b_str), AnsibleUnsafe), "b'too', AnsibleUnsafeBytes -> AnsibleUnsafe"
    b_str = 'foo'
    assert isinstance(AnsibleUnsafeBytes(b_str), AnsibleUnsafeBytes), "'foo', AnsibleUnsafeBytes -> AnsibleUnsafeBytes"

# Generated at 2022-06-23 14:44:01.294019
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # Test case: Unicode string is converted and wrapped
    assert type(AnsibleUnsafeBytes(b"str").decode()) is AnsibleUnsafeText
    # Test case: Decoding of Unicode to Binary string is passed through
    assert type(AnsibleUnsafeBytes(b"str").decode('utf-8')) is AnsibleUnsafeBytes


# Generated at 2022-06-23 14:44:04.709238
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # Create an AnsibleUnsafeBytes object
    bytes_text = AnsibleUnsafeBytes('testing')

    # Validate type of object
    assert isinstance(bytes_text, AnsibleUnsafeBytes)
    assert isinstance(bytes_text, binary_type)

# Generated at 2022-06-23 14:44:06.449382
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    if isinstance('', AnsibleUnsafe):
        print('test_AnsibleUnsafeText: Passed')

# Generated at 2022-06-23 14:44:07.675497
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    unsafe = AnsibleUnsafeText(u'foobar')
    assert unsafe.__UNSAFE__

# Generated at 2022-06-23 14:44:14.364652
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    import pytest
    b = AnsibleUnsafeBytes(b'Hello')
    assert(isinstance(b, binary_type))
    assert(b.__UNSAFE__ is True)
    assert(b == b'Hello')
    assert(isinstance(b.decode('utf-8'), AnsibleUnsafeText))
    assert(b.decode('utf-8') == 'Hello')
    assert(b.decode('utf-8').encode('utf-8') == b)
    with pytest.raises(AttributeError):
        b.UNSAFE


# Generated at 2022-06-23 14:44:22.194047
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    """ Ensure that the method decode of class AnsibleUnsafeBytes will return a AnsibleUnsafeText
    """
    b_str = b"String to be decoded"
    ans_unsafe_str = AnsibleUnsafeBytes(b_str)
    decoded_str = ans_unsafe_str.decode()
    assert isinstance(decoded_str, AnsibleUnsafeText) and decoded_str == u"String to be decoded"

# Generated at 2022-06-23 14:44:33.468146
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3

    assert wrap_var(AnsibleUnsafeBytes('unsafe byte string')) == AnsibleUnsafeBytes('unsafe byte string')
    assert wrap_var(AnsibleUnsafeText('unsafe unicode string')) == AnsibleUnsafeText('unsafe unicode string')
    assert wrap_var('safe unicode string') == 'safe unicode string'

    if PY3:
        assert wrap_var(b'safe byte string') == AnsibleUnsafeBytes(b'safe byte string')
        assert wrap_var('safe unicode string'.encode('utf-8')) == AnsibleUnsafeBytes('safe unicode string'.encode('utf-8'))
    else:
        assert wrap_var(b'safe byte string') == b'safe byte string'

# Generated at 2022-06-23 14:44:35.666119
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    string = 'Test String'
    ut = AnsibleUnsafeText(string)
    assert ut.encode() == string.encode()

# Generated at 2022-06-23 14:44:40.752901
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert type(UnsafeProxy('test')) is AnsibleUnsafeText
    assert type(UnsafeProxy(u'test')) is AnsibleUnsafeText
    assert type(UnsafeProxy(b'test')) is AnsibleUnsafeBytes
    assert UnsafeProxy(u'test').__UNSAFE__
    assert UnsafeProxy(b'test').__UNSAFE__



# Generated at 2022-06-23 14:44:43.430179
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    s = NativeJinjaUnsafeText(u'You are either a god that can protect me or a shit ...')


# Generated at 2022-06-23 14:44:52.640362
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    def test_wrap_var(v):
        if isinstance(v, string_types):
            v = AnsibleUnsafeText(to_text(v, errors='surrogate_or_strict'))
        return v
    res = test_wrap_var(AnsibleUnsafeBytes().decode())
    assert res.__UNSAFE__ == True
    res = test_wrap_var(AnsibleUnsafeBytes().decode(encoding='utf-8'))
    assert res.__UNSAFE__ == True
    res = test_wrap_var(AnsibleUnsafeBytes().decode(encoding='utf-8', errors='strict'))
    assert res.__UNSAFE__ == True



# Generated at 2022-06-23 14:45:01.926252
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.display import Display
    Display.deprecated = DummyDisplay

# Generated at 2022-06-23 14:45:04.801039
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    bytes_obj = AnsibleUnsafeBytes(b'foo')
    text_obj = bytes_obj.decode()
    assert isinstance(text_obj, AnsibleUnsafeText)
    assert text_obj == u'foo'
    assert isinstance(bytes_obj, AnsibleUnsafe)


# Generated at 2022-06-23 14:45:13.916415
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text('str'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text('str', errors='surrogate_or_strict'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'str', errors='surrogate_or_strict'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(None), type(None))
    assert isinstance(to_unsafe_text(1), type(1))
    assert isinstance(to_unsafe_text(1.0), type(1.0))
    assert isinstance(to_unsafe_text({'key': 'val'}), dict)
    assert isinstance(to_unsafe_text([1, 2, 3]), list)

# Generated at 2022-06-23 14:45:20.753431
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.utils.display import Display
    try:
        UnsafeProxy("foo")
    except DeprecationWarning:
        pass
    else:
        assert False, "The first call to UnsafeProxy should raise a deprecation warning"

    try:
        UnsafeProxy("foo")
    except DeprecationWarning:
        pass
    else:
        assert False, "The second call to UnsafeProxy should raise a deprecation warning"

# Generated at 2022-06-23 14:45:25.840828
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    from ansible.module_utils.six import PY3

    if PY3:
        assert isinstance(AnsibleUnsafeText('Foo').encode(), AnsibleUnsafeBytes)
    else:
        assert isinstance(AnsibleUnsafeText('Foo'), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:45:29.945750
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert str(UnsafeProxy('start')) == 'start'
    assert str(UnsafeProxy(True)) == 'True'
    assert str(UnsafeProxy(None)) == 'None'
    assert str(UnsafeProxy(1)) == '1'
    assert str(UnsafeProxy(1.0)) == '1.0'

# Generated at 2022-06-23 14:45:37.064580
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert UnsafeProxy(None) is None
    assert UnsafeProxy(5) == 5
    assert UnsafeProxy({"foo": "bar"}) == {"foo": "bar"}
    assert UnsafeProxy(["a", "b"]) == ["a", "b"]
    assert UnsafeProxy("{{ password }}") == "{{ password }}"
    assert isinstance(UnsafeProxy(b"foo"), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(u"foo"), AnsibleUnsafeText)



# Generated at 2022-06-23 14:45:44.567382
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    v = AnsibleUnsafeBytes('abc')
    assert not isinstance(v, AnsibleUnsafeText)
    b = v.encode()
    assert isinstance(b, AnsibleUnsafeText)
    assert b == 'abc'
    b = v.encode('utf8')
    assert isinstance(b, AnsibleUnsafeText)
    assert b == 'abc'
    b = v.encode('utf8', errors='replace')
    assert isinstance(b, AnsibleUnsafeText)
    assert b == 'abc'


# Generated at 2022-06-23 14:45:52.507417
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import unittest
    import json

    class TestJson(unittest.TestCase):
        def test_to_unsafe_text(self):
            plain_dict = {"foo": "bar"}
            unsafe_dict = {"foo": AnsibleUnsafeText("bar")}
            plain_bytes = b"{\"foo\": \"bar\"}"
            unsafe_bytes = b"{\"foo\": \"bar\"}"
            self.assertEqual(json.dumps(plain_dict), json.dumps(unsafe_dict))
            self.assertEqual(plain_bytes, unsafe_bytes)
    unittest.main()

# Generated at 2022-06-23 14:46:04.377458
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var("test") == b'test'
    assert wrap_var(b"test") == b"test"

    assert type(wrap_var("test")) == AnsibleUnsafeText
    assert type(wrap_var(b"test")) == AnsibleUnsafeBytes
    assert type(wrap_var(None)) == type(None)

    # test wrap_var with a tuple
    data = (1, b"2", 3)
    unsafe_data = wrap_var(data)
    assert type(unsafe_data) == tuple
    assert len(unsafe_data) == len(data)
    assert unsafe_data[0] == 1
    assert unsafe_data[1] == b"2"
    assert unsafe_data[2] == 3

    # test wrap_var with a list

# Generated at 2022-06-23 14:46:15.636182
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var({'a': 1, 'b': 'asd'}) == {'a': 1, 'b': 'asd'}
    assert wrap_var({'a': 1, 'b': 'asd'}) == {'a': 1, 'b': 'asd'}
    assert wrap_var({'a': 1, 'b': {'c': 2}}) == {'a': 1, 'b': {'c': 2}}
    assert wrap_var({'a': 1, 'b': ['asd', 'fgh']}) == {'a': 1, 'b': ['asd', 'fgh']}
    assert wrap_var({'a': 1, 'b': set(['asd', 'fgh'])}) == {'a': 1, 'b': set(['asd', 'fgh'])}

# Generated at 2022-06-23 14:46:18.723867
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    str1 = AnsibleUnsafeText("abc")
    str1.encode()
    str2 = AnsibleUnsafeText("čřžě")
    str2.encode()

# Generated at 2022-06-23 14:46:20.464871
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe().__UNSAFE__



# Generated at 2022-06-23 14:46:29.348805
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils._text import to_native

    # test None object
    s = None
    b = UnsafeProxy(s)
    assert b is None

    # test bytes object
    s = to_native(b'bytes object')
    b = UnsafeProxy(s)
    assert b is s

    # test text object
    s = to_native('text object')
    b = UnsafeProxy(s)
    assert type(b) is str
    assert b == s

    # test wrapped text object
    s = to_native(b'wrapped text object')
    b = UnsafeProxy(s)
    assert type(b) is str
    assert b == s

    # test list object
    s = [1, 2, 3]
    b = UnsafeProxy(s)
    assert type(b)

# Generated at 2022-06-23 14:46:33.073694
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    test_string = b'this is test string'
    test_AnsibleUnsafeBytes = AnsibleUnsafeBytes(test_string)
    assert test_AnsibleUnsafeBytes == test_string



# Generated at 2022-06-23 14:46:35.784843
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    ut = AnsibleUnsafeText(u"This is a test")
    assert isinstance(ut.encode(), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:46:44.329182
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Assert:
    import re
    #  string is not AnsibleUnsafe
    assert not isinstance('my_string', AnsibleUnsafe)
    #  UnsafeProxy is AnsibleUnsafe
    assert isinstance(UnsafeProxy('my_string'), AnsibleUnsafe)
    #  UnsafeProxy is a string
    assert isinstance(UnsafeProxy('my_string'), text_type)
    #  UnsafeProxy keeps the same string
    assert str(UnsafeProxy('my_string')) == 'my_string'
    #  UnsafeProxy has a wrap_var method
    assert hasattr(UnsafeProxy('my_string'), 'wrap_var')
    #  UnsafeProxy has a __UNSAFE__ attribute
    assert hasattr(UnsafeProxy('my_string'), '__UNSAFE__')



# Generated at 2022-06-23 14:46:46.981271
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert(str(UnsafeProxy('Hello')) == 'Hello')
    assert(str(UnsafeProxy(u'Hello')) == 'Hello')


# Generated at 2022-06-23 14:46:50.718352
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    from ansible.module_utils.six import PY3
    if PY3:
        obj = AnsibleUnsafeBytes(__name__)
    else:
        obj = AnsibleUnsafeText(__name__)
    assert isinstance(obj, AnsibleUnsafe)

# Generated at 2022-06-23 14:46:53.898438
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert str('abc') == AnsibleUnsafeText('abc')


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 14:47:05.048006
# Unit test for function wrap_var
def test_wrap_var():
    assert not isinstance(None, AnsibleUnsafe)
    # Test type conversions
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(AnsibleUnsafeText(u'bar')), AnsibleUnsafeText)

    # Test safe path for text types
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'☃'), AnsibleUnsafeText)
    assert isinstance(wrap_var(str(b'foo')), AnsibleUnsafeText)
    assert isinstance(wrap_var(str(b'\xe2\x98\x83')), AnsibleUnsafeText)

    # Test

# Generated at 2022-06-23 14:47:07.959232
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert UnsafeProxy('string') == to_text('string')
    assert UnsafeProxy(to_text('string')) == to_text('string')

# Generated at 2022-06-23 14:47:11.039422
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    unsafe_text = AnsibleUnsafeText('foo')
    assert isinstance(unsafe_text.encode(), AnsibleUnsafeBytes)
    assert isinstance(unsafe_text.encode('utf-8'), AnsibleUnsafeBytes)
    assert isinstance(unsafe_text.encode('utf-8', 'strict'), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:47:12.678704
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe().__UNSAFE__ == True


# Generated at 2022-06-23 14:47:16.283920
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # Unicode
    v = AnsibleUnsafeText(u'\u00a2')

    # Bytes
    v = AnsibleUnsafeBytes(b'\xc3\x91')


# Generated at 2022-06-23 14:47:27.704149
# Unit test for constructor of class AnsibleUnsafeBytes

# Generated at 2022-06-23 14:47:30.840113
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    s = "\xc3\xa9 \xc3\xa3 \xc3\xa7"
    assert to_unsafe_bytes(s) == s.encode('utf-8')



# Generated at 2022-06-23 14:47:33.972134
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    test_str = "test"
    native_jinja_unsafe_text = NativeJinjaUnsafeText(test_str)
    assert native_jinja_unsafe_text is not None

# Generated at 2022-06-23 14:47:45.209433
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    def _test(given, expected):

        assert to_unsafe_text(given) == expected

        # for jinja
        assert to_text(to_unsafe_text(given)) == to_text(expected)

    _test('a', u'a')
    _test('你好', u'你好')
    _test(NativeJinjaText(u'你好'), NativeJinjaUnsafeText(u'你好'))
    _test('a\x01', u'a\x01')
    _test('a\x01', u'a\x01')
    _test(u'a\x01', u'a\x01')
    _test(b'a\x01', u'a\x01')

# Generated at 2022-06-23 14:47:55.241704
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.module_utils.six import PY3

    assert isinstance(to_unsafe_text(None), type(None))
    assert isinstance(to_unsafe_text('simple string'), type('simple string'))
    assert isinstance(to_unsafe_text(NativeJinjaText('jinja string')),
                      type('jinja string'))
    if PY3:
        assert isinstance(to_unsafe_text(b'bytes string'), type('bytes string'))
    else:
        assert isinstance(to_unsafe_text(b'bytes string'), type(u'bytes string'))

# Generated at 2022-06-23 14:48:07.221407
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    class Foo:
        pass
    foo = Foo()
    foo.bar = []
    foo.bar.append("one")
    foo.bar.append("two")

    foo.baz = {"a": 1, "b": 2}

    foo.bar_tuple = ("tuple_one", "tuple_two")

    foo_proxy = UnsafeProxy(foo)

    assert isinstance(foo_proxy.bar, list)
    assert isinstance(foo_proxy.bar[0], AnsibleUnsafeText)
    assert isinstance(foo_proxy.bar[1], AnsibleUnsafeText)

    assert isinstance(foo_proxy.baz, dict)
    assert isinstance(foo_proxy.baz["a"], AnsibleUnsafeText)