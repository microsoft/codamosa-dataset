

# Generated at 2022-06-23 14:38:06.886135
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    test_str = b"bytes_test_str"
    unsafe_bytes = AnsibleUnsafeBytes(test_str)
    assert unsafe_bytes.__str__() == test_str
    # Test for conversion to text
    assert unsafe_bytes.decode().__str__() == to_text(test_str)
    # Test for conversion of class itself
    assert type(unsafe_bytes.decode()) == AnsibleUnsafeText


# Generated at 2022-06-23 14:38:13.921555
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    """
    Test that invoking the encode method on an AnsibleUnsafeText instance
    results in an AnsibleUnsafeBytes instance.
    """
    unsafe_string = AnsibleUnsafeText(u'Unsafe')
    result = unsafe_string.encode('utf-8')
    assert isinstance(result, AnsibleUnsafeBytes), "encoding an unsafe string should return an unsafe byte instance"


# Generated at 2022-06-23 14:38:21.451378
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    expected_output = 'test_string'
    input1 = u'test_string'
    input2 = b'test_string'
    input3 = 'test_string'
    actual_output1 = UnsafeProxy(input1)
    assert isinstance(actual_output1, text_type)
    assert str(actual_output1) == expected_output
    actual_output2 = UnsafeProxy(input2)
    assert isinstance(actual_output2, binary_type)
    assert str(actual_output2) == expected_output
    actual_output3 = UnsafeProxy(input3)
    assert isinstance(actual_output3, binary_type)
    assert str(actual_output3) == expected_output


# Generated at 2022-06-23 14:38:24.012721
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert AnsibleUnsafeText(ansible_text) is ansible_text

ansible_text = AnsibleUnsafeText(to_text("some text"))

# Generated at 2022-06-23 14:38:25.251713
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe



# Generated at 2022-06-23 14:38:34.248372
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.safe_eval import unsafe_eval

    # Test types
    # Note: anything with __UNSAFE__ attribute is automatically wrapped as
    # AnsibleUnsafe

# Generated at 2022-06-23 14:38:40.870920
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    test_bytes = b'\x00\x01\x02\x03\x04\x05'
    ansible_unsafe_bytes = AnsibleUnsafeBytes(test_bytes)
    if ansible_unsafe_bytes != test_bytes or str(ansible_unsafe_bytes) != test_bytes or not isinstance(ansible_unsafe_bytes, AnsibleUnsafeBytes):
        raise AssertionError()

# Generated at 2022-06-23 14:38:42.777659
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes('Hello World!').decode(), AnsibleUnsafeText)


# Generated at 2022-06-23 14:38:46.767748
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.common.collections import is_sequence

    assert not isinstance(UnsafeProxy(None), AnsibleUnsafe)
    assert not is_sequence(UnsafeProxy(None))
    assert isinstance(UnsafeProxy('string'), AnsibleUnsafeText)
    assert is_sequence(UnsafeProxy('string'))



# Generated at 2022-06-23 14:38:59.410786
# Unit test for function wrap_var
def test_wrap_var():
    """Basic test to assert the behavior of wrap_var"""
    class Tmp(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y

# Generated at 2022-06-23 14:39:01.834838
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert(isinstance(to_unsafe_text('a'), AnsibleUnsafeText))
    assert(isinstance(to_unsafe_text(b'a'), AnsibleUnsafeText))
    assert(isinstance(to_unsafe_text('a'.encode()), AnsibleUnsafeText))
    assert(isinstance(to_unsafe_text(AnsibleUnsafeBytes('a'.encode())), AnsibleUnsafeText))

# Generated at 2022-06-23 14:39:11.865468
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    import unittest

    class AnsibleUnsafeBytesTest(unittest.TestCase):
        def test_AnsibleUnsafeBytes_defined(self):
            test_string = "test"
            self.assertIsInstance(test_string, string_types)
            self.assertFalse(isinstance(test_string, binary_type))
            self.assertFalse(isinstance(test_string, AnsibleUnsafeBytes))
            self.assertFalse(isinstance(test_string, AnsibleUnsafeText))

            test_bytes = b"test"
            self.assertIsInstance(test_bytes, binary_type)
            self.assertFalse(isinstance(test_bytes, AnsibleUnsafeBytes))
            self.assertFalse(isinstance(test_bytes, AnsibleUnsafeText))

            test_unsafe_bytes = AnsibleUn

# Generated at 2022-06-23 14:39:12.452936
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    AnsibleUnsafe()

# Generated at 2022-06-23 14:39:20.540685
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # Test for expected input
    data = b'some string'
    obj = AnsibleUnsafeBytes(data)
    if sys.version_info[0] == 3:
        assert isinstance(obj, AnsibleUnsafeBytes)
        assert isinstance(obj.decode(), AnsibleUnsafeText)
        assert obj.decode().startswith('some string') == True
    else:
        assert isinstance(obj, AnsibleUnsafeBytes)
        assert isinstance(obj.decode(), AnsibleUnsafeText)
        assert obj.decode().startswith(u'some string') == True


# Generated at 2022-06-23 14:39:25.370656
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils._text import to_text
    txt = to_text(b'foo')

    assert isinstance(UnsafeProxy(txt), text_type)
    assert isinstance(UnsafeProxy(txt), AnsibleUnsafe)



# Generated at 2022-06-23 14:39:30.054219
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert isinstance(UnsafeProxy('hello'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'hello'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText('hello')), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes(b'hello')), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(u'hello'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(u'hello'.encode('utf-8')), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:39:39.926133
# Unit test for method __new__ of class UnsafeProxy

# Generated at 2022-06-23 14:39:44.886161
# Unit test for function wrap_var
def test_wrap_var():
    import unittest

    class TestWrapVar(unittest.TestCase):
        def test_wrap_recursive(self):
            a = {'a': 'b'}
            l = ['a', 'b', 'c']
            d = {'a': ['b', 'c'], 'b': 'c', 'c': {'a': 'b'}}

            self.assertTrue(isinstance(wrap_var(a), dict))
            self.assertTrue(isinstance(wrap_var(l), list))
            self.assertTrue(isinstance(wrap_var(d), dict))

        def test_wrap_duplicate(self):
            a = ['a', 'b', 'a']
            l = ['a', 'b', 'c']


# Generated at 2022-06-23 14:39:49.306228
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    res = AnsibleUnsafeBytes(b'\xe3\x81\x82').decode('utf-8')
    assert isinstance(res, AnsibleUnsafeText)
    assert res == u'\u3042'


# Generated at 2022-06-23 14:39:53.856302
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # Arrange
    test_string = AnsibleUnsafeText("<>&'\"")

    # Act
    result = test_string.encode()

    # Assert
    assert result == b"<>&'\""
    assert result.__UNSAFE__


# Generated at 2022-06-23 14:40:02.087365
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    # Test str is converted to unicode
    assert isinstance(to_unsafe_bytes('string'), text_type)
    # Test int is converted to unicode
    assert isinstance(to_unsafe_bytes(123), text_type)
    # Test list of ints is converted to unicode
    assert isinstance(to_unsafe_bytes([123]), text_type)
    # Test list of strings is converted to list of unicode
    for item in to_unsafe_bytes(['string1', 'string2']):
        assert isinstance(item, text_type)
    # Test dict of strings is converted to dict of unicode
    for key, val in to_unsafe_bytes({'key1': 'val1', 'key2': 'val2'}).items():
        assert isinstance(key, text_type) and isinstance

# Generated at 2022-06-23 14:40:08.548200
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy('foo'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy('foo'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(None), type(None))
    assert isinstance(UnsafeProxy(None), type(None))
    assert isinstance(UnsafeProxy(None), type(None))
    assert isinstance(UnsafeProxy(None), type(None))



# Generated at 2022-06-23 14:40:11.064224
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText("test_string").encode(), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:40:13.482340
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    obj = NativeJinjaUnsafeText('{{ ansible_managed }}')
    assert obj.__UNSAFE__ == True


# Generated at 2022-06-23 14:40:16.097975
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('foobar') == b'foobar'


# Generated at 2022-06-23 14:40:25.842162
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.display import Display
    from collections import Mapping, Set

    display = Display()

    def _test_wrap(v, v_type):
        try:
            vv = wrap_var(v)
        except KeyboardInterrupt:
            raise
        except:
            display.error('wrap_var(%r) failed' % v)
        else:
            if isinstance(v, string_types):
                if vv is not v:
                    display.error('wrap_var(%r) did not return the original value' % v)
            elif not isinstance(vv, AnsibleUnsafe):
                display.error('wrap_var(%r) did not return an AnsibleUnsafe value' % v)

# Generated at 2022-06-23 14:40:29.313618
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('test') == b'test'
    assert isinstance(to_unsafe_bytes('test'), AnsibleUnsafeBytes)
    assert to_unsafe_bytes([b'test']) == [b'test']
    assert isinstance(to_unsafe_bytes([b'test']), AnsibleUnsafe)
    assert to_unsafe_bytes({'test': b'test'}) == {'test': b'test'}
    assert isinstance(to_unsafe_bytes({'test': b'test'}), AnsibleUnsafe)



# Generated at 2022-06-23 14:40:33.055808
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    u = AnsibleUnsafeText(to_text('this is a test', errors='surrogate_or_strict'))
    assert isinstance(u.encode(), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:40:39.005311
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # AnsibleUnsafeText should inherit from both AnsibleUnsafe and class text_type
    assert issubclass(AnsibleUnsafeText, AnsibleUnsafe) and issubclass(AnsibleUnsafeText, text_type)
    # It should be creatable with a valid constructor
    test_unsafe_text = AnsibleUnsafeText('test')
    assert test_unsafe_text == 'test'
    assert test_unsafe_text.__UNSAFE__ is True



# Generated at 2022-06-23 14:40:42.129093
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(AnsibleUnsafeText(b'caf\xc3\xa9').encode('utf8'), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:40:50.772970
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    from ansible.module_utils.six import text_type
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

    native = NativeJinjaUnsafeText("Some bytes")
    assert isinstance(native, NativeJinjaUnsafeText)

    # TODO: Remove this once we fully deprecate UnsafeProxy
    native = NativeJinjaUnsafeText("Some bytes")
    assert isinstance(native, UnsafeProxy)

    native = NativeJinjaUnsafeText(to_bytes("Some bytes"))
    assert isinstance(native, NativeJinjaUnsafeText)

    native = NativeJinjaUnsafeText(to_text("Some text"))

# Generated at 2022-06-23 14:41:00.211709
# Unit test for function wrap_var
def test_wrap_var():
    def check_unsafe(v):
        assert isinstance(v, AnsibleUnsafe)
        return v

    # noop on None
    assert wrap_var(None) is None

    assert wrap_var('string')
    assert wrap_var('unicode')
    assert check_unsafe(wrap_var(b'bytes')).startswith(b'bytes')

    assert wrap_var(Mapping)
    assert check_unsafe(wrap_var({'new': 'dict'}))
    assert check_unsafe(wrap_var(['new', 'list'])).startswith('new')
    assert check_unsafe(wrap_var(set('new set'))).startswith('new')


# Generated at 2022-06-23 14:41:11.257902
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('string') == AnsibleUnsafeText('string')
    assert to_unsafe_bytes('string', encoding=None) == AnsibleUnsafeText('string')
    assert to_unsafe_bytes(b'string') == AnsibleUnsafeBytes('string')
    assert to_unsafe_bytes(AnsibleUnsafeText('string')) == AnsibleUnsafeText('string')
    assert to_unsafe_bytes(AnsibleUnsafeBytes('string')) == AnsibleUnsafeBytes('string')
    assert to_unsafe_bytes(None) is None
    assert to_unsafe_bytes(AnsibleUnsafeText(None)) is None
    assert to_unsafe_bytes(AnsibleUnsafeBytes(None)) is None

# Generated at 2022-06-23 14:41:13.345805
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    obj = AnsibleUnsafeText('safe')
    assert obj == 'safe'


# Generated at 2022-06-23 14:41:15.081910
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes(b'unsafe') == \
        b'unsafe'



# Generated at 2022-06-23 14:41:23.909238
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils._text import to_text

    for val in [b'hello', u'hello', b'\xe9', BytesIO(b'hello')]:
        assert isinstance(to_unsafe_text(val), AnsibleUnsafeText)

    # ensure a string is returned in the same type
    assert isinstance(to_unsafe_text(b'hello'), binary_type)
    assert isinstance(to_unsafe_text(u'hello'), text_type)

# Generated at 2022-06-23 14:41:35.681919
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # pylint: disable=missing-function-docstring
    import io

    assert isinstance(AnsibleUnsafeText(u""), AnsibleUnsafe)
    assert isinstance(AnsibleUnsafeText(''), AnsibleUnsafe)
    assert isinstance(AnsibleUnsafeText(u"abc"), AnsibleUnsafe)
    assert isinstance(AnsibleUnsafeText('abc'), AnsibleUnsafe)
    assert isinstance(AnsibleUnsafeText(u"123"), AnsibleUnsafe)
    assert isinstance(AnsibleUnsafeText('123'), AnsibleUnsafe)

    # Test utf8 encoding
    assert isinstance(AnsibleUnsafeText(u"123".encode('utf8')), AnsibleUnsafe)

# Generated at 2022-06-23 14:41:39.487151
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import u
    test_string = u('test_string')
    unsafe_proxy = UnsafeProxy(test_string)
    assert unsafe_proxy.__class__.__name__ == 'AnsibleUnsafeString'
    assert unsafe_proxy == u('test_string')



# Generated at 2022-06-23 14:41:51.813316
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    from ansible.utils.display import Display
    display = Display()

    param = AnsibleUnsafeBytes(to_bytes("test", errors='surrogate_or_strict'))
    assert isinstance(param, AnsibleUnsafeBytes), 'Expected type %s, got %s' % (AnsibleUnsafeBytes, type(param))
    assert isinstance(param, binary_type), 'Expected type %s, got %s' % (binary_type, type(param))
    assert isinstance(param, AnsibleUnsafe), 'Expected type %s, got %s' % (AnsibleUnsafe, type(param))

    param = to_unsafe_bytes("test", errors='surrogate_or_strict')

# Generated at 2022-06-23 14:41:54.383095
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    bytes = "This is test".encode()
    ans = AnsibleUnsafeBytes(bytes)
    assert ans.decode() == "This is test"



# Generated at 2022-06-23 14:41:55.775822
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    ans = AnsibleUnsafe()
    assert(ans.__UNSAFE__ == True)

# Generated at 2022-06-23 14:42:03.486226
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    a = AnsibleUnsafeText("hello")
    b = AnsibleUnsafeBytes("hello")
    assert a.__class__.__name__ == "AnsibleUnsafeText"
    assert b.__class__.__name__ == "AnsibleUnsafeBytes"
    assert isinstance(a, AnsibleUnsafe)
    assert isinstance(b, AnsibleUnsafe)
    assert "__UNSAFE__" in dir(a)
    assert "__UNSAFE__" in dir(b)
    assert a == "hello"
    assert type(a) == type("")
    assert b == b"hello"
    assert type(b) == type(b"")
    assert a.encode() == b"hello"
    assert b.decode() == "hello"


# Generated at 2022-06-23 14:42:15.000010
# Unit test for function wrap_var
def test_wrap_var():
    # Strings should be wrapped as unsafe text
    assert isinstance(wrap_var(u'foobar'), AnsibleUnsafeText)
    # Wrapped strings should still be strings
    assert isinstance(wrap_var(u'foobar'), text_type)
    # Strings should be left alone when already wrapped
    assert isinstance(wrap_var(wrap_var(u'foobar')), AnsibleUnsafeText)
    # Sequence items should be wrapped
    assert isinstance(wrap_var([u'foobar'])[0], AnsibleUnsafeText)
    # Dict keys and values should be wrapped
    assert isinstance(wrap_var({u'foobar': u'baz'}).get(u'foobar'), AnsibleUnsafeText)
    # Dict keys and values should be wrapped when already wrapped

# Generated at 2022-06-23 14:42:19.939507
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # Test for AnsibleUnsafeBytes.decode
    v = AnsibleUnsafeBytes('foo')
    assert v.decode('utf-8') == u'foo'

    v = AnsibleUnsafeBytes('á')
    assert v.decode('utf-8') == u'á'



# Generated at 2022-06-23 14:42:31.215006
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    input1 = b'abcdefg'
    input2 = b'abcdefg'
    input3 = 'abcdefg'
    input4 = AnsibleUnsafeText('abcdefg')
    input5 = b'abcdefg'
    input6 = 'abcdefg'
    input7 = 'abcdefg'
    input8 = AnsibleUnsafeText('abcdefg')
    output = AnsibleUnsafeText('abcdefg')
    assert AnsibleUnsafeBytes(input1).decode() == output
    assert AnsibleUnsafeBytes(input2).decode('ascii') == output
    assert AnsibleUnsafeBytes(input3).decode('ascii') == output
    assert AnsibleUnsafeBytes(input4).decode('ascii') == output
    assert AnsibleUnsafeBytes(input5).dec

# Generated at 2022-06-23 14:42:39.224519
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    # test None
    assert to_unsafe_bytes(None) is None

    # test normal str
    assert isinstance(to_unsafe_bytes("test"), binary_type)
    assert to_unsafe_bytes("test") == b'test'

    # test bytes
    assert issubclass(type(to_unsafe_bytes(b"test")), AnsibleUnsafe)
    assert to_unsafe_bytes(to_bytes(b"test")) == b'test'

    # test unicode
    assert issubclass(type(to_unsafe_bytes(u"test")), AnsibleUnsafe)
    assert to_unsafe_bytes(to_bytes(u"test")) == b'test'

    # test int
    with pytest.raises(TypeError):
        to_unsafe_bytes(3)

   

# Generated at 2022-06-23 14:42:47.478455
# Unit test for function wrap_var
def test_wrap_var():
    from .common.constants import (
        COMPLEX_FIXTURE,
        COMPLEX_FIXTURE_UNSAFE_BYTES,
        COMPLEX_FIXTURE_UNSAFE_TEXT,
        SIMPLE_FIXTURE,
        SIMPLE_FIXTURE_UNSAFE_BYTES,
        SIMPLE_FIXTURE_UNSAFE_TEXT,
        UNSAFE_FIXTURE,
    )
    from .common.unit.utils import TEST_DATA_DIR
    import os
    import yaml

    path = os.path.join(TEST_DATA_DIR, 'module_util_22_wrap_var_fixtures.yaml')
    with open(path) as f:
        fixtures = yaml.safe_load(f)

    # complex

# Generated at 2022-06-23 14:42:51.818773
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafeBytes("test") == b"test"
    assert AnsibleUnsafeText("test") == "test"
    assert isinstance(AnsibleUnsafeText("test"), AnsibleUnsafe)



# Generated at 2022-06-23 14:42:54.798708
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    a = AnsibleUnsafeBytes("this is a test")
    assert isinstance(a, AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:42:56.996459
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    a = AnsibleUnsafe()
    assert hasattr(a, '__UNSAFE__') == True


# Generated at 2022-06-23 14:43:08.481132
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes(bytearray(b'h\x65llo')), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(123), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes('h\x65llo'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes('"h\x65llo"', errors='surrogate_or_strict'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(['h\x65llo', 123, text_type('h\x65llo')]), list)
    assert isinstance(to_unsafe_bytes('[h\x65llo, 123, "h\x65llo"]', errors='surrogate_or_strict'), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:43:18.908035
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():

    # A string which is not safe, it contains '$'
    unsafe_string = "ansibleUnsafe"
    safe_string = "ansibleSafe"
    unsafe_string_safe = "ansibleUnsafeSafe"

    # Check that a string is not safe
    assert(not isinstance(UnsafeProxy(unsafe_string), AnsibleUnsafe))

    # Check that a safe string is not converted as unsafe
    assert(not isinstance(UnsafeProxy(safe_string), AnsibleUnsafe))

    # Check that a string which is both safe and unsafe is not converted as safe
    assert(not isinstance(UnsafeProxy(unsafe_string_safe), AnsibleUnsafe))



# Generated at 2022-06-23 14:43:28.117425
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('foo') == b'foo'
    assert to_unsafe_bytes(u'foo') == b'foo'
    assert to_unsafe_bytes('foo', encoding='utf-8') == b'foo'
    assert to_unsafe_bytes(u'foo', encoding='utf-8') == b'foo'
    assert to_unsafe_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', encoding='utf-8') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

# Generated at 2022-06-23 14:43:31.576073
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    test_string="test"
    test_AnsibleUnsafeText_encode=AnsibleUnsafeText(test_string)
    assert (test_AnsibleUnsafeText_encode.encode()==b"test")

# Generated at 2022-06-23 14:43:32.829690
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    val = NativeJinjaUnsafeText('Test1')
    assert(val.__class__.__name__ == 'NativeJinjaUnsafeText')

# Generated at 2022-06-23 14:43:40.315877
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    literal = 'hello'
    assert AnsibleUnsafeText(literal).__UNSAFE__ == True
    assert AnsibleUnsafeBytes(literal).__UNSAFE__ == True
    assert NativeJinjaUnsafeText(literal).__UNSAFE__ == True
    assert NativeJinjaUnsafeText(literal).__UNSAFE__ == True

# Unit test wrap_var with raw literal

# Generated at 2022-06-23 14:43:43.292386
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert str(type(AnsibleUnsafeText('str').encode())) == "<class 'ansible.module_utils.basic.AnsibleUnsafeBytes'>"


# Generated at 2022-06-23 14:43:45.940217
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    a=AnsibleUnsafe()
    try:
        assert a
    except AssertionError as e:
        print(e)

# Generated at 2022-06-23 14:43:52.902062
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy(None) is None
    assert UnsafeProxy(True) is True
    assert UnsafeProxy(False) is False
    assert UnsafeProxy(0) == 0
    assert UnsafeProxy({}) == {}
    assert UnsafeProxy([]) == []
    assert UnsafeProxy(()) == ()
    assert UnsafeProxy(u'unicode') == u'unicode'
    assert UnsafeProxy(b'byte') == b'byte'



# Generated at 2022-06-23 14:43:55.872152
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    ansible_unsafe_bytes = AnsibleUnsafeBytes(b'Hello World')
    assert isinstance(ansible_unsafe_bytes.decode(), AnsibleUnsafeText)



# Generated at 2022-06-23 14:44:06.450774
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    string = b'bytes'
    res = UnsafeProxy(string)
    assert type(res) == AnsibleUnsafeBytes
    assert res == b'bytes'

    res = UnsafeProxy(to_text(string, errors='surrogate_or_strict'))
    assert type(res) == AnsibleUnsafeText
    assert res == u'bytes'

    long_string = 'b' * 2000
    res = UnsafeProxy(long_string)
    assert type(res) == AnsibleUnsafeText
    assert res == u'b' * 2000

    # test no change
    res = UnsafeProxy(res)
    assert type(res) == AnsibleUnsafeText
    assert res == u'b' * 2000

    # test empty
    res = UnsafeProxy('')
    assert type(res) == Ansible

# Generated at 2022-06-23 14:44:07.930218
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    text = NativeJinjaUnsafeText("plain text")
    assert text == "plain text"

# Generated at 2022-06-23 14:44:11.338801
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    s = {"k1": "v1", "k2": ["v2", "v3"]}
    s_u = to_unsafe_text(s)
    assert s_u["k1"] == u"v1"
    assert s_u["k2"][0] == u"v2"

# Generated at 2022-06-23 14:44:13.295411
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes(b''), AnsibleUnsafe)


# Generated at 2022-06-23 14:44:24.992531
# Unit test for function wrap_var
def test_wrap_var():
    import pytest
    v1 = {"foo": "bar", "ns": {"baz": "qux"}}
    v2 = [{"foo": "bar", "ns": {"baz": "qux"}}]
    v3 = ["foo", "bar", {"foo": "bar", "ns": {"baz": "qux"}}]
    v4 = {"foo": ["bar", "baz"]}
    v5 = "foo"
    v6 = AnsibleUnsafeBytes(u'foo')
    v7 = AnsibleUnsafeText(u'foo')
    v8 = object()
    v9 = AnsibleUnsafeBytes(u'foo')
    v10 = NativeJinjaText(u'foo')

    assert isinstance(wrap_var(v1), dict)

# Generated at 2022-06-23 14:44:30.323031
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    s = 'this is a string'
    ubs = to_bytes(s)
    tbs = to_unsafe_bytes(s)
    assert type(ubs) == binary_type
    assert type(tbs) == AnsibleUnsafeBytes
    assert s == ubs


# Generated at 2022-06-23 14:44:32.206974
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    unsafe_text_obj = AnsibleUnsafeText("This is a test")
    safe_bytes_obj = unsafe_text_obj.encode("ascii")
    assert isinstance(safe_bytes_obj, AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:44:37.249496
# Unit test for function wrap_var
def test_wrap_var():
    test_dict = {'key1': 'value1',
                 'key2': ['subkey1', 'subkey2']}

    test_list = ['value1', 'value2']

    assert isinstance(wrap_var(test_dict), dict)
    assert isinstance(wrap_var(test_list), list)
    assert isinstance(wrap_var('test')[0], AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:44:39.863770
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    testNativeJinjaText = NativeJinjaUnsafeText("testNativeJinjaUnsafeText")
    assert isinstance(testNativeJinjaText, AnsibleUnsafe)

# Generated at 2022-06-23 14:44:44.372008
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert isinstance(AnsibleUnsafeText('abc'), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeText(), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeText(123), AnsibleUnsafeText)

# Generated at 2022-06-23 14:44:47.011951
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import u

    x = UnsafeProxy(u(''))
    assert isinstance(x, AnsibleUnsafeText)



# Generated at 2022-06-23 14:44:57.140505
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    import pytest
    from ansible.utils.display import Display

# Generated at 2022-06-23 14:45:04.054759
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # These are values that should trigger __UNSAFE__
    # These tests are just ensuring the constructors work correctly
    ausb = AnsibleUnsafeBytes('Test String')
    assert isinstance(ausb, binary_type)
    assert hasattr(ausb, '__UNSAFE__')

    aus = AnsibleUnsafeText('Test String')
    assert isinstance(aus, text_type)
    assert hasattr(aus, '__UNSAFE__')


# Generated at 2022-06-23 14:45:10.358354
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text
    obj = UnsafeProxy(u'ABC')
    obj = UnsafeProxy(b'ABC')
    obj = UnsafeProxy([u'ABC', u'BCD'])
    obj = UnsafeProxy(dict(abc=to_bytes('abc')))
    basic._ANSIBLE_ARGS = []  # Just to check it doesn't cause an exception

# Generated at 2022-06-23 14:45:21.126360
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.unsafe_proxy import wrap_var
    assert True == isinstance(wrap_var(None), type(None))
    assert True == isinstance(wrap_var(True), type(True))
    assert True == isinstance(wrap_var(False), type(False))

    assert True == isinstance(wrap_var([]), list)
    assert True == isinstance(wrap_var({}), dict)
    assert True == isinstance(wrap_var(()), tuple)
    assert True == isinstance(wrap_var(set()), set)
    assert True == isinstance(wrap_var('test'), text_type)
    assert True == isinstance(wrap_var(b'\xff\xfe\xfd\xfc'), binary_type)

# Generated at 2022-06-23 14:45:23.901874
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(to_unsafe_text(b'hello').encode('utf-8'), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:45:32.045185
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # Test low case unicode
    unsafeBytes = AnsibleUnsafeBytes(b'test')
    assert isinstance(unsafeBytes, AnsibleUnsafeBytes)
    assert isinstance(unsafeBytes.decode(), AnsibleUnsafeText)

    # Test upper case unicode
    unsafeBytes = AnsibleUnsafeBytes(b'TEST')
    assert isinstance(unsafeBytes, AnsibleUnsafeBytes)
    assert isinstance(unsafeBytes.decode(), AnsibleUnsafeText)

    # Test non-ascii unicode
    unsafeBytes = AnsibleUnsafeBytes(b'\xc3\xa9')
    assert isinstance(unsafeBytes, AnsibleUnsafeBytes)
    assert isinstance(unsafeBytes.decode(), AnsibleUnsafeText)



# Generated at 2022-06-23 14:45:37.390665
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    new_jinja_unsafe_text = NativeJinjaUnsafeText("<test>")

    assert new_jinja_unsafe_text == "<test>"
    assert isinstance(new_jinja_unsafe_text, ansible.utils.native_jinja.NativeJinjaText)
    assert isinstance(new_jinja_unsafe_text, AnsibleUnsafeText)

# Generated at 2022-06-23 14:45:47.767458
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    ansible_unsafe=AnsibleUnsafeBytes(b"test")
    assert True == isinstance(ansible_unsafe, binary_type), "AnsibleUnsafeBytes is not a binary_type"
    assert True == isinstance(ansible_unsafe, AnsibleUnsafe), "AnsibleUnsafeBytes is not a AnsibleUnsafe"
    assert b"test" == ansible_unsafe, "AnsibleUnsafeBytes(b\"test\") == " + str(ansible_unsafe)
    assert True == isinstance(ansible_unsafe.decode(), AnsibleUnsafeText), "AnsibleUnsafeBytes.decode() is not a AnsibleUnsafeText"

# Generated at 2022-06-23 14:46:01.296912
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(10), type(10))
    wrapped = wrap_var('foo')
    assert isinstance(wrapped, AnsibleUnsafeText)
    assert wrapped == 'foo'
    wrapped = wrap_var(u'foo')
    assert isinstance(wrapped, AnsibleUnsafeText)
    assert wrapped == 'foo'
    assert isinstance(wrap_var(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    wrapped = wrap_var(NativeJinjaText('foo'))
    assert isinstance(wrapped, NativeJinjaUnsafeText)
    assert wrapped == 'foo'
    wrapped = wrap_var(NativeJinjaUnsafeText('foo'))

# Generated at 2022-06-23 14:46:05.809312
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    tests = [
        'Test',
        u'Test',
        AnsibleUnsafeText('Test')
    ]

    for test in tests:
        assert isinstance(test.encode('utf-8'), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:46:11.154164
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    t = AnsibleUnsafeText(u"Some text")
    assert(isinstance(t, text_type))
    assert(isinstance(t, AnsibleUnsafe))
    assert(isinstance(t.encode("ascii"), AnsibleUnsafeBytes))
    assert(t.encode("ascii") == b"Some text")


# Generated at 2022-06-23 14:46:17.332975
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # Construct a binary string with ansible unsafe bytes
    ans_unsafe_bytes = AnsibleUnsafeBytes(b"testing")
    assert isinstance(ans_unsafe_bytes, binary_type), \
        "ans_unsafe_bytes is not a binary_type"
    assert isinstance(ans_unsafe_bytes, AnsibleUnsafe), \
        "ans_unsafe_bytes is not an instance of AnsibleUnsafe"



# Generated at 2022-06-23 14:46:20.083132
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    a = AnsibleUnsafeText('text')
    assert a.encode('ascii') == AnsibleUnsafeText(u'text').encode('ascii')



# Generated at 2022-06-23 14:46:24.397595
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    u = AnsibleUnsafeBytes("b'\xb0\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'")
    assert u.__class__ == AnsibleUnsafeBytes
    u = u.decode()
    assert u.__class__ == AnsibleUnsafeText


# Generated at 2022-06-23 14:46:32.039001
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    # Create instance of NativeJinjaUnsafeText
    unsafe_text = NativeJinjaUnsafeText('test')
    # Assert that instance has the proper attributes
    assert unsafe_text.__class__.__name__ == 'NativeJinjaUnsafeText'
    assert unsafe_text.__class__.__mro__[1].__name__ == 'NativeJinjaText'
    assert unsafe_text.__class__.__mro__[2].__name__ == 'AnsibleUnsafeText'
    assert unsafe_text.__class__.__mro__[3].__name__ == 'str'
    assert unsafe_text.__class__.__mro__[4].__name__ == 'object'
    assert getattr(unsafe_text, '__UNSAFE__', False) == True

# Generated at 2022-06-23 14:46:42.760380
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    import logging
    import types

    logging.basicConfig(level=logging.WARNING)
    logger = logging.getLogger(__name__)

    logger.debug('Running method test_AnsibleUnsafeBytes_decode')

    ansible_unsafe_bytes_1 = AnsibleUnsafeBytes(b'unsafe text')
    assert isinstance(ansible_unsafe_bytes_1, AnsibleUnsafeBytes)

    ansible_unsafe_text_1 = ansible_unsafe_bytes_1.decode()
    assert isinstance(ansible_unsafe_text_1, AnsibleUnsafeText)

    ansible_unsafe_bytes_2 = ansible_unsafe_text_1.encode()
    assert isinstance(ansible_unsafe_bytes_2, AnsibleUnsafeBytes)

    ansible

# Generated at 2022-06-23 14:46:52.283468
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text

    utf8_byte_string = '\xe2\x9c\x93'
    utf16_native_string = u'\u2713'

    # Convert text string to bytes
    b = to_bytes(utf16_native_string)
    assert isinstance(b, bytes)
    assert b == utf8_byte_string

    # Convert text string to unsafe bytes
    b = to_unsafe_bytes(utf16_native_string)
    assert isinstance(b, AnsibleUnsafeBytes)
    if PY3:
        # unchanged from original as we need a byte string type
        assert b == utf16_native_string

# Generated at 2022-06-23 14:46:55.542761
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    var="""{{ a }}"""
    var=NativeJinjaUnsafeText(var)
    assert isinstance(var, NativeJinjaUnsafeText)
    assert isinstance(var, text_type)

# Generated at 2022-06-23 14:46:59.261291
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert(isinstance(AnsibleUnsafeBytes(""), AnsibleUnsafeBytes))
    assert(isinstance(AnsibleUnsafeBytes(""), AnsibleUnsafe))


# Generated at 2022-06-23 14:47:07.749812
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.six import PY3

    assert isinstance(to_unsafe_text(None), type(None))
    assert isinstance(to_unsafe_text(''), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b''), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text('foo'), AnsibleUnsafeText)
    if PY3:
        assert isinstance(to_unsafe_text(b'foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(123), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(123.45), AnsibleUnsafeText)

# Generated at 2022-06-23 14:47:08.534948
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert 'str' == AnsibleUnsafeBytes('str').decode()


# Generated at 2022-06-23 14:47:14.680449
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('str') == to_text('str')
    assert wrap_var('str') == to_unsafe_text('str')
    # AnsibleUnsafeText(wrap_var('str')) == AnsibleUnsafeText(wrap_var('str'))
    assert wrap_var(u'unicode') == to_text(u'unicode')
    assert wrap_var(u'unicode') == to_unsafe_text(u'unicode')
    assert wrap_var(u'unicode') != to_text('unicode')
    assert wrap_var(u'unicode') != to_unsafe_text('unicode')
    assert wrap_var(u'unicode') == AnsibleUnsafeText(u'unicode')

# Generated at 2022-06-23 14:47:17.191725
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes(b'\xff') == b'\xff'


# Generated at 2022-06-23 14:47:20.693088
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert(isinstance(AnsibleUnsafeBytes(b'a'), AnsibleUnsafeBytes))
    assert(isinstance(AnsibleUnsafeBytes(b'a').__UNSAFE__, bool))


# Generated at 2022-06-23 14:47:30.486885
# Unit test for function wrap_var
def test_wrap_var():
    import json
    import six

    # Test wrapping of various types
    tests = [
        # name, input value, expected output value
        ('None', None, None),
        ('int', 5, 5),
        ('dict', {'a': 1, 'b': 2}, {'a': 1, 'b': 2}),
        ('unicode', u'\u1234', u'\u1234'),  # python2.x specific
        ('byte string', b"\x00\x01\x02\x03", b"\x00\x01\x02\x03"),
        ('list', [1, 2, 3], [1, 2, 3]),
        ('empty byte string', b'', b''),
        ('empty unicode string', u'', u''),
    ]


# Generated at 2022-06-23 14:47:34.788447
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    import jinja2

    tpl = jinja2.Template('{{ a }}')
    assert tpl.render({'a': UnsafeProxy('foo')}) == 'foo'
    assert tpl.render({'a': AnsibleUnsafeText('bar')}) == 'bar'



# Generated at 2022-06-23 14:47:46.116988
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():

    import unittest

    class TestAnsibleUnsafe(unittest.TestCase):
        def test_AnsibleUnsafe_1(self):
            testStr = 'test'
            unsafeStr = AnsibleUnsafeText(testStr)
            orignalStr = str(unsafeStr)
            self.assertEqual(testStr, orignalStr)

        def test_AnsibleUnsafe_2(self):
            testStr = 'test'
            unsafeStr = AnsibleUnsafeText(testStr)
            newStr = str(unsafeStr) + '1'
            self.assertEqual(newStr, str(unsafeStr))

        def test_AnsibleUnsafe_3(self):
            testStr = u'test'
            unsafeStr = AnsibleUnsafeText(testStr)

# Generated at 2022-06-23 14:47:49.365525
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes('')
    assert AnsibleUnsafeBytes('\t')
    assert AnsibleUnsafeBytes('\t\t\t\t')


# Generated at 2022-06-23 14:47:55.387514
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes(None) is None
    assert to_unsafe_bytes('') == ''
    assert to_unsafe_bytes('foo') == 'foo'

    assert isinstance(to_unsafe_bytes(AnsibleUnsafeBytes('foo')), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(AnsibleUnsafeText('foo')), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:47:59.199459
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    s = AnsibleUnsafeText('中文')
    b = s.encode()
    assert isinstance(b, AnsibleUnsafeBytes)
    assert b.decode() == s


# Generated at 2022-06-23 14:48:09.321912
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    good_bytes_inputs = (
        b'test',
        b'foo1',
        bytearray(b'foo2'),
    )
    good_bytes_results = (
        AnsibleUnsafeBytes(b'test'),
        AnsibleUnsafeBytes(b'foo1'),
        AnsibleUnsafeBytes(b'foo2'),
    )
    good_text_inputs = (
        'test',
        u'test',
        'foo3',
        u'foo3',
        to_text(b'foo4'),
    )