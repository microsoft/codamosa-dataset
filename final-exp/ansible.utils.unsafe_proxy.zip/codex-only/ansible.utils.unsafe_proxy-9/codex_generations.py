

# Generated at 2022-06-23 14:38:06.545755
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    expected = b'foo'
    assert isinstance(to_unsafe_bytes(expected), AnsibleUnsafeBytes) is True
    assert to_unsafe_bytes(expected) == expected

    expected = 'foo'
    assert isinstance(to_unsafe_bytes(expected), AnsibleUnsafeBytes) is True
    assert to_unsafe_bytes(expected) == to_bytes(expected)

# Generated at 2022-06-23 14:38:18.249104
# Unit test for function wrap_var
def test_wrap_var():
    assert(wrap_var(None) == None)
    assert(wrap_var(False) == False)
    assert(wrap_var('a') == to_unsafe_text('a'))
    assert(wrap_var(b'a') == to_unsafe_bytes('a'))
    assert(wrap_var(to_unsafe_text('a')) == to_unsafe_text('a'))
    assert(wrap_var(to_unsafe_bytes('a')) == to_unsafe_bytes('a'))
    assert(wrap_var(['a', 'b']) == ['a', 'b'])
    assert(wrap_var(('a', 'b')) == ('a', 'b'))
    assert(wrap_var({'a': 'b'}) == {'a': 'b'})
   

# Generated at 2022-06-23 14:38:19.884911
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    s = AnsibleUnsafeText('abc')
    assert(s.__UNSAFE__ == True)

# Generated at 2022-06-23 14:38:30.589481
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    from ansible.module_utils.six import b, PY3
    if PY3:
        assert isinstance(AnsibleUnsafeBytes(b('abcd')), AnsibleUnsafeText)
    else:
        assert isinstance(AnsibleUnsafeBytes(b('abcd')), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText(b('abcd').decode()), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeText(b('abcd').decode()), AnsibleUnsafeText)
    assert isinstance(NativeJinjaUnsafeText(b('abcd').decode()), AnsibleUnsafeBytes)
    assert isinstance(NativeJinjaUnsafeText(b('abcd').decode()), AnsibleUnsafeText)

# Generated at 2022-06-23 14:38:32.396870
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy("foo") == AnsibleUnsafeText("foo")



# Generated at 2022-06-23 14:38:44.085415
# Unit test for function wrap_var
def test_wrap_var():
    import json
    import sys
    import types
    import collections

    str_types = type(b''), type(u'')

    def check_wrap_var(expected, var):
        assert wrap_var(var) == expected
        assert wrap_var(var) is not var

    def test_wrap_var_basic_types():
        # Basic types don't need wrapping
        check_wrap_var(None, None)
        check_wrap_var(True, True)
        check_wrap_var(False, False)
        check_wrap_var(7, 7)
        check_wrap_var(3.14, 3.14)

    def test_wrap_var_str_types():
        if sys.version_info[0] == 2:
            str_types += type(None),

# Generated at 2022-06-23 14:38:48.376804
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(b"Hello World") == u"Hello World"
    assert to_unsafe_text(u"Hello World") == u"Hello World"

# Generated at 2022-06-23 14:38:57.075437
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('foo') == b'foo'
    assert isinstance(to_unsafe_bytes('foo'), AnsibleUnsafeBytes)
    assert to_unsafe_bytes(b'foo') == b'foo'
    assert isinstance(to_unsafe_bytes(b'foo'), AnsibleUnsafeBytes)
    assert to_unsafe_bytes(u'foo') == b'foo'
    assert isinstance(to_unsafe_bytes(u'foo'), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:38:58.145587
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe()

# Generated at 2022-06-23 14:39:04.295395
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy('foo'), text_type)
    assert isinstance(UnsafeProxy(b'foo'), binary_type)
    assert isinstance(UnsafeProxy(123), int)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText('foo')), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes(b'foo')), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:39:07.965646
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec={})
    module_result = dict(changed=False)

    result = UnsafeProxy(module_result)

    assert not result['changed']

# Generated at 2022-06-23 14:39:14.601607
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    from ansible.utils.display import Display
    failed = False
    try:
        unsafe_string = to_unsafe_bytes('foo')
        if not isinstance(unsafe_string, AnsibleUnsafeBytes):
            failed = True
    except ImportError:
        # We ignore import error and just assume that we don't want to
        # run the unit test
        pass

    if failed:
        raise [AssertionError, 'Unit test failed']

# Generated at 2022-06-23 14:39:21.497562
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    """Test for the to_unsafe_text function"""
    # test with unicode by default
    test_str = u'unicode string'
    new_str = to_unsafe_text(test_str)
    assert type(new_str) is AnsibleUnsafeText
    assert new_str == test_str

    # test with bytes that needs to be decoded
    test_str = b'bytes string'
    new_str = to_unsafe_text(test_str)
    assert type(new_str) is AnsibleUnsafeText
    assert new_str == to_text(test_str)

# Generated at 2022-06-23 14:39:29.234618
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    text = 'ᚠᛇᚻ᛫ᛒᛦᚦ᛫ᚠᚱᚩᚠᚢᚱ᛫ᚠᛁᚱᚪ᛫ᚷᛖᚻᚹᛦᛚᚳᚢᛗ'
    assert isinstance(AnsibleUnsafeText(text).encode('utf-8'), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:39:33.041154
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    test_string = "ABCDE".encode('utf-8')
    test_instance = AnsibleUnsafeBytes(test_string)

    assert isinstance(test_instance.decode('utf-8'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:39:44.937422
# Unit test for function wrap_var
def test_wrap_var():
    import unittest
    import sys

    if sys.version_info[0] == 2:
        class TestWrapVar(unittest.TestCase):

            def test_wrap_var_none(self):
                self.assertIsNone(wrap_var(None))

            def test_wrap_dict(self):
                d = {u'f\xf4\xf4': u'bar'}
                d_copy = {u'f\xf4\xf4': u'bar'}
                self.assertDictEqual(d, _wrap_dict(d_copy))

            def test_wrap_set(self):
                s = set([u'f\xf4\xf4', u'bar'])
                s_copy = set([u'f\xf4\xf4', u'bar'])

# Generated at 2022-06-23 14:39:56.781732
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    from ansible.module_utils._text import to_text
    val = u"Oshun's \u263b is the most powerful!"
    val_utf8 = val.encode('utf-8')
    val_unicode = to_text(val_utf8, errors='surrogate_or_strict')

    ans_unsafe_text = AnsibleUnsafeText(val)
    assert isinstance(ans_unsafe_text, AnsibleUnsafeText)
    assert isinstance(ans_unsafe_text, text_type)
    ans_unsafe_text_utf8 = ans_unsafe_text.encode('utf-8')
    ans_unsafe_text_utf8 = ans_unsafe_text_utf8.decode('utf-8')
    assert val_utf8 == ans_unsafe_text_

# Generated at 2022-06-23 14:40:03.752808
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    data = {'key1': '\x00\x01'}
    assert isinstance(data['key1'], AnsibleUnsafeBytes)
    data = {'key1': to_unsafe_text(data['key1'])}
    assert isinstance(data['key1'], AnsibleUnsafeText)
    data = {'key1': to_text(data['key1'])}
    assert isinstance(data['key1'], text_type)

# Generated at 2022-06-23 14:40:07.159907
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    my_bytes = AnsibleUnsafeBytes(b"test")
    my_str = my_bytes.decode()
    assert(isinstance(my_str, AnsibleUnsafeText))


# Generated at 2022-06-23 14:40:09.616946
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    proxy = UnsafeProxy("test string")
    assert type(proxy) is AnsibleUnsafeText
    # test_UnsafeProxy()

# Generated at 2022-06-23 14:40:13.432017
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    result = AnsibleUnsafeBytes("us-ascii", "ignore").decode("us-ascii", "ignore")
    assert isinstance(result, AnsibleUnsafeText)


# Generated at 2022-06-23 14:40:16.041255
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    n = NativeJinjaText('abc')
    j = NativeJinjaUnsafeText(n)

# Generated at 2022-06-23 14:40:25.803742
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes("utf8"), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes("utf8", "strict"), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes("utf8", "replace"), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes("utf8", "ignore"), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes("ascii", "xmlcharrefreplace"), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b"ascii"), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(u"unicode"), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:40:27.524947
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert (type(to_unsafe_bytes('test')) == AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:40:38.271750
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    try:
        object = AnsibleUnsafeText(binary_type(b"Hello World"))
    except Exception as e:
        assert False, "Construction of 'AnsibleUnsafeText' object with binary type failed: " + repr(e)

    try:
        object = AnsibleUnsafeText(text_type("Hello World"))
    except Exception as e:
        assert False, "Construction of 'AnsibleUnsafeText' object with text type failed: " + repr(e)

    try:
        object = AnsibleUnsafeText("Hello World")
    except Exception as e:
        assert False, "Construction of 'AnsibleUnsafeText' object with str type failed: " + repr(e)


# Generated at 2022-06-23 14:40:49.179016
# Unit test for function wrap_var
def test_wrap_var():
    #wrap_var should not touch immutable, safe types
    assert wrap_var(None) is None
    assert wrap_var(True) is True
    assert wrap_var(1) == 1
    assert wrap_var(1.0) == 1.0
    assert wrap_var(set([1, 2, 3])) == set([1, 2, 3])

    #wrap_var should wrap strings and sequences
    assert isinstance(wrap_var(""), AnsibleUnsafeText)
    assert isinstance(wrap_var(b""), AnsibleUnsafeBytes)
    assert isinstance(wrap_var([1, 2, 3]), AnsibleUnsafe)
    assert isinstance(wrap_var((1, 2, 3)), AnsibleUnsafe)

# Generated at 2022-06-23 14:40:53.224426
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    test_string = u'This is a test string'
    test_UnsafeText = AnsibleUnsafeText(test_string)
    if test_UnsafeText.__UNSAFE__:
        print('UnsafeText constructor is working')
    else:
        print('UnsafeText constructor is NOT working')


# Generated at 2022-06-23 14:40:54.985072
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    a = AnsibleUnsafeText(u"foo")
    assert a.__UNSAFE__

# Generated at 2022-06-23 14:40:58.397104
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    byte_str = AnsibleUnsafeBytes('python')
    ansible_str = byte_str.decode('utf-8')
    assert type(ansible_str) is AnsibleUnsafeText
    assert ansible_str == 'python'



# Generated at 2022-06-23 14:41:09.498914
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():

    # dict with unsafe bytes should be wrapped with unsafe bytes
    test_dict = {u'hello': u'world'}
    test_dict_with_unsafe = _wrap_dict(test_dict)
    assert isinstance(test_dict_with_unsafe[u'hello'], AnsibleUnsafeBytes)

    # tuple with unsafe bytes should be wrapped with unsafe bytes
    test_tuple = (u'hello', u'world')
    test_tuple_with_unsafe = _wrap_sequence(test_tuple)
    assert isinstance(test_tuple_with_unsafe[0], AnsibleUnsafeBytes)

    # set with unsafe bytes should be wrapped with unsafe bytes
    # set is an unordered collection so the randomness of set is not predictable
    # only check the type of the elements
    test_set = set()


# Generated at 2022-06-23 14:41:15.904217
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes(None) == wrap_var(None)
    assert to_unsafe_bytes(42) == wrap_var(42)
    assert to_unsafe_bytes(42.0) == wrap_var(42.0)
    assert to_unsafe_bytes([]) == wrap_var([])
    assert to_unsafe_bytes([1, 2, 3]) == wrap_var([1, 2, 3])
    assert to_unsafe_bytes((1, 2, 3)) == wrap_var((1, 2, 3))
    assert to_unsafe_bytes({"a": "b"}) == wrap_var({"a": "b"})
    assert isinstance(to_unsafe_bytes("a"), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:41:22.359085
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    # Test that AnsibleUnsafeBytes creates an unsafe object
    # by checking __UNSAFE__ is set.
    assert(hasattr(AnsibleUnsafeBytes(b"test"), '__UNSAFE__'))
    # It should have the same encoding as bytes.
    assert(AnsibleUnsafeBytes(b"test").encoding == bytes(b"test").encoding)


# Generated at 2022-06-23 14:41:33.817856
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert to_unsafe_text(u'unicode') == u'unicode'
    assert to_unsafe_text(b'\xc3\xa9') == u'\xe9'
    assert to_unsafe_text('\xc3\xa9', encoding='utf-8') == u'\xe9'

    try:
        to_unsafe_text(b'\xff')
    except UnicodeError:
        pass
    else:
        assert False
    try:
        to_unsafe_text('\xff')
    except UnicodeError:
        pass
    else:
        assert False
    try:
        to_unsafe_text('\xff', 'ascii')
    except UnicodeError:
        pass
    else:
        assert False

# Generated at 2022-06-23 14:41:35.729443
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    obj = NativeJinjaUnsafeText()
    assert obj.__UNSAFE__

# Generated at 2022-06-23 14:41:44.399321
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    from ansible.module_utils._text import to_text
    x = {
        'a': [u'1', u'2', u'3'],
        u'b': {
            'c': {
                u'd': u'4',
                'e': u'5',
                u'f': u'6',
                'g': [u'7', u'8', u'9', u'0'],
                u'h': [1, 2, 3, 4, 5, 6]
            },
            u'i': u'10'
        },
        'j': [{u'k': u'11'}]
    }

    a = AnsibleUnsafeBytes(b'bytes')
    b = AnsibleUnsafeText(u'text')

# Generated at 2022-06-23 14:41:50.548343
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert issubclass(AnsibleUnsafeBytes, AnsibleUnsafe)
    assert issubclass(AnsibleUnsafeText, AnsibleUnsafe)
    assert issubclass(NativeJinjaUnsafeText, AnsibleUnsafeText)

    assert issubclass(UnsafeProxy, object)

# Generated at 2022-06-23 14:42:00.549839
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY3, binary_type, text_type

    b = b'foo'
    s = to_text(b)
    assert isinstance(s, text_type)
    assert isinstance(wrap_var(s), AnsibleUnsafeText)
    assert isinstance(wrap_var(b), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b), binary_type)
    assert isinstance(wrap_var(s), text_type)

    a = {'foo': 123, 'bar': 456}
    w = wrap_var(a)
    assert isinstance(w, dict)
    assert isinstance(w['foo'], AnsibleUnsafeText)

# Generated at 2022-06-23 14:42:08.331501
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    in_value = b'\x01\x02\x03\x04\x05\x06\x07\x08'
    out_value = AnsibleUnsafeBytes(in_value).decode('hex')

    if not isinstance(out_value, text_type):
        raise AssertionError
    elif out_value != to_text(in_value, errors='surrogate_or_strict'):
        raise AssertionError



# Generated at 2022-06-23 14:42:18.746717
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test plain builtin types
    for t in [object, bool, complex, int, float, set, frozenset, str, unicode]:
        assert isinstance(UnsafeProxy(t()), AnsibleUnsafe)

    # Test sequences
    assert isinstance(UnsafeProxy([]), AnsibleUnsafe)
    assert isinstance(UnsafeProxy(tuple()), AnsibleUnsafe)
    assert isinstance(UnsafeProxy(list()), AnsibleUnsafe)
    assert isinstance(UnsafeProxy(set()), AnsibleUnsafe)  # Test set
    assert isinstance(UnsafeProxy(frozenset()), AnsibleUnsafe)  # Test frozenset

    # Test mapping

# Generated at 2022-06-23 14:42:20.358868
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes(b'foo'), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:42:30.217251
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    class Foo:
        def __unicode__(self):
            return 'Foo'

    foo = Foo()
    assert isinstance(to_unsafe_bytes(foo), AnsibleUnsafeBytes)
    assert to_unsafe_bytes(foo) == b'Foo'
    assert isinstance(to_unsafe_bytes(text_type(foo)), AnsibleUnsafeBytes)
    assert to_unsafe_bytes(text_type(foo)) == b'Foo'
    assert isinstance(to_unsafe_bytes(binary_type(foo)), AnsibleUnsafeBytes)
    assert to_unsafe_bytes(binary_type(foo)) == b'Foo'

# Generated at 2022-06-23 14:42:37.760452
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(None), type(None))
    assert isinstance(to_unsafe_text(u'fo'), text_type)
    assert isinstance(to_unsafe_text(b'fo'), text_type)
    assert isinstance(to_unsafe_text(b'fo', errors='strict'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text('fo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text([1, 2, 3]), list)
    assert isinstance(to_unsafe_text({'foo': 'bar'}), dict)
    assert isinstance(to_unsafe_text((1, 2, 3)), tuple)

# Generated at 2022-06-23 14:42:39.905362
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    val = AnsibleUnsafeText("test")
    assert isinstance(val, text_type)
    assert isinstance(val, AnsibleUnsafe)

# Generated at 2022-06-23 14:42:47.892542
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():

    # str -> unicode -> AnsibleUnsafeText
    x1 = AnsibleUnsafeText(u"test")
    assert isinstance(x1, AnsibleUnsafeText)
    assert x1 == u"test"

    # str -> AnsibleUnsafeText
    x2 = AnsibleUnsafeText("test")
    assert isinstance(x2, AnsibleUnsafeText)
    assert x2 == u"test"

    # unicode -> AnsibleUnsafeText
    x3 = AnsibleUnsafeText(u"test")
    assert isinstance(x3, AnsibleUnsafeText)
    assert x3 == u"test"

    # AnsibleUnsafeText -> AnsibleUnsafeText
    x4 = AnsibleUnsafeText(x1)
    assert isinstance(x4, AnsibleUnsafeText)
    assert x4

# Generated at 2022-06-23 14:42:49.552651
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert isinstance(AnsibleUnsafe(), AnsibleUnsafe)


# Generated at 2022-06-23 14:43:01.031757
# Unit test for function wrap_var
def test_wrap_var():
    """
    Wrap the following types to ensure we have the appropriate AnsibleUnsafe type generated

    * ansible_unsafe - already unsafe, so returned as-is
    * text/unicode - wrapped in AnsibleUnsafeText
    * binary/bytes - wrapped in AnsibleUnsafeBytes
    * Mapping - recursively wrapped
    * Sequence (tuple, list) - recursively wrapped
    * Set - recursively wrapped
    * native_jinja_text - wrapped in NativeJinjaUnsafeText
    * everything else - returned as-is
    """
    assert(isinstance(wrap_var(AnsibleUnsafeText('abc')), AnsibleUnsafeText))
    assert(isinstance(wrap_var('abc'), AnsibleUnsafeText))
    assert(isinstance(wrap_var(b'abc'), AnsibleUnsafeBytes))

# Generated at 2022-06-23 14:43:03.453942
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    value = AnsibleUnsafeBytes('test')
    assert isinstance(value.decode(), AnsibleUnsafeText)


# Generated at 2022-06-23 14:43:05.733752
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    unsafeText = AnsibleUnsafeText(u"hello world")
    bytes = unsafeText.encode()
    assert isinstance(bytes, AnsibleUnsafeBytes)
    assert str(bytes) == "b'hello world'"


# Generated at 2022-06-23 14:43:10.547496
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    # NativeJinjaUnsafeText(self, *args, **kwargs)
    test_text = NativeJinjaUnsafeText('testing text string')

    assert isinstance(test_text, NativeJinjaUnsafeText)
    assert test_text == 'testing text string'
    assert test_text.__UNSAFE__

# Generated at 2022-06-23 14:43:20.463519
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    from ansible.module_utils.six import binary_type
    # In our usage we should only receive unicode strings.
    # This conditional and conversion exists to sanity check the values
    # we're given but we may want to take it out for testing and sanitize
    # our input instead.
    unsafe = AnsibleUnsafeBytes(b"string")
    assert unsafe.__class__ == AnsibleUnsafeBytes
    assert isinstance(unsafe.decode('utf-8'), AnsibleUnsafeText)
    assert isinstance(unsafe, AnsibleUnsafe)
    # Test that method decode works as expected
    assert unsafe.decode('utf-8') == u"string"


# Generated at 2022-06-23 14:43:29.547047
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(''), AnsibleUnsafeText)
    assert isinstance(wrap_var(u''), AnsibleUnsafeText)
    assert isinstance(wrap_var(b''), AnsibleUnsafeBytes)
    assert isinstance(wrap_var([]), list)
    assert isinstance(wrap_var(()), tuple)
    assert isinstance(wrap_var({}), dict)
    assert isinstance(wrap_var({'a': 'b'}), dict)
    assert isinstance(wrap_var({'a': 'b'}).get('a'), AnsibleUnsafeText)
    assert isinstance(wrap_var({u'a': u'b'}), dict)

# Generated at 2022-06-23 14:43:31.530170
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes(b"abc"), AnsibleUnsafe)


# Generated at 2022-06-23 14:43:43.381772
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    import pytest
    from ansible.module_utils.six import PY3
    u = UnsafeProxy("test")

    if PY3:
        assert isinstance(u, AnsibleUnsafeText)
        assert u == "test"
    else:
        assert isinstance(u, AnsibleUnsafeBytes)
        assert u == b"test"

    u2 = UnsafeProxy(u)
    if PY3:
        assert isinstance(u2, AnsibleUnsafeText)
        assert u2 == "test"
    else:
        assert isinstance(u2, AnsibleUnsafeBytes)
        assert u2 == b"test"

    with pytest.raises(TypeError):
        UnsafeProxy(None)

# Generated at 2022-06-23 14:43:54.733454
# Unit test for function wrap_var
def test_wrap_var():
    import types
    import ansible.module_utils.six

    # Test None
    assert wrap_var(None) is None

    # Test strings
    assert wrap_var('Unsafe') == 'Unsafe'
    assert wrap_var(u'Unsafe') == u'Unsafe'
    assert isinstance(wrap_var(b'Unsafe'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'Unsafe'.decode('utf-8')), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'Unsafe'.encode('utf-8')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'Unsafe'), AnsibleUnsafeText)

    # Test lists
    assert wrap_var(['Unsafe']) == ['Unsafe']

# Generated at 2022-06-23 14:43:56.600781
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes(b'\x00\xff').__UNSAFE__


# Generated at 2022-06-23 14:44:07.067628
# Unit test for function wrap_var
def test_wrap_var():
    import collections
    import pytest

    assert isinstance(wrap_var(b'unicode'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(b'"\xe2\x80\x98"'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'"\u2018"'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'"\xe2\x80\x98"'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'\u2018'), AnsibleUnsafeText)
    assert isinstance(wrap_var(u'\xe2\x80\x98'), AnsibleUnsafeText)
    assert isinstance(wrap_var(NativeJinjaUnsafeText(u'\u2018')), NativeJinjaUnsafeText)

# Generated at 2022-06-23 14:44:09.525426
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b'foo').decode(), AnsibleUnsafeText)
    assert AnsibleUnsafeBytes(b'foo').decode() == u'foo'



# Generated at 2022-06-23 14:44:12.238265
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    ans = AnsibleUnsafe()
    assert isinstance(ans, AnsibleUnsafe)
    assert ans.__UNSAFE__



# Generated at 2022-06-23 14:44:14.068998
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert isinstance(AnsibleUnsafeText(u'string'), AnsibleUnsafeText)


# Generated at 2022-06-23 14:44:22.294662
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.six import text_type
    s = b'\xa3'
    b = to_unsafe_bytes(s, 'utf-8')
    t = to_unsafe_text(s, 'utf-8')
    assert b != t
    assert isinstance(t, AnsibleUnsafeText)
    assert isinstance(b, AnsibleUnsafeBytes)
    assert b.__UNSAFE__
    assert t.__UNSAFE__

# Generated at 2022-06-23 14:44:30.276496
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    u = AnsibleUnsafeBytes(b'foo')
    assert isinstance(u, AnsibleUnsafeBytes)
    assert isinstance(u, binary_type)
    assert isinstance(u, AnsibleUnsafe)
    assert not isinstance(u, AnsibleUnsafeText)
    u = u.decode('ascii')
    assert isinstance(u, AnsibleUnsafeText)
    assert isinstance(u, text_type)
    assert isinstance(u, AnsibleUnsafe)


# Generated at 2022-06-23 14:44:35.458676
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    a = u"\u0080"
    b = to_unsafe_text(a)
    assert isinstance(b, AnsibleUnsafeText)

    a = "abc"
    b = to_unsafe_text(a)
    assert isinstance(b, AnsibleUnsafeText)

    a = ""
    b = to_unsafe_text(a)
    assert isinstance(b, AnsibleUnsafeText)



# Generated at 2022-06-23 14:44:39.168090
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    obj = AnsibleUnsafeBytes('hello')
    text = 'hello'
    result = obj.decode('utf8')
    assert isinstance(result, AnsibleUnsafeText)
    assert result == text


# Generated at 2022-06-23 14:44:45.558752
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # Basic test for method __new__ of class UnsafeProxy
    assert UnsafeProxy('{"foo": "bar"}') == {"foo": "bar"}
    assert UnsafeProxy(['{"foo": "bar"}']) == ["{\"foo\": \"bar\"}"]
    assert UnsafeProxy('{"foo": "bar"}') == {"foo": "bar"}
    assert UnsafeProxy(None) is None


# Generated at 2022-06-23 14:44:48.518213
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    bs = to_bytes('test')
    assert isinstance(bs, binary_type)
    ub = to_unsafe_bytes(bs)
    assert isinstance(ub, AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:44:58.557274
# Unit test for function wrap_var
def test_wrap_var():
    # Create 5 different types of variables
    empty_set = set()
    not_empty_set = {'a', 'b', 'c'}
    empty_dict = dict()
    not_empty_dict = {'a': 'a', 'b': 'b', 'c': 'c'}
    not_empty_list = ['a', 'b', 'c']
    not_empty_tuple = ('a', 'b', 'c')

    # Create two variables of native jinja unsafe text
    unsafe_text1 = "Hello World !!"
    unsafe_text2 = u"Hello World !!"

    # Create two variables of native jinja unsafe bytes
    unsafe_bytes1 = b'Hello World !!'
    unsafe_bytes2 = b'Hello World !!'

    # Create four variables of native jinja text
    text1

# Generated at 2022-06-23 14:45:01.385684
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert type(UnsafeProxy('hello')).__name__ == 'AnsibleUnsafeText'
    assert type(UnsafeProxy(b'hello')).__name__ == 'AnsibleUnsafeBytes'

# Generated at 2022-06-23 14:45:07.706820
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert str(AnsibleUnsafeBytes(b'\xc3\x8f').decode('utf-8')) == str(b'\xc3\x8f'.decode('utf-8'))
    assert str(AnsibleUnsafeBytes(b'\xc3\x8f').decode('utf-8')) == str(u'\xc3\x8f')


# Generated at 2022-06-23 14:45:10.941724
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    text = "sanitize me"
    unsafeText = AnsibleUnsafeText(text)
    assert unsafeText.encode() == "sanitize me"
    assert isinstance(unsafeText.encode(), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:45:12.411635
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    obj = AnsibleUnsafeText("test")
    assert isinstance(obj, AnsibleUnsafe)

# Generated at 2022-06-23 14:45:22.819113
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    test_input_data = [
        (b"this is a bytestring", AnsibleUnsafeBytes),
        ("this is a unicode string", AnsibleUnsafeText)
    ]

    for item in test_input_data:
        obj, expected_class = item
        result = UnsafeProxy(obj)
        if not isinstance(result, expected_class):
            raise AssertionError("%s != %s is not %s instance" % (obj, expected_class, type(result)))
        if not isinstance(result, AnsibleUnsafe):
            raise AssertionError("%s is not an instance of AnsibleUnsafe" % (type(result)))

# Generated at 2022-06-23 14:45:27.313051
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    result = AnsibleUnsafeBytes("hello")
    assert result.__UNSAFE__ == True
    assert result.decode() == "hello"
    assert result.decode("utf-8") == "hello"
    assert result.decode("utf-8", "ignore") == "hello"


# Generated at 2022-06-23 14:45:29.339462
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    '''
    This test checks whether NativeJinjaUnsafeText class can be constructed.
    '''
    assert NativeJinjaUnsafeText('string')

# Generated at 2022-06-23 14:45:32.722664
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    original_text = u'Original Text'
    proxy_obj = UnsafeProxy(original_text)
    assert isinstance(proxy_obj, AnsibleUnsafeText)
    assert proxy_obj == original_text



# Generated at 2022-06-23 14:45:43.782383
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    test_dict1 = {'a': 1, 'b': 2, 'c': 3}
    test_dict2 = {'d': 4, 'e': 5, 'f': 6}
    test_dict3 = {test_dict1, test_dict2}
    test_dict4 = {'g': 7, 'h': 8, 'i': 9}
    test_dict5 = {'j': 1, 'k': 2, 'l': 3}
    test_dict6 = {'m': 4, 'n': 5, 'o': 6}
    test_dict7 = {test_dict5, test_dict6}
    test_dict8 = {'p': 7, 'q': 8, 'r': 9}
    test_dict9 = {'s': 10}

# Generated at 2022-06-23 14:45:46.482364
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    text = 'hello im the test string :)'
    a = AnsibleUnsafeText(text)
    assert isinstance(a, AnsibleUnsafeText)
    assert isinstance(a, text_type)
    assert isinstance(a, AnsibleUnsafe)
    assert a == text
    assert len(a) == len(text)
    assert a[0] == text[0]



# Generated at 2022-06-23 14:45:52.670436
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    s = AnsibleUnsafeBytes("\xc3\xa7\xc3\xb5\xc3\xab", 'utf-8')
    assert str(s) == "\xc3\xa7\xc3\xb5\xc3\xab"
    assert s.encode('utf-8') == s
    assert s.encode('ascii') == "???"



# Generated at 2022-06-23 14:46:02.985908
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import os, tempfile

    fd, fname = tempfile.mkstemp()
    os.close(fd)
    f = open(fname, 'wb')
    f.write(b'\xFF\xFF\xFF')
    f.close()

    with open(fname, 'rb') as f:
        f.seek(0)
        bytestr = f.read()
        textstr = to_text(bytestr)
        unsafe_textstr = to_unsafe_text(bytestr)

    os.remove(fname)

    assert(textstr != unsafe_textstr)


# Generated at 2022-06-23 14:46:04.678094
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert(AnsibleUnsafeText('test'))

# Generated at 2022-06-23 14:46:11.103509
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var('test') == 'test'
    assert wrap_var(u'test') == u'test'

    assert isinstance(wrap_var(b'test'), binary_type)
    assert isinstance(wrap_var(b'test'), AnsibleUnsafeBytes)

    assert isinstance(wrap_var(u'test'), text_type)
    assert isinstance(wrap_var(u'test'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:46:13.942895
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    str = "test"
    bytes_ = AnsibleUnsafeBytes(str)
    assert bytes_ == b"test"
    assert bytes_.__UNSAFE__ == True


# Generated at 2022-06-23 14:46:15.094952
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert AnsibleUnsafeText(u"") == u""

# Generated at 2022-06-23 14:46:25.501573
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    result = UnsafeProxy(None)
    assert result is None, \
        "UnsafeProxy(None) returned %r, expected None" % (result,)

    result = UnsafeProxy(u"foo")
    assert isinstance(result, AnsibleUnsafeText), \
        "UnsafeProxy(u'foo') returned %r, expected an instance of %s" \
        % (result, AnsibleUnsafeText)

    result = UnsafeProxy(b"foo")
    assert isinstance(result, AnsibleUnsafeBytes), \
        "UnsafeProxy(b'foo') returned %r, expected an instance of %s" \
        % (result, AnsibleUnsafeBytes)

    result = UnsafeProxy(u"foo")

# Generated at 2022-06-23 14:46:30.254188
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    try:
        AnsibleUnsafe()
    except Exception as e:
        print('AnsibleUnsafe raised Exception on instantiation: ' + str(e))
    else:
        print('AnsibleUnsafe instantiation failed!')


# Generated at 2022-06-23 14:46:41.684581
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    """
    This method is for unit test for class UnsafeProxy's method __new__.

    :return: A boolean value to indicate if the unit test is passed.
    """
    # Test case 1: function test
    func_obj = UnsafeProxy('abc', 123)
    assert func_obj is not None
    assert isinstance(func_obj, AnsibleUnsafeText)
    assert func_obj == 'abc'

    # Test case 2: class test
    class TestClass:
        def __str__(self):
            return 'def'

    obj = TestClass()
    class_obj = UnsafeProxy(obj)
    assert class_obj is not None
    assert isinstance(class_obj, TestClass)
    assert str(class_obj) == 'def'

    return True



# Generated at 2022-06-23 14:46:45.473174
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    value = 'This is a string that should be Unicode'

    res = UnsafeProxy(value)

    assert isinstance(res, AnsibleUnsafeText)
    assert res == value
    assert res != value.encode('utf-8')


# Generated at 2022-06-23 14:46:50.472101
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    class Foo(AnsibleUnsafeBytes):
        pass

    # test decode with no arguments
    obj = Foo()
    assert isinstance(obj.decode(), AnsibleUnsafeText)

    # test decode with arguments
    obj = Foo()
    assert isinstance(obj.decode(encoding='utf-8'), AnsibleUnsafeText)



# Generated at 2022-06-23 14:46:53.942544
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    a = b'Some string'
    b = AnsibleUnsafeBytes(a)
    assert str(b) == "b'Some string'"
    assert b.decode() == "Some string"


# Generated at 2022-06-23 14:46:57.683583
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert(AnsibleUnsafeText == type(UnsafeProxy(text_type)))
    assert(AnsibleUnsafeBytes == type(UnsafeProxy(binary_type)))


# Generated at 2022-06-23 14:47:05.755818
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes(b'test'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'test', 'ascii'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(b'test', 'ascii', 'strict'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes('test'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes('test', 'ascii'), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes('test', 'ascii', 'strict'), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:47:09.005255
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
	a = AnsibleUnsafeText('hello')
	assert a.encode() == b'hello'
	assert a.encode('utf-8') == b'hello'


# Generated at 2022-06-23 14:47:10.313518
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    u = AnsibleUnsafeText(u"a")
    assert isinstance(u, text_type)


# Generated at 2022-06-23 14:47:22.536326
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    testobj = {
        "unicode": "foo",
        "bytes": b"bar",
        "None": None,
        "int": 4,
        "list": ["foo", 4, None],
        "set": {"foo", 4, None},
        "dict": {"key": "value", "int": 4},
    }
    expected = {
        "unicode": b"foo",
        "bytes": b"bar",
        "None": None,
        "int": 4,
        "list": [b"foo", 4, None],
        "set": {b"foo", 4, None},
        "dict": {"key": b"value", "int": 4},
    }
    testobj_bytes = to_unsafe_bytes(testobj)
    assert testobj_bytes == expected



# Generated at 2022-06-23 14:47:33.000799
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import string_types

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.exit_json(changed=False)

    list_of_strings = ["v1", "v2", "v3"]
    list_of_unsafe_bytes = [to_unsafe_bytes(x) for x in list_of_strings]
    list_of_unsafe_text = [to_unsafe_text(x) for x in list_of_strings]

    # Bytes to text
    assert isinstance(wrap_var(list_of_unsafe_bytes), list)

# Generated at 2022-06-23 14:47:43.780653
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    import json
    # Test if UnsafeProxy is able to convert a text to an AnsibleUnsafeText
    # Python 3.5 returns an AnsibleUnsafeText
    # Python 2.7 returns an AnsibleUnsafeBytes
    unsafe_text = UnsafeProxy('unsafe_text')
    assert isinstance(unsafe_text, AnsibleUnsafe)
    # Test if UnsafeProxy is able to convert a byte to an AnsibleUnsafeBytes
    unsafe_bytes = UnsafeProxy(b'unsafe_bytes')
    assert isinstance(unsafe_bytes, AnsibleUnsafe)
    # Test if UnsafeProxy is able to convert a dict
    unsafe_dict = UnsafeProxy(json.loads('{"a":1}'))
    assert isinstance(unsafe_dict, AnsibleUnsafe)
    # Test if UnsafeProxy is able to

# Generated at 2022-06-23 14:47:49.573716
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert UnsafeProxy(None) is None
    assert UnsafeProxy('string') == u'string'
    assert UnsafeProxy(u'unicode string') == u'unicode string'
    assert UnsafeProxy(b'bytes string') == b'bytes string'
    assert UnsafeProxy(list()) == list()
    assert UnsafeProxy(set()) == set()

# Generated at 2022-06-23 14:47:52.254416
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    class AnsibleUnsafe(object):
        __UNSAFE__ = True

    ans = AnsibleUnsafe()
    assert ans is not None
    assert ans.__UNSAFE__ is True

# Generated at 2022-06-23 14:47:55.234846
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    ansibleUnsafe = AnsibleUnsafeText("test")
    assert isinstance(ansibleUnsafe, AnsibleUnsafeText)
    assert isinstance(ansibleUnsafe, text_type)

# Generated at 2022-06-23 14:47:57.113261
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert hasattr(AnsibleUnsafe, '__UNSAFE__')


# Generated at 2022-06-23 14:48:02.933426
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.six import text_type
    assert isinstance(to_unsafe_text('foo', errors='surrogate_or_strict'), AnsibleUnsafeText)
    assert not isinstance(to_unsafe_text('foo', errors='surrogate_or_strict'), text_type)

# Generated at 2022-06-23 14:48:10.250934
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3

    if PY3:
        # Python 3 unicode to bytes conversion
        assert type(wrap_var(b"test")) is AnsibleUnsafeBytes
        assert type(wrap_var(u"test")) is AnsibleUnsafeText
    else:
        # Python 2 str and unicode to bytes conversion
        assert type(wrap_var(b"test")) is AnsibleUnsafeBytes
        assert type(wrap_var(to_bytes(u"test"))) is AnsibleUnsafeBytes
        assert type(wrap_var(u"test")) is AnsibleUnsafeText
        assert type(wrap_var(to_text(b"test"))) is AnsibleUnsafeText