

# Generated at 2022-06-23 14:38:05.557653
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():

    ret = AnsibleUnsafeText(b'abc')
    assert isinstance(ret, AnsibleUnsafeText)

# Generated at 2022-06-23 14:38:11.110784
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    test_data = AnsibleUnsafeBytes(b'\xe4\xb8\xad\xe6\x96\x87')
    test_unsafeProxy = UnsafeProxy(test_data)
    return isinstance(test_unsafeProxy, AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:38:14.741858
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    b = to_unsafe_bytes("ABC")
    if not isinstance(b, AnsibleUnsafeBytes):
        raise AssertionError("to_unsafe_bytes must return an AnsibleUnsafeBytes object")

# Generated at 2022-06-23 14:38:22.381049
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    original_string_text = "the quick brown fox jumped over the lazy dog"
    usubytes = original_string_text.encode('ascii')
    text = AnsibleUnsafeBytes(usubytes)
    assert isinstance(text.encode('utf-8'), AnsibleUnsafeBytes)
    assert text.encode('utf-8') == usubytes.decode('ascii').encode('utf-8')
    assert isinstance(text.encode('ascii'), AnsibleUnsafeBytes)
    assert text.encode('ascii') == usubytes.decode('ascii').encode('ascii')
    assert isinstance(text.encode('ascii', 'ignore'), AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:38:26.904053
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    text = AnsibleUnsafeText("some text")
    text2 = text.encode()
    assert isinstance(text, text_type)
    assert isinstance(text, AnsibleUnsafe)
    assert isinstance(text2, binary_type)
    assert isinstance(text2, AnsibleUnsafe)

# Generated at 2022-06-23 14:38:36.995507
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    import sys
    import ansible.utils.unsafe_proxy

    wrapper = lambda x: ansible.utils.unsafe_proxy.AnsibleUnsafeBytes(str(x))

    # RFC 3629 (UTF-8)
    # NOTE: we're leaving out UTF-32 for now because we're converting to text
    assert to_unsafe_bytes(u'\u0F8A') == wrapper(b'\xE0\xBE\xAA')
    assert to_unsafe_bytes(u'\u1E94\u0BC0') == wrapper(b'\xE1\xBA\x94\xE0\xAF\x80')
    assert to_unsafe_bytes(u'\U0010FFFD') == wrapper(b'\xF4\x8F\xBF\xBD')

    #

# Generated at 2022-06-23 14:38:47.193038
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    # Test case: obj is string
    str_a = "AAA"
    str_b = AnsibleUnsafeText("AAA")
    assert str_a == str_b
    assert str_a is not str_b
    assert str_a.__class__.__name__ == str_b.__class__.__name__
    assert str_a.__class__.__base__.__name__ == str_b.__class__.__base__.__name__

    # Test case: obj is text_type
    str_c = u"BBB"
    str_d = AnsibleUnsafeText(str_c)
    assert str_c == str_d
    assert str_c is not str_d
    assert str_c.__class__.__name__ == str_d.__class__.__name__
   

# Generated at 2022-06-23 14:38:49.230461
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    ustr = u'\u263a'
    assert ustr == to_unsafe_text(ustr)

# Generated at 2022-06-23 14:38:53.766714
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.display import Display
    Display().deprecated('Passing the Display class to UnsafeProxy function will only create deprecation warnings.')
    assert UnsafeProxy("foo", Display()) == "foo"



# Generated at 2022-06-23 14:39:01.210018
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    u1 = UnsafeProxy(u"hello")
    assert isinstance(u1, AnsibleUnsafeText)
    assert u1 == u"hello"

    u2 = UnsafeProxy(b"hello")
    assert isinstance(u2, AnsibleUnsafeBytes)
    assert u2 == b"hello"

    u3 = UnsafeProxy(u2)
    assert isinstance(u3, AnsibleUnsafeBytes)
    assert u3 == b"hello"

# Generated at 2022-06-23 14:39:03.480940
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes(b"hello").decode(), AnsibleUnsafeText)


# Generated at 2022-06-23 14:39:10.351956
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert not isinstance(UnsafeProxy('some text'), AnsibleUnsafe)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText('some text')), AnsibleUnsafe)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes(b'some text')), AnsibleUnsafe)
    assert isinstance(UnsafeProxy(b'some text'), AnsibleUnsafe)
    assert isinstance(UnsafeProxy(u'some text'), AnsibleUnsafe)
    assert isinstance(UnsafeProxy(None), AnsibleUnsafe)



# Generated at 2022-06-23 14:39:20.769739
# Unit test for function wrap_var
def test_wrap_var():
    """Tests wrap_var, ensures that the basic types are wrapped and tuples aren't accidentally
    deep copied"""
    # Maps (dicts) and lists are wrapped, with their values wrapped as well
    assert 'AnsibleUnsafeText' in repr(wrap_var({'foo': 'foo'}))
    assert 'AnsibleUnsafeText' in repr(wrap_var(['foo']))
    # Shelling out to the module system for a type name check
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves.builtins import basestring
    if PY3:
        from ansible.module_utils.six.moves.queue import Queue
    else:
        from Queue import Queue

    # Other built-in types, ints, floats, strings and queue

# Generated at 2022-06-23 14:39:32.948944
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    # Test passing in safe text
    unsafe_text = UnsafeProxy('this is safe text')
    assert isinstance(unsafe_text, AnsibleUnsafeText)
    assert not hasattr(unsafe_text, '__UNSAFE__')

    # Test passing in safe bytes
    unsafe_bytes = UnsafeProxy('this is safe bytes'.encode())
    assert isinstance(unsafe_bytes, AnsibleUnsafeBytes)
    assert unsafe_bytes.__UNSAFE__

    # Test passing in safe text and bytes
    unsafe_text_bytes = UnsafeProxy('this is safe text bytes'.encode())
    assert isinstance(unsafe_text_bytes, AnsibleUnsafeText)
    assert unsafe_bytes.__UNSAFE__

    # Test passing in safe text and bytes

# Generated at 2022-06-23 14:39:44.789957
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    bytes_val = "hellø"
    bytes_val2 = "hellø".encode('utf-8')

    assert isinstance(bytes_val, str)
    assert isinstance(bytes_val2, bytes)

    ansible_safe_text = AnsibleUnsafeText(bytes_val)
    ansible_safe_text2 = AnsibleUnsafeText(bytes_val2)

    assert isinstance(ansible_safe_text, AnsibleUnsafeText)
    assert isinstance(ansible_safe_text2, AnsibleUnsafeText)

    ansible_safe_text_to_bytes = ansible_safe_text.encode('utf-8')
    ansible_safe_text2_to_bytes = ansible_safe_text2.encode('utf-8')


# Generated at 2022-06-23 14:39:56.652352
# Unit test for function wrap_var
def test_wrap_var():
    import json

    # Test for string conversion
    assert type(wrap_var('string')) == AnsibleUnsafeText
    assert type(wrap_var(b'bytestring')) == AnsibleUnsafeBytes
    assert type(wrap_var(AnsibleUnsafeText('UnsafeText'))) == AnsibleUnsafeText
    assert type(wrap_var(AnsibleUnsafeBytes(b'UnsafeBytes'))) == AnsibleUnsafeBytes

    # Test for list conversion
    seq = ['string', b'bytestring', AnsibleUnsafeText('UnsafeText'), AnsibleUnsafeBytes(b'UnsafeBytes')]
    assert type(seq) != AnsibleUnsafeText
    assert type(seq) != AnsibleUnsafeBytes
    assert type(_wrap_sequence(seq)) == list

    # Test for tuple conversion

# Generated at 2022-06-23 14:39:57.770027
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    NativeJinjaUnsafeText(u'helo')

# Generated at 2022-06-23 14:40:01.133467
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    original_value = AnsibleUnsafeText('x')
    encoded_value = AnsibleUnsafeBytes('x')

    result = original_value.encode()

    assert result == encoded_value


# Generated at 2022-06-23 14:40:05.723822
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    # Test all possible combination of parameters
    assert to_unsafe_bytes(from_txt="from", to='utf-8', errors='strict') == b"from"
    assert to_unsafe_bytes(from_txt="from", to='utf-8', errors='ignore') == b"from"
    assert to_unsafe_bytes(from_txt="from", to='utf-8', errors='replace') == b"from"
    assert to_unsafe_bytes(from_txt="from", to='utf-8', errors='surrogateescape') == b"from"
    assert to_unsafe_bytes(from_txt="from", to='utf-8', errors='surrogate_or_strict') == b"from"

# Generated at 2022-06-23 14:40:07.630707
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes(b'sample'), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:40:16.934380
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    # Test with no args
    assert(isinstance(to_unsafe_bytes(), AnsibleUnsafeBytes))
    assert(isinstance(to_unsafe_bytes('test'), AnsibleUnsafeBytes))
    assert(isinstance(to_unsafe_bytes(b'test'), AnsibleUnsafeBytes))
    assert(isinstance(to_unsafe_bytes(1), AnsibleUnsafeBytes))

# Generated at 2022-06-23 14:40:26.353898
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    import re
    regex = re.compile("^foo.*")
    # Note: Use NativeJinjaUnsafeText() when you want the contents to be dumped as they are.
    # For example:
    # ansible -m debug -a "var={{ my_var }}"
    # my_var=NativeJinjaUnsafeText(regex)
    # The above will dump the regular expression object 'regex' as-is.

    # Note: Use AnsibleUnsafeText() when you want the contents to be dumped as a string.
    # For example:
    # ansible -m debug -a "var={{ my_var }}"
    # my_var=AnsibleUnsafeText(regex)
    # The above will dump the regular expression object 'regex' as a string.

    my_var = NativeJinja

# Generated at 2022-06-23 14:40:32.751458
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert to_unsafe_bytes('foo') == AnsibleUnsafeText(u'foo')
    assert to_unsafe_bytes(u'foo') == AnsibleUnsafeText(u'foo')
    assert to_unsafe_bytes(b'foo') == AnsibleUnsafeBytes(b'foo')
    assert to_unsafe_bytes(1) == AnsibleUnsafeText(u'1')



# Generated at 2022-06-23 14:40:35.365052
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    obj = AnsibleUnsafeBytes('foo')
    # pylint: disable=assignment-from-no-return
    newobj = obj.decode()


# Generated at 2022-06-23 14:40:37.079564
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert isinstance(NativeJinjaUnsafeText(u'string'), NativeJinjaUnsafeText)

# Generated at 2022-06-23 14:40:39.933877
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert issubclass(AnsibleUnsafe, object)
    assert AnsibleUnsafe().__UNSAFE__



# Generated at 2022-06-23 14:40:42.392282
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(wrap_var(to_bytes('test', 'utf-8')), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:40:51.595921
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    import six

    # There should be no change when encoding an unsafe string
    assert to_unsafe_text(u"test") == u"test"

    # Strings should be made unsafe by UTF-8 encoding them
    assert type(to_unsafe_text(b"test")) == six.text_type

    # Encoding should be UTF-8
    assert to_unsafe_text(b"test") == u"test"

    # Strings should be made unsafe by Unicode encoding them
    assert type(to_unsafe_text(u"test")) == six.text_type

    # Encoding should be UTF-8
    assert to_unsafe_text(u"test") == u"test"

    # There should be no change when encoding an unsafe string

# Generated at 2022-06-23 14:41:00.552759
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var("foo") == u"foo"
    assert wrap_var(u"foo") == u"foo"
    assert wrap_var(u"foo".encode("utf-8")) == u"foo"
    assert wrap_var(wrap_var("foo")) == u"foo"
    assert wrap_var(u"\U0001f638") == u"\U0001f638"
    assert type(wrap_var("foo")) is NativeJinjaUnsafeText
    assert type(wrap_var(u"foo")) is NativeJinjaUnsafeText
    assert type(wrap_var(u"foo".encode("utf-8"))) is NativeJinjaUnsafeText
    assert type(wrap_var(wrap_var("foo"))) is NativeJinjaUnsafeText

# Generated at 2022-06-23 14:41:03.760394
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    test_text = to_unsafe_text("test")

    assert isinstance(test_text, AnsibleUnsafeText)


# Generated at 2022-06-23 14:41:07.557786
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    assert isinstance(AnsibleUnsafeText(''), AnsibleUnsafeText)
    assert isinstance(AnsibleUnsafeText('a'), AnsibleUnsafeText)
    assert str(AnsibleUnsafeText('a')) == 'a'


# Generated at 2022-06-23 14:41:12.632485
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    from ansible.module_utils._text import to_native

    my_str = to_native(b'\xc3\xa9')
    ans_str = AnsibleUnsafeText(my_str)

    assert isinstance(ans_str.encode('utf-8'), AnsibleUnsafeBytes)
    assert ans_str.encode('utf-8') == AnsibleUnsafeBytes(b'\xc3\xa9')


# Generated at 2022-06-23 14:41:16.279261
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    jinja_file = NativeJinjaUnsafeText(text_type(__file__))
    assert isinstance(jinja_file, NativeJinjaUnsafeText)


# Generated at 2022-06-23 14:41:18.588919
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert isinstance(NativeJinjaUnsafeText('hello'), NativeJinjaUnsafeText)


# Generated at 2022-06-23 14:41:21.871561
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    ansible_unsafe_text = AnsibleUnsafeText("This is a test")

    # Check the type of object
    assert type(ansible_unsafe_text) is AnsibleUnsafeText

# Generated at 2022-06-23 14:41:29.288262
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert issubclass(UnsafeProxy('foo'), AnsibleUnsafeText)
    assert issubclass(UnsafeProxy(u'foo'), AnsibleUnsafeText)
    assert issubclass(UnsafeProxy(b'foo'), AnsibleUnsafeBytes)
    assert issubclass(UnsafeProxy(42), AnsibleUnsafe)
    assert issubclass(UnsafeProxy(['foo']), AnsibleUnsafe)
    assert issubclass(UnsafeProxy(b'foo'), AnsibleUnsafe)



# Generated at 2022-06-23 14:41:34.961493
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.utils.hashing import md5s
    from ansible.parsing.yaml.objects import AnsibleUnicode
    plain_string = "this is a plain string"
    plain_unicode = u"this is a plain unicode string"
    plain_tuple = (1, 2)
    plain_list = [1, 2]
    plain_dict = {u'a': u'b', u'c': u'd'}
    plain_dict2 = {u'a': plain_dict}
    utf8_string = u"this is a UTF-8 string with a \u2019 (right single quote) in it"
    cf_string = u"this string uses curly quotes \u2018 (left single quote) and \u2019 (right single quote)"
    cf_string_utf8 = cf_string.en

# Generated at 2022-06-23 14:41:37.073488
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    assert isinstance(
        AnsibleUnsafeText('123').encode('utf-8'),
        AnsibleUnsafeBytes
    )



# Generated at 2022-06-23 14:41:41.170510
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    # simple string
    assert to_unsafe_text(b'test') == u'test'
    # unicode string
    assert to_unsafe_text(u'test') == u'test'
    # binary string
    assert isinstance(to_unsafe_text(b'test'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:41:46.274358
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    text = NativeJinjaUnsafeText('Unsafe')
    assert text == 'Unsafe'
    assert not hasattr(text, '__UNSAFE__')
    assert hasattr(text, '__UNSAFE_TEMPLATE_DATA__')
    assert isinstance(text, (binary_type, text_type))



# Generated at 2022-06-23 14:41:48.793497
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    text = NativeJinjaUnsafeText(to_text("{{ 'unsafe' }}"))

# Generated at 2022-06-23 14:41:54.745029
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    import inspect
    for name, obj in inspect.getmembers(UnsafeProxy):
        if name.startswith('_') or name.startswith('__'):
            pass

# Generated at 2022-06-23 14:41:56.391329
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert AnsibleUnsafeBytes(b'1234') == b'1234'


# Generated at 2022-06-23 14:42:03.815171
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils.six import b, u
    from ansible.module_utils.common._collections_compat import Hashable

    assert isinstance(UnsafeProxy(None), AnsibleUnsafe)
    assert isinstance(UnsafeProxy(AnsibleUnsafeBytes(b('foo'))), AnsibleUnsafe)
    assert isinstance(UnsafeProxy(AnsibleUnsafeText(u('foo'))), AnsibleUnsafe)

    assert isinstance(UnsafeProxy(b('foo')), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(u('foo')), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b('foo')), Hashable)
    assert isinstance(UnsafeProxy(u('foo')), Hashable)

    assert UnsafeProxy(b('foo')) == Ans

# Generated at 2022-06-23 14:42:10.744058
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    assert type(UnsafeProxy('a')) == AnsibleUnsafeText
    assert type(UnsafeProxy(u'a')) == AnsibleUnsafeText
    assert type(UnsafeProxy(b'a')) == AnsibleUnsafeBytes
    assert type(UnsafeProxy(AnsibleUnsafeText('a'))) == AnsibleUnsafeText
    assert type(UnsafeProxy(AnsibleUnsafeBytes(b'a'))) == AnsibleUnsafeBytes



# Generated at 2022-06-23 14:42:14.356882
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    AnUnsafeBytes = AnsibleUnsafeBytes(b"foo")
    assert isinstance(AnUnsafeBytes, AnsibleUnsafeBytes)
    assert AnUnsafeBytes == b"foo"


# Generated at 2022-06-23 14:42:26.588760
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(None), type(None))
    assert isinstance(to_unsafe_text(42), int)
    assert isinstance(to_unsafe_text(42.0), float)
    assert isinstance(to_unsafe_text('foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'foo'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(tuple()), tuple)
    assert isinstance(to_unsafe_text(list()), list)
    assert isinstance(to_unsafe_text(set()), set)
    assert isinstance(to_unsafe_text({}), dict)
    assert isinstance(to_unsafe_text(dict()), dict)


# Generated at 2022-06-23 14:42:34.932493
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    """ansible.module_utils.common.unsafe_proxy._UnsafeProxy.__new__() = <_UnsafeProxy object>"""
    assert (UnsafeProxy(None) == None)
    assert (UnsafeProxy(1) == 1)
    assert (UnsafeProxy('foo') == 'foo')
    assert (UnsafeProxy(u'foo') == u'foo')
    assert (UnsafeProxy('foo') == 'foo')
    assert (UnsafeProxy(['foo', 'bar']) == ['foo', 'bar'])
    assert (UnsafeProxy(('foo', 'bar')) == ('foo', 'bar'))
    assert (UnsafeProxy({'foo': 'foo', 'bar': 'bar'}) == {'foo': 'foo', 'bar': 'bar'})

# Generated at 2022-06-23 14:42:37.117895
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    unsafe_text = '\u0000&\u0001'
    assert to_text(to_unsafe_text(unsafe_text)) == unsafe_text


# Generated at 2022-06-23 14:42:41.077456
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    s = AnsibleUnsafeBytes(b"\x8a\x89a")
    assert isinstance(s, AnsibleUnsafeBytes)
    assert s.decode(errors='replace') == u'\ufffd\ufffda'


# Generated at 2022-06-23 14:42:44.189067
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():

    # Testing if the class constructor is correctly initializing the object
    string = "Test string"
    testText = NativeJinjaUnsafeText(string)

    assert testText == string
    assert testText.__UNSAFE__ == True

# Generated at 2022-06-23 14:42:55.432792
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    from ansible.module_utils.six import print_
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six import u
    from io import BytesIO
    from io import TextIOBase

    for stream in (BytesIO(b'foobar'), StringIO('foobar')):
        assert isinstance(stream, TextIOBase)
        stream.seek(0)
        unsafe_text = AnsibleUnsafeText(stream.read())
        stream.seek(0)
        assert isinstance(unsafe_text, AnsibleUnsafeText)
        assert isinstance(unsafe_text, text_type)
        assert isinstance(unsafe_text, u('foobar'))
        assert unsafe_text.__UNSAFE__ is True

# Generated at 2022-06-23 14:43:02.658408
# Unit test for function to_unsafe_text
def test_to_unsafe_text():

    # Test case 1 - the test input is a string
    xx = "testing string"
    yy = AnsibleUnsafeText(xx)
    assert to_unsafe_text(xx) == yy

    # Test case 2 - the test input is a string that has unicode characters
    zz = "测试中文字符串"
    ww = AnsibleUnsafeText(zz)
    assert to_unsafe_text(zz) == ww

# Generated at 2022-06-23 14:43:05.953235
# Unit test for constructor of class AnsibleUnsafeText
def test_AnsibleUnsafeText():
    a = AnsibleUnsafeText('Abc')
    b = AnsibleUnsafeText('Abcd')
    assert a == 'Abc'
    assert b == 'Abcd'
    assert a < b


# Generated at 2022-06-23 14:43:14.858937
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert UnsafeProxy('123') == wrap_var('123')
    assert UnsafeProxy(None) == wrap_var(None)
    assert UnsafeProxy(['123']) == wrap_var(['123'])
    assert UnsafeProxy(['123']) != wrap_var(None)
    assert UnsafeProxy(u'123') == wrap_var(u'123')
    assert UnsafeProxy(b'123') == wrap_var(b'123')
    assert UnsafeProxy(u'123') != wrap_var(b'123')
    assert UnsafeProxy(b'123') != wrap_var(u'123')
    assert UnsafeProxy(['123']) != wrap_var(u'123')
    assert UnsafeProxy(['123']) != wrap_var(b'123')


# Generated at 2022-06-23 14:43:22.984309
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.tests.unit.compat.mock import patch
    from ansible.module_utils import common as module_common
    test_cases = [
        (u'hi', u'hi'),
        ('hi', u'hi'),
        (b'hi', u'hi'),
    ]

    for inp, exp in test_cases:
        assert exp == to_unsafe_text(inp)

    with patch.object(module_common, 'to_text', return_value=u'hi'):
        assert u'hi' == to_unsafe_text(b'hi')


# Generated at 2022-06-23 14:43:31.096351
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    assert isinstance(UnsafeProxy(''), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy('b'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'b'), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(u'b'), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(None), None)
    assert isinstance(UnsafeProxy('b', None), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(u'b', None), AnsibleUnsafeText)
    assert isinstance(UnsafeProxy(b'b', None), AnsibleUnsafeBytes)
    assert isinstance(UnsafeProxy(None, 'a'), None)
    assert isinstance(UnsafeProxy('b', 'a'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:43:39.635558
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():

    # Testing the case when the data is a string
    result = AnsibleUnsafeBytes("Hello Ansible")
    assert isinstance(result, AnsibleUnsafeBytes)

    # Testing the case when the data is a unicode
    result = AnsibleUnsafeBytes(u"Hello Ansible")
    assert isinstance(result, AnsibleUnsafeBytes)

    # Testing the case when the data is a binary
    result = AnsibleUnsafeBytes(b"Hello Ansible")
    assert isinstance(result, AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:43:48.138294
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # Test with a normal str
    teststr = to_bytes('*** hello ***')
    teststr_unsafe = AnsibleUnsafeBytes.decode(teststr, 'utf-8')
    teststr_safestr = to_text(teststr, 'utf-8')

    assert isinstance(teststr_safestr, text_type)
    assert isinstance(teststr_unsafe, text_type)
    assert teststr_unsafe == teststr_safestr

    # Test with an unsafe str
    teststr = to_bytes('*** hello ***')
    teststr_unsafe = AnsibleUnsafeBytes(teststr)
    teststr_unsafestr = AnsibleUnsafeBytes.decode(teststr_unsafe, 'utf-8')

# Generated at 2022-06-23 14:43:54.333041
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes("x"), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(text_type("x")), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(AnsibleUnsafeBytes("x")), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(AnsibleUnsafeText("x")), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:43:57.985823
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.display import Display
    from ansible.utils.unsafe_proxy import UnsafeProxy
    test_instance = UnsafeProxy("test123")
    return (type(test_instance) == AnsibleUnsafeText)

# Generated at 2022-06-23 14:44:08.095104
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(u'a'), AnsibleUnsafeText) and to_unsafe_text(u'a') == u'a'
    assert isinstance(to_unsafe_text('a'), AnsibleUnsafeText) and to_unsafe_text('a') == u'a'
    assert isinstance(to_unsafe_text(u'a', errors='surrogate_or_strict'), AnsibleUnsafeText) and to_unsafe_text(u'a', errors='surrogate_or_strict') == u'a'
    assert isinstance(to_unsafe_text('a', errors='surrogate_or_strict'), AnsibleUnsafeText) and to_unsafe_text('a', errors='surrogate_or_strict') == u'a'

# Generated at 2022-06-23 14:44:09.236661
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert(AnsibleUnsafe() is not None)

# Generated at 2022-06-23 14:44:15.945177
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert type(to_unsafe_bytes('string')) == AnsibleUnsafeBytes
    # test that a str('string') type is returned as a AnsibleUnsafeBytes object
    assert type(to_unsafe_bytes(str('string'))) == AnsibleUnsafeBytes
    assert type(to_unsafe_bytes(b'string')) == AnsibleUnsafeBytes
    # test that a AnsibleUnsafeBytes object is returned as a AnsibleUnsafeBytes object
    assert type(to_unsafe_bytes(AnsibleUnsafeBytes(b'string'))) == AnsibleUnsafeBytes

    assert type(to_unsafe_bytes('string')) == AnsibleUnsafeBytes
    # test that a str('string') type is returned as a AnsibleUnsafeBytes object

# Generated at 2022-06-23 14:44:21.186535
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    class S(str):
        def __new__(cls):
            return super(S, cls).__new__(cls, "hello")
    assert isinstance(to_unsafe_text(S()), AnsibleUnsafeText)

# Generated at 2022-06-23 14:44:28.852748
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    import ansible.module_utils.six as six
    if six.PY3:
        #safe_text = str("{{ foo }}")
        safe_text = str("something")
        safe_text_converted_to_unsafe = NativeJinjaUnsafeText(safe_text)
        assert isinstance(safe_text_converted_to_unsafe, NativeJinjaUnsafeText)
        assert isinstance(safe_text_converted_to_unsafe, AnsibleUnsafeText)
    else:
        safe_text = unicode("{{ foo }}")
        safe_text_converted_to_unsafe = NativeJinjaUnsafeText(safe_text)
        assert isinstance(safe_text_converted_to_unsafe, NativeJinjaUnsafeText)

# Generated at 2022-06-23 14:44:30.822049
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    u = AnsibleUnsafeText('root:xxxxx')
    assert isinstance(u, AnsibleUnsafeText)
    assert isinstance(u.encode('ascii'), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:44:35.237623
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():

    # Create UnsafeProxy, test with existing and non-existent attribute
    a = UnsafeProxy('1')
    # 1. Non-existent attribute test
    assert(a.__UNSAFE__ == True)

    # 2. Check that the string '1' was passed as an argument to the constructor
    assert(a == '1')

    # 3. Check that the constructor converted the str type to
    # the safe str type
    assert(type(a) == AnsibleUnsafeText)

    b = UnsafeProxy(a)

    # 4. Check that the string '1' was passed as an argument to the constructor
    assert(b == '1')

    # 5. Check that the constructor converted the str type to
    # the safe str type
    assert(type(b) == AnsibleUnsafeText)

    # 6. Check that the original string

# Generated at 2022-06-23 14:44:44.757370
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils.six import PY3
    # Test wrap_var with bytes
    if PY3:
        x = b'foo'
        assert type(wrap_var(x)) is AnsibleUnsafeBytes
    else:
        x = 'foo'
        assert type(wrap_var(x)) is AnsibleUnsafeText

    # Test wrap_var with list
    x = [b'foo', b'bar', b'baz']
    assert type(wrap_var(x)) is list
    assert type(wrap_var(x)[0]) is AnsibleUnsafeBytes

    # Test wrap_var with tuple
    x = (b'foo', b'bar', b'baz')
    assert type(wrap_var(x)) is tuple
    assert type(wrap_var(x)[0]) is AnsibleUn

# Generated at 2022-06-23 14:44:50.812730
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.module_utils._text import to_bytes, to_native
    unicode_string = u'łąka'
    byte_string = b'\xc5\x82\xc4\x85ka'
    assert unicode_string == UnsafeProxy(unicode_string)
    assert byte_string == UnsafeProxy(to_bytes(unicode_string))
    assert unicode_string == UnsafeProxy(to_native(unicode_string))
    assert byte_string == UnsafeProxy(byte_string)



# Generated at 2022-06-23 14:44:54.790267
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    assert isinstance(to_unsafe_bytes("test"), AnsibleUnsafeBytes)
    assert isinstance(to_unsafe_bytes(None), type(None))
    assert isinstance(to_unsafe_bytes(AnsibleUnsafeBytes("test")), AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:45:01.531809
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    # class UnsafeProxy:
    # def __new__(cls, obj, *args, **kwargs):
    assert UnsafeProxy('') == ''
    assert UnsafeProxy(1) == 1
    assert UnsafeProxy(1.1) == 1.1
    assert UnsafeProxy({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert UnsafeProxy((1, 2, 3)) == (1, 2, 3)
    assert UnsafeProxy([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-23 14:45:11.208034
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.text_encoder import to_unicode

    if PY3:
        obj = 'bytes'.encode('utf-8')
        result = UnsafeProxy(obj)
        assert type(result) == AnsibleUnsafeBytes
        assert result == b'bytes'

    obj = 'text'
    result = UnsafeProxy(obj)
    assert type(result) == AnsibleUnsafeText
    assert result == 'text'

    obj = to_unicode('text')
    result = UnsafeProxy(obj)
    assert type(result) == AnsibleUnsafeText
    assert result == 'text'



# Generated at 2022-06-23 14:45:15.379871
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    class AnsibleUnsafeBytesSubclass(AnsibleUnsafeBytes):
        pass
    obj = AnsibleUnsafeBytesSubclass(b"foo")
    assert isinstance(obj, AnsibleUnsafeBytesSubclass)
    assert isinstance(obj.decode(), AnsibleUnsafeText)


# Generated at 2022-06-23 14:45:27.516638
# Unit test for constructor of class UnsafeProxy
def test_UnsafeProxy():
    from ansible.utils.display import Display
    Display().deprecated('UnsafeProxy is being deprecated. Use wrap_var or AnsibleUnsafeBytes/AnsibleUnsafeText directly instead',
        version='2.13', collection_name='ansible.builtin')
    assert type(UnsafeProxy('')) == AnsibleUnsafeText
    assert type(UnsafeProxy(b'')) == AnsibleUnsafeBytes
    assert type(UnsafeProxy(u'')) == AnsibleUnsafeText
    assert type(UnsafeProxy(AnsibleUnsafeText(''))) == AnsibleUnsafeText
    assert type(UnsafeProxy(AnsibleUnsafeBytes(b''))) == AnsibleUnsafeBytes
    # This is the same as above but just making sure that an unsafe proxy is
    # not being re-proxied

# Generated at 2022-06-23 14:45:37.951807
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    import os
    from ansible.module_utils.six import PY3, b
    from ansible.module_utils.six.moves import StringIO
    from ansible.template import generate_ansible_template_vars

    template_string = u'{{ foo }}'

    # StringIO() is not supported under Python 3.  Use BytesIO() instead.
    stream = StringIO() if PY3 else BytesIO()
    template = NativeJinjaUnsafeText(template_string, stream=stream)

    # Set up a dummy environment to get the module_vars()

# Generated at 2022-06-23 14:45:48.271867
# Unit test for function wrap_var
def test_wrap_var():
    # Wrap a string
    assert isinstance(wrap_var('foo'), AnsibleUnsafeText)
    # Wrap a list
    assert isinstance(wrap_var(['foo', 'bar']), list)
    assert isinstance(wrap_var(['foo', 'bar'])[0], AnsibleUnsafeText)
    # Wrap a list of lists
    assert isinstance(wrap_var([['foo', 'bar'], ['baz', 'qux']]), list)
    assert isinstance(wrap_var([['foo', 'bar'], ['baz', 'qux']])[0], list)
    assert isinstance(wrap_var([['foo', 'bar'], ['baz', 'qux']])[0][0], AnsibleUnsafeText)
    # Wrap a list of dicts

# Generated at 2022-06-23 14:46:01.613020
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    from ansible.module_utils.common.text_utils import to_native
    from ansible.module_utils.six import StringIO

    test_str_utf8 = b'utf\xc3\xb8'
    test_str_unicode = u'danish \xf8'
    native_str = to_native(test_str_utf8)

    if not hasattr(StringIO, 'getvalue'):
        # These tests are only valid on Python 2.6+
        return

    assert to_unsafe_text(NativeJinjaText(test_str_utf8)).encode('utf-8') == test_str_utf8
    assert to_unsafe_text(NativeJinjaText(test_str_unicode)).encode('utf-8') == test_str_utf8
    assert to_unsafe_text

# Generated at 2022-06-23 14:46:06.177028
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():
    assert isinstance(AnsibleUnsafeBytes(b'string'), AnsibleUnsafeBytes)
    assert isinstance(AnsibleUnsafeBytes(b'\xc3\xb1'), AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:46:14.475083
# Unit test for constructor of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes():

    test_var = binary_type(b'Test')
    ansible_unsafe_bytes = AnsibleUnsafeBytes(test_var)

    # Verify that the class AnsibleUnsafeBytes exists and has the member attribute __UNSAFE__
    assert hasattr(ansible_unsafe_bytes, '__UNSAFE__')
    # Verify that the value of __UNSAFE__ is True
    assert ansible_unsafe_bytes.__UNSAFE__ == True
    # Verify that the value of ansible_unsafe_bytes is equal to test_var
    assert ansible_unsafe_bytes == test_var

# Generated at 2022-06-23 14:46:21.290421
# Unit test for function wrap_var
def test_wrap_var():
    assert wrap_var(None) is None
    assert isinstance(wrap_var(u'foo'), NativeJinjaUnsafeText)
    assert ansible_unsafe_proxy(u'foo') == wrap_var(u'foo')
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var({'foo': 'bar'}), dict)
    assert isinstance(wrap_var(['foo', 'bar']), list)
    assert isinstance(wrap_var(('foo', 'bar')), tuple)

# Generated at 2022-06-23 14:46:23.220340
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    # Create instance of class AnsibleUnsafe
    a = AnsibleUnsafe()
    assert(a.__UNSAFE__)

# Generated at 2022-06-23 14:46:25.408724
# Unit test for function to_unsafe_bytes
def test_to_unsafe_bytes():
    converted = to_unsafe_bytes(u'abc')
    assert isinstance(converted, AnsibleUnsafeBytes)



# Generated at 2022-06-23 14:46:28.940900
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    # Setup
    arg1 = AnsibleUnsafeBytes(b'abc')
    arg2 = AnsibleUnsafeBytes(b'abc')
    # Exercise
    s = arg1.decode(arg2)
    # Verify
    assert isinstance(s, AnsibleUnsafeText)


# Generated at 2022-06-23 14:46:40.911368
# Unit test for function to_unsafe_text
def test_to_unsafe_text():

    # Create a dictionary to be encoded
    test1 = {
        'k1': 'v1',
        'k2': 'v2',
        'k3': ['v3_1', 'v3_2', 'v3_3']
    }
    # Encode and decode the dictionary
    encoded = to_unsafe_text(test1)
    decoded = encoded.decode('utf-8')

    # Check the type is AnsibleUnsafeText
    assert isinstance(encoded, AnsibleUnsafeText)
    assert isinstance(encoded, str)
    assert isinstance(decoded, AnsibleUnsafeText)
    assert isinstance(decoded, str)

    # Check the value of the dictionaries

# Generated at 2022-06-23 14:46:49.053389
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    assert isinstance(NativeJinjaUnsafeText(b'foo'), NativeJinjaUnsafeText) == True
    assert isinstance(NativeJinjaUnsafeText(u'foo'), NativeJinjaUnsafeText) == True
    assert NativeJinjaUnsafeText(u'foo') == u'foo'
    assert NativeJinjaUnsafeText(b'foo') == u'foo'
    assert not isinstance(NativeJinjaUnsafeText(u'foo'), AnsibleUnsafeBytes)
    assert not isinstance(NativeJinjaUnsafeText(u'foo'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:46:54.645303
# Unit test for function to_unsafe_text
def test_to_unsafe_text():
    assert isinstance(to_unsafe_text(u'\u00e9'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'\xc3\xa9'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(u'abc'), AnsibleUnsafeText)
    assert isinstance(to_unsafe_text(b'asdf'), AnsibleUnsafeText)

# Generated at 2022-06-23 14:47:01.054689
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    # Test the encode method of the AnsibleUnsafeText class
    try:
        test_str = 'hello world'
        utest = AnsibleUnsafeText(test_str)
        btest = utest.encode('utf-8')
        assert(btest == test_str.encode('utf-8'))
    except:
        raise
    return True



# Generated at 2022-06-23 14:47:08.824184
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    d = dict
    l = list
    t = tuple
    from ansible.utils.unsafe_proxy import UnsafeProxy

    assert isinstance(UnsafeProxy(d({'a': 'b'})), dict)
    assert isinstance(UnsafeProxy(d), type)
    assert isinstance(UnsafeProxy(d({'a': 'b'})), dict)
    assert isinstance(UnsafeProxy(d), type)
    assert isinstance(UnsafeProxy(l(['a', 'b'])), list)
    assert isinstance(UnsafeProxy(l), type)
    assert isinstance(UnsafeProxy(t(['a', 'b'])), tuple)
    assert isinstance(UnsafeProxy(t), type)
    assert UnsafeProxy(u'a') == 'a'

# Generated at 2022-06-23 14:47:12.726038
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    x = AnsibleUnsafeText('hello world')
    xb = to_unsafe_bytes('hello world')
    assert isinstance(x.encode(), AnsibleUnsafeBytes)
    assert x.encode() == xb



# Generated at 2022-06-23 14:47:25.054992
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    from ansible.utils.display import Display
    Display().deprecated = lambda *args, **kwargs: None

    assert UnsafeProxy(None) is None
    assert UnsafeProxy(u'') == u''
    assert type(UnsafeProxy('Test')) == AnsibleUnsafeText
    assert type(UnsafeProxy(u'Test')) == AnsibleUnsafeText
    assert type(UnsafeProxy(b'Test')) == AnsibleUnsafeBytes
    assert UnsafeProxy(b'Test').decode() == 'Test'
    assert type(UnsafeProxy(AnsibleUnsafeBytes(b'Test'))) == AnsibleUnsafeBytes
    assert type(UnsafeProxy(AnsibleUnsafeText('Test'))) == AnsibleUnsafeText
    assert UnsafeProxy(AnsibleUnsafeBytes(b'Test')).decode

# Generated at 2022-06-23 14:47:26.762784
# Unit test for method decode of class AnsibleUnsafeBytes
def test_AnsibleUnsafeBytes_decode():
    assert isinstance(AnsibleUnsafeBytes('123').decode(), AnsibleUnsafeText)



# Generated at 2022-06-23 14:47:31.504599
# Unit test for method encode of class AnsibleUnsafeText
def test_AnsibleUnsafeText_encode():
    from ansible.module_utils._text import to_bytes, to_text

    unsafe_text = u'hello\uFFFD'
    unsafe_text = AnsibleUnsafeText(unsafe_text)
    text_bytes = to_bytes(unsafe_text)
    assert isinstance(text_bytes, AnsibleUnsafeBytes)


# Generated at 2022-06-23 14:47:37.258849
# Unit test for constructor of class NativeJinjaUnsafeText
def test_NativeJinjaUnsafeText():
    test_cases = [
        "{% set a = '<a href=\"x' %}<a href=\"x\">",
        "{% set a = 2 %}2",
        "{{ ['<g>'] | last }}<g>",
        "{% if ['<z>'] | count == 1 %}<z>{% endif %}<z>"
    ]
    for test_case in test_cases:
        assert NativeJinjaUnsafeText(test_case).__UNSAFE__ == True

# Generated at 2022-06-23 14:47:38.464685
# Unit test for constructor of class AnsibleUnsafe
def test_AnsibleUnsafe():
    assert AnsibleUnsafe()

# Generated at 2022-06-23 14:47:49.959277
# Unit test for function wrap_var
def test_wrap_var():
    from ansible.module_utils._text import to_text
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(None), AnsibleUnsafe)
    assert isinstance(wrap_var(AnsibleUnsafeBytes(b'hello')), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(AnsibleUnsafeText(u'hello')), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'hello'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var(u'hello'), AnsibleUnsafeText)
    assert isinstance(wrap_var(NativeJinjaText(u'hello')), NativeJinjaUnsafeText)
    assert isinstance(wrap_var(dict(a='hello', b=dict(c=5))), dict)

# Generated at 2022-06-23 14:47:55.939858
# Unit test for function wrap_var
def test_wrap_var():
    assert isinstance(wrap_var(None), type(None))
    assert isinstance(wrap_var(u'foo'), AnsibleUnsafeText)
    assert isinstance(wrap_var(b'foo'), AnsibleUnsafeBytes)
    assert isinstance(wrap_var([b'foo']), list)
    assert isinstance(wrap_var([b'foo'])[0], AnsibleUnsafeBytes)
    assert isinstance(wrap_var((b'foo')), tuple)
    assert isinstance(wrap_var((b'foo'))[0], AnsibleUnsafeBytes)

# Generated at 2022-06-23 14:48:02.522190
# Unit test for method __new__ of class UnsafeProxy
def test_UnsafeProxy___new__():
    class Res:
        def __init__(self, var):
            self.var = var
    result = UnsafeProxy(Res('AnsibleUnsafe'))
    assert result.__class__.__name__ == 'Res'
    assert result.__class__.__module__ == '__main__'
    assert result.var == 'AnsibleUnsafe'
