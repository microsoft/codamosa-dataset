

# Generated at 2022-06-21 00:12:28.329372
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    assert Block.__repr__ == object.__repr__

# Generated at 2022-06-21 00:12:32.472300
# Unit test for method serialize of class Block
def test_Block_serialize():
    import ansible.playbook.role
    play = ansible.playbook.Play()
    block = Block(play=play)
    data = block.serialize()
    block_new = Block()
    block_new.deserialize(data)
    assert block_new.serialize() == data


# Generated at 2022-06-21 00:12:40.289241
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    host = MagicMock()
    task = Task()
    task._role = Role()
    task._variable_manager = VariableManager()
    task.block = []
    task.rescue = []
    task.always = []
    task._loader = None
    task._play = Play()
    task._block = Task()
    task._role = Task()
    task.block = Task()
    task.rescue = Task()
    task.always = Task()
    task.tags = []
    task.when = []
    task.register = []
    task.ignore_errors = None
    task.any_errors_fatal = None
    task.delegate_to = None
    task.transport = None
    task.notify = []
    task.first_available_file = None
    task.until = []
    task

# Generated at 2022-06-21 00:12:48.179930
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    p = Play()
    block = Block.load(dict(block=dict(tasks=dict(name='ok', register='ok_var'))), play=p, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert block.block[0].name == 'ok'
    assert block.block[0].action == 'ok'


# Generated at 2022-06-21 00:12:58.300698
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():

    # Playbook block tests
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False)
    assert block.all_parents_static() == True, "Expected True"
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False)
    block.statically_loaded = False
    assert block.all_parents_static() == True, "Expected True"
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False)
    block.statically_loaded = False
    block2 = Block(play=None, parent_block=block, role=None, task_include=None, use_handlers=False)
   

# Generated at 2022-06-21 00:13:05.390297
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    h = 'localhost'
    t = Task()
    a = ActionBase()
    block = Block(task_include=t, parent_block=a)
    if block.__ne__('') != NotImplemented:
        raise AssertionError()
    block.block=[h] 
    if block.__ne__(block) is not False:
        raise AssertionError()

# Generated at 2022-06-21 00:13:09.487052
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block(
        loader=True,
        parent_block=True,
        role=True,
        use_handlers=True,
    )
    b.set_loader(
        loader=True
    )

# Generated at 2022-06-21 00:13:10.959488
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    test = Block()
    print(test)

# Generated at 2022-06-21 00:13:21.619791
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    class AnsibleModuleMock:
        def __init__(self, argument_spec):
            self.params = None
    class BlockMock:
        def __init__(self):
            self._module = AnsibleModuleMock(argument_spec={})
        def run(self, **kwargs):
            pass
    block = BlockMock()
    assert block.has_tasks() == False

    class BlockMock:
        def __init__(self):
            self._module = AnsibleModuleMock(argument_spec={})
            self.block = [1]
            self.rescue = []
            self.always = []
        def run(self, **kwargs):
            pass
    block = BlockMock()
    assert block.has_tasks() == True


# Generated at 2022-06-21 00:13:29.297745
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    # Block(play, ds, parent_block, role, task_include, use_handlers, implicit)
    b1 = Block(play={}, parent_block={}, role={}, task_include={}, use_handlers={}, implicit={})
    b2 = Block(play={}, parent_block={}, role={}, task_include={}, use_handlers={}, implicit={})
    b3 = Block(play={}, parent_block={}, role={}, task_include={}, use_handlers={}, implicit={})
    assert b1 != b2
    assert b2 != b1
    assert b1 != b3
    assert b3 != b1
    assert b2 != b3
    assert b3 != b2


# Generated at 2022-06-21 00:14:23.824663
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block = Block(str({"fake":("val1")}))
    with pytest.raises(AnsibleParserError) as e:
        block.__repr__()


# Generated at 2022-06-21 00:14:27.334615
# Unit test for method __repr__ of class Block
def test_Block___repr__():
  block = Block()
  repr_block = repr(block)
  assert repr_block == "Block()"

test_Block___repr__()

# Generated at 2022-06-21 00:14:28.514504
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    pass


# Generated at 2022-06-21 00:14:31.528055
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    block1 = Block()
    block2 = Block()
    if (block1 == block2):
        raise Exception("block1 == block2")


# Generated at 2022-06-21 00:14:39.654059
# Unit test for method __eq__ of class Block

# Generated at 2022-06-21 00:14:51.785253
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.module_utils.six import PY3

    def test_fun(name, parent, dep_chain, expect_dep_chain):
        if not PY3:
            # Python 2.6 can't handle unicode characters in method names
            name = name.encode('utf-8')

# Generated at 2022-06-21 00:15:02.454982
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    b = Block(name='test', default_args={'x': 1}, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    b.preprocess_data([])
    assert b.block == ['test']
    b.preprocess_data(['test'])
    assert b.block == ['test']
    b.preprocess_data({'block': [{'action': {'module': 'debug', 'args': {'x': 11, 'y': 22}}}]})
    assert b.block == [{'action': {'module': 'debug', 'args': {'x': 11, 'y': 22}}}]
    b.preprocess_data({})
    assert b.block == ['test']
    # TODO: raise an error if the specified task

# Generated at 2022-06-21 00:15:13.368297
# Unit test for method serialize of class Block
def test_Block_serialize():
    data = {'block': [{'tasks': [{'action': {'module': 'ping'}}]}]}
    loader = DataLoader()
    play = Play()
    play._loader = loader
    play._variable_manager = VariableManager()
    result = Block.load(data, play=play)

# Generated at 2022-06-21 00:15:23.825249
# Unit test for method load of class Block
def test_Block_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    my_vars = dict(foo='FOO',
                   bar='BAR',
                   baz='BAZ',
                   bam='BAM')

    Options = namedtuple('Options',
                        ['connection',
                         'module_path',
                         'forks',
                         'become',
                         'become_method',
                         'become_user',
                         'check',
                         'listhosts',
                         'listtasks',
                         'listtags',
                         'syntax',
                         'sudo_user',
                         'sudo',
                         'diff'])

# Generated at 2022-06-21 00:15:28.446970
# Unit test for method serialize of class Block
def test_Block_serialize():
    data = {'block': 'test', 'rescue': 'test', 'always': 'test', 'dep_chain': 'test', 'role': 'test', 'parent': 'test', 'parent_type': 'test'}
    b = Block(implicit=True)
    b.deserialize(data)
    res = b.serialize()
    assert data == res
    return True


# Generated at 2022-06-21 00:16:02.366904
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    # Test case 1:
    # Test if the method get_first_parent_include returns the first TaskInclude parent of the block
    #       if the parent of this block is not a TaskInclude

    # Test setup:
    b = Block()
    b._parent = None
    # Test execution:
    assert b.get_first_parent_include() == None

    # Test case 2:
    # Test if the method get_first_parent_include returns the first TaskInclude parent of the block
    #       if the parent of this block is a TaskInclude

    # Test setup:
    b = Block()
    ti = TaskInclude()
    ti._parent = None
    b._parent = ti
    # Test execution:
    assert b.get_first_parent_include() == ti

    # Test case 3:
    # Test if

# Generated at 2022-06-21 00:16:03.215219
# Unit test for method copy of class Block
def test_Block_copy():
    obj = Block()
    assert isinstance(obj.copy(), Block)


# Generated at 2022-06-21 00:16:12.332480
# Unit test for method filter_tagged_tasks of class Block

# Generated at 2022-06-21 00:16:22.959572
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    '''
    Make sure calling Block.__eq__ doesn't throw an exception.
    '''

    # Set up a Block object
    block_obj1 = Block(play=play_context.PlayContext._play, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=None)

    # Create another Block object
    block_obj2 = Block(play=play_context.PlayContext._play, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=None)

    # Call Block.__eq__ and make sure it doesn't throw an exception
    block_obj1.__eq__(block_obj2)

# Generated at 2022-06-21 00:16:25.364680
# Unit test for method is_block of class Block
def test_Block_is_block():
    '''
    Test of method is_block of class Block
    '''

# Generated at 2022-06-21 00:16:36.783266
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block._attributes = {"depth": 0}
    block.block = [Sentinel]
    block.rescue = None
    block.always = None
    block._ds = ''
    block._valid_attrs = {}
    block._play = Play()
    block._play._attributes = {}
    block._play.roles = [Sentinel]
    block._play.tasks = None
    block._play._loader = DataLoader()
    block._play.hosts = '127.0.0.1'
    block._play.handlers = []
    block._play.name = 'test'
    block._play.connection = 'local'
    block._play.gather_facts = 'no'
    block._play._variable_manager = VariableManager()
    block._play._variable_manager._fact

# Generated at 2022-06-21 00:16:40.274031
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    TaskInclude = TaskInclude_class
    my_block = Block()
    my_taskinclude = TaskInclude()
    my_block._parent = my_taskinclude
    my_taskinclude._parent = Block()
    taskinclude = my_block.get_first_parent_include()
    assert isinstance(taskinclude, TaskInclude_class)
 # End unit test for method get_first_parent_include of class Block


# Generated at 2022-06-21 00:16:47.761407
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    b1 = Block()
    assert b1.all_parents_static() == True
    b2 = Block(parent=b1)
    assert b2.all_parents_static() == True
    t1 = TaskInclude(statically_loaded=False, parent=b2)
    assert t1.all_parents_static() == False
    b3 = Block(parent=t1)
    assert b3.all_parents_static() == False
    assert t1.all_parents_static() == False

# Generated at 2022-06-21 00:16:52.859794
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block(use_handlers=False, variable_manager=None, loader=None)
    d = {'block': {}, 'rescue': {}, 'always': {}}
    b.load_data(d)
    b.set_loader('loader')
    assert b._loader == 'loader'



# Generated at 2022-06-21 00:16:53.831890
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block = Block()
    assert str(block) == "<task @(block:1)>"


# Generated at 2022-06-21 00:17:16.778395
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    pass

# Generated at 2022-06-21 00:17:24.945011
# Unit test for method filter_tagged_tasks of class Block

# Generated at 2022-06-21 00:17:32.951094
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    # Test no parent is present
    b = Block()
    assert b.get_first_parent_include() == None

    # Test parent is a block
    b = Block()
    assert b.get_first_parent_include() == None

    # Test parent is a task
    b = Block()
    assert b.get_first_parent_include() == None

    # Task parent is a Task Include
    b = Block()
    assert b.get_first_parent_include() == None


# Generated at 2022-06-21 00:17:39.555950
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    block_1 = Block()
    block_2 = Block()
    # Try with different blocks
    assert block_1 != block_2
    # Try with same instance but different role
    block_2 = block_1
    block_2._role = Role()
    assert block_1 != block_2
    # Try with same instance and same role
    block_1._role = block_2._role
    assert block_1 == block_2


# Generated at 2022-06-21 00:17:48.193597
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    fake_task_ds = ('fake_module', 'fake_args', 'fake_action', 'fake_name', 'fake_delegate_to', 'fake_register', 'fake_notify',
                    'fake_become', 'fake_become_method', 'fake_become_user', 'fake_check_mode', 'fake_tags')

# Generated at 2022-06-21 00:18:00.739346
# Unit test for constructor of class Block
def test_Block():
    # Test with empty data
    try:
        Block(play=None, parent_block=None, role=None, task_include=None).load_data(None)
        assert False
    except AnsibleParserError:
        pass

    # Test with empty yaml data
    try:
        Block(play=None, parent_block=None, role=None, task_include=None).load_data("")
        assert False
    except AnsibleParserError:
        pass

    # Test with invalid yaml data
    try:
        Block(play=None, parent_block=None, role=None, task_include=None).load_data("{'test'}")
        assert False
    except AnsibleParserError:
        pass

    # Test with non-dictionary

# Generated at 2022-06-21 00:18:06.555343
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block()
    b.set_loader(None)
    b.set_loader('')
    b.set_loader(u'')
    b.set_loader({})
    b.set_loader([])
    b.set_loader(())
    b.set_loader(1)
    b.set_loader(0.0)


# Generated at 2022-06-21 00:18:11.359587
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1]
    assert block.has_tasks() == True
    block.block = []
    block.always = [1]
    assert block.has_tasks() == True
    block.always = []
    block.rescue = [1]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False



# Generated at 2022-06-21 00:18:13.848079
# Unit test for constructor of class Block
def test_Block():
    b = Block()
    assert b.block is None
    assert b.rescue is None
    assert b.always is None
    assert b._play is None
    assert b._role is None
    assert b._parent is None
    assert b._dep_chain is None

# Generated at 2022-06-21 00:18:26.834637
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    '''
      Unit test for method get_include_params of class Block
    '''
    def _setup_args(args=None, task_args=None, role_args=None, play_args=None):
        class Include:
            def __init__(self, args_dict):
                for k, v in args_dict.iteritems():
                    setattr(self, k, v)

        args = Include(args or dict())
        args.task_include = Include(task_args or dict())
        args.task_include.role = Include(role_args or dict())
        args.task_include.play = Include(play_args or dict())

        return args

    class _VarsModule(object):
        def __init__(self, hostvars=None):
            self.hostvars = hostvars


# Generated at 2022-06-21 00:19:14.739342
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
  print("down")

  # Case 1
  b = Block()
  assert b.get_dep_chain() == None

  # Case 2
  b = Block()
  b._dep_chain = [1, 2, 3]
  assert b.get_dep_chain() == [1, 2, 3]

  print("up")


# Generated at 2022-06-21 00:19:16.487999
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block = Block()
    string = repr(block)
    assert string
    assert type(string)== str

# Generated at 2022-06-21 00:19:21.435905
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block()
    assert not b.has_tasks()
    b.block = [1]
    assert b.has_tasks()
    b.block = []
    b.rescue = [1]
    assert b.has_tasks()
    b.rescue = []
    b.always = [1]
    assert b.has_tasks()
    b.rescue = [1]
    assert b.has_tasks()



# Generated at 2022-06-21 00:19:23.378156
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    pass


# Generated at 2022-06-21 00:19:24.324969
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    pass


# Generated at 2022-06-21 00:19:27.841846
# Unit test for method load of class Block
def test_Block_load():
  '''
  Unit test for method load of class Block
  '''
  # create an instance of class Block with specifed args
  b = Block(play='play')
  # load an instance of class Block
  b.load(ds='ds')


# Generated at 2022-06-21 00:19:37.917227
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Implicit task
    task1 = Task(action='setup', implicit=True)
    task2 = Task(action='debug')
    task3 = Task(action='debug')
    task4 = Task(action='debug')
    task5 = Task(action='debug')
    task6 = Task(action='debug')
    task7 = Task(action='debug')
    task8 = Task(action='debug')
    task9 = Task(action='debug')
    task10 = Task(action='debug')
    task11 = Task(action='debug')
    task12 = Task(action='debug')
    task13 = Task(action='debug')
    task14 = Task(action='debug')

    # Include tasks that should be filtered out by the filter_tagged_tasks method

# Generated at 2022-06-21 00:19:44.914564
# Unit test for method serialize of class Block
def test_Block_serialize():
    block = Block()
    assert block.serialize() == {'always': None, 'block': None, 'dep_chain': None, 'name': None, 'rescue': None, '_attributes': {}, 'when': None}
    block = Block(name='test_name')
    assert block.serialize() == {'always': None, 'block': None, 'dep_chain': None, 'name': 'test_name', 'rescue': None, '_attributes': {}, 'when': None}


# Generated at 2022-06-21 00:19:46.145956
# Unit test for method serialize of class Block
def test_Block_serialize():
    block = Block()
    block.serialize()

# Generated at 2022-06-21 00:19:54.477922
# Unit test for constructor of class Block
def test_Block():
    # for valid_attrs validation
    from ansible.playbook.base import Base
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False)
    block.validate()
    fields_block = vars(block)
    fields_base = vars(Base())
    block_difference = set(fields_block.keys()).difference(fields_base.keys())
    base_difference = set(fields_base.keys()).difference(fields_block.keys())
    assert not base_difference, 'There are some unexpected fields in the Block class: {0}'.format(','.join(base_difference))

# Generated at 2022-06-21 00:21:01.210883
# Unit test for method load of class Block
def test_Block_load():
  inp = """
- name: Debug
  debug:
    msg: "{{ var }}"
  block:
- name: Inner debug
  debug:
    msg: "Hi"
  rescue:
- name: Inner debug 2
  debug:
    msg: "Hi"
  always:
- name: Inner debug 3
  debug:
    msg: "Hi"
- name: Inner debug 4
  debug:
    msg: "Hi"
  rescue:
  - name: Inner debug 5
    debug:
      msg: "Hi"
  always:
  - name: Inner debug 6
    debug:
      msg: "Hi"
  - name: Inner debug 7
    debug:
      msg: "Hi"
- name: Inner debug 8
  debug:
    msg: "Hi"
"""

# Generated at 2022-06-21 00:21:08.346265
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Create an instance of Block
    block = Block()
    # Implictly make _dep_chain instance variable Sentinel
    assert_equals(block._dep_chain, Sentinel)

    block.set_loader(None)
    assert_equals(block._dep_chain, Sentinel)
    assert_equals(block.get_dep_chain(), None)

    # Now set instance variable _dep_chain to be a list
    block._dep_chain = list()
    assert_equals(block._dep_chain, [])
    assert_equals(block.get_dep_chain(), [])



# Generated at 2022-06-21 00:21:20.368076
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [{"key": "value"}]
    block.rescue = [{"key": "value"}]
    block.always = [{"key": "value"}]

    new_block = block.copy()

    assert new_block.block is not None
    assert new_block.rescue is not None
    assert new_block.always is not None
    assert new_block.block != [{"key": "value"}]
    assert new_block.rescue != [{"key": "value"}]
    assert new_block.always != [{"key": "value"}]

    assert new_block.block[0].parent is new_block
    assert new_block.rescue[0].parent is new_block
    assert new_block.always[0].parent is new_block

    assert new_block

# Generated at 2022-06-21 00:21:21.562066
# Unit test for constructor of class Block
def test_Block():
    b = Block()
    assert b is not None

# Generated at 2022-06-21 00:21:27.690646
# Unit test for method copy of class Block
def test_Block_copy():
    """
    Block.copy(exclude_parent=False, exclude_tasks=False)
    """

    # instantiate
    class_ = Block

    # setup
    exclude_parent = False
    exclude_tasks = True

    # expected
    expected = "dupe"

    # run
    actual = class_.copy(exclude_parent, exclude_tasks)

    # assert
    assert expected == actual

