

# Generated at 2022-06-21 00:11:59.079733
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    pass


# Generated at 2022-06-21 00:12:09.002574
# Unit test for method load of class Block
def test_Block_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.common import cmd_quote
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    import ansible.constants as C
    import os
    data = dict(
        block=[
            dict(
            ),
            dict(
            ),
        ],
    )

# Generated at 2022-06-21 00:12:10.102689
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block()
    assert b.has_tasks() == True


# Generated at 2022-06-21 00:12:13.479583
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # We instantiate a Block object
    b = Block()
    # Now we serialize it
    data = b.serialize()
    # We instantiate a Block object
    b = Block()
    # We deserialize it
    b.deserialize(data)



# Generated at 2022-06-21 00:12:20.100145
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    test_block = Block(implicit=False)
    var_manager = VariableManager()
    loader = DataLoader()
    test_block.set_loader(loader)
    test_block._variable_manager = var_manager
    test_block._ds = {}
    test_block._attributes = test_block._load_attrs(test_block._ds)
    test_block.post_validate(templar=None, shared_loader_obj=None)
    result = test_block.get_dep_chain()
    assert result == None


# Generated at 2022-06-21 00:12:23.304711
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False)
    assert block.__ne__(None) is True


# Generated at 2022-06-21 00:12:33.951120
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    print("---------- test_Block_preprocess_data start ------------")

    # Implicit block
    data = dict(name="Test")
    b = Block()
    new_data = b.preprocess_data(data)
    assert new_data == dict(block=[data])

    # Explicit block
    data = dict(block=[dict(name="Test")])
    b = Block()
    new_data = b.preprocess_data(data)
    assert new_data == data

    # Explicit block with implicit children
    data = dict(block=[dict(name="Test"), dict(name="Test2")])
    b = Block()
    new_data = b.preprocess_data(data)
    assert new_data == data

    # Implicit block with explicit children

# Generated at 2022-06-21 00:12:35.259139
# Unit test for method load of class Block

# Generated at 2022-06-21 00:12:36.835467
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    loader = MagicMock()
    block.set_loader(loader)


# Generated at 2022-06-21 00:12:39.291452
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False)
    assert block.get_dep_chain() is None


# Generated at 2022-06-21 00:13:39.803778
# Unit test for method is_block of class Block
def test_Block_is_block():
    TEST_1 = {
        "block": [
            {"debug":{"msg":"Hello World!"}},
            {"debug":{"msg":"'This is {{ ansible_hostname }} speaking'"}},
            {"debug":{"msg":"This is something else"}}
        ],
        "rescue": [
            {
                "debug":{"msg":"ERROR: something has gone wrong"}
            }
        ],
        "always": [
            {"debug":{"msg":"'Always something else'"}}
        ]
    }
    assert Block.is_block(TEST_1)
    assert Block.is_block({})
    assert not Block.is_block(None)
    assert not Block.is_block([])

# Generated at 2022-06-21 00:13:47.488209
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    import sys
    import inspect

    # when method is the first line of a class
    lines = inspect.getsourcelines(Block.get_first_parent_include)[0]
    assert lines[0] == '    def get_first_parent_include(self):\n'
    # Check indentation
    assert all(len(line) - len(line.lstrip(' ')) == 4 for line in lines[1:])

    # when method is not the first line of a class
    lines = inspect.getsourcelines(Block.set_loader)[0]
    assert lines[0] == '    def set_loader(self, loader):\n'
    # Check indentation
    assert all(len(line) - len(line.lstrip(' ')) == 4 for line in lines[1:])



# Generated at 2022-06-21 00:13:52.302457
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    b = Block()
    p = Block(statically_loaded=False)
    b._parent = p

    assert b.all_parents_static() == False

# Generated at 2022-06-21 00:13:58.314632
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    '''
    ensure the __ne__ method works properly in the case of Block object
    '''
    block = Block(parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    block1 = Block(parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    assert block != block1


# Generated at 2022-06-21 00:14:08.310545
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    ds = {}
    # Case 1 : An implicit block with single task
    ds = [{'action': 'fail', 'msg': 'Single task'}]
    data = Block.load(ds)
    assert data.get_dep_chain() == None

    # Case 2 : A block with one task
    ds = {'block': [{'action': 'fail', 'msg': 'In block'}]}
    data = Block.load(ds)
    assert data.get_dep_chain() == None

    # Case 3 : A task with one dependency
    ds = {'block': [{'name': 'TaskOne', 'action': 'fail', 'msg': 'TaskOne'}],
          'rescue': [{'name': 'TaskTwo', 'action': 'fail', 'msg': 'TaskTwo'}]}
    data

# Generated at 2022-06-21 00:14:16.380653
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins import loader as plugin_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from io import StringIO
    loader = DataLoader()
    options

# Generated at 2022-06-21 00:14:29.679479
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    # Block created with parameters:
    #   _attributes: {'block': [], 'rescue': [], 'always': []}
    #   _use_handlers: True
    #   _implicit: False
    #   _statically_loaded: True
    #   _dep_chain: None
    #   _parent: None
    #   _role: None
    #   _play: None
    #   _loader: None
    #   _variable_manager: None
    obj = Block()

    # If a valid object not is an instance of Block, the method __eq__ returns False
    obj1 = object()
    assert not (obj == obj1)

    # If a valid object is an instance of Block but with a different value of the _attributes attribute, the method __eq__ returns False
    obj1 = Block()
   

# Generated at 2022-06-21 00:14:37.368817
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    set_fact_task = {u'name': u'set_fact', u'from_task': u'set_fact', u'action': u'set_fact', u'from_action': u'set_fact', u'from_the_task': u'set_fact', u'cacheable': True}
    set_fact_task['hosts'] = u'localhost'
    set_fact_task['args'] = {'var': u'var_test'}
    play_context = PlayContext()
    templar = Templar(play_context=play_context, loader=None, shared_loader_obj=None)

# Generated at 2022-06-21 00:14:44.639783
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # test_block is an instannce of class Block
    # test_task is an instannce of class Task
    test_block = Block()
    test_task = Task()
    test_block.block.append(test_task)
    test_block.block.append(test_block.copy(exclude_parent=True, exclude_tasks=True))
    assert test_block.filter_tagged_tasks([])

# Generated at 2022-06-21 00:14:56.345121
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from collections import namedtuple
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import Playbook
    
    Play = namedtuple('Play', ['context'])

    class my_task(object):
        def __init__(self, play):
            self._parent = None
            self.play = play

        def set_loader(self, loader):
            pass

        def get_dep_chain(self):
            return None

        def copy(self, exclude_parent=False, exclude_tasks=False):
            return self

        def serialize(self):
            pass

        def deserialize(self, data):
            pass


# Generated at 2022-06-21 00:15:23.471519
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    test_block = Block()
    test_block._play = Play()
    test_block._play.vars = dict(test_key='test_value')
    test_block._parent = TaskInclude()
    test_block._parent._parent = Block()
    test_block._parent._parent._parent = TaskInclude()
    test_block._parent._parent._parent._parent = Block()
    test_block._parent._parent._parent._parent._parent = TaskInclude()
    test_block._parent._parent._parent._parent._parent._parent = Host()
    assert test_block.get_include_params() == dict(test_key='test_value')


# Generated at 2022-06-21 00:15:26.585616
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    assert block.copy()
    assert block.copy(exclude_parent=True)
    assert block.copy(exclude_tasks=True)
    assert block.copy(exclude_parent=True, exclude_tasks=True)



# Generated at 2022-06-21 00:15:38.543140
# Unit test for method preprocess_data of class Block

# Generated at 2022-06-21 00:15:49.060749
# Unit test for method is_block of class Block

# Generated at 2022-06-21 00:16:01.277065
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import load_plugin_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.pb_base import PlaybookBase
    import os
    from ansible.module_utils.six import string_types


# Generated at 2022-06-21 00:16:08.965796
# Unit test for method __repr__ of class Block
def test_Block___repr__():

    from ansible.playbook.play_context import PlayContext

    with pytest.raises(AssertionError) as excinfo:
        Block(play=None, parent_block=None, role=None, task_include=None)
    assert excinfo.value.args[0] == 'a block must have a name'

    b = Block(play=None, parent_block=None, role=None, task_include=None, name="name")
    assert str(b) == "name()"
    assert b.__repr__() == "name()"



# Generated at 2022-06-21 00:16:15.261563
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    load_data = load_fixture('load_block_without_rescue_or_always.json')
    ds = load_data['datastructure']
    myplay = Play().load(ds[0], variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 00:16:16.240303
# Unit test for method copy of class Block
def test_Block_copy():
	pass

# Generated at 2022-06-21 00:16:28.819243
# Unit test for constructor of class Block
def test_Block():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # Try to create a block in the main playbook
    b = Block()
    assert b.block == None
    assert b.rescue == None
    assert b.always == None
    assert b.any_errors_fatal == None
    assert b.run_once == None
    assert b.delegate_to == None
    assert b.delegate_facts == None
    assert b.deprecated == None
    assert b.notify == []
    assert b.when == None
    assert b.tags == []
    assert b.register == None
    assert b._parent == None
    assert b._role == None
    assert b._dep_chain == None
    assert b._loop == None
    assert b._has_tasks == True



# Generated at 2022-06-21 00:16:35.188863
# Unit test for method is_block of class Block
def test_Block_is_block():
    # test valid inputs
    assert Block.is_block({"block": []})
    assert Block.is_block({"rescue": []})
    assert Block.is_block({"always": []})
    assert Block.is_block({"block": [], "rescue": [], "always": []})

    # test invalid inputs
    assert not Block.is_block({"name": "test", "not_block": []})


# Generated at 2022-06-21 00:17:19.036327
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.template import Templar
    
    # create block and define attribute block as a list of object Task and Handler
    block = Block()
    block.block = [Task(), Handler()]
    block.rescue = [Task(), Handler()]
    block.always = [Task(), Handler()]
    
    # create block with implicit value equals True
    block1 = Block(implicit=True)
    # reconfigure an attribute block in block1
    block1.block = [Task(), Handler()]
    
    # create object Play
    play = Play()
    # reconfigure an attribute_play in block
    block._play = play
    #

# Generated at 2022-06-21 00:17:29.012482
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    from ansible.playbook.base import Base
    # creating instance
    yaml_data = """
- hosts: 127.0.0.1
  connection: local
  vars:
    myvar: "value"
  become_user: root
"""
    data = yaml.load(yaml_data)
    my_obj = Block()
    my_obj.vars = Base().preprocess_data(data['vars'])
    ret = my_obj.preprocess_data(data)
    # Returns:
    # {'block': [{'hosts': '127.0.0.1', 'connection': 'local', 'vars': {'myvar': 'value'}, 'become_user': 'root'}]}

# Generated at 2022-06-21 00:17:32.001118
# Unit test for constructor of class Block
def test_Block():
    b = Block()

    assert b._attributes == dict()
    assert b._parent is None
    assert b._dep_chain is None
    assert b._role is None


# Generated at 2022-06-21 00:17:42.864882
# Unit test for method serialize of class Block
def test_Block_serialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook_include.safe_eval import generate_safe_eval_funcs
    from ansible.playbook.task_include import TaskInclude

    class objectview(object):
        def __init__(self, d):
            self.__dict__ = d

    def to_safe(expr, locals=None):
        if locals is None:
            locals = {}
        safe_globals = generate_safe_eval_funcs()
        safe_locals = {}
        for k,v in locals.items():
            safe_locals[k] = v
        return objectview(safe_globals)(expr, safe_locals)


# Generated at 2022-06-21 00:17:50.295155
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
	block = Block()

	##
	## --- Simple Task
	##
	data = dict(action='ping')
	assert block.preprocess_data(data) == dict(block=[dict(action='ping')]), 'Block.preprocess_data(data) failed'

	##
	## --- Simple Task in List
	##
	data = [ dict(action='ping') ]
	assert block.preprocess_data(data) == dict(block=[dict(action='ping')]), 'Block.preprocess_data(data) failed'

	##
	## --- List of Tasks in List
	##
	data = [ dict(action='ping'), dict(action='shell', args='echo "Hello World"') ]

# Generated at 2022-06-21 00:18:02.948065
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # create test class
    b = Block()

    # create test parent_include
    i = IncludeRole()
    i.vars = dict(var1=1)
    i.block = []
    i.statically_loaded = True
    i._parent = None
    i._role = None
    i._parent_role = None
    i._block = None
    i._dep_chain = None
    i._loader = None
    i._tqm = None
    i._variable_manager = None

    # create test Block for parent
    b_

# Generated at 2022-06-21 00:18:05.343242
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block()

# Generated at 2022-06-21 00:18:11.206279
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    assert_raises(AnsibleParserError, lambda: Block().deserialize({'always': {'tasks': [], 'rescue': [], 'when': 'yes'}}))
    assert_raises(AnsibleParserError, lambda: Block().deserialize({'block': {'tasks': [], 'rescue': [], 'when': 'yes'}}))
    assert_raises(AnsibleParserError, lambda: Block().deserialize({'rescue': {'tasks': [], 'always': [], 'when': 'yes'}}))


# Generated at 2022-06-21 00:18:16.964206
# Unit test for constructor of class Block
def test_Block():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    play_ds = dict(
        name="myplay",
        hosts='webservers',
        gather_facts='yes',
        tasks=[
            dict(action=dict(module='shell', args='ls')),
        ]
    )
    play = Play().load(play_ds, variable_manager=VariableManager(), loader=DataLoader())
    block = Block(play=play)
    assert len(block.block) == 1
    assert isinstance(block.block[0], Task)
    assert block.rescue == []
    assert block.always == []
    assert block.always

# Generated at 2022-06-21 00:18:29.314628
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    import json
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-21 00:19:13.261228
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    test_obj1 = Block()
    test_obj2 = Block()
    print('Testing method __eq__ of class Block...')
    print('Test Case 1:')
    print('Expected Output: True')
    print('Actual Output:', test_obj1 == test_obj2)
    test_obj2.when = 'x'
    print('Test Case 2:')
    print('Expected Output: False')
    print('Actual Output:', test_obj1 == test_obj2)
    test_obj2.when = False
    print('Test Case 3:')
    print('Expected Output: True')
    print('Actual Output:', test_obj1 == test_obj2)
    test_obj1.when = False
    print('Test Case 4:')
    print('Expected Output: True')
    print

# Generated at 2022-06-21 00:19:14.546666
# Unit test for constructor of class Block
def test_Block():
    block = Block()
    assert block



# Generated at 2022-06-21 00:19:22.722224
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = Block()
    block.block = None
    block.rescue = None
    block.always = None
    block._play = None
    block._use_handlers = None
    block._dep_chain = None
    block._parent = None
    block._role = None
    all_vars = {}
    filtered_block = block.filter_tagged_tasks(all_vars)
    assert filtered_block.block == None
    assert filtered_block.rescue == None
    assert filtered_block.always == None
    assert filtered_block._play == None
    assert filtered_block._use_handlers == None
    assert filtered_block._dep_chain == None
    assert filtered_block._parent == None
    assert filtered_block._role == None


# Generated at 2022-06-21 00:19:31.156353
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.base import Base
    t = TaskInclude('name', 'static', False, 'name', 'static', 'static', 'static', {}, None)
    b = Block(use_handlers=False, task_include=t, parent_block=t)
    expected_result = {'task': 'static', 'tasks': 'static', 'name': 'name'}
    assert b.get_include_params() == expected_result, 'Error in get_include_params of class Block'


# Generated at 2022-06-21 00:19:41.489145
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    hostvars = dict(magic='magic')
    play_context = PlayContext()
    play_context._set_variable_manager(VariableManager())
    play_context.variable_manager.set_host_variable(host='hostname', varname='hostvars', value=hostvars)
    play_context.variable_manager.set_host_variable(host='hostname', varname='magic', value='magic')
    block_loader = DataLoader()
    inventory = Inventory(block_loader)


# Generated at 2022-06-21 00:19:51.545590
# Unit test for method load of class Block
def test_Block_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    data_loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(data_loader, variable_manager, 'localhost')
    play_context = PlayContext(variable_manager=variable_manager, loader=data_loader)

# Generated at 2022-06-21 00:19:53.136039
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    b = Block()
    assert b.get_dep_chain() is None


# Generated at 2022-06-21 00:19:58.109871
# Unit test for method is_block of class Block
def test_Block_is_block():
    
    data = {'block': [], 'rescue': [], 'always': []}
    is_block = Block.is_block(data)
    assert is_block == True

    data = None
    is_block = Block.is_block(data)
    assert is_block == False


# Generated at 2022-06-21 00:20:00.252698
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block()
    l = DictDataLoader({})
    b.set_loader(l)


# Generated at 2022-06-21 00:20:01.314478
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    raise NotImplementedError


# Generated at 2022-06-21 00:20:47.499026
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task import Task
    from ansible.errors import AnsibleParserError
    from ansible.executor.task_result import TaskResult
    from collections import MutableMapping
    import json
    import yaml
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    add_all_plugin_dirs()

    ######################################################################
    # Test set_loader without loader and without _loader
    ######################################################################
    b = Block()
    b.set_loader(loader)

    ######################################################################
    # Test set_loader without loader and with _loader
    ######################################################################
    b = Block()
    loader._loader = 'some other loader'
    b

# Generated at 2022-06-21 00:20:53.827455
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    class TestBlock():
        def __init__(self, d1):
            self._attributes = dict()
            self._attributes['name'] = d1
        def __ne__(self, other):
            return self._attributes['name'] != other._attributes['name']

    b1 = TestBlock(1)
    b2 = TestBlock(2)
    assert b1 != b2

# Generated at 2022-06-21 00:21:05.308250
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.parsing.yaml.objects import AnsibleMapping
    # a simple playbook with two plays
    # each has a single task with tags
    # each task is executed if all tags match

# Generated at 2022-06-21 00:21:15.534263
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    # sample role for testing
    test_role = AnsibleRole.load_from_file("/home/saurav/ansible-runner/test/integration/test_data/test_copy/roles/copyrole",
        playbook_path='/home/saurav/ansible-runner/test/integration/test_data/test_copy',
        config = dict(roles_path='/home/saurav/ansible-runner/test/integration/test_data/test_copy/roles')
    )
    assert test_role.get_include_params() == {'_raw_params': '', '_role_params': {}, '_tqm': None, '_variable_manager': None}


# Generated at 2022-06-21 00:21:26.775441
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    '''
    Test Task's filter_tagged_tasks
    '''
    # initialize a task object
    temp_task_object=Task()
    # initialize a Block object
    test_block_object=Block()  
    # creating a list of task objects
    temp_task_list=[temp_task_object]
    # assigning the list of task objects
    test_block_object.block=temp_task_list
    # creating a list of task objects
    temp_task_list=[temp_task_object]
    # assigning the list of task objects
    test_block_object.rescue=temp_task_list
    # creating a list of task objects
    temp_task_list=[temp_task_object]
    # assigning the list of task objects
    test_block_object.always=temp_task_list
    #