

# Generated at 2022-06-21 00:12:41.333642
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    host_list = ['localhost', '192.168.4.4']
    play_source = dict(
        name="Ansible Play",
        hosts=host_list,
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    print('play: %s' % play)

# Generated at 2022-06-21 00:12:55.210208
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    loader = DictDataLoader({})
    inventory = Inventory(loader=loader, variable_manager=VariableManager())
    variable_manager = inventory.get_variable_manager()
    variable_manager._extra_vars = load_extra_vars(loader=loader, options=None)
    variable_manager.set_inventory(inventory)
    path = 'ansible/playbooks/test.yml'

    play_source =  dict(
        name = "Ansible Play 0",
        hosts = 'mywebservers',
        gather_facts = 'no',
        tasks = [
            dict(name="task 0", setup = 'some_module')
        ]
    )

    b = Block.load(play_source, variable_manager=variable_manager, loader=loader)
    assert b.all_parents_static() is True


# Generated at 2022-06-21 00:12:58.340382
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    obj = Block()
    res = obj.get_include_params()
    assert res == {}, ('Unexpected result: %s' % res)
    print('Default object: ' + repr(obj))
    print('Default test: PASS')


# Generated at 2022-06-21 00:13:01.687423
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    block_1 = Block(implicit=False)
    block_2 = Block(implicit=False)
    assert block_1.__eq__(block_2)


# Generated at 2022-06-21 00:13:13.845230
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    # Arrange
    b1 = Block()
    b2 = Block()
    role1 = Role()
    role2 = Role()
    ti1 = TaskInclude()
    ti2 = TaskInclude()
    hti1 = HandlerTaskInclude()
    hti2 = HandlerTaskInclude()
    task1 = Task()
    task2 = Task()
    play1 = Play()
    play2 = Play()
    # Act:
    # Block1 --> Block2 --> Role1

# Generated at 2022-06-21 00:13:19.951296
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_obj = Block(1, 2, 3, 4, 5)
    data = '{"block": [], "rescue": [], "always": [], "loop": [], "until": "", "dep_chain": null, "role": null, "parent": null, "parent_type": null}'

    # Call method
    block_obj.deserialize(data)

    # assert the data is well serialized
    assert True


# Generated at 2022-06-21 00:13:23.834364
# Unit test for method get_vars of class Block
def test_Block_get_vars():
  play = fakes.FakePlay()
  block = Block(play, task_include=None)
  assert isinstance(block.get_vars(), dict)
  assert block.get_vars() == {'ansible_play_hosts': []}


# Generated at 2022-06-21 00:13:33.186390
# Unit test for method load of class Block
def test_Block_load():  # synced
    from ansible.playbook import Play
    pb = Play().load({
        'name': 'testing',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [{
            'block': [{
                'include': 'other'
            }]
        }]
    }, variable_manager=VariableManager(), loader=DictDataLoader())

    assert isinstance(pb._tasks[0], Block)
    assert isinstance(pb._tasks[0].block[0]._parent, Block)

    for item in pb.data.blocks:
        assert item['name'] == 'other'
        assert item['static'] is True

# Generated at 2022-06-21 00:13:43.940755
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():

    #Test scenario where there is no parent
    block = Block(block=[{"include": "testinclude_task.yml"}])
    assert block.get_first_parent_include() == None

    #Test scenario where parent is not a TaskInclude
    block_parent = Block()
    block = Block(block=[{"include": "testinclude_task.yml"}],parent=block_parent)
    assert block.get_first_parent_include() == None

    #Test scenario where parent is a TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader = None)

# Generated at 2022-06-21 00:13:56.216859
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    hosts = ['localhost']
    block_file = 'test_block.yml'
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=hosts)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
            name = "Ansible Play",
            hosts = hosts,
            gather_facts = 'no',
            vars = dict(
                msg_format="Hello {color} {env} World...")
            )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 00:14:13.625531
# Unit test for method serialize of class Block
def test_Block_serialize():
    '''
    Unit test for method serialize of class Block
    '''
    x = Block()
    x._attributes['block'] = {'tasks': [{'name': 'first task'},{'name': 'second task'}], 'rescue': []}
    x.serialize()



# Generated at 2022-06-21 00:14:26.728890
# Unit test for constructor of class Block
def test_Block():
    class TestBlock(Block):
        _valid_attrs = Block._valid_attrs.copy()
        _valid_attrs.update(dict(
            test1 = Attribute(isa='bool', default=False, immutable=True),
            test2 = Attribute(isa='string', default='default'),
            test3 = Attribute(isa='string', default='default2'),
            test4 = Attribute(isa='list', default=['default']),
        ))

    # No args
    b = TestBlock()
    assert b.test1 is False
    assert b.test2 == 'default'
    assert b.test3 == 'default2'

    # kwargs
    b = TestBlock(test1='true', test2='override', test4='notlist')
    assert b.test1 is True
    assert b.test

# Generated at 2022-06-21 00:14:28.351845
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b=Block()
    b.set_loader()
    

# Generated at 2022-06-21 00:14:30.560487
# Unit test for method serialize of class Block
def test_Block_serialize():
    block = Block()
    data = dict()
    assert block.serialize() == data


# Generated at 2022-06-21 00:14:37.767787
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    class TestBlock(Block):
        def __init__(self, parent):
            self._parent = parent
            self.statically_loaded = True

    class TestTaskInclude(TaskInclude):
        def __init__(self, parent):
            self._parent = parent
            self.statically_loaded = False

    block1 = TestBlock(None)
    block2 = TestBlock(block1)
    assert block2.all_parents_static()

    task_include = TestTaskInclude(block2)
    block3 = TestBlock(task_include)
    assert not block3.all_parents_static()

# unit test for method get_first_parent_include

# Generated at 2022-06-21 00:14:38.655603
# Unit test for method load of class Block
def test_Block_load():
    pass

# Generated at 2022-06-21 00:14:50.870507
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    b = Block()
    block_data = {"block": [{"set_fact": {"test1": "test2"}}], "always": [{"set_fact": {"test3": "test4"}}], "rescue": [{"set_fact": {"test5": "test6"}}], "_ansible_module_name": "set_fact", "_ansible_group_name": "command", "include": "test.yml", "tags": ["foo"], "when": "bar", "_ansible_line_number": 1}
    b.deserialize(block_data)
    assert b._attributes["block"][0].action == "set_fact"
    assert b.block[0].action == "set_fact"
    assert b.block[0].args["test1"] == "test2"
    assert b.module_name

# Generated at 2022-06-21 00:14:59.997599
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    include_params = dict(a="1", b="2")
    play = Block()
    role = Role()
    task_include = TaskInclude()
    block = Block()
    task_include.params = include_params
    role.block = play
    play._parent = task_include
    play.block = [block]
    block._parent = play
    assert block.get_include_params() == dict(a="1", b="2")



# Generated at 2022-06-21 00:15:02.235327
# Unit test for method set_loader of class Block
def test_Block_set_loader():
  data = dict()
  data['block'] = "block"
  block = Block(data=data)
  loader = DictDataLoader({})
  block.set_loader(loader)


# Generated at 2022-06-21 00:15:06.009970
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    block = Block()
    parent = Block()
    block._parent = parent
    assert block.get_include_params() == parent.get_include_params()
    from ansible.playbook.task_include import TaskInclude
    parent = TaskInclude()
    block._parent = parent
    assert block.get_include_params() == parent.get_include_params()



# Generated at 2022-06-21 00:15:38.637310
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    config_data={}
    config_data['DEFAULT_ROLES_PATH'] = '/etc/ansible/roles'
    config_data['DEFAULT_REMOTE_TMP'] = '/tmp/.ansible/tmp'
    config_data['DEFAULT_LOCAL_TMP'] = '/tmp/.ansible/tmp'
    config_data['DEFAULT_KEEP_REMOTE_FILES'] = False
    config_data['DEFAULT_SUDO'] = False
    config_data['DEFAULT_SUDO_USER'] = 'root'
    config_data['DEFAULT_SU'] = False
    config_data['DEFAULT_SU_USER'] = 'root'
    config_data['ANSIBLE_LIBRARY'] = []

# Generated at 2022-06-21 00:15:49.171128
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    a = Block()
    b = Block()
    b._parent = a
    c = Block()
    c._parent = b
    # method get_first_parent_include as no TaskInclude instance in the parent chain
    result = c.get_first_parent_include()
    # should be None
    assert result == None
    # add a TaskInclude instance (with the attribute 'statically_loaded' set to False) in the parent chain
    d = TaskInclude()
    d._parent = c
    d.statically_loaded = False
    # method get_first_parent_include now find a TaskInclude instance
    result = d.get_first_parent_include()
    # should be the TaskInclude

# Generated at 2022-06-21 00:16:01.332401
# Unit test for method deserialize of class Block

# Generated at 2022-06-21 00:16:11.302793
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    from ansible.playbook.task_include import TaskInclude

    # test case 1
    def test_data_1():
        data = dict(a=10, b=20, c=30)
        return data
    data_1 = test_data_1()
    block_1 = Block(task_include=TaskInclude())
    block_1.vars = data_1
    block_1.block = [{'a':1,'b':2,'c':3}]
    block_1.rescue = [{'a':1,'b':2,'c':3}]
    block_1.always = [{'a':1,'b':2,'c':3}]
    block_1.loop = [{'a':1,'b':2,'c':3}]

# Generated at 2022-06-21 00:16:17.988023
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    assert isinstance(block, Block)
    block_copy = block.copy(exclude_parent=False, exclude_tasks=False)
    assert isinstance(block, Block)
    assert block == block_copy
    assert block is not block_copy

# Generated at 2022-06-21 00:16:30.433089
# Unit test for method copy of class Block

# Generated at 2022-06-21 00:16:32.809874
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    loader = DictDataLoader({})
    block = Block()
    block.set_loader(loader)


# Generated at 2022-06-21 00:16:40.799160
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    block_obj = Block(statically_loaded=True)
    task_obj = Task(statically_loaded=True)
    task_include_obj = TaskInclude(statically_loaded=True)
    handler_obj = Handler(statically_loaded=True)
    block_obj._parent = task_obj
    task_obj._parent = task_include_obj
    task_include_obj._parent = handler_obj
    task_include_obj.vars = {'test_var': 'test_value'}
    assert(block_obj.get_include_params() == {'test_var': 'test_value'})



# Generated at 2022-06-21 00:16:44.632278
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block(loader=None, use_handlers=False, implicit=False, parent_block=None, role=None, task_include=None)
    b.set_loader(loader=None)
    

# Generated at 2022-06-21 00:16:52.860338
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    dep_chain = [Block(),Block()]
    dep_chain[0]._dep_chain = [Block(),Block()]
    dep_chain[1]._dep_chain = [Block(),Block()]
    
    block = Block(_dep_chain = [Block(),Block()])
    assert block.get_dep_chain() == None
    block = Block(dep_chain = dep_chain)
    assert block.get_dep_chain() == dep_chain
    block = Block()
    assert block.get_dep_chain() == None
    

# Generated at 2022-06-21 00:17:16.564132
# Unit test for method deserialize of class Block

# Generated at 2022-06-21 00:17:17.080368
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    pass

# Generated at 2022-06-21 00:17:18.818664
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    p=Block()
    assert(not p.get_first_parent_include())


# Generated at 2022-06-21 00:17:20.870967
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_instance = Block()
    block_instance.deserialize(data=None)
    # the source code is fine when data is None

# Generated at 2022-06-21 00:17:28.326187
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    play=dict()
    block=Block(play=play)

    if 1==1:
        block._attributes["block"]=[]
    else:
        block._attributes["block"]=[""]
    if 1==1:
        block._attributes["rescue"]=[]
    else:
        block._attributes["rescue"]=[""]
    if 1==1:
        block._attributes["always"]=[]
    else:
        block._attributes["always"]=[""]
    if block.has_tasks()==0:
        return True
    return False


# Generated at 2022-06-21 00:17:39.658576
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    """
    Test if the object representation is correct for __repr__ of class Block
    """
    # Values
    test_data = dict()
    test_data = {'block': None, 'rescue': None, 'always': None, 'tags': [], 'when': None, 'register': None, 'name': None, 'delegate_to': None, 'run_once': None, 'any_errors_fatal': None, 'changed_when': None, 'ignore_errors': None, 'stdin': None, 'stdout': None, 'stderr': None, 'local_action': None}
    test_block = Block(**test_data)
    result = test_block.__repr__()
    assert result == "<Block(name=None)>"


# Generated at 2022-06-21 00:17:41.490571
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block = Block()
    assert block.__repr__() == '<Block>'


# Generated at 2022-06-21 00:17:49.459070
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    import json
    # create a dummy block
    parent_block = Block()
    parent_block.block = []
    data_loader = DataLoader()
    result = parent_block.has_tasks()
    assert result == False
    # Create a block that contains a task
    block = Block()

# Generated at 2022-06-21 00:18:02.124580
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    # Test 1: Run without any parent.
    given_block = Block()
    expected_output = dict()
    actual_output = given_block.get_include_params()
    assert actual_output==expected_output
    # Test 2: Run with a specific parent.
    #Include class doesn't have any method get_include_params.
    #Hence, this class has a method _get_parent_include which will return its parent
    #on calling _get_parent_include method.
    given_include = Include()
    given_block = Block(parent_block=given_include)
    expected_output = 'parent'
    actual_output = given_block._get_parent_include()
    assert actual_output==expected_output
    # Test 3: Run with a specific ansible_facts
    #Ansible facts dont have any

# Generated at 2022-06-21 00:18:10.345495
# Unit test for constructor of class Block
def test_Block():
    play = Play.load({}, AnsibleOptions({'connection': 'local'}), VariableManager(), False, None)
    block = Block.load(
        dict(block=dict(
            tasks=[
                dict(action=dict(module='shell', args="echo hi")),
                dict(action=dict(module='debug', args=dict(msg='{{foo}}')))
            ]
            # ... other block arguments
        )),
        play=play,
        use_handlers=True,
        task_include=None,
        role=None,
        loader=None,
        variable_manager=None,
    )
    pass # stfu pylint

# Generated at 2022-06-21 00:18:30.717602
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    f = open('block.yml', 'r')
    d = yaml.safe_load(f)
    f.close()
    block = Block.load(d)
    try:
        block_str = str(block)
        assert block_str == "Block (name=None, block=1 tasks, rescue=[], always=[])"
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-21 00:18:42.250191
# Unit test for method is_block of class Block
def test_Block_is_block():
    bD1 = dict(block=["block1"])
    bD2 = dict(rescue=["rescue1"])
    bD3 = dict(always=["always1"])
    bD4 = dict(block=["block1"], rescue=["rescue1"], always=["always1"])
    assert(Block.is_block(bD1) is True)
    assert(Block.is_block(bD2) is True)
    assert(Block.is_block(bD3) is True)
    assert(Block.is_block(bD4) is True)
    assert(Block.is_block("block1") is False)
    assert(Block.is_block("block") is False)



# Generated at 2022-06-21 00:18:46.093917
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    print('Start of Unit test for method get_vars of class Block')
    # TODO: Add a test with code and examples
    print('End of Unit test for method get_vars of class Block')

# Generated at 2022-06-21 00:18:55.650656
# Unit test for method get_vars of class Block

# Generated at 2022-06-21 00:19:07.355444
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # create an instance of Block class
    block_obj = Block()

    # create an instance of Play class
    play_obj = Play()

    # create an instance of Role class
    role_obj = Role()

    # create an instance of IncludeFile class
    task_include_obj = IncludeFile()

    # create an instance of Host class
    host_obj = Host()

    # create an instance of VariableManager class
    variable_manager_obj = VariableManager()

    # create an instance of Loader class
    loader_obj = Loader()

    # invoke preprocess_data() method passing different arguments
    assert not block_obj.preprocess_data([]), "test_Block_preprocess_data() failed with above arguments"

    assert isinstance(block_obj.preprocess_data(dict(block=[])), dict)

    assert not block

# Generated at 2022-06-21 00:19:15.669951
# Unit test for constructor of class Block
def test_Block():
    '''
    Basic sanity test for constructor of class Block
    '''

    # Create a block
    block = Block()

    # Test the implicit_inherit attribute of the block
    assert block.implicit_inherit is True
    block.implicit_inherit = False
    assert block.implicit_inherit is False

    # Test the always_run attribute of the block
    assert block.always_run is False
    block.always_run = True
    assert block.always_run is True

    # Test the rescue attribute of the block
    assert block.rescue is None
    block.rescue = object()
    assert block.rescue is not None

    # Test the when attribute of the block
    assert block.when is None
    when = object()
    block.when = when
    assert block.when is when

# Generated at 2022-06-21 00:19:18.082931
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    block_0._dep_chain = ["block_0"]
    assert block_0.get_dep_chain() == ["block_0"]


# Generated at 2022-06-21 00:19:25.435525
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block._valid_attrs = set([])
    block._play = Play()
    block.block = [ Task() ]
    block.rescue = [ Task() ]
    block.always = [ Task() ]
    block._role = Role()
    block._parent = Block()
    block._loader = None
    block._dep_chain = None
    block._use_handlers = True
    block._attributes = dict(
        name=Sentinel
    )
    block._unresolved_attrs = set([])

    new_block = block.copy(exclude_parent=True, exclude_tasks=False)
    assert new_block.block[0] is not None
    assert new_block.rescue[0] is not None
    assert new_block.always[0] is not None
   

# Generated at 2022-06-21 00:19:35.176401
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    b1 = Block()
    b2 = Block()
    b3 = Block()
    b4 = Block()
    b5 = Block()
    b6 = Block()
    b7 = Block()
    b8 = Block()

    b1._parent = b2
    b2._parent = b3
    b3._parent = b4
    b4._parent = b5
    b5._parent = b6
    b6._parent = b7
    b7._parent = b8

    b1._attributes['param1'] = 1
    b2._attributes['param2'] = 2
    b3._attributes['param3'] = 3
    b4._attributes['param4'] = 4
    b5._attributes['param5'] = 5
    b6._attributes['param6'] = 6
    b

# Generated at 2022-06-21 00:19:38.304348
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block=Block(play={"a":1})
    assert block._play=={"a":1}
    block.set_loader(block)
    assert block._loader==block


# Generated at 2022-06-21 00:20:12.644060
# Unit test for method is_block of class Block
def test_Block_is_block():
    # Block.is_block() == 0
    assert Block.is_block(Block) == False
    # Block.is_block(ds) == 1

    ds = {'block':[Loaded_Task(action=dict(__ansible_module__='foo')),Loaded_Task(action=dict(__ansible_module__='foo'))]}
    assert Block.is_block(ds) == True
    # Block.is_block(ds) == 2
    ds = {'rescue':[Loaded_Task(action=dict(__ansible_module__='foo'))]}
    assert Block.is_block(ds) == True
    # Block.is_block(ds) == 3
    ds = {'always':[Loaded_Task(action=dict(__ansible_module__='foo'))]}


# Generated at 2022-06-21 00:20:25.406343
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.playbook.task import Task

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    task = Task()
    task.action = 'debug'
    task.args = dict(msg='{{ item }}')
    task.loop = 'with_items'
    task.loop_args = [1,2,3]
    task.set_loader(loader)
    task.set_play_context(play_context)
    task.set

# Generated at 2022-06-21 00:20:30.151924
# Unit test for method is_block of class Block
def test_Block_is_block():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    # Create an empty inventory object
    inventory = InventoryManager(loader=loader, sources='localhost,')
    # Create a variable manager object, which will be shared across all units
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    myplay = Play().load({
            'name': 'foo',
            'hosts': 'all',
            'gather_facts': 'no',
            'roles': 'bar',
        },
        variable_manager=variable_manager,
        loader=loader,
    )

# Generated at 2022-06-21 00:20:32.501705
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Test for the get_dep_chain() method
    # TODO: implement in TestBlock()
    pass


# Generated at 2022-06-21 00:20:43.066705
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    with pytest.raises(AnsibleParserError, match="A malformed block was encountered while loading a block"):
        Block.load(object())


# Generated at 2022-06-21 00:20:44.258556
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    pass

# Generated at 2022-06-21 00:20:55.568820
# Unit test for constructor of class Block
def test_Block():
    b = Block()
    assert b.name is None
    assert b.block is None
    assert b.rescue is None
    assert b.always is None
    assert b.vars == dict()
    assert len(b.any_errors_fatal) == 0
    assert b.always_run is None
    assert b.register == 'block_result'
    assert b.ignore_errors is None
    assert b.ignore_warnings is None
    assert len(b.always_run) == 0
    assert len(b.changed_when) == 0
    assert len(b.failed_when) == 0
    assert b.run_once is None
    assert b.changed_when is None
    assert b.failed_when is None
    assert b.when is None
    assert b.notify == []
    assert b.tags

# Generated at 2022-06-21 00:20:59.669534
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    host = FakeHost()
    test_block = Block(play=Play.load(dict(name='test', hosts=host), variable_manager=VariableManager(), loader=DataLoader()))
    test_block.set_loader(DataLoader())

# Generated at 2022-06-21 00:21:09.009066
# Unit test for method serialize of class Block
def test_Block_serialize():
    # this test create a object of Block class and serialize it
    from ansible.playbook.task_include import TaskInclude
    b = Block()
    b.statically_loaded = False
    b.always = [{'name': 'always1', 'include': {'task': 'tasks/apagerduty.yml', 'name': 'pagerduty'}}]
    parent = TaskInclude()
    parent.tasks = [{'name': 'task1', 'include': {'task': 'tasks/apagerduty.yml', 'name': 'pagerduty'}}]
    b.parent = parent
    result = b.serialize()

# Generated at 2022-06-21 00:21:20.977219
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    print('call Block.test_Block_preprocess_data')
    class FakePlay:
        def set_loader(self):
            self.loader = None
    class FakeVariableManager:
        def get_vars(self):
            return dict()
    class FakeLoader:
        def get_basedir(self):
            return ''
        def load_from_file(self):
            return dict()
        def load(self):
            return dict()
    class FakeTask:
        def __init__(self):
            self.task = dict()
    class FakeTaskInclude:
        def __init__(self):
            self.task = dict()
            self.block = None
    assert Block.is_block(dict(block=1))