

# Generated at 2022-06-21 00:12:53.552833
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    import os
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    yaml_data = {
        'hosts': 'all',
        'tasks': [
            {'name': 'test task block', 'block': [
                {'name': 'test task', 'debug': 'msg="in block"'},
            ]},
        ],
    }
    play_ds = Play().load(yaml_data, variable_manager=None, loader=None)
    play = play_ds[0]

    # test_block_task is a Block object and its contain is a Task object
    test_block_task = play.get_tasks()[0]


# Generated at 2022-06-21 00:13:01.286543
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    obj = Block()

# Generated at 2022-06-21 00:13:13.579394
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.task import Task
    from ansible.playbook.task import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler import HandlerTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Cond

# Generated at 2022-06-21 00:13:23.907897
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    p = Play().load({
        'hosts': 'all',
        'tasks': [
             dict(block=dict(
                 name='test block',
                 tasks=[
                     dict(
                         name='i am task 1',
                         include_vars='{{test_var1}}'
                     ),
                     dict(
                         block=dict(
                             name='i am block 2',
                             tasks=[
                                 dict(
                                     name='i am task 2',
                                     include_vars='{{test_var2.var2}}'
                                 )
                             ]
                         )
                     )
                 ]
             )),
             dict(
                 name='i am task 3',
                 include_vars='{{test_var3}}'
             )
        ]
    })

# Generated at 2022-06-21 00:13:25.857303
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    import pytest
    with pytest.raises(AnsibleParserError):
        # TODO
        pass


# Generated at 2022-06-21 00:13:37.446127
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    """
    Test case for the method Block.get_include_params()
    """
    task = Task()
    task._parent = TaskInclude()
    task._parent.args = dict(a = True)

    # Source: test_block
    task1 = Task()
    task1.register = 'shell_out'
    task2 = Task()
    task2.register = 'shell_out'
    task3 = Task()
    task3.register = 'shell_out'
    block1 = Block(block=[task1,task2],rescue=[task3])

    block1_result = block1.get_include_params()
    assert block1_result == {}, "Failed: Block.get_include_params()"

    # Source: test_block_parent
    task1 = Task()

# Generated at 2022-06-21 00:13:39.750762
# Unit test for method set_loader of class Block
def test_Block_set_loader():
	
	block = Block()
	block.set_loader(loader, variable_manager, play)
	return True


# Generated at 2022-06-21 00:13:47.972433
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # import is here to avoid import loops
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    block = Block()
    for attr in block._valid_attrs:
        if attr not in ('block', 'rescue', 'always'):
            block._attributes[attr] = 1
    block._dep_chain = [1, 2, 3]
    role_data = {}
    role_data['name'] = 'test'
    role_data['default_vars'] = {}
    role_data['vars'] = {}
    role_data['metadata'] = {}
    role_data['tasks'] = []
    role_data['handlers'] = []
    role_data['files'] = []

# Generated at 2022-06-21 00:13:51.077243
# Unit test for method serialize of class Block
def test_Block_serialize():
    testobj = Block()

    assert testobj.serialize() == {}


# Generated at 2022-06-21 00:14:02.038161
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    

# Generated at 2022-06-21 00:14:27.006765
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    pb = Playbook()
    il = PlaybookIncludeLoader(pb)
    il.load('./data/playbook-include/playbook.yml')
    play = pb.get_plays()[0]
    block = play.get_tasks()[0]
    dep_chain = block.get_dep_chain()
    print('dep_chain:', dep_chain)


if __name__ == "__main__":
    test_Block_get_dep_chain()

# Generated at 2022-06-21 00:14:36.151292
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    b = Block()
    b.set_loader(DictDataLoader({"/etc/ansible/roles/foo/tasks/main.yaml": """
- name: test
  action: ping
    """}))
    try:
        assert(b.all_parents_static() == True)
        ti = TaskInclude.load('/etc/ansible/roles/foo/tasks/main.yaml', block=b, role=None, task_include=None, variable_manager=None, loader=None)
        assert(ti.all_parents_static() == False)
        assert(b.all_parents_static() == True)
    except AssertionError as e:
        print(e)


# Generated at 2022-06-21 00:14:40.406231
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block(tasks=["echo hi"])
    assert(block.has_tasks() is True)
    assert(not block.has_tasks() is False)
# Unit tests for class Block
import pytest


# Generated at 2022-06-21 00:14:43.614859
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    b1 = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)


# Generated at 2022-06-21 00:14:50.489683
# Unit test for constructor of class Block
def test_Block():
    for butype in (None, 'block'):
        sut = Block(butype)
        assert sut.block == []
        assert sut.rescue == []
        assert sut.always == []

        sut = Block('block')
        assert sut.block == []
        assert sut.rescue == []
        assert sut.always == []

# vim:set et sts=4 ts=4 tw=79:

# Generated at 2022-06-21 00:15:01.517675
# Unit test for constructor of class Block
def test_Block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager

    block1_tasks = [
        Task(),
        Task(),
        Task(),
        Role(),
        TaskInclude(),
        HandlerTaskInclude(),
    ]
    block1 = Block(
        parent_block=None,
        role=None,
        play=Play(),
        task_include=None,
        implicit=True,
        block=block1_tasks,
        rescue=[],
        always=[],
    )
    # test for implicit parameter
    assert block

# Generated at 2022-06-21 00:15:07.727557
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    t = Task()
    r = Role()
    r._role_path = 'roles/foo'
    _tasks = [t]
    _block = Block(play=Play().load(dict(name='testplay', roles=[r.get_name()], tasks=_tasks), variable_manager=VariableManager(), loader=None), role=r)
    assert _block.get_vars() == {'role_path': 'roles/foo'}
    

# Generated at 2022-06-21 00:15:16.487015
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    a = Playbook()
    b = Block()
    c = Role()
    d = TaskInclude()
    d._params = {'x':'y'}
    b._parent = d
    c._parent = b
    a._entries = [[d],[c]]
    print (a.get_tasks()[0].get_include_params())
    assert (a.get_tasks()[0].get_include_params() == {'x':'y'})
    assert (a.get_tasks()[1].get_include_params() == {'x':'y'})

# Generated at 2022-06-21 00:15:18.112078
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block({"block" : []}) is True


# Generated at 2022-06-21 00:15:24.902924
# Unit test for constructor of class Block

# Generated at 2022-06-21 00:15:58.192955
# Unit test for method is_block of class Block
def test_Block_is_block():
    Block()

# Generated at 2022-06-21 00:16:01.642411
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block({'block':[]})
    assert not Block.is_block([])
    assert not Block.is_block({})

# Generated at 2022-06-21 00:16:11.467936
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-21 00:16:23.793284
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    '''
    Unit test for method get_dep_chain of class Block
    '''
    # We currently don't support this function, so this test is skipped
    raise SkipTest
    # Create new block b
    from ansible.playbook.task_include import TaskInclude
    b = Block(use_handlers=True)
    # get_dep_chain() returns a list
    assert isinstance(b.get_dep_chain(), list)
    # Create new task_include t
    t = TaskInclude()
    # Create new task_include t1
    t1 = TaskInclude()
    # Create new task_include t2
    t2 = TaskInclude()
    # We call get_parent_attribute of b
    assert b.get_parent_attribute == AttributeResolver._get_parent_attribute
    # We set

# Generated at 2022-06-21 00:16:33.065472
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    b = Block()
    data = {'any_errors_fatal': 'yes', 'block': ['tasks'], 'rescue': 'rescues', 'always': 'always', 'dep_chain': 'dep_chain', 'role': 'role', 'parent': 'parent', 'parent_type': 'Block', '_use_handlers': 'yes'}
    b.deserialize(data)
    assert b._attributes == {'any_errors_fatal': 'yes'}
    assert b._dep_chain == 'dep_chain'


# Generated at 2022-06-21 00:16:40.966071
# Unit test for constructor of class Block

# Generated at 2022-06-21 00:16:44.372902
# Unit test for method serialize of class Block
def test_Block_serialize():
    block = Block()
    d = block.serialize()
    assert type(d) == dict
    assert d.get('dep_chain') == None


# Generated at 2022-06-21 00:16:48.528511
# Unit test for constructor of class Block
def test_Block():
    myblock = Block()
    assert myblock.block == []
    assert myblock.rescue == []
    assert myblock.always == []

# unit test for method _load_block:
# create a block with 3 tasks in the block and one task in the rescue

# Generated at 2022-06-21 00:16:55.911213
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    # Test block initialization
    block1 = Block()
    block2 = Block()
    # Test block equality
    test1 = block1 == block2
    assert test1 == True
    # Test block inequality
    block3 = Block(parent=block1, attr1='val1')
    block4 = Block(parent=block1, attr1='val1', attr2='val2')
    test2 = block3 == block4
    assert test2 == False

# Generated at 2022-06-21 00:16:59.257609
# Unit test for constructor of class Block
def test_Block():
    b = Block()
    assert b.block is None
    assert b.rescue is None
    assert b.always is None
    assert b.name is None
    assert b.when is None
    assert b.any_errors_fatal is None


# Generated at 2022-06-21 00:17:49.368076
# Unit test for method is_block of class Block
def test_Block_is_block():
    block = Block()
    assert not block.is_block({'block':[]})
    assert not block.is_block([])
    assert not block.is_block("block:")
    assert block.is_block({'block':[], 'rescue':[], 'always':[]})
    assert block.is_block({'block':[], 'rescue':[]})
    assert block.is_block({'block':[], 'always':[]})


# Generated at 2022-06-21 00:17:53.106289
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    # Initialize a Block object
    b = Block()
    # Call the get_vars method of this object
    b.get_vars()

# Generated at 2022-06-21 00:17:56.081595
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    # define block_obj
    block_obj = Block()
    # call method
    result  = block_obj.get_include_params()
    # assert the result
    assert result == {}

# Generated at 2022-06-21 00:18:08.155855
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Case 1: all the parents of the Block object are statically loaded.
    t1 = dict(
            block=[]
        )
    myblock = Block.load(t1)
    assert myblock.all_parents_static() == True
    # Case 2: only the most closest parent of the Block object is not statically loaded.
    t1 = dict(
            block=[]
        )
    myblock = Block.load(t1, statically_loaded=False)
    assert myblock.all_parents_static() == False
    # Case 3: the most closest parent of the Block object is statically loaded, but
    #         another parent is not.
    t1 = dict(
            block=[]
        )
    t2 = dict()
    myblock = Block.load(t1)

# Generated at 2022-06-21 00:18:15.667122
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Test method with an include parent 
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    b = Block()
    b.statically_loaded = True
    b._role = Role()
    b.block = [Task()]
    ti = TaskInclude()
    ti.statically_loaded = False
    ti._parent = b
    assert(ti.all_parents_static() == False)

    ti = TaskInclude()
    ti.statically_loaded = False
    ti._parent = TaskInclude()
    ti._parent.statically_loaded = True
    ti._parent._parent = b
    assert(ti.all_parents_static() == True)

# Generated at 2022-06-21 00:18:28.810417
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    #Test case 1 - Block with Task as parent
    #input
    t = Task()
    b = Block(parent_block = t)
    #output
    assert b.get_include_params() == dict()
    # Test case 2 - Block with TaskInclude as parent
    # input
    ti = TaskInclude()
    b = Block(parent_block = ti)
    # output
    assert b.get_include_params() == ti.get_include_params()
    #Test case 3 - Block with Handler as parent
    #input
    h = Handler()
    b = Block

# Generated at 2022-06-21 00:18:31.356294
# Unit test for method is_block of class Block
def test_Block_is_block():
    # Test
    assert Block.is_block({"block": ["task1", "task2"]})


# Generated at 2022-06-21 00:18:37.602847
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    parent1 = Block(parent_block=None)
    parent2 = Block(parent_block=parent1)
    parent3 = Block(parent_block=parent2)

    testObj = Block(parent_block=parent3)

    assert testObj.get_dep_chain() == parent1.get_dep_chain()



# Generated at 2022-06-21 00:18:44.466613
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    block.name = 'first_block'
    block_copy = block.copy()
    block_copy.name = 'second_block'
    block.block = [block_copy]
    assert block.has_tasks() == True
    
    
    
    block = Block()
    assert block.has_tasks() == False
    
    

    
    
    
    
    
    

# Generated at 2022-06-21 00:18:54.635043
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    m_self = Mock()
    m_ds = Mock()
    m_data = Mock()
    m_data.get.return_value = m_ds
    m_self._attributes = {"name": m_data}
    m_self._get_parent_attribute.return_value = m_data
    m_self.get_dep_chain.return_value = [{"name": data_1}]
    m_self.serialize.return_value = {"name": data_1}
    Block.__repr__(m_self)

# Generated at 2022-06-21 00:21:03.938556
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    pass


# Generated at 2022-06-21 00:21:11.212426
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block = Block()
    assert block._parent is None
    assert block.statically_loaded

    block0 = Block()
    block0._parent = block
    assert not block0.statically_loaded
    assert block0.all_parents_static()
    assert block0._parent._parent is None

    block1 = Block()
    block1._parent = block0
    assert not block1.statically_loaded
    assert block1._parent == block0
    assert block1._parent._parent == block
    assert block1.all_parents_static()

    block2 = Block()
    block2._parent = block1
    assert not block2.statically_loaded
    assert block2._parent == block1
    assert block2._parent._parent == block0
    assert block1._parent._parent._parent == block
    assert not block2

# Generated at 2022-06-21 00:21:12.342396
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block()


# Generated at 2022-06-21 00:21:13.413360
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    pass

# Generated at 2022-06-21 00:21:24.570795
# Unit test for method copy of class Block
def test_Block_copy():
    play_context = dict(
        port=22,
        remote_user='root',
        connection='smart',
        network_os='default',
        module_path=None,
        forks=100,
        become=False,
        become_method=None,
        become_user=None,
        check=False,
        diff=False,
        timeout=10,
        private_key_file=None,
        remote_pass=None,
    )
    display = Display()
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(Inventory('hosts'))
    variable_manager.set_loader(loader)
    variable_manager.set_play_context(play_context)