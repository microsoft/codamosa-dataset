

# Generated at 2022-06-21 00:11:59.600495
# Unit test for method is_block of class Block
def test_Block_is_block():
    # ds = dict(block=1)
    assert_equal(Block.is_block(dict(block=1)), True)

# Generated at 2022-06-21 00:12:05.762842
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # Setup
    data = None
    play = None
    parent_block = None
    role = None
    task_include = None
    use_handlers = True
    implicit = True
    b = Block(play, parent_block, role, task_include, use_handlers)

    # Test
    ds = b.preprocess_data(data)

    # Verify
    assert(not ds)


# Generated at 2022-06-21 00:12:12.319219
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # instance setup
    block = Block()
    # test
    assert not block.has_tasks()
    block.block = [123]
    assert block.has_tasks()
    block.block = []
    block.rescue = [123]
    assert block.has_tasks()
    block.rescue = []
    block.always = [123]
    assert block.has_tasks()
    block.always = []
    block.block = []
    block.rescue = []
    block.always = []
    assert not block.has_tasks()


# Generated at 2022-06-21 00:12:17.653632
# Unit test for constructor of class Block
def test_Block():

    # Test to ensure Block does not accept bare strings as arguments
    test_passed = False
    try:
        block = Block("this should fail")
    except AnsibleParserError:
        test_passed = True
    assert test_passed, "Block should not accept a bare string, instead it should raise a TypeError"

    # Test to ensure Block accepts strings wrapped in a list
    test_passed = False
    try:
        block = Block(["this should pass"])
    except TypeError:
        test_passed = True
    assert not test_passed, "Block should accept a string wrapped in a list"

    # Test for implicit Block constructor
    my_block = Block(["this should pass"])
    assert my_block.implicit, "implicit Block constructor should set implicit attribute to True by default"

    # Test for explicit

# Generated at 2022-06-21 00:12:28.370811
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    my_loader = DictDataLoader({
        "test.yml": {
            "hosts": "localhost",
            "tasks": [
                {"action": {"module": "shell", "args": "echo hello world"}}
            ]
        }
    })
    my_play = Play().load({
        "hosts": "localhost",
        "tasks": [
            {"action": {"module": "shell", "args": "echo hello world"}}
        ]
    }, loader=my_loader)
    my_block = Block().load({
        "block": [
            {"action": {"module": "shell", "args": "echo hello world"}}
        ]
    }, play=my_play)
    my_block.set_loader(my_loader)
    assert my_block._loader == my_loader

#

# Generated at 2022-06-21 00:12:37.986771
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='hosts')
    playbook_path = './playbook.yml'


# Generated at 2022-06-21 00:12:39.934834
# Unit test for method is_block of class Block
def test_Block_is_block():
    # Setting up the mock class for Block
    Block_instance = Block()
    mock_data = "test_value"
    Block_instance.is_block(mock_data)


# Generated at 2022-06-21 00:12:53.012342
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.block import Block
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from yaml import YAMLObject, YAMLObjectMetaclass
    play_context = PlayContext(vars=dict(a=1))

# Generated at 2022-06-21 00:12:56.871470
# Unit test for method is_block of class Block
def test_Block_is_block():
    block_dict = {'block': 1}
    assert Block.is_block(block_dict)
    block_str = 'asdf'
    assert not Block.is_block(block_str)
    block_list = [1, 2]
    assert Block.is_block(block_list)

# Generated at 2022-06-21 00:13:03.215457
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    res = Block.preprocess_data("ds")
    assert res == {'block': 'ds'}
    res = Block.preprocess_data({"block": "ds"})
    assert res == {'block': 'ds'}
    dicts = dict()
    with pytest.raises(AssertionError):
        res = Block.preprocess_data(dicts) # No block keyword in dict


# Generated at 2022-06-21 00:13:39.300361
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # Test setUp
    ds1 = dict(block=['task1', 'task2'])
    ds2 = dict(rescue=['task3', 'task4'])
    ds3 = dict(always=['task5'])
    ds4 = dict(block=[ds1, ds2, ds3])
    ds5 = {'block': ['task1', 'task2'], 'rescue': ['task3', 'task4'], 'always': ['task5']}
    ds6 = {'block': ['task1', 'task2'], 'rescue': ['task3', 'task4'], 'always': ['task5'], 'dep_chain': 'abc'}
    
    
    b = Block(implicit=True)
    assert b.implicit == True
    

# Generated at 2022-06-21 00:13:47.312478
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    data = dict(block=[1, 2, 3])
    b = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    b = b.load_data(data, variable_manager=None, loader=None)

    if b is None:
        raise Exception('Block.load_data() returned None')
    assert(b.has_tasks() == True)
    data['block'] = []
    b = b.load_data(data, variable_manager=None, loader=None)

    if b is None:
        raise Exception('Block.load_data() returned None')

    assert(b.has_tasks() == False)


# Generated at 2022-06-21 00:14:00.017887
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    mock_block = Mock(name='block')

    # create test object to use
    block = Block(block=['block'])
    mock_block = Mock(name='block')
    block.block = mock_block
    task_include = TaskInclude()
    mock_task_include = Mock(name='task_include')
    mock_task_include.all_parents_static.return_value = True
    task_include = mock_task_include
    task = Task()
    mock_task = Mock(name='task')
    mock_task

# Generated at 2022-06-21 00:14:07.482129
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    '''
    Unit test for method preprocess_data of class Block
    '''
    data_set = [
        ['foo', {'block': ['foo']}],
        [['foo'], {'block': ['foo']}],
        [{'foo': 'bar'}, {'block': [{'foo': 'bar'}]}],
        [None, {'block': []}],
    ]

    for i, data in enumerate(data_set):
        b = Block()
        assert b.preprocess_data(data[0]) == data[1]


# Generated at 2022-06-21 00:14:15.921668
# Unit test for method is_block of class Block
def test_Block_is_block():
	# Create the test object
	test_object = Block()

	# Set the test input data

# Generated at 2022-06-21 00:14:23.189881
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    print("testing method Block_has_tasks")
    assert Block.has_tasks([]) == False
    assert Block.has_tasks('a') == False
    assert Block.has_tasks(False) == False
    assert Block.has_tasks({}) == False
    assert Block.has_tasks(0) == False
    assert Block.has_tasks([1,2,3]) == True


# Generated at 2022-06-21 00:14:29.724117
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False)

    with pytest.raises(Exception) as e:
        block.set_loader("failed_loader")
        assert 'not a valid loader' in str(e.value)
        
    block.set_loader(DictDataLoader)

# Generated at 2022-06-21 00:14:34.489975
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = Block(block=[], rescue=[], always=[])
    if (not hasattr(block, 'filter_tagged_tasks')):
        # If the method does not exist, ignore the test
        return
    # Your implementation of filter_tagged_tasks goes here, and
    # you should return True if it passes, or False if it fails
    return True


# Generated at 2022-06-21 00:14:47.092936
# Unit test for method all_parents_static of class Block

# Generated at 2022-06-21 00:14:53.757944
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    '''
    Unit test for method Block.__ne__
    '''

    # setup
    block1 = Block()
    block2 = Block()
    block3 = Block()
    block3._attributes['foo'] = '2'
    block3._attributes['bar'] = '3'

    # test
    assert block1 != block2
    assert block1 != block3
    assert block2 != block3


# Generated at 2022-06-21 00:15:20.912423
# Unit test for constructor of class Block
def test_Block():
    '''
    Playbook._load_block unit test
    '''
    block_loader = DataLoader()
    play = Play().load({
        "name": "test play",
        "hosts": "all",
        "gather_facts": "no",
        "tasks": [
            {"action": {"module": "shell", "args": "echo hi"},
             "register": "result"},
            {"action": {"module": "fail", "args": "msg=check_mode testing"}},
            {"action": {"module": "debug", "args": "var=hostvars"}}
        ]
    }, loader=block_loader, variable_manager=VariableManager())
    block = Block.load(play.tasks[0], play=play, loader=block_loader, variable_manager=VariableManager())

# Generated at 2022-06-21 00:15:28.025549
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    class Root(object):
        def get_vars(self):
            return dict()
    parent = Block.load({}, parent_block=Root())
    parent._parent = Root()
    block = Block.load({}, parent_block=parent)
    assert block.get_include_params() == {}
    block._parent = parent
    assert block.get_include_params() == {}
    block.vars = {'x': 'y'}
    assert block.get_include_params()['x'] == 'y'
    block._parent.vars = {'z': 'w'}
    assert block.get_include_params()['x'] == 'y'
    assert block.get_include_params()['z'] == 'w'

# Generated at 2022-06-21 00:15:37.195284
# Unit test for method is_block of class Block
def test_Block_is_block():
    ds = dict(block=[dict(action='setup'), dict(action='debug', msg='Hello World')], rescue=[], always=[])
    assert Block.is_block(ds)
    ds = dict(block=[dict(action='setup'), dict(action='debug', msg='Hello World')])
    assert Block.is_block(ds)

    d = dict(action='setup')
    assert Block.is_block(d) == False

    ds = [dict(action='setup'), dict(action='debug', msg='Hello World')]
    assert Block.is_block(ds) == False


# Generated at 2022-06-21 00:15:43.110083
# Unit test for method load of class Block
def test_Block_load():
    data = {
        'block': [
            'task_1',
            'task_2'
        ]
    }
    b = Block.load(data)
    assert(isinstance(b, Block))
    assert(b.block[0].action == 'task_1')
    assert(b.block[1].action == 'task_2')


# Generated at 2022-06-21 00:15:44.417886
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    assert False, "Test not implemented"


# Generated at 2022-06-21 00:15:48.939985
# Unit test for method is_block of class Block
def test_Block_is_block():
    data = {
     "block": [
         {
             "name": "foo",
             "block": [
                 "task 1"
             ]
         }
     ]
    }
    
    assert Block.is_block(data) == True
    assert Block.is_block("foo") == False
    assert Block.is_block({}) == False
    

# Generated at 2022-06-21 00:16:00.996468
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    ti = TaskInclude()
    ti._statically_loaded = True
    b = Block()
    b._statically_loaded = True
    ti._parent = b
    ti._dep_chain = [ti, b, b]
    assert ti.get_dep_chain() == [ti, b, b]

    hti = HandlerTaskInclude()
    hti._statically_loaded = True
    hti._parent = ti
    hti._dep_chain = [hti, ti, b, b]
    assert hti.get_dep_chain() == [hti, ti, b, b]

    ti._dep_chain = None
    b._parent = ti
    b

# Generated at 2022-06-21 00:16:06.645110
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    my_block = Block()
    my_block.block = []
    my_block.rescue = []
    my_block.always = []
    my_block.statically_loaded = True
    assert my_block.all_parents_static() == True
    my_block.statically_loaded = False
    assert my_block.all_parents_static() == False



# Generated at 2022-06-21 00:16:14.159635
# Unit test for method deserialize of class Block

# Generated at 2022-06-21 00:16:26.695999
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Test with simple values
    task1 = Task(
        use_handlers=False,
        implicit=True,
        action='debug',
        args=dict(msg='hello world')
    )
    assert task1.get_vars() == dict(msg='hello world')
    assert task1.get_vars(include_hostvars=False, include_delegate_to=False) == dict(msg='hello world')

    # Test with complex values

# Generated at 2022-06-21 00:16:43.536437
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    #__ne__(other)
    
    
    raise NotImplementedError()

# Generated at 2022-06-21 00:16:55.262330
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    import pytest
    # Setup arguments for the Method
    task = Task()
    task._parent = TaskInclude()
    task._parent._parent = HandlerTaskInclude()
    task.load({
        'name': 'test',
        'vars': {'test': 'test'},
    })
    task._parent.load({'vars': {'test1': 'test1'}})
    task._parent._parent.load({'vars': {'test2': 'test2'}})
    # Method Unit Test
    ansible_vars = task.get_vars()
    # Now check if the value returned is matching

# Generated at 2022-06-21 00:17:02.585805
# Unit test for method load of class Block
def test_Block_load():
    '''
    Block.load(data)

    This method will create a block object with the data provided.
    '''
    # Set up mock objects
    mock_data = {}
    mock_play = {}
    mock_parent_block = {}
    mock_role = {}
    mock_task_include = {}
    mock_use_handlers = {}
    mock_variable_manager = {}
    mock_loader = {}

    # Set up class to test
    Block_class_to_test = Block(play=mock_play, parent_block=mock_parent_block, role=mock_role, task_include=mock_task_include, use_handlers=mock_use_handlers, implicit=True)

    # Invoke method

# Generated at 2022-06-21 00:17:12.539459
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    b = Block()
    assert b.get_first_parent_include() is None
    ti = TaskInclude()
    b._parent = ti
    assert b.get_first_parent_include() == ti
    b = Block()
    ti = TaskInclude()
    ti._parent = b
    assert ti.get_first_parent_include() == ti
    b = Block()
    ti = TaskInclude()
    b._parent = ti
    ti._parent = Block()
    assert b.get_first_parent_include() == ti


# Generated at 2022-06-21 00:17:17.650571
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    new_block = Block()
    new_block._parent = None
    new_block.block = [1,2,3,4]
    new_block.rescue = []
    new_block.always = []
    block_params = new_block.get_include_params()
    assert block_params is None

# Generated at 2022-06-21 00:17:24.945220
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    assert None == Block().get_dep_chain()
    assert ['x'] == Block(dep_chain=['x']).get_dep_chain()
    assert ['x'] == Block(parent=TaskInclude(dep_chain=['x'])).get_dep_chain()
    assert ['x'] == Block(parent=HandlerTaskInclude(dep_chain=['x'])).get_dep_chain()
    assert ['x'] == Block(parent=TaskInclude(dep_chain=['x'])).get_dep_chain()


# Generated at 2022-06-21 00:17:26.134515
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    pass # TODO: write me


# Generated at 2022-06-21 00:17:29.835864
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    assert repr( Block() ) == "<ansible.playbook.block.Block(implicit='True',name='None',block=[],rescue=[],always=[])>"

# Generated at 2022-06-21 00:17:41.021599
# Unit test for method is_block of class Block
def test_Block_is_block():
    import json
    import unittest
    import sys
    import os

    test_dir = os.path.dirname(os.path.realpath(__file__))
    # Add content of library to module search path.
    sys.path.insert(0, os.path.join(test_dir, 'library'))
    import ansible_module_helper as ansible_module

    # Load the module source code.
    module_path = os.path.join(test_dir, '..')
    if module_path not in sys.path:
        sys.path.insert(0, module_path)
    from ansible.playbook.block import Block

    class TestBlock_is_block(unittest.TestCase):
        def test_Block_is_block_empty_input(self):
            ds = {}


# Generated at 2022-06-21 00:17:42.079885
# Unit test for method load of class Block
def test_Block_load():
    pass # used to test the Block load method

# Generated at 2022-06-21 00:18:07.982782
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    
    # set up test variables
    
    choices = [u'censored value']
    default = u'uncensored value'
    name = u'name'
    set_none = False
    
    
    
    # set up test class object
    block_instance_object = Block()
    block_instance_object.set_loader(loader)
    
    # test default
    
    assert block_instance_object._loader == loader, 'Block._loader default value does not match'
    assert block_instance_object._role == None, 'Block._role default value does not match'

# Generated at 2022-06-21 00:18:13.761389
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.play import Play

    # Create a play to pass into the block.
    # We don't actually care what is in the play for this test.
    play = Play.load(dict(name='test', hosts=['localhost']), variable_manager=None, loader=None)
    # The only required parameter for a Block is a play.
    block = Block(play=play)

    # Actually test the copy() method
    block_copy = block.copy()

    assert block_copy.__class__.__name__ == "Block"


# Generated at 2022-06-21 00:18:15.380573
# Unit test for constructor of class Block
def test_Block():
    # 1. Create instance of Block()
    block = Block()
    assert block is not None


# Generated at 2022-06-21 00:18:18.191371
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    default_block=Block()
    assert default_block.has_tasks()==0


# Generated at 2022-06-21 00:18:30.084302
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence

    ########################################################################################
    #
    # Setup test objects
    #
    ########################################################################################

    host1 = Host(name="foo")
    host2 = Host(name="bar")
    group1 = Group(name="g1")
    group2 = Group(name="g2")
    group1.add_host(host1)

# Generated at 2022-06-21 00:18:36.934498
# Unit test for method has_tasks of class Block

# Generated at 2022-06-21 00:18:40.244132
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block = Block()
    # No error raised.
    repr(block)
    block.name = 'block_name'
    # No error raised.
    repr(block)



# Generated at 2022-06-21 00:18:51.884446
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    fake_playbook = FakeYaml()
    fake_inventory = FakeInventory(fake_playbook)
    fake_variable_manager = FakeVariableManager()

    fake_loader = FakeLoader()

    temp_block = Block(play=fake_playbook, loader=fake_loader)

    dep_chain = temp_block.get_dep_chain()

    assert dep_chain is None, 'get_dep_chain() must return None if no dependency chain is stored'

    assert temp_block._dep_chain is None, '_dep_chain must be initialized with None'

    temp_block._dep_chain = 'any value'

    dep_chain = temp_block.get_dep_chain()

    assert dep_chain == 'any value', 'get_dep_chain() must return a copy of the value stored in _dep_chain'

    dep_

# Generated at 2022-06-21 00:18:53.245389
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    pass # TODO: implement your test here



# Generated at 2022-06-21 00:19:05.715143
# Unit test for method serialize of class Block
def test_Block_serialize():
    b = Block()
    assert b.serialize() == {
        'dep_chain': None,
    }

    b = Block(name='block')
    b.load({
        'block': [{
            'name': 'task 1',
            'action': 'setup'
        }],
        'rescue': [{
            'name': 'rescue task 1',
            'action': 'setup'
        }],
        'always': [{
            'name': 'always task 1',
            'action': 'setup'
        }]
    })
    b.set_loader(DictDataLoader({}))

# Generated at 2022-06-21 00:19:27.703605
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    class Test:
        @staticmethod
        def get_parent_attribute():
            return "test"
    try:
        b = Block(play=test)
        b1 = Block(play=test)
        assert Block.__eq__(b, b1)
    except:
        raise
        
    try:
        b = Block(play=test)
        b1 = Block(play=None)
        assert Block.__eq__(b, b1) == False
    except:
        raise
        
    try:
        b = Block(play=test)
        b1 = Block(play=test)
        b._attributes['a'] = "test"
        b1._attributes['b'] = "test"
        assert Block.__eq__(b, b1) == False
    except:
        raise
        

# Generated at 2022-06-21 00:19:37.752800
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    # Setup
    my_block = Block()
    my_block.block = [1, 2, 3]
    my_block.name = "Test name"
    my_block.always = [1, 2, 3]
    my_block.rescue = [1, 2, 3]
    my_block.any_errors_fatal = True
    my_block.deprecated = True
    my_block.ignore_errors = True
    my_block.notify = ["my_handler"]
    my_block.delegate_to = "otherhost"
    my_block.listen = "otherhost"
    my_block.loop = 'item in sequence'
    my_block.loop_with_items = ['item1', 'item2']
    my_block.loop_with_sequence = [1, 2, 3]


# Generated at 2022-06-21 00:19:48.572763
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    import ansible.constants as C
    import json


# Generated at 2022-06-21 00:19:50.532232
# Unit test for method serialize of class Block
def test_Block_serialize():
    block = Block()
    block.post_validate({}, {})
    block.deserialize({})
    block.serialize()

# Generated at 2022-06-21 00:19:56.698510
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.template import Templar

    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    import pytest
    import copy

    # Create a play to use as parent
    vars_manager = VariableManager()
    loader = DictDataLoader({})
    iters = [
        dict(key=dict(value=1)),
        dict(key=dict(value=2))
    ]

# Generated at 2022-06-21 00:19:59.916534
# Unit test for constructor of class Block
def test_Block():
    block = Block()
    assert not block.block
    assert not block.rescue
    assert not block.always
    assert block._implicit is False


# Generated at 2022-06-21 00:20:01.448049
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    block = Block()
    assert block != None


# Generated at 2022-06-21 00:20:12.710004
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.parsing import DataLoader
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.Playbook import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

    # test task with tags

# Generated at 2022-06-21 00:20:13.420445
# Unit test for method load of class Block
def test_Block_load():
    pass

# Generated at 2022-06-21 00:20:26.242600
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    b = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    assert b == b
#  _valid_attrs = dict(
#          block=dict(default=[], type='list', elements='task', inherit_parent=True),
#          rescue=dict(default=[], type='list', elements='task', inherit_parent=True),
#          always=dict(default=[], type='list', elements='task', inherit_parent=True),
#          name=dict(default=None, type='string'),
#          register=dict(default=None, type='string'),
#          tags=dict(default=[], type='list', elements='string'),
#          when=dict(default=None, type='boolean'),
#  )

# Generated at 2022-06-21 00:21:10.313121
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    from ansible.playbook.play_context import PlayContext

    class MockTask:
        def __init__(self, name, vars):
            self.name = name
            self.use_handlers = False
            self.vars = vars

    class MockLoadedTask:
        def __init__(self, name, deps):
            self.name = name
            self.deps = deps

        def get_loaded_vars(self):
            return dict()

    class MockLoader():
        def __init__(self):
            self.path_exists = False

        def path_exists(self, name):
            return self.path_exists

    class MockPlay:
        def __init__(self, vars):
            self.vars = vars
            self.hostvars = dict()



# Generated at 2022-06-21 00:21:14.476647
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    b = Block.load(dict(block=dict(tasks=dict(action=dict(module="debug", args=dict(msg="value")))))).block[0]
    assert b == b



# Generated at 2022-06-21 00:21:23.774129
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    b1 = Block()
    b2 = Block()
    b3 = Block()
    b3.register_var_one = "test"

    assert b1.__ne__(b2), "test_Block___ne__ #1 failed."
    assert b1.__ne__(b3), "test_Block___ne__ #2 failed."
    assert b2.__ne__(b3), "test_Block___ne__ #3 failed."
    assert b3.__ne__(b1), "test_Block___ne__ #4 failed."
    assert b3.__ne__(b2), "test_Block___ne__ #5 failed."
