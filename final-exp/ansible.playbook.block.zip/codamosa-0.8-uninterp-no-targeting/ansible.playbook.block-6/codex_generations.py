

# Generated at 2022-06-21 00:12:26.541133
# Unit test for constructor of class Block
def test_Block():
    some_block = Block()
    assert isinstance(some_block, object)
    assert isinstance(some_block, Block)
    assert not some_block.statically_loaded

# Generated at 2022-06-21 00:12:36.120825
# Unit test for method __eq__ of class Block

# Generated at 2022-06-21 00:12:42.604905
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = PlaybookInclude.load('foobar/main.yml', None, None, None, None, False, None, None)
    assert b.has_tasks() == True

    b = Block.load(None, None, None, None, None, False, None, None)
    assert b.has_tasks() == False

    b = Block.load(dict(block=[]), None, None, None, None, False, None, None)
    assert b.has_tasks() == False

    b = Block.load(dict(block=[dict(task='foo')]), None, None, None, None, False, None, None)
    assert b.has_tasks() == True



# Generated at 2022-06-21 00:12:45.375146
# Unit test for method serialize of class Block
def test_Block_serialize():
    my_serialize = 1

    assert my_serialize == 1

# Generated at 2022-06-21 00:12:50.687473
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    block1 = AnsibleBlock()
    block2 = AnsibleBlock()
    try:
        block1.__eq__(block2)
    except NotImplementedError as ex:
        assert str(ex) == "NotImplementedError: block.__eq__() has not been implemented"


# Generated at 2022-06-21 00:12:59.701138
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    block = Block()
    assert block.__ne__(True)==True
    assert block.__ne__(False)==True
    assert block.__ne__(0)==True
    assert block.__ne__(1)==True
    assert block.__ne__(1.0)==True
    assert block.__ne__(0.0)==True
    assert block.__ne__(0.0+1.0j)==True
    assert block.__ne__('')==True
    assert block.__ne__([])==True
    assert block.__ne__(())==True
    assert block.__ne__({})==True
    assert block.__ne__(set())==True
    assert block.__ne__(object())==True
    assert block.__ne__(None)==False

# Unit

# Generated at 2022-06-21 00:13:05.737619
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    real_play = Play()
    fake_play = Play()
    fake_play.tasks = [Task(), Task()]
    fake_parent = Block()
    assert not real_play.has_tasks()
    assert fake_play.has_tasks()
    assert not fake_parent.has_tasks()


# Generated at 2022-06-21 00:13:13.359439
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
  block = Block()
  assert block.preprocess_data('ds') == {
    'block': 'ds'
  }
  assert block.preprocess_data([
    'ds'
  ]) == {
    'block': [
      'ds'
    ]
  }
  assert block.preprocess_data(
    {
      'block': {
        'a': 1
      }
    }
  ) == {
    'block': {
      'a': 1
    }
  }



# Generated at 2022-06-21 00:13:20.601521
# Unit test for method load of class Block
def test_Block_load():
    # initialize args
    data = {}
    play = None
    parent_block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    
    # create instance of class Block to test against
    b = Block(play, parent_block, role, task_include, use_handlers)
    b.load(data, play, parent_block, role, task_include, use_handlers, variable_manager, loader)
    
    
    
    
    

# Generated at 2022-06-21 00:13:28.019917
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    hosts = [dict(hostname = '127.0.0.1', port = 22)]
    inventory = Inventory(hosts)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=DataLoader())
    tqm = None
    play._prepare_task_blocks()
    result = play.tasks[0].has_tasks()
    assert False == result


# Generated at 2022-06-21 00:13:58.633556
# Unit test for method load of class Block
def test_Block_load():
    # TODO: Implement unit test
    pass


# Generated at 2022-06-21 00:14:06.417498
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    mock_self = MagicMock(name=u'Block')
    mock_y = MagicMock(name=u'MagicMock object')
    mock_self.__ne__.return_value = 'return value'
    mock_y.__ne__.return_value = 'return value'
    actual = Block.__ne__(mock_self, mock_y)
    assert actual == 'return value'
    mock_self.__ne__.assert_called_once_with('return value')
    mock_y.__ne__.assert_called_once_with('return value')


# Generated at 2022-06-21 00:14:11.094276
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    a = Block(
        name="baz",
        block=[
            dict(
                name="foo"
            )
        ]
    )

    b = Block(
        name="bar",
        block=[
            dict(
                name="foo"
            )
        ]
    )

    assert a != b

# Generated at 2022-06-21 00:14:14.328249
# Unit test for method load of class Block
def test_Block_load():
    block = Block()
    assert block.load({'block': [{'action': 'setup', 'implicit': True}]}).block[0].action == 'setup'
# class Block(object)



# Generated at 2022-06-21 00:14:27.334960
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.role_include import RoleInclude
    loader = AnsibleLoader(None, False)
    play = Play()
    role_include = RoleInclude()
    role_include.load_role(loader, dict(name='test_role'))

    # Case: Block: has block, rescue and always
    test_data = dict(block=[{'test_task':'test_name'}], rescue=[{'test_task':'test_name'}], always=[{'test_task':'test_name'}])
    result = Block(play, role=role_include).preprocess_data(test_data)
    assert result['block'][0]['test_task'] == 'test_name'

# Generated at 2022-06-21 00:14:33.264444
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook import Play, Playbook
    from ansible import constants as C
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import os
    import shutil
    import sys
    import yaml
    import json

    user_variable_manager = VariableManager()
    inventory = InventoryManager(loader=yaml.safe_loader, sources=['tests/hosts'], variable_manager=user_variable_manager)

# Generated at 2022-06-21 00:14:39.940031
# Unit test for method load of class Block
def test_Block_load():
    data = dict(a=1)
    {'a': 1}
    play = None
    parent_block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    b = Block.load(data, play, parent_block, role, task_include, use_handlers, variable_manager, loader)
    assert b._ds == {'a': 1}

# Generated at 2022-06-21 00:14:42.540201
# Unit test for method deserialize of class Block
def test_Block_deserialize():
  data = {}
  myBlock = Block()
  myBlock.deserialize(data)
  return myBlock


# Generated at 2022-06-21 00:14:44.412165
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block({'key': 'value'}) == False


# Generated at 2022-06-21 00:14:56.251071
# Unit test for constructor of class Block
def test_Block():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    block = Block()
    assert(block.block == [])
    assert(block.rescue == [])
    assert(block.always == [])

    t = Task()
    block = Block(block=[t])
    assert(len(block.block) == 1)
    assert(block.rescue == [])
    assert(block.always == [])

    block = Block(rescue=[t])
    assert(block.block == [])
    assert(len(block.rescue) == 1)
    assert(block.always == [])

    block = Block(always=[t])
    assert(block.block == [])
    assert(block.rescue == [])

# Generated at 2022-06-21 00:15:24.367763
# Unit test for method load of class Block
def test_Block_load():
    # Initializing the test environment
    global_args = dict(
        basedir=test_dir
    )
    p = Play().load(dict(
        name="test play",
        hosts="all",
        gather_facts="no",
        roles=["test_role"],
        tasks=[{"debug": "msg={{ role_path }}"}]
    ), variable_manager=VariableManager(), loader=MockDataLoader())
    # Loading the test data
    data = dict(
        debug="msg={{ role_path }}"
    )
    f = Block(play=p)
    b = f.load(data)
    assert b.get_vars()['role_path'] == "test/test_role_1"

# Generated at 2022-06-21 00:15:28.387217
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    myPlay = play.Play()
    myBlock = Block(play=myPlay)
    myTaskInclude = task_include.TaskInclude(play=myPlay)
    myTaskInclude.statically_loaded = False
    myBlock._parent = myTaskInclude
    assert myBlock.all_parents_static() == False

# Generated at 2022-06-21 00:15:29.709058
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    pass


# Generated at 2022-06-21 00:15:36.113804
# Unit test for method serialize of class Block
def test_Block_serialize():
    b = Block()
    assert(b.serialize() == dict())

    b = Block.load(dict(block=dict(name='foo')))
    b.serialize()

    b = Block.load(dict(block=dict(name='foo')))
    r = Role()
    r.name = 'test_role'
    b._role = r

    b.serialize()


# Generated at 2022-06-21 00:15:47.308750
# Unit test for method is_block of class Block
def test_Block_is_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import MockInventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

# Generated at 2022-06-21 00:15:58.072950
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():

    # Unit test for Block.get_dep_chain()
    #
    # When Block._dep_chain is None and _parent exist,
    # will return _parent.get_dep_chain()
    #
    # When Block._dep_chain is None and _parent do not exist,
    # will return None
    #
    # When Block._dep_chain is not None,
    # will return _dep_chain[:]

    # Create a Role() object
    role = Role()

    # Create a Block() object
    block = Block()

    # Create a Block() object
    block_B = Block()

    # Create a Block() object
    block_C = Block()

    # Create a Block() object
    block_D = Block()

    # Create a Block() object
    block_E = Block()

    # Create a Block()

# Generated at 2022-06-21 00:16:09.363778
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    G = LinkedListGraph()
    G.insertNode(TaskInclude().get_id())
    G.insertNode(TaskInclude().get_id())
    G.insertNode(TaskInclude().get_id())

    G.insertEdge(0, 1)
    G.insertEdge(1, 2)
    G.insertEdge(2, 1)

    l = G.getAllNodes()
    l = [ li for li in l if li != None ]
    ti0 = TaskInclude()
    ti1 = TaskInclude()
    ti2 = TaskInclude()
    ti0.set_id(l[0])
    ti1.set_id(l[1])
    ti2.set_id(l[2])
    ti0._

# Generated at 2022-06-21 00:16:11.649325
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block = Block()
    data = None
    assert block.preprocess_data(data) == None
test_Block_preprocess_data()

# Generated at 2022-06-21 00:16:24.007976
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    # Test case where self._parent = None
    block = Block()
    assert block.get_vars() == dict()

    # Test case where self._parent._attributes['vars'] = {}
    playbook = AnsiblePlaybook()
    block.update_parent_variable_manager(playbook)
    playbook.name = "test"
    assert block.get_vars() == dict()

    # Test case where self._parent._attributes['vars'] = {'name': 'Ansible'}
    playbook = AnsiblePlaybook()
    playbook.name = "test"
    playbook.vars = {'name': 'Ansible'}
    block.update_parent_variable_manager(playbook)
    assert block.get_vars() == {'name': 'Ansible'}

    # Test case where self._

# Generated at 2022-06-21 00:16:35.793641
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    class TestClass:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    # Test parent includes
    yaml_data1 = """
    - include_tasks: test1.yml
      when: var1
    - block:
        - include_tasks: test2.yml
          when: var2
        - debug:
            msg: parent_include
    - debug:
        msg: parent_include
    """
    block1 = Block.load(yaml.safe_load(yaml_data1))
    assert block1.block[0].get_include_params() == {'when': 'var1'}
    assert block1.block[1].block[0].get_include_params() == {'when': 'var1'}
    assert block1

# Generated at 2022-06-21 00:16:57.164951
# Unit test for constructor of class Block
def test_Block():
    b = Block()
    print(b)


# Generated at 2022-06-21 00:16:59.494856
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    obj = Block()
    other = Block()
    assert(obj != other)


# Generated at 2022-06-21 00:17:10.557183
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a play object to use
    play = Play()
    block = Block(play)
    
    # Create a Task object to use as a task within the Block
    task = Task()
    block.block.append(task)

    # Create a handler Task object to use as a task within the Block
    task2 = Task(action='add_host')
    block.block.append(task2)

    # Create a Meta Task object to use as a task within the Block
    task3 = Task(action='meta')
    block.block.append(task3)

    # Create a role to use as a dependency chain
    role = Role()

    # Create a handler Task object to use within the dependency chain
    task4 = Task(action='add_host')
    role.tasks.append(task4)

    # Create a Meta Task object to

# Generated at 2022-06-21 00:17:21.327813
# Unit test for method __ne__ of class Block
def test_Block___ne__():

    # TODO: Test with different parameters
    # ansible.parsing.yaml.objects.AnsibleUnicode object
    name = None

    # ansible.parsing.yaml.objects.AnsibleUnicode object
    value = None

    # ansible.parsing.yaml.objects.AnsibleUnicode object
    attr = None

    # ansible.parsing.yaml.objects.AnsibleUnicode object
    header = None

    # ansible.parsing.yaml.objects.AnsibleUnicode object
    task = None

    # ansible.parsing.yaml.objects.AnsibleUnicode object
    block = None

    # ansible.parsing.yaml.objects.AnsibleUnicode object
    rescue = None

# Generated at 2022-06-21 00:17:27.013354
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = Block()
    block.block = [{'action': 'action', 'tags': 'tag'}]
    
    # First test: no tags.
    new_block = block.filter_tagged_tasks(all_vars={})
    assert block.block == new_block.block
    # Second test: exception raised
    new_block.block == block.filter_tagged_tasks(all_vars={'skip_tags': 'tag'})
    assert len(new_block.block) == 0

# Generated at 2022-06-21 00:17:38.217239
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    data = {'action': 'meta', 'block': 'block', 'rescue': 'rescue', 'always': 'always', 'when': 'when', 'dep_chain': 'dep_chain', 'role': 'role', 'parent': 'parent', 'parent_type': 'parent_type'}
    
    block.deserialize(data)
    assert block.action == 'meta'
    assert block.block == 'block'
    assert block.rescue == 'rescue'
    assert block.always == 'always'
    assert block.when == 'when'
    assert block.dep_chain == 'dep_chain'
    assert block.role == 'role'
    assert block.parent == 'parent'


# Generated at 2022-06-21 00:17:42.800327
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    """
    If a simple task is given, an implicit block for that single task
    is created, which goes in the main portion of the block.
    """
    block = Block()
    simple_task = dict(name = 'test-block2')
    assert block.preprocess_data(simple_task) == dict(block=[simple_task])

# Generated at 2022-06-21 00:17:50.027469
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    '''
    Unit test for method get_dep_chain of class Block
    '''
    
    d = dict()

    my_block = Block(play = None, 
                     parent_block = None, 
                     role = None, 
                     task_include = None,
                     implict = False,
                     use_handlers = False, 
                     )
    my_block.load_data(d)
    assert my_block._dep_chain == None
    
    d['dep_chain'] = ['a', 'b', 'c']
    my_block.load_data(d)
    assert my_block._dep_chain == ['a', 'b', 'c']
    
    

test_Block_get_dep_chain()


# Generated at 2022-06-21 00:17:52.616883
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    import types
    block = Block()
    assert type(block.__repr__())==types.StringType

# Generated at 2022-06-21 00:17:54.792038
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    b = Block()
    assert b.__ne__(b) == True


# Generated at 2022-06-21 00:18:24.977931
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
  abc_dict = {"block": [{"block": [{"block": [{"block": [], "rescue": [], "always": []}], "rescue": []}], "rescue": [], "always": []}], "rescue": [], "always": []}
  test_block = Block.load(abc_dict)
  assert type(test_block.get_first_parent_include()) == None


# Generated at 2022-06-21 00:18:33.179461
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.parsing.vault import VaultLib
    vault_pass = os.environ.get('ANSIBLE_VAULT_PASSWORD_FILE', None)
    assert(vault_pass is not None)
    block_vars = {"foo": "bar"}

    try:
        with open(vault_pass, 'r') as f:
            va = VaultLib([f.read().strip()])
            block_vars = va.decrypt(block_vars)
    except:
        pass

    class MockRole(Role):
        def __init__(self):
            self._tasks = []
            self._name = ""

        @property
        def tasks(self):
            return self._tasks

        @tasks.setter
        def tasks(self, value):
            self._tasks = value

# Generated at 2022-06-21 00:18:45.745586
# Unit test for method load of class Block
def test_Block_load():
    # Instantiate a mock play object to use in the test.
    test_play = Mock()
    test_play.vars = dict()

    # Instantiate a mock variable manager object to use in the test.
    test_variable_manager = Mock()
    test_variable_manager.get_vars.return_value = dict()

    # Instantiate a mock loader object that contains a list of paths to search.
    test_paths = ['/some/fake/path']
    test_loader = DictDataLoader({})
    test_loader.set_basedir('/some/fake/path')

    # The following are a series of tests to cover the different types of blocks
    # that could be supplied to the load() method. They all follow the same
    # basic setup, but with a different block.
    ############################################################################
    testcase

# Generated at 2022-06-21 00:18:49.929741
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
  block = Block()
  assert block.has_tasks() is False
  # 2 rescue tasks in the block
  rescue = [
    {
      'name': 'Test',
      'action': {
        '__ansible_action__': 'debug',
        'msg': '{{hello}}'
      }
    },
    {
      'name': 'Test2',
      'action': {
        '__ansible_action__': 'debug',
        'msg': 'world!'
      }
    }
  ]
  block.load({'rescue': rescue})
  assert block.has_tasks() is True
  # empty block
  block = Block()
  assert block.has_tasks() is False

# Generated at 2022-06-21 00:18:57.585379
# Unit test for method get_vars of class Block

# Generated at 2022-06-21 00:18:59.296917
# Unit test for method serialize of class Block
def test_Block_serialize():
    b = Block()
    b.serialize()


# Generated at 2022-06-21 00:19:09.293329
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible import constants as C
    # initial object
    block_object = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=True)
    # initial data
    data = dict(block=[], rescue=[], always=[], tags=[], when=[], any_errors_fatal=C.DEFAULT_ERRORS_FATAL, auto_resolve=C.DEFAULT_AUTO_RESOLVE)
    block_object.deserialize(data=data)
    # get deserialize data
    deserialize_data = block_object.serialize()
    # same keys
    assert sorted(data.keys()) == sorted(deserialize_data.keys())

# Generated at 2022-06-21 00:19:12.953693
# Unit test for method is_block of class Block
def test_Block_is_block():
    class TestArgs(object):

        def __init__(self, block):
            self.block = block

    assert Block.is_block(TestArgs(block="I am a block"))
    assert not Block.is_block(None)
    assert not Block.is_block('I am not a block')

# Generated at 2022-06-21 00:19:21.867809
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-21 00:19:27.012298
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    data = load_fixture('basic_playbook.yml')
    play = Play.load('test_play', data[0], variable_manager=variable_manager, loader=loader)
    result = repr(play.get_task_blocks()[0])
    assert type(result) == str
    assert result == '<Block (1 tasks)>'


# Generated at 2022-06-21 00:20:12.395712
# Unit test for method is_block of class Block
def test_Block_is_block():
  Block.is_block({})


# Generated at 2022-06-21 00:20:15.203160
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    b1 = Block()
    b2 = Block()
    if b1!=b2:
        raise Exception('Unit test for method __eq__ of class Block is failed')


# Generated at 2022-06-21 00:20:27.933902
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # Set up mock objects
    play = mock.MagicMock(spec=Play)
    parent_block = mock.MagicMock(spec=Block)
    role = mock.MagicMock(spec=Role)
    task_include = mock.MagicMock(spec=TaskInclude)
    use_handlers = mock.MagicMock(use_handlers=True)

    # Create instance of class to be tested
    block = Block(play=play, parent_block=parent_block, role=role,
        task_include=task_include, use_handlers=use_handlers)

    # Test attribute types and default values
    assert isinstance(block.block, list)
    assert isinstance(block.rescue, list)
    assert isinstance(block.always, list)
    assert isinstance(block._play, Play)


# Generated at 2022-06-21 00:20:39.875537
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.playbook.task_include import TaskInclude
    import ansible.playbook.task_include
    import ansible.playbook
    import ansible.playbook.handler_task_include
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.template
    # static
    parent = ansible.playbook.task_include.TaskInclude()
    parent.statically_loaded = True
    first = ansible.playbook.block.Block(parent)

# Generated at 2022-06-21 00:20:47.175169
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    v_mgr = VariableManager()
    templar = Templar(loader=None, variables=v_mgr)
    p_context = PlayContext()

    v_mgr.set_inventory(inventory=None)
    v_mgr.set_variable_manager(v_mgr)

    Block(templar=templar, vars=v_mgr, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)

    loader = DataLoader()

# Generated at 2022-06-21 00:20:56.437682
# Unit test for constructor of class Block

# Generated at 2022-06-21 00:21:04.925535
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    ds = dict(block=[dict()])
    block = Block.load(ds)
    assert block.block[0]._attributes == dict()
    block = Block.load(ds['block'])
    assert block.block[0]._attributes == dict()
    ds = dict()
    block = Block.load(ds['block'])
    assert block.block[0]._attributes == dict()
    block = Block.load(ds)
    assert block.block[0]._attributes == dict()
# end unit test for Block.preprocess_data

# Generated at 2022-06-21 00:21:06.611080
# Unit test for method copy of class Block
def test_Block_copy():
    # copy(self, exclude_parent=False, exclude_tasks=False)
    pass



# Generated at 2022-06-21 00:21:12.791629
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    class FakeTaskInclude(object):
        def __init__(self, parent):
            self._parent = parent

        def all_parents_static(self):
            return self._parent.all_parents_static()

    class FakeParent(object):
        def __init__(self, statically_loaded, parent):
            self.statically_loaded = statically_loaded
            self._parent = parent

        def all_parents_static(self):
            if not self.statically_loaded:
                return False
            return self._parent.all_parents_static()

    # Create a complete tree:
    #                       FakeParent(1)
    #                      /
    #                     FakeParent(1)
    #                    /
    # FakeTaskInclude(1)-FakeParent(0)-FakeParent(1)
    #                    \             /
    #                    

# Generated at 2022-06-21 00:21:13.982597
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    assert True == False
