

# Generated at 2022-06-21 00:12:16.192192
# Unit test for method serialize of class Block
def test_Block_serialize():
    from ansible.playbook.task import Task
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    
    tk = Task.load(dict(action=dict(module='raw', args=dict(msg='HELLO'))), play=dict())
    tk_serialized = tk.serialize()


# Generated at 2022-06-21 00:12:27.199693
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    import json


# Generated at 2022-06-21 00:12:29.722447
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    my_block = Block()
    my_block2 = Block()
    assert(my_block == my_block2)

# Generated at 2022-06-21 00:12:31.430855
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block = Block()
    assert block.__repr__() is not None


# Generated at 2022-06-21 00:12:34.899233
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    host1 = Host('test')
    block1 = Block(u'block', host1)
    task1 = Task(u'name', host1)
    block1.block.append(task1)
    assert(block1.has_tasks() == True)


# Generated at 2022-06-21 00:12:36.874269
# Unit test for method load of class Block
def test_Block_load():
    my_block = {}
    block_obj = Block()
    block_obj.load(my_block)


# Generated at 2022-06-21 00:12:41.634066
# Unit test for constructor of class Block
def test_Block():
    block = Block(
        play=dict(
            name="play",
            hosts=["host"],
            gather_facts="no",
            tasks=[
                dict(
                    block=dict(
                        block=["task1"]
                    )
                )
            ]
        ),
        block=["task2"],
        rescue=["task3"],
        always=["task4"]
    )

    assert block.block == ["task2"]
    assert block.rescue ==  ["task3"]
    assert block.always ==  ["task4"]

    assert block.block[0].block == ["task1"]

# Generated at 2022-06-21 00:12:54.526579
# Unit test for method load of class Block
def test_Block_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    inv = Inventory(loader=loader)
    variable_manager = VariableManager()
    variable_manager.set_inventory(inv)

    fake_play = dict(vars={'a': 1, 'b': '{{a}}', 'c': '{{b}}'})

    b1 = Block.load(dict(name='first', with_items='{{test}}', debug='{{test}}'), play=fake_play, variable_manager=variable_manager)
    print(('b1.name is', b1.name))
    print(('b1.loop is', b1.loop))


# Generated at 2022-06-21 00:12:58.914753
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    b_obj = Block()
    b_obj._dep_chain = [1, 2, 3, 4]
    result = b_obj.get_dep_chain()
    if [1, 2, 3, 4] == result:
        print("Test get_dep_chain: Pass")
    else:
        print("Test get_dep_chain: Fail")



# Generated at 2022-06-21 00:13:11.599821
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.playbook import Task
    my_Block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=None)
    my_Task = Task(play=None, ds=None, module_vars=dict(), task_vars=dict(), default_vars=dict(), role=None, task_include=None, role_params=dict(), use_handlers=False, debug_hide_sensitive=False, loader=None, variable_manager=None, templar=None, static_vars=dict())

# Generated at 2022-06-21 00:13:26.615817
# Unit test for method copy of class Block
def test_Block_copy():
    A = Block()
    B = A.copy()
    assert isinstance(B, Block)


# Generated at 2022-06-21 00:13:29.071726
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    block = Block('block')
    second_block = Block('second_block')
    assert (block == second_block) == False


# Generated at 2022-06-21 00:13:33.546511
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Setup
    b = Block(play=Play(), parent_block=None, role=Role(), task_include=None, use_handlers=False, implicit=False, static=False)

    # Test
    b.all_parents_static()



# Generated at 2022-06-21 00:13:41.170525
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # test case 1:
    # parent is not static
    block_obj = Block()
    block_obj.statically_loaded = False
    block_obj2 = Block(parent=block_obj)
    assert not block_obj2.all_parents_static()
    # test case 2:
    # parent is static
    block_obj = Block()
    block_obj.statically_loaded = True
    block_obj2 = Block(parent=block_obj)
    assert block_obj2.all_parents_static()



# Generated at 2022-06-21 00:13:43.135447
# Unit test for method is_block of class Block
def test_Block_is_block():
    data = {'block': ['a', 'b']}
    assert Block.is_block(data)


# Generated at 2022-06-21 00:13:48.452901
# Unit test for constructor of class Block
def test_Block():
    b = Block()
    assert b
    assert b == {}
    assert b.block is None
    assert b.rescue is None
    assert b.always is None

    b = Block(block=[1,2,3,], rescue=[4,5,6,], always=[7,8,9])
    assert b == {'block': [1,2,3,], 'rescue': [4,5,6,], 'always': [7,8,9]}

# Generated at 2022-06-21 00:13:56.602182
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block = Block()
    assert block.get_first_parent_include() == None
    import ansible.playbook.task_include
    task_include = ansible.playbook.task_include.TaskInclude()
    block._parent = task_include
    assert block.get_first_parent_include() == task_include

if __name__ == "__main__":
    test_Block_get_first_parent_include()

# Generated at 2022-06-21 00:14:00.185433
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    b = Block()
    data = dict()
    b.deserialize(data)
    assert True


# Generated at 2022-06-21 00:14:02.422570
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block([1,2])==False,"Test succeed"

# Unit tests for method get_dep_chain of class Block

# Generated at 2022-06-21 00:14:07.188204
# Unit test for method __ne__ of class Block
def test_Block___ne__():
  block_1 = Block()
  block_1._valid_attrs = dict()
  block_1._attributes = dict()
  block_1._parent = None
  block_1._play = None
  block_1._dep_chain = None
  block_1._use_handlers = None
  block_1._role = None
  block_1._loader = None
  block_1._implicitly_converted = False
  block_1._id = None
  block_2 = Block()
  block_2._valid_attrs = dict()
  block_2._attributes = dict()
  block_2._parent = None
  block_2._play = None
  block_2._dep_chain = None
  block_2._use_handlers = None
  block_2._role = None
  block_

# Generated at 2022-06-21 00:14:34.152757
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    data = dict()
    data['block'] = dict()
    data['block']['tasks'] = dict()
    data['block']['tasks'][1] = dict()
    data['block']['tasks'][1]['include'] = dict()
    data['block']['tasks'][1]['include']['name'] = 'test.yml'
    # Create a parent object to call method get_include_params
    parent = Block()
    field_info = dict()
    field_info['as_type'] = 'name'
    field_info['attrs'] = dict()
    temp1 = dict()
    temp1['include'] = dict()
    temp1['include']['with'] = dict()

# Generated at 2022-06-21 00:14:46.637779
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    _play = "play"
    _role = "role"
    _dep_chain = "dep_chain"
    _parent = "parent"
    _use_handlers = "use_handlers"
    _loader = "loader"
    _variable_manager = "variable_manager"
    _task_include = "task_include"
    _block = "block"
    _rescue = "rescue"
    _always = "always"
    _when = "when"
    _loop = "loop"
    _loop_with_items = "loop_with_items"
    _async_seconds = "async_seconds"
    _async_poll_interval = "async_poll_interval"
    _become = "become"
    _become_user = "become_user"
   

# Generated at 2022-06-21 00:14:47.818786
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    pass


# Generated at 2022-06-21 00:14:50.544878
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    ds = {
        'name': 'fail'
    }
    ds = Block.load(ds)
    ds.set_loader(None)


# Generated at 2022-06-21 00:15:01.571463
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    play = Play()
    role = Role()
    task_include = TaskInclude()

    play.load(dict(
        name = "Test Play",
        hosts = "localhost",
        gather_facts = "no",
        tasks = [
            dict(
                debug = dict(msg = "First task!"),
                tags = ['tag-a', 'tag-b'],
            ),
        ]
    ), variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 00:15:05.269177
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    assert repr(block) == "<Block (name=None, only_tags=[], skip_tags=[], implicit=False, rescue=[], always=[], block=[])>"


# Generated at 2022-06-21 00:15:07.784710
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = make_block()
    block.filter_tagged_tasks(["tagged"])


# Generated at 2022-06-21 00:15:13.504283
# Unit test for method load of class Block
def test_Block_load():
    data = dict()
    play = Play()
    parent_block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None

    b = Block.load(data, play, parent_block, role, task_include, use_handlers, variable_manager, loader)


# Generated at 2022-06-21 00:15:17.356880
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    _loader = DictDataLoader(dict())
    _variable_manager = VariableManager()
    _block = Block(loader=_loader, variable_manager=_variable_manager)
    assert _block.get_vars() == {}

# Generated at 2022-06-21 00:15:26.620474
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task_include import TaskInclude
    block = Block()

    # Test with a task_include
    task_include = TaskInclude()
    task_include._loader = 'test-loader'
    block._parent = task_include
    block.set_loader(object())
    assert block._loader == 'test-loader'
    assert block._parent._loader == 'test-loader'
    assert block._dep_chain == [task_include]

    # Test with a block
    block_parent = Block()
    block_parent._loader = 'test-loader'
    block._parent = block_parent
    block.set_loader(object())
    assert block._loader == 'test-loader'
    assert block._parent._loader == 'test-loader'
    assert block._dep_chain == []

    # Test

# Generated at 2022-06-21 00:15:46.733116
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    class Mock_Block:
        def __init__(self):
            self.block = [Mock_Task()]
            self.rescue = []
            self.always = []
    
    class Mock_Task:
        def __init__(self):
            self.action = 'mock'
            self.implicit = False
        def evaluate_tags(self, only_tags, skip_tags, all_vars=None):
            return False

    class Mock_Playbook:
        def __init__(self):
            self.only_tags = set()
            self.skip_tags = set()

    class Mock_Role:
        def __init__(self):
            self._attributes = dict()
        def set_loader(self, loader):
            None


# Generated at 2022-06-21 00:15:50.281227
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Mock data
    dep_chain = [True]
    parent = MagicMock()
    parent._dep_chain = dep_chain
    
    # Test function
    block = Block()
    block._parent = parent
    result = block.get_dep_chain()
    assert result == dep_chain
    pass

# Generated at 2022-06-21 00:15:56.078138
# Unit test for method is_block of class Block
def test_Block_is_block():
    data = None
    assert not Block.is_block(data)

    data = {'block': [], 'rescue': [], 'always': []}
    assert Block.is_block(data) == True

    data = {'a': 123}
    assert Block.is_block(data) == False

    return data
print(test_Block_is_block())


# Generated at 2022-06-21 00:16:07.998883
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Create a mock object for loader.
    loader = 'loader'
    # Create a mock object for role.
    role = 'role'
    # Create a mock object for parent.
    parent = 'parent'

    # Create a Block object for test.
    block = Block(role=role, parent_block=parent)

    # Get the value of attribute _loader before calling set_loader() method.
    value_of__loader = block._loader

    # Call method set_loader() of block.
    block.set_loader(loader)

    # Check the value of attribute _loader after calling set_loader() method.
    assert block._loader == loader

    # Check the value of attribute _loader after calling set_loader() method is not equal the value before.
    assert block._loader != value_of__loader

    # Check the value of attribute _loader

# Generated at 2022-06-21 00:16:19.148348
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    import os
    import unittest
    import sys

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib'))
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.plugins.loader import action_loader

    class TestBlock(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_filter_tagged_tasks(self):
            play_context = {}

# Generated at 2022-06-21 00:16:23.884930
# Unit test for method copy of class Block
def test_Block_copy():
    # Initialize a block object to test copy
    block = Block(Implicit('implicit1'), children=[Task('task1'), Task('task2')])
    new_block = block.copy()
    assert new_block.name == 'block'
    assert new_block.block == block.block
    assert new_block.always == block.always
    assert new_block.rescue == block.rescue
    assert new_block._role == block._role
    assert new_block.dep_chain == block.dep_chain
    assert new_block.children == block.children
    assert new_block._parent == block._parent
    assert new_block.use_handlers == block.use_handlers
    assert new_block.loop_control == block.loop_control
    assert new_block._attribute_overrides == block._attribute_

# Generated at 2022-06-21 00:16:35.665998
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    _play = None
    _use_handlers = True
    _name = 'block_name'
    _block = [{
        'name': 'debug',
        'debug': {
            'msg': 'hi'
        }
    }]
    _rescue = None
    _always = None
    _vars = None
    _when = None
    _register = None
    _failed_when = None
    _changed_when = None
    _any_errors_fatal = None
    _any_unreachable_fatal = None
    _notify = None
    _first_available_file = None
    _include = None
    _include_role = None
    _include_tasks = None
    _until = None
    _with_items = [
        1,
        3
    ]
    _

# Generated at 2022-06-21 00:16:36.299160
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    block = Block()


# Generated at 2022-06-21 00:16:42.490211
# Unit test for constructor of class Block
def test_Block():
    b = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    b.load({'block': [{'local_action': {'module': 'shell', 'args': 'ls'}}], 'always': [{'local_action': {'module': 'shell', 'args': 'ls'}}]})
    assert b.load({'block': [{'local_action': {'module': 'shell', 'args': 'ls'}}], 'always': [{'local_action': {'module': 'shell', 'args': 'ls'}}]}) == b

# Generated at 2022-06-21 00:16:45.424394
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block=Block()
    if(block.has_tasks()):
        print("Unit test passed")
    else:
        print("Unit test failed")

# Generated at 2022-06-21 00:17:14.016764
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    #from ansible.playbook.role_include import RoleInclude
    role_include = RoleInclude()
    role_include.statically_loaded = False
    p1 = Play()
    p1.statically_loaded = False
    p2 = Play()
    p2.statically_loaded = False
    p3 = Play()
    p3.statically_loaded = True
    p4 = Play()
    p4.statically_loaded = True
    b1 = Block()
    b1.statically_loaded = False
    b2 = Block()
    b2.statically_loaded = False
    b3 = Block()
    b3.statically_loaded = True
    b4 = Block()
    b4.statically_loaded = True
    t1 = Task()

# Generated at 2022-06-21 00:17:15.285117
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    block_obj=Block()
    list_vars=block_obj.get_vars()
    assert list_vars=={}

# Generated at 2022-06-21 00:17:23.931351
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    args = dict(
        block=[
            dict(
                rescue=[
                    dict(
                        name='test',
                        action='something',
                        always=[
                            dict(
                                delegate_to='localhost',
                                delegate_facts=False,
                                any_errors_fatal=True,
                                name='test',
                                action='something'
                            )
                        ],
                        register='test'
                    )
                ],
                delegate_to='localhost',
                delegate_facts=False,
                any_errors_fatal=True,
                name='test',
                action='something'
            )
        ],
        delegate_to='localhost',
        delegate_facts=False,
        any_errors_fatal=True,
        name='test',
        action='something'
    )

# Generated at 2022-06-21 00:17:25.838143
# Unit test for method deserialize of class Block
def test_Block_deserialize():
  ds = {}
  b = Block()
  b.deserialize(ds)


# Generated at 2022-06-21 00:17:28.274043
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block({'block': []})
    assert not Block.is_block({})

# Generated at 2022-06-21 00:17:40.006806
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    from ansible.playbook.task import Task

    # test 1
    # Check that has_tasks returns False when no block/rescue/always
    block = Block()
    assert block.has_tasks() == False

    # test 2
    # Check that has_tasks returns True when block
    task = Task(action="")
    block = Block()
    block.block = [task]
    assert block.has_tasks() == True

    # test 3
    # Check that has_tasks returns True when rescue
    task = Task(action="")
    block = Block()
    block.rescue = [task]
    assert block.has_tasks() == True

    # test 4
    # Check that has_tasks returns True when always
    task = Task(action="")
    block = Block()

# Generated at 2022-06-21 00:17:42.913636
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    b = Block()
    b._parent = Block()
    b._parent._vars = {'a': 'z'}
    assert b.vars == {'a': 'z'}


# Generated at 2022-06-21 00:17:46.462441
# Unit test for constructor of class Block
def test_Block():
    b = Block()

# Generated at 2022-06-21 00:17:48.885116
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    obj = Block()
    loader = 'foo'
    result = obj.set_loader(loader)
    assert result is None


# Generated at 2022-06-21 00:17:55.384778
# Unit test for constructor of class Block
def test_Block():
    b = Block.load(dict(block=["test"]))
    assert b.block[0].action == "test"
    assert len(b.block) == 1
    assert b.implicit is True
    assert b.statically_loaded is True

if __name__ == "__main__":
    #import doctest
    #doctest.testmod()
    test_Block()

# Generated at 2022-06-21 00:18:18.025264
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    host_vars_dict = dict()
    ji_vars_dict = dict()
    task_vars_dict = dict()
    instance = Block()

# Generated at 2022-06-21 00:18:20.766051
# Unit test for method get_dep_chain of class Block

# Generated at 2022-06-21 00:18:24.436251
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    parent = Mock()
    block = Block(parent=parent)
    assert block.get_first_parent_include() == parent


# Generated at 2022-06-21 00:18:32.896092
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    mock_load_data = MagicMock()
    mock_data = MagicMock()
    #No parent block
    b = Block()
    with patch("ansible.playbook.block.Block.load_data", mock_load_data):
    #    b = Block.load(mock_data)
        b.statically_loaded = False
        b._ds = mock_data
        b._attributes["block"] = mock_data
    assert b.get_include_params() == {}
    #Parent block
    mock_parent = MagicMock()
    mock_parent.get_include_params = MagicMock(return_value = {'a':'b'})
    mock_parent.get_first_parent_include = MagicMock(return_value = mock_parent)

# Generated at 2022-06-21 00:18:37.136640
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    # First, we create a Block object
    block = Block()
    arg = block.get_include_params()
    assert isinstance(arg, dict)
    assert len(arg) == 0


# Generated at 2022-06-21 00:18:48.610348
# Unit test for method serialize of class Block
def test_Block_serialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    play_context = PlayContext()#initialize play_context
    play_context._attributes = {
        'no_log': False,
        'no_tags': False,
        'verbosity': 0,
        'force_handlers': False,
    }

    play = Play()#initialize play
    play._included_file = "../../test/functional/targets/test_include.yml"

# Generated at 2022-06-21 00:18:53.534341
# Unit test for constructor of class Block
def test_Block():
    # Test code to verify constructor of class Block
    block = Block()
    assert(block)
    assert(isinstance(block, Block))
    assert(0 == len(block.block))
    assert(0 == len(block.rescue))
    assert(0 == len(block.always))

# Generated at 2022-06-21 00:19:05.868712
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block = Block(name='within_block')
    block.block.extend([Block()])
    block.rescue.extend([Block()])
    block.always.extend([Block()])
    block.block.extend([TaskInclude()])
    block.rescue.extend([TaskInclude()])
    block.always.extend([TaskInclude()])
    assert repr(block) == "block(within_block): block=1, rescue=1, always=1, implicit=True, tasks=3"
    assert repr(block.block[0]) == "block(within_block): block=0, rescue=0, always=0, implicit=True, tasks=0"

# Generated at 2022-06-21 00:19:08.225545
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block = Block()
    try:
        assert repr(block)
    except Exception as exception:
        assert False, "AssertionError: {}".format(exception)


# Generated at 2022-06-21 00:19:16.694887
# Unit test for method __eq__ of class Block
def test_Block___eq__():
  # hack for using Ansible's objects as real python objects
  from ansible.parsing.dataloader import DataLoader
  from ansible.vars import VariableManager
  from ansible.inventory import Inventory
  from ansible.playbook.play import Play
  loader = DataLoader()
  variable_manager = VariableManager()
  inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list='localhost')

# Generated at 2022-06-21 00:20:46.887334
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    def get_vars_test_data():
        task_vars = {'a': 1, 'b': 2, 'c': 3}
        loop_vars = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
        templar = Templar(loader=None, shared_loader_obj=None)
        task = Task(block=None, role=None, task_include=None, use_handlers=False)
        block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
        block._parent = task
        play = Play()

        return (task_vars, loop_vars, templar, task, block, play)

    task_vars, loop_vars

# Generated at 2022-06-21 00:20:58.688611
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.block import load_list_of_tasks
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    ds = """
    - name: task_1
    - name: task_2
    - name: task_3
    include: test_include.yml
    - name: task_4
    - name: task_5
    - name: task_6
    """
    #test case 1: 1st task: block, 2nd task: task_include, 3rd task: handler_task_include

# Generated at 2022-06-21 00:21:04.283790
# Unit test for constructor of class Block
def test_Block():
    a = Block()
    assert a.block is None
    assert a.rescue is None
    assert a.always is None
    assert a.loop is None
    assert a.loop_args is None
    assert a.loop_with is None
    assert a.retries is None
    assert a.until is None
    assert a.when is None


# Generated at 2022-06-21 00:21:08.443044
# Unit test for method is_block of class Block
def test_Block_is_block():
    for (data, expected_output) in (
            ({'block': [{'hosts': 'xxx', 'tasks': [{'action': 'aa', 'args': {'name': 'xx'}}]}]}, True),
            ([], False),
            (dict(), False),
    ):
        assert Block.is_block(data) == expected_output



# Generated at 2022-06-21 00:21:09.500448
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    pass

# Generated at 2022-06-21 00:21:12.292558
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    block = Block()
    assert block.__ne__(None) is True
    assert block.__ne__(block) is False

# Generated at 2022-06-21 00:21:13.361498
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    pass

# Generated at 2022-06-21 00:21:18.202161
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # create mock data
    play = create_mock_data()
    block = play.get_block_list()[0]
    # call test method
    result = block.get_dep_chain()
    assert len(result) == 2
    assert type(result[0]) == Block
    assert type(result[1]) == Block


# Generated at 2022-06-21 00:21:23.104382
# Unit test for constructor of class Block
def test_Block():
    # Constructor parameter 'ds' cannot be None
    try:
        block1 = Block(None)
        is_fail = 0
    except:
        is_fail = 1
    assert is_fail == 1, "test_Block failed to test_Block constructor"