

# Generated at 2022-06-21 00:12:04.975216
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    t = TaskInclude(name='test_task')
    assert t.get_first_parent_include() is None

    b = Block()
    b.task_include = t
    assert b.get_first_parent_include() is None

    b2 = Block()
    b2.task_include = b
    assert b2.get_first_parent_include() is t

# Generated at 2022-06-21 00:12:13.337465
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    
    # Test for when all parents are static
    
    task_obj = Task()
    block_obj = Block()
    task_obj._parent = block_obj
    block_obj._parent = block_obj
    
    assert block_obj.all_parents_static() == True
    
    # Test for when the first parent is not static
    
    task_include_obj = TaskInclude()
    task_obj._parent = task_include_obj
    task_include_obj._parent = block_obj
    block_obj._parent = block_obj
    
    assert block_obj.all_parents_static() == False
    

# Generated at 2022-06-21 00:12:22.794695
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    b = Block()
    assert b._role is None
    assert b.block is []
    assert b.rescue is []
    assert b.always is []
    assert b._dep_chain is None
    assert b._parent is None
    data = {}
    b.deserialize(data)
    assert b._role is None
    assert b.block is []
    assert b.rescue is []
    assert b.always is []
    assert b._dep_chain is None
    assert b._parent is None
    data = {
        'role': None,
        'block': [],
        'rescue': [],
        'always': [],
        'dep_chain': None,
        'parent': None,
        'parent_type': 'Block'
    }
    b.deserialize(data)
    assert b

# Generated at 2022-06-21 00:12:33.775151
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.vars import VariableManager

    b = Block()
    data = { u'block': [], u'skip_tags': [], u'any_errors_fatal': False, u'always_run': True, u'tags': []}
    b.deserialize(data)

    class obj():
        pass
    ansible_play_context = PlayContext()
    obj.ansible_play_context = ansible_play_context

# Generated at 2022-06-21 00:12:38.970624
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import load_list_of_tasks
    b = Block(
        play=None,
        parent_block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        implicit=False)
    # Case 1: no parent block
    b._parent = None
    assert b.get_first_parent_include() == None
    # Case 2: parent block is a TaskInclude object
    # t1: parent TaskInclude object
    t1 = TaskInclude()
    # t2: a Task object

# Generated at 2022-06-21 00:12:51.526602
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    '''
    Unit test for method get_dep_chain
    of class Block
    '''

    # create the object
    block_obj = Block()

    # get the value of dep_chain which
    # is of type sentinel.Sentinel
    dep_chain = block_obj.get_dep_chain()

    # use the function call to set the value of dep_chain
    # to the empty list.
    block_obj._dep_chain = []

    # check that dep_chain is of type list
    assert type(dep_chain) is list

    # check if the the value of dep_chain is empty
    assert not dep_chain

    # set the value of dep_chain to None.
    block_obj._dep_chain = None

    # get the value of dep_chain through function call
    dep_chain = block_obj

# Generated at 2022-06-21 00:12:58.890994
# Unit test for method is_block of class Block
def test_Block_is_block():
    t = Block.is_block({'block':[{'tasks':[{'include':'main.yml', 'name':'Including main.yml'}]}, {'rescue':[{'tasks':[{'local_action': 'debug msg={{hostvars[inventory_hostname]}}'}, {'local_action': 'debug msg={{hostvars[inventory_hostname]}}'}, {'local_action': 'debug msg={{hostvars[inventory_hostname]}}'}, {'local_action': 'debug msg={{hostvars[inventory_hostname]}}'}], 'always':[{'tasks':[{'local_action': 'debug msg={{hostvars[inventory_hostname]}}'}]}]}]}], 'name': 'ensure nginx is installed'})
   

# Generated at 2022-06-21 00:13:03.907472
# Unit test for method is_block of class Block
def test_Block_is_block():
    mydict = {'block': 'sample'}
    assert Block.is_block(mydict) == True
    mydict = {'not_block': 'sample'}
    assert Block.is_block(mydict) == False



# Generated at 2022-06-21 00:13:13.205907
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    list_of_Block = list()
    dep_chain = ["this", 1]
    list_of_Block.append(Block(dep_chain=dep_chain))
    list_of_Block.append(Block(dep_chain=dep_chain))
    list_of_Block.append(Block(dep_chain=dep_chain))
    list_of_Block.append(Block(dep_chain=dep_chain))
    list_of_Block.append(Block(dep_chain=dep_chain))
    for Block_obj in list_of_Block:
        assert Block_obj.get_dep_chain() == ["this", 1]




# Generated at 2022-06-21 00:13:21.263292
# Unit test for method copy of class Block
def test_Block_copy():

    copyObj = Block()
    copyObj.block = "test_block"
    copyObj.always = "test_always"
    copyObj.rescue = "test_rescue"
    copyObj.meta = "test_meta"
    copyObj.tags = "test_tags"

    returnVal = copyObj.copy()
    assert returnVal.block == "test_block"
    assert returnVal.always == "test_always"
    assert returnVal.rescue == "test_rescue"
    assert returnVal.meta == "test_meta"
    assert returnVal.tags == "test_tags"

# Generated at 2022-06-21 00:14:12.160934
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    b = Block()
    # We cannot test because of assert statement in the method under test
    return

# Generated at 2022-06-21 00:14:13.224686
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    pass



# Generated at 2022-06-21 00:14:19.042981
# Unit test for method serialize of class Block
def test_Block_serialize():
    fp = 'test/units/modules/util/ansible_playbook/playbook/block.py'
    lcp = 'util.ansible_playbook.playbook.block'
    module = load_module_from_file(fp, lcp)

    b = module.Block(dict(foo='bar'))
    module.Block.serialize()



# Generated at 2022-06-21 00:14:31.095830
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block()
    assert b.has_tasks() == False
    b = Block(block = [])
    assert b.has_tasks() == False
    b = Block(block = 'block')
    assert b.has_tasks() == True
    b = Block(rescue = 'block')
    assert b.has_tasks() == True
    b = Block(always = 'block')
    assert b.has_tasks() == True
    b = Block(block = 'block', rescue = 'block', always = 'block')
    assert b.has_tasks() == True
    b = Block(block = [], rescue = [], always = [])
    assert b.has_tasks() == False


# Generated at 2022-06-21 00:14:31.847460
# Unit test for method __ne__ of class Block
def test_Block___ne__():

    pass


# Generated at 2022-06-21 00:14:32.364960
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    pass

# Generated at 2022-06-21 00:14:39.490057
# Unit test for method all_parents_static of class Block

# Generated at 2022-06-21 00:14:41.335936
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    block = Block()
    o = object()
    assert(block != o)



# Generated at 2022-06-21 00:14:46.977026
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    block = Block(
        task_include=None,
        use_handlers=False,
        implicit=False,
        rescue=[],
        always=[],
        parent_block=None,
        play=None,
        role=None,
        block=[]
    )


# Generated at 2022-06-21 00:14:58.134212
# Unit test for method copy of class Block
def test_Block_copy():
    result = True

    # Example from Ansible doc
    # - name: play with a rescue and always
    #   hosts: all
    #   gather_facts: False
    #   vars:
    #     test_var: 77

    #   tasks:
    #     - name: Failing task
    #       fail:
    #         msg: "{{ test_var }}"
    #     - name: Some task
    #       debug:
    #         msg: "{{ test_var }}"
    #     - name: Another task
    #       debug:
    #         msg: "{{ test_var }}"

# Generated at 2022-06-21 00:15:35.962603
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    def create_task(type):
        task = Task()
        task._attributes = {
            'type': type
        }
        return task

    b = Block()
    p0 = Play()
    p0._attributes = {
        'vars': {
            'play_var': 'play_value'
        },
        'roles': [
            {
                'name': 'my_role',
                'vars': {
                    'role_var': 'role_value'
                },
                'block': [
                    create_task('block_var'),
                ]
            }
        ],
    }
    b._parent = p0

# Generated at 2022-06-21 00:15:43.270937
# Unit test for method serialize of class Block
def test_Block_serialize():
    # Setup
    block = Block(use_handlers=True, implicit=True)
    block._ds = dict(block=['sdaf'], rescue=[], always=[], when='asdf')

    # Exercise and verify
    data = block.serialize()
    serialized_block = data
    return serialized_block


if __name__ == "__main__":
    block = test_Block_serialize()
    print("Test result : " + str(block))

# Generated at 2022-06-21 00:15:51.287228
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    #Test for 1st branch
    a = Block(None, None, None, None, None, False, False)
    assert a._dep_chain == None
    #Test for 2nd branch
    a = Block(None, None, None, None, None, False, False)
    b = Block(None, None, None, None, None, False, False)
    c = Block(None, None, None, None, None, False, False)
    d = Block(None, None, None, None, None, False, False)
    e = Block(None, None, None, None, None, False, False)
    e._dep_chain = ['a', 'b', 'c', 'd']
    a._parent = b
    b._parent = c
    c._parent = d
    d._parent = e
    assert a.get

# Generated at 2022-06-21 00:15:53.138019
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    block = ansible.playbook.block.Block()


# Generated at 2022-06-21 00:16:05.574653
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    Stat = namedtuple('Stat', ('st_ctime', 'st_mtime'))

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    result = Block()
    tasks = [Task() for i in range(random.randint(0, 100))]
    for i in range(random.randint(0, 100)):
        tasks.append(Block())
    blocks = [Block(block=tasks) for i in range(random.randint(0, 100))]
    rescue = [Task() for i in range(random.randint(0, 100))]
    for i in range(random.randint(0, 100)):
        rescue.append(Block())
    always = [Task() for i in range(random.randint(0, 100))]

# Generated at 2022-06-21 00:16:13.540104
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    import ansible.playbook
    u = Block()
    obj = ansible.playbook.BaseInclude()
    obj.add_action=lambda k,v:setattr(obj,k,v)
    obj.add_action("block", Block())
    obj.add_action("rescue", Block())
    obj.add_action("always", Block())
    obj.set_loader=lambda x:None
    obj.get_include_params=lambda :{}
    u._parent = obj
    assert u.get_include_params() == {}
    obj.get_include_params=lambda :{'d':'e'}
    assert u.get_include_params() == {'d':'e'}
    u2 = Block()
    obj2 = ansible.playbook.BaseInclude()

# Generated at 2022-06-21 00:16:17.702784
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block = Block()
    ansible_repr = repr(block)
    expected_repr = "Block(block=[] rescue=[] always=[] name=None when=[])"
    assert ansible_repr == expected_repr



# Generated at 2022-06-21 00:16:23.272642
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    t1 = "task1"
    t2 = "task2"
    t3 = "task3"
    task = [t1, t2, t3]
    block = Block()
    result = block.preprocess_data(task)
    assert result == {'block': [t1, t2, t3]}


# Generated at 2022-06-21 00:16:26.642742
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    block_instance = Block()

    block_instance2 = Block()

    assert block_instance.__ne__(block_instance2) == NotImplemented


# Generated at 2022-06-21 00:16:32.376639
# Unit test for method serialize of class Block
def test_Block_serialize():
    # create block obj by calling block class constructor
    my_block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=True)
    # we are expecting the serialize() call to not raise an exception
    assert my_block.serialize()



# Generated at 2022-06-21 00:17:05.866198
# Unit test for method __repr__ of class Block
def test_Block___repr__():
   block = Block('a_Block')
   repr(block)

# Generated at 2022-06-21 00:17:08.966563
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    loader = object()
    block.set_loader(loader)
    
    assert block._loader == loader

# Generated at 2022-06-21 00:17:11.501985
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    # Create a new Block with no parameters
    block = Block()

    # Use __repr__ method on Block
    repr(block)

# Generated at 2022-06-21 00:17:17.793384
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    my_play = Play()
    my_play._ds = dict(tasks=dict(block=dict(tasks=dict(a=1, b=2, c=3))))
    my_block = Block(play=my_play, task_include=None, use_handlers=False)
    ds = [1, 2, 3]
    my_block.preprocess_data(ds)


# Generated at 2022-06-21 00:17:25.138673
# Unit test for method serialize of class Block

# Generated at 2022-06-21 00:17:28.068815
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    p = Play()
    b = Block(play=p)
    assert b.get_vars()=={}

# Generated at 2022-06-21 00:17:30.048887
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    b = Block()
    b.get_first_parent_include()


# Generated at 2022-06-21 00:17:41.202768
# Unit test for method serialize of class Block
def test_Block_serialize():
    my_block = Block(block=[Task(), Task()], rescue=[Task()])

    # serialize() should return a dict
    assert isinstance(my_block.serialize(), dict)

    # serialize() should return a dict containing the block
    assert my_block.serialize().get('block', False)

    # serialize() should return a dict containing the rescue
    assert my_block.serialize().get('rescue', False)

    # serialize() should return a dict not containing the always
    assert not my_block.serialize().get('always', False)


# Generated at 2022-06-21 00:17:44.529067
# Unit test for method serialize of class Block
def test_Block_serialize():
    my_block = Block()
    test_data = dict()
    test_data['_parent'] = dict()
    test_data['_dep_chain'] = list()
    my_block.deserialize(test_data)
    assert my_block.serialize() == test_data


# Generated at 2022-06-21 00:17:47.827331
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    my_block = Block(
        implicit = 'yes',
        rescue = [],
        always = []
    )
    my_block2 = Block(
        implicit = 'yes',
        rescue = [],
        always = []
    )
    assert my_block == my_block2


# Generated at 2022-06-21 00:18:15.342568
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude

    parent = TaskInclude()
    parent._task = Task()
    assert(parent.get_first_parent_include() == parent)

    block1 = Block()
    block1._parent = parent
    block1._task = Task()
    assert(block1.get_first_parent_include() == parent)

    block2 = Block()
    block2._parent = block1
    block2._task = Task()
    assert(block2.get_first_parent_include() == parent)

    block3 = Block()
    block3._parent = block2
    block3._task = Task()

# Generated at 2022-06-21 00:18:28.458156
# Unit test for method load of class Block
def test_Block_load():
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.task_include
    data = {
        'block': [
            {
                'include': 'main.yml',
                'vars': [
                    {'var1': 'val1'},
                    {'var2': 'val2'}
                ]
            },
            {
                'include': 'main2.yml',
                'vars': [
                    {'var3': 'val3'},
                    {'var4': 'val4'}
                ]
            }
        ]
    }

    # Create an instance of a task
    task1 = ansible.playbook.task.Task()
    task1._parent

# Generated at 2022-06-21 00:18:41.250587
# Unit test for method copy of class Block
def test_Block_copy():
    args = dict(
        exclude_parent=dict(
            default=False,
            type='bool'
        ),
        exclude_tasks=dict(
            default=False,
            type='bool'
        )
    )
    block = Block(module_defaults=dict(params=args), module_args=random_args(args, count=1))
    block._dep_chain = [
        {
            "attribute_name": "dep_chain",
            "attribute_value": "[]"
        }
    ]
    block._parent = "parent"
    # Test with exclude_parent False
    result = block.copy(exclude_parent=False)
    assert result._parent == "parent", "Expected 'parent' got %s" % result._parent

# Generated at 2022-06-21 00:18:52.641733
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    bb = Block(block=[Task(action='setup')])
    bh = Block(block=[Task(action='setup')], handlers=[Handler(task='setup')])
    br = Block(block=[Task(action='setup')], rescue=[Handler(task='setup')])
    ba = Block(block=[Task(action='setup')], always=[Handler(task='setup')])
    b = Block(block=[Task(action='setup')], rescue=[Handler(task='setup')], always=[Handler(task='setup')])
    bn = Block(block=[], rescue=[], always=[])
    assert bb.has_tasks()
    assert bh.has_tasks()
    assert br

# Generated at 2022-06-21 00:19:05.283021
# Unit test for method copy of class Block
def test_Block_copy():
    data = {
        'block': [
            { 'debug': 'msg={{inventory_hostname}}' },
            { 'debug': 'msg={{inventory_hostname}}' }
        ],
        'rescue': [
            { 'debug': 'msg={{inventory_hostname}}' },
            { 'debug': 'msg={{inventory_hostname}}' }
        ],
        'always': [
            { 'debug': 'msg={{inventory_hostname}}' },
            { 'debug': 'msg={{inventory_hostname}}' }
        ],
        'name': 'foo',
        'register': 'myvar',
        'changed_when': False,
        'failed_when': False,
        'ignore_errors': True,
        'delegate_to': 'localhost'
    }
    b = Block.load

# Generated at 2022-06-21 00:19:06.784830
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    data = {}
    assert Block.set_loader(data) == None
    return True

# Generated at 2022-06-21 00:19:15.221397
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    data1_dict = {"name": "test_block_1", "block": [{"name": "test_task_1", "debug": "msg=yo"},{"name": "test_task_2", "debug": "msg=so"}]}
    data2_dict = {"name": "test_block_2", "block": [{"name": "test_task_3", "debug": "msg=hoo"},{"name": "test_task_4", "debug": "msg=do"}]}
    task1 = Task()
    task1.load(data={"name": "test_task_1", "debug": "msg=yo"}, variable_manager=None, loader=None)
    task2 = Task()

# Generated at 2022-06-21 00:19:23.581236
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    '''
    Unit test for method __repr__ of class Block
    '''

    # Create an instance of class Block without mandatory
    # member variables
    block = Block()

    # Try to call method __repr__ of class Block without
    # argument
    try:
        block.__repr__()
    except TypeError as e:
        assert hasattr(e, 'message')
        assert e.message == '__repr__() takes exactly 1 argument (0 given)'
        assert hasattr(e, 'args')
        assert len(e.args) == 2
        assert e.args[0] == '__repr__() takes exactly 1 argument (0 given)'
        assert e.args[1] == ('',)
    except Exception as e:
        assert False, 'The code should not be reachable, an Exception is raised'

# Generated at 2022-06-21 00:19:33.406378
# Unit test for constructor of class Block
def test_Block():
    my_block = Block()
    my_block.statically_loaded = False
    my_block.curdir = "/path/to/curdir"
    my_block.block = list()
    my_block.block.append("task1")
    my_block.block.append("task2")
    my_block.block.append("task3")
    my_block.rescue = list()
    my_block.rescue.append("task1")
    my_block.always = list()
    my_block.always.append("task1")
    my_block.vars = dict()
    my_block.vars["str_key"] = "str_value"
    my_block.vars["int_key"] = 1
    my_block.vars["float_key"] = 1.1
   

# Generated at 2022-06-21 00:19:34.786310
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(object())

# Generated at 2022-06-21 00:20:11.536769
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    # -- these are Block instances
    parent = Block()
    parent._parent = None
    parent.name = "not_an_include"
    parent.block = []

    block = Block()
    block._parent = parent
    block.name = "not_an_include"
    block.block = []

    assert block.get_first_parent_include() == None

    # -- these are Block instances
    parent = Block()
    parent._parent = None
    parent.name = "not_an_include"
    parent.block = []

    include = TaskInclude()
    include._parent = parent
    include.name = "include"
    include.block = []
    include.tasks = []

    block = Block()
    block._parent = include
    block.name = "not_an_include"
    block.block

# Generated at 2022-06-21 00:20:12.470818
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    pass


# Generated at 2022-06-21 00:20:19.946245
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    loader = Mock()
    variable_manager = Mock()
    play = Mock()
    parent_block = Mock()
    role = Mock()
    task_include = Mock()
    use_handlers = Mock()
    data = Mock()
    block = Block.load(data, play, parent_block, role, task_include, use_handlers, variable_manager, loader)
    block.preprocess_data(data)



# Generated at 2022-06-21 00:20:24.949929
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block(task_include=None, role=None, play=None, implicit=False, parent_block=None, use_handlers=False)
    block.serialize()
    block.deserialize({})
    assert block.copy() is not None
    assert block.serialize() is not None


# Generated at 2022-06-21 00:20:37.956778
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    print("start of test_Block_all_parents_static")
    from ansible.playbook.task import Task

    # Arrange
    play = Play()
    include1 = TaskInclude("tests/include/first", play, play.basedir)
    block1 = Block(play=play, parent_block=include1)
    include2 = TaskInclude("tests/include/second", play, play.basedir, static_include=True)
    block2 = Block(play=play, parent_block=include2)
    task3 = Task("this is a test", play)
    block3 = Block(play=play, parent_block=task3)
    task4 = Task("this is a test", play)
    block4 = Block(play=play, parent_block=task4)

    # Act
    result1 = block1

# Generated at 2022-06-21 00:20:45.358810
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    test_parent = {}
    test_dep_chain = {}
    test_result = {}
    test_args = {}
    test_args[0] = []
    test_args[1] = [test_parent,test_dep_chain]
    test_result[0] = None
    test_result[1] = test_dep_chain
    obj = None
    for i in test_args:
        obj = Block()
        obj._parent = test_args[i][0]
        obj._dep_chain = test_args[i][1]
        assert (obj.get_dep_chain() == test_result[i])

# Generated at 2022-06-21 00:20:56.572989
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task import TaskResult
    from ansible.playbook.block import Block
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import preprocess_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash_duplicate_key
    from ansible.utils.vars import merge_hash_x
    from ansible.utils.vars import combine_hash
   

# Generated at 2022-06-21 00:21:08.250323
# Unit test for method load of class Block
def test_Block_load():
    # Initialize test environment
    test_dir_path = os.path.dirname(os.path.abspath(__file__))
    test_data_dir_path = os.path.join(test_dir_path, 'data', 'test_data')
    play_path = os.path.join(test_data_dir_path, 'playbooks', 'play001.yml')
    vars_file = os.path.join(test_data_dir_path, 'vars', 'var001.yml')

    # Init Ansible variables
    options = Options()
    options.module_path = None
    options.connection = 'local'
    options.forks = 1
    options.become = None
    options.become_method = None
    options.become_user = None

# Generated at 2022-06-21 00:21:11.360229
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    loader = None
    block.set_loader(loader)
    assert block._loader is None


# Generated at 2022-06-21 00:21:13.770219
# Unit test for method get_include_params of class Block