

# Generated at 2022-06-21 00:13:20.664727
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.six import PY3

    if PY3:
        unicode = str

    # test code

# Generated at 2022-06-21 00:13:25.629890
# Unit test for method serialize of class Block
def test_Block_serialize():
    b = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    result = b.serialize()
    assert isinstance(result, dict)
    assert result.get('dep_chain') == None
    assert result.get('parent') == None
    assert result.get('parent_type') == None


# Generated at 2022-06-21 00:13:37.083055
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
  from ansible.utils.unsafe_proxy import AnsibleUnsafeText

  # Test 1, input:
  #   ds = {'block': [{'loop_control': 'loop_var: "{{ item_name }}"',
  #     'block': [{'debug': 'msg="{{ item_name }}"', 'loop': '"{{ item_list }}"', 'name': 'debug item_name'}],
  #     'name': 'debug item list'}]}

# Generated at 2022-06-21 00:13:39.813127
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    print()
    b = Block()
    # set_loader of Block class takes loader as input
    b.set_loader(None)
    print("Test passed successfully")


# Generated at 2022-06-21 00:13:47.999431
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    p = Play()
    i = TaskInclude()
    i._play = p
    i._use_handlers = True
    i._loader = DictDataLoader({})
    i.statically_loaded = True

    t = Task()
    t._play = p
    t._use_handlers = True
    t._loader = DictDataLoader({})
    t.statically_loaded = True
    t._parent = i

    b = Block()
    b._play = p
    b._use_handlers = True
    b._loader = DictDataLoader({})
    b._parent = t

    b.block = [t, t]
    b.block[0].statically_loaded = False

# Generated at 2022-06-21 00:13:56.510448
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    '''
    Unit test for method __ne__ of class Block
    '''
    from ansible.playbook import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    b = Block()
    b._parent = TaskInclude()
    if b.__ne__(None):
        print("yes")
    else:
        print("no")

# Generated at 2022-06-21 00:14:06.519578
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.handler import Handler
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager.set_inventory(inventory)

    variable

# Generated at 2022-06-21 00:14:07.573492
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
	pass


# Generated at 2022-06-21 00:14:08.690969
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    #TODO
    pass


# Generated at 2022-06-21 00:14:14.271492
# Unit test for constructor of class Block
def test_Block():
    block = Block(None, None, None)
    block.load_data({})
    assert block._block == []
    assert block._rescue == []
    assert block._always == []
    assert block._dep_chain == []
    assert block._role is None
    assert block._parent is None
    assert block._loader is None
    assert block.any_errors_fatal is False
    assert block.always_run is False


# Test to see if attribute is set on the Block object

# Generated at 2022-06-21 00:14:45.457278
# Unit test for method load of class Block
def test_Block_load():
  import ansible.parsing.dataloader
  import ansible.vars.manager

# Generated at 2022-06-21 00:14:47.878029
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block = Block()
    result = block.__repr__()

    assert result is not None



# Generated at 2022-06-21 00:14:48.608730
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block()

# Generated at 2022-06-21 00:14:59.793052
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    class Mock_Parent(object):
        def __init__(self):
            pass

    block = Block()
    block.action = "test"
    block._parent = Mock_Parent()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    class Mock_Play(object):
        def __init__(self):
            self.only_tags = [1]
            self.skip_tags = [2]
    block._play = Mock_Play()
    vars = {}
    res = block.filter_tagged_tasks(vars)
    assert res is not None
    assert len(res.block) == 3
    assert len(res.rescue) == 3
    assert len(res.always) == 3

# Generated at 2022-06-21 00:15:06.252671
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():

    # When implicitly creating a block, ensure that the single task
    # is created and added to the block
    implicit_block_data1 = dict(name="Test Task")
    implicit_block_data2 = [dict(name="Test Task")]
    b = Block()
    b_data = b.preprocess_data(implicit_block_data1)
    b_data2 = b.preprocess_data(implicit_block_data2)

    assert(b_data['block'] == [dict(name="Test Task")])
    assert(b_data2['block'] == [dict(name="Test Task")])




# Generated at 2022-06-21 00:15:09.312810
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    b = Block()
    b.deserialize({})


# Generated at 2022-06-21 00:15:20.460365
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    hostvars = {'localhost': {'var1': 'localhost_value1'}}
    vars_manager = VariableManager()
    vars_manager.set_inventory(Inventory('/fake/inventory'))
    loader = DataLoader()
    options = Options().serialize()
    play_context = PlayContext('local', None, None, None, options, None)
    new_stdin = False
    result = Block.load({'name': 'test', 'hosts': 'localhost'}, loader=loader, variable_manager=vars_manager, play_context=play_context).get_vars(host='localhost', all_vars=hostvars, play_context=play_context, new_stdin=new_stdin, unsafe=False)
    assert result == {'var1': 'localhost_value1'}

# Generated at 2022-06-21 00:15:25.965179
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    b = Block()
    t = Task()
    ti = TaskInclude()
    t.name, t._parent, ti.name, ti._parent = "Task-1", b, "Task-2",t
    assert ti == b.get_first_parent_include()
    assert "Task-1" == b.get_first_parent_include().name

# Generated at 2022-06-21 00:15:29.499474
# Unit test for constructor of class Block
def test_Block():
    print("Constructor of class Block")
    play = Play()
    block = Block(play, implicit=False)
    assert(block)

if __name__ == '__main__':
    test_Block()

# Generated at 2022-06-21 00:15:33.382557
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    obj = Block()
    assert obj.preprocess_data(dict()) == dict()
    assert obj.preprocess_data(dict(block=[dict(include="test")])) == dict(block=[dict(include="test")])


# Generated at 2022-06-21 00:16:09.272571
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    ##########################################################################################
    # 1: test_Block_set_loader:
    ##########################################################################################
    task1 = Block()
    task2 = Block()
    task2._loader = None
    task1.set_loader(task2)
    print("\ntest_Block_set_loader: task1._loader=", task1._loader, ", task2._loader=", task2._loader)
    if task1._loader is not None and task2._loader is None:
        print("test_Block_set_loader: PASS")
    else:
        print("test_Block_set_loader: FAIL")


# Generated at 2022-06-21 00:16:21.027528
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    b1 = Block()
    b2 = Block()
    b3 = Block()
    b4 = Block()
    b5 = Block()
    b2._dep_chain = [b1, b2]
    b3._dep_chain = [b1, b2, b3]
    b4._dep_chain = [b1, b2, b3, b4]
    b5._dep_chain = [b1, b2, b3, b4, b5]
    assert b2.get_dep_chain() == [b1, b2]
    assert b3.get_dep_chain() == [b1, b2, b3]
    assert b4.get_dep_chain() == [b1, b2, b3, b4]

# Generated at 2022-06-21 00:16:33.575498
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Make sure that all parents of the block are static when the
    # "statically_loaded" annotation is present
    block_0 = collections.namedtuple('block_0', ['statically_loaded'])
    block_1 = collections.namedtuple('block_1', ['statically_loaded'])
    block_2 = collections.namedtuple('block_2', ['statically_loaded'])

    block_0.statically_loaded = True
    block_1.statically_loaded = True
    block_2.statically_loaded = True

    block_0._parent = block_1
    block_1._parent = block_2

    block_2._parent = None

    assert Block.all_parents_static(block_0) == True

    # Make sure that all parents of the block are not static when the
    # "

# Generated at 2022-06-21 00:16:41.222470
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    '''
    Unit test for method all_parents_static of class Block
    '''
    print("\ntest_Block_all_parents_static - START")
    block = Block()
    try:
        result = block.all_parents_static()
    except:
        print("Got exception")
        print(sys.exc_info()[1])
        result = False
    assert(not result)
    block.statically_loaded = True
    try:
        result = block.all_parents_static()
    except:
        print("Got exception")
        print(sys.exc_info()[1])
        result = False
    assert(result)
    block1 = Block()
    block1.statically_loaded = True
    block.statically_loaded = False
    block1._parent = block

# Generated at 2022-06-21 00:16:53.316767
# Unit test for method deserialize of class Block
def test_Block_deserialize():

    import ansible.playbook
    import ansible.playbook.block
    def test_impl_Block_deserialize(self):

        pass
    setattr(ansible.playbook.block.Block, 'deserialize', test_impl_Block_deserialize)

    import ansible.playbook
    import ansible.playbook.block
    def test_impl_Block_deserialize(self):

        pass
    setattr(ansible.playbook.block.Block, 'deserialize', test_impl_Block_deserialize)

    import ansible.playbook
    import ansible.playbook.block
    def test_impl_Block_deserialize(self):

        pass
    setattr(ansible.playbook.block.Block, 'deserialize', test_impl_Block_deserialize)

   

# Generated at 2022-06-21 00:16:54.319107
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    pass


# Generated at 2022-06-21 00:17:02.218304
# Unit test for constructor of class Block
def test_Block():
    # Test implicit creation of block
    data_list = [
        {'find': {'paths': '/tmp/', 'patterns': '*.pyc'}},
        [
            {'debug': {'msg': 'this is a debug task'}},
            {'debug': {'msg': 'this is a debug task'}},
        ]
    ]
    for data in data_list:
        block = Block(data)
        assert(block is not None)
        assert(block.block == data)
        assert(block.rescue == [])
        assert(block.always == [])

    # Test explicit creation of block

# Generated at 2022-06-21 00:17:08.146025
# Unit test for method __eq__ of class Block

# Generated at 2022-06-21 00:17:12.863405
# Unit test for method serialize of class Block
def test_Block_serialize():
    b = Block()
    b.block = [1, 2, 3]
    b.rescue = [4, 5, 6]
    b.always = [7, 8, 9]
    b.serialize()
    assert False # TODO: implement your test here


# Generated at 2022-06-21 00:17:22.627608
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    import yaml
    block = Block()

# Generated at 2022-06-21 00:17:57.531731
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    ret = "Block(implicit=False, always=None, rescue=None, block=None)"
    assert ret == repr(block)

# Generated at 2022-06-21 00:18:09.672486
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    b = Block(block=[
        {'debug': 'msg={{ foo }}', 'when': 'foo is defined'},
        {'debug': 'msg={{ bar }}', 'when': 'bar is defined'},
    ])
    assert repr(b)

    b = Block(block=[
        {'debug': 'msg={{ foo }}', 'when': 'foo is defined'},
        {'debug': 'msg={{ bar }}', 'when': 'bar is defined'},
    ], rescue=[
        {'debug': 'msg={{ baz }}', 'when': 'baz is defined'},
        {'debug': 'msg={{ qux }}', 'when': 'qux is defined'},
    ])
    assert repr(b)


# Generated at 2022-06-21 00:18:20.822824
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    assert Block.load({'block': [{'name': 'Name'}]}).has_tasks()
    assert Block.load({'block': [{'block': [{'name': 'Name'}]}]}).has_tasks()
    assert Block.load({'block': [{'block': []}], 'rescue': [{'name': 'Name'}]}).has_tasks()
    assert Block.load({'block': [{'block': []}], 'always': [{'name': 'Name'}]}).has_tasks()
    assert Block.load({'block': [{'block': []}], 'rescue': [], 'always': [{'name': 'Name'}]}).has_tasks()

# Generated at 2022-06-21 00:18:25.769826
# Unit test for method is_block of class Block
def test_Block_is_block():
    """
    test method is_block of class Block
    """
    d = {"block" : "block","rescue" : "rescue","always" : "always"}
    assert Block.is_block(d)

# Generated at 2022-06-21 00:18:33.583946
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    import copy
    import ansible.playbook.block
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.base import Base
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.utils.hashing import md5s
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-21 00:18:42.144570
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():

    # Parsing a list results in an implicit block
    data = {'block': [{'debug': {'msg': 'Block preprocess data test'}}]}
    b = Block()
    assert b.preprocess_data([{'debug': {'msg': 'Block preprocess data test'}}]) == data

    # Parsing a dict results in no change
    data = {'block': [{'debug': {'msg': 'Block preprocess data test'}}]}
    b = Block()
    assert b.preprocess_data(data) == data



# Generated at 2022-06-21 00:18:53.329552
# Unit test for method load of class Block
def test_Block_load():
    class Play:
        pass
    play = Play()

    class HandlerTaskInclude:
        pass
    handler_task_include = HandlerTaskInclude()

    class ParentBlock:
        def __init__(self, parent_block=None, task_include=None, use_handlers=False, implicit=True):
            self.parent_block = parent_block
            self.task_include = task_include
            self.use_handlers = use_handlers
            self.implicit = implicit

        def copy(self, exclude_parent=False, exclude_tasks=False):
            return Block(play=play, parent_block=self.parent_block, role=None, task_include=self.task_include, use_handlers=self.use_handlers, implicit=self.implicit)

    class Role:
        pass


# Generated at 2022-06-21 00:18:55.386704
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    u = Block()
    assert u.set_loader(None) == None


# Generated at 2022-06-21 00:19:01.320248
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block = Block()

    # fixture: no attributes
    assert repr(block) == "Block(implicit=True, rescue=[], always=[], block=[])"

    # fixture: no implicit
    block.implicit = False
    assert repr(block) == "Block(implicit=False, rescue=[], always=[], block=[])"


# Generated at 2022-06-21 00:19:06.976277
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    b1 = Block()
    b1._attributes['name'] = 'a'
    b2 = Block()
    b2._attributes['name'] = 'b'
    b3 = Block()
    b3._attributes['name'] = 'a'
    assert (b1 == b2) == False
    assert (b1 == b3) == True

# Generated at 2022-06-21 00:19:41.677195
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # my_block = Block()
    my_block =Block(play=None)
    my_block.set_loader(loader=None)
# create a Block
my_block = Block(play=None)


# Generated at 2022-06-21 00:19:44.151724
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block = Block()
    # TODO: uncomment
    # assert block.get_dep_chain() == None
    print('Test get_dep_chain passed!')


# Generated at 2022-06-21 00:19:53.421099
# Unit test for method get_dep_chain of class Block

# Generated at 2022-06-21 00:20:05.446355
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    ds1 = dict(block=['task1', 'task2'])
    b1 = Block.load(ds1, loader=loader, variable_manager=variable_manager)
    assert b1.block[0].action == 'task1'
    ds2 = {'action': 'task3'}
    b2 = Block.load(ds2, loader=loader, variable_manager=variable_manager)
    assert b2.block[0].action == 'task3'
    ds3 = ['task4', 'task5']

# Generated at 2022-06-21 00:20:12.807135
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_obj = Block(
        block=[
            {'action': 'debug', 'msg': 'mode = $mode'},
            {'action': 'debug', 'msg': 'x = $x', 'when': 'x is defined'},
            {'action': 'debug', 'msg': 'y = $y', 'when': 'y is defined'},
            {'action': 'debug', 'msg': 'z = $z', 'when': 'z is defined'}
          ]
    )
    assert block_obj.has_tasks() == True


# Generated at 2022-06-21 00:20:25.394506
# Unit test for method is_block of class Block
def test_Block_is_block():
    from ansible.parsing.yaml import objects
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    data = None
    test_block = Block(play=None, task_include=None, role=None, task_include=None, use_handlers=None, implicit=None)
    assert test_block.is_block(data) == False
    data = objects.AnsibleUnicode()
    assert test_block.is_block(data) == False
    data = {}
    assert test_block.is_block(data) == True
    data = []
    assert test_block.is_block(data) == False
    data = ['A', 'B']
    assert test_block.is_block(data) == False

# Generated at 2022-06-21 00:20:36.316297
# Unit test for constructor of class Block
def test_Block():
    # Create a block
    block = Block()

    # Verify the default value of block_start
    assert block.block_start is False

    # Verify the defaults for block, rescue and always
    assert block.block == []
    assert block.rescue == []
    assert block.always == []

    # Set some values for block, rescue and always
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]

    # Verify the values for block, rescue and always
    assert block.block == [1,2,3]
    assert block.rescue == [4,5,6]
    assert block.always == [7,8,9]


# Generated at 2022-06-21 00:20:45.347333
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    block1 = Block()
    block2 = Block()
    block1.name = block2.name = "Block 1"
    block1.loop = block2.loop = ["1","2","3"]
    block1._attributes = block2._attributes = {"loop":"1"}
    block1.when = block2.when = ["1","2","3"]
    block1.rescue = block2.rescue = ["1","2","3"]
    block1.always = block2.always = ["1","2","3"]
    block1.block = block2.block = ["1","2","3"]
    assert block1 == block2
    block1.name = "Block 2"
    assert block1 != block2
    block1.name = block2.name = "Block 1"
    block1.loop = ["1"]


# Generated at 2022-06-21 00:20:47.586735
# Unit test for method __ne__ of class Block
def test_Block___ne__():
  block_obj = Block()
  assert block_obj.__ne__(block_obj) == NotImplemented


# Generated at 2022-06-21 00:20:49.682259
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    assert False, "No tests for this module"



# Generated at 2022-06-21 00:21:29.398623
# Unit test for constructor of class Block
def test_Block():
    play_name = 'test_play'
    block_name = 'test_block'
    b = Block(play=play_name, name=block_name)
    assert b.name == block_name
    assert b._play == play_name
    assert b._implicit is False
    assert b._parent is None
    assert b._role is None
    assert b._dep_chain == None

    # test _load_block
    task_name = 'test_task'
    parent_block = 'parent_block'
    b._load_block(block_name, task_name)
    assert b._ds == {block_name: task_name}

    b.block = task_name
    assert b.block == task_name

    assert b.serialize()
    assert b.deserialize()

    assert b.copy()