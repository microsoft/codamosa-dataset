

# Generated at 2022-06-21 00:12:45.940890
# Unit test for method is_block of class Block
def test_Block_is_block():
    with pytest.raises(Exception):
        Block.is_block(123, 1)


# Generated at 2022-06-21 00:12:56.794726
# Unit test for method __eq__ of class Block
def test_Block___eq__():

    block_obj = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=None)
    block_obj2 = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=None)
    assert not (block_obj == block_obj2)

    block_obj.block = [1,2,3,4,5]
    block_obj2.block = [1,2,3,4,5]
    assert not (block_obj == block_obj2)

    block_obj.rescue = [1,2,3,4,5]
    block_obj2.rescue = [1,2,3,4,5]

# Generated at 2022-06-21 00:13:05.242248
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    ##Test True case
    b1 = Block()
    t1 = Task()
    t2 = Task()
    t3 = Task()
    t4 = Task()
    t5 = Task()
    b1.block=[t1,t2,t3]
    b1.rescue = [t4]
    b1.always = [t5]
    assert b1.has_tasks() == True
    ##Test False case
    b1 = Block()
    assert b1.has_tasks() == False


# Generated at 2022-06-21 00:13:09.755036
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block = Block({}, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=True)
    assert block.preprocess_data({"block": "block"}) == {"block": "block"}


# Generated at 2022-06-21 00:13:12.438205
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    block1 = Block()
    block2 = Block()
    assert block1.__eq__(block2)


# Generated at 2022-06-21 00:13:22.851945
# Unit test for method is_block of class Block
def test_Block_is_block():
    loader = DataLoader()
    variable_manager = VariableManager()

    ds = {'block': None}
    b = Block.load(ds, loader=loader, variable_manager=variable_manager)
    assert b.is_block(ds) == True

    ds = {'block': []}
    b = Block.load(ds, loader=loader, variable_manager=variable_manager)
    assert b.is_block(ds) == True

    ds = {'block': {'a': 'b'}}
    b = Block.load(ds, loader=loader, variable_manager=variable_manager)
    assert b.is_block(ds) == True

    ds = {'rescue': []}
    b = Block.load(ds, loader=loader, variable_manager=variable_manager)

# Generated at 2022-06-21 00:13:29.684294
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-21 00:13:41.217829
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, variable_manager, None)
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='setup', args=''))
             ]
        )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 00:13:47.501668
# Unit test for method is_block of class Block
def test_Block_is_block():
    ds = {
            'block': [
                {"name": "test"},
                {"name": "test2"}
            ],
            'rescue': [
                {"name": "test3"},
                {"name": "test4"}
            ],
            'always': [
                {"name": "test5"},
                {"name": "test6"}
            ]
        }
    assert Block.is_block(ds)
    ds = [
            {"name": "test"},
            {"name": "test2"}
        ]
    assert not Block.is_block(ds)
 

# Generated at 2022-06-21 00:14:00.143955
# Unit test for method is_block of class Block
def test_Block_is_block():
    from ansible.playbook.block import Block
    from ansible.playbook.block import Task
    from ansible.errors import AnsibleParserError
    block_test = {
        'block': [
            {
                'debug': 'msg={{inventory_hostname}}'
            },
            {
                'debug': 'msg={{inventory_hostname}}'
            }

        ],
        'rescue': [
            {
                'debug': 'msg={{inventory_hostname}}'
            }
        ],
        'always': [
            {
                'debug': 'msg={{inventory_hostname}}'
            }
        ]
    }
    task_test = {
        'name': 'Testing'
    }
    assert Block.is_block(block_test) == True

# Generated at 2022-06-21 00:14:19.484248
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
  obj = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
  result = obj.get_first_parent_include()
  assert result == None

# Generated at 2022-06-21 00:14:28.149119
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    import ansible.playbook.block
    block = ansible.playbook.block.Block()
    assert isinstance(ansible.playbook.block.Block, object)
    assert hasattr(ansible.playbook.block.Block, "set_loader")
    assert callable(ansible.playbook.block.Block.set_loader)
    assert isinstance(ansible.playbook.block.Block, object)
    block.set_loader(loader=get_loader_mock())

# Generated at 2022-06-21 00:14:37.452951
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    obj = Block()

# Generated at 2022-06-21 00:14:50.010542
# Unit test for method load of class Block
def test_Block_load():
    fake_play = dict(
        name="test",
        hosts=["localhost"],
    )
    fake_loader = dict(
        load_from_file=lambda _: dict(),
    )
    fake_variable_manager = dict(
        extra_vars=dict(),
    )

# Generated at 2022-06-21 00:14:55.811056
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block({'block': False})
    assert not Block.is_block(False)
    assert Block.is_block({'rescue': False})
    assert Block.is_block({'always': False})
    assert not Block.is_block({'not a block': False})
    assert not Block.is_block(42)


# Generated at 2022-06-21 00:14:58.287158
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block(loader=None)
    b.set_loader(None)
    assert b._loader is None

# Generated at 2022-06-21 00:15:02.975995
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    b = Block()
    b.deserialize(dict(name='hello'))
    assert b.name == 'hello'
    assert b.when is None
    assert b.block == []
    assert b.rescue == []
    assert b.always == []
    assert b.loop is None
    assert b.notify == []
    assert b.vars == {}


# Generated at 2022-06-21 00:15:06.394563
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    try:
        block.copy()
    except NotImplementedError:
        pass
    except:
        assert False, 'Unexpected exception thrown'
    else:
        assert False, 'ExpectedException not thrown'


# Generated at 2022-06-21 00:15:11.665473
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    d1 = {'rescue': [
        {'shell': 'test.sh'},
        {'shell': 'test1.sh'},
        ]
    }
    b1 = Block(implicit=True)
    print(b1.preprocess_data(d1))



# Generated at 2022-06-21 00:15:14.740710
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    v = VarsModule()
    t = Task()
    b = Block(block=[t])

    assert b.filter_tagged_tasks(v).has_tasks()


# Generated at 2022-06-21 00:15:46.002387
# Unit test for method serialize of class Block
def test_Block_serialize():
    # Testing the serialize method
    from ansible.playbook.role_task_include import RoleTaskInclude
    my_block = Block(use_handlers=True)
    my_block._attributes['name'] = 'test'
    my_block_serialized = my_block.serialize()
    assert my_block_serialized['name'] == 'test'
    assert my_block_serialized['use_handlers'] == True
    # Testing the deserialize method
    my_second_block = Block()
    my_second_block.deserialize(my_block_serialized)
    assert my_second_block._attributes['name'] == 'test'
    assert my_second_block._attributes['use_handlers'] == True
    assert my_second_block._use_handlers == True
    # Testing

# Generated at 2022-06-21 00:15:49.302046
# Unit test for constructor of class Block
def test_Block():
    b = Block(static=True, parent_block=None, role=None, task_include=None, implicitly_converted=None, use_handlers=False)
    assert b.__class__.__name__ == 'Block'

if __name__ == '__main__':
    pass

# Generated at 2022-06-21 00:15:50.806077
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block = Block()
    assert repr(block)



# Generated at 2022-06-21 00:15:52.154795
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    pass # TODO


# Generated at 2022-06-21 00:15:54.324024
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    test = Block()
    test.deserialize()
    return True # no error


# Generated at 2022-06-21 00:16:03.461996
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():

    # Creating Block object
    b = Block()

    # Checking for the method and its return type
    assert isinstance(b.get_include_params(), dict)

    # Assigning value to attribute _parent
    b._parent = None

    # Checking for the method and its return type
    assert isinstance(b.get_include_params(), dict)

    # Assigning value to attribute _parent
    b._parent = "some_value"

    # Checking for the method and its return type
    assert isinstance(b.get_include_params(), dict)


# Generated at 2022-06-21 00:16:12.452137
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    test_obj = None
    if test_obj is None:

        # Creating object instance of class Block
        obj = Block()

        # Getting the class name
        cls_name = obj.__class__.__name__

        # Checking the class name
        if cls_name == 'Block':
            print("Class %s found" % cls_name)
        else:
            print("Class %s does not found" % cls_name)

        # Getting the parent class name
        cls_parent = obj.__class__.__bases__[0].__name__

        # Checking the parent class name
        if cls_parent == 'Task':
            print("Parent of Class %s is %s" % (cls_name, cls_parent))

# Generated at 2022-06-21 00:16:17.140160
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block(parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    b.set_loader('test_loader')
    assert isinstance(b._loader, 'test_loader') == TRUE
    

# Generated at 2022-06-21 00:16:18.830814
# Unit test for method serialize of class Block
def test_Block_serialize():
    block = Block()
    block.serialize()

# Generated at 2022-06-21 00:16:21.794900
# Unit test for method is_block of class Block
def test_Block_is_block():
    ds = dict()
    block = Block()
    assert isinstance(block, Block)
    assert not Block.is_block(ds)
    ds['block'] = [dict()]
    assert Block.is_block(ds)
    ds = dict()
    ds['rescue'] = [dict()]
    assert Block.is_block(ds)
    ds = dict()
    ds['always'] = [dict()]
    assert Block.is_block(ds)


# Generated at 2022-06-21 00:16:51.038274
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    print ('in method:', inspect.stack()[0][3])
    print ('test_Block_get_dep_chain()[1]')
    # create a new Block object
    b = Block()
    # create a new Role object
    r = Role()
    # create a new Play object
    p = Play()
    # create two new Task objects
    t1 = Task()
    t2 = Task()
    # create two new Block objects
    b1 = Block()
    b2 = Block()
    # set the role of Block as Role
    b._role = r
    # set the parent of Block as Block1
    b._parent = b1
    # set the parent of Block1 as Task1
    b1._parent = t1
    # set the play of Block1 as Play
    b1._play = p
    #

# Generated at 2022-06-21 00:17:00.414221
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook import Play, Task as ParentTask
    from ansible.callbacks import AggregateStats
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    import os

    class Task(Base):

        def __init__(self):
            self._attributes = {}

    class Role:

        def __init__(self):
            pass

    class Handler(Base):

        def __init__(self):
            self._attributes = {}

    class Play:

        def __init__(self):
            self._attributes = {}

# Generated at 2022-06-21 00:17:11.883029
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    mock_play = MagicMock()
    mock_loader = MagicMock()
    block = Block(play=mock_play, loader=mock_loader)
    block_2 = Block(parent_block=block, play=mock_play, loader=mock_loader)
    block_3 = Block(parent_block=block_2, play=mock_play, loader=mock_loader)
    block_4 = Block(parent_block=block_3, play=mock_play, loader=mock_loader)
    block_5 = Block(parent_block=block_4, play=mock_play, loader=mock_loader)
    block_6 = Block(parent_block=block_5, play=mock_play, loader=mock_loader)

    # If the Block's parent_block has the

# Generated at 2022-06-21 00:17:22.143832
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from task import Task
    from role import Role
    import raw

    b1 = Block()
    t1 = Task()
    t2 = Task()
    t3 = Task()
    ti1 = TaskInclude()
    b2 = Block()
    ti2 = TaskInclude()

    b1.block = [t1]
    t1.block = [t2]
    t2.block = [t3]
    t3.block = [ti1]
    ti1.block = [b2]
    b2.block = [ti2]

    assert b1.all_parents_static() == True
    assert t1.all_parents_static() == True
    assert t2.all_parents

# Generated at 2022-06-21 00:17:32.950467
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-21 00:17:34.981211
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # create an object of class Block from Ansible
    block = Block()



# Generated at 2022-06-21 00:17:36.773081
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # FIXME: do we need to test this? it doesn't do anything
    pass


# Generated at 2022-06-21 00:17:46.436096
# Unit test for constructor of class Block

# Generated at 2022-06-21 00:17:48.834499
# Unit test for method serialize of class Block
def test_Block_serialize():
    block = Block(dict(),Block(),None)
    res = block.serialize()
    assert isinstance(res,dict)


# Generated at 2022-06-21 00:17:50.972629
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    v = Block()
    assert v.get_dep_chain() is None

# Generated at 2022-06-21 00:18:16.651194
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block = Block()
    assert block.preprocess_data(dict(block=[])) == dict(block=[])
    assert block.preprocess_data(dict(block=[], rescue=[], always=[])) == dict(block=[], rescue=[], always=[])
    assert block.preprocess_data(dict(block=[{'action': 'shell', 'args': 'ls'}, {'action': 'shell', 'args': 'cd'}])) == dict(block=[{'action': 'shell', 'args': 'ls'}, {'action': 'shell', 'args': 'cd'}])
    assert block.preprocess_data('ls') == dict(block=['ls'])
    assert block.preprocess_data(['ls', 'cd']) == dict(block=['ls', 'cd'])

# Generated at 2022-06-21 00:18:29.314479
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    ansible_playbook_block = dict(
        block = [
            dict(
                block = [
                    dict(
                        block = [
                            dict(
                                name = dict(
                                    args = dict(
                                        chdir = '/etc',
                                        debug = "msg='{{ inventory_hostname }}'",
                                    ),
                                    msg = 'foo bar',
                                ),
                                with_items = '{{ foobar }}',
                            ),
                        ],
                    ),
                ],
                rescue = [
                    dict(
                        name = 'foo bar',
                    ),
                ],
                always = [
                    dict(
                        name = 'foo bar',
                    ),
                ],
            ),
        ],
    )

# Generated at 2022-06-21 00:18:31.461563
# Unit test for method serialize of class Block
def test_Block_serialize():
  b = Block()
  b.serialize()


# Generated at 2022-06-21 00:18:44.311087
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.inventory.group import Group

    # Setup the inventory and variable manager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["hosts"])
    group = Group("group1")

# Generated at 2022-06-21 00:18:53.371245
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    b = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    assert b.all_parents_static() == True
    b._parent = object()
    b._parent.statically_loaded = True
    assert b.all_parents_static() == True
    b._parent.statically_loaded = False
    assert b.all_parents_static() == False
    b._parent.all_parents_static = lambda : False
    assert b.all_parents_static() == False
    b._parent.all_parents_static = lambda : True
    assert b.all_parents_static() == True



# Generated at 2022-06-21 00:19:05.765909
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():

    res = load_list_of_tasks(dict(block=[
        dict(command='a'),
        dict(block=[dict(command='b'), dict(command='c')])
    ]), play=Play().load(dict(hosts='all', gather_facts='no', tasks=[
        dict(debug=dict(msg='yes')),
    ])))

    # !!!: Make sure that this does not throw an exception
    assert len(res) == 2
    assert res[0].action == 'command'
    assert res[1].action == 'meta'
    assert len(res[1].block) == 2
    assert res[1].block[0].action == 'command'
    assert res[1].block[1].action == 'command'

    # Also test that we don't get an implicit block for the block
    # keyword which

# Generated at 2022-06-21 00:19:13.886443
# Unit test for method copy of class Block
def test_Block_copy():
    m = AnsibleModule()
    block = Block(play=m.play, parent_block=m.block, role=m.role, task_include=None, use_handlers=m.use_handlers, implicit=None)
    block.any_errors_fatal=None
    block.block=None
    block.always=None
    block.rescue=None
    # This causes infinite recursion in python2, because it calls its own copy method, and the copy method
    # calls copy of the parent block. This causes the copy method to create a copy of itself and its parent block,
    # ad infinitum.
    # This doesn't cause the same problem in python3, because the copy method is called on the copy object, not the object 'block'.
    #new_me = block.copy()
    #print("new_me.__

# Generated at 2022-06-21 00:19:14.596546
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    pass

# Generated at 2022-06-21 00:19:23.378131
# Unit test for constructor of class Block
def test_Block():
    '''
    - name: test1
      debug: msg="test1"
      block:
        - block:
            - debug: msg="block1"
            - debug: msg="block2"
        - debug: msg="test2"
    '''
    block1 = dict(
        name="test1",
        debug="msg='test1'",
        block=[
            dict(
                block=[
                    dict(
                        debug="msg='block1'"
                    ),
                    dict(
                        debug="msg='block2'"
                    )
                ]
            ),
            dict(
                debug="msg='test2'"
            )
        ]
    )
    play1 = play_from_file(os.path.join(FIXTURE_DIR, "block_test.yaml"))
    block2 = play1.get_

# Generated at 2022-06-21 00:19:25.531688
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    my_Block = Block()
    my_Block.deserialize(0) # TODO: implement this test


# Generated at 2022-06-21 00:19:52.576317
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block({}, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    new_block = block.copy()
    assert new_block


# Generated at 2022-06-21 00:20:04.341164
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    a = AnsibleOptions()
    b = AnsibleBaseVars()
    c = VariableManager()
    d = DataLoader()
    e = Playbook.load('./test_playbook/block.yml', a,b,c,d)
    pb = PlaybookExecutor(e,a,c,d)
    pb._tqm._final_q = e[0].compile()
    pb._tqm._failed_hosts = dict()
    pb._tqm._unreachable_hosts = dict()
    iterator = pb._tqm.get_iterator()
    tasks = sorted(iterator, key=lambda t: t._uuid)
    assert tasks[1].all_parents_static() == False
    assert tasks[3].all_parents_static() == True

# Unit

# Generated at 2022-06-21 00:20:05.372568
# Unit test for method load of class Block
def test_Block_load():
  pass

# Generated at 2022-06-21 00:20:06.845983
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    b = Block()
    assert b.get_dep_chain() == None

# Generated at 2022-06-21 00:20:15.054600
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    '''
    Unit test for method has_tasks of class Block
    '''
    b = Block()
    assert not b.has_tasks()
    b.load_data({'block': []})
    assert not b.has_tasks()
    b.load_data({'block': [{'action': 'dummy'}]})
    assert b.has_tasks()
    b.load_data({'block': [], 'rescue': [], 'always': []})
    assert not b.has_tasks()
    b.load_data({'block': [], 'rescue': [{'action': 'dummy'}], 'always': []})
    assert b.has_tasks()

# Generated at 2022-06-21 00:20:16.804580
# Unit test for method copy of class Block
def test_Block_copy():
    pass



# Generated at 2022-06-21 00:20:18.752754
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block = Block()
    assert block.__repr__() is None


# Generated at 2022-06-21 00:20:31.112502
# Unit test for method all_parents_static of class Block

# Generated at 2022-06-21 00:20:35.231386
# Unit test for method serialize of class Block
def test_Block_serialize():
    # Setup test data/fixtures
    data = {}

    # Execute the method being tested
    b = Block()
    result = b.serialize()

    # Verify the results
    assert_equals(result, data)


# Generated at 2022-06-21 00:20:36.616013
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    pass
###########################################################################
#                          END OF FILE                                    #
###########################################################################

# Generated at 2022-06-21 00:20:59.209381
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    b1 = Block()
    b2 = Block()
    assert b1.__ne__(b2) == True
    b1.static()
    assert b1.__ne__(b2) == False
    b2.static()
    assert b1.__ne__(b2) == False


# Generated at 2022-06-21 00:21:05.520396
# Unit test for constructor of class Block
def test_Block():
    block1 = Block()
    assert block1._attributes['block'] == []
    assert block1._attributes['rescue'] == []
    assert block1._attributes['always'] == []

    block2 = Block({'block': 'test1'})
    assert block2._attributes['block'] == 'test1'
    assert block2._attributes['rescue'] == []
    assert block2._attributes['always'] == []


# Generated at 2022-06-21 00:21:12.128444
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    my_hosts = [
        dict(
            host="localhost",
            tasks=[
                dict(action=dict(__ansible_module__="debug", msg="Hello World!")),
                dict(action=dict(__ansible_module__="debug", msg="Bye World!")),
            ],
            rescue=[dict(action=dict(__ansible_module__="debug", msg="Rescue World!"))],
            always=[dict(action=dict(__ansible_module__="debug", msg="Always World!"))],
        )
    ]
    my_play = dict(
        name="Ansible Play",
        hosts=my_hosts,
        gather_facts="no",
        tasks=[],
        roles=[],
    )


# Generated at 2022-06-21 00:21:23.517627
# Unit test for constructor of class Block
def test_Block():
    b = Block()

    assert b.name == None
    assert b.block == None
    assert b.rescue == None
    assert b.always == None
    assert b._attributes == {}
    assert b._play == None
    assert b._parent == None
    assert b._role == None
    assert b.any_errors_fatal == None
    assert b.changed_when == None
    assert b.deprecated == None
    assert b.failed_when == None
    assert b.run_once == None
    assert b.tags == None
    assert b._elements == {}
    assert b._elements_path == []
    assert b._ds == {}
    assert b.failed_when_result == None
    assert b.changed_when_result == None
    assert b._variable_manager == None

# Generated at 2022-06-21 00:21:24.488187
# Unit test for method serialize of class Block
def test_Block_serialize():
    pass