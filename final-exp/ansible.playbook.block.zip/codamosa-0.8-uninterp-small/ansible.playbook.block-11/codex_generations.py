

# Generated at 2022-06-25 04:54:26.593073
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    print("TESTING test_Block_deserialize")
    bool_0 = True
    block_0 = Block(bool_0)
    dict_0 = dict()
    dict_0["block"] = "block"
    dict_0["always"] = "always"
    dict_0["rescue"] = "rescue"
    dict_0["dep_chain"] = "dep_chain"
    dict_0["role"] = "role"
    dict_0["parent"] = "parent"
    dict_0["parent_type"] = "parent_type"

    # test_case_0
    block_0.deserialize(dict_0)
    # assertion: Exception


# Generated at 2022-06-25 04:54:36.384051
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block(True, '', '', True)
    block_1 = Block(True, '', '', True)
    # block_1 sets block_0 as parent
    block_1.set_loader(None)
    block_1._parent = block_0
    # block_0's statically_loaded attr should be false
    block_0._statically_loaded = False
    # block_1.all_parents_static() calls block_0.all_parents_static()
    # which will return False, so all_parents_static should return False
    if block_1.all_parents_static():
        raise Exception("block_1.all_parents_static() should return False, but returned True")


# Generated at 2022-06-25 04:54:47.604709
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    bool_0 = True
    block_0 = Block(bool_0)
    list_0 = ['foo', 'bar', 'baz']
    block_0.dep_chain = list_0
    dep_chain = block_0.get_dep_chain()
    assert dep_chain == list_0
    block_0.dep_chain = None
    assert block_0._parent is None
    dep_chain = block_0.get_dep_chain()
    assert dep_chain is None
    block_0._parent = block_0
    dep_chain = block_0.get_dep_chain()
    assert dep_chain is None
    block_0._parent._dep_chain = list_0
    dep_chain = block_0.get_dep_chain()
    assert dep_chain == list_0

# Unit test

# Generated at 2022-06-25 04:54:50.027771
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    bool_0 = True
    block_0 = Block(bool_0)
    dict_0 = dict()
    __result = block_0.filter_tagged_tasks(dict_0)
    # AssertionError: False is not true : Block._attributes['block'] is not set.
    __result


# Generated at 2022-06-25 04:54:54.052918
# Unit test for method copy of class Block
def test_Block_copy():
    no_arg_method_called = False
    try:
        case_1 = Block(True)
        case_1.copy()
        no_arg_method_called = True
    except TypeError:
        pass


# Generated at 2022-06-25 04:54:58.811738
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    try:
        test_case_0()
    except NotImplementedError:
        assert False, "exception raised in case 0"



# Generated at 2022-06-25 04:55:04.894680
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # set up
    bool_0 = True
    block_0 = Block(bool_0)
    block_1 = None
    block_0._ds = block_1
    # test
    block_0.deserialize(block_1)


# Generated at 2022-06-25 04:55:09.666678
# Unit test for method copy of class Block
def test_Block_copy():
    _data = dict()
    _exclude_parent = True
    _exclude_tasks = True

    # TODO: change for test_case_0
    _args = {'block': block_0, 'exclude_tasks': _exclude_tasks, 'exclude_parent': _exclude_parent}
    _obj = block_0
    _expected = Block(bool_0)

    _result = _obj.copy(_exclude_parent, _exclude_tasks)
    assert _expected == _result



# Generated at 2022-06-25 04:55:14.250716
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    test_play_0 = Play()
    test_task_0 = Task()
    test_task_0._attributes['name'] = u'test_task'
    test_block_0 = Block(test_play_0)
    test_block_0.block = [test_task_0]
    test_dict_0 = dict()
    test_block_1 = test_block_0.filter_tagged_tasks(test_dict_0)
    assert test_block_1.block[0] == test_task_0



# Generated at 2022-06-25 04:55:17.421496
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block({}) == False
    assert Block.is_block({'block': 'string'}) == True
    assert Block.is_block({'rescue': 'string'}) == True
    assert Block.is_block({'always': 'string'}) == True
    assert Block.is_block({'string': 'string'}) == False


# Generated at 2022-06-25 04:55:57.459695
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    return_value = None
    # call the method
    return return_value


# Generated at 2022-06-25 04:56:01.587337
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    var_0 = Block()
    var_1 = AnsibleLoader(None)
    var_0.set_loader(var_1)
    if var_0._loader != var_1:
        print('FAILURE : test_Block_set_loader')
    else:
        print('SUCCESS : test_Block_set_loader')


# Generated at 2022-06-25 04:56:03.762627
# Unit test for method is_block of class Block
def test_Block_is_block():
    var_1 = dict()
    var_1['var_0'] = dict()


# Generated at 2022-06-25 04:56:05.001688
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    assert Block.preprocess_data(var_0) == dict()


# Generated at 2022-06-25 04:56:12.107116
# Unit test for method copy of class Block
def test_Block_copy():

    block_0 = Block()
    block_0.become = None
    block_0.become_user = None
    block_0.block = []
    block_0.changed_when = None
    block_0.compile_when = None
    block_0.delegate_to = None
    block_0.delegate_facts = None
    block_0.dep_chain = None
    block_0.ds = dict()
    block_0.environment = None
    block_0.failed_when = None
    block_0.ignore_errors = None
    block_0.included_block = False
    block_0.implicit = False
    block_0.loop = None
    block_0.loop_args = None
    block_0.loop_control = None
    block_0.loop_with

# Generated at 2022-06-25 04:56:17.540425
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    var_0 = dict()
    var_0 = Block.load(var_0)
    var_0.get_dep_chain()


# Generated at 2022-06-25 04:56:19.201915
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # TODO: Implement test function

    print("Begin test")

test_case_0()

# Generated at 2022-06-25 04:56:24.479730
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    var_0 = dict()

    # fill the object
    block = Block(play=var_0)

    # run the tested code
    block.filter_tagged_tasks(all_vars=var_0)


# Generated at 2022-06-25 04:56:26.433056
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    var_0 = Block()
    # unit test for method get_first_parent_include of class Block
    assert var_0.get_first_parent_include() == None


# Generated at 2022-06-25 04:56:29.580743
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    var_1 = dict(attr='attr')
    f = Block.preprocess_data(var_1)

# Generated at 2022-06-25 04:56:58.821075
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    var_1 = dict()
    assert test_case_0() == var_1

# Generated at 2022-06-25 04:57:03.704937
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Make sure we can load this module
    test_case_0()



# Generated at 2022-06-25 04:57:07.466135
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    var_1 = dict(block=[dict(action="system test")])
    var_2 = Block.load(var_1)
    var_3 = dict(block=[dict(action="system test")])
    sys_0 = dict()
    sys_1 = dict(block=[dict(action="system test")])
    var_4 = var_3 == sys_1
    var_5 = var_4
    return var_5



# Generated at 2022-06-25 04:57:10.269785
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    obj_0 = Block()
    var_0 = obj_0.filter_tagged_tasks(test_case_0())


# Generated at 2022-06-25 04:57:11.279398
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    var_0 = dict()



# Generated at 2022-06-25 04:57:19.236941
# Unit test for method copy of class Block
def test_Block_copy():
    var_0 = dict()
    var_1 = Block.load(var_0, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    var_2 = var_1.copy(exclude_parent=False, exclude_tasks=False)


# Generated at 2022-06-25 04:57:23.955898
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    var_0 = dict()

    # Create a block
    block_0 = Block()
    block_0.filter_tagged_tasks(var_0)


# Generated at 2022-06-25 04:57:29.409677
# Unit test for method set_loader of class Block

# Generated at 2022-06-25 04:57:30.342043
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    var_1 = dict()
    pass


# Generated at 2022-06-25 04:57:33.711031
# Unit test for method preprocess_data of class Block

# Generated at 2022-06-25 04:57:57.748436
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    var_0 = dict()


# Generated at 2022-06-25 04:57:58.685103
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    var_0 = Block()


# Generated at 2022-06-25 04:58:00.964886
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    var_1 = Block()
    var_1.set_loader(var_0, var_0, var_0, var_0)



# Generated at 2022-06-25 04:58:03.114077
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block()
    assert isinstance (b, Block)

    b.set_loader(None)
    #assert raise AssertionError('Faild assert: isinstance(loader, BaseLoader)')



# Generated at 2022-06-25 04:58:12.010883
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    var_1={"block": [{"include": "test.yml"}, {"include": "test.yml"}], "name": "Foo", "post_tasks": [{"include": "test.yml"}], "pre_tasks": [{"include": "test.yml"}], "role": "test", "tasks": [{"include": "test.yml"}]}
    obj_0 = Block.load(var_1)
    assert(obj_0.get_loader()==None)
    obj_0.set_loader(var_0)
    assert(obj_0.get_loader()==var_0)


# Generated at 2022-06-25 04:58:15.488249
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    print('Testing Block.set_loader')
    var_0 = dict()
    print('Unit test completed')


# Generated at 2022-06-25 04:58:18.175349
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    var_0 = dict()
    obj = Block(ds=var_0)
    all_vars = 'a'
    obj.filter_tagged_tasks(all_vars)


# Generated at 2022-06-25 04:58:21.161128
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    var_0 = dict()
    test_Block_0 = Block(name="test_Block_0")
    test_Block_0.get_dep_chain()


# Generated at 2022-06-25 04:58:27.958236
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    args = []
    # No params to method call.
    # No exception should be thrown.
    try:
        test_case_0()
    except Exception as e:
        print('Exception: ' + str(e))
test_Block_filter_tagged_tasks()

# Generated at 2022-06-25 04:58:28.980624
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    obj = Block()
    obj.get_dep_chain()


# Generated at 2022-06-25 04:59:18.970107
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    var_1 = Block()
    var_2 = dict()
    var_3 = var_1.filter_tagged_tasks(var_2)


# Generated at 2022-06-25 04:59:19.950486
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    var_0 = dict()


# Generated at 2022-06-25 04:59:25.740808
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    loader_0 = FileLoader(test_case_0(), 'string')
    block_0.set_loader(loader_0)
    loader_0.set_basedir('k7')
    assert loader_0.get_basedir() is 'k7'

# Generated at 2022-06-25 04:59:29.092569
# Unit test for method copy of class Block
def test_Block_copy():
    var_0 = dict()
    obj_0 = Block(var_0)
    var_1 = obj_0.copy()


# Generated at 2022-06-25 04:59:38.965927
# Unit test for method is_block of class Block
def test_Block_is_block():
    var_1 = dict(block=[dict(name="test"), dict(name="test2")])
    var_2 = dict(block=[dict(name="test"), dict(name="test2")])
    var_2.update(dict(rescue=[dict(name="test"), dict(name="test2")]))
    var_2.update(dict(always=[dict(name="test"), dict(name="test2")]))
    var_2.update(dict(deprecated="yes"))
    var_2.update(dict(when="yes"))
    var_3 = [dict(name="test"), dict(name="test2")]
    Block.is_block(var_1)
    Block.is_block(var_2)
    Block.is_block(var_3)
    print("Test Case Passed!")



# Generated at 2022-06-25 04:59:45.436171
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # var_0 is a dictionary
    var_0 = dict()
    # var_1 is a Block
    var_1 = Block.load(var_0, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    # var_2 is a Loader
    var_2 = Loader()
    var_1.set_loader(var_2)


# Generated at 2022-06-25 04:59:47.227170
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    print('unit test for method filter_tagged_tasks of class Block')
    block = Block()
    all_vars = dict()
    ret = block.filter_tagged_tasks(all_vars)
    return ret

# Generated at 2022-06-25 04:59:49.358565
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():

    test_case_0()


# Generated at 2022-06-25 05:00:00.468353
# Unit test for method deserialize of class Block
def test_Block_deserialize():

    old_payload = dict(dep_chain = None, _role = None, parent = None, parent_type = "Block")
    new_payload = Block.deserialize(old_payload)
    test_assert(new_payload['dep_chain'] == None, 'test_Block_deserialize:test_assert:0')
    test_assert(new_payload['_role'] == None, 'test_Block_deserialize:test_assert:1')
    test_assert(new_payload['parent'] == None, 'test_Block_deserialize:test_assert:2')
    test_assert(new_payload['parent_type'] == "Block", 'test_Block_deserialize:test_assert:3')


# Generated at 2022-06-25 05:00:11.452204
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # Test with task list
    task_0 = dict()
    test_0 = Block.preprocess_data(task_0)
    assert (test_0 == dict(block=list()))
    # Test with dict with 'block' key
    key_0 = 'block'
    task_1 = dict()
    task_1[key_0] = list()
    test_1 = Block.preprocess_data(task_1)
    assert (test_1 == dict(block=list()))
    # Test with dict with 'rescue' key
    key_1 = 'rescue'
    task_2 = dict()
    task_2[key_1] = list()
    test_2 = Block.preprocess_data(task_2)
    assert (test_2 == dict(block=list(), rescue=list()))


# Generated at 2022-06-25 05:01:08.658532
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    var_0 = Block()

# Generated at 2022-06-25 05:01:11.653582
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    var_0 = dict()
    var_1 = None
    var_1 = Block(var_0)
    var_1.set_loader(var_0)


# Generated at 2022-06-25 05:01:13.290626
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    assert callable(getattr(Block, 'filter_tagged_tasks'))


# Generated at 2022-06-25 05:01:14.590520
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block(var_0) == False


# Generated at 2022-06-25 05:01:20.132279
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    var_0 = dict()
    a_Block_obj = Block(var_0)
    var_0 = dict()
    a_Block_obj.set_loader(var_0)
    a_Block_obj.get_first_parent_include()
    try:
        a_Block_obj.set_loader(var_0)
        a_Block_obj.get_first_parent_include()
    except AnsibleError:
        pass


# Generated at 2022-06-25 05:01:20.940319
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    var_0 = dict()


# Generated at 2022-06-25 05:01:22.576974
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    var_0 = Block()
    var_1 = var_0.get_dep_chain()
    var_2 = assertEqual(var_1,None)


# Generated at 2022-06-25 05:01:24.417444
# Unit test for method copy of class Block
def test_Block_copy():
    assert 1 == 1

# Generated at 2022-06-25 05:01:27.939376
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # simple test for a non-block
    test_case_0()


# Generated at 2022-06-25 05:01:33.417025
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # Initializing
    var_1 = dict()
    var_1['parent'] = str()
    var_1['role'] = str()

    # Invoking deserialize('a', 'b', 'c', 'd')
    Block.deserialize('a', 'b', 'c', 'd')


# Generated at 2022-06-25 05:02:12.458160
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    block_0.set_loader(None)


# Generated at 2022-06-25 05:02:21.676431
# Unit test for method is_block of class Block
def test_Block_is_block():
    block_1 = Block()

    # Test to see if the function is_block of class Block will return True
    # if an inputted data type ds, is a dictionary and contains keys 'block',
    # 'rescue', and 'always'.

    ds_1 = {}
    ds_1['block'] = {}
    ds_1['rescue'] = {}
    ds_1['always'] = {}

    block_1.is_block(ds_1)

    ds_2 = None
    ds_3 = ''
    ds_4 = []
    ds_5 = {}
    ds_6 = {'test': 'testing'}
    ds_7 = {}
    ds_7['block'] = {}
    ds_8 = {}
    ds_8['block'] = {}


# Generated at 2022-06-25 05:02:24.463176
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0.deserialize(None)


# Generated at 2022-06-25 05:02:26.758007
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_1 = Block()
    block_2 = Block()
    block_1.set_loader(block_2.loader)


# Generated at 2022-06-25 05:02:36.480814
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    import sys
    import copy
    import types

    # Dummy play, block, task and task_include
    play = Play.load({})
    block = Block.load({}, play)
    task = Task()
    task_include = TaskInclude()

    # Init original objects
    task._parent = block
    block._parent = task_include
    task_include._parent = task_include
    task_include.statically_loaded = False
    task._play = play
    block._play = play
    task_include._play = play
    play._role = None
    block._role = None
    task._role = None
    task_include._role = None

    # Init test objects
    task_test = copy.deepcopy(task)
    block_test

# Generated at 2022-06-25 05:02:41.487318
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():

    # create a block
    block = Block()

    # assert parent is None
    assert block._parent == None

    # assert all parents are static
    assert block.all_parents_static() == True

    # create a TaskInclude
    from ansible.playbook.task_include import TaskInclude
    task_include = TaskInclude()

    # set the parent to TaskInclude
    block._parent = task_include

    # assert the parent is TaskInclude
    assert block._parent == task_include

    # assert all parents are not static
    assert block.all_parents_static() == False

# Generated at 2022-06-25 05:02:43.930129
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    block.block = [dict(), dict(), dict(), dict(), dict(), dict()]
    block.rescue = [dict(), dict(), dict(), dict(), dict(), dict()]
    block.always = [dict(), dict(), dict(), dict(), dict(), dict()]

    assert block.has_tasks() is True


# Generated at 2022-06-25 05:02:49.212467
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():

    block_0 = Block()
    block_0.all_parents_static()

    block_1 = Block()
    block_1.statically_loaded = True
    block_1.all_parents_static()

    block_1.statically_loaded = False
    block_1.all_parents_static()

    block_0._parent = block_1
    block_0.all_parents_static()

    block_1.statically_loaded = True
    block_0.all_parents_static()

    block_1.statically_loaded = False
    block_0.all_parents_static()

    block_2 = Block()
    block_2.statically_loaded = True
    block_2._parent = block_1
    block_0.all_parents_static()

    block_2 = Block()
   