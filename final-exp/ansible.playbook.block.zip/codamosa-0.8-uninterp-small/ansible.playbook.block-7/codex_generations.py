

# Generated at 2022-06-25 04:54:07.331019
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    int_0 = -2554
    block_0 = Block(int_0)
    var_0 = block_0.all_parents_static()


# Generated at 2022-06-25 04:54:09.652350
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    int_0 = -8296
    list_0 = []
    block_0 = Block(int_0)
    list_1 = block_0.filter_tagged_tasks(list_0)
    assert len(list_1) == 0


# Generated at 2022-06-25 04:54:13.287562
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    int_0 = -2554
    block_0 = Block(int_0)
    dict_0 = dict()
    block_0.deserialize(dict_0)


# Generated at 2022-06-25 04:54:14.409267
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    pass


# Generated at 2022-06-25 04:54:22.603115
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    print("Testing 'set_loader' method")
    int_0 = -1287
    block_0 = Block(int_0)
    int_1 = -1947
    loader_0 = DataLoader(int_1)
    block_0.set_loader(loader_0)
    var_0 = block_0.__repr__()

if __name__ == '__main__':
    import sys
    import nose

    argv = sys.argv[:]
    argv.append('--verbose')
    argv.append('--nocapture')
    nose.runmodule(argv=argv, exit=False)

# Generated at 2022-06-25 04:54:24.442201
# Unit test for method deserialize of class Block

# Generated at 2022-06-25 04:54:25.636698
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    int_0 = 18449
    block_0 = Block(int_0)
    block_0.set_loader()


# Generated at 2022-06-25 04:54:32.116140
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    with pytest.raises(AnsibleParserError) as pytest_wrapped_e:
        test_case_0()
    assert "Malformed block definition for block" in pytest_wrapped_e.value.message
    assert "line" in pytest_wrapped_e.value.message



# Generated at 2022-06-25 04:54:38.947233
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    bool_0 = block_0.has_tasks()
    assert_false(bool_0)


# Generated at 2022-06-25 04:54:46.337789
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    int_0 = -5695
    block_0 = Block(int_0)
    int_1 = -9031
    block_0.block = [ int_1 ]
    int_2 = -6967
    block_0.rescue = [ int_2 ]
    int_3 = -4436
    block_0.always = [ int_3 ]
    list_0 = block_0.filter_tagged_tasks(None)
    list_1 = block_0.filter_tagged_tasks(None)
    return list_0


# Generated at 2022-06-25 04:55:03.079324
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    task_0 = Task()
    var_0 = task_0.deserialize(data)


# Generated at 2022-06-25 04:55:07.589934
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0.deserialize(None)


# Generated at 2022-06-25 04:55:13.633855
# Unit test for method filter_tagged_tasks of class Block

# Generated at 2022-06-25 04:55:15.498778
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block(
        task_type='include',
        _static_parent=Parent(),
        _attributes={},
    )
    loader = DataLoader()
    block.set_loader(loader)


# Generated at 2022-06-25 04:55:22.330833
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    block_0.block = []
    var_0 = block_0.has_tasks()

    block_1 = Block()
    block_1.block = [ Task() ]
    var_1 = block_1.has_tasks()

    assert not var_0
    assert var_1


# Generated at 2022-06-25 04:55:29.126573
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    # Testing for exception in copy
    try:
        block_0.copy(False, False)
    except (TypeError, ValueError, NameError, AttributeError, KeyError, IndexError, KeyError, NameError, KeyError, TypeError) as e:
        print("Exception in test_Block_copy : " + str(e))


# Generated at 2022-06-25 04:55:33.930023
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block_0 = Block()
    block_0.preprocess_data(['list'])
    block_0.preprocess_data({'dict': 'dict'})
    block_0.preprocess_data(123)


# Generated at 2022-06-25 04:55:40.488667
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    def test_set_loader_0():
        block_0 = Block()
        loader_0 = MockModuleLoader()
        block_0.set_loader(loader_0)
    def test_set_loader_1():
        block_0 = Block()
        loader_0 = MockModuleLoader()
        block_0.set_loader(loader_0)


# Generated at 2022-06-25 04:55:47.111856
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    block_0 = Block()
    var_0 = block_0.all_parents_static()

    block_1 = Block(parent_block=None)
    var_1 = block_1.all_parents_static()

    block_2 = Block(parent_block=block_1)
    var_2 = block_2.all_parents_static()

    block_3 = Block(parent_block=TaskInclude())
    var_3 = block_3.all_parents_static()

    block_4 = Block(parent_block=HandlerTaskInclude())
    var_4 = block_4.all_parents_static()


# Generated at 2022-06-25 04:55:54.291448
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    block_0 = Block()
    result = block_0.all_parents_static()
    assert result == True

    block_1 = Block(parent=TaskInclude())
    result = block_1.all_parents_static()
    assert result == True

    block_1._parent.statically_loaded = False
    result = block_1.all_parents_static()
    assert result == False

    block_2 = Block(parent=block_1)
    result = block_2.all_parents_static()
    assert result == False

    block_3 = Block(parent=HandlerTaskInclude())
    result = block_3.all_parents_static()
    assert result == True

# Generated at 2022-06-25 04:56:09.783672
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    test_case_0()


# Generated at 2022-06-25 04:56:11.254372
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    var_0 = block_0.set_loader(None)


# Generated at 2022-06-25 04:56:15.698429
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    var_0 = C.Block()
    var_1 = dict()
    var_1['role'] = dict()
    var_1['parent'] = dict()
    var_1['parent_type'] = str()
    var_1['dep_chain'] = None
    var_1['when'] = ('x', 'y', 'z')
    block_0.deserialize(var_1)
    var_0.deserialize(var_1)



# Generated at 2022-06-25 04:56:17.424971
# Unit test for method is_block of class Block
def test_Block_is_block():
    _data = {}
    assert Block.is_block(_data)


# Generated at 2022-06-25 04:56:28.018529
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()

# Generated at 2022-06-25 04:56:33.404581
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_obj = Block()
    block_obj.deserialize(dict(name='test', tasks={'1': dict(action='setup'), '2': dict(action='setup')}, rescue=[]))
    tasks = []
    for task in block_obj.block:
        tasks.append(task.action)
    return tasks == ['setup', 'setup']


# Generated at 2022-06-25 04:56:45.001098
# Unit test for method copy of class Block
def test_Block_copy():
    block_1 = Block()
    block_1.block = [ ]
    block_1.rescue = [ ]
    block_1.always = [ ]
    block_1.name = 'foo'
    block_1.when = 'bar'
    block_1.ignore_errors = True
    block_1.register = 'baz'
    block_1._dep_chain = [ ]
    block_1.vars_prompt = [ ]
    block_1.loop = 'quux'
    block_1.loop_args = { }
    block_1.dynamic_block_items = [ ]
    block_1.max_loop = 'foobar'
    block_1.until = 'foobaz'
    block_1.retries = 'quuux'

# Generated at 2022-06-25 04:56:47.220336
# Unit test for method deserialize of class Block
def test_Block_deserialize():

    # Setup
    block_0 = Block()
    data_0 = dict()

    # Test
    block_0.deserialize(data_0)


# Generated at 2022-06-25 04:56:48.899372
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    var_0 = block_0.filter_tagged_tasks(None)


# Generated at 2022-06-25 04:56:53.907832
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    import ansible.playbook.task_include
    import ansible.playbook.task
    block_0 = Block()
    task_0 = ansible.playbook.task.Task()
    task_include_0 = ansible.playbook.task_include.TaskInclude(task=task_0)
    task_0._parent = block_0
    task_include_0._parent = task_0
    block_0._parent = task_include_0
    var_0 = block_0.get_first_parent_include() == task_include_0
    var_1 = block_0.get_first_parent_include() == task_0


# Generated at 2022-06-25 04:57:18.698785
# Unit test for method deserialize of class Block
def test_Block_deserialize():

    block_0 = Block()
    block_0.deserialize(yaml.safe_load('''role: null
dep_chain: []
'''))


# Generated at 2022-06-25 04:57:26.413164
# Unit test for method has_tasks of class Block

# Generated at 2022-06-25 04:57:28.418091
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    test_case_0()



# Generated at 2022-06-25 04:57:30.506813
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    var_0 = block_0.has_tasks()

    C.t(0, var_0)


# Generated at 2022-06-25 04:57:42.517686
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    new_play_context = PlayContext()
    new_play_context.tags = ['test']
    new_play_context.only_tags = ['test']
    new_play_context.skip_tags = []

    variable_manager = VariableManager()
    variable_manager.set_play_context(new_play_context)


# Generated at 2022-06-25 04:57:49.029911
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    # Test cases
    block_0.deserialize(None)
    block_0.deserialize('Sentinel')
    block_0.deserialize({})
    block_0.deserialize('')
    block_0.deserialize([])
    # Test cases
    block_0.deserialize("Sentinel")
    block_0.deserialize("Sentinel")
    block_0.deserialize("Sentinel")


# Generated at 2022-06-25 04:57:58.859741
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.parsing.yaml.objects import AnsibleSequence
    # Init members
    block_0 = Block()
    block_0._loader = None
    block_0._attributes = {}
    block_0._dep_chain = None
    block_0._parent = None
    block_0._play = None
    block_0._role = None
    block_0._block = None
    block_0._rescue = None
    block_0._always = None
    block_0._task_includes = AnsibleSequence()
    block_0._valid_attrs = {}
    block_0._loop = None
    block_0._when = None
    block_0._loop_args = None
    block_0._when_value = 'true'
    block_0._post_validate_called = False

# Generated at 2022-06-25 04:58:04.505957
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    var_0 = block_0.get_dep_chain()


# Generated at 2022-06-25 04:58:12.113513
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # block_0 = Block({'always': [{'action': 'meta', 'args': {'_raw_params': 'reset_connection', '_uses_shell': False, '_use_delegated_facts': False, '_msg': 'Reset connection'}, 'changed_when': False, 'register': 'task_result', 'ignore_errors': False, 'delegate_to': '127.0.0.1', 'when': True, 'failed_when': False, 'implicit': True, 'async': 0, 'poll': 0, 'name': 'Reset connection', 'tags': ['always']}]})
    # var_0 = block_0.filter_tagged_tasks([])
    pass


# Generated at 2022-06-25 04:58:18.696636
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    block_0._play = dict()
    block_0._play['skip_tags'] = [ 'skip' ]
    block_0._play['only_tags'] = [ 'only' ]
    block_0.block = [ dict() ]
    block_0.rescue = [ dict() ]
    block_0.always = [ dict() ]
    var_0 = block_0.filter_tagged_tasks(dict())


# Generated at 2022-06-25 04:58:38.642168
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    result = block_0.filter_tagged_tasks(all_vars=[])
    print(repr(result))
    assert repr(result) == '<Block>'


# Generated at 2022-06-25 04:58:42.347132
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_1 = Block()
    var_1 = block_1.get_dep_chain()


# Generated at 2022-06-25 04:58:47.156940
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Basic test
    block_0 = Block()
    block_0.block = list()
    block_0.rescue = list()
    block_0.always = list()
    var_0 = block_0.has_tasks()


# Generated at 2022-06-25 04:58:55.119229
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    block_0 = Block()
    # Unit test for assertion block_0._parent == None
    try:
        assert block_0._parent == None
    except AssertionError as e:
        print("AssertionError raised in test_case_0():")
        print(e)
        traceback.print_exc()

    # Unit test for assertion block_0._dep_chain == None
    try:
        assert block_0._dep_chain == None
    except AssertionError as e:
        print("AssertionError raised in test_case_0():")
        print(e)
        traceback.print_exc()

    # Unit test for assertion block_0.parent == None

# Generated at 2022-06-25 04:59:00.205184
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
  block = Block()
  parent = TaskInclude()
  block.parent = parent

  assert block.get_first_parent_include() == parent


# Generated at 2022-06-25 04:59:05.119859
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    block_1 = Block()
    block_1.block = [Task()]
    block_1.block[0].tags = ['a']
    var_1 = block_1.filter_tagged_tasks([])

    assert(var_1)

# Generated at 2022-06-25 04:59:15.135340
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    all_vars_0 = {}
    filtered_block_0 = block_0.filter_tagged_tasks(all_vars_0)
    assert filtered_block_0 == block_0
    # Test with filters
    # Test 1
    task_0 = Task()
    tag_0 = 'tag1'
    task_0.tags.append(tag_0)
    task_0.action = 'Ping'
    task_0.register = 'var_0'
    block_1 = Block()
    block_1.block.append(task_0)
    var_2 = {'only_tags':[tag_0], 'skip_tags':[]}
    filtered_block_1 = block_1.filter_tagged_tasks(var_2)

# Generated at 2022-06-25 04:59:17.272054
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    var_0 = block_0.has_tasks()
    assert(var_0 == False)

# Generated at 2022-06-25 04:59:21.602356
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    task_0 = Task()
    assert task_0 is not None
    block_0 = Block(block=[task_0])
    block_1 = Block(block=[block_0])
    assert block_1 is not None
    all_vars_0 = {}
    block_2 = block_1.filter_tagged_tasks(all_vars_0)
    assert block_2 is not None

# Generated at 2022-06-25 04:59:25.585658
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    block_1 = block_0.filter_tagged_tasks({'anything_result': False, 'test': 'some text'})


# Generated at 2022-06-25 04:59:54.445174
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    kwargs = {
        'all_vars': {},
    }

    block_0 = Block()
    block_1 = block_0.filter_tagged_tasks(**kwargs)

if __name__ == "__main__":
    import sys
    import inspect
    test_functions = [ x for x in dir() if x.startswith('test_')]
    for name in sorted(test_functions):
        print('%s: ' % name)

# Generated at 2022-06-25 04:59:58.017239
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task

    block_0 = Block()
    str_0 = block_0.filter_tagged_tasks([])
    var_0 = str_0.has_tasks()
    assert var_0 == False


# Generated at 2022-06-25 04:59:59.525872
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    var_0 = block_0.get_first_parent_include()


# Generated at 2022-06-25 05:00:05.675809
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Test case for POSITIVE behavior
    block_0 = Block()
    all_vars_0 = {}
    assert_equals(block_0.filter_tagged_tasks(all_vars_0), block_0)


# Generated at 2022-06-25 05:00:07.779830
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    var_0 = block_0.get_dep_chain()
    assert isinstance(var_0, list)


# Generated at 2022-06-25 05:00:11.160020
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    var_0 = block_0.has_tasks()
    var_1 = block_0.filter_tagged_tasks(None)


# Generated at 2022-06-25 05:00:16.094848
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block_1 = Block()
    with pytest.raises(AssertionError) as excinfo:
       block_1.preprocess_data(1)
    assert 'not a dictionary or list of tasks' in str(excinfo.value)
    #assert False # TODO


# Generated at 2022-06-25 05:00:19.227865
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy(exclude_parent=False, exclude_tasks=False)
    var_1 = block_1.has_tasks()


# Generated at 2022-06-25 05:00:20.842412
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    block_1 = block_0.all_parents_static()


# Generated at 2022-06-25 05:00:29.136154
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    b = Block()
    data = {'rescue': [], 'dep_chain': [1]}
    b.deserialize(data)
    assert data['dep_chain'] == [1]
    data = {'rescue': [], 'dep_chain': [1], 'block': [], 'always': [], 'role': {'vars': [], 'tasks': [], 'default_vars': [], 'metadata': {}, 'handlers': [], 'default_vars_files': [], 'path': './', 'name': 'db', 'description': 'Database role'}}
    b.deserialize(data)
    assert data['dep_chain'] == [1]

# Generated at 2022-06-25 05:00:58.987494
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    block_0 = Block()
    block_0._parent = TaskInclude()
    block_0._parent._parent = TaskInclude()
    var_0 = block_0.get_first_parent_include()
    if not var_0:
        raise AssertionError()
    var_0 = var_0.__class__.__name__
    if var_0 != "TaskInclude":
        raise AssertionError()


# Generated at 2022-06-25 05:01:02.433999
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    var_0 = {}
    var_1 = block_0.filter_tagged_tasks(var_0)


# Generated at 2022-06-25 05:01:08.482019
# Unit test for method copy of class Block
def test_Block_copy():
    block_1 = Block()
    block_2 = block_1.copy(exclude_parent=True, exclude_tasks=False)
    var_1 = block_2.has_tasks()
    block_3 = block_1.copy(exclude_parent=False, exclude_tasks=True)
    var_2 = block_3.has_tasks()


# Generated at 2022-06-25 05:01:18.500452
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # Input data for this unit test
    block_0 = Block()
    ds = dict()
    ds['block'] = [{'action': 'set_fact', 'args': {'var': 'value'}}]
    ds['rescue'] = [{'action': 'set_fact', 'args': {'var': 'value'}}]
    ds['always'] = [{'action': 'set_fact', 'args': {'var': 'value'}}]
    ds['when'] = 1
    ds['name'] = 'action'
    ds['tags'] = 'tag'
    ds['register'] = 'value'
    ds['delegate_to'] = 'value'
    ds['local_action'] = 2
    ds['transport'] = 'value'

# Generated at 2022-06-25 05:01:20.043594
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    # Test case.
    #block_0 = Block()
    #var_0 = block_0.get_first_parent_include()
    return


# Generated at 2022-06-25 05:01:24.550662
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    block_0.all_parents_static()
    block_0.get_first_parent_include()
    block_0.get_include_params()
    block_0.get_dep_chain()
    block_0.copy()
    block_0.serialize()
    block_0.deserialize()
    block_0.set_loader()
    block_0.filter_tagged_tasks()

test_case_0()
test_Block_filter_tagged_tasks()

# Generated at 2022-06-25 05:01:25.177276
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    pass

# Generated at 2022-06-25 05:01:29.987362
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    Test.assert_equals(block_0.copy(), block_0)
    Test.assert_equals(block_0.copy(exclude_parent=True), block_0)
    Test.assert_equals(block_0.copy(exclude_tasks=True), block_0)


# Generated at 2022-06-25 05:01:39.900878
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block_0 = Block()
    block_1 = Block()
    block_2 = Block()
    block_3 = Block()
    block_4 = Block()
    block_5 = Block()
    block_6 = Block()
    block_7 = Block()
    block_8 = Block()
    block_9 = Block()
    # This simple task is implicitly wrapped into a main block
    data_0 = list()
    var_0 = block_0.load(data_0)
    # This normal block is fully loaded
    data_1 = dict(block=list())
    var_1 = block_1.load(data_1)
    # This block has a conditional rescue block, which is skipped
    data_2 = dict(block=list(), rescue=dict())
    var_2 = block_2.load(data_2)

# Generated at 2022-06-25 05:01:42.295888
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()
    val = isinstance(block_1, Block)
    assert val == True


# Generated at 2022-06-25 05:02:02.258056
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    try:
        test_case_0()
    except:
        print("Test case 0 Failed!")
        return
    print("Test case 0 OK!")
    return
# Test class Block
test_Block_has_tasks()


# Generated at 2022-06-25 05:02:03.861941
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    var_0 = block_0.all_parents_static()


# Generated at 2022-06-25 05:02:05.750741
# Unit test for method copy of class Block
def test_Block_copy():
    block_1 = Block()
    var_1 = block_1.copy()


# Generated at 2022-06-25 05:02:07.518496
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = Block()
    all_vars = dict()
    block.filter_tagged_tasks(all_vars)


# Generated at 2022-06-25 05:02:13.947150
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0.rescue = [ {'action': 'blockinfile', 'block': 'Block goes here', 'line': 'New line', 'insertafter': 'EOF', 'insertbefore': 'EOF', 'path': '/etc/default/elasticsearch', 'search': 'regex', 'state': 'present'} ]
    block_0.always = [ {'action': 'blockinfile', 'block': 'Block goes here', 'line': 'New line', 'insertafter': 'EOF', 'insertbefore': 'EOF', 'path': '/etc/default/elasticsearch', 'search': 'regex', 'state': 'present'} ]
    var_0 = block_0.copy()
    assert var_0._valid_attrs == block_0._valid_attrs
    assert var_0._

# Generated at 2022-06-25 05:02:18.907445
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Test fixtures
    ds = dict(
      block = [
         dict(rescue = ['task_1','task_2']),
      ]

    )
    play = Play.load(ds=ds)
    block = play.block_list[0]
    var_0 = block.all_parents_static()

    # Assertions
    assert(var_0 == True)


# Generated at 2022-06-25 05:02:20.811346
# Unit test for method copy of class Block
def test_Block_copy():
    block_1 = Block()
    var_1 = block_1.copy()
    assert var_1 is None


# Generated at 2022-06-25 05:02:30.451231
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    boolean_0 = block_0.copy()
    boolean_1 = block_0.copy(exclude_parent=True)
    boolean_2 = block_0.copy(exclude_tasks=True)
    boolean_3 = block_0.copy(exclude_parent=False, exclude_tasks=True)
    boolean_4 = block_0.copy(exclude_parent=True, exclude_tasks=False)
    boolean_5 = block_0.copy(exclude_parent=False, exclude_tasks=False)


# Generated at 2022-06-25 05:02:40.643334
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    block_0.block = []
    block_0.rescue = []
    block_0.always = []

    # test block
    task_0 = Task()
    task_1 = Task()
    task_0.action = "foo"
    task_0.action = "foo"
    task_0.tags = ["all"]
    task_1.tags = ["all"]
    block_0.block.append(task_0)
    block_0.block.append(task_1)

    # test rescue
    task_0 = Task()
    task_1 = Task()
    task_0.action = "foo"
    task_0.action = "foo"
    task_0.tags = ["all"]
    task_1.tags = ["all"]

# Generated at 2022-06-25 05:02:43.057077
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_1 = Block()
    block_1.deserialize(block_0)
