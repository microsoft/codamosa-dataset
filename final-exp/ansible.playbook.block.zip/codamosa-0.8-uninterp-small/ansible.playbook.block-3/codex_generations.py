

# Generated at 2022-06-25 04:54:02.837096
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    """
    This method is run to test the Block::filter_tagged_tasks method
    """
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    block_0 = Block()
    PlayContext.DEFAULT_TOP_LEVEL_VARS = {}

    testcase_0 = []
    testcase_1 = []
    testcase_2 = []
    testcase_3 = []
    testcase_4 = []
    testcase_5 = []
    testcase_6 = []
    testcase_7 = []
    testcase_8 = []
    testcase_9 = []

    PlayContext.DEFAULT_LOADER = DataLoader()

    # testcase 0

# Generated at 2022-06-25 04:54:05.774162
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()
    assert block_0 != block_1
    assert block_0.copy() == block_1
    assert block_1.copy() == block_1.copy(exclude_parent=True)
    assert block_1.copy() == block_1.copy(exclude_tasks=True)



# Generated at 2022-06-25 04:54:10.846029
# Unit test for method deserialize of class Block
def test_Block_deserialize():

    block_0 = Block()
    print(type(block_0), block_0.deserialize({'block': [], 'rescue': [], 'dep_chain': [], 'always': [], 'register': 'hostvar0', 'loop': 'hostvar1', 'name': 'hostvar2', 'until': 'hostvar3', 'when': 'hostvar4', 'paused': False, 'loop_control': {'index_var': 'hostvar5', 'loop_var': 'hostvar6'}, 'local_action': None}))

if __name__ == "__main__":
    test_case_0()
    test_Block_deserialize()

# Generated at 2022-06-25 04:54:13.138358
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    assert block_0.has_tasks() == False


# Generated at 2022-06-25 04:54:14.495505
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_1 = Block()

    # disabled because the set_loader method is expecting a loader as an argument which is wrong and needs to be fixed
    #block_1.set_loader()

# Generated at 2022-06-25 04:54:16.076762
# Unit test for method is_block of class Block
def test_Block_is_block():
    data_0 = Block.is_block(None)
    assert data_0 == False

# Generated at 2022-06-25 04:54:25.501821
# Unit test for method all_parents_static of class Block

# Generated at 2022-06-25 04:54:30.210439
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    block_0 = Block()

    include_0 = TaskInclude()
    include_1 = TaskInclude()
    include_0.statically_loaded = False
    include_1.statically_loaded = False
    include_0._parent = block_0
    include_1._parent = include_0

    assert not include_1.all_parents_static()

    include_0.statically_loaded = True
    assert include_1.all_parents_static()

    include_1_b = HandlerTaskInclude()
    include_1_b.statically_loaded = False
    include_1_b._parent = block_0

    assert not include_1_b.all_

# Generated at 2022-06-25 04:54:33.566146
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0_copy = block_0.copy()
    assert block_0_copy



# Generated at 2022-06-25 04:54:35.134177
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0.deserialize({})
    # Should not raise an exception


# Generated at 2022-06-25 04:54:53.408533
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    assert block_0.get_dep_chain() == None



# Generated at 2022-06-25 04:54:54.940078
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block(implicit=True)
    assert block_0.has_tasks() is False


# Generated at 2022-06-25 04:55:06.889429
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    '''
    Tests whether the filter_tagged_tasks() method of Block works properly
    '''

    block_test = Block()
    block_test.block = [
        Task(),
        Task(),
        Task().load_data(dict(action='pause', pause_seconds=3)),
        Block(),
        Block().load_data(dict(block=[
            Task(),
            Task(),
            Task(),
            Task(),
            Block(),
            Block(),
            Block(),
            Block(),
        ])),
    ]

    # Since the list is empty, we should get an empty block.
    all_vars = {}
    filtered_block = block_test.filter_tagged_tasks(all_vars)
    if not isinstance(filtered_block, Block):
        return False

# Generated at 2022-06-25 04:55:12.180287
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    import ansible.playbook.play
    from ansible.playbook.play import Play

    block_0 = Block.load(dict(
        name='test',
        block=[
            dict(
                action='shell',
                tags=['first']
            ),
            dict(
                action='shell',
                tags=['third']
            )
        ]
    ))
    assert block_0.has_tasks() == True
    assert block_0.filter_tagged_tasks(dict()).has_tasks() == True

    # filter with no tags

# Generated at 2022-06-25 04:55:19.257918
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Test that method has_tasks() of class Block returns True if the
    # block has at least one task in block, rescue, or always lists
    block_0 = Block()
    block_0.block = [0]
    assert(block_0.has_tasks() == True)
    # Test that method has_tasks() of class Block returns False if the
    # block has no tasks in block, rescue, or always lists
    block_1 = Block()
    # Test that method has_tasks() of class Block returns False if the
    # block has tasks only in rescue and always lists
    block_2 = Block()
    block_2.rescue = [0]
    assert(block_2.has_tasks() == True)
    # Test that method has_tasks() of class Block returns False if the
    # block has

# Generated at 2022-06-25 04:55:29.904975
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    '''
    make sure TaskInclude and RoleInclude are showing up in Block.get_dep_chain()
    '''
    block_0 = Block()
    block_1 = Block(parent_block=block_0)
    block_2 = Block(parent_block=block_1)
    task_include_0 = TaskInclude(parent_block=block_2)
    role_include_0 = RoleInclude(parent_block=task_include_0)
    dep_chain = role_include_0.get_dep_chain()
    assert dep_chain == [block_2, task_include_0, role_include_0]


# Generated at 2022-06-25 04:55:37.690434
# Unit test for method copy of class Block
def test_Block_copy():
    # test when exclude_tasks is True
    block_0 = Block(name='block', rescue=[], always=[])
    assert block_0.copy(exclude_tasks=True).name == block_0.name
    assert block_0.copy(exclude_tasks=True).rescue == block_0.rescue
    assert block_0.copy(exclude_tasks=True).always == block_0.always

    # test when exclude_tasks is False
    assert block_0.copy().name == block_0.name
    assert block_0.copy().rescue == block_0.rescue
    assert block_0.copy().always == block_0.always


# Generated at 2022-06-25 04:55:49.945402
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_1 = Block()

# Generated at 2022-06-25 04:55:54.785184
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    block_1 = Block()

    block_0.block = [block_1]
    assert block_0.has_tasks()


# Generated at 2022-06-25 04:55:59.070657
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.playbook.block import Block
    block = Block()
    block.deserialize(['bar', 'foo'])
    assert block.block == ['bar', 'foo']


# Generated at 2022-06-25 04:56:17.606933
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = Block()
    all_vars = dict()
    block.filter_tagged_tasks(all_vars)

# Generated at 2022-06-25 04:56:24.869335
# Unit test for method get_first_parent_include of class Block

# Generated at 2022-06-25 04:56:27.086134
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    assert block_0._type == 'block'
    try:
        block_0.copy(exclude_parent=False, exclude_tasks=False)
    except Exception:
        assert True


# Generated at 2022-06-25 04:56:31.850727
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    test_case = dict(hosts='all')
    result = Block.load(test_case)
    assert isinstance(result, Block) is True
    assert result.hosts == 'all'
    assert result.block is None
    assert result.rescue is None
    assert result.always is None


# Generated at 2022-06-25 04:56:37.343015
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert True == Block.is_block(dict(block=[]))
    assert True == Block.is_block(dict(rescue=[]))
    assert True == Block.is_block(dict(always=[]))
    assert True == Block.is_block(dict(block=[], rescue=[], always=[]))


# Generated at 2022-06-25 04:56:39.458540
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()


# Generated at 2022-06-25 04:56:42.240662
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0.deserialize(dict(block=[], always=[], rescue=[], dep_chain=None, parent=None, parent_type=None))


# Generated at 2022-06-25 04:56:50.167818
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    play = Play.load(dict(
        name='Test Play',
        hosts=['localhost'],
        gather_facts='no',
        tasks=[dict(action=dict(module='setup', args=dict()))]
    ), loader=null_loader, variable_manager=variable_manager)
    block_0 = Block(play=play, use_handlers=True, name='random block', implicit=True)
    task_0 = Task()
    block_0._parent = task_0
    block_0._dep_chain = []
    block_0._attributes['block'] = [task_0]
    block_0._att

# Generated at 2022-06-25 04:56:55.575509
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0.vars = dict()
    block_0.block = [copy.deepcopy(dict())]
    block_0.post_validate(templar=MagicMock())
    block_0.serialize()
    block_0.deserialize(data=dict())
    block_0.get_vars()
    block_0.all_parents_static()
    block_0._load_attr(attr='block', ds=dict())
    block_0._load_attr(attr='rescue', ds=dict())
    block_0._load_attr(attr='always', ds=dict())
    block_0._get_parent_attribute(attr='name', extend=False, prepend=False)
    block_0.set_loader(loader=MagicMock())

# Generated at 2022-06-25 04:56:59.588418
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
  block_0 = Block()
  value_1 = block_0.has_tasks()
  assert value_1 == False

if __name__ == "__main__":
    test_case_0()
    test_Block_has_tasks()

# Generated at 2022-06-25 04:57:32.302786
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_1 = Block()

    data = {
        'block': 'more',
        'rescue': 'more',
        'always': 'more',
    }
    block_1.deserialize(data)

    block_1 = block_1.copy()


# Generated at 2022-06-25 04:57:36.498809
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    try:
        block_0.deserialize(None)
    except TypeError as exc:
        assert True
    except Exception as exc:
        print(exc)


# Generated at 2022-06-25 04:57:45.427134
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # Create an instance of class Block with specfile
    block_0 = Block()
    # Create an instance of class Block with specfile
    block_1 = Block()
    # Create an instance of class Block with specfile
    block_2 = Block()
    # Create an instance of class Block with specfile
    block_3 = Block()
    # Create an instance of class Block with specfile
    block_4 = Block()
    # Create an instance of class Block with specfile
    block_5 = Block()
    # Create an instance of class Block with specfile
    block_6 = Block()

    data_0 = dict()
    data_0['parent_type'] = 'Block'
    data_0['parent'] = block_0.serialize()
    data_0['dep_chain'] = None
    data_0['role'] = block

# Generated at 2022-06-25 04:57:52.073129
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    block_0.block = [Task(), Task(), Task(), Task(), Task()]
    block_0.block[0].action = 'configure'
    block_0.block[0].tags = ['network', 'routing']
    block_0.block[1].action = 'start'
    block_0.block[1].tags = ['network', 'routing']
    block_0.block[2].action = 'stop'
    block_0.block[2].tags = ['network', 'routing']
    block_0.block[3].action = 'configure'
    block_0.block[3].tags = ['network', 'routing']
    block_0.block[4].action = 'restart'

# Generated at 2022-06-25 04:57:57.151072
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    def test_case(l_block, l_all_vars, l_expected):
        block = copy.deepcopy(l_block)
        all_vars = copy.deepcopy(l_all_vars)
        expected = copy.deepcopy(l_expected)
        # Create block
        # call method
        block.filter_tagged_tasks(all_vars)
        # get result
        # assert result == expected
        assert block == expected

# Generated at 2022-06-25 04:57:58.967286
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    loader = DictDataLoader({})
    block.set_loader(loader)
    r = block._loader == loader
    assert r, 'block.set_loader(loader) error'


# Generated at 2022-06-25 04:58:11.027490
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0.deserialize({'_role': None, '_parent': None, '_dep_chain': None, '_loader': None, '_raw_params': None, '_play': None, '_role_params': None, '_role_name': None, '_use_handlers': True, '_play_context': None, '_task_include': None, '_variable_manager': None, '_parent_type': None, '_loop': None, '_delegate_to': None, '_role_path': None, '_parent_role': None, '_vars_files': None, '_parent_block': None})



# Generated at 2022-06-25 04:58:14.575429
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_1 = Block()
    assert block_1.has_tasks() == False


# Generated at 2022-06-25 04:58:21.874688
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0.always = []
    block_0.block = []
    block_0.rescue = []
    block_0.role = Role()
    block_0.block_vars = None
    block_0.block_type = "raw"
    block_0.block_vars = {}
    assert(block_0.__class__ == Block)
    assert(block_0.always == [])
    assert(block_0.block == [] )
    assert(block_0.block_type == "raw")
    assert(block_0.block_vars == {})
    assert(block_0.rescue == [])
    assert(isinstance(block_0.role,Role))
    assert(block_0)
    # block_0.copy(exclude_parent

# Generated at 2022-06-25 04:58:28.590137
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    for has_tasks in (True, False):
        b = Block()
        if has_tasks:
            b.block = [Task()]
        else:
            b.block = []
        b.rescue = []
        b.always = []
        assert b.has_tasks() is has_tasks

        b = Block()
        if has_tasks:
            b.rescue = [Task()]
        else:
            b.rescue = []
        b.block = []
        b.always = []
        assert b.has_tasks() is has_tasks

        b = Block()
        if has_tasks:
            b.always = [Task()]

# Generated at 2022-06-25 04:59:10.690453
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    task = Task()
    task.action = 'debug'
    task.args = dict(msg='Foo')
    block = Block()
    block.block = [task]
    block.name = 'Test'
    task2 = Task()
    task2.action = 'debug'
    task2.args = dict(msg='Foo 2')
    block.block.append(task2)
    serialized = block.serialize()
    print(serialized)
    block_deserialized = Block()
    block_deserialized.deserialize(serialized)
    assert block_deserialized.name == 'Test'
    print('-----')
    serialized = block_deserialized.serialize()
    print(serialized)


# Generated at 2022-06-25 04:59:19.423660
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block(dict(block=[1,2,3])),'Success'
    assert Block.is_block(dict(block=[1,2,3],rescue=[1,2,3])),'Success'
    assert Block.is_block(dict(block=[1,2,3],always=[1,2,3])),'Success'
    assert Block.is_block(dict(block=[1,2,3],rescue=[1,2,3],always=[1,2,3])),'Success'
    assert not Block.is_block(dict(block=[1,2,3],rescue=[1,2,3],always=[1,2,3],test=[1,2,3])),'Success'

# Generated at 2022-06-25 04:59:24.129873
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    block_1 = Block()
    block_2 = Block()
    task_include_0 = TaskInclude()
    block_2._parent = task_include_0
    block_1._parent = block_2
    block_0._parent = block_1
    task_include_0.statically_loaded = True
    assert block_0.get_first_parent_include() == \
        task_include_0

if __name__ == "__main__":
    import pytest
    pytest.main(["-s", "test_block.py"])

# Generated at 2022-06-25 04:59:25.827362
# Unit test for method get_dep_chain of class Block

# Generated at 2022-06-25 04:59:37.742559
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    import os
    import tempfile

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_vault_password()
    variable_manager.extra_vars = dict(
        my_block_var=1,
        my_task_var=2,
    )


# Generated at 2022-06-25 04:59:47.432221
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    show_title('Unittest of Block.filter_tagged_tasks()')
    block_vars = dict()

    # Initializes variable 'block_vars' to an empty dictionary
    show_title('Initializes variable \'block_vars\' to an empty dictionary')
    show_results(block_vars)

    show_title('Creates variable \'block_vars\' with content:\n'
               '{\n'
               '    "firstvariable": "firstvalue",\n'
               '    "secondvariable": "secondvalue",\n'
               '    "thirdvariable": "thirdvalue"\n'
               '}')
    block_vars = {
                    'firstvariable': 'firstvalue',
                    'secondvariable': 'secondvalue',
                    'thirdvariable': 'thirdvalue'
                }

# Generated at 2022-06-25 04:59:52.382237
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    data = dict()
    try:
        block_0.deserialize(data)
    except (TypeError, ValueError) as exc:
        pass

# Generated at 2022-06-25 04:59:55.487149
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    assert block_0.all_parents_static()


# Generated at 2022-06-25 04:59:57.255015
# Unit test for method copy of class Block
def test_Block_copy():
    '''
   Unit test for method Block.copy
    '''
    pass


# Generated at 2022-06-25 05:00:05.035742
# Unit test for method copy of class Block
def test_Block_copy():
    # Test without optional parameters
    block_1 = Block()
    block_2 = block_1.copy()
    # Test with extend=False
    block_1 = Block()
    block_2 = block_1.copy(extend=False)
    # Test with prepend=False
    block_1 = Block()
    block_2 = block_1.copy(prepend=False)
    # Test with the parameter "exclude_parent", value = True
    block_1 = Block()
    block_2 = block_1.copy(exclude_parent=True)
    # Test with the parameter "exclude_tasks", value = True
    block_1 = Block()
    block_2 = block_1.copy(exclude_tasks=True)


# Generated at 2022-06-25 05:00:45.677173
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block(dict(block=[]))
    assert Block.is_block(dict(block=[1]))
    assert Block.is_block(dict(rescue=[]))
    assert Block.is_block(dict(always=[]))
    assert not Block.is_block(dict())
    assert not Block.is_block(0)
    assert not Block.is_block(None)


# Generated at 2022-06-25 05:00:51.149626
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0.name = 'block_0'
    block_0.rescue = list()
    block_0.block = list()
    block_0.always = list()
    block_1 = block_0.copy(exclude_parent=True, exclude_tasks=True)
    block_1_1 = block_1.copy(exclude_parent=True, exclude_tasks=True)
    block_1_1.name = 'block_1_1'
    block_1_2 = block_1.copy(exclude_parent=True, exclude_tasks=True)
    block_1_2.name = 'block_1_2'
    block_2 = block_1.copy(exclude_parent=True, exclude_tasks=True)

# Generated at 2022-06-25 05:00:54.251165
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    assert Block.has_tasks() == 0


# Generated at 2022-06-25 05:01:01.654474
# Unit test for method is_block of class Block
def test_Block_is_block():
    tasks = [{
        'action': 'command1'
    },{
        'action': 'command2'
    }]

    block = {
        'block': tasks,
        'rescue': [
            {'action': 'command3'}
        ],
        'always': [
            {'action': 'command4'}
        ]
    }

    # This is a block
    assert(Block.is_block(block) == True)

    # This is not a block
    value = {'action': 'command1'}
    assert(Block.is_block(value) == False)


# Generated at 2022-06-25 05:01:10.234044
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()

    # any changes to '_attributes' in the test may break the serialize/deserialize tests
    block_0._attributes = dict()
    block_0.deprecated = dict()
    block_0._ds = dict()
    block_0.action = ''
    block_0._valid_attrs = dict()
    block_0._parent = None
    block_0.local_vars = dict()
    block_0.statically_loaded = True
    block_0._loader = None
    block_0._role = None
    block_0._play = None
    block_0._dep_chain = None
    block_0._variable_manager = None
    block_0._use_handlers = False
    block_0._implicit = False
    block_0._block = []

# Generated at 2022-06-25 05:01:20.953585
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()

    class AnsiblePlay(object):
        pass

    class AnsibleVariableManager(object):

        def __init__(self):
            self.vars_cache = dict()

    ansible_play = AnsiblePlay()
    ansible_play.only_tags = []
    ansible_play.skip_tags = []
    block_0._play = ansible_play
    ansible_variable_manager_0 = AnsibleVariableManager()
    ansible_variable_manager_0.vars_cache = dict()
    block_0._variable_manager = ansible_variable_manager_0
    block_0._role = None
    block_0._use_handlers = False
    task_0 = dict()
    task_0['register'] = 'task_0_register'

# Generated at 2022-06-25 05:01:28.450308
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # Get data from ansible.cfg
    config_filename = C.CONFIG_FILE
    cfg = configparser.ConfigParser()
    cfg.read(config_filename)
    base_dir = cfg['defaults']['inventory']

    # Create variable manager
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(base_dir))
    variable_manager.extra_vars = {'my_var': 'goodbye', 'other_var': ['hello', 'world']}
    loader = DataLoader()
    # Create a dummy playbook
    play = Play().load({'hosts': 'all'}, variable_manager=variable_manager, loader=loader)
    # Create a block object
    block_0 = Block(play=play)
    # Serialize the block object
    serialized_block

# Generated at 2022-06-25 05:01:32.261694
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0.deserialize({})
    assert block_0.dep_chain ==  None


# Generated at 2022-06-25 05:01:33.494497
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0.deserialize()


# Generated at 2022-06-25 05:01:35.133760
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    block_0.all_parents_static()


# Generated at 2022-06-25 05:02:22.360238
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    '''
    Check that Block.filter_tagged_tasks return a Block object with task lists
    filtered based on tags (only_tags/skip_tags)
    '''

    # Generate a 'Block' object
    test_playbook = PlayBook()
    test_playbook._loader = DictDataLoader({})
    test_playbook._variable_manager = VariableManager()
    test_playbook._tagged_tasks_filter = {'only_tags':['test-tag'], 'skip_tags':[]}
    block = Block(parent=test_playbook)

    # Add tasks to block
    # T1: task tagged with test-tag
    # T2: "action" task
    # T3: task not tagged
    # T4: task tagged with wrong test-tag

    # T1
    task_data

# Generated at 2022-06-25 05:02:27.988332
# Unit test for method deserialize of class Block

# Generated at 2022-06-25 05:02:30.979587
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    _1 = block_0.copy()
    assert block_0 is not _1


# Generated at 2022-06-25 05:02:33.068224
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Test case 0
    block_0 = Block()
    assert block_0.get_dep_chain() == None


# Generated at 2022-06-25 05:02:33.960658
# Unit test for method copy of class Block
def test_Block_copy():
    test_case_0()


# Generated at 2022-06-25 05:02:40.063151
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    # Check return value
    assert block_0.get_first_parent_include() == None


# Generated at 2022-06-25 05:02:47.354507
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block(dict()) == True
    assert Block.is_block(dict(block='something')) == True
    assert Block.is_block(dict(rescue='something')) == True
    assert Block.is_block(dict(always='something')) == True
    assert Block.is_block(dict(block='something', rescue='something')) == True
    assert Block.is_block(dict(block='something', always='something')) == True
    assert Block.is_block(dict(rescue='something', always='something')) == True
    assert Block.is_block(dict(block='something', rescue='something', always='something')) == True
    assert Block.is_block(list()) == False
    assert Block.is_block(['something', 'something']) == False
    assert Block.is_block