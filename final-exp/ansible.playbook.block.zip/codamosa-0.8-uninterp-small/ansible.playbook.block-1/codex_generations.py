

# Generated at 2022-06-25 04:53:56.693968
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    test_case_0()


# Generated at 2022-06-25 04:54:01.950082
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    has_tasks = block_0.has_tasks()
    assert has_tasks == False


# Generated at 2022-06-25 04:54:07.167585
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0._valid_attrs = dict(block=dict(extend=True), rescue=dict(extend=True, prepend=True), always=dict(extend=True, prepend=True))
    data = dict()
    data['role'] = None
    data['parent'] = None
    data['block'] = None
    data['rescue'] = None
    data['always'] = None
    data['dep_chain'] = None
    block_0.deserialize(data)


# Generated at 2022-06-25 04:54:18.029143
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    block_0._dep_chain = ['dep_chain']
    dep_chain = block_0.get_dep_chain()
    assert dep_chain == ['dep_chain']

    block_1 = Block()
    block_1._parent = jump_queue()
    block_1._parent._parent = TaskInclude()
    dep_chain = block_1.get_dep_chain()
    assert dep_chain is None

    block_2 = Block()
    block_2._role = Role()
    dep_chain = block_2.get_dep_chain()
    assert dep_chain is None

    # TODO: check that all values in dep_chain list
    #       are not just references to original list


# Generated at 2022-06-25 04:54:19.796984
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()

    # Testing code goes here TODO
    raise NotImplementedError


# Generated at 2022-06-25 04:54:25.075243
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # Init block_0
    block_0 = Block()

    # Try to deserialize deserialize_0
    deserialize_0 = "{\"role\": {\"name\": \"test\"}}"
    try:
        block_0.deserialize(deserialize_0)
    except AnsibleError as e:
        print(e.message)
    assert False, "Unreachable"


# Generated at 2022-06-25 04:54:31.201907
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    ###
    # 1. Test case when the block has only one parent and the parent is a block that is statically_loaded
    ###
    block_0 = Block()
    parent_0 = Block()
    parent_0.statically_loaded = True
    block_0._parent = parent_0
    assert(block_0.all_parents_static() == True)

    ###
    # 2. Test case when the block has only one parent and the parent is a block that is not statically_loaded
    ###
    block_1 = Block()
    parent_1 = Block()
    parent_1.statically_loaded = False
    block_1._parent = parent_1
    assert(block_1.all_parents_static() == False)

    ###
    # 3. Test case when the block has more than one parent and all parents are statically_loaded

# Generated at 2022-06-25 04:54:33.333365
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    '''
    Block().has_tasks()
    '''
    block_0 = Block()
    assert block_0.has_tasks()


# Generated at 2022-06-25 04:54:43.111773
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()
    assert block_1.__class__.__name__ == "Block"

    # Less-simple example of Block.copy()
    file1 = '''
        - name: task0
          block:
            - debug: msg="hi"
              tags:
                - test_tag
        '''
    file2 = '''
        - name: task1
          include_tasks:
            file: test_file.yaml
          tags:
            - test_tag
        '''
    loader = DataLoader()
    role = Role()
    role._role_path = "test_role_path"
    role._role_name = "test_role_name"

    playbook = Playbook()
    playbook._loader = loader
    playbook._options = Options

# Generated at 2022-06-25 04:54:45.736378
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    block_0.set_loader(None)
    block_1 = Block()
    block_1.set_loader(None)
    block_2 = Block()
    block_2.set_loader(None)


# Generated at 2022-06-25 04:55:03.941015
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    block_0.get_dep_chain()


# Generated at 2022-06-25 04:55:09.271843
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_1 = Block()
    block_2 = Block()
    block_2.block = test_Block_filter_tagged_tasks_gen_blocks(3)    
    block_3 = Block()
    block_3.block = test_Block_filter_tagged_tasks_gen_blocks(3)
    block_4 = Block()
    block_4.block = test_Block_filter_tagged_tasks_gen_blocks(2)

    expected_block_1 = Block()
    expected_block_2 = Block()
    expected_block_2.block = test_Block_filter_tagged_tasks_gen_blocks(3)
    expected_block_3 = Block()
    expected_block_3.block = test_Block_filter_tagged_tasks_gen_blocks(3)
    expected

# Generated at 2022-06-25 04:55:12.001766
# Unit test for method is_block of class Block
def test_Block_is_block():
    block = Block()

    block_1 = block.is_block({})
    assert block_1 == False

    block_2 = block.is_block({'block':'block','rescue': 'test', 'always':'test'})
    assert block_2 == True


# Generated at 2022-06-25 04:55:24.086644
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    data = dict(
        name='test_block_name',
        when='test_block_when',
        fail_when='test_block_fail_when',
        block=[],
        rescue=[],
        always=[],
        is_task=False,
        loop='test_block_loop',
        loop_args='test_block_loop_args',
        loop_var='test_block_loop_var',
        delegate_to='test_block_delegate_to',
        become=False,
        become_user='test_block_become_user',
        become_method='test_block_become_method',
        run_once=False,
        loop_control='test_block_loop_control'
    )
    block_0.deserialize(data)

# Generated at 2022-06-25 04:55:29.946941
# Unit test for method copy of class Block
def test_Block_copy():
    # Initialize class Block
    block_1 = Block()

    # Copy class Block
    block_2 = block_1.copy()

    # Check if the copy is correct (the two objects are not the same)
    assert block_1 != block_2


# Generated at 2022-06-25 04:55:36.863383
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    b = Block()
    b.vars = {}
    b_copy = b.copy()
    assert b_copy.vars == {}
    b.vars["test"] = "test2"
    assert b.vars["test"] == "test2"
    b_copy = b.copy()
    assert b_copy.vars["test"] == "test2"

    my_task = Task()
    my_task_copy = my_task.copy()

    b.block = [my_task]
    b.rescue = [my_task]
    b.always = [my_task]
    b_copy = b.copy()
    my_task.action

# Generated at 2022-06-25 04:55:43.341975
# Unit test for method is_block of class Block
def test_Block_is_block():
    block_0 = Block()
    assert not Block.is_block([])
    assert not Block.is_block({})
    assert not Block.is_block(dict({u'block': []}))


# Generated at 2022-06-25 04:55:45.118125
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    assert block_0.get_dep_chain() == None


# Generated at 2022-06-25 04:55:50.122115
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a block, which has no loaded data
    block_0 = Block()
    # Create a pass dict, which Block.filter_tagged_tasks needs as the parameter
    all_vars = {}
    # Run the method
    result = block_0.filter_tagged_tasks(all_vars)
    # Check the result
    assert result == block_0


# Generated at 2022-06-25 04:55:54.567582
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # TODO: mock object for loader
    block_0 = Block()
    block_0.set_loader(None)


# Generated at 2022-06-25 04:56:22.098753
# Unit test for method deserialize of class Block

# Generated at 2022-06-25 04:56:33.569702
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    print("\n*** Testing get_first_parent_include() of class Block")

    task_include_0    = TaskInclude()
    task_include_1    = TaskInclude()
    block_0           = Block()
    block_1           = Block()
    block_2           = Block()
    block_0_first_parent = block_0.get_first_parent_include()
    assert block_0_first_parent == None

    task_include_0._parent = block_1
    block_1._parent = block_0
    block_0._parent = block_2
    block_2._parent = task_include_1
    block_0_first_parent = block_0.get_first_parent_include()
    assert block_0_first_parent == task_include_0

    block_1._parent

# Generated at 2022-06-25 04:56:45.198887
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    '''
     Test ansible.playbook.block.Block.deserialize
    '''
    block_0 = Block()


# Generated at 2022-06-25 04:56:46.639271
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0.deserialize({'use_handlers': False,
                         'dep_chain': None,
                         'always': []})


# Generated at 2022-06-25 04:56:57.269525
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0_dict = {
        'statically_loaded': False,
        'dep_chain': None,
        '_attributes': {},
        'use_handlers': False,
        'block': [],
        'rescue': [],
        'always': [],
        'parent': None,
        'parent_type': None
    }

    block_0.deserialize(block_0_dict)
    assert(block_0._attributes == {})
    assert(block_0.use_handlers is False)
    assert(block_0.block == [])
    assert(block_0.rescue == [])
    assert(block_0.always == [])
    assert(block_0.parent is None)

# Generated at 2022-06-25 04:57:07.279753
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    result = block_0.all_parents_static()
    assert result

    block_1 = Block(parent_block=Block())
    result = block_1.all_parents_static()
    assert result

    block_2 = Block(parent_block=Block(parent_block=Block()))
    result = block_2.all_parents_static()
    assert result

    block_3 = Block(parent_block=Block(parent_block=Block(parent_block=Block())))
    result = block_3.all_parents_static()
    assert result

    block_4 = Block(parent_block=Block(parent_block=Block(parent_block=Block(parent_block=Block()))))
    result = block_4.all_parents_static()
    assert result

    block_5 = Block

# Generated at 2022-06-25 04:57:10.075741
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    res = block_0.copy()
    assert isinstance(res, Block)


# Generated at 2022-06-25 04:57:17.505840
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext

    t0 = Task()
    t0.action = 'include_tasks'
    t0._parent = 'block 0'
    t0._role = 'parent role'
    t0._dep_chain = ['dep 1', 'dep 2']

    t1 = Task()
    t1.action = 'pause'
    t1.pause = 10
    t1._parent = 'block 1'
    t1._role = 'parent role'
    t1._dep_chain = ['dep 1', 'dep 2']

    t2 = Task()

# Generated at 2022-06-25 04:57:24.351712
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():

    block_1 = Block()
    block_1.block = [dict(action=dict(module='shell', args='ls')),
                     dict(action=dict(module='shell', args='whoami'))]

    assert block_1.has_tasks() == True

    block_2 = Block()
    assert block_2.has_tasks() == False


# Generated at 2022-06-25 04:57:31.249845
# Unit test for method copy of class Block
def test_Block_copy():
    block_1 = Block()
    result = block_1.deserialize({'role': {}, 'parent': {}, 'parent_type': 'Block'})
    assert result == None
    result = block_1.copy(exclude_parent=True, exclude_tasks=True)
    assert result is not block_1
    result = block_1.serialize()
    assert result == {'role': {}, 'parent': {}, 'parent_type': 'Block', 'dep_chain': None}
    result = block_1.deserialize({'role': {}, 'parent': {}, 'parent_type': 'Block'})
    assert result == None


# Generated at 2022-06-25 04:57:50.703434
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block = fake_block()
    dict_block = block.preprocess_data(dict(a=1, b=2))
    assert dict_block == dict(block=[dict(a=1, b=2)])

    block_list = block.preprocess_data([dict(a=1), dict(b=2)])
    assert block_list == dict(block=[dict(a=1), dict(b=2)])

    block_default = block.preprocess_data(dict())
    assert block_default == dict(block=[dict()])

    block_list_default = block.preprocess_data([dict(), dict()])
    assert block_list_default == dict(block=[dict(), dict()])

    block_include = block.preprocess_data(dict(a=1, b=2, include=dict()))
   

# Generated at 2022-06-25 04:57:52.925018
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    test_case_0()


# Generated at 2022-06-25 04:57:54.984882
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block = Block()
    assert block.all_parents_static() == True, \
        "Test of method all_parents_static of class Block failed."


# Generated at 2022-06-25 04:57:58.458047
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    result = False
    block_0 = Block()
    result = block_0.has_tasks()
    assert result == False


# Generated at 2022-06-25 04:58:00.764854
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block_1 = Block()
    assert not Block.is_block(list())
    assert not Block.is_block(dict())


# Generated at 2022-06-25 04:58:05.884550
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_1 = Block()
    block_1.deserialize({'rescue': None, 'ignore_errors': True, 'when': '1', 'block': ['echo 1', 'echo 2']})


# Generated at 2022-06-25 04:58:11.946573
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    yaml_str = """
    - meta: end_play
    """
    data = yaml.load(yaml_str)
    b = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    result = b.preprocess_data(data)
    assert result == {'block': [{'meta': 'end_play'}]}


# Generated at 2022-06-25 04:58:18.820941
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block_0 = Block()
    block_0.preprocess_data("a_string") == {"block": ["a_string"]}
    block_0.preprocess_data("a_string") == {"block": "a_string"}
    block_0.preprocess_data("a_string") == "a_string"
    block_0.preprocess_data("a_string") == None
    block_0.preprocess_data("a_string") == {"block": "a_string"}



# Generated at 2022-06-25 04:58:22.830150
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    block_1 = Block()
    block_2 = Block()
    loader_3 = DataLoader()
    block_0.set_loader(loader_3)
    assert block_0._loader == loader_3
    assert block_1._loader is block_2._loader


# Generated at 2022-06-25 04:58:33.236252
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    blk_0 = Block()

    assert blk_0.get_first_parent_include() is None

    task_0 = Task()
    task_1 = Task()

    blk_0.block = [ task_0, task_1 ]

    assert blk_0.get_first_parent_include() is None

    blk_1 = Block()
    blk_1.block = blk_0.block
    blk_0.block = [ blk_1 ]

    assert blk_1.get_first_parent_include() is None
    assert blk_0.get_first_parent_include() is None

    task_0 = TaskInclude()
    task_1 = Task()

# Generated at 2022-06-25 04:58:49.605186
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    # case where _dep_chain is None
    dep_chain = block_0.get_dep_chain()
    assert dep_chain is None


# Generated at 2022-06-25 04:58:56.625522
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    import ansible.playbook.block

    test_block = ansible.playbook.block.Block()
    test_block_include = ansible.playbook.block.Block()

    test_task_include = ansible.playbook.task_include.TaskInclude()
    test_task = ansible.playbook.task.Task()

    test_block.block = [test_block_include, test_task]
    test_block_include.block = [test_task_include, test_task]
    test_block_include.rescue = [test_task, test_task_include]
    test_block_include.always = [test_task_include, test_task]

    test_block = test_block.filter_tagged_tasks()

# Generated at 2022-06-25 04:59:07.091731
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.name = "pipeline"
    block.block = []
    block.block.append("foo")
    block.block.append("bar")
    block.rescue = ["baz"]
    block.always = ["qux"]
    block.when = "a == b"
    block.dep_chain = [1, 2, 3]
    block.retry = 3
    block.retry_delay = 42
    block.until = "b == c"
    block.ignore_errors = True
    block.pause_for = 10
    block.when_file_exists = "a.txt"
    block.when_file_missing = "b.txt"
    block.first_available_file = "c.txt"
    block.local_action = "baz"

# Generated at 2022-06-25 04:59:16.322995
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from mock import Mock
    block_0 = Block()
    block_1 = Block()
    task_0 = Task()
    task_1 = Task()
    task_2 = Task()
    handler_0 = Handler()
    handler_1 = Handler()
    handler_2 = Handler()
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_1 = HandlerTaskInclude()

    # Test case with value None
    assert block_0.get_

# Generated at 2022-06-25 04:59:18.178909
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()

    data = dict()
    block_0.deserialize(data)


# Generated at 2022-06-25 04:59:28.380488
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Test case #0 - all static
    block_0 = Block()
    task_0 = Task()
    task_1 = Task()
    task_2 = Task()
    block_0.load(dict(block=[task_0]))
    task_0.set_loader(DictDataLoader({}))
    task_0._parent = block_0
    test_case_0_met = block_0.all_parents_static() == True
    # Test case #1 - one static
    block_1 = Block()
    task_3 = Task()
    task_4 = Task()
    block_1.load(dict(block=[task_3]))
    task_3.set_loader(DictDataLoader({}))
    task_3._parent = block_1
    include_0 = TaskInclude()
   

# Generated at 2022-06-25 04:59:38.689048
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():

    block = Block(block = [Task(name='Mock')], use_handlers = False)
    assert block.has_tasks() is True

    block = Block(rescue = [Task(name='Mock')], use_handlers = False)
    assert block.has_tasks() is True

    block = Block(always = [Task(name='Mock')], use_handlers = False)
    assert block.has_tasks() is True

    block = Block(block = [], use_handlers = False)
    assert block.has_tasks() is False

    block = Block(rescue = [], use_handlers = False)
    assert block.has_tasks() is False

    block = Block(always = [], use_handlers = False)
    assert block.has_tasks() is False


#

# Generated at 2022-06-25 04:59:45.037892
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.role

    pb = ansible.playbook.play.Play()
    pb._loader = DictDataLoader({})
    pb.vars = dict()
    block = Block(play=pb)

    task = ansible.playbook.task.Task()
    task.set_loader(pb._loader)
    task._attributes['name'] = 'Rename file'
    task._attributes['tags'] = ['always']
    task.action = 'file'
    pb.add_role(ansible.playbook.role.Role())
    pb._included_files = ['/home/a/test.yml']
    block.block.append(task)
    pb.block = block



# Generated at 2022-06-25 04:59:47.882813
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    assert block_0.has_tasks() == False


# Generated at 2022-06-25 04:59:53.554015
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    with pytest.raises(NotImplementedError) as excinfo:
        block_0 = Block()
        block_0.deserialize()
    assert 'deserialize' in str(excinfo.value)



# Generated at 2022-06-25 05:00:06.836375
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block_0 = Block()
    block_0.preprocess_data("test_value")


# Generated at 2022-06-25 05:00:10.061603
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    assert block_0.filter_tagged_tasks() == None


# Generated at 2022-06-25 05:00:12.934378
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    result = block_0.all_parents_static()
    assert result == True


# Generated at 2022-06-25 05:00:14.880021
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()


# Generated at 2022-06-25 05:00:21.720485
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    b0 = Block()
    assert b0.get_first_parent_include() == None
    b1 = Block()
    b0._parent = b1

    ti1 = TaskInclude()
    b1._parent = ti1
    assert b0.get_first_parent_include() == ti1

# Unit tests for method all_parents_static of class Block

# Generated at 2022-06-25 05:00:26.518444
# Unit test for method copy of class Block
def test_Block_copy():
    _block = Block()
    _exclude_parent = False
    _exclude_tasks = False
    _return_value = _block.copy(_exclude_parent, _exclude_tasks)
    if not isinstance(_return_value, Block):
        raise AssertionError('Return value of copy is not a Block.')
    else:
        print('Return value of copy is a Block.')


# Generated at 2022-06-25 05:00:27.707555
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-25 05:00:34.405202
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    b1 = Block(parent=None)
    b2 = Block(parent=b1)
    b3 = Block(parent=b2)
    b4 = Block(parent=b3)
    b5 = Block(parent=b4)
    ti1 = TaskInclude(parent=None, play_context=PlayContext())
    ti2 = TaskInclude(parent=ti1, play_context=PlayContext())
    ti3 = TaskInclude(parent=ti2, play_context=PlayContext())
    ti4 = TaskInclude(parent=ti3, play_context=PlayContext())

# Generated at 2022-06-25 05:00:36.169107
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    b = Block()
    if not b.all_parents_static():
        raise AssertionError('Test failed.  Expected True, got False')


# Generated at 2022-06-25 05:00:45.706869
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    play = Play()
    block_0 = Block(play=play)
    assert block_0.all_parents_static() == True
    from ansible.playbook.task import Task
    task_0 = Task(play=play)
    block_1 = Block(play=play, parent=task_0)
    assert block_1.all_parents_static() == True
    from ansible.playbook.task_include import TaskInclude
    task_include_0 = TaskInclude(play=play)
    block_2 = Block(play=play, parent=task_include_0)
    assert block_2.all_parents_static() == True
    task_include_0.statically_loaded = False
    block_3 = Block(play=play, parent=task_include_0)
    assert block_3.all_

# Generated at 2022-06-25 05:01:11.576795
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()

# Generated at 2022-06-25 05:01:20.577946
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    assert Block().has_tasks() == False
    assert Block().has_tasks() == False
    assert Block().has_tasks() == False
    assert Block().has_tasks() == False
    assert Block().has_tasks() == False
    assert Block().has_tasks() == False
    assert Block().has_tasks() == False
    assert Block().has_tasks() == False
    assert Block().has_tasks() == False
    assert Block().has_tasks() == False
    assert Block().has_tasks() == False
    assert Block().has_tasks() == False
    assert Block().has_tasks() == False
    assert Block().has_tasks() == False
    assert Block().has_tasks() == False
    assert Block().has_tasks() == False
    assert Block().has_t

# Generated at 2022-06-25 05:01:26.361087
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # testing case 0
    block_0 = Block()

    # testing case 1
    block_1 = Block()

    # testing case 2
    block_2 = Block()

    # testing case 3
    block_3 = Block()

    # testing case 4
    block_4 = Block()

    # testing case 5
    block_5 = Block()

    # testing case 6
    block_6 = Block()

    # testing case 7
    block_7 = Block()


# Generated at 2022-06-25 05:01:30.474346
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    all_vars = dict()

    filtered_block = block_0.filter_tagged_tasks(all_vars)


# Generated at 2022-06-25 05:01:42.228204
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():

    block_1 = Block()

    test_cases = {}

    test_cases[0] = [{'block': [{'block': [{'debug': {'msg': 'test1'}}],
                                 'rescue': [{'debug': {'msg': 'test2'}}],
                                 'always': [{'debug': {'msg': 'test3'}}]}]},
                     {'block': [{'block': [{'debug': {'msg': 'test1'}}],
                                 'rescue': [{'debug': {'msg': 'test2'}}],
                                 'always': [{'debug': {'msg': 'test3'}}]}]}]


# Generated at 2022-06-25 05:01:44.281791
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # if necessary, create the test playbook here
    # e.g., create tasks with the following tags: ['tag1','tag2']
    # now attempt to filter here
    pass



# Generated at 2022-06-25 05:01:52.581623
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    # Setup so that there is a parent and a grandparent, both Tasks
    p = Task()
    g = Task()
    p._parent = g

    # Put a task in the block
    b = Block()
    b.block = [ p ]

    # Get the first parent with a TaskInclude
    assert b.get_first_parent_include() == None

    # Add a TaskInclude to the grandparent
    from ansible.playbook.task_include import TaskInclude
    g = TaskInclude()

    # Grandparent should be the result
    assert p._parent == g
    assert b.get_first_parent_include() == g

if __name__ == "__main__":
    try:
        test_case_0()
    except Exception as e:
        print(e)
        import traceback
       

# Generated at 2022-06-25 05:01:55.613998
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    block_1 = Block()
    block_2 = Block()
    block_3 = Block()
    block_4 = Block()

    b = block_0.filter_tagged_tasks(block_1.all_vars)
    assert b is not None


# Generated at 2022-06-25 05:01:58.166838
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    # Test for method get_dep_chain(self)
    # self._dep_chain is None
    try:
        block_0.get_dep_chain()
    except KeyError:
        pass


# Generated at 2022-06-25 05:02:02.524185
# Unit test for method copy of class Block
def test_Block_copy():
    block_1 = Block()
    block_2 = Block()
    # Test with both parameters True, should fail
    try:
        block_1.copy(True, True)
        assert False
    except:
        # fail
        assert True
    # Test with both parameters False, should pass
    try:
        block_1.copy(False, False)
        # pass
        assert True
    except:
        assert False


# Generated at 2022-06-25 05:02:34.361203
# Unit test for method is_block of class Block
def test_Block_is_block():
    import copy
    import sys
    import types
    import unittest
    import ansible.parsing.dataloader
    import ansible.playbook.role
    import ansible.playbook.task
    import ansible.playbook.helpers
    import ansible.vars.manager
    import ansible.template
    import ansible.inventory.host
    import ansible.inventory.group

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    from ansible.playbook.helpers import load_list_of_tasks
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role import Role


# Generated at 2022-06-25 05:02:39.507214
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # TODO: Add test case for Block.filter_tagged_tasks
    pass


# Generated at 2022-06-25 05:02:43.540557
# Unit test for method copy of class Block
def test_Block_copy():
    block_1 = Block()

    block_2 = block_1.copy()
    assert isinstance(block_1,Block)
    assert isinstance(block_1,Block)
    assert isinstance(block_2,Block)


# Generated at 2022-06-25 05:02:48.021208
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0.deserialize({'block': [], 'rescue': [], 'always': []})
