

# Generated at 2022-06-25 04:54:22.376334
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_1 = Block()
    all_vars_1 = dict()
    run_1 = block_1.filter_tagged_tasks(all_vars=all_vars_1)


# Generated at 2022-06-25 04:54:29.532641
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0.block = [{'register': 'item', 'loop': '{{ lookup("dig") | default([]) }}', 'when': '{{ public }} and (item is mapping and (item.address.address is not defined or item.address.address == "127.0.0.1"))'}]
    block_0.rescue = [{'name': 'name', 'debug': 'msg="{{ item.value }}"'}]
    block_0.always = [{'name': 'name', 'debug': 'msg="{{ item.value }}"'}]
    block_0.loop = '{{ lookup("dig") | default([]) }}'
    block_0.name = 'name'
    block_0.loop_control.loop_var = 'item.key'

# Generated at 2022-06-25 04:54:35.199741
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    data_0 = dict()
    assert_raises(AssertionError, block_0.deserialize, data_0)
    assert_raises(AssertionError, block_0.deserialize, data=data_0)


# Generated at 2022-06-25 04:54:37.552177
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = Block()
    all_vars = dict()
    block.filter_tagged_tasks(all_vars)


# Generated at 2022-06-25 04:54:41.763282
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    # test with sentinel value
    data_0 = block_0.get_dep_chain()
    assert data_0 is not None


# Generated at 2022-06-25 04:54:44.008300
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()
    assert(block_1 == block_0)


# Generated at 2022-06-25 04:54:46.584093
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    '''
    Unit test for method all_parents_static of class Block
    '''
    block_1 = Block()
    assert block_1.all_parents_static() == True, "Test case for method block_1.all_parents_static of class Block not implemented"


# Generated at 2022-06-25 04:54:51.867780
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    data_0 = dict()
    block_0.deserialize(data_0)


# Generated at 2022-06-25 04:54:58.374098
# Unit test for method deserialize of class Block
def test_Block_deserialize():

    # Typical use of method:
    block = Block(vars={'a': 1, 'b': 2})
    block_data = block.serialize()
    task1 = Task(name='task1', action='shell', args='ls', vars={'c': 3, 'b': 4})
    task2 = Task(name='task2', action='shell', args='ls', vars={'c': 5, 'd': 6})
    task3 = Task(name='task3', action='shell', args='ls', vars={'c': 7, 'd': 8})
    block.block = [task1, task2]
    block.rescue = [task3]
    block.set_loader(DictDataLoader({}))
    deserialized_block = Block()

# Generated at 2022-06-25 04:55:02.789328
# Unit test for method copy of class Block
def test_Block_copy():
    block_1 = Block()
    block_1.copy()


# Generated at 2022-06-25 04:55:32.650739
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_1 = Block()
    assert block_1.get_first_parent_include() == None


# Generated at 2022-06-25 04:55:44.382300
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    block_0 = Block()
    block_1 = Block()
    block_2 = Block()
    block_3 = Block()
    block_4 = Block()
    block_5 = Block()
    block_6 = Block()
    block_7 = Block()
    block_8 = Block()
    block_9 = Block()
    block_10 = Block()
    block_11 = Block()
    block_12 = Block()
    block_string = 'block_string'
    TaskInclude_0 = TaskInclude()
    TaskInclude_1 = TaskInclude()
    TaskInclude_2 = TaskInclude()
    TaskInclude_3 = TaskInclude()
    TaskInclude_4 = TaskInclude()
    TaskInclude_5 = Task

# Generated at 2022-06-25 04:55:48.343933
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # create object
    block_0 = Block()

    # execute method
    result = block_0.get_dep_chain()

    # assert result is of type NoneType
    assert isinstance(result, types.NoneType)

    # assert result is None
    assert result == None


# Generated at 2022-06-25 04:55:51.827888
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Set up the fixture
    block_0 = Block()
    # Add some logic here to determine the value of the variables all_vars
    raise TypeError
    block_0.filter_tagged_tasks(all_vars)


# Generated at 2022-06-25 04:56:01.102271
# Unit test for method deserialize of class Block

# Generated at 2022-06-25 04:56:06.354578
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_data = dict()
    block_data['block'] = 'block'
    block_data['rescue'] = ['rescue']
    block_data['always'] = ['always']
    block_data['name'] = 'name'
    block_data['dep_chain'] = 'dep_chain'
    role_data= dict()
    role_data['name'] = 'name'
    role_data['default_vars'] = 'default_vars'
    role_data['metadata'] = 'metadata'
    role_data['tasks'] = 'tasks'
    role_data['handlers'] = 'handlers'
    role_data['dependencies'] = 'dependencies'
    role_data['vars'] = 'vars'

# Generated at 2022-06-25 04:56:15.010374
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Create a mock object for mock_loader
    mock_loader = MagicMock(spec=TaskInclude)
    # Create some values
    mock_loader_value = 'terraform'
    # Create the test object
    test_obj = Block()
    # assert that the test object is valid
    assert test_obj._attributes['name'] is not None, "The set_loader test failed because the test object contains invalid attributes"
    # Call the set_loader method of the test object
    test_obj.set_loader(mock_loader)
    # assert that the set_loader call updated the right attribute
    assert test_obj._loader == mock_loader, "The set_loader test failed because the set_loader call failed to update the correct attribute"


# Generated at 2022-06-25 04:56:17.648776
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    assert block_0.get_first_parent_include() == None


# Generated at 2022-06-25 04:56:24.897304
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Block 
    block = Block(name="Test_Block")
    block.vars = dict(
        test_var=True
    )

    # Play
    play = Play()

    # Variable Manager
    variable_manager = VariableManager()
    variable_manager._fact_cache = dict()
    variable_manager._vars_cache = dict()

    # Block Tasks
    block_task_0 = Block(name="Test_Block_0")
    block_task_0.vars = dict(
        test_var=True
    )
    block_task_0.tags = ['test']

    block_task_1 = Block(name="Test_Block_1")
    block_task_1.vars = dict(
        test_var=True
    )


# Generated at 2022-06-25 04:56:26.279498
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    expected = True
    actual = block_0.all_parents_static()
    assert expected == actual, 'Expected: %s, Actual: %s' % (expected, actual)

# Generated at 2022-06-25 04:56:59.994704
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    assert block_0.has_tasks() == False


# Generated at 2022-06-25 04:57:07.354207
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    b1 = Block()
    assert b1.all_parents_static()

    b2 = Block(parent=b1)
    assert b2.all_parents_static()

    b1.statically_loaded = False
    assert not b2.all_parents_static()

    b3 = Block(parent=b2)
    assert not b3.all_parents_static()

    b2.statically_loaded = True
    assert not b3.all_parents_static()



# Generated at 2022-06-25 04:57:10.174771
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    # test for method copy of class Block
    block_1 = block_0.copy()


# Generated at 2022-06-25 04:57:11.322615
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_2 = Block()
    block_2.set_loader(None)


# Generated at 2022-06-25 04:57:18.483559
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()
    assert block_1._parent == None
    assert isinstance(block_1, Block)
    assert block_1._dep_chain == None
    assert block_0 is not block_1


# Generated at 2022-06-25 04:57:19.928303
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    try:
        block_0 = Block()
        ret_0 = block_0.has_tasks()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 04:57:31.982246
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Test case 1
    block_1 = Block(block=[Task(), Task(), Task()])

    play_1 = Play().load(dict(name="Dummy", hosts=['localhost'], gather_facts='no', roles=[]))
    block_1._play = play_1

    include_1 = TaskInclude(include=dict(static='yes', tasks='fake.yml'))
    include_1._task = play_1

    block_1._parent = include_1

    role_1 = Role(name="Dummy")
    role_1._get_parent_attribute = Mock()
    role_1._get_parent_attribute.return_value = 'something'
    block_1._role = role_1

    block_1._play._variable_manager = VariableManager()
    block_1._play._variable_manager._fact

# Generated at 2022-06-25 04:57:35.132995
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    data_0 = dict()
    assert block_0.deserialize(data_0) is None


# Generated at 2022-06-25 04:57:39.896783
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Set up objects
    block_0 = Block()

    # Process block_0
    all_vars = {}
    filtered = block_0.filter_tagged_tasks(all_vars)

    # Check results
    assert('block' in filtered.__dict__)

# Generated at 2022-06-25 04:57:41.818743
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_2 = Block()
    task_1 = Task()
    assert block_2.get_dep_chain() is None


# Generated at 2022-06-25 04:58:15.677034
# Unit test for method copy of class Block
def test_Block_copy():
    block_1 = Block()
    block_1_copy = block_1.copy()
    assert type(block_1_copy) == Block


# Generated at 2022-06-25 04:58:26.560671
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = Block()
    #Add block tests

# Generated at 2022-06-25 04:58:37.229052
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task, TaskInclude
    from ansible.playbook.handler import Handler
    all_vars = dict()
    block = Block()

    # block should be untouched since it has no tasks
    result = block.filter_tagged_tasks(all_vars)
    assert result.block == list()
    assert result.rescue == list()
    assert result.always == list()

    task = Task()
    task._attributes['tags'] = 'blah'
    block.block.append(task)
    task = Task()
    task._attributes['tags'] = 'test,test2'
    block.block.append(task)
    handler = Handler()
    handler._attributes['tags'] = 'test3,test4'
    block.always.append(handler)
    block

# Generated at 2022-06-25 04:58:46.289588
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    
    # Create Host object
    host = Host(name="myhost")

    # Create Group object
    group = Group(name="mygroup")

    # Create Task object
    task = Task()

    # Append host and group to task's hosts, groups fields
    task.hosts = [host,]
    task.groups = [group,]

    # Create TaskInclude object
    task_include = TaskInclude()

    # Append task and task_include to block's block field
    block_0 = Block()

# Generated at 2022-06-25 04:58:48.431690
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    #TODO
    raise(NotImplementedError, "test_Block_filter_tagged_tasks")


# Generated at 2022-06-25 04:58:49.881830
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    assert block_0.all_parents_static() is True


# Generated at 2022-06-25 04:58:52.099860
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    block_0.set_loader(loader=None)


# Generated at 2022-06-25 04:58:53.426451
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block = Block()
    assert block.get_dep_chain() == None


# Generated at 2022-06-25 04:58:55.376496
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    obj = Block()

    obj.block = [1,2,3]
    assert obj.has_tasks() == True

    obj.block = []
    assert obj.has_tasks() == False

# Generated at 2022-06-25 04:59:03.170997
# Unit test for method copy of class Block

# Generated at 2022-06-25 04:59:37.183687
# Unit test for method copy of class Block
def test_Block_copy():
    # Get an instance of Block
    block_0 = Block()
    # Call method copy of Block
    block_0.copy()

# Generated at 2022-06-25 04:59:44.369529
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():

    # test default value
    block_0 = Block()
    assert block_0.get_dep_chain() == None
    block_0._dep_chain = []
    assert block_0.get_dep_chain() == []
    block_0._dep_chain = None
    assert block_0.get_dep_chain() == None


# Generated at 2022-06-25 04:59:54.549796
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # data_0 is of type dict
    data_0 = dict(
        block=[
            dict(
                name="example",
                include=dict(
                    file="example.yml"
                )
            )
        ]
    )
    # parent_0 is of type object
    parent_0 = object()
    block_0 = Block(
        parent_0,
        implicit=True
    )
    # data_1 is of type dict
    data_1 = dict(
        block=[
            dict(
                name="example",
                include=dict(
                    file="example.yml"
                )
            )
        ]
    )
    # parent_0 is of type object
    parent_0 = object()
    block_1 = Block(
        parent_0,
        implicit=True
    )
   

# Generated at 2022-06-25 04:59:56.411814
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()

    block_1 = Block(task_include=None)
    block_1.deserialize(block_0.serialize())


# Generated at 2022-06-25 05:00:03.321770
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    try:
        data = "{}".format({"block": [{"action": "meta", "args": {"_raw_params": "cache_reload=yes"}}]})
        bl = Block.load(data, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
        bl.set_loader(loader=None)
    except Exception as e:
        print(e)
        print("Failed to set loader")
        pass



# Generated at 2022-06-25 05:00:07.022029
# Unit test for method copy of class Block
def test_Block_copy():
    # Create a new instance of Block
    # Test the copy method
    block_0 = Block()
    block_1 = block_0.copy()
    assert block_0.__class__ == block_1.__class__


# Generated at 2022-06-25 05:00:17.084983
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    block_0.statically_loaded = False
    block_0.role_name = "cds_test"
    block_0.task_tags = []
    block_0.always = []
    task_1 = Task()
    task_1.statically_loaded = False
    task_1.name = "task_1"
    task_1.tags = []
    task_1.when = {"true": 0}
    block_0.block = [task_1]
    block_0.rescue = []
    block_0._play = None
    block_0._role = None
    block_0._loader = None
    block_0._variable_manager = None
    block_0._use_handlers = False
    block_0._loop = None
    r = block_0

# Generated at 2022-06-25 05:00:19.179825
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    assert block_0.has_tasks() == False


# Generated at 2022-06-25 05:00:20.487751
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0.copy()


# Generated at 2022-06-25 05:00:22.918321
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    dep_chain_0 = block_0.get_dep_chain()
    assert dep_chain_0 == None


# Generated at 2022-06-25 05:01:01.562077
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_deserialize_0 = Block()


# Generated at 2022-06-25 05:01:10.554410
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block._attributes['name'] = "test_block"
    loader = DictDataLoader(dict())
    my_vars = dict(foo='bar', bam='baz')
    vm = VariableManager(loader=loader, variables=my_vars)

    # test_case_0
    block_0 = Block(loader=loader, variable_manager=vm)

    # test_case_1
    block_1 = Block(loader=loader, variable_manager=vm)

    # test_case_2
    block_2 = Block(loader=loader, variable_manager=vm)

    # play_loader might be None
    # test_case_3
    block_3 = Block(loader=None, variable_manager=vm)

    # test_case_4

# Generated at 2022-06-25 05:01:18.223617
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    #define test variables
    from ansible.playbook.task import Task
    t=Task()
    t._attributes['name'] = 'task'
    t._attributes['tags'] = ['tag1', 'tag2']
    from ansible.playbook.play import Play
    p=Play()
    p._attributes['only_tags'] = ['tag2','tag3']

    #define Block
    b=Block(parent=p)
    b._attributes['block'] = [t]

    #set object attributes
    assert b.filter_tagged_tasks({})
    assert t in b.block


# Generated at 2022-06-25 05:01:19.772143
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_1 = Block()
    block_1.set_loader(None)


# Generated at 2022-06-25 05:01:27.505684
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_1 = Block()
    block_2 = Block()
    block_3 = Block()
    block_4 = Block()
    block_5 = Block()
    block_6 = Block()

    block_1.deserialize({'block': [{'tasks': [{'command': 'echo bar'}, {'command': 'echo foo'}]}, {'tasks': [{'command': 'echo baz'}]}]})

    assert block_1.block is not None

    assert block_1.block[0].has_tasks()
    assert block_1.block[1].has_tasks()




# Generated at 2022-06-25 05:01:38.827955
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.parsing.vault import VaultLib

    block_all_tasks_1 = Block()

    task_0 = Task()
    block_all_tasks_1.block = [task_0]

    task_1 = Task()
    block_all_tasks_1.block = [task_1]

    task_2 = Task()
    block_all_tasks_1.block = [task_2]

    block_all_tasks

# Generated at 2022-06-25 05:01:43.415117
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    block_0.resource = 'test block resource'
    TaskInclude = TaskInclude()
    TaskInclude.dep_chain = ['test dep chain']
    block_0._dep_chain = None
    block_0._parent = TaskInclude
    TaskInclude._parent = None

    ret = block_0.get_dep_chain()
    assert ret == ['test dep chain'], ret


# Generated at 2022-06-25 05:01:46.668258
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    block_0.block = []
    block_0.rescue = []
    block_0.always = []
    assert block_0.has_tasks() == False

# Testing the load function

# Generated at 2022-06-25 05:01:50.271392
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_1 = Block()
    block_2 = Block()
    assert block_1.filter_tagged_tasks(None).__eq__(block_2)


# Generated at 2022-06-25 05:01:54.176922
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    data_0 = {}
    all_vars_0 = {}
    assert block_0.filter_tagged_tasks(all_vars_0) is not None


# Generated at 2022-06-25 05:02:40.619949
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # Test data for deserialize
    uut = Block()

# Generated at 2022-06-25 05:02:44.126871
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    assert block_0.has_tasks() == 0

    # setup all task lists to have tasks
    block_0.block = [1]
    block_0.rescue = [1]
    block_0.always = [1]
    assert block_0.has_tasks() == 1
