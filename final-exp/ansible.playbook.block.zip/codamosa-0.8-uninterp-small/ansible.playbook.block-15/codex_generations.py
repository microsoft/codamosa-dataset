

# Generated at 2022-06-25 04:53:50.426709
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # instance of class Block
    block_0 = Block()
    # Testing attr_loader of class Block, which is an instance of class Loader
    loader_0 = Loader()
    # Testing method set_loader of class Block
    block_0.set_loader(loader_0)


# Generated at 2022-06-25 04:53:55.042947
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_1 = Block()
    block_1._play = 'play_3'
    block_1._role = 'role_4'
    block_1._dep_chain = None
    block_1._parent = 'block_0'

    # Invoke method
    result = block_1.get_dep_chain()
    assert result == 'block_0'


# Generated at 2022-06-25 04:53:58.516313
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block_0 = Block()
    ds = {'block': ['task_0', ]}
    block_1 = Block.load(ds)
    assert block_1.post_validate()
    assert block_1.block[0]


# Generated at 2022-06-25 04:54:01.841101
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    var_0 = block_0.all_parents_static()


# Generated at 2022-06-25 04:54:09.029313
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    def validate_all_parents_static(block, expected, block_dict):
        assert block.all_parents_static() == expected, \
            "ERROR: Block %s did not evaluate all_parents_static() correctly." % block_dict['name']

    blocks = dict()

    block_0 = Block()
    block_0._parent = None
    blocks['block_0'] = block_0
    validate_all_parents_static(block_0, True, blocks['block_0'])

    block_1 = Block()
    block_1._parent = block_0
    blocks['block_1'] = block_1

# Generated at 2022-06-25 04:54:10.617478
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    assert True == block_0.all_parents_static()


# Generated at 2022-06-25 04:54:12.543726
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-25 04:54:15.246052
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Instantiate the class
    block_0 = Block()
    # Get the value of attribute dep_chain
    var_0 = block_0.get_dep_chain()


# Generated at 2022-06-25 04:54:16.468433
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    test_case_0()


# Generated at 2022-06-25 04:54:18.436853
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_1 = Block()
    result_1 = block_1.has_tasks()
    assert result_1 == False


# Generated at 2022-06-25 04:54:50.361663
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block_0 = Block()
    block_1 = Block()
    block_2 = Block()
    block_3 = Block()
    block_loop = True
    while (block_loop == True):
        try:
            assert block_0 is not None
            block_loop = False
        except Exception:
            block_loop = True
            continue

    assert block_0 is not None
    assert block_0._parent is None
    assert block_0._attributes is None
    assert block_0._valid_attrs is None
    assert block_0.block is None
    assert block_0.rescue == []
    assert block_0.always == []
    assert block_0._use_handlers is None
    assert block_0._dep_chain is None


# Generated at 2022-06-25 04:54:52.564955
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    with pytest.raises(AnsibleParserError):
        block_0.set_loader(None)


# Generated at 2022-06-25 04:54:57.789106
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext

    # Create a block object
    block_get_dep_chain = Block()

    # Calling the get_dep_chain method
    block_get_dep_chain.get_dep_chain()



# Generated at 2022-06-25 04:55:05.155871
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    block_0 = Block()
    ds_0 = 'test string'
    try:
        block_0.preprocess_data(ds_0)
    except AssertionError as e:
        print(e)
    ds_1 = AnsibleUnicode('test unicode')
    try:
        block_0.preprocess_data(ds_1)
    except AssertionError as e:
        print(e)
    ds_2 = AnsibleSequence([])

# Generated at 2022-06-25 04:55:11.663885
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    block_0.block = []
    block_0.rescue = []
    block_0.always = []
    block_0.has_tasks()


# Generated at 2022-06-25 04:55:17.385532
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    b = Block()
    # test case 0
    assert b.preprocess_data(ds={'block': [{'debug': 'msg=foo'}]}) == {'block': [{'debug': 'msg=foo'}]}
    # test case 1
    assert b.preprocess_data(ds='foo') == {'block': ['foo']}
    # test case 2
    assert b.preprocess_data(ds=['foo']) == {'block': ['foo']}

# Generated at 2022-06-25 04:55:20.480718
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    loader_0 = DataLoader()

    block_0.set_loader(loader_0)
    assert block_0._loader == loader_0


# Generated at 2022-06-25 04:55:29.947525
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_1 = Block()

    # test with a null task list
    # we're not doing an assert here because the return value is not well defined when there are no tasks
    block_1.filter_tagged_tasks({})

    # test with a simple task list
    task = Block()
    block_1.block = [task]
    res = block_1.filter_tagged_tasks({})
    assert res.block == [task]

    # test with a complex task graph
    task_2 = Block()
    block_1.block.append(task_2)
    task_2.block = [task_2]
    block_1.rescue = [task_2]
    block_1.always = [task_2]
    res = block_1.filter_tagged_tasks({})
    assert res

# Generated at 2022-06-25 04:55:32.511497
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    # test method with None case
    assert block_0.get_first_parent_include() == None

    # test method with parent case
    block_1 = Block()
    block_1._parent = block_0
    assert block_1.get_first_parent_include() == None


# Generated at 2022-06-25 04:55:36.862284
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    obj = Block()
    assert not obj.deserialize({})


# Generated at 2022-06-25 04:56:09.264464
# Unit test for method copy of class Block
def test_Block_copy():
    pass


# Generated at 2022-06-25 04:56:10.930726
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Initialize object Block
    block_0 = Block()

    assert block_0.has_tasks() ==  True


# Generated at 2022-06-25 04:56:21.525549
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0.deserialize({'always': [],
                         'dep_chain': None,
                         'parent': {'always': [],
                                    'dep_chain': None,
                                    'loop': "{{ list_of_ips }}",
                                    'loop_control': {'loop_var': "ansible_host"},
                                    'name': "loop_block",
                                    'parent': None,
                                    'parent_type': None,
                                    'register': "host_loop",
                                    'rescue': [],
                                    'role': None},
                         'parent_type': "IncludedFile",
                         'rescue': []})


# Generated at 2022-06-25 04:56:29.356356
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0._attributes['name'] = 'foo'
    block_0.always = []
    block_0.always.append(Block())
    block_0.always[0]._attributes['name'] = 'bar'
    block_1 = block_0.copy()
    assert(block_1._attributes['name'] == 'foo')
    assert(block_1.always[0]._attributes['name'] == 'bar')



# Generated at 2022-06-25 04:56:32.222306
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    loader_0 = DataLoader()
    block_0.set_loader(loader_0)


# Generated at 2022-06-25 04:56:33.465735
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    assert block_0.all_parents_static() == True


# Generated at 2022-06-25 04:56:38.077967
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    block_1 = Block()
    block_0.set_loader(block_1)
    assert block_0._loader == block_1


# Generated at 2022-06-25 04:56:43.465407
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    assert(block_0.get_dep_chain() == None)
    block_1 = Block(dep_chain = [])
    assert(block_1.get_dep_chain() == [])
    block_2 = Block(dep_chain = [])
    assert(block_2.get_dep_chain() == [])
    dep_chain_list = []
    block_3 = Block(dep_chain = dep_chain_list)
    assert(block_3.get_dep_chain() == [])
    block_4 = Block(dep_chain = [])
    assert(block_4.get_dep_chain() == [])
    block_5 = Block(dep_chain = [block_3, block_4])

# Generated at 2022-06-25 04:56:51.063166
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0_copy = block_0.copy()
    assert block_0_copy.block == []
    assert block_0_copy.rescue == None
    assert block_0_copy.always == None
    assert block_0_copy.loop == None
    assert block_0_copy.loop_args == None
    assert block_0_copy.when == None
    assert block_0_copy.dep_chain == None
    assert block_0_copy._parent == None
    assert block_0_copy._role == None
    assert block_0_copy._play == None
    assert block_0_copy._loader == None
    assert block_0_copy._variable_manager == None
    assert block_0_copy._use_handlers == True
    assert block_0_copy.failed_when

# Generated at 2022-06-25 04:57:02.817934
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    '''
    Unit test for method Block.deserialize
    '''

    block_0 = Block()

# Generated at 2022-06-25 04:57:23.515585
# Unit test for method filter_tagged_tasks of class Block

# Generated at 2022-06-25 04:57:28.236919
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    assert block_0.get_dep_chain() is None
    block_1 = Block()
    assert block_1.get_dep_chain() is None
    block_0._dep_chain = [block_1]
    block_1._dep_chain = 'foobar'
    assert block_0.get_dep_chain() == [block_1]
    assert block_1.get_dep_chain() == 'foobar'
    block_1._dep_chain = None


# Generated at 2022-06-25 04:57:34.317831
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = Block()
    meta = ActionModule("\'block\'", {}, False, False, None)
    block.block = [meta]
    fake_play = Play().load({})
    fake_play.only_tags = ["fake_only_tags"]
    fake_play.skip_tags = ["fake_skip_tags"]
    block._play = fake_play
    block.filter_tagged_tasks(vars())
    assert block.block[0]._attributes == {}
    block.block[0]._attributes["tags"] = ["fake_only_tags"]
    block.filter_tagged_tasks(vars())
    assert block.block[0]._attributes == {}
    block.block[0]._attributes["tags"] = ["fake_skip_tags"]
    block.filter_tagged_t

# Generated at 2022-06-25 04:57:38.070231
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    dep_chain_list = block_0.get_dep_chain()

    assert(dep_chain_list is None)


# Generated at 2022-06-25 04:57:39.589554
# Unit test for method copy of class Block
def test_Block_copy():
    block_obj = Block()
    assert block_obj.copy()


# Generated at 2022-06-25 04:57:44.805907
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block()
    assert b.has_tasks() == False

    b.block = [Task()]
    assert b.has_tasks() == True

    b.block = []
    assert b.has_tasks() == False

    b.rescue = [Task()]
    assert b.has_tasks() == True

    b.rescue = []
    assert b.has_tasks() == False

    b.always = [Task()]
    assert b.has_tasks() == True


# Generated at 2022-06-25 04:57:52.778867
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    b = Block()

    data = {
        '_role': {
            '_parent': {}
        },
        '_parent': {
            '_attributes': {
                'tags': ['test_parent']
            }
        },
        '_attributes': {
            'name': 'test',
            'tags': ['test']
        }
    }
    b.deserialize(data)

    assert b.tags == ['test_parent', 'test']
    assert b._role.parent == {}
    b.tags = ['test_parent', 'test', 'test']
    assert len(b.tags) == 2


# Generated at 2022-06-25 04:58:00.205154
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    play_0 = Play()
    block_0 = Block(play=play_0)
    # Test that block_0 object's tasks list is empty.
    assert block_0.block == []
    # Test that block_0 object's rescue list is empty.
    assert block_0.rescue == []
    # Test that block_0 object's always list is empty.
    assert block_0.always == []
    # Test that block_0 object's filter_tagged_tasks() returns an empty object.
    assert block_0.filter_tagged_tasks({}) == block_0
    block_1 = block_0.filter_tagged_tasks({})
    # Test that block_1 object's tasks list is empty.
    assert block_1.block == []
    # Test that block_1 object's rescue list is empty.

# Generated at 2022-06-25 04:58:04.658138
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    print(block_0.has_tasks())


# Generated at 2022-06-25 04:58:07.184555
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    dep_chain_0 = block_0.get_dep_chain()
    assert dep_chain_0 == None


# Generated at 2022-06-25 04:58:29.746563
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # test_case_0
    block_0 = Block()
    assert(block_0.all_parents_static() == True)


# Generated at 2022-06-25 04:58:35.290374
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    # Unit test expects 0 tasks to be in the block
    if block_0.has_tasks():
        raise AssertionError


# Generated at 2022-06-25 04:58:37.155390
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()
    assert block_0 == block_1


# Generated at 2022-06-25 04:58:41.553725
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()

    # Verify that the Block is being returned
    assert block_0.get_dep_chain() == None


# Generated at 2022-06-25 04:58:52.266018
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0._ds = dict()
    block_0._attributes = dict()
    block_0._loader = None
    block_0._variable_manager = None
    block_0._parent = None
    block_0.block = []
    block_0.rescue = []
    block_0.always = []
    block_0._play = None
    block_0._use_handlers = None
    block_0._dep_chain = None
    block_0._role = None
    block_0._task_include = None
    block_0._implicit = None
    block_0._static_deps = set()
    block_0._included_path = None
    block_0._vars_from_main = set()
    block_0._vars_from_role

# Generated at 2022-06-25 04:59:01.664462
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()

# Generated at 2022-06-25 04:59:12.721460
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.inventory.host import Host
    a = PlayContext()
    b = Block()
    c = TaskInclude()
    d = Task()
    e = Handler()
    f = Host(name="localhost")
    a.set_loader(None)
    b.set_loader(a._loader)
    c.set_loader(b._loader)
    d.set_loader(c._loader)
    e.set_loader(d._loader)
    f.set_loader(e._loader)
    d._parent = c
   

# Generated at 2022-06-25 04:59:16.248822
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():

    # Load data
    block_0 = Block()

    # Get first parent include
    block_0_get_first_parent_include = block_0.get_first_parent_include()

    # Assert
    assert(block_0_get_first_parent_include == None)


# Generated at 2022-06-25 04:59:20.645146
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # The procedure is simple, create a Block instance and check if the
    # variable loader is set or not

    block_ = Block()

    # test against None
    block_.set_loader(None)
    assert block_._loader is None

    # test with a loader
    loader = object()
    block_.set_loader(loader)
    assert block_._loader is loader

# Generated at 2022-06-25 04:59:21.899245
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0.deserialize(None)


# Generated at 2022-06-25 04:59:44.645357
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from units.mock.loader import DictDataLoader
    loader = DictDataLoader({'main': {'tasks': [{'block': [{'local_action': 'debug msg="test block"'}], 'meta': {'foo': 'bar'}}]}})
    b = Block()
    b.deserialize({'loader': loader, '_attributes': {'foo': 'bar'}, 'name': 'test', 'block': [{'action': 'debug', 'msg': 'test block'}]})
    assert b.serialize() == {'_attributes': {'foo': 'bar'}, 'name': 'test', 'block': [{'action': 'debug', 'msg': 'test block'}], 'meta': {}}


# Generated at 2022-06-25 04:59:46.280447
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    # Test for the exception
    try:
        block_0.deserialize(None)
    except IOError as e:
        assert isinstance(e, IOError)


# Generated at 2022-06-25 04:59:57.108508
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    pb = Playbook()
    pb.load_from_file('test.yml')
    all_vars = {}
    b0 = pb.get_plays()[0].get_roles()[0].get_tasks()[0].filter_tagged_tasks(all_vars)
    assert b0.has_tasks()

    b1 = pb.get_plays()[0].get_roles()[0].get_tasks()[1].filter_tagged_tasks(all_vars)
    assert b1.has_tasks()

    b2 = pb.get_plays()[0].get_roles()[0].get_tasks()[2].filter_tagged_tasks(all_vars)
    assert not b2.has_tasks()



# Generated at 2022-06-25 05:00:01.497641
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    data_0 = {'always': [], 'rescue': [], 'block': [], 'dep_chain': None, 'parent': {'defaults': {'tags': [], 'gather_facts': True}, 'name': 'Example', 'playbook': 'Example.yml'}, 'parent_type': 'Play'}
    block_0.deserialize(data=data_0)


# Generated at 2022-06-25 05:00:06.836472
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0.vars = dict()
    block_0.post_validate()
    block_0.serialize()
    block_0.deserialize(dict(block=dict()))
    block_1 = block_0.copy(exclude_parent=False, exclude_tasks=False)


# Generated at 2022-06-25 05:00:12.304120
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():

    class block:

        def get_parent_attribute(self, attr, extend=False, prepend=False):
            return None

        def get_include_params(self):
            return None

    block_0 = block()

    assert len(block_0.filter_tagged_tasks(0)) == 0



# Generated at 2022-06-25 05:00:14.919459
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    assert not block_0.get_first_parent_include()


# Generated at 2022-06-25 05:00:25.663790
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block(exclude_parent=True)
    block.deserialize(dict(block=[dict(action=dict(module='setup')), dict(action=dict(module='command', args=dict(chdir='/tmp')))], rescue=[dict(action=dict(module='setup')), dict(action=dict(module='command', args=dict(chdir='/tmp')))], always=[dict(action=dict(module='setup')), dict(action=dict(module='command', args=dict(chdir='/tmp')))], register='tmp'))
    block.serialize()

# Generated at 2022-06-25 05:00:27.167595
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()

test_case_0()
test_Block_filter_tagged_tasks()

# Generated at 2022-06-25 05:00:33.992848
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    data = {'max_fail_percentage': None, 'until': None, 'delay': None, 'retries': None, 'rescue': [], 'always': [], 'dep_chain': None, 'block': [{'when': None, 'name': u'Generate a list of random hostnames', 'local_action': {'module_name': u'generate_hostnames', 'module_args': {'count': 5, 'pattern': u'prefix-%02x'}}}, {'when': None, 'name': u'Use the first hostname', 'local_action': {'module_name': u'set_fact', 'module_args': {'ansible_host': u'{{ generated_hostnames.0 }}'}}}]}
    block_0.deserialize(data)

# Unit test

# Generated at 2022-06-25 05:01:01.297712
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # block_0 = Block()
    block_0 = Block.load(dict(block=[dict(name="task0", action=dict(module="foo", args=dict())), dict(name="task1", action=dict(module="bar", args=dict(arg1="value1"))), dict(name="task2", action=dict(module="baz", args=dict(arg1="value1", arg2="value2"))), dict(name="task3", action=dict(module="foo", args=dict(arg1="value1")))]), use_handlers=True, variable_manager=MagicMock(), loader=MagicMock())

    all_vars = MagicMock()
    result = block_0.filter_tagged_tasks(all_vars)
    assert(result != None)


# Generated at 2022-06-25 05:01:03.810360
# Unit test for method copy of class Block
def test_Block_copy():
    block_1 = Block()
    block_2 = block_1.copy()
    if not isinstance(block_2, Block):
        raise Exception("%s is not a Block" % type(block_2))


# Generated at 2022-06-25 05:01:13.162968
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    TaskInclude_1 = TaskInclude()
    Task_0 = Task()
    TaskInclude_1.statically_loaded = True
    TaskInclude_1.name = 'a'
    TaskInclude_1.parent = block_0
    TaskInclude_1.tasks = [Task_0]
    TaskInclude_1.tags = ['a', 'b']
    TaskInclude_1.when = ['a', 'b']
    TaskInclude_1.static_include = True
    TaskInclude_1.vars = {'a': 1}
    TaskInclude_1.loop = ['a', 'b']
    TaskInclude_1.loop_args = {'a': 1}
    TaskInclude_1.loop_control = ['a', 'b']
   

# Generated at 2022-06-25 05:01:15.396303
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    assert type(block_0.copy()) is Block


# Generated at 2022-06-25 05:01:23.067438
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    '''
    Tests that blocks behave as expected when trying to determine whether or not
    all of their parents are statically loaded.
    '''
    assert not Block().all_parents_static()

    b1 = Block()
    b1.statically_loaded = True

    assert b1.all_parents_static()

    b2 = Block()
    b2.statically_loaded = True
    b1.block = [b2]

    assert b2.all_parents_static()

    b3 = Block()
    b3.statically_loaded = True
    b3.block = [b2]

    assert b2.all_parents_static()

    b2.block = [b1]

    assert b2.all_parents_static()
    assert not b1.all_parents_static()

    # import is here to

# Generated at 2022-06-25 05:01:26.615620
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    defined_chain = ['dep1', 'dep2', 'dep3']
    block_0 = Block(dep_chain=defined_chain)
    assert block_0.get_dep_chain() == defined_chain


# Generated at 2022-06-25 05:01:33.378311
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_1 = Block()
    # Set loader on Block
    block_1.set_loader(None)
    if block_1._loader is None:
        print("Success: test_Block_set_loader")
    else:
        print("Failure: test_Block_set_loader")

# Unit test function for class Block

# Generated at 2022-06-25 05:01:42.849825
# Unit test for method deserialize of class Block

# Generated at 2022-06-25 05:01:44.130292
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    assert block_0.has_tasks() == False


# Generated at 2022-06-25 05:01:46.144470
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    block_0.block = [Task(), Task()]
    expect_result = True
    actual_result = block_0.has_tasks()
    assert actual_result == expect_result
