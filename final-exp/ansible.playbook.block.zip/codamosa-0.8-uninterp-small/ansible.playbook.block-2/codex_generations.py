

# Generated at 2022-06-25 04:53:57.322680
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create an instance of a Block object and pass it to a block
    tuple_0 = ()
    block_0 = Block()

    # Check if the method all_parents_static returns the expected result
    if block_0.all_parents_static() != True:
        raise AssertionError("Returned values do not match expected values")


# Generated at 2022-06-25 04:53:59.582286
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    pass


# Generated at 2022-06-25 04:54:01.368044
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    tuple_0 = ()
    all_vars_0 = dict()
    block_0 = Block()
    result = block_0.filter_tagged_tasks(all_vars_0)


# Generated at 2022-06-25 04:54:08.598866
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    tuple_0 = ()
    tuple_1 = (u'c', u'd', u'e')
    block_0 = Block()
    block_0._attributes[u'always'] = tuple_1
    block_0._attributes[u'block'] = tuple_0
    block_0._attributes[u'catch'] = tuple_1
    block_0._attributes[u'rescue'] = tuple_0
    block_0._attributes[u'vars'] = u'd'
    block_1 = Block()
    block_2 = Block()
    block_2._attributes[u'name'] = u'False'
    block_2._parent = block_1
    block_1._attributes[u'always'] = tuple_1

# Generated at 2022-06-25 04:54:19.055444
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    tuple_0 = ('abcd',)
    block_0 = Block()
    task_0 = block_0.create_task(block=tuple_0)

    # test for abcd task is added to the block
    assert task_0.action == 'abcd'
    assert task_0.block == tuple_0

    # test for { 'block' : ['abcd'] } is added to the block
    tuple_1 = ('abcd',)
    block_1 = Block()
    task_1 = block_1.create_task(block=tuple_1)
    assert task_1.action == 'abcd'
    assert task_1.block == tuple_1

    # test for { 'block' : ['abcd'] } is added to the block

# Generated at 2022-06-25 04:54:22.418350
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():

    block = Block()
    assert block.get_dep_chain() == None

    block = Block(dep_chain=["str"])
    assert block.get_dep_chain() == ["str"]


# Generated at 2022-06-25 04:54:23.387265
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    test_case_0()


# Generated at 2022-06-25 04:54:24.370237
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    test_case_0()


# Generated at 2022-06-25 04:54:28.242512
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    set_0 = set()
    str_0 = "^f1ah:}_7,zP"
    tuple_0 = (str_0, )
    block_0 = Block()
    block_0._dep_chain = tuple_0
    result = block_0.get_dep_chain()
    result_set = set(result)
    assert result_set == set_0


# Generated at 2022-06-25 04:54:39.205860
# Unit test for method copy of class Block
def test_Block_copy():
    # Test that Block.copy() returns a Block object
    tuple_0 = ()
    tuple_1 = ()
    block_1 = Block()
    block_0 = block_1.copy()
    assert isinstance(block_0, Block)
    # Test that Block.copy() returns the correct Block object
    tuple_2 = ()
    tuple_4 = ()
    block_4 = Block()
    parent_0 = Block()
    role_0 = Role()
    block_4._play = None
    data_0 = dict()
    data_1 = dict()
    data_1['role'] = role_0
    data_0['parent'] = data_1
    data_0['parent_type'] = 'Block'
    block_4.deserialize(data_0)
    block_4._parent = parent_0


# Generated at 2022-06-25 04:55:04.616021
# Unit test for method copy of class Block
def test_Block_copy():
    tuple_0 = ()
    tuple_1 = (1, 2)
    block_0 = Block()
    block_1 = Block()
    block_2 = Block()
    block_0.rescue = Block()
    block_1.block = block_2
    block_0.block = block_1
    block_1.block = Block()
    block_0.block = tuple_1
    block_0.block = block_1
    tuple_0 = ()
    block_0 = Block()


# Generated at 2022-06-25 04:55:06.550750
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    tuple_0 = ()
    all_vars_0 = dict()
    block_0 = Block()
    filtered_block_0 = block_0.filter_tagged_tasks(all_vars_0)


# Generated at 2022-06-25 04:55:11.846138
# Unit test for method filter_tagged_tasks of class Block

# Generated at 2022-06-25 04:55:13.374205
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0.copy(exclude_tasks = bool())
    block_0.copy()


# Generated at 2022-06-25 04:55:15.470635
# Unit test for method is_block of class Block
def test_Block_is_block():
    # Example:
    tuple_0 = ()
    block_0 = Block()
    # Arguments of this method are: (1) data
    data = tuple_0
    block_0.is_block(data)


# Generated at 2022-06-25 04:55:17.263969
# Unit test for method copy of class Block
def test_Block_copy():
    tuple_0 = ()
    block_0 = Block()
    block_1 = block_0.copy()
    assert block_1 is not None


# Generated at 2022-06-25 04:55:20.363958
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    tuple_0 = ('key_0', 'key_1', 'key_2')
    block_0 = Block(tuple_0)
    block_0.all_parents_static()


# Generated at 2022-06-25 04:55:22.293218
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    tuple_0 = ()
    block_0 = Block()
    assert block_0.has_tasks() == False


# Generated at 2022-06-25 04:55:27.981044
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    test_case_0()
    test_Block_filter_tagged_tasks_0()
    test_Block_filter_tagged_tasks_1()
    test_Block_filter_tagged_tasks_2()


# Generated at 2022-06-25 04:55:34.858634
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    assert block_0.get_dep_chain() is None
    block_0._dep_chain = []
    assert block_0.get_dep_chain() == []
    block_0._dep_chain = None
    assert block_0.get_dep_chain() is None



# Generated at 2022-06-25 04:56:02.319709
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    '''
    Unit test for method deserialize of class Block
    '''
    dict_0 = dict()
    dict_0['role'] = dict()
    dict_1 = dict()
    dict_1['role'] = dict()
    dict_1['parent'] = dict()
    dict_0['parent'] = dict_1
    dict_0['parent_type'] = "TaskInclude"
    assert False


# Generated at 2022-06-25 04:56:04.774088
# Unit test for method copy of class Block
def test_Block_copy():
    tuple_0 = ()
    block_0 = Block()
    assert tuple_0 is None
    assert block_0 is not None


# Generated at 2022-06-25 04:56:06.329834
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    tuple_0 = ()
    block_0 = Block(tuple_0)
    deserialized = block_0.deserialize(tuple_0)


# Generated at 2022-06-25 04:56:12.557527
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = Block()
    all_vars = dict()
    result = block.filter_tagged_tasks(all_vars)
    assert isinstance(result, Block)


# Generated at 2022-06-25 04:56:13.267251
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    test_case_0()


# Generated at 2022-06-25 04:56:22.157042
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # set up test data
    tuple_0 = ()
    block_0 = Block(tuple_0)
    block_0._parent = "obj1"
    block_0._parent._parent = "obj2"
    block_0._parent._parent._parent = "obj3"
    block_0._parent._parent._parent.statically_loaded = bool_0 = bool()

    # test the method
    if (not block_0.all_parents_static()):
        raise RuntimeError('Test case 0 failed')

test_case_0()
test_Block_all_parents_static()

# Generated at 2022-06-25 04:56:26.428774
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    all_vars = dict()
    block_0 = Block()
    block_1 = block_0.filter_tagged_tasks(all_vars)


# Generated at 2022-06-25 04:56:35.249996
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    tuple_0 = ()
    block_0 = Block(data = None, play = None, parent_block = None, role = None, task_include = None, use_handlers = False, implicit = False)
    block_1 = Block(data = None, implicit = False)
    block_2 = Block(data = None, implicit = True)
    block_3 = Block(data = None, implicit = True)
    block_4 = block_3.preprocess_data(block_2)
    # Verify if attribute parent is of type Block
    assert isinstance(block_4.parent, Block)
    # Verify if attribute name is of type str
    assert isinstance(block_4.name, str)
    # Verify if attribute only_if is of type bool
    assert isinstance(block_4.only_if, bool)
    # Verify

# Generated at 2022-06-25 04:56:46.156292
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    tuple_0 = ()
    block_0 = Block()

    # All parents are static
    test_obj = {
        "block": [
            {
                "block": [
                    {
                        "block": [
                            {
                                "block": [
                                    {
                                        "block": [
                                            {
                                                "block": [],
                                                "name": "Test parent play hosts"
                                            }
                                        ],
                                        "name": "Test parent play tasks"
                                    }
                                ],
                                "name": "Test parent play pre_tasks"
                            }
                        ],
                        "name": "Test parent play roles"
                    }
                ],
                "name": "Test parent play tasks"
            }
        ],
        "name": "Test parent play"
    }

# Generated at 2022-06-25 04:56:48.245214
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    test_case_0()


# Generated at 2022-06-25 04:57:13.354548
# Unit test for method copy of class Block
def test_Block_copy():
    tuple_0 = ()
    block_0 = Block()
    block_0.copy(exclude_parent = True, exclude_tasks = True)
    block_0.copy(exclude_parent = True)
    block_0.copy(exclude_tasks = True)
    block_0.copy()


# Generated at 2022-06-25 04:57:18.792355
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    tuple_0 = ()
    block_0 = Block()
    block_0.block = tuple_0
    assert block_0.has_tasks() == False
    assert block_0._attributes['block'] == tuple_0


# Generated at 2022-06-25 04:57:24.676407
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    tuple_0 = ()
    block_0 = Block()
    assert block_0.deserialize(tuple_0) == None
    assert block_0._role == None
    assert block_0._parent == None
    assert block_0._dep_chain == None


# Generated at 2022-06-25 04:57:32.721419
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    task_include_0 = TaskInclude()
    try:
        task_include_0.get_first_parent_include()
    except AttributeError:
        pass
    block_0._parent = task_include_0
    assert block_0.all_parents_static()
    task_include_0.statically_loaded = True
    assert block_0.all_parents_static()
    task_include_0.statically_loaded = False
    assert not block_0.all_parents_static()



# Generated at 2022-06-25 04:57:36.273678
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert not block.has_tasks()
    block.block = [Task()]
    assert block.has_tasks()


# Generated at 2022-06-25 04:57:38.621839
# Unit test for method is_block of class Block
def test_Block_is_block():
    tuple_0 = ()
    block_0 = Block()


# Generated at 2022-06-25 04:57:43.218889
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Declare test environment variables
    tuple_0 = ()
    block_0 = Block()
    dict_0 = {}
    str_0 = block_0.filter_tagged_tasks(tuple_0)

# Generated at 2022-06-25 04:57:52.455712
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    from ansible.parsing.dataloader import DataLoader
    tuple_0 = ()
    block_0 = Block(loader = DataLoader())
    block_1 = Block(loader = DataLoader())
    block_2 = Block(loader = DataLoader())
    block_3 = Block(loader = DataLoader())
    block_4 = Block(loader = DataLoader())
    block_5 = Block(loader = DataLoader())
    block_6 = Block(loader = DataLoader())
    bool_0 = True
    if bool_0:
        block_7 = Block(loader = DataLoader())
        block_8 = Block(loader = DataLoader())
    task_0 = Task(loader = DataLoader())
    task_1 = Task(loader = DataLoader())
    task_2 = Task(loader = DataLoader())

# Generated at 2022-06-25 04:57:53.359806
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    test_case_0()


# Generated at 2022-06-25 04:58:03.641239
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    tuple_0 = ()
    block_0 = Block()
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()


# Generated at 2022-06-25 04:58:43.052700
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    tuple_0 = ()
    block_0 = Block()
    block_0.filter_tagged_tasks(tuple_0)


# Generated at 2022-06-25 04:58:45.801722
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    tuple_0 = ()
    block_0 = Block(loader=None)
    block_0.filter_tagged_tasks()


# Generated at 2022-06-25 04:58:52.997112
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    tuple_0 = (1, 2, 3)
    dictionary_0 = {
        'a': 1,
        'b': 2,
        'c': 3,
    }

# Generated at 2022-06-25 04:58:54.506863
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    tuple_0 = ()
    block_0 = Block()
    assert block_0.has_tasks() == False


# Generated at 2022-06-25 04:59:05.258151
# Unit test for method copy of class Block
def test_Block_copy():
    block_1 = Block()
    block_1.always = [None] * 6 # list
    block_1.block = [None] * 8 # list
    block_1.notify = [None] * 3 # list
    block_1.rescue = [None] * 6 # list
    block_1.when = [None] * 6 # list
    block_1.meta = {'meta_0': block_1, 'meta_1': block_1.always, 'meta_2': 'str_2', 'meta_3': block_1.block, 'meta_4': 'str_4', 'meta_5': 'str_5', 'meta_6': 'str_6', 'meta_7': block_1.notify, 'meta_8': 'str_8', 'meta_9': block_1.rescue} #

# Generated at 2022-06-25 04:59:10.291545
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Get ansible.playbook.block.Block class
    tuple_0 = ()
    block_0 = Block()
    # Calling 'get_dep_chain' method of Block class
    result_0 = block_0.get_dep_chain()
    assert result_0 is not None


# Generated at 2022-06-25 04:59:19.054204
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    block_1 = Block()
    block_2 = Block()
    block_3 = Block()
    block_4 = Block()
    block_5 = Block()
    block_6 = Block()
    block_7 = Block()
    block_8 = Block()
    block_9 = Block()
    block_10 = Block()
    block_11 = Block()
    block_12 = Block()
    block_13 = Block()
    block_14 = Block()
    block_15 = Block()
    block_16 = Block()
    block_17 = Block()
    block_18 = Block()
    block_19 = Block()
    block_20 = Block()
    block_21 = Block()
    block_22 = Block()
    block_23 = Block()
    block_24 = Block()

# Generated at 2022-06-25 04:59:20.598866
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0.copy(exclude_parent=True, exclude_tasks=True)


# Generated at 2022-06-25 04:59:25.800577
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    '''Block has_tasks'''
    block_0 = Block()
    block_0.rescue = [Task()]
    block_1 = copy.deepcopy(block_0)
    assert(block_1.has_tasks() == True)


# Generated at 2022-06-25 04:59:29.620471
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    try:
        tuple_1 = ()
        block_1 = Block()
        block_1.all_parents_static()
    except Exception:
        pass


# Generated at 2022-06-25 04:59:55.071201
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    name = 'block_0'
    block_0 = Block(name=name)
    playbook_0 = Playbook(name=name)

    all_vars = dict()
    result = block_0.filter_tagged_tasks(all_vars)
    assert result

    name = 'block_1'
    block_1 = Block(name=name)
    task_0 = Task(name=name)
    block_1.block.append(task_0)
    task_1 = Task(name=name)
    task_1.always = None
    block_1.always = [ task_1 ]
    block_1._play = playbook_0
    playbook_0.tasks.append(block_1)

    all_vars = dict()

# Generated at 2022-06-25 05:00:03.076019
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Tests for class Block - has_tasks
    tuple_0 = ()
    block_0 = Block()
    assert block_0.has_tasks() == False
    # Test with another class
    dict_0 = dict()
    block_1 = Block(implicit=False)
    assert block_1.has_tasks() == False
    # Test with different variables
    block_0 = Block(None, None, None, None, False, False)
    assert block_0.has_tasks() == False


# Generated at 2022-06-25 05:00:13.375764
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    tuple_0 = ()
    block_0 = Block()
    block_0.block = [block_0]
    boolean_0 = block_0.has_tasks()
    block_1 = block_0.filter_tagged_tasks(tuple_0)
    # Verify whether the function _get_parent_attribute of block_1 produces the expected value.
    assert block_1.action == 'meta'
    # Verify whether the function _get_parent_attribute of block_1 produces the expected value.
    assert block_1.block == []
    # Verify whether the function _get_parent_attribute of block_1 produces the expected value.
    assert block_1.delegate_to == '127.0.0.1'
    # Verify whether the function _get_parent_attribute of block_1 produces the expected value.

# Generated at 2022-06-25 05:00:16.136711
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    tuple_0 = ()
    block_0 = Block()
    assert block_0.has_tasks() == False



# Generated at 2022-06-25 05:00:21.224680
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Setup input param
    block_0 = Block()
    block_0._play_context = PlayContext()
    all_vars = dict()

    # Execute method
    filter_tagged_tasks_0 = block_0.filter_tagged_tasks(all_vars)

    # Return test result
    return filter_tagged_tasks_0 is not None



# Generated at 2022-06-25 05:00:29.146010
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Source data for this test
    tuple_0 = ('tag_name_0', ('tag_name_1', ('tag_name_2', ('tag_name_3', ()))))

    # Constructor test
    block_0 = Block()

    # Method test
    assert block_0.has_tasks() == False

    # Constructor test
    block_1 = Block()

    # Method test
    assert block_1.has_tasks() == False

    # Constructor test
    block_2 = Block()

    # Method test
    assert block_2.has_tasks() == False

    # Constructor test
    block_3 = Block()

    # Method test
    assert block_3.has_tasks() == False

    # Constructor test
    block_4 = Block()

    # Method test
    assert block_

# Generated at 2022-06-25 05:00:35.465129
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():

    tuple_0 = ()
    block_0 = Block()
    block_0.dep_chain = tuple_0
    result = block_0.get_dep_chain()
    assert result == tuple_0
    block_1 = Block()
    block_1.dep_chain = tuple_0
    result = block_1.get_dep_chain()
    assert result != tuple_0


# Generated at 2022-06-25 05:00:39.152756
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # test_vars = dict()
    block_0 = Block()
    block_1 = block_0.filter_tagged_tasks(test_vars)
    # print(block_1)
    print(block_1)



# Generated at 2022-06-25 05:00:48.836660
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    tuple_0 = ()
    block_0 = Block(block=tuple_0)
    block_0.block = block_0.filter_tagged_tasks(None)
    block_0.rescue = block_0.filter_tagged_tasks(None)
    block_0.always = block_0.filter_tagged_tasks(None)
    block_0.block = block_0.filter_tagged_tasks(None)
    block_0.rescue = block_0.filter_tagged_tasks(None)
    block_0.always = block_0.filter_tagged_tasks(None)
    block_0.block = block_0.filter_tagged_tasks(None)

# Generated at 2022-06-25 05:00:54.733388
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    tuple_0 = ()
    block_0 = Block()
    block_0.set_loader(tuple_0)


# Generated at 2022-06-25 05:01:11.714266
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    pass

# Generated at 2022-06-25 05:01:13.372677
# Unit test for method copy of class Block
def test_Block_copy():
    tuple_0 = ()
    block_0 = Block()
    result = block_0.copy()


# Generated at 2022-06-25 05:01:21.994264
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    tuple_0 = ()
    block_0 = Block()
    block_0.block = tuple_0
    block_0.rescue = tuple_0
    block_0.always = tuple_0
    assert not block_0.has_tasks()
    block_1 = Block()
    block_1.block = tuple_0
    block_1.rescue = tuple_0
    block_1.always = (1, 2, 3)
    assert block_1.has_tasks()
    block_2 = Block()
    block_2.block = tuple_0
    block_2.rescue = (1, 2, 3)
    block_2.always = tuple_0
    assert block_2.has_tasks()
    block_3 = Block()

# Generated at 2022-06-25 05:01:24.603563
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    test = Block()
    assert test.deserialize(None) == None, 'Test for method deserialize of class Block: Failed'


# Generated at 2022-06-25 05:01:26.735818
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    tuple_0 = ()
    block_0 = Block()
    block_0.deserialize(tuple_0)


# Generated at 2022-06-25 05:01:33.456685
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    
    block_0 = Block()
    block_0._parent = None
    value = block_0.get_dep_chain()
    assert value is None
    
    block_0 = Block()
    block_0._parent = None
    value = block_0.get_dep_chain()
    assert value is None


# Generated at 2022-06-25 05:01:43.167759
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    tuple_0 = ()
    # invocation: get_first_parent_include()
    # expected result: tuple_0
    block_0 = Block()
    result_0 = block_0.get_first_parent_include()
    if tuple_0 != result_0:
        raise AssertionError("result: {} != expected: {}".format(result_0, tuple_0))
    tuple_1 = ()
    # invocation: get_first_parent_include()
    # expected result: tuple_1

# Generated at 2022-06-25 05:01:48.132762
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    result = block_0.all_parents_static()
    assert isinstance(result, six.boolean_types) is True


# Generated at 2022-06-25 05:01:53.134112
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    parent = Block()
    parents = {'parent': parent}
    obj = Block()
    obj.deserialize({'parent': parent, 'parent_type': 'Block'})
    obj.deserialize(parents)
    obj.deserialize({'parent': parent, 'parent_type': 'Block'})


# Generated at 2022-06-25 05:01:58.339277
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    tuple_0 = ()
    block_0 = Block()
    block_0.filter_tagged_tasks(tuple_0)


# Generated at 2022-06-25 05:02:18.758769
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    tuple_0 = ()
    block_0 = Block()
    block_1 = block_0.get_dep_chain()


# Generated at 2022-06-25 05:02:20.671317
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    (tuple_0, block_0) = test_case_0()
    block_0.set_loader(tuple_0)


# Generated at 2022-06-25 05:02:23.977807
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # TODO: Implement test
    tuple_0 = ()
    block_0 = Block()
    block_0.deserialize(tuple_0)


# Generated at 2022-06-25 05:02:30.639927
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    tuple_0 = ()
    block_0 = Block()
    # Call method deserialize of class Block
    rv = block_0.deserialize(tuple_0)

# Generated at 2022-06-25 05:02:32.782373
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    tuple_0 = ()
    block_0 = Block()
    assert block_0.get_dep_chain() == None


# Generated at 2022-06-25 05:02:35.638414
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    data_0 = dict()
    block_0.deserialize(data_0)
    assert block_0._play == None
    assert block_0._use_handlers == False
    assert block_0._implicit == False


# Generated at 2022-06-25 05:02:40.511850
# Unit test for method copy of class Block
def test_Block_copy():
    tuple_0 = ()
    block_0 = Block()
    boolean_0 = block_0.copy()
    boolean_1 = block_0.copy()
    boolean_2 = block_0.copy()
    boolean_3 = block_0.copy()
    # Test whether the results of the method copy of class Block match
    # with the expected value.
    assert boolean_0 == boolean_1
    assert not boolean_1 == boolean_2
    assert not boolean_2 == boolean_3


# Generated at 2022-06-25 05:02:42.557880
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    tuple_0 = ()
    block_0 = Block()
    result_0 = block_0.has_tasks()
    assert_false(result_0)


# Generated at 2022-06-25 05:02:48.142273
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    tuple_0 = ()
    block_0 = Block()
    dict_0 = {}
    block_1 = block_0.filter_tagged_tasks(dict_0)
