

# Generated at 2022-06-25 04:54:01.606827
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():

    include_1 = TaskInclude()
    include_1._parent = include_1
    block_2 = Block()
    block_2._play = Play()
    task_3 = Task()
    task_3._attributes['tags'] = ['tag_4', 'tag_5']
    task_3._parent = block_2
    task_6 = Task()
    task_6._attributes['tags'] = ['tag_7', 'tag_8']
    task_6._parent = block_2
    task_9 = Task()
    task_9._attributes['tags'] = ['tag_10', 'tag_11']
    task_9._parent = block_2
    task_12 = Task()
    task_12._attributes['tags'] = ['tag_13', 'tag_14']

# Generated at 2022-06-25 04:54:03.291350
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    assert isinstance(block_0.copy(), Block)


# Generated at 2022-06-25 04:54:09.948180
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    '''
    Unit test of method filter_tagged_tasks of class Block.
    This method is a recursive method. If recursive method has no bugs,
    its iterative method must not have bugs.
    '''
    play_0 = Play()
    play_0._variable_manager = VariableManager()
    block_0 = Block(play=play_0)
    task_0_0 = Task()
    task_0_0._load_name('test_task_0_0')
    task_0_0._play = play_0
    task_0_1 = Task()
    task_0_1._load_name('test_task_0_1')
    task_0_1._play = play_0
    task_0_2 = Task()
    task_0_2._play = play_0
    task_

# Generated at 2022-06-25 04:54:20.259888
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    """Unittest for filter_tagged_tasks() method of Block class."""
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    block_0 = Block()
    task_0 = Task()
    task_0._role = None
    task_1 = Task()
    task_1._role = None
    task_2 = Task()
    task_2._role = None
    task_3 = Task()
    task_3._role = None

    # test 0
    block_1 = block_0.filter_tagged_tasks(PlayContext())

    # test 1
    task_0.only_if = [{"test": "foo"}]
    block_0.block = [{"include": "foo.yml", "meta": task_0}]


# Generated at 2022-06-25 04:54:28.481940
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block(implicit=False)
    block_0._attributes = dict()
    block_0._attributes['block'] = list()
    block_0._attributes['block'].append(Task())
    block_0._attributes['rescue'] = list()
    block_0._attributes['always'] = list()
    block_0._parent = None
    block_0._role = None
    block_0._dep_chain = None
    block_0._implicit = False
    block_0._variable_manager = None
    block_0._loader = None
    block_0._play = None
    block_0._play_context = None
    block_0._task_include = None
    block_0._use_handlers = None
    block_0.block = list()
    block_0

# Generated at 2022-06-25 04:54:32.324308
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block.load({})
    block_0.set_loader(None)
    assert block_0._loader is None


# Generated at 2022-06-25 04:54:39.241791
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()
    block_2 = block_1.copy()
    assert block_2 is not block_1


# Generated at 2022-06-25 04:54:49.543078
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()

# Generated at 2022-06-25 04:54:51.719737
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    block_0.statically_loaded = True
    block_result = block_0.all_parents_static()
    assert block_result == True


# Generated at 2022-06-25 04:54:58.331666
# Unit test for method set_loader of class Block
def test_Block_set_loader():

    ansible_path = 'ansible_path'

    class test_parent_class(object):
        def __init__(self):
            self.loader = 'loader'
            self.name = 'name'
            self.path = ansible_path
            self.statically_loaded = 'statically_loaded'

    test_parent_obj = test_parent_class()

    class test_role_class(object):
        def __init__(self):
            self.loader = 'loader'
            self.name = 'name'
            self.path = ansible_path
            self.statically_loaded = 'statically_loaded'

    test_role_obj = test_role_class()

    class test_play_class(object):
        def __init__(self):
            self.loader = 'loader'

# Generated at 2022-06-25 04:55:43.199793
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    try:
        test_case_0()
    except:
        print("Exception in testcase 0")
        raise


# Generated at 2022-06-25 04:55:54.085741
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    '''
    Test case for has_tasks() method of class Block.
    It tests the functionality of method has_tasks of class Block.
    '''
    block_has_tasks = Block()
    # add a task to block.block
    block_has_tasks.block.append(dict(action='test_action'))
    # add a task to block.rescue
    block_has_tasks.rescue.append(dict(action='test_action'))
    # add a task to block.always
    block_has_tasks.always.append(dict(action='test_action'))
    assert block_has_tasks.has_tasks() == True



# Generated at 2022-06-25 04:56:01.746064
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook import include_role
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    block_0 = Block()
    block_0.dep_chain = 'test_value'
    dep_chain = block_0.get_dep_chain()
    assert dep_chain == 'test_value'

# Generated at 2022-06-25 04:56:04.313064
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    data = dict()
    block.deserialize(data)
    assert block is not None


# Generated at 2022-06-25 04:56:11.483312
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    loader_0 = DictDataLoader({})
    block_0.set_loader(loader_0)
    block_1 = Block()
    loader_1 = DictDataLoader({})
    block_1.set_loader(loader_1)
    block_2 = Block()
    loader_2 = DictDataLoader({})
    block_2.set_loader(loader_2)
    block_3 = Block()
    loader_3 = DictDataLoader({})
    block_3.set_loader(loader_3)
    block_4 = Block()
    loader_4 = DictDataLoader({})
    block_4.set_loader(loader_4)
    block_5 = Block()
    loader_5 = DictDataLoader({})

# Generated at 2022-06-25 04:56:17.564570
# Unit test for method set_loader of class Block
def test_Block_set_loader():

    # Ensure expected exception was thrown
    block_0 = Block()
    try:
        block_0.set_loader(None)
    except AnsibleError as e:
        assert e.message == 'loader argument is not an instance of BaseLoader'

    # Ensure expected exception was thrown
    block_1 = Block()
    try:
        block_1.set_loader(None)
    except AnsibleError as e:
        assert e.message == 'loader argument is not an instance of BaseLoader'

    # Ensure expected exception was thrown
    block_2 = Block()
    try:
        block_2.set_loader(None)
    except AnsibleError as e:
        assert e.message == 'loader argument is not an instance of BaseLoader'

    # Ensure expected exception was thrown
    block_3 = Block()

# Generated at 2022-06-25 04:56:24.112621
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():

    # set up variables
    variable = 1
    block_0 = Block()
    block_0.vars = variable

    # call the method
    # test Block.filter_tagged_tasks()
    block_0.filter_tagged_tasks()


# Generated at 2022-06-25 04:56:25.461588
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_1 = Block()
    block_0.deserialize(block_1)


# Generated at 2022-06-25 04:56:30.428927
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    testcase = {
        (True, True): True,
        (True, False): False,
        (False, True): False,
        (False, False): False,
    }

    # create a block which is static, but has a static and a non-static parent
    block_0 = Block()
    block_0.statically_loaded = True
    block_0._parent = Block()
    block_0._parent.statically_loaded = True
    block_0._parent._parent = Block()
    block_0._parent._parent.statically_loaded = False

    assert testcase[(block_0.statically_loaded, block_0._parent.statically_loaded, block_0._parent._parent.statically_loaded)] == block_0.all_parents_static()



# Generated at 2022-06-25 04:56:35.056249
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    value = block_0.copy()


# Generated at 2022-06-25 04:57:16.858321
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    assert block_0.get_first_parent_include() == None


# Generated at 2022-06-25 04:57:22.103672
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    block_0._attributes = dict()
    block_0._valid_attrs = dict()
    block_0._parent = []
    block_0._play = []
    block_0._dep_chain = []
    block_0._role = []
    block_0._loader = C.DataLoader()
    block_0._ds = dict()
    block_0._use_handlers = None
    block_0.block = []
    block_0.rescue = []
    block_0.always = []
    all_vars = {}
    filtered_block_0 = block_0.filter_tagged_tasks(all_vars)
    return filtered_block_0


# Generated at 2022-06-25 04:57:23.508422
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    assert False



# Generated at 2022-06-25 04:57:30.630028
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    #
    # Create an empty Block and no tags so all tasks should be in the new Block
    block_1 = Block()
    block_1.block = [ 'task_1', 'task_2', 'task_3' ]
    block_1.rescue = [ 'task_4', 'task_5', 'task_6' ]
    block_1.always = [ 'task_7', 'task_8', 'task_9' ]
    filtered_block_1 = block_1.filter_tagged_tasks( all_vars=dict() )
    assert filtered_block_1.block == block_1.block
    assert filtered_block_1.rescue == block_1.rescue
    assert filtered_block_1.always == block_1.always
    #
    # Create a Block with a skip_tags and no

# Generated at 2022-06-25 04:57:35.237106
# Unit test for method copy of class Block
def test_Block_copy():
    block_1 = Block()
    block_2 = Block()
    # Does a shallow copy of the block, by default
    block_2 = block_1.copy()

# Generated at 2022-06-25 04:57:38.019999
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_1 = block_0.deserialize()


# Generated at 2022-06-25 04:57:45.797070
# Unit test for method is_block of class Block
def test_Block_is_block():
    '''
    unit test for method is_block of class Block
    '''

# Generated at 2022-06-25 04:57:49.620811
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    loader = DataLoader()
    block_0.set_loader(loader)


# Generated at 2022-06-25 04:57:56.286315
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_2 = Block()
    block_2.set_loader(loader=None)

    class FakeLoader(object):
        def __init__(self):
            self.path_exists = lambda x: False
            self.path_finder = None
            self.is_text_file = lambda x: True

    block_3 = Block()
    block_3.set_loader(loader=FakeLoader())
    block_3.set_loader(loader=FakeLoader())


# Generated at 2022-06-25 04:57:59.264487
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()

    assert block_0.name == block_1.name
    assert block_0._parent == block_1._parent
    assert block_0._role == block_1._role


# Generated at 2022-06-25 04:58:21.985462
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    block_0.block = [ActionModule({u'action': u'ping'})]
    all_vars = dict()
    actual = block_0.filter_tagged_tasks(all_vars)


# Generated at 2022-06-25 04:58:22.907161
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    pass

# vim:syntax=python:

# Generated at 2022-06-25 04:58:24.776754
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    assert not block_0.has_tasks()


# Generated at 2022-06-25 04:58:33.939887
# Unit test for method copy of class Block
def test_Block_copy():

    # Data structure setup
    block_0 = Block()
    block_0._parent = None
    block_0._loader = None
    block_0._task = None
    block_0._play = None
    block_0._dep_chain = None
    block_0._role = None
    block_0._always = None
    block_0._block = None
    block_0._rescue = None
    block_0._when = None
    block_1 = Block()
    block_1._parent = None
    block_1._loader = None
    block_1._task = None
    block_1._play = None
    block_1._dep_chain = block_0._dep_chain
    block_1._role = None
    block_1._always = None
    block_1._block = None
    block_1

# Generated at 2022-06-25 04:58:36.571755
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    try:
        block_0.all_parents_static()
    except NotImplementedError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 04:58:43.135364
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Create an instance of Block
    block_1 = Block()
    # Check produced dep_chain
    block_1_dep_chain = block_1.get_dep_chain()
    assert block_1_dep_chain == None
    # Create an instance of Block
    block_2 = Block()
    # Create an instance of Role
    role_0 = Role()
    # Create an instance of Task
    task_0 = Task()
    # Create an instance of Task
    task_1 = Task()
    # Create an instance of Task
    task_2 = Task()
    # Create an instance of Task
    task_3 = Task()
    # Create an instance of Task
    task_4 = Task()
    # Create an instance of Task
    task_5 = Task()
    # Create an instance of Task
    task_6 = Task()

# Generated at 2022-06-25 04:58:48.726955
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = Block()
    block.block = [ 'task 1', 'task 2' ]
    block.rescue = [ 'task 3' ]
    block.always = [ 'task 4' ]
    all_vars = {}
    filtered_block = block.filter_tagged_tasks(all_vars)
    assert ( filtered_block is None )


# Generated at 2022-06-25 04:58:50.372929
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize()


# Generated at 2022-06-25 04:59:01.542783
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()
    assert block_0 is not block_1
    assert block_0 == block_1
    assert block_0._play is None
    assert block_0._use_handlers
    assert block_0._parent is None
    assert block_0._dep_chain is None
    assert block_0._iterator is None
    assert block_0._role is None
    assert block_0._attributes == block_1._attributes
    assert block_0._ds is None
    assert block_0._loader is None
    assert block_0._variable_manager is None
    assert block_0._implicit is False
    assert block_0._always_run is False
    assert block_0._any_errors_fatal is False
    assert block_0._force_hand

# Generated at 2022-06-25 04:59:12.682500
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    def _evaluate_tasks(tasks, all_vars):
        new_tasks = []
        for task in tasks:
            if isinstance(task, Block):
                filtered_block = task.filter_tagged_tasks(all_vars)
                if filtered_block.has_tasks():
                    new_tasks.append(filtered_block)

# Generated at 2022-06-25 04:59:41.132358
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    import sys
    import json

    with open('playbook_test_unittest_file_filter_tagged_tasks.yml', 'r') as f:
        ds = f.read()
        ds = json.loads(ds)
    p = Play().load(ds, variable_manager=VariableManager(), loader=DictDataLoader())

    all_vars = dict()
    filtered_block = p.filter_tagged_tasks(all_vars)
    return filtered_block

if __name__ == "__main__":
	rc = test_Block_filter_tagged_tasks()

# Generated at 2022-06-25 04:59:51.137378
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0_ds = block_0.deserialize({'when': '1', 'register': {}, 'delegate_to': '127.0.0.1', 'until': [], 'block': [], 'rescue': [], 'always': [], 'changed_when': '1', 'any_errors_fatal': [], 'failed_when': '1', 'ignore_errors': [], 'remote_user': '127.0.0.1', 'sudo': False, 'sudo_user': '127.0.0.1', 'tags': []})
    assert block_0.__dict__ == block_0_ds


# Generated at 2022-06-25 05:00:01.114277
# Unit test for method copy of class Block
def test_Block_copy():
    global block_0

    block_1 = block_0.copy()

    assert not block_0.__eq__(block_1)
    assert block_0.__class__ == block_1.__class__
    #assert block_0.__dict__ == block_1.__dict__
    #assert block_0.__doc__ == block_1.__doc__
    assert block_0._attributes == block_1._attributes
    #assert block_0._ds == block_1._ds
    #assert block_0._loader == block_1._loader
    assert block_0._play == block_1._play
    assert block_0._role == block_1._role
    assert block_0._task_include == block_1._task_include
    assert block_0._use_handlers == block_1._use_

# Generated at 2022-06-25 05:00:03.700918
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    my_block = Block()
    my_block.deserialize(None)


# Generated at 2022-06-25 05:00:10.255408
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block(block=[Task()])
    assert block_0.has_tasks() == True
    block_1 = Block(block=[Task(), Task()])
    assert block_1.has_tasks() == True
    block_2 = Block(rescue=[Task()])
    assert block_2.has_tasks() == True
    block_3 = Block(always=[Task()])
    assert block_3.has_tasks() == True
    block_4 = Block(block=[Task()], rescue=[Task()])
    assert block_4.has_tasks() == True
    block_5 = Block(rescue=[Task()], always=[Task()])
    assert block_5.has_tasks() == True
    block_6 = Block(block=[Task()], always=[Task()])
    assert block_6

# Generated at 2022-06-25 05:00:20.805496
# Unit test for method filter_tagged_tasks of class Block

# Generated at 2022-06-25 05:00:22.850920
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    print('')
    print('<test_Block_filter_tagged_tasks>')
    print('')


# Generated at 2022-06-25 05:00:24.550854
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    block_0.set_loader(None)


# Generated at 2022-06-25 05:00:29.174414
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    import ansible.playbook.block
    import ansible.playbook.task_include
    import ansible.playbook.task

    task = ansible.playbook.task.Task()
    task_include = ansible.playbook.task_include.TaskInclude()
    block = ansible.playbook.block.Block()

    task_include.block = block
    task.block = task_include

    assert task.block.get_first_parent_include() is task_include
    return True



# Generated at 2022-06-25 05:00:30.691633
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    assert block_0.copy() == {}


# Generated at 2022-06-25 05:01:03.267880
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block(block=[], rescue=[], always=[])
    assert block.has_tasks() == False, "1: has_tasks() returned true unexpectedly"
    block = Block(block=[], rescue=[], always=[], play=Play(), role=Role(), parent_block=Block())
    assert block.has_tasks() == False, "2: has_tasks() returned true unexpectedly"
    block = Block(block=[Task(name="test_task")], rescue=[], always=[])
    assert block.has_tasks() == True, "3: has_tasks() returned false unexpectedly"
    block = Block(block=[Task(name="test_task")], rescue=[], always=[], play=Play(), role=Role(), parent_block=Block())

# Generated at 2022-06-25 05:01:08.481603
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    result = block_0.copy()
    assert isinstance(result, Block)


if __name__ == "__main__":
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-25 05:01:10.095360
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()

# Generated at 2022-06-25 05:01:20.036944
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_1 = Block()

# Generated at 2022-06-25 05:01:22.241154
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block_0 = Block()
    assert block_0.preprocess_data("key") == {'block': ['key']}, 'Expected value for block_0.preprocess_data("key") is {\'block\': [\'key\']}'


# Generated at 2022-06-25 05:01:29.635562
# Unit test for method deserialize of class Block
def test_Block_deserialize():
        block_0 = Block()
        data = {}
        data['block'] = ['task_1', 'task_2']
        data['block'][0] = {}
        data['block'][0]['action'] = 'ping'
        data['block'][0]['async'] = 0
        data['block'][0]['async_poll_interval'] = 1.0
        data['block'][0]['attributes'] = {}
        data['block'][0]['attributes_string'] = '<TaskAttribute Node=None, Context=None, Parent=None>'
        data['block'][0]['delegate_to'] = 'localhost'
        data['block'][0]['delegate_facts'] = False
        data['block'][0]['environment'] = {}

# Generated at 2022-06-25 05:01:39.786608
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.conditional import Conditional
    from ansible.template import Templar
    
    block = Block()
    block_rescue = Block()
    block_always = Block()
    task_1 = Task()
    task_1_1 = Task()
    task_2 = Task()
    task_2_1 = Task()
    task_3 = Task()
    task_3_1 = Task()
    
    block.block = [task_1, task_2]
    block.rescue = [task_1_1]
    block.always = [task_2_1]

# Generated at 2022-06-25 05:01:43.227561
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_1 = Block()
    try:
        block_0.deserialize()
    except Exception as e:
        pass

    try:
        block_0.deserialize(block_1)
    except Exception as e:
        pass


# Generated at 2022-06-25 05:01:45.748566
# Unit test for method copy of class Block
def test_Block_copy():
    print('')
    print('Testing copy for class Block')
    block_0 = Block()
    exclude_parent_0 = False
    exclude_tasks_0 = False
    ds_0 = block_0.copy(exclude_parent_0, exclude_tasks_0)


# Generated at 2022-06-25 05:01:50.730059
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create the Block object
    b = Block()
    options = Options()
    options.tags = 'untagged'
    options.skip_tags = ''
    tags = ['tagged']
    tags_0 = ['untagged']
    tags_1 = ['tagged']
    tags_2 = ['untagged']
    variables = dict(foo="bar")
    tasks = [dict(
        action=dict(
            module="shell",
            args="echo '{{ foo }}'",
            tags=tags
        )
    )]
    tasks_0 = [dict(
        action=dict(
            module="shell",
            args="echo '{{ foo }}'",
            tags=tags_0
        )
    )]

# Generated at 2022-06-25 05:02:11.901177
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = Block()
    all_vars={}
    filtered_block = block.filter_tagged_tasks(all_vars)

# Generated at 2022-06-25 05:02:15.209631
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    play = Play()
    t1 = Task()
    block_0 = Block(parent_block=t1, role=play)
    assert block_0.all_parents_static() == True


# Generated at 2022-06-25 05:02:20.671325
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()
    block_2 = block_0.copy(exclude_tasks=True)
    block_3 = block_0.copy(exclude_tasks=True, exclude_parent=True)
    return (block_1, block_2, block_3)


# Generated at 2022-06-25 05:02:32.861048
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    block_0 = Block()
    block_0._attributes["block"] = ['value_1']
    block_0._attributes["rescue"] = ['value_2']
    block_0._attributes["always"] = ['value_3']
    block_0._attributes["vars"] = "value_4"
    block_0._attributes["when"] = "value_5"
    block_0._attributes["register"] = "value_6"
    block_0._attributes["delegate_to"] = "value_7"
    block_0._attributes["with_items"] = "value_8"
    block_0._attributes["tags"] = "value_9"
    block_0._attributes["run_once"]

# Generated at 2022-06-25 05:02:36.740395
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    try:
        block_0.filter_tagged_tasks()
        assert False, ''' Block.filter_tagged_tasks() didn't throw an exception '''
    except NotImplementedError:
        pass


# Generated at 2022-06-25 05:02:45.946493
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Setup
    block = Block()
    block.block = [
        Task(name="task #1", tags=["foo", "bar"]),
        Task(name="task #2", tags=["foo", "baz"]),
        Block(name="block", tags=["foo", "baz"]),
        Task(name="task #3", tags=["foo", "bar"])
        ]

    # Test
    only_tags = ["foo"]
    skip_tags = []
    filtered_block = block.filter_tagged_tasks(dict())

    # Assertions
    assert len(filtered_block.block) == 3
    assert filtered_block.block[0].name == "task #1"
    assert filtered_block.block[1].name == "task #2"
    assert "block" in filtered_block