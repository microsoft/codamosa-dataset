

# Generated at 2022-06-25 04:54:01.765869
# Unit test for method copy of class Block
def test_Block_copy():
    block_0_1 = Block()
    block_0_2 = block_0_1.copy()


# Generated at 2022-06-25 04:54:08.942937
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    block1 = Block()
    task1 = Task()
    task2 = Task()
    task3 = Task()
    block1.block = [task1, task2, task3]
    block2 = Block()
    block2.block = [block1]
    block3 = Block()
    block3.block = [block2]
    task1.tags = ['tag1', 'tag2']
    task2.tags = ['tag2', 'tag3']
    task3.tags = ['tag4']
    result = block3.filter_tagged_tasks([])
    expected = Block()

# Generated at 2022-06-25 04:54:10.987406
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    assert block_0.all_parents_static() == True


# Generated at 2022-06-25 04:54:16.550795
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    print('Test filter_tagged_tasks')
    test_case_0()
    block_0 = Block()
    block_0_dict = {'block': [{'action': 'shell', 'do': ['echo hi']}]}
    block_0.load_data(block_0_dict)
    block_0.filter_tagged_tasks({})


# Generated at 2022-06-25 04:54:17.863164
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0.copy()


# Generated at 2022-06-25 04:54:26.998347
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    play = Play()
    host = Host(name='localhost')
    block = Block(
        parent=play,
        block=[
            Task(
                action='setup',
                tags=['always']
            ),
            Block(
                block=[
                    Task(
                        action='debug',
                        tags=['debugselinux']
                    )
                ]
            )
        ],
        always=[
            Task(
                action='debug',
                tags=['always']
            )
        ]
    )
    all_vars = {'tags': ['debugselinux', 'always']}

    filtered_block = block.filter_tagged_tasks(all_vars)
    assert len(filtered_block.block) == 2
    assert len(filtered_block.rescue) == 0

# Generated at 2022-06-25 04:54:37.066684
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    block_0.block = [
        dict(name="t0", tags=["t0"]),
        dict(name="t1", tags=["t1"]),
        dict(name="t2", tags=["t2"]),
        dict(name="t3", tags=["t3"]),
    ]

    play = Play()
    play.tasks = block_0.block

    f = play.filter_tagged_tasks(dict(), play.tags)

    assert len(f) == 0

    f = play.filter_tagged_tasks(dict(), play.tags, skip_tags=True)

    assert len(f) == 4

    f = play.filter_tagged_tasks(dict(), play.tags, skip_tags=True, only_tags=True)

   

# Generated at 2022-06-25 04:54:40.299511
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # ToDo: write unit test for Block.set_loader
    assert 1 == 1


# Generated at 2022-06-25 04:54:43.568889
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()
    assert block_0.copy() == block_1


# Generated at 2022-06-25 04:54:49.023631
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block_1 = Block()
    block_2 = Block()
    block_2.load_data({ 'block' : [ { 'test_key' : 'test_value' } ] })
    assert block_1.serialize() == block_2.serialize()
    block_2 = Block()
    block_2.load_data([ { 'test_key' : 'test_value' } ])
    assert block_1.serialize() == block_2.serialize()
    block_2 = Block()
    block_2.load_data({ 'test_key' : 'test_value' })
    assert block_1.serialize() == block_2.serialize()


# Generated at 2022-06-25 04:55:24.846051
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    class MockPlay:
        pass
    
    class MockTask:
        pass
    
    block = Block()
    block.block = [MockTask(), MockTask()]
    block._play = MockPlay()
    block._play.only_tags = []
    block._play.skip_tags = []
    block.filter_tagged_tasks(None)
    assert block.block == [MockTask(), MockTask()]

# Generated at 2022-06-25 04:55:34.233918
# Unit test for method copy of class Block
def test_Block_copy():
    '''
    Unit test for method copy of class Block
    '''
    tests = [
        {
            "name": "block",
            "block": [
                {
                    "name": "test 0",
                    "local_action": "setup",
                },
            ],
        },
        {
            "block": [
                {
                    "name": "test 1",
                    "local_action": "setup",
                },
                {
                    "name": "test 2",
                    "local_action": "setup",
                },
            ],
        },
    ]

    for test in tests:
        result = Block.load(test)
        assert(result)
        assert(result.name == test.get('name', None))
        copy = result.copy(exclude_parent=True)
        copy_block = copy

# Generated at 2022-06-25 04:55:40.712193
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    block_1 = Block()
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    play_0 = Play()
    block_0.set_loader(DictDataLoader())
    block_1.set_loader(DictDataLoader())
    task_include_0.set_loader(DictDataLoader())
    task_include_1.set_loader(DictDataLoader())
    block_0._parent = task_include_0
    task_include_0._parent = block_1
    block_1._parent = task_include_1
    task_include_1._parent = play_0
    # Testing part of get_first_parent_include where there is a parent include
    expected_value = task_include_0

# Generated at 2022-06-25 04:55:42.210953
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Setup
    block_0 = Block()
    assert block_0.all_parents_static() == True


# Generated at 2022-06-25 04:55:44.410881
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()
    if block_0 != block_1:
        raise Exception('Test Failed.')


# Generated at 2022-06-25 04:55:48.497725
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    data_0 = {}
    block_0.deserialize(data_0)


# Generated at 2022-06-25 04:55:58.013449
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    block_0.rescue = None
    block_0.block = None
    # tests that always is set to an empty list before any value is assigned to it
    assert block_0.has_tasks() == False
    block_0.always = []
    assert block_0.has_tasks() == False
    block_0.always = None
    block_0.rescue = []
    assert block_0.has_tasks() == False
    block_0.rescue = None
    # tests that block is set to an empty list before any value is assigned to it
    assert block_0.has_tasks() == False
    block_0.block = []
    assert block_0.has_tasks() == False


# Generated at 2022-06-25 04:55:59.667693
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0.deserialize(None)


# Generated at 2022-06-25 04:56:04.677036
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    assert block_0.get_dep_chain() is None

    block_0 = Block()
    block_1 = Block()
    block_0.add_dep(block_1)

    block_0 = Block()
    block_1 = Block()
    block_1_1 = Block()
    block_0.add_dep(block_1)
    block_1.add_dep(block_1_1)
    assert block_0.get_dep_chain() == [block_1]
    assert block_1.get_dep_chain() == [block_1_1]


# Generated at 2022-06-25 04:56:11.859452
# Unit test for method deserialize of class Block

# Generated at 2022-06-25 04:56:34.824055
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    task_0 = Task()
    task_0.name = 'sample task'
    task_1 = Task()
    task_1.name = 'sample task'
    handler_task_include_0 = HandlerTaskInclude()
    handler_task_include_0.name = 'sample handler task include'
    task_include_0 = TaskInclude()
    task_include_0.name = 'sample task include'
    block_0._parent = task_0
    block_0.name = 'sample block'
    task_0._parent = task_1
    task_1._parent = handler_task_include_0
    handler_task_include_0._parent = task_include_0
    block_0.get_first_parent_include()
    assert(block_0)

# Unit

# Generated at 2022-06-25 04:56:46.117644
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task import Task

    task_0 = Task()
    task_1 = Task()
    task_2 = Task()
    block_0 = Block()
    block_0.block = [ task_0 ]
    task_0._parent = block_0
    block_1 = Block()
    block_1.block = [ task_1 ]
    task_1._parent = block_1
    block_0._parent = block_1
    block_1.statically_loaded = False
    block_2 = Block()
    block_2.block = [ task_2 ]
    task_2._parent = block_2
    block_1._parent = block_2
    # all_parents_static()

# Generated at 2022-06-25 04:56:57.127271
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    parent_block_0 = Block()
    block_0 = Block(parent_block=parent_block_0)

    result_0 = block_0.all_parents_static()
    # Yes, the above tests a different functionality than the method name
    # suggests. all_parents_static is called by the iterator. Since the parent
    # block is the only non-staticly loaded object in the chain it considers
    # the chain non-static and skips the block.
    assert result_0 == True, "Failure: block_0.all_parents_static() did not return expected result"


block_0 = Block()
block_0.block = [ { 'block': [ { 'always': [ { 'meta': [ 'start_play', { 'playbook_path': '/foo/bar/baz.yml' } ] } ] } ] } ]

# Generated at 2022-06-25 04:57:05.210767
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    fail = False
    for i in range(4):
        try:
            b = Block()
            if( i == 0 ):
                assert b.get_dep_chain() == None
            elif( i == 1 ):
                b._dep_chain = []
                assert b.get_dep_chain() == []
            elif( i == 2 ):
                b._dep_chain = [ 1, 2, 3 ]
                assert b.get_dep_chain() == [ 1, 2, 3 ]
            else:
                b._dep_chain = [ "7", "8", "9" ]
                assert b.get_dep_chain() == [ "7", "8", "9" ]
        except Exception as e:
            print("Error encountered in test_Block_get_dep_chain: " + str(e))
            fail = False

# Generated at 2022-06-25 04:57:15.160246
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition

    block_0 = Block()
    assert len(block_0.filter_tagged_tasks(None).block) == 0

    block_1 = Block()
    task_0 = Task()
    task_0.action = C.ACTION_COMMAND
    block_1.block.append(task_0)
    assert len(block_1.filter_tagged_tasks(None).block) == 1

    block_2 = Block()
    task_0 = Task()
    task_0.action = C.ACTION_META
    block_2.block.append(task_0)

# Generated at 2022-06-25 04:57:25.331581
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    '''
    Unit test for method filter_tagged_tasks of class Block
    '''
    block = Block()

    # Block with no tasks
    assert (len(block.filter_tagged_tasks([]).block) == 0)
    assert (len(block.filter_tagged_tasks([]).rescue) == 0)
    assert (len(block.filter_tagged_tasks([]).always) == 0)

    # Block with 1 task
    block = Block(block=[Task()])

    assert (len(block.filter_tagged_tasks([]).block) == 1)
    assert (len(block.filter_tagged_tasks([]).rescue) == 0)
    assert (len(block.filter_tagged_tasks([]).always) == 0)

    # Block with

# Generated at 2022-06-25 04:57:26.937995
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    data_1 = dict()
    block_0.deserialize(data_1)


# Generated at 2022-06-25 04:57:31.209092
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'key_0': 'value_0'})
    # check if the attribute '_attributes' has been correctly set
    assert block._attributes == {'key_0': 'value_0'}


# Generated at 2022-06-25 04:57:43.014493
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()

    block._valid_attrs['block'] = [True, False]
    block._valid_attrs['rescue'] = [True, False]
    block._valid_attrs['always'] = [True, False]

    # Test conditions where we expect True
    # block = True, rescue = True, always = True
    block._valid_attrs['block'] = [True, False]
    block._valid_attrs['rescue'] = [True, False]
    block._valid_attrs['always'] = [True, False]
    assert block.has_tasks() == True

    # Test conditions where we expect False
    # block = False, rescue = False, always = False
    block._valid_attrs['block'] = [False, False]

# Generated at 2022-06-25 04:57:45.212266
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0.always = []
    def tmp_func_0():
        block_0.block = []
        pass
    return block_0.copy()


# Generated at 2022-06-25 04:58:03.619112
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    assert True

test_case_0()
test_Block_deserialize()

# Generated at 2022-06-25 04:58:08.848701
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()
    assert isinstance(block_1, Block), "Incorrect type returned: %s" % (type(block_1))


# Generated at 2022-06-25 04:58:20.711138
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    block_0._variable_manager = dict()
    block_0._play = dict()
    block_0._play.only_tags = ['example_tag']
    block_0._play.skip_tags = ['example_tag']
    block_0._play.tags = ['example_tag']
    block_0.block = []
    block_0.rescue = []
    block_0.always = []
    block_0.name = 'example_name'
    block_0.vars = {'foo': 'bar'}
    block_0.register = 'example_register'
    block_0.free_form = 'example_free_form'
    block_0.tags = ['example_tag']
    block_0.loop = 'example_loop'
    block_0.when

# Generated at 2022-06-25 04:58:32.567047
# Unit test for method copy of class Block
def test_Block_copy():
    test_block = Block()
    test_block.any_errors_fatal = False
    test_block.any_errors_fatal = True
    test_block.always = [1, 2, 3]
    test_block.block = [4, 5, 6]
    test_block.name = "test_block"
    test_block.rescue = [7, 8, 9]
    test_block._attributes = {'always': [1, 2, 3], 'block': [4, 5, 6], 'name': "test_block", 'rescue': [7, 8, 9]}
    test_block.statically_loaded = False
    test_block.statically_loaded = True
    return test_block.copy()

# Generated at 2022-06-25 04:58:38.219390
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    # attempt to call method 'get_first_parent_include' of object 'Block'
    # but object 'Block' has no attribute 'get_first_parent_include'
    try:
        block_0.get_first_parent_include()
    except AttributeError:
        print("AttributeError: %s" % AttributeError)
    else:
        print("No exception raised")


# Generated at 2022-06-25 04:58:45.096265
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    user_testcases = [
        ['block_0', Block()],
    ]
    for testcase in user_testcases:
        getattr(sys.modules[__name__], testcase[0])
        if testcase[1]._loader is None:
            return ("FAIL: Block: set_loader: _loader was not set.")
        if testcase[1] is None:
            return ("FAIL: Block: set_loader: obj was not set.")
        else:
            pass
            #pass #print("PASS: Block: set_loader")
    return None


# Generated at 2022-06-25 04:58:53.998142
# Unit test for method filter_tagged_tasks of class Block

# Generated at 2022-06-25 04:59:04.462773
# Unit test for method copy of class Block
def test_Block_copy():
    # Testing when the parameter exclude_parent is not given
    block_0 = Block()
    block_1 = block_0.copy()
    assert block_0._parent is block_1._parent
    assert block_0._role is block_1._role
    block_2 = block_0.copy(exclude_parent=True)
    assert block_0._parent is not block_2._parent
    assert block_0._role is block_2._role
    # Testing when the parameter exclude_parent is True
    block_3 = block_0.copy(exclude_parent=True)
    assert block_0._parent is not block_3._parent
    assert block_0._role is block_3._role
    block_4 = block_0.copy(exclude_parent=False)
    assert block_0._parent is block_4

# Generated at 2022-06-25 04:59:11.895936
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()
    task_0 = Task()
    block_0.block.append(task_0)
    task_1 = task_0.copy()
    block_1.block.append(task_1)
    # assert block_0.block[0] is task_0
    # assert block_1.block[0] is task_0
    # assert block_1.block[1] is task_1
    print("Passed method copy of class Block")


# Generated at 2022-06-25 04:59:20.513156
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    print('Testing filter_tagged_tasks')

    def get_block_obj(block_name):
        block_args = dict(name=block_name, parent=test_block_1, role=test_role, play=test_play, loader=test_loader,
                          use_handlers=False,
                          variable_manager=test_variable_manager)

        block_obj = Block(vars=block_args)
        return block_obj


# Generated at 2022-06-25 05:00:05.152474
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    block_0.set_loader()


# Generated at 2022-06-25 05:00:14.632042
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    play = Play()
    play._attributes['hosts'] = 'all'

    test_task_1 = Task()
    task_1_tags = ['always']
    test_task_1._attributes['tags'] = task_1_tags

    test_task_2 = Task()
    task_2_tags = []
    test_task_2._attributes['tags'] = task_2_tags

    test_task_3 = Task()
    task_3_tags = ['debug']
    test_task_3._attributes['tags'] = task_3_tags

    test_task_4 = Task()
    task_4_tags = []
    test_task_4._attributes['tags'] = task_4_tags

    test_task_5 = Task()
    task_5_tags = ['always']
    test

# Generated at 2022-06-25 05:00:19.979583
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()

    try:
        result = block_0.all_parents_static()
    except Error as e:
        # Should not throw an exception, so fail if it does
        assert False
    
    # Should throw an exception, so fail if it doesn't
    assert result == True


# Generated at 2022-06-25 05:00:21.751223
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    loader_0 = DictDataLoader({})
    block_0.set_loader(loader_0)


# Generated at 2022-06-25 05:00:22.914365
# Unit test for method copy of class Block
def test_Block_copy():
    test_case_0()


# Generated at 2022-06-25 05:00:29.014415
# Unit test for method set_loader of class Block
def test_Block_set_loader():

    # setup a mock load to test with
    class fake_loader(object):
        def __init__(self):
            self.flag = 0
        def load(self):
            self.flag = 1
    mock_loader = fake_loader()

    # setup a fake block, inject the mock loader, load the block and
    # ensure the loader was called
    from ansible.playbook.task import Task
    mock_block = Block()
    mock_block.set_loader(mock_loader)
    mock_block.load({'block': [{'task': 'fake'}]})

    assert mock_loader.flag == 1

# Generated at 2022-06-25 05:00:31.990366
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0.deserialize(dict(name="TestBlock"))
    assert block_0.name == "TestBlock"


# Generated at 2022-06-25 05:00:33.702215
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    assert block_0.has_tasks() == False


# Generated at 2022-06-25 05:00:36.527524
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    b = Block()
    b.block = [
        Task()
    ]

    assert test_common_utils.can_execute_test("test_Block_filter_tagged_tasks")
    try:
        b.filter_tagged_tasks({})
        assert True
    except:
        assert False


# Generated at 2022-06-25 05:00:37.532700
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()


# Generated at 2022-06-25 05:01:13.966793
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_1 = Block()
    block_2 = Block()
    block_2._parent = block_1
    block_3 = Block()
    block_3._parent = block_2

# Generated at 2022-06-25 05:01:17.151134
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Setup
    block_0 = Block()

    # Test
    result = block_0.get_dep_chain()

    # Verify
    assert result is None

    return True


# Generated at 2022-06-25 05:01:24.333163
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Test case 1: if self._dep_chain is None, return None
    block_1 = Block()
    assert block_1.get_dep_chain() == None

    # Test case 2: if self._dep_chain is not None, return self._dep_chain[:]
    block_2 = Block()
    block_2._dep_chain = []
    assert block_2.get_dep_chain() == []

    block_3 = Block()
    block_3._dep_chain = [1, 2, 3]
    assert block_3.get_dep_chain() == [1, 2, 3]

    # Test case 3: if self._dep_chain is None and self._parent is not None, return self._parent.get_dep_chain()
    block_4 = Block()
    block_4._parent = 1

# Generated at 2022-06-25 05:01:28.210734
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    assert block_0.has_tasks() == False


# Generated at 2022-06-25 05:01:30.483993
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    data = dict(
    )
    block.deserialize(data)


# Generated at 2022-06-25 05:01:42.228256
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # testing only_tags
    play_data = {
        'name': 'test',
        'hosts': 'all',
        'roles': None,
        'tasks':
        [{'debug': {'msg': '1'}},
         {'debug': {'msg': '2'}},
         {'debug': {'msg': '3'}},
         {'debug': {'msg': '4'}, 'tags': ['a', 'b']},
         {'debug': {'msg': '5'}, 'tags': ['b', 'c']},
         {'debug': {'msg': '6'}, 'tags': ['a', 'b', 'c']},
         {'debug': {'msg': '7'}, 'tags': ['c']}
         ]
    }

# Generated at 2022-06-25 05:01:44.649366
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    try:
        block_0.set_loader(block_0)
    except:
        raise AssertionError("a exception occur.")


# Generated at 2022-06-25 05:01:45.724117
# Unit test for method deserialize of class Block
def test_Block_deserialize():
  # TODO
  pass


# Generated at 2022-06-25 05:01:50.192857
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    if block_0.all_parents_static():
        print("test success")
    else:
        print("test fail")


# Generated at 2022-06-25 05:01:51.877689
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False, block.has_tasks()



# Generated at 2022-06-25 05:02:20.432832
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    assert block_0.has_tasks() == False


# Generated at 2022-06-25 05:02:32.567453
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.name = 'block name for test'
    block.block = ['block', 'block']
    block.always = ['always', 'always']
    block.rescue = ['rescue', 'rescue']
    block.deprecated = 'deprecated'
    block.no_log = 'no_log'
    block.run_once = 'run_once'
    block.vars = ['vars_1', 'vars_2']
    block.when = ['when', 'when']
    block.setup = ['setup', 'setup']
    block.setup_retry = ['setup_retry', 'setup_retry']
    block.teardown = ['teardown', 'teardown']
    block.tags = ['tags_1', 'tags_2']

# Generated at 2022-06-25 05:02:34.482861
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    result = block_0.get_first_parent_include()
    assert result is None


# Generated at 2022-06-25 05:02:40.669234
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    assert not block_0.has_tasks()
    mylist = [1, 2, 3]
    block_0.block = mylist
    assert block_0.has_tasks()

# Generated at 2022-06-25 05:02:46.446300
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_1 = Block()
    block_1.block = [
        Task(),
        Task(),
        Task(),
    ]
    assert block_1.has_tasks()

    block_2 = Block()
    assert not block_2.has_tasks()

    block_3 = Block()
    block_3.rescue = [
        Task(),
        Task(),
        Task(),
    ]
    assert block_3.has_tasks()

    block_4 = Block()
    block_4.always = [
        Task(),
        Task(),
        Task(),
    ]
    assert block_4.has_tasks()


# Generated at 2022-06-25 05:02:49.995656
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    block_0.load_data({'block': []})
    assert block_0.has_tasks() == False
