

# Generated at 2022-06-25 04:53:34.378152
# Unit test for method get_first_parent_include of class Block

# Generated at 2022-06-25 04:53:36.557826
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    str_0 = "Y,\tX&x"
    block_0 = Block(str_0)
    bool_0 = block_0.has_tasks()
    print(bool_0)


# Generated at 2022-06-25 04:53:39.415385
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # handle case where self._parent is a TaskInclude
    block_0 = Block('TaskIncludeImplicit')
    block_0._parent = TaskIncludeImplicit()
    all_vars = {}
    filtered_block = block_0.filter_tagged_tasks(all_vars)
    if len(filtered_block.block) != 0 and len(filtered_block.rescue) != 0 and len(filtered_block.always) != 0:
        raise AssertionError


# Generated at 2022-06-25 04:53:41.319352
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    str_0 = "Fo^w'\x0c"
    block_0 = Block(str_0)
    loader = Mock()
    var_0 = block_0.set_loader(loader)


# Generated at 2022-06-25 04:53:47.051691
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    str_0 = "Fo^w'\x0c"
    block_0 = Block(str_0)
    var_0 = block_0.has_tasks()


# Generated at 2022-06-25 04:53:51.785103
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    str_0 = "\x13\x9cW\x07\x80C\x06\xb8\x12\x08`\x07"
    block_0 = Block(str_0)
    var_0 = block_0.preprocess_data({})


# Generated at 2022-06-25 04:54:00.469607
# Unit test for method all_parents_static of class Block

# Generated at 2022-06-25 04:54:02.750031
# Unit test for method is_block of class Block
def test_Block_is_block():
    str_0 = "Y7F9DdK*'\x0bP"
    block_0 = Block(str_0)
    var_0 = block_0.is_block()


# Generated at 2022-06-25 04:54:05.378896
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    str_0 = ':=@-\x1c'
    block_0 = Block(str_0)
    var_0 = block_0.all_parents_static()
    assert var_0 == True


# Generated at 2022-06-25 04:54:07.796465
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    str_0 = "!xBL\x1f\x06\t\x12"
    block_0 = Block(str_0)
    var_0 = block_0.get_first_parent_include()


# Generated at 2022-06-25 04:54:24.538286
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    try:
        assert(False)
    except AssertionError as e:
        print("AssertionError: %s" % e)


# Generated at 2022-06-25 04:54:33.573048
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    str_0 = "N|g!\x1b"
    block_0 = Block(str_0)
    str_0 = "Y\x06"
    block_0.deserialize(str_0)
    str_0 = "T\x03"
    block_0.deserialize(str_0)
    str_0 = "6\n"
    block_0.deserialize(str_0)
    str_0 = "u\x1f"
    block_0.deserialize(str_0)
    str_0 = "O)d"
    block_0.deserialize(str_0)


# Generated at 2022-06-25 04:54:36.389348
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    str_0 = "Fo^w'\x0c"
    block_0 = Block(str_0)
    assert block_0.all_parents_static() == True


# Generated at 2022-06-25 04:54:42.254073
# Unit test for method copy of class Block
def test_Block_copy():
    str_0 = "Fo^w'\x0c"
    block_0 = Block(str_0)
    block_0.copy()
    block_0.copy(exclude_parent=True)
    block_0.copy(exclude_parent=True, exclude_tasks=True)


# Generated at 2022-06-25 04:54:43.707482
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    block_0.filter_tagged_tasks({})


# Generated at 2022-06-25 04:54:50.053865
# Unit test for method copy of class Block

# Generated at 2022-06-25 04:54:53.108060
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    str_0 = "{pyr\xed'\x0c"
    block_0 = Block(str_0)
    result = block_0.get_dep_chain()
    if result is not None:
        if result:
            pass


# Generated at 2022-06-25 04:54:54.387726
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0.deserialize({})


# Generated at 2022-06-25 04:55:03.172916
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    try:
        str_0 = "?8\x06"
        block_0 = Block.load("?8\x06")
    except AnsibleParserError as e:
        print("Failed to load block.")
    else:
        if not isinstance(block_0, Block):
            print("Failed to unpack the block.")

        if not isinstance(block_0.block, list):
            print("Failed to unpack the tasks properly.")

        print("Success")

if __name__ == "__main__":
    test_case_0()
    test_Block_preprocess_data()

# Generated at 2022-06-25 04:55:06.356085
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Input parameters
    # Output parameters

    # Unit test for method all_parents_static of class Block
    test_case_0()

Block.add_attribute(attribute='always',field_name='always', attribute_type='list')
Block.add_attribute(attribute='block',field_name='block', attribute_type='list')
Block.add_attribute(attribute='rescue',field_name='rescue', attribute_type='list')

# Generated at 2022-06-25 04:55:30.002405
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    str_0 = '{^\xa9\xfd\xcd\xfd\xfe\xe1\xca\xe3\x05'
    block_0 = Block(str_0)
    str_1 = ' '
    list_0 = []
    str_2 = ';'
    str_3 = 'yb'
    str_4 = 'Q'
    str_5 = 'C\x10'
    list_1 = [str_3, str_4, str_5]
    str_6 = 'task_0.yml'
    block_1 = Block(str_6)
    str_7 = 'task_1.yml'
    block_2 = Block(str_7)

# Generated at 2022-06-25 04:55:32.535087
# Unit test for method is_block of class Block
def test_Block_is_block():
    str_0 = "Fo^w'\x0c"
    block_0 = Block(str_0)
    assert Block.is_block(str_0)
    assert not Block.is_block(block_0)


# Generated at 2022-06-25 04:55:39.043842
# Unit test for method copy of class Block
def test_Block_copy():
    str_0 = "q9\x13"
    block_0 = Block(str_0)
    bool_0 = block_0.copy()
    bool_1 = block_0.copy(True, True)



# Generated at 2022-06-25 04:55:43.548666
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    str_0 = "Fo^w'\x0c"
    block_0 = Block(str_0)
    assert block_0.preprocess_data() == None


# Generated at 2022-06-25 04:55:48.736764
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    str_0 = "Fo^w'\x0c"
    block_0 = Block(str_0)
    result = block_0.get_dep_chain()


# Generated at 2022-06-25 04:55:51.247503
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()

# Generated at 2022-06-25 04:55:54.883948
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    str_0 = "Fo^w'\x0c"
    block_0 = Block(str_0)
    block_0.all_parents_static()


# Generated at 2022-06-25 04:55:59.550077
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block(str_0)
    dep_chain_0 = block_0.get_dep_chain()


# Generated at 2022-06-25 04:56:01.067553
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0.deserialize('my_str')


# Generated at 2022-06-25 04:56:04.275305
# Unit test for method copy of class Block
def test_Block_copy():
    str_0 = "foobar"
    block_0 = Block(str_0)
    block_1 = block_0.copy()
    # AssertionError: None != 'foobar'


# Generated at 2022-06-25 04:56:27.355493
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    str_0 = "_\x15>w\x1a\x1b"
    block_0 = Block(str_0)
    dict_0 = dict()
    dict_0['role'] = str_0
    dict_0['block'] = str_0
    dict_0['parent'] = str_0
    dict_0['always'] = str_0
    dict_0['rescue'] = str_0
    dict_0['dep_chain'] = str_0
    dict_0['parent_type'] = str_0
    block_0.deserialize(dict_0)


# Generated at 2022-06-25 04:56:34.101090
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    str_0 = "Fo^w'\x0c"
    block_0 = Block(str_0)
    loader_0 = MockLoader()
    set_loader_return = block_0.set_loader(loader_0)
    # This is to test with the MockLoader object, which has the attribute `_paths`.
    # So, we check that the attribute `_paths` is not empty and not `None`
    assert len(loader_0._paths) > 0
    assert loader_0._paths is not None


# Generated at 2022-06-25 04:56:38.652097
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    str_0 = '4\x0b\x0c\x1e'
    block_0 = Block(str_0)
    block_0.has_tasks()


# Generated at 2022-06-25 04:56:40.642324
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    my_block = Block()
    my_block.deserialize("Fo^w'\x0c")


# Generated at 2022-06-25 04:56:41.948120
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    assert block_0.has_tasks()


# Generated at 2022-06-25 04:56:44.962715
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    str_0 = "}sm\xa8K\xb9"
    block_0 = Block(str_0)
    dep_chain_0 = block_0.get_dep_chain()
    print(dep_chain_0)


# Generated at 2022-06-25 04:56:52.134212
# Unit test for method filter_tagged_tasks of class Block

# Generated at 2022-06-25 04:56:57.210169
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block(str_0)
    # TODO: test case not implemented


# Generated at 2022-06-25 04:56:59.111158
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    test_case_0()



# Generated at 2022-06-25 04:57:08.647174
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    str_0 = 'c_\x15\x19\xb2l\x17\x0e'
    block_0 = Block(str_0)
    for attr in block_0._valid_attrs:
        if attr in ('block', 'rescue', 'always'):
            continue
        setattr(block_0, attr, 'hN\x7f\xde\x9c\n\xbd\x90\xb6\x17')

# Generated at 2022-06-25 04:57:27.785587
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # Test with just a regular block 
    block_0 = Block(str(115))
    block_0.deserialize(block_0.serialize())
    return True


# Generated at 2022-06-25 04:57:29.837454
# Unit test for method copy of class Block
def test_Block_copy():
    str_0 = "Fo^w'\x0c"
    block_0 = Block(str_0)
    block_1 = block_0.copy(block_0)


# Generated at 2022-06-25 04:57:33.637530
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block.load({u'block': [{u'task': {u'name': u'test1', u'local_action': {u'module': u'command', u'args': u'uptime'}}, u'block': [{u'task': {u'name': u'test2', u'local_action': {u'module': u'command', u'args': u'uptime'}}}]}]})
    assert block_0.has_tasks() == True


# Generated at 2022-06-25 04:57:38.227407
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    #  Test case 0
    str_0 = "Fo^w'\x0c"
    block_0 = Block(str_0)
    boolean_0 = block_0.has_tasks()



# Generated at 2022-06-25 04:57:39.345486
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert True


# Generated at 2022-06-25 04:57:40.439590
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    test_case_0()


# Generated at 2022-06-25 04:57:46.697791
# Unit test for method copy of class Block
def test_Block_copy():
   block_0 = Block('block_0')
   block_1 = block_0.copy()
   assert block_1.get_name() == 'block_0'


# Generated at 2022-06-25 04:57:49.733238
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    obj = Block("\x1c\x1d")
    obj.deserialize("\x1c\x1d")


# Generated at 2022-06-25 04:57:54.362459
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    str_0 = "Fo^w'm"
    block_0 = Block(str_0)
    str_1 = "\x17\x1b\x0f"
    block_0.deserialize(str_1)


# Generated at 2022-06-25 04:57:58.299727
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block("Hello")

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:58:21.671340
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    #MOCK
    block = Block('/home/ec2-user/playbook.yml')
    block._play = Mock()
    block._play.only_tags = None
    block._play.skip_tags = None
    block._play._attributes.get.return_value = Sentinel
    block.evaluate_tags = Mock()
    block.evaluate_tags.__name__ = 'evaluate_tags'
    block.evaluate_tags.return_value = True
    class Task():
        def __init__(self, a, b, c, i = False):
            self.action = a
            self.implicit = i
            self.evaluate_tags = Mock()
            self.evaluate_tags.__name__ = 'evaluate_tags'
            self.evaluate_tags.return_value = b

# Generated at 2022-06-25 04:58:29.731165
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block = Block(0)
    
    # Construct array of expected return values
    expected_return_values_0 = [None]
    
    for i in range(0, len(expected_return_values_0)):
        # Call method being tested
        return_value_0 = block.get_first_parent_include()
        
        assert return_value_0 == expected_return_values_0[i]


# Generated at 2022-06-25 04:58:36.297654
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block("ABC")
    all_vars = None
    result = block_0.filter_tagged_tasks(all_vars)
    assert result == None, 'Block.filter_tagged_tasks did not return None'


# Generated at 2022-06-25 04:58:41.629704
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    str_0 = '>@;R\x7f\t\x1c[\x19\x1d\x1a'
    block_0 = Block(str_0)
    str_1 = '\x05UF\x18\x0b\x1d\r\x05\x1b.^\x10\x02\x0c\x19\x10\x06\x08\x13\x17\x08\x0c\x1d\x1a\x1c\x1d\x0c\x18\x14\x05\x19\x11\x1c[\x17\x1d\x06\x0fX'

# Generated at 2022-06-25 04:58:52.298277
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block_0 = Block('\x0c')
    block_1 = block_0.preprocess_data()
    assert block_1
    str_0 = "\x0c\x0b"
    block_2 = Block(str_0)
    block_3 = block_2.preprocess_data()
    assert block_3
    str_1 = "C\x04\x0f"
    block_4 = Block(str_1)
    block_5 = block_4.preprocess_data()
    assert block_5
    str_2 = "\x0f9\t"
    block_6 = Block(str_2)
    block_7 = block_6.preprocess_data()
    assert block_7
    str_3 = "!\x1e)"

# Generated at 2022-06-25 04:59:02.907197
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    tasks = [
        {
            'hosts': 'foo',
            'tasks': [
                {
                    'name': 'foobar',
                    'tags': ['foo'],
                    'action': 'debug',
                    'args': 'var=1'
                }
            ]
        }
    ]

    play_ctx = dict()
    play_ctx['only_tags'] = ['foo']
    play_ctx['skip_tags'] = []
    play_ctx['vars'] = dict()
    play_ctx['vars']['play_hosts'] = ['foo']

    loader = DictDataLoader({})
    variable_manager = VariableManager()
    variable_manager.extra_vars = play_ctx['vars']


# Generated at 2022-06-25 04:59:13.326248
# Unit test for method deserialize of class Block

# Generated at 2022-06-25 04:59:16.742932
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    str_0 = "Fo^w'\x0c"
    block_0 = Block(str_0)
    assert isinstance(block_0.get_first_parent_include(), type(None))


# Generated at 2022-06-25 04:59:18.716018
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    pass


# Generated at 2022-06-25 04:59:22.478098
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0.copy()
    str_0 = "Ow,<\x0c"
    block_1 = Block(str_0)
    block_1.copy()
    str_0 = "Ow,<\x0c"
    block_2 = Block(str_0)
    block_2.copy()


# Generated at 2022-06-25 04:59:41.092964
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    """
    Method all_parents_static test stub.
    """
    test_case_0()


# Generated at 2022-06-25 04:59:45.397160
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    data = { 'block': 'Fo^w\'\x0c' }
    b = Block()
    b.deserialize(data)


# Generated at 2022-06-25 04:59:49.114318
# Unit test for method is_block of class Block
def test_Block_is_block():
    try:
        test_case_0()
        raise AssertionError("Expected AssertionError was not raised")
    except AssertionError as e:
        assert str(e) == "A malformed block was encountered while loading a block"

# Generated at 2022-06-25 04:59:57.955009
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    str_0 = "&B\x1f3)N\x24!\x1fEN\x01\x06\x0f:5\x1c\x0e\x1c\x62\x06\x0e\x0c\x1b\x05\x1c\x62\x0f\x14\x1b\x1b\x13"
    task_0 = Task(str_0)

# Generated at 2022-06-25 04:59:58.967627
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    test_case_0()


# Generated at 2022-06-25 05:00:06.422063
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block('\x00\x0b\x15\x1c\x1f\x0e\x15\x00\x1b\x02\x0c\x1d\x15\x1f')
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    str_2 = "w'\x0c"
    test_case_0()
    test_case_0()
    block_0.serialize()
    block_0.deserialize(str_2)
    test_case_0()

# Generated at 2022-06-25 05:00:12.032836
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    a = Block("x")
    a.block = [a]
    a.block = [a]
    a.block = [a]
    a.filter_tagged_tasks("")
    a.filter_tagged_tasks("")
    a.filter_tagged_tasks("")



# Generated at 2022-06-25 05:00:12.967050
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    assert True


# Generated at 2022-06-25 05:00:21.478344
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    #t = {'tasks': [], 'block': [], 'rescue': [], 'always': []}
    t = {'block': [], 'rescue': [], 'always': []}
    b = Block(t)
    assert(b.has_tasks() == False)
    t = {'block': [{'block':[], 'rescue':[], 'always': []}], 'rescue': [{'block':[], 'rescue':[], 'always': []}], 'always': [{'block':[], 'rescue':[], 'always': []}]}
    b = Block(t)
    assert(b.has_tasks() == True)


# Generated at 2022-06-25 05:00:29.556762
# Unit test for method copy of class Block

# Generated at 2022-06-25 05:00:57.102068
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    str_0 = "T\x04"
    block_0 = Block(str_0)


# Generated at 2022-06-25 05:01:04.162980
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    str_0 = "Fo^w'\x0c"
    str_1 = "x"
    block_0 = Block(str_0)
    all_vars = dict()
    ret_val = block_0.filter_tagged_tasks(all_vars)
    assert ret_val == -1
    assert block_0 == -1
    block_1 = Block(str_0)
    all_vars = dict()
    ret_val = block_1.filter_tagged_tasks(all_vars)
    assert ret_val == -1
    assert block_1 == -1
    block_2 = Block(str_0)
    all_vars = dict()
    ret_val = block_2.filter_tagged_tasks(all_vars)
    assert ret_val

# Generated at 2022-06-25 05:01:09.966942
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Setup
    str_0 = "Fo^w'\x0c"
    block_0 = Block(str_0)
    all_vars_0 = {}

    # Invocation
    ret_0 = block_0.filter_tagged_tasks(all_vars_0)

    # Assertion
    assert isinstance(ret_0, Block)
    assert ret_0 is not block_0
    assert ret_0.block is not block_0.block
    assert ret_0.rescue is not block_0.rescue
    assert ret_0.always is not block_0.always



# Generated at 2022-06-25 05:01:14.564457
# Unit test for method copy of class Block
def test_Block_copy():
    # Setup inputs
    str_0 = "Fo^w'\x0c"
    exclude_parent = True
    exclude_tasks = False

    block_0 = Block(str_0)
    block_0.copy(exclude_parent, exclude_tasks)


# Generated at 2022-06-25 05:01:22.357415
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    str_0 = 'E]}!m%c'

# Generated at 2022-06-25 05:01:26.077194
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    loader_0 = DataLoader()
    block_0.set_loader(loader_0)

if __name__ == "__main__":
    test_Block_set_loader()

# Generated at 2022-06-25 05:01:26.853044
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    test_case_0()


# Generated at 2022-06-25 05:01:31.679727
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    str_0 = "Fo^w'\x0c"
    block_0 = Block(str_0)
    block_0.has_tasks()


# Generated at 2022-06-25 05:01:34.638971
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 05:01:37.196149
# Unit test for method copy of class Block
def test_Block_copy():
    str_0 = "=\x0c"
    block_0 = Block(str_0)
    block_0.copy()


# Generated at 2022-06-25 05:01:58.878604
# Unit test for method filter_tagged_tasks of class Block

# Generated at 2022-06-25 05:02:03.718177
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block("\x07")
    all_vars = {}
    result = block_0.filter_tagged_tasks(all_vars)


# Generated at 2022-06-25 05:02:13.148773
# Unit test for method filter_tagged_tasks of class Block

# Generated at 2022-06-25 05:02:18.458996
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block('\x12\x0e\x0f')
    str_0 = '\x13\x0f\x0f'
    bool_0 = block_0.copy()
    bool_1 = block_0.copy(exclude_parent=bool_0)
    bool_3 = block_0.copy(exclude_tasks=bool_1)



# Generated at 2022-06-25 05:02:20.128258
# Unit test for method filter_tagged_tasks of class Block

# Generated at 2022-06-25 05:02:25.706150
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block(None)
    block_0.filter_tagged_tasks(None)
    block_0 = Block(None, None)
    block_0.filter_tagged_tasks(None)
    block_0 = Block(None, None, None)
    block_0.filter_tagged_tasks(None)


# Generated at 2022-06-25 05:02:30.676953
# Unit test for method get_first_parent_include of class Block

# Generated at 2022-06-25 05:02:33.960740
# Unit test for method copy of class Block
def test_Block_copy():
    str_0 = "v\xa5\x8d\x01\xe5\x1d\x07\x9f\x92"
    block_0 = Block(str_0)
    block_1 = block_0.copy()


# Generated at 2022-06-25 05:02:38.178772
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    pass # TODO


# Generated at 2022-06-25 05:02:46.449933
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    str_0 = '\x1a\xfb\x0c\xdd\xeb\xdc\x0f\xe3\x1bOs\x84\x98\x1bW'
    block_0 = Block(str_0)
    block_0._attributes = {'block': 0, 'rescue': 0, 'always': 0, 'implicit': 0, 'loop': 0, 'register': 0, 'name': 0}
    deque_0 = deque()
    deque_0.append(0)
    block_0.dep_chain = deque_0
    block_0.statically_loaded = True