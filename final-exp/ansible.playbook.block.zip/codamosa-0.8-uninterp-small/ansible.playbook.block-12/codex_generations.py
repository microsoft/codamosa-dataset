

# Generated at 2022-06-25 04:53:47.636402
# Unit test for method set_loader of class Block
def test_Block_set_loader():

    block_1 = Block()
    block_1.set_loader(None)



# Generated at 2022-06-25 04:53:58.439966
# Unit test for method is_block of class Block
def test_Block_is_block():
    data1 = {'block': [{'set_fact': {'a': '{{a}}', 'b': '{{b}}'}}, {'set_fact': {'c': '{{c}}'}}]}
    data2 = {'block': '{{a}}'}
    data3 = [{'set_fact': {'a': '{{a}}', 'b': '{{b}}'}}, {'set_fact': {'c': '{{c}}'}}]
    data4 = {'name': '{{a}}'}

    assert Block.is_block(data1) == True
    assert Block.is_block(data2) == True
    assert Block.is_block(data3) == False
    assert Block.is_block(data4) == False


# Generated at 2022-06-25 04:54:01.803566
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    assert(block_0.has_tasks() == False)



# Generated at 2022-06-25 04:54:04.268659
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    '''
    Unit test for method set_loader of class Block
    '''
    block_0 = Block()
    block_0.set_loader(None)
    assert block_0._loader == None


# Generated at 2022-06-25 04:54:06.360715
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.base import Base
    for obj in [Base(), Block()]:
        obj.copy()
        obj.copy(exclude_parent=True)
        obj.copy(exclude_tasks=True)


# Generated at 2022-06-25 04:54:09.692740
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_1 = Block()
    assert block_1.all_parents_static()


# Generated at 2022-06-25 04:54:15.634934
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    block_0 = Block()
    block_0.set_loader(loader=None)
    loader = DictDataLoader()
    block_0.set_loader(loader=loader)


# Generated at 2022-06-25 04:54:18.773355
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    '''
    Test for method "get_first_parent_include" of class: Block
    '''
    block_0 = Block()
    assert block_0.get_first_parent_include() is None


# Generated at 2022-06-25 04:54:27.673119
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    """ test_Block_filter_tagged_tasks """
    # create a Block
    block_0 = Block()
    # create a Task
    task_0 = Task()
    task_0.action = 'ACTION_START'
    # create a Task
    task_1 = Task()
    # create a Block
    block_1 = Block()
    # create a Task
    task_2 = Task()
    task_2.action = 'ACTION_START'
    # create a Task
    task_3 = Task()
    task_3.action = 'ACTION_INCLUDE'
    task_3.implicit = True
    # create a Task
    task_4 = Task()
    # create a dict
    dict_0 = dict()
    dict_0['skip_tags'] = list()

# Generated at 2022-06-25 04:54:35.487977
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    block_0 = Block()
    task_0 = Task()
    block_0.block = [task_0]
    task_include_0 = TaskInclude()
    task_include_0.block = [block_0]
    assert not block_0.get_first_parent_include()
    assert task_include_0.get_first_parent_include() == task_include_0


# Generated at 2022-06-25 04:54:53.583795
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block_0 = Block()

# Generated at 2022-06-25 04:54:56.456087
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_1 = Block()
    block_1._dep_chain = [42]
    dep_chain_1 = block_1.get_dep_chain()
    assert dep_chain_1 == [42]
    assert dep_chain_1 is not block_1._dep_chain
    block_2 = Block()
    block_2._dep_chain = None
    dep_chain_2 = block_2.get_dep_chain()
    assert dep_chain_2 is None


# Generated at 2022-06-25 04:54:58.992463
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook import Play
    from ansible.playbook.role import Role
    block_0 = Block()
    loader_0 = DataLoader()
    play_0 = Play()
    role_0 = Role()
    block_0.set_loader(loader_0)
    block_0.set_loader(play_0)
    block_0.set_loader(role_0)


# Generated at 2022-06-25 04:55:02.873144
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    test = Test_Block()
    test.set_loader(None)



# Generated at 2022-06-25 04:55:11.911178
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_data = {
            'block': [{'action': 'set_fact', 'args': {'ansible_facts': {u'foo': u'bar', u'baz': u'blergh'}}}],
            'dep_chain': [{'block': [{'action': 'debug', 'args': {'msg': 'Hello World!'}}]}],
            'always': [{'action': 'debug', 'args': {'msg': 'Hello World!'}}],
            'conditional': True,
            'when': False
        }
    block_0.deserialize(block_data)


# Generated at 2022-06-25 04:55:17.346834
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0.deserialize("test_data")
    pass

# Generated at 2022-06-25 04:55:18.497337
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader()


# Generated at 2022-06-25 04:55:20.817527
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    assert block_0.get_first_parent_include() == None


# Generated at 2022-06-25 04:55:23.789085
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Suppose that block is a code block object.
    # Note: this is not the actual method but is a stub.
    block = Block()
    try:
        block.all_parents_static()
    except BaseException as e:
        raise e
    else:
        pass
    finally:
        pass


# Generated at 2022-06-25 04:55:30.124883
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    test_Block = Block()
    test_Block._loader = None
    test_Block._play = Play()
    test_Block._play._loader = None
    test_Block.set_loader(None)
    assert test_Block._loader == None
    assert test_Block._play._loader == None


# Generated at 2022-06-25 04:55:59.253975
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    block_0 = Block()

    task_0 = Task()
    task_0._attributes['action'] = 'debug'
    task_0._attributes['implicit'] = True
    target_0 = block_0.block
    target_0.append(task_0)

    task_1 = Task()
    task_1._attributes['action'] = 'debug'
    task_1._attributes['implicit'] = True
    target_1 = block_0.block
    target_1.append(task_1)

    task_2 = Task()
    task_2._attributes['action'] = 'asdf'
    task_2._attributes['implicit'] = False
    target_2 = block_0.block

# Generated at 2022-06-25 04:56:04.065548
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()

    # Test with no tasks
    assert block_0.has_tasks() == False

    # Test with tasks
    block_0.block = [ AnsibleAction('setup') ]
    assert block_0.has_tasks() == True

    # Test with both 'rescue' and 'always' tasks
    block_1 = Block()
    block_1.rescue = [ AnsibleAction('rescue') ]
    block_1.always = [ AnsibleAction('always') ]
    assert block_1.has_tasks() == True


# Generated at 2022-06-25 04:56:07.682913
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0.always = ['always']
    block_0.block = ['block']
    block_1 = block_0.copy()
    if not isinstance(block_1, Block):
        raise AssertionError('block_0.copy() did not return an instance of Block')


# Generated at 2022-06-25 04:56:08.985096
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()
    assert block_1._attributes == {}


# Generated at 2022-06-25 04:56:10.304420
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    # TODO
    block.set_loader()


# Generated at 2022-06-25 04:56:21.799475
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    # Set the required objects for the task
    play_context_0 = PlayContext()
    task_0 = Task()
    task_0._attributes['tags'] = []
    task_0._ds = {'foo':'bar'}
    task_0._role = None
    task_0._loader = None
    task_0.action = 'setup'
    task_0._task_deps = []
    task_0._blocks = []
    task_0._role = None
    task_0._loop = None
    task_0._when = None
    task_0._loop

# Generated at 2022-06-25 04:56:25.708134
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    assert block_0.has_tasks() == False


# Generated at 2022-06-25 04:56:27.245237
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    assert block_0.deserialize() is None


# Generated at 2022-06-25 04:56:30.308018
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    new_block = block.copy()

    assert(block.all_parents_static() == new_block.all_parents_static())



# Generated at 2022-06-25 04:56:34.683783
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # block_0 = Block()
    block_0 = Block.load(dict(always=dict(tasks=dict())))
    block_0.block = [{'include': {'name': 'hello.yml', 'tags': ['a', 'b']}}]
    vars_0 = dict()
    block_0.filter_tagged_tasks(vars_0)


# Generated at 2022-06-25 04:56:53.890581
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # First test (should pass)
    block_1 = Block()
    task_0 = Task()
    task_1 = Task()
    task_2 = Task()
    block_1.block = [task_0, task_1, task_2]

    assert block_1.filter_tagged_tasks([]) == block_1


# Generated at 2022-06-25 04:57:03.731611
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():

    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.conditional import Conditional
    from ansible.vars.manager import VariableManager

    # create block
    block_0 = Block()

    # create play
    play_0 = Play()
    play_0._variable_manager = VariableManager()
    play_0._tqm = None
    play_0._loader = None
    play_0._variable_manager.extra_vars = {}
    play_0._variable_manager.options_vars = {}

    block_0._play = play_0

    # Add a task to block_0
    task_0 = Task()
   

# Generated at 2022-06-25 04:57:08.289698
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    loader_0 = DataLoader()
    block_0.set_loader(loader_0)


# Generated at 2022-06-25 04:57:11.039367
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()
    assert block_0 is not block_1
    assert type(block_1) is Block


# Generated at 2022-06-25 04:57:17.417423
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    tasks = []
    test_cases = [
        # test_case_0
        {
            'block_0': block_0,
            'tasks': tasks,
            'exclude_parent': False,
            'exclude_tasks': False,
        },
    ]
    for test_case in test_cases:
        block_0 = test_case['block_0']
        tasks = test_case['tasks']
        exclude_parent = test_case['exclude_parent']
        exclude_tasks = test_case['exclude_tasks']
        assert block_0.copy(exclude_parent, exclude_tasks) is not None

# Generated at 2022-06-25 04:57:27.707489
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0.vars = dict()
    block_0.block = []
    block_0.always = []
    block_0.rescue = []
    block_0.loop_block = []
    block_0.loop_control = 'loop'
    block_0.until = []
    block_0.use_handlers = True
    block_0.register = 'register_0'
    block_0.ignore_errors = False
    block_0._attributes = dict()
    block_0.when = []
    block_0.delegate_to = 'delegate_to_0'
    block_0.always_run = 'always_run_0'
    block_0.hosts = 'hosts_0'

# Generated at 2022-06-25 04:57:28.978030
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    assert block_0.all_parents_static()


# Generated at 2022-06-25 04:57:34.882126
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    block_1 = Block()
    block_2 = Block()
    block_3 = Block()
    block_4 = Block()
    block_5 = Block()
    block_6 = Block()
    block_7 = Block()
    block_8 = Block()
    block_9 = Block()
    block_10 = Block()
    block_0.block = [ block_1 ]
    block_2.block = [ block_3 ]
    block_4.block = [ block_5 ]
    block_6.block = [ block_7 ]
    block_8.block = [ block_9 ]
    block_9.block = [ block_10 ]
    block_0.set_loader(block_2)
    block_2.set_loader(block_4)

# Generated at 2022-06-25 04:57:39.233170
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block(use_handlers=True)
    try:
        result = block_0.copy()
    except Exception as e:
        print("TestCase: failed to copy block_0")
        print(e.message)


# Generated at 2022-06-25 04:57:46.716405
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.inventory.host import Host
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar

    test_loader = DictDataLoader({'test': "{'test': 'test'}"})
    test_variable_manager = VariableManager()
    test_host = Host('test_host')
    test_host.set_variable_manager(test_variable_manager)

    # Create template in which to test
    test_block = Block()
    test_block._loader = test_loader
    test_block._variable_manager = test_variable_manager
    test_block.set_loader(test_loader)

    assert test_block._loader == test_loader

# Generated at 2022-06-25 04:58:07.596906
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    def test(b):
        assert not b.has_tasks(), 'test_Block_has_tasks() failed'

    b = Block()
    test(b)

    b = Block()
    b.block = [None]
    test(b)

    b = Block()
    b.rescue = [None]
    test(b)

    b = Block()
    b.always = [None]
    test(b)

    b = Block()
    b.block = [None]
    b.rescue = [None]
    b.always = [None]
    assert b.has_tasks(), 'test_Block_has_tasks() failed'

if __name__ == "__main__":
    test_Block_has_tasks()

# Generated at 2022-06-25 04:58:09.688540
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    test_case_0()


if __name__ == '__main__':
    test_Block_all_parents_static()

# Generated at 2022-06-25 04:58:12.864635
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    test_case_0()
    test_case_0()


# Generated at 2022-06-25 04:58:13.778900
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    assert block_0.deserialize(dict()) == None


# Generated at 2022-06-25 04:58:17.154008
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block()
    assert b.has_tasks() is False
    b = Block.load({'block': [{'name': 'task'}]})
    assert b.has_tasks() is True



# Generated at 2022-06-25 04:58:19.460060
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude

    block_0 = Block()

    assert isinstance(block_0.get_first_parent_include(), (type(None), TaskInclude))


# Generated at 2022-06-25 04:58:22.635149
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    """
    TODO: Test this test.
    """

    block_0 = Block()
    all_vars = all_vars
    filtered_block = block_0.filter_tagged_tasks(all_vars)


# Generated at 2022-06-25 04:58:28.137443
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    data = {'name': 'test'}
    block_0.deserialize(data)

##
# END
##


if __name__ == '__main__':
    test_case_0()
    test_Block_deserialize()

# Generated at 2022-06-25 04:58:34.864527
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0._attributes['block'] = [ Task(action='setup') ]
    data = block_0.serialize()
    block_1 = Block()
    block_1.deserialize(data)
    assert(block_1._attributes['block'] == block_0._attributes['block'])

# Generated at 2022-06-25 04:58:45.421189
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block1 = Block()
    assert block1.has_tasks() is False
    block2 = Block(block=[
        {'name': 'basic task', 'args': {'f': 'b'}}
    ])
    assert block2.has_tasks() is True
    block3 = Block(block=[
        Block(block=[{'name': 'basic task', 'args': {'f': 'b'}}])
    ])
    assert block3.has_tasks() is True
    block4 = Block(block=[
        {'action': 'include', 'block': [{'name': 'basic task', 'args': {'f': 'b'}}]}
    ])
    assert block4.has_tasks() is True


# Generated at 2022-06-25 04:59:06.489307
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # 1. Create object of class Task
    task_0 = Task()
    # 2. Create object of class Block
    block_0 = Block()
    # 3. Call method deserialize of object block_0
    result = block_0.deserialize()


# Generated at 2022-06-25 04:59:15.913071
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    test_case_0()
    assert(True)

################################################################################
#                            BEGIN TEST CASES                                  #
################################################################################

# Generated at 2022-06-25 04:59:18.336105
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    data = { u'loop': u'lorem.ipsum' }
    block_0.deserialize(data)


# Generated at 2022-06-25 04:59:22.183937
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    assert block_0.deserialize({'block': []})
    assert block_0.deserialize({'rescue': []})
    assert block_0.deserialize({'always': []})
    assert block_0.deserialize({'name': 'test block'})
    assert block_0.deserialize({'pause': 2})


# Generated at 2022-06-25 04:59:23.410675
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    block_0.get_dep_chain()


# Generated at 2022-06-25 04:59:25.413025
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    test_Block = Block()
    test_all_vars = {}
    test_Block.filter_tagged_tasks(test_all_vars)

# Generated at 2022-06-25 04:59:37.197824
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():

    # create test data
    all_vars = dict()
    test_block = Block(
        tasks=[
            dict(action=dict(module="ping", args=dict(data="foo")))
        ],
        rescue=[
            dict(include="some_ignore_me_tasks", tags=['tag1'])
        ]
    )
    test_block.post_validate(templar=None)

    # call test target method
    test_block.filter_tagged_tasks(all_vars)

    # verify
    assert(len(test_block.block)==1)
    assert(len(test_block.rescue)==1)
    assert(isinstance(test_block.block[0], Task))
    assert(isinstance(test_block.rescue[0], TaskInclude))
   

# Generated at 2022-06-25 04:59:43.012759
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    # AssertionError: Block.deserialize() called without a loader
    block_0.deserialize({})


# Generated at 2022-06-25 04:59:47.287228
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0.name()

    block_0.copy()


# Generated at 2022-06-25 04:59:51.832709
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    assert block_0.has_tasks() == False


# Generated at 2022-06-25 05:00:14.800116
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_1 = Block()

    print("Testing Block::get_first_parent_include()")
    print("trying case: no parents")
    test_case_0()
    if block_1.get_first_parent_include() is None:
        print("PASS")
    else:
        print("FAIL")



# Generated at 2022-06-25 05:00:25.547189
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    pb = PlaybookSrc.get_entry_point()
    pc = PlayContext(pb)
    loader = DataLoader()
    play = Play().load(dict(
        name='test_play',
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(
                block=[
                    dict(
                        block=[
                            dict(
                                name='debug',
                                debug=dict(msg='in block 1'))])]
            )
        ]), variable_manager=pc.variable_manager, loader=loader)

    play.set_loader(loader)
    play.preprocess_data()
    loader.set_basedir(pb._basedir)
    play.load(play._ds, variable_manager=pc.variable_manager, loader=loader)

    assert play.statically_loaded



# Generated at 2022-06-25 05:00:27.336591
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    res = block_0.copy()

    assert isinstance(res, Block)


# Generated at 2022-06-25 05:00:28.914887
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    data = {'_parent':None}
    assert block_0.deserialize(data)==None


# Generated at 2022-06-25 05:00:29.972121
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    assert Block().get_dep_chain() is None

# Generated at 2022-06-25 05:00:33.418354
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    data_0 = dict()
    print(type(block_0))
    print(type(data_0))
    block_0.deserialize(data_0)


# Generated at 2022-06-25 05:00:37.572525
# Unit test for method deserialize of class Block
def test_Block_deserialize():

    # block = Block()
    # data = dict(block=[dict()], rescue=[dict()], always=[dict()])
    # Depends on Task.deserialize
    # block.deserialize(data)
    pass


# Generated at 2022-06-25 05:00:43.238729
# Unit test for method copy of class Block
def test_Block_copy():
    '''
    Test copy method of class Block
    '''
    test_case_0()
    test_Block_copy.exception = None
    try:
        test_case_0()
    except Exception as e:
        test_Block_copy.exception = e
    finally:
        if test_Block_copy.exception is None:
            raise(test_Block_copy.exception)



# Generated at 2022-06-25 05:00:48.660693
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    mock_loader = Mock()
    data = Mock()
    data.tags = ["tag1", "tag2"]
    data.when = "when1"
    data.register = "register1"
    task = Task.load(data)

    task_list = [task, task]
    block = Block.load(task_list)

    assert len(block.block) == 2
    assert block.block[0].loader == None
    assert block.block[1].loader == None

    block.set_loader(mock_loader)

    assert block.block[0].loader == mock_loader
    assert block.block[1].loader == mock_loader


# Generated at 2022-06-25 05:00:55.630122
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    class _loader_0(object):
        def load_from_file(self, filename=None, attr='', cache=True, unsafe=False, show_content=True, show_filename=False, show_scope=False, content_type='vars'):
            pass
        def list_directory(self, path):
            pass
        def path_exists(self, path):
            pass
        def is_directory(self, path):
            pass
        def find_file_in_search_path(self, filename, search_path):
            pass
        def get_basedir(self, path):
            pass
        def get_real_file(self, filename):
            pass
    _loader_0_obj = _loader_0()

# Generated at 2022-06-25 05:01:28.874845
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    b0 = Block()
    b0.block = [
        {
            'action': 'debug',
            'name': 'This is a task',
            'tags': ['debug']
        }
    ]
    b0.rescue = [
        {
            'action': 'debug',
            'name': 'This is a rescue task',
            'tags': ['oops'],
            'when': 'debug'
        },
        {
            'action': 'debug',
            'name': 'This is a rescue task',
            'tags': ['debug']
        }
    ]
    b0.always = [
        {
            'action': 'debug',
            'name': 'This is an always task',
            'tags': ['debug']
        }
    ]
    b0._use_handlers = True

    # Test

# Generated at 2022-06-25 05:01:39.469561
# Unit test for method copy of class Block
def test_Block_copy():
    """
    Most of the implementation of this method has already been unit tested in
    the copy() methods of the other objects of the Play class.

    What remains to be unit tested is the specifics of the Block copy() method
    itself, which is the job of this method.
    """

    # Create a simple block to test
    test_block_0 = Block()

    # Create a clone of the test block
    test_block_1 = test_block_0.copy(exclude_tasks=False)

    # Add a value to the test block
    test_block_0.name = 'my_block'

    # Make sure that the two blocks are not the same
    # (test_block_1 should not have been changed when we added a value to test_block_0)

# Generated at 2022-06-25 05:01:46.307323
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():

    # The test assumes that the following tasks are defined in the test
    # playbook:
    #  1) task contains the tag 'a'
    #  2) task contains the tag 'b'
    #  3) task contains the tag 'c'
    #  4) task contains the tag 'd'
    #  5) task contains the tag 'e'
    #  6) task contains the tag 'f'
    #  7) task contains the tag 'g'
    #  8) task contains the tag 'h'

    # Assume that the first tag should be picked
    block = Block()
    block.block = [1,2,3,4,5,6,7,8]
    filtered_block = block.filter_tagged_tasks({'tags': ['a'], 'skip_tags': []})

    assert filtered_

# Generated at 2022-06-25 05:01:48.209020
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    pass


# Generated at 2022-06-25 05:01:56.818723
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()

# Generated at 2022-06-25 05:01:57.919755
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    assert block_0.all_parents_static() == True


# Generated at 2022-06-25 05:02:00.261635
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block(loader=DictDataLoader())
    block_0.vars.update({"test": 1})
    block_0.block = [{'action': {'__ansible_module__': "setup"}}]
    block_0.copy()



# Generated at 2022-06-25 05:02:02.126969
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    block_0._parent = Sentinel
    expected = False
    result = block_0.all_parents_static()
    assert result == expected


# Generated at 2022-06-25 05:02:04.233480
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()

    if len(block_0.get_first_parent_include().__str__()) > 0:
        return True
    return False


# Generated at 2022-06-25 05:02:06.130001
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    block_0.set_loader(loader)
