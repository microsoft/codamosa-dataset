

# Generated at 2022-06-25 04:54:07.765142
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():

    # Create a play
    play_0 = Play()

    # Create a block
    str_0 = 'done templating'
    block_0 = Block(str_0, parent_block=play_0)

    # Create a block
    str_1 = 'done templating'
    block_1 = Block(str_1, parent_block=block_0)

    # Create a block
    str_2 = 'done templating'
    block_2 = Block(str_2, parent_block=block_1)

    # Create a task
    task_0 = Task()
    block_2.block.append(task_0)

    # Create a task
    task_1 = Task()
    block_2.block.append(task_1)

    # Create a task
    task_2 = Task()
   

# Generated at 2022-06-25 04:54:13.140426
# Unit test for method is_block of class Block
def test_Block_is_block():
    str_0 = 'done templating'
    block_0 = Block(str_0)

    b_0 = Block.is_block(block_0)
    b_1 = Block.is_block(block_1)
    b_2 = Block.is_block(block_2)


# Generated at 2022-06-25 04:54:16.342003
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Init a block object, set it's attr to the values we need
    block = Block()
    block.block = ['block']
    result = block.has_tasks()
    assert result == True


# Generated at 2022-06-25 04:54:18.933222
# Unit test for method copy of class Block
def test_Block_copy():
    str_0 = 'done templating'
    block_0 = Block(str_0)
    test_0 = block_0.copy()
    assert test_0 == block_0


# Generated at 2022-06-25 04:54:22.377063
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    str_0 = 'done templating'
    block_0 = Block(str_0)
    loader_0 = DataLoader()
    block_0.set_loader(loader_0)


# Generated at 2022-06-25 04:54:27.004437
# Unit test for method is_block of class Block
def test_Block_is_block():
    import os
    import tempfile
    tempdir = tempfile.mkdtemp()
    block_1_file = os.path.join(tempdir, "block_1")
    fd = open(block_1_file, "w")
    fd.write("#!/usr/bin/python\n")
    fd.write("# -*- coding: utf-8 -*-\n")
    fd.write("\n")
    fd.write("\n")
    fd.write("import os\n")
    fd.write("import sys\n")
    fd.write("import unittest\n")
    fd.write("\n")
    fd.write("# Import mock to mock the dependant modules\n")
    fd.write("try:\n")
    f

# Generated at 2022-06-25 04:54:32.829155
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    str_0 = 'done templating'
    block_0 = Block(str_0)
    result = block_0.has_tasks()
    assert False == result


# Generated at 2022-06-25 04:54:36.134518
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block('Some string')
    assert block_0.has_tasks() == False
    block_1 = Block('Other string')
    assert block_1.has_tasks() == False

test_case_0()

# Generated at 2022-06-25 04:54:40.787686
# Unit test for method copy of class Block
def test_Block_copy():
  str_0 = 'done templating'
  block_0 = Block(str_0)
  block_0_copy = block_0.copy(sentinel.arg1, sentinel.arg2)
  return True


# Generated at 2022-06-25 04:54:45.672663
# Unit test for method is_block of class Block
def test_Block_is_block():
    str_0 = 'done templating'
    block_0 = Block(str_0)
    data = dict()
    data['block'] = 'foo'

    block_1 = Block(data)
    Block.is_block(data)
    Block.is_block(block_1)
    Block.is_block(block_0)
    Block.is_block(str_0)


# Generated at 2022-06-25 04:55:05.941537
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude

    # Setup:
    block_0 = Block()
    task_include_0 = TaskInclude()

    # Test:
    assert block_0.get_first_parent_include() == None
    block_0._parent = task_include_0
    assert block_0.get_first_parent_include() == task_include_0



# Generated at 2022-06-25 04:55:14.976487
# Unit test for method is_block of class Block
def test_Block_is_block():
    data = dict()
    assert(Block.is_block(data) == False)

    data = dict(block = [dict(action=dict(module="shell", args="ls -l"), register="shell_out", always_run="yes"), dict(action=dict(module="debug", args="msg={{shell_out.stdout}}"))])
    assert(Block.is_block(data) == True)


# Generated at 2022-06-25 04:55:15.976566
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0.copy()


# Generated at 2022-06-25 04:55:22.881421
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    copy_0 = block_0.copy()
    assert copy_0 is not block_0
    assert copy_0.__dict__ == block_0.__dict__
    assert copy_0.block == []
    assert copy_0.rescue == []
    assert copy_0.always == []


# Generated at 2022-06-25 04:55:26.378485
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    assert Block().get_dep_chain() == None


# Generated at 2022-06-25 04:55:30.229200
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()
    block_2 = Block()
    block_3 = block_2.copy()


# Generated at 2022-06-25 04:55:32.193039
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    loader = DataLoader()
    block_0.set_loader(loader)
    assert block_0._loader is loader


# Generated at 2022-06-25 04:55:38.207137
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():

    block_0 = Block()

    block_0._dep_chain = None

    actual = block_0.get_dep_chain()

    if actual != None:
        raise ValueError('Test Failed')


# Generated at 2022-06-25 04:55:41.005787
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()

    # Try calling set_loader with and without a loader argument
    try:
        block_0.set_loader()
    except TypeError:
        pass
    block_0.set_loader(loader)


# Generated at 2022-06-25 04:55:49.107883
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():

    my_block = Block(
        rescue=[
            Task(
                name='rescue task 1',
                tags=['tag_1', 'tag_2'],
            )
        ],
        always=[
            Task(
                name='always task 1',
                tags=['tag_2', 'tag_3'],
            )
        ],
        block=[
            Task(
                name='task 1',
                tags=['tag_0'],
            ),
            Task(
                name='task 2',
                tags=['tag_2', 'tag_3'],
            ),
            Task(
                name='task 3',
                tags=['tag_3', 'tag_4'],
            ),
        ],
    )

    my_play = Play()
    my_play.only_tags = ['tag_2']
   

# Generated at 2022-06-25 04:56:04.227515
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    block_0.all_parents_static()


# Generated at 2022-06-25 04:56:06.661560
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    class test_loader():
        def __init__(self):
            pass

    loader = test_loader()
    block.set_loader(loader)


# Generated at 2022-06-25 04:56:12.360096
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    data = dict()
    block_0.deserialize(data)
    assert block_0 is not None


# Generated at 2022-06-25 04:56:17.424745
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    assert block_0.get_dep_chain() is None


# Generated at 2022-06-25 04:56:24.726575
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Create a block with a non-none dep_chain
    print("Testing get_dep_chain")
    test_block = Block()
    test_block._dep_chain = ['A', 'B']
    assert test_block.get_dep_chain() == ['A', 'B']

    # Create a block with a none dep_chain, but with a parent block
    test_block = Block()
    test_block._dep_chain = None
    test_block._parent = Block()
    test_block._parent._dep_chain = ['A', 'B']
    assert test_block.get_dep_chain() == ['A', 'B']

    # Create a block with a none dep_chain, but with a parent block
    test_block = Block()
    test_block._dep_chain = None
    test_block._parent = Block

# Generated at 2022-06-25 04:56:29.569787
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0.deserialize({
        'delegate_to': 'localhost',
        'block': [
            {
                'name': 'test_task_0',
                'include': 'asdf',
                'action': 'setup',
                'tags': [
                    'test'
                ],
                'when': 'test',
                'local_action': ['shell echo hello world'],
                'register': 'test_var_0'
            }
        ],
        'gather_facts': 'no',
        'when': 'test_when_0',
        'changed_when': 'test_changed_when_0'
    })


# Generated at 2022-06-25 04:56:37.363420
# Unit test for method is_block of class Block
def test_Block_is_block():
    # Test case for function Block.is_block(ds) with good data:
    data_1 = dict(block=('first_task','second_task','third_task',
        'fourth_task','fifth_task','sixth_task','seventh_task','eighth_task',
        'ninth_task','tenth_task','eleventh_task','twelth_task','thirteenth_task',
        'fourteenth_task','fifteenth_task','sixteenth_task','seventeenth_task',
        'eighteenth_task','nineteenth_task','twentieth_task','twentyfirst_task',
        'twentysecond_task','twentythird_task','twentyfourth_task','twentyfifth_task'))
    assert(Block.is_block(data_1) == True)


# Generated at 2022-06-25 04:56:39.503726
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    dep_chain_0 = block_0.get_dep_chain()


# Generated at 2022-06-25 04:56:43.291360
# Unit test for method copy of class Block
def test_Block_copy():
    global block_0

    task_1 = Task()
    block_0.block.append(task_1)

    block_2 = block_0.copy()

    assert block_0.block[0]._parent == block_0
    assert block_2.block[0]._parent == block_2


# Generated at 2022-06-25 04:56:50.941670
# Unit test for method copy of class Block
def test_Block_copy():
    '''
    Test copy method
    '''
    r = Role()
    r._role_name = 'foo'
    r._role_path = r._role_name
    block_0 = Block(role=r)
    block_0._parent = Block()
    block_0.block = [
        Task(),
        Task()
    ]
    block_0.rescue = [
        Task()
    ]
    block_0.always = [
        Task()
    ]

    block_0_copy = block_0.copy()

    assert_equal(block_0.block[0].get_name(), block_0_copy.block[0].get_name())
    assert_true(block_0.block[0]._role is block_0_copy.block[0]._role)

# Generated at 2022-06-25 04:57:42.457833
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Example for a dep chain of size 0
    block_0 = Block()
    assert block_0.get_dep_chain() == None
    
    # Example for a dep chain of size 1
    block_1 = Block()
    block_1._dep_chain = [Block()]
    assert block_1.get_dep_chain() == [Block()]
    
    # Example for a dep chain of size 2
    block_2 = Block()
    block_2._dep_chain = [Block(), Block()]
    assert block_2.get_dep_chain() == [Block(), Block()]
    
    # Example for a dep chain of size 3
    block_3 = Block()
    block_3._dep_chain = [Block(), Block(), Block()]

# Generated at 2022-06-25 04:57:43.634094
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0.deserialize()


# Generated at 2022-06-25 04:57:49.407230
# Unit test for method copy of class Block
def test_Block_copy():
    block_1 = Block()

    ret = block_1.copy()
    assert isinstance(ret, Block)
    assert ret != block_1
    assert ret.block is None
    assert ret.rescue is None
    assert ret.always is None
    assert ret._dep_chain is None
    assert ret._parent is None
    assert ret._role is None
    assert ret.any_errors_fatal is True
    assert ret._loop is None
    assert ret._parent is None
    assert ret._use_handlers is True
    assert ret._role is None
    assert ret._loop is None
    assert ret.any_errors_fatal is True


# Generated at 2022-06-25 04:57:57.856131
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    #
    # Ansible 2.2, 2.3
    #

    # Note: This test is not run from the command line because it will be
    # run as part of the python code coverage test.

    # Initialize the test case
    block_0 = Block()

    # From Ansible 2.2
    block_0.statically_loaded = False
    block_0._parent = None
    r = block_0.all_parents_static()
    assert r == True

    # From Ansible 2.3
    r = block_0.all_parents_static()
    assert r == False

# Generated at 2022-06-25 04:58:03.246970
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_1 = Block()
    assert isinstance(block_1, Block)
    parent_1 = block_1.get_first_parent_include()
    assert parent_1 is None
    parents_static_1 = block_1.all_parents_static()
    assert parents_static_1
    if True:
        # block_1 is True, parent_1 is None
        # local vars is not empty
        # assert parent_1 is not None
        pass
    else:
        # block_1 is True, parent_1 is None
        pass


# Generated at 2022-06-25 04:58:07.182781
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    block_5 = Block(parent=block_0)
    block_8 = Block(block=block_5)
    assert block_8.get_first_parent_include() == None


# Generated at 2022-06-25 04:58:15.687991
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    assert block_0.get_dep_chain() is None
    block_1 = Block()
    block_1._parent = block_0
    block_2 = Block()
    block_2._parent = block_1
    block_3 = Block()
    block_3._parent = block_2
    assert block_3.get_dep_chain() == [block_2, block_1, block_0]
    assert block_3.get_dep_chain() != [block_3, block_2, block_1]

# Generated at 2022-06-25 04:58:21.366464
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    play = Play()
    block = Block()

    assert play.only_tags is None
    assert play.skip_tags is None

    assert block.filter_tagged_tasks({}) is block


# Generated at 2022-06-25 04:58:33.151750
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0.static = True
    block_0.name = 'myblock'
    block_0.loop_control = dict(loop_var='my_terms')
    block_0.when = 'when'
    block_0._valid_attrs['loop'] = (FieldAttribute(isa='sequence'), FieldAttribute(isa='sequence', default=[]))
    block_0.loop = ['loop']
    block_0.block = []
    block_0.rescue = []
    block_0.always = []
    block_0.tags = ['tags']
    block_0._attributes['when'] = 'when'
    block_0._attributes['name'] = 'myblock'
    block_0._attributes['loop'] = 'loop'

# Generated at 2022-06-25 04:58:36.719149
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    assert block_0._loader is None
    block_0._set_loader(loader=None)
    assert block_0._loader == None
    block_0._set_loader(loader=None)
    assert block_0._loader == None


# Generated at 2022-06-25 04:58:59.989257
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    result_0 = block_0.has_tasks()
    assert result_0 == False


# Generated at 2022-06-25 04:59:11.455468
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    test_Section_Section_load()
    test_Section_Section_set_canonical()
    test_Section_Section_get_section_var()
    test_Section_Section_get_vars()
    test_Section_Section_get_vars_files()
    test_Section_Section_get_vars_file_entries()
    test_Section_Section_get_vars_sources()
    test_Section_Section_get_host_vars()
    test_Section_Section_merge_vars()
    test_Section_Host_load()
    test_Section_Host_set_canonical()
    test_Section_Host_get_section_var()
    test_Section_Host_get_vars()
    test_Section_Host_get_vars_files()
    test_Section_Host

# Generated at 2022-06-25 04:59:20.133828
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    mock_loader = Mock()
    mock_ansible_vars = Mock()
    mock_ansible_vars.get_vars = Mock()
    mock_task_include = TaskInclude()
    mock_task_include.set_loader = Mock()
    mock_task_include.get_loader = Mock()
    mock_task_include.get_loader.return_value = mock_loader
    mock_handler_task_include = HandlerTaskInclude()
    mock_handler_task_include.set_loader = Mock()
    mock_handler_task_include.get_loader = Mock()
    mock_handler_task_include.get_loader.return_value = mock_loader
    mock_role = Role()
    mock_role.get_vars = Mock()

# Generated at 2022-06-25 04:59:26.782385
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude

    task_include_0 = TaskInclude()

    block_0 = Block()
    # set _parent in Block instance block_0
    block_0._parent = task_include_0

    # check for test case 0
    assert block_0.get_first_parent_include() == task_include_0




# Generated at 2022-06-25 04:59:38.463704
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    '''
    Test a simple implicit block with tags.
    '''

    ds = dict(
        block=dict(
            tasks=[
                dict(name="first test task", action=dict(module="command", args="true"), tags=["first"]),
                dict(name="second test task", action=dict(module="command", args="true"), tags=["second", "second_tag"]),
            ]
        )
    )

    p = Play().load(ds)
    pb = Playbook().load([p])
    i = Inventory(loader=DataLoader())
    i.host_list = [Host(name="foobar")]
    i.get_host("foobar").set_variable('ansible_python_interpreter', sys.executable)

# Generated at 2022-06-25 04:59:43.490629
# Unit test for method copy of class Block
def test_Block_copy():
    pass
    # TODO: Test
    # block = Block()
    # expected = None
    # actual = block.copy()
    # assertEquals(expected, actual)


# Generated at 2022-06-25 04:59:46.378765
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    block_0.block = ['tasks']

    block_0.filter_tagged_tasks(['False'])


# Generated at 2022-06-25 04:59:55.044902
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    play = Play()
    play.vars = dict(var_1 = 'var_1')
    block_0 = Block(play)

    role_0 = Role()
    role_0._parent = None
    role_0._attributes = dict()

    simple_0 = Task()
    simple_0.action = 'set_fact'
    simple_0.args = dict(var_2 = 'var_2')
    simple_0._attributes = dict(tags = ['t_0'])

    block_0._parent = role_0
    block_0.block = [simple_0]
    block_0.rescue = []
    block_0.always = []
    block_0._role = role_0
    block_0._play = play
    block_0._dep_chain = None
    block_0

# Generated at 2022-06-25 04:59:57.113426
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    print(block_0.has_tasks())


# Generated at 2022-06-25 05:00:05.238500
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    tasks = ({"action": {"__ansible_module__": "setup", "register": "ansible_facts"}}, {"action": {"__ansible_module__": "shell", "args": "ls", "name": "ls"}})
    data = {'register': 'ansible_facts', '__ansible_module__': 'setup'}
    module = 'setup'
    import sys
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-25 05:00:30.716516
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # create a block
    block_0 = Block()

    # create a play
    play_0 = Play()

    # create a task
    task_0 = Task()

    # create a TaskInclude
    task_include_0 = TaskInclude()

    # create an implicit task
    task_1 = Task()

    # create a playcontext
    playcontext_0 = PlayContext()

    # setup the playcontext to have some hosts
    playcontext_0.set_hosts(['my_host'])

    # setup the playcontext to have some variables
    playcontext_0._vars_cache['my_var'] = 'my_value'

    # setup the playcontext to have a set of tags
    playcontext_0.set_only_tags(['my_tag'])

    # setup the playcontext to have another set of

# Generated at 2022-06-25 05:00:33.165175
# Unit test for method get_first_parent_include of class Block

# Generated at 2022-06-25 05:00:37.609463
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    '''
    Unit test for method filter_tagged_tasks of class Block
    '''

    test_case_1_setup()
    f_res = block_0.filter_tagged_tasks(None)
    assert(f_res != None)



# Generated at 2022-06-25 05:00:48.709301
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block()
    assert b.has_tasks() == False

    block_0 = Block()
    block_1 = Block()
    
    # First test case
    block_0._parent = block_1
    block_0.block = [ansible.task.Task(), ansible.task.Task()]
    assert block_0.has_tasks() == True
    block_0.block = []
    assert block_0.has_tasks() == False
    
    # Second test case
    block_0.block = [ansible.task.Task(), ansible.task.Task()]
    block_0.rescue = [ansible.task.Task(), ansible.task.Task()]
    
    assert block_0.has_tasks() == True
    
    # Third test case
    block_0

# Generated at 2022-06-25 05:01:00.342001
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert len(block.block) == 0
    assert len(block.rescue) == 0
    assert len(block.always) == 0
    assert not block.has_tasks()
    assert len(block.rescue) == 0
    assert not block.has_tasks()
    task1 = Task()
    block.block = [task1]
    assert len(block.block) > 0
    assert len(block.rescue) == 0
    assert len(block.always) == 0
    assert block.has_tasks()

if __name__ == "__main__":
    test_case_0()
    test_Block_has_tasks()
    print("everything passed")

# Generated at 2022-06-25 05:01:02.550616
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    test = Block()
    assert test.has_tasks() == False
    test = Block(block=[{'foo': 'bar'}])
    assert test.has_tasks() == True


# Generated at 2022-06-25 05:01:03.436104
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()


# Generated at 2022-06-25 05:01:08.040295
# Unit test for method set_loader of class Block
def test_Block_set_loader():

    # Test 1
    # Data
    block = Block.load(dict(block=[dict(action='set_fact', name="my_business_hours", value="10am-7pm")]))
    loader = DictDataLoader({})

    # Run method
    try:
        block.set_loader(loader)
    except Exception:
        print("Passed test: Block.set_loader method raised expected exception")
    else:
        print("Failed test: Block.set_loader method did not raise expected exception")


# Generated at 2022-06-25 05:01:18.220705
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    import sys
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    ansible_loader = loader.AnsibleLoader()
    ansible_loader.set_basedir(tmpdir)


# Generated at 2022-06-25 05:01:24.040277
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    # Call filter_tagged_tasks of Block
    block_0.filter_tagged_tasks(all_vars)


# Generated at 2022-06-25 05:02:12.583866
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_0._play = Play()
    my_vars = dict()
    my_vars['hostvars'] = dict()
    block_0._variable_manager = VariableManager()
    block_0._variable_manager._fact_cache = dict()
    block_0._variable_manager._extra_vars = my_vars

# Generated at 2022-06-25 05:02:15.353789
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    result = block_0.copy()
    assert result.__class__.__name__ == 'Block'



# Generated at 2022-06-25 05:02:17.100012
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    assert test_case_0() == block_0.all_parents_static()



# Generated at 2022-06-25 05:02:19.602135
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block0 = Block()
    assert block0.has_tasks() == False

    block1 = Block()
    task = Task()
    block1.block = [task]
    assert block1.has_tasks() == True


# Generated at 2022-06-25 05:02:24.616940
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0.dep_chain = ['dep_chain_0', 'dep_chain_1']

    block_0_copy = block_0.copy()

    if not block_0_copy.dep_chain == block_0.dep_chain:
        return False

    return True


# Generated at 2022-06-25 05:02:25.705932
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    test_case_0()


# Generated at 2022-06-25 05:02:29.703000
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    for x in range(100):
        b = Block()
        if b.get_dep_chain() == None:
            return True
        else:
            return False


# Generated at 2022-06-25 05:02:40.594412
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    block_0 = Block()
    parent_data = {'_parent': None}
    parent_type = 'Block'
    block_0.deserialize({'parent': parent_data, 'parent_type': parent_type})
    assert block_0._parent.__class__.__name__ == 'Block'
    assert isinstance(block_0._parent, Block)
    block_1 = Block()
    parent_data = {'_parent': None}
    parent_type = 'TaskInclude'
    block_1.deserialize({'parent': parent_data, 'parent_type': parent_type})

# Generated at 2022-06-25 05:02:42.848831
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    assert block_0.has_tasks() == False


# Generated at 2022-06-25 05:02:46.860542
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    assert block_0.all_parents_static() == True
