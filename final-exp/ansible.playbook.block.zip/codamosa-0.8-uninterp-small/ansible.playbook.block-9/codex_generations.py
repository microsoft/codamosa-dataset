

# Generated at 2022-06-25 04:53:59.512337
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    #test case for Block.get_first_parent_include()
    block_0 = Block({})
    assert block_0.get_first_parent_include() == None, "Block test_case_0 failed"


# Generated at 2022-06-25 04:54:03.519239
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    b = Block.load(dict(block=[dict(action=dict(module='test_1'))]))
    b_parent = Block.load(dict(block=[b]))
    assert isinstance(b_parent, Block)
    assert isinstance(b, Block)
    b_parent.all_parents_static()


# Generated at 2022-06-25 04:54:09.394137
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    dict_0 = None
    block_0 = Block(dict_0)


# Generated at 2022-06-25 04:54:19.797845
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    # verify that Block object is created with the expected attribute values
    dict_0 = None
    block_0 = Block(dict_0)
    assert isinstance(block_0, Block)
    assert isinstance(block_0._attributes, dict)
    assert isinstance(block_0._parent, Block)
    assert block_0._parent is None

    # verify that get_first_parent_include returns None for the default object
    dict_0 = None
    block_0 = Block(dict_0)
    assert block_0.get_first_parent_include() is None

    # verify that get_first_parent_include returns the correct object
    dict_0 = {'include': 'tasks/main.yml'}
    dict_1 = {'block': [dict_0]}
    dict_2 = None
    dict_

# Generated at 2022-06-25 04:54:25.716522
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    dict_0 = [{'my_block': 'my_block'}]
    block_0 = Block(dict_0)
    dict_1 = ['my_task']
    block_1 = Block(dict_1)
    dict_2 = {'block': 'block'}
    block_2 = Block(dict_2)
    dict_3 = {'my_block': 'my_block'}
    block_3 = Block(dict_3)


# Generated at 2022-06-25 04:54:36.143276
# Unit test for method copy of class Block
def test_Block_copy():
    # initialize a new instance of class Block
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    # assert if get_include_params method of instance Block
    # is equal to expected output
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    # assert if get_include_params method of instance Block
    # is equal to expected output
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
   

# Generated at 2022-06-25 04:54:47.424621
# Unit test for method deserialize of class Block
def test_Block_deserialize():

    # Values for testing
    data = dict()
    # clear the task list
    for attr in [ 'block', 'rescue', 'always' ]:
        if attr in data and attr not in ( 'block', 'rescue', 'always' ):
            setattr(block_0, attr, data.get(attr))
    block_0._role = None
    if block_0._role:
        r = Role()
        r.deserialize(role_data)
        block_0._role = r
    block_0._parent = None
    if block_0._parent:
        parent_data = data.get('parent')
        if parent_data:
            parent_type = data.get('parent_type')
            if parent_type == 'Block':
                p = Block()

# Generated at 2022-06-25 04:54:51.138935
# Unit test for method copy of class Block
def test_Block_copy():
    dict_0 = None
    block_0 = Block(dict_0)
    bool_0 = False
    bool_1 = True
    block_1 = block_0.copy(bool_0, bool_1)

# Generated at 2022-06-25 04:54:57.817906
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # test_0
    dict_0 = None
    block_0 = Block(dict_0)
    # test_1
    dict_1 = dict(
        block=list(
            dict(
                block=list(
                    dict(
                        always=list(dict(name=str("echo"), register=str("shell_out"))),
                        block=list(dict(name=str("echo"), register=str("shell_out"))),
                        rescue=list(dict(name=str("echo"), register=str("shell_out")))
                    )
                )
            )
        )
    )
    block_1 = Block(dict_1).copy()
    # test_2

# Generated at 2022-06-25 04:55:08.928896
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    dict_0 = {}
    block_0 = Block(dict_0)

# Generated at 2022-06-25 04:55:28.790665
# Unit test for method copy of class Block
def test_Block_copy():
    dict_0 = None
    block_0 = Block(dict_0)
    assert(block_0.copy(exclude_parent = False, exclude_tasks = False) == None)


# Generated at 2022-06-25 04:55:33.867047
# Unit test for method copy of class Block
def test_Block_copy():
    dict_0 = None
    block_0 = Block(dict_0)
    block_0.copy(False)
    # Verify method copy exist in class Block
    assert 1 == block_0.copy(False)


# Generated at 2022-06-25 04:55:41.944381
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    parser = PlaybookParser()
    pb = parser.parse('test/staticdata/test_playbook.yml')

    block_0 = pb.get_plays()[0].get_tasks()[0].block
    all_vars = pb.get_plays()[0].get_variable_manager().get_vars(play=pb.get_plays()[0])

    # test_case_0
    assert (block_0.filter_tagged_tasks(all_vars).has_tasks()) == True



# Generated at 2022-06-25 04:55:43.835940
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block(None)
    block_1 = block_0.copy()
    assert(block_1 == block_0)


# Generated at 2022-06-25 04:55:48.737341
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    dict_0 = None
    block_0 = Block(dict_0)
    loader_0 = None
    block_0.set_loader(loader_0)


# Generated at 2022-06-25 04:55:51.359054
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    dict_0 = {}
    block_0 = Block(dict_0)
    data_0 = ''
    dict_1 = block_0.preprocess_data(data_0)
    return dict_1


# Generated at 2022-06-25 04:55:54.667673
# Unit test for method copy of class Block
def test_Block_copy():
    dict_0 = None
    block_0 = Block(dict_0)
    block_1 = block_0.copy()


# Generated at 2022-06-25 04:56:01.036423
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    play_0 = Play.load(dict(name='foo', hosts=['all'], gather_facts='no'), loader=None)
    block_0 = Block(dict(block=[]), play=play_0)
    block_0.set_loader(None)


# Generated at 2022-06-25 04:56:03.934424
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():

    import ansible.playbook.block
    blockObj = ansible.playbook.block.Block(block_data=None)
    blockObj.has_tasks()


# Generated at 2022-06-25 04:56:07.002894
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    dict_0 = None
    block_0 = Block(dict_0)
    dict_0 = {}
    all_vars = dict_0
    ret = block_0.filter_tagged_tasks(all_vars)
    assert(ret is not None)


# Generated at 2022-06-25 04:56:40.643481
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block(dep_chain=[], parent=None, role=None, use_handlers=True, use_handlers=True, name='name_0')
    assert block_0
    test_0 = block_0.copy()
    assert test_0
    assert test_0.parent is None
    assert test_0.dep_chain == []
    assert test_0.role is None
    assert not test_0.block
    assert not test_0.rescue
    assert not test_0.always


# Generated at 2022-06-25 04:56:46.000555
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    import pytest

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role

    block_0 = Block()
    block_0._play = Play()
    # Create a new variable context and set it to block_0._play.

    #pl_cont = PlayContext()
    #block_0._play._variable_manager = VariableManager(loader=None, inventory=None, use_vault=False)
    #block_0._play._variable_manager._fact_cache = dict()
    #block_0._play._variable_manager.extra_vars = dict()
    #block_0._play._variable_manager

# Generated at 2022-06-25 04:56:52.731873
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    block_0 = Block()
    value_1 = Sentinel
    block_0.block = value_1
    value_2 = Sentinel
    block_0.rescue = value_2
    value_3 = Sentinel
    block_0.always = value_3
    value_4 = "test"
    block_0.always_run = value_4
    value_5 = Sentinel
    block_0._dep_chain = value_5
    value_6 = Sentinel
    block_0._role = value_6
    value_7 = Sentinel
    block_0._play = value_7
    value_8 = Sentinel
    block_0._parent = value_8
    value_9 = Sentinel
    block_0._use_handlers

# Generated at 2022-06-25 04:56:58.763892
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block_0 = Block()
    block_0.preprocess_data('hello')
    block_0.preprocess_data(['hello', 'world'])
    assert block_0._valid_attrs['block'].implicit


# Generated at 2022-06-25 04:57:04.398067
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_1 = Block()
    block_2 = Block()

    task_0 = Task()
    task_1 = Task()
    task_2 = Task()
    task_3 = Task()
    task_4 = Task()

    block_1.block = [task_0, task_1]
    assert block_1.has_tasks()

    block_2.rescue = [task_2, task_3]
    assert block_2.has_tasks()

    block_2.always = [task_4]
    assert block_2.has_tasks()


# Generated at 2022-06-25 04:57:10.176648
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # A test for the scenario:
    # only_tags:
    #   - tag_1
    #   - tag_2
    #   - tag_3
    # skip_tags:
    #   - tag_4
    #   - tag_5
    #   - tag_6

    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    def generate_block_with_tags(tags=None, block_id=''):
        block = Block()

# Generated at 2022-06-25 04:57:12.120773
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    if (block_0.all_parents_static() != True):
        raise AssertionError()


# Generated at 2022-06-25 04:57:21.656740
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    P = AnsibleParser(loader=DataLoader())
    block_0 = Block()
    block_0.tags = ['all', 'test_0']
    block_0.block = []
    task_0 = Task()
    task_0.action = 'pause'
    task_0.tags = ['test_1']
    task_0.block = []
    block_0.block.append(task_0)
    block_0.filter_tagged_tasks(None)

    block_1 = Block()
    block_1.tags = ['test_2']
    block_1.block = []
    task_1 = Task()
    task_1.action = 'pause'
    task_1.tags = ['all', 'test_3']
    task_1.block = []
    block_1.block.append

# Generated at 2022-06-25 04:57:28.599380
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # Test for tasks
    block_1 = Block()
    data_1 = {'block': [{'action': 'setup'}]}
    res_1 = block_1.preprocess_data(data_1)
    assert data_1 == res_1
    data_2 = [{'action': 'setup'}]
    res_2 = block_1.preprocess_data(data_2)
    assert res_2['block'] == data_2
    data_3 = {'block': [{'action': 'setup'}], 'when': 'True'}
    res_3 = block_1.preprocess_data(data_3)
    assert data_3 == res_3
    data_4 = [{'action': 'setup'}, {'action': 'copy'}]
    res_4 = block_1

# Generated at 2022-06-25 04:57:31.657854
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    parent = Host()
    block = Block(parent = parent)
    result = block.get_dep_chain()
    assert result == [parent]

if __name__ == "__main__":
    test_case_0()
    test_Block_get_dep_chain()

# Generated at 2022-06-25 04:57:48.956917
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    raise Exception('Not implemented')


# Generated at 2022-06-25 04:57:55.280159
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block(name='block0')
    yaml = '''
    name: block0
    block:
    - name: task0
    rescue:
    - name: task1
    always:
    - name: task2'''
    block_0.deserialize(yaml)
    assert type(block_0) == Block
    assert block_0.name == 'block0'
    assert len(block_0.block) == 1
    assert block_0.block[0].name == 'task0'
    assert len(block_0.rescue) == 1
    assert block_0.rescue[0].name == 'task1'
    assert len(block_0.always) == 1
    assert block_0.always[0].name == 'task2'


# Generated at 2022-06-25 04:57:58.745888
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    dep_chain_0 = block_0.get_dep_chain()
    print(dep_chain_0)


# Generated at 2022-06-25 04:58:03.276667
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_1 = Block()
    block_1.block = [
        Block(),
        Block(),
        Block(),
        ]
    block_1.rescue = [
        Block(),
        Block(),
        Block(),
        ]
    block_1.always = [
        Block(),
        Block(),
        Block(),
        ]

    assert block_1.has_tasks()

    block_2 = Block()
    assert not block_2.has_tasks()


# Generated at 2022-06-25 04:58:15.359840
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create test object Block
    block_0 = Block()
    # Call method 'filter_tagged_tasks'
    test_list = [
        Block(only_tags=['tag2']),
        Block(only_tags=['tag1']),
        Block()
    ]
    actual = block_0.filter_tagged_tasks(test_list)
    expected = [
        Block(only_tags=['tag2']),
        Block(),
        Block(),
    ]
    assertEquals(actual, expected)
    # Call method 'filter_tagged_tasks'
    test_list = [
        Block(only_tags=['tag1']),
        Block(only_tags=['tag2']),
        Block()
    ]

# Generated at 2022-06-25 04:58:16.439757
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    block_0.all_parents_static()


# Generated at 2022-06-25 04:58:18.242384
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    test_case_0()


# Generated at 2022-06-25 04:58:24.583396
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    # Get the copy of the block object
    block_copy_0 = block_0.copy(exclude_parent=True)
    assert(block_copy_0.block == [])
    assert(block_copy_0.rescue == [])
    assert(block_copy_0.always == [])
    # Test the method encloses

    tasks_0 = [
        {
            'debug': 'msg=debug1'
        },
        {
            'debug': 'msg=debug2'
        }
    ]

    block_0 = Block.load(tasks_0)
    # Get the copy of the block object
    block_copy_0 = block_0.copy(exclude_parent=True)
    assert(block_copy_0.block == block_0.block)
   

# Generated at 2022-06-25 04:58:31.858530
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    obj = block_0.copy(exclude_parent=False, exclude_tasks=False)
    assert obj.dep_chain == None
    assert obj._loader == None
    assert not obj._static
    assert obj._use_handlers
    assert not obj._implicit
    assert not obj._parent
    assert not obj._play
    assert not obj._role
    assert obj.always == []
    assert obj.block == []
    assert obj.rescue == []


# Generated at 2022-06-25 04:58:40.965310
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0._parent = 'foo'
    block_0._valid_attrs = {'foo':'bar'}
    block_0._attributes = {'foo':{'bar':'foobar'}}
    block_0.block = ['foo', 'bar']
    block_0.rescue = ['foo', 'bar']
    block_0.always = ['foo', 'bar']
    block_0._role = 'foo'
    block_0.role = 'foo'
    block_0.dep_chain = ['foo', 'bar']
    block_0.dep_chain = ['foo', 'bar']
    block_0.dep_chain = ['foo', 'bar']
    block_0.dep_chain = ['foo', 'bar']

# Generated at 2022-06-25 04:59:13.450491
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()

# Generated at 2022-06-25 04:59:18.381353
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Test case 0
    block_0 = Block()
    loader_0 = DataLoader()
    block_0.set_loader(loader_0)

    with pytest.raises(Exception) as excinfo:
        block_0.set_loader(loader_0)
    assert excinfo.value.args[0] == "unsupported operand type(s) for &=: 'dict' and 'dict'"

# Generated at 2022-06-25 04:59:23.036979
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_1 = Block()
    if block_1.all_parents_static() != True:
        print("ERROR: block_1.all_parents_static()")


# Generated at 2022-06-25 04:59:24.447540
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # block_0 is a Block object
    block_0 = Block()

# Generated at 2022-06-25 04:59:25.540024
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    assert block_0.has_tasks() == False


# Generated at 2022-06-25 04:59:27.429390
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    assert block_0.all_parents_static() == True


# Generated at 2022-06-25 04:59:36.317835
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    flag_0 = block_0.has_tasks()
    print(flag_0)
    block_0.block = []
    flag_1 = block_0.has_tasks()
    print(flag_1)
    block_0.rescue = []
    flag_2 = block_0.has_tasks()
    print(flag_2)
    block_0.always = []
    flag_3 = block_0.has_tasks()
    print(flag_3)


# Generated at 2022-06-25 04:59:38.257826
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    block_0.set_loader(None)


# Generated at 2022-06-25 04:59:42.800344
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    raises(Exception, block_0.deserialize, "/srv/vars/foo.json")


# Generated at 2022-06-25 04:59:47.289491
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    block_0.set_loader()
    return True


# Generated at 2022-06-25 05:00:18.069356
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    play_0 = Play().load({'name': 'woot', 'hosts': 'all'}, variable_manager=VariableManager(), loader=DataLoader())
    task_0 = Block()
    task_0._play = play_0
    block_0._parent = task_0
    task_1 = Task().load({'action': {'__ansible_module__': 'debug'}}, variable_manager=VariableManager(), loader=DataLoader())
    block_0.block = [task_1]
    task_2 = Task().load({'action': {'__ansible_module__': 'debug'}}, variable_manager=VariableManager(), loader=DataLoader())
    task_1._parent = task_2

# Generated at 2022-06-25 05:00:21.334327
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_1 = Block()
    assert block_1.has_tasks() == False
    block_2 = Block(blocks=["no task"], handlers=[], rescue=[])
    assert block_2.has_tasks() == True


# Generated at 2022-06-25 05:00:24.212701
# Unit test for method copy of class Block
def test_Block_copy():
    '''
    Test copy() method of Block.
    '''
    block_0 = Block()
    # Test that copy() returns different object.
    assert block_0.copy() != block_0


# Generated at 2022-06-25 05:00:27.638908
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    try:
        block_0 = Block()
        assert block_0 == None
    except Exception:
        import traceback
        print("Caught exception in test_Block_deserialize(): %s" % traceback.format_exc())
        return False
    
    return True


# Generated at 2022-06-25 05:00:34.381948
# Unit test for method copy of class Block
def test_Block_copy():
    """
    Test for method copy of class Block
    """
    block_copy = Block.load(dict(block=[dict(task=dict(name='test', module_name='debug'))]), use_handlers=True)
    parent_copy = Block.load(dict(block=[dict(task=dict(name='test', module_name='debug'))]), use_handlers=True)
    task_copy = Block.load(dict(task=dict(name='test', module_name='debug')), use_handlers=True)
    parent_copy.block = [task_copy]

    block = Block()
    block.block = [Block.load(dict(block=[dict(task=dict(name='test', module_name='debug'))]), use_handlers=True)]
    block.rescue = []

# Generated at 2022-06-25 05:00:36.110674
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():

    # Create a block
    block_1 = Block()

    # Test all_parents_static
    assert(block_1.all_parents_static() is True)


# Generated at 2022-06-25 05:00:37.243261
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    if test_case_0():
        pass


# Generated at 2022-06-25 05:00:40.561878
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_1 = Block()
    result = block_1.all_parents_static()
    assert result == True


# Generated at 2022-06-25 05:00:43.388160
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    test_Block_deserialize0()
    test_Block_deserialize1()
    test_Block_deserialize2()
    test_Block_deserialize3()
    test_Block_deserialize4()


# Generated at 2022-06-25 05:00:45.894970
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Just check the method can be called
    block_0 = Block()
    block_0.set_loader('fake_loader')

# Generated at 2022-06-25 05:01:30.505347
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    dep_chain_1 = block_0.get_dep_chain()
    if dep_chain_1 is not None:
        assert isinstance(dep_chain_1, list)


# Generated at 2022-06-25 05:01:34.816473
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block = Block()
    assert block.all_parents_static() is True


# Generated at 2022-06-25 05:01:37.974324
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # Test args, kwargs
    (block, data) = (Block(), dict())

    block.deserialize(data)

    assert True is True # TODO: implement your test here


# Generated at 2022-06-25 05:01:41.041952
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_1 = Block()

    assert(block_1.filter_tagged_tasks(all_vars) == block_1)


# Generated at 2022-06-25 05:01:52.337582
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()
    assert block_0.dep_chain == block_1.dep_chain
    assert block_0.block == block_1.block
    assert block_0.rescue == block_1.rescue
    assert block_0.always == block_1.always
    assert block_0.name == block_1.name
    assert block_0.when == block_1.when
    assert block_0.register == block_1.register
    assert block_0.conditional == block_1.conditional
    assert block_0._role == block_1._role
    assert block_0.tags == block_1.tags
    assert block_0.loop == block_1.loop
    assert block_0._play == block_1._play
    assert block

# Generated at 2022-06-25 05:01:55.478846
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    data = dict(block=['test'],
            rescue=['test'],
            always=['test'],
            role=dict(name='test'),
            )
    block_0 = Block()
    block_0.deserialize(data)


# Generated at 2022-06-25 05:01:57.995143
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    pass


# Generated at 2022-06-25 05:01:59.652774
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    block_0.get_first_parent_include()


# Generated at 2022-06-25 05:02:01.368749
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    block_1 = block_0.filter_tagged_tasks(all_vars={})


# Generated at 2022-06-25 05:02:06.089156
# Unit test for method copy of class Block
def test_Block_copy():
    print('Testing method copy of class Block')
    block_0 = Block()
    block_0.name = 'test1'
    block_1 = block_0.copy()
    if not block_1.name == block_0.name:
        print('Copy method of Block was unsuccessful in coping the name attribute')
        return False
    else:
        return True
