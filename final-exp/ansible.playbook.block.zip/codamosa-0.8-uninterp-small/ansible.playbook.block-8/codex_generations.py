

# Generated at 2022-06-25 04:53:46.973915
# Unit test for method copy of class Block
def test_Block_copy():

    # Constructor test
    assert(str(Block()) != None)


# Generated at 2022-06-25 04:53:56.942456
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    complex_0 = None
    block_0 = Block()
    # start test with a valid block

# Generated at 2022-06-25 04:54:01.983740
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    complex_0 = None
    block_0 = Block()
    assert block_0.get_dep_chain() == None


# Generated at 2022-06-25 04:54:05.842791
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    """
    This test case is to ensure that method has_tasks of class Block is working as expected
    """
    block_0 = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=True)
    complex_0 = block_0.has_tasks()
    assert complex_0 == False


# Generated at 2022-06-25 04:54:10.253234
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    complex_0 = None
    block_0 = Block()
    block_0.block = list()
    c = block_0.has_tasks()
    if c:
        print("has_tasks returned True")
    else:
        print("has_tasks returned False")
    assert c == False
    block_0.block.append(block_0)
    c = block_0.has_tasks()
    if c:
        print("has_tasks returned True")
    else:
        print("has_tasks returned False")
    assert c == True


# Generated at 2022-06-25 04:54:21.139342
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block(complex_0) == False
    assert Block.is_block(block_0) == False
    assert Block.is_block(complex_1) == True
    assert Block.is_block(block_1) == True
    assert Block.is_block(complex_3) == True
    assert Block.is_block(block_3) == True
    assert Block.is_block(complex_4) == True
    assert Block.is_block(block_4) == True
    assert Block.is_block(complex_5) == True
    assert Block.is_block(block_5) == True
    assert Block.is_block(complex_6) == True
    assert Block.is_block(block_6) == True
    assert Block.is_block(complex_7) == True

# Generated at 2022-06-25 04:54:23.150083
# Unit test for method copy of class Block
def test_Block_copy():
    complex_0 = None
    block_0 = Block()

    assert block_0.copy() is not block_0


# Generated at 2022-06-25 04:54:26.522648
# Unit test for method is_block of class Block
def test_Block_is_block():
    print('>>> Test(Block, is_block())')
    complex_0 = None
    block_0 = Block()
    try:
        block_0.is_block()
        print('>>> PASSED')
    except Exception as err:
        print('>>> FAILED:')
        print(err)


# Generated at 2022-06-25 04:54:28.536017
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    complex_0 = None
    block_0 = Block()
    var_0 = (vars(block_0))
    return block_0.filter_tagged_tasks(var_0)


# Generated at 2022-06-25 04:54:36.844390
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    complex_0 = None
    block_0 = Block()
    all_vars_0 = None
    # get the value of the input parameters
    all_vars_0 = {}
    try:
        out_0 = block_0.filter_tagged_tasks(all_vars_0)
    except Exception as exception:
        print("Unexpected exception: ", type(exception))
        print("Unexpected exception: ", exception)
        exit(1)


# Generated at 2022-06-25 04:55:14.539360
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    test_Block_all_parents_static.__doc__ = '''
        Testcase for all_parents_static method of Block class.
        '''
    block_0 = Block(implicit=True)
    assert(block_0.all_parents_static())
    block_1 = Block(implicit=True)
    block_0 = Block(implicit=True)
    block_0._parent = block_1
    assert(block_0.all_parents_static())


# Generated at 2022-06-25 04:55:20.052946
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    # Tests for when the _parent is not a TaskInclude
    #_parent is None

# Generated at 2022-06-25 04:55:30.001341
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block({
        'block': ['block1'],
        'rescue': ['rescue1'],
        'always': ['always1'],
    }) == True
    assert Block.is_block({
        'block': 'block1',
        'rescue': 'rescue1',
        'always': 'always1',
    }) == True
    assert Block.is_block({
        'block': ['block1'],
        'rescue': ['rescue1'],
    }) == True
    assert Block.is_block({
        'block': ['block1'],
        'always': ['always1'],
    }) == True
    assert Block.is_block({
        'block': ['block1'],
    }) == True

# Generated at 2022-06-25 04:55:32.259377
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():

    block_0 = Block()
    block_popped = block_0.filter_tagged_tasks([])

    assert block_0 == block_popped, "Error in filter_tagged_tasks function"

# Generated at 2022-06-25 04:55:37.953528
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_1 = Block(parent_block=None, task_include=None)
    assert block_1.get_dep_chain() is None


# Generated at 2022-06-25 04:55:41.772794
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    test_case_0()


# Generated at 2022-06-25 04:55:44.579562
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():

    # Initialize a Block object
    block = Block()

    # Test has_tasks for an empty Block where block has no tasks
    task_list = block.has_tasks()
    assert task_list == False






# Generated at 2022-06-25 04:55:46.678264
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    '''
    Test for Ansible module Block
    '''
    # Test for filter_tagged_tasks
    # Create a block and call filter_tagged_tasks method on it.
    block = Block()
    block.filter_tagged_tasks({})


# Generated at 2022-06-25 04:55:48.823457
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()

    assert block_0.copy() is not None


# Generated at 2022-06-25 04:55:58.929541
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()

    def _dupe_task_list(task_list, new_block):
        new_task_list = []
        for task in task_list:
            new_task = task.copy(exclude_parent=True)
            if task._parent:
                new_task._parent = task._parent.copy(exclude_tasks=True)
                if task._parent == new_block:
                    # If task._parent is the same as new_block, just replace it
                    new_task._parent = new_block
                else:
                    # task may not be a direct child of new_block, search for the correct place to insert new_block
                    cur_obj = new_task._parent
                    while cur_obj._parent and cur_obj._parent != new_block:
                        cur_obj = cur_obj._parent



# Generated at 2022-06-25 04:56:12.508292
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    loader_0 = data_loader.DataLoader()
    block_0.set_loader(loader_0)


# Generated at 2022-06-25 04:56:15.419270
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():

    # Create a test block
    block_0 = Block()

    # Create vars
    all_vars = {}

    # Call method filter_tagged_tasks
    res_0 = block_0.filter_tagged_tasks(all_vars)

    # Assertions
    # !AssertionError: 'Block' object has no attribute 'get_first_parent_include'
    #assert res_0.get_first_parent_include() == None


# Generated at 2022-06-25 04:56:23.804441
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role_include import RoleInclude

    # Test Case 0
    # A Block with no parent.
    # Expected Results: True
    block_0 = Block()
    assert block_0.all_parents_static() is True

    # Test Case 1
    # A Block with a statically loaded Block parent.
    # Expected Results: True
    block_0 = Block()
    block_1 = Block()
    block_1._parent = block_0
    assert block_1.all_parents_

# Generated at 2022-06-25 04:56:29.164673
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block({'block':[ {'name':'test_1'} ]}) == True, "method is_block of class Block failed: expected True, got False for {'block':[ {'name':'test_1'} ]}"
    assert Block.is_block({'rescue':[ {'name':'test_1'} ]}) == True, "method is_block of class Block failed: expected True, got False for {'rescue':[ {'name':'test_1'} ]}"
    assert Block.is_block({'always':[ {'name':'test_1'} ]}) == True, "method is_block of class Block failed: expected True, got False for {'always':[ {'name':'test_1'} ]}"

# Generated at 2022-06-25 04:56:34.740302
# Unit test for method is_block of class Block
def test_Block_is_block():
    block_0 = Block()
    data_0 = {u'block': [{u'local_action': {u'module': u'win_command', u'args': {u'_raw_params': u'type C:\\Windows\\System32\\Drivers\\etc\\hosts'}}}]}
    retval_0 = Block.is_block(data_0)
    # The return value is of type bool
    assert isinstance(retval_0, bool)



# Generated at 2022-06-25 04:56:39.867631
# Unit test for method is_block of class Block
def test_Block_is_block():
    block_0 = Block()
    assert True == Block.is_block(block_0)
    assert True == Block.is_block([])
    assert False == Block.is_block(None)


# Generated at 2022-06-25 04:56:40.921047
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()



# Generated at 2022-06-25 04:56:41.909244
# Unit test for method copy of class Block
def test_Block_copy():
    block_1 = Block()


# Generated at 2022-06-25 04:56:43.664334
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # Values
    data_0 = 'data_0'
    block_0 = Block()

    # Invoke method
    block_0.deserialize(data_0)


# Generated at 2022-06-25 04:56:45.995703
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    loader = DataLoader()
    block.set_loader(loader)
    assert block._loader == loader, 'Block.set_loader not working'


# Generated at 2022-06-25 04:57:09.932953
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    actual = block_0.all_parents_static()
    expected = True
    assert actual == expected


# Generated at 2022-06-25 04:57:11.703057
# Unit test for method copy of class Block
def test_Block_copy():
    try:
        test_1_copy_result = test_1.copy()
    except Exception:
        assert False, "An exception occurred!"
    else:
        assert True


# Generated at 2022-06-25 04:57:20.078119
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Test Block with no parents
    block_0 = Block()
    assert block_0.get_dep_chain() is None

    # Test Block with different parent types
    block_1 = Block(parent_block=Block(parent_block=Block()))
    assert len(block_1.get_dep_chain()) == 2

    # Test Block with no dep_chain
    block_2 = Block(dep_chain=None)
    assert block_2.get_dep_chain() is None


# Generated at 2022-06-25 04:57:23.259297
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    assert block_0.all_parents_static() == True, "Unit test for Block.all_parents_static() has failed!"
    return


# Generated at 2022-06-25 04:57:32.162971
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Implicit block
    block_0 = Block()
    block_0.block = [
        ActionModule(action='setup')
        ]
    # Implicit block
    block_1 = Block()
    block_1.block = [
        ActionModule(action='setup')
        ]
    # Implicit block
    block_2 = Block()
    block_2.block = [
        ActionModule(action='setup')
        ]
    # Implicit block
    block_3 = Block()
    block_3.block = [
        ActionModule(action='setup')
        ]
    # Implicit block
    block_4 = Block()
    block_4.block = [
        ActionModule(action='setup')
        ]
    # Implicit block
    block_5 = Block()

# Generated at 2022-06-25 04:57:35.389104
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Test with no arguments
    block_0 = Block()
    assert block_0.set_loader() is None


# Generated at 2022-06-25 04:57:38.525402
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    loader = DataLoader()
    block_0 = Block()
    block_0.set_loader(loader)


# Generated at 2022-06-25 04:57:40.046570
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({})


# Generated at 2022-06-25 04:57:49.514724
# Unit test for method deserialize of class Block
def test_Block_deserialize():

    block_0 = Block()
    block_1 = Block()
    block_2 = Block()

    # Block.deserialize
    try:
        block_1.deserialize(block_0)
    except Exception as exc:
        assert False, f"Exception raised: {exc}"
    else:
        assert True, "No exception was raised"
    assert block_1 is not block_0, "Block.deserialize: Failed to set value of instance attribute"


# Generated at 2022-06-25 04:57:52.659621
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    block_0.get_first_parent_include()

    # test for multiple variable declarations
    result = block_0.get_first_parent_include()
    assert(type(result) == type(None))

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 04:58:21.507089
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    print('')
    print('Testing method has_tasks from class Block')
    block_0 = Block()
    task_0 = Task()
    block_1 = Block()
    block_1.block.append(task_0)
    block_2 = Block()
    task_1 = Task()
    block_2.block.append(task_1)
    block_2.rescue.append(task_0)
    block_3 = Block()
    block_3.always.append(task_1)
    block_3.always.append(task_0)
    print('has_tasks(block_0) = %s' % block_0.has_tasks())
    print('has_tasks(block_1) = %s' % block_1.has_tasks())

# Generated at 2022-06-25 04:58:25.023406
# Unit test for method set_loader of class Block
def test_Block_set_loader():

    # test case #1:
    # test 'block_0' is created as an instance of Block class
    test_case_0()
    # assign the block_0 to block
    block = block_0
    # call set_loader of Block class
    block.set_loader(None)
    return


# Generated at 2022-06-25 04:58:30.950448
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block_0 = Block()

    block_0.preprocess_data(dict(block=[
                                dict(action='some action', other_attribute='some value'),
                                dict(action='other action', some_attribute='some value')
                                ]))
    
    assert len(block_0.block) == 2


# Generated at 2022-06-25 04:58:35.776701
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    all_vars = {}
    r = block_0.filter_tagged_tasks(all_vars)
    assert r is not None


# Generated at 2022-06-25 04:58:38.045191
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    deserialize_0 = None
    assert block_0.deserialize(deserialize_0) == None, 'Test is fail'


# Generated at 2022-06-25 04:58:41.382792
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    assert block_0.has_tasks() == 0


# Generated at 2022-06-25 04:58:42.852091
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()


# Generated at 2022-06-25 04:58:52.896129
# Unit test for method is_block of class Block
def test_Block_is_block():

    # verify that Block.is_block() returns True when the caller is of dict type
    # and has the correct keywords
    assert Block.is_block({'block': ['blah']}) == True
    assert Block.is_block({'rescue': ['blah']}) == True
    assert Block.is_block({'always': ['blah']}) == True
    assert Block.is_block({'block': ['blah'], 'rescue': ['blah'], 'always': ['blah']}) == True

    # verify that Block.is_block() returns False when the caller is not of dict type
    assert Block.is_block(['blah']) == False

    # verify that Block.is_block() returns False when the caller is of dict type
    # but does not have the correct keywords

# Generated at 2022-06-25 04:58:58.812615
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Input data
    exp_skip_tags = ['skip1', 'skip2']
    exp_only_tags = ['only1', 'only2']
    exp_all_vars  = {'name1': 'value1', 'name2': ['list_value2']}
    exp_included_tasks = ['block0']

    # Prepare expected data
    exp_data = dict()
    exp_data['block'] = exp_included_tasks
    exp_data['rescue'] = []
    exp_data['always'] = []

    # Prepare input data
    block_0 = Block()
    block_0.block  = [exp_included_tasks]
    block_0.rescue = []
    block_0.always = []
    block_0._play  = Mock(spec=Play)
   

# Generated at 2022-06-25 04:59:08.152199
# Unit test for method deserialize of class Block

# Generated at 2022-06-25 04:59:37.166351
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    import ansible.errors
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

    # Block object
    block_0 = Block()

    assert block_0.filter_tagged_tasks([]) is not None
    assert type(block_0) is Block


# Generated at 2022-06-25 04:59:45.078654
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    assert not block_0.has_tasks()

    block_0.block = [Task(), Task(), Task()]
    assert block_0.has_tasks()

    block_0.rescue = [Task(), Task(), Task()]
    assert block_0.has_tasks()

    block_0.always = [Task(), Task(), Task()]
    assert block_0.has_tasks()

# Generated at 2022-06-25 04:59:50.161848
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook import Play, Task
    from ansible.playbook.handler import Handler
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.inventory import Inventory

    task_include0 = TaskInclude()
    task_include1 = TaskInclude()
    task_include2 = TaskInclude()
    task1 = Task()
    task2 = Task()
    task3 = Task()
    task4 = Task()
    block1 = Block()
    block2 = Block()
    handler = Handler()
    play = Play()
    host = Host(name="hostname")
    group = Group(name="groupname")
    inventory = Inventory(host_list=[host])
    all_vars

# Generated at 2022-06-25 05:00:00.986694
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    if not unittest.source:
        unittest.source = Block.__module__

    loader = DictDataLoader({'foo': dict(block=[])})
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)

# Generated at 2022-06-25 05:00:06.444502
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Set up the mock loader
    loader = mock_loader()

    # Create a block to test with
    block = Block()

    # Call the set_loader method
    block.set_loader(loader)

    # Check the results
    assert block.set_loader(loader) == None


# Generated at 2022-06-25 05:00:18.029877
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [{'debug': 'msg="hello world"'}]
    block.rescue = [{'debug': 'msg="error world"'}]
    block.always = [{'debug': 'msg="goodbye world"'}]

    new_block_1 = block.copy()
    new_block_2 = block.copy(exclude_parent=True)
    new_block_3 = block.copy(exclude_tasks=True)
    new_block_4 = block.copy(exclude_parent=True, exclude_tasks=True)

    assert block.block == new_block_1.block
    assert block.rescue == new_block_1.rescue
    assert block.always == new_block_1.rescue
    assert block._parent == new_block_1._

# Generated at 2022-06-25 05:00:22.617478
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    all_vars = dict()
    # Call to filter_tagged_tasks of block_0
    new_block = block_0.filter_tagged_tasks(all_vars)


# Generated at 2022-06-25 05:00:29.997335
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    import ansible.constants as C

    play_context = PlayContext()
    play_0 = Play()
    block_0 = Block()

    # pass
    assert block_0.all_parents_static() == True

    block_0._parent = TaskInclude()
    block_0._parent._parent = TaskInclude()
    block_0._parent._parent._parent = TaskInclude()
    block_0._parent.st

# Generated at 2022-06-25 05:00:33.454088
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    expected = False
    actual = block_0.has_tasks()
    assert actual == expected, 'Expected: %s, Actual: %s' % (expected, actual)


# Generated at 2022-06-25 05:00:34.860828
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    answer = list()
    assert block_0.get_dep_chain() == answer, 'Block.get_dep_chain() failed'



# Generated at 2022-06-25 05:01:32.907733
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_0.copy()
    block_1 = Block(task_include=None)
    block_1.copy()
    block_2 = Block(implicit=False)
    block_2.copy()


# Generated at 2022-06-25 05:01:41.378631
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    ansible_0 = AnsibleModule()
    ansible_1 = AnsibleModule()
    block_0 = Block()
    block_0._loader = ansible_0
    block_0._role = Role()
    block_0._parent = Role()
    block_0._loader = ansible_1
    assert block_0._loader is ansible_1
    block_0._role.set_loader(ansible_1)
    assert block_0._role._loader is ansible_1
    block_0._parent._loader = ansible_0
    block_0.set_loader(ansible_1)
    assert block_0._parent._loader is ansible_1


# Generated at 2022-06-25 05:01:52.153234
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    ansible = Ansible()
    loader = DataLoader()
    variable_manager = VariableManager()
    db = None
    block_0 = Block.load(dict(name='test', block=[dict(name='test-subtask-1')]), play=None, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    block_0.deserialize({'role': {'_role_params': {}, '_role_name': 'test_role', '_task_blocks': []}, 'dep_chain': [], 'role_name': 'test_role'})
    assert block_0._role.name == 'test_role'
    assert block_0._dep_chain == []


# Generated at 2022-06-25 05:01:59.573437
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    block_1 = Block()
    block_2 = Block()
    block_3 = Block()
    block_4 = Block()
    block_5 = Block()
    block_6 = Block()
    block_7 = Block()
    block_8 = Block()
    block_9 = Block()
    block_10 = Block()
    block_11 = Block()
    block_12 = Block()
    block_13 = Block()
    block_14 = Block()
    block_15 = Block()
    block_16 = Block()
    block_17 = Block()
    block_18 = Block()
    block_19 = Block()
    block_20 = Block()
    block_21 = Block()
    block_22 = Block()
    block_23 = Block()
    block_24 = Block()

# Generated at 2022-06-25 05:02:05.259556
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block(parent_block=None, role=None, task_include=None, use_handlers=None, implicit=None)
    block_0_copy = block_0.copy()
    print("block_0_copy = " + str(block_0_copy))


# Generated at 2022-06-25 05:02:09.891295
# Unit test for method deserialize of class Block
def test_Block_deserialize():

    def test_case_0():
        b0 = Block()
        data = dict(
            name='Test',
        )
        b0.deserialize(data)
        assert b0.name == 'Test'

    def test_case_1():
        b0 = Block()

# Generated at 2022-06-25 05:02:15.366061
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():

    block_0 = Block()
    block_1 = Block()
    block_0.block = [block_1]
    block_1.block = [Task()]
    block_1.rescue = [Task()]
    block_1.always = [Task()]

    block_2 = block_0.filter_tagged_tasks({})
    assert block_2.block[0].block == block_1.block
    assert block_2.block[0].rescue == block_1.rescue
    assert block_2.block[0].always == block_1.always

    block_2.block[0].block[0].tags = ['not_skip']
    block_2.block[0].rescue[0].tags = ['not_skip']

# Generated at 2022-06-25 05:02:16.493274
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    print(block_0.has_tasks())

test_Block_has_tasks()

# Generated at 2022-06-25 05:02:26.953101
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    ds = dict(
        handlers=["ok"],
        rescue=None,
        always=None
    )
    deps = Block.deserialize(ds)
    assert deps.handlers is not None
    assert deps.rescue is None
    assert deps.always is None

    ds = dict(
        handlers=None,
        rescue=["ok"],
        always=None
    )
    deps = Block.deserialize(ds)
    assert deps.handlers is None
    assert deps.rescue is not None
    assert deps.always is None

    ds = dict(
        handlers=None,
        rescue=None,
        always=["ok"]
    )
    deps = Block.deserialize(ds)
    assert deps.handlers is None

# Generated at 2022-06-25 05:02:30.500464
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    bool_0 = block_0.has_tasks()

    assert bool_0 == False
