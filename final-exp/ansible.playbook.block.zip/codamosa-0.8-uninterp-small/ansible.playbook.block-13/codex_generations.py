

# Generated at 2022-06-25 04:53:23.905154
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    assert True


# Generated at 2022-06-25 04:53:25.880305
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    all_vars_0 = block_0.get_vars()
    # AssertionError: expected exception was not raised


# Generated at 2022-06-25 04:53:29.858196
# Unit test for method copy of class Block
def test_Block_copy():
    '''
    Unit test for method copy
    '''
    block_0 = Block()
    block_1 = block_0.copy()
    assert not hasattr(block_1, '_debugger')
    assert block_1.has_tasks()
    assert not block_1.implicit
    assert isinstance(block_1, Block)

    block_2 = block_0.copy(exclude_parent=True, exclude_tasks=True)
    assert not hasattr(block_2, '_debugger')
    assert not block_2.has_tasks()
    assert not block_2.implicit
    assert isinstance(block_2, Block)


# Generated at 2022-06-25 04:53:36.527784
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    task_0 = ActionModule('setup')
    block_0 = Block()
    block_0.block = [task_0]
    task_1 = ActionModule('debug')
    block_0.rescue = [task_1]
    task_2 = ActionModule('debug')
    block_0.always = [task_2]
    block_1 = block_0.filter_tagged_tasks(None)

# Generated at 2022-06-25 04:53:37.808822
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    data_0 = {}
    block_0.deserialize(data_0)


# Generated at 2022-06-25 04:53:39.278868
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    all_vars_0 = dict()
    block_1 = block_0.filter_tagged_tasks(all_vars_0)


# Generated at 2022-06-25 04:53:41.813229
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # Setup
    block_0 = Block()
    data = dict()

    # Invocation
    try:
        block_0.deserialize(data)
    except:
        pass

    # Verification
    # No verification needed. An exception should have been raised
    # during the invocation. If no exception was raised, or if other
    # types of exceptions were raised, this test fails.


# Generated at 2022-06-25 04:53:47.133175
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    var_0 = block_0.has_tasks()


# Generated at 2022-06-25 04:53:57.042286
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = AnsibleLoader(None, variable_manager=VariableManager(), loader=DataLoader())


# Generated at 2022-06-25 04:53:59.400399
# Unit test for method is_block of class Block
def test_Block_is_block():
    block_0 = Block()
    block = None

# Generated at 2022-06-25 04:54:23.112654
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block_0 = Block()
    block_0.preprocess_data(block_0)
    block_0.preprocess_data(block_0)


# Generated at 2022-06-25 04:54:29.995797
# Unit test for method copy of class Block
def test_Block_copy():
    # Create empty block object
    block_0 = Block()

    # Call copy method of block_0 to copy the block_0
    block_1 = block_0.copy()

    # Check for exceptions for a None value for exclude_parent in copy method of block_0
    try:
        block_2 = block_0.copy(exclude_parent=None)
    except Exception as err:
        pass
    else:
        raise Exception('ExpectedTypeError not raised for None value for exclude_parent in copy method of block_0')

    # Check for exceptions for a None value for exclude_tasks in copy method of block_0
    try:
        block_3 = block_0.copy(exclude_tasks=None)
    except Exception as err:
        pass

# Generated at 2022-06-25 04:54:35.198461
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # This test case doesn't need a mock of class AnsiblePlaybook
    block = Block()
    all_vars = dict()
    filtered_block = block.filter_tagged_tasks(all_vars)
    assert filtered_block is not None


# Generated at 2022-06-25 04:54:37.551984
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    if block_0.has_tasks():
        raise Exception("Test failed")


# Generated at 2022-06-25 04:54:40.845209
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    block_0.set_loader('loader')


# Generated at 2022-06-25 04:54:43.139487
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()


# Generated at 2022-06-25 04:54:51.541778
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    load_vars = {
        'test_var_0': u'''"abcdef'""''',
        'test_var_1': u'''"abcdef'""''',
        'test_var_2': u'''"abcdef'""''',
        'test_var_3': u'''"abcdef'""'''
    }
    test_task_0 = AnsibleDummyActionModule(u'''pwd''', u'''pwd''', u'''pwd''', load_vars=load_vars)
    test_task_1 = AnsibleDummyActionModule(u'''pwd''', u'''pwd''', u'''pwd''', load_vars=load_vars)

# Generated at 2022-06-25 04:54:58.139462
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    block_0 = Block()
    block_0.implicit = False
    block_0.always = [{u'name': u'All tasks', u'include': u'all'}]
    block_0.block = [{u'name': u'Install Apache', u'apt': {u'name': u'apache2'}, u'when': u'"apache" in groups'}]
    block_0.rescue = []
    block_0.any_errors_fatal = None
    block_0.changed_when = None
    block_0.always_run = None
    block_0.when = None
    block_0.run_once = None
    block_0.notify = None
    block_0.delegate_to = None

# Generated at 2022-06-25 04:55:03.085767
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    var_0 = block_0.all_parents_static()


# Generated at 2022-06-25 04:55:08.207529
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    all_vars = dict()
    filtered_block = block_0.filter_tagged_tasks(all_vars)


# Generated at 2022-06-25 04:55:36.873019
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    block_0 = Block()
    block_0.block = [Task(), Task(), Task(), Task(), Task(), Task(), Task(), Task(), Task()]
    block_0.rescue = [Task(), Task(), Task(), Task(), Task(), Task(), Task()]
    block_0.always = [Task(), Task(), Task()]
    block_1 = block_0.filter_tagged_tasks({})
    assert block_1.block == []
    assert block_1.rescue == []
    assert block_1.always == []



# Generated at 2022-06-25 04:55:42.246737
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    dep_chain_0 = block_0.get_dep_chain()



# Generated at 2022-06-25 04:55:45.970228
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()
    assert block_1 != block_0
    assert block_0._use_handlers == block_1._use_handlers
    assert block_0._dep_chain == block_1._dep_chain
    assert block_0._parent == block_1._parent
    assert block_0._role == block_1._role


# Generated at 2022-06-25 04:55:50.644440
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    all_vars_0 = dict()

    tmp_list_0 = list()
    task_1 = Task()
    tmp_list_0.append(task_1)
    block_0.block = tmp_list_0

    result_0 = block_0.filter_tagged_tasks(all_vars_0)


# Generated at 2022-06-25 04:55:54.612093
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():

    # Setup
    block_0 = Block()

    # Test
    block_0.filter_tagged_tasks(None)


# Generated at 2022-06-25 04:56:01.132204
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    block_0_line_no = 0
    block_0_all_vars = dict()
    block_0_result = block_0.filter_tagged_tasks(block_0_all_vars)


# Generated at 2022-06-25 04:56:04.352292
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_parent = Block()
    block_child = Block()
    block_child._parent = block_parent
    test_ans = block_child.all_parents_static()
    return test_ans

test_ans = test_Block_all_parents_static()
if True:
    print("test_Block_all_parents_static(): " + str(test_ans))


# Generated at 2022-06-25 04:56:06.509926
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    flag_0 = block_0.all_parents_static() # Expecting True
    assert flag_0 == True


# Generated at 2022-06-25 04:56:16.866748
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import IncludeTask
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook import Play
    # Instantiate a block object to test
    block_0 = Block()

    # Add parent to the block
    block_1 = Block()

# Generated at 2022-06-25 04:56:27.474744
# Unit test for method is_block of class Block
def test_Block_is_block():
    b = Block()
    # verify is_block() method of class Block
    data = dict(
        block = dict(
            - host_a
        ),
        rescue = dict(
            - host_a
        ),
        always = dict(
            - host_a
        )
    )
    res = Block.is_block(data)
    assert res == True
    data = dict(
        block = dict(
            - host_a
        )
    )
    res = Block.is_block(data)
    assert res == True
    data = dict(
        rescue = dict(
            - host_a
        )
    )
    res = Block.is_block(data)
    assert res == True
    data = dict(
        always = dict(
            - host_a
        )
    )
   

# Generated at 2022-06-25 04:56:46.872910
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    dep_chain_0 = block_0.get_dep_chain()

    # check if the 2nd element of the returned dep_chain is an instance of Block
    # assert dep_chain_0[1].__class__.__name__ == u'Block'
    assert isinstance(dep_chain_0[1], Block)

    # check if the 3rd element of the returned dep_chain is an instance of Block
    # assert dep_chain_0[2].__class__.__name__ == u'Block'
    assert isinstance(dep_chain_0[2], Block)

    # check if the 1st element of the returned dep_chain is an instance of Block
    # assert dep_chain_0[0].__class__.__name__ == u'Block'

# Generated at 2022-06-25 04:56:56.227986
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()
    block_1.check_triggers('')
    block_2 = block_1.copy(True)
    block_0.check_triggers('')
    block_3 = block_0.copy(False)
    block_3.check_triggers('')
    block_4 = block_3.copy(True, True)
    block_4.check_triggers('')
    block_5 = block_4.copy(False, False)
    block_5.check_triggers('')


# Generated at 2022-06-25 04:56:57.204378
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    pass


# Generated at 2022-06-25 04:56:59.064077
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block_0 = Block()
    dep_chain_0 = block_0.get_dep_chain()


# Generated at 2022-06-25 04:57:01.575049
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    data = dict(
        attr1=1,
        attr2=2
    )
    role_data = dict()
    block_0.deserialize(data)


# Generated at 2022-06-25 04:57:02.394271
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    pass


# Generated at 2022-06-25 04:57:08.547269
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    # FIXME: Remove after Ansible 2.4 is released
    from ansible.playbook.play import Play

    var_manager = VariableManager()
    play_context = PlayContext()
    pass

    # FIXME: Remove after Ansible 2.4 is released
    # Arguments: play
    # Return: none
    # Return type: none
    pass

    # FIXME: Remove after Ansible 2.4 is released
    # Arguments: play
    # Return: none
    # Return type: none
    pass

    # FIXME: Remove after Ansible 2.4 is released
    # Arguments: play
    # Return: none
    # Return type: none


# Generated at 2022-06-25 04:57:16.684720
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    "Unit test of method filter_tagged_tasks of class Block"
    block_1 = Block()
    block_1._play = Play()
    block_1._play.only_tags = ['t1']
    block_1._play.skip_tags = ['t2']
    block_1._play._variable_manager = VariableManager()
    block_1._play._variable_manager._fact_cache = {u't1': [u't2'], u't2': [u't3'], u't3': u't4'}
    block_1.block = [Task()]
    block_1.block[0]._attributes = {u'with_items': [u'tag_T1_and_T2'], u'when': u'tag_T1_and_T2'}
    block_1.block

# Generated at 2022-06-25 04:57:24.648779
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block_0 = Block()
    res_0 = block_0.preprocess_data({'block': [{'action': 'debug', 'msg': 'block 1'}, {'action': 'debug', 'msg': 'block 2'}]})
    res_1 = block_0.preprocess_data({'action': 'debug', 'msg': 'block 1'})
    res_2 = block_0.preprocess_data({'action': {'debug': 'block 1'}})


# Generated at 2022-06-25 04:57:28.022847
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():

    # From /usr/local/lib/python2.7/dist-packages/ansible/playbook/block.py:176

    block_0 = Block()
    var_0 = block_0.get_dep_chain()



# Generated at 2022-06-25 04:57:42.485102
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    var_0 = block_0.set_loader(loader=None)


# Generated at 2022-06-25 04:57:50.305835
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    # test_value_0 will be passed as static to TaskOrBlockInclude
    test_value_0 = True
    test_value_1 = False
    task_0 = TaskInclude(test_value_0)
    task_1 = TaskInclude(test_value_1)
    result_0 = task_0.all_parents_static()
    result_1 = task_1.all_parents_static()
    assert result_0 == test_value_0
    assert result_1 == test_value_1


# Generated at 2022-06-25 04:57:51.597946
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    try:
        block_0.deserialize(str())
    except Exception as exc:
        print (exc)


# Generated at 2022-06-25 04:57:59.013595
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    #create a dummy parent object to prevent errors
    parent = EntityBase()
    parent.statically_loaded = True
    parent._attributes = dict()
    parent._type_validators = dict()
    parent._valid_attrs = dict()
    parent._parent = None
    parent.get_dep_chain = lambda: list()
    parent._loader = DictDataLoader()
    parent.set_loader = lambda x: None
    parent._variable_manager = VariableManager()
    parent._loader.set_basedir()
    parent.loader = parent._loader
    parent.variable_manager = parent._variable_manager
    parent._role = None

    #create a dummy role object to prevent errors
    role = Role()
    role.statically_loaded = True
    role._attributes = dict()
    role._type_validators = dict

# Generated at 2022-06-25 04:58:00.316185
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    block_0.set_loader(None)


# Generated at 2022-06-25 04:58:06.105295
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    vars_0 = dict()
    filtered_block_0 = block_0.filter_tagged_tasks(vars_0)
    # AssertionError: assert False



# Generated at 2022-06-25 04:58:16.529364
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

    play = Play()
    play.load({'name': 'something', 'hosts': 'somethingelse'})
    play_vars = play.get_variable_manager().get_vars(loader=None, play=play)

    def form_task(tags=[]):
        task = Task()
        task.action = 'something'
        task.args = {}
        task.tags = tags
        task._play = play
        task._role = None
        return task

    ## Tests for filter_tagged_tasks for basic tasks
    # No tags
    task = form_task()
    block = Block(block=[task])
    filtered_block = block.filter

# Generated at 2022-06-25 04:58:19.347261
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    try:
        test_case_0()
        print("Test #0 - all_parents_static (of class Block):  Success!")
    except (AssertionError) as e:
        print("Test #0 - all_parents_static (of class Block):  Fail.")
        print(e)
    except Exception as e:
        print("Test #0 - all_parents_static (of class Block):  Fail.")
        print(e)


# Generated at 2022-06-25 04:58:20.301602
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    try:
        test_case_0()
        return True
    except Exception as e:
        return False


# Generated at 2022-06-25 04:58:33.029639
# Unit test for method copy of class Block

# Generated at 2022-06-25 04:58:47.989877
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # self = Block()
    # data = dict()
    # self.deserialize(data)
    assert True



# Generated at 2022-06-25 04:58:53.393555
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()

# Generated at 2022-06-25 04:59:02.255779
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    """
    test_case_0:
        description:
            Test filter_tagged_tasks without block
        expect_result:
            The value of block is []
        setup:
            block_0 = Block()
            block_0.filter_tagged_tasks([])
    """
    block_0 = Block()
    var_0 = block_0.filter_tagged_tasks([])
    assert len(var_0.block) == 0, "block is not []"



# Generated at 2022-06-25 04:59:12.847949
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Save current values for attributes of class Block
    w_0 = Block.__dict__['_valid_attrs']

    # Initialize variable to store original values for attributes of class Block
    Block_w = dict()
    for attr_0 in w_0:
        Block_w[attr_0] = getattr(Block, attr_0)

    # Set attributes of class Block to new values
    Block.__dict__['_valid_attrs'] = dict()

    # Test original values of attributes
    block_0 = test_case_0()
    assert block_0.all_parents_static() == True

    # Set attributes of class Block to original values
    for attr_0 in Block_w:
        setattr(Block, attr_0, Block_w[attr_0])

test_case_0()

# Generated at 2022-06-25 04:59:21.292987
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    data_0 = {'role': {'name': 'role_0', 'path': '/home/pclouds/ansible_dir/roles/role_0'}, 'parent': {'play': 'play_0', 'block': ['handler_task_include_0', 'handler_task_0', 'include_task_0', 'task_include_0', 'task_0', 'task_1', 'task_2'], 'vars': {'var_0': 'value_0', 'var_1': 'value_1'}, 'dep_chain': ['role_0']}, 'parent_type': 'Block', 'dep_chain': ['role_0']}
    block_0.deserialize(data_0)


# Generated at 2022-06-25 04:59:26.761127
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Init a block and assign vars for assert
    block_0 = Block()
    # Condition 1:
    # verify assert: block_0.block is an empty list
    assert block_0.block == []

    # Condition 2:
    # verify assert: block_0.rescue is an empty list
    assert block_0.rescue == []

    # Condition 3:
    # verify assert: block_0.always is an empty list
    assert block_0.always == []

    # Case 0: all conditions are False
    # verify assert: block_0.has_tasks() is False 
    assert block_0.has_tasks() is False

    # Condition 1:
    # verify assert: block_0.block is not an empty list
    block_0.block.append(1)
    # Condition 2:
    #

# Generated at 2022-06-25 04:59:29.993597
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_0 = Block()
    data = dict()
    block_0.deserialize(data)


# Generated at 2022-06-25 04:59:32.502902
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    blk = Block()
    facts = dict()
    # assert_tagged_tasks(tagged_tasks, facts)


# Generated at 2022-06-25 04:59:37.010334
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    all_vars_0 = {}
    filter_tagged_tasks_0 = block_0.filter_tagged_tasks(all_vars_0)


# Generated at 2022-06-25 04:59:39.089575
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block = Block()
    if isinstance(block, Block):
        with pytest.raises(AttributeError) as excinfo:
             assert block.get_first_parent_include()


# Generated at 2022-06-25 04:59:54.628514
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    var_0 = block_0.filter_tagged_tasks()


# Generated at 2022-06-25 05:00:01.413806
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    block_0._play = None
    block_0._parent = None
    block_0.statically_loaded = None

    block_0._play = mock.MagicMock()
    m_block_0__play = mock.MagicMock()
    block_0._play.resolve_dynamic_imports = m_block_0__play.resolve_dynamic_imports
    m_block_0__play.return_value = False
    block_0._parent = mock.MagicMock()
    m_block_0__parent = mock.MagicMock()
    block_0._parent.all_parents_static = m_block_0__parent.all_parents_static
    m_block_0__parent.return_value = False

    block_0.statically_loaded = False

# Generated at 2022-06-25 05:00:03.042714
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    loader = { 'key' : 'value' }
    block_0.set_loader(loader)


# Generated at 2022-06-25 05:00:05.797678
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_0 = Block()
    bool_0 = block_0.all_parents_static()
    assert bool_0


# Generated at 2022-06-25 05:00:07.842705
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    # Assertion(False, block_0.filter_tagged_tasks(all_vars=[])==[])


# Generated at 2022-06-25 05:00:11.751508
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_1 = Block()
    block_2 = Block()
    block_2.block.append(block_1)
    block_3 = Block()
    block_3.block.append(block_2)
    block_3.filter_tagged_tasks()


# Generated at 2022-06-25 05:00:13.803127
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    y_0 = block_0.has_tasks()


# Generated at 2022-06-25 05:00:24.764145
# Unit test for method copy of class Block
def test_Block_copy():
    global name
    global src
    global dest
    global force
    global link
    global state
    global recurse
    global directory_mode
    global remote_src
    global validate
    global follow
    global unsafe_writes
    global content
    global encoding
    global content_type
    global owner
    global group
    global mode
    global selevel
    global serole
    global setype
    global seuser
    global unsafe_writes
    global become        # TODO: a future enhancement
    global become_user   # TODO: a future enhancement
    global become_method # TODO: a future enhancement


# Generated at 2022-06-25 05:00:27.529700
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_0 = Block()
    try:
        var_0 = block_0.get_first_parent_include()
    except:
        var_0 = None
    assert var_0 == None


# Generated at 2022-06-25 05:00:29.135826
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_1 = Block()
    loader_1 = DataLoader()
    block_1.set_loader(loader_1)


# Generated at 2022-06-25 05:01:06.163144
# Unit test for method copy of class Block
def test_Block_copy():
    block1 = Block(name = "foo")
    block1.load(load_example_file("basic.yml"))
    block2 = block1.copy()
    var_0 = block2._attributes
    var_1 = block2.name


# Generated at 2022-06-25 05:01:07.962713
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    block_1 = block_0.copy()


# Generated at 2022-06-25 05:01:09.755199
# Unit test for method copy of class Block
def test_Block_copy():
    block_0 = Block()
    var_0 = block_0.copy()


# Generated at 2022-06-25 05:01:19.735982
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # This is how we initialize a Block object
    block_1 = Block()
    # We can only filter the tasks if there are tasks, the following two are the
    # block attribute lists.
    block_1.block = []
    block_1.rescue = []
    block_1.always = []
    # Is there a way to skip the argument without providing some default value?
    # Don't know how to initialize a dict/list in our project.
    all_vars = {}
    # The second argument is passed by reference, but returned by value.
    # Why we didn't create a new Block object but got the reference of block_1?
    # Is the returned value a copy of block_1?
    assert block_1 is block_1.filter_tagged_tasks(all_vars)


# Generated at 2022-06-25 05:01:22.795268
# Unit test for method copy of class Block
def test_Block_copy():
    block_1 = Block()
    block_2 = block_1.copy()
    assert block_2.get_vars() == {}


# Generated at 2022-06-25 05:01:24.257004
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_0 = Block()
    loader_0 = DataLoader()
    block_0.set_loader(loader_0)


# Generated at 2022-06-25 05:01:27.311187
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()

    # NOTE: The code below is not usable, since the stub of
    # method evaluate_tags of class Task is empty. At
    # the moment, it is not possible to define stubs
    # with behavior, i.e., stubs with a non-empty body.
    block_1 = block_0.filter_tagged_tasks(all_vars = None)


# Generated at 2022-06-25 05:01:31.909792
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    # variable is a boolean value, if it is True, it will always true.
    var_0 = block_0.has_tasks()


# Generated at 2022-06-25 05:01:42.366068
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.play import PlayContext
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    ans_path = "/Users/muki/Develop/ansible/ansible/test/sanity/integration/targets/"
    ans_path = "/Users/muki/Develop/ansible/ansible/test/units/modules/network/"

    playbook_0 = Playbook().load(ans_path + "test_nxos_command.yml", variable_manager=None, loader=None)
    host_0

# Generated at 2022-06-25 05:01:50.968447
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    """
    Test method get_first_parent_include on Block
    """
    # Unit test for method get_first_parent_include of class Block
    from ansible.playbook.task_include import TaskInclude
    block_1 = Block()

    task_include_2 = TaskInclude()
    block_1.load_data([task_include_2])

    res_0 = block_1.get_first_parent_include()

    assert task_include_2.__class__.__name__ == res_0.__class__.__name__


# Generated at 2022-06-25 05:02:33.101931
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block_0 = Block()
    block_0.block = []
    block_0.rescue = []
    block_0.always = []
    var_0 = block_0.has_tasks()
    assert var_0 == False
    block_0.block = [task_0]
    var_1 = block_0.has_tasks()
    assert var_1 == True


# Generated at 2022-06-25 05:02:35.692558
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    block_1 = block_0.filter_tagged_tasks('[all_vars]')


# Generated at 2022-06-25 05:02:45.864491
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    test_block = Block()

    
    
    
    
    
    
    block_0 = Block()
    

    
    
    
    
    
    
    
    block_1 = Block()
    

    
    
    
    
    
    
    
    block_2 = Block()
    

    
    
    
    
    
    
    
    block_3 = Block()
    
    
    
    
    
    
    
    
    block_4 = Block()
    
    
    
    
    
    
    
    
    block_5 = Block()
    
    
    
    
    
    
    
    
    block_6 = Block()
    
    
    
    
    
    
    
    
    block_7 = Block()
    
    

# Generated at 2022-06-25 05:02:52.026937
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_0 = Block()
    block_0.block = []
    block_0.block.append(block_0)
    block_0.rescue = []
    block_0.rescue.append(block_0)
    block_0.always = []
    block_0.always.append(block_0)
    block_0.vars = {}
    block_0.register = []
    block_0.delegate_to = None
    block_0.delegate_facts = False
    block_0.run_once = False
    block_0.no_log = False
    block_0.any_errors_fatal = False
    block_0.always_run = False
    block_0.changed_when = None
    block_0.failed_when = None
    block_0.create_handler