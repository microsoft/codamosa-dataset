

# Generated at 2022-06-17 07:05:03.511941
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:05:09.642130
# Unit test for method serialize of class Block
def test_Block_serialize():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block

# Generated at 2022-06-17 07:05:11.121699
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    data = dict()
    block.deserialize(data)


# Generated at 2022-06-17 07:05:12.289261
# Unit test for method serialize of class Block
def test_Block_serialize():
    block = Block()
    block.serialize()


# Generated at 2022-06-17 07:05:26.463492
# Unit test for method is_block of class Block
def test_Block_is_block():
    block = Block()
    assert block.is_block(dict(block=[])) == True
    assert block.is_block(dict(rescue=[])) == True
    assert block.is_block(dict(always=[])) == True
    assert block.is_block(dict(block=[], rescue=[], always=[])) == True
    assert block.is_block(dict(block=[], rescue=[], always=[], foo=[])) == True
    assert block.is_block(dict(foo=[])) == False
    assert block.is_block([]) == False
    assert block.is_block(dict()) == False
    assert block.is_block(None) == False


# Generated at 2022-06-17 07:05:28.546991
# Unit test for method serialize of class Block
def test_Block_serialize():
    block = Block()
    block.serialize()


# Generated at 2022-06-17 07:05:40.099437
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a block with a parent
    block = Block()
    block._parent = Block()
    # Check that the method returns True
    assert block.all_parents_static()
    # Create a block with a parent that is not statically loaded
    block = Block()
    block._parent = Block()
    block._parent.statically_loaded = False
    # Check that the method returns False
    assert not block.all_parents_static()
    # Create a block with a parent that is a TaskInclude
    block = Block()
    block._parent = TaskInclude()
    # Check that the method returns True
    assert block.all_parents_static()
    # Create a block with a parent that is a TaskInclude that is not statically loaded
    block = Block()
    block._parent = TaskInclude()
    block._parent.statically_

# Generated at 2022-06-17 07:05:51.516544
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b.block = [1, 2, 3]
    b.rescue = [4, 5, 6]
    b.always = [7, 8, 9]
    b.dep_chain = [1, 2, 3]
    b.role = Role()
    b.role.name = 'test'
    b.role.path = 'test'
    b.role.default_vars = {'test': 'test'}
    b.role.tasks = [1, 2, 3]
    b.role.handlers = [4, 5, 6]
    b.role.meta = {'test': 'test'}
    b.role.vars = {'test': 'test'}
    b.role.default_vars = {'test': 'test'}

# Generated at 2022-06-17 07:06:01.057492
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a block with a task list
    block = Block()

# Generated at 2022-06-17 07:06:03.388644
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:07:11.820585
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = [4,5,6]
    assert block.has_tasks() == True
    block.always = [7,8,9]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:07:19.512989
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a block object
    block = Block()
    # Create a task object
    task = Task()
    # Create a task include object
    task_include = TaskInclude()
    # Create a block object
    block1 = Block()
    # Create a block object
    block2 = Block()
    # Create a block object
    block3 = Block()
    # Create a block object
    block4 = Block()
    # Create a block object
    block5 = Block()
    # Create a block object
    block6 = Block()
    # Create a block object
    block7 = Block()
    # Create a block object
    block8 = Block()
    # Create a block object
    block9 = Block()
    # Create a block object
    block10 = Block()
    # Create a block object
    block11 = Block()
   

# Generated at 2022-06-17 07:07:26.567668
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:07:30.814343
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'always': [], 'block': [], 'dep_chain': [], 'rescue': []})
    assert block.always == []
    assert block.block == []
    assert block.dep_chain == []
    assert block.rescue == []


# Generated at 2022-06-17 07:07:38.938463
# Unit test for method is_block of class Block
def test_Block_is_block():
    # Test with a dict
    data = {'block': [{'name': 'test'}]}
    assert Block.is_block(data) == True

    # Test with a list
    data = [{'name': 'test'}]
    assert Block.is_block(data) == False

    # Test with a string
    data = 'test'
    assert Block.is_block(data) == False


# Generated at 2022-06-17 07:07:40.305504
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    loader = DataLoader()
    block.set_loader(loader)
    assert block._loader == loader


# Generated at 2022-06-17 07:07:46.437514
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

# Generated at 2022-06-17 07:07:57.867486
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 07:08:07.613453
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.errors import AnsibleParserError
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_

# Generated at 2022-06-17 07:08:11.499927
# Unit test for method serialize of class Block
def test_Block_serialize():
    block = Block()
    block.serialize()


# Generated at 2022-06-17 07:08:42.974943
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block(dict(block=[]))
    assert not Block.is_block(dict(block=[]))


# Generated at 2022-06-17 07:08:45.679053
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Create a Block object
    block = Block()
    # Call the method
    block.get_dep_chain()


# Generated at 2022-06-17 07:08:57.087874
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 07:09:05.216410
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [{'name': 'test'}]
    block.rescue = [{'name': 'test'}]
    block.always = [{'name': 'test'}]
    block.dep_chain = ['test']
    block.role = Role()
    block.parent = Block()
    block.parent_type = 'Block'
    block.statically_loaded = True
    block.use_handlers = True
    block.implicit = True
    block.loop = 'test'
    block.loop_args = 'test'
    block.when = 'test'
    block.changed_when = 'test'
    block.failed_when = 'test'
    block.always_run = True
    block.register = 'test'

# Generated at 2022-06-17 07:09:07.395507
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block(dict(block=[]))
    assert not Block.is_block(dict(block=[]))


# Generated at 2022-06-17 07:09:14.894465
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:09:19.111609
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block(dict(block=[]))
    assert not Block.is_block(dict(block=[]))


# Generated at 2022-06-17 07:09:26.519543
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a Block
    block = Block()
    # Create a TaskInclude
    task_include = TaskInclude()
    # Create a Block
    block2 = Block()
    # Create a TaskInclude
    task_include2 = TaskInclude()
    # Create a Block
    block3 = Block()
    # Create a TaskInclude
    task_include3 = TaskInclude()
    # Create a Block
    block4 = Block()
    # Create a TaskInclude
    task_include4 = TaskInclude()
    # Create a Block
    block5 = Block()
    # Create a TaskInclude
    task_include5 = TaskInclude()
    # Create a Block
    block6 = Block()
    # Create a TaskInclude
    task_include6 = TaskInclude()
    # Create a Block
    block7

# Generated at 2022-06-17 07:09:35.374248
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:09:37.076813
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    data = dict()
    block.deserialize(data)

# Generated at 2022-06-17 07:10:00.172943
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block(dict(block=[]))
    assert not Block.is_block(dict(not_block=[]))
    assert not Block.is_block(dict())
    assert not Block.is_block([])


# Generated at 2022-06-17 07:10:06.008459
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()

# Generated at 2022-06-17 07:10:16.305292
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 07:10:24.314685
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

# Generated at 2022-06-17 07:10:30.065607
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # Test with a simple task
    data = dict(name='test')
    b = Block()
    assert b.preprocess_data(data) == dict(block=[data])

    # Test with a list of tasks
    data = [dict(name='test1'), dict(name='test2')]
    b = Block()
    assert b.preprocess_data(data) == dict(block=data)

    # Test with a block
    data = dict(block=[dict(name='test1'), dict(name='test2')])
    b = Block()
    assert b.preprocess_data(data) == data


# Generated at 2022-06-17 07:10:41.986325
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:10:49.442742
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.errors import AnsibleParserError


# Generated at 2022-06-17 07:10:54.933370
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'name': 'test', 'block': [{'name': 'test2'}]})
    assert block.name == 'test'
    assert block.block[0].name == 'test2'


# Generated at 2022-06-17 07:11:06.700639
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 07:11:17.935732
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role_dependency import RoleDependency

# Generated at 2022-06-17 07:11:57.083386
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-17 07:12:08.455524
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a Block object
    block = Block()
    # Create a Task object
    task = Task()
    # Create a Block object
    block_1 = Block()
    # Create a Task object
    task_1 = Task()
    # Create a Block object
    block_2 = Block()
    # Create a Task object
    task_2 = Task()
    # Create a Block object
    block_3 = Block()
    # Create a Task object
    task_3 = Task()
    # Create a Block object
    block_4 = Block()
    # Create a Task object
    task_4 = Task()
    # Create a Block object
    block_5 = Block()
    # Create a Task object
    task_5 = Task()
    # Create a Block object
    block_6 = Block()
    # Create a Task object
   

# Generated at 2022-06-17 07:12:16.097732
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 07:12:23.568994
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-17 07:12:25.628069
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:12:34.124148
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()

# Generated at 2022-06-17 07:12:45.929233
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

# Generated at 2022-06-17 07:12:55.613094
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'block': [{'action': 'shell', 'args': {'chdir': '/tmp', 'creates': '/tmp/foo', 'executable': None, 'removes': '/tmp/foo', 'warn': True}, 'async_val': 0, 'changed_when': False, 'delegate_to': '', 'failed_when': False, 'name': 'shell', 'poll': 0, 'register': 'shell_out', 'remote_user': '', 'retries': 0, 'run_once': False, 'until': [], 'when': []}], 'dep_chain': [], 'always': [], 'rescue': [], 'when': [], 'register': '', 'ignore_errors': False, 'delegate_facts': False})

# Generated at 2022-06-17 07:13:02.210337
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:13:09.059009
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader

# Generated at 2022-06-17 07:13:33.645640
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Create a Block object
    block = Block()
    # Test the method get_dep_chain
    assert block.get_dep_chain() == None


# Generated at 2022-06-17 07:13:43.192180
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:13:53.977561
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 07:14:00.551208
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Test with implicit block
    data = dict(
        block=[
            dict(
                name="task1",
                action=dict(module="debug", args=dict(msg="task1")),
            ),
            dict(
                name="task2",
                action=dict(module="debug", args=dict(msg="task2")),
            ),
        ],
    )
    b = Block.load(data)
    assert b.get_dep_chain() == None
    # Test with explicit block

# Generated at 2022-06-17 07:14:08.379352
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block()
    assert b.has_tasks() == False
    b.block = [1,2,3]
    assert b.has_tasks() == True
    b.block = []
    assert b.has_tasks() == False
    b.rescue = [1,2,3]
    assert b.has_tasks() == True
    b.rescue = []
    assert b.has_tasks() == False
    b.always = [1,2,3]
    assert b.has_tasks() == True
    b.always = []
    assert b.has_tasks() == False


# Generated at 2022-06-17 07:14:16.854744
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import action_loader
   

# Generated at 2022-06-17 07:14:31.466027
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Test with empty block
    block = Block()
    assert block.filter_tagged_tasks({}) == block
    # Test with block with empty tasks
    block = Block(block=[])
    assert block.filter_tagged_tasks({}) == block
    # Test with block with tasks
    block = Block(block=[Task(action='test', tags=['test'])])
    assert block.filter_tagged_tasks({}) == block
    # Test with block with tasks and tags
    block = Block(block=[Task(action='test', tags=['test'])])
    assert block.filter_tagged_tasks({'tags': ['test']}) == block
    # Test with block with tasks and tags
    block = Block(block=[Task(action='test', tags=['test'])])
    assert block.filter_tag