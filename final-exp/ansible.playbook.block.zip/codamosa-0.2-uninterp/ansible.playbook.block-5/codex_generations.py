

# Generated at 2022-06-17 07:05:17.438624
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:05:29.027924
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a Block object
    b = Block()
    # Create a TaskInclude object
    ti = TaskInclude()
    # Create a Block object
    b2 = Block()
    # Create a TaskInclude object
    ti2 = TaskInclude()
    # Create a Block object
    b3 = Block()
    # Create a TaskInclude object
    ti3 = TaskInclude()
    # Create a Block object
    b4 = Block()
    # Create a TaskInclude object
    ti4 = TaskInclude()
    # Create a Block object
    b5 = Block()
    # Create a TaskInclude object
    ti5 = TaskInclude()
    # Create a Block object
    b6 = Block()
    # Create a TaskInclude object
    ti6 = TaskInclude()
    # Create a Block object
    b

# Generated at 2022-06-17 07:05:36.189761
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    b = Block()
    assert not Block.is_block(dict(block=[]))
    assert Block.is_block(dict(block=[], rescue=[], always=[]))
    assert Block.is_block(dict(block=[], rescue=[], always=[], foo='bar'))
    assert not Block.is_block(dict(foo='bar'))
    assert not Block.is_block(dict(block=[], foo='bar'))
    assert not Block.is_block(dict(rescue=[], foo='bar'))
    assert not Block.is_block(dict(always=[], foo='bar'))
    assert not Block.is_block(dict(block=[], rescue=[], foo='bar'))
    assert not Block.is_block(dict(block=[], always=[], foo='bar'))
    assert not Block.is_

# Generated at 2022-06-17 07:05:38.868208
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Create a Block object
    block = Block()
    # Create a Play object
    play = Play()
    # Set the loader attribute of the Block object
    block.set_loader(play)
    # Assert the loader attribute of the Block object is the same as the Play object
    assert block._loader == play


# Generated at 2022-06-17 07:05:44.830494
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:05:54.536521
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_

# Generated at 2022-06-17 07:06:02.297218
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role

# Generated at 2022-06-17 07:06:12.389451
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:06:26.296643
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Create a mock object for the loader
    loader = mock.Mock()
    # Create a mock object for the play
    play = mock.Mock()
    # Create a mock object for the role
    role = mock.Mock()
    # Create a mock object for the parent block
    parent_block = mock.Mock()
    # Create a mock object for the task
    task = mock.Mock()
    # Create a mock object for the task include
    task_include = mock.Mock()
    # Create a mock object for the handler task include
    handler_task_include = mock.Mock()
    # Create a mock object for the variable manager
    variable_manager = mock.Mock()
    # Create a mock object for the loader
    loader = mock.Mock()
    # Create a mock object for the data structure
    d

# Generated at 2022-06-17 07:06:38.039374
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'block': [{'action': 'debug', 'args': {'msg': '{{inventory_hostname}}'}, 'when': 'inventory_hostname == "localhost"'}], 'dep_chain': [], 'always': [], 'rescue': [], 'loop': '{{playbook_dir}}/files/{{inventory_hostname}}.txt', 'loop_control': {'loop_var': 'item'}, 'when': 'inventory_hostname == "localhost"'})
    assert block.block[0].action == 'debug'
    assert block.block[0].args['msg'] == '{{inventory_hostname}}'
    assert block.block[0].when == 'inventory_hostname == "localhost"'
    assert block.dep_chain == []
    assert block.always == []

# Generated at 2022-06-17 07:07:03.038185
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
   

# Generated at 2022-06-17 07:07:13.275929
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.errors import AnsibleParserError
    from ansible.executor.task_queue_manager import Task

# Generated at 2022-06-17 07:07:26.483839
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostV

# Generated at 2022-06-17 07:07:35.884700
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'role': {'name': 'test', 'path': 'test'}, 'parent': {'role': {'name': 'test', 'path': 'test'}}, 'parent_type': 'Block'})
    assert block.role.name == 'test'
    assert block.role.path == 'test'
    assert block.parent.role.name == 'test'
    assert block.parent.role.path == 'test'
    assert block.parent_type == 'Block'


# Generated at 2022-06-17 07:07:38.115369
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    loader = Mock()
    block.set_loader(loader)
    assert block._loader == loader


# Generated at 2022-06-17 07:07:45.216191
# Unit test for method is_block of class Block
def test_Block_is_block():
    ds = dict(block=[])
    assert Block.is_block(ds) == True
    ds = dict(rescue=[])
    assert Block.is_block(ds) == True
    ds = dict(always=[])
    assert Block.is_block(ds) == True
    ds = dict(block=[], rescue=[])
    assert Block.is_block(ds) == True
    ds = dict(block=[], always=[])
    assert Block.is_block(ds) == True
    ds = dict(rescue=[], always=[])
    assert Block.is_block(ds) == True
    ds = dict(block=[], rescue=[], always=[])
    assert Block.is_block(ds) == True
    ds = dict()
    assert Block.is_block(ds) == False
   

# Generated at 2022-06-17 07:07:46.953870
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:07:58.632642
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader

# Generated at 2022-06-17 07:08:08.139123
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [{'name': 'test_block'}]
    block.rescue = [{'name': 'test_rescue'}]
    block.always = [{'name': 'test_always'}]
    block.dep_chain = ['test_dep_chain']
    block.role = Role()
    block.role.name = 'test_role'
    block.parent = Block()
    block.parent.name = 'test_parent'
    block.parent_type = 'test_parent_type'
    block.statically_loaded = True
    block.name = 'test_name'
    block.loop = 'test_loop'
    block.loop_control = 'test_loop_control'
    block.when = 'test_when'
    block.any_errors_

# Generated at 2022-06-17 07:08:18.323765
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_

# Generated at 2022-06-17 07:08:34.292800
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block(dict(block=[]))
    assert not Block.is_block(dict(not_block=[]))
    assert not Block.is_block(dict())
    assert not Block.is_block(list())
    assert not Block.is_block(None)


# Generated at 2022-06-17 07:08:44.244517
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block

# Generated at 2022-06-17 07:08:55.939633
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup
    from ansible.vars.hostvars import HostV

# Generated at 2022-06-17 07:09:04.383482
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroupVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroupVars
    from ansible.vars.hostvars import HostVarsGroup

# Generated at 2022-06-17 07:09:09.590173
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'role': {'name': 'test_role'}, 'parent': {'name': 'test_parent'}, 'parent_type': 'Block'})
    assert block._role.name == 'test_role'
    assert block._parent.name == 'test_parent'
    assert block._parent.__class__.__name__ == 'Block'


# Generated at 2022-06-17 07:09:16.127840
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1, 2, 3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1, 2, 3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1, 2, 3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:09:25.249290
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

# Generated at 2022-06-17 07:09:37.354147
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 07:09:40.337226
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block = Block()
    assert block.get_dep_chain() == None
    block._dep_chain = [1,2,3]
    assert block.get_dep_chain() == [1,2,3]


# Generated at 2022-06-17 07:09:48.942466
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a block object
    block = Block()
    # Create a task object
    task = Task()
    # Create a task include object
    task_include = TaskInclude()
    # Create a block object
    block2 = Block()
    # Create a block object
    block3 = Block()
    # Create a task object
    task2 = Task()
    # Create a task include object
    task_include2 = TaskInclude()
    # Create a block object
    block4 = Block()
    # Create a task object
    task3 = Task()
    # Create a task include object
    task_include3 = TaskInclude()
    # Create a block object
    block5 = Block()
    # Create a task object
    task4 = Task()
    # Create a task include object
    task_include4 = TaskInclude()


# Generated at 2022-06-17 07:10:06.205106
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(loader)


# Generated at 2022-06-17 07:10:16.408385
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
   

# Generated at 2022-06-17 07:10:27.038694
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:10:39.327375
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader


# Generated at 2022-06-17 07:10:42.148680
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize(dict(name='test', block=[dict(name='test')]))
    assert block.name == 'test'
    assert block.block[0].name == 'test'


# Generated at 2022-06-17 07:10:49.608750
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.template import Templar

# Generated at 2022-06-17 07:11:00.390593
# Unit test for method is_block of class Block
def test_Block_is_block():
    block = Block()
    assert block.is_block(dict(block=[])) == True
    assert block.is_block(dict(rescue=[])) == True
    assert block.is_block(dict(always=[])) == True
    assert block.is_block(dict(block=[], rescue=[], always=[])) == True
    assert block.is_block(dict(block=[], rescue=[], always=[], name="test")) == True
    assert block.is_block(dict(block=[], rescue=[], always=[], name="test", when="test")) == True
    assert block.is_block(dict(block=[], rescue=[], always=[], name="test", when="test", tags="test")) == True

# Generated at 2022-06-17 07:11:02.007368
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(loader)
    assert block._loader == loader


# Generated at 2022-06-17 07:11:12.838915
# Unit test for method copy of class Block
def test_Block_copy():
    # Create a mock object for the class Block
    mock_Block = Mock(spec=Block)
    # Create a mock object for the class Task
    mock_Task = Mock(spec=Task)
    # Create a mock object for the class Role
    mock_Role = Mock(spec=Role)
    # Create a mock object for the class TaskInclude
    mock_TaskInclude = Mock(spec=TaskInclude)
    # Create a mock object for the class HandlerTaskInclude
    mock_HandlerTaskInclude = Mock(spec=HandlerTaskInclude)
    # Create a mock object for the class Block
    mock_Block_1 = Mock(spec=Block)
    # Create a mock object for the class Block
    mock_Block_2 = Mock(spec=Block)
    # Create a mock object for the class Block
    mock_Block_3 = Mock

# Generated at 2022-06-17 07:11:21.208234
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    block.dep_chain = [1, 2, 3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = 'Block'
    block.statically_loaded = True
    block.use_handlers = True
    block.play = Play()
    block.variable_manager = VariableManager()
    block.loader = DataLoader()
    block.validate()
    block.copy()


# Generated at 2022-06-17 07:11:57.879715
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 07:12:02.847249
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Setup
    # Setup test data
    # Setup expected results
    expected = None
    # Perform the test
    b = Block()
    actual = b.get_dep_chain()
    # Verify the results
    assert actual == expected


# Generated at 2022-06-17 07:12:07.626469
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:12:15.510539
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 07:12:27.551345
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.become_plugin import Become

# Generated at 2022-06-17 07:12:39.802617
# Unit test for method copy of class Block
def test_Block_copy():
    '''
    Unit test for method copy of class Block
    '''
    # Create a mock object for the class Block
    mock_Block = MagicMock(spec=Block)
    # Create a mock object for the class Task
    mock_Task = MagicMock(spec=Task)
    # Create a mock object for the class Role
    mock_Role = MagicMock(spec=Role)
    # Create a mock object for the class Play
    mock_Play = MagicMock(spec=Play)
    # Create a mock object for the class TaskInclude
    mock_TaskInclude = MagicMock(spec=TaskInclude)
    # Create a mock object for the class HandlerTaskInclude
    mock_HandlerTaskInclude = MagicMock(spec=HandlerTaskInclude)
    # Create a mock object for the class Block
    mock_Block_

# Generated at 2022-06-17 07:12:49.745336
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a Block object
    block = Block()
    # Create a Task object
    task = Task()
    # Create a Play object
    play = Play()
    # Create a variable manager object
    variable_manager = VariableManager()
    # Create a loader object
    loader = DataLoader()
    # Create a dictionary
    all_vars = {}
    # Create a list
    target = []
    # Create a list
    tmp_list = []
    # Create a Block object
    filtered_block = Block()
    # Create a Block object
    new_block = Block()
    # Call method filter_tagged_tasks of class Block
    filtered_block = block.filter_tagged_tasks(all_vars)
    # Call method has_tasks of class Block
    filtered_block.has_tasks()
    #

# Generated at 2022-06-17 07:12:57.736355
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block = Block()
    assert block.preprocess_data(dict(block=[])) == dict(block=[])
    assert block.preprocess_data(dict(block=[], rescue=[], always=[])) == dict(block=[], rescue=[], always=[])
    assert block.preprocess_data(dict(block=[], rescue=[], always=[], foo='bar')) == dict(block=[], rescue=[], always=[], foo='bar')
    assert block.preprocess_data([]) == dict(block=[])
    assert block.preprocess_data(dict(foo='bar')) == dict(block=[dict(foo='bar')])
    assert block.preprocess_data(dict(foo='bar', baz='qux')) == dict(block=[dict(foo='bar', baz='qux')])
    assert block.preprocess_data

# Generated at 2022-06-17 07:13:05.306580
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

# Generated at 2022-06-17 07:13:11.619450
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
   

# Generated at 2022-06-17 07:13:44.457213
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import Host

# Generated at 2022-06-17 07:13:55.121079
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:14:01.209926
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup
    from ansible.vars.hostvars import HostVarsGroups
    from ansible.vars.hostvars import HostVarsInventory

# Generated at 2022-06-17 07:14:09.300172
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a Block object
    block = Block()
    # Create a TaskInclude object
    task_include = TaskInclude()
    # Create a Block object
    block1 = Block()
    # Create a TaskInclude object
    task_include1 = TaskInclude()
    # Create a Block object
    block2 = Block()
    # Create a TaskInclude object
    task_include2 = TaskInclude()
    # Create a Block object
    block3 = Block()
    # Create a TaskInclude object
    task_include3 = TaskInclude()
    # Create a Block object
    block4 = Block()
    # Create a TaskInclude object
    task_include4 = TaskInclude()
    # Create a Block object
    block5 = Block()
    # Create a TaskInclude object
    task_include5 = TaskIn

# Generated at 2022-06-17 07:14:16.914498
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:14:22.437317
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:14:34.510711
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    block.dep_chain = [1,2,3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = "Block"
    block.statically_loaded = True
    block.use_handlers = True
    block.implicit = True
    block.loop = "loop"
    block.when = "when"
    block.any_errors_fatal = True
    block.changed_when = "changed_when"
    block.failed_when = "failed_when"
    block.until = "until"
    block.retries = "retries"