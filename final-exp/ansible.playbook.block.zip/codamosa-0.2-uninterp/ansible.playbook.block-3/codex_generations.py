

# Generated at 2022-06-17 07:05:08.219896
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_include import HandlerInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 07:05:12.971528
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude

# Generated at 2022-06-17 07:05:27.634525
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    assert block.has_tasks() == True
    block.block = []
    block.rescue = []
    block.always = []
    assert block.has_tasks() == False
    block.block = [1, 2, 3]
    block.rescue = []
    block.always = []
    assert block.has_tasks() == True
    block.block = []
    block.rescue = [4, 5, 6]
    block.always = []
    assert block.has_tasks() == True
    block.block = []
    block.rescue = []
    block.always = [7, 8, 9]

# Generated at 2022-06-17 07:05:35.893701
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.errors import Ansible

# Generated at 2022-06-17 07:05:36.903257
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(None)


# Generated at 2022-06-17 07:05:47.085952
# Unit test for method is_block of class Block
def test_Block_is_block():
    block = Block()
    assert block.is_block(dict(block=[])) == True
    assert block.is_block(dict(rescue=[])) == True
    assert block.is_block(dict(always=[])) == True
    assert block.is_block(dict(block=[], rescue=[], always=[])) == True
    assert block.is_block(dict(block=[], rescue=[], always=[], foo=[])) == True
    assert block.is_block(dict(block=[], rescue=[], always=[], foo=[], bar=[])) == True
    assert block.is_block(dict(block=[], rescue=[], always=[], foo=[], bar=[], baz=[])) == True

# Generated at 2022-06-17 07:05:55.540737
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.unsafe_proxy import AnsibleUn

# Generated at 2022-06-17 07:06:05.647151
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block(dict(block=[dict(action='debug', msg='Hello World')]))
    assert not Block.is_block(dict(action='debug', msg='Hello World'))
    assert not Block.is_block(dict(block=[dict(action='debug', msg='Hello World'), dict(action='debug', msg='Hello World')]))
    assert not Block.is_block(dict(block=[dict(action='debug', msg='Hello World'), dict(action='debug', msg='Hello World')]))
    assert not Block.is_block(dict(block=[dict(action='debug', msg='Hello World'), dict(action='debug', msg='Hello World')]))
    assert not Block.is_block(dict(block=[dict(action='debug', msg='Hello World'), dict(action='debug', msg='Hello World')]))

# Generated at 2022-06-17 07:06:15.358656
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup
    from ansible.vars.hostvars import HostVarsGroups
    from ansible.vars.hostvars import HostVarsAllGroups

# Generated at 2022-06-17 07:06:22.874712
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # create a block
    block = Block()
    # create a task
    task = Task()
    # set the action of the task
    task.action = 'shell'
    # set the tags of the task
    task.tags = ['tag1', 'tag2']
    # set the block attribute block to the task
    block.block = [task]
    # create a play
    play = Play()
    # set the play attribute only_tags to ['tag1']
    play.only_tags = ['tag1']
    # set the play attribute skip_tags to ['tag2']
    play.skip_tags = ['tag2']
    # set the block attribute play to the play
    block.play = play
    # create a variable manager
    variable_manager = VariableManager()
    # create a variable
    variable = Variable()
    #

# Generated at 2022-06-17 07:06:47.577424
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:06:57.098085
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.conditional import Conditional
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-17 07:07:04.670418
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:07:08.903719
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'role': {'name': 'test'}, 'parent': {'name': 'test'}, 'parent_type': 'Block'})
    assert block._role.name == 'test'
    assert block._parent.name == 'test'
    assert block._parent_type == 'Block'


# Generated at 2022-06-17 07:07:17.324330
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional

# Generated at 2022-06-17 07:07:22.781321
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a block
    block = Block()
    # Create a task
    task = Task()
    # Create a task list
    task_list = []
    # Add the task to the task list
    task_list.append(task)
    # Set the block's task list to the task list
    block.block = task_list
    # Create a dictionary of variables
    all_vars = {}
    # Call the method
    result = block.filter_tagged_tasks(all_vars)
    # Check the result
    assert result is not None
    assert isinstance(result, Block)
    assert result.block is not None
    assert isinstance(result.block, list)
    assert len(result.block) == 1
    assert result.block[0] is not None

# Generated at 2022-06-17 07:07:30.162148
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a Block object
    block = Block()
    # Create a Task object
    task = Task()
    # Create a list of tasks
    tasks = [task]
    # Create a Play object
    play = Play()
    # Create a list of plays
    plays = [play]
    # Create a Playbook object
    playbook = Playbook()
    # Create a list of plays
    playbooks = [playbook]
    # Create a Runner object
    runner = Runner()
    # Create a list of runners
    runners = [runner]
    # Create a list of variables
    all_vars = []
    # Call the method filter_tagged_tasks of class Block
    block.filter_tagged_tasks(all_vars)
    # Assert that the method filter_tagged_tasks of class Block returns a Block object

# Generated at 2022-06-17 07:07:34.402615
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block(dict(block=[]))
    assert not Block.is_block(dict(block=[]))


# Generated at 2022-06-17 07:07:38.435596
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize(dict(block=[dict(action='debug', args=dict(msg='foo'))]))
    assert block.block[0].action == 'debug'
    assert block.block[0].args['msg'] == 'foo'


# Generated at 2022-06-17 07:07:47.514423
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize(dict())
    assert block._attributes == {}
    assert block._dep_chain is None
    assert block._parent is None
    assert block._role is None
    assert block._play is None
    assert block._use_handlers is False
    assert block._loader is None
    assert block._tasks is None
    assert block._rescue is None
    assert block._always is None
    assert block._implicit is False
    assert block._static is False
    assert block._statically_loaded is False
    assert block._dep_chain is None

# Generated at 2022-06-17 07:08:18.291089
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup

# Generated at 2022-06-17 07:08:23.127016
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # Test with a simple task
    data = dict(name="test")
    b = Block()
    b.preprocess_data(data)
    assert b.block[0].name == "test"
    # Test with a block
    data = dict(block=[dict(name="test")])
    b = Block()
    b.preprocess_data(data)
    assert b.block[0].name == "test"
    # Test with a list of tasks
    data = [dict(name="test")]
    b = Block()
    b.preprocess_data(data)
    assert b.block[0].name == "test"


# Generated at 2022-06-17 07:08:34.964811
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

# Generated at 2022-06-17 07:08:44.371441
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    block.dep_chain = [1, 2, 3]
    block.role = Role()
    block.role.name = 'test'
    block.role.path = 'test'
    block.role.default_vars = {'a': 1, 'b': 2}
    block.role.tasks = [1, 2, 3]
    block.role.handlers = [4, 5, 6]
    block.role.vars = {'a': 1, 'b': 2}
    block.role.default_vars = {'a': 1, 'b': 2}

# Generated at 2022-06-17 07:08:56.048251
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a block
    block = Block()
    # Create a task
    task = Task()
    # Create a play
    play = Play()
    # Create a variable manager
    variable_manager = VariableManager()
    # Create a loader
    loader = DataLoader()
    # Create a task list
    task_list = []
    # Create a dictionary
    d = {}
    # Create a list
    l = []
    # Create a string
    s = ""
    # Create a boolean
    b = True
    # Create an integer
    i = 1
    # Create a float
    f = 1.0
    # Create a complex number
    c = 1.0 + 2.0j
    # Create a byte
    by = b'a'
    # Create a byte array

# Generated at 2022-06-17 07:09:04.449825
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_include import HandlerInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-17 07:09:05.885316
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:09:14.273558
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    b = Block()
    assert b.preprocess_data(dict(block=[])) == dict(block=[])
    assert b.preprocess_data(dict(block=[dict(action='setup')])) == dict(block=[dict(action='setup')])
    assert b.preprocess_data(dict(block=[dict(action='setup')], rescue=[dict(action='debug')])) == dict(block=[dict(action='setup')], rescue=[dict(action='debug')])
    assert b.preprocess_data(dict(block=[dict(action='setup')], rescue=[dict(action='debug')], always=[dict(action='debug')])) == dict(block=[dict(action='setup')], rescue=[dict(action='debug')], always=[dict(action='debug')])

# Generated at 2022-06-17 07:09:27.646211
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.errors import AnsibleParserError
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 07:09:38.861486
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    block.dep_chain = [1,2,3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = 'Block'
    block.play = Play()
    block.use_handlers = True
    block.statically_loaded = True
    block.implicit = True
    block.any_errors_fatal = True
    block.always_run = True
    block.serialize_when = 'never'
    block.delegate_to = 'localhost'
    block.delegate_facts = True
    block.notify = ['localhost']
    block.register = 'localhost'
   

# Generated at 2022-06-17 07:10:02.489657
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Create a block object
    block = Block()
    # Create a loader object
    loader = DataLoader()
    # Call the method set_loader of class Block
    block.set_loader(loader)
    # Check if the loader object is set
    assert block._loader == loader


# Generated at 2022-06-17 07:10:12.951992
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Test case 1
    # Test when parent is not static
    # Expected result: False
    block = Block()
    block._parent = Block()
    block._parent.statically_loaded = False
    assert block.all_parents_static() == False

    # Test case 2
    # Test when parent is static
    # Expected result: True
    block = Block()
    block._parent = Block()
    block._parent.statically_loaded = True
    assert block.all_parents_static() == True

    # Test case 3
    # Test when parent is not static and parent is TaskInclude
    # Expected result: False
    from ansible.playbook.task_include import TaskInclude
    block = Block()
    block._parent = TaskInclude()
    block._parent.statically_loaded = False
    assert block

# Generated at 2022-06-17 07:10:27.290345
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup

# Generated at 2022-06-17 07:10:39.644645
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
   

# Generated at 2022-06-17 07:10:46.575352
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block()
    assert b.has_tasks() == False
    b.block = [1, 2, 3]
    assert b.has_tasks() == True
    b.block = []
    assert b.has_tasks() == False
    b.rescue = [1, 2, 3]
    assert b.has_tasks() == True
    b.rescue = []
    assert b.has_tasks() == False
    b.always = [1, 2, 3]
    assert b.has_tasks() == True
    b.always = []
    assert b.has_tasks() == False


# Generated at 2022-06-17 07:10:50.068188
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block()
    b.set_loader(None)


# Generated at 2022-06-17 07:10:55.006651
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()
    block.copy(exclude_parent=True)
    block.copy(exclude_tasks=True)
    block.copy(exclude_parent=True, exclude_tasks=True)


# Generated at 2022-06-17 07:11:06.146008
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Create a block with no tasks
    block = Block()
    assert block.has_tasks() == False
    # Create a block with a task
    block = Block(block=[Task()])
    assert block.has_tasks() == True
    # Create a block with a rescue task
    block = Block(rescue=[Task()])
    assert block.has_tasks() == True
    # Create a block with an always task
    block = Block(always=[Task()])
    assert block.has_tasks() == True
    # Create a block with a task, rescue task, and always task
    block = Block(block=[Task()], rescue=[Task()], always=[Task()])
    assert block.has_tasks() == True


# Generated at 2022-06-17 07:11:15.817319
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 07:11:26.647585
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:11:46.649704
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-17 07:11:58.110577
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Test with a Block object as parent
    b = Block()
    b._parent = Block()
    b._parent.statically_loaded = True
    assert b.all_parents_static() == True
    b._parent.statically_loaded = False
    assert b.all_parents_static() == False
    # Test with a TaskInclude object as parent
    b = Block()
    b._parent = TaskInclude()
    b._parent.statically_loaded = True
    assert b.all_parents_static() == True
    b._parent.statically_loaded = False
    assert b.all_parents_static() == False
    # Test with a TaskInclude object as parent and a Block object as grandparent
    b = Block()
    b._parent = TaskInclude()
    b._parent._parent = Block()
    b

# Generated at 2022-06-17 07:12:09.285480
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Test with a block that has no parent
    block = Block()
    assert block.get_dep_chain() is None

    # Test with a block that has a parent
    parent = Block()
    block = Block(parent=parent)
    assert block.get_dep_chain() is None

    # Test with a block that has a parent with a dep_chain
    parent = Block()
    parent._dep_chain = ['dep1', 'dep2']
    block = Block(parent=parent)
    assert block.get_dep_chain() == ['dep1', 'dep2']

    # Test with a block that has a parent with a dep_chain and a dep_chain
    parent = Block()
    parent._dep_chain = ['dep1', 'dep2']
    block = Block(parent=parent)

# Generated at 2022-06-17 07:12:14.389111
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Create a Block object
    block = Block()
    # Test get_dep_chain method
    assert block.get_dep_chain() == None


# Generated at 2022-06-17 07:12:22.619445
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a Block object
    block = Block()
    # Create a TaskInclude object
    task_include = TaskInclude()
    # Set the parent of the Block object to the TaskInclude object
    block._parent = task_include
    # Assert that the all_parents_static method returns False
    assert block.all_parents_static() == False


# Generated at 2022-06-17 07:12:32.850810
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:12:43.828909
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

# Generated at 2022-06-17 07:12:53.257977
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup

# Generated at 2022-06-17 07:13:01.791860
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:13:08.598841
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar

# Generated at 2022-06-17 07:13:21.273445
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(loader)


# Generated at 2022-06-17 07:13:29.467659
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a Block object
    b = Block()
    # Create a TaskInclude object
    ti = TaskInclude()
    # Create another Block object
    b1 = Block()
    # Set the parent of the first Block object to the TaskInclude object
    b._parent = ti
    # Set the parent of the TaskInclude object to the second Block object
    ti._parent = b1
    # Set the statically_loaded attribute of the second Block object to False
    b1.statically_loaded = False
    # Check if all_parents_static() returns False
    assert b.all_parents_static() == False
    # Set the statically_loaded attribute of the second Block object to True
    b1.statically_loaded = True
    # Check if all_parents_static() returns True
    assert b.all_parents_static() == True


# Generated at 2022-06-17 07:13:40.687962
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
   

# Generated at 2022-06-17 07:13:50.447699
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Test with a block that has a parent
    block = Block()
    block._parent = Block()
    assert block.get_dep_chain() == None

    # Test with a block that has a parent and a dep_chain
    block = Block()
    block._parent = Block()
    block._dep_chain = [Block()]
    assert block.get_dep_chain() == [Block()]

    # Test with a block that has a dep_chain
    block = Block()
    block._dep_chain = [Block()]
    assert block.get_dep_chain() == [Block()]

    # Test with a block that has a dep_chain and a parent
    block = Block()
    block._parent = Block()
    block._dep_chain = [Block()]

# Generated at 2022-06-17 07:13:58.125815
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a block
    block = Block()
    # Create a task
    task = Task()
    # Create a task include
    task_include = TaskInclude()
    # Create a block
    block2 = Block()
    # Create a block
    block3 = Block()
    # Create a block
    block4 = Block()
    # Create a block
    block5 = Block()
    # Create a block
    block6 = Block()
    # Create a block
    block7 = Block()
    # Create a block
    block8 = Block()
    # Create a block
    block9 = Block()
    # Create a block
    block10 = Block()
    # Create a block
    block11 = Block()
    # Create a block
    block12 = Block()
    # Create a block
    block13 = Block()
    #

# Generated at 2022-06-17 07:14:06.615374
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block

# Generated at 2022-06-17 07:14:17.082558
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Create a block with no tasks
    block = Block()
    assert block.has_tasks() == False
    # Create a block with one task
    block = Block(block=[{'action': 'debug', 'msg': 'Hello world'}])
    assert block.has_tasks() == True
    # Create a block with one task and one rescue task
    block = Block(block=[{'action': 'debug', 'msg': 'Hello world'}],
                  rescue=[{'action': 'debug', 'msg': 'Hello world'}])
    assert block.has_tasks() == True
    # Create a block with one task and one always task
    block = Block(block=[{'action': 'debug', 'msg': 'Hello world'}],
                  always=[{'action': 'debug', 'msg': 'Hello world'}])
   

# Generated at 2022-06-17 07:14:22.606516
# Unit test for method copy of class Block
def test_Block_copy():
    # Create a Block object
    block = Block()
    # Copy the Block object
    new_block = block.copy()
    # Check if the Block object is copied
    assert new_block is not None


# Generated at 2022-06-17 07:14:34.618464
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role_dependency import RoleDependency

    # Create a Play
    play = Play()
    play.name = "test_play"
    play.vars = dict()
    play.vars['test_var'] = "test_value"
    play.vars['test_var2'] = "test_value2"
    play

# Generated at 2022-06-17 07:14:43.326712
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.plugins.loader import get_all_plugin_loaders
   