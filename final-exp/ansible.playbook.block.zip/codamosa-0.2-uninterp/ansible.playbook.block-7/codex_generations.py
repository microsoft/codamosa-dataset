

# Generated at 2022-06-17 07:05:13.785335
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:05:14.946252
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({})


# Generated at 2022-06-17 07:05:28.207505
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:05:36.080230
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [{'action': {'__ansible_module__': 'command', '__ansible_arguments__': 'echo "hello"', '__ansible_action__': 'command'}, 'async': 0, 'poll': 0, '__ansible_arguments__': {'chdir': None, 'creates': None, 'executable': None, 'removes': None, 'warn': True}, '__ansible_action__': 'command', '__ansible_module__': 'command', '__ansible_no_log__': False, '__ansible_verbosity__': 0, '__ansible_version__': 2}]

# Generated at 2022-06-17 07:05:46.647632
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:05:57.395850
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Test 1
    # Create a Block object
    b = Block()
    # Create a list of dependencies
    dep_chain = ['dep1', 'dep2']
    # Set the _dep_chain attribute of the Block object
    b._dep_chain = dep_chain
    # Call the get_dep_chain method of the Block object
    result = b.get_dep_chain()
    # Assert that the result is equal to the list of dependencies
    assert result == dep_chain
    # Assert that the result is not the same as the list of dependencies
    assert result is not dep_chain
    # Assert that the result is a list
    assert isinstance(result, list)
    # Assert that the result is a copy of the list of dependencies
    assert result == dep_chain[:]
    # Assert that the result is not the same

# Generated at 2022-06-17 07:06:06.612598
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a Block object
    block = Block()
    # Create a Play object
    play = Play()
    # Create a Task object
    task = Task()
    # Create a Block object
    block2 = Block()
    # Create a Task object
    task2 = Task()
    # Create a Task object
    task3 = Task()
    # Create a Task object
    task4 = Task()
    # Create a Task object
    task5 = Task()
    # Create a Task object
    task6 = Task()
    # Create a Task object
    task7 = Task()
    # Create a Task object
    task8 = Task()
    # Create a Task object
    task9 = Task()
    # Create a Task object
    task10 = Task()
    # Create a Task object
    task11 = Task()
    # Create a Task object

# Generated at 2022-06-17 07:06:15.932140
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # Test with a block with a parent
    block = Block()
    block.deserialize({'block': [], 'rescue': [], 'always': [], 'dep_chain': None, 'role': None, 'parent': {'block': [], 'rescue': [], 'always': [], 'dep_chain': None, 'role': None, 'parent': None, 'parent_type': None}, 'parent_type': 'Block'})
    assert block._attributes == {'block': [], 'rescue': [], 'always': []}
    assert block._dep_chain is None
    assert block._role is None
    assert block._parent is not None
    assert block._parent._attributes == {'block': [], 'rescue': [], 'always': []}
    assert block._parent._dep_chain is None
    assert block

# Generated at 2022-06-17 07:06:22.070786
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block()
    assert b.has_tasks() == False
    b.block = [1,2,3]
    assert b.has_tasks() == True
    b.block = []
    b.rescue = [1,2,3]
    assert b.has_tasks() == True
    b.rescue = []
    b.always = [1,2,3]
    assert b.has_tasks() == True
    b.always = []
    assert b.has_tasks() == False


# Generated at 2022-06-17 07:06:30.642098
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Create a block with no tasks
    block = Block()
    assert block.has_tasks() == False
    # Create a block with a task
    block = Block(block=[{'action': 'debug', 'msg': 'This is a test'}])
    assert block.has_tasks() == True
    # Create a block with a rescue task
    block = Block(rescue=[{'action': 'debug', 'msg': 'This is a test'}])
    assert block.has_tasks() == True
    # Create a block with an always task
    block = Block(always=[{'action': 'debug', 'msg': 'This is a test'}])
    assert block.has_tasks() == True
    # Create a block with a task, rescue task, and always task

# Generated at 2022-06-17 07:07:00.238034
# Unit test for method is_block of class Block
def test_Block_is_block():
    data = {'block': [{'action': 'debug', 'msg': 'hello'}]}
    assert Block.is_block(data) == True
    data = {'block': [{'action': 'debug', 'msg': 'hello'}], 'rescue': [{'action': 'debug', 'msg': 'hello'}]}
    assert Block.is_block(data) == True
    data = {'block': [{'action': 'debug', 'msg': 'hello'}], 'always': [{'action': 'debug', 'msg': 'hello'}]}
    assert Block.is_block(data) == True

# Generated at 2022-06-17 07:07:10.523234
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a block
    block = Block()
    # Create a task
    task = Task()
    # Create a task include
    task_include = TaskInclude()
    # Create a block include
    block_include = Block()
    # Set the parent of the block to the task
    block._parent = task
    # Test that the method all_parents_static returns True
    assert block.all_parents_static() == True
    # Set the parent of the block to the task include
    block._parent = task_include
    # Test that the method all_parents_static returns True
    assert block.all_parents_static() == True
    # Set the parent of the block to the block include
    block._parent = block_include
    # Test that the method all_parents_static returns True
    assert block.all_parents_static() == True

# Generated at 2022-06-17 07:07:11.907798
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:07:19.584455
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    block.dep_chain = [1, 2, 3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = 'Block'
    new_block = block.copy()
    assert new_block.block == [1, 2, 3]
    assert new_block.rescue == [4, 5, 6]
    assert new_block.always == [7, 8, 9]
    assert new_block.dep_chain == [1, 2, 3]
    assert new_block.role == Role()
    assert new_block.parent == Block()

# Generated at 2022-06-17 07:07:24.025230
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
   

# Generated at 2022-06-17 07:07:30.783820
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 07:07:42.412789
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'block': [{'action': 'debug', 'args': {'msg': 'Hello world'}, 'name': 'debug', 'register': 'debug_result'}], 'dep_chain': [], 'name': 'debug', 'parent': {'block': [{'action': 'debug', 'args': {'msg': 'Hello world'}, 'name': 'debug', 'register': 'debug_result'}], 'dep_chain': [], 'name': 'debug', 'parent': None, 'role': None, 'tags': ['debug'], 'when': 'True'}, 'role': None, 'tags': ['debug'], 'when': 'True'})
    assert block.block[0].action == 'debug'
    assert block.block[0].args['msg'] == 'Hello world'

# Generated at 2022-06-17 07:07:51.142410
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    b = Block()
    assert b.get_dep_chain() is None
    b._dep_chain = [1, 2, 3]
    assert b.get_dep_chain() == [1, 2, 3]
    b._parent = Block()
    b._parent._dep_chain = [4, 5, 6]
    assert b.get_dep_chain() == [4, 5, 6]
    b._dep_chain = [1, 2, 3]
    assert b.get_dep_chain() == [1, 2, 3]


# Generated at 2022-06-17 07:08:01.799142
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 07:08:05.914990
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block(dict(block=[]))
    assert not Block.is_block(dict(not_block=[]))
    assert not Block.is_block(dict())
    assert not Block.is_block(list())
    assert not Block.is_block(None)


# Generated at 2022-06-17 07:08:34.994855
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Create a mock object for the class 'Block'
    block = mock.Mock(spec=Block)
    # Create a mock object for the class 'Role'
    role = mock.Mock(spec=Role)
    # Create a mock object for the class 'Play'
    play = mock.Mock(spec=Play)
    # Create a mock object for the class 'TaskInclude'
    task_include = mock.Mock(spec=TaskInclude)
    # Create a mock object for the class 'HandlerTaskInclude'
    handler_task_include = mock.Mock(spec=HandlerTaskInclude)
    # Create a mock object for the class 'Block'
    block_1 = mock.Mock(spec=Block)
    # Create a mock object for the class 'TaskInclude'
    task_include_1 = mock.M

# Generated at 2022-06-17 07:08:44.371271
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 07:08:49.011392
# Unit test for method copy of class Block
def test_Block_copy():
    # Create a Block object
    block = Block()
    # Copy the Block object
    new_block = block.copy()
    # Check if the new Block object is created
    assert new_block is not None


# Generated at 2022-06-17 07:08:51.036137
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(loader)


# Generated at 2022-06-17 07:08:57.625542
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    block.block = [1, 2, 3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1, 2, 3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1, 2, 3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:09:08.206381
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
   

# Generated at 2022-06-17 07:09:16.127813
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 07:09:28.238287
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

# Generated at 2022-06-17 07:09:39.146029
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars


# Generated at 2022-06-17 07:09:47.700176
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a Block object
    block = Block()
    # Create a TaskInclude object
    task_include = TaskInclude()
    # Create a Block object
    block2 = Block()
    # Create a TaskInclude object
    task_include2 = TaskInclude()
    # Create a Block object
    block3 = Block()
    # Create a TaskInclude object
    task_include3 = TaskInclude()
    # Create a Block object
    block4 = Block()
    # Create a TaskInclude object
    task_include4 = TaskInclude()
    # Create a Block object
    block5 = Block()
    # Create a TaskInclude object
    task_include5 = TaskInclude()
    # Create a Block object
    block6 = Block()
    # Create a TaskInclude object
    task_include6 = TaskIn

# Generated at 2022-06-17 07:10:06.946494
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 07:10:13.474144
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a Block object
    b = Block()
    # Create a TaskInclude object
    ti = TaskInclude()
    # Create a Block object
    b2 = Block()
    # Set the parent of the Block object to the TaskInclude object
    b.set_loader(DictDataLoader())
    b._parent = ti
    # Set the parent of the TaskInclude object to the Block object
    ti._parent = b2
    # Set the statically_loaded attribute of the TaskInclude object to False
    ti.statically_loaded = False
    # Check if the all_parents_static method returns False
    assert b.all_parents_static() == False


# Generated at 2022-06-17 07:10:27.458989
# Unit test for method copy of class Block
def test_Block_copy():
    # Create a new instance of Block
    block = Block()
    # Create a new instance of Block
    block_1 = Block()
    # Create a new instance of Block
    block_2 = Block()
    # Create a new instance of Block
    block_3 = Block()
    # Create a new instance of Block
    block_4 = Block()
    # Create a new instance of Block
    block_5 = Block()
    # Create a new instance of Block
    block_6 = Block()
    # Create a new instance of Block
    block_7 = Block()
    # Create a new instance of Block
    block_8 = Block()
    # Create a new instance of Block
    block_9 = Block()
    # Create a new instance of Block
    block_10 = Block()
    # Create a new instance of Block

# Generated at 2022-06-17 07:10:29.218132
# Unit test for method copy of class Block
def test_Block_copy():
    # Create a Block object
    block = Block()
    # Call method copy of Block object
    block.copy()


# Generated at 2022-06-17 07:10:41.667000
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_block import HandlerBlock
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_block import HandlerBlock
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-17 07:10:43.983825
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(loader)
    assert block._loader == loader


# Generated at 2022-06-17 07:10:44.883731
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    pass

# Generated at 2022-06-17 07:10:55.603383
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

# Generated at 2022-06-17 07:11:07.196077
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

# Generated at 2022-06-17 07:11:09.894792
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Create a Block object
    block = Block()
    # Test if the Block object has tasks
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:11:28.798362
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude

# Generated at 2022-06-17 07:11:40.294665
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Create a block object
    block = Block()
    # Create a role object
    role = Role()
    # Create a task object
    task = Task()
    # Create a task_include object
    task_include = TaskInclude()
    # Create a handler_task_include object
    handler_task_include = HandlerTaskInclude()
    # Create a play object
    play = Play()
    # Create a block object
    block1 = Block()
    # Create a block object
    block2 = Block()
    # Create a block object
    block3 = Block()
    # Create a block object
    block4 = Block()
    # Create a block object
    block5 = Block()
    # Create a block object
    block6 = Block()
    # Create a block object
    block7 = Block()
    # Create a block object

# Generated at 2022-06-17 07:11:46.650384
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'role': {'name': 'test_role'}, 'parent': {'name': 'test_parent'}, 'parent_type': 'Block'})
    assert block._role.name == 'test_role'
    assert block._parent.name == 'test_parent'
    assert block._parent.__class__.__name__ == 'Block'


# Generated at 2022-06-17 07:11:58.073578
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b.block = [1,2,3]
    b.rescue = [4,5,6]
    b.always = [7,8,9]
    b.dep_chain = [1,2,3]
    b.role = Role()
    b.parent = Block()
    b.parent_type = 'Block'
    b.statically_loaded = True
    b.name = 'test'
    b.loop = 'test'
    b.loop_args = 'test'
    b.when = 'test'
    b.changed_when = 'test'
    b.failed_when = 'test'
    b.until = 'test'
    b.retries = 'test'
    b.delay = 'test'
    b.register = 'test'
    b.ignore

# Generated at 2022-06-17 07:12:09.217840
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:12:16.681315
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(None)
    assert block._loader == None
    assert block._parent == None
    assert block._role == None
    assert block._dep_chain == None
    assert block._play == None
    assert block._use_handlers == False

# Generated at 2022-06-17 07:12:18.859228
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:12:28.563008
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    block.dep_chain = [1,2,3]
    block.role = Role()
    block.role.name = "test"
    block.role.path = "test"
    block.role.default_vars = "test"
    block.role.metadata = "test"
    block.role.tasks = "test"
    block.role.handlers = "test"
    block.role.vars = "test"
    block.role.default_vars = "test"
    block.role.main_file = "test"
    block.role.files = "test"

# Generated at 2022-06-17 07:12:36.490227
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.handler_task_include import HandlerTaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.role.block import Block as RoleBlock
    from ansible.playbook.role.task import Task as RoleTask
    from ansible.playbook.role.handler import Handler as RoleHandler

# Generated at 2022-06-17 07:12:47.398699
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader

# Generated at 2022-06-17 07:13:07.494134
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar


# Generated at 2022-06-17 07:13:12.835291
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Create a Block object
    block = Block()
    # Call method get_dep_chain of class Block
    result = block.get_dep_chain()
    # Assert the result
    assert result is None


# Generated at 2022-06-17 07:13:20.491699
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:13:28.798860
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block

# Generated at 2022-06-17 07:13:40.612596
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:13:50.502904
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_include import HandlerInclude
    from ansible.playbook.role import Role

# Generated at 2022-06-17 07:13:58.253577
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup
    from ansible.vars.hostvars import HostVarsGroups

# Generated at 2022-06-17 07:14:01.567827
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Test with no parent
    b = Block()
    assert b.get_dep_chain() is None

    # Test with parent
    b = Block()
    b._parent = Block()
    assert b.get_dep_chain() is None

    # Test with parent and dep_chain
    b = Block()
    b._parent = Block()
    b._dep_chain = [Block()]
    assert b.get_dep_chain() == [Block()]


# Generated at 2022-06-17 07:14:09.320294
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    block.dep_chain = [1, 2, 3]
    block.role = Role()
    block.role.name = 'test'
    block.role.path = 'test'
    block.role.default_vars = {'a': 1, 'b': 2}
    block.role.vars_files = [1, 2, 3]
    block.role.tasks = [1, 2, 3]
    block.role.handlers = [1, 2, 3]
    block.role.meta = {'a': 1, 'b': 2}

# Generated at 2022-06-17 07:14:16.913251
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    block.dep_chain = [1,2,3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = 'Block'
    new_block = block.copy()
    assert new_block.block == [1,2,3]
    assert new_block.rescue == [4,5,6]
    assert new_block.always == [7,8,9]
    assert new_block.dep_chain == [1,2,3]
    assert new_block.role == block.role
    assert new_block.parent == block.parent

# Generated at 2022-06-17 07:14:34.509703
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False
