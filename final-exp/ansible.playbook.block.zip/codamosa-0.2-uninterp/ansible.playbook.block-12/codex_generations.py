

# Generated at 2022-06-17 07:05:09.467995
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader

# Generated at 2022-06-17 07:05:16.571618
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

# Generated at 2022-06-17 07:05:26.981258
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # Test with a simple task
    data = dict(name='test')
    b = Block()
    assert b.preprocess_data(data) == dict(block=[data])
    # Test with a list of tasks
    data = [dict(name='test'), dict(name='test2')]
    b = Block()
    assert b.preprocess_data(data) == dict(block=data)
    # Test with a block
    data = dict(block=[dict(name='test')])
    b = Block()
    assert b.preprocess_data(data) == data


# Generated at 2022-06-17 07:05:35.589874
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

# Generated at 2022-06-17 07:05:41.493519
# Unit test for method is_block of class Block

# Generated at 2022-06-17 07:05:52.385624
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_include import HandlerInclude
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.conditional import Conditional

# Generated at 2022-06-17 07:05:57.915107
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()
    block.copy(exclude_parent=True)
    block.copy(exclude_tasks=True)
    block.copy(exclude_parent=True, exclude_tasks=True)


# Generated at 2022-06-17 07:06:05.523047
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:06:14.265553
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import action_loader


# Generated at 2022-06-17 07:06:16.961289
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block = Block()
    assert block.get_dep_chain() == None


# Generated at 2022-06-17 07:06:35.988787
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.handler_task_include import HandlerTaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:06:37.076352
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:06:47.089997
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'block': [{'action': 'debug', 'name': 'test'}], 'dep_chain': [], 'role': {'name': 'test'}, 'parent': {'block': [{'action': 'debug', 'name': 'test'}], 'dep_chain': [], 'role': {'name': 'test'}, 'parent_type': 'Block'}, 'parent_type': 'Block'})
    assert block.block[0].action == 'debug'
    assert block.block[0].name == 'test'
    assert block.dep_chain == []
    assert block._role.name == 'test'
    assert block._parent.block[0].action == 'debug'
    assert block._parent.block[0].name == 'test'
    assert block._parent.dep

# Generated at 2022-06-17 07:06:56.705110
# Unit test for method filter_tagged_tasks of class Block

# Generated at 2022-06-17 07:07:07.468429
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude

# Generated at 2022-06-17 07:07:09.152177
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(None)
    assert block._loader is None


# Generated at 2022-06-17 07:07:15.898128
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # Test with a valid block
    block = Block()

# Generated at 2022-06-17 07:07:27.734792
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # create a block
    b = Block()
    # create a task
    t = Task()
    # create a list of tasks
    l = []
    # add the task to the list
    l.append(t)
    # set the block's block to the list of tasks
    b.block = l
    # create a variable manager
    vm = VariableManager()
    # create a dictionary of variables
    d = {}
    # set the variable manager's variables to the dictionary
    vm.set_vars(d)
    # set the variable manager's extra vars to the dictionary
    vm.set_extra_vars(d)
    # set the variable manager's options to the dictionary
    vm.set_options(d)
    # create a play
    p = Play()
    # set the play's variable manager to the variable manager
   

# Generated at 2022-06-17 07:07:28.752622
# Unit test for method serialize of class Block
def test_Block_serialize():
    block = Block()
    block.serialize()
    assert True


# Generated at 2022-06-17 07:07:40.479463
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [{'name': 'test'}]
    block.rescue = [{'name': 'test'}]
    block.always = [{'name': 'test'}]
    block.dep_chain = [{'name': 'test'}]
    block.role = {'name': 'test'}
    block.parent = {'name': 'test'}
    block.parent_type = 'test'
    block.statically_loaded = True
    block.implicit = True
    block.loop = 'test'
    block.loop_args = 'test'
    block.loop_with_items = 'test'
    block.when = 'test'
    block.register = 'test'
    block.delegate_to = 'test'
    block.delegate_

# Generated at 2022-06-17 07:08:09.304675
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    block.dep_chain = [1, 2, 3]
    block.role = Role()
    block.parent = Block()
    block.validate()
    new_block = block.copy()
    assert new_block.block == [1, 2, 3]
    assert new_block.rescue == [4, 5, 6]
    assert new_block.always == [7, 8, 9]
    assert new_block.dep_chain == [1, 2, 3]
    assert new_block.role == block.role
    assert new_block.parent == block.parent
    assert new_block.validate()

# Unit test

# Generated at 2022-06-17 07:08:18.413728
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 07:08:23.741889
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Create a Block object
    block = Block()
    # Test if the Block object has tasks
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:08:28.715436
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
   

# Generated at 2022-06-17 07:08:39.814679
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
   

# Generated at 2022-06-17 07:08:48.513666
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Create a play

# Generated at 2022-06-17 07:08:57.810935
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    block.loop = 'loop'
    block.name = 'name'
    block.when = 'when'
    block.any_errors_fatal = 'any_errors_fatal'
    block.changed_when = 'changed_when'
    block.failed_when = 'failed_when'
    block.delay = 'delay'
    block.until = 'until'
    block.retries = 'retries'
    block.register = 'register'
    block.ignore_errors = 'ignore_errors'
    block.tags = 'tags'
    block.run_once = 'run_once'

# Generated at 2022-06-17 07:08:58.852630
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:09:07.658098
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a block
    block = Block()
    # Create a task
    task = Task()
    # Create a task include
    task_include = TaskInclude()
    # Set the parent of the block to the task
    block._parent = task
    # Set the parent of the task to the task include
    task._parent = task_include
    # Set the statically_loaded attribute of the task include to False
    task_include.statically_loaded = False
    # Assert that the all_parents_static method of the block returns False
    assert block.all_parents_static() == False


# Generated at 2022-06-17 07:09:14.991441
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a block
    b = Block()
    # Create a play
    p = Play()
    # Create a task
    t = Task()
    # Create a role
    r = Role()
    # Create a task include
    ti = TaskInclude()
    # Create a handler task include
    hti = HandlerTaskInclude()
    # Create a variable manager
    vm = VariableManager()
    # Create a loader
    l = DictDataLoader({})
    # Create a variable
    v = Variable()
    # Create a task include result
    t_i_r = TaskIncludeResult()
    # Create a handler task include result
    h_t_i_r = HandlerTaskIncludeResult()
    # Create a task result
    t_r = TaskResult()
    # Create a role result
    r_r = RoleResult

# Generated at 2022-06-17 07:09:45.710703
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

# Generated at 2022-06-17 07:09:50.078075
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    assert block.has_tasks() == True
    block.block = []
    block.rescue = []
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:10:00.742438
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor


# Generated at 2022-06-17 07:10:06.235239
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block()
    b.set_loader(None)
    assert b._loader == None


# Generated at 2022-06-17 07:10:16.470964
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

# Generated at 2022-06-17 07:10:24.558656
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:10:31.554681
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup

# Generated at 2022-06-17 07:10:42.938672
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_block import HandlerBlock

# Generated at 2022-06-17 07:10:55.086722
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:11:00.102297
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import wrap_var

# Generated at 2022-06-17 07:12:09.650333
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:12:13.155293
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Test with no loader
    b = Block()
    b.set_loader(None)
    assert b._loader is None
    # Test with loader
    b = Block()
    b.set_loader(DummyLoader())
    assert isinstance(b._loader, DummyLoader)


# Generated at 2022-06-17 07:12:26.888262
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import RoleTaskInclude
    from ansible.playbook.role.handler_task_include import RoleHandlerTaskInclude
    from ansible.playbook.role.block import RoleBlock
    from ansible.playbook.role.task import RoleTask
    from ansible.playbook.role.handler import RoleHandler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

# Generated at 2022-06-17 07:12:32.197983
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:12:41.827815
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b.block = [1,2,3]
    b.rescue = [4,5,6]
    b.always = [7,8,9]
    b.dep_chain = [1,2,3]
    b.role = Role()
    b.parent = Block()
    b.parent_type = 'Block'
    b.statically_loaded = True
    b.name = 'test'
    b.loop = 'test'
    b.when = 'test'
    b.any_errors_fatal = True
    b.changed_when = 'test'
    b.failed_when = 'test'
    b.always_run = True
    b.register = 'test'
    b.ignore_errors = True
    b.delegate_to = 'test'
   

# Generated at 2022-06-17 07:12:50.608262
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    block.dep_chain = [1,2,3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = 'Block'
    block.statically_loaded = True
    block.name = 'block'
    block.loop = 'loop'
    block.when = 'when'
    block.any_errors_fatal = True
    block.changed_when = 'changed_when'
    block.failed_when = 'failed_when'
    block.until = 'until'
    block.retries = 'retries'
    block.delay = 'delay'

# Generated at 2022-06-17 07:12:51.479145
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:13:02.841550
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 07:13:03.898342
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:13:10.535604
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b.block = [1, 2, 3]
    b.rescue = [4, 5, 6]
    b.always = [7, 8, 9]
    b._dep_chain = [1, 2, 3]
    b._parent = 1
    b._role = 1
    b._play = 1
    b._use_handlers = 1
    b._loader = 1
    b._variable_manager = 1
    b._task_include = 1
    b._task_include_vars = 1
    b._task_include_first_pass = 1
    b._task_include_role = 1
    b._task_include_role_vars = 1
    b._task_include_role_first_pass = 1
    b._task_include_loop_vars = 1
    b._

# Generated at 2022-06-17 07:14:00.053930
# Unit test for method copy of class Block
def test_Block_copy():
    # Create a mock object of class Block
    block = Block()
    # Create a mock object of class Block
    block2 = Block()
    # Create a mock object of class Block
    block3 = Block()
    # Create a mock object of class Block
    block4 = Block()
    # Create a mock object of class Block
    block5 = Block()
    # Create a mock object of class Block
    block6 = Block()
    # Create a mock object of class Block
    block7 = Block()
    # Create a mock object of class Block
    block8 = Block()
    # Create a mock object of class Block
    block9 = Block()
    # Create a mock object of class Block
    block10 = Block()
    # Create a mock object of class Block
    block11 = Block()
    # Create a mock object of class Block
    block12

# Generated at 2022-06-17 07:14:03.064058
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [{'action': 'debug', 'msg': 'Hello World'}]
    block.rescue = [{'action': 'debug', 'msg': 'Hello World'}]
    block.always = [{'action': 'debug', 'msg': 'Hello World'}]
    block.copy()


# Generated at 2022-06-17 07:14:05.770630
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b.copy()


# Generated at 2022-06-17 07:14:08.033877
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:14:16.484232
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a block
    block = Block()
    # Create a task
    task = Task()
    # Create a play
    play = Play()
    # Create a variable manager
    variable_manager = VariableManager()
    # Create a loader
    loader = DataLoader()
    # Create a variable
    variable = Variable()
    # Create a task_include
    task_include = TaskInclude()
    # Create a handler_task_include
    handler_task_include = HandlerTaskInclude()
    # Create a role
    role = Role()
    # Create a block_loader
    block_loader = BlockLoader()
    # Create a task_loader
    task_loader = TaskLoader()
    # Create a role_include
    role_include = RoleInclude()
    # Create a role_dependency
    role_dependency = RoleD

# Generated at 2022-06-17 07:14:19.460295
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(loader)
    assert block._loader == loader


# Generated at 2022-06-17 07:14:33.273913
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

# Generated at 2022-06-17 07:14:36.716401
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Create a new instance of class Block
    block = Block()
    # Check if the method has_tasks of class Block returns False
    assert block.has_tasks() == False