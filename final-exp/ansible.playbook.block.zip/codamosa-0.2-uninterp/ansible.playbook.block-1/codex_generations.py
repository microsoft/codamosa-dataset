

# Generated at 2022-06-17 07:05:52.258904
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

# Generated at 2022-06-17 07:06:01.747216
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b.block = [1, 2, 3]
    b.rescue = [4, 5, 6]
    b.always = [7, 8, 9]
    b.dep_chain = [1, 2, 3]
    b.role = Role()
    b.parent = Block()
    b.parent_type = 'Block'
    b.statically_loaded = True
    b.use_handlers = True
    b.implicit = True
    b.loop = True
    b.loop_args = True
    b.loop_with_items = True
    b.loop_with_sequence = True
    b.loop_with_indexed_items = True
    b.loop_with_first_only = True
    b.loop_with_nested_items = True
    b.loop

# Generated at 2022-06-17 07:06:03.613116
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block()
    b.set_loader(None)


# Generated at 2022-06-17 07:06:13.325702
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:06:22.540211
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.become import Become
    from ansible.playbook.become_context import BecomeContext
    from ansible.template import Templar

# Generated at 2022-06-17 07:06:27.077032
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'role': {'name': 'test_role'}, 'parent': {'role': {'name': 'test_role'}}, 'parent_type': 'Block'})
    assert block._role.name == 'test_role'
    assert block._parent._role.name == 'test_role'
    assert block._parent_type == 'Block'


# Generated at 2022-06-17 07:06:35.717348
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'block': [], 'rescue': [], 'always': [], 'dep_chain': [], 'role': {}, 'parent': {}, 'parent_type': 'Block'})
    assert block.block == []
    assert block.rescue == []
    assert block.always == []
    assert block.dep_chain == []
    assert block.role == {}
    assert block.parent == {}
    assert block.parent_type == 'Block'


# Generated at 2022-06-17 07:06:41.673716
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Test with a block that has a parent
    block = Block()
    parent = Block()
    block._parent = parent
    assert block.get_dep_chain() == None
    # Test with a block that has a dep_chain
    block = Block()
    block._dep_chain = [1,2,3]
    assert block.get_dep_chain() == [1,2,3]
    # Test with a block that has a parent and a dep_chain
    block = Block()
    parent = Block()
    block._parent = parent
    block._dep_chain = [1,2,3]
    assert block.get_dep_chain() == [1,2,3]


# Generated at 2022-06-17 07:06:52.554512
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader

# Generated at 2022-06-17 07:06:53.120828
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    pass

# Generated at 2022-06-17 07:07:25.413885
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader

# Generated at 2022-06-17 07:07:29.297586
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    block.dep_chain = [1,2,3]
    block.role = 'role'
    block.parent = 'parent'
    block.parent_type = 'parent_type'
    block.validate()
    block.copy()


# Generated at 2022-06-17 07:07:35.283143
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [1,2,3]
    block.always = [1,2,3]
    block.loop = [1,2,3]
    block.when = [1,2,3]
    block.other = [1,2,3]
    block.notify = [1,2,3]
    block.dep_chain = [1,2,3]
    block._play = [1,2,3]
    block._use_handlers = [1,2,3]
    block._parent = [1,2,3]
    block._role = [1,2,3]
    block._loader = [1,2,3]
    block._variable_manager = [1,2,3]
    block

# Generated at 2022-06-17 07:07:43.712365
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action

# Generated at 2022-06-17 07:07:53.274373
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:08:02.615211
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
   

# Generated at 2022-06-17 07:08:03.319958
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    pass

# Generated at 2022-06-17 07:08:11.865539
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader

# Generated at 2022-06-17 07:08:18.673614
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Test with no parent
    b = Block()
    assert b.get_dep_chain() is None

    # Test with parent
    b = Block(parent_block=Block(parent_block=Block()))
    assert b.get_dep_chain() == [b._parent._parent]

    # Test with dep_chain
    b = Block(dep_chain=[Block(), Block()])
    assert b.get_dep_chain() == [Block(), Block()]

    # Test with dep_chain and parent
    b = Block(dep_chain=[Block(), Block()], parent_block=Block(parent_block=Block()))
    assert b.get_dep_chain() == [Block(), Block(), b._parent._parent]


# Generated at 2022-06-17 07:08:28.262073
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 07:08:48.543491
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 07:08:50.409050
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:08:53.474592
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # Create a Block object
    block = Block()
    # Test preprocess_data method
    block.preprocess_data(None)


# Generated at 2022-06-17 07:09:02.898837
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup

# Generated at 2022-06-17 07:09:12.106553
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    block.dep_chain = [1,2,3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = "Block"
    block.statically_loaded = True
    block.name = "Block"
    block.loop = "loop"
    block.when = "when"
    block.any_errors_fatal = True
    block.changed_when = "changed_when"
    block.failed_when = "failed_when"
    block.until = "until"
    block.retries = 1
    block.delay = 2
    block.register = "register"

# Generated at 2022-06-17 07:09:19.800856
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # Test with a simple task
    b = Block()
    ds = dict(name="test", action="test")
    assert b.preprocess_data(ds) == dict(block=[ds])
    # Test with a list of tasks
    ds = [dict(name="test1", action="test1"), dict(name="test2", action="test2")]
    assert b.preprocess_data(ds) == dict(block=ds)
    # Test with a block
    ds = dict(block=[dict(name="test1", action="test1"), dict(name="test2", action="test2")])
    assert b.preprocess_data(ds) == ds


# Generated at 2022-06-17 07:09:26.859128
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

# Generated at 2022-06-17 07:09:38.605318
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:09:47.193427
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a block object
    block = Block()
    # Create a task object
    task = Task()
    # Create a task include object
    task_include = TaskInclude()
    # Create a block object
    block1 = Block()
    # Create a block object
    block2 = Block()
    # Create a block object
    block3 = Block()
    # Create a block object
    block4 = Block()
    # Create a block object
    block5 = Block()
    # Create a block object
    block6 = Block()
    # Create a block object
    block7 = Block()
    # Create a block object
    block8 = Block()
    # Create a block object
    block9 = Block()
    # Create a block object
    block10 = Block()
    # Create a block object
    block11 = Block()
   

# Generated at 2022-06-17 07:09:50.677892
# Unit test for method is_block of class Block
def test_Block_is_block():
    block = Block()
    assert block.is_block({'block': [{'name': 'test'}]}) == True
    assert block.is_block([{'name': 'test'}]) == False
    assert block.is_block({'name': 'test'}) == False
    assert block.is_block(None) == False


# Generated at 2022-06-17 07:10:15.365297
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
   

# Generated at 2022-06-17 07:10:28.079335
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

# Generated at 2022-06-17 07:10:40.529496
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-17 07:10:41.765773
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(loader)


# Generated at 2022-06-17 07:10:49.342049
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b.block = [1, 2, 3]
    b.rescue = [4, 5, 6]
    b.always = [7, 8, 9]
    b.loop = 'loop'
    b.when = 'when'
    b.name = 'name'
    b.any_errors_fatal = 'any_errors_fatal'
    b.changed_when = 'changed_when'
    b.failed_when = 'failed_when'
    b.delay = 'delay'
    b.retries = 'retries'
    b.until = 'until'
    b.run_once = 'run_once'
    b.tags = 'tags'
    b.register = 'register'
    b.ignore_errors = 'ignore_errors'

# Generated at 2022-06-17 07:11:00.389765
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup
    from ansible.vars.hostvars import HostVarsGroups

# Generated at 2022-06-17 07:11:08.162143
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'role': {'name': 'test_role'}, 'parent': {'name': 'test_parent'}, 'parent_type': 'Block'})
    assert block._role.name == 'test_role'
    assert block._parent.name == 'test_parent'
    assert block._parent.__class__.__name__ == 'Block'

# Generated at 2022-06-17 07:11:18.836046
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a Block object
    block = Block()
    # Create a TaskInclude object
    task_include = TaskInclude()
    # Set the parent of the Block object to the TaskInclude object
    block._parent = task_include
    # Create a TaskInclude object
    task_include2 = TaskInclude()
    # Set the parent of the TaskInclude object to the TaskInclude2 object
    task_include._parent = task_include2
    # Create a Block object
    block2 = Block()
    # Set the parent of the TaskInclude2 object to the Block2 object
    task_include2._parent = block2
    # Create a TaskInclude object
    task_include3 = TaskInclude()
    # Set the parent of the Block2 object to the TaskInclude3 object
    block2._parent = task_include3

# Generated at 2022-06-17 07:11:28.577731
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a Block object
    block = Block()
    block.block = [{'action': 'debug', 'tags': ['debug']}, {'action': 'debug', 'tags': ['debug', 'test']}]
    block.rescue = [{'action': 'debug', 'tags': ['debug']}, {'action': 'debug', 'tags': ['debug', 'test']}]
    block.always = [{'action': 'debug', 'tags': ['debug']}, {'action': 'debug', 'tags': ['debug', 'test']}]
    # Create a Play object
    play = Play()
    play.only_tags = ['debug']
    play.skip_tags = ['test']
    # Create a Task object
    task = Task()
    task.action = 'debug'
    task.tags = ['debug']
    task

# Generated at 2022-06-17 07:11:30.014308
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:11:50.759812
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()
    block.copy(exclude_parent=True)
    block.copy(exclude_tasks=True)
    block.copy(exclude_parent=True, exclude_tasks=True)


# Generated at 2022-06-17 07:11:59.967913
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Create a block object
    block = Block()
    # Create a task object
    task = Task()
    # Create a task object
    task1 = Task()
    # Create a task object
    task2 = Task()
    # Create a task object
    task3 = Task()
    # Create a task object
    task4 = Task()
    # Create a task object
    task5 = Task()
    # Create a task object
    task6 = Task()
    # Create a task object
    task7 = Task()
    # Create a task object
    task8 = Task()
    # Create a task object
    task9 = Task()
    # Create a task object
    task10 = Task()
    # Create a task object
    task11 = Task()
    # Create a task object
    task12 = Task()
    # Create a task

# Generated at 2022-06-17 07:12:11.235563
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 07:12:21.173807
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Test with no tags
    block = Block()
    block.block = [
        Task(action='debug', tags=['debug']),
        Task(action='debug', tags=['debug']),
        Task(action='debug', tags=['debug']),
        Task(action='debug', tags=['debug']),
        Task(action='debug', tags=['debug']),
        Task(action='debug', tags=['debug']),
    ]

# Generated at 2022-06-17 07:12:24.971751
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Create a Block object
    block = Block()
    # Test the method
    assert block.get_dep_chain() == None


# Generated at 2022-06-17 07:12:35.562176
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:12:47.334067
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.handler_task_include import HandlerTaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.role.block import Block as RoleBlock
    from ansible.playbook.role.task import Task as RoleTask
    from ansible.playbook.role.handler import Handler as RoleHandler

# Generated at 2022-06-17 07:12:55.824387
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup

# Generated at 2022-06-17 07:13:04.266227
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Create a new instance of class Block
    block = Block()
    # Create a new instance of class Play
    play = Play()
    # Create a new instance of class Role
    role = Role()
    # Create a new instance of class Task
    task = Task()
    # Create a new instance of class TaskInclude
    task_include = TaskInclude()
    # Create a new instance of class HandlerTaskInclude
    handler_task_include = HandlerTaskInclude()
    # Create a new instance of class Block
    block_1 = Block()
    # Create a new instance of class Block
    block_2 = Block()
    # Create a new instance of class Block
    block_3 = Block()
    # Create a new instance of class Block
    block_4 = Block()
    # Create a new instance of class Block

# Generated at 2022-06-17 07:13:10.862679
# Unit test for method all_parents_static of class Block

# Generated at 2022-06-17 07:13:32.971678
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars

    # Create a block with a task that has a tag
    block = Block()
    block.block = [Task()]
    block

# Generated at 2022-06-17 07:13:42.683782
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 07:13:50.613275
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Create a mock object
    mock_loader = MagicMock()
    mock_loader.get_basedir.return_value = "test_loader_basedir"
    mock_loader.path_dwim.return_value = "test_loader_path_dwim"

    # Create a mock object
    mock_variable_manager = MagicMock()
    mock_variable_manager.get_vars.return_value = "test_variable_manager_vars"

    # Create a mock object
    mock_play = MagicMock()
    mock_play.get_variable_manager.return_value = mock_variable_manager

    # Create a mock object
    mock_role = MagicMock()
    mock_role.get_variable_manager.return_value = mock_variable_manager

    # Create a mock object
    mock_

# Generated at 2022-06-17 07:14:00.156014
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    block.dep_chain = [1, 2, 3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = 'Block'
    block.statically_loaded = True
    block.implicit = True
    block.loop = 'loop'
    block.loop_args = 'loop_args'
    block.when = 'when'
    block.any_errors_fatal = True
    block.always_run = True
    block.register = 'register'
    block.ignore_errors = True
    block.delegate_to = 'delegate_to'

# Generated at 2022-06-17 07:14:05.986087
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = {'foo': 'bar'}


# Generated at 2022-06-17 07:14:07.352212
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:14:17.652941
# Unit test for method filter_tagged_tasks of class Block

# Generated at 2022-06-17 07:14:31.878135
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 07:14:41.827479
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
   