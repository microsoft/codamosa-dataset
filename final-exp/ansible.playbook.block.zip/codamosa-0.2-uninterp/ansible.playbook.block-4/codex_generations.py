

# Generated at 2022-06-17 07:05:35.320188
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # Create a play context
    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager._extra_vars = {'tag1': 'tag1', 'tag2': 'tag2'}

    # Create a loader
    loader = DataLoader()

    # Create an inventory

# Generated at 2022-06-17 07:05:38.353985
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(loader)


# Generated at 2022-06-17 07:05:44.697495
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:05:56.445467
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a block object
    block = Block()
    # Create a task object
    task = Task()
    # Create a task include object
    task_include = TaskInclude()
    # Create a role object
    role = Role()
    # Create a play object
    play = Play()
    # Create a handler task include object
    handler_task_include = HandlerTaskInclude()
    # Create a handler object
    handler = Handler()
    # Create a block object
    block_1 = Block()
    # Create a block object
    block_2 = Block()
    # Create a block object
    block_3 = Block()
    # Create a block object
    block_4 = Block()
    # Create a block object
    block_5 = Block()
    # Create a block object
    block_6 = Block()
    # Create a

# Generated at 2022-06-17 07:06:02.952626
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader

# Generated at 2022-06-17 07:06:10.168824
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block = Block()
    assert block.get_dep_chain() == None
    block._dep_chain = [1,2,3]
    assert block.get_dep_chain() == [1,2,3]
    block._parent = Block()
    assert block.get_dep_chain() == [1,2,3]
    block._dep_chain = None
    block._parent._dep_chain = [4,5,6]
    assert block.get_dep_chain() == [4,5,6]


# Generated at 2022-06-17 07:06:21.592915
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 07:06:30.431266
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:06:37.861767
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b.block = [1,2,3]
    b.rescue = [4,5,6]
    b.always = [7,8,9]
    b.dep_chain = [1,2,3]
    b.role = Role()
    b.parent = Block()
    b.parent_type = 'Block'
    b.statically_loaded = True
    b.implicit = True
    b.loop = 'loop'
    b.loop_args = 'loop_args'
    b.when = 'when'
    b.any_errors_fatal = True
    b.always_run = True
    b.changed_when = 'changed_when'
    b.failed_when = 'failed_when'
    b.ignore_errors = True

# Generated at 2022-06-17 07:06:43.264332
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:07:14.588325
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import Become

# Generated at 2022-06-17 07:07:25.050066
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Test with a block that has no parent
    test_block = Block()
    assert test_block.get_dep_chain() is None

    # Test with a block that has a parent
    test_block = Block()
    test_block._parent = Block()
    assert test_block.get_dep_chain() is None

    # Test with a block that has a parent and a dep_chain
    test_block = Block()
    test_block._parent = Block()
    test_block._dep_chain = [Block()]
    assert test_block.get_dep_chain() == [Block()]


# Generated at 2022-06-17 07:07:27.919100
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block = Block()
    assert block.get_dep_chain() is None
    block = Block(dep_chain=['dep_chain'])
    assert block.get_dep_chain() == ['dep_chain']


# Generated at 2022-06-17 07:07:39.538706
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    block.dep_chain = [1, 2, 3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = 'Block'
    block.play = Play()
    block.use_handlers = True
    block.statically_loaded = True
    block.implicit = True
    block.loop = 'loop'
    block.loop_args = 'loop_args'
    block.when = 'when'
    block.any_errors_fatal = True
    block.continue_on_error = True
    block.delegate_to = 'delegate_to'
    block.delegate_

# Generated at 2022-06-17 07:07:40.532987
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:07:41.722284
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:07:47.634104
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-17 07:07:59.307068
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    block.dep_chain = [1,2,3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = 'Block'
    block.statically_loaded = True
    block.name = 'block'
    block.loop = 'loop'
    block.when = 'when'
    block.any_errors_fatal = True
    block.always_run = True
    block.register = 'register'
    block.ignore_errors = True
    block.delegate_to = 'delegate_to'
    block.run_once = True
    block.connection = 'connection'
    block

# Generated at 2022-06-17 07:08:08.790165
# Unit test for method copy of class Block
def test_Block_copy():
    # Create a mock object for the class Block
    mock_Block = mock.Mock(spec=Block)
    # Create a mock object for the class Task
    mock_Task = mock.Mock(spec=Task)
    # Create a mock object for the class TaskInclude
    mock_TaskInclude = mock.Mock(spec=TaskInclude)
    # Create a mock object for the class HandlerTaskInclude
    mock_HandlerTaskInclude = mock.Mock(spec=HandlerTaskInclude)
    # Create a mock object for the class Role
    mock_Role = mock.Mock(spec=Role)
    # Create a mock object for the class Play
    mock_Play = mock.Mock(spec=Play)
    # Create a mock object for the class Block
    mock_Block_1 = mock.Mock(spec=Block)


# Generated at 2022-06-17 07:08:18.354870
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    block.loop = "{{loop}}"
    block.when = "{{when}}"
    block.name = "{{name}}"
    block.tags = "{{tags}}"
    block.register = "{{register}}"
    block.until = "{{until}}"
    block.notify = "{{notify}}"
    block.failed_when = "{{failed_when}}"
    block.changed_when = "{{changed_when}}"
    block.ignore_errors = "{{ignore_errors}}"
    block.dep_chain = "{{dep_chain}}"
    block.role = "{{role}}"

# Generated at 2022-06-17 07:08:56.649429
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']

    block = Block()
    block.vars = dict()
    block.vars['tag1'] = True
    block.vars['tag2'] = False
    block.vars['tag3'] = False
   

# Generated at 2022-06-17 07:08:57.982856
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:09:05.870341
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    block.dep_chain = [1, 2, 3]
    block.role = Role()
    block.parent = Block()
    block.validate()
    new_block = block.copy()
    assert new_block.block == [1, 2, 3]
    assert new_block.rescue == [4, 5, 6]
    assert new_block.always == [7, 8, 9]
    assert new_block.dep_chain == [1, 2, 3]
    assert new_block.role == block.role
    assert new_block.parent == block.parent
    assert new_block.validate()

# Unit test

# Generated at 2022-06-17 07:09:14.089694
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

# Generated at 2022-06-17 07:09:27.549094
# Unit test for method filter_tagged_tasks of class Block

# Generated at 2022-06-17 07:09:38.860866
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [ 'block' ]
    block.rescue = [ 'rescue' ]
    block.always = [ 'always' ]
    block.dep_chain = [ 'dep_chain' ]
    block.role = 'role'
    block.parent = 'parent'
    block.statically_loaded = 'statically_loaded'
    block.implicit = 'implicit'
    block.use_handlers = 'use_handlers'
    block.play = 'play'
    block.task_include = 'task_include'
    block.variable_manager = 'variable_manager'
    block.loader = 'loader'
    block.validate()
    block.copy()
    block.copy(exclude_parent=True)
    block.copy(exclude_tasks=True)


# Generated at 2022-06-17 07:09:39.816286
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block()
    b.set_loader(None)


# Generated at 2022-06-17 07:09:48.503517
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader

# Generated at 2022-06-17 07:09:54.354592
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Create a Block object
    block = Block()
    # Test the method get_dep_chain
    assert block.get_dep_chain() == None


# Generated at 2022-06-17 07:09:58.708461
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'role': {'name': 'test'}, 'parent': {'role': {'name': 'test'}}, 'parent_type': 'Block'})
    assert block._role.name == 'test'
    assert block._parent._role.name == 'test'
    assert block._parent_type == 'Block'


# Generated at 2022-06-17 07:10:55.488274
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Test with a Block object
    b = Block()
    b._parent = Block()
    b._parent.statically_loaded = True
    assert b.all_parents_static()
    b._parent.statically_loaded = False
    assert not b.all_parents_static()

    # Test with a TaskInclude object
    from ansible.playbook.task_include import TaskInclude
    b = Block()
    b._parent = TaskInclude()
    b._parent.statically_loaded = True
    assert b.all_parents_static()
    b._parent.statically_loaded = False
    assert not b.all_parents_static()


# Generated at 2022-06-17 07:11:07.089727
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    block.dep_chain = [1, 2, 3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = 'Block'
    block.validate()
    new_block = block.copy()
    assert new_block.block == [1, 2, 3]
    assert new_block.rescue == [4, 5, 6]
    assert new_block.always == [7, 8, 9]
    assert new_block.dep_chain == [1, 2, 3]
    assert new_block.role == Role()
    assert new_block.parent == Block()
    assert new_block

# Generated at 2022-06-17 07:11:18.272367
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:11:28.515880
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    block.dep_chain = [1,2,3]
    block.role = Role()
    block.role.name = 'test'
    block.role.path = 'test'
    block.role.default_vars = {'a':1}
    block.role.tasks = [1,2,3]
    block.role.handlers = [1,2,3]
    block.role.meta = {'a':1}
    block.role.vars = {'a':1}
    block.role.default_vars = {'a':1}

# Generated at 2022-06-17 07:11:35.652705
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_queue_manager import TaskQueueManager
    from ansible.playbook.handler_task_queue_manager import HandlerTaskQueueManager

# Generated at 2022-06-17 07:11:39.841030
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Create a Block object
    block = Block()
    # Create a loader object
    loader = DataLoader()
    # Call the method set_loader of class Block
    block.set_loader(loader)
    # Check if the method set_loader of class Block returns None
    assert block.set_loader(loader) is None


# Generated at 2022-06-17 07:11:46.741376
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block

# Generated at 2022-06-17 07:11:51.885423
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Test with no parent
    b = Block()
    assert b.get_dep_chain() is None

    # Test with parent
    b = Block(parent_block=Block())
    assert b.get_dep_chain() == []

    # Test with parent and dep_chain
    b = Block(parent_block=Block(), dep_chain=[Block()])
    assert b.get_dep_chain() == [Block()]



# Generated at 2022-06-17 07:11:53.345289
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(None)
    assert block._loader == None


# Generated at 2022-06-17 07:12:01.481063
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 07:12:39.957702
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    block.dep_chain = [1, 2, 3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = 'Block'
    block.play = Play()
    block.use_handlers = True
    block.statically_loaded = True
    block.implicit = True
    block.post_validate = True
    block.any_errors_fatal = True
    block.always_run = True
    block.no_log = True
    block.delegate_to = 'localhost'
    block.run_once = True
    block.notify = ['localhost']
    block.first

# Generated at 2022-06-17 07:12:49.864289
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

# Generated at 2022-06-17 07:12:57.870441
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar

# Generated at 2022-06-17 07:13:07.367873
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.handler_task_include import HandlerTaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

# Generated at 2022-06-17 07:13:16.477073
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:13:28.169791
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:13:31.670248
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block = Block()
    assert block.get_dep_chain() == None


# Generated at 2022-06-17 07:13:41.682451
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:13:47.506120
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a block
    b = Block()
    # Create a block
    b2 = Block()
    # Create a block
    b3 = Block()
    # Create a block
    b4 = Block()
    # Create a block
    b5 = Block()
    # Create a block
    b6 = Block()
    # Create a block
    b7 = Block()
    # Create a block
    b8 = Block()
    # Create a block
    b9 = Block()
    # Create a block
    b10 = Block()
    # Create a block
    b11 = Block()
    # Create a block
    b12 = Block()
    # Create a block
    b13 = Block()
    # Create a block
    b14 = Block()
    # Create a block
    b15 = Block()
    # Create a block

# Generated at 2022-06-17 07:13:50.515534
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Test case 1
    block = Block()
    block._dep_chain = [1,2,3]
    assert block.get_dep_chain() == [1,2,3]
    # Test case 2
    block = Block()
    block._parent = Block()
    block._parent._dep_chain = [1,2,3]
    assert block.get_dep_chain() == [1,2,3]


# Generated at 2022-06-17 07:14:33.140112
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude