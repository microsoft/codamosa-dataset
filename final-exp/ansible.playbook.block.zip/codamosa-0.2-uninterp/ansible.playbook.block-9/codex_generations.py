

# Generated at 2022-06-17 07:05:06.427320
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [1,2,3]
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    block.rescue = []
    block.always = []
    assert block.has_tasks() == False
    block.block = [1,2,3]
    block.rescue = []
    block.always = []
    assert block.has_tasks() == True
    block.block = []
    block.rescue = [1,2,3]
    block.always = []
    assert block.has_tasks() == True
    block.block = []
    block.rescue = []
    block.always = [1,2,3]

# Generated at 2022-06-17 07:05:10.509956
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:05:13.125559
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block(dict(block=[dict(action='setup')]))
    assert not Block.is_block(dict(action='setup'))
    assert not Block.is_block([dict(action='setup')])


# Generated at 2022-06-17 07:05:17.636914
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Test 1
    # Setup
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    all_vars = {}
    # Exercise
    result = block.filter_tagged_tasks(all_vars)
    # Verify
    assert result.block == [1, 2, 3]
    assert result.rescue == [4, 5, 6]
    assert result.always == [7, 8, 9]
    # Cleanup - none necessary

    # Test 2
    # Setup
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    all_

# Generated at 2022-06-17 07:05:29.104763
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    assert block.has_tasks() == True
    block.block = []
    block.rescue = []
    block.always = []
    assert block.has_tasks() == False
    block.block = [1,2,3]
    block.rescue = []
    block.always = []
    assert block.has_tasks() == True
    block.block = []
    block.rescue = [4,5,6]
    block.always = []
    assert block.has_tasks() == True
    block.block = []
    block.rescue = []
    block.always = [7,8,9]

# Generated at 2022-06-17 07:05:35.863580
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block

# Generated at 2022-06-17 07:05:40.152601
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:05:51.549083
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_

# Generated at 2022-06-17 07:05:57.959898
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup
    from ansible.vars.hostvars import HostVarsGroups

# Generated at 2022-06-17 07:06:06.663516
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # Test with a simple task
    b = Block()
    ds = dict(name='test')
    assert b.preprocess_data(ds) == dict(block=[ds])

    # Test with a list of tasks
    ds = [dict(name='test'), dict(name='test2')]
    assert b.preprocess_data(ds) == dict(block=ds)

    # Test with a block
    ds = dict(block=[dict(name='test')])
    assert b.preprocess_data(ds) == ds

    # Test with a rescue
    ds = dict(rescue=[dict(name='test')])
    assert b.preprocess_data(ds) == ds

    # Test with a always
    ds = dict(always=[dict(name='test')])
    assert b.preprocess_

# Generated at 2022-06-17 07:06:31.536130
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play

# Generated at 2022-06-17 07:06:32.717802
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(loader)


# Generated at 2022-06-17 07:06:33.899593
# Unit test for method serialize of class Block
def test_Block_serialize():
    block = Block()
    block.serialize()


# Generated at 2022-06-17 07:06:42.129288
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:06:52.636972
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.color import colorize, hostcolor

# Generated at 2022-06-17 07:07:02.864895
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-17 07:07:13.104563
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.errors import AnsibleParserError

# Generated at 2022-06-17 07:07:23.654433
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:07:24.739263
# Unit test for method serialize of class Block
def test_Block_serialize():
    block = Block()
    block.serialize()


# Generated at 2022-06-17 07:07:27.311570
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Test for method get_dep_chain(self)
    # of class Block
    #
    # This test is not implemented.
    #
    # TODO: Implement this test.
    #
    # assert(False, "Test not implemented.")
    pass


# Generated at 2022-06-17 07:08:13.250507
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    block.dep_chain = [1,2,3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = 'Block'
    block.play = Play()
    block.use_handlers = True
    block.statically_loaded = True
    block.implicit = True
    block.loop = 'loop'
    block.loop_args = 'loop_args'
    block.when = 'when'
    block.any_errors_fatal = True
    block.always_run = True
    block.register = 'register'
    block.ignore_errors = True
    block.delegate

# Generated at 2022-06-17 07:08:24.545072
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    new_block = block.copy()
    assert new_block.block == [1,2,3]
    assert new_block.rescue == [4,5,6]
    assert new_block.always == [7,8,9]
    assert new_block is not block
    assert new_block.block is not block.block
    assert new_block.rescue is not block.rescue
    assert new_block.always is not block.always
    assert new_block.block[0] is block.block[0]
    assert new_block.rescue[0] is block.rescue[0]

# Generated at 2022-06-17 07:08:34.079971
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    block.block = [1, 2, 3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.block = [1, 2, 3]
    block.rescue = [1, 2, 3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == True
    block.block = []
    block.always = [1, 2, 3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:08:38.876743
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize(dict(block=[dict(action='debug', args=dict(msg='foo'))]))
    assert block.block[0].action == 'debug'
    assert block.block[0].args['msg'] == 'foo'


# Generated at 2022-06-17 07:08:45.827237
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:08:57.230134
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash


# Generated at 2022-06-17 07:09:05.345982
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False

# Generated at 2022-06-17 07:09:08.035225
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a Block object
    block = Block()
    # Test all_parents_static method
    assert block.all_parents_static() == True


# Generated at 2022-06-17 07:09:14.243617
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:09:27.647215
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 07:10:06.850057
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 07:10:15.589340
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:10:28.191501
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Create a block object
    block = Block()
    # Create a task object
    task = Task()
    # Create a role object
    role = Role()
    # Create a play object
    play = Play()
    # Create a task include object
    task_include = TaskInclude()
    # Create a handler task include object
    handler_task_include = HandlerTaskInclude()
    # Create a handler object
    handler = Handler()
    # Create a block object
    block1 = Block()
    # Create a block object
    block2 = Block()
    # Create a block object
    block3 = Block()
    # Create a block object
    block4 = Block()
    # Create a block object
    block5 = Block()
    # Create a block object
    block6 = Block()
    # Create a block object
    block7

# Generated at 2022-06-17 07:10:40.641650
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    block.dep_chain = [1,2,3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = "Block"
    block.statically_loaded = True
    block.name = "Block"
    block.loop = "loop"
    block.when = "when"
    block.loop_control = "loop_control"
    block.any_errors_fatal = "any_errors_fatal"
    block.any_unreachable_fatal = "any_unreachable_fatal"
    block.changed_when = "changed_when"
    block.failed_when

# Generated at 2022-06-17 07:10:48.562492
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_block import HandlerBlock
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

# Generated at 2022-06-17 07:10:56.344052
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 07:11:01.052446
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    assert block.has_tasks() == True
    block.block = []
    block.rescue = []
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:11:12.128496
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_block import HandlerBlock

# Generated at 2022-06-17 07:11:21.672906
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:11:26.583558
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader

# Generated at 2022-06-17 07:11:58.328563
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.template import Templar
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
   

# Generated at 2022-06-17 07:12:09.449612
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:12:20.457459
# Unit test for method copy of class Block
def test_Block_copy():
    # Test with exclude_parent=False, exclude_tasks=False
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    block._dep_chain = [1, 2, 3]
    block._parent = 1
    block._role = 1
    new_block = block.copy()
    assert new_block.block == [1, 2, 3]
    assert new_block.rescue == [4, 5, 6]
    assert new_block.always == [7, 8, 9]
    assert new_block._dep_chain == [1, 2, 3]
    assert new_block._parent == 1
    assert new_block._role == 1

    # Test with exclude_parent=True,

# Generated at 2022-06-17 07:12:22.619500
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:12:32.850048
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a block
    b = Block()

# Generated at 2022-06-17 07:12:44.245699
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
   

# Generated at 2022-06-17 07:12:49.058443
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Test with _dep_chain is None
    block = Block()
    assert block.get_dep_chain() is None

    # Test with _dep_chain is not None
    block._dep_chain = [1, 2, 3]
    assert block.get_dep_chain() == [1, 2, 3]


# Generated at 2022-06-17 07:12:50.320198
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:12:51.226151
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b.copy()


# Generated at 2022-06-17 07:13:02.721190
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-17 07:13:21.614715
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block()
    b.set_loader(None)


# Generated at 2022-06-17 07:13:31.296753
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    block.dep_chain = [1, 2, 3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = 'Block'
    block.play = Play()
    block.use_handlers = True
    block.statically_loaded = True
    block.implicit = True
    block.loop = 'loop'
    block.loop_args = 'loop_args'
    block.when = 'when'
    block.any_errors_fatal = 'any_errors_fatal'
    block.always_run = 'always_run'
    block.register = 'register'

# Generated at 2022-06-17 07:13:36.378444
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.template import Templar
   

# Generated at 2022-06-17 07:13:44.272794
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.include_role import IncludeRole
    from ansible.playbook.include_task import IncludeTask

# Generated at 2022-06-17 07:13:48.568323
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({})


# Generated at 2022-06-17 07:13:55.965730
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 07:14:00.087623
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block()
    b.set_loader(None)


# Generated at 2022-06-17 07:14:05.947025
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-17 07:14:16.294294
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    block = Block()
    data = dict()
    data['role'] = dict()
    data['parent'] = dict()
    data['parent_type'] = 'Block'
    block.deserialize(data)
    assert block._role is None
    assert block._parent is None
    data['role'] = dict()
    data['parent'] = dict()
    data['parent_type'] = 'TaskInclude'
    block.deserialize(data)
    assert block._role is None
    assert isinstance(block._parent, TaskInclude)
    data['role'] = dict()
    data['parent'] = dict()
    data['parent_type'] = 'HandlerTaskInclude'

# Generated at 2022-06-17 07:14:24.576897
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler