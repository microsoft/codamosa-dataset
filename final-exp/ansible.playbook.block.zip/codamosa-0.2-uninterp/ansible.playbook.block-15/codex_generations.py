

# Generated at 2022-06-17 07:05:29.387870
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:05:33.253997
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'role': {'name': 'test_role'}, 'parent': {'name': 'test_parent'}, 'parent_type': 'Block'})
    assert block._role.name == 'test_role'
    assert block._parent.name == 'test_parent'
    assert block._parent.__class__.__name__ == 'Block'


# Generated at 2022-06-17 07:05:40.440864
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader

# Generated at 2022-06-17 07:05:51.771415
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 07:05:58.147719
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create a play
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.remote_addr = '127.0.0.1'


# Generated at 2022-06-17 07:06:06.662496
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.errors import AnsibleParserError
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
   

# Generated at 2022-06-17 07:06:10.078171
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # Create a block object
    b = Block()
    # Create a dictionary
    ds = {'block': [{'action': 'debug', 'msg': 'Hello World'}]}
    # Call the method preprocess_data of class Block
    b.preprocess_data(ds)
    # Assert that the dictionary is equal to the dictionary returned by the method preprocess_data of class Block
    assert ds == b.preprocess_data(ds)


# Generated at 2022-06-17 07:06:20.448167
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:06:28.834697
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()

# Generated at 2022-06-17 07:06:40.070450
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
   

# Generated at 2022-06-17 07:07:26.559881
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a block
    b = Block()
    # Create a task
    t = Task()
    # Create a play
    p = Play()
    # Create a variable manager
    v = VariableManager()
    # Create a loader
    l = DataLoader()
    # Create a variable manager
    v = VariableManager()
    # Create a variable manager options
    vmo = VariableManagerOptions()
    # Create a inventory
    i = Inventory(loader=l, variable_manager=v, host_list=[])
    # Create a play context
    pc = PlayContext()
    # Create a task queue manager
    tqm = None
    # Create a loader
    l = DataLoader()
    # Create a variable manager
    v = VariableManager(loader=l, inventory=i, variable_manager_options=vmo)
    # Create a playbook

# Generated at 2022-06-17 07:07:38.985478
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    block.dep_chain = [1,2,3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = 'Block'
    block.statically_loaded = True
    block.implicit = True
    block.loop = 'loop'
    block.loop_args = 'loop_args'
    block.loop_control = 'loop_control'
    block.when = 'when'
    block.changed_when = 'changed_when'
    block.failed_when = 'failed_when'
    block.until = 'until'
    block.retries = 'retries'

# Generated at 2022-06-17 07:07:48.387231
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 07:08:00.025731
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block

    # Create a play
    play_context = PlayContext()
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'root'
    play_context.connection = 'ssh'
    play_context.port = 22

# Generated at 2022-06-17 07:08:09.413913
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a block
    block = Block()
    # Create a task
    task = Task()
    # Create a block
    block1 = Block()
    # Create a task
    task1 = Task()
    # Create a block
    block2 = Block()
    # Create a task
    task2 = Task()
    # Create a block
    block3 = Block()
    # Create a task
    task3 = Task()
    # Create a block
    block4 = Block()
    # Create a task
    task4 = Task()
    # Create a block
    block5 = Block()
    # Create a task
    task5 = Task()
    # Create a block
    block6 = Block()
    # Create a task
    task6 = Task()
    # Create a block
    block7 = Block()
    # Create a task


# Generated at 2022-06-17 07:08:15.928794
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block

# Generated at 2022-06-17 07:08:26.161980
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

# Generated at 2022-06-17 07:08:31.639680
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:08:41.227590
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import Play

# Generated at 2022-06-17 07:08:48.419234
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Test case 1
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    block.tags = ['tag1', 'tag2']
    block.when = 'when'
    block.any_errors_fatal = True
    block.always_run = True
    block.register = 'register'
    block.ignore_errors = True
    block.delegate_to = 'delegate_to'
    block.notify = ['notify1', 'notify2']
    block.first_available_file = 'first_available_file'
    block.local_action = 'local_action'
    block.transport = 'transport'
    block.remote_user = 'remote_user'

# Generated at 2022-06-17 07:09:12.557045
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader

# Generated at 2022-06-17 07:09:26.741356
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [
        {
            'name': 'test',
            'action': 'debug',
            'args': {
                'msg': 'test'
            }
        }
    ]
    block.rescue = [
        {
            'name': 'test',
            'action': 'debug',
            'args': {
                'msg': 'test'
            }
        }
    ]
    block.always = [
        {
            'name': 'test',
            'action': 'debug',
            'args': {
                'msg': 'test'
            }
        }
    ]
    block.when = 'test'
    block.loop = 'test'
    block.loop_control = {
        'loop_var': 'test'
    }
    block.retries

# Generated at 2022-06-17 07:09:38.474564
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

# Generated at 2022-06-17 07:09:41.367248
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block = Block()
    assert block.get_dep_chain() is None

    block._dep_chain = [1, 2, 3]
    assert block.get_dep_chain() == [1, 2, 3]


# Generated at 2022-06-17 07:09:43.507144
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Setup
    b = Block()
    b._dep_chain = [1, 2, 3]
    # Exercise
    result = b.get_dep_chain()
    # Verify
    assert result == [1, 2, 3]
    # Cleanup - none necessary



# Generated at 2022-06-17 07:09:51.411876
# Unit test for method copy of class Block
def test_Block_copy():
    # Create a mock object for the class Block
    mock_Block = MagicMock()
    # Create a mock object for the class Task
    mock_Task = MagicMock()
    # Create a mock object for the class Role
    mock_Role = MagicMock()
    # Create a mock object for the class TaskInclude
    mock_TaskInclude = MagicMock()
    # Create a mock object for the class HandlerTaskInclude
    mock_HandlerTaskInclude = MagicMock()
    # Create a mock object for the class Block
    mock_Block2 = MagicMock()
    # Create a mock object for the class Task
    mock_Task2 = MagicMock()
    # Create a mock object for the class Role
    mock_Role2 = MagicMock()
    # Create a mock object for the class TaskInclude
    mock_TaskIn

# Generated at 2022-06-17 07:10:00.513181
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test case 1:
    #   Block
    #   |
    #   |- TaskInclude
    #   |- Block
    #   |  |
    #   |  |- TaskInclude
    #   |  |- TaskInclude
    #   |  |- Block
    #   |  |  |
    #   |  |  |- TaskInclude
    #   |  |  |- TaskInclude
    #   |  |  |- Task

# Generated at 2022-06-17 07:10:12.403595
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-17 07:10:20.701679
# Unit test for method copy of class Block
def test_Block_copy():
    # Create a new Block object
    block = Block()
    # Create a new Block object
    block_copy = block.copy()
    # Check if the copy is a Block object
    assert isinstance(block_copy, Block)
    # Check if the copy is equal to the original
    assert block_copy == block


# Generated at 2022-06-17 07:10:28.823872
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:10:56.007294
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude

# Generated at 2022-06-17 07:11:07.548350
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup

# Generated at 2022-06-17 07:11:08.555540
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(loader)


# Generated at 2022-06-17 07:11:16.381165
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
   

# Generated at 2022-06-17 07:11:27.146231
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-17 07:11:35.134191
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import Host

# Generated at 2022-06-17 07:11:45.855682
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
   

# Generated at 2022-06-17 07:11:54.610051
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:12:06.372455
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-17 07:12:16.171214
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:12:36.990538
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    block.dep_chain = [1,2,3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = 'Block'
    block.play = Play()
    block.use_handlers = True
    block.statically_loaded = True
    block.implicit = True
    block.loop = 'loop'
    block.loop_args = 'loop_args'
    block.when = 'when'
    block.changed_when = 'changed_when'
    block.failed_when = 'failed_when'
    block.until = 'until'

# Generated at 2022-06-17 07:12:38.718636
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(loader)
    assert block._loader == loader


# Generated at 2022-06-17 07:12:43.481663
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:12:51.043721
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block

    # Create a TaskInclude object
    task_include = TaskInclude()
    task_include.statically_loaded = False
    assert task_include.all_parents_static() == False

    # Create a HandlerTaskInclude object
    handler_task_include = HandlerTaskInclude()
    handler_task_include.statically_loaded = False
    assert handler_task_include.all_parents_static() == False

    # Create a Task object
    task = Task()
    task.statically_loaded = False
    assert task.all

# Generated at 2022-06-17 07:13:02.658828
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:13:09.423158
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:13:11.785735
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:13:19.765286
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:13:28.468479
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
   

# Generated at 2022-06-17 07:13:40.573848
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 07:14:14.352131
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:14:22.525972
# Unit test for method copy of class Block
def test_Block_copy():
    # Create a new Block object
    block = Block()
    # Copy the Block object
    new_block = block.copy()
    # Assert the new Block object is not the same as the original
    assert new_block is not block
    # Assert the new Block object is an instance of Block
    assert isinstance(new_block, Block)


# Generated at 2022-06-17 07:14:34.547402
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

# Generated at 2022-06-17 07:14:43.326203
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler