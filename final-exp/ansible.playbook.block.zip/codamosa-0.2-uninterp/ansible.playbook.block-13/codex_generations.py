

# Generated at 2022-06-17 07:05:28.627033
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    b = Block()

# Generated at 2022-06-17 07:05:38.036292
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [Task()]
    assert block.has_tasks() == True
    block.block = []
    block.rescue = [Task()]
    assert block.has_tasks() == True
    block.rescue = []
    block.always = [Task()]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:05:45.719364
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook

# Generated at 2022-06-17 07:05:56.684146
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import Ansible

# Generated at 2022-06-17 07:06:03.107866
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.included_file import IncludedFile
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:06:11.312020
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1, 2, 3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1, 2, 3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1, 2, 3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:06:18.541964
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-17 07:06:28.192663
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    block.dep_chain = [1,2,3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = 'Block'
    block.statically_loaded = True
    block.use_handlers = True
    block.implicit = True
    block.loop = True
    block.loop_control = True
    block.when = True
    block.any_errors_fatal = True
    block.changed_when = True
    block.failed_when = True
    block.always_run = True
    block.register = True
    block.ignore_errors = True
    block.delegate

# Generated at 2022-06-17 07:06:39.668927
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:06:44.122783
# Unit test for method serialize of class Block
def test_Block_serialize():
    block = Block()
    assert block.serialize() == {'dep_chain': None}


# Generated at 2022-06-17 07:07:17.316931
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:07:24.507705
# Unit test for method all_parents_static of class Block

# Generated at 2022-06-17 07:07:31.064984
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:07:39.286167
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [{'name': 'test'}]
    block.rescue = [{'name': 'test'}]
    block.always = [{'name': 'test'}]
    block.dep_chain = ['test']
    block.role = Role()
    block.parent = Block()
    block.parent_type = 'Block'
    block.validate()
    block.copy()


# Generated at 2022-06-17 07:07:45.509311
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Test with a Block object
    block = Block()
    block.statically_loaded = True
    assert block.all_parents_static() == True
    block.statically_loaded = False
    assert block.all_parents_static() == False
    # Test with a TaskInclude object
    from ansible.playbook.task_include import TaskInclude
    task_include = TaskInclude()
    task_include.statically_loaded = True
    assert task_include.all_parents_static() == True
    task_include.statically_loaded = False
    assert task_include.all_parents_static() == False
    # Test with a Block object and a TaskInclude object
    block = Block()
    block.statically_loaded = True
    task_include = TaskInclude()
    task_include.statically_loaded

# Generated at 2022-06-17 07:07:57.453954
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
   

# Generated at 2022-06-17 07:08:01.271466
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize(dict(block=[dict(action="debug", args=dict(msg="hello"))]))
    assert block.block[0].action == "debug"
    assert block.block[0].args["msg"] == "hello"


# Generated at 2022-06-17 07:08:10.441346
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup

# Generated at 2022-06-17 07:08:18.515886
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.task_context import TaskContext
    from ansible.playbook.block_context import BlockContext
    from ansible.playbook.handler_context import HandlerContext
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 07:08:24.422164
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import Play

# Generated at 2022-06-17 07:08:55.450082
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import Host

# Generated at 2022-06-17 07:09:00.350972
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    assert block.has_tasks() == True
    block.block = []
    block.rescue = []
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:09:10.854513
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

# Generated at 2022-06-17 07:09:12.923228
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:09:26.960195
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-17 07:09:38.692646
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader

# Generated at 2022-06-17 07:09:44.210295
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a block object
    block = Block()
    # Create a task object
    task = Task()
    # Create a task include object
    task_include = TaskInclude()
    # Create a block object
    block_1 = Block()
    # Create a block object
    block_2 = Block()
    # Create a block object
    block_3 = Block()
    # Create a block object
    block_4 = Block()
    # Create a block object
    block_5 = Block()
    # Create a block object
    block_6 = Block()
    # Create a block object
    block_7 = Block()
    # Create a block object
    block_8 = Block()
    # Create a block object
    block_9 = Block()
    # Create a block object
    block_10 = Block()
    # Create a block

# Generated at 2022-06-17 07:09:49.371268
# Unit test for method is_block of class Block
def test_Block_is_block():
    data = dict(
        block = [
            dict(
                name = "test",
                action = dict(
                    module = "shell",
                    args = "ls"
                )
            )
        ]
    )
    assert Block.is_block(data) == True


# Generated at 2022-06-17 07:10:00.324118
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:10:12.218362
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:10:40.450827
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
   

# Generated at 2022-06-17 07:10:48.425034
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    b = Block()

# Generated at 2022-06-17 07:10:50.402404
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:10:55.006726
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [{'name': 'test'}]
    block.rescue = [{'name': 'test'}]
    block.always = [{'name': 'test'}]
    block.copy()


# Generated at 2022-06-17 07:10:57.295584
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Create a Block object
    block = Block()
    # Test the method get_dep_chain
    assert block.get_dep_chain() == None


# Generated at 2022-06-17 07:10:58.879422
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:11:10.456262
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'block': [{'action': 'debug', 'args': {'msg': 'Hello world'}, 'name': 'debug'}], 'dep_chain': [], 'parent': {'block': [{'action': 'debug', 'args': {'msg': 'Hello world'}, 'name': 'debug'}], 'dep_chain': [], 'parent': None, 'parent_type': None, 'role': None, 'when': None}, 'parent_type': 'Block', 'role': None, 'when': None})
    assert block.block[0].action == 'debug'
    assert block.block[0].args['msg'] == 'Hello world'
    assert block.block[0].name == 'debug'
    assert block.dep_chain == []

# Generated at 2022-06-17 07:11:20.340059
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:11:22.984870
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:11:29.428299
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

# Generated at 2022-06-17 07:11:56.951964
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role

# Generated at 2022-06-17 07:12:08.260279
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a block
    block = Block()
    # Create a task
    task = Task()
    # Create a task list
    task_list = [task]
    # Create a variable manager
    variable_manager = VariableManager()
    # Create a loader
    loader = DataLoader()
    # Create a play
    play = Play()
    # Create a play context
    play_context = PlayContext()
    # Set the loader of the block
    block.set_loader(loader)
    # Set the variable manager of the block
    block.set_variable_manager(variable_manager)
    # Set the play of the block
    block.set_play(play)
    # Set the play context of the block
    block.set_play_context(play_context)
    # Set the block of the block
    block.block = task_

# Generated at 2022-06-17 07:12:18.950456
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:12:28.617551
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a Block object
    b = Block()
    # Create a Task object
    t = Task()
    # Create a Block object
    b1 = Block()
    # Create a Task object
    t1 = Task()
    # Create a Block object
    b2 = Block()
    # Create a Task object
    t2 = Task()
    # Create a Block object
    b3 = Block()
    # Create a Task object
    t3 = Task()
    # Create a Block object
    b4 = Block()
    # Create a Task object
    t4 = Task()
    # Create a Block object
    b5 = Block()
    # Create a Task object
    t5 = Task()
    # Create a Block object
    b6 = Block()
    # Create a Task object
    t6 = Task()
    # Create a Block

# Generated at 2022-06-17 07:12:36.286800
# Unit test for method is_block of class Block
def test_Block_is_block():
    # Test with a dictionary
    ds = {'block': [{'name': 'test'}]}
    assert Block.is_block(ds) == True
    # Test with a list
    ds = [{'name': 'test'}]
    assert Block.is_block(ds) == False
    # Test with a string
    ds = 'test'
    assert Block.is_block(ds) == False
    # Test with a number
    ds = 1
    assert Block.is_block(ds) == False
    # Test with a boolean
    ds = True
    assert Block.is_block(ds) == False
    # Test with a None
    ds = None
    assert Block.is_block(ds) == False


# Generated at 2022-06-17 07:12:37.382394
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:12:43.668170
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a block
    b = Block()
    # Create a task
    t = Task()
    # Create a task include
    ti = TaskInclude()
    # Create a role
    r = Role()
    # Create a play
    p = Play()
    # Create a block
    b2 = Block()
    # Create a task
    t2 = Task()
    # Create a task include
    ti2 = TaskInclude()
    # Create a role
    r2 = Role()
    # Create a play
    p2 = Play()
    # Create a block
    b3 = Block()
    # Create a task
    t3 = Task()
    # Create a task include
    ti3 = TaskInclude()
    # Create a role
    r3 = Role()
    # Create a play
    p3 = Play()


# Generated at 2022-06-17 07:12:53.058084
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.handler_task_include import HandlerTaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.tasks import Tasks
    from ansible.playbook.role.handlers import Handlers
    from ansible.playbook.role.vars import Vars

# Generated at 2022-06-17 07:13:03.367074
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 07:13:08.229497
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1, 2, 3]
    assert block.has_tasks() == True
    block.block = []
    block.rescue = [1, 2, 3]
    assert block.has_tasks() == True
    block.rescue = []
    block.always = [1, 2, 3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:13:31.390906
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_include import HandlerInclude

# Generated at 2022-06-17 07:13:36.457191
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.only_tags = ['tag1']
    play_context.skip_tags = ['tag2']
    play_context.tags = ['tag1', 'tag2']

    block = Block()

# Generated at 2022-06-17 07:13:39.118720
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'block': [{'action': 'debug', 'args': {'msg': 'Hello world'}, 'name': 'Hello world'}], 'dep_chain': [], 'always': [], 'rescue': [], 'when': 'True', 'loop': '', 'loop_control': {'loop_var': '', 'label': ''}})
    assert block.block[0].name == 'Hello world'


# Generated at 2022-06-17 07:13:44.486047
# Unit test for method copy of class Block
def test_Block_copy():
    # Create a new Block object
    block = Block()
    # Create a new Block object
    block_copy = block.copy()
    # Check if the two objects are equal
    assert block == block_copy


# Generated at 2022-06-17 07:13:55.152594
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup

# Generated at 2022-06-17 07:14:01.228686
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a Block object
    b = Block()
    # Create a Play object
    p = Play()
    # Create a Task object
    t = Task()
    # Create a Block object
    b1 = Block()
    # Create a Task object
    t1 = Task()
    # Create a Task object
    t2 = Task()
    # Create a Task object
    t3 = Task()
    # Create a Task object
    t4 = Task()
    # Create a Task object
    t5 = Task()
    # Create a Task object
    t6 = Task()
    # Create a Task object
    t7 = Task()
    # Create a Task object
    t8 = Task()
    # Create a Task object
    t9 = Task()
    # Create a Task object
    t10 = Task()
    # Create a Task object

# Generated at 2022-06-17 07:14:02.383440
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # TODO: implement
    pass


# Generated at 2022-06-17 07:14:14.696212
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-17 07:14:23.515074
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # Test with a simple task
    b = Block()
    ds = dict(name='test')
    result = b.preprocess_data(ds)
    assert result == dict(block=[ds])

    # Test with a block
    ds = dict(block=[ds])
    result = b.preprocess_data(ds)
    assert result == ds


# Generated at 2022-06-17 07:14:33.006561
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False
