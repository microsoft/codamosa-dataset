

# Generated at 2022-06-17 07:05:05.667953
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()

# Generated at 2022-06-17 07:05:09.074748
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [{'name': 'test'}]
    block.rescue = [{'name': 'test'}]
    block.always = [{'name': 'test'}]
    block.dep_chain = ['test']
    block.role = Role()
    block.parent = Block()
    block.validate()
    block.copy()


# Generated at 2022-06-17 07:05:15.046916
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:05:27.261000
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'block': [{'action': 'debug', 'args': {'msg': 'hello world'}, 'name': 'debug'}], 'dep_chain': [], 'parent': {'block': [{'action': 'debug', 'args': {'msg': 'hello world'}, 'name': 'debug'}], 'dep_chain': [], 'parent': None, 'parent_type': None, 'role': None}, 'parent_type': 'Block'})
    assert block.block[0].args['msg'] == 'hello world'
    assert block.parent.block[0].args['msg'] == 'hello world'


# Generated at 2022-06-17 07:05:35.667867
# Unit test for method is_block of class Block
def test_Block_is_block():
    data = {'block': [{'action': 'shell', 'args': 'echo "Hello World"'}]}
    assert Block.is_block(data) == True
    data = {'block': [{'action': 'shell', 'args': 'echo "Hello World"'}], 'rescue': [{'action': 'shell', 'args': 'echo "Hello World"'}]}
    assert Block.is_block(data) == True
    data = {'block': [{'action': 'shell', 'args': 'echo "Hello World"'}], 'always': [{'action': 'shell', 'args': 'echo "Hello World"'}]}
    assert Block.is_block(data) == True

# Generated at 2022-06-17 07:05:46.614290
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import strategy_loader

# Generated at 2022-06-17 07:05:55.520983
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a block
    block = Block()
    block.block = [{'name': 'task1', 'tags': ['tag1', 'tag2']}, {'name': 'task2', 'tags': ['tag1', 'tag3']}]
    block.rescue = [{'name': 'task3', 'tags': ['tag1', 'tag2']}, {'name': 'task4', 'tags': ['tag1', 'tag3']}]
    block.always = [{'name': 'task5', 'tags': ['tag1', 'tag2']}, {'name': 'task6', 'tags': ['tag1', 'tag3']}]
    # Create a play
    play = Play()
    play.only_tags = ['tag1']
    play.skip_tags = ['tag2']
    # Create a variable manager

# Generated at 2022-06-17 07:06:00.601755
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:06:09.174741
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:06:16.943620
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # create a block
    block = Block()
    # create a task
    task = Task()
    # create a task_include
    task_include = TaskInclude()
    # create a block_include
    block_include = Block()
    # create a block_include_include
    block_include_include = Block()
    # create a block_include_include_include
    block_include_include_include = Block()
    # create a block_include_include_include_include
    block_include_include_include_include = Block()
    # create a block_include_include_include_include_include
    block_include_include_include_include_include = Block()
    # create a block_include_include_include_include_include_include
    block_include_include_include_include_include_include = Block()
   

# Generated at 2022-06-17 07:06:38.816216
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

# Generated at 2022-06-17 07:06:47.727497
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # Test with simple task
    b = Block()
    ds = dict(name='test')
    assert b.preprocess_data(ds) == dict(block=[ds])

    # Test with list of tasks
    ds = [dict(name='test1'), dict(name='test2')]
    assert b.preprocess_data(ds) == dict(block=ds)

    # Test with block
    ds = dict(block=[dict(name='test1'), dict(name='test2')])
    assert b.preprocess_data(ds) == ds

    # Test with rescue
    ds = dict(rescue=[dict(name='test1'), dict(name='test2')])
    assert b.preprocess_data(ds) == ds

    # Test with always

# Generated at 2022-06-17 07:06:57.220821
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader

# Generated at 2022-06-17 07:07:04.760199
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Initialize a Block object
    block = Block()
    # Initialize a Play object
    play = Play()
    # Initialize a Task object
    task = Task()
    # Initialize a Block object
    block1 = Block()
    # Initialize a Task object
    task1 = Task()
    # Initialize a Task object
    task2 = Task()
    # Initialize a Task object
    task3 = Task()
    # Initialize a Task object
    task4 = Task()
    # Initialize a Task object
    task5 = Task()
    # Initialize a Task object
    task6 = Task()
    # Initialize a Task object
    task7 = Task()
    # Initialize a Task object
    task8 = Task()
    # Initialize a Task object
    task9 = Task()
    # Initialize a Task object

# Generated at 2022-06-17 07:07:13.896620
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import filter_loader

# Generated at 2022-06-17 07:07:23.764570
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [Task()]
    assert block.has_tasks() == True
    block.block = []
    block.rescue = [Task()]
    assert block.has_tasks() == True
    block.rescue = []
    block.always = [Task()]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:07:31.207530
# Unit test for method all_parents_static of class Block

# Generated at 2022-06-17 07:07:35.203254
# Unit test for method serialize of class Block
def test_Block_serialize():
    block = Block()
    block.serialize()


# Generated at 2022-06-17 07:07:43.685031
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'block': [{'action': 'debug', 'args': {'msg': 'Hello World'}, 'delegate_to': 'localhost', 'register': 'debug_result', 'when': 'True'}], 'dep_chain': [], 'always': [], 'rescue': [], 'when': 'True', 'delegate_to': 'localhost'})
    assert block.block == [{'action': 'debug', 'args': {'msg': 'Hello World'}, 'delegate_to': 'localhost', 'register': 'debug_result', 'when': 'True'}]
    assert block.dep_chain == []
    assert block.always == []
    assert block.rescue == []
    assert block.when == 'True'
    assert block.delegate_to == 'localhost'



# Generated at 2022-06-17 07:07:55.545726
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-17 07:08:30.634174
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    data = {}
    block.deserialize(data)
    assert block._attributes == {}
    assert block._dep_chain == None
    assert block._role == None
    assert block._parent == None


# Generated at 2022-06-17 07:08:36.826742
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:08:38.389550
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:08:43.207140
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # Create a Block object
    block = Block()
    # Create a dict object
    data = dict()
    # Call method deserialize of Block object
    block.deserialize(data)


# Generated at 2022-06-17 07:08:55.410912
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Create a Block object
    block = Block()
    # Create a Play object
    play = Play()
    # Create a Role object
    role = Role()
    # Create a TaskInclude object
    task_include = TaskInclude()
    # Create a HandlerTaskInclude object
    handler_task_include = HandlerTaskInclude()
    # Create a Loader object
    loader = Loader()
    # Create a DataLoader object
    data_loader = DataLoader()
    # Create a VariableManager object
    variable_manager = VariableManager()
    # Create a Inventory object
    inventory = Inventory()
    # Create a PlayContext object
    play_context = PlayContext()
    # Create a PlaybookExecutor object
    playbook_executor = PlaybookExecutor()
    # Create a Playbook object
    playbook = Playbook()
    #

# Generated at 2022-06-17 07:09:04.001976
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_include import HandlerInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_include import HandlerInclude
    from ansible.playbook.task_include import TaskInclude
   

# Generated at 2022-06-17 07:09:05.404056
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({})


# Generated at 2022-06-17 07:09:13.757997
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:09:27.380790
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:09:29.723824
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(None)


# Generated at 2022-06-17 07:09:53.262074
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:10:01.015422
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block()
    b.set_loader(None)
    assert b._loader == None
    assert b._role._loader == None
    assert b._parent._loader == None
    assert b._dep_chain[0]._loader == None
    assert b._dep_chain[1]._loader == None
    assert b._dep_chain[2]._loader == None
    assert b._dep_chain[3]._loader == None
    assert b._dep_chain[4]._loader == None
    assert b._dep_chain[5]._loader == None
    assert b._dep_chain[6]._loader == None
    assert b._dep_chain[7]._loader == None
    assert b._dep_chain[8]._loader == None
    assert b._dep_chain[9]._loader == None
    assert b._dep

# Generated at 2022-06-17 07:10:08.148872
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
   

# Generated at 2022-06-17 07:10:15.090797
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:10:28.012496
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess

# Generated at 2022-06-17 07:10:40.492800
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader

# Generated at 2022-06-17 07:10:48.481428
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a block
    block = Block()
    # Create a task
    task = Task()
    # Create a play
    play = Play()
    # Set the play of the block
    block._play = play
    # Set the parent of the block
    block._parent = task
    # Set the parent of the task
    task._parent = block
    # Set the only_tags of the play
    play.only_tags = ['tag1']
    # Set the skip_tags of the play
    play.skip_tags = ['tag2']
    # Set the tags of the task
    task.tags = ['tag1']
    # Set the action of the task
    task.action = 'action'
    # Set the block of the block
    block.block = [task]
    # Set the rescue of the block
    block.rescue

# Generated at 2022-06-17 07:10:56.293446
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader

# Generated at 2022-06-17 07:10:57.527306
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:11:09.664874
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

# Generated at 2022-06-17 07:11:24.318657
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Create a Block object
    block = Block()
    # Check if the Block object has tasks
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:11:34.960333
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Test with a Block object
    b = Block()
    b._loader = None
    b.set_loader(None)
    assert b._loader is None
    # Test with a Block object
    b = Block()
    b._loader = None
    b.set_loader(None)
    assert b._loader is None
    # Test with a Block object
    b = Block()
    b._loader = None
    b.set_loader(None)
    assert b._loader is None
    # Test with a Block object
    b = Block()
    b._loader = None
    b.set_loader(None)
    assert b._loader is None
    # Test with a Block object
    b = Block()
    b._loader = None
    b.set_loader(None)
    assert b._loader is None
    # Test with

# Generated at 2022-06-17 07:11:40.787376
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'block': [{'action': 'debug', 'args': {'msg': 'Hello World'}, 'name': 'debug'}], 'dep_chain': [], 'name': 'test'})
    assert block.block[0].action == 'debug'
    assert block.block[0].args['msg'] == 'Hello World'
    assert block.block[0].name == 'debug'
    assert block.dep_chain == []
    assert block.name == 'test'


# Generated at 2022-06-17 07:11:46.937486
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 07:11:58.149457
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:12:09.285258
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_

# Generated at 2022-06-17 07:12:16.697155
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.included_file import IncludedFile

# Generated at 2022-06-17 07:12:22.012224
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:12:28.033745
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Create a block object
    block = Block()
    # Create a loader object
    loader = DataLoader()
    # Call the method set_loader of class Block
    block.set_loader(loader)
    # Check if the loader is set correctly
    assert block._loader == loader


# Generated at 2022-06-17 07:12:38.237935
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:12:58.498056
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # create a block
    block = Block()
    # create a task
    task = Task()
    # set the action of the task to be 'debug'
    task.action = 'debug'
    # set the name of the task to be 'test'
    task.name = 'test'
    # set the tags of the task to be 'test'
    task.tags = ['test']
    # set the block to be a list of tasks
    block.block = [task]
    # create a play
    play = Play()
    # set the skip_tags of the play to be 'test'
    play.skip_tags = ['test']
    # set the only_tags of the play to be 'test'
    play.only_tags = ['test']
    # set the block's play to be the play
    block._play = play


# Generated at 2022-06-17 07:13:01.588505
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:13:08.417403
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 07:13:15.709827
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:13:19.135277
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b.copy()


# Generated at 2022-06-17 07:13:28.395752
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_include import HandlerInclude
    from ansible.playbook.role import Role

# Generated at 2022-06-17 07:13:38.594423
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # create a block
    block = Block()
    # create a task
    task = Task()
    # create a task include
    task_include = TaskInclude()
    # set the parent of the block to the task
    block._parent = task
    # set the parent of the task to the task include
    task._parent = task_include
    # set the statically_loaded of the task include to False
    task_include.statically_loaded = False
    # call the method all_parents_static of the block
    result = block.all_parents_static()
    # check the result
    assert result == False


# Generated at 2022-06-17 07:13:39.778477
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(loader)
    assert block._loader == loader


# Generated at 2022-06-17 07:13:50.378225
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    block.dep_chain = [1, 2, 3]
    block.role = Role()
    block.role.name = 'role'
    block.role.default_vars = {'a': 1, 'b': 2}
    block.role.tasks = [1, 2, 3]
    block.role.handlers = [4, 5, 6]
    block.role.meta = {'a': 1, 'b': 2}
    block.role.vars = {'a': 1, 'b': 2}
    block.role.default_vars = {'a': 1, 'b': 2}
    block.role

# Generated at 2022-06-17 07:13:59.061490
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1, 2, 3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1, 2, 3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1, 2, 3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False
