

# Generated at 2022-06-17 07:05:35.348478
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Test with a Block object
    b = Block()
    b._parent = Block()
    b._parent._parent = Block()
    b._parent._parent._parent = Block()
    b._parent._parent._parent._parent = Block()
    b._parent._parent._parent._parent._parent = Block()
    b._parent._parent._parent._parent._parent._parent = Block()
    b._parent._parent._parent._parent._parent._parent._parent = Block()
    b._parent._parent._parent._parent._parent._parent._parent._parent = Block()
    b._parent._parent._parent._parent._parent._parent._parent._parent._parent = Block()
    b._parent._parent._parent._parent._parent._parent._parent._parent._parent._parent = Block()
    b._parent._parent._parent._parent._parent._parent._

# Generated at 2022-06-17 07:05:46.614754
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b.block = [1,2,3]
    b.rescue = [4,5,6]
    b.always = [7,8,9]
    b._dep_chain = [1,2,3]
    b._parent = 1
    b._role = 1
    b._play = 1
    b._use_handlers = 1
    b._loader = 1
    b._variable_manager = 1
    b._task_include = 1
    b._task_include_first_pass = 1
    b._task_include_vars = 1
    b._task_include_vars_files = 1
    b._task_include_params = 1
    b._task_include_role_params = 1
    b._task_include_dirname = 1
    b._task_include_

# Generated at 2022-06-17 07:05:49.629202
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({})


# Generated at 2022-06-17 07:05:52.635128
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [{'task': {'name': 'test'}}]
    new_block = block.copy()
    assert new_block.block[0].task.name == 'test'


# Generated at 2022-06-17 07:05:58.771354
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # Create a block object
    block = Block()
    # Create a data structure
    data = {
        'block': [
            {
                'name': 'test',
                'action': 'shell',
                'args': 'echo hello'
            }
        ]
    }
    # Call the method
    result = block.preprocess_data(data)
    # Verify the result
    assert result == data
    # Create a data structure
    data = [
        {
            'name': 'test',
            'action': 'shell',
            'args': 'echo hello'
        }
    ]
    # Call the method
    result = block.preprocess_data(data)
    # Verify the result
    assert result == {'block': data}
    # Create a data structure

# Generated at 2022-06-17 07:06:06.716601
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 07:06:16.066649
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_include import HandlerInclude

# Generated at 2022-06-17 07:06:27.287732
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-17 07:06:32.267256
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(None)
    assert block._loader == None
    assert block._play == None
    assert block._role == None
    assert block._dep_chain == None
    assert block._parent == None


# Generated at 2022-06-17 07:06:33.237640
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(loader)


# Generated at 2022-06-17 07:06:46.521426
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    pass

# Generated at 2022-06-17 07:06:56.164047
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.errors import AnsibleParserError
    import os
    import json
    import pytest
    import sys
    import copy
    import shutil
    from collections import namedtuple
   

# Generated at 2022-06-17 07:07:07.384953
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a block
    block = Block()
    # Create a task
    task = Task()
    # Create a task with a tag
    task_tag = Task()
    task_tag.tags = ['tag1']
    # Create a block with a task
    block_task = Block()
    block_task.block = [task]
    # Create a block with a task with a tag
    block_task_tag = Block()
    block_task_tag.block = [task_tag]
    # Create a block with a block with a task
    block_block_task = Block()
    block_block_task.block = [block_task]
    # Create a block with a block with a task with a tag
    block_block_task_tag = Block()

# Generated at 2022-06-17 07:07:16.087004
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import Ansible

# Generated at 2022-06-17 07:07:27.797808
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Create a mock object for the loader
    loader = MagicMock()
    # Create a mock object for the play
    play = MagicMock()
    # Create a mock object for the role
    role = MagicMock()
    # Create a mock object for the parent
    parent = MagicMock()
    # Create a mock object for the dep_chain
    dep_chain = MagicMock()
    # Create a mock object for the task
    task = MagicMock()
    # Create a mock object for the task_include
    task_include = MagicMock()
    # Create a mock object for the handler_task_include
    handler_task_include = MagicMock()
    # Create a mock object for the data
    data = MagicMock()
    # Create a mock object for the variable_manager
    variable_manager = MagicMock()

# Generated at 2022-06-17 07:07:39.374270
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a Block object
    block = Block()
    # Create a TaskInclude object
    task_include = TaskInclude()
    # Create a Block object
    block_1 = Block()
    # Set the parent of Block object to TaskInclude object
    block._parent = task_include
    # Set the parent of TaskInclude object to Block object
    task_include._parent = block_1
    # Set the statically_loaded attribute of TaskInclude object to False
    task_include.statically_loaded = False
    # Set the statically_loaded attribute of Block object to True
    block_1.statically_loaded = True
    # Call the method all_parents_static of Block object
    result = block.all_parents_static()
    # Check the result
    assert result == False


# Generated at 2022-06-17 07:07:43.702227
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'role': {'name': 'role1'}, 'parent': {'name': 'parent1'}, 'parent_type': 'Block'})
    assert block._role.name == 'role1'
    assert block._parent.name == 'parent1'
    assert block._parent_type == 'Block'


# Generated at 2022-06-17 07:07:45.252249
# Unit test for method serialize of class Block
def test_Block_serialize():
    b = Block()
    b.serialize()
    assert True


# Generated at 2022-06-17 07:07:46.953748
# Unit test for method serialize of class Block
def test_Block_serialize():
    block = Block()
    block.serialize()


# Generated at 2022-06-17 07:07:58.632787
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.errors import AnsibleParserError
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-17 07:08:39.874341
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 07:08:46.164631
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    import ansible.playbook
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.role
    import ansible.playbook.handler
    import ansible.playbook.task_include
    import ansible.playbook.handler_task_include
    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.vars.manager
    import ansible.template
    import ansible.parsing.yaml.objects
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.inventory.inventory
    import ansible.utils.vars
    import ansible.utils.unsafe_proxy
    import ansible.utils.unsafe_proxy.wrap_var

# Generated at 2022-06-17 07:08:57.399968
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:09:05.474547
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # create a block object
    block = Block()
    # create a task object
    task = Task()
    # set the task object to the block object
    block.block = [task]
    # check if the block object has tasks
    assert block.has_tasks() == True
    # create a block object
    block = Block()
    # create a task object
    task = Task()
    # set the task object to the block object
    block.rescue = [task]
    # check if the block object has tasks
    assert block.has_tasks() == True
    # create a block object
    block = Block()
    # create a task object
    task = Task()
    # set the task object to the block object
    block.always = [task]
    # check if the block object has tasks
    assert block.has_

# Generated at 2022-06-17 07:09:13.821182
# Unit test for method get_dep_chain of class Block

# Generated at 2022-06-17 07:09:27.416249
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 07:09:28.531783
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    pass

# Generated at 2022-06-17 07:09:39.413320
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup

# Generated at 2022-06-17 07:09:41.367211
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Create a Block object
    block = Block()
    # Set the loader
    block.set_loader(None)


# Generated at 2022-06-17 07:09:49.782783
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import Task

# Generated at 2022-06-17 07:10:10.225866
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Test with no tags
    block = Block()

# Generated at 2022-06-17 07:10:11.765252
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(loader)
    assert block._loader == loader


# Generated at 2022-06-17 07:10:19.155356
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1, 2, 3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1, 2, 3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1, 2, 3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:10:30.628662
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Create a mock object for the loader
    loader = mock.MagicMock()
    # Create a mock object for the variable manager
    variable_manager = mock.MagicMock()
    # Create a mock object for the play
    play = mock.MagicMock()
    # Create a mock object for the role
    role = mock.MagicMock()
    # Create a mock object for the parent block
    parent_block = mock.MagicMock()
    # Create a mock object for the task include
    task_include = mock.MagicMock()
    # Create a mock object for the use handlers
    use_handlers = mock.MagicMock()
    # Create a mock object for the implicit
    implicit = mock.MagicMock()
    # Create a mock object for the data
    data = mock.MagicMock()
    # Create a mock object

# Generated at 2022-06-17 07:10:42.214728
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    block.dep_chain = [1, 2, 3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = "Block"
    block.statically_loaded = True
    block.implicit = True
    block.ignore_errors = True
    block.only_if = True
    block.loop = True
    block.loop_args = True
    block.until = True
    block.retries = True
    block.delay = True
    block.when = True
    block.changed_when = True
    block.failed_when = True
    block.register = True

# Generated at 2022-06-17 07:10:49.630350
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [{'name': 'test'}]
    block.rescue = [{'name': 'test'}]
    block.always = [{'name': 'test'}]
    block.when = 'test'
    block.loop = 'test'
    block.loop_with_items = 'test'
    block.loop_with_sequence = 'test'
    block.loop_with_indexed_items = 'test'
    block.loop_with_dict = 'test'
    block.loop_with_nested_dict = 'test'
    block.loop_with_subelements = 'test'
    block.loop_with_subelements_flattened = 'test'
    block.loop_with_subelements_flattened_keys = 'test'


# Generated at 2022-06-17 07:10:53.983900
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.include_role import IncludeRole
    from ansible.playbook.include_tasks import IncludeTasks
    from ansible.playbook.include_vars import IncludeVars

# Generated at 2022-06-17 07:11:03.406822
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

# Generated at 2022-06-17 07:11:15.165404
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import Handler

# Generated at 2022-06-17 07:11:17.484534
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a Block object
    b = Block()
    # Check if all parents are static
    assert b.all_parents_static() == True


# Generated at 2022-06-17 07:11:37.714226
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Test with no parent
    b = Block()
    assert b.get_dep_chain() == None

    # Test with parent
    b = Block(parent_block=Block())
    assert b.get_dep_chain() == []

    # Test with parent and dep_chain
    b = Block(parent_block=Block(), dep_chain=[Block()])
    assert b.get_dep_chain() == [Block()]


# Generated at 2022-06-17 07:11:45.306809
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Test with empty block
    b = Block()
    assert b.has_tasks() == False
    # Test with block with tasks
    b = Block(block=[Task()])
    assert b.has_tasks() == True
    # Test with block with rescue and always
    b = Block(rescue=[Task()], always=[Task()])
    assert b.has_tasks() == True
    # Test with block with rescue and always and block
    b = Block(block=[Task()], rescue=[Task()], always=[Task()])
    assert b.has_tasks() == True


# Generated at 2022-06-17 07:11:50.813725
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # create a block
    block = Block()
    # create a loader
    loader = DictDataLoader({})
    # set the loader
    block.set_loader(loader)
    # assert that the loader is set
    assert block._loader == loader


# Generated at 2022-06-17 07:12:00.031058
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Create a block object
    block = Block()
    # Create a list of tasks
    tasks = [Task()]
    # Create a list of handlers
    handlers = [Handler()]
    # Create a list of roles
    roles = [Role()]
    # Create a list of blocks
    blocks = [Block()]
    # Create a list of task includes
    task_includes = [TaskInclude()]
    # Create a list of handler task includes
    handler_task_includes = [HandlerTaskInclude()]
    # Create a list of playbooks
    playbooks = [Playbook()]
    # Create a list of plays
    plays = [Play()]
    # Create a list of dep_chains
    dep_chains = [tasks, handlers, roles, blocks, task_includes, handler_task_includes, playbooks, plays]


# Generated at 2022-06-17 07:12:11.237139
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:12:21.174752
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import action_loader


# Generated at 2022-06-17 07:12:31.875638
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

# Generated at 2022-06-17 07:12:39.193607
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Test with a block that has a dep_chain
    block = Block()
    block._dep_chain = ['dep1', 'dep2']
    assert block.get_dep_chain() == ['dep1', 'dep2']
    # Test with a block that has no dep_chain
    block = Block()
    block._dep_chain = None
    assert block.get_dep_chain() == None
    # Test with a block that has a parent
    block = Block()
    block._dep_chain = None
    block._parent = Block()
    block._parent._dep_chain = ['dep1', 'dep2']
    assert block.get_dep_chain() == ['dep1', 'dep2']
    # Test with a block that has a parent and a dep_chain
    block = Block()

# Generated at 2022-06-17 07:12:44.002162
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:12:53.523715
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    block.dep_chain = [1, 2, 3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = "Block"
    block.statically_loaded = True
    block.implicit = True
    block.loop = "loop"
    block.loop_control = "loop_control"
    block.when = "when"
    block.any_errors_fatal = True
    block.changed_when = "changed_when"
    block.failed_when = "failed_when"
    block.always_run = True
    block.register = "register"
    block.ignore_errors

# Generated at 2022-06-17 07:13:15.848244
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:13:20.972419
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Create a block object
    block = Block()
    # Check if the block has tasks
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:13:29.152625
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 07:13:40.651536
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Test case 1
    block = Block()
    block._parent = None
    assert block.all_parents_static() == True

    # Test case 2
    block = Block()
    block._parent = Block()
    assert block.all_parents_static() == True

    # Test case 3
    block = Block()
    block._parent = Block()
    block._parent._parent = Block()
    block._parent._parent.statically_loaded = False
    assert block.all_parents_static() == False

    # Test case 4
    block = Block()
    block._parent = Block()
    block._parent._parent = Block()
    block._parent._parent.statically_loaded = True
    assert block.all_parents_static() == True

    # Test case 5
    block = Block()
    block._parent = Block()


# Generated at 2022-06-17 07:13:50.384120
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Test for Block
    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = None

# Generated at 2022-06-17 07:13:58.096833
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

# Generated at 2022-06-17 07:14:06.938415
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Test case 1
    # Test with a Block object
    # Expected result: True
    block = Block()
    block.statically_loaded = True
    assert block.all_parents_static() == True

    # Test case 2
    # Test with a TaskInclude object
    # Expected result: False
    from ansible.playbook.task_include import TaskInclude
    task_include = TaskInclude()
    task_include.statically_loaded = False
    assert task_include.all_parents_static() == False

    # Test case 3
    # Test with a Block object
    # Expected result: False
    block = Block()
    block.statically_loaded = False
    assert block.all_parents_static() == False

    # Test case 4
    # Test with a TaskInclude object
    # Expected

# Generated at 2022-06-17 07:14:17.356271
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play

# Generated at 2022-06-17 07:14:31.743363
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase

# Generated at 2022-06-17 07:14:37.731299
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1, 2, 3]
    assert block.has_tasks() == True
    block.rescue = [1, 2, 3]
    assert block.has_tasks() == True
    block.always = [1, 2, 3]
    assert block.has_tasks() == True
