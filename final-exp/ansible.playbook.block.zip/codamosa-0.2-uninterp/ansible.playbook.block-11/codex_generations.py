

# Generated at 2022-06-17 07:05:40.870893
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({})


# Generated at 2022-06-17 07:05:51.802999
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Test with a Block object
    b = Block()
    b._parent = Block()
    b._parent.statically_loaded = True
    assert b.all_parents_static() == True
    b._parent.statically_loaded = False
    assert b.all_parents_static() == False

    # Test with a TaskInclude object
    b = Block()
    b._parent = TaskInclude()
    b._parent.statically_loaded = True
    assert b.all_parents_static() == True
    b._parent.statically_loaded = False
    assert b.all_parents_static() == False

    # Test with a TaskInclude object, which has a parent
    b = Block()
    b._parent = TaskInclude()
    b._parent._parent = Block()
    b._parent._parent.statically_

# Generated at 2022-06-17 07:05:52.604671
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    pass


# Generated at 2022-06-17 07:05:58.750181
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroupVars

# Generated at 2022-06-17 07:06:06.705082
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [{'name': 'test'}]
    block.rescue = [{'name': 'test'}]
    block.always = [{'name': 'test'}]
    block.loop = 'test'
    block.when = 'test'
    block.changed_when = 'test'
    block.failed_when = 'test'
    block.until = 'test'
    block.retries = 'test'
    block.delay = 'test'
    block.register = 'test'
    block.ignore_errors = 'test'
    block.tags = 'test'
    block.run_once = 'test'
    block.any_errors_fatal = 'test'
    block.delegate_to = 'test'

# Generated at 2022-06-17 07:06:16.066755
# Unit test for method all_parents_static of class Block

# Generated at 2022-06-17 07:06:18.997570
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b.copy()


# Generated at 2022-06-17 07:06:28.323662
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
   

# Generated at 2022-06-17 07:06:35.919033
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-17 07:06:43.883913
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    block.dep_chain = [1,2,3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = 'Block'
    block.statically_loaded = True
    block.use_handlers = True
    block.implicit = True
    block.loop = 'loop'
    block.loop_args = 'loop_args'
    block.when = 'when'
    block.any_errors_fatal = True
    block.always_run = True
    block.register = 'register'
    block.ignore_errors = True

# Generated at 2022-06-17 07:07:02.009355
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:07:03.246026
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(loader)


# Generated at 2022-06-17 07:07:13.473769
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block = Block()
    assert block.preprocess_data(dict(block=[])) == dict(block=[])
    assert block.preprocess_data(dict(block=[1, 2, 3])) == dict(block=[1, 2, 3])
    assert block.preprocess_data(dict(block=[1, 2, 3], rescue=[4, 5, 6])) == dict(block=[1, 2, 3], rescue=[4, 5, 6])
    assert block.preprocess_data([1, 2, 3]) == dict(block=[1, 2, 3])
    assert block.preprocess_data(1) == dict(block=[1])
    assert block.preprocess_data(dict(block=1)) == dict(block=[1])

# Generated at 2022-06-17 07:07:26.594336
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block(dict(block=[]))
    assert not Block.is_block(dict(rescue=[]))
    assert not Block.is_block(dict(always=[]))
    assert not Block.is_block(dict(block=[], rescue=[]))
    assert not Block.is_block(dict(block=[], always=[]))
    assert not Block.is_block(dict(rescue=[], always=[]))
    assert not Block.is_block(dict(block=[], rescue=[], always=[]))
    assert not Block.is_block(dict(block=[], rescue=[], always=[], foo=[]))
    assert not Block.is_block(dict(block=[], rescue=[], always=[], foo=[], bar=[]))

# Generated at 2022-06-17 07:07:38.983771
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:07:41.322473
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()
    block.copy(exclude_parent=True)
    block.copy(exclude_tasks=True)
    block.copy(exclude_parent=True, exclude_tasks=True)


# Generated at 2022-06-17 07:07:44.333492
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a block
    b = Block()
    # Create a task
    t = Task()
    # Set the parent of the block to the task
    b._parent = t
    # Call the method all_parents_static of the block
    result = b.all_parents_static()
    # Check the result
    assert result == True


# Generated at 2022-06-17 07:07:56.049329
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.template import Templar

# Generated at 2022-06-17 07:08:04.078747
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1, 2, 3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1, 2, 3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1, 2, 3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:08:12.357971
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    # import is here to avoid import loops
    data = dict()
    data['dep_chain'] = None
    role_data = data.get('role')
    if role_data:
        r = Role()
        r.deserialize(role_data)
        self._role = r
    parent_data = data.get('parent')
    if parent_data:
        parent_type = data.get('parent_type')
        if parent_type == 'Block':
            p = Block()
        elif parent_type == 'TaskInclude':
            p = TaskInclude()
        elif parent_type == 'HandlerTaskInclude':
            p = HandlerTaskInclude()
       

# Generated at 2022-06-17 07:08:28.931685
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b.block = [1,2,3]
    b.rescue = [4,5,6]
    b.always = [7,8,9]
    b.dep_chain = [1,2,3]
    b.role = Role()
    b.parent = Block()
    b.parent_type = 'Block'
    b.statically_loaded = True
    b.name = 'Block'
    b.loop = 'loop'
    b.when = 'when'
    b.any_errors_fatal = True
    b.changed_when = 'changed_when'
    b.failed_when = 'failed_when'
    b.always_run = True
    b.register = 'register'
    b.delegate_to = 'delegate_to'

# Generated at 2022-06-17 07:08:36.026085
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:08:37.206065
# Unit test for method copy of class Block
def test_Block_copy():
    # TODO: Implement test_Block_copy
    pass


# Generated at 2022-06-17 07:08:47.756502
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader

# Generated at 2022-06-17 07:08:49.746563
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({})


# Generated at 2022-06-17 07:08:51.376395
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:08:59.355764
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrack

# Generated at 2022-06-17 07:09:08.851269
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block()
    assert b.has_tasks() == False
    b.block = [1,2,3]
    assert b.has_tasks() == True
    b.block = []
    assert b.has_tasks() == False
    b.rescue = [1,2,3]
    assert b.has_tasks() == True
    b.rescue = []
    assert b.has_tasks() == False
    b.always = [1,2,3]
    assert b.has_tasks() == True
    b.always = []
    assert b.has_tasks() == False


# Generated at 2022-06-17 07:09:16.970033
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'block': [{'action': 'debug', 'name': 'test'}], 'dep_chain': [], 'parent': {'block': [{'action': 'debug', 'name': 'test'}], 'dep_chain': [], 'parent': None, 'parent_type': 'Block'}, 'parent_type': 'Block'})
    assert block.block[0].action == 'debug'
    assert block.block[0].name == 'test'
    assert block.dep_chain == []
    assert block.parent.block[0].action == 'debug'
    assert block.parent.block[0].name == 'test'
    assert block.parent.dep_chain == []
    assert block.parent.parent is None
    assert block.parent.parent_type == 'Block'


# Generated at 2022-06-17 07:09:28.324366
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 07:09:48.828267
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Create a mock object for the loader
    loader = mock.MagicMock()
    # Create a mock object for the play
    play = mock.MagicMock()
    # Create a mock object for the role
    role = mock.MagicMock()
    # Create a mock object for the variable manager
    variable_manager = mock.MagicMock()
    # Create a mock object for the task
    task = mock.MagicMock()
    # Create a mock object for the task
    task_include = mock.MagicMock()
    # Create a mock object for the handler task include
    handler_task_include = mock.MagicMock()
    # Create a mock object for the block
    block = mock.MagicMock()
    # Create a mock object for the block
    block_1 = mock.MagicMock()
    # Create a mock object

# Generated at 2022-06-17 07:10:00.294978
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [{'name': 'test'}]
    block.rescue = [{'name': 'test'}]
    block.always = [{'name': 'test'}]
    block.dep_chain = ['test']
    block.role = Role()
    block.role.name = 'test'
    block.role.tasks = [{'name': 'test'}]
    block.role.default_vars = {'test': 'test'}
    block.role.vars_files = ['test']
    block.role.tasks_from = 'test'
    block.role.handlers = [{'name': 'test'}]
    block.role.meta = {'test': 'test'}
    block.role.dependencies = ['test']
   

# Generated at 2022-06-17 07:10:02.790597
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:10:12.981050
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-17 07:10:27.290249
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
   

# Generated at 2022-06-17 07:10:34.650428
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:10:39.201900
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'role': {'name': 'test_role'}})
    assert block._role.name == 'test_role'


# Generated at 2022-06-17 07:10:47.505109
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.template import Templar
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 07:10:56.129446
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a block object
    block = Block()
    # Create a task object
    task = Task()
    # Create a task object
    task1 = Task()
    # Create a task object
    task2 = Task()
    # Create a task object
    task3 = Task()
    # Create a task object
    task4 = Task()
    # Create a task object
    task5 = Task()
    # Create a task object
    task6 = Task()
    # Create a task object
    task7 = Task()
    # Create a task object
    task8 = Task()
    # Create a task object
    task9 = Task()
    # Create a task object
    task10 = Task()
    # Create a task object
    task11 = Task()
    # Create a task object
    task12 = Task()
    # Create a task

# Generated at 2022-06-17 07:11:08.014441
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 07:11:34.862687
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import action_loader


# Generated at 2022-06-17 07:11:40.786712
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    block.block = [1, 2, 3]
    assert block.has_tasks()
    block.block = []
    assert block.has_tasks()
    block.rescue = [1, 2, 3]
    assert block.has_tasks()
    block.rescue = []
    assert block.has_tasks()
    block.always = [1, 2, 3]
    assert block.has_tasks()
    block.always = []
    assert not block.has_tasks()


# Generated at 2022-06-17 07:11:41.936545
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:11:52.721833
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

# Generated at 2022-06-17 07:12:01.084283
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a block
    block = Block()
    # Create a task
    task = Task()
    # Create a task include
    task_include = TaskInclude()
    # Create a block include
    block_include = Block()
    # Set the parent of the block to the task
    block._parent = task
    # Set the parent of the task to the task include
    task._parent = task_include
    # Set the parent of the task include to the block include
    task_include._parent = block_include
    # Set the statically_loaded attribute of the block include to False
    block_include.statically_loaded = False
    # Check the result of the method all_parents_static
    assert not block.all_parents_static()
    # Set the statically_loaded attribute of the block include to True
    block_include.statically_loaded

# Generated at 2022-06-17 07:12:09.426376
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:12:18.686407
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1, 2, 3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1, 2, 3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1, 2, 3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:12:28.515840
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Create a mock object for the loader
    loader = Mock()
    # Create a mock object for the variable manager
    variable_manager = Mock()
    # Create a mock object for the play
    play = Mock()
    # Create a mock object for the role
    role = Mock()
    # Create a mock object for the parent block
    parent_block = Mock()
    # Create a mock object for the task include
    task_include = Mock()
    # Create a mock object for the task
    task = Mock()
    # Create a mock object for the handler task include
    handler_task_include = Mock()
    # Create a mock object for the dep
    dep = Mock()
    # Create a mock object for the dep_chain
    dep_chain = Mock()
    # Create a mock object for the data
    data = Mock()
    # Create a

# Generated at 2022-06-17 07:12:38.281067
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:12:48.469816
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader

# Generated at 2022-06-17 07:13:25.282878
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    block.dep_chain = [1,2,3]
    block.role = Role()
    block.role.name = 'test'
    block.parent = Block()
    block.parent.name = 'test'
    block.parent.block = [1,2,3]
    block.parent.rescue = [4,5,6]
    block.parent.always = [7,8,9]
    block.parent.dep_chain = [1,2,3]
    block.parent.role = Role()
    block.parent.role.name = 'test'
    block.parent.parent = Block()
    block.parent

# Generated at 2022-06-17 07:13:32.411156
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude

# Generated at 2022-06-17 07:13:38.245016
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(None)
    assert block._loader == None
    assert block._role._loader == None
    assert block._parent._loader == None
    assert block._dep_chain[0]._loader == None
    assert block._dep_chain[1]._loader == None
    assert block._dep_chain[2]._loader == None


# Generated at 2022-06-17 07:13:45.277692
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
   

# Generated at 2022-06-17 07:13:49.353565
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:13:57.140679
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play

# Generated at 2022-06-17 07:14:04.187700
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:14:15.580655
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader

# Generated at 2022-06-17 07:14:30.680320
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a Block object
    block = Block()
    # Create a TaskInclude object
    task_include = TaskInclude()
    # Create a Block object
    block1 = Block()
    # Create a TaskInclude object
    task_include1 = TaskInclude()
    # Create a Block object
    block2 = Block()
    # Create a TaskInclude object
    task_include2 = TaskInclude()
    # Create a Block object
    block3 = Block()
    # Create a TaskInclude object
    task_include3 = TaskInclude()
    # Create a Block object
    block4 = Block()
    # Create a TaskInclude object
    task_include4 = TaskInclude()
    # Create a Block object
    block5 = Block()
    # Create a TaskInclude object
    task_include5 = TaskIn

# Generated at 2022-06-17 07:14:41.028973
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # test_block_filter_tagged_tasks_1
    block = Block()