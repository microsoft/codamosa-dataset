

# Generated at 2022-06-17 07:05:07.857767
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import Un

# Generated at 2022-06-17 07:05:15.238229
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    b = Block()
    assert b.get_dep_chain() is None
    b._dep_chain = [1, 2, 3]
    assert b.get_dep_chain() == [1, 2, 3]
    b._dep_chain = None
    b._parent = Block()
    b._parent._dep_chain = [1, 2, 3]
    assert b.get_dep_chain() == [1, 2, 3]
    b._parent._dep_chain = None
    b._parent._parent = Block()
    b._parent._parent._dep_chain = [1, 2, 3]
    assert b.get_dep_chain() == [1, 2, 3]


# Generated at 2022-06-17 07:05:28.321754
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:05:38.898509
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block()
    assert b.has_tasks() == False
    b.block = [1,2,3]
    assert b.has_tasks() == True
    b.block = []
    assert b.has_tasks() == False
    b.rescue = [1,2,3]
    assert b.has_tasks() == True
    b.rescue = []
    assert b.has_tasks() == False
    b.always = [1,2,3]
    assert b.has_tasks() == True
    b.always = []
    assert b.has_tasks() == False


# Generated at 2022-06-17 07:05:41.276068
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    data = dict()
    block.deserialize(data)


# Generated at 2022-06-17 07:05:52.175460
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a Block object
    block = Block()
    # Create a Play object
    play = Play()
    # Create a Task object
    task = Task()
    # Create a Block object
    block1 = Block()
    # Create a Task object
    task1 = Task()
    # Create a Block object
    block2 = Block()
    # Create a Task object
    task2 = Task()
    # Create a Block object
    block3 = Block()
    # Create a Task object
    task3 = Task()
    # Create a Block object
    block4 = Block()
    # Create a Task object
    task4 = Task()
    # Create a Block object
    block5 = Block()
    # Create a Task object
    task5 = Task()
    # Create a Block object
    block6 = Block()
    # Create a Task object

# Generated at 2022-06-17 07:06:01.691552
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b.block = [1,2,3]
    b.rescue = [4,5,6]
    b.always = [7,8,9]
    b.dep_chain = [1,2,3]
    b.role = Role()
    b.role.name = 'test_role'
    b.role.path = '/path/to/role'
    b.role.default_vars = {'a':1, 'b':2}
    b.role.tasks = [1,2,3]
    b.role.handlers = [4,5,6]
    b.role.meta = {'a':1, 'b':2}
    b.role.vars = {'a':1, 'b':2}
    b.role.default_vars

# Generated at 2022-06-17 07:06:03.567694
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:06:10.773259
# Unit test for method is_block of class Block
def test_Block_is_block():
    # Test with a dictionary
    ds = {'block': [{'name': 'test'}]}
    assert Block.is_block(ds) == True
    # Test with a list
    ds = [{'name': 'test'}]
    assert Block.is_block(ds) == False
    # Test with a string
    ds = 'test'
    assert Block.is_block(ds) == False
    # Test with a number
    ds = 1
    assert Block.is_block(ds) == False


# Generated at 2022-06-17 07:06:21.618183
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    block.block = None
    block.rescue = None
    block.always = None
    block.loop = None
    block.loop_args = None
    block.when = None
    block.name = None
    block.any_errors_fatal = None
    block.any_unreachable_fatal = None
    block.changed_when = None
    block.failed_when = None
    block.tags = None
    block.run_once = None
    block.ignore_errors = None
    block.register = None
    block.notify = None
    block.free_form = None
    block.until = None
    block.retries = None
    block

# Generated at 2022-06-17 07:07:05.446306
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Create a mock object for the loader
    loader = mock.MagicMock()
    # Create a mock object for the variable manager
    variable_manager = mock.MagicMock()
    # Create a mock object for the play
    play = mock.MagicMock()
    # Create a mock object for the role
    role = mock.MagicMock()
    # Create a mock object for the task
    task = mock.MagicMock()
    # Create a mock object for the block
    block = mock.MagicMock()
    # Create a mock object for the dep_chain
    dep_chain = mock.MagicMock()
    # Create a mock object for the parent
    parent = mock.MagicMock()
    # Create a mock object for the parent_type
    parent_type = mock.MagicMock()
    # Create a mock object for the

# Generated at 2022-06-17 07:07:09.276276
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Create a block object
    block = Block()
    # Call the method get_dep_chain of the object block
    block.get_dep_chain()
    # Assert that the method get_dep_chain of the object block returns None
    assert block.get_dep_chain() == None


# Generated at 2022-06-17 07:07:16.009139
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # Test with a simple block
    block = Block()
    block.deserialize({'block': [{'action': 'setup'}]})
    assert block.block[0].action == 'setup'

    # Test with a block with a rescue
    block = Block()
    block.deserialize({'block': [{'action': 'setup'}], 'rescue': [{'action': 'debug'}]})
    assert block.block[0].action == 'setup'
    assert block.rescue[0].action == 'debug'

    # Test with a block with a rescue and an always
    block = Block()
    block.deserialize({'block': [{'action': 'setup'}], 'rescue': [{'action': 'debug'}], 'always': [{'action': 'debug'}]})


# Generated at 2022-06-17 07:07:27.767458
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

# Generated at 2022-06-17 07:07:39.330453
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play

# Generated at 2022-06-17 07:07:49.623114
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader

# Generated at 2022-06-17 07:08:00.473673
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

# Generated at 2022-06-17 07:08:01.842006
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({})


# Generated at 2022-06-17 07:08:10.878760
# Unit test for method copy of class Block

# Generated at 2022-06-17 07:08:12.869614
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block(dict(block=[]))
    assert not Block.is_block(dict(block=[]))


# Generated at 2022-06-17 07:08:38.104529
# Unit test for method is_block of class Block
def test_Block_is_block():
    block = Block()
    assert block.is_block(dict(block=[]))
    assert not block.is_block(dict(block=[]))


# Generated at 2022-06-17 07:08:46.748479
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:08:57.433494
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:09:07.895612
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.errors import AnsibleError
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_v

# Generated at 2022-06-17 07:09:12.046664
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Create a Block object
    b = Block()
    # Check if the Block object has tasks
    assert b.has_tasks() == False
    # Create a Task object
    t = Task()
    # Add the Task object to the Block object
    b.block = [t]
    # Check if the Block object has tasks
    assert b.has_tasks() == True


# Generated at 2022-06-17 07:09:20.705944
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Test with a block that has a parent that is not statically loaded
    block = Block()
    block._parent = Block()
    block._parent.statically_loaded = False
    assert block.all_parents_static() == False

    # Test with a block that has a parent that is statically loaded
    block = Block()
    block._parent = Block()
    block._parent.statically_loaded = True
    assert block.all_parents_static() == True

    # Test with a block that has a parent that is not statically loaded
    # and a grandparent that is statically loaded
    block = Block()
    block._parent = Block()
    block._parent._parent = Block()
    block._parent._parent.statically_loaded = True
    block._parent.statically_loaded = False
    assert block.all_parents_static() == False



# Generated at 2022-06-17 07:09:28.592054
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:09:39.451571
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    block.dep_chain = [10, 11, 12]
    block.role = Role()
    block.parent = Block()
    block.parent_type = "Block"
    block.statically_loaded = True
    block.implicit = True
    block.loop = "loop"
    block.loop_args = "loop_args"
    block.when = "when"
    block.changed_when = "changed_when"
    block.failed_when = "failed_when"
    block.until = "until"
    block.retries = "retries"
    block.delay = "delay"

# Generated at 2022-06-17 07:09:42.760588
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Create a Block object
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    # Test the method has_tasks
    assert block.has_tasks() == False

# Generated at 2022-06-17 07:09:51.537593
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block = [1,2,3]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == False
    block.rescue = [1,2,3]
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == False
    block.always = [1,2,3]
    assert block.has_tasks() == True
    block.always = []
    assert block.has_tasks() == False


# Generated at 2022-06-17 07:10:13.094870
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.vars import Vars
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
   

# Generated at 2022-06-17 07:10:27.324762
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:10:39.722890
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block(dict(block=[]))
    assert not Block.is_block(dict(rescue=[]))
    assert not Block.is_block(dict(always=[]))
    assert not Block.is_block(dict(block=[], rescue=[], always=[]))
    assert not Block.is_block(dict(block=[], rescue=[], always=[], foo='bar'))
    assert not Block.is_block(dict(foo='bar'))
    assert not Block.is_block(dict())
    assert not Block.is_block(list())
    assert not Block.is_block(None)
    assert not Block.is_block(42)
    assert not Block.is_block('foo')
    assert not Block.is_block(True)
    assert not Block.is_block(False)

# Generated at 2022-06-17 07:10:47.899197
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

# Generated at 2022-06-17 07:10:56.158532
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader

# Generated at 2022-06-17 07:11:08.069401
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:11:11.976572
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:11:21.540088
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 07:11:26.452485
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

# Generated at 2022-06-17 07:11:28.519121
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # TODO: implement
    pass


# Generated at 2022-06-17 07:11:43.643488
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # test_Block_set_loader() of class Block
    # Create a Block object
    b = Block()
    # Set the loader
    b.set_loader(loader)
    # Check if the loader is set
    assert b._loader == loader


# Generated at 2022-06-17 07:11:56.819552
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader

# Generated at 2022-06-17 07:12:08.136986
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:12:18.866138
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b.block = [1, 2, 3]
    b.rescue = [4, 5, 6]
    b.always = [7, 8, 9]
    b.dep_chain = [1, 2, 3]
    b.role = Role()
    b.parent = Block()
    b.parent_type = 'Block'
    b.statically_loaded = True
    b.use_handlers = True
    b.implicit = True
    b.loop = 'loop'
    b.loop_args = 'loop_args'
    b.loop_with_items = 'loop_with_items'
    b.loop_with_sequence = 'loop_with_sequence'
    b.loop_with_index = 'loop_with_index'
    b.loop_with_first_only

# Generated at 2022-06-17 07:12:26.513968
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block(dict(block=[dict(action='debug', msg='test')]))
    assert not Block.is_block(dict(action='debug', msg='test'))
    assert not Block.is_block(dict(block=dict(action='debug', msg='test')))
    assert not Block.is_block(dict(block=[dict(action='debug', msg='test')], rescue=[dict(action='debug', msg='test')]))
    assert not Block.is_block(dict(block=[dict(action='debug', msg='test')], always=[dict(action='debug', msg='test')]))

# Generated at 2022-06-17 07:12:32.161877
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:12:39.437886
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play

# Generated at 2022-06-17 07:12:44.215581
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
   

# Generated at 2022-06-17 07:12:53.753541
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b.block = [1,2,3]
    b.rescue = [4,5,6]
    b.always = [7,8,9]
    b.when = "when"
    b.name = "name"
    b.loop = "loop"
    b.loop_control = "loop_control"
    b.register = "register"
    b.retries = "retries"
    b.delay = "delay"
    b.until = "until"
    b.changed_when = "changed_when"
    b.failed_when = "failed_when"
    b.tags = "tags"
    b.run_once = "run_once"
    b.ignore_errors = "ignore_errors"

# Generated at 2022-06-17 07:13:03.785683
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [{'name': 'test'}]
    block.rescue = [{'name': 'test'}]
    block.always = [{'name': 'test'}]
    block.dep_chain = ['test']
    block.role = Role()
    block.role.name = 'test'
    block.parent = Block()
    block.parent.name = 'test'
    block.parent_type = 'test'
    block.statically_loaded = True
    block.use_handlers = True
    block.implicit = True
    block.loop = 'test'
    block.loop_args = 'test'
    block.when = 'test'
    block.register = 'test'
    block.ignore_errors = True

# Generated at 2022-06-17 07:13:20.116842
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'role': {'name': 'test_role'}, 'parent': {'name': 'test_parent'}, 'parent_type': 'Block'})
    assert block._role.name == 'test_role'
    assert block._parent.name == 'test_parent'
    assert block._parent.__class__.__name__ == 'Block'


# Generated at 2022-06-17 07:13:28.501939
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:13:40.612593
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup

# Generated at 2022-06-17 07:13:41.565014
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-17 07:13:50.571575
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude

# Generated at 2022-06-17 07:13:58.282979
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [{'name': 'test'}]
    block.rescue = [{'name': 'test'}]
    block.always = [{'name': 'test'}]
    block.dep_chain = [{'name': 'test'}]
    block.role = {'name': 'test'}
    block.parent = {'name': 'test'}
    block.parent_type = 'Block'

    new_block = block.copy()
    assert new_block.block == [{'name': 'test'}]
    assert new_block.rescue == [{'name': 'test'}]
    assert new_block.always == [{'name': 'test'}]

# Generated at 2022-06-17 07:14:06.928657
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

# Generated at 2022-06-17 07:14:16.294943
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    block.dep_chain = [1, 2, 3]
    block.role = Role()
    block.parent = Block()
    block.parent_type = 'Block'
    block.play = Play()
    block.use_handlers = True
    block.validate()
    block.copy()
    block.copy(exclude_parent=True)
    block.copy(exclude_tasks=True)
    block.copy(exclude_parent=True, exclude_tasks=True)


# Generated at 2022-06-17 07:14:31.146187
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-17 07:14:32.865394
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader(loader)
