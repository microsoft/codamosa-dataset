

# Generated at 2022-06-11 09:47:30.383514
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    data = {
        'block': [{
            'action': 'shell',
            'args': 'ls'}],
        'rescue': [{
            'action': 'shell',
            'args': 'ls',
            'environment': {'key': 'value'}},
            {'action': 'shell',
                'args': 'ls'}],
        'always': [{
            'action': 'shell',
            'args': 'ls'}]
    }
    block = Block(data)
    block.validate()
    assert block.has_tasks() == True

# Generated at 2022-06-11 09:47:34.113061
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    ds = {'block': 'block_value'}
    b = Block()
    assert b.preprocess_data(dict(block='block_value')) == ds



# Generated at 2022-06-11 09:47:40.354805
# Unit test for method copy of class Block
def test_Block_copy():
  # i am using testinfra to execute ansible 
  host = ansible.utils.create_host(testinfra_host.backend.get_hostname(), testinfra_host.backend.get_connection_type(), ansible.constants.DEFAULT_VAULT_PASSWORD)
  host.backend.connection._shell = ShellModule(host.backend)
  result = host.backend.connection._shell.run_command('ls')
  assert result.rc == 0

# Generated at 2022-06-11 09:47:49.785866
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    import json
    
    with open("data/tasks.json") as json_file:
        json_data = json.load(json_file)
    
    
    
    
    
    ##################################################
    #### Function to help testing filter_tagged_tasks
    ##################################################
    def compare_tasks(tasks, json_tasks):
        for task in tasks:
            task_name = task.get_name()
            if task_name == "debug":
                if not "when" in task.keys():
                    # debug task without when should be the same
                    if task_name != json_tasks[0]["action"]["__ansible_module__"]:
                        return False
                    else:
                        del json_tasks[0]

# Generated at 2022-06-11 09:47:51.034693
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block = Block()
    assert block.all_parents_static()


# Generated at 2022-06-11 09:47:54.875557
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    import ansible.playbook
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    b = Block()
    t = Task()
    b.block = [t]
    b.filter_tagged_tasks(dict())

# end class Block



# Generated at 2022-06-11 09:47:57.716238
# Unit test for method copy of class Block
def test_Block_copy():
    """
    Unit test for the method `copy` of class Block
    """
    a = Block()
    b = a.copy()
    assert a.__dict__ == b.__dict__


# Generated at 2022-06-11 09:47:59.430834
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block()
    b.set_loader(mock.ANY)
    assert True


# Generated at 2022-06-11 09:48:08.784798
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    b.always = None
    b.always_run = None
    b.block = None
    b.changed_when = None
    b.connection = None
    b.delegate_to = None
    b.delegate_facts = None
    b.deprecated = None
    b.environment = None
    b.errors = None
    b.evaluations = None
    b.failed_when = None
    b.notify = None
    b.name = None
    b.no_log = None
    b.poll = None
    b.retries = None
    b.run_once = None
    b.serial = None
    b.sudo = None
    b

# Generated at 2022-06-11 09:48:19.575046
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    ''' Block.filter_tagged_tasks()
    tests for method Block.filter_tagged_tasks() of class Block
    '''
    try:
        from ansible.playbook.block import Block
    except ImportError:
        # since the block imports the PlayBook and Play classes
        # we can use this to test if the PlayBook class was loaded
        # or not, even though we are not testing it here
        sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
        sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
        from ansible.playbook.block import Block

    test_block = Block()
    test_block.block = [ {} ]

    test_block = Block

# Generated at 2022-06-11 09:48:40.389336
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create instance of class Block
    block_obj = Block()
    # Create some objects to test with
    file_obj = [File()]
    block_obj = [Block()]
    all_vars = [All_vars()]
    # Test filter_tagged_tasks
    block_obj.filter_tagged_tasks(all_vars)


# Generated at 2022-06-11 09:48:45.985317
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Create a Block object and make sure it has no tasks
    block = Block()
    assert block.has_tasks() == False
    # Create a Block object with a task (it has a name and a file)
    block = Block(block=[{"name":"test task in block", "foo": {"bar": "test baz"}}])
    assert block.has_tasks() == True


# Generated at 2022-06-11 09:48:47.030449
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
	raise NotImplementedError


# Generated at 2022-06-11 09:48:58.527738
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.playbook import Play
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    m_args = {'_use_handlers': False, '_variable_manager': None, '_l': None, '_loader': None, '_dep_chain': None, '_v': None, '_parent': None, '_role': None, '_tags': []}


# Generated at 2022-06-11 09:48:59.221106
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    pass

# Generated at 2022-06-11 09:49:09.681023
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # initialize the TestBlock class
    class TestBlock(Block):
        _valid_attrs = frozenset()

    # initialize the TestPlay class
    class TestPlay(object):
        def __init__(self, only_tags, skip_tags):
            self._attributes = dict()
            self.only_tags = only_tags
            self.skip_tags = skip_tags

    # initialize the TestRole class
    class TestRole(object):
        def __init__(self, data):
            self._attributes = data

    # initialize the TestTask class
    class TestTask(object):
        def __init__(self, name, tags, action):
            self._attributes = dict()
            self.name = name

            if isinstance(tags, list):
                self.tags = tags

            self.action = action

       

# Generated at 2022-06-11 09:49:16.764666
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    name = 'block1'
    block = Block(name)
    first_parent_include = block.get_first_parent_include()
    assert first_parent_include == None
    name = 'block2'
    block2 = Block(name)
    block2._parent = block
    first_parent_include = block2.get_first_parent_include()
    assert first_parent_include == None
    from ansible.playbook.task_include import TaskInclude
    name = 'task2'
    task2 = TaskInclude(name)
    task2._parent = block2
    first_parent_include = task2.get_first_parent_include()
    assert first_parent_include == None
    name = 'task3'
    task3 = TaskInclude(name)
    task3._parent = task2


# Generated at 2022-06-11 09:49:28.899750
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources=[])
    variable_manager.set_inventory(inventory)
    context = PlayContext(variable_manager=variable_manager)
    context._tqm = MagicMock()
    context._tqm.tags = ['tag1', 'tag2']

# Generated at 2022-06-11 09:49:33.263886
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    obj = Block()
    obj.block = [Task()]
    obj.rescue = [Task()]
    obj.always = [Task()]
    assert obj.has_tasks() is True


# Generated at 2022-06-11 09:49:44.749076
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    data = dict(a='a', b='b')
    block.deserialize(data)
    assert block._attributes == data

    dep_chain = ['dep1', 'dep2']
    data = dict(dep_chain=dep_chain)
    block._dep_chain = None
    block.deserialize(data)
    assert block._dep_chain == dep_chain

    role_data = dict(name='role_name')
    data = dict(role=role_data)
    block._role = None
    block.deserialize(data)
    assert block._role.serialize() == role_data

    parent_data = dict(name='parent')
    parent_data['parent_type'] = 'TaskInclude'
    data = dict(parent=parent_data)
    block._parent

# Generated at 2022-06-11 09:50:16.928577
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.reserved import is_reserved_name
    from ansible.parsing.dataloader import DataLoader

    def set_parents(obj):
        if hasattr(obj, '_parent'):
            obj._parent = Block()

    b1 = Block()

# Generated at 2022-06-11 09:50:22.663203
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    test_data = {
        'block': [],
        'rescue': [],
        'always': []
    }
    ds = copy.deepcopy(test_data)
    new_block = Block()
    new_block.load_data(ds)

    assert new_block.has_tasks() == False
    assert new_block.all_parents_static() == True



# Generated at 2022-06-11 09:50:32.781173
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # Set up mock objects for the test
    mock_loader = MagicMock()
    mock_play = MagicMock()
    mock_parent = Role()
    mock_task = MagicMock()
    mock_task.serialize.return_value = dict(test_var='test_val')
    mock_parent._tasks = [mock_task]
    mock_role = MagicMock()
    mock_parent._role = mock_role
    mock_parent._play = mock_play
    mock_parent._loader = mock_loader
    mock_parent.statically_loaded = True


# Generated at 2022-06-11 09:50:34.464668
# Unit test for method deserialize of class Block
def test_Block_deserialize():
	block = Block()
	assert block.deserialize({}) == None
	#

# Generated at 2022-06-11 09:50:45.129496
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    b = Block.load(dict(block=[
            dict(name='first task', tags=['foo', 'bar']),
            dict(name='second task', tags=['baz', 'qux']),
            dict(name='third task', tags=['corge', 'grault']),
        ]),
        variable_manager=VariableManager(),
        loader=DataLoader(),
    )
    p = Play().load(dict(tasks=[b]), variable_manager=VariableManager(), loader=DataLoader())
    p._tasks = [b]
    p.post_validate(variable_manager=VariableManager(), loader=DataLoader())
    p._variable_

# Generated at 2022-06-11 09:50:50.673549
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = Block()  
    block.block = [{'tags': ['firsttag']}]
    block.rescue = [{'tags': ['firsttag']}]
    block.always = [{'tags': ['firsttag']}]
    block.filter_tagged_tasks({})

# end of unit test for method filter_tagged_tasks of class Block


# Generated at 2022-06-11 09:50:58.764690
# Unit test for method is_block of class Block
def test_Block_is_block():
	from ansible.parsing.dataloader import DataLoader
	from ansible.vars.manager import VariableManager
	from ansible.inventory.manager import InventoryManager
	from ansible.playbook.play import Play
	options = namedtuple('Options', ['connection','module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff'])
	options = Options(connection='local', module_path='/path/to/mymodules', forks=10, become=None, become_method=None, become_user=None, check=False, diff=False)
	loader = DataLoader()
	passwords = dict()
	inventory = InventoryManager(loader=loader, sources='localhost,')
	variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 09:51:09.469697
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = dict(
        block= [
            dict(
                block=[
                    dict(
                        when='False',
                        block= [
                            dict(
                                when='False',
                                block=[
                                    dict(when='True', action=dict(module='include_tasks', args=dict(static='{{ test }}', name='static_load', ) ) ),
                                ]
                            ),
                        ]
                    ),
                ]
            ),
        ]
    )

    task_include = dict(
        when='False',
        action=dict(
            module='include_tasks',
            args=dict(
                dynamic='{{ test }}',
                name='dynamic_load',
                tags='test',
            )
        ),
    )

    all_vars = dict(test='test')

# Generated at 2022-06-11 09:51:19.970808
# Unit test for method is_block of class Block
def test_Block_is_block():

    # Check if ds is a dict
    ds_not_dict = "foo"
    assert(not Block.is_block(ds_not_dict))

    ds_not_dict = [1, 2, 3]
    assert(not Block.is_block(ds_not_dict))

    ds_not_dict = Block.load(dict(block=[1,2]), play=None, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert(not Block.is_block(ds_not_dict))

    # Check if ds is a dict with attr 'block', 'rescue', 'always'
    dict_single_key = dict(block=[1,2])

# Generated at 2022-06-11 09:51:28.122582
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.base import Base
    # Test method copy of class Block
    obj = Block()
    parent = Base()
    obj._parent = parent
    obj._valid_attrs = {'hosts': 'hosts'}
    obj._attributes = {'hosts': 'hosts'}
    obj._use_handlers = True
    obj.block = []
    obj.rescue = []
    obj.always = []
    obj._loader = None
    obj.dep_chain = None
    obj.always_post_validate = Base.post_validate
    obj.always_pre_validate = Base.pre_validate
    obj.rescue_post_validate = Base.post_validate
    obj.rescue_pre_validate = Base.pre_validate
    obj.block_

# Generated at 2022-06-11 09:51:53.019419
# Unit test for method copy of class Block
def test_Block_copy():
    import ansible.playbook.task
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.block
    import ansible.playbook.task_include
    import ansible.playbook.handler_task_include
    import ansible.playbook.handler_block
    import ansible.template
    import ansible.parsing.yaml.objects
    import ansible.inventory.host
    Task = ansible.playbook.task.Task
    Play = ansible.playbook.play.Play
    Role = ansible.playbook.role.Role
    Block = ansible.playbook.block.Block
    TaskInclude = ansible.playbook.task_include.TaskInclude
    HandlerTaskInclude = ansible.playbook.handler_task_include.HandlerTask

# Generated at 2022-06-11 09:51:54.687346
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    print("********* Unit Testing Block_get_dep_chain ************")
    b = Block()

# Generated at 2022-06-11 09:52:04.339720
# Unit test for method deserialize of class Block

# Generated at 2022-06-11 09:52:10.458516
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    mock_Block = MagicMock(spec=Block)
    mock_Block._load_data.return_value = sentinel._load_data
    with patch.object(Block, 'preprocess_data', new=mock_Block.preprocess_data):
        ret_Block_preprocess_data = Block.preprocess_data('self', 'ds')
    assert mock_Block._load_data.called
    assert ret_Block_preprocess_data == sentinel._load_data

# Generated at 2022-06-11 09:52:20.252622
# Unit test for method deserialize of class Block
def test_Block_deserialize():

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Create and deserialize a block to test against
    top_block = Block()
    top_block._loader = DictDataLoader({})
    top_block._attributes = {'loop': '{{ my_list }}', 'name': "Top Block"}
    top_block._role = Role()
    top_block._parent = TaskInclude()

    top_block.block = [Task(), Task(), Handler(), Task()]
    top_block.block[0]._role = Role()
    top_block.block[0]._parent = top_block
    top_block.block[1]._role = Role()
    top_block.block[1]._parent = top_block


# Generated at 2022-06-11 09:52:28.639389
# Unit test for method copy of class Block
def test_Block_copy():
    # Basic test: implicit block
    data = dict(block=[dict(action=dict(module='debug', args=dict(msg='foo')))])
    b = Block.load(data, play=object())
    assert b.copy() != b
    # Tags affect copy
    data = dict(block=[dict(action=dict(module='debug', args=dict(msg='foo'))), dict(action=dict(module='debug', args=dict(msg='foo')), tags=['a'])])
    b = Block.load(data, play=object())
    assert len(b.copy().block) == 1
    b = Block.load(data, play=object(), use_handlers=True)
    assert len(b.copy().block) == 2
    # Rescue and Always affect copy

# Generated at 2022-06-11 09:52:29.283497
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    pass

# Generated at 2022-06-11 09:52:32.474277
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    obj = Block()
    obj.block = []
    assert obj.has_tasks()
    obj.always = []
    assert obj.has_tasks()
    obj.rescue = []
    assert not obj.has_tasks()

# Generated at 2022-06-11 09:52:43.097197
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host 
    from ansible.inventory.group import Group 
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-11 09:52:53.903151
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible import context
    #Setup initial data
    hosts = None
    roles = None
    play_context = PlayContext()
    loader = DataLoader()
    variable

# Generated at 2022-06-11 09:53:12.908244
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    result = block.has_tasks()
    assert not result
    block.block = True
    result = block.has_tasks()
    assert result
##########################################################################

# Generated at 2022-06-11 09:53:21.109325
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Test fixture
    def _get_block(block_data, parent_block=None):
        class TestBlock(Block):
            def __init__(self):
                super(TestBlock, self).__init__(parent_block=parent_block)
        block = TestBlock()
        block._attributes = block_data
        return block

    # test data

# Generated at 2022-06-11 09:53:31.286568
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    '''
    Test that Block.filter_tagged_tasks method filters blocks as expected
    '''

# Generated at 2022-06-11 09:53:32.786395
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()


# Generated at 2022-06-11 09:53:41.764464
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # Test that deserialize raises exception on bad input data
    block = Block()
    deserialize = lambda: block.deserialize({})
    assert_raises(AssertionError, deserialize)

    # Test that deserialize raises exception on bad input data
    block = Block()
    deserialize = lambda: block.deserialize({'role': {}})
    assert_raises(AnsibleError, deserialize)

    # Test that deserialize raises exception on bad input data
    from ansible.playbook import PlayBook, Play
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager

    host = Inventory()
    host.add_host('test.example.com', 'all')
    play = Play()
    play.deserialize({'name': 'test'})

# Generated at 2022-06-11 09:53:44.067784
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    b = Block()
    b.deserialize(dict(block=[('first','second','third')], whenever_values=['first','second','third']))
    # TODO


# Generated at 2022-06-11 09:53:53.410069
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # If a simple task is given, an implicit block for that single task
    # is created, which goes in the main portion of the block
    # This test is to check if this deserialization works correctly.
    task = Task()
    task.deserialize({"name": "test"})
    b = Block()
    b.deserialize(task.serialize())
    print(b.serialize())
    assert b.block == [task], "Block deserialization failed"

    # If a simple task is given, an implicit block for that single task
    # is created, which goes in the main portion of the block
    # This test is to check if this deserialization works correctly.
    task1 = Task()
    task2 = Task()
    task1.deserialize({"name": "task1"})
    task2.deserial

# Generated at 2022-06-11 09:54:01.944587
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import Host

# Generated at 2022-06-11 09:54:10.708520
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    #from ansible.playbook.task_include.TaskInclude import TaskInclude
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import Variable

# Generated at 2022-06-11 09:54:13.026842
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Setup
    block = Block()
    loader = object()

    # Exercise
    block.set_loader(loader)

    # Verify
    assert block._loader == loader

# Generated at 2022-06-11 09:54:53.249931
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # TODO: Test variable and function evaluation with include_vars,
    # include_tasks, and import_role
    b = Block()
    assert b.has_tasks() == False
    b = Block(block=[])
    assert b.has_tasks() == True
    b = Block(block=[{'task': 'name'}, {'task': 'name2'}])
    assert b.has_tasks() == True
    b = Block(block=[{'meta': 'noop'}])
    assert b.has_tasks() == True
    b = Block(rescue=[{'task': 'name'}])
    assert b.has_tasks() == True
    b = Block(block=[{'task': 'name'}])
    assert b.has_tasks() == True
    b = Block

# Generated at 2022-06-11 09:54:59.261859
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    args_deserialize = {'data':{'when':['blah'], 'rescue':None}}
    obj = Block(**{'play':None, 'role':None, 'task_include':None, 'use_handlers':False, 'implicit':True})
    try:
        obj.deserialize(**args_deserialize)
    except Exception as err:
        assert isinstance(err, AnsibleParserError)
        assert str(err) == "invalid conditional statement: 'blah'"


# Generated at 2022-06-11 09:55:06.974124
# Unit test for method is_block of class Block
def test_Block_is_block():

    ds = list()
    data = Block.is_block(ds)
    assert data is False

    ds = dict()
    data = Block.is_block(ds)
    assert data is False

    ds = dict(block=list())
    data = Block.is_block(ds)
    assert data is True

    ds = dict(always=list())
    data = Block.is_block(ds)
    assert data is True

    ds = dict(rescue=list())
    data = Block.is_block(ds)
    assert data is True

    ds = dict(block="block")
    data = Block.is_block(ds)
    assert data is True


# Generated at 2022-06-11 09:55:09.488521
# Unit test for method copy of class Block
def test_Block_copy():
    '''test_Block_copy
    Test for method copy
    '''
    print("\n========== test_Block_copy ==========")
    assert False == False

# Generated at 2022-06-11 09:55:18.205292
# Unit test for method deserialize of class Block
def test_Block_deserialize():
  block = Block()
  assert getattr(block, "rescue") == []
  assert getattr(block, "block") == []
  assert getattr(block, "always") == []
  assert getattr(block, "_attributes") == {}
  assert getattr(block, "_loader") == None
  assert getattr(block, "_valid_attrs") == {}
  assert getattr(block, "_parent") == None
  assert getattr(block, "_role") == None
  assert getattr(block, "_dep_chain") == None
  assert getattr(block, "_play") == None
  assert getattr(block, "_loader_cache") == {}
  assert getattr(block, "_use_handlers") == None
  assert getattr(block, "_variable_manager") == None

# Generated at 2022-06-11 09:55:28.615131
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    block1 = Block()
    block1.statically_loaded = False
    task1 = Task()
    block1.block = [task1]
    block2 = Block()
    task2 = Task()
    block2.block = [task2]
    block2.statically_loaded = False
    task_include = TaskInclude()
    task_include.block = block1
    task_include.statically_loaded = False
    block3 = Block()
    block3.statically_loaded = False
    block3.block = [task_include]
    play = Play()

# Generated at 2022-06-11 09:55:39.081178
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block(use_handlers=True)

# Generated at 2022-06-11 09:55:40.605751
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
  assert(Block._all_parents_static() == 0)


# Generated at 2022-06-11 09:55:42.240965
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # check set_loader of class Block
    pass


# Generated at 2022-06-11 09:55:50.726501
# Unit test for method has_tasks of class Block

# Generated at 2022-06-11 09:56:24.812493
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block(block=["test"])
    c = b.copy()
    assert c.has_tasks()


# Generated at 2022-06-11 09:56:25.672673
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
  assert False


# Generated at 2022-06-11 09:56:27.760068
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    # TODO: validate the [] that is passed
    block.set_loader({})


# Generated at 2022-06-11 09:56:35.354174
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    B = Block(
        block=[
            Task(action='shell echo 1'),
            Task(action='shell echo 2')
        ],
        rescue=[
            Task(action='shell echo 3'),
            Task(action='shell echo 4')
        ],
        always=[
            Task(action='shell echo 5'),
            Task(action='shell echo 6')
        ]
    )
    assert B.has_tasks() == True

    B = Block(
        block=[
            Task(action='shell echo 1'),
            Task(action='shell echo 2')
        ]
    )
    assert B.has_tasks() == True
