

# Generated at 2022-06-11 09:47:23.505042
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Initialize a Block object
    b = Block()
    # Check has_tasks method if block has no tasks
    assert b.has_tasks() == False


# Generated at 2022-06-11 09:47:33.691744
# Unit test for method copy of class Block
def test_Block_copy():
    my_block = Block(statically_loaded=False, parent=None, dep_chain=None, use_handlers=True, implicit=False, play=None, role=None, task_include=None)
    new_block = my_block.copy()
    assert new_block._attributes == my_block._attributes
    assert new_block.block == my_block.block
    assert new_block.rescue == my_block.rescue
    assert new_block.always == my_block.always
    assert new_block._play == my_block._play
    assert new_block._use_handlers == my_block._use_handlers
    assert new_block._dep_chain == my_block._dep_chain
    assert new_block._parent == my_block._parent
    assert new_block._role == my_block

# Generated at 2022-06-11 09:47:37.497490
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=True)
    ds = {}
    block.preprocess_data(ds)


# Generated at 2022-06-11 09:47:46.923857
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    block = Block()
    task = Task()
    block.load({
        'block': [
            {
                'task': {
                    'action': 'set_fact',
                    'args': {'a': 2}}
            },
            {
                'block': [
                    {
                        'task': {
                            'action': 'set_fact',
                            'args': {'a': 2}}
                        , 'when': 'true'}
                ],
                'always': [
                    {
                        'task': {
                            'action': 'set_fact',
                            'args': {'a': 2}}
                    }
                ]
            }
        ]})
    # normal test
    all_vars = {}


# Generated at 2022-06-11 09:47:56.087937
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():

    def assert_equal(expected, result, msg=""):
        if expected != result:
            errmsg = "Expected:\n%s\n\nGot:\n%s\n\n%s" % (expected, result, msg)
            raise AssertionError(errmsg)

    # Setup
    b = Block()
    with open("./test/unit/output/Block_filter_tagged_tasks.inp", "r") as f:
        b._data = f.read()
        b.load_data(b._data)
        # Write to test file for visual confirmation.

# Generated at 2022-06-11 09:48:05.240933
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    task_obj = Task()
    block_obj = Block(play=None, parent_block=task_obj, role=None, task_include=None, use_handlers=False, implicit=False)
    task_include_obj = TaskInclude()
    handler_obj = Handler()
    handler_task_include_obj = HandlerTaskInclude()
    assert block_obj.all_parents_static() == True
    block_obj._parent = task_include_obj
    assert block_obj.all_parents_static() == True
    block_obj._parent = handler_obj

# Generated at 2022-06-11 09:48:06.152539
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block.copy()

# Generated at 2022-06-11 09:48:08.323256
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    dup = b.copy()
    assert b is not dup
    assert isinstance(dup, Block)

# Generated at 2022-06-11 09:48:17.064425
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
  # create a new object for ansible.playbook.task_include.TaskInclude
  task_include = TaskInclude()
  # create a new object for ansible.playbook.block.Block
  block = Block()
  # create a new object for ansible.playbook.task.Task
  task = Task()
  # create a new list
  list_ = []
  # call method filter_tagged_tasks of class Block
  filter_tagged_tasks = block.filter_tagged_tasks(list_)
  assert filter_tagged_tasks is None, 'Expected output does not match'


# Generated at 2022-06-11 09:48:27.524334
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-11 09:49:08.094174
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.basic import Playbook
    from ansible.playbook.block import Block
    from ansible.module_utils._text import to_bytes
    from ansible.errors import AnsibleParserError
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import yaml
    import os

    # Load playbook file
    playbook_dir=os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    yml_path=os.path.join(playbook_dir,'test/unit/test_modules/test_playbook.yml')

# Generated at 2022-06-11 09:49:14.609131
# Unit test for method copy of class Block
def test_Block_copy():
    '''
    Unit test for method copy of class Block
    '''
    my_ds = {'register': 'my_register', 'block': [{'action': 'my_action'}], 'rescue': [{'action': 'my_action'}], 'always': [{'action': 'my_action'}], 'vars': {'test': 'test'}}
    my_block = Block.load(my_ds, None, None, None, None, None, None)
    my_block_copy = my_block.copy()
    assert my_block.copy() == my_block_copy



# Generated at 2022-06-11 09:49:15.634802
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    pass


# Generated at 2022-06-11 09:49:17.604779
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = Block(block=[])
    assert(block.filter_tagged_tasks([]) == Block())



# Generated at 2022-06-11 09:49:30.375810
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    def make_block(block_id, block=None, rescue=None, always=None):
        return Block(block=block, rescue=rescue, always=always, play=fake_play, role=fake_role, task_include=fake_task_include, use_handlers=True, implicit=True, id=block_id)
    def make_task(task_id, action='debug', args={'msg': 'test'}, tags=None):
        return Task(action=action, args=args, tags=tags, play=fake_play, role=fake_role, task_include=fake_task_include, use_handlers=True, implicit=True, id=task_id)
    fake_play             = Play()
    fake_role             = Role()
    fake_task_include     = TaskInclude()
    fake_block

# Generated at 2022-06-11 09:49:34.739184
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block1 = Block()
    # param: data
    data = dict()
    # deserialize method of Block class returns None
    assert block1.deserialize(data) == None


# Generated at 2022-06-11 09:49:35.571095
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    pass

# Generated at 2022-06-11 09:49:46.308770
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Instantiate a Block object
    obj = Block()

    # Assign a valid value for attribute '_attributes' of the Block object
    obj._attributes = dict()

    # Assign a valid value for attribute '_valid_attrs' of the Block object
    obj._valid_attrs = dict()

    # Assign a valid value for attribute 'name' of the Block object
    obj.name = None

    # Assign a valid value for attribute 'action' of the Block object
    obj.action = None

    # Assign a valid value for attribute '_parent' of the Block object
    # obj._parent = None

    # Assign a valid value for attribute 'always' of the Block object
    # obj.always = None

    # Assign a valid value for attribute 'block' of the Block object
    # obj.block = None

   

# Generated at 2022-06-11 09:49:54.354170
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    """
    Unit test for method all_parents_static of class Block
    """
    block1 = unittest.mock.Mock(spec=Block)
    block1.statically_loaded = False
    block1.all_parents_static = unittest.mock.Mock()
    block1.all_parents_static.return_value = False

    block2 = unittest.mock.Mock(spec=Block)
    block2.all_parents_static = unittest.mock.Mock()
    block2.all_parents_static.return_value = True
    block2._parent = block1

    block3 = unittest.mock.Mock(spec=Block)
    block3.all_parents_static = unittest.mock.Mock()
    block3.all_parents

# Generated at 2022-06-11 09:49:57.948122
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    p = Play()
    b = Block(play=p, parent_block=None, role=None, task_include=None)
    assert b._loader == None
    b.set_loader(None)
    # FIXME Change this if different behavior is observed
    pass

# Generated at 2022-06-11 09:50:20.388271
# Unit test for method deserialize of class Block
def test_Block_deserialize():
   block = Block()
   print(block.deserialize())


# Generated at 2022-06-11 09:50:22.697080
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # obj = Block()
    # args = dict()
    # obj.deserialize(**args)
    pass


# Generated at 2022-06-11 09:50:29.022422
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    # arrange
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    parent_include = TaskInclude()

    # act
    actual = test_Block_get_first_parent_include_helper(parent_include)

    # assert
    assert actual == parent_include, "Expected: %s, Actual: %s" % (parent_include, actual)


# Generated at 2022-06-11 09:50:38.308864
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    t = Block()
    assert t.has_tasks() == False
    t = Block(block = [])
    assert t.has_tasks() == False
    t = Block(block = [Task()])
    assert t.has_tasks() == True
    t = Block(block = [], rescue = [])
    assert t.has_tasks() == False
    t = Block(block = [], rescue = [Task()])
    assert t.has_tasks() == True
    t = Block(block = [], rescue = [], always = [])
    assert t.has_tasks() == False
    t = Block(block = [], rescue = [], always = [Task()])
    assert t.has_tasks() == True


# Generated at 2022-06-11 09:50:38.932622
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
	pass

# Generated at 2022-06-11 09:50:50.623523
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.tqm import UnreachableHost
    from ansible.timing import Timer
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_inventory_vars
    from ansible.utils.vars import load_play_vars
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-11 09:50:56.740040
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    import ansible.playbook.task_include
    import ansible.playbook.handler_task_include
    import ansible.playbook.role_include
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.playbook.included_file
    import ansible.playbook.included_file
    import ansible.module_utils.basic
    import ansible.utils
    import ansible.errors

# Generated at 2022-06-11 09:50:57.906204
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize()


# Generated at 2022-06-11 09:51:08.559589
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
  from ansible.playbook.block import Block
  from ansible.playbook.task import Task
  from ansible.playbook.task_include import TaskInclude
  from ansible.playbook.handler_task_include import HandlerTaskInclude

  ## If a Block object has a parent object
  ## which is a TaskInclude object and the statically_loaded of this TaskInclude object is False
  ## Method all_parents_static return False
  task_include = TaskInclude()
  task_include.statically_loaded = False
  task_block = Block()
  task_block._parent = task_include
  assert task_block.all_parents_static() == False

  ## If the parent of the parent of parent of ... of the Block object is a TaskInclude object
  ## and this TaskInclude object is statically_loaded
  ## But

# Generated at 2022-06-11 09:51:10.827307
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    play = Play()
    block = Block(play=play)
    block.set_loader(object())
    assert block.set_loader(object()).__class__ == None

# Generated at 2022-06-11 09:51:42.546044
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    #Import Libraries
    import pytest
    import sys
    import os

    # Import test modules
    curr_path = os.path.dirname(os.path.abspath(__file__))
    sys.path.append(os.path.abspath(curr_path + "/../../"))
    sys.path.append(os.path.abspath(curr_path + "/../"))
    import unittest.mock as mock
    from ansible.playbook.blocks import Block

    # Test Cases
    block = Block()

    # Case 1 : Test if all parents are static
    resp = block.all_parents_static()
    assert resp == True
    # Case 2 : Test if all parents are not static
    block._parent = False
    resp = block.all_parents_static()

# Generated at 2022-06-11 09:51:51.961063
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    # Test case 1
    b = Block(all_parents_static=True)
    assert None == b.get_first_parent_include()
    # Test case 2
    b = Block(all_parents_static=True)
    assert None == b.get_first_parent_include()
    # Test case 3
    b = Block(all_parents_static=True)
    assert None == b.get_first_parent_include()
    # Test case 4
    b = Block(all_parents_static=True)
    assert None == b.get_first_parent_include()
    # Test case 5
    b = Block(all_parents_static=True)
    assert None == b.get_first_parent_include()


# Generated at 2022-06-11 09:51:53.903687
# Unit test for method copy of class Block
def test_Block_copy():
    """
    Unit test for method copy of class Block
    """
    pass


# ----------------------------------------------------------------------------
# AnsibleRandom()
# ----------------------------------------------------------------------------

# Generated at 2022-06-11 09:52:03.345113
# Unit test for method copy of class Block
def test_Block_copy():

    my_block = Block()
    my_block._attributes = {
        'become_user': 'bob',
        'register': 'result',
        'unreachable': False,
        'ignore_errors': True,
    }
    my_block._ds = dict()

    my_task = ActionModule(dict(action='ping'))
    my_task._attributes = {
        'become_user': 'bob',
        'register': 'result',
        'unreachable': False,
        'ignore_errors': True,
    }
    my_task.action = 'ping'
    my_task._ds = dict()
    my_task._parent = my_block

    new_block = my_block.copy(exclude_parent=False, exclude_tasks=False)
    assert new_block

# Generated at 2022-06-11 09:52:04.701854
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    obj = Block()
    assert obj.has_tasks() == False

# Generated at 2022-06-11 09:52:14.370370
# Unit test for method deserialize of class Block

# Generated at 2022-06-11 09:52:23.898522
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    '''
    Test filter_tagged_tasks of Block
    '''
    
    from ansible.playbook.task import Task
    from ansible.playbook.playbook import Playbook, PlaybookInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.dynamic_block import DynamicInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    
    ##########
    # TaskInclude
    task_include = TaskInclude()
    task_include.set_loader(DictDataLoader(dict()))
    task_include.vars = {}
    task_include.statically_loaded = True
    
    playbook = Playbook()

    # task_include.block = ["a", "b"]

# Generated at 2022-06-11 09:52:32.634379
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a simple set of tasks to test
    block1 = Block(
        block=[
            dict(
                block=[dict(block=[dict(block=[dict(action='fubar')], rescue=[dict(action='fubar')]), dict(action='debug')],
                           rescue=[dict(block=dict(rescue=[dict(action='debug')]), action='debug')]),
                   dict(action='debug', tags=['debug']),
                   dict(action='debug', tags=['undebug']),
                   dict(action='debug', when='1 < 2'),
                   dict(action='debug', when='1 > 2'),
                   dict(action='debug', when='1n0ttrue')])
        ])

    # Create variable manager
    variable_manager = VariableManager()

    # Create loader
    loader = DataLoader()

    # Create

# Generated at 2022-06-11 09:52:34.639946
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    s = "class Block::set_loader is not implemented"
    raise Exception(s)

# Generated at 2022-06-11 09:52:42.534981
# Unit test for method deserialize of class Block

# Generated at 2022-06-11 09:54:36.213068
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-11 09:54:40.904773
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # initialize()
    t_play = play.Play()
    t_variable_manager = VariableManager()
    t_loader = DataLoader()
    t_task = task.Task()
    t_block = Block(parent_block=t_task, loader=t_loader, variable_manager=t_variable_manager, play=t_play)

    t_block.set_loader(t_loader)
    


# Generated at 2022-06-11 09:54:50.165961
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.plugins.loader import become_loader, vars_loader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    def _initialize_loader():
        fake_loader = DictDataLoader({})
        fake_loader.set_basedir("/some/path")
        fake_loader._template_class = Templar
        fake_loader._add_directory(os.path.join("/some/path", 'filter_plugins'))
        fake_loader._add_directory(os.path.join("/some/path", 'lookup_plugins'))
        become_loader.get = MagicMock(return_value=None)
        vars_loader.get = MagicMock(return_value=None)

        return fake_loader

    def _initialize_variable_manager(loader):
        variable

# Generated at 2022-06-11 09:54:59.062021
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    class MyBlock(Block):
        pass
    class MyTask(Task):
        pass
    class MyTaskInclude(TaskInclude):
        pass
    task = MyTask()
    block = MyBlock()
    block.lineage = 'parent'
    block.load({'block': [task]})
    task.lineage = 'mytask'
    task.block = block
    task2 = MyTask()
    task2.lineage = 'child'
    task_include = MyTaskInclude()
    task_include.lineage = 'myinclude'
    task_include.load({'tasks': [task2]})

# Generated at 2022-06-11 09:55:00.769898
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    test_block = Block()
    test_block.set_loader(test_block)


# Generated at 2022-06-11 09:55:01.444967
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    pass

# Generated at 2022-06-11 09:55:10.331241
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    '''
    unit test for method all_parents_static of class Block
    '''
    # This is a pretty in-depth unit test, as it includes several mock objects,
    # and also requires serializing and deserializing to test that all_parents_static()
    # behaves properly when the objects were statically or dynamically loaded.

    ## Because we're working with objects that need to be dynamically created, we
    ## can't use a standard unit test class.  Instead, we create the objects
    ## manually, and test them in the dynamic context of a fake task, which
    ## adds complexity that doesn't really need to be tested in this unit test.
    class MockTask(object):
        def __init__(self):
            self._role = None

        def set_loader(self, loader):
            pass
        def get_loader(self):
            return None

# Generated at 2022-06-11 09:55:13.019210
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False)
    data = None
    block.deserialize(data)

# Generated at 2022-06-11 09:55:21.552956
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    b = Block()
    b.block = [
        Task(action='debug', name='task0', tags=['tag0']),
        Task(action='debug', name='task1', tags=['tag1']),
        Task(action='debug', name='task2', tags=['tag2']),
        ]
    p = PlayContext()
    p.only_tags = ['tag0']
    p.skip_tags = ['tag1']
    b = b.filter_tagged_tasks(dict(play_context=p))

    assert len(b.block) == 2
    assert len(b.rescue) == 0
    assert len(b.always)

# Generated at 2022-06-11 09:55:23.235506
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    return None


# Generated at 2022-06-11 09:56:37.135325
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    block = Block()
    block.deserialize({'role': {'name': 'test_role'}})
    assert(isinstance(block._role, Role))
    assert(block._role._name == 'test_role')
    parent = Block()
    parent._attributes['name'] = 'test'
    block.deserialize({'parent': {'name': 'test'}, 'parent_type': 'Block'})
    assert(isinstance(block._parent, Block))
    assert(block._parent._attributes['name'] == 'test')
    assert(block._parent._name == 'test')
    task = Task()