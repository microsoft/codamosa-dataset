

# Generated at 2022-06-11 09:47:03.557450
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from data.yml.task_include import test_include_task_include_data
    from data.yml.playbook import test_playbook_play_data
    parent_task_include = TaskInclude.load(test_include_task_include_data, play=Play().load(test_playbook_play_data, variable_manager=VariableManager()))
    parent_task_include.statically_loaded = False
    block = Block(parent_block=parent_task_include, use_handlers=False, implicit='block')
    # test if dep_chain is None
    block._dep_chain = None
    copy_block = block.copy(exclude_parent=False, exclude_tasks=False)
    assert copy_block.get_dep_chain() == None
    # test if dep_chain is not None
    block

# Generated at 2022-06-11 09:47:06.268622
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=True)
    b.set_loader(loader=None)


# Generated at 2022-06-11 09:47:07.614504
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    # TODO: add unit test
    pass


# Generated at 2022-06-11 09:47:09.613262
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.block import Block
    block = Block(None, None, None)
    block.set_loader(None)


# Generated at 2022-06-11 09:47:18.955992
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    task1 = Task()
    task2 = Task()
    block1 = Block()
    block2 = Block()
    task_include1 = TaskInclude()
    task_include2 = TaskInclude()
    task_include3 = TaskInclude()
    task_include4 = TaskInclude()
    block1.block = [task1]
    block2.block = [task2]
    task_include1.block = [block1]
    task_include1.statically_loaded = True
    task_include2.block = [block2]
    task_include2.statically_loaded = False
    task_include3.block = [task_include1]
    task_include3.statically_loaded = True
    task_include4.block = [task_include2]
    task_include4.statically_loaded

# Generated at 2022-06-11 09:47:27.380218
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    #Initializations
    test_data = {'name': 'test'}
    test_block = Block()
    test_block.load_data(test_data)
    test_variable_manager = VariableManager()
    test_loader = DataLoader()
    test_block.set_loader(test_loader)
    test_block.post_validate(test_variable_manager)
    test_block.preprocess_data()
    # Run test
    block_dep_chain = test_block.get_dep_chain()
    # If dep_chain is None, the output will be None, otherwise output will be a list
    assert block_dep_chain is None or isinstance(block_dep_chain, list)

# Generated at 2022-06-11 09:47:32.056973
# Unit test for method serialize of class Block
def test_Block_serialize():
    b = Block()
    b._attributes['block'] = None
    b._attributes['name'] = 'toto'

    assert b.serialize() == {'name': 'toto', 'dep_chain': None, 'vars': dict(), 
                            'when': None, 'always': [], 'rescue': [], 'block': []}


# Generated at 2022-06-11 09:47:42.963951
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block = Block()
    assert block.get_first_parent_include() is None
    block2 = Block()
    block.parent = block2
    assert block.get_first_parent_include() is None
    task_include = TaskInclude()
    block2.parent = task_include
    assert block.get_first_parent_include() is task_include
    block3 = Block()
    block2.parent = block3
    assert block.get_first_parent_include() is task_include
    task_include2 = TaskInclude()
    block3.parent = task_include2
    assert block.get_first_parent_include() is task_include2
    block4 = Block()
    block3.parent = block4
    assert block.get_first_parent_include() is task_include2
    task_include

# Generated at 2022-06-11 09:47:43.951517
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = Block()
    assert True

# Generated at 2022-06-11 09:47:47.040594
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    b = Block()
    b.deserialize({'role': {'name': 'test'}, 'parent': {'foo': 'bar'}, 'parent_type': 'Block'})

    assert(b._role.name == 'test')


# Generated at 2022-06-11 09:49:08.323719
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    '''
    Test if filter_tagged_tasks returns a copy of block with task lists filtered based on the tags
    '''

# Generated at 2022-06-11 09:49:11.541196
# Unit test for method copy of class Block
def test_Block_copy():
   block_instance = Block()
   exclude_tasks = False
   out = block_instance.copy(exclude_tasks)
   assert isinstance(out, Block)
   assert out.__dict__ == block_instance.__dict__



# Generated at 2022-06-11 09:49:17.673838
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Get a path where we can dump test data
    #
    test_dir = os.path.dirname(__file__)
    test_dir = os.path.join(test_dir,'data')

    #
    # Load a playbook yaml file
    #
    data_file = os.path.join(test_dir,'test_Block_has_tasks.yaml')
    print("Testing " + data_file)
    yaml_data = open(data_file,'r')
    data = yaml.safe_load(yaml_data)
    yaml_data.close()
    if data == None:
        print("ERROR - could not read " + data_file)
        sys.exit(1)

    #
    # Create a playbook object and populate the blocks with data
    #
    p = Play()


# Generated at 2022-06-11 09:49:30.429902
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():

    ###################################################################
    # _init_ method test
    ###################################################################

    # init Block by Block()
    obj1 = Block()
    # init Block by Block(parent_block=,)

# Generated at 2022-06-11 09:49:33.059018
# Unit test for method deserialize of class Block
def test_Block_deserialize():
  test_block = Block( )
  test_block.deserialize( )


# Generated at 2022-06-11 09:49:44.561890
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    """
    Unit test for method get_first_parent_include of class Block
    """

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    display.debug("Unit test started for method get_first_parent_include of class Block")
    display.debug("Generating a Block object ...")
    block_obj = Block()
    block_obj.block = [TaskInclude(), Task(), Task(), TaskInclude(), Task()]

# Generated at 2022-06-11 09:49:50.999624
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    locals().update(ImportModule('setup')._wrapped())

    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    original_inventory = Inventory(loader=None, variable_manager=None, host_list=[])
    original_play = Play().load({
        'hosts': 'all',
        'name': 'test',
    }, variable_manager=variable_manager, loader=loader)
    original_play.set_loader(loader)
    original_

# Generated at 2022-06-11 09:49:59.841230
# Unit test for method filter_tagged_tasks of class Block

# Generated at 2022-06-11 09:50:02.047086
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Initialize an object of class Block
    block = Block()

    # Check the behavior of method set_loader of class Block
    block.set_loader(None)

# Generated at 2022-06-11 09:50:03.884157
# Unit test for method copy of class Block
def test_Block_copy():
    block_copy = block.copy()
    import ansible.playbook
    assert isinstance(block_copy, ansible.playbook.base.Base)


# Generated at 2022-06-11 09:50:36.876108
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    
    block = Block('play')
    
    block.block = [
            Task(action='test1'),
            Task(action='test2'),
            Task(action='test3')
        ]
    assert block.has_tasks()
    
    block.block = []
    block.rescue = [
            Task(action='test1'),
            Task(action='test2'),
            Task(action='test3')
        ]
    assert block.has_tasks()
    
    block.rescue = []

# Generated at 2022-06-11 09:50:39.711404
# Unit test for method deserialize of class Block
def test_Block_deserialize():
  block = Block()
  data = block.serialize()
  block.deserialize(data)
  assert block.serialize() == data


# Generated at 2022-06-11 09:50:51.325341
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # ansible.cfg has been moved to /tmp so we need to set the ANSIBLE_CONFIG
    # environment variable.
    os.environ['ANSIBLE_CONFIG'] = '/tmp/ansible.cfg'
    # Inject values into context.CLIARGS of module ansible.cli.CLI.
    context.CLIARGS = ImmutableDict(connection='local', module_path=None,
        forks=5, become=False, become_method=None, become_user=None,
        check=False, diff=False, listhosts=False, listtasks=False,
        listtags=False, syntax=False, subset=None, inventory=None,
        extra_vars=[], vault_password=None, run_hosts=[])

    # Construct mock object for self._play of class Block.
    self

# Generated at 2022-06-11 09:50:57.798468
# Unit test for method deserialize of class Block
def test_Block_deserialize():
  # test that valid Block object
  ds = dict(block=None)
  role = Role()
  role.deserialize(dict())

  # Block.deserialize(ds):
  # deserializing a serialized block
  # eventhough the original block was not an ansible block, it has the attributes
  # that are valid for the serialized Block
  # test that invalid Block object
  ds = dict(block=None, parent='not a valid ansible block')
  role = Role()
  role.deserialize(dict())

  # Block.deserialize(ds):
  # deserializing a serialized block
  # eventhough the original block was not an ansible block, it has the attributes

  # test that valid Block object
  ds = dict(block=None)
  role = Role()
  role

# Generated at 2022-06-11 09:51:02.066984
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    param = {'statically_loaded': True, '_parent': {'statically_loaded': True, '_parent': {'statically_loaded': True, '_parent': {'statically_loaded': True}}}}
    obj = Block(param)
    assert obj.all_parents_static() == True



# Generated at 2022-06-11 09:51:12.002647
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.color import stringc
    from ansible.errors import AnsibleError

# Generated at 2022-06-11 09:51:22.327509
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    import tests.data.ansible_local.ansible_util as ansible_util
    from ansible.playbook.task import Task
    import ansible.playbook
    import pprint

# Generated at 2022-06-11 09:51:24.476817
# Unit test for method copy of class Block
def test_Block_copy():
    test_obj = Block()
    test_obj.load({'block': [{'task': 'test', 'action': 'test'}]})



# Generated at 2022-06-11 09:51:25.569748
# Unit test for method copy of class Block
def test_Block_copy():
    pass


# Generated at 2022-06-11 09:51:34.278458
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    options = None
    loader = DataLoader()
    passwords = dict()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 09:52:28.487147
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Assigning arguments
    loader = mock.MagicMock()

    # From ansible.playbook.task
    task = mock.MagicMock()
    task._loader = None

    # From ansible.playbook.task_include.TaskInclude
    ti = mock.MagicMock()
    ti._task = task
    ti._loader = None

    # From ansible.playbook.task_include.HandlerTaskInclude
    hti = mock.MagicMock()
    hti._task = task
    hti._loader = None

    # From ansible.playbook.task
    task_ = mock.MagicMock()
    task_._loader = None

    # From ansible.playbook.task
    task__ = mock.MagicMock()
    task__._loader = None

    # From ansible.playbook.

# Generated at 2022-06-11 09:52:38.197016
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.play import Play
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.playbook.play_context import PlayContext
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.playbook.handler
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.inventory.inventory
    import ansible.template.template
    import ansible.vars.manager
    import ansible.parsing.yaml.objects
    import ansible.errors
    import ansible.utils.vars
    import ansible.parsing.dataloader

    # Initialise a new Play object
    play_obj = Play()

    # Initialise a new Host object
    host_obj = ansible

# Generated at 2022-06-11 09:52:49.154054
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block = Block()
    block._parent = Block()
    assert block.get_dep_chain() == None
    assert block._dep_chain == None

    block._parent = Block()
    block._parent._parent = Block()
    assert block.get_dep_chain() == None
    assert block._dep_chain == None

    block._dep_chain = []
    block._parent = Block()
    block._parent._parent = Block()
    assert block.get_dep_chain() == []
    assert block._dep_chain == []

    block._dep_chain = [{1,2}, {3,4}]
    block._parent = Block()
    block._parent._parent = Block()
    assert block.get_dep_chain() == [{1,2}, {3,4}]

# Generated at 2022-06-11 09:52:59.259678
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    global fake_data
    fake_data = {
        "hosts": "all",
        "block": [
            {
                "block": [
                    {
                        "include": "test",
                        "hosts": "{{ xyz }}",
                        "roles": [
                            {
                                "role": "test"
                            }
                        ]
                    }
                ],
                "roles": [
                    {
                        "role": "test"
                    }
                ]
            }
        ]
    }
    data_loader()
    try:
        from ansible.playbook.block import Block as block_obj
        block_obj.load(fake_data)
        block_obj.get_first_parent_include()
    except Exception as exception:
        assert ()


# Generated at 2022-06-11 09:53:02.341390
# Unit test for method copy of class Block
def test_Block_copy():
    '''
    Unit test for method copy of class Block
    '''
    block = Block()
    block.always = [Mock()]
    block.block = [Mock()]
    block.rescue = [Mock()]
    block.copy()



# Generated at 2022-06-11 09:53:11.357039
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    import copy
    # create a block that has no tasks and we only have skip-tags filtered out
    block1 = Block.load({'block': []})
    task1 = dict(action='action_name', tags='x')
    task1 = Task.load(task1, play=None, block=block1, task_include=None, variable_manager=None, loader=None)
    block1.block = [task1]
    all_vars = dict(role_name="test")
    filtered_block = block1.filter_tagged_tasks(all_vars)
    task_list = filtered_block.block
    assert len(task_list) == 0, \
        "filter_tagged_tasks should return task_list with 0 tasks because we only have skip-tags filtered out"
    # create a block that has no

# Generated at 2022-06-11 09:53:19.344407
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    b = Block()
    b.statically_loaded = True
    b._attributes['name'] = "this is a block"
    b._attributes['block'] = []
    t = TaskInclude()
    t.statically_loaded = True
    t._attributes['name'] = "this is a task include"
    b._attributes['parent'] = t
    assert b.all_parents_static()

    b = Block()
    b.statically_loaded = False
    b._attributes['name'] = "this is a block"
    b._attributes['block'] = []
    t = TaskInclude()
    t.statically_loaded = True

# Generated at 2022-06-11 09:53:20.706361
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    assert True == False, "Test not implemented"


# Generated at 2022-06-11 09:53:30.844644
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.yaml_dict import YamlDict
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)

    task = Task()
    task.action = 'debug'
    task.args['msg'] = 'all'
    block = Block()
    block.block = [task]
    all_vars = combine_vars(loader, variable_manager, inventory)
    filtered_block = block.filter_tagged_tasks(all_vars)


# Generated at 2022-06-11 09:53:40.181712
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.group import Group
    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group as InGroup
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import Reserved
    from ansible.parsing import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    loader = DataLoader()

# Generated at 2022-06-11 09:54:37.651898
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # create a temporary file
    with tempfile.NamedTemporaryFile() as temp:
        temp.write(b'---\n- hosts: localhost\n  tasks:\n  - block:\n    - debug: var=foo\n')
        temp.flush()
        # load PlaybookFile and Task
        pb_loader = Playbook.PlaybookFileLoader(temp.name, variable_manager=VariableManager(), loader=DictDataLoader())
        pb = pb_loader.load()
        task_list = pb._entries[0].get_tasks()
        task = task_list[1]
        # test
        test_dep_chain = task.get_dep_chain()
        assert isinstance(test_dep_chain, list)

# Generated at 2022-06-11 09:54:46.598236
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    import ansible.playbook.play_context
    import ansible.playbook.role
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.task_include
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.inventory.inventory
    import ansible.vars.manager
    import ansible.vars.option_validator
    import ansible.module_utils.six
    import ansible.module_utils.basic
    import ansible.playbook.play
    import ansible.template
    import ansible.parsing.dataloader
    import ansible.errors
    import ansible.inventory.dir
    import collections

    play_context = ansible.playbook.play_context.PlayContext()

# Generated at 2022-06-11 09:54:55.819430
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    import copy
    import json

# Generated at 2022-06-11 09:54:57.847319
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.block import Block
    b = Block()
    assert b.get_dep_chain() is None


# Generated at 2022-06-11 09:54:58.572337
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    pass

# Generated at 2022-06-11 09:55:07.254607
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():

    #Create a Block object having statically_loaded = True
    b1 = Block(statically_loaded=True)
    #Create a Block object having statically_loaded = False
    b2 = Block(statically_loaded=False)
    #Create a Block object having statically_loaded = None
    b3 = Block(statically_loaded=None)

    #Add created block objects to a list
    block_list = [b1,b2,b3]

    #Test each element one by one
    for i in block_list:
        #First element has statically_loaded as True, hence check passes
        if i == b1:
            assert i.all_parents_static()
        #Second element has statically_loaded as False, hence check fails
        elif i == b2:
            assert not i.all_parents_static()
        #Third element

# Generated at 2022-06-11 09:55:16.056337
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create an Block
    block = Block()

# Generated at 2022-06-11 09:55:26.527145
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    import pytest
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    fake_loader = None
    fake_variable_manager = None
    fake_play = None
    fake_task = Block(
        play=fake_play,
        parent_block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        implicit=False)
    fake_first_parent_include = TaskInclude(
        play=fake_play,
        block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        loop=None,
        loop_args=None)

# Generated at 2022-06-11 09:55:29.291474
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    copy = block.copy(exclude_parent=True, exclude_tasks=True)
    assert copy._attributes == block._attributes

# Generated at 2022-06-11 09:55:39.587678
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a block to test filtering
    b = Block()
    b._attributes['tags'] = ["t1"]
    b.validate()

    t = Task()
    t._attributes['action'] = "test1"
    t._attributes['tags'] = ["t2"]
    t.validate()

    b2 = Block()
    b2._attributes['tags'] = ["t3"]
    b2.validate()

    # Block b will have 2 children: task t and block b2
    b.block = [t, b2]

    # Only task t should be filtered out
    fb = b.filter_tagged_tasks({})
    assert len(fb.block) == 1
    assert isinstance(fb.block[0], Block)

    # Block b should not be filtered out and should have task

# Generated at 2022-06-11 09:56:37.716978
# Unit test for method filter_tagged_tasks of class Block