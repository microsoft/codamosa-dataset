

# Generated at 2022-06-11 09:47:19.791338
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    run()
    block = Block(play=None, parent_block=None, role=None, task_include=None, implicit=False)
    block.block = [1,2,3]
    assert block.has_tasks()

    block.block = []
    block.rescue = [1,2,3]
    assert block.has_tasks()

    block.rescue = []
    block.always = [1,2,3]
    assert block.has_tasks()

    block.always = []
    assert block.has_tasks() == False

# Generated at 2022-06-11 09:47:29.380249
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook import Play, Playbook
    from ansible.inventory.manager import InventoryManager
    import os
    import tempfile

    hosts = 'localhost'
    connection = 'local'

# Generated at 2022-06-11 09:47:36.036202
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleMapping
    block1 = Block()
    block1.set_loader(None)

# Generated at 2022-06-11 09:47:45.517551
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.errors import AnsibleParserError
    from ansible.playbook.task import Task

    block = Block(
        loader=None,
        play=None,
        parent_block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        implicit=False,
    )
    block._attributes['name'] = 'test_block'

    task_1 = Task(
        loader=None,
        play=None,
        parent_block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        implicit=False,
    )
    task_1._attributes['name'] = 'test_task_1'
    task_1._attributes['tags'] = ['a', 'b']

# Generated at 2022-06-11 09:47:54.668786
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    global C
    C = object()
    C._PLAY_ROLE_NAMES = set()
    def __init__(self):
        self._attributes = {}
        self._block = None
        self._rescue = None
        self._always = None
        self._play = None
        self._role = None
        self._dep_chain = None
        self._parent = None
        self._task_include = None
        self._use_handlers = None
        self._registered_attrs = set()
        self._deprecated_attrs = set()
        self._invalid_attrs = set()
        self._valid_attrs = self.VALID_ATTRIBUTES
        self._implicit_block = False
        self._implicit_dep_chain = None


# Generated at 2022-06-11 09:48:03.837606
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.plugins import action_loader
    from ansible.utils.boolean import boolean
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.loader import AnsibleLoader
    import os
    import json
    import ast


# Generated at 2022-06-11 09:48:13.548520
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    play = Play().load(dict(
            name = "foobar",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='setup', args='')),
            ]
        ),
        loader=loader,
        variable_manager=None,
        loader_cache=None
    )
    play._variable_manager = VariableManager()
    play._variable_manager.extra_vars = dict(
        ansible_ssh_user='appdeploy',
        ansible_ssh_pass='secret',
    )

# Generated at 2022-06-11 09:48:19.825074
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    options = [
        ('/home/stack/configuration.yml', 'test_playbook_path'),
    ]

    for path, playbook_path in options:
        with patch('ansible.playbook.block.Block._set_loader') as mock_set_loader:
            mock_set_loader.return_value = None

            b = Block()
            b.set_loader(path)



# Generated at 2022-06-11 09:48:29.604959
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    host = Host("localhost")
    block1 = Block(parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    assert block1.all_parents_static() == True

    block2 = Block(parent_block=block1, role=None, task_include=None, use_handlers=False, implicit=False)
    assert block2.all_parents_static() == True

    block3 = Block(parent_block=block2, role=None, task_include=None, use_handlers=False, implicit=False)
    assert block3.all_parents_static() == True

    block1._parent = block3
    assert block1.all_parents_static() == False
    assert block2.all_parents_static() == False
    assert block3.all_parents

# Generated at 2022-06-11 09:48:32.374001
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    b = Block()
    b.deserialize({'role': {'name': 'test.yml'}})
    assert isinstance(b._role, Role)
    assert b._role.name == 'test.yml'


# Generated at 2022-06-11 09:49:22.013151
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    ast = parse_ast("""
    """)
    method = Block.deserialize

# Generated at 2022-06-11 09:49:24.661681
# Unit test for method is_block of class Block
def test_Block_is_block():
    block = Block()
    assert block.is_block(dict()) == True
    assert block.is_block(list()) == False

# Generated at 2022-06-11 09:49:39.498605
# Unit test for method copy of class Block
def test_Block_copy():
    firstBlock = Block()
    firstBlock.always = []
    firstBlock.block = []
    firstBlock.rescue = []
    firstBlock.when = ''
    firstBlock.failed_when = ''
    firstBlock.changed_when = ''
    firstBlock.deprecated_tags = []
    firstBlock.tags = []
    firstBlock.notify = []
    firstBlock.environment = ''
    firstBlock.name = ''
    firstBlock.loop = ''
    firstBlock.delegate_to = ''
    firstBlock.transport = ''
    firstBlock.tags = []
    firstBlock.when = ''
    firstBlock.notify = []
    firstBlock.delegate_facts = ''
    firstBlock.register = ''
    newBlock = firstBlock.copy()
    assert isinstance(newBlock, Block)

# Generated at 2022-06-11 09:49:48.168917
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    data = {
        "block": [{"action": "set_fact", "args": {"var": "ansible_check_mode", "value": "True"}}, {"action": "debug", "args": {"msg": "Hello World"}}]
    }
    
    b = Block(play=None, parent_block=None, use_handlers=False, implicit=False)
    b.load_data(data)
    
    assert b.get_dep_chain() == []

    data2 = {"include": {"tasks": "tasks/main.yml", "vars": "tasks/vars.yml"}}
    data3 = {"include": "tasks/main.yml"}

    b2 = Block(play=None, parent_block=None, use_handlers=False, implicit=False)
    b2

# Generated at 2022-06-11 09:49:56.788719
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    
    block=Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    task1=Task()
    task1.set_loader(DictDataLoader({}))
    task1.action="include_vars"
    task1.args = dict(file='a.yml')
    task1.loop = '1'
    task1.loop_args = dict(name="test")
    task1._parent = block

# Generated at 2022-06-11 09:49:58.722442
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b.block = []
    b.rescue = []
    b.always = []
    return b

# Generated at 2022-06-11 09:50:06.672651
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.helpers import load_list_of_tasks
    from ansible.playbook.block import Block
    example_play_script = {'block':[]}
    example_play = Play()
    example_play.vars = dict()
    example_play.extra_vars = dict()
    example_play.hosts = []
    example_play.roles = []
    example_play.handlers = [Handler()]
    example_play.task_includes = []
    example_play_roles =[Role()]
    example_play.dep_chain = []

# Generated at 2022-06-11 09:50:16.221447
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    b = Block()
    data = {
        "_attributes": {"_bogus_variable": "BOGUS"},
        "dep_chain": [{"_role": {}, "_attributes": {"_bogus_variable": "BOGUS"}}],
        "parent": {"_attributes": {}, "parent_type": "Block"},
        "role": {"_attributes": {}}
    }
    b.deserialize(data)
    assert b._attributes.get('_bogus_variable') == "BOGUS"
    assert b._dep_chain[0]._role == {}
    assert b._dep_chain[0]._attributes.get('_bogus_variable') == "BOGUS"
    assert b._parent
    assert b._role


# Generated at 2022-06-11 09:50:19.764308
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=True)
    assert block.deserialize(None) == None



# Generated at 2022-06-11 09:50:20.791385
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    assert False, "Test not implemented"

# Generated at 2022-06-11 09:50:33.482905
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    pass


# Generated at 2022-06-11 09:50:43.895445
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    class PlaybookMock(object):
        def __init__(self):
            self.only_tags = []
            self.skip_tags = []

    class BlockMock(object):
        def __init__(self, parent=None):
            self.parent = parent
            self.block = []
            self.always = []
            self.rescue = []
            self.tags = []
            self.action = 'whatever'
            self._play = PlaybookMock()
            self._parent = parent

        def copy(self, exclude_parent=False, exclude_tasks=False):
            return self

    class TaskMock(object):
        def __init__(self, tags=[]):
            self.tags = tags


# Generated at 2022-06-11 09:50:54.372934
# Unit test for method deserialize of class Block
def test_Block_deserialize():

    # Test deserializing a Block that wasn't serialized
    block = Block()
    serialized = block.serialize()
    deserialized = Block()
    deserialized.deserialize(serialized)
    assert serialized == deserialized.serialize()

    # Test deserializing a Block with a role

# Generated at 2022-06-11 09:51:00.769941
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display
    play_context = PlayContext()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='./test_inventory.yml')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    display = Display()

# Generated at 2022-06-11 09:51:08.516211
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    import ansible.constants as C
    b = Block(block=["block"], rescue=["rescue"], always=["always"])

    action = Mock()
    action.action = C._ACTION_META
    action.implicit = False
    action.evaluate_tags = Mock()
    action.evaluate_tags.return_value = False
    
    b.block = [ action ]
    b.filter_tagged_tasks(False)
    assert len(b.block) == 0

# This tests the case when there is a task that goes through filter_tagged_tasks.

# Generated at 2022-06-11 09:51:18.969950
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.playbook.role import Role
    b = Block()
    assert b.deserialize({}) is None
    assert b.deserialize(dict(foo='bar')) is None
    assert b.foo == 'bar'
    assert b.deserialize(dict(foo='bar2')) is None
    assert b.foo == 'bar2'
    assert b.deserialize(dict(role=dict())) is None
    assert b.role is not None and isinstance(b.role, Role)
    assert b.deserialize(dict(role=dict())) is None
    assert b.role is not None and isinstance(b.role, Role)
    assert b.deserialize(dict(parent=dict())) is None
    assert b.parent is not None and isinstance(b.parent, Block)


# Generated at 2022-06-11 09:51:23.626173
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # First create a simple block
    b = Block(parent_block=None)

    # The block created above should be simple and return True for
    # all_parents_static
    if not b.all_parents_static():
        raise AssertionError('all_parents_static() must return True for a simple Block object')

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.base import Base
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role_include import RoleInclude
    # Create a task in the block created above.
    t = Base()

# Generated at 2022-06-11 09:51:32.047725
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    '''
    Unit test for method filter_tagged_tasks of class Block
    '''

    # Create an instance of class Block
    mock_block_obj = Block()

    # Returns a new block, with task lists filtered based on the tags
    # Returns a new block, with task lists filtered based on the tags
    mock_block_obj.filter_tagged_tasks(all_vars={})

    # Returns True if this block has tasks, or False otherwise
    mock_block_obj.has_tasks()

    # Returns a dictionary containing any parameters passed to an include statement
    mock_block_obj.get_include_params()

    # Determine if all of the parents of this block were statically loaded
    mock_block_obj.all_parents_static()

    # Return the first TaskInclude or HandlerTaskInclude parent of the given

# Generated at 2022-06-11 09:51:43.320767
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # block attribute is not assigned yet
    b = Block()
    assert b.has_tasks() == False
    
    # block is assigned a value but it has no tasks
    b = Block()
    b.block = []
    assert b.has_tasks() == False
    
    # always is assigned a value but it has no tasks
    b = Block()
    b.always = []
    assert b.has_tasks() == False
    
    # rescue is assigned a value but it has no tasks
    b = Block()
    b.rescue = []
    assert b.has_tasks() == False
    
    # block attribute is assigned a value and it has tasks
    b = Block()
    b.block = [1, 2]
    assert b.has_tasks() == True
    
    # block is empty

# Generated at 2022-06-11 09:51:48.784603
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block = {
    "block": [
        "t1",
        {
            "rescue": [
                "t2"
            ]
        }
    ]
}
    try:
        Block.load(block)
        raise Exception("Exception is not raised")
    except AnsibleParserError as e:
        print(e)
    except Exception as e:
        raise e
if __name__ == '__main__':
    test_Block_all_parents_static()

# Generated at 2022-06-11 09:52:11.342410
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    '''test_Block_filter_tagged_tasks'''
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    # mock PlayContext in C._play_context
    C._play_context = PlayContext()
    # mock Task._attributes in C._attributes
    C._attributes = dict()
    assert Block.filter_tagged_tasks([]) == None, 'Block.filter_tagged_tasks() call failed'

if __name__ == '__main__':
    from pytest import main
    main(['-x', __file__])

# Generated at 2022-06-11 09:52:21.084290
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Initialize test objects
    role = Role()
    task = Task()
    play = Play()
    role_include = RoleInclude()
    task_include = TaskInclude()
    handler_task_include = HandlerTaskInclude()
    block = Block()

    # Set a loader and test
    block.set_loader(play)
    assert block._loader == play

    # Set a parent and test
    block

# Generated at 2022-06-11 09:52:28.525460
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    '''
    Unit test for method all_parents_static of class Block
    '''

    block_1 = Block()
    block_2 = Block()
    block_3 = Block()

    block_1._parent = block_2
    block_2._parent = block_3

    assert block_1.all_parents_static() == True
    assert block_2.all_parents_static() == True
    assert block_3.all_parents_static() == True

    block_1.statically_loaded = False

    assert block_1.all_parents_static() == False
    assert block_2.all_parents_static() == True
    assert block_3.all_parents_static() == True


# Generated at 2022-06-11 09:52:31.929959
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    class MockBlock(Block):
        def __init__(self, name):
            self.block = name

    sut = Block.filter_tagged_tasks(MockBlock('foo'), [])
    assert sut.block == MockBlock('foo')

# Generated at 2022-06-11 09:52:41.623886
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    play_context = PlayContext()
    role = Role()
    parent = Block(role=role)
    parent.statically_loaded = True
    block = Block(play=play_context, parent_block=parent, role=role, task_include=TaskInclude())
    block.statically_loaded = True
    task = Task()
    task._parent = block
    assert not task.all_parents_static()

test_Block_all_parents_static()

# Generated at 2022-06-11 09:52:52.408508
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    import copy
    import json
    import pprint
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # The data to be loaded, same as the YAML playbook

# Generated at 2022-06-11 09:52:53.204254
# Unit test for method copy of class Block
def test_Block_copy():
    pass

# Generated at 2022-06-11 09:53:02.130634
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block = Block()

    try:
        block.get_first_parent_include()
        assert False
    except:
        assert True

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    block.parent = TaskInclude()
    assert block.get_first_parent_include() == block.parent

    block.parent = Task()
    block.parent.parent = TaskInclude()
    assert block.get_first_parent_include() == block.parent.parent

    block.parent.parent = Task()
    block.parent.parent.parent = TaskInclude()
    assert block.get_first_parent_include() == block.parent.parent.parent

    block.parent.parent.parent = Task()
    block.parent.parent.parent.parent = TaskInclude

# Generated at 2022-06-11 09:53:11.125088
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager))
    name = 'name'
    task_tags = 'tags'
    either_required = 'either'
    tag_list = 'taglist'
    ds = dict(
        name=name,
        tags=task_tags,
        either=either_required,
        taglist=tag_list
    )
    task = Task()
    task.load(ds, variable_manager=variable_manager, loader=loader)
    assert task.name == name
    assert task.tags == task_tags
    assert task.either_required == either_required
    assert task.tag_list == tag_list

    dep_

# Generated at 2022-06-11 09:53:15.394268
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    defaults = ['test']
    data = dict(test = dict(default = defaults))

    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    data = dict(default = defaults)

    block = Block()
    block.deserialize(data)
    assert block.default == defaults


# Generated at 2022-06-11 09:53:27.051795
# Unit test for method copy of class Block
def test_Block_copy():
    Block()
    pass


# Generated at 2022-06-11 09:53:28.951740
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block = create_block(None)
    assert block.all_parents_static() == True


# Generated at 2022-06-11 09:53:38.709545
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play import Play

    def test_data_1():
        return {
            'hosts': 'all',
            'tasks': [
                {'name': 'foo', 'action': {'module': 'shell', 'args': 'foo'}, 'tags': [], 'when': 'True'},
                {'block': [
                    {'rescue': [
                        {'name': 'bar', 'action': {'module': 'shell', 'args': 'bar'}, 'tags': [], 'when': 'True'}
                    ]}
                ]},
            ],
        }


# Generated at 2022-06-11 09:53:39.923274
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader()

# Generated at 2022-06-11 09:53:49.151362
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    #

    # Read in the data structure representing the block
    import yaml
    with open("../playbooks/test-playbook-block.yml") as file_in:
        data = yaml.load(file_in, Loader=yaml.FullLoader)
    # Create a Block object with data structure
    task_implicit = Task()
    task_implicit.load_data(data['tasks'][0])
    task_include = Task()
    task_include.load_data(data['tasks'][1])
    task_include2 = Task()
    task_include2.load_data(data['tasks'][2])
    task_block = Task()
    task_block.load_data(data['tasks'][3])
    task_block2 = Task()
    task_block2.load

# Generated at 2022-06-11 09:53:50.110734
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
  raise NotImplementedError()


# Generated at 2022-06-11 09:53:58.634102
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    args = dict(
        loader=MagicMock(),
        play=MagicMock(),
        role=MagicMock(),
        block=MagicMock(),
        parent_block=MagicMock(),
        task_include=MagicMock(),
        use_handlers=MagicMock(),
        implicit=MagicMock(),
        variable_manager=MagicMock(),
    )
    b = Block(**args)
    # Test correct loader used
    expected = args['loader']
    actual = b._loader
    assert expected == actual
    # Test loader used in all sub-objects
    args['play'].set_loader.assert_called_once_with(expected)
    args['role'].set_loader.assert_called_once_with(expected)

# Generated at 2022-06-11 09:54:02.560973
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # set up
    obj = Block()
    obj.block = ["list[0]", "list[1]", "list[2]"]
    obj.rescue = []
    obj.always = []

    # test
    result = obj.has_tasks()

    # assert
    assert result == True
    del obj


# Generated at 2022-06-11 09:54:11.386168
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():

    def test_Block__parent_None_and_Dep_chain_None():
        b = Block()
        b._parent = None
        b._dep_chain = None
        assert_equal(b.get_dep_chain(), None)

    def test_Block__parent_not_None_and_Dep_chain_None():
        b = Block()
        b._parent = 5
        b._dep_chain = None
        assert_equal(b.get_dep_chain(), 5)

    def test_Block__parent_None_and_Dep_chain_not_None():
        b = Block()
        b._parent = None
        b._dep_chain = 6
        assert_equal(b.get_dep_chain(), 6)


# Generated at 2022-06-11 09:54:20.856329
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
  # block.py:2056:
  b = Block()
  assert b.get_dep_chain() == None

  # block.py:2060:
  b = Block()
  b._parent = TaskInclude(name="include_tasks.yml")
  b._parent._parent = Play()
  assert b.get_dep_chain() == None

  # block.py:2068:
  b = Block()
  b._parent = Block()
  b._parent._parent = TaskInclude(name="include_tasks.yml")
  b._parent._parent._parent = Play()
  assert b.get_dep_chain() == None

  # block.py:2071:
  b = Block()
  b._parent = Block()

# Generated at 2022-06-11 09:54:54.869137
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
  from play import Play
  from block import Block
  from task import Task
  from ansible.vars import VariableManager
  from ansible.inventory import Inventory

  block1 = Block(parent=None)
  block2 = Block(parent=block1)
  task1 = Task(parent=block1)
  task2 = Task(parent=block2)
  block1.block= [task1, block2]

  # play without tags
  # all tasks should be included in the new block
  play = Play()
  all_vars = VariableManager()
  all_vars.add_host(Inventory("localhost"))
  all_vars.set_host_variable("localhost", "foo", "bar")
  block3 = block1.filter_tagged_tasks(all_vars)

# Generated at 2022-06-11 09:55:03.843727
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    inventory = Inventory(
        host_list = [
            "host.example.com",
            "192.168.1.100"
        ]
    )

    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    loader = DataLoader()

    # block without tags

# Generated at 2022-06-11 09:55:06.012601
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block()
    my_loader = 'loader'
    b.set_loader(my_loader)
    assert b._loader == my_loader


# Generated at 2022-06-11 09:55:14.924992
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = Block.load(
        {
            'block': [
                {
                    'action': 'shell',
                    'tags': ['always'],
                    'args': 'uptime'
                }
            ],
            'rescue': [
                {
                    'action': 'shell',
                    'tags': ['always'],
                    'args': 'uptime'
                }
            ],
            'always': [
                {
                    'action': 'shell',
                    'tags': ['always'],
                    'args': 'uptime'
                }
            ]
        },
        task_include=None,
        use_handlers=False,
        variable_manager=None,
        loader=None
    )
    class FakePlay():
        def __init__(self, only_tags, skip_tags):
            self.only_

# Generated at 2022-06-11 09:55:25.063768
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    new_block = Block()
    new_block.block = [1, 2, 3]
    new_block.rescue = [4, 5, 6]
    new_block.always = [7, 8, 9]
    cur_block = new_block.filter_tagged_tasks([])
    assert_equal(cur_block.block, [1, 2, 3])
    assert_equal(cur_block.rescue, [4, 5, 6])
    assert_equal(cur_block.always, [7, 8, 9])

    play1 = Play()
    play1.only_tags = set

# Generated at 2022-06-11 09:55:35.632220
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    v = VarsModule()
    v.set_variable("var2", "FOO")
    v.set_variable("ansible_version", "2.9.9")
    v.set_variable("ansible_distribution", "CentOS")
    v.set_variable("ansible_distribution_release", "7")
    v.set_variable("ansible_distribution_version", "7")
    v.set_variable("ansible_os_family", "RedHat")
    v.set_variable("ansible_pkg_mgr", "yum")

    b = Block(play=Play(), parent_block=None, role=None, task_include=None, use_handlers=False, implicit=True)
    b._attributes['tags'] = ['foo']

# Generated at 2022-06-11 09:55:45.447770
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    block = Block()
    assert block.all_parents_static() == True
    task = Task()
    block._parent = task
    assert block.all_parents_static() == True
    task = Task(use_handlers=True)
    block._parent = task
    assert block.all_parents_static() == True
    task = Task()
    task._parent = task
    block._parent = task
    assert block.all_parents_static() == True
    block = Block()
    task = Task()
    block._parent = task
    task._parent = block
    assert block.all_parents_static()

# Generated at 2022-06-11 09:55:54.011107
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    # Case when Block has no parent
    block = Block()
    assert block.get_first_parent_include() is None

    # Case when first parent is not an instance of TaskInclude
    task = Task()
    block = Block(parent=task)
    assert block.get_first_parent_include() is None

    # Case when first parent is an instance of TaskInclude
    task_include = TaskInclude()
    block = Block(parent=task_include)
    assert block.get_first_parent_include() == task_include

    # Case when first parent is NOT an instance of TaskInclude, but 2nd-level parent is
    assert not hasattr(task_include, "_parent")
    assert not hasattr(task, "_parent")
    task_include._parent = task
    assert block.get_first_parent_include()

# Generated at 2022-06-11 09:56:03.008667
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    import ansible.playbook
    import ansible.playbook.task
    import ansible.playbook.task_include
    reload(ansible.playbook.task)
    reload(ansible.playbook.task_include)
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    block = Block()
    tasks = [Task()]
    tasks[0].tags = ['tag1', 'tag2', 'tag3']
    block.block = tasks
    p = Play()


# Generated at 2022-06-11 09:56:03.915978
# Unit test for method copy of class Block
def test_Block_copy():
  pass
