

# Generated at 2022-06-11 09:47:20.993498
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b.block = [{'name': 'test1'}, {'name': 'test2'}]
    b2 = b.copy()
    assert b2.block == b.block

# Generated at 2022-06-11 09:47:30.084886
# Unit test for method copy of class Block
def test_Block_copy():
    a = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False, statically_loaded=True)
    a.block = None
    a.rescue = None
    a.always = None
    a.statically_loaded = False
    a.dep_chain = None
    a._parent = None
    a._role = None
    b = a.copy(exclude_parent=False, exclude_tasks=False)
    assert b.block is None
    assert b.rescue is None
    assert b.always is None
    assert b.statically_loaded is False
    assert b.dep_chain is None
    assert b._parent is None
    assert b._role is None
    return

# Generated at 2022-06-11 09:47:30.726186
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    pass

# Generated at 2022-06-11 09:47:41.587433
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # setup
    filename = "/home/ansible/playbooks/playbook.yml"
    name = "task"
    action_str = "shell"
    args = "ls"
    block = Block(filename, name)
    assert not block.has_tasks()

    # action: create a new task and append to block.block
    task = Task(filename, name, action_str, args)
    block.block.append(task)
    assert block.has_tasks()

    # action: create a new task and append to block.rescue
    task = Task(filename, name, action_str, args)
    block.rescue.append(task)
    assert block.has_tasks()

    # action: create a new task and append to block.always

# Generated at 2022-06-11 09:47:45.115132
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    # Expected value
    expected = None
    # Actual value
    serialized_data = {'whatever' : "test"}
    block.deserialize(serialized_data)
    actual = block._attributes
    assert actual == expected

# Generated at 2022-06-11 09:47:51.073173
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():

    task_block = Block(
        parent_block=dict(
            task_include=dict(
                include=dict(
                    name=dict(
                        name=dict(
                            include=dict(
                                name=None,
                                static=True
                            )
                        )
                    )
                )
            )
        ),
        use_handlers=False
    )

    print(task_block.get_first_parent_include())

test_Block_get_first_parent_include()

# Generated at 2022-06-11 09:47:56.409110
# Unit test for method copy of class Block
def test_Block_copy():
    playbook = Playbook.load('tests/test_playbook_include.yml')
    play = playbook.get_plays()[0]

    block = play.compile()
    # Create a object of class Block
    obj = AnsibleObject()
    # call method copy of class Block
    result = obj.copy()
    # check the result if it is not none
    assert result is not None
test_Block_copy()


# Generated at 2022-06-11 09:47:58.404099
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block()
    b._loader=None
    b.set_loader(1)
    assert b._loader==1

# Generated at 2022-06-11 09:48:07.465562
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    from ansible.playbook import Play

    play_data = {
        'name': 'test play',
        'hosts': 'all',
        'tasks': [
            {'name': 'test task', 'action': 'ping'}
        ]
    }
    play = Play().load(play_data, variable_manager=variable_manager, loader=loader)
    play.validate()
    assert(play.has_tasks())
    assert(play.tasks[0].has_tasks())

    play_data = {
        'name': 'test play',
        'hosts': 'all',
    }
    play = Play().load(play_data, variable_manager=variable_manager, loader=loader)
    play.validate()
    assert(not play.has_tasks())

# unit test for

# Generated at 2022-06-11 09:48:10.746188
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block(
        tasks=[],
        rescue=[],
        always=[]
    )
    ret = block.deserialize(
        data = {}
    )
    assert ret is None

# Generated at 2022-06-11 09:48:50.167355
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():

    # prep object(s)
    # define parent
    p = TaskInclude()
    pp = TaskInclude()
    ppp = Block()
    p.load_data("testtask1.yml")
    pp.load_data("testtask2.yml")
    ppp.load_data("testblock.yml")
    # define child
    c = Block()
    c.load_data("testblock.yml")

    # build parent hierachy
    # task - task - block (True)
    p.set_loader(DictDataLoader())
    ppp.set_parent(pp)
    pp.set_parent(p)
    c.set_parent(ppp)

    assert c.all_parents_static()
    assert ppp.all_parents_static()
    assert pp.all_parents

# Generated at 2022-06-11 09:48:54.056523
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    '''
    Unit test for method set_loader of class Block
    '''
    T = Task()
    B = Block()
    assert B._loader == None
    B.set_loader(T)
    assert B._loader == T

# Generated at 2022-06-11 09:49:05.292500
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Setup the task
    t = Task()

    # Setup the task include
    ti = TaskInclude()
    ti.name = "tasks/main.yml"
    ti.tasks = [t]

    # Setup the block
    b = Block()
    b.name = "Task Block"
    b.block = [ti]

    # Setup the play
    p = Play()
    p.hosts = ['hostname']
    p.tasks = [b]

    # Setup the play book
    pb = PlayBook()
    pb.playbook = [p]

    # Setup the Ansible runner
    ar = AnsibleRunner(pb)

    # Make sure filter_tagged_tasks works correctly

# Generated at 2022-06-11 09:49:10.611591
# Unit test for method copy of class Block
def test_Block_copy():
    data =  { 'always': [ { 'debug': { 'msg': 'hello world' } } ],
              'block': [ { 'debug': { 'msg': 'bar' } }],
              'rescue': [ { 'debug': { 'msg': 'foo' } }]}
    root = Block.load(data)
    assert root.copy().serialize() == root.serialize()

# Generated at 2022-06-11 09:49:14.027005
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    t1 = AnsibleTask()
    t2 = AnsibleTask()
    t3 = AnsibleTask()
    b1 = Block(block=[t1,t2,t3])
    b1.filter_tagged_tasks({})
    #TODO put some test for this method


# Generated at 2022-06-11 09:49:23.954485
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    o = Block()


# Generated at 2022-06-11 09:49:29.989796
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    b = Block()
    assert b.has_tasks() == False
    b.block = [{"action": "test"}, {"action": "test"}, {"action": "test"}]
    assert b.has_tasks() == True
    assert isinstance(b, Block) == True



# Generated at 2022-06-11 09:49:32.059290
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    o = Block()
    o.deserialize('')


# Generated at 2022-06-11 09:49:43.781813
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

    # without a loader, it's not possible to deserialize
    try:
        block.deserialize(dict())
        assert False
    except AssertionError:
        pass

    # but with a loader, it should work
    block.set_loader(DictDataLoader({}))
    block.deserialize(dict(block=[[dict(action='setup')]], rescue=[], always=[]))

    # deserialize a simple block
    block = Block()
    block.set_loader(DictDataLoader({}))
    block.deserialize(dict(block=[[dict(action='setup')]], rescue=[], always=[]))
    assert len(block.block) == 1
    assert block.block[0].action == 'setup'

    # deserialize a block with rescue
    block

# Generated at 2022-06-11 09:49:49.319534
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    block = Block(
        name = "myname",
        block = [
            Task(name="C1", action="action1"),
            Task(name="C2", action="action2")
        ],
        rescue = [
            Task(name="R1", action="action3")
        ],
        always = [
            Task(name="A1", action="action4")
        ],
    )
    assert block.has_tasks()


# Generated at 2022-06-11 09:50:12.869333
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    test_play = Play(
        name='test',
        hosts='all',
        gather_facts='no',
        vars_prompt=dict(),
        vars={'test_var': 'test_value'},
        roles_path=['/etc/ansible/roles']
    )
    test_context = PlayContext(play=test_play, options=dict(tags=[]))
    test_play._variable_manager = VariableManager()
    test_play._variable_manager.extra_vars = dict(test_var='test_value')
    test_play._variable_manager.set_play_context(test_context)
    test_play.post_validate()


# Generated at 2022-06-11 09:50:18.940989
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block()
    assert b.has_tasks() == False
    b.block = []
    assert b.has_tasks() == False
    b.rescue = []
    assert b.has_tasks() == False
    b.always = []
    assert b.has_tasks() == False

    t1 = Task()
    b.block = [t1]
    assert b.has_tasks() == True


# Generated at 2022-06-11 09:50:26.650282
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b._parent = Block()
    b.block = [1,2,3]
    b.rescue = [4,5,6]
    b.always = [7,8,9]
    assert_raises(AttributeError, b.copy, exclude_tasks=True)
    assert_raises(AttributeError, b.copy, exclude_tasks=False)
    assert_raises(AttributeError, b.copy, exclude_parent=True)
    assert_raises(AttributeError, b.copy, exclude_parent=False)


# Generated at 2022-06-11 09:50:35.897934
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # _dep_chain is None, and _parent is not None
    b = Block()
    b._dep_chain = None
    b._parent = Block()
    b._parent._dep_chain = ["dep_chain1", "dep_chain2", "dep_chain3"]
    assert b.get_dep_chain() == ["dep_chain1", "dep_chain2", "dep_chain3"]
    # _dep_chain is not None, and _parent is None
    b._dep_chain = ["dep_chain1", "dep_chain2", "dep_chain3"]
    b._parent = None
    assert b.get_dep_chain() == ["dep_chain1", "dep_chain2", "dep_chain3"]
    # _dep_chain is None, and _parent is None
    b._dep_chain = None

# Generated at 2022-06-11 09:50:40.747429
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.task.include import TaskInclude
    from ansible.utils.vars import combine_vars

    def task_include(name, tasks, parent=None, role=None, task_include=None, variable_manager=None, loader=None, use_handlers=False):
        ti = TaskInclude()
        ti._parent = parent
        ti._role = role
        ti._use_handlers = use_handlers
        ti._variable_manager = variable_manager
        ti._loader = loader

        vars_params = dict()
        if parent:
            vars_params = combine_vars(vars_params, parent.get_include_params())
        if role:
            vars_params = combine_vars(vars_params, role.get_default_vars())


# Generated at 2022-06-11 09:50:42.727209
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Check without params
    b = Block()
    b.filter_tagged_tasks()

# Generated at 2022-06-11 09:50:47.379129
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    c = {'key': 'value'}
    ds = [dict(block=c)]
    data = dict()
    data['block'] = ds
    b = Block(data)
    assert b.preprocess_data(c) == data



# Generated at 2022-06-11 09:50:56.853596
# Unit test for method copy of class Block

# Generated at 2022-06-11 09:51:00.818245
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    b = Block()
    # Call method preprocess_data of Block
    assert b.preprocess_data("") == {}
    assert b.preprocess_data("abc") == {'block': ['abc']}
    meta = {}
    assert b.preprocess_data(meta) == meta


# Generated at 2022-06-11 09:51:01.508397
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    pass

# Generated at 2022-06-11 09:51:22.349588
# Unit test for method copy of class Block
def test_Block_copy():
    pass

# Generated at 2022-06-11 09:51:26.962972
# Unit test for method copy of class Block
def test_Block_copy():
    args = dict(
        name='example',
        block=[
            {'debug': {
                'msg': 'this is a test'
            }}
        ]
    )

    parent = Block(name='parent')
    block = Block(name='child', block=[
        {'debug': {
            'msg': 'this is a test'
        }}
    ])
    block._parent = parent

    role = Role()
    parent._role = role
    parent._role._role_path = 'roles/example'

    new_block = block.copy(exclude_tasks=True)
    assert new_block.name == 'child'
    assert new_block.block == []

    assert new_block._role is not None
    assert new_block._parent is not None

# Generated at 2022-06-11 09:51:36.560921
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    import os

    c = PlayContext()
    c._ansible_vars = dict(
        prod = 'prod_server',
        a = 'a',
        b = 'b'
    )

    class FakePlay(object):
        '''
        This class mocks the Play class so that we can test the Block class
        without needing to load all of the play objects.
        '''

        _attributes = dict(
            tags = ['foo', 'bar'],
            skip_tags = ['baz'],
            vars = dict(),
            vars_prompt = dict(),
            vars_files = []
        )


# Generated at 2022-06-11 09:51:45.802029
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    def test_implicit_block():
        data = [{'action': 'first', 'register': 'a'}, {'action': 'second', 'register': 'b'}]
        expected = dict(block=data)
        actual = Block().preprocess_data(data)
        assert_equal(actual, expected)

    def test_explicit_block():
        data = dict(block=[{'action': 'first', 'register': 'a'}, {'action': 'second', 'register': 'b'}])
        actual = Block().preprocess_data(data)
        assert_equal(actual, data)

    test_implicit_block()
    test_explicit_block()


# Generated at 2022-06-11 09:51:49.361707
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block.load({'always': {'debug': {'msg': 'I always run'}}}, loader=DictDataLoader(), variable_manager=VariableManager())
    block.deserialize({'always': {'debug': {'msg': 'I always run'}}})
    return block


# Generated at 2022-06-11 09:51:51.739965
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    block.set_loader()


# Generated at 2022-06-11 09:52:00.835763
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook import Play
    from ansible.vars import VariableManager


# Generated at 2022-06-11 09:52:10.762713
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    #test for normal situation
    block1 = Block(play = None, parent = None, role = None, task_include = None, use_handlers = False, implicit = False)
    include1 = TaskInclude(play = None, parent = block1, role = None, task_include = None, use_handlers = False, implicit = False)
    block2 = Block(play = None, parent = include1, role = None, task_include = None, use_handlers = False, implicit = False)

# Generated at 2022-06-11 09:52:12.123366
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    assert False, "No tests for method filter_tagged_tasks"


# Generated at 2022-06-11 09:52:21.836278
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.included_file import IncludedFile

    # we need a Play object to instantiate the Task objects
    play = Play.load(dict(name="test play"), variable_manager=None, loader=None)
    play._included_files.append(IncludedFile("test_file", "test_host", "test_path"))
    play._role_names = ['test_role']


# Generated at 2022-06-11 09:52:49.209654
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    args= dict(
            dep_chain = None,
            rescue = None,
            ignore_errors = None,
            always = None,
            any_errors_fatal = None,
            block = (
                Task(name = 'Test name', action = 'Test action'),
                Task(name = 'Test name', action = 'Test action'),
            ),
            tags = None,
            retries = 0,
            when = None,
            delegate_to = 'localhost',
            max_fail_percentage = 100,
            no_log = False,
            register = None,
            until = None,
            changed_when = None,
            failed_when = None,
            delay = 10,
            delegate_facts = None,
            local_action = None,
            run_once = False,
        )

# Generated at 2022-06-11 09:52:59.296810
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    role_data = dict(
        name='test_role',
        foo='/path/foo',
        bar=['test', 'stuff']
    )

    r = Role()
    r.deserialize({'name': 'test_role', 'foo': 'bar', 'bar': 'foo'})

    play_ds = dict(
        name='test_play',
        gather_facts='no',
        roles=[role_data]
    )

    p = Play().load(play_ds, variable_manager=VariableManager())
    t = Task().load(dict(name='test'), play=p, variable_manager=VariableManager(), loader=None)

# Generated at 2022-06-11 09:53:08.028185
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    DUMMY_DICT = {'a':'b'}
    DUMMY_LIST = ['a', 'b']

    def _mock_is_block(ds):
        return False

    def _mock_is_no_block(ds):
        return True

    # Check when Block._is_block returns False
    b = Block()
    b._is_block = MagicMock(side_effect=_mock_is_block)
    res_data = b.preprocess_data(DUMMY_DICT)
    assert res_data == DUMMY_DICT

    res_data = b.preprocess_data(DUMMY_LIST)
    assert res_data == dict(block=DUMMY_LIST)

    # Check when Block._is_block returns True
    b = Block()
    b._

# Generated at 2022-06-11 09:53:10.690103
# Unit test for method is_block of class Block
def test_Block_is_block():

    test = dict(a=1,b=2)

    assert Block.is_block(test) == False

    test['block'] = True

    assert Block.is_block(test) == True

# Generated at 2022-06-11 09:53:13.359164
# Unit test for method is_block of class Block
def test_Block_is_block():
    pass
###############################################################################
# END - Unit test for method is_block of class Block
###############################################################################



###############################################################################
# BEGIN - Unit test for method preprocess_data of class Block
###############################################################################

# Generated at 2022-06-11 09:53:21.617837
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude

    block = Block()
    assert True == block.all_parents_static()

    block2 = Block()
    block2.block = [Task()]
    block.block = [block2]
    assert True == block.all_parents_static()

    block2 = Block()
    block2.block = [TaskInclude()]
    block.block = [block2]
    assert False == block.all_parents_static()

    block2 = Block()
    block2.block = [RoleInclude()]
    block.block = [block2]
    assert True == block.all_parents_

# Generated at 2022-06-11 09:53:32.002914
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    #(self, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=None):
    a=Block(1,2,3)
    #Create append_task(target)
    def append_task(target):
        tmp_list = []
        for task in target:
            tmp_list.append(task)
        return tmp_list
    assert append_task([1,2,3])==[1,2,3]
    #Create evaluate_block(block)
    def evaluate_block(block):
        new_block = block.copy(exclude_parent=True, exclude_tasks=True)
        new_block._parent = block._parent
        new_block.block = append_task(block.block)
        new_block.rescue = append_

# Generated at 2022-06-11 09:53:34.740748
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    from ansible.playbook.block import Block

    block = Block(use_handlers=False)
    assert block.has_tasks() == False


# Generated at 2022-06-11 09:53:36.557868
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    debug("test_Block_filter_tagged_tasks")
    # TODO
    assert False


# Generated at 2022-06-11 09:53:38.596807
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Create a test object the easy way
    b = Block()
    b.set_loader(object())
    pass


# Generated at 2022-06-11 09:53:58.596913
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    b.block = [1,2,3]
    b.rescue = [4,5,6]
    b.always = [7,8,9]
    assert b.has_tasks()

    b = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    b.block = []
    b.rescue = []
    b.always = []
    assert not b.has_tasks()

    b = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)

# Generated at 2022-06-11 09:54:07.204878
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    b = Block()
    b._attributes = {}
    b.deserialize({'role': {'_role_name': 'test-role', '_task_blocks':[]}, 'parent': {'statically_loaded': True, 'include_variables': {'a': 1}, '_task_blocks': [], '_role_name': 'test-role', '_attributes': {'include_variables': {'a': 1}, 'statically_loaded': True}}, 'parent_type': 'Block'})
    assert b._role._role_name == 'test-role'
    assert b._parent._parent_type == 'Block'

# Generated at 2022-06-11 09:54:16.406957
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    print()
    print('Test Block.filter_tagged_tasks()')
    print('--------------------------------')

    block = Block(
        name="valid",
        block='''
- name: task 1
  meta: end_play

- name: task 2
  include_role:
    name: test
    tasks_from: val.yml

- name: task 3
  block:
    - name: task 3.1
      meta: end_play
      tags:
          - test
    - name: task 3.2
      debug:
          msg: "{{ test }}"'''
    )
    block.load()

    print()
    print('all_tasks')
    print('---------')
    filtered_block = block.filter_tagged_tasks({})
    new_block = block.copy()


# Generated at 2022-06-11 09:54:18.964396
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block = Block()
    block._dep_chain = [1,2,3]
    assert block.get_dep_chain() == [1,2,3]

# Generated at 2022-06-11 09:54:28.646749
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    # Build a new Block object
    block = Block()
    # Test if it return False
    assert block.all_parents_static() == True
    # Build a new TaskInclude object with statically_loaded attribute set to True
    task_include = TaskInclude(statically_loaded=True)
    # Set task_include as parent of Block
    block._parent = task_include
    # Test if it return True
    assert block.all_parents_static() == True
    # Build a new TaskInclude object with statically_loaded attribute set to False
    task_include = TaskInclude(statically_loaded=False)
    # Set task_include as parent of Block
    block._parent = task_include
    # Test if it

# Generated at 2022-06-11 09:54:30.998799
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    args = dict()
    args['data'] = None
    b = Block()
    r = b.deserialize(**args)
    assert r is False


# Generated at 2022-06-11 09:54:38.173222
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    assert block.copy() == block
    assert block.copy(exclude_parent=True) == block
    assert block.copy(exclude_tasks=True) == block
    assert block.copy(exclude_parent=False, exclude_tasks=True) == block

from ansible.playbook.block import Block
from ansible.playbook.role import Role
from ansible.playbook.task import Task


from ansible.playbook.task_include import TaskInclude
from ansible.playbook.handler_task_include import HandlerTaskInclude


from ansible.playbook.role import Role
from ansible.playbook.task import Task
from ansible.playbook.handler import Handler

# Generated at 2022-06-11 09:54:42.682346
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    print("Testing method has_tasks() of Block ")
    print("TEST 1: block has no tasks")
    assert block.has_tasks() == False
    print("TEST 2: block is None")
    block = None
    assert not block.has_tasks()
    print("------------End of tests for method has_tasks of class Block-------------")


# Generated at 2022-06-11 09:54:52.316129
# Unit test for method copy of class Block
def test_Block_copy():
  data1 = "The quick brown fox."
  data2 = "The quick brown fox. The quick brown fox. The quick brown fox."
  data3 = "The quick brown fox. The quick brown fox. The quick brown fox. The quick brown fox. The quick brown fox."
  data4 = "The quick brown fox. The quick brown fox. The quick brown fox. The quick brown fox. The quick brown fox. The quick brown fox."  
  data5 = "The quick brown fox. The quick brown fox. The quick brown fox. The quick brown fox. The quick brown fox. The quick brown fox. The quick brown fox."
  data6 = "The quick brown fox. The quick brown fox. The quick brown fox. The quick brown fox. The quick brown fox. The quick brown fox. The quick brown fox. The quick brown fox."

# Generated at 2022-06-11 09:55:01.043101
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    args = dict(
        block=None,
        rescue=None,
        always=None,
        name='foo',
        async_val=0,
        notify=[],
        static=False,
        ignore_errors=False,
        loop=None,
        retries=0,
        until=[],
        run_once=False,
        only_if=[],
        when=[],
        register=None,
        with_items=[],
        with_file=[],
        with_dict=[],
        with_subelements=[],
        with_sequence=[],
        with_first_found=[],
        environment={},
        role=None,
        dep_chain=None,
        statically_loaded=False,
        parent=None,
        parent_type=None,
    )
    b = Block(**args)

# Generated at 2022-06-11 09:55:14.370263
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # FIXME: write a unit test for the Block.filter_tagged_tasks() method
    pass


# Generated at 2022-06-11 09:55:15.866895
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block = Block()
    assert block.get_dep_chain() == None


# Generated at 2022-06-11 09:55:24.155428
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # test case 1
    block = Block()
    print("block.has_tasks(): %s" % block.has_tasks())
    # test case 2
    block.block = [1, 2]
    print("block.has_tasks(): %s" % block.has_tasks())
    # test case 3
    block.rescue = [1, 2]
    print("block.has_tasks(): %s" % block.has_tasks())
    # test case 4
    block.always = [1, 2]
    print("block.has_tasks(): %s" % block.has_tasks())


# Generated at 2022-06-11 09:55:34.790541
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    import os
    import sys
    import tempfile
    import yaml
    testDir = os.path.dirname(__file__)
    testFilesDir = os.path.join(testDir, "test_files")
    myfile = open(os.path.join(os.path.expanduser(testFilesDir), "test_tagged_tasks.yaml"))
    test_data = myfile.read()
    myfile.close()
    task = Task()
    loader = DictDataLoader()
    data = yaml.safe_load(test_data)

# Generated at 2022-06-11 09:55:42.674928
# Unit test for method is_block of class Block
def test_Block_is_block():
    # test for empty dictionary
    data = {}
    assert Block.is_block(data) == False

    # test for valid block
    data = {"block": [{"action": "ansible.builtin.debug", "args": "msg=\"this is my debug command\"", "name": "debug"}]}
    assert Block.is_block(data) == True

    # test for invalid block
    data = {"rescue": [{"action": "ansible.builtin.debug", "args": "msg=\"this is my debug command\"", "name": "debug"}]}
    assert Block.is_block(data) == True


# Generated at 2022-06-11 09:55:45.006619
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    c = b.copy()

    # Test that a block that has not been loaded returns a copy of itself
    assert (c is b)

# Generated at 2022-06-11 09:55:46.759639
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    print('Testing method has_tasks')
    print('Not yet implemented')


# Generated at 2022-06-11 09:55:51.832293
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
  # Call method
  # test for a case in which the block does not have any tasks
  assert Block(play=Play(), parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False).has_tasks() == False
  # test for a case in which the block has tasks
  assert Block(play=Play(), parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False).has_tasks() == True
  

# Generated at 2022-06-11 09:55:54.496134
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    def get_block():
        return Block()
        
    block = get_block()
    loader = DataLoader()
    block.set_loader(loader=loader)


# Generated at 2022-06-11 09:56:03.499958
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Test a block whose parents are statically loaded.
    block = Block()
    assert block.all_parents_static() == True

    # Test a block whose parent is a task_include with static_loaded set to False.
    from ansible.playbook.task_include import TaskInclude
    task_include = TaskInclude(statically_loaded=False)
    block2 = Block(parent=task_include)
    assert block2.all_parents_static() == False

    # Test a block whose parent is a task_include whose parent is a block with static_loaded set to False.
    block3 = Block(parent=task_include)
    task_include.parent = block3
    assert block3.all_parents_static() == False
    
    
###############################################################################
# Class: Play
#   A Play contains a list of plays

# Generated at 2022-06-11 09:56:20.401449
# Unit test for method is_block of class Block
def test_Block_is_block():
    data = {'block': [{'tags': [], 'task': 'test_task'}], 'rescue': [], 'always': [], 'tags': []}
    obj = Block.is_block(data)
    return obj == True


# Generated at 2022-06-11 09:56:21.300949
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    pass



# Generated at 2022-06-11 09:56:29.572247
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    b = Block()
    b.all_parents_static()
    b._parent = Block()
    b.all_parents_static()
    b._parent = Block()
    t = Task()
    b._parent = t
    b.all_parents_static()
    b._parent = TaskInclude()
    b.all_parents_static()
    ti = TaskInclude()
    ti.statically_loaded = False
    b._parent = ti
    b.all_parents_static()
