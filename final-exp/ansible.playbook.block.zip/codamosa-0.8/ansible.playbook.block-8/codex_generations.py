

# Generated at 2022-06-11 09:47:18.479109
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    import yaml
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    # CASE: Block.block, block as a list([])
    block_list = Block()
    assert(isinstance(block_list, Block))
    block_list.block = []

    filtered_block_list = Block()
    filtered_block_list.block = []
    assert(block_list.filter_tagged_tasks([]) == filtered_block_list)

    # CASE: Block.block, block as a list([{}])
    block_list = Block()
    assert(isinstance(block_list, Block))
    block_list.block = [{}]

    filtered_block_list = Block()
    filtered_block_list.block = [{}]

# Generated at 2022-06-11 09:47:28.103882
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    b1 = Block()
    b2 = Block()
    b3 = Block()

    b1.implicit = b2.implicit = b3.implicit = True

    assert b1.get_dep_chain() == None
    assert b2.get_dep_chain() == None
    assert b3.get_dep_chain() == None

    b2._parent = b1
    b2._dep_chain = b1.get_dep_chain()

    assert b1.get_dep_chain() == None
    # now b2._parent == b1, we check __eq__ == 'is'
    assert b2.get_dep_chain() == [b1]
    assert b3.get_dep_chain() == None

    b3._parent = b2
    b3._dep_chain = b2.get_

# Generated at 2022-06-11 09:47:38.794693
# Unit test for method copy of class Block
def test_Block_copy():
    import pytest
    from ansible.playbook.play_context import PlayContext

    my_task = Task()
    my_task._play = Play()
    my_task._play.context = PlayContext()

    with pytest.raises(AnsibleAssertionError) as execinfo:
        foo = Block()
        foo.copy()

    foo = my_task.copy()

# Generated at 2022-06-11 09:47:48.346570
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    '''
    Unit test class Block:
    method set_loader - tests variable _loader changed correctly
    '''
    host_list = [{"hostname": "hostname", "ip": "10.122.1.122", "port": "22",
                  "username": "root", "password": "123456"}]

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=host_list)
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 09:47:57.378426
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    b = Block()
    b._dep_chain = [1]
    assert b.get_dep_chain() == [1]
    #b.get_dep_chain() == b._dep_chain[:]

    b = Block()
    b._parent = None
    assert b.get_dep_chain() == None

    b = Block()
    b._parent = Block()
    b._parent._dep_chain = [1]
    expected = [1]
    assert b.get_dep_chain() != expected

    b = Block()
    b._parent = Block()
    b._parent._dep_chain = [1]
    assert b.get_dep_chain() == b._parent.get_dep_chain()

    b = Block()
    b._parent = Block()
    b._parent._dep_chain = [1]

# Generated at 2022-06-11 09:47:58.733530
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block()
    assert b.has_tasks() == False


# Generated at 2022-06-11 09:48:06.377614
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    # should raise exception due to not being a dictionary
    try:
        block.copy(exclude_tasks=True)
    except Exception as e:
        assert type(e) == AssertionError
    # asserts the block is copied correctly
    assert block.copy({'_role': None, '_parent': None, '_dep_chain': None,
        'always': None, 'rescue': None, 'block': None}, exclude_tasks=True) == {'_role': None, '_parent': None, '_dep_chain': None,
        'always': None, 'rescue': None, 'block': None}


# Generated at 2022-06-11 09:48:09.743117
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
  # Provision a module named Block
  Block_instance = Block()
  # Invoke the instance method
  assert bool(Block_instance.has_tasks()) == bool(('has_tasks', 'Block'))

# Generated at 2022-06-11 09:48:13.300350
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    pb = Mock()
    block = Block(play=pb, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    ld = Mock()
    block.set_loader(ld)


# Generated at 2022-06-11 09:48:17.999097
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = Block()
    block.block = [2, 3]
    block.rescue = [4, 5]
    block.always = [6, 7]
    assert block.filter_tagged_tasks(None) == [2, 3]

# Generated at 2022-06-11 09:48:42.134702
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    play = AnsiblePlay()
    block = Block(play=play, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    my_dict1 = dict()
    block_returned = block.filter_tagged_tasks(my_dict1)

# Generated at 2022-06-11 09:48:52.382304
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude


# Generated at 2022-06-11 09:49:03.995746
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    ###
    # Create the object Block and set its attribute
    ###
    block = Block()
    ###
    # Test the methods has_tasks, __repr__, get_block_list, get_include_params,
    # all_parents_static, get_first_parent_include, __getstate__, __setstate__ of
    # class Block
    ###
    assert block.has_tasks() is False

# Generated at 2022-06-11 09:49:11.414694
# Unit test for method copy of class Block
def test_Block_copy():
    play = Play().load({'name': 'test play'}, variable_manager=VariableManager(), loader=DictDataLoader())
    role = Role()
    b = Block(play=play, role=role, task_include=None, use_handlers=True)
    new_me = b.copy()
    assert new_me._play == b._play
    assert new_me._use_handlers == b._use_handlers
    assert new_me._dep_chain == b._dep_chain
    assert new_me._parent == b._parent
    assert new_me._role == b._role


# Generated at 2022-06-11 09:49:15.531316
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_obj = Block(task_include=None)
    test_data = dict()
    test_data['dep_chain'] = None
    test_data['role'] = ''
    test_data['parent_type'] = 'Block'
    block_obj.deserialize(test_data)
    assert block_obj._dep_chain == None
    assert block_obj._role == None
    assert block_obj._parent == None

# Generated at 2022-06-11 09:49:26.052188
# Unit test for method copy of class Block

# Generated at 2022-06-11 09:49:40.417916
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-11 09:49:41.254372
# Unit test for method set_loader of class Block
def test_Block_set_loader():


    pass

# Generated at 2022-06-11 09:49:49.460036
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # Creating an instance of Block and assigning values to its member variables.
    b = Block()
    b.DEPRECATED_BOOLEANS = {'yes': True, 'on': True, '1': True, 'true': True, 'no': False, 'off': False, '0': False, 'false': False}
    b._attributes = {'foo': None, 'hosts': None, 'roles': None, 'name': None, 'loop': None, 'any_errors_fatal': None, 'ignore_errors': None, 'until': None, 'retries': None, 'delay': None, 'run_once': None}
    b._dep_chain = None
    b.block = None
    b.rescue = None
    b.always = None
    b.ignore_errors = None
    b.any_errors_f

# Generated at 2022-06-11 09:49:51.838627
# Unit test for method is_block of class Block
def test_Block_is_block():
    block1 = {'block':'something'}
    assert Block.is_block(block1) == True, "Block.is_block() is False, should be True"
    return True


# Generated at 2022-06-11 09:50:15.068798
# Unit test for method get_dep_chain of class Block

# Generated at 2022-06-11 09:50:25.332572
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    group = Group('webservers')
    group.vars['foo'] = "bar"

    host = Host(name="test.example.com")
    host.set_variable('ansible_ssh_port', 1234)
    # host.set_variable('ansible_ssh_host', '1.2.3.4')
    host.set_variable('ansible_connection', 'ssh')

    play = Play()
    play.hosts = "webservers"
    play.name = "Test"


# Generated at 2022-06-11 09:50:35.124228
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.base import Base
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    block = Block()
    block._play = Base()
    block._play._attributes = dict(
        tags_name_map=dict(
            foo=['f']
        )
    )
    block.tags = ['f']
    block._role = Role()
    block.block = []
    block.rescue = []
    block.always = []
    task0 = Task()
    task0.action = 'meta'
    task0.implicit = True
    task0.tags = []
    task1 = Task()
    task1.action = 'include'
    task1.tags = []
    task2 = Task()
    task2.action = 'meta'


# Generated at 2022-06-11 09:50:39.867576
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    '''
    Unit test for method get_first_parent_include of class Block
    '''
    # create simple Block
    block1 = Block(task_include=None, use_handlers=False, implicit=False)
    # create Block_result
    block_result = block1.get_first_parent_include()
    # assert
    assert block_result == None


# Generated at 2022-06-11 09:50:51.457937
# Unit test for method filter_tagged_tasks of class Block

# Generated at 2022-06-11 09:50:52.195469
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    pass


# Generated at 2022-06-11 09:50:59.540177
# Unit test for method deserialize of class Block
def test_Block_deserialize():

    # Testing deserialization of a Block object
    # Deserialization of a Block object
    # Input: data
    # Expected output: No exception
    data = dict(handler=None, rescue=None, always=None, block="some text")
    # Unit test:
    assert isinstance(data, dict)
    assert data['block'] == 'some text'

    b = Block()
    assert isinstance(b, Block)
    b.deserialize(data)

    # Testing deserialization of a Block object
    # Deserialization of a Block object with invalid data
    # Input: data
    # Expected output: exception
    data = dict(handler=None, rescue=None, always=None, block=["some text", "other text"])
    # Unit test:

# Generated at 2022-06-11 09:51:05.665112
# Unit test for method is_block of class Block
def test_Block_is_block():
  test_block=Block()
  test_block_dict={'block':[], 'rescue':[], 'always':[]}
  test_block_list=[]
  test_result=test_block.is_block(test_block_dict)
  assert test_result
  test_result=test_block.is_block(test_block_list)
  assert not test_result


# Generated at 2022-06-11 09:51:15.887310
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = Block(block=[Task(action='debug', tags=['foo'])])
    assert isinstance(block, Block)
    assert isinstance(block.block, list) and len(block.block) == 1
    assert isinstance(block.block[0], Task)
    block = block.filter_tagged_tasks(dict())
    assert isinstance(block, Block)
    assert isinstance(block.block, list) and len(block.block) == 1
    assert isinstance(block.block[0], Task)
    block = block.filter_tagged_tasks(dict(tags=['foo']))
    assert isinstance(block, Block)
    assert isinstance(block.block, list) and len(block.block) == 1
    assert isinstance(block.block[0], Task)

# Generated at 2022-06-11 09:51:24.656524
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import get_all_plugin_loaders
    loader = get_all_plugin_loaders()
    inventory = Inventory("/ansible/inventory")
    play_source = dict(
        name="Ansible Play",
        hosts='testhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    )
    play = Play().load(play_source, variable_manager=inventory.get_variable_manager(), loader=loader)

# Generated at 2022-06-11 09:51:56.969334
# Unit test for method deserialize of class Block

# Generated at 2022-06-11 09:51:57.566837
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    pass

# Generated at 2022-06-11 09:52:07.617446
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test case 1: no parent
    print('Test case 1: no parent')
    block = Block()
    assert block.get_first_parent_include() is None

    # Test case 2: parent is a task
    print('Test case 2: parent is a task')
    task = Task()
    task._role_name = 'test'
    block._parent = task
    assert block.get_first_parent_include() is None

    # Test case 3

# Generated at 2022-06-11 09:52:14.520362
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    try:
        data = dict()
        b = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
        test = "test_Block_set_loader"
        loader = None    
        assert hasattr(b,test)
        assert b.set_loader(loader)
        assert b.set_loader(loader) == None
        assert b.set_loader(loader) == None
        assert b.set_loader(loader) == None
    except:
        return False
    return True


# Generated at 2022-06-11 09:52:23.995807
# Unit test for method copy of class Block
def test_Block_copy():
    my_block = Block(variable_manager="variable_manager", loader="loader", play="play", parent_block="parent_block", role="role", task_include="task_include", use_handlers="use_handlers")
    # First pass.
    # Verify that copy returns an object of the same class.
    my_block_copy_1 = my_block.copy()
    assert isinstance(my_block_copy_1, Block)
    # Verify that copy returns different object.
    assert my_block is not my_block_copy_1
    # Verify that the attributes of the objects are equal.
    # It is not clear what is needed to test here.

    # Second pass.
    # Verify that copy returns an object of the same class.

# Generated at 2022-06-11 09:52:32.819673
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    def _get_block_tasks(block):
        tasks = []
        for t in block.block:
            if isinstance(t, Block):
                for t1 in _get_block_tasks(t):
                    tasks.append(t1)
            else:
                tasks.append(t)
        return tasks

    def _get_block_by_name(block, name):
        if block.name == name:
            return block
        for t in block.block:
            if isinstance(t, Block):
                res = _get_block_by_name(t, name)
                if res:
                    return res
        return None

    class FakeTask(object):
        def __init__(self, name, tags):
            self.name = name
            self.tags = tags

# Generated at 2022-06-11 09:52:34.386568
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    b = Block()
    b.filter_tagged_tasks()


# Generated at 2022-06-11 09:52:44.972317
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    data = dict()


# Generated at 2022-06-11 09:52:55.218249
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    import ansible.playbook
    import ansible.playbook.block

    block = ansible.playbook.block.Block()
    if block:
        assert block.has_tasks() == False

    block = ansible.playbook.block.Block()
    block.block = [1, 2]
    if block:
        assert block.has_tasks() == True

    block = ansible.playbook.block.Block()
    block.rescue = [1, 2]
    if block:
        assert block.has_tasks() == True

    block = ansible.playbook.block.Block()
    block.always = [1, 2]
    if block:
        assert block.has_tasks() == True

# Generated at 2022-06-11 09:52:56.558903
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    assert isinstance(block.copy(), Block)


# Generated at 2022-06-11 09:53:28.052398
# Unit test for method deserialize of class Block
def test_Block_deserialize():
  pass


# Generated at 2022-06-11 09:53:38.029071
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

    Base._variable_manager = Mock()
    Base._loader = Mock()
    Base._shared_loader_obj = True
    Base._role_manager = Mock()

    PlayContext._variable_manager = Mock()
    PlayContext._loader = Mock()
    PlayContext._shared_loader_obj = True
    PlayContext._role_manager = Mock()

    Task._role = Mock()
    Task._play = Mock()

    HandlerTask

# Generated at 2022-06-11 09:53:38.922584
# Unit test for method copy of class Block
def test_Block_copy():
    Block()


# Generated at 2022-06-11 09:53:41.430501
# Unit test for method copy of class Block
def test_Block_copy():
    test_copy = lambda: Block.copy()
    assert_raises(NotImplementedError, test_copy)
    assert_raises(NotImplementedError, test_copy)

# Generated at 2022-06-11 09:53:46.200310
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():

    # Create input for test; copy of method's declaration
    data = dict(a=1, b=2, c=3)
    # Expected result
    expected_result = dict(block=[data])

    # Create instance of class
    b_instance = Block()

    # Execute the method to test
    results = b_instance.preprocess_data(data)

    # Test for expected results
    assert (expected_result == results)


# Generated at 2022-06-11 09:53:55.535948
# Unit test for method copy of class Block
def test_Block_copy():
    args = dict(
        block='block',
        always='always',
        rescue='rescue',
        delegate_to='delegate_to',
        run_once='run_once',
        any_errors_fatal='any_errors_fatal',
        serial='serial',
        name='name',
        when='when',
        tags='tags',
        skip_tags='skip_tags',
        until='until',
        changed_when='changed_when',
        failed_when='failed_when',
        always_run='always_run',
    )
    b = Block(**args)
    b_copy = b.copy(True, True)
    for k, v in args.items():
        assert v == getattr(b_copy, k)
    assert not b_copy._play
    assert not b_copy._

# Generated at 2022-06-11 09:54:04.168897
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    host_list = [
        'localhost',
        'example.com'
    ]
    block = Block(
        use_handlers=True,
        role=Role(),
        static=True,
        become=True,
        become_user='root',
        block=['1', '2', '3'],
        rescue=['4', '5', '6'],
        always=['7', '8', '9']
    )
    assert block.has_tasks()

# Test class unit Block

# Generated at 2022-06-11 09:54:07.861798
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # pylint: disable=protected-access
    module = AnsibleModule(
        argument_spec=dict(
            loader=dict(type='path', required=False),
        ),
    )
    result = dict(
        changed=False,
    )
    module.exit_json(**result)


# Generated at 2022-06-11 09:54:17.096867
# Unit test for method has_tasks of class Block

# Generated at 2022-06-11 09:54:26.549808
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    import pytest
    my_block=Block()
    my_block_1=Block()
    my_block_2=Block()
    my_block_3=Block()
    my_task_include=TaskInclude()
    my_task_include_1=TaskInclude()
    my_task_include_2=TaskInclude()
    my_task_include_3=TaskInclude()
    my_task_include_4=TaskInclude()
    my_block_1._parent=my_block
    my_block_2._parent=my_block_1
    my_block_3._parent=my_block_2
    my_task_include_1._parent=my_task_include


# Generated at 2022-06-11 09:54:59.480886
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    raise NotImplementedError



# Generated at 2022-06-11 09:55:08.327408
# Unit test for method copy of class Block
def test_Block_copy():
    # Test fixture
    play_context = dict()
    new_block = dict()
    new_block['dep_chain'] = ['Test1']
    play_context['block'] = ['Test1']
    play_context['rescue'] = ['Test2']
    play_context['always'] = ['Test3']
    mock_play = MagicMock()
    mock_play._attributes = play_context
    role_context = dict()
    role_context['_valid_attrs'] = ['Test1','Test2','Test3']
    mock_role = MagicMock()
    mock_role._attributes = role_context
    mock_parent = MagicMock()
    mock_parent._parent =  MagicMock()
    mock_parent._parent._attributes = role_context
    mock_parent._attributes = play_context

# Generated at 2022-06-11 09:55:09.724705
# Unit test for method copy of class Block
def test_Block_copy():
    '''
    Test function copy with parameters:
    '''
    pass

# Generated at 2022-06-11 09:55:18.477319
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    obj = Block()
    obj._loader = loader
    obj._variable_manager = variable_manager
    obj._dep_chain = ['test']
    obj._parent = 'test'
    obj._role = 'test'
    # object passed in is a copy the object, without the attributes' values
    # the object created must be indentical to the previous one
    obj2 = obj.copy()
    assert obj2._loader == obj._loader

# Generated at 2022-06-11 09:55:29.152794
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block=Block()
    assert False == block.has_tasks()
    
    block.block=['test']
    assert True == block.has_tasks()

    block.block=[]
    block.rescue=['test']
    assert True == block.has_tasks()

    block.rescue=[]
    block.rescue=['test']
    assert True == block.has_tasks()

    block.rescue=[]
    block.always=['test']
    assert True == block.has_tasks()
# Test method copy of class Block
block=Block()
assert type(block) == type(block.copy())
# Test method serialize of class Block
block=Block()
assert type(block) == type(Block.deserialize(block.serialize()))
# Test method set_loader of class Block

# Generated at 2022-06-11 09:55:39.464423
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    print("START test_Block_has_tasks")
    b = Block()

    # Case 1
    print("Case 1")
    print("START setUp")
    b._attributes = {'block': {}}
    print("END setUp")
    print("EXPECTED has_tasks: False")
    actual = b.has_tasks()
    print("ACTUAL has_tasks:", actual )
    assert actual == False

    # Case 2
    print("Case 2")
    print("START setUp")
    b._attributes = {'block': {'rescue': {}}}
    print("END setUp")
    print("EXPECTED has_tasks: False")
    actual = b.has_tasks()
    print("ACTUAL has_tasks:", actual )
    assert actual == False

# Generated at 2022-06-11 09:55:45.937367
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    my_block = Block()
    my_block_parent = Block()
    my_block._parent = my_block_parent
    my_block_parent_parent = Block()
    my_block_parent._parent = my_block_parent_parent
    my_task = TaskInclude()
    my_block_parent_parent._parent = my_task
    assert my_block.get_first_parent_include() == my_task



# Generated at 2022-06-11 09:55:47.496815
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block=Block()
    assert block.get_first_parent_include() == None


# Generated at 2022-06-11 09:55:48.107966
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    pass

# Generated at 2022-06-11 09:55:48.987093
# Unit test for method is_block of class Block
def test_Block_is_block():
    pass


# Generated at 2022-06-11 09:56:24.582913
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    class ResultsCollector(CallbackBase):
        def __init__(self):
            super(ResultsCollector, self).__init__()
            self.host_ok = {}
            self.host_unreachable = {}
            self.host_failed = {}

        def v2_runner_on_unreachable(self, result):
            self.host_unreachable[result._host.get_name()] = result


# Generated at 2022-06-11 09:56:31.570310
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
  from ansible.playbook.task_include import TaskInclude
  block = Block()
  TaskInclude().set_loader( 'loader' )
  task_include = TaskInclude()
  task_include._statically_loaded = True
  first_parent_include = block.get_first_parent_include()
  assert first_parent_include == None
  block = Block( task_include )
  task_include = TaskInclude()
  task_include._statically_loaded = True
  task_include._parent = block
  first_parent_include = block.get_first_parent_include()
  assert first_parent_include == task_include

