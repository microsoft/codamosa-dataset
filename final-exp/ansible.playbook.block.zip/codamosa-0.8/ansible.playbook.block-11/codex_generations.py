

# Generated at 2022-06-11 09:47:24.901187
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.vars import combine_vars, load_extra_vars, load_options_vars
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import Play

    class TestInventory:
        def __init__(self):
            self.hosts = dict()

    class Options:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    class FakeClass:
        pass

    options = Options

# Generated at 2022-06-11 09:47:35.778296
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block = Block()
    assert not block.all_parents_static()

    block_i = Block(statically_loaded=False)
    block.parent = block_i

    assert not block.all_parents_static()

    block_ii = Block(statically_loaded=True)
    block_i.parent = block_ii

    assert not block.all_parents_static()

    block_iii = Block(statically_loaded=True)
    block_ii.parent = block_iii

    assert block.all_parents_static()

    Block.all_parents_static(block)

Block.register_attribute('block', type='list', subtype='task', default=[],
                         inherit=True, static=[],
                         description="List of tasks to be performed in this block.")

# Generated at 2022-06-11 09:47:45.285077
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    def _get_loader():
        return DictDataLoader({ 'templates': { 'test.j2': 'test' } })

    loader = _get_loader()

    # Block.preprocess_data(None)
    # Should raise: 
    #  AnsibleParserError: Please supply a task list
    try:
        Block.load(None)
    except:
        pass
    else:
        raise Exception("Should raise AnsibleParserError: Please supply a task list")
    # Block.preprocess_data(['test'])
    # Should return: 
    #  {'block': ['test']}
    assert Block.preprocess_data(['test']) == {'block': ['test']}
    # Block.preprocess_data('{ role: test }')
    # Should return: 
    #  '{

# Generated at 2022-06-11 09:47:49.956033
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_obj = create_block_obj()
    obj_config_reader = ReadConfig()
    obj_config_reader.read_configuration(path_to_config)
    loader = DataLoader()
    block_obj.set_loader(loader)
if __name__ == "__main__":
    # Execute only if run as a script
    test_Block_set_loader()

# Generated at 2022-06-11 09:47:50.911741
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    assert Block.has_tasks()

# Generated at 2022-06-11 09:48:00.053258
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=DataLoader(), variable_manager=variable_manager, host_list=['localhost']))
    templar = Templar(loader=DataLoader(), variables=variable_manager.get_vars())

    def filter_tagged_tasks(filter_tags, filter_tags_match, max_tags, skip_tags_match, skip_tags, expect_task_count):
        class Playbook:
            only_tags = filter_tags
            tags_match = filter_tags_match
            max_tags = max_tags
            skip_tags_match = skip_tags_match
            skip_tags = skip

# Generated at 2022-06-11 09:48:09.743148
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task import Task

    block = Block()
    block.set_loader({})
    assert block.__dict__.get('_loader') == {}

    block = Block()
    block._parent = Task()
    block.set_loader({})
    assert block.__dict__.get('_loader') == {}

    block = Block()
    block._role = {'tasks': [], 'defaults': [], 'vars': [], 'meta': [], 'handlers': []}
    block.set_loader({})
    assert block.__dict__.get('_loader') == {}

    block = Block()
    block._parent = Task()
    block.__dict__['_task_dep_chain'] = ['A', 'B']
    block.set_loader({})
    assert block.__

# Generated at 2022-06-11 09:48:10.391152
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    pass

# Generated at 2022-06-11 09:48:20.440036
# Unit test for method copy of class Block
def test_Block_copy():
  block = Block(play=dict(), parent_block=dict(), role=dict(), task_include=dict(), use_handlers=True, implicit=True)
  assert block.copy() == block.copy(exclude_parent=True, exclude_tasks=True)
  assert block.copy(exclude_parent=True, exclude_tasks=False) == block.copy(exclude_parent=True, exclude_tasks=True)
  assert block.copy(exclude_parent=False, exclude_tasks=True) == block.copy(exclude_parent=True, exclude_tasks=True)
  assert block.copy(exclude_parent=False, exclude_tasks=False) == block.copy(exclude_parent=True, exclude_tasks=True)


# Generated at 2022-06-11 09:48:30.388235
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    """
    Test that the method filter_tagged_tasks of class Block
    works when there are the following cases:
    1. no task is tagged.
    2. all tasks are tagged.
    3. a mix of tasks that are tagged and not tagged.
    4. no tasks in block.
    5. comments with tags are ignored.
    """

    from ansible.playbook import Base
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    class TestTaskInclude(TaskInclude):
        def __init__(self, block, role=None, task_include=None, use_handlers=False):
            TaskInclude.__init__(self, block, role=None, task_include=None, use_handlers=False)
            self.block = block

# Generated at 2022-06-11 09:48:57.001412
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'admin'
    play_context.connection = 'network_cli'
    play_context.timeout = 10
    play_context.become = None
    play_context.become_method = None
    play_context.bec

# Generated at 2022-06-11 09:49:07.876039
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    static_block_1 = Block.load({'block': [{'debug': {'msg': 'TEST 1 in static block'}}]})
    static_block_2 = Block.load({'block': [{'debug': {'msg': 'TEST 2 in static block'}}]})
    static_block_2.statically_loaded = True
    static_block_3 = Block.load({'block': [{'debug': {'msg': 'TEST 3 in static block'}}]})
    static_block_3.statically_loaded = True
    static_block_4 = Block.load({'block': [{'debug': {'msg': 'TEST 4 in static block'}}]})
    static_block_4.statically_loaded = True

# Generated at 2022-06-11 09:49:15.850949
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    import yaml


# Generated at 2022-06-11 09:49:26.549733
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Setup mocks
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.playbook.task
    import ansible.playbook.role
    from ansible.playbook import play
    from ansible.playbook import block
    from ansible.playbook import task
    from ansible.playbook import task
    from ansible.playbook import role
    from ansible.parsing.yaml.loader import AnsibleLoader
    instance = Block()
    instance._play = ansible.playbook.play.Play()
    instance.block = [ansible.playbook.task.Task(),ansible.playbook.task.Task()]
    all_vars = {}
    # Invoke method
    retval

# Generated at 2022-06-11 09:49:29.368552
# Unit test for method copy of class Block
def test_Block_copy():
    my_block = Block()
    my_block.copy()


# Generated at 2022-06-11 09:49:41.921292
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create some task_data
    task_data = {'action': 'test1', 'tags': ['test1']}
    task_data2 = {'action': 'test2', 'tags': ['test2']}
    tag1_data = {'block': [task_data, task_data2]}
    block1 = Block.load(tag1_data)

    # Create filter
    filter = {}
    filter['only_tags'] = ['test1']
    filter['skip_tags'] = []

    def test_dict(temp_block):
        result = True
        if len(temp_block.block) != 1:
            result = False
        if not isinstance(temp_block.block[0], Task):
            result = False
        if temp_block.block[0].action != 'test1':
            result = False

# Generated at 2022-06-11 09:49:48.482402
# Unit test for method filter_tagged_tasks of class Block

# Generated at 2022-06-11 09:49:49.358469
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # FIXME: write tests
    pass

# Generated at 2022-06-11 09:49:58.044915
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    import ast
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=['localhost'])
    playbook_path = 'fake_path/ansible_playbook.yml'
    variable_manager = VariableManager()
    loader = DataLoader()


# Generated at 2022-06-11 09:50:01.574083
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # Create Block object
    block_obj = Block()
    block_obj.deserialize({})

    block_obj2 = Block()
    block_obj2.deserialize({})

    block_obj3 = Block()
    block_obj3.deserialize({})


# Generated at 2022-06-11 09:50:25.545999
# Unit test for method preprocess_data of class Block

# Generated at 2022-06-11 09:50:29.486453
# Unit test for method copy of class Block
def test_Block_copy():
    # Create a block to test
    block = Block()
    # Create a task to test
    task = Task()
    block.block = [task]
    # Test for copy method of class Block
    copy = block.copy()
    assert len(copy.block) == 1


# Generated at 2022-06-11 09:50:38.840321
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    role_name = 'test_role'

# Generated at 2022-06-11 09:50:50.572425
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from units.mock.loader import DictDataLoader

    cur_path =  os.path.dirname(__file__)
    results_path = cur_path + '/results/'
    input_path = cur_path + '/input/'
    Playbook = collections.namedtuple('Playbook', ['loader', 'variable_manager', 'inventory'])
    play = Play()
    play._ds = {'name': 'test_play'}
    play._basedir = cur_path
    play._file_name = cur_path + '/test_play.yml'
    play._play_basedir = cur_path
    variable_manager = VariableManager()
    variable_manager._extra_

# Generated at 2022-06-11 09:50:58.706749
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    parent = Block()
    block = Block(parent=parent)
    assert block.get_first_parent_include() == None

    parent = TaskInclude()
    block = Block(parent=parent)
    assert block.get_first_parent_include() == parent

    parent = Block()
    parent_parent = TaskInclude()
    parent._parent = parent_parent
    block = Block(parent=parent)
    assert block.get_first_parent_include() == parent_parent

    parent = Task()
    parent_parent = TaskInclude()
    parent._parent = parent_parent
    block = Block(parent=parent)
    assert block.get_first_

# Generated at 2022-06-11 09:51:09.435828
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block(play=object(), parent_block=object(), role=object(), task_include=object(), use_handlers=True, implicit=True)
    data = dict()
    assert block.deserialize(data) is None
    assert block.statically_loaded == True
    assert block.always == []
    assert block.block == []
    assert block.failed_when == False
    assert block.post_validate == []
    assert block.pre_validate == []
    assert block.rescue == []
    assert block.tags == []
    assert block.tasks == []
    assert block._attributes == dict()
    assert block._dep_chain == None
    assert block._parent == None
    assert block._role == None
    assert block._ds == {}
    assert block.args == {}

# Generated at 2022-06-11 09:51:11.013603
# Unit test for method is_block of class Block
def test_Block_is_block():
    data = dict(block=["a"])
    assert Block.is_block(data)

# Generated at 2022-06-11 09:51:21.466533
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    parent_block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    parent_block._dep_chain = None
    parent_block._parent = None
    b = Block(play=None, parent_block=parent_block, role=None, task_include=None, use_handlers=False, implicit=False)
    b._dep_chain = ['1', '2', '3']
    assert b.get_dep_chain() == b._dep_chain

    b._parent = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    b._parent._dep_chain = ['4', '5', '6']
    assert b.get_dep_chain

# Generated at 2022-06-11 09:51:25.569993
# Unit test for method is_block of class Block

# Generated at 2022-06-11 09:51:26.346482
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    assert Block().has_tasks() == False

# Generated at 2022-06-11 09:51:53.993912
# Unit test for method is_block of class Block
def test_Block_is_block():
    """Test case for the function Block.is_block"""

    data = "maslul"
    block_test = Block.is_block(data)
    assert block_test == False



# Generated at 2022-06-11 09:52:03.552374
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext
    
    implicit = True
    #test 1
    #_data = [ ]
    #play = None
    #parent_block = None
    #role = None
    #task_include = None
    #use_handlers = False
    #test 1
    _data = [ ]
    play = Base()
    parent_block = Block()
    role = Base()
    task_include = Base()
    use_handlers = False
    #test 1
    #_data = [ ]
    #play = Base()
    #parent_block = Block()
    #role = Base()
    #task_include = Base()
    #use_handlers = True
    
    

# Generated at 2022-06-11 09:52:09.207479
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # load_list_of_tasks is called inside the preprocess_data method.
    # Hence we are mocking the load_list_of_tasks.
    MockClass = Mock(return_value = 1)
    setattr(Block, "_load_block", MockClass)
    block = Block()
    data = block.preprocess_data("test")
    eq_(data, dict(block=["test"]))


# Generated at 2022-06-11 09:52:13.528093
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    try:
        t = AnsibleTask()
        t.action = 'debug'
        t.args = dict(msg='test debug')
        b = Block(block=[t])
        assert b.has_tasks() == True
    except Exception as e:
        print(repr(e))
        assert False


# Generated at 2022-06-11 09:52:23.157501
# Unit test for method copy of class Block
def test_Block_copy():

    block = Block()
    block.copy()
    assert dict(block._attributes) == {'block': [], 'rescue': [], 'always': []}

    block = Block()
    block.block = [{'name': 'test'}]
    assert dict(block._attributes) == {'block': [{'name': 'test'}], 'rescue': [], 'always': []}
    block.copy()
    assert dict(block._attributes) == {'block': [{'name': 'test'}], 'rescue': [], 'always': []}

    block = Block()
    block.block = [{'name': 'test'}]
    assert dict(block._attributes) == {'block': [{'name': 'test'}], 'rescue': [], 'always': []}
   

# Generated at 2022-06-11 09:52:27.268511
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
  # input arguments for the test
  Block_block = []
  Block_rescue = []
  Block_always = []

  # Test for class Block
  Block_instance = Block()
  Block_instance.block = Block_block
  Block_instance.rescue = Block_rescue
  Block_instance.always = Block_always
  return Block_instance.has_tasks()


# Generated at 2022-06-11 09:52:27.929607
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    pass

# Generated at 2022-06-11 09:52:28.535206
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    pass

# Generated at 2022-06-11 09:52:30.574839
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    loader = 'loader'
    block.set_loader(loader)
    assert block._loader == loader



# Generated at 2022-06-11 09:52:31.885554
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False


# Generated at 2022-06-11 09:52:58.504680
# Unit test for method copy of class Block
def test_Block_copy():
    data = {"i_am":"test_data"}
    b = Block(data)
    b.copy() == data
    return True


# Generated at 2022-06-11 09:53:00.142228
# Unit test for method is_block of class Block
def test_Block_is_block():

    data = Block(use_handlers=False)
    assert True == Block.is_block(data)


# Generated at 2022-06-11 09:53:08.930922
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # prepare test data
    block = Block()
    block2 = Block()
    block3 = Block()
    task1 = Task()
    task2 = Task(tags=['tag1'])
    task3 = Task(tags=['tag2'])
    block.block = [task1, task2, block2, task3, block3]
    block2.block = [task1, task2, task3]
    block2.rescue = [task1, task2, task3]
    block2.always = [task1, task2, task3]
    block3.block = [task1, task2, task3]
    block3.rescue = [task1, task2, task3]
    block3.always

# Generated at 2022-06-11 09:53:10.187924
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block=Block()
    block.deserialize()


# Generated at 2022-06-11 09:53:18.220314
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    print("**** TESTING: test_Block_deserialize")

    # From test_block.yml: 171
    #comments:
    #- |-
    #  # TESTS: tasks/block/deserialize
    #  # TESTS: tasks/block/deserialize:2,3
    #- |-
    #  #TESTS: tasks/block/deserialize:4-6
    #  #TESTS: tasks/block/deserialize:7,8,9

    # From test_block.yml: 176

# Generated at 2022-06-11 09:53:27.964571
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    inventory = InventoryManager(loader=None, sources=None)
    variables = VariableManager(loader=None, inventory=inventory)
    play = Play().load(dict(
        name = "Ansible Play for testing",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', args=dict()))
        ]
    ), variable_manager=variables, loader=None)

    tqm_deps = dict(
        variable_manager=variables,
        loader=None,
        inventory=inventory,
        stdout_callback='default',
    )
    tqm = TaskQueueManager(**tqm_deps)
    tqm._final_q = Queue()
    tqm._failed_hosts = dict()
    tqm

# Generated at 2022-06-11 09:53:32.207276
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks()==False
    block.block=True
    assert block.has_tasks()==True
    block.rescue=True
    assert block.has_tasks()==True
    block.always=True
    assert block.has_tasks()==True



# Generated at 2022-06-11 09:53:41.317887
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handlers.include import HandlerInclude
    def make_task(task_ds):
        task_ds = wrap_var(task_ds)
        return Task.load(task_ds)
    def make_block(block_ds, parents=None, role=None, include=None, handler=None):
        block_ds = wrap_var(block_ds)
        play_ds = {}
        play = Play.load(play_ds)
        if parents is None:
            parents = []

# Generated at 2022-06-11 09:53:50.552181
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude


# Generated at 2022-06-11 09:53:59.055244
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    def test_method_all_parents_static():
        # test case 1
        #
        # {
        #     "block": [
        #         {
        #             "block": []
        #         }
        #     ],
        #     "use_handlers": true
        # }
        test_block = Block(use_handlers=True)
        test_block.load(dict(block=[]))
        test_block.load(dict(block=[test_block.copy()]))

        # test case 2
        #
        # {
        #     "block": [
        #         {
        #             "block": [
        #                 {
        #                     "block": [],
        #                     "always": [],
        #                     "implicit": true,
        #                     "rescue": [],
       