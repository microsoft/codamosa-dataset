

# Generated at 2022-06-11 09:47:11.681940
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():

    # test empty block
    b = Block()

    assert b.preprocess_data({}) == {'block': []}, 'Did not convert empty block to empty list'

    # test simple block
    b = Block()

    assert b.preprocess_data([{'task': 'mytask'}]) == {'block': [{'task': 'mytask'}]}

using_loader()


# Generated at 2022-06-11 09:47:20.993734
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
  print('Test for method filter_tagged_tasks of class Block')
  # Construct a dummy class Block
  class BlockCopy(object):
    def __init__(self):
      self._play = 0
      self.statically_loaded = True
      self._attributes = {}
      self.tags = ['all']
      self.block = []
    def get_dep_chain(self):
      self._dep_chain = []
      return self._dep_chain
    def filter_tagged_tasks(self, all_vars):
      return 0
    def copy(self):
      self.BlockCopy = Block()
      return BlockCopy
  # The filter_tagged_tasks method should return the block with the task lists filtered
  # based on the tags
  a = Block()
  a._play = BlockCopy()
 

# Generated at 2022-06-11 09:47:30.423234
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    data = {'always': [{'has_triggered': False, 'tags': [], 'name': u'always test', 'delegate_to': '127.0.0.1'}],
            'dep_chain': u'[u"TestRole"]',
            'block': [{'has_triggered': False, 'tags': [], 'name': u'debug from block', 'delegate_to': '127.0.0.1'}],
            'other_attr': u'default value'}
    import ansible.playbook.task_include as task_include
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    import ansible.playbook.task as task
    b = Block()
    b.deserialize(data)
    # check the role created in deserial

# Generated at 2022-06-11 09:47:35.191822
# Unit test for method copy of class Block
def test_Block_copy():
    m_data = {}
    p = Play()
    r = Role()
    t = Task()
    b = Block(play=p, role=r, task_include=t)
    b.load_data(m_data)
    b.copy()


# Generated at 2022-06-11 09:47:38.512162
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    orig_b = b
    assert orig_b is b
    copy_b = b.copy()
    assert copy_b is not b
    assert orig_b is b
    assert copy_b is not b


# Generated at 2022-06-11 09:47:40.626957
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'key1': 'value1', 'key2': 'value2'})



# Generated at 2022-06-11 09:47:49.998173
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    b = Block()

    # If a simple task is given, an implicit block for that single task
    # is created, which goes in the main portion of the block
    data1 = dict(handlers=[])
    data1_res = dict(block=[dict(handlers=[])])
    assert b.preprocess_data(data1) == data1_res

    # If a list is given, then the resulting dict is a block containing those
    data2 = dict(block=[])
    data2_res = dict(block=[])
    assert b.preprocess_data(data2) == data2_res

    # If a dict containing "block" is given, then it's a normal block
    data3 = dict(block=dict(block=[]))
    data3_res = dict(block=dict(block=[]))
    assert b.pre

# Generated at 2022-06-11 09:47:59.051854
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    '''
    Subroutine to test the method filter_tagged_tasks of the class Block

    expected_results: expected results of filter_tagged_tasks
    expected_results: expected results when skip_tags is used
    tag_values: values for tags for each task
    skip_tags: skip_tags for the filter_tagged_tasks call
    task_action_include: param for whether tasks are include tasks
    only_tags: only_tags for the filter_tagged_tasks call

    Returns True if the method call has the expected results, else False
    '''
    tag_values = list()
    expected_results = list()
    expected_results_skip = list()
    task_action_include = list()

    class task:
        def __init__(self, action):
            self.action = action
            self

# Generated at 2022-06-11 09:48:00.401069
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    assert block.copy()


# Generated at 2022-06-11 09:48:02.469922
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    '''
    Unit test for method deserialize of class Block
    '''
    # FIXME: implement properly
    pass

# Generated at 2022-06-11 09:48:33.382876
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.parsing.utils.addresses import parse_address
    from ansible.playbook.play import Play
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import fragment_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    import ansible.constants as C
    # Create play
    play = Play()
    # Create block
    block = Block()
    # Create role
    role = Role()
    # Create variable manager
    variable_manager = VariableManager()
    # Create loader
   

# Generated at 2022-06-11 09:48:35.907706
# Unit test for method deserialize of class Block
def test_Block_deserialize():

    # Create a Block object to pass to test function
    block_obj = Block()

    parser_errors = []
    block_obj.deserialize(parser_errors)
    assert parser_errors == []

# Generated at 2022-06-11 09:48:45.984722
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.playbook.handlers.include import Include
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    loader = [
        Base, Task, Include, Block, Play, Playbook, Taggable, RoleInclude, Role
    ]
    loader1 = []
    play = Play()
    role = Role()
    role._loader = loader
    role.set_loader(loader)
    play._loader = loader
    block = Block

# Generated at 2022-06-11 09:48:56.639847
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.task import Task
    b = Block()
    t = Task()
    b.block = [t]
    new_me = b.copy()
    # Assert copy of Block b is set to new_me
    assert new_me.__class__.__name__ == 'Block'
    # Assert copy of Block b has same value for attribute block
    assert new_me.block[0].__class__.__name__ == 'Task'
    # Assert type of attribute block of copy of Block is list
    if six.PY3:
        assert type(new_me.block) is list
    else:
        assert type(new_me.block) is types.ListType

# Generated at 2022-06-11 09:49:07.452503
# Unit test for method deserialize of class Block
def test_Block_deserialize():
  block=Block()
  # serialize with parent
  data={"dep_chain":None,"parent_type":"Block","parent":{"dep_chain":None,"parent_type":"TaskInclude","parent":{"when":{"dep_chain":["when"],"name":"when","statically_loaded":True,"value":"ansible1"},"block":[],"dep_chain":None,"implicit":False,"loop":[],"role":None,"statically_loaded":True,"use_handlers":True}}
  ,
  "role":{"_role_data":{"default_vars":{"ansible1":"ansible2"}},"allow_duplicates":True,"metadata":None},
  "statically_loaded":True,"use_handlers":True}
  block.deserialize(data)
  assert block.get_dep_chain()==None

# Generated at 2022-06-11 09:49:08.505284
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    pass


# Generated at 2022-06-11 09:49:09.513868
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    return True


# Generated at 2022-06-11 09:49:16.695661
# Unit test for method copy of class Block
def test_Block_copy():
    loader = DictDataLoader({'testhost': dict(host_data='test_host_data'),
                             'notesthost': dict(host_data='no_test_host_data')})
    inv_data = HostInventoryData()
    inv_data.get_host('testhost').set_variable('foo', 'bar')
    inv_data.get_host('testhost').set_variable('fizz', 'buzz')
    inv_data.get_host('testhost').set_variable('foobar', [1, 2, 3])
    inv_data.get_host('testhost').set_variable('foobaz', dict(a=1, b=2, c=3))
    inv_data.get_host('testhost').set_variable('ansible_python_interpreter', 'ansible_python')


# Generated at 2022-06-11 09:49:27.941475
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    # (1) tests the parent is None
    b = Block()
    b._parent = None
    assert b.get_first_parent_include()==None

    # (2) tests the parent is not None
    from ansible.playbook.task_include import TaskInclude
    ti = TaskInclude()
    ti._parent = None
    b1 = Block()
    b1._parent = ti
    assert b1.get_first_parent_include()==ti

    from ansible.playbook.task_include import TaskInclude
    ti = TaskInclude()
    ti._parent = None
    b2 = Block()
    b2._parent = ti
    b3 = Block()
    b3._parent = b2
    assert b3.get_first_parent_include()==ti

# Generated at 2022-06-11 09:49:38.272855
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    ds = { 'block' : [], 'rescue' : [], 'always' : [], 'name' : "foo" }
    b = Block()
    b.preprocess_data(ds)
    assert ds == { 'block' : [], 'rescue' : [], 'always' : [], 'name' : "foo" }
    ds = []
    b.preprocess_data(ds)
    assert ds == { 'block' : [], 'rescue' : [], 'always' : [] }


# Generated at 2022-06-11 09:50:24.375716
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become

    PlayContext._init_global_context()
    global_vars = dict()
    play_context = PlayContext(become=Become(), become_method='sudo', become_user='root', connection='ssh', check=False, diff=False, passwords={}, remote_addr='127.0.0.1', port=22, remote_user='user', shell=None, timeout=10, verbosity=3, environment={}, only_tags=[], skip_tags=[], forks=10, module_path=None)
    play_context.set_vars

# Generated at 2022-06-11 09:50:26.605521
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    '''test_Block_filter_tagged_tasks()'''
    #TODO
    pass

# Generated at 2022-06-11 09:50:35.819414
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.vars.unsafe_proxy import wrap_var

    all_vars = {}
    for i in range(4):
        task = Task()
        task._play = {}
        task._attributes = {}
        if i == 0:
            task.tags = ['count']
            task.action = 'count'
        elif i == 1:
            task.tags = ['matrix', 'count']
            task.action = 'count'
        elif i == 2:
            task.tags = ['count']
            task.action = 'assert'
        else:
            task.tags = ['count']
            task.action = 'always'

        task.name = 'task number %d' % i

        task._valid_attrs = {}
        task.environment = {}
        task.registered = {}

# Generated at 2022-06-11 09:50:40.708807
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # This test loads a set of tasks using the load_list_of_tasks
    # function and then sets the loader of the first task in the list
    # to a DummyLoader object. We do not care about the tasks
    # themselves in this test, so we just create a dummy block object
    # to pass to the function and we ignore the return from
    # load_list_of_tasks.
    #
    # As long as the exception is not raised, we consider the test
    # successful.
    data = '''
    - first_task
    - second_task
    '''
    ds = yaml.safe_load(data)

    loader = DummyLoader()
    b = Block(use_handlers=False)
    b.load_data(ds)
    b.set_loader(loader)


# Generated at 2022-06-11 09:50:52.304509
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test init and copy of Block
    block = Block()
    assert block.name == 'Default Block'

    block_copy = block.copy(exclude_parent=False)
    # Test parameter exclude_parent of copy method
    assert block.name == block_copy.name

    # Test parameter exclude_tasks of copy method
    block_copy = block.copy(False,True)
    assert block_copy.block == []
    assert block_copy.rescue == []
    assert block_copy.always == []

    # Test serialize and deserialize of Block

# Generated at 2022-06-11 09:50:54.296332
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    b = Block()
    ret = b.filter_tagged_tasks(all_vars={})
    assert ret



# Generated at 2022-06-11 09:50:55.264612
# Unit test for method copy of class Block
def test_Block_copy():
    assert False # TODO: implement your test here


# Generated at 2022-06-11 09:51:04.960939
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude

    block = Block()
    task = Task()
    include = TaskInclude()

    block.statically_loaded = True
    task.statically_loaded = True
    include.statically_loaded = True

    assert task.all_parents_static() == True

    block.statically_loaded = False
    task.statically_loaded = True
    include.statically_loaded = True
    task._parent = block
    assert task.all_parents_static() == False

    block.statically_loaded = True
    task.statically_loaded = True
    include.statically_loaded = False
    task._parent = include
    assert task.all_parents_static

# Generated at 2022-06-11 09:51:15.060927
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    def _check_task_lists(block_before, block_after):
        assert len(block_before.block) == len(block_after.block)
        assert len(block_before.rescue) == len(block_after.rescue)
        assert len(block_before.always) == len(block_after.always)
        assert len(block_before.rescue) == len(block_after.rescue)
        assert len(block_before.always) == len(block_after.always)
        for task_before, task_after in zip(block_before.block, block_after.block):
            assert task_before.action == task_after.action
            assert task_before.name == task_after.name
            if task_before.action == 'include':
                assert task_before.include_name == task_

# Generated at 2022-06-11 09:51:20.837958
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    b = Block()
    i = TaskInclude()
    b._parent = i
    assert b.get_first_parent_include() == i

    i._parent = b
    assert b.get_first_parent_include() == i

    a = Block()
    a._parent = b
    assert a.get_first_parent_include() == i



# Generated at 2022-06-11 09:51:56.436896
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    host_list = [
        # Unreachable host
        {
            'hostname': '192.168.1.1',
            'port': 2222,
            'username': 'vagrant',
            'private_key_file': '~/.vagrant.d/insecure_private_key',
        }
    ]

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hosts': 'mywebservers'}

    inventory = Inventory(
        loader=loader,
        variable_manager=variable_manager,
        host_list=host_list
    )
    variable_manager.set_inventory(inventory)
    pb = Playbook.load(pb_path, variable_manager=variable_manager, loader=loader)
    play = pb.get_plays()[0]
   

# Generated at 2022-06-11 09:52:06.365039
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.helpers import load_list_of_tasks
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    import os

    # test data
    parser = AnsibleBaseYAMLObject()

# Generated at 2022-06-11 09:52:16.593280
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    import pytest

    def test_only_static_block_parents():
        # Create Block A
        # Create Block B
        # Create Task C
        # Make C a child of B, B a child of A
        # Make sure all parents are static

        block_a = Block(statically_loaded = True)
        block_b = Block(statically_loaded = True)
        task_c = Task()

        block_b.block = [task_c]
        block_a.block = [block_b]

        task_c.parent = block_b
        block_b.parent = block_a

        assert task_c.all_parents_static() == True


# Generated at 2022-06-11 09:52:25.100594
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    my_block = Block()

    my_block.block = [
        'this is a task',
        'this is another task'
    ]

    my_block.rescue = [
        'this is a rescue task',
        'this is another rescue task'
    ]

    my_block.always = [
        'this is an always task',
        'this is another always task'
    ]

    my_block._role = 'my_role'

    my_block.dep_chain = [
        'this is a dependency chain',
        'this is another dependency chain'
    ]

    my_block._variable_manager = 'my_variable_manager'

    my_block._loader = 'my_loader'

    my_block._play = 'my_play'


# Generated at 2022-06-11 09:52:27.041631
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    result = block.copy()
    assert result.__class__.__name__ == 'Block'


# Generated at 2022-06-11 09:52:28.322755
# Unit test for method copy of class Block
def test_Block_copy():
    print("Test for method copy for class Block")
    pass

# Generated at 2022-06-11 09:52:38.020105
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    import unittest
    import sys
    from collections import Mapping
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    def _init_Block(args):
        init_args = {}
        for k, v in args.items():
            init_args[k.lstrip('_')] = v
        return Block(**init_args)

    class FakeRoleInclude(RoleInclude):
        def __init__(self, _dep_chain, _loader, _parent, _role):
            Role

# Generated at 2022-06-11 09:52:39.210104
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    assert True == True

# Generated at 2022-06-11 09:52:41.667245
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    i = TaskInclude()
    b = Block()
    b._parent = i

    assert not b.all_parents_static()


# Generated at 2022-06-11 09:52:47.331860
# Unit test for method copy of class Block
def test_Block_copy():
    import copy
    from ansible.module_utils.six import string_types

    # some of this should be moved to the base class for testing
    static_data = dict(
        block=[
            dict(
                include=dict(
                    tasks='test.yml',
                ),
            ),
            dict(
                include=dict(
                    tasks='thing.yml',
                    tags='test',
                ),
            ),
        ],
    )
    static_loader = DataLoader()
    static_vars = {}
    b = Block.load(static_data, variable_manager=VariableManager(loader=static_loader, host_vars=static_vars), loader=static_loader)
    b_new = b.copy()

    if not isinstance(b, type(b_new)):
        return False

# Generated at 2022-06-11 09:53:11.999569
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    A = Block(dep_chain=None)
    assert A._dep_chain is None


# Generated at 2022-06-11 09:53:20.071004
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    b = Block.load(dict(
        block=[
            dict(debug=dict(msg="{{ my_test }}"))
        ]
    ), loader=loader, variable_manager=VariableManager())

    assert b is not None
    assert b.block is not None
    assert len(b.block) == 1
    assert b.block[0] is not None
    assert b.block[0].register == 'debugger'

    block_copy = b.copy()
    assert block_copy is not None
    assert block_copy.block is not None
    assert len(block_copy.block) == 1
    assert block_copy.block[0] is not None
    assert block_copy.block[0].register == 'debugger'

# Generated at 2022-06-11 09:53:30.112621
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole

    # block = Block(block = [])
    if Block().filter_tagged_tasks(None):
        print("Test 1 passed.")
    else:
        raise ValueError("Test 1 Failed.")

    # block = Block(block = None)
    if Block(block = None).filter_tagged_tasks(None):
        print("Test 2 passed.")
    else:
        raise ValueError("Test 2 Failed.")

    # block = Block(block = tag_tasks)
    tag_tasks = [Task(action = "setup"), Task(action = "setup"), Task(action = "setup")]

# Generated at 2022-06-11 09:53:38.101484
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    b = Block()
    assert b.get_first_parent_include()==None
    b._parent = TaskInclude()
    assert b.get_first_parent_include()==b._parent

if __name__ == "__main__":
    import sys, inspect
    members = inspect.getmembers(sys.modules[__name__], inspect.isfunction)
    for (name, member) in members:
        if name.startswith("test_"):
            print("executing " + name)
            member()

# Generated at 2022-06-11 09:53:46.273782
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # create instance of Task to be used as parent
    task = Task()
    task.static_loader = True
    task._role = None

    # create instance of Block to be copied
    block = Block(play=None, parent_block=task, role=None, task_include=None, use_handlers=False, implicit=True)
    block._dep_chain = 'test_dep_chain'
    block._attributes = {'attr1': 'attr1_value', 'attr2': 'attr2_value'}

    # call method
    new_block = block.copy(exclude_parent=True)

    # assertions
    assert new_block.get_dep_chain() == 'test_dep_chain'
    assert new

# Generated at 2022-06-11 09:53:52.357029
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    parent = Block()
    task = Task()
    task._parent = parent
    assert task.get_first_parent_include() is None

    parent = Task()
    grand_parent = TaskInclude()
    great_grand_parent = Task()
    grand_parent._parent = great_grand_parent
    parent._parent = grand_parent
    task = Task()
    task._parent = parent
    assert task.get_first_parent_include() == grand_parent



# Generated at 2022-06-11 09:53:53.293587
# Unit test for method copy of class Block
def test_Block_copy():
    pass


# Generated at 2022-06-11 09:53:59.357236
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    '''
    unit test: test_Block_all_parents_static
    '''
    temp_all_vars = {"TAGS": ['xxxx']}
    temp_block = Block()
    temp_block.block = []
    temp_block.rescue = []
    temp_block.always = []
    temp_block._dep_chain = None
    temp_block._parent = None
    temp_block._role = None
    temp_block.validate()

    assert temp_block.all_parents_static() == True

# Generated at 2022-06-11 09:54:07.945959
# Unit test for method copy of class Block
def test_Block_copy():
    obj = Block()

    # calling Block copy() without arguments
    # you can options "exclude_parent" to override its default value
    # you can options "exclude_tasks" to override its default value
    result = obj.copy()
    assert result is not None

    # calling Block copy() with arguments
    # you can options "exclude_parent" to override its default value
    # you can options "exclude_tasks" to override its default value
    result = obj.copy(exclude_parent=True)
    assert result is not None

    # calling Block copy() with arguments
    # you can options "exclude_parent" to override its default value
    # you can options "exclude_tasks" to override its default value
    result = obj.copy(exclude_tasks=True)
    assert result is not None

   

# Generated at 2022-06-11 09:54:17.301888
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    task_one = Task()
    task_one.action = 'one'
    task_one.only_if = "a or b"
    task_one.when = 'c and d'
    task_one.tags = ['a', 'b', 'c', 'd']
    task_one_blk = Block(block=[task_one])

    task_two = Task()
    task_two.action = 'two'
    task_two.tags = ['a', 'b']
    task_two.only_if = "a and b"
    task_two

# Generated at 2022-06-11 09:54:50.684455
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # this is a unit test for method has_tasks of class Block
    # set up
    block = Block()
    assert(block.has_tasks() == False)
    test_task = Task()
    test_task.name = 'test_task'
    test_task.action = 'shell'
    test_task.args = {'argv': 'ls'}
    assert(block.has_tasks() == False)
    block.block.append(test_task)
    # run
    block.has_tasks()
    # assert
    assert(block.has_tasks() == True)
    # teardown
    block.block.remove(test_task)
    assert(block.has_tasks() == False)
    return True

# Generated at 2022-06-11 09:54:55.262119
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize(args)
    assert block._dep_chain == ['/home/gavin/sandbox/ansible_collections/notmintest/not_a_real_collection/roles/test_role/library/test.py']
    assert block._name == 'test'
    assert block._role.get_name() == 'test_role'

# Generated at 2022-06-11 09:54:57.264852
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    b = Block()
    ret = b.filter_tagged_tasks('SomeTags')
    assert type(ret) is Block


# Generated at 2022-06-11 09:55:06.051547
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    a = Block()
    a.action = 'debug'
    a.tags = ['a']
    b = Block()
    b.action = 'debug'
    b.tags = ['b']
    c = Block()
    c.action = 'debug'
    c.tags = ['c']

    d = Block()
    d.block = [a, b]
    d.rescue = [c]

    assert d.filter_tagged_tasks({}) == d

    d = Block()
    d.block = [a, b]
    d.rescue = [c]
    d.tags = ['a']

    assert d.filter_tagged_tasks({}) == d

    d = Block()
    d.block = [a, b]
    d.rescue = [c]

# Generated at 2022-06-11 09:55:11.377364
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    block = Block()
    task_include = TaskInclude()
    play_context = PlayContext()
    task_include._parent = block
    play_context.set_loader(DataLoader())
    block._play = play_context
    assert task_include.get_first_parent_include() == task_include


# Generated at 2022-06-11 09:55:13.990288
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    block = Block(statically_loaded=False, parent=TaskInclude(statically_loaded=False))
    assert block.all_parents_static() is False

# Generated at 2022-06-11 09:55:23.311996
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # globally disable log output
    logger = logging.getLogger('ansible.playbook')
    old_propagate = logger.propagate
    logger.propagate = False

    def _make_block(block_data):
        block = Block()
        block.load(block_data)
        return block

    def _make_tasks(tasks_data):
        tasks = []
        for t in tasks_data:
            task = Task()
            task.load(t)
            tasks.append(task)
        return tasks

    # case 1
    # input1:
    #   - block:
    #       - debug: msg="this part 1"
    #         tags: ["test1", "test2"]
    #     rescue:
    #       - debug: msg="test rescue 1"
    #         tags: ["test

# Generated at 2022-06-11 09:55:34.206178
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    # []
    b = Block()
    assert b.all_parents_static() is True
    # [{"task_include":{"block":{}}}]
    ti = TaskInclude()
    ti.statically_loaded = False
    ti.task_include = {"block":{}}
    b.block.append(ti)
    assert b.all_parents_static() is False
    # [{"task_include":{"block":{"block":{}}}}, {"task_include":{"block":{}}}]
    bi = Block()
    ti = TaskInclude()
    ti.statically_loaded = False
    ti.task_include = {"block":{}}
    bi.block.append(ti)
    ti = TaskInclude()
    ti.statically_loaded = False
   

# Generated at 2022-06-11 09:55:37.674646
# Unit test for method copy of class Block
def test_Block_copy():
    # Tests if after copying the properties are identical
    play = Play().load({},variable_manager={},loader=None)
    role = Role()
    block = Block(play=play, role=role)
    assert block.copy() == block


# Generated at 2022-06-11 09:55:40.462702
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # initialize a block
    b = Block()
    # initialize a task
    t = Task()
    # add tasks to block
    b.add_task(t)

# Generated at 2022-06-11 09:56:31.250458
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block(
        block=[
            TaskFail(msg=dict(other='value'))
        ]
    )
    c = b.copy(exclude_tasks=True)
    assert c != b
    d = b.copy()
    assert d == b
test_Block_copy()