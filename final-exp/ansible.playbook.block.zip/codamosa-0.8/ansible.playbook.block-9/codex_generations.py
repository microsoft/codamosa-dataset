

# Generated at 2022-06-11 09:46:55.662809
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    c = Block()

    b = c.preprocess_data(None)
    assert b == dict(block=None)

    b = c.preprocess_data([])
    assert b == dict(block=[])

    b = c.preprocess_data([{'param': 'value'}])
    assert b == dict(block=[{'param': 'value'}])

    b = c.preprocess_data(dict(block=[]))
    assert b == dict(block=[])

    b = c.preprocess_data(dict(block=[{'param': 'value'}]))
    assert b == dict(block=[{'param': 'value'}])


# Generated at 2022-06-11 09:47:04.433862
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager

    task1 = Task()
    task1.set_loader(DictDataLoader({}))
    task1._role = Role()
    task1._role.set_loader(DictDataLoader({}))
    task1._variable_manager = VariableManager()

    task2 = Task()
    task2.set_loader(DictDataLoader({}))
    task2._role = Role()
    task2._role.set_loader(DictDataLoader({}))
    task2._variable_manager = VariableManager()

    task3 = Task()
    task3.set_loader(DictDataLoader({}))

# Generated at 2022-06-11 09:47:05.031172
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    pass

# Generated at 2022-06-11 09:47:12.170451
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    block_1=Block()
    block_2=Block(play=PlayContext(), loader=None,variable_manager=None,use_handlers=True,parent_block=None,role=Role(),task_include=None,implicit=False,statically_loaded=False,dep_chain=None)
    block_1.deserialize(block_2.serialize())


# Generated at 2022-06-11 09:47:13.409632
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    pass # TODO: implement your test here


# Generated at 2022-06-11 09:47:18.306147
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block = Block()
    assert block.get_dep_chain() == None
    block._dep_chain = []
    assert block.get_dep_chain() == []
    block._parent = Block()
    assert block.get_dep_chain() == None
    block._parent = None
    block._dep_chain = None
    assert block.get_dep_chain() == None



# Generated at 2022-06-11 09:47:22.136924
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    my_Block = Block(play=None,parent_block=None,role=None,task_include=None,use_handlers=False,implicit=False)
    result = my_Block.set_loader(loader=None)
    assert (result == None)


# Generated at 2022-06-11 09:47:31.604383
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Always_run test
    assert Block(always_run=True)._attributes['always_run']
    # actions test
    assert Block(actions=['a','b','c'])._attributes['actions'] == ['a','b','c']
    # block test
    assert Block(block=['a','b','c'])._attributes['block'] == ['a','b','c']
    # delegate_to test
    assert Block(delegate_to='a')._attributes['delegate_to'] == 'a'
    # delegate test
    assert Block(delegate={'a':'b'})._attributes['delegate'] == {'a':'b'}
    # ignore_errors test
    assert Block(ignore_errors=True)._attributes['ignore_errors']
    # local_action test
    assert Block

# Generated at 2022-06-11 09:47:42.467989
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    b = Block()

# Generated at 2022-06-11 09:47:51.513143
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    first_task = Task()
    first_task.set_loader('Test_loader')
    first_task.action = 'ping'
    first_task.set_loader('Test_loader')
    first_task.tags = ""
    first_task.args = ""
    second_task = Task()
    second_task.action = 'ping'
    second_task.tags = "always"
    second_task.args = ""
    second_task.set_loader('Test_loader')
    third_task = Task()
    third_task.action = 'ping'
    third_task.tags = "deploy_app"
    third_task.args = ""
    third_task.set_loader('Test_loader')
   

# Generated at 2022-06-11 09:49:08.955338
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    class _Base(Base):
        _valid_attrs = frozenset((
            'name',
            'shares',
            'any_errors_fatal',
            'always_run',
            'serial',
        ))
        _default_attrs = frozenset((
            'any_errors_fatal',
            'always_run',
            'serial',
        ))

    role = Role().load(dict(
        name='test',
        hosts='test',
        any_errors_fatal='no',
        always_run='no',
        serial='50%',
    ))
    parent = _Base()
    parent._valid_attrs = role._valid_attrs
    parent._default_attrs = role

# Generated at 2022-06-11 09:49:11.046110
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    loader = DictDataLoader({})
    b = Block()
    b.set_loader(loader)

    assert(b._loader == loader)

# Generated at 2022-06-11 09:49:17.436945
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    # test no parent exists
    b1 = Block()
    result1 = b1.all_parents_static()
    assert(result1)
    # test with TaskInclude parent
    b2 = Block()
    ti = TaskInclude()
    b2._parent = ti
    ti._parent = b2
    b2._implicit = True
    result2 = b2.all_parents_static()
    assert(result2 == False)
    # test with non-TaskInclude parent
    b3 = Block()
    b4 = Block()
    b3._parent = b4
    b4._parent = b3
    b3._implicit = True
    result3 = b

# Generated at 2022-06-11 09:49:30.131995
# Unit test for method deserialize of class Block
def test_Block_deserialize():
  data1 = dict(_dep_chain=[])
  data1['_attributes'] = dict(_parent=None, _play=None, _role=None, _dep_chain=[], _use_handlers=False, _block=None, _rescue=None, _always=None, _name='block test', _static=False, _environment=None, _when=None, _any_errors_fatal=None, _changed_when=None, _failed_when=None, _ignore_errors=None)
  data1['_role'] = None
  parent = Block()
  parent._play = None
  parent._role = None
  parent._dep_chain = []
  parent._block = None
  parent._rescue = None
  parent._always = None
  data2 = dict(_dep_chain=[])

# Generated at 2022-06-11 09:49:40.636750
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block(
        block=[
            dict(
                block= [
                    dict(when="1"), dict(when="2"), dict(when="3"),
                    dict(block=[
                        dict(when="4"), dict(when="5"), dict(when="6"),
                    ]),
                    dict(block=[
                        dict(when="7"), dict(when="8"), dict(when="9"),
                    ]),
                    dict(when="10"), dict(when="11"), dict(when="12"),
                ]
            ),
            dict(
                block=[]
            )
        ]
    )
    assert b.has_tasks()

# Generated at 2022-06-11 09:49:43.706291
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():

    print("Test: test_Block_get_dep_chain")

    #print "Testing Block.get_dep_chain method"

    # TODO: write test for Block.get_dep_chain method


# Generated at 2022-06-11 09:49:50.670429
# Unit test for method get_dep_chain of class Block

# Generated at 2022-06-11 09:49:55.248993
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    fake_play = Play()
    fake_play.load = MagicMock(return_value=None)
    fake_play.serialize = MagicMock(return_value=None)
    block = Block(play=fake_play, use_handlers=True)
    assert block.has_tasks() == False, "Block.has_tasks returned wrong value"


# Generated at 2022-06-11 09:49:57.822612
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'action': 'myaction', 'name': 'myname'})
    assert block.action == 'myaction'
    assert block.name == 'myname'

# Generated at 2022-06-11 09:50:00.701641
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    b = Block()
    assert b.get_dep_chain() == None
    b.dep_chain = [1, 2, 3]
    assert b.get_dep_chain() == [1, 2, 3]


# Generated at 2022-06-11 09:50:29.234863
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # Constructor Block(self, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    # Test if an AttributeError is raised when deserialize is called without a
    # dictionary
    with pytest.raises(AttributeError) as excinfo:
        block.deserialize(data='123')
    # Verify the exception raised
    assert excinfo.value.args[0] == 'data must be a dictionary'

    with pytest.raises(AnsibleUndefinedVariable) as excinfo:
        block.deserialize(data={'name': 'AnsibleUndefinedVariable'})
    #

# Generated at 2022-06-11 09:50:35.337293
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # Setup
    block = Block()
    # Exercise
    for i in range(20):
        ds = random_data()
        # Verify
        if not Block.is_block(ds):
            if isinstance(ds, list):
                assert block.preprocess_data(ds) == {'block': ds}
            else:
                assert block.preprocess_data(ds) == {'block': [ds]}
        else:
            assert block.preprocess_data(ds) == ds
    

# Generated at 2022-06-11 09:50:36.841494
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block = Block()
    result = block.get_dep_chain()
    assert not result

# Generated at 2022-06-11 09:50:48.529771
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    _play = Play().load(load_fixture('dep_chain_play.yml'), variable_manager=variable_manager, loader=loader)
    for block in _play.compile():
        if block.get_name() == 'test':
            assert block.get_dep_chain() == None
            assert block._dep_chain == None
        if block.get_name() == 'test2':
            assert block.get_dep_chain() == ['test']
            assert block._dep_chain == ['test']
        if block.get_name() == 'test3':
            assert block.get_dep_chain() == ['test', 'test2']
            assert block._dep_chain == ['test', 'test2']

# Generated at 2022-06-11 09:50:52.091731
# Unit test for method copy of class Block
def test_Block_copy():
    i = Block()
    i.deserialize({"always": [{"action": "something"}], "block": [{"action": "something"}], "dep_chain": None, "rescue": [{"action": "something"}]})
    assert i.copy()

# Generated at 2022-06-11 09:50:57.644432
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    # test when self_parent._parent is None
    assert Block().all_parents_static() == True

    # test when self._parent._parent is not None
    assert Block(parent=TaskInclude()).all_parents_static() == True

    # test when self._parent._parent is not None
    assert Block(parent=TaskInclude(parent=TaskInclude(parent=Block()))).all_parents_static() == True


# Generated at 2022-06-11 09:51:06.250944
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    data = {"use_handlers": False, "block": [{"action": "ping", "__ansible_module__": "ping", "__ansible_arguments__": {"data": {"interval": 0.1, "dst": "localhost", "timeout": 30, "count": 10}}, "__ansible_action_args__": {"data": {"interval": 0.1, "dst": "localhost", "timeout": 30, "count": 10}}}], "always": [], "register": "ping_localhost", "rescue": []}
    b = Block()
    b.deserialize(data)
    assert b is not None


# Generated at 2022-06-11 09:51:07.326487
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    pass
# unit tests for class RoleInclude

# Generated at 2022-06-11 09:51:09.351176
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = Block()
    all_vars = {}
    assert block.filter_tagged_tasks(all_vars) == block

# Generated at 2022-06-11 09:51:19.799485
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-11 09:51:44.827020
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    test_block = []
    block = Block()
    assert block.preprocess_data(test_block) == {"block": test_block}


# Generated at 2022-06-11 09:51:54.617776
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # create a fake task with a list for attribute: tasks
    task = {
        'name': 'fake task',
        'tasksFile': 'my_tasks_file.yml',
        'tasks': ['block', 'rescue', 'always'],
        'block': ['block', 'rescue', 'always'],
        'rescue': ['block', 'rescue', 'always'],
        'always': ['block', 'rescue', 'always'],
    }
    # create a fake parent play
    play = Play()
    # create a fake parent block
    parent_block = Block(play)
    # call the method preprocess_data() of class Block
    b = Block.load(task, play, parent_block)
    # assert in the correct values
    assert b.name == 'fake task'
    assert b

# Generated at 2022-06-11 09:51:58.339778
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    data = dict(dep_chain=['a'], role=dict(name='test_name'), parent=dict(name='test_name'), parent_type='test_parent_type')
    result = block.deserialize(data)
    assert result == None


# Generated at 2022-06-11 09:52:08.286000
# Unit test for method copy of class Block
def test_Block_copy():
   t = Block()
   t.block = [
      load_list_of_tasks(
         [],
         play=None,
         block=None,
         role=None,
         task_include=None,
         variable_manager=None,
         loader=None,
         use_handlers=False),
      load_list_of_tasks(
         [],
         play=None,
         block=None,
         role=None,
         task_include=None,
         variable_manager=None,
         loader=None,
         use_handlers=False)]

# Generated at 2022-06-11 09:52:14.130100
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    switcher = {
        Block: 'block',
        Rescue: 'rescue',
        Always: 'always',
    }
    b = Block()
    if b.__class__.__name__ in switcher:
        ret = switcher[b.__class__.__name__]
    else:
        ret = 'block'
    assert b.preprocess_data(ret) == 'block'
test_Block_preprocess_data()


# Generated at 2022-06-11 09:52:23.664944
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.become import Become
    from ansible.playbook.become_options import BecomeOptions
    from ansible.playbook.helpers import load_list_of_tasks
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    import mock
    import os

    # Initialise some test variables
    data = {'block': [{'name': 'first task', 'tags': ['first']},
                      {'name': 'second task', 'tags': ['second']},
                      {'name': 'third task', 'tags': ['third']}]}

# Generated at 2022-06-11 09:52:31.984380
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.task import Task
    block = Block(play=None)
    assert block.get_first_parent_include() is None
    #
    task_include = TaskInclude(play=None)
    block._parent = task_include
    assert block.get_first_parent_include() is task_include
    #
    task = Task(play=None)
    block._parent = task
    assert block.get_first_parent_include() is None
    #
    task_include = TaskInclude(play=None)
    task._parent = task_include
    assert block.get_first_parent_include() is task_include
#
#
#

# Generated at 2022-06-11 09:52:42.669428
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    import ansible.playbook
    import ansible.playbook.block
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.task
    import ansible.inventory
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.runner
    import ansible.callbacks
    import ansible.vars

    # test cases for list of one task, which is neither tagged nor skipped, and another task, which is tagged
    test_block = ansible.playbook.block.Block()
    test_task_1 = ansible.playbook.task.Task()
    test_task_1.tags = ['tag1']
    test_task_2 = ansible.playbook.task.Task()

# Generated at 2022-06-11 09:52:47.503247
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # Assign
    obj = Block(None, None, None, [], False)
    ds = 'missing_field'

    # Action
    ret = obj.preprocess_data(ds)

    # Assert
    assert "block" in ret
    assert ret["block"] == ds
    assert ds == ret

# Generated at 2022-06-11 09:52:57.909095
# Unit test for method copy of class Block
def test_Block_copy():
    parent = Parent()
    b = Block(parent=parent)
    new_parent = Parent()

# Generated at 2022-06-11 09:53:43.675078
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    b = Block(play=PlayContext())
    b_sp = Block(play=PlayContext())
    b_sp.statically_loaded = False
    t = TaskInclude(play=PlayContext())
    t.statically_loaded = False
    t_sp = TaskInclude(play=PlayContext())
    t_sp.statically_loaded = False
    h = HandlerTaskInclude(play=PlayContext())
    h.statically_loaded = False
    h_sp = HandlerTaskInclude(play=PlayContext())
    h_sp.statically_loaded = False
    b._parent = b_sp
    b_sp.parent = t
    b_sp.parent = t_sp


# Generated at 2022-06-11 09:53:46.083794
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b.test = 1
    b2 = b.copy()
    assert b2
    assert b2.test == 1


# Generated at 2022-06-11 09:53:55.383688
# Unit test for method copy of class Block
def test_Block_copy():
    """
    Tests for method copy of class Block
    """
    # create an instance of the class
    from ansible.parsing import vault
    from ansible.parsing.vault import VaultLib
    vault_secret = '$ANSIBLE_VAULT;1.1;AES256\r\n3338373233306133383838326565363639353662333339656136653933386638343366646264\r\ntr6j8g26ee66955fb39ea6e938f843fdbd\r\n'
    password = 'testpass'
    vault_id = 'test-vault-id'
    vault_password = 'test_vault_password'
    vault_password_file = 'test_vault_password_file'

# Generated at 2022-06-11 09:53:58.745508
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    pb = Play()
    pb.vars = dict()
    t1 = Task()
    t1.block = [t1]
    pb.tasks = [t1]
    b = Block()
    b.set_loader(pb)

# Generated at 2022-06-11 09:54:01.278173
# Unit test for method copy of class Block
def test_Block_copy():
    my_block=Block()
    my_block_copy=my_block.copy()
    print(my_block_copy,my_block)
    assert my_block==my_block_copy

# Generated at 2022-06-11 09:54:04.544581
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    ta = Task()
    bi= Block()
    bi._parent = ta
    ta2 = Task()
    ti = TaskInclude()
    ti._parent = ta2
    ta2._parent = bi
    assert ti.get_first_parent_include() == ti

# Generated at 2022-06-11 09:54:13.439182
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.plugins.loader import get_all_plugin_loaders

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_

# Generated at 2022-06-11 09:54:16.849667
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    block.deserialize({'parent': None, 'block': [], 'dep_chain': None, 'rescue': [], 'always': [], 'role': None, 'loop': None})

# Generated at 2022-06-11 09:54:18.964213
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # Object instantiation without any mandatory arguments
    my_obj = Block()
    my_obj.preprocess_data("Test string")


# Generated at 2022-06-11 09:54:28.647481
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create objects of classes "Block" and "TaskInclude"
    block_obj = Block()
    task_include_obj = TaskInclude()
    # Calling the method "all_parents_static" of class "Block" with objects of class "Block" and "TaskInclude" as parents
    assert block_obj.all_parents_static() == True

    # Setting the parent of class "Block" object to class "TaskInclude" object
    block_obj.set_parent(task_include_obj)
    # Calling the method "all_parents_static" of class "Block" with object of class "TaskInclude" as parent
    # The method should return False as the parents are not static
    assert block_obj.all_parents_static() == False

    # Setting the parent of class "TaskInclude" object to class "Block" object
   

# Generated at 2022-06-11 09:55:01.514362
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    '''
    Unit test for method has_tasks of class Block
    '''
    print('Test has_tasks() of Block')
    test_block = Block()
    assert test_block.has_tasks() == False
    test_block.block = [{'action': 'debug', 'msg': '>hello world<'}, {'action': 'debug', 'msg': '>hello world<'}]
    assert test_block.has_tasks() == True
    test_block.rescue = [{'action': 'debug', 'msg': '>hello world<'}, {'action': 'debug', 'msg': '>hello world<'}]
    assert test_block.has_tasks() == True

# Generated at 2022-06-11 09:55:10.370814
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    # create some hosts
    host_test1 = Host(name="test1")
    host_test2 = Host(name="test2")
    # create a group and add hosts to it
    group = Group(name="group_test")
    group.add_host(host_test1)
    group.add_host(host_test2)
    # create inventory and set the group as host of it
    inventory=Inventory()
    inventory.add_group(group)
    # create play
    from ansible.playbook.play import Play

# Generated at 2022-06-11 09:55:19.123517
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    my_obj = Task()
    my_obj.deserialize({'name': 'foobar'})
    assert my_obj.name == 'foobar'

    my_obj = TaskInclude()
    my_obj.deserialize({'name': 'foobar'})
    assert my_obj.name == 'foobar'

    my_obj = HandlerTaskInclude()
    my_obj.deserialize({'name': 'foobar', 'handlers': ['bar']})
    assert my_obj.name == 'foobar'

# Generated at 2022-06-11 09:55:29.901199
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    obj = Block()

# Generated at 2022-06-11 09:55:39.127534
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    host = MagicMock()
    host.get_vars.return_value = dict()
    task1 = Task(play=MagicMock(), block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    task2 = Task(play=MagicMock(), block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    data = dict(block=[task1.serialize(), task2.serialize()])
    block = Block(play=None, block=None, role=None, task_include=None, use_handlers=None, implicit=None)
    block.deserialize(data)


# Generated at 2022-06-11 09:55:40.722170
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    assert True == Block().get_first_parent_include()

# Generated at 2022-06-11 09:55:47.576757
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Setup
    block = Block(play=dict(), parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    block.statically_loaded = False
    block.parent = Block(play=dict(), parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    block.parent.statically_loaded = True

    # Execute
    result = block.all_parents_static()

    # Assert
    assert not result, "The returned value is incorrect"

# Generated at 2022-06-11 09:55:56.132965
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-11 09:56:01.705421
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block_dict = dict(a=123, b=234, c=345, d=[1, 2, 3])
    block_deserialized = Block.deserialize(block_dict)
    assert type(block_deserialized) is Block
    assert block_deserialized.a == 123
    assert block_deserialized.b == 234
    assert block_deserialized.c == 345
    assert block_deserialized.d == [1, 2, 3]


# Generated at 2022-06-11 09:56:09.387202
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # pylint: disable=undefined-variable
    """
    Test method filter_tagged_tasks of class Block
    """
