

# Generated at 2022-06-11 09:46:59.030915
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    pass  # TODO

###
### MODULE IMPORT
###

# Generated at 2022-06-11 09:47:06.922253
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.role_include import IncludeRole
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.errors import AnsibleParserError
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    role_dir1 = 'test/integration/targets/block/role2'
    file_name = 'main.yml'
    name = 'main'


# Generated at 2022-06-11 09:47:09.216827
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    
    block = Block()
    block._parent = None
    parent = block.get_first_parent_include()
    assert (parent == None)



# Generated at 2022-06-11 09:47:10.528533
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    assert False



# Generated at 2022-06-11 09:47:11.092404
# Unit test for method deserialize of class Block
def test_Block_deserialize():
  pass

# Generated at 2022-06-11 09:47:20.263636
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():

    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext(tags=['tag_1'], skip_tags=['skip_tag_1'], only_tags=['only_tag_1'])

# Generated at 2022-06-11 09:47:22.823845
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block=Block()
    data=block.serialize()
    block.deserialize(data)
    assert block.serialize() == data


# Generated at 2022-06-11 09:47:23.804444
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    pass # TODO

# Generated at 2022-06-11 09:47:34.261935
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    ds = dict(block=[dict(name="test name")])
    b = Block()
    b.preprocess_data(ds)
    assert b.block[0].name == 'test name'
    ds = [dict(name="test name")]
    b.preprocess_data(ds)
    assert b.block[0].name == 'test name'
    b.preprocess_data(dict(name="test name"))
    assert b.block[0].name == 'test name'
    b = Block()
    ds = dict(block=[dict(name="test name")])
    b.preprocess_data(ds)
    assert b.block[0].name == 'test name'
    ds = [dict(name="test name")]
    b.preprocess_data(ds)
    assert b.block

# Generated at 2022-06-11 09:47:44.167697
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    def get_expected_data():
        block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
        block.block = [Task()]
        block.rescue = [Task()]
        block.always = [Task()]
        return block

    # create source
    block = get_expected_data()

    # make expected new block
    expected_block = get_expected_data()
    # perform action
    new_block = block.copy(exclude_parent=False, exclude_tasks=False)

    assert expected_block.block == new_block.block
    assert expected_block.rescue == new_block.rescue
   

# Generated at 2022-06-11 09:48:32.160686
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    import json
    data_path = 'data/playbooks/test/filter_blocks/'
    play_data = json.load(open(data_path + 'initial_play.json'))
    play_data_expect = json.load(open(data_path + 'expected_play.json'))
    play = Play().load(play_data, variable_manager=VariableManager(), loader=DictDataLoader())
    play.filter_tagged_tasks(dict())
    play_data = play.serialize()
#     import pdb; pdb.set_trace()
    assert play_data == play_data_expect

    play_data = json.load(open(data_path + 'initial_play_2.json'))

# Generated at 2022-06-11 09:48:35.130151
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block = Block()
    ref = Block()
    b2 = Block()
    ti = TaskInclude()
    block._parent = ti
    ti._parent = ref
    ref._parent = b2
    b2._parent = block

# Generated at 2022-06-11 09:48:45.538031
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    obj = Block()
    result = obj.has_tasks()
    assert result == False
    obj = Block()
    obj.block = Task()
    result = obj.has_tasks()
    assert result == True
    obj = Block()
    obj.rescue = Task()
    result = obj.has_tasks()
    assert result == True
    obj = Block()
    obj.always = Task()
    result = obj.has_tasks()
    assert result == True
    obj = Block()
    obj.block = Task()
    obj.rescue = Task()
    obj.always = Task()
    result = obj.has_tasks()
    assert result == True
    obj = Block()
    obj.rescue = Task()
    obj.always = Task()
    result = obj.has_tasks()


# Generated at 2022-06-11 09:48:56.454785
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Mocks
    class MockPlay(object):
        def __init__(self):
            self.only_tags = None
            self.skip_tags = None
    class MockBlockParent(object):
        def __init__(self):
            self._parent = None
        def get_parent_attribute(self, attr, extend=False, prepend=False):
            return None
    class MockBlock(Block):
        def __init__(self):
            self._attributes = {}
            self._valid_attrs = {}
            self._dependency_attrs = {}
            self._parent = MockBlockParent()

    ## Create a block, with tagged tasks in the block, rescue and always lists
    block_parent = MockBlockParent()
    block = MockBlock()
    task = MockTaskInclude()
    task._use_handlers

# Generated at 2022-06-11 09:48:59.956117
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    block1 = block.copy()
    assert isinstance(block1, Block)
    assert block1.__class__.__name__ == block.__class__.__name__


# Generated at 2022-06-11 09:49:10.257653
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    import json
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    t0 = Task()
    t1 = Task()
    t2 = Task()
    t3 = Task()

    b0 = Block()
    b1 = Block()
    b2 = Block()

    b0.load({'block': [t1]})
    b1.load({'block': [b0]})
    b2.load({'block': [b1]})

    # validate that all parents are static by default
    assert b0.all_parents_static()
    assert b1.all_parents_static()
    assert b2.all_parents_static()

    # validate that a single non-static parent sets the flag for all
    b0._parent = t0
    t0.st

# Generated at 2022-06-11 09:49:13.376405
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block({'block': [
        {'name': 'a', 'action': 'nice', 'ignore_errors': False},
        {'name': 'b', 'action': 'nice', 'ignore_errors': False},
    ]})==True


# Generated at 2022-06-11 09:49:22.825681
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
        # Tests that all_parents_static() returns False when a block has
        # a parent that is not statically loaded
        #
        # Setup: Create a one level nested block
        b1 = Block(dep_chain=['t1'])
        b2 = Block(dep_chain=['t2'])
        # Make b2's parent non-static
        b2._parent = b1
        b2.statically_loaded = False

        assert not b1.all_parents_static()
        # Tests that all_parents_static() returns True when a block has
        # a parent that is statically loaded
        #
        # Setup: Create two nested blocks
        b1 = Block(dep_chain=['t1'])
        b2 = Block(dep_chain=['t2'])

# Generated at 2022-06-11 09:49:28.726496
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    arguments = dict(
        block = ['block'],
        rescue = ['rescue'],
        always = ['always']
    )
    bl = Block(**arguments)
    print(bl.all_parents_static())
    assert bl.all_parents_static() == True

# Generated at 2022-06-11 09:49:34.838953
# Unit test for method copy of class Block
def test_Block_copy():

    # test copy of object type Block
    testBlock = Block()
    newBlock = Block()
    # test copy of object type Base
    testBase = Block()
    newBase = Block()
    # test copy of object type Base
    testBase = Base()
    newBase = Base()

    assert True

# Generated at 2022-06-11 09:50:23.130523
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    class MockTaskInclude:
        def __init__(self, statically_loaded=False):
            self.statically_loaded = statically_loaded
            self.parent = None

    class MockBlock:
        def __init__(self, statically_loaded=False):
            self.statically_loaded = statically_loaded
            self.parent = None

    # Case 1. The block parent is None
    block = Block()
    assert block.all_parents_static() == True

    # Case 2. The block parent is TaskInclude, the statically_loaded of TaskInclude is True
    block = Block()
    task_include = MockTaskInclude(statically_loaded=True)
    block.parent = task_include
    assert block.all_parents_static() == True

    # Case 3. The block parent is TaskInclude, the statically_loaded

# Generated at 2022-06-11 09:50:33.239183
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook import Playbook
    from collections import namedtuple
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var

    Options = namedtuple('Options', ['tags', 'skip_tags'])
    opts = Options(tags=['role1'], skip_tags=['role2'])
    loader = DummyLoader()

# Generated at 2022-06-11 09:50:43.052106
# Unit test for method copy of class Block
def test_Block_copy():
    # Not using the system definitions for this unit test, instead using
    # the included definitions in the same directory as this module.
    defs = DataLoader()
    defs.set_basedir(os.path.join(os.getcwd(), 'test_utils'))
    Inventory(defs).clear_pattern_cache()

    role = Role.load(dict(
        name='test',
        tasks=[
            dict(block=dict(
                name='test block',
                tasks=[dict(name='task1')],
            ))
        ]
    ), variable_manager=VariableManager(), loader=defs)

    block = role.get_block('test block')
    assert block is not None
    assert block.has_tasks()

    new_block = block.copy()

    assert new_block is not block
    assert new_

# Generated at 2022-06-11 09:50:48.356621
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    a = Mock()
    a.get_dep_chain = MagicMock(return_value = [1, 2])

    b = Block()
    b._parent = a

    assert b.get_dep_chain() == [1, 2]
    #assert a.get_dep_chain.called


# Generated at 2022-06-11 09:50:57.306849
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    '''
    Block.set_loader
    '''

    # Loader that returns tasks
    t = Task()
    t.action = "template"
    t.name = "hello world"
    t.notify = "me"

    def _get_file_parser(file_name, vault_password=None):
        return t

    loader = DataLoader()
    loader._get_file_parser = _get_file_parser

    # playbook to use
    pb = Playbook()
    pb.vars = dict()

    # Role to use
    r = Role()
    r.name = "role"
    r.path = "/home/ansible/roles/role"

    # Block to test
    b = Block()
    b.vars = dict()
    b._parent = None
    b._dep

# Generated at 2022-06-11 09:51:07.777729
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    Task.load = Task_load_stub
    Task.__getitem__ = Task___getitem___stub
    Task.__iter__ = Task___iter___stub
    Block.load_from_file = Block_load_from_file_stub
    Block.load = Block_load_stub
    Block.is_block = Block_is_block_stub
    Block.preprocess_data = Block_preprocess_data_stub
    Block._load_block = Block__load_block_stub
    Block._load_rescue = Block__load_rescue_stub
    Block._load_always = Block__load_always_stub
    Block._validate_always = Block__validate_always_stub
    Block._validate_rescue = Block__validate_rescue_stub

# Generated at 2022-06-11 09:51:09.112843
# Unit test for method deserialize of class Block
def test_Block_deserialize():
   obj = Block()
   obj.deserialize(data)



# Generated at 2022-06-11 09:51:19.585522
# Unit test for method copy of class Block
def test_Block_copy():
    host = dict(connection='local')
    loader = DictDataLoader({'sample.yml': ''})
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(a='b')
    variable_manager.options_vars = dict(e='f')
    blocks = [dict(block=['a', 'b'])]
    play = dict(hosts='all', gather_facts='no', blocks=blocks)
    pb = Play.load(play, variable_manager=variable_manager, loader=loader)
    tqm = TaskQueueManager(inventory=InventoryManager(loader=loader, sources=[{'name': 'localhost', 'hosts': ['localhost']}]))

    b1 = Block.load(blocks[0], pb, tqm._variable_manager, loader)
    b2

# Generated at 2022-06-11 09:51:22.325551
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    class Block_Stub():
        def __init__(self, parent):
            self._parent = parent
    # actual test
    bs = Block_Stub(None)
    ans = bs.all_parents_static()
    assert ans is True

# Generated at 2022-06-11 09:51:24.199506
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b1 = Block()
    assert b1.has_tasks() == False
    b2 = Block(block=[])
    assert b2.has_tasks() == False
    b3 = Block(block=['task'])
    assert b3.has_tasks() == True

# Generated at 2022-06-11 09:52:10.092348
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    data = dict(
        block=[
            dict(
                name='test 123',
                debug=dict(
                    msg='this is {{a_var}} test'
                )
            )
        ]
    )
    block = Block()
    block.deserialize(data)
    assert block.block[0].name == 'test 123'
    assert block.block[0].debug.msg == 'this is {{a_var}} test'



# Generated at 2022-06-11 09:52:13.617325
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    '''
    deserialize(data)
    Override of the default deserialize method, to match the above overridden
    serialize method
    '''
    bl = Block()
    res = bl.deserialize(data)
    assert res == NotImplemented

# Generated at 2022-06-11 09:52:18.855707
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    #tasks = [t for t in all_tasks if not any(a for a in t.loop.keys())]
    #my_tasks = [t for t in all_tasks if any(a for a in t.loop.keys())]
    #assert len(tasks) == 27
    #assert len(my_tasks) == 5

    pass


# Generated at 2022-06-11 09:52:26.277399
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    '''
    Unit test for method deserialize of class Block Class
    '''

    # Create the test object
    m_self = Block()

    # Set the required instance variables of class Block
    m_self._loader = None
    m_self._variable_manager = None
    m_self._parent = None
    m_self._use_handlers = None
    m_self._dep_chain = None
    m_self._play = None
    m_self._role = None
    m_self._task_include = None
    m_self._attributes = None


    # Call the method deserialize of class Block
    m_self.deserialize(data)



# Generated at 2022-06-11 09:52:35.541269
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.static_task_include import StaticTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    import ansible.constants as C

    # Create parent class, Play

    p = Play()
    p._variable_manager = variable_manager = VariableManager()
    p.vars = variable_manager.set_available_variables(loader=None, play=p)
    p.vars

# Generated at 2022-06-11 09:52:46.290837
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

# Generated at 2022-06-11 09:52:46.908845
# Unit test for method copy of class Block
def test_Block_copy():
    pass

# Generated at 2022-06-11 09:52:48.314516
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    new_instance = Block()
    new_instance.set_loader(loader='loader')
    assert new_instance._loader == 'loader'
    

# Generated at 2022-06-11 09:52:55.658181
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    b = Block()
    assert b.get_first_parent_include() is None
    b._parent = Block(statically_loaded = False)
    assert b.get_first_parent_include() is None
    b._parent = Block(statically_loaded = True)
    assert b.get_first_parent_include() is None
    from ansible.playbook.task_include import TaskInclude
    b._parent = TaskInclude()
    assert b.get_first_parent_include() is not None

# Generated at 2022-06-11 09:52:58.794598
# Unit test for method has_tasks of class Block

# Generated at 2022-06-11 09:53:40.617167
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    loader = 'loader'
    block.set_loader(loader)

# Generated at 2022-06-11 09:53:49.874185
# Unit test for method filter_tagged_tasks of class Block

# Generated at 2022-06-11 09:53:58.402493
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    
    from ansible.playbook.task import Task
    
    # initial block
    b = dict(
        block=[dict(action='debug', args=dict(msg='foobar'))],
        rescue=[],
        always=[],
    )
    
    # Block object
    B = Block.load(b, None, None, None, None, None, None)
    
    # creating a task
    T = Task.load(dict(action='debug', args=dict(msg='foobar')), None, None, None, None, None)
    
    # playing with all_vars

# Generated at 2022-06-11 09:54:06.979291
# Unit test for method filter_tagged_tasks of class Block

# Generated at 2022-06-11 09:54:10.311671
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    test_Block = Block()

    test_loader = DictDataLoader({
        "test_path": {},
        "with/intermediate/dirs": {}
    })
    test_Block.set_loader(test_loader)
    assert(test_loader == test_Block._loader)

# Generated at 2022-06-11 09:54:17.560454
# Unit test for method copy of class Block
def test_Block_copy():
    # verify that copying a block with a static task produces the same result
    # as the original

    block = Block.load(dict(
        block=[
            dict(
                local_action=dict(
                    module='ping',
                    host='localhost',
                ),
                tags=['block_copy_test'],
            ),
        ],
    ), variable_manager=VariableManager(), loader=DataLoader())

    new_block = block.copy()
    for t1, t2 in itertools.izip_longest(block.block, new_block.block):
        assert t1 == t2



# Generated at 2022-06-11 09:54:26.923355
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    block = Block()
    block.deserialize(data={'role': 'role', 'parent': 'parent', 'parent_type': 'Block'})
    block.deserialize(data={'role': 'role', 'parent': 'parent', 'parent_type': 'TaskInclude'})
    block.deserialize(data={'role': 'role', 'parent': 'parent', 'parent_type': 'HandlerTaskInclude'})
    block.deserialize(data={'role': 'role'})
    block.deserialize(data={'parent': 'parent', 'parent_type': 'Block'})

# Generated at 2022-06-11 09:54:35.769854
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block()
    assert b.has_tasks() == 0

# Generated at 2022-06-11 09:54:40.397900
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.parsing.dataloader import DataLoader

    # Initialize params
    data = {'debug': 'var=2'}

    # Setup test object
    b = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=True)
    b._loader = DataLoader()
    b.deserialize(data)
    return True


# Generated at 2022-06-11 09:54:49.163475
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    tmp = {}

# Generated at 2022-06-11 09:55:41.671044
# Unit test for method copy of class Block
def test_Block_copy():
    # Set up test environment
    # NOTE: The test method alone is not enough to prove that the parent pointer is
    # set correctly. We added another test case in test_Block_copy_parent()
    test_play = MagicMock()
    test_block = Block(play=test_play,
        role=None,
        task_include=None,
        use_handlers=None,
        implicit=False,
        static_loader=False
    )
    # Call the method to be tested
    new_block = test_block.copy()
    assert new_block is not None
    assert new_block != test_block
    assert new_block.block == test_block.block
    assert new_block.rescue == test_block.rescue
    assert new_block.always == test_block.always
    assert new_block._

# Generated at 2022-06-11 09:55:49.633776
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create two blocks: A and B
    A = Block()
    B = Block()
    A.statically_loaded = True
    B.statically_loaded = True

    # Create two task includes: A1 and B1
    A1 = TaskInclude()
    B1 = TaskInclude()
    A1.static = True
    B1.static = False

    # Link everything together
    A._parent = A1
    B._parent = B1
    A1._parent = None
    B1._parent = B

    assert A.all_parents_static() == True
    assert B.all_parents_static() == False
    assert A1.all_parents_static() == True
    assert B1.all_parents_static() == False

# Generated at 2022-06-11 09:55:58.686011
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    import json
    import sys
    import doctest
    from ansible.playbook.play import Play
    from ansible.playbook.play import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    with open('test/units/parsing/yaml/block/test_Block_filter_tagged_tasks.yml', 'r') as test_file:
        source_data = test_file.read()
        data = json.loads(source_data)['data']

    # Create a block from the source data
    block = Block.load(data, play=Play())
    variables = {}
    all_vars = {}
    # Get the filtered block
    filtered_block = block.filter_tagged_tasks(all_vars)
    assert filtered_

# Generated at 2022-06-11 09:56:07.089567
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    b = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=True)
    b.deserialize(data={'name': 'test_Block_deserialize'})
    assert b._name == 'test_Block_deserialize'
    assert b._play is None

    assert b._parent is None
    assert b._role is None
    assert b._dep_chain is None

    r = Role()
    r.deserialize(data={'name': 'test_Block_deserialize_role'})
    assert r._name == 'test_Block_deserialize_role'


# Generated at 2022-06-11 09:56:07.643873
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    pass

# Generated at 2022-06-11 09:56:14.723448
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a block
    block = Block(play=None, parent_block=None, role=None, use_handlers=False, implicit=False)
    # Create a block_copy for filtering
    # block_copy = Block(play=None, parent_block=None, role=None, use_handlers=False, implicit=False)
    # Add a task with different tags (including one which is not empty)
    from ansible.playbook.task import Task
    task = Task()
    task.tags = set(['a', 'b', 'c'])
    block.block = [task]
    # Check if the required filter_tagged_tasks method is present in class Block
    has_attr(block, 'filter_tagged_tasks')
    # Check the appropriate response when all_vars is empty
    assert block.filter

# Generated at 2022-06-11 09:56:23.433274
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    print('Testing Block_filter_tagged_tasks')
    loader = DataLoader()
    iti = TaskInclude()
    iti.tags = set(['foo'])
    t = Task()
    t.tags = set(['foo'])
    t2 = Task()
    t2.tags = set(['bar'])
    t3 = Task()
    t3.tags = set(['baz'])
    my_block = Block(loader=loader, parent=iti)
    my_block.block = [ t, t2, t3 ]
    filtered_block = my_block.filter_tagged_tasks({})
    assert(len(filtered_block.block) == 2)
    assert(filtered_block.block[0] == t2)

# Generated at 2022-06-11 09:56:28.573176
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    #TODO: The test has not been completed
    from ansible.playbook_include import IncludeRole
    b = Block()
    assert b.all_parents_static() == True

    b2 = Block()
    b2._parent = b
    assert b2.all_parents_static() == True

    ir = IncludeRole()
    ir.statically_loaded = False
    b2._parent = ir
    assert b2.all_parents_static() == False

