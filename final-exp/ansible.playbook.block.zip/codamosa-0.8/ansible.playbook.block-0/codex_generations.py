

# Generated at 2022-06-11 09:47:16.679854
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    t = Task()
    block = Block.load(
        dict(
            block=dict(
                tasks=dict(
                    task_1 = dict(
                        name = 'Task 1',
                        action = 'fail',
                        tags = ['tag1', 'tag2']
                    ),
                    task_2 = dict(
                        name = 'Task 2',
                        action = 'fail',
                        tags = ['tag1']
                    ),
                    task_3 = dict(
                        name = 'Task 3',
                        action = 'fail',
                        tags = ['tag2']
                    )
                )
            )
        )
    )

    pb = Playbook()

# Generated at 2022-06-11 09:47:18.911947
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    b = Block()
    ds = dict()
    b.deserialize(ds)
    assert ds == dict()



# Generated at 2022-06-11 09:47:28.575630
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    my_block = Block()
    my_block._loader = None
    my_block._parent = mock.MagicMock()
    my_block._parent._loader = mock.MagicMock()
    my_block._play = mock.MagicMock()
    my_block._play._loader = mock.MagicMock()
    my_block._role = mock.MagicMock()
    my_block._role._loader = mock.MagicMock()
    my_block._use_handlers = mock.MagicMock()
    my_block._valid_attrs = {}
    my_block._dep_chain = None
    my_block._play = mock.MagicMock()
    my_block.block = []
    my_block.rescue = []
    my_block.always = []
    my_block.vars = {}


# Generated at 2022-06-11 09:47:39.283514
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    task1 = Task()
    task2 = Task()
    include_tasks = TaskInclude()
    handler = HandlerTaskInclude()
    handler.tasks = [task2]
    include_tasks.tasks = [task1]
    handler.static_tasks = [task2]
    include_tasks.static_tasks = [task1]
    block = Block()
    block.block = [include_tasks]
    block.rescue = [handler]


# Generated at 2022-06-11 09:47:48.775324
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()

    block.deserialize({
        'dep_chain': None,
        'ignore_errors': None,
        'only_if': None,
        'until': None,
        'when': None,
        'register': None,
        'notify': None,
        'delegate_to': None,
        'changed_when': None,
        'failed_when': None,
        'tags': None,
        'any_errors_fatal': False,
        'failed_when_result': False,
        'always_run': False,
        'no_log': False,
        'run_once': False,
        'use_handlers': False,
        'implicit': False,
        'block': [],
        'rescue': [],
        'always': [],
    })
#

# Generated at 2022-06-11 09:47:52.691427
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    deserialize = Block.deserialize

    # Setup arguments that would be passed to the above method
    data = dict(a=1, b=2)

    # Set the return value(s)
    # Setup mock objects
    # Run the test
    result = deserialize(data)
    assert(result)


# Generated at 2022-06-11 09:48:02.003188
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    filepath = os.path.join(os.path.dirname(__file__), '../../lib/ansible/playbook/play_context.py')
    if not os.path.exists(filepath):
        raise Exception("file not exist: {}".format(filepath))
    sys.path.append(filepath)
    import play_context

    filepath = os.path.join(os.path.dirname(__file__), '../../lib/ansible/playbook/task_include.py')
    if not os.path.exists(filepath):
        raise Exception("file not exist: {}".format(filepath))
    sys.path.append(filepath)
    import task_include

    def test_filter_tagged_tasks():
        # Test case no 1
        list_of_tasks

# Generated at 2022-06-11 09:48:11.579577
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    def _get_scanner_mock(good_tags):
        class ScannerMock(object):
            def __init__(self, good_tags):
                self.__good_tags = good_tags

            def match(self, tags):
                return "all" in tags or any([tag in self.__good_tags for tag in tags])

            def match_include(self, tags):
                return self.match(tags)

        return ScannerMock(good_tags)

    def _get_play_mock(only_tags, start_at=None):
        class PlayMock(object):
            def __init__(self, only_tags, start_at):
                self._start_at = start_at
                self.only_tags = only_tags


# Generated at 2022-06-11 09:48:22.276728
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    '''
    Unit test for method filter_tagged_tasks of class Block
    '''
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    _block = Block()
    _block.vars.update(dict(role=dict(a=1, b=2)))

    _task_1 = Task()
    _task_1._attributes['tags'] = ['a', 'b']
    _task_1._role = _block

    _task_2 = Task()
    _task_2._attributes['tags'] = ['a', 'b']
    _task_2._role = _block

    _block._block

# Generated at 2022-06-11 09:48:23.171862
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    pass

# Generated at 2022-06-11 09:48:59.380451
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    root = Block()
    root.statically_loaded = True
    b1 = Block()
    b1._parent = root
    b1.statically_loaded = True
    b2 = Block()
    b2._parent = b1
    b2.statically_loaded = True
    b3 = Block()
    b3._parent = b2
    b3.statically_loaded = True
    assert b3.all_parents_static() == True
    b3.statically_loaded = False
    assert b3.all_parents_static() == False
    b3.statically_loaded = True
    t1 = Task()

# Generated at 2022-06-11 09:49:04.447283
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    b1 = Block()
    b1.action = 'include'
    
    b2 = Block()
    b2.action = 'block'
    b2.block = b1
    
    result = b2.filter_tagged_tasks(all_vars=[])
    assert result == b2


# Generated at 2022-06-11 09:49:05.836773
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    b = Block()
    b.set_loader(b)



# Generated at 2022-06-11 09:49:14.608502
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    '''
    Unit test for method set_loader of class Block
    '''
    print("UNIT test " + str(inspect.stack()[0][2:4]))
    print("set loader")

    loader = DictDataLoader({
        "hello.yml": "", 
        "world.yml": ""
    })

    variable_manager = VariableManager()
    variable_manager.extra_vars = load_extra_vars(loader=loader, options=Options(tags=['include']))
    variable_manager.options_vars = load_options_vars(options=Options(tags=['include']))


# Generated at 2022-06-11 09:49:20.041899
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # # Add your test here
    # #Sentinel value for parameter 'attr'
    # attr = None
    # #Initialize a Block object with attributes attr
    # block = Block(attr)
    # try:
    #     block.deserialize(data)
    # except Exception as err:
    #     pass
    # else:
    #     raise Exception('ExpectedException not thrown')
    pass

# Generated at 2022-06-11 09:49:21.883362
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    obj = Block()
    assert(obj.has_tasks() == False)
    


# Generated at 2022-06-11 09:49:36.723468
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.vars import VariableManager, HostVars
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    # define the data needed to load our test data
    loader = AnsibleLoader(None, 'localhost')

# Generated at 2022-06-11 09:49:42.180782
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    block.block = []
    block.rescue = []
    block.always = []
    assert block.has_tasks(), "block has no tasks"

    block.block = [1,2,3]
    block.rescue = [4,5,6]
    block.always = [7,8,9]
    assert block.has_tasks(), "block has tasks"

# Generated at 2022-06-11 09:49:49.859715
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    t = Task()
    b = Block()
    t.block = b

    t.static = True
    b.static = False
    assert b.all_parents_static() == True

    b.static = True
    assert b.all_parents_static() == True

    t.static = False
    assert b.all_parents_static() == False

    b1 = Block()
    b2 = Block()
    b1.block = b2
    b1.static = True
    b2.static = False

    assert b2.all_parents_static() == False

    t2 = Task()
    ti1 = TaskInclude()
    ti2 = TaskInclude()
    b3 = Block()



# Generated at 2022-06-11 09:49:54.936045
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    #Create a play and add a block to it
    p = Play()
    b = Block(parent=p)

    #assert that the function returns true
    assert b.all_parents_static() == True

    #create a task include and add it to the block
    task_inc = TaskInclude(parent=b, statically_loaded=False)

    #assert that the function returns false
    assert b.all_parents_static() == False

# Generated at 2022-06-11 09:50:27.467235
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block_1 = Block.load(dict(rescue=[dict(action=dict(module='debug', args=dict(msg="block_1 rescue")))]))
    block_2 = Block.load(dict(rescue=[dict(action=dict(module='debug', args=dict(msg="block_2 rescue")))]))
    block_3 = Block.load(dict(rescue=[dict(action=dict(module='debug', args=dict(msg="block_3 rescue")))]))
    block_4 = Block.load(dict(rescue=[dict(action=dict(module='debug', args=dict(msg="block_4 rescue")))]))
    block_5 = Block.load(dict(rescue=[dict(action=dict(module='debug', args=dict(msg="block_5 rescue")))]))

# Generated at 2022-06-11 09:50:36.632885
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Set up test environment
    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from units.mock.loader import DictDataLoader

    fake_loader = DictDataLoader({})

    fake_play_context = PlayContext()

    fake_variable_manager = VariableManager()

    fake_task_ds = dict(
        action=dict(
            module='shell',
            args='echo "hello world"',
        ),
    )

    # Execute code to be

# Generated at 2022-06-11 09:50:38.918714
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    obj=Block()
    assert not obj.all_parents_static()

# class Block: get_first_parent_include

# Generated at 2022-06-11 09:50:50.624072
# Unit test for method copy of class Block
def test_Block_copy():
   # create object of class Block
   obj_instance = Block()

# Generated at 2022-06-11 09:50:58.736593
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    debug = False

# Generated at 2022-06-11 09:51:09.433835
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    class StaticBlock1(Block):
        @staticmethod
        def load(play, parent=None, role=None, task_include=None, use_handlers=False):
            block = StaticBlock1(play=play, parent=parent, role=role, task_include=task_include, use_handlers=use_handlers)
            block.statically_loaded = True
            return block

    class StaticBlock2(Block):
        @staticmethod
        def load(play, parent=None, role=None, task_include=None, use_handlers=False):
            block = StaticBlock2(play=play, parent=parent, role=role, task_include=task_include, use_handlers=use_handlers)
            block.statically_loaded = True
            return block


# Generated at 2022-06-11 09:51:19.971169
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.included_file import IncludedFile
    from ansible.vars.manager import VariableManager

    def Task_init(self):
        Task.__init__(self)
        self._attributes = dict()
    Task.__init__ = Task_init

    t1 = Task()
    t1.statically_loaded = True
    t1._parent = None
    t2 = TaskInclude()
    t2.statically_loaded = True
    t2._parent = t1
    t3 = HandlerTaskInclude()
    t3.statically_loaded = True
    t3._parent = t2

# Generated at 2022-06-11 09:51:20.827792
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    assert_equal(True, Block.has_tasks())


# Generated at 2022-06-11 09:51:28.978342
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Create a new empty task
    # NOTE: The only_tags and skip_tags attributes of play object in this test
    # are not set.
    a = ActionModule(task=Task(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    b = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    t = Task()
    t.action = 'action_module'
    t.module_name = 'action'
    t.set_loader(None)
    t.action = a
    b.block = [t]
    # The below line of code is only for testing purposes. In normal case, the
    # all_vars of the play object is set to {} and

# Generated at 2022-06-11 09:51:39.364474
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.handler import Handler
    block = Block(
        play=Play().load({'name': 'test', 'hosts': 'remote'}, variable_manager=VariableManager(), loader=DictDataLoader()),
        role=None,
        task_include=None,
        use_handlers=False,
        implicit=False)
    # TODO

# Generated at 2022-06-11 09:52:04.651079
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    task_file = TaskFile()
    t = task_file.load('task1.yml')
    assert t.has_tasks()
    t = task_file.load('task2.yml')
    assert not t.has_tasks()
    t = task_file.load('task3.yml')
    assert t.has_tasks()
    t = task_file.load('task4.yml')
    assert t.has_tasks()
    t = task_file.load('task5.yml')
    assert t.has_tasks()
    t = task_file.load('task6.yml')
    assert t.has_tasks()
    
test_Block_has_tasks()
print("finished task_block.py")

print("start task_include.py")


# Generated at 2022-06-11 09:52:14.333615
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    a = Block()
    b = Block()
    c = Block()
    a.dep_chain = [b, c]
    ret = a.get_dep_chain()
    assert ret == [b, c]
    ret = a.get_dep_chain()
    assert ret == [b, c]
    a.dep_chain = []
    ret = a.get_dep_chain()
    assert ret == []
    b.dep_chain = [a]
    ret = b.get_dep_chain()
    assert ret == [a]
    c.dep_chain = [b]
    ret = c.get_dep_chain()
    assert ret == [b]
    b.dep_chain = []
    ret = b.get_dep_chain()
    assert ret == None
    c.dep_chain = []

# Generated at 2022-06-11 09:52:23.813290
# Unit test for method copy of class Block
def test_Block_copy():
    # container_block = Block.load(None,
    #                               play=None,
    #                               parent_block=None,
    #                               role=None,
    #                               task_include=None,
    #                               use_handlers=False,
    #                               variable_manager=None,
    #                               loader=None)
    container_block = Block()
    new_block = container_block.copy(exclude_parent=False, exclude_tasks=False)

    assert new_block._play is None
    assert new_block._use_handlers is False
    assert new_block._dep_chain is None
    assert new_block._parent is None
    assert new_block.block == []
    assert new_block.rescue == []
    assert new_block.always == []
    assert new_

# Generated at 2022-06-11 09:52:28.640803
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    parent_block = Block(use_handlers=False, implicit=False)
    parent_block._parent = None
    parent_block.statically_loaded = True
    assert parent_block.all_parents_static() == True
    parent_block.statically_loaded = False
    assert parent_block.all_parents_static() == False
    parent_block._parent = parent_block
    assert parent_block.all_parents_static() == True


# Generated at 2022-06-11 09:52:38.358143
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    m = Block()
    data = {'block': [{'action': 'test_action', 'when': 'test_when', 'name': 'test_name'}]}
    m.deserialize(data)
    data = {'block': [{'action': 'test_action', 'when': 'test_when', 'name': 'test_name'}]}
    m.deserialize(data)
    data = {'block': [{'action': 'test_action', 'when': 'test_when', 'name': 'test_name'}]}
    m.deserialize(data)
    data = {'block': [{'action': 'test_action', 'when': 'test_when', 'name': 'test_name'}]}
    m.deserialize(data)


# Generated at 2022-06-11 09:52:49.264071
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.block import Block
    block = Block()
    all_vars = {}

    def test_filter_tagged_tasks_helper(param_list, expected_return_block, test_name=None, msg=None):
        block_with_tasks = Block()
        block_with_tasks.block = block_with_tasks.rescue = block_with_tasks.always = param_list
        return_value = block_with_tasks.filter_tagged_tasks(all_vars)
        assert expected_return_block.block == return_value.block, "return_value.block {} does not match with expected {}" \
            .format(return_value.block, expected_return_block.block)

    from ansible.playbook.task import Task

# Generated at 2022-06-11 09:52:54.802893
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    """
    Test case for has_tasks method of class Block.
    """
    block_obj=Block()
    block_obj.block=['','']
    block_obj.rescue=['','','','']
    block_obj.always=['','','','','','']
    assert block_obj.has_tasks()


# Generated at 2022-06-11 09:52:56.282571
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    assert block.deserialize("") == None

# Generated at 2022-06-11 09:53:01.695522
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    block = Block()
    ti = TaskInclude()
    ti.statically_loaded = True
    block._parent = ti
    result = block.get_first_parent_include()
    assert(result == ti)
    block = Block()
    ti = TaskInclude()
    ti.statically_loaded = False
    block._parent = ti
    result = block.get_first_parent_include()
    assert(result == None)



# Generated at 2022-06-11 09:53:09.546183
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block1=Block()
    block2=Block()
    block3=Block()
    block4=Block()
    block1.statically_loaded=True
    block2.statically_loaded=True
    block3.statically_loaded=True
    block4.statically_loaded=True
    block1._parent = block2
    block2._parent = block3
    block3._parent = block4
    assert block1.all_parents_static() == True
    block1.statically_loaded=False
    assert block1.all_parents_static() == False
    block1.statically_loaded=True
    block2.statically_loaded=False
    assert block1.all_parents_static() == False

# Generated at 2022-06-11 09:53:48.354050
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    # an empty play
    play1 = dict(
        name = "my first play",
        hosts = 'web_servers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='copy', name='copy something'), register='copy_result'),
            dict(action=dict(module='shell', name='script something'), register='shell_result'),
            dict(action=dict(module='raw', name='raw something')),
        ]
    )
    # Assign play to object play
    play = Play().load(play1, variable_manager=variable_manager, loader=loader)
    # Assign a value to task

# Generated at 2022-06-11 09:53:56.965236
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    import ansible.playbook
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.playbook.task_include
    class Block_statically_loaded_true(ansible.playbook.block.Block):
        def __init__(self):
            self.statically_loaded = True
    class Block_statically_loaded_false(ansible.playbook.block.Block):
        def __init__(self):
            self.statically_loaded = False


# Generated at 2022-06-11 09:53:57.990260
# Unit test for method deserialize of class Block
def test_Block_deserialize():
	pass # TODO


# Generated at 2022-06-11 09:54:06.617352
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block.load(dict(
        block=[
            dict(block=[dict(name='test_Block_has_tasks - 2')]),
            dict(name='test_Block_has_tasks - 3')
        ],
        rescue=[
            dict(block=[dict(name='test_Block_has_tasks - 4')]),
            dict(name='test_Block_has_tasks - 5')
        ],
        always=[
            dict(block=[dict(name='test_Block_has_tasks - 6')]),
            dict(name='test_Block_has_tasks - 7')
        ],
        name='test_Block_has_tasks'
    ))
    assert block.has_tasks()

# Generated at 2022-06-11 09:54:15.662385
# Unit test for method copy of class Block
def test_Block_copy():
    copy = Block.copy
    sentinel = Sentinel

    block = Block()
    block._parent = sentinel
    block._role = sentinel
    block._play = sentinel
    block_cpy = copy(block)
    assert block_cpy._parent is None
    assert block_cpy._role is None
    assert block_cpy._play is None
    block_cpy = copy(block, False, False)
    assert block_cpy._parent is sentinel
    assert block_cpy._role is sentinel
    assert block_cpy._play is sentinel
    block_cpy = copy(block, True, False)
    assert block_cpy._parent is not sentinel
    assert block_cpy._parent._parent is None
    assert block_cpy._role is None

# Generated at 2022-06-11 09:54:25.448115
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block1 = Block()
    assert block1.has_tasks() == False
    block2 = Block(dict(block=[1, 2, 3]))
    assert block2.has_tasks() == True
    block3 = Block(dict(rescue=[4, 5, 6]))
    assert block3.has_tasks() == True
    block4 = Block(dict(always=[7, 8, 9]))
    assert block4.has_tasks() == True
    block5 = Block(dict(block=[10, 11, 12], rescue=[13, 14, 15], always=[16, 17, 18]))
    assert block5.has_tasks() == True
    block6 = Block(dict(block=[19, 20, 21], always=[23, 24, 25]))
    assert block6.has_tasks() == True

# Generated at 2022-06-11 09:54:34.508935
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import RoleInclude
    block = Block()
    assert block.has_tasks() == False
    block.block = [Task()]
    assert block.has_tasks() == True
    block.rescue = [Task()]
    assert block.has_tasks() == True
    block.always = [Task()]
    assert block.has_tasks() == True
    block.block = []
    assert block.has_tasks() == True
    block.rescue = []
    assert block.has_tasks() == True
    block.always = []
    assert block.has

# Generated at 2022-06-11 09:54:40.967850
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Instantiation of class Block
    b = Block()
    # b.set_loader(loader)
    # loader is an object of class AnsibleFileLoader
    # The method set_loader of class Block is defined in file ansible/playbook/block.py
    # Loader is an instance of class AnsibleFileLoader.

    # class AnsibleFileLoader is defined in file ansible/parsing/dataloader.py
    # AnsibleFileLoader inherits from DataLoader
    # DataLoader is defined in file ansible/parsing/dataloader.py
    # DataLoader inherits from BaseLoader
    # BaseLoader is defined in file ansible/parsing/dataloader.py
    # BaseLoader inherits from DataLoaderBase
    # DataLoaderBase is defined in file ansible/parsing/dataloader

# Generated at 2022-06-11 09:54:50.205768
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    import ansible.parsing.dataloader
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.vars.manager
    import ansible.playbook.play
    import ansible.playbook.block
    import ansible.template
    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.manager.VariableManager()
    variable_manager._extra_vars = dict(myhost="this", otherhost="that")
    inventory = ansible.inventory.Inventory(loader=loader, variable_manager=variable_manager, host_list=[])

# Generated at 2022-06-11 09:54:54.609167
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Instantiate an instance of class Block
    obj = Block()
    # Test if the method all_parents_static can be called.
    try:
        result = obj.all_parents_static()
    except Exception:
        assert False, "Method all_parents_static can not be called."
    else:
        assert True, "Method all_parents_static can not be called."

# Generated at 2022-06-11 09:55:33.807577
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    ds_str = '{"parent_type": "Block", "always": [{"when": ["always"]}], "parent": {"dep_chain": [], "parent_type": "Play", "parent": null, "_attributes": {"serial": 1}, "tags": ["collective", "foo"], "name": "fooplay", "hosts": ["foo"]}, "rescue": [], "block": [{"when": ["foo"], "name": "foo"}], "dep_chain": [], "_attributes": {"only_tags": ["foo"]}}'
    ds = json.loads(ds_str)
    b = Block()
    b.deserialize(ds)
    assert(b.name == '')
    assert(len(b._valid_attrs) == 7)
    assert(b._parent._parent is None)

# Generated at 2022-06-11 09:55:43.959030
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    class TaskInclude(object):
        def __init__(self, statically_loaded=True):
            self.statically_loaded = statically_loaded

        def all_parents_static(self):
            return self.statically_loaded

    block = Block()
    static_task = TaskInclude()
    dynamic_task = TaskInclude(statically_loaded=False)

    block.statically_loaded = True
    assert block.all_parents_static()

    block.statically_loaded = False
    assert not block.all_parents_static()

    block._parent = static_task
    assert block.all_parents_static()

    block._parent = dynamic_task
    assert not block.all_parents_static()

    static_block = Block(statically_loaded=True)
    block._parent = static_block

# Generated at 2022-06-11 09:55:52.231194
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Create instance of AnsibleLoader to be used to load data
    loader = AnsibleLoader()

    # Create instance of Block to test the metod get_dep_chain()
    b = Block()

    # Test if the method get_dep_chain() returns an empty list when
    # attribute _dep_chain is None.
    b._dep_chain = None
    assert b.get_dep_chain() is None

    # Test if the method get_dep_chain() returns a copy of the attribute
    # _dep_chain
    b._dep_chain = []
    assert b.get_dep_chain() == b._dep_chain

    # Test if the method get_dep_chain() returns the de_chain of the parent
    # attribute when attribute _dep_chain is None.
    b._dep_chain = None

    # Create instance of Block

# Generated at 2022-06-11 09:55:53.378505
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    assert False, "Test not implemented"



# Generated at 2022-06-11 09:56:02.378626
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    ti = TaskInclude()
    ti._loader = False
    test_block1 = Block(parent=ti)
    test_block2 = Block(parent=test_block1)
    assert(ti == test_block2.get_first_parent_include())
    ti._loader = True
    assert(ti == test_block2.get_first_parent_include())
    test_context = PlayContext()

# Generated at 2022-06-11 09:56:09.676435
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    b = Block(implicit=True)
    t1 = Task()
    t1.tags.append('foo')
    b.block.append(t1)

    filtered = b.filter_tagged_tasks({})
    assert len(filtered.block) == 1

    # now test a scenario where the 'tasks' are also includes
    b2 = Block(implicit=True)
    b2.block = []
    ti = TaskInclude()
    ti.tags.append('foo')
    b2.block.append(ti)

    filtered = b2.filter_tagged_tasks({})
    assert len(filtered.block) == 1

# Generated at 2022-06-11 09:56:17.220683
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    import pytest
    t1 = Task(); t2 = Task(); t3 = Task(); t4 = Task(); t5 = Task(); t6 = Task(); t7 = Task(); t8 = Task(); t9 = Task(); t10 = Task()
    block = Block(block=[t1], rescue=[t2], always=[t3])
    assert block.has_tasks() == True
    block = Block(block=[t1], rescue=[t2], always=[])
    assert block.has_tasks() == True
    block = Block(block=[t1], rescue=[], always=[t3])
    assert block.has_tasks() == True
    block = Block(block=[], rescue=[t2], always=[t3])
    assert block.has_tasks() == True
    block = Block(block=[t1], rescue=[], always=[])

# Generated at 2022-06-11 09:56:20.245520
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    my_block = Block()
    class  my_loader:
        pass
    my_block.set_loader(my_loader)
    assert my_block._loader == my_loader


# Generated at 2022-06-11 09:56:22.726151
# Unit test for method deserialize of class Block
def test_Block_deserialize():
	data = {}

	x = Block(parent=None, role=None, task_include=None, use_handlers=False, implicit=True)
	x.deserialize(data)


# Generated at 2022-06-11 09:56:23.364137
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    pass