

# Generated at 2022-06-23 05:52:56.182383
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = Block(name='test-block')
    block.block = [
        Task(action='a1', tags=['t1', 't2', 't3']),
        Task(action='a2', tags=['t1', 't3']),
        Task(action='a3', tags=['t1'])
    ]

    filtered_block = block.filter_tagged_tasks({'tags': ['t1', 't2']})
    assert len(filtered_block.block) == 3

# Generated at 2022-06-23 05:52:57.966938
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    pass # TODO


# Generated at 2022-06-23 05:53:10.436486
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='debug', args=dict(msg='{{test_var}}')))
        ]
    )

    p = Play().load(play_ds, variable_manager=VariableManager(), loader=DataLoader())

    # block object to test
    b= p.task_blocks[0]

    # set variable manager
    b._variable_manager = VariableManager()

    # test for get_vars
    test_var = dict(test_var="it works!")
    b._variable_manager.set_nonpersistent_facts(test_var)
    b._variable_manager.set_nonpers

# Generated at 2022-06-23 05:53:15.382012
# Unit test for method serialize of class Block
def test_Block_serialize():
    block = Block()
    serialized = block.serialize()
    #serialized should be a dict
    assert isinstance(serialized, dict)
    # Check that all the attributes are present in the serialization
    attributes = set(dir(block)) - set(dir(Base))
    assert attributes.issubset(serialized)
    # Check that it serializes a list
    block._load_rescue('rescue', [['debug', 'msg: test']])
    serialized = block.serialize()
    assert serialized.get('rescue') is not None
    assert isinstance(serialized.get('rescue'), list)
    assert serialized.get('rescue')[0].get('name') == 'debug'
    assert serialized.get('rescue')[0].get('args') == 'msg: test'
#

# Generated at 2022-06-23 05:53:23.952071
# Unit test for method is_block of class Block
def test_Block_is_block():
    test_block = Block()
    test_block.block = [  ]
    value = None
    try:
        value = Block.is_block(test_block)
    except Exception as e:
        value = e
    assert value == False
    test_block.block = [ "get_url" ]
    try:
        value = Block.is_block(test_block)
    except Exception as e:
        value = e
    assert value == True
    test_block.block = [  ]
    test_block.rescue = [ "get_url" ]
    try:
        value = Block.is_block(test_block)
    except Exception as e:
        value = e
    assert value == True
    test_block.rescue = [  ]

# Generated at 2022-06-23 05:53:36.675783
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block({'block': [{'name': 'file', 'src': '../file.txt', 'dest': './file.txt'}]}) == True
    assert Block.is_block({'block': [{'name': 'shell', 'command': '/bin/true'}]}) == True
    assert Block.is_block({'block': [{'name': 'set_fact', 'ansible_facts': {'foo': 'bar'}}]}) == True
    assert Block.is_block({'block': [{'name': 'command', 'command': '/bin/true'}]}) == True
    assert Block.is_block({'block': [{'name': 'include', 'include': '../include.yml'}]}) == True

# Generated at 2022-06-23 05:53:47.961404
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    '''
    Test function to create a Block object, initiate the object and call get_first_parent_include function
    '''
    try:
        b = Block()
        b.get_first_parent_include()
        print("get_first_parent_include of class Block Test - Success")
    except Exception as err:
        print("get_first_parent_include of class Block Test - Failed :" + str(err))
Block.register_attribute('register', FieldAttribute(isa='string', default=None))
Block.register_attribute('ignore_errors', FieldAttribute(isa='bool', default=False))
Block.register_attribute('always_run', FieldAttribute(isa='bool', default=False))
Block.register_attribute('changed_when', FieldAttribute(isa='string', default=False))

# Generated at 2022-06-23 05:53:57.692947
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    myImplicit = Block()
    myImplicit.block = []
    myImplicit.rescue = []
    myImplicit.always = []
    assert not myImplicit.has_tasks()

    myList_withNone = Block()
    myList_withNone.block= [None]
    myList_withNone.rescue = []
    myList_withNone.always = []
    with pytest.raises(AttributeError):
        assert myList_withNone.has_tasks()


if __name__ == '__main__':
    # Unit test this class
    unittest.main()

# Generated at 2022-06-23 05:54:04.527772
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    data = {"name": "test_Block_preprocess_data"}
    assert Block.preprocess_data(data) == {"block": [{"name": "test_Block_preprocess_data"}]}
    data = [{"name": "test_Block_preprocess_data"}]
    assert Block.preprocess_data(data) == {"block": [{"name": "test_Block_preprocess_data"}]}



# Generated at 2022-06-23 05:54:15.609100
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    print('Testing Block.has_tasks')

    # Test if has_tasks() is True if the block has some playbooks inside block/rescue/always.
    block = Block(use_handlers=True)
    block.block = [ AnsibleAction( 'action_1', 'module_1', 'args_1'), AnsibleAction( 'action_2', 'module_2', 'args_2') ]
    block.rescue = [ AnsibleAction( 'action_3', 'module_3', 'args_3'), AnsibleAction( 'action_4', 'module_4', 'args_4') ]
    block.always = [ AnsibleAction( 'action_5', 'module_5', 'args_5'), AnsibleAction( 'action_6', 'module_6', 'args_6') ]


# Generated at 2022-06-23 05:54:22.482354
# Unit test for method copy of class Block
def test_Block_copy():
    # test the method without arguments.
    my_obj = Block()
    my_obj.copy()

    # test with arguments
    # test arguments 0: exclude_parent=False
    my_obj = Block()
    my_obj.copy(exclude_parent=False)

    # test arguments 1: exclude_tasks=False
    my_obj = Block()
    my_obj.copy(exclude_tasks=False)

    # test arguments 2: exclude_parent=False, exclude_tasks=False
    my_obj = Block()
    my_obj.copy(exclude_parent=False, exclude_tasks=False)


# Generated at 2022-06-23 05:54:28.582160
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    def test(s):
        instance = Block()
        setattr(instance, "_parent", s)
        assert instance.get_include_params() is s
    test(None)
    test(1)
    test(True)
    test([1,2,3])
    test({1,2,3})
    test({1:"hello", 2:"world"})


# Generated at 2022-06-23 05:54:38.490980
# Unit test for method is_block of class Block
def test_Block_is_block():
	assert Block.is_block(dict(block=['a'])), "dict(block=['a']) should return true"
	assert not Block.is_block(['a']), "list ['a'] should return false"
	assert Block.is_block(dict(rescue=['a'])), "dict(rescue=['a']) should return true"
	assert Block.is_block(dict(always=['a'])), "dict(always=['a']) should return true"
	assert Block.is_block(dict(block=['a'], rescue=['b'])), "dict(block=['a'], rescue=['b']) should return true"
	assert not Block.is_block(None), "None should return false"

# Generated at 2022-06-23 05:54:48.029956
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    block = Block(use_handlers=False)
    block.statically_loaded = True
    task = Task()
    task.statically_loaded = True
    block2 = Block(use_handlers=False)
    block2.statically_loaded = True
    task2 = Task()
    task2.statically_loaded = True
    handler = Handler()
    handler.statically_loaded = True

    assert block.all_parents_static() == True
    task._parent = block
    assert task.all_parents_static() == True
    block2._parent = block
    assert block2.all_parents_static() == True
    task2._parent = block2

# Generated at 2022-06-23 05:55:00.326963
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    '''
    Test the filter_tagged_tasks method of Block.
    :return:
    '''
    print("")
    print("test_Block_filter_tagged_tasks")
    # Test one item

# Generated at 2022-06-23 05:55:03.006010
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    print(Block.get_first_parent_include())

# Generated at 2022-06-23 05:55:12.931588
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
	# block=None, parent_block=None, dep_chain=None, role=None, task_include=None, use_handlers=False, implicit=False
	b1 = Block(block = [])
	# role=None, _task_includes=None, _role=None, vars=None, defaults=None, name=None, play=None
	r = Role(vars = {})
	# name=None, play=None, _role=None, _task_includes=None, vars=None, defaults=None, _valid_attrs=None, _display=None, dep_chain=None, dynamically_loaded=False
	t1 = TaskInclude(name = 'task_name', play = None, dep_chain = None, dynamically_loaded = False)
	t1._role = r
	b1._parent = t

# Generated at 2022-06-23 05:55:16.305904
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block = Block(play = dict(), parent_block = dict(), role = dict(), task_include = dict(), use_handlers = dict(), implicit = dict(), static_only = dict())
    block.get_dep_chain()

# Generated at 2022-06-23 05:55:21.748469
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    block = Block(play=Play())
    assert block.get_vars() == {}
    play = Play()
    play.vars = {'foo': 'bar'}
    play.set_variable_manager(VariableManager(play.vars))
    block = Block(play=play)
    assert block.get_vars() == {'foo': 'bar'}


# Generated at 2022-06-23 05:55:28.048389
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager, HostVars
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    # Given: Inventory and PlayContext
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager())
    hostvars = HostVars(
        inventory=inventory,
        variable_manager=VariableManager(),
    )
    inventory.set_variable_manager(hostvars)
    play_context = PlayContext(
        variable_manager=VariableManager(),
        loader=loader,
    )
    # When: I Create a block object

# Generated at 2022-06-23 05:55:29.286191
# Unit test for method deserialize of class Block
def test_Block_deserialize():
  pass



# Generated at 2022-06-23 05:55:35.321010
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block = Block()
    block.block = [ 'block' ]
    block.rescue = [ 'rescue' ]
    block.always = [ 'always' ]
    block._valid_attrs = { '_valid_attrs': None }
    assert repr(block) == "Block(implicit=True, block=['block'], rescue=['rescue'], always=['always'], _valid_attrs={'_valid_attrs': None})"


# Generated at 2022-06-23 05:55:36.517913
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    assert True


# Generated at 2022-06-23 05:55:47.205445
# Unit test for method serialize of class Block
def test_Block_serialize():
    # Set up mock objects
    b = Block(task_include=None, use_handlers=False, implicit=False)

# Generated at 2022-06-23 05:55:53.549029
# Unit test for method load of class Block
def test_Block_load():
    args = dict(
        data=[dict(block=[dict(
            arguments=[dict(
                foo="bar", name="test",
            )],
            name="test",
            task=[
                dict(include="test.yml", with_first_found=dict(files=["test.yml"])),
            ]
        )])],
        loader=Mock(),
        play=Mock(),
        role=Mock(),
        task_include=Mock(),
        use_handlers=True,
        variable_manager=Mock(),
    )
    block = Block.load(**args)
    assert block._play == args["play"]
    assert block._use_handlers == args["use_handlers"]


# Generated at 2022-06-23 05:56:04.540657
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    import inspect
    import sys
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    f = inspect.currentframe()
    module = sys.modules[f.f_globals['__name__']]

    # Test with Handler object
    s = Base()
    s._attributes['tags'] = ['tag1', 'tag2']
    s._attributes['when'] = AnsibleUnicode('when1')
    s._attributes['name'] = AnsibleUnicode('name1')
    s._attributes['async']

# Generated at 2022-06-23 05:56:14.429229
# Unit test for constructor of class Block
def test_Block():
    name = 'test'
    play = 'play'
    role = 'my-role'
    data = 'data'
    parent_block = 'parent_block'
    task_include = 'task_include'
    use_handlers = 'use_handlers'
    dep_chain = 'dep_chain'

    # Test Block constructor without name, play, role, data, parent_block, task_include, use_handlers, dep_chain
    block = Block()
    assert block.name is None
    assert block.play is None
    assert block.role is None
    assert block.data is None
    assert block.parent_block is None
    assert block.task_include is None
    assert block.use_handlers is None
    assert block.dep_chain is None

    # Test Block constructor with name, play, role, data

# Generated at 2022-06-23 05:56:24.393597
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    _ = AnsibleOptions(connection='local')

    # Create a dummy inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Load a play from yaml

# Generated at 2022-06-23 05:56:29.580531
# Unit test for method is_block of class Block
def test_Block_is_block():
    expected_result = True
    test_data = {"test":"test"}

    result = Block.is_block(test_data)

    assert result == expected_result, "Expected {0}, but got {1}".format(expected_result, result)


# Generated at 2022-06-23 05:56:30.717616
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    pass


# Generated at 2022-06-23 05:56:38.374388
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    block_test = Block(
        block=[
            {'block': [1, 2, 3]},
            {'block': [4, 5, 6]}
        ]
    )
    assert block_test.get_include_params() == dict()

    block_test = Block(
        include_params={'foo': 'bar'},
        block=[
            {'block': [1, 2, 3]},
            {'block': [4, 5, 6]}
        ]
    )
    assert block_test.get_include_params() == {'foo': 'bar'}

    block_test = Block(
        include_params={'foo': 'bar'},
        block=[
            {'block': [1, 2, 3]},
            {'block': [4, 5, 6]}
        ]
    )


# Generated at 2022-06-23 05:56:42.691281
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    play = Play()
    block = Block(play)
    print(block.get_include_params())


# Generated at 2022-06-23 05:56:53.705308
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # block = Block()
    # assert block.has_tasks() == 0
    # block = Block(block=[])
    # assert block.has_tasks() == 0
    # block = Block(block=[], rescue=[])
    # assert block.has_tasks() == 0
    # block = Block(block=[], rescue=[], always=[])
    # assert block.has_tasks() == 0
    block = Block(block=[Block()])
    assert block.has_tasks() == 1
    block = Block(block=[Task()])
    assert block.has_tasks() == 1

if __name__ == "__main__":
    test_Block_has_tasks()

# Generated at 2022-06-23 05:56:58.747723
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
  block = Block()
  block.block = []
  block.rescue = []
  block.always = []
  assert not block.has_tasks()
  block.block = ['task_1']
  assert block.has_tasks()
  block.block = []
  block.rescue = ['task_2']
  assert block.has_tasks()
  block.rescue = []
  block.always = ['task_3']
  assert block.has_tasks()
  

# Generated at 2022-06-23 05:57:08.295256
# Unit test for method load of class Block

# Generated at 2022-06-23 05:57:15.407066
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Create an empty dict we can deserialize into
    data = dict()
    # create a dict for the Block
    block = dict()
    # copy the dict  to the Block
    data['block'] = block
    # Create an empty Block
    block = Block()
    # Load data into the Block
    value = block.load_data(data)
    assert block.has_tasks() == False

# Generated at 2022-06-23 05:57:24.855889
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # Instance to test method on
    runme = Block()

    # Test to see if method correctly returns a dict with key "block" and list passed to method as value of key "block"
    print("Testing Block.preprocess_data with non-block value")
    assert runme.preprocess_data(["hello", "world"]) == {"block": ["hello", "world"]}, "Did not return dict with key 'block' and list passed to method as value"
    print("Successfully tested Block.preprocess_data with non-block value")

    # Test to see if method correctly returns dict passed in if it has key "block"
    print("Testing Block.preprocess_data with block value")

# Generated at 2022-06-23 05:57:28.453514
# Unit test for method is_block of class Block
def test_Block_is_block():
    b = Block()
    data = dict(a=1, b=dict(c=2))
    assert not b.is_block(data)
    data = dict(block=['a', 'b', 'c'])
    assert b.is_block(data)

# Generated at 2022-06-23 05:57:29.999901
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    pass # implemented in test_playbook_include.py

# Generated at 2022-06-23 05:57:34.250895
# Unit test for method get_dep_chain of class Block

# Generated at 2022-06-23 05:57:41.790724
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    """
    Checks if the method has_tasks returns True when there are non-empty children
    and False otherwise
    """
    print ("Testing has_tasks of Block")

    # create a dummy task
    test_task = Task()
    test_task._role = Role()
    test_task.role._parent = Play()

    # Test case: non-empty block
    test_block = Block(play=test_task.role.play, parent_block=test_task._role, task_include=test_task.role)
    test_block.block.append(test_task)

    assert test_block.has_tasks() is True

    # Test case: empty block

# Generated at 2022-06-23 05:57:49.128796
# Unit test for constructor of class Block
def test_Block():
    block = Block(
        play=None,
        parent_block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        implicit=None,
    )
    assert block._play is None
    assert block._parent is None
    assert block._role is None
    assert block._task_include is None
    assert not block._use_handlers
    assert block._implicit is None



# Generated at 2022-06-23 05:57:55.021027
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task import Task
    # Testing validation of parent object
    obj = Task()
    block = Block()
    block._parent = obj
    result = block.get_first_parent_include()
    assert result is None


# Generated at 2022-06-23 05:58:00.852684
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError
    from unit.mock.loader import DictDataLoader
    from unit.mock.path import mock_unfrackpath_noop
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
   

# Generated at 2022-06-23 05:58:10.294734
# Unit test for method load of class Block
def test_Block_load():
	data = {u'block': [{u'block': [{u'debug': {u'msg': u'something here'}}]}], u'notify': {u'msg': u'no'}}
	play = None
	parent_block = None
	role = None
	task_include = None
	use_handlers = False
	variable_manager = None
	loader = None
	obj = Block.load(data, play=play, parent_block=parent_block, role=role, task_include=task_include, use_handlers=use_handlers, variable_manager=variable_manager, loader=loader)
	obj.get_vars()
	obj.load_data(data)
	obj.dump_opts()
	obj.post_validate(templar=None)
	obj.dep_chain

# Generated at 2022-06-23 05:58:15.635479
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    block1 = Block()
    block2 = Block()
    assert block1.get_include_params() == dict()
    block1.set_loader(Mock())
    assert block1.get_include_params() == dict(loader=block1._loader)
    assert block2.get_include_params() == dict()


# Generated at 2022-06-23 05:58:28.155181
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    host_1 = Host(name='host_1')
    host_2 = Host(name='host_2')
    host_3 = Host(name='host_3')

    vars_manager = VariableManager()
    vars_manager.add_host_variable(host_1, 'server_id', '1')

    inventory = Inventory(host_list=[host_1, host_2, host_3])

    host_pattern = "all"

# Generated at 2022-06-23 05:58:31.301159
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():

    def evaluate_block(block):
        task_list = block.filter_tagged_tasks()
        return task_list

    return evaluate_block

# END of dynamically generated code for Block()

# Generated at 2022-06-23 05:58:40.451483
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    # Create block with parent and task
    b1 = Block(parent_block=Block(parent_block=Block()), block=[Task()])
    # Block only has access to its own vars, so get_vars returns a copy of b1.vars
    assert b1.get_vars() == b1.vars
    # b1's parent has access to b1's vars, so get_vars returns a copy of those vars
    assert b1.get_vars() == b1.parent._attributes.get('vars')
    # b1's grandparent has access to its parent's vars, so get_vars returns a copy of those vars
    assert b1.get_vars() == b1.parent.parent._attributes.get('vars')
    # Create a grandparent block with a task that has

# Generated at 2022-06-23 05:58:43.284769
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block = Block()
    assert repr(block) == "Block(block=None, always=None, rescue=None)"


# Generated at 2022-06-23 05:58:51.656455
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    yaml_data = '''
    - block:
        - name: Play
          hosts: all
          gather_facts: False
          tasks:
            - name: MyTask
              debug:
                msg: 'Hello, World!'
    '''
    data = yaml.safe_load(yaml_data)
    play = Play.load(data[0], variable_manager=VariableManager(), loader=DataLoader())
    task = play.get_tasks()[0]
    block = task.block
    loader = DataLoader()
    block.set_loader(loader)
    assert block.get_loader() == loader

if __name__ == '__main__':
    test_Block_set_loader()

# Generated at 2022-06-23 05:58:54.359508
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    a = ansible.playbook.task.Task()
    a.set_loader('loader')
    assert a._loader == 'loader'


# Generated at 2022-06-23 05:59:02.848356
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    # Create Block1
    class TestBlock(Block):
        _valid_attrs = frozenset(('tasks', 'rescue', 'always', 'name', 'vars'))
    block1 = TestBlock(block=[])

    # Create Block2, which is child of Block1
    block2 = TestBlock(block=[], parent = block1)

    # Create Block3, which is child of Block2
    block3 = TestBlock(block=[], parent = block2)

    # Create included task, which is child of Block3
    class IncludedTask(object):
        def __init__(self, parent):
            self._parent = parent

    class TaskInclude(IncludedTask):
        pass

    task_include = TaskInclude(parent = block3)

    # Create Block4, which is child of included task

# Generated at 2022-06-23 05:59:05.153403
# Unit test for method serialize of class Block
def test_Block_serialize():

    obj = Block()

    # serialize result has correct type
    assert isinstance(obj.serialize(), dict)

# Generated at 2022-06-23 05:59:18.123401
# Unit test for method copy of class Block
def test_Block_copy():
    def _dupe_task_list(task_list, new_block):
        new_task_list = []
        for task in task_list:
            new_task = task.copy(exclude_parent=True)
            if task._parent:
                new_task._parent = task._parent.copy(exclude_tasks=True)
                if task._parent == new_block:
                    # If task._parent is the same as new_block, just replace it
                    new_task._parent = new_block
                else:
                    # task may not be a direct child of new_block, search for the correct place to insert new_block
                    cur_obj = new_task._parent
                    while cur_obj._parent and cur_obj._parent != new_block:
                        cur_obj = cur_obj._parent

                    cur_obj._parent

# Generated at 2022-06-23 05:59:26.231938
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    mock_loader = {}
    mock_dep = {}
    mock_loader['mock_loader'] = 'mock_loader'
    mock_dep['mock_dep'] = 'mock_dep'
    block = Block()
    block._loader = None
    block.set_loader(mock_loader)
    print("Set loader test passed")
    # block._dep_chain = {}
    block._dep_chain = []
    block._dep_chain.append(mock_dep)
    block.set_loader(mock_loader)
    print("Setting loader for dep chain test passed")

# Generated at 2022-06-23 05:59:28.012504
# Unit test for method serialize of class Block
def test_Block_serialize():
    block = Block()
    block.serialize()



# Generated at 2022-06-23 05:59:34.355615
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    block = Block.load(dict(block=[dict(action=dict(module='debug', args=dict(msg='{{test_var}}')))]), variable_manager=VariableManager(), loader=DataLoader())
    vars = dict(test_var='success')
    block.vars = vars
    assert block.get_include_params() == {}


# Generated at 2022-06-23 05:59:35.536339
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    b = Block()
    b.get_dep_chain()


# Generated at 2022-06-23 05:59:49.886517
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    ##########
    # test 1
    ##########
    # arrange
    all_vars = {}
    block = Block(
        use_handlers = False,
        rescue = [],
        always = [
            Task(action="echo", args={
                    "msg": "This task will execute always"
                }, register=None),
            Task(action="meta", args={
                    "end_play": True
                }, register=None)
        ],
        block = [
            Task(action="fail", args={
                    "msg": "This task will fail."
                }, register=None)
        ],
        role = None,
        implicit = False,
        parent_block = None,
        task_include = None,
        play = Play()
    )
    block.task_include = TaskInclude()
    block.task

# Generated at 2022-06-23 05:59:51.008361
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    pass


# Generated at 2022-06-23 05:59:55.999245
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    b = Block(play=dict(vars=dict(a=1)))
    assert b.get_vars() == dict(a=1)
    b = Block(play=dict(vars=dict(a=1)))
    b._attributes['vars'] = dict(b=1)
    assert b.get_vars() == dict(a=1, b=1)


# Generated at 2022-06-23 05:59:56.868207
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    pass



# Generated at 2022-06-23 06:00:00.005891
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    '''
    Test __repr__ of class Block
    '''
    block = Block()
    out = block.__repr__()
    assert out is not None
    assert isinstance(out, str)

# Generated at 2022-06-23 06:00:01.018785
# Unit test for constructor of class Block
def test_Block():
    b = Block()


# Generated at 2022-06-23 06:00:02.911802
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
# create task block with no task content

# Generated at 2022-06-23 06:00:07.108724
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    try:
        block.set_loader(None)
    except:
        pass
    else:
        raise AssertionError("Unable to test Block.set_loader()")


# Generated at 2022-06-23 06:00:17.905027
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    dat = {}
    dat['block'] = "block"
    dat['rescue'] = "rescue"
    dat['always'] = "always"
    dat['when'] = "when"
    dat['tags'] = "tags"
    dat['name'] = "name"
    dat['register'] = "register"
    dat['changed_when'] = "changed_when"
    dat['failed_when'] = "failed_when"
    dat['ignore_errors'] = "ignore_errors"
    dat['delegate_to'] = "delegate_to"
    dat['transport'] = "transport"
    dat['until'] = "until"
    dat['retries'] = "retries"
    dat['delay'] = "delay"
    dat['become'] = "become"
    dat['become_user']

# Generated at 2022-06-23 06:00:18.946384
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    pass


# Generated at 2022-06-23 06:00:28.825475
# Unit test for method is_block of class Block
def test_Block_is_block():
    # Check the results of a test with string
    is_block = Block.is_block('hello')
    assert is_block == False
    # Check the results of a test with dict
    is_block = Block.is_block(
        {'block': 'hello'})
    assert is_block == True
    # Check the results of a test with dict
    is_block = Block.is_block(
        {'block': 'hello', 'rescue': 'hello'})
    assert is_block == True
    # Check the results of a test with dict
    is_block = Block.is_block(
        {'block': 'hello', 'rescue': 'hello', 'always': 'hello'})
    assert is_block == True
    # Check the results of a test with dict

# Generated at 2022-06-23 06:00:38.525100
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    '''
    Unit test for method has_tasks of class Block
    '''
    block = Block()
    assert block.has_tasks() is False
    # Undefined block
    block = Block()
    block.block.append(MagicMock())
    assert block.has_tasks()
    assert_equal(block.has_tasks(), True)

    # Defined block
    block = Block(block=[{
        'name': 'Task Name',
        'action': {'module': 'shell', 'args': 'ls -l'},
    }])
    assert_equal(block.has_tasks(), True)



# Generated at 2022-06-23 06:00:48.516964
# Unit test for method deserialize of class Block

# Generated at 2022-06-23 06:00:49.233921
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    pass

# Generated at 2022-06-23 06:00:58.630837
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():    
    def create_args(obj):
        if isinstance(obj, dict):
            args = dict()
            for k, v in obj.items():
                args[k] = create_args(v)
            return args
        return obj

    # Create arguments for the new object.
    args = create_args(block_args)
    # Create new object.
    self = Block(**args)
    # unit test get_dep_chain
    print("UNIT TEST START: Block.get_dep_chain()")
    self.get_dep_chain()
    print("UNIT TEST END: Block.get_dep_chain()")

# Generated at 2022-06-23 06:01:04.548769
# Unit test for method deserialize of class Block
def test_Block_deserialize():

    b = Block(play = None, parent_block = None, role = None, task_include = None)

    data = {'block': None, 'rescue': None, 'always': None, 'dep_chain': None, 'role': None, 'parent': None, 'parent_type': None}

    b.deserialize(data)


# Generated at 2022-06-23 06:01:12.346235
# Unit test for constructor of class Block
def test_Block():
    myBlock = Block(rescue=[])
    fail_json = dict(failed=True)
    exit_json = dict(changed=False)
    success_json = dict(failed=False)
    assert isinstance(myBlock.block, list)
    assert isinstance(myBlock.rescue, list)
    assert isinstance(myBlock.always, list)
    assert isinstance(myBlock.get_dep_chain(), list)
    assert isinstance(myBlock.serialize(), dict)
    assert isinstance(myBlock.deserialize(exit_json), dict)
    assert isinstance(myBlock.copy(), Block)
    assert isinstance(myBlock.get_vars(), dict)
    assert isinstance(myBlock.set_loader, types.MethodType)
    assert isinstance(myBlock.get_loader(), DataLoader)

# Generated at 2022-06-23 06:01:15.624441
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    b = Block()
    assert(repr(b) == '<Block (/home/user/ansible/lib/ansible/playbook/block.py:40, block #0)>')

# Generated at 2022-06-23 06:01:17.374025
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block({'block': 'abc'}) is True

# Generated at 2022-06-23 06:01:29.819294
# Unit test for constructor of class Block
def test_Block():
    b = Block()
    assert b._play is None
    assert b.always is None
    assert b.block is None
    assert b.rescue is None
    assert b._role is None
    assert b.when is None
    assert b.name is None
    assert isinstance(b.register, basestring)
    assert isinstance(b.ignore_errors, bool)
    assert isinstance(b.no_log, bool)
    assert isinstance(b._attributes, dict)

    play_ds = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        user = 'darth'
    )
    play = Play().load(play_ds, variable_manager=VariableManager(), loader=DictDataLoader())
    b = Block(play=play)


# Generated at 2022-06-23 06:01:34.313289
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.play_context import PlayContext

    b = Block(play=PlayContext())
    b.block = [dict(name='foo', action='asdf')]
    assert b.all_parents_static() == True

# Generated at 2022-06-23 06:01:36.876672
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    import ansible.playbook
    b1 = ansible.playbook.Block()
    b2 = ansible.playbook.Block()
    assert b1 != b2


# Generated at 2022-06-23 06:01:41.866366
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    # Testing when play is None, role is None and all_parents_static() is True, implicit is True and block is None, rescue is None and always is None
    block1 = Block(play=None, role=None, implicit=True)
    block2 = Block(play=None, role=None, implicit=True)
    assert block1.__eq__(block2) == True



# Generated at 2022-06-23 06:01:44.098178
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    assert Block.has_tasks is Sentinel  # True


# Generated at 2022-06-23 06:01:47.358281
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    _Block = Block()
    assert _Block == _Block
    assert _Block != 10
    assert _Block != 'Block'
    assert _Block != tuple()


# Generated at 2022-06-23 06:01:58.462767
# Unit test for method filter_tagged_tasks of class Block

# Generated at 2022-06-23 06:01:59.253061
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    pass

# Generated at 2022-06-23 06:02:00.316710
# Unit test for constructor of class Block
def test_Block():
    _ = Block()
    assert True


# Generated at 2022-06-23 06:02:03.789632
# Unit test for method is_block of class Block
def test_Block_is_block():
  block = Block()
  ds = dict()
  ds['block'] = [{'hosts': 'host1', 'name': 'test1'}]
  assert block.is_block(ds)


# Generated at 2022-06-23 06:02:05.961716
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block
    assert block._loader == None
    return


# Generated at 2022-06-23 06:02:11.270819
# Unit test for constructor of class Block
def test_Block():
    ds = {}
    b = Block(ds, play=None, parent_block=None, role=None, task_include=None, use_handlers=False)
    assert not b.block and not b.rescue and not b.always and not b.tags


# Generated at 2022-06-23 06:02:11.898963
# Unit test for method copy of class Block
def test_Block_copy():
    pass

# Generated at 2022-06-23 06:02:23.301623
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # setup
    playbook_name = 'test_playbook.yml'
    file_name = __file__
    playbook_path = os.path.realpath(os.path.join(os.path.dirname(file_name), '..', '..', 'test', 'units', playbook_name))
    loader, inventory, variable_manager = ansible_test_setup()
    play_source = load_playbook_file(playbook_path, variable_manager=variable_manager, loader=loader)
    MyPlay = namedtuple('MyPlay', ['hosts', 'name', 'sequence', 'variable_manager'])
    play = MyPlay(hosts="all", name="name", sequence=play_source, variable_manager=variable_manager)

    # test

# Generated at 2022-06-23 06:02:31.666014
# Unit test for method load of class Block
def test_Block_load():
    '''
    Unit test for method load of class Block
    '''
    data = [
      {'block': [
        {'meta': [
          {'end_play': True},
          {'end_play': True}
        ]},
        {'meta': [
          {'end_play': True},
          {'end_play': True}
        ]}
      ]}
    ]

    b = Block.load(data)


# Generated at 2022-06-23 06:02:42.242175
# Unit test for method set_loader of class Block

# Generated at 2022-06-23 06:02:52.701187
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    host = Host(name = '127.0.0.1')
    t = Task()
    t._role = None
    t.vars = dict(a=1, b=2, c=3)
    t.private_variables = 'ignore'

    b = Block(play=None)
    b._attributes = dict(vars=dict(d=4, e=5, f=6))
    b.block = [t]
    b._dep_chain = None

    t2 = Task()
    t2._role = None
    t2.vars = dict(a=1, b=2, c=3)
    t2.private_variables = 'ignore'

    r = Role()
    r._attributes = dict(vars=dict(g=7, h=8, i=9))
