

# Generated at 2022-06-23 05:53:00.300582
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.template import Templar

    block_1 = Block()
    block_2 = Block()
    block_3 = Block()
    task_1 = TaskInclude()
    task_2 = TaskInclude()
    task_3 = TaskInclude()
    block_1.block = [block_2]
    block_2.block = [block_3]
    block_3.block = [task_1]
    block_3.rescue = [task_2]

# Generated at 2022-06-23 05:53:02.548174
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    block = Block()
    Block.__eq__(block, block)

# Generated at 2022-06-23 05:53:13.429236
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    o = Block()
    o._attributes = dict(vars=dict(a=1))
    o._play = None
    o._task_include = None
    o._role = None
    o._parent = None
    o._dep_chain = []
    assert o.get_vars() == dict(a=1)
    assert o.get_vars(include_deps=True) == dict(a=1)
    del(o._attributes)
    assert o.get_vars() == dict()
    assert o.get_vars(include_deps=True) == dict()
    o._attributes = dict(vars=dict(a=1), othervars=dict(b=2))
    assert o.get_vars() == dict(a=1, b=2)

# Generated at 2022-06-23 05:53:22.528512
# Unit test for method serialize of class Block
def test_Block_serialize():
    arguments = {"self": { "statically_loaded": "AsQYap8nXPWJyhR6CfHg", "block": [ { "__ansible_module__": "setup", "__ansible_arguments__": "" }, { "__ansible_module__": "debug", "__ansible_arguments__": "msg: Hello world!\n" } ], "rescue": [ { "__ansible_module__": "debug", "__ansible_arguments__": "msg: Rescue: something bad happened!\n" } ], "always": [ { "__ansible_module__": "debug", "__ansible_arguments__": "msg: Always: something happened!" }, { "__ansible_module__": "debug", "__ansible_arguments__": "msg: Always: and something else!" } ] }}


# Generated at 2022-06-23 05:53:31.354490
# Unit test for constructor of class Block
def test_Block():
    b = Block()
    assert b.block is None
    assert b.rescue is None
    assert b.always is None
    assert b.only_tags == None
    assert b.skip_tags == None
    assert b.dep_chain == None
    assert b._attributes_to_remove == []


# Unit test to check object equality of two Block objects
# Equality in this case means that the parent is the same and Block objects
# are created with the same attributes

# Generated at 2022-06-23 05:53:40.045108
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    data = {'block':['task1'], 'rescue':['task2'], 'always':['task3']}
    b = Block.load(data)

    assert(b.block[0].__class__.__name__ == 'Task')
    assert(b.block[0].has_triggered == False)

    assert(b.rescue[0].__class__.__name__ == 'Task')
    assert(b.rescue[0].has_triggered == False)

    assert(b.always[0].__class__.__name__ == 'Task')
    assert(b.always[0].has_triggered == False)


# Generated at 2022-06-23 05:53:41.920061
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    a = Block(name='a')
    b = Block(name='a')
    assert a == b

# Generated at 2022-06-23 05:53:47.371494
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    pass


# Generated at 2022-06-23 05:53:51.911355
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    '''
    unit test for method has_tasks of class Block
    '''
    global context
    obj = context.Block()
    result = obj.has_tasks()
    assert result == False

# Generated at 2022-06-23 05:54:02.044519
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    # create an instance of class Block with some valid arguments
    block = Block(play = "", parent_block = "", role = "", task_include = "", use_handlers = "")

    # Check the values returned by method get_vars of class Block
    # It should be a dictionary with a single key
    assert(isinstance(block.get_vars(), dict) == True)
    assert(len(block.get_vars()) == 1)

    # test method get_vars of class Block with wrong type of argument
    try:
        block.get_vars('')
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-23 05:54:13.372751
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():

    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    host_list = [
        'localhost',
    ]
    inventory = Inventory(loader=None, variable_manager=None, host_list=host_list)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    play_context = PlayContext(variable_manager=variable_manager)

    play = Play().load(dict(
        name='test',
        hosts=host_list,
        gather_facts='no',
    ), variable_manager=variable_manager, loader=None)

# Generated at 2022-06-23 05:54:24.781554
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    b = Block()
    b.deserialize({})
    b=Block()
    b.deserialize({'role': {}, 'parent_type': 'Block', 'parent': {}})
    b=Block()
    b.deserialize({'dep_chain': [{'role': {}, 'parent_type': 'Block', 'parent': {}}], 'role': {}, 'parent_type': 'Block', 'parent': {}})
    b=Block()

# Generated at 2022-06-23 05:54:29.199429
# Unit test for method serialize of class Block
def test_Block_serialize():
    # Test only idempotent tasks
    block = Block(
        use_handlers=True,
        task_include='some/template'
    )
    block.deserialize(dict(
        handlers=[]
    ))
    assert isinstance(block.serialize(), dict)

# Generated at 2022-06-23 05:54:34.925108
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    test1_vars = dict()
    test1_block = Block()
    result1 = test1_block.get_vars()
    assert result1 == test1_vars
    # No need to test more
    # Because the default value of _attributes is dict().
    # So the results of get_vars() method are always same.


# Generated at 2022-06-23 05:54:39.182250
# Unit test for constructor of class Block
def test_Block():
    b = Block()
    assert b.block is None
    assert b.rescue is None
    assert b.always is None

# Generated at 2022-06-23 05:54:46.823702
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host

    block = Block()
    task = Task()

    task.vars = dict (
        ansible_ssh_private_key_file = '/home/ansible/.ssh/secret_key',
        ansible_ssh_host = '192.168.1.2',
        ansible_ssh_port = '2222',
        ansible_ssh_user = 'user1',
        ansible_ssh_pass = '123456',
        ansible_connection = 'ssh',
        ansible_become = 'yes',
        ansible_become_user = 'root',
        ansible_network_os = 'ios',
        ansible_python_interpreter = '/usr/bin/python'
    )

    task._

# Generated at 2022-06-23 05:54:57.359551
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    blk = Block()
    blk._play = None
    blk._role = None
    
    # Test 1   
    # value = {u'block': [{u'run_once': True, u'ignore_errors': True, u'name': u'Copy public key to authorized_keys', u'local_action': {u'command': u'yes | ssh-keygen -i -f /tmp/key.pub > /root/.ssh/authorized_keys'}}]}

# Generated at 2022-06-23 05:55:05.632909
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    '''
    This method helps to test get_first_parent_include()
    '''
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    test_obj = Block(None, None, None, None, None)
    task_include = TaskInclude(None, None, None, None, None, None, None, None, None, None, None)
    task_include.statically_loaded = True
    test_obj._parent = task_include
    assert test_obj.get_first_parent_include().statically_loaded

# Generated at 2022-06-23 05:55:14.880904
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block()
    assert not b.has_tasks()
    assert not b.has_tasks(), 'has_tasks() failed: should be false, but is true.'
    b = Block(block=[])
    assert not b.has_tasks()
    assert not b.has_tasks(), 'has_tasks() failed: should be false, but is true.'
    b = Block(block=[Task()])
    assert b.has_tasks()
    assert b.has_tasks(), 'has_tasks() failed: should be true, but is false.'
    b = Block(block=[])
    b.rescue = [Task()]
    assert b.has_tasks()
    assert b.has_tasks(), 'has_tasks() failed: should be true, but is false.'

# Generated at 2022-06-23 05:55:20.173582
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    # Create mock object
    
    
    
    
    
    
    
    
    
    
    
    
    # Get attribute
    # Call method with arguments
    # Check if the outcome is what we expect
    
    
    
    
    
    
    
    
    pass
# End of test #


# Generated at 2022-06-23 05:55:24.274910
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    p = Block()
    p._attributes['foo'] = 'bar'
    p._attributes['baz'] = 'bat'
    p1 = Block()
    p1._parent = p
    p2 = Block()
    p2._parent = p1
    assert p2.get_include_params() == {'foo': 'bar', 'baz': 'bat'}

# Generated at 2022-06-23 05:55:34.557504
# Unit test for method is_block of class Block
def test_Block_is_block():
    block_test_1 = Block.is_block({
        'block': ['test']
    })
    assert block_test_1 is True
    block_test_2 = Block.is_block({
        'rescue': ['test']
    })
    assert block_test_2 is True
    block_test_3 = Block.is_block({
        'always': ['test']
    })
    assert block_test_3 is True
    block_test_4 = Block.is_block({
        'not_block': 'test'
    })
    assert block_test_4 is False
    block_test_5 = Block.is_block('not a block')
    assert block_test_5 is False
    block_test_6 = Block.is_block(['not a block'])

# Generated at 2022-06-23 05:55:41.854914
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    t = Block()
    assert t.preprocess_data(None) is None
    assert t.preprocess_data({}) == {}
    assert t.preprocess_data({'block': []}) == {'block': []}
    assert t.preprocess_data({'block': ['test']}) == {'block': ['test']}
    assert t.preprocess_data(['test']) == {'block': ['test']}
    assert t.preprocess_data({'block': ['test']}) == {'block': ['test']}

# Generated at 2022-06-23 05:55:51.354857
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    # Initialize class objects
    # Block(validate_only=False, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    # here implicit = False by default and play=None implying that _play = None
    # Injecting task_include (TaskInclude(static=True)) in Block
    # check for the play object, it should be task_include object
    task_include = TaskInclude(static=True)
    task_include.set_loader(None)
    block_obj = Block(False, task_include)

    # Testing for object = object
    block_obj_new = block_obj
    assert block_obj.__ne__(block_obj_new) is False
    
    # Testing for object = None

# Generated at 2022-06-23 05:55:53.407319
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    block = Block()
    assert block == block

# Generated at 2022-06-23 05:56:04.456305
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    name = 'ansible.playbook.block.Block'
    m = sys.modules[name]
    if hasattr(m, 'test_Block_set_loader'):
        return
    setattr(m, 'test_Block_set_loader', 1)

    class AnsibleUnsafeText(object):
        def __init__(self, value):
            self.value = value


    class AnsibleUnsafeBytes(object):
        def __init__(self, value):
            self.value = value


    Block.unsafe_text = AnsibleUnsafeText
    Block.unsafe_bytes = AnsibleUnsafeBytes
    def ansible_module_common_new(self):
        pass
    Block.ansible_module_common_new = ansible_module_common_new
    import copy

# Generated at 2022-06-23 05:56:08.336177
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Construct the arguments
    args = dict()
    # Instantiate the object
    b = Block(**args)

    # Call the method
    res = b.get_dep_chain()
    print(res)


# Generated at 2022-06-23 05:56:16.523290
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    # TODO: implement test for function __eq__
    block1 = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=None)
    block2 = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=None)
    assert block1.__eq__(block2)

# Generated at 2022-06-23 05:56:22.379289
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    print("Unittesting ansible.playbook.block.Block_get_include_params():")
    # TODO: Make unit test for this method of class Block
    # Method that should be tested:
    #   get_include_params
    print("<skipped>\n")


# Generated at 2022-06-23 05:56:25.461181
# Unit test for method serialize of class Block
def test_Block_serialize():
    # Block() without parameters
    with pytest.raises(AnsibleUndefinedVariable):
        # Note: serialize is a instance method, it should be called from an instance
        block = Block()
        block.serialize()

# Generated at 2022-06-23 05:56:36.664711
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from .. import VariableManager
    from .hosts import Host
    from .task import Task
    from .task_include import TaskInclude
    from .role import Role
    from .playbook.block import Block
    from .playbook.play_context import PlayContext
    from .playbook.play import Play
    from .loader import DataLoader

    loader = DataLoader()

    ############################################
    # CASE 1: tag([], [])
    ############################################
    print('CASE 1: tag([], [])')
    block = Block.load(dict(
        block=[
            dict(
                task=dict(
                    action="shell", args="echo 1")),
            dict(
                task=dict(
                    action="shell", args="echo 2")),
        ]
    ))
    new_block = block.filter_tag

# Generated at 2022-06-23 05:56:49.075124
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    loader = Mock()


# Generated at 2022-06-23 05:56:59.223186
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # create local play
    play = Play().load({
        'name': 'test play',
        'hosts': 'all',
        'gather_facts': 'no',
    }, variable_manager=VariableManager(), loader=DictDataLoader())
    # test if method raises no exception
    assert(Block.preprocess_data([{
        'block:': 'myblock',
        'task': {
            'name': 'test task',
            'action': 'command',
            'args': 'echo "{{ myvar }}"',
        },
    }], play=play) == [{
        'block': [{
            'name': 'test task',
            'action': 'command',
            'args': 'echo "{{ myvar }}"',
        }],
    }])
    # test if method raises no exception

# Generated at 2022-06-23 05:57:06.159022
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    data = dict(name='foo')
    new_block = block.copy()

    # test __init__(self, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    assert new_block._attributes == dict()
    assert new_block._parent is None
    assert new_block._use_handlers is False

    #test @property
    assert new_block.name == 'foo'
    assert new_block.block == []
    assert new_block.rescue == []
    assert new_block.always == []
    assert new_block.any_errors_fatal == C.DEFAULT_ANY_ERRORS_FATAL
    assert new_block.changed_when == C.DEFAULT_BLOCK_CHANGED

# Generated at 2022-06-23 05:57:17.001505
# Unit test for method copy of class Block
def test_Block_copy():
    p = Play.load({'name': 'test-play',
                   'hosts': "127.0.0.1",
                   'gather_facts': True,
                   'roles': [{'role': 'dummy'}]})
    b = Block(play=p)

    # test calling copy without arguments
    b_copy = b.copy()

    # test calling copy with exclude_parent argument
    b = Block(play=p)
    b_copy = b.copy(exclude_parent=True)

    # test calling copy with exclude_tasks argument
    b = Block(play=p)
    b_copy = b.copy(exclude_tasks=True)



# Generated at 2022-06-23 05:57:20.023580
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    bl = Block(["t"], None, None, None, None)
    print(bl.has_tasks())


if __name__ == '__main__':
    test_Block_has_tasks()

# Generated at 2022-06-23 05:57:25.337007
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block = Block()
    # Preprocess Data
    assert block.preprocess_data('{"block": {"block": [1, 2, 3]}}') == {'block': [1, 2, 3]}
    assert block.preprocess_data('{"block": [1, 2, 3]}') == {'block': [1, 2, 3]}
    assert block.preprocess_data([1, 2, 3]) == {'block': [1, 2, 3]}

# Generated at 2022-06-23 05:57:26.561087
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False

# Generated at 2022-06-23 05:57:29.558570
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block()
    b1 = b.copy()
    assert b1 is not None and b1 != ""


# Generated at 2022-06-23 05:57:38.804284
# Unit test for constructor of class Block
def test_Block():
    # Test: Explicit constructor
    role = Role()
    role.get_name = Mock(return_value='test_role')
    block = Block(play=None, parent_block=None, role=role, task_include=None, use_handlers=False, implicit=True)
    assert block._parent is None
    assert block._play is None
    assert block._role is role
    assert block._task_include is None
    assert block._use_handlers is False
    assert block._implicit is True
    assert block._dep_chain is None
    assert len(block.block) == 0
    assert len(block.rescue) == 0
    assert len(block.always) == 0

# Generated at 2022-06-23 05:57:49.287090
# Unit test for method load of class Block
def test_Block_load():
    dict1 = dict(block=dict(), rescue=dict(), always=dict())
    dict2 = dict()
    dict3 = dict(block=dict())
    dict4 = dict(block=dict(block=dict()), rescue=dict(), always=dict())
    dict5 = dict(block=dict(block=dict()))
    dict6 = dict(block=dict(block=dict(block=dict())))
    dict7 = dict(block=dict(block=dict(block=dict(), rescue=dict(), always=dict())), rescue=dict(), always=dict())
    dict8 = dict(block=dict(block=dict(block=dict(), rescue=dict(), always=dict())))

# Generated at 2022-06-23 05:57:53.586190
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    b = Block()
    assert repr(b) == "<Block (implicit={}) name=None>".format(b._implicit_name)


# Generated at 2022-06-23 05:58:04.837537
# Unit test for method serialize of class Block
def test_Block_serialize():
    block_instance = Block()
    block_instance.block = Sentinel
    block_instance.rescue = Sentinel
    block_instance.always = Sentinel
    block_instance.when = 'mars'
    assert block_instance.serialize() == {'when': 'mars', 'dep_chain': None}
    block_instance._dep_chain = ['a', 'b']
    assert block_instance.serialize() == {'when': 'mars', 'dep_chain': ['a', 'b']}
    block_instance._dep_chain = ['a', 'b', Sentinel]
    assert block_instance.serialize() == {'when': 'mars', 'dep_chain': ['a', 'b']}
    block_instance._dep_chain = ['a', 'b', 'not_Sentinel']
    assert block_instance.serial

# Generated at 2022-06-23 05:58:10.839561
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    g = GlobalLoader()
    ds = dict(name="test play", hosts='localhost', connection='local', gather_facts='no')
    p = Play().load(ds, variable_manager=VariableManager(), loader=g)
    r = Role().load(dict(name="test role"), variable_manager=VariableManager(), loader=g)
    block = Block(play=p, parent_block=None, role=r, task_include=None, use_handlers=False, implicit=False)
    block.set_loader(g)
    
    

# Generated at 2022-06-23 05:58:17.832190
# Unit test for constructor of class Block
def test_Block():
    block = Block.load(dict(block=[]))
    assert isinstance(block, Block)
    assert block.parent_block is None
    assert block.dep_chain is None
    assert block.block == []
    assert block.rescue is None
    assert block.always is None
    assert block.when == 'True'
    assert block.loop is None
    assert block.continue_, False
    assert block.register is None
    assert block.any_errors_fatal is False
    assert block.failed_when == 'False'
    assert block.tags == []
    assert block.ignore_errors is False

# Generated at 2022-06-23 05:58:27.800570
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    if not os.path.exists('temp/playbook') and os.path.exists('temp'):
        os.mkdir('temp/playbook')
    if os.path.exists('temp/playbook'):
        os.chdir('temp/playbook')
        copyfile('../../../test/unit/module_utils/test_block.yml','test_block.yml')
        callback = callbacks.AggregateStats()
        runner = Runner(
            pattern='test_block.yml',
            inventory=None,
            variable_manager=None,
            loader=None,
            options=None,
            passwords=None,
            stdout_callback=callback,
            run_tree=False,
            )
        runner.run()
        # The "block" task list should have 3 tasks, which makes has

# Generated at 2022-06-23 05:58:30.900038
# Unit test for method __eq__ of class Block
def test_Block___eq__():

    # Create a block
    b = Block()

    # Create a second block
    b2 = Block()

    # Test comparison between b and b2
    assert b == b2


# Generated at 2022-06-23 05:58:35.595630
# Unit test for constructor of class Block
def test_Block():
    block = Block(
        parent_block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        implicit=False,
    )
    assert block._parent is None
    assert block._role is None
    assert block._task_include is None
    assert block._use_handlers == False
    assert block._implicit == False

# Generated at 2022-06-23 05:58:47.845342
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    host = Host()
    play = Play()
    block1 = Block()
    block2 = Block()
    sub_block = Block()
    task = Task()
    block1.load_data({'block':{'block':[]}})
    block2.load_data({'block':{'block':[]}})
    sub_block.load_data({'block':{'block':[]}})
    task.load_data({'name':'task'})
    host.set_variable('host_var', 'host_var')
    play.set_variable('play_var', 'play_var')
    block1.set_variable('block1_var1', 'block1_var1')
    block2.set_variable('block2_var2', 'block2_var2')
    sub_block.set_variable

# Generated at 2022-06-23 05:58:54.609392
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    '''
      Unit test for method set_loader of class Block
    '''
    # From /usr/local/lib/python2.7/dist-packages/ansible/playbook/block.py
    play = Base.load('Playbook')(loader=MagicMock())
    block = Block(play=play, use_handlers=MagicMock())
    loader = MagicMock()
    block.set_loader(loader)
    assert loader == block._loader


# Generated at 2022-06-23 05:59:03.014217
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    import sys
    import os

    # FIXME: remove this ugly hack
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))

    if __name__ == '__main__':
        from ansible.playbook import Play
        from ansible.constants import DEFAULT_HANDLERS_PATH, DEFAULT_HOST_LIST
        from ansible.inventory import Inventory
        from ansible.vars import VariableManager
        from ansible.parsing.dataloader import DataLoader

        loader = DataLoader()
        variable_manager = VariableManager()
        variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list=DEFAULT_HOST_LIST))

        # TaskInclude, Task and Block are loaded correctly
        test_file

# Generated at 2022-06-23 05:59:05.633893
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block_obj = Block()
    block_obj._attributes['name'] = 'test123'
    assert repr(block_obj) == "Block (name=test123)"


# Generated at 2022-06-23 05:59:18.329823
# Unit test for constructor of class Block
def test_Block():
    my_block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False)
    my_block.block = [
        dict(action='first'),
        dict(action='second', meta='dynamic')
        ]
    my_block.rescue = [
        dict(action='third'),
        dict(action='fourth', meta='dynamic')
        ]
    my_block.always = [
        dict(action='fifth'),
        dict(action='sixth', meta='dynamic')
        ]

    assert (my_block.block[0].action == 'first')
    assert (my_block.rescue[1].action == 'fourth')
    assert (my_block.always[0].action == 'fifth')

# Generated at 2022-06-23 05:59:26.948075
# Unit test for constructor of class Block
def test_Block():
    # not block
    ds = dict()
    b = Block(use_handlers=True, implicit=True)
    b.load_data(ds)
    if not isinstance(b, Block):
        raise Exception("Block init failed")
    elif not b._implicit:
        raise Exception("Block init failed 2")

    # block
    ds = dict(block=[])
    b = Block(use_handlers=False, implicit=False)
    b.load_data(ds)
    if not isinstance(b, Block):
        raise Exception("Block init failed 3")
    elif b._implicit:
        raise Exception("Block init failed 4")

if __name__ == "__main__":
    test_Block()

# Generated at 2022-06-23 05:59:31.609737
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    # Given: test args
    
    
    # When: call method
    b = Block()
    ret = repr(b)
    
    # Then
    assert ret == "<Block />"


# Generated at 2022-06-23 05:59:47.551351
# Unit test for method serialize of class Block
def test_Block_serialize():
    b = Block(play=Play(), parent_block=None, role=None, task_include=None, use_handlers=None, implicit=None)

# Generated at 2022-06-23 05:59:51.485188
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    my_block = Block()
    my_block.block = []
    my_block.rescue = []
    my_block.always = []
    assert repr(my_block) == '<Block(always=[],block=[],rescue=[])>'


# Generated at 2022-06-23 05:59:57.951186
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    t = Block(name="Foo", block=[])
    t2 = Block(name="Foo", block=[])
    assert (t == t2)
    t3 = Block(name="Foo", block=[])
    t3.task_include = True
    assert not (t == t3)
    t4 = Block(name="Foo", block=[])
    t4.statically_loaded = True
    assert (t == t4)
    t5 = Block(name="Foo", block=[])
    t5.role = True
    assert not (t == t5)

# Generated at 2022-06-23 06:00:01.459950
# Unit test for method is_block of class Block
def test_Block_is_block():
    print("Test Block::is_block()")
    test_data = {"block": [{"hosts": ["host_A"], "connection": "local", "name": "Task_A"}]}
    assert Block.is_block(test_data) == True
    test_data = []
    assert Block.is_block(test_data) == False


# Generated at 2022-06-23 06:00:13.862335
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
   
    b1 = Block(play=Play().load({}, loader=None, variable_manager=None), parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False,post_validate=False)
    b2 = Block(play=Play().load({}, loader=None, variable_manager=None), parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False,post_validate=False)

# Generated at 2022-06-23 06:00:24.824978
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.play_context import PlayContext
    import sys

    # test when no parent
    b1 = Block()
    if b1.get_first_parent_include():
        raise AssertionError('Unit test for method get_first_parent_include of class Block failed. Expected to get False as result, but got True')

    # test when no parent and a task-include parent
    t1 = TaskInclude(static=True)
    b2 = Block(parent=t1)

# Generated at 2022-06-23 06:00:36.243332
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block = Block(None, None, None, None, use_handlers=False, implicit=False)
    if not isinstance(block, Block):
        raise AssertionError()
    if not isinstance(block, Base):
        raise AssertionError()

    # try:
    #     block.load_data([])  # TypeError: isinstance() arg 2 must be a type or tuple of types
    #     raise AssertionError()
    # except TypeError:
    #     pass

    b = block.preprocess_data([])
    if not isinstance(b, dict):
        raise AssertionError()
    if b.get('block', None) is None:
        raise AssertionError()

    if b == block.preprocess_data(b):
        raise AssertionError()


# Generated at 2022-06-23 06:00:37.666717
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    b = Block
    assert b == b

# Generated at 2022-06-23 06:00:47.921848
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    # Test with no implicit blocks
    block_dict_1 = {'block':[{'debug':{'var':'msg'}},{'debug':{'var':'msg1'}}]}
    block_obj_1 = Block.load(block_dict_1)
    assert isinstance(block_obj_1, Block)
    assert isinstance(block_obj_1.block[0], Task)
    assert isinstance(block_obj_1.block[1], Task)
    # Test with implicit block

# Generated at 2022-06-23 06:00:59.472971
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    parent_block = Block(parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    parent_block._attributes['metadata'] = {'foo': 'bar'}
    parent_block.statically_loaded = True
    parent_block._dep_chain = None
    parent_block.name = 'task'
    parent_block.block = []
    parent_block.rescue = []
    parent_block.always = []
    parent_block.tags = []

    block = Block(play=None, parent_block=parent_block, role=None, task_include=None, use_handlers=False, implicit=False)
    block._attributes['metadata'] = {'foo': 'bar'}
    block.statically_loaded = True
    block._dep_chain

# Generated at 2022-06-23 06:01:07.567613
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.attribute import Attribute

    # Create Block object
    block = Block()

    # Execute method copy
    result = block.copy()

    # Assert default values
    assert result._valid_attrs["block"].default is None
    assert result._valid_attrs["rescue"].default is None
    assert result._valid_attrs["always"].default is None
    assert result._valid_attrs["loop"].default is None
    assert result._valid_attrs["loop_args"].default is None
    assert result._valid_attrs["any_errors_fatal"].default is None


# Generated at 2022-06-23 06:01:19.666134
# Unit test for method __repr__ of class Block
def test_Block___repr__():

    block = Block.load(
        data=dict(block=dict(hosts=dict(groupa='one'), tasks=dict(debug=dict(msg='This is a test')))),
        play=None,
        parent_block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=None,
        loader=None
    )

    assert block.__repr__() == "<block (1): groupa=one>"
    assert block.block[0].__repr__() == "<tasks (1)>"
    assert block.block[0].block[0].__repr__() == "<debug (1)>"

    block._attributes['name'] = 'foo'


# Generated at 2022-06-23 06:01:31.256169
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    import os
    import sys
    import unittest2 as unittest

    # Create mock objects
    class AnsiblePlaybook:
        def __init__(self):
            self.basedir = '.'
    class AnsiblePlay:
        def __init__(self):
            self.basedir = '.'
            self.playbook = AnsiblePlaybook()
            self.vars = dict()
            self.tags = list()
    class Block(AnsibleBlock):
        def __init__(self, play, parent_block, role, task_include, use_handlers):
            self.play = play
            self.tags = list()
            self._dep_chain = list()
            self._parent = parent_block
            self._role = role
            self._task_include = task_include
            self._use_hand

# Generated at 2022-06-23 06:01:40.918908
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    # Create Objects of class Block
    block_0 = Block()
    block_0.block = [
        dict(action='debug', args=dict(msg='this is block_0')),
    ]

    block_1 = Block()
    block_1.block = [
        dict(action='debug', args=dict(msg='this is block_1')),
    ]
    block_1._parent = block_0

    block_2 = Block()
    block_2.block = [
        dict(action='debug', args=dict(msg='this is block_2')),
    ]
    block_2._parent = block_1

    first_include =  block_2.get_first_parent_include()
    assert(first_include == None)
    #Change the parent to be an instance of task_include

# Generated at 2022-06-23 06:01:49.623826
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    b = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    data = {}
    p = Block()
    p._attributes['continue_on_error'] = False
    p._role = None
    p._parent = None
    new_me = b
    new_me._play = None
    new_me._use_handlers = False
    new_me._dep_chain = None
    new_me._parent = None
    new_me._role = None
    new_me.block = [ ]
    new_me.rescue = [ ]
    new_me.always = [ ]
    data = copy.deepcopy(data)
    # If a simple task is given, an implicit block for that single task
    # is created, which

# Generated at 2022-06-23 06:02:00.192171
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Test playbook call
    playbook = Playbook.load("TESTPLAYBOOK.yml")
    # Get first play
    play = playbook.get_plays()[0]
    # Get block of first play
    block = play.get_block_list()[0]
    # Test filter_tagged_tasks
    block.filter_tagged_tasks({})

# Test added to unit test method get_block_list of class Play
# block = play.get_block_list()[0]
# Test added to unit test method get_dep_chain of class Block
# block.get_dep_chain()

# Test added to unit test method copy of class Block
# new_block = block.copy(exclude_parent=False, exclude_tasks=False)

# Test added to unit test method serialize of class Block
#

# Generated at 2022-06-23 06:02:01.326921
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    print(Block().__repr__())

# Generated at 2022-06-23 06:02:05.921606
# Unit test for method load of class Block
def test_Block_load():
    real_ansible_playbook_callbacks = ansible.playbook.callbacks.default
    ansible.playbook.callbacks.default = Mock()
    # assert Block.load(0) == None


# Generated at 2022-06-23 06:02:10.233312
# Unit test for method load of class Block
def test_Block_load():
    b = Block()
    data = {'block': ['a', 'b']}
    b.load(data, variable_manager=VariableManager(), loader=DataLoader())
    assert b.block[0] == 'a'
    assert b.block[1] == 'b'

# Generated at 2022-06-23 06:02:14.453557
# Unit test for method serialize of class Block
def test_Block_serialize():
  data = {}
  myblock = Block.load(data, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
  retval = myblock.serialize()
  assert retval == {} 


# Generated at 2022-06-23 06:02:20.401580
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    class Block(object):
        def __init__(self):
            self._dep_chain = []
        def get_dep_chain(self):
            return self._dep_chain
    class TaskInclude(object):
        _parent = None
        pass

    b = Block()
    ti = TaskInclude()
    ti._parent = b
    b.get_dep_chain() == ti.get_dep_chain() == []



# Generated at 2022-06-23 06:02:28.060403
# Unit test for method copy of class Block
def test_Block_copy():
    import copy
    import ansible.playbook.base
    import ansible.playbook.block
    import ansible.playbook.handler
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.task
    import ansible.template
    import ansible.utils
    from ansible.parsing.splitter import parse_kv
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    # Instantiate object Block
    b = Block()
    # test method copy
    result = b.copy()
    assert isinstance(result, ansible.playbook.base.Base)
    assert isinstance(result, ansible.playbook.block.Block)
    assert result._attributes != b._attributes
    assert result._att

# Generated at 2022-06-23 06:02:29.637647
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block1 = Block()
    block2 = Block()
    return None

# Generated at 2022-06-23 06:02:32.863331
# Unit test for method copy of class Block
def test_Block_copy():
    b = Block(use_handlers=True)
    assert not b.copy(exclude_parent=True,exclude_tasks=True).has_tasks()


# Generated at 2022-06-23 06:02:45.465872
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    # Test when parent is None
    b = Block(use_handlers=False)
    assert b.all_parents_static()
    # Test when parent is Task object
    t = Task()
    b_child = Block(parent=t, use_handlers=False)
    assert b_child.all_parents_static()
    # Test when parent is Block object
    b_parent = Block(use_handlers=False)
    b_child.update_block_parent(b_parent)
    assert b_child.all_parents_static()
    # Test when parent is TaskInclude object
    ti = TaskInclude()
    b_child.update_block_parent(ti)
    assert not b_child

# Generated at 2022-06-23 06:02:50.926835
# Unit test for method set_loader of class Block
def test_Block_set_loader():

    args = {}
    obj = Block(**args)

    class Args(object):

        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    loader = Args(**{ })
    obj.set_loader(loader)
