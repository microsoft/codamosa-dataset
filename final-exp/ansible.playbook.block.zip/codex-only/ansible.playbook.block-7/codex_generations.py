

# Generated at 2022-06-23 05:52:56.846224
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task import Task

    def method():
        pass

    class Parent():
        def __init__(self):
            self.statically_loaded = True

    parent = Parent()

    root_block = Block(parent=parent)
    assert root_block.all_parents_static()

    block1 = Block(parent=root_block)
    assert block1.all_parents_static()

    block2 = Block(parent=block1)
    assert block2.all_parents_static()

    parent.statically_loaded = False
    assert not block2.all_parents_static()
    assert not block1.all_parents_static()
    assert not root_block.all_parents_static()


# Generated at 2022-06-23 05:52:58.331576
# Unit test for constructor of class Block
def test_Block():
    b = Block()
    assert b.name is None


# Generated at 2022-06-23 05:53:08.078281
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    from ansible.playbook.task import Task

    block = Block()
    assert len(block.block) == 0 and len(block.rescue) == 0 and len(block.always) == 0
    assert not block.has_tasks()

    block.block.append(Task())
    assert block.has_tasks()

    block.block.pop()
    block.rescue.append(Task())
    assert block.has_tasks()

    block.rescue.pop()
    block.always.append(Task())
    assert block.has_tasks()


# Generated at 2022-06-23 05:53:17.291598
# Unit test for method __eq__ of class Block
def test_Block___eq__():

    from ansible.playbook.task import Task
    assert Task(1) == Task(1)
    assert Task(1) != Task(2)
    block1 = Block(name="bla")
    block1.block = [Task(1), Task(2)]
    block2 = Block(name="bla")
    block2.block = [Task(2), Task(1)]
    assert block1 == block2
    assert block1 != Task(1)
    block2 = Block(name="blo")
    block2.block = [Task(1), Task(2)]
    assert block1 != block2
    block2.block = [Task(2), Task(1)]
    block2.block.append(Task(3))
    assert block1 != block2
    block2 = Block(name=None)
    block2.block

# Generated at 2022-06-23 05:53:23.029101
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # test case 1.
    block = Block()
    block._dep_chain = None
    expected = None
    actual = block.get_dep_chain()
    assert actual == expected, 'test case 1 failed'

    # test case 2.
    dep_chain = ['dep_chain']
    block = Block()
    block._dep_chain = dep_chain
    expected = dep_chain[:]
    actual = block.get_dep_chain()
    assert actual == expected, 'test case 2 failed'



# Generated at 2022-06-23 05:53:35.936527
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.debug import debug
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import Callback

# Generated at 2022-06-23 05:53:41.040917
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    b = Block(dep_chain = [], _parent = None, _role = None, _play = None, use_handlers = False, implicit = False)
    assert b.get_dep_chain() == [], "get_dep_chain method failed!"

# Generated at 2022-06-23 05:53:47.895954
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    block_obj = Block()
    result = block_obj.__ne__()
    assert result == True


# Generated at 2022-06-23 05:53:50.315091
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert type(block.has_tasks()) == bool

# Generated at 2022-06-23 05:54:01.276123
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    assert Block(implicit=False, use_handlers=True).all_parents_static()
    assert not Block(implicit=False, use_handlers=True, parent=TaskInclude(statically_loaded=False)).all_parents_static()
    assert not Block(implicit=False, use_handlers=True, parent=HandlerTaskInclude(statically_loaded=False)).all_parents_static()
    assert not Block(implicit=False, use_handlers=True, parent=Block(parent=TaskInclude(statically_loaded=False))).all_parents_static()

# Generated at 2022-06-23 05:54:02.721235
# Unit test for method serialize of class Block
def test_Block_serialize():
    pass # no code to test

# Generated at 2022-06-23 05:54:08.890235
# Unit test for constructor of class Block
def test_Block():
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    assert block._play is None
    assert block._parent_block is None
    assert block._role is None
    assert block._task_include is None
    assert block._use_handlers is False
    assert block._implicit is False


# Generated at 2022-06-23 05:54:11.735174
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False
    block.block.append(dict())
    assert block.has_tasks() == True



# Generated at 2022-06-23 05:54:20.895545
# Unit test for method all_parents_static of class Block

# Generated at 2022-06-23 05:54:32.509257
# Unit test for method copy of class Block

# Generated at 2022-06-23 05:54:41.568839
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    b = type('Block', (Block,), {"_attributes": {}})()
    b._parent = type('Block', (Block,), {"_attributes": {}})()
    assert b.all_parents_static() is True
    ti = type('TaskInclude', (TaskInclude,), {"_attributes": {}})()
    b._parent = type('Block', (Block,), {"_attributes": {}, "_parent":ti})()
    assert b.all_parents_static() is False

# Generated at 2022-06-23 05:54:44.760786
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    loader = DictDataLoader({})
    block.set_loader(loader)
    assert block._loader == loader


# Generated at 2022-06-23 05:54:57.055538
# Unit test for method is_block of class Block
def test_Block_is_block():
    block = Block()
    implicit = True
    b = block.load_data('Task')
    assert b.is_block(b) == False
    b = block.load_data(['Task'])
    assert b.is_block(b) == False
    b = block.load_data({'block': 'Task'})
    assert b.is_block(b) == True
    assert b.is_block(['Task']) == False
    assert b.is_block(implicit) == False
    b = block.load_data({'block': ['Task']})
    assert b.is_block(b) == True
    assert b.is_block(['Task']) == False
    assert b.is_block(implicit) == False
    b = block.load_data({'rescue': ['Task']})


# Generated at 2022-06-23 05:55:04.785028
# Unit test for constructor of class Block
def test_Block():
    class namespace_object(object):
        pass

    class variable_manager(object):
        pass

    class loader(object):
        pass

    class play(object):
        variable_manager = variable_manager()
        loader = loader()
        basedir = './'

    class role(object):
        pass

    block = Block(play=play(), parent_block=None, role=None, task_include=None, use_handlers=False)
    assert type(block.name) == str
    assert block.dep_chain is None
    assert type(block._ds) == str
    assert block._parent is None
    assert block._play is play
    assert block._role is None
    assert block._task_include is None
    assert block._use_handlers is False


# Generated at 2022-06-23 05:55:13.643833
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    test_obj = block.deserialize(test_data_Block)
    assert test_obj._attributes[u'dep_chain'] == ['a','b','c']
    assert test_obj._attributes[u'always'] == ['e','f','g']
    assert test_obj._attributes[u'block'] == ['1','2','3']
    assert test_obj._attributes[u'rescue'] == ['d','e','f']
    assert test_obj._role == test_obj._attributes[u'role']
    assert test_obj._parent == test_obj._attributes[u'parent']
    assert test_obj._dep_chain == test_obj._attributes[u'dep_chain']
    assert test_obj._loader == test_obj._attributes[u'loader']


# Generated at 2022-06-23 05:55:17.406203
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=True)
    block_ = block.preprocess_data(dict(block=[dict(name='test')]))
    assert block_ == dict(block=[dict(name='test')])


# Generated at 2022-06-23 05:55:19.078742
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    block = Block()
    val = block.__ne__('')

# Generated at 2022-06-23 05:55:26.723485
# Unit test for constructor of class Block
def test_Block():
    # test empty block
    block = Block()
    assert block.block == []
    assert block.rescue == []
    assert block.always == []

    # test implicit block
    block = Block(implicit=True)
    assert block.block == []
    assert block.rescue == []
    assert block.always == []

    # test explicit block
    block = Block(block=[{'name': 'task1'}])
    assert len(block.block) == 1
    assert isinstance(block.block[0], Task)
    assert block.block[0].name == 'task1'
    assert len(block.rescue) == 0
    assert len(block.always) == 0

    # test normal explicit block with rescue and always

# Generated at 2022-06-23 05:55:27.472118
# Unit test for method copy of class Block
def test_Block_copy():
  test_playbook.test_playbook()



# Generated at 2022-06-23 05:55:30.354580
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block_obj = Block(loader=None)

    block_obj.set_loader(loader=None)
    assert block_obj._loader == None



# Generated at 2022-06-23 05:55:36.444408
# Unit test for constructor of class Block
def test_Block():
    block_data = {
        'block': [],
        'rescue': [],
        'always': []
    }
    b = Block.load(block_data)
    assert b.__class__.__name__ == 'Block'
    assert b.block == []
    assert b.rescue == []
    assert b.always == []


# Generated at 2022-06-23 05:55:46.300573
# Unit test for method load of class Block

# Generated at 2022-06-23 05:55:47.892047
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    # create object
    obj = Block()
    # run method __ne__ on object
    obj.__ne__()

# Generated at 2022-06-23 05:55:54.413983
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    #create a test object of class Block
    obj = Block()
    assert obj._attributes['block'] == []
    assert obj._attributes['rescue'] == []
    assert obj._attributes['always'] == []
    assert obj.has_tasks() is False
    obj._attributes['block'].append(1)
    assert obj.has_tasks() is True


# Generated at 2022-06-23 05:56:05.171128
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.template import Templar

    playbook = Playbook()
    block = Block.load({u'block': [{u'vars': {u'a': u'b'}, u'tags': [u'test'], u'tasks': [{u'debug': {u'msg': u"{{ a }}", u'var': u"{{ a }}"}}, {u'fail': {u'msg': u"{{ a }}"}}], u'when': u"{{ a }} == 'b'"}, {u'block': [{u'tasks': [{u'include': u'test.yml', u'vars': {u'a': u'c'}}]}]}]}, None, None, None)
    block

# Generated at 2022-06-23 05:56:14.826997
# Unit test for method serialize of class Block
def test_Block_serialize():
    import ansible.playbook
    loader = ansible.playbook.Playbook.loader
    variable_manager = ansible.playbook.variable_manager.VariableManager()
    inventory = ansible.inventory.Inventory(loader=loader, variable_manager=variable_manager)
    block = Block.load(dict(
        block=[
            dict(action=dict(module='copy', args=dict(dest='/tmp/test1', content='{{ item }}'))),
            dict(action=dict(module='copy', args=dict(dest='/tmp/test2', content='{{ item }}'))),
            dict(action=dict(module='copy', args=dict(dest='/tmp/test3', content='{{ item }}'))),
            ]),
            variable_manager=variable_manager
            )

# Generated at 2022-06-23 05:56:24.684406
# Unit test for method copy of class Block
def test_Block_copy():
    host = mock()
    play = Play()
    play._variable_manager = mock()
    play._variable_manager._fact_cache = dict()
    play._variable_manager._hostvars = dict()
    play._variable_manager._group_vars = dict()
    play._variable_manager._group_vars_files = dict()
    play._variable_manager._play_context = PlayContext(vars=dict())
    play.get_variable_manager = mock()
    play.get_variable_manager.return_value = play._variable_manager
    play.set_variable_manager = mock()
    play.set_variable_manager.return_value = play._variable_manager
    play.set_fact_cache = mock()
    play.set_basedir = mock()
    play.set_loader = mock()

    block

# Generated at 2022-06-23 05:56:33.023053
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block = Block()
    assert block.has_tasks() == False

    task = AnsibleModule()
    block = Block()
    block.block = [task]
    assert block.has_tasks() == True

    task = AnsibleModule()
    block = Block()
    block.rescue = [task]
    assert block.has_tasks() == True

    task = AnsibleModule()
    block = Block()
    block.always = [task]
    assert block.has_tasks() == True

# tests for class FailTask

# Generated at 2022-06-23 05:56:38.501528
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    obj_dummy_block = Block()
    obj_dummy_task_include = TaskInclude()
    obj_dummy_block._parent = obj_dummy_task_include
    res = obj_dummy_block.get_first_parent_include()
    assert res == obj_dummy_task_include
    obj_dummy_task_include.statically_loaded = False
    res = obj_dummy_block.all_parents_static()
    assert res == False
    obj_dummy_task_include._parent = obj_dummy_block
    return

# Generated at 2022-06-23 05:56:47.554458
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block()
    assert not b.has_tasks()
    t1 = Task()
    t2 = Task()
    t1._parent = b
    t2._parent = b
    b.block = [t1, t2]
    assert b.has_tasks()
    b.block = []
    b.rescue = [t1, t2]
    assert b.has_tasks()
    b.rescue = []
    b.always = [t1, t2]
    assert b.has_tasks()
    b.always = []
    assert not b.has_tasks()


# Generated at 2022-06-23 05:56:49.776913
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    # FIXME: this is a stub
    pass

# Generated at 2022-06-23 05:56:51.322025
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    first = Block()
    second = Block()
    assert first != second



# Generated at 2022-06-23 05:56:59.038613
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    for (testdata, expect) in [
        (test_data(dict(block=dict(block=["block example", "block example"],
                                   rescue=[],
                                   task1='task1',
                                   name="test_name",
                                   tags='test_tag',
                                   when='1 == 1',
                                   always=[]))), dict()),
        (test_data(dict(block=dict(block=["task1"],
                                   rescue=[],
                                   task1='task1',
                                   name="test_name",
                                   tags='test_tag',
                                   when='1 == 1',
                                   always=[]))), dict()),
    ]:
        b = Block.load(testdata, task_include=None)
        assert b.get_include_params() == expect, testdata
# Unit test

# Generated at 2022-06-23 05:57:03.831693
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.base import Base
    # Create a Block instance
    block_obj = Block()
    # Execute the "get_first_parent_include" method
    block_obj.get_first_parent_include()
    assert True == True

# Generated at 2022-06-23 05:57:05.210259
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    myBlock = Block()
    assert myBlock.deserialize(None) == None


# Generated at 2022-06-23 05:57:06.880686
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    block = Block()
    assert Block.is_block(None) == False


# Generated at 2022-06-23 05:57:18.406525
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    class Playbook(object):
        def __init__(self, ds):
            self.ds = ds
            self.___dependency_tree = None
            self.___included = True
            self.___validate_attrs = {}
            self.___base = None
            self.___task_cache = None
            self.___role_cache = None
            self._attributes = {}

    class Role(object):
        def __init__(self, ds):
            self.ds = ds
            self.___dependency_tree = None
            self.___included = True
            self.___validate_attrs = {}
            self.___base = None
            self.___task_cache = None
            self.___role_cache = None
            self._attributes = {}


# Generated at 2022-06-23 05:57:27.058172
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager

    block = Block()
    # Test the case of self._parent is None
    actual = block.get_first_parent_include()
    expected = None
    assert expected == actual

    # Test the case of self._parent is not a TaskInclude
    block._parent = VariableManager()
    actual = block.get_first_parent_include()
    expected = None
    assert expected == actual

    # Test the case of self._parent is a TaskInclude
    block._parent = TaskInclude()
    actual = block.get_first_parent_include()
    expected = block._parent
    assert expected == actual

    # Test the case when self._parent._parent is a TaskIn

# Generated at 2022-06-23 05:57:29.390905
# Unit test for method load of class Block
def test_Block_load():
    assert_raises(AttributeError, Block.load)


# Generated at 2022-06-23 05:57:41.569015
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    block = Block()
    x = block.all_parents_static()
    assert x == True
    block.statically_loaded = True
    x = block.all_parents_static()
    assert x == True
    block.statically_loaded = False
    x = block.all_parents_static()
    assert x == False
    task_include = TaskInclude()
    block.statically_loaded = False
    task_include._parent = block
    x = task_include.all_parents_static()
    assert x == False
    task_include.statically_loaded = True
    task_include._parent = block
    x = task_include.all_parents_static()
    assert x == True
    task_include.statically_loaded = False
   

# Generated at 2022-06-23 05:57:52.637436
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    '''
    Unit test for method filter_tagged_tasks of class Block
    '''
    _play = {'hosts': 'all'}
    _loader = DataLoader()
    _var_manager = VariableManager(loader=_loader)

    # Simple block
    # tasks:
    # - debug: msg="task1"
    #   tags: ['tag1', 'tag2']
    # - debug: msg="task2"
    #   tags: ['tag1']
    # - debug: msg="task3"
    #   when: 0 == 1
    # - debug: msg="task4"
    #   when: 1 == 1
    #   tags: ['tag1', 'tag2']

# Generated at 2022-06-23 05:57:58.506579
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block = Block()
    block.statically_loaded = True
    assert(block.all_parents_static())

    block = Block()
    block.statically_loaded = False
    assert(not block.all_parents_static())

    taskInclude = TaskInclude()
    taskInclude.statically_loaded = True
    block = Block()
    block._parent = taskInclude
    assert(block.all_parents_static())

    taskInclude = TaskInclude()
    taskInclude.statically_loaded = False
    block = Block()
    block._parent = taskInclude
    assert(not block.all_parents_static())


# Generated at 2022-06-23 05:58:04.015453
# Unit test for method copy of class Block
def test_Block_copy():
    b1 = Block()
    b1.name = 'foo'
    b1.always = ['a']
    b2 = b1.copy()
    assert b1.name == b2.name
    assert b1.always == b2.always
    assert b1._attributes == b2._attributes
    assert b1.__dict__ != b2.__dict__


# Generated at 2022-06-23 05:58:11.093984
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block()

# Generated at 2022-06-23 05:58:13.781170
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block(block=[])
    print(b.has_tasks())

test_Block_has_tasks()


# Generated at 2022-06-23 05:58:23.276144
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    test_play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(
                name = "setup",
                action = dict(module="setup", args=""),
            ),
        ]
    ), variable_manager=VariableManager(), loader=DataLoader())

    test_play.post_validate(variable_manager=VariableManager(), loader=DataLoader())

# Generated at 2022-06-23 05:58:26.611056
# Unit test for method load of class Block
def test_Block_load():
    # Create a block object
    block = Task()
    # Check if object is of type Block
    assert isinstance(block, Block)

# Generated at 2022-06-23 05:58:30.054277
# Unit test for method serialize of class Block
def test_Block_serialize():
  block = Block()
  ansible_module_mock = MagicMock()
  block_implicit = Block(ansible_module_mock, implicit=True)
  block_implicit.serialize()
  block.serialize()

# Generated at 2022-06-23 05:58:36.064371
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    # Testing with a value
    block = Block(use_handlers=False, implicitly_convert_to_tuple=False, always=[])
    expected = '''<Block (implicit={implicit}, always=[], implicitly_convert_to_tuple={implicit_conv})>'''.format(implicit=True, implicit_conv=False)
    returned = block.__repr__()
    assert expected == returned

# Generated at 2022-06-23 05:58:40.428704
# Unit test for method is_block of class Block
def test_Block_is_block():
    from ansible.playbook.block import Block
    ds = {}
    result = Block.is_block(ds)
    assert result == True


# Generated at 2022-06-23 05:58:49.851011
# Unit test for constructor of class Block
def test_Block():

    loader = DictDataLoader({})
    variable_manager = VariableManager()
    play = Play()
    target_block = Block(
        play=play,
        role=Role(),
        task_include=None,
        use_handlers=False,
        implicit=False,
    )

# Generated at 2022-06-23 05:59:00.810659
# Unit test for method serialize of class Block
def test_Block_serialize():
    import pytest
    import sys
    import os
    import ansible.parsing.dataloader
    import ansible.playbook.block

    dataloader = ansible.parsing.dataloader.DataLoader()


# Generated at 2022-06-23 05:59:09.966264
# Unit test for method copy of class Block
def test_Block_copy():
    from ansible.playbook.base import Base
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    t = Task()
    t._parent = Base()
    t._role = Role()
    t._play = Play()
    t._loader = None
    t.action = 'fail'
    t.always = [t]
    t.any_errors_fatal = None
    t.args = t
    t.async_val = None
    t.block = t
    t.block_errors = None

# Generated at 2022-06-23 05:59:12.951345
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block = Block()
    assert repr(block) == "<ansible.parsing.dataloader.Block object at 0x7f5ff0e03550>"

# Generated at 2022-06-23 05:59:14.926045
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()

    # block._play  == None => None
    assert block.copy() == block


# Generated at 2022-06-23 05:59:18.229890
# Unit test for method serialize of class Block
def test_Block_serialize():
    b = Block()
    serialized = b.serialize()
    assert serialized == dict(dep_chain=None, parent=None, parent_type=None, role=None)


# Generated at 2022-06-23 05:59:28.454995
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    """
    *******************************************************************
    Unit test for method get_first_parent_include of class Block
    Refer to https://github.com/ansible/ansible/blob/devel/test/units/plugins/strategy/test_linear.py
    *******************************************************************
    """

    if 'role_path' in os.environ:
        ROLE_PATH = os.environ['role_path']
    else:
        ROLE_PATH = "../../../../../../"

    PATH = ['./', ROLE_PATH]

    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude

    # initialize
    loader = DataLoader()

# Generated at 2022-06-23 05:59:30.464743
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    block = Block()
    # If block's parent is None, None is returned
    assert block.all_parents_static() == None
test_Block_all_parents_static()


# Generated at 2022-06-23 05:59:36.422061
# Unit test for method copy of class Block
def test_Block_copy():
    parent_block = Block(
        play=Play().load({
            'hosts': 'all', 
            'gather_facts': 'no', 
            'tasks': [{
                'name': 'test task', 
                'block': [{
                    'block': 'some block'
                }]
            }]
        }),
        parent_block=None,
        role=None,
        task_include=None,
        use_handlers=False
    )
    # Do some initialization for parent_block
    parent_block.load_data({
        'block': [], 
        'rescue': [], 
        'always': []
    })
    parent_block.post_validate(templar=Templar(loader=DataLoader()))
    # Run the test

# Generated at 2022-06-23 05:59:38.085841
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    pass

# Generated at 2022-06-23 05:59:49.538712
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    '''
    Unit test for method Block.get_vars
    '''

    ds = dict()
    b = Block.load(ds, play=None, parent_block=None, role=None, task_include=None, use_handlers=False)
    b.get_vars.expect_call().return_value = dict()
    with pytest.raises(AnsibleUndefinedVariable):
        b.get_vars(fail_on_undefined=True)

    class loader_mock:
        path = '.'

    class variable_manager:
        class _fact_cache:
            def add(self, some_key, data):
                pass
        def get_vars(self, play=None, host=None, task=None):
            return dict()

# Generated at 2022-06-23 05:59:54.163015
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    import ansible.playbook.block 
    f = ansible.playbook.block.Block._get_parent_attribute
    assert f('name') == f('name')
    

# Generated at 2022-06-23 05:59:57.504442
# Unit test for method is_block of class Block
def test_Block_is_block():
    print("test_Block_is_block()")
    data = {
        'name': 'test',
        'block': []
    }
    b = Block()
    assert b.is_block(data)



# Generated at 2022-06-23 05:59:59.585596
# Unit test for method is_block of class Block
def test_Block_is_block():
    block = Block()
    dict = {'block': 'test'}
    assert(Block.is_block(dict)) == True


# Generated at 2022-06-23 06:00:07.370817
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    # Given
    block_list = ['valid_block', 'another_valid_block']
    rescue_list = ['valid_rescue', 'another_valid_rescue']
    always_list = ['valid_always', 'another_valid_always']

    # When
    block = Block(block=block_list, rescue=rescue_list, always=always_list)
    expected_result  = 'Block (2 tasks):\n  valid_block\n  another_valid_block\n'
    expected_result += 'Block (rescue 2 tasks):\n  valid_rescue\n  another_valid_rescue\n'
    expected_result += 'Block (always 2 tasks):\n  valid_always\n  another_valid_always'
    result = str(block)

    # Then
    assert result == expected_result

# Generated at 2022-06-23 06:00:09.877494
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # __init__ takes no arguments!
    b = Block()
    assert b._dep_chain == None
    return


# Generated at 2022-06-23 06:00:19.605727
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    # create object using default constructor and check object fields
    b = Block()
    parent = object()
    b._parent = parent
    assert b.get_first_parent_include() == parent

if __name__ == "__main__":
    if len(sys.argv) == 2 and sys.argv[1] == "pylint":
        # pylint will exit with non-zero code if there are any errors
        # or finding any errors.  This is fine for us
        sys.exit(run_pylint(args=sys.argv[1:], script=__file__))
    elif len(sys.argv) >= 2 and sys.argv[1] == "coverage":
        sys.exit(run_coverage(args=sys.argv[1:], script=__file__))
    el

# Generated at 2022-06-23 06:00:28.877393
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create instance of class Block
    block = Block()
    print("All parents are static: %s" % block.all_parents_static())


# Generated at 2022-06-23 06:00:37.925306
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    from ansible.playbook.task import Task
    my_block = Block()

    # Test case 1
    data_1 = "a_string"
    my_block.preprocess_data(data_1)

    assert len(my_block.block) == 1, "Block.preprocess_data is not creating an array of Task objects of size 1."
    assert isinstance(my_block.block[0], Task)
    assert my_block.block[0].action == data_1, "Block.preprocess_data is not creating a Task object with the right action."

    # Test case 2
    data_2 = dict(block = "block_in_dict")
    my_block.preprocess_data(data_2)

# Generated at 2022-06-23 06:00:47.438051
# Unit test for method load of class Block
def test_Block_load():
    host_list = [{
        'hostname': 'localhost',
        'port': 22,
        'username': 'vagrant',
        'private_key_file': '~/.vagrant.d/insecure_private_key'}]

    inventory = Inventory(host_list=host_list)
    variable_manager = VariableManager(inventory=inventory)
    loader = DataLoader()
    options = Options()

    obj = Block(parent_block=None, role=None, task_include=None) # TODO
    #TODO obj = Block.load(data, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)


# Generated at 2022-06-23 06:00:56.185662
# Unit test for constructor of class Block
def test_Block():
    block_type = Block
    block_type_name = 'Block'
    block_object = block_type(
        name = 'Just a block',
        parent = None,
        role = None,
        task_include = None,
        use_handlers = True,
        implicit = False,
    )
    assert block_object.name == 'Just a block'
    assert block_object.parent is None
    assert block_object.role is None
    assert block_object.task_include is None
    assert block_object.use_handlers is True
    assert block_object.implicit is False

# Generated at 2022-06-23 06:01:06.484290
# Unit test for constructor of class Block
def test_Block():

    # test invalid use of implicit=True
    try:
        Block(implicit = True, parent = None, role = None, task_include = None, load_role = True)
        raise Exception('Failed to raise AnsibleParserError: Constructor of class Block with implicit = True and empty data should have raised an exception')
    except AnsibleParserError:
        pass
    except:
        raise Exception('Failed to raise AnsibleParserError: Constructor of class Block with implicit = True and empty data should have raised an exception')

    #test valid use of implicit=True
    data = dict(
        block = []
    )
    Block(implicit = True, data=data, parent = None, role = None, task_include = None, load_role = True)

    #test invalid use of implicit=False

# Generated at 2022-06-23 06:01:15.875117
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    import copy
    from ansible.playbook.play_context import PlayContext
    correct_result = True

# Generated at 2022-06-23 06:01:28.453977
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    '''
    Make sure Block.__ne__() properly compares two objects.
    '''
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task import TaskInclude
    from ansible.playbook.handler import Handler

    obj1 = Block()
    obj1.block = [
        Task(),
        Task(),
    ]
    obj1.rescue = [
        Task(),
        Task(),
    ]
    obj1.always = [
        Task(),
        Task(),
    ]
    obj1.handler = [
        Handler(),
    ]

# Generated at 2022-06-23 06:01:39.231701
# Unit test for method serialize of class Block

# Generated at 2022-06-23 06:01:49.154647
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    # Create a new Block instance with a Mock parent
    obj = Block(parent_block=M)

    # Call the get_dep_chain method of the new Block instance and
    # store the result
    result = obj.get_dep_chain()

    # Check that the result is None
    assert (result is None)

    # Create a new Block instance with a Mock parent and a Mock dep_chain
    obj = Block(parent_block=M, dep_chain=M)

    # Call the get_dep_chain method of the new Block instance and
    # store the result
    result = obj.get_dep_chain()

    # Check that the result is not None
    assert (result is not None)

    # Call the get_dep_chain method of the new Block instance and
    # store the result
    result = obj.get_dep_chain

# Generated at 2022-06-23 06:02:01.276430
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    # Test normal behavior
    block = Block()
    block.block = [1, 2, 3]
    block.rescue = [4, 5, 6]
    block.always = [7, 8, 9]
    block.vars = {'a': 'b'}
    block_1 = Block()
    block_1.block = [1, 2, 3]
    block_1.rescue = [4, 5, 6]
    block_1.always = [7, 8, 9]
    block_1.vars = {'a': 'b'}
    block_2 = Block()
    block_2.block = [1, 2, 3]
    block_2.rescue = [4, 5, 6]
    block_2.always = [7, 8, 9]
    block_2.vars

# Generated at 2022-06-23 06:02:09.532302
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block(1) == False
    assert Block.is_block(dict()) == False
    assert Block.is_block(dict(block=[])) == True
    assert Block.is_block(dict(rescue=[])) == True
    assert Block.is_block(dict(always=[])) == True
    assert Block.is_block([]) == None
    assert Block.is_block(dict(block=[])) == True
    return True


# Generated at 2022-06-23 06:02:12.802619
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    from ansible.playbook.task import Task
    b = Block()
    assert not b.has_tasks()
    t1 = Task()
    b.block = [t1]
    assert b.has_tasks()

# Generated at 2022-06-23 06:02:21.816006
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block()
    assert b.has_tasks() == False
    b.block = [{'action': 'include_tasks', 'tasks': 'tasks/main.yml'}]
    assert b.has_tasks() == True
    b.block = []
    b.rescue = [{'action': 'include_tasks', 'tasks': 'tasks/main.yml'}]
    assert b.has_tasks() == True
    b.rescue = []
    b.always = [{'action': 'include_tasks', 'tasks': 'tasks/main.yml'}]
    assert b.has_tasks() == True
test_Block_has_tasks()



# Generated at 2022-06-23 06:02:28.394670
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    
    # case-1
    pl = Play().load({}, variable_manager=VariableManager(), loader=DictDataLoader())
    data={'block': [{'name': 'test'}]}
    block=Block(play=pl, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=True)
    res = block.preprocess_data(data)
    assert type(res) is dict
    assert 'block' in res

    # case-2
    pl = Play().load({}, variable_manager=VariableManager(), loader=DictDataLoader())
    data=[{'name': 'test'}]
    block=Block(play=pl, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=True)

# Generated at 2022-06-23 06:02:29.236099
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    test_block = Block()


# Generated at 2022-06-23 06:02:36.596322
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    block=Block(name="test_block")
    block.block=[Block(name="test_block2")]
    block.rescue=[Block(name="test_block3")]
    block.always=[Block(name="test_block4")]
    assert block.has_tasks() == True
    block.block=[]
    block.rescue=[]
    block.always=[]
    assert block.has_tasks() == False

block = Block()


# Generated at 2022-06-23 06:02:45.141270
# Unit test for constructor of class Block
def test_Block():
    block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=True)
    assert block._play is None
    assert block._blocks is None
    assert block._parent is None
    assert block._role is None
    assert block._dep_chain is None
    assert block._use_handlers is False
    assert block._task_include is None
    assert block.block is None
    assert block.rescue is None
    assert block.always is None
    assert block.implicit is True
