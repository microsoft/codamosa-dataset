

# Generated at 2022-06-23 05:52:54.588374
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    test1 = dict(task1=dict(action=dict(module='test')))
    test2 = dict(block=[dict(task1=dict(action=dict(module='test')))])
    test3 = dict(block=[dict(task1=dict(action=dict(module='test')))], rescue=None)
    test4 = dict(block=[dict(task1=dict(action=dict(module='test')))], always=None)
    test5 = dict(block=[dict(task1=dict(action=dict(module='test')))], rescue=None, always=None)
    test6 = dict(block=[dict(task1=dict(action=dict(module='test')))], rescue=None, always=None, not_allowed=None)

    assert Block.is_block(test1) == False

# Generated at 2022-06-23 05:53:03.731316
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    def test_loader(path):
        if path == 'test.yml':
            return yaml.load('''
                - name: task 1
                - name: task 2
                ''')

    block_obj = Block()
    block_obj._loader = None
    block_obj._attributes = {}
    block_obj._use_handlers = False
    block_obj._play = None
    block_obj._role = None
    block_obj._task_include = None
    block_obj._variable_manager = None
    block_obj.implicit = False

    block_obj._parent = None
    block_obj._dep_chain = None

    block_obj.set_loader(test_loader)



# Generated at 2022-06-23 05:53:14.075544
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    b0 = Block()
    b0.static_load()
    b1 = Block()
    b1.static_load()
    b2 = Block()
    b2.static_load()
    b3 = Block()
    b3.static_load()
    b4 = Block()
    b4.static_load()
    b5 = Block()
    b5.static_load()
    b6 = Block()
    b6.static_load()
    t = Task()
    t.static_load()
    h = Handler()
    h.static_load()


# Generated at 2022-06-23 05:53:14.736804
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    pass

# Generated at 2022-06-23 05:53:22.145143
# Unit test for constructor of class Block
def test_Block():
    # static block
    static_block_raw = {
        'block': [
            {'debug': {'msg': 'this is the block'}},
            {'debug': {'msg': 'this is the block too'}}
        ],
        'name': 'my block',
        'rescue': [
            {'debug': {'msg': 'this is the rescue'}}
        ],
        'always': [
            {'debug': {'msg': 'this is the always'}},
            {'debug': {'msg': 'this is the always too'}}
        ],
        'other_attribute': 'this is an extra attribute'
    }


# Generated at 2022-06-23 05:53:23.741717
# Unit test for method serialize of class Block
def test_Block_serialize():
    print('Test Block.serialize')


# Generated at 2022-06-23 05:53:36.622009
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    # Testing Block.get_first_parent_include
    #       case 1: self._parent is None
    #       case 2: self._parent is not None and is not a TaskInclude
    #       case 3: self._parent is not None and is a TaskInclude
    #Test case 1
    b = Block()
    assert b.get_first_parent_include() == None
    #Test case 2
    t = Task()
    b1 = Block(parent = t)
    t.parent = b1
    assert b1.get_first_parent_include() == None
    #Test case 3
    b2 = Block(parent = t)
    b3 = Block(parent = b2)
    t.parent = b3
    assert b3.get_first_parent_include() == t
    return True

# Unit test

# Generated at 2022-06-23 05:53:44.492055
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():


    b = Block()


    # Check that a Block isn't created if its data is of the wrong type
    data = [1]
    result = b.preprocess_data(data)
    assert result is None

    # Check that a Block isn't created if its data doesn't include 'block'
    data = dict()
    result = b.preprocess_data(data)
    assert result is None

    # Check that a Block is created if its data includes 'block'
    data = dict(block=[1])
    result = b.preprocess_data(data)
    assert isinstance(result, Block)


# Generated at 2022-06-23 05:53:59.021403
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    import copy
    block = Block()
    o_block = copy.deepcopy(block)
    o_block.block = [Task(), Task(), Task(), Task()]
    o_block.rescue = [Task(), Task()]
    o_block.always = [Task()]
    
    block.block = [Task(), Task(), Task()]
    block.rescue = [Task()]
    block.always = [Task()]
    assert block.filter_tagged_tasks([]).block == o_block.block[0:3]
    assert block.filter_tagged_tasks([]).rescue == o_block.rescue[0:1]
    assert block.filter_tagged_tasks([]).always == o_block.always
    #test_Block_filter_tagged_tasks()

   

# Generated at 2022-06-23 05:54:00.893326
# Unit test for constructor of class Block
def test_Block():
    b = Block()

    assert b.block is None
    assert b.rescue is None
    assert b.always is None

# Generated at 2022-06-23 05:54:12.467599
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    block = Block()
    with pytest.raises(KeyError) as exp:
        block.deserialize({})
    assert str(exp.value) == "'loader'"
    with pytest.raises(KeyError) as exp:
        block.deserialize({'loader': 'Loader'})
    assert str(exp.value) == "'_attributes'"
    with pytest.raises(KeyError) as exp:
        block.deserialize({'loader': 'Loader', '_attributes': {}})
    assert str(exp.value) == "'role'"
    with pytest.raises(KeyError) as exp:
        block.deserialize({'loader': 'Loader', '_attributes': {}, 'role': {}})
    assert str(exp.value) == "'parent'"

# Generated at 2022-06-23 05:54:21.640371
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_task_include import RoleTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    # init a block b1
    b1 = Block()
    # init a block b2
    b2 = Block()
    # init a task_include ti
    ti = TaskInclude()
    # init a role_task_include rti
    rti = RoleTaskInclude()
    # init a handler_task_include hti
    hti = HandlerTaskInclude()
    # set b2 as the parent of b1
    b1._parent = b2
    # set ti as the parent of b1
    b1._parent = ti
    # set rti as the parent of b1
    b

# Generated at 2022-06-23 05:54:23.979102
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    blocck = Block()
    assert blocck.has_tasks() == False


# Generated at 2022-06-23 05:54:34.673246
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    from ansible.playbook.role import Role
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    
    loader = DataLoader() # Takes care of finding and reading yaml, json and ini files
    variable_manager = VariableManager() # Used to load extra vars
    inventory = InventoryManager(loader=loader, sources='hosts') # Create an inventory manager
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 05:54:38.642264
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # testing that no tasks in block
    block = Block()
    assert not block.has_tasks()
    # testing that has tasks in block
    block.block = [Task()]
    block.rescue = [Task()]
    block.always = [Task()]
    assert block.has_tasks()

# Generated at 2022-06-23 05:54:42.588229
# Unit test for method is_block of class Block
def test_Block_is_block():
    for _ in range(100):
        _ds = generate_random_data()
        assert Block.is_block(_ds) == ((isinstance(_ds, dict) and (('block' in _ds) or ('rescue' in _ds) or ('always' in _ds))) or False)


# Generated at 2022-06-23 05:54:52.280148
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils import context_objects as co
    loader = DataLoader()
    play_vars = [{'var1': 'value1'}, {'var2': 'value2'}]
    play = Play

# Generated at 2022-06-23 05:54:56.334247
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    # Init
    block = Block()

    assert isinstance(block, Block)
    expected_result = "<Block>"
    assert block.__repr__() == expected_result



# Generated at 2022-06-23 05:55:02.480382
# Unit test for method is_block of class Block
def test_Block_is_block():
    # Arrange
    # Act
    # Assert
    assert Block.is_block({'block': 'block'}) == True
    assert Block.is_block({'rescue': 'rescue'}) == True
    assert Block.is_block({'always': 'always'}) == True
    assert Block.is_block({'always': 'always', 'block': 'block', 'rescue': 'rescue'}) == True


# Generated at 2022-06-23 05:55:07.470007
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    # Test to check that the method __ne__ of class Block functions as ne.
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler

    block1 = Block()
    block2 = Block()
    assert block1 != block2

# Generated at 2022-06-23 05:55:16.418813
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block

    # Create a Task object
    task = Task()
    task._parent = None
    assert task.get_first_parent_include() == None

    # Create a Handler object
    handler = Handler()
    handler._parent = None
    assert handler.get_first_parent_include() == None

    # Create a Block object
    block = Block()
    block._parent = None
    assert block.get_first_parent_include() == None

    # Create a TaskInclude object
    task_include = TaskInclude()
    task_include._parent = None
    assert task_include.get_first_parent_include()

# Generated at 2022-06-23 05:55:27.833732
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    b = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=True, implicit=True)
    b._valid_attrs = dict(
        name = dict(key=True),
        task_includes = dict(type='list'),
        when = dict(),
    )
    b._attributes = dict(
        task_includes = [
            {'name': 'included_task', 'tags': ['foo', 'bar']}
        ],
        name = 'block_name',
        when = 'when_condition',        
    )
    
    assert b.get_vars() == dict(
        block_name = b.name,
        block_when = b.when,
        block_tags = [],
    )


# Generated at 2022-06-23 05:55:30.399848
# Unit test for method is_block of class Block
def test_Block_is_block():
    block = Block()
    list = True
    dict = False
    assert block.is_block(list) == dict


# Generated at 2022-06-23 05:55:36.075120
# Unit test for method is_block of class Block
def test_Block_is_block():
    assert Block.is_block({'block':'task1'})
    assert Block.is_block({'rescue':'task1'})
    assert Block.is_block({'always':'task1'})
    assert Block.is_block({'block':'task1','rescue':'task1','always':'task1'})
    assert Block.is_block({})
    assert not Block.is_block([])

# Generated at 2022-06-23 05:55:46.797947
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    b=Block()
    assert b.get_first_parent_include() is None
    b.block = [Task(), Task()]
    assert b.get_first_parent_include() is None
    b.block = [TaskInclude(), Task()]
    assert isinstance(b.get_first_parent_include(), TaskInclude)
    b.block = [Task(), TaskInclude()]
    assert isinstance(b.get_first_parent_include(), TaskInclude)
    b.block = [Task(), Task(), TaskInclude()]
    assert isinstance(b.get_first_parent_include(), TaskInclude)
    b.block = [Task(), TaskInclude(), Task()]

# Generated at 2022-06-23 05:55:53.681694
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    #testing to check the number of its parents
    my_var=dict()
    my_var['var']='blah'
    my_block=Block.load(dict(block=[dict(hosts='hostA', tasks=[dict(name='test_taskA'),dict(name='test_taskB', when='test_varA')])], rescue=[dict(name='test_rescueA')], always=[dict(name='test_alwaysA')]), play=my_var, variable_manager=my_var, loader=my_var)

# Generated at 2022-06-23 05:56:04.099731
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.vars import substitute
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    t1 = Task()
    t1._loader = loader
    t2 = Task()
    t2._loader = loader
    t3 = Task()
    t3._loader = loader
    b1 = Block(play=play, parent_block=parent_block, role=role, task_include=task_include, use_handlers=use_handlers, implicit=implicit)
    b1.block = [t1,t2,t3]
    b1.set_loader(loader)


# Generated at 2022-06-23 05:56:14.200673
# Unit test for constructor of class Block
def test_Block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars import VariableManager

    context = PlayContext()
    context._tqm = object()
    play = Play(dict(
                    name='testing_block',
                    hosts=['127.0.0.1'],
                    gather_facts='no',
                    tasks=[dict(action=dict(module='setup', )), ],
                    ), variable_manager=VariableManager(), loader=None)
    templar = Templar(loader=None, variables=context._variables)
    block = Block(play=play, task_include=None, use_handlers=True, variable_manager=play.get_variable_manager(), loader=play._loader)
    assert block.parent_

# Generated at 2022-06-23 05:56:22.038692
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    host, stats, loader, variable_manager, kwargs = mock_objects()

    # Test 1: _loader is already set
    task1 = Block()
    task1._loader = 1234

    task1.set_loader(loader)

    # Test 2: _loader is not set
    task2 = Block()
    task2.set_loader(loader)

    assert task1._loader == 1234
    assert task2._loader == loader


# Generated at 2022-06-23 05:56:25.336454
# Unit test for method is_block of class Block
def test_Block_is_block():
    args = dict(
)
    verify_dumper(Block.is_block, args)


# Generated at 2022-06-23 05:56:36.518999
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():

    # setup test objects
    base_obj = Block() 
    base_obj.action = 'action'
    base_obj.tags = 'tags'
    base_obj.loop = 'loop'
    base_obj.when = 'when'
    base_obj._dep_chain = 'dep_chain'
    base_obj.failed_when = 'failed_when'
    base_obj._attributes = {
        'block': ['block'],
        'rescue': ['rescue'],
        'always': ['always'],
    }
    
    
    # perform the method test
    test_obj = base_obj.filter_tagged_tasks('all_vars')

    # verify the results
    assert type(test_obj) == Block
    
    
    
    
    
    
    



# Generated at 2022-06-23 05:56:40.976378
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    block_obj = Block()
    block_obj._parent = Block()
    parent_obj = block_obj._parent
    parent_obj._parent = Block()
    block_obj._parent = parent_obj
    block_obj.get_first_parent_include()

# Generated at 2022-06-23 05:56:46.081361
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    a = Block()
    # 1
    b = {'block': 'a', 'rescue': 'b'}
    print('process=%s' %a.preprocess_data(b))
    print('process=%s' %a.preprocess_data('c'))

# Generated at 2022-06-23 05:56:55.357021
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    try:
        B = Block()
        data = {}
        B.deserialize(data)
        raise AssertionError("Deserialize failed to raise exception when not enough data was provided.")
    except AnsibleParserError:
        pass

    try:
        B = Block()
        data = {'role': {}}
        B.deserialize(data)
        raise AssertionError("Deserialize failed to raise exception when not enough data was provided.")
    except AnsibleParserError:
        pass

    try:
        B = Block()
        data = {'role': {'name': 'george'}}
        B.deserialize(data)
        raise AssertionError("Deserialize failed to raise exception when not enough data was provided.")
    except AnsibleParserError:
        pass


# Generated at 2022-06-23 05:56:59.343392
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    block = Block(
            play=None,
            parent_block=None,
            role=None,
            task_include=None,
            use_handlers=False,
            implicit=False)

    assert block.__eq__(block) == True

    block.load_data({})
    block.validate()

    assert block.__eq__(block) == True


# Generated at 2022-06-23 05:57:05.659926
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    myblock = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=None, static_include=False)
    a = dict(block=[dict(name="foo"), dict(name="Bar")])
    b = myblock.preprocess_data(a)
    assert a == b
    a = [dict(name="foo"), dict(name="Bar")]
    b = myblock.preprocess_data(a)
    assert b.get('block') == a
    a = dict(name="foo")
    b = myblock.preprocess_data(a)
    assert b.get('block') == [a]

# Generated at 2022-06-23 05:57:07.794005
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    pass

# Generated at 2022-06-23 05:57:16.006267
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # create a simple mock for task
    class MockTask(object):
        pass

    mock_task = MockTask()

    b = Block()

    # non-block data
    ds = [mock_task]

    data = b.preprocess_data(ds)

    assert data == {'block': [mock_task]}

    # block data (doesn't change)
    ds = {'block': [mock_task], 'foo': 'bar'}

    data = b.preprocess_data(ds)

    assert data == ds


# Generated at 2022-06-23 05:57:17.832279
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    block = Block()
    res2 = block.__ne__(block)


# Generated at 2022-06-23 05:57:26.674775
# Unit test for method load of class Block
def test_Block_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import add_all_plugin_dirs

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=None)
    inventory.add_host(host=u'localhost')
    inventory.add_group(group=u'group0')
    inventory.add_child(child=u'localhost', parent=u'group0')
    variable_manager.set_inventory(inventory)

    variable_manager.set_variable(u'vars', u'test')

# Generated at 2022-06-23 05:57:38.520269
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    data = dict(
        name = "test1",
        block = [
            dict(
                name = "test1_1",
                action = dict(module = "debug", args = dict(msg = "test1_1"))
            ),
            dict(
                name = "test1_2",
                action = dict(module = "debug", args = dict(msg = "test1_2")),
                tags = ["test"]
            )
        ]
    )
    b = Block.load(data)
    assert b.has_tasks()
    assert len(b.block) == 2

    b1 = b.filter_tagged_tasks(dict())
    assert b1.has_tasks()
    assert len(b1.block) == 2


# Generated at 2022-06-23 05:57:49.108782
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    test_cases = dict()
    test_cases[0] = dict(
        input_block = dict(
            block=['task1', 'task2', 'task3', 'task4'],
            only_tags=['tag1', 'tag2'],
            skip_tags=['tag3', 'tag4'],
        ),
        output_block = dict(
            block=['task1', 'task2'],
        ),
    )

# Generated at 2022-06-23 05:58:02.115079
# Unit test for method is_block of class Block
def test_Block_is_block():
    print("Unit test starts")
    assert Block.is_block(dict(block=[])) == True
    assert Block.is_block(dict(block=[dict(action="debug", msg="Hello")])) == True
    assert Block.is_block(dict(rescue=[])) == True
    assert Block.is_block(dict(always=[])) == True
    assert Block.is_block(dict(block=[], rescue=[], always=[])) == True
    assert Block.is_block(dict(name="test", block=[], rescue=[], always=[])) == True
    assert Block.is_block(dict(block=[], always=[])) == True
    assert Block.is_block(dict()) == False
    assert Block.is_block(dict(action="debug", msg="Hello")) == False

# Generated at 2022-06-23 05:58:16.829569
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block

    b = Block(
        block=['all the tasks'],
        rescue=['all the rescue tasks'],
        always=['all the always tasks'],
        use_handlers=False,
        implicit=False,
    )
    assert b.get_first_parent_include() == None

    t = Task()
    h = HandlerTaskInclude()

# Generated at 2022-06-23 05:58:29.288675
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    play_context = PlayContext()
    inventory = Host(name="my_host")
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)
    play = Play().load

# Generated at 2022-06-23 05:58:40.006524
# Unit test for method copy of class Block
def test_Block_copy():
    obj = Block()
    new_obj = obj.copy()
    assert isinstance(new_obj, Block)

    # TODO: Test real values
    obj = Block()
    obj.block = []
    obj.rescue = []
    obj.always = []
    obj.when = []
    obj.dep_chain = None
    obj.role = None
    obj.parent = None
    obj.loop = []
    obj.any_errors_fatal = False
    obj.notify = []
    obj.timeout = None
    obj.retries = None
    obj.delay = None
    obj.until = []
    obj.changed_when = []
    obj.failed_when = []
    obj.ignore_errors = False
    obj.register = None
    obj.ignore_unexpected_errors = False
    obj

# Generated at 2022-06-23 05:58:49.577618
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()
    assert isinstance(block.copy(), Block)
    assert isinstance(block.copy(block, exclude_parent=True), Block)
    assert isinstance(block.copy(block, exclude_tasks=True), Block)

    # test isinstance
    task = AnsibleTask()
    block = Block()
    new_block = block.copy(task, exclude_parent=True)
    assert isinstance(new_block, Block)

    task = AnsibleTask()
    block = Block()
    new_block = block.copy(task, exclude_tasks=True)
    assert isinstance(new_block, Block)



# Generated at 2022-06-23 05:58:56.006404
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    b= Block()

    b.statically_loaded = True
    b.block='block'
    b.rescue='rescue'
    b.always='always'
    assert b.all_parents_static()== True

    b.statically_loaded = False
    assert b.all_parents_static()== False


# Generated at 2022-06-23 05:58:57.505312
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    pass

# Generated at 2022-06-23 05:59:05.763394
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():

    # setup
    b = Block()

    # test
    assert b.preprocess_data(dict(block=[{'name': 'test'}])) == dict(block=[{'name': 'test'}])
    assert b.preprocess_data([{'name': 'test'}]) == dict(block=[{'name': 'test'}])
    assert b.preprocess_data({'name': 'test'}) == dict(block=[{'name': 'test'}])


# Generated at 2022-06-23 05:59:08.055102
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    '''
    Unit test for method get_dep_chain() of class Block
    '''
    block = Block()
    assert block.get_dep_chain() == None, "Block().get_dep_chain() fail"


# Generated at 2022-06-23 05:59:11.883464
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block(use_handlers=True)
    block._loader = 'a'
    loader = 'b'

    block.set_loader(loader)
    assert block._loader == 'b'

# Generated at 2022-06-23 05:59:20.750670
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    b = Block(task_include=None)
    assert not b.has_tasks()
    
    b.block = [Task()]
    assert b.has_tasks()
    
    b.block = [Task(), Task()]
    b.rescue = [Task()]
    assert b.has_tasks()
    
    b.block = []
    b.rescue = []
    b.always = [Task()]
    assert b.has_tasks()

    b.block = []
    b.rescue = []
    b.always = []
    assert not b.has_tasks()

# Generated at 2022-06-23 05:59:22.702104
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    B = Block.load({'block': []}, play=Play())
    assert B != ''

# Generated at 2022-06-23 05:59:31.558989
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.block import Block

# Generated at 2022-06-23 05:59:47.505762
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    print("TESTING Block.get_dep_chain()")

# Generated at 2022-06-23 05:59:58.011239
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    global vars
    vars = dict(
        ansible_become=True,
        ansible_become_method='sudo',
        ansible_become_user='root',
        ansible_check_mode=False,
        ansible_connection='ssh',
        ansible_host='localhost',
        ansible_inventory_sources=['/etc/ansible/hosts'],
        ansible_playbook_python='/usr/bin/python',
        ansible_user='yusheng',
        ansible_version='2.5.0',
    )
    b = Block(None)
    b._parent = Task(None)
    b._parent._parent = Task(None)
    assert b.all_parents_static() == True

    b._parent._parent = Block(None)
    b._parent

# Generated at 2022-06-23 05:59:58.635036
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    pass

# Generated at 2022-06-23 06:00:08.251324
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    # Retry imports
    import ansible.playbook
    import ansible.playbook.block
    import ansible.playbook.task

    # Create expected objects
    expected_Block = ansible.playbook.block.Block()

    # Create test object
    test_Block = ansible.playbook.block.Block()

    # Create mock objects
    mock_all_vars = dict()

    # Run unit test
    result_Block = test_Block.filter_tagged_tasks(mock_all_vars)

    # Check result
    assert result_Block == expected_Block, "Unit test for Block.filter_tagged_tasks() failed!"

if __name__ == "__main__":
    import ansible.playbook
    import ansible.playbook.block
    import ansible.playbook.task



# Generated at 2022-06-23 06:00:18.827958
# Unit test for constructor of class Block
def test_Block():
    # Test loading/constructing a block which contains a single task
    block = Block(task_include=None, role=None, use_handlers=False, implicit=True)
    block.load({'foo': 'bar'})
    assert isinstance(block, Block)
    assert not block.rescue
    assert not block.always
    assert block.block
    assert isinstance(block.block, list)
    assert len(block.block) == 1
    assert block.block[0].action == 'foo'
    assert block.block[0].args == 'bar'

    # Test loading/constructing a block which contains a single task in a list
    block = Block(task_include=None, role=None, use_handlers=False, implicit=True)

# Generated at 2022-06-23 06:00:25.972498
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    '''
    Unit test for method __ne__ of class Block
    '''
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # Create an object of class Block
    block_obj = Block()
    task = Task()
    # Check for AssertionError for parent_block = None
    try:
        block_obj.__ne__(task)
        assert False, "Expected AssertionError"
    except AssertionError:
        pass

    assert block_obj.__ne__('block') is True



# Generated at 2022-06-23 06:00:36.402060
# Unit test for method is_block of class Block
def test_Block_is_block():
    from copy import deepcopy
    block_simple = {
        'block': [
            {
                "name": "example",
                "debug": "yes"
            }
        ]
    }
    assert Block.is_block(block_simple) is True
    
    block_with_stuff = {
        'block': [
            {
                "name": "example",
                "debug": "yes"
            }
        ],
        'rescue': [
            {
                "name": "example",
                "debug": "yes"
            }
        ],
        'always': [
            {
                "name": "example",
                "debug": "yes"
            }
        ]
    }
    assert Block.is_block(block_with_stuff) is True


# Generated at 2022-06-23 06:00:41.353914
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    # block_instance is the instance of Block to be tested
    block_instance = Block()
    # Call method __repr__ of class Block
    assert repr(block_instance) == '<TaskInclude /Library/Frameworks/Python.framework/Versions/3.6/lib/python3.6/site-packages/ansible/playbook/block.py>'

# Generated at 2022-06-23 06:00:42.131197
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    pass

# Generated at 2022-06-23 06:00:42.891688
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    pass

# Generated at 2022-06-23 06:00:45.875144
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # Instantiate an instance of Block, get an attribute value and check the 
    # result
    bk = Block()
    bk.deserialize()

# Generated at 2022-06-23 06:00:54.404576
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    test_block = Block()
    test_block._play = Play().load({'name': 'test_play',
                                    'connection': 'local',
                                    'hosts': 'all',
                                    'tasks': [{'block': [{'block': [{'block': [{'module': 'setup',
                                                                                    'tags': ['test_tag']}]}],
                                                                    'name': 'block1_task'}]},
                                               {'block': [{'block': [{'block': [{'module': 'setup',
                                                                                    'tags': ['invalid_tag']}]}],
                                                                    'name': 'invalid_block_task'}]}],
                                    'handlers': []})
    filtered_block = test_block.filter_tagged_tasks

# Generated at 2022-06-23 06:01:02.280945
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():

    block = Block(
        play=None,
        parent_block=None,
        role=None,
        task_include=None,
        use_handlers=None,
        implicit=None,
    )
    assert not block.has_tasks()

    block_1 = Block(
        play=None,
        parent_block=None,
        role=None,
        task_include=None,
        use_handlers=None,
        implicit=None,
    )
    block_1.block = "task_list"
    assert block_1.has_tasks()



# Generated at 2022-06-23 06:01:11.439009
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block = Block()
    assert not block.filter_tagged_tasks(None).has_tasks()
    block = Block(block=[{'name': 'foo'}, {'name': 'bar'}])
    assert block.filter_tagged_tasks({}).has_tasks()
    assert block.filter_tagged_tasks({'tags': 'baz'}).has_tasks()
    assert block.filter_tagged_tasks({'tags': ['foobar']}).has_tasks()
    assert block.filter_tagged_tasks({'tags': ['foobar', 'baz']}).has_tasks()
    block = Block(block=[{'name': 'foo', 'tags': ['bar']}, {'name': 'bar', 'tags': ['baz']}])

# Generated at 2022-06-23 06:01:21.946418
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    t1 = Task()
    t2 = Task()
    b1 = Block(t1)
    b1.block = [t2]
    t3 = Task()
    b2 = Block(b1)
    b2.block = [t3]
    t4 = Task()
    ti = TaskInclude(t4, load_role_tasks=True, variable_manager=VariableManager())
    b3 = Block(t4)

# Generated at 2022-06-23 06:01:33.120036
# Unit test for method copy of class Block
def test_Block_copy():
    host1 = "localhost"
    host2 = "localhost"
    host3 = "localhost"
    task1 = Task()
    task2 = Task()
    task3 = Task()
    block1 = Block(qwe=1, asd=2, zxc=3, block=(task1, task2))
    block1.always = task3
    block1.rescue = task3
    block2 = block1.copy()
    assert type(block2) == type(block1)
    assert block2.qwe == 1
    assert block2.asd == 2
    assert block2.zxc == 3
    assert type(block2.block) == type(list())
    assert type(block2.rescue) == type(list())
    assert type(block2.always) == type(list())

# Generated at 2022-06-23 06:01:35.019320
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    block = Block()
    print(block.__ne__(['key']))


# Generated at 2022-06-23 06:01:39.512020
# Unit test for method load of class Block

# Generated at 2022-06-23 06:01:49.850604
# Unit test for method __ne__ of class Block
def test_Block___ne__():    
    file_name = "test_playbooks/files/block_ne.yml"
    blk = Block.load(
        file_name,
        play=None,
        parent_block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=None,
        loader=None,
    )
    task = Task.load(
        file_name,
        play=None,
        parent_block=blk,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=None,
        loader=None,
    )
    # Create an instance of Block for testing
    blk2 = Block()
    result = blk.__ne__(blk2)

# Generated at 2022-06-23 06:01:50.540834
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    pass

# Generated at 2022-06-23 06:01:55.234033
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    block = Block(
        tasks=[
            Task(action={'__ansible_module__': 'debug', '__ansible_arguments__': "var=hostvars['example.com']", '__ansible_no_log__': False})
        ],
    )
    assert block != "foo"


# Generated at 2022-06-23 06:01:57.462280
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    play = Play()
    block = Block(play=play)
    result = block.get_vars()
    assert result == None


# Generated at 2022-06-23 06:01:58.181630
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    pass

# Generated at 2022-06-23 06:02:07.462196
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.include import Include
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import RoleInclude

    parent = TaskInclude()
    block = Block()
    parent_static = TaskInclude(statically_loaded=True)
    block_static = Block(statically_loaded=True)
    include = Include()
    parent_role = RoleInclude()
    parent_task = Task(statically_loaded=True)
    task = Task()

    block._parent = block
    assert block.all_parents_static()
    block.statically_loaded = False
    assert not block.all_parents_static()

    parent._parent = block
   

# Generated at 2022-06-23 06:02:15.899181
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    play = Play()
    block = Block(play=play)
    include_params = block.get_include_params()
    assert(include_params == dict())
    block2 = Block(play=play, parent_block=block)
    include_params2 = block2.get_include_params()
    assert(include_params2 == dict())
    block3 = Block(play=play, parent_block=block2, role=None)
    include_params3 = block3.get_include_params()
    assert(include_params3 == dict())

# Generated at 2022-06-23 06:02:22.838739
# Unit test for method copy of class Block

# Generated at 2022-06-23 06:02:35.299838
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    # perform a test of the Block.deserialize() method
    # test_dict is a dict representing a TaskInclude object
    #test_dict = {'first_execution': 'second_execution', u'_attributes': {}, '_included': {}, '_role': None, '_parent': None}
    # test_obj is a Block object
    test_obj = Block()
    test_obj.deserialize(test_dict)
    assert test_obj._attributes == {}
    assert test_obj._included == {}
    assert test_obj._role is None
    assert test_obj._parent is None
    assert test_obj._dep_chain is None
    assert test_obj._play is None
    assert test_obj._statically_loaded == True
    assert test_obj.block == []
    assert test

# Generated at 2022-06-23 06:02:38.871095
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    b = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=False)
    assert not b.deserialize("data")

# Generated at 2022-06-23 06:02:50.383973
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.task import Task
    block = Block()
    block_1 = Block()
    block_2 = Block()
    block_3 = Block()
    block_4 = Block()
    block_5 = Block()
    block_6 = Block()
    block_7 = Block()

    block.block = [block_1]
    block.rescue = [block_2]
    block.always = [block_3]
    block_1.block = [block_4]
    block_1.rescue = [block_5]
    block_1.always = [block_6]
    block_2.block = [block_7]

    task_1 = Task()
    block_1.block.append(task_1)
    task_2 = Task()
    block_1.block.append