

# Generated at 2022-06-23 05:52:58.989729
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    class MockPlay(object):
        _attributes = dict()
        _loader = None
        def __init__(self):
            self.vars = dict()
    class MockRole(object):
        _attributes = dict()
        _loader = None
        def __init__(self):
            self.vars = dict()
    
    test_block = Block(
        play=MockPlay(),
        parent_block=None,
        role=MockRole(),
        task_include=None,
        use_handlers=False,
        implicit=None
    )
    maxDiff = None
    assert test_block.get_vars() == {'block': None}
# unit test for method load of class Block

# Generated at 2022-06-23 05:53:07.362019
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    b = Block()
    block_ne = b.__ne__("string1")
    assert block_ne == True
    block_ne = b.__ne__("")
    assert block_ne == True
    b.__init__("string2")
    block_ne = b.__ne__("string1")
    assert block_ne == True
    block_ne = b.__ne__("string2")
    assert block_ne == False
    

# Generated at 2022-06-23 05:53:08.089187
# Unit test for method is_block of class Block
def test_Block_is_block():
    pass

# Generated at 2022-06-23 05:53:17.330786
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    yaml = """
    - block:
        - name: test1
          hosts: temp1
          connection: local
          gather_facts: no
          tasks:
            - name: test2
              debug:
                var: test4
              tags:
                - test5
              when: test6
              async: test7
              poll: test8
        rescue:
          - name: test3
            debug:
              var: test9
            tags:
              - test10
            when: test11
            async: test12
            poll: test13
    """
    print("TEST 1")
    print(yaml)
    script = yaml_to_ansible_task(yaml)

# Generated at 2022-06-23 05:53:25.279793
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    globals()['__name__'] = '__main__'
    import __main__ as main
    globals()['main'] = main
    globals()['Block'] = Block
    globals()['AnsibleParserError'] = AnsibleParserError


    print('*** testing ansible.playbook.block.Block.__ne__ ***')
    print('*** testing ansible.playbook.block.Block.__ne__ ***')
    b1 = Block()
    try:
        b2 = b1.__ne__(None)
    except Exception as e:
        print(e)
    else:
        print('%s got %s expected %s' % (b1.__ne__(None), b2, None))

# Generated at 2022-06-23 05:53:29.730320
# Unit test for method get_vars of class Block
def test_Block_get_vars():

    block = Block(variable_manager=VariableManager(), loader=None)
    block.vars = dict(x=3)
    assert block.vars == dict(x=3)


# Generated at 2022-06-23 05:53:32.794526
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    p = Play()
    b = Block.load(dict(name='foo', block=dict(body='bar')), play=p)
    assert repr(b) == "<block (foo)>"

# Generated at 2022-06-23 05:53:36.621518
# Unit test for method __repr__ of class Block
def test_Block___repr__():
  test_object = Block()
  test_object.block=[]
  test_object.block.append(Task())
  assert test_object.__repr__() == "Block (1 task, 0 rescue, 0 always)"


# Generated at 2022-06-23 05:53:47.444183
# Unit test for method is_block of class Block
def test_Block_is_block():
    data_list = [
        dict(
            block=[dict()]
        ),
        dict(
            block=[dict()],
            when=True,
            name="test_tasks"
        ),
        dict(
            block=[dict(), dict()],
            rescue=[dict()],
            always=[dict()],
            when=True,
            name="test_tasks"
        ),
        None,
        dict(),
        dict(rescue=[dict()]),
        dict(always=[dict()])
    ]

    expect = [True for i in range(len(data_list)-3)]
    expect.extend([False, False, False])

    for i, data in enumerate(data_list):
        assert expect[i] == Block.is_block(data)



# Generated at 2022-06-23 05:54:00.529432
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    '''
    Unit test for method set_loader of class Block
    '''
    #
    # create a mock loader object
    #
    class MockLoader(object):
        def __init__(self):
            self.path_sep = '/'
            self.paths = ['/path/one', '/path/two']
            self.basedir = '/'

        def load_from_file(self, path, cache=True, unsafe=False):
            pass

    #
    # create a mock Role object
    #
    class MockRole(object):

        def __init__(self):
            self.loader = None

        def set_loader(self, loader):
            self.loader = loader

    #
    # create a mock Block object
    #

# Generated at 2022-06-23 05:54:12.102077
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    task_attrs={'action': 'dummy','args': {}}
    task_one=Task.load(task_attrs)
    task_two=Task.load(task_attrs)
    task_list=[task_one,task_two]
    block1_attrs={'block':task_list,'always':task_list,'rescue':task_list,}
    block1=Block.load(block1_attrs)
    block2_attrs={'block':task_list,'always':task_list,'rescue':task_list,}
    block2=Block.load(block2_attrs)
    assert block1!=block2


# Generated at 2022-06-23 05:54:14.039560
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    assert False, 'No unit tests for method all_parents_static of class Block'


# Generated at 2022-06-23 05:54:19.512085
# Unit test for method load of class Block

# Generated at 2022-06-23 05:54:31.616279
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    assert_equal(Block.preprocess_data([1]), {'block': [1]})
    assert_equal(Block.preprocess_data(1), {'block': [1]})
    assert_equal(Block.preprocess_data({'block': [1, 2]}), {'block': [1, 2]})
    block = Block()
    assert_equal(block.preprocess_data(1), {'block': [1]})
    assert_equal(block.preprocess_data([1]), {'block': [1]})
    assert_equal(block.preprocess_data({'block': [1, 2]}), {'block': [1, 2]})
    r = Role()
    assert_equal(block.preprocess_data({'block': [1, 2]}), {'block': [1, 2]})

# Generated at 2022-06-23 05:54:36.385802
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    class MockTaskInclude(TaskInclude):

        def __init__(self):
            super(MockTaskInclude, self).__init__()
            self.statically_loaded = False

    # test for TaskInclude is not statically loaded
    # all_parents_static should return False
    m = MockTaskInclude()
    b = Block(parent_block=m)
    assert not b.all_parents_static()


# Generated at 2022-06-23 05:54:45.903876
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader, variable_manager, 'localhost,')
    play_context = PlayContext()
    variable_manager.set_inventory(inventory)

    block = Block(block=dict(name='block', variable='block_variable_value'))
    variable_manager.set_play_context(play_context)
    variable_manager.add_task_vars('localhost', {'deep_value': 42})

    expected_result = dict(
        block_variable_value='block_variable_value',
        deep_value=42,
    )

# Generated at 2022-06-23 05:54:57.122515
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # block has empty block , rescue and always attributes
    block = Block()
    result = block.has_tasks()
    assert result == False, "test_Block_has_tasks in test_block.py failed."

    # block has block but empty rescue and always attributes
    block2 = Block()  #create a new block
    block2.block = [1]
    result = block2.has_tasks()
    assert result == True, "test_Block_has_tasks in test_block.py failed."

    # block has rescue but empty block and always attributes
    block3 = Block()  #create a new block
    block3.rescue = [1]
    result = block3.has_tasks()
    assert result == True, "test_Block_has_tasks in test_block.py failed."

    # block

# Generated at 2022-06-23 05:54:59.073515
# Unit test for method is_block of class Block
def test_Block_is_block():
    data='Tis a block'
    assert Block.is_block(data) == False


# Generated at 2022-06-23 05:55:02.741511
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block = Block()
    ansible_qc.asserteq(block.__repr__(), '<trellis.model.ansible.block.Block object at 0x7f43e7f34b38>')



# Generated at 2022-06-23 05:55:11.612314
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    b = Block()
    assert not Block.is_block(['ls -l'])

    b = Block()
    assert Block.is_block({'block': ['ls -l']})

    b = Block()
    assert Block.is_block({'block': ['ls -l'], 'other': 'attr'})

    b = Block()
    assert b.preprocess_data({'block': ['ls -l']}) == {'block': ['ls -l']}

    b = Block()
    assert b.preprocess_data(['ls -l']) == {'block': ['ls -l']}

    b = Block()
    assert b.preprocess_data('ls -l') == {'block': ['ls -l']}

# Generated at 2022-06-23 05:55:19.941935
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    # Verifying the set_loader method of Blcok class.
    # Testing with different values 1. block with one task 2. block with many tasks 3. block with no task
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    
    # block with one task
    # create block object
    block = Block()
    # create task object
    task = Task()
    task.action = "Shell"
    task.args['command'] = "hello"
    task._parent = block
    block.block = [task]
    # create dataLoader object
    dataLoader = DataLoader()
    # create variableManager object
    variable

# Generated at 2022-06-23 05:55:22.540215
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    class C(object):
        _play = None
    class B(Block):
        _parent = C()

    assert B().get_include_params() == {}


# Generated at 2022-06-23 05:55:32.486757
# Unit test for method load of class Block

# Generated at 2022-06-23 05:55:34.008661
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
	b=Block()
	print(b.get_include_params())


# Generated at 2022-06-23 05:55:41.762554
# Unit test for method has_tasks of class Block
def test_Block_has_tasks():
    # Construct a mock Block object
    block = Block()
    if not block.has_tasks():
        raise AssertionError("assertion error")
    # Construct a mock Block object
    block = Block()
    block._valid_attrs["rescue"] = "rescue"
    if not block.has_tasks():
        raise AssertionError("assertion error")
    # Construct a mock Block object
    block = Block()
    block._valid_attrs["always"] = "always"
    if not block.has_tasks():
        raise AssertionError("assertion error")

# Generated at 2022-06-23 05:55:49.681548
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    import ansible.playbook.task
    Task = ansible.playbook.task.Task
    parent = TaskInclude()
    block = Block()
    block._parent = parent
    assert(block.get_first_parent_include() == parent)
    parent = Base()
    block = Block()
    block._parent = parent
    assert(block.get_first_parent_include() == None)



# -----------------------------------------------------
# Play class
# -----------------------------------------------------

# Generated at 2022-06-23 05:55:53.408868
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    assert Block.get_first_parent_include(Block) == None


# =====================================================================================
#
# =====================================================================================

# Generated at 2022-06-23 05:56:04.021285
# Unit test for method load of class Block
def test_Block_load():

    p = Mock(name='p')
    parent_block = Mock(name='parent_block', get_dep_chain=Mock(return_value=[]))
    r = Mock(name='r')
    ti = Mock(name='ti')
    vm = Mock(name='vm')
    l = Mock(name='l')
    b = Block.load(dict(block=['block_load']), play=p, parent_block=parent_block, role=r, task_include=ti, use_handlers=False, variable_manager=vm, loader=l)

    assert b._play == p
    assert b._parent == parent_block
    assert b._dep_chain == []
    assert b._role == r
    assert b._task_include == ti
    assert b._use_handlers == False
    assert b._variable_

# Generated at 2022-06-23 05:56:14.164057
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    import pytest
    # All parents statically loaded

# Generated at 2022-06-23 05:56:18.531245
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    # case is a dictionary
    # implicit is None
    # case is a dictionary
    # implicit is False
    # case is a dictionary
    # implicit is True
    # case is a list
    # implicit is None
    # case is a list
    # implicit is False
    # case is a list
    # implicit is True
    pass


# Generated at 2022-06-23 05:56:24.222809
# Unit test for method load of class Block
def test_Block_load():
  data = None
  play = None
  parent_block = None
  role = None
  task_include = None
  use_handlers = False
  variable_manager = None
  loader = None
  obj = Block()
  result = obj.load(data, play, parent_block, role, task_include, use_handlers, variable_manager, loader)
  assert result == None, "Block.load returned '%s' instead of '%s'" % (result, None)


# Generated at 2022-06-23 05:56:27.872834
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    # Given a variable of type Block
    block = Block()

    # When the variable is compared with itself
    # Then the result is True
    assert block == block
    assert not block != block


# Generated at 2022-06-23 05:56:36.974948
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    d = dict(
        name = "block 3",
        block = [
            dict(
                name = "task 1.1",
                debug = "msg=task1.1"
            ),
            dict(
                name = "task 1.2",
                debug = "msg=task1.2"
            )
        ]
    )
    parent_block = Block.load(d, play=None, parent_block=None, role=None, task_include=None, use_handlers=False)

# Generated at 2022-06-23 05:56:49.333588
# Unit test for method preprocess_data of class Block
def test_Block_preprocess_data():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    b=Block(
        play=None,
        parent_block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        implicit=True
    )
    # ansible
    d = dict(
        name = "test",
        debug = dict(
            msg="test Message var={{var}}",
            var="ansible",
            other_var="{{test}}"
        ),
    )
    # ansible-1.9.4

# Generated at 2022-06-23 05:56:51.913595
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    # Create a Block object
    b = Block(implicit=False)
    # Check the all_parents_static method of Block
    assert b.all_parents_static() == True


# Generated at 2022-06-23 05:56:56.813116
# Unit test for method is_block of class Block
def test_Block_is_block():
    b = Block()
    assert not b.is_block(None)
    assert not b.is_block({'hosts': 'all'})
    assert b.is_block({'block': []})
    assert b.is_block({'block': [], 'rescue': []})
    assert b.is_block({'block': [], 'rescue': [], 'always': []})



# Generated at 2022-06-23 05:57:00.088808
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    pass



# Generated at 2022-06-23 05:57:08.782956
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    exdata1= {
        "hosts": "{{hosts}}",
        "name": "TEST",
        "tasks": [
            {
                "name": "test",
                "debug": "var={{hosts}}",
                "block": [
                    {
                        "name": "test1",
                        "debug": "var={{hosts}}",
                        "block": [
                            {
                                "name": "test2",
                                "debug": "var={{hosts}}"
                            }
                        ]
                    }
                ]
            }
        ]
    }

# Generated at 2022-06-23 05:57:13.806690
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    # Setup test values
    self = Block()
    other = Block()
    expected = None # Expected result from function

    # Perform the test
    result = self.__eq__(other)
    assert expected == result, "Block.__eq__() did not return expected value."

# Generated at 2022-06-23 05:57:23.799769
# Unit test for constructor of class Block
def test_Block():
    # test initializing Block
    data1 = {'block': [{'local_action': 'ping'}, {'local_action': 'shell hostname'}]}
    data2 = {'block': [{'local_action': 'ping'}, {'local_action': 'shell hostname'}],
             'rescue': [{'local_action': 'ping'}, {'local_action': 'shell hostname'}],
             'always': [{'local_action': 'ping'}, {'local_action': 'shell hostname'}],
             }
    test1 = Block.load(data1)
    test2 = Block.load(data2)
    assert test1.block[1].action == 'shell'
    assert test2.rescue[1].action == 'shell'

# Generated at 2022-06-23 05:57:26.235558
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    obj = Block()
    obj._dep_chain = None
    assert obj.get_dep_chain() is None
    obj._dep_chain = []
    assert obj.get_dep_chain() == []

# Generated at 2022-06-23 05:57:36.372929
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    # Initialize these value first
    play_name = "Ansible Playbook"
    gather_facts = False
    tasks = [{"include_role": {"name": "common", "tasks_from": "tasks/main.yml"}, "name": "Configure Common Files"}]
    play = Play().load({
        "name": play_name,
        "hosts": "all",
        "gather_facts": gather_facts,
        "tasks": tasks,
    }, variable_manager=None, loader=None)

# Generated at 2022-06-23 05:57:39.687429
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    b1 = Block(name='block1')
    block_name = b1.name
    result = b1.get_first_parent_include()
    assert result == None, "Incorrect block_name."
    print("Successfully tested method get_first_parent_include of class Block")
test_Block_get_first_parent_include()


# Generated at 2022-06-23 05:57:47.331343
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    '''
    Unit test for method __ne__ of class Block
    '''
    # Initialize a Block object
    blk = Block()

    # Assert Block is not equal to another object
    assert blk != object()

    # Initialize a Block object
    other_blk = Block()

    # Assert Block is equal to another Block
    assert blk == other_blk
if __name__ == '__main__':
    # Unit test for method __ne__ of class Block
    test_Block___ne__()

# Generated at 2022-06-23 05:57:55.924113
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    # create the playbook object, which is basically
    # a container of plays, each play contains a list
    # of tasks
    from ansible.playbook.base import Play

    pb = Play()
    # This is the '--skip-tags' option provided to ansible-playbook
    pb.skip_tags = ['debug']

    # create a new task, and name it my_task
    task_1 = Task()
    task_1.name = "my_task"
    task_1.action = 'command'
    task_1.args['creates'] = '/etc/file.txt'

# Generated at 2022-06-23 05:58:06.707672
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.attribute import Attribute
    from ansible.playbook.base import Base
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    # Create a new context for testing
    test_context = Context()

# Generated at 2022-06-23 05:58:12.558183
# Unit test for constructor of class Block
def test_Block():

    # test default Block
    block = Block()
    assert block.block == []
    assert block.rescue == []
    assert block.always == []

    # test block with 'when' value
    block = Block(when='test_when')
    assert block.block == []
    assert block.rescue == []
    assert block.always == []
    assert block.when == 'test_when'

# Generated at 2022-06-23 05:58:23.814785
# Unit test for method copy of class Block
def test_Block_copy():
    play = Play().load(dict(
        name="Ansible Play",
        hosts=["all"],
        gather_facts="no",
        serial=10,
        tasks=[
            dict(action=dict(module="shell", args="ls"), register="shell_out"),
            dict(action=dict(module="debug", args=dict(msg="{{shell_out.stdout}}")))
        ]
    ), loader=DummyLoader())
    assert isinstance(play, Play)

    block = play.compile()
    assert isinstance(block, Block)

    copy_block = block.copy()
    assert isinstance(copy_block, Block)

# Generated at 2022-06-23 05:58:35.410035
# Unit test for constructor of class Block
def test_Block():
    b = Block(play=None)
    assert b.name is None
    assert b.block is None
    assert b.rescue is None
    assert b.always is None
    assert b.tags is None
    assert b.when is None
    assert b.notify is None
    assert isinstance(b.loop, Loop)
    assert b.loop.name is None
    assert isinstance(b.loop, Loop)
    assert b.loop.items is None
    assert b.loop.until is None
    assert b.loop.with_items is None
    assert b.loop.with_sequence is None
    assert b.loop.changed_when is None
    assert b.loop_control.loop_var is None
    assert b.loop_control.loop_var is None
    assert b.loop_control.loop_var is None

# Generated at 2022-06-23 05:58:39.609370
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    # The data is a complex structure, it may need to create more test cases
    # to test method get_include_params defined in class Block
    pass

# Generated at 2022-06-23 05:58:49.813083
# Unit test for method is_block of class Block

# Generated at 2022-06-23 05:59:00.773724
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    import pytest
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # setup class instance for test
    my_playbook = Playbook()
    my_playbook.statically_loaded = True
    my_playbook.set_loader(DictDataLoader({}))

    my_play = Play()
    my_play.set_loader(DictDataLoader({}))

    my_block = Block(play=my_play, role=my_playbook, task_include=TaskInclude(play=my_play), use_handlers=False, implicit=True)

    my_block._role = IncludeRole()

# Generated at 2022-06-23 05:59:06.708897
# Unit test for method is_block of class Block
def test_Block_is_block():
    data_block = dict(block=[dict(name='test_task')])
    data_not_block = dict(name="not_block")
    result_block = Block.is_block(data_block)
    result_not_block = Block.is_block(data_not_block)
    assert result_block is True
    assert result_not_block is False

# Generated at 2022-06-23 05:59:10.775167
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    '''
    Unit test for method __repr__ of class Block
    '''
    # We can't instantiate an abstract class, so we just call the method
    this = Block()
    this.__repr__()


# Generated at 2022-06-23 05:59:12.739532
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block = Block()
    assert block.get_dep_chain() is None


# Generated at 2022-06-23 05:59:14.765856
# Unit test for method is_block of class Block
def test_Block_is_block():
    Block_obj = Block()
    ds = {}
    assert Block.is_block(ds)


# Generated at 2022-06-23 05:59:21.891329
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    # Testing 'get_vars' method of class Block
    b = Block(parent_block=None)
    assert b.vars == dict(), 'Block.vars returned incorrect results'
    # Testing 'get_vars' method of class Block when parent_block is defined
    b2 = Block(task_include=None)
    b = Block(parent_block=b2)
    assert b.vars == dict(), 'Block.vars returned incorrect results when parent_block is defined'


# Generated at 2022-06-23 05:59:30.140044
# Unit test for method __eq__ of class Block
def test_Block___eq__():
    # set up the objects to be compared
    a = Block.load({'block': [{'tasks': [{'name': 't1'}], 'block': [{'tasks': [{'name': 't2'}], 'block': [{'tasks': [{'name': 't3'}]}]}]}]})
    b = Block.load({'block': [{'tasks': [{'name': 't1'}], 'block': [{'tasks': [{'name': 't2'}], 'block': [{'tasks': [{'name': 't3'}]}]}]}]})
    assert a == b


# Generated at 2022-06-23 05:59:39.961285
# Unit test for method __eq__ of class Block

# Generated at 2022-06-23 05:59:48.332088
# Unit test for method deserialize of class Block
def test_Block_deserialize():
    data = {}

    b = Block()
    b.deserialize(data)
    assert b._dep_chain is None

    b._parent = True
    b._dep_chain = 'foo'
    b.deserialize(data)
    assert b._dep_chain == 'foo'

    b._parent = None
    b.deserialize(data)
    assert b._dep_chain is None

    data = {'dep_chain': ['a']}
    b.deserialize(data)
    assert b._dep_chain == ['a']



# Generated at 2022-06-23 05:59:58.042372
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,', 'otherhost,'])


# Generated at 2022-06-23 06:00:03.849510
# Unit test for method copy of class Block
def test_Block_copy():

    # Create a mock task so we can check if it was copied to the Block object
    task_mock = MagicMock()
    task_mock.copy.return_value = task_mock
    task_mock.copy.side_effect = task_mock

    # Create a mock role so we can check if it was copied to the Block object
    role_mock = MagicMock()
    role_mock.copy.return_value = role_mock
    role_mock.copy.side_effect = role_mock

    # Create a mock parent block so we can check if it was copied to the Block object
    parent_mock = MagicMock()
    parent_mock.copy.return_value = parent_mock
    parent_mock.copy.side_effect = parent_mock

    # Create a mock loader

# Generated at 2022-06-23 06:00:08.560264
# Unit test for method load of class Block
def test_Block_load():
    assert Block.load([])._ds == {}
    assert Block.load([1])._ds == {'block': [1]}

# Generated at 2022-06-23 06:00:13.094642
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    C.config.init(args=[])
    b = Block()
    b.set_loader(TestMock(dict(path_info=None)))

# Generated at 2022-06-23 06:00:15.136916
# Unit test for method copy of class Block
def test_Block_copy():
    block = Block()

    # TODO implement test code for method Block.copy


# Generated at 2022-06-23 06:00:25.389178
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    t1 = Task.load(dict(action=dict(module='test'))) # t1 is a Task object
    b1 = Block.load(dict(block=[t1, dict(action=dict(module='test'))])) # b1 is a Block object
    t2 = Task.load(dict(action=dict(module='test'))) # t2 is a Task object
    t2.set_loader(DictDataLoader({}))
    b2 = Block.load(dict(block=[t2, t1]), task_include=b1) # b2 is a Task object
    assert (b2.all_parents_static() == False)

    t1 = Task.load(dict(action=dict(module='test'))) # t1 is a Task object

# Generated at 2022-06-23 06:00:31.780502
# Unit test for method get_dep_chain of class Block
def test_Block_get_dep_chain():
    block = Block()
    task1 = Task()
    task1._parent = block
    task2 = Task()
    task2._parent = task1

    assert block.get_dep_chain() is None
    block._dep_chain = [task1]
    assert block.get_dep_chain() == [task1]
    task1._dep_chain = [task2]
    assert block.get_dep_chain() == [task2, task1]

# Generated at 2022-06-23 06:00:43.590615
# Unit test for method deserialize of class Block
def test_Block_deserialize():

    # Test deserialization of a task include
    test_case = {}
    test_case['action'] = 'include'
    test_case['static'] = False
    test_case['args'] = {'tasks': '/home/vagrant/test-galaxy-roles/do-something/tasks/main.yml'}
    test_case['_parent'] = {'action': 'include', 'static': False,
                            'args': {'tasks': '/home/vagrant/test-galaxy-roles/do-something/tasks/main.yml'},
                            'dep_chain': None, 'role': {'_role_name': 'do-something', 'static': True},
                            'parent': None, 'parent_type': None}
    test_case['_dep_chain'] = None



# Generated at 2022-06-23 06:00:45.344862
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    assert Block(1).all_parents_static() == None


# Generated at 2022-06-23 06:00:57.025628
# Unit test for method copy of class Block
def test_Block_copy():
    # Control return value
    ans1 = Block(
        always=None,
        block=None,
        rescue=None,
        when=[{
            'conditional': 'is_windows',
            'static': True
        }]
    )

    # Test data

# Generated at 2022-06-23 06:01:05.568655
# Unit test for method all_parents_static of class Block
def test_Block_all_parents_static():
    b = Block.load({"block": [{"name": "task1", "do": "something"}, {"name": "task2", "do": "something_else"}]}, task_include={"block": [{"name": "task3", "do": "another_thing"}], "role": {"name": "test_role"}}, variable_manager={"test": "testing"})

    assert b.all_parents_static()
    b.block[0].block = {"block": [{"name": "task4", "do": "another_thing"}]}
    assert b.all_parents_static()
    b.block[0].block = {"block": [{"name": "task5", "do": "another_thing", "with_items": "{{ test }}"}]}
    assert not b.all_parents_static()

# Generated at 2022-06-23 06:01:12.146624
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    the_loader = DictDataLoader({})
    block = Block()
    assert block._loader == None
    block.set_loader(the_loader)
    assert block._loader == the_loader
    block._parent = Block()
    block._parent.set_loader(the_loader)
    assert block._parent._loader == the_loader
    block._role = Role()
    block._role.set_loader(the_loader)
    assert block._role._loader == the_loader


# Generated at 2022-06-23 06:01:22.485594
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    block = Block()
    assert block._role is None
    assert block._parent is None
    assert block._play is None
    assert block._loader is None
    assert block._dep_chain == []
    assert block._attribute_errors == []
    assert block.statically_loaded == True
    assert block.notify is None
    assert block.become is None
    assert block.no_log is None
    assert block.loop is None
    assert block.when is None
    assert block.tags == []
    assert block.gather_facts is None
    assert block.register is None
    assert block.free_form is None
    assert block.name is None
    assert block.only_if is None
    assert block.until is None
    assert block.delegate_to is None
    assert block.rescue is None
    assert block

# Generated at 2022-06-23 06:01:24.009224
# Unit test for constructor of class Block
def test_Block():
    results = Block()
    assert results != None


# Generated at 2022-06-23 06:01:34.400469
# Unit test for constructor of class Block
def test_Block():
    b = Block()
    assert b.name is None
    assert b.block is None
    assert b.rescue is None
    assert b.always is None
    assert b.any_errors_fatal is False
    assert b.when is None
    assert b.notify is None
    assert b.become is None
    assert b.become_user is None
    assert b.become_method is None
    assert b.tags == list()
    assert b.register is None
    assert b.run_once is False
    assert b._role is None
    assert b._parent is None
    assert b._play is None
    assert b._dep_chain is None
    assert b._loop is None
    assert b._loop_args == list()
    assert b._included_file is None
    assert b._role is None


# Generated at 2022-06-23 06:01:40.565291
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    b = Block()
    fr_task = Task()
    fr_task._role = Role()
    ti = TaskInclude()
    ti._role = Role()
    t = Task()
    t._role = Role()

    fr_task._parent = None
    ti._parent = fr_task
    t._parent = ti

    b._parent = t
    assert b.get_first_parent_include() == ti
    print("Unit test for method get_first_parent_include of class Block: Success\n")


# Generated at 2022-06-23 06:01:48.760879
# Unit test for method get_first_parent_include of class Block
def test_Block_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    first_parent_include = TaskInclude(None, None, None, None, None, None)
    parent_block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False)
    parent_block._parent = first_parent_include
    child_block = Block(play=None, parent_block=parent_block, role=None, task_include=None, use_handlers=False)
    result = child_block.get_first_parent_include()
    assert result is first_parent_include


# Generated at 2022-06-23 06:01:59.515664
# Unit test for method set_loader of class Block
def test_Block_set_loader():
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    
    # Create the objects that we need to run the task
    loader = AnsibleLoader(None, None)
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)
    loader.set_templar(templar)

# Generated at 2022-06-23 06:02:11.856590
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    block_obj = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=False, implicit=None)
    # test for supported types: Block
    for supported_type in C._BLOCK:
        assert block_obj.filter_tagged_tasks(supported_type)
        # test for unsupported types: str, int, tuple, list, set, frozenset, dict
    for unsupported_type in ['string_value', 1, (1,), [1], {1: 1}, {1}]:
        try:
            block_obj.filter_tagged_tasks(unsupported_type)
        except Exception as e:
            print(e, ':', 'unsupported type: ', type(unsupported_type))


# Generated at 2022-06-23 06:02:23.301433
# Unit test for method filter_tagged_tasks of class Block
def test_Block_filter_tagged_tasks():
    b = Block()
    b.block = [
        Task(name='A', tags=['taskA']),
        Task(name='B', tags=['taskB']),
        Task(name='C', tags=['taskC']),
    ]
    b.rescue = [
        Task(name='D', tags=['taskD']),
        Task(name='E', tags=['taskE']),
        Task(name='F', tags=['taskF']),
    ]
    b.always = [
        Task(name='G', tags=['taskG']),
        Task(name='H', tags=['taskH']),
        Task(name='I', tags=['taskI']),
    ]

    assert(b.filter_tagged_tasks(all_vars={}) == b)

# Generated at 2022-06-23 06:02:27.071699
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    block = Block()
    repr_value = repr(block)
    assert repr_value == "Block (implicit)"


# Generated at 2022-06-23 06:02:32.369357
# Unit test for method __ne__ of class Block
def test_Block___ne__():
    args = dict(
        role=None,
        task_include=None,
        use_handlers=False,
        static=True,
        implicit=False,
        )
    # Assert success for positive cases
    b = Block(**args)
    c = Block(**args)
    assert b != c

# Generated at 2022-06-23 06:02:41.498728
# Unit test for method is_block of class Block
def test_Block_is_block():
    arg1 = {'block': 'ds', 'rescue': 'ds', 'always': 'ds'}
    result = Block.is_block(arg1)
    assert result == True
    
    arg2 = {
        'block': {
            'ignore_errors': 'ignore_errors',
            'tasks': [
                {'debug': 'msg'}
            ]
        }
    }
    result = Block.is_block(arg2)
    assert result == True
    
    
# # load

# Generated at 2022-06-23 06:02:42.323830
# Unit test for method get_vars of class Block
def test_Block_get_vars():
    pass

# Generated at 2022-06-23 06:02:47.416923
# Unit test for method get_include_params of class Block
def test_Block_get_include_params():
    b = Block()
    assert(b.get_include_params() == dict())

    b = Block(parent_block=None)
    assert(b.get_include_params() == dict())

    b = Block(parent_block=Block())
    assert(b.get_include_params() == dict())

# Generated at 2022-06-23 06:02:52.584110
# Unit test for method __repr__ of class Block
def test_Block___repr__():
    # Create mock object for Play()
    # Create mock object for Role()
    # Create mock object for Playbook()
    test_block = Block()
    test_block.name = "myblock"
    assert test_block.__repr__() == "<Block (name='myblock')>"
