

# Generated at 2022-06-16 22:17:28.679234
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-16 22:17:35.426012
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert not is_iterable(None)
    assert not is_iterable(10)
    assert not is_iterable(10.2)
    assert not is_iterable(Exception())


# Generated at 2022-06-16 22:17:46.983324
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)
    assert ImmutableDict(a=1, b=2) == {'a': 1, 'b': 2}
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=3)
    assert ImmutableDict(a=1, b=2) != {'a': 1, 'b': 3}
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=2, c=3)
    assert ImmutableDict(a=1, b=2) != {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-16 22:17:54.275144
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:18:03.252217
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDict objects with the same content
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test for equality of two ImmutableDict objects with different content
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test for equality of an ImmutableDict object and a dict object with the same content
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test for equality of an ImmutableDict object and a dict object with different content

# Generated at 2022-06-16 22:18:09.159861
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict
    """
    # Test with two ImmutableDict objects
    immutable_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    immutable_dict_2 = ImmutableDict({'a': 1, 'b': 2})
    assert immutable_dict_1 == immutable_dict_2

    # Test with two ImmutableDict objects with different keys
    immutable_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    immutable_dict_2 = ImmutableDict({'a': 1, 'c': 2})
    assert immutable_dict_1 != immutable_dict_2

    # Test with two ImmutableDict objects with different values

# Generated at 2022-06-16 22:18:18.890632
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(tuple())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(u'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(True)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object, include_strings=True)
    assert not is_iterable(object)
    assert not is_iterable(object, include_strings=False)


# Generated at 2022-06-16 22:18:31.266106
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:18:39.112725
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(u''))
    assert not is_iterable(None)
    assert not is_iterable(True)

# Generated at 2022-06-16 22:18:49.566561
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__() works as expected
    """
    # Test that two ImmutableDicts with the same keys and values are equal
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})

    # Test that two ImmutableDicts with the same keys but different values are not equal
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})

    # Test that two ImmutableDicts with different keys but the same values are not equal
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})

    # Test that an ImmutableDict and a dict with the same keys and

# Generated at 2022-06-16 22:19:05.624428
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of ImmutableDict with a dictionary
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test for equality of ImmutableDict with another ImmutableDict
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test for equality of ImmutableDict with a list
    assert ImmutableDict({'a': 1, 'b': 2}) != [1, 2]
    # Test for equality of ImmutableDict with a string
    assert ImmutableDict({'a': 1, 'b': 2}) != 'a'
    # Test for equality of ImmutableDict with a tuple

# Generated at 2022-06-16 22:19:18.605215
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test for inequality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2

    # Test for inequality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 != d2

    # Test for inequality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = Immutable

# Generated at 2022-06-16 22:19:31.762679
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test that ImmutableDict is equal to itself
    test_dict = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict == test_dict

    # Test that ImmutableDict is equal to a dict with the same key-value pairs
    assert test_dict == {'a': 1, 'b': 2}

    # Test that ImmutableDict is not equal to a dict with different key-value pairs
    assert test_dict != {'a': 1, 'b': 3}

    # Test that ImmutableDict is not equal to a dict with different keys
    assert test_dict != {'a': 1, 'c': 2}

    # Test that ImmutableDict is not equal to a dict with different values
    assert test_dict != {'a': 2, 'b': 2}

    # Test that Imm

# Generated at 2022-06-16 22:19:40.115508
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict.
    """
    # Test case 1:
    # Two ImmutableDict objects are equal if they have the same key-value pairs.
    # The order of the key-value pairs does not matter.
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'b': 2, 'a': 1})
    assert dict1 == dict2

    # Test case 2:
    # Two ImmutableDict objects are not equal if they have different key-value pairs.
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'b': 2, 'a': 3})
    assert dict1 != dict2

    # Test case 3:
    # Two Immutable

# Generated at 2022-06-16 22:19:47.047169
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2, 'c': 3})
    assert is_iterable(set(['a', 'b', 'c']))
    assert is_iterable(range(3))
    assert is_iterable(xrange(3))
    assert is_iterable(iter(['a', 'b', 'c']))
    assert is_iterable(iter(xrange(3)))
    assert is_iterable(iter(range(3)))
    assert is_iterable(iter(set(['a', 'b', 'c'])))
    assert is_iterable(iter({'a': 1, 'b': 2, 'c': 3}))

# Generated at 2022-06-16 22:19:59.419586
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(1, 10))
    assert is_iterable(xrange(1, 10))
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert is_iterable(bytearray(u'abc'))
    assert is_iter

# Generated at 2022-06-16 22:20:04.936018
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:20:11.371583
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test case 1:
    #   - ImmutableDict1 = {'a': 1, 'b': 2}
    #   - ImmutableDict2 = {'a': 1, 'b': 2}
    #   - ImmutableDict3 = {'a': 1, 'b': 3}
    #   - ImmutableDict4 = {'a': 1, 'b': 2, 'c': 3}
    #   - ImmutableDict5 = {'a': 1, 'b': 2, 'c': 3}
    #   - ImmutableDict6 = {'a': 1, 'b': 2, 'c': 4}
    #   - ImmutableDict7 = {'a': 1, 'b': 2, 'c': 3, 'd

# Generated at 2022-06-16 22:20:22.892730
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(1))
    assert is_iterable(xrange(1))
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(1)))
    assert is_iterable(iter(xrange(1)))

# Generated at 2022-06-16 22:20:34.430782
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})

    # Test for inequality
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})

# Generated at 2022-06-16 22:20:54.738810
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable(('a', 'b', 'c'))
    assert is_iterable({'a', 'b', 'c'})
    assert is_iterable({'a': 1, 'b': 2, 'c': 3})
    assert is_iterable(set(['a', 'b', 'c']))
    assert is_iterable(frozenset(['a', 'b', 'c']))
    assert is_iterable(xrange(1, 10))
    assert is_iterable(iter(['a', 'b', 'c']))
    assert is_iterable(iter(('a', 'b', 'c')))
    assert is_iterable(iter(set(['a', 'b', 'c'])))

# Generated at 2022-06-16 22:21:05.618134
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert not is_iterable(None)
    assert not is_iterable(10)
    assert not is_iterable(10.2)
    assert not is_iterable(object())
    assert not is_iterable(Exception())


# Generated at 2022-06-16 22:21:13.488375
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != {'a': 1}
    assert ImmutableDict({'a': 1}) != 'a'
    assert ImmutableDict({'a': 1}) != None

# Generated at 2022-06-16 22:21:17.858588
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(1) is False
    assert is_iterable(None) is False


# Generated at 2022-06-16 22:21:29.672132
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test with different types of arguments
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:21:41.549567
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of the ImmutableDict class.
    """
    # Test equality of two ImmutableDict objects
    test_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    test_dict_2 = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict_1 == test_dict_2

    # Test equality of an ImmutableDict object and a dict object
    test_dict_3 = ImmutableDict({'a': 1, 'b': 2})
    test_dict_4 = {'a': 1, 'b': 2}
    assert test_dict_3 == test_dict_4

    # Test inequality of two ImmutableDict objects

# Generated at 2022-06-16 22:21:50.405531
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-16 22:22:02.444726
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test for equal dictionaries
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test for equal dictionaries with different order of keys
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'b': 2, 'a': 1})
    assert d1 == d2

    # Test for unequal dictionaries
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2

    # Test for unequal dictionaries with different

# Generated at 2022-06-16 22:22:14.449497
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(tuple())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(dict()))
    assert is_iterable(iter(tuple()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)
    assert not is_iterable(0)
    assert not is_iterable(0.0)
    assert not is_iterable('')
    assert not is_iterable

# Generated at 2022-06-16 22:22:25.637413
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1})

# Generated at 2022-06-16 22:22:52.045606
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(a=1, b=2)
    d3 = ImmutableDict(a=1, b=3)
    d4 = ImmutableDict(a=1, b=2, c=3)
    d5 = ImmutableDict(a=1, b=3, c=3)
    d6 = ImmutableDict(a=1, b=2, c=3, d=4)
    d7 = ImmutableDict(a=1, b=2, c=3, d=4, e=5)
    d8 = ImmutableDict(a=1, b=2, c=3, d=4, e=5, f=6)

# Generated at 2022-06-16 22:22:59.521932
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict
    """
    # Test that two ImmutableDict objects with the same key-value pairs are equal
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 == d2

    # Test that two ImmutableDict objects with different key-value pairs are not equal
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d2 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    assert d1 != d2

    # Test that an ImmutableDict object is not equal to a dict object with the same key-value pairs

# Generated at 2022-06-16 22:23:12.103167
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test that ImmutableDict is equal to itself
    a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert a == a

    # Test that ImmutableDict is equal to a dict with the same key-value pairs
    b = {'a': 1, 'b': 2, 'c': 3}
    assert a == b

    # Test that ImmutableDict is not equal to a dict with different key-value pairs
    c = {'a': 1, 'b': 2, 'c': 4}
    assert a != c

    # Test that ImmutableDict is not equal to a dict with different keys
    d = {'a': 1, 'b': 2, 'd': 3}
    assert a != d

    # Test that ImmutableDict is not equal to a dict with different values


# Generated at 2022-06-16 22:23:19.840279
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(3))
    assert is_iterable(xrange(3))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(xrange(3)))
    assert is_iterable(iter(range(3)))
    assert is_iterable(iter(set([1, 2, 3])))
    assert is_iterable(iter({'a': 1, 'b': 2}))
    assert is_iterable(iter((1, 2, 3)))


# Generated at 2022-06-16 22:23:29.279199
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:23:35.918952
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable((x for x in range(10)))
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(u'unicode')
    assert is_iterable(b'bytes')
    assert is_iterable(1) is False
    assert is_iterable(None) is False


# Generated at 2022-06-16 22:23:45.776514
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(u'')
    assert is_iterable(xrange(0))
    assert is_iterable(xrange(1))
    assert is_iterable(xrange(2))
    assert is_iterable(xrange(3))
    assert is_iterable(xrange(4))
    assert is_iterable(xrange(5))
    assert is_iterable(xrange(6))
    assert is_iterable(xrange(7))
    assert is_iterable(xrange(8))
    assert is_iterable(xrange(9))


# Generated at 2022-06-16 22:23:58.214698
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict
    """
    test_dict1 = ImmutableDict({'a': 1, 'b': 2})
    test_dict2 = ImmutableDict({'a': 1, 'b': 2})
    test_dict3 = ImmutableDict({'a': 1, 'b': 3})
    test_dict4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_dict5 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_dict6 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    test_dict7 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})

# Generated at 2022-06-16 22:24:08.375172
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:24:19.173142
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test case 1:
    # Two ImmutableDict objects with the same key-value pairs are equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test case 2:
    # Two ImmutableDict objects with different key-value pairs are not equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 3})
    assert dict1 != dict2

    # Test case 3:
    # An ImmutableDict object and a dict object with the same key-value pairs are not equal
    dict1 = Immutable

# Generated at 2022-06-16 22:25:05.717472
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-16 22:25:18.445912
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1, 'a': 1})

# Generated at 2022-06-16 22:25:25.671045
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(u'abc'.encode('utf-8'))
    assert is_iterable(1) is False
    assert is_iterable(None) is False



# Generated at 2022-06-16 22:25:39.147514
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable(('a', 'b', 'c'))
    assert is_iterable({'a', 'b', 'c'})
    assert is_iterable({'a': 1, 'b': 2, 'c': 3})
    assert is_iterable(xrange(0, 10))
    assert is_iterable(set(xrange(0, 10)))
    assert is_iterable(dict(zip(xrange(0, 10), xrange(0, 10))))
    assert is_iterable(iter(xrange(0, 10)))
    assert is_iterable(iter(dict(zip(xrange(0, 10), xrange(0, 10)))))
    assert is_iterable(iter(set(xrange(0, 10))))

# Generated at 2022-06-16 22:25:47.709312
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({}))
    assert is_iterable(ImmutableDict({}).items())

# Generated at 2022-06-16 22:26:00.496205
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(u''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(range(0)))
    assert is_

# Generated at 2022-06-16 22:26:11.104180
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test case 1:
    # Two ImmutableDict objects with same key-value pairs
    # Expected result:
    # The two ImmutableDict objects are equal
    test_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    test_dict_2 = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict_1 == test_dict_2

    # Test case 2:
    # Two ImmutableDict objects with different key-value pairs
    # Expected result:
    # The two ImmutableDict objects are not equal
    test_dict_1 = ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-16 22:26:17.803857
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test __eq__ method of ImmutableDict class"""
    # Test 1: Test equality of two ImmutableDicts
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test 2: Test inequality of two ImmutableDicts
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 3})
    assert dict1 != dict2

    # Test 3: Test equality of ImmutableDict and dict
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = {'a': 1, 'b': 2}
    assert dict1 == dict2

   

# Generated at 2022-06-16 22:26:30.133500
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(u'unicode')
    assert is_iterable(b'bytes')
    assert is_iterable(u'unicode'.encode('utf-8'))
    assert is_iterable(u'unicode'.encode('utf-16'))
    assert is_iterable(u'unicode'.encode('utf-32'))
    assert is_iterable(u'unicode'.encode('latin-1'))
    assert is_iterable(u'unicode'.encode('ascii'))

# Generated at 2022-06-16 22:26:39.332979
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 2}