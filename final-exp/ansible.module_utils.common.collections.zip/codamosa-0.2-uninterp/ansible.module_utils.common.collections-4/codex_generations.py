

# Generated at 2022-06-16 22:17:20.767566
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of ImmutableDict and MutableMapping
    assert ImmutableDict(a=1, b=2) == {'a': 1, 'b': 2}

    # Test for equality of ImmutableDict and ImmutableDict
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)

    # Test for equality of ImmutableDict and MutableMapping with different keys
    assert ImmutableDict(a=1, b=2) != {'a': 1, 'b': 3}

    # Test for equality of ImmutableDict and ImmutableDict with different keys
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=3)

    # Test for equality of ImmutableDict and Mutable

# Generated at 2022-06-16 22:17:31.631553
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:17:44.636357
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__() returns True when the ImmutableDict is equal to another ImmutableDict
    and False when the ImmutableDict is not equal to another ImmutableDict
    """
    # Test that ImmutableDict.__eq__() returns True when the ImmutableDict is equal to another ImmutableDict
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-16 22:17:52.808238
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict
    """
    # Test equality of two ImmutableDicts
    a = ImmutableDict({"a": 1, "b": 2})
    b = ImmutableDict({"a": 1, "b": 2})
    assert a == b

    # Test equality of an ImmutableDict and a dict
    a = ImmutableDict({"a": 1, "b": 2})
    b = {"a": 1, "b": 2}
    assert a == b

    # Test equality of an ImmutableDict and a list
    a = ImmutableDict({"a": 1, "b": 2})
    b = [("a", 1), ("b", 2)]
    assert a == b

    # Test equality of an ImmutableDict and a tuple
    a = Imm

# Generated at 2022-06-16 22:18:02.686190
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict
    """
    # Test that two ImmutableDicts with the same values are equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test that two ImmutableDicts with different values are not equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 3})
    assert dict1 != dict2

    # Test that an ImmutableDict is not equal to a MutableDict with the same values
    dict1 = ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-16 22:18:14.356313
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1, 2, 3})
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(frozenset([1, 2, 3]))
    assert is_iterable(range(1, 4))
    assert is_iterable(xrange(1, 4))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(xrange(1, 4)))
    assert is_iterable(iter(range(1, 4)))
    assert is_iterable(iter(set([1, 2, 3])))
    assert is_

# Generated at 2022-06-16 22:18:23.985766
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict().items())
    assert is_iterable(ImmutableDict().keys())
    assert is_iterable(ImmutableDict().values())
   

# Generated at 2022-06-16 22:18:35.956452
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of ImmutableDict and dict
    assert ImmutableDict({'a': 1}) == {'a': 1}
    assert ImmutableDict({'a': 1}) != {'a': 2}
    assert ImmutableDict({'a': 1}) != {'b': 1}
    assert ImmutableDict({'a': 1}) != {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1}
    assert ImmutableDict({'a': 1, 'b': 2}) != {'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}

# Generated at 2022-06-16 22:18:45.664226
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of ImmutableDict with itself
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test equality of ImmutableDict with a different ImmutableDict
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test equality of ImmutableDict with a dict
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test equality of ImmutableDict with a different dict
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}
    # Test equality of ImmutableDict with a list

# Generated at 2022-06-16 22:18:53.773114
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))

    assert not is_iterable(None)
    assert not is_iterable(10)
    assert not is_iterable(10.5)
    assert not is_iterable(object())
    assert not is_iterable(object)
    assert not is_iterable(type)

    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))


# Generated at 2022-06-16 22:19:07.946608
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)

# Generated at 2022-06-16 22:19:20.136840
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:19:33.140726
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDict objects
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test for equality of an ImmutableDict object and a dict object
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test for equality of an ImmutableDict object and a dict object with different order
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}
    # Test for equality of an ImmutableDict object and a dict object with different order
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}
    # Test for equality

# Generated at 2022-06-16 22:19:42.697178
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(u''))

# Generated at 2022-06-16 22:19:53.798383
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:20:05.638039
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:20:18.489732
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__() works as expected
    """
    # Test that ImmutableDict.__eq__() returns True when comparing two ImmutableDicts with the same key-value pairs
    assert ImmutableDict({"a": 1, "b": 2}) == ImmutableDict({"a": 1, "b": 2})
    # Test that ImmutableDict.__eq__() returns False when comparing two ImmutableDicts with different key-value pairs
    assert not ImmutableDict({"a": 1, "b": 2}) == ImmutableDict({"a": 1, "b": 3})
    # Test that ImmutableDict.__eq__() returns False when comparing an ImmutableDict with a dict

# Generated at 2022-06-16 22:20:30.579582
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({}))
    assert is_iterable(ImmutableDict({'a': 1}))

# Generated at 2022-06-16 22:20:39.399629
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable(set())
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(dict())
    assert is_iterable(dict(a=1, b=2, c=3))
    assert is_iterable(xrange(10))
    assert is_iterable(xrange(1, 10))
    assert is_iterable(xrange(1, 10, 2))
    assert is_iterable(iter([]))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(set([1, 2, 3])))

# Generated at 2022-06-16 22:20:52.006215
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of the ImmutableDict class
    """
    # Test equality of two ImmutableDicts
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})

    # Test equality of an ImmutableDict and a dict
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

    # Test equality of an ImmutableDict and a list
    assert ImmutableDict({'a': 1, 'b': 2}) == [('a', 1), ('b', 2)]

    # Test equality of an ImmutableDict and a tuple
    assert ImmutableDict({'a': 1, 'b': 2}) == (('a', 1), ('b', 2))

   

# Generated at 2022-06-16 22:21:10.671365
# Unit test for method __eq__ of class ImmutableDict

# Generated at 2022-06-16 22:21:19.030232
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(5) is False
    assert is_iterable('abc') is False
    assert is_iterable(u'abc') is False
    assert is_iterable(b'abc') is False
    assert is_iterable(bytearray(b'abc')) is False
    assert is_iterable(None) is False
    assert is_iterable(Exception()) is False

    assert is_iterable([], include_strings=True)

# Generated at 2022-06-16 22:21:30.581246
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test case 1:
    #   Two ImmutableDicts with the same key-value pairs are equal
    #   Two ImmutableDicts with the same key-value pairs are hashable
    #   Two ImmutableDicts with the same key-value pairs have the same hash
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2
    assert hash(dict1) == hash(dict2)

    # Test case 2:
    #   Two ImmutableDicts with different key-value pairs are not equal
    #   Two ImmutableDicts with different key-value pairs are hashable
    #   Two ImmutableDicts with different key-value pairs have different hashes

# Generated at 2022-06-16 22:21:42.401069
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(xrange(1))
    assert is_iterable(xrange(2))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(xrange(1)))
    assert is_iterable(iter(xrange(2)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
   

# Generated at 2022-06-16 22:21:52.868195
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2
    # Test for inequality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2
    # Test for inequality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 != d2
    # Test for inequality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = Immutable

# Generated at 2022-06-16 22:22:01.695952
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert not is_iterable(10)
    assert not is_iterable(10.1)
    assert not is_iterable(None)
    assert not is_iterable(object())


# Generated at 2022-06-16 22:22:13.789456
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(u'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(True)
    assert is_iterable(False)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object)
    assert is_iterable(test_is_iterable)
    assert is_iterable(is_iterable)
    assert is_iterable(is_iterable)
    assert is_iterable(ImmutableDict())
    assert is_

# Generated at 2022-06-16 22:22:25.003960
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of ImmutableDict objects
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'c': 1, 'b': 2})

# Generated at 2022-06-16 22:22:35.856224
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:22:46.614720
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test case 1:
    #   ImmutableDict1 = {'a': 1, 'b': 2}
    #   ImmutableDict2 = {'a': 1, 'b': 2}
    #   ImmutableDict1 == ImmutableDict2
    #   Expected result: True
    ImmutableDict1 = ImmutableDict({'a': 1, 'b': 2})
    ImmutableDict2 = ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict1 == ImmutableDict2

    # Test case 2:
    #   ImmutableDict1 = {'a': 1, 'b': 2}
    #   ImmutableDict2 = {'a': 1, 'b': 3}
    #   ImmutableDict1 == ImmutableDict2
    #

# Generated at 2022-06-16 22:23:12.435607
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({})
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set())
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter([]))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(10)))

# Generated at 2022-06-16 22:23:18.810382
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert not is_iterable(None)
    assert not is_iterable(10)
    assert not is_iterable(10.2)
    assert not is_iterable(True)



# Generated at 2022-06-16 22:23:28.744473
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 2, 'c': 3}
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1}

# Generated at 2022-06-16 22:23:40.456562
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2
    assert d2 == d1

    # Test for inequality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2
    assert d2 != d1

    # Test for inequality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 != d2
    assert d2 != d1

    # Test for inequality
    d

# Generated at 2022-06-16 22:23:48.250982
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDict objects with same keys and values
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test for equality of two ImmutableDict objects with same keys and values but different order
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    # Test for equality of two ImmutableDict objects with same keys but different values
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test for equality of two ImmutableDict objects with different keys

# Generated at 2022-06-16 22:24:01.179472
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test method __eq__ of class ImmutableDict"""
    # Test case 1:
    #   - ImmutableDict is equal to ImmutableDict with the same content
    #   - ImmutableDict is not equal to ImmutableDict with different content
    #   - ImmutableDict is not equal to a dict with the same content
    #   - ImmutableDict is not equal to a dict with different content
    #   - ImmutableDict is not equal to a list with the same content
    #   - ImmutableDict is not equal to a list with different content
    #   - ImmutableDict is not equal to a string with the same content
    #   - ImmutableDict is not equal to a string with different content
    #   - ImmutableDict is not equal to an integer with the same content
    #   - ImmutableD

# Generated at 2022-06-16 22:24:08.039292
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__ works as expected.
    """
    # Test that ImmutableDict.__eq__ returns True if the two ImmutableDict objects are equal
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test that ImmutableDict.__eq__ returns False if the two ImmutableDict objects are not equal
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test that ImmutableDict.__eq__ returns False if the two ImmutableDict objects are not equal

# Generated at 2022-06-16 22:24:18.861435
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__ works as expected.
    """
    # Test that ImmutableDict.__eq__ returns True when comparing two ImmutableDict instances
    # with the same key-value pairs
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test that ImmutableDict.__eq__ returns False when comparing two ImmutableDict instances
    # with different key-value pairs
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2

    # Test that ImmutableDict.__eq__ returns False when comparing

# Generated at 2022-06-16 22:24:27.548761
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(u'abc'.encode('utf-8'))
    assert not is_iterable(None)
    assert not is_iterable(10)
    assert not is_iterable(10.2)
    assert not is_iterable(object())



# Generated at 2022-06-16 22:24:35.373536
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test __eq__ method of ImmutableDict class
    """
    # Test 1: Test equality of two ImmutableDict objects
    test_dict1 = ImmutableDict({'a': 1, 'b': 2})
    test_dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict1 == test_dict2

    # Test 2: Test equality of ImmutableDict object with a dictionary
    test_dict1 = ImmutableDict({'a': 1, 'b': 2})
    test_dict2 = {'a': 1, 'b': 2}
    assert test_dict1 == test_dict2

    # Test 3: Test equality of ImmutableDict object with a dictionary with different order

# Generated at 2022-06-16 22:24:59.146334
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Unit test for method __eq__ of class ImmutableDict
    """
    # Test case 1:
    #   Two ImmutableDict objects are equal if and only if their hash values are equal
    #   and they have the same key-value pairs
    #   (i.e. the hash values are equal if and only if the key-value pairs are equal)
    #   This test case tests the case where the hash values are equal but the key-value
    #   pairs are not equal
    #   The expected result is that the two ImmutableDict objects are not equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 3})
    assert dict1 != dict2

    # Test case 2:
    #   Two ImmutableDict

# Generated at 2022-06-16 22:25:11.458749
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    d3 = ImmutableDict({'a': 1, 'b': 3})
    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d5 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d6 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    d7 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    d8 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})

# Generated at 2022-06-16 22:25:23.302135
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({'a': 1}))
    assert is_iterable(ImmutableDict(a=1))

# Generated at 2022-06-16 22:25:31.241277
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1, 'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2, 'b': 1})

# Generated at 2022-06-16 22:25:43.115110
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(True)
    assert is_iterable(False)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object)
    assert is_iterable(is_iterable)
    assert is_iterable(test_is_iterable)
    assert is_iterable(x for x in range(10))

# Generated at 2022-06-16 22:25:55.069398
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1, 2, 3})
    assert is_iterable({1: 2, 3: 4})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(frozenset([1, 2, 3]))
    assert is_iterable(range(1, 4))
    assert is_iterable(xrange(1, 4))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(xrange(1, 4)))
    assert is_iterable(iter(range(1, 4)))
    assert is_iterable(iter(set([1, 2, 3])))
    assert is_iterable

# Generated at 2022-06-16 22:26:06.861030
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of ImmutableDict
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 2, 'c': 3}
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1}
    assert Immutable

# Generated at 2022-06-16 22:26:15.314721
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert not is_iterable(None)
    assert not is_iterable(10)
    assert not is_iterable(10.2)
    assert not is_iterable(Exception())
    assert not is_iterable(Exception)
    assert not is_iterable(Exception('test'))
    assert not is_iterable(Exception('test', 'test2'))
    assert not is_iterable(Exception('test', 'test2', 'test3'))

# Generated at 2022-06-16 22:26:27.831229
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({}))
    assert is_iterable(ImmutableDict({'a': 1}))

# Generated at 2022-06-16 22:26:37.566679
# Unit test for function is_iterable
def test_is_iterable():
    """Test the is_iterable function."""
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(tuple())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(xrange(1)))
    assert is_iterable(iter(xrange(2)))
    assert is_iterable(iter(xrange(3)))
    assert is_iterable(iter(xrange(4)))
    assert is_iterable(iter(xrange(5)))
    assert is_iterable(iter(xrange(6)))
    assert is_iterable

# Generated at 2022-06-16 22:27:16.387358
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(u'abc'.encode('utf-8'))
    assert is_iterable(1) is False
    assert is_iterable(None) is False
