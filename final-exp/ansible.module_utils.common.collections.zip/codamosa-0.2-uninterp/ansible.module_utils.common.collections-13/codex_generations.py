

# Generated at 2022-06-16 22:17:30.204098
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(xrange(0)))

# Generated at 2022-06-16 22:17:42.924485
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict(a=1, b=2, c=3)
    b = ImmutableDict(a=1, b=2, c=3)
    c = ImmutableDict(a=1, b=2, c=3, d=4)
    d = ImmutableDict(a=1, b=2, c=3, d=4)
    e = ImmutableDict(a=1, b=2, c=3, d=4)
    f = ImmutableDict(a=1, b=2, c=3, d=4)
    g = ImmutableDict(a=1, b=2, c=3, d=4)
    h = ImmutableDict(a=1, b=2, c=3, d=4)
    i = ImmutableDict

# Generated at 2022-06-16 22:17:49.559907
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1: 'a', 2: 'b', 3: 'c'})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable('abc')
    assert is_iterable(b'abc')
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(None)


# Generated at 2022-06-16 22:18:00.543350
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1: 'a', 2: 'b', 3: 'c'})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(1, 10))
    assert is_iterable(xrange(1, 10))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter((1, 2, 3)))
    assert is_iterable(iter({1: 'a', 2: 'b', 3: 'c'}))
    assert is_iterable(iter(set([1, 2, 3])))
    assert is_iterable(iter(range(1, 10)))
    assert is_iterable

# Generated at 2022-06-16 22:18:11.923965
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test for equality of two ImmutableDict objects
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2
    # Test for inequality of two ImmutableDict objects
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2
    # Test for equality of an ImmutableDict object and a dict object
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'a': 1, 'b': 2}
    assert d1 == d2

# Generated at 2022-06-16 22:18:22.522138
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:18:34.757237
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDicts
    dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert dict1 == dict2

    # Test for inequality of two ImmutableDicts
    dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict2 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    assert dict1 != dict2

    # Test for equality of an ImmutableDict and a dict
    dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-16 22:18:44.817459
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test case 1:
    #   - ImmutableDict is equal to a dictionary with the same key-value pairs
    #   - ImmutableDict is not equal to a dictionary with different key-value pairs
    #   - ImmutableDict is not equal to a dictionary with the same key-value pairs, but in a different order
    #   - ImmutableDict is not equal to a dictionary with the same key-value pairs, but with a different type
    #   - ImmutableDict is not equal to a dictionary with the same key-value pairs, but with a different type
    #   - ImmutableDict is not equal to a dictionary with the same key-value pairs, but with a different type
    #   - ImmutableDict is not equal to a dictionary with the same key-

# Generated at 2022-06-16 22:18:53.494524
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test for inequality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2

    # Test for inequality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 != d2

    # Test for inequality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = Immutable

# Generated at 2022-06-16 22:19:05.282266
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(1, 3))
    assert is_iterable(xrange(1, 3))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(xrange(1, 3)))
    assert is_iterable(iter(range(1, 3)))
    assert is_iterable(iter(set([1, 2, 3])))
    assert is_iterable(iter({'a': 1, 'b': 2}))
    assert is_iterable(iter((1, 2, 3)))
   

# Generated at 2022-06-16 22:19:20.298133
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test for method __eq__ of class ImmutableDict"""
    # Test for equality with a dictionary
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'a': 1, 'b': 2}
    assert d1 == d2

    # Test for equality with a different dictionary
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'a': 1, 'b': 3}
    assert d1 != d2

    # Test for equality with a different ImmutableDict
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2

    # Test for equality with a different ImmutableDict
    d

# Generated at 2022-06-16 22:19:33.340410
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDict objects
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test for equality of an ImmutableDict object and a dict object
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test for equality of an ImmutableDict object and a dict object with different order of keys
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}
    # Test for equality of an ImmutableDict object and a dict object with different number of keys
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1}
    # Test for equality of

# Generated at 2022-06-16 22:19:42.980479
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({'a': 1}))
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(None)
    assert not is_iterable(object())
    assert not is_iterable

# Generated at 2022-06-16 22:19:54.184723
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:20:05.898480
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=2, c=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, c=2)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2)
    assert ImmutableDict(a=1, b=2) != ImmutableD

# Generated at 2022-06-16 22:20:18.846030
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(object())
    assert is_iterable(object)
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(1j)
    assert is_iterable(u'unicode')
    assert is_iterable(b'bytes')
    assert is_iterable(bytearray(b'bytearray'))
    assert is_iterable(memoryview(b'memoryview'))
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter([]))

# Generated at 2022-06-16 22:20:31.004444
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict() == {}
    assert ImmutableDict(a=1) == ImmutableDict(a=1)
    assert ImmutableDict(a=1) == {'a': 1}
    assert ImmutableDict(a=1) != ImmutableDict(a=2)
    assert ImmutableDict(a=1) != {'a': 2}
    assert ImmutableDict(a=1) != ImmutableDict(b=1)
    assert ImmutableDict(a=1) != {'b': 1}
    assert ImmutableDict(a=1, b=2) == ImmutableDict(b=2, a=1)

# Generated at 2022-06-16 22:20:39.269753
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Unit test for method __eq__ of class ImmutableDict
    """
    # Test case 1:
    # Two ImmutableDict objects with same key-value pairs
    # Expected result: True
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test case 2:
    # Two ImmutableDict objects with different key-value pairs
    # Expected result: False
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 3})
    assert dict1 != dict2

    # Test case 3:
    # Two ImmutableDict objects with different keys
    # Ex

# Generated at 2022-06-16 22:20:51.898297
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable({'a', 'b', 'c'})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(1, 10))
    assert is_iterable(xrange(1, 10))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(xrange(1, 10)))
    assert is_iterable(iter({'a': 1, 'b': 2}))
    assert is_iterable(iter({'a', 'b', 'c'}))
    assert is_

# Generated at 2022-06-16 22:21:00.068899
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert is_iterable(xrange(0))
    assert is_iterable(xrange(1))
    assert is_iterable(xrange(2))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(u''))
    assert is_iterable(iter(b''))
    assert is_

# Generated at 2022-06-16 22:21:14.067717
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert is_iterable(0)
    assert is_iterable(0.0)
    assert is_iter

# Generated at 2022-06-16 22:21:23.530445
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of ImmutableDict with itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d1

    # Test equality of ImmutableDict with another ImmutableDict with the same items
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test equality of ImmutableDict with another ImmutableDict with the same items in different order
    d3 = ImmutableDict({'b': 2, 'a': 1})
    assert d1 == d3

    # Test equality of ImmutableDict with a dict with the same items
    d4 = {'a': 1, 'b': 2}
    assert d1 == d4

    # Test equality of ImmutableDict with a dict with the same items in different order

# Generated at 2022-06-16 22:21:32.376160
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)

# Generated at 2022-06-16 22:21:43.935090
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:21:55.824690
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test case 1:
    #   ImmutableDict with same keys and values
    #   Expected result: True
    dict1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    dict2 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert dict1 == dict2

    # Test case 2:
    #   ImmutableDict with same keys and different values
    #   Expected result: False
    dict1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    dict2 = ImmutableDict({'key1': 'value1', 'key2': 'value3'})
    assert dict1 != dict2

    # Test case 3:
    #   ImmutableDict with different

# Generated at 2022-06-16 22:22:05.873089
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable(object())
    assert is_iterable([], include_strings=True)
    assert is_iterable((), include_strings=True)
    assert is_iterable({}, include_strings=True)
    assert is_iterable(set(), include_strings=True)


# Generated at 2022-06-16 22:22:18.467336
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable(object())
    assert not is_iterable(object)
    assert not is_iterable(type)
    assert not is_iterable(is_iterable)

# Generated at 2022-06-16 22:22:28.980877
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:22:40.766547
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable(set())
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(dict())
    assert is_iterable(dict(a=1, b=2, c=3))
    assert is_iterable(xrange(10))
    assert is_iterable(xrange(1, 10))
    assert is_iterable(xrange(1, 10, 2))
    assert is_iterable(iter([]))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(set([1, 2, 3])))

# Generated at 2022-06-16 22:22:44.547541
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test case 1:
    # Two ImmutableDict objects are equal
    # if they have the same keys and values
    immutable_dict_1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    immutable_dict_2 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert immutable_dict_1 == immutable_dict_2

    # Test case 2:
    # Two ImmutableDict objects are not equal
    # if they have different keys
    immutable_dict_1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})

# Generated at 2022-06-16 22:23:00.337870
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(5) is False
    assert is_iterable(None) is False



# Generated at 2022-06-16 22:23:12.940028
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(tuple())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(dict()))
    assert is_iterable(iter(tuple()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable('string')
    assert not is_iterable

# Generated at 2022-06-16 22:23:20.347791
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(set([1, 2, 3])))
    assert is_iterable(iter({'a': 1, 'b': 2}))
    assert is_iterable(iter((1, 2, 3)))

# Generated at 2022-06-16 22:23:29.589210
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test the __eq__ method of ImmutableDict class"""
    # Test case 1: Two ImmutableDict instances with the same key-value pairs
    # are equal
    immutable_dict_1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    immutable_dict_2 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert immutable_dict_1 == immutable_dict_2

    # Test case 2: Two ImmutableDict instances with the same key-value pairs
    # but in different order are equal
    immutable_dict_1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})

# Generated at 2022-06-16 22:23:41.506369
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test case 1:
    #   - ImmutableDict1 = ImmutableDict(a=1, b=2)
    #   - ImmutableDict2 = ImmutableDict(a=1, b=2)
    #   - ImmutableDict3 = ImmutableDict(a=1, b=3)
    #   - ImmutableDict4 = ImmutableDict(a=1, b=2, c=3)
    #   - ImmutableDict5 = ImmutableDict(a=1, b=2, c=3)
    #   - ImmutableDict6 = ImmutableDict(a=1, b=2, c=3)
    #   - ImmutableDict7 = ImmutableDict(a=1,

# Generated at 2022-06-16 22:23:48.607115
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDicts
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test for equality of an ImmutableDict and a dict
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'a': 1, 'b': 2}
    assert d1 == d2

    # Test for equality of an ImmutableDict and a dict with different order of keys
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'b': 2, 'a': 1}
    assert d1 == d2

    # Test for inequality of two ImmutableDicts

# Generated at 2022-06-16 22:24:01.544841
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test method __eq__ of class ImmutableDict"""
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    d3 = ImmutableDict({'a': 1, 'b': 3})
    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d5 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    d6 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    d7 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})

# Generated at 2022-06-16 22:24:08.686540
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test with two ImmutableDict objects
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    assert a == b

    # Test with two ImmutableDict objects with different keys
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'c': 2})
    assert a != b

    # Test with two ImmutableDict objects with different values
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 3})
    assert a != b

    # Test with an ImmutableDict object and a dict object

# Generated at 2022-06-16 22:24:19.850148
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict
    """
    # Test equality of ImmutableDict with itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d1

    # Test equality of ImmutableDict with another ImmutableDict with same key-value pairs
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test equality of ImmutableDict with another ImmutableDict with same key-value pairs but different order
    d3 = ImmutableDict({'b': 2, 'a': 1})
    assert d1 == d3

    # Test equality of ImmutableDict with a dict with same key-value pairs
    d4 = {'a': 1, 'b': 2}

# Generated at 2022-06-16 22:24:30.549171
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict
    """
    # Test equality of two ImmutableDicts
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test inequality of two ImmutableDicts
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test equality of an ImmutableDict and a dict
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test inequality of an ImmutableDict and a dict
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}
    #

# Generated at 2022-06-16 22:24:57.019073
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert not is_iterable(None)
    assert not is_iterable(10)
    assert not is_iterable(10.2)
    assert not is_iterable(object())


# Generated at 2022-06-16 22:25:05.139136
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of ImmutableDicts
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test for inequality of ImmutableDicts
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 3})
    assert dict1 != dict2

    # Test for equality of ImmutableDict and MutableMapping
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = {'a': 1, 'b': 2}
    assert dict1 == dict2

    # Test for inequality of ImmutableDict and MutableMapping
    dict1 = Imm

# Generated at 2022-06-16 22:25:17.823405
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test case 1:
    #   - ImmutableDict1 and ImmutableDict2 are equal
    #   - ImmutableDict1 and ImmutableDict3 are not equal
    #   - ImmutableDict1 and ImmutableDict4 are not equal
    ImmutableDict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    ImmutableDict2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    ImmutableDict3 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    ImmutableDict4 = ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict1 == ImmutableDict2
    assert ImmutableDict1 != ImmutableDict3
   

# Generated at 2022-06-16 22:25:28.079245
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))

    assert not is_iterable(None)
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable(0)
    assert not is_iterable(0.0)

# Generated at 2022-06-16 22:25:40.877361
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1: 2, 3: 4})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(1, 10))
    assert is_iterable(xrange(1, 10))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(xrange(1, 10)))
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(object())
    assert not is_iterable(None)
    assert not is_iterable(True)

# Generated at 2022-06-16 22:25:48.698909
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__() returns True when the two ImmutableDicts are equal
    and False when they are not.
    """
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-16 22:26:01.009396
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1, 'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 2, 'a': 2})

# Generated at 2022-06-16 22:26:11.576449
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test case 1:
    #   - ImmutableDict1 = {'a': 1, 'b': 2, 'c': 3}
    #   - ImmutableDict2 = {'a': 1, 'b': 2, 'c': 3}
    #   - ImmutableDict3 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    #   - ImmutableDict4 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    #   - ImmutableDict5 = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    #   - ImmutableDict6 = {'a': 1, 'b': 2

# Generated at 2022-06-16 22:26:23.411622
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)

# Generated at 2022-06-16 22:26:34.009345
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test for equality of two ImmutableDict objects
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2
    # Test for equality of an ImmutableDict object and a dict object
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = {'a': 1, 'b': 2}
    assert dict1 == dict2
    # Test for equality of an ImmutableDict object and a dict object with different order of keys
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = {'b': 2, 'a': 1}