

# Generated at 2022-06-16 22:17:21.273570
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)

# Generated at 2022-06-16 22:17:32.163055
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__() returns True when the two ImmutableDicts are equal,
    and False otherwise.
    """
    # Test that two ImmutableDicts with the same keys and values are equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test that two ImmutableDicts with the same keys and different values are not equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 3})
    assert dict1 != dict2

    # Test that two ImmutableDicts with different keys and the same values are not equal
    dict1 = ImmutableDict

# Generated at 2022-06-16 22:17:44.855172
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test case 1:
    # Two ImmutableDicts with the same key-value pairs are equal
    immutable_dict_1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    immutable_dict_2 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert immutable_dict_1 == immutable_dict_2

    # Test case 2:
    # Two ImmutableDicts with different key-value pairs are not equal
    immutable_dict_1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    immutable_dict_2 = ImmutableDict({'key1': 'value1', 'key3': 'value3'})


# Generated at 2022-06-16 22:17:56.480332
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(tuple())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(dict()))
    assert is_iterable(iter(tuple()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable

# Generated at 2022-06-16 22:18:03.860872
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(3))
    assert is_iterable(xrange(3))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(xrange(3)))
    assert is_iterable(iter(range(3)))
    assert is_iterable(iter({'a': 1, 'b': 2}))
    assert is_iterable(iter(set([1, 2, 3])))
    assert is_iterable(iter((1, 2, 3)))

# Generated at 2022-06-16 22:18:14.890824
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(x for x in []))
    assert is_iterable(iter(x for x in ()))
    assert is_iterable(iter(x for x in {}))

# Generated at 2022-06-16 22:18:24.377960
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 2}

# Generated at 2022-06-16 22:18:36.409492
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object)
    assert is_iterable(is_iterable)
    assert is_iterable(test_is_iterable)
    assert is_iterable(xrange(10))
    assert is_iterable(xrange(0))
    assert is_iterable(xrange(1))
    assert is_iterable(xrange(0, 10, 2))
    assert is_iter

# Generated at 2022-06-16 22:18:46.380021
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(u'')
    assert is_iterable(xrange(0))
    assert is_iterable(xrange(1))
    assert is_iterable(xrange(2))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(u''))
    assert is_

# Generated at 2022-06-16 22:18:54.014581
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:19:08.150811
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Create two ImmutableDict objects with the same key-value pairs
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    # Check that the two objects are equal
    assert a == b
    # Create two ImmutableDict objects with different key-value pairs
    c = ImmutableDict({'a': 1, 'b': 2})
    d = ImmutableDict({'a': 1, 'b': 3})
    # Check that the two objects are not equal
    assert c != d
    # Create two ImmutableDict objects with different keys
    e = ImmutableDict({'a': 1, 'b': 2})
    f = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
   

# Generated at 2022-06-16 22:19:20.297951
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(object())


# Generated at 2022-06-16 22:19:33.340307
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(xrange(1, 10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(1, 10)))

# Generated at 2022-06-16 22:19:43.022974
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(1) is False
    assert is_iterable(None) is False
    assert is_iterable(object()) is False
    assert is_iterable(object, include_strings=True) is False
    assert is_iterable(u'abc', include_strings=True)

# Generated at 2022-06-16 22:19:52.134049
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable((x for x in range(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(123) is False
    assert is_iterable(None) is False
    assert is_iterable(object()) is False
    assert is_iterable(object, include_strings=True) is False
    assert is_iterable(u'abc', include_strings=True)
    assert is_iterable(b'abc', include_strings=True)


# Generated at 2022-06-16 22:20:04.352887
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDict instances with the same content
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})

    # Test for equality of two ImmutableDict instances with different content
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})

    # Test for equality of an ImmutableDict instance and a dict instance with the same content
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

    # Test for equality of an ImmutableDict instance and a dict instance with different content

# Generated at 2022-06-16 22:20:16.528090
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:20:28.613006
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({})
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set())
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(xrange(0, 10))
    assert is_iterable(xrange(0, 10, 2))
    assert is_iterable(iter([]))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter((1, 2, 3)))
    assert is_iterable(iter({}))

# Generated at 2022-06-16 22:20:36.003520
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(1))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(1)))
    assert is_iterable(1) is False
    assert is_iterable(1.0) is False
    assert is_iterable(None) is False
    assert is_iterable(True) is False
    assert is_iterable(False) is False
    assert is_iterable(object()) is False
    assert is_iterable(object) is False

# Generated at 2022-06-16 22:20:47.039132
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test case 1:
    #   ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)
    #   Expected result: True
    test_dict_1 = ImmutableDict(a=1, b=2)
    test_dict_2 = ImmutableDict(a=1, b=2)
    assert test_dict_1 == test_dict_2

    # Test case 2:
    #   ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2, c=3)
    #   Expected result: False
    test_dict_1 = ImmutableDict(a=1, b=2)

# Generated at 2022-06-16 22:21:01.557237
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableD

# Generated at 2022-06-16 22:21:12.436278
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1, b=2) == ImmutableDict(b=2, a=1)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1, c=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1, c=3, d=4)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1, c=3, d=4, e=5)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1, c=3, d=4, e=5, f=6)

# Generated at 2022-06-16 22:21:19.487282
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__ works as expected
    """
    # Test that ImmutableDict.__eq__ returns True when the two ImmutableDicts are equal
    # and False when they are not
    test_dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_dict2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_dict3 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    assert test_dict1 == test_dict2
    assert test_dict1 != test_dict3
    assert test_dict2 != test_dict3

    # Test that ImmutableDict.__eq__ returns False when the two objects are not ImmutableDicts
    assert test

# Generated at 2022-06-16 22:21:30.166259
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(5) is False
    assert is_iterable('abc') is False
    assert is_iterable(u'abc') is False
    assert is_iterable(b'abc') is False
    assert is_iterable(u'abc', include_strings=True)
    assert is_iterable(b'abc', include_strings=True)



# Generated at 2022-06-16 22:21:42.127491
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test for inequality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2

    # Test for inequality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 != d2

    # Test for inequality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = Immutable

# Generated at 2022-06-16 22:21:52.422123
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:22:03.784988
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    c = ImmutableDict({'a': 1, 'b': 3})
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    e = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    f = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    g = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    h = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})
    i

# Generated at 2022-06-16 22:22:16.221397
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(u''))
    assert is_iterable(iter(bytearray()))
    assert is_iter

# Generated at 2022-06-16 22:22:27.216337
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test case 1:
    # Two ImmutableDict objects with same key-value pairs
    # should be equal
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test case 2:
    # Two ImmutableDict objects with different key-value pairs
    # should not be equal
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2

    # Test case 3:
    # An ImmutableDict object and a dict object with same key-value pairs
   

# Generated at 2022-06-16 22:22:34.808287
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable('abc')
    assert is_iterable(bytearray(b'abc'))
    assert is_iterable(5) is False
    assert is_iterable(None) is False


# Generated at 2022-06-16 22:22:59.380229
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:23:06.936578
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:23:16.571469
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1, 2, 3})
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(xrange(1, 10))
    assert is_iterable(set(xrange(1, 10)))
    assert is_iterable(dict(a=1, b=2, c=3))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(1) is False
    assert is_iterable(None) is False
    assert is_iterable(True) is False
    assert is_iterable(False) is False
    assert is_iterable(object()) is False
   

# Generated at 2022-06-16 22:23:23.725023
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(5) is False
    assert is_iterable('abc') is False
    assert is_iterable(u'abc') is False
    assert is_iterable(b'abc') is False
    assert is_iterable(bytearray(b'abc')) is False
    assert is_iterable(None) is False
    assert is_iterable(Exception()) is False
    assert is_iterable(Exception) is False
    assert is_iterable(Exception('abc')) is False


# Generated at 2022-06-16 22:23:31.683031
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0, 10))
    assert is_iterable(xrange(0, 10))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0, 10)))
    assert is_iterable(iter(xrange(0, 10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(u'abc'.encode('utf-8'))

# Generated at 2022-06-16 22:23:42.909612
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__ returns True only when the two ImmutableDicts are equal.
    """
    # Test that ImmutableDict.__eq__ returns True when the two ImmutableDicts are equal
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test that ImmutableDict.__eq__ returns False when the two ImmutableDicts are not equal
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test that ImmutableDict.__eq__ returns False when the two ImmutableDicts are not equal

# Generated at 2022-06-16 22:23:54.974363
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:24:06.059702
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test that ImmutableDict is equal to itself
    d = ImmutableDict({'a': 1, 'b': 2})
    assert d == d
    # Test that ImmutableDict is equal to a dict with the same key-value pairs
    assert d == {'a': 1, 'b': 2}
    # Test that ImmutableDict is not equal to a dict with different key-value pairs
    assert d != {'a': 1, 'b': 3}
    # Test that ImmutableDict is not equal to a dict with different keys
    assert d != {'a': 1, 'c': 2}
    # Test that ImmutableDict is not equal to a dict with different values
    assert d != {'a': 2, 'b': 2}
    # Test that ImmutableDict is not equal to a dict with different keys and values

# Generated at 2022-06-16 22:24:12.845919
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(x for x in []))
    assert is_iterable(iter(x for x in ()))
    assert is_iterable(iter(x for x in {}))

# Generated at 2022-06-16 22:24:24.321941
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable(('a', 'b', 'c'))
    assert is_iterable({'a', 'b', 'c'})
    assert is_iterable({'a': 1, 'b': 2, 'c': 3})
    assert is_iterable(xrange(0, 10))
    assert is_iterable(xrange(0, 10, 2))
    assert is_iterable(iter(['a', 'b', 'c']))
    assert is_iterable(iter(('a', 'b', 'c')))
    assert is_iterable(iter({'a', 'b', 'c'}))
    assert is_iterable(iter({'a': 1, 'b': 2, 'c': 3}))

# Generated at 2022-06-16 22:25:06.420086
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(1))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(1)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))
    assert is_iterable(iter(iter(xrange(1))))

    assert not is_iterable(None)


# Generated at 2022-06-16 22:25:19.168950
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__ returns True if the hashes of the two ImmutableDicts are equal
    and False otherwise.
    """
    # Test that ImmutableDict.__eq__ returns True if the hashes of the two ImmutableDicts are equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'b': 2, 'a': 1})
    assert dict1 == dict2

    # Test that ImmutableDict.__eq__ returns False if the hashes of the two ImmutableDicts are not equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'b': 2, 'a': 2})
    assert dict1 != dict2

    # Test that ImmutableDict.__

# Generated at 2022-06-16 22:25:29.080629
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(u''))
    assert is_iterable(iter(bytearray()))
    assert is_iter

# Generated at 2022-06-16 22:25:41.770975
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1: 'a', 2: 'b', 3: 'c'})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(1, 4))
    assert is_iterable(xrange(1, 4))
    assert is_iterable(1)
    assert not is_iterable('abc')
    assert not is_iterable(u'abc')
    assert not is_iterable(b'abc')
    assert not is_iterable(bytearray(b'abc'))
    assert not is_iterable(1.0)
    assert not is_iterable(1j)
    assert not is_iterable(None)

# Generated at 2022-06-16 22:25:53.565839
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(5))
    assert is_iterable(xrange(5))
    assert is_iterable(iter(range(5)))
    assert is_iterable(5) is False
    assert is_iterable(None) is False
    assert is_iterable('abc') is False
    assert is_iterable(u'abc') is False
    assert is_iterable(b'abc') is False
    assert is_iterable(bytearray(b'abc')) is False
    assert is_iterable(bytearray(b'abc'), include_strings=True)

# Generated at 2022-06-16 22:26:05.036997
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of ImmutableDict objects with same content
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test for equality of ImmutableDict objects with different content
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert not (d1 == d2)

    # Test for equality of ImmutableDict objects with different content
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert not (d1 == d2)

# Generated at 2022-06-16 22:26:14.437619
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1, 'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1, 'a': 1})
    assert ImmutableDict({'a': 1}) != {'a': 1}

# Generated at 2022-06-16 22:26:26.988953
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1, 2, 3})
    assert is_iterable({1: 2, 3: 4})
    assert is_iterable(range(1, 3))
    assert is_iterable(x for x in range(1, 3))
    assert is_iterable(1)
    assert not is_iterable(None)
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable(1.0)
    assert not is_iterable(1.0 + 2.0j)
    assert not is_iterable(object())
    assert not is_iterable(object)
    assert not is_iterable(Exception)

# Generated at 2022-06-16 22:26:35.336146
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(None)
    assert not is_iterable(object())



# Generated at 2022-06-16 22:26:45.664966
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test method __eq__ of class ImmutableDict"""
    # Test case 1:
    # Test if two ImmutableDict objects are equal
    # when they have the same key-value pairs
    # and the same order of key-value pairs
    test_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    test_dict_2 = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict_1 == test_dict_2

    # Test case 2:
    # Test if two ImmutableDict objects are equal
    # when they have the same key-value pairs
    # but different order of key-value pairs
    test_dict_1 = ImmutableDict({'a': 1, 'b': 2})