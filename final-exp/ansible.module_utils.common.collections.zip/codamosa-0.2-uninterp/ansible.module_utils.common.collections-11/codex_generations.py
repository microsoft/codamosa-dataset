

# Generated at 2022-06-16 22:17:21.221956
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test for equality of two ImmutableDict objects
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(a=1, b=2)
    assert d1 == d2

    # Test for equality of an ImmutableDict object and a dict object
    d1 = ImmutableDict(a=1, b=2)
    d2 = dict(a=1, b=2)
    assert d1 == d2

    # Test for equality of an ImmutableDict object and a dict object
    # with different order of keys
    d1 = ImmutableDict(a=1, b=2)
    d2 = dict(b=2, a=1)
    assert d1 == d2

# Generated at 2022-06-16 22:17:32.077726
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({}))
    assert is_iterable(ImmutableDict(a=1))

# Generated at 2022-06-16 22:17:44.855386
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2})


# Generated at 2022-06-16 22:17:54.645775
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(x for x in range(10))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(1) is False
    assert is_iterable('abc') is False
    assert is_iterable(b'abc', include_strings=True)
    assert is_iterable(u'abc', include_strings=True)


# Generated at 2022-06-16 22:18:03.352729
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:18:07.995338
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable("")
    assert is_iterable(u"")
    assert is_iterable(b"")
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(object())
    assert is_iterable(None)
    assert is_iterable(True)
    assert is_iterable(False)
    assert is_iterable(Exception())
    assert is_iterable(Exception)
    assert is_iterable(Exception(""))
    assert is_iterable(Exception("", ""))


# Generated at 2022-06-16 22:18:16.091147
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(u'abc'.encode('utf-8'))
    assert is_iterable(1) is False
    assert is_iterable(None) is False



# Generated at 2022-06-16 22:18:24.996640
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({}))
    assert is_iterable(ImmutableDict({'a': 1}))
    assert is_iterable(ImmutableDict(a=1))
    assert is_iterable(ImmutableDict(a=1, b=2))


# Generated at 2022-06-16 22:18:37.232659
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=2, c=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1, c=3)
    assert ImmutableDict(a=1, b=2)

# Generated at 2022-06-16 22:18:47.376098
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test case 1:
    # Two ImmutableDicts with the same content are equal
    immutable_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    immutable_dict_2 = ImmutableDict({'a': 1, 'b': 2})
    assert immutable_dict_1 == immutable_dict_2

    # Test case 2:
    # Two ImmutableDicts with different content are not equal
    immutable_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    immutable_dict_2 = ImmutableDict({'a': 1, 'b': 3})
    assert immutable_dict_1 != immutable_dict_2

    # Test case 3:
    # An ImmutableDict is not equal to a Mut

# Generated at 2022-06-16 22:19:02.460888
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test for method __eq__ of class ImmutableDict
    """
    # Test for equality of two ImmutableDict objects
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test for equality of ImmutableDict and dict objects
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'a': 1, 'b': 2}
    assert d1 == d2

    # Test for equality of ImmutableDict and dict objects
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'a': 1, 'b': 2}
    assert d1 == d2

    #

# Generated at 2022-06-16 22:19:10.105409
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test case 1:
    # Two empty ImmutableDict objects are equal
    assert ImmutableDict() == ImmutableDict()

    # Test case 2:
    # Two ImmutableDict objects with the same key-value pairs are equal
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})

    # Test case 3:
    # Two ImmutableDict objects with the same key-value pairs but in different order are equal
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})

    # Test case 4:
    # Two ImmutableDict objects with different key-value pairs are not equal

# Generated at 2022-06-16 22:19:21.242502
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(None) is False
    assert is_iterable(1) is False
    assert is_iterable(1.0) is False
    assert is_iterable(True) is False
    assert is_iterable(False) is False
    assert is_iterable(b'abc') is False
    assert is_iterable(u'abc') is False
    assert is_iterable(b'abc', include_strings=True) is True
    assert is_iterable(u'abc', include_strings=True) is True
    assert is_iterable([]) is True
    assert is_iterable(()) is True
    assert is_iterable({}) is True
    assert is_iterable(set()) is True
    assert is_iterable(range(0)) is True

# Generated at 2022-06-16 22:19:34.169545
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test __eq__ method of ImmutableDict class
    """
    # Create two ImmutableDict objects
    immutable_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    immutable_dict_2 = ImmutableDict({'a': 1, 'b': 2})

    # Test equality
    assert immutable_dict_1 == immutable_dict_2

    # Test inequality
    immutable_dict_3 = ImmutableDict({'a': 1, 'b': 3})
    assert immutable_dict_1 != immutable_dict_3

    # Test equality with a dict
    assert immutable_dict_1 == {'a': 1, 'b': 2}

    # Test inequality with a dict
    assert immutable_dict_1 != {'a': 1, 'b': 3}

    # Test equality with a list

# Generated at 2022-06-16 22:19:44.014615
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of the ImmutableDict class.
    """
    # Test the case where the two ImmutableDicts are equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test the case where the two ImmutableDicts are not equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 3})
    assert dict1 != dict2

    # Test the case where the two ImmutableDicts are not equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-16 22:19:55.499734
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:20:06.743045
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test case 1:
    # Two ImmutableDict objects are equal if they have the same key-value pairs
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test case 2:
    # Two ImmutableDict objects are not equal if they have different key-value pairs
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 3})
    assert dict1 != dict2

    # Test case 3:
    # Two ImmutableDict objects are not equal if they have different keys
    dict1 = Immutable

# Generated at 2022-06-16 22:20:17.120698
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(5) is False
    assert is_iterable(5.0) is False
    assert is_iterable(None) is False
    assert is_iterable(Exception()) is False


# Generated at 2022-06-16 22:20:29.233406
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test 1: compare two ImmutableDict objects with the same content
    test_dict1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    test_dict2 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert test_dict1 == test_dict2

    # Test 2: compare two ImmutableDict objects with different content
    test_dict1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    test_dict2 = ImmutableDict({'key1': 'value1', 'key2': 'value3'})
    assert test_dict1 != test_dict2

    # Test 3: compare an ImmutableDict object with a dict object with the same content
    test_dict1

# Generated at 2022-06-16 22:20:38.431306
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:20:55.802133
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(3))
    assert is_iterable(xrange(3))
    assert is_iterable(iter(range(3)))
    assert is_iterable(iter(xrange(3)))

    assert not is_iterable(None)
    assert not is_iterable(3)
    assert not is_iterable(3.0)
    assert not is_iterable(object())

    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')

    assert is_iterable('abc', include_strings=True)

# Generated at 2022-06-16 22:21:08.402451
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    c = ImmutableDict({'a': 1, 'b': 3})
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    e = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    f = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    g = ImmutableDict({'a': 1, 'b': 2, 'c': 4, 'd': 5})
    h = ImmutableDict({'a': 1, 'b': 2, 'c': 4, 'd': 5})

# Generated at 2022-06-16 22:21:16.924913
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(u'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(True)
    assert is_iterable(False)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object)
    assert is_iterable(lambda: None)
    assert is_iterable(is_iterable)
    assert is_iterable(test_is_iterable)
    assert is_iterable(Exception)

# Generated at 2022-06-16 22:21:27.903032
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=2, c=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, c=2)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2)
    assert ImmutableDict(a=1, b=2) != ImmutableD

# Generated at 2022-06-16 22:21:39.255817
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(iter(iter(range(10))))

# Generated at 2022-06-16 22:21:47.650371
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) == {'a': 1}
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1, 'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1, 'c': 2})
    assert ImmutableDict

# Generated at 2022-06-16 22:21:59.693752
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object)
    assert is_iterable(is_iterable)
    assert is_iterable(Exception)
    assert is_iterable(Exception())
    assert is_iterable(Exception('foo'))
    assert is_iterable(Exception('foo', 'bar'))


# Generated at 2022-06-16 22:22:08.049369
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test for equality of two ImmutableDict objects
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test for equality of an ImmutableDict object and a dict object
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = {'a': 1, 'b': 2}
    assert dict1 == dict2

    # Test for equality of an ImmutableDict object and a dict object
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-16 22:22:20.649465
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({})
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set())
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iter

# Generated at 2022-06-16 22:22:30.501045
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test __eq__ method of ImmutableDict class"""
    # Test for equality
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) == {'a': 1}
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1}) == ImmutableDict({'b': 2, 'a': 1, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:22:51.190341
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:23:00.951353
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test that two ImmutableDict instances with the same key-value pairs are equal
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test that two ImmutableDict instances with different key-value pairs are not equal
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test that an ImmutableDict instance is not equal to a dict instance with the same key-value pairs
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 2}
    # Test that an ImmutableDict instance is not equal to a dict instance with different key-value pairs

# Generated at 2022-06-16 22:23:13.377328
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of ImmutableDict instances
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:23:23.649759
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert not is_iterable(None)
    assert not is_iterable(10)
    assert not is_iterable(10.5)
    assert not is_iterable(object())


# Generated at 2022-06-16 22:23:28.000265
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(tuple())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(1)
    assert not is_iterable(None)
    assert not is_iterable(object())


# Generated at 2022-06-16 22:23:39.391328
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(3))
    assert is_iterable(xrange(3))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(xrange(3)))
    assert is_iterable(iter(range(3)))
    assert is_iterable(iter({'a': 1, 'b': 2}))
    assert is_iterable(iter(set([1, 2, 3])))
    assert is_iterable(iter((1, 2, 3)))

# Generated at 2022-06-16 22:23:47.961544
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:24:00.930996
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__() returns True if the ImmutableDicts are equal,
    and False otherwise.
    """
    # Test that two ImmutableDicts with the same key-value pairs are equal
    assert ImmutableDict(a=1, b=2) == ImmutableDict(b=2, a=1)

    # Test that two ImmutableDicts with different key-value pairs are not equal
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=3)

    # Test that an ImmutableDict and a dict with the same key-value pairs are not equal
    assert ImmutableDict(a=1, b=2) != dict(a=1, b=2)

    # Test that an ImmutableDict and a dict with different key

# Generated at 2022-06-16 22:24:09.896854
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    assert a == b

    # Test for inequality
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 3})
    assert a != b

    # Test for inequality
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert a != b

    # Test for inequality
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'c': 2})


# Generated at 2022-06-16 22:24:20.894240
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:24:54.989489
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict.
    """
    # Test case 1:
    #   - ImmutableDict objects are equal
    #   - ImmutableDict objects are not equal to a non-ImmutableDict object
    #   - ImmutableDict objects are not equal to a non-ImmutableDict object
    #   - ImmutableDict objects are not equal to a non-ImmutableDict object
    #   - ImmutableDict objects are not equal to a non-ImmutableDict object
    #   - ImmutableDict objects are not equal to a non-ImmutableDict object
    #   - ImmutableDict objects are not equal to a non-ImmutableDict object
    #   - ImmutableDict objects are not equal to a non-ImmutableDict object
    #   - Immutable

# Generated at 2022-06-16 22:25:03.459776
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable(set())
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(dict())
    assert is_iterable(dict(a=1, b=2, c=3))
    assert is_iterable(xrange(10))
    assert is_iterable(xrange(1, 10))
    assert is_iterable(xrange(1, 10, 2))
    assert is_iterable(iter([]))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(set([1, 2, 3])))

# Generated at 2022-06-16 22:25:15.806588
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of ImmutableDict with itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d1

    # Test equality of ImmutableDict with a copy of itself
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test equality of ImmutableDict with a different ImmutableDict
    d3 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d3

    # Test equality of ImmutableDict with a MutableMapping
    d4 = {'a': 1, 'b': 2}
    assert d1 == d4

    # Test equality of ImmutableDict with a Mapping

# Generated at 2022-06-16 22:25:26.990713
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test that ImmutableDict is equal to itself
    d = ImmutableDict({'a': 1, 'b': 2})
    assert d == d

    # Test that ImmutableDict is equal to a dict with the same key-value pairs
    assert d == {'a': 1, 'b': 2}

    # Test that ImmutableDict is not equal to a dict with different key-value pairs
    assert d != {'a': 1, 'b': 3}

    # Test that ImmutableDict is not equal to a dict with different keys
    assert d != {'a': 1, 'c': 2}

    # Test that ImmutableDict is not equal to a dict with different values
    assert d != {'a': 2, 'b': 2}

    # Test that ImmutableDict is not equal to a dict with different keys and values

# Generated at 2022-06-16 22:25:33.141605
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of the ImmutableDict class.

    The __eq__ method should return True if the ImmutableDict is equal to another ImmutableDict,
    and False otherwise.
    """
    # Test that two ImmutableDicts with the same keys and values are equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test that two ImmutableDicts with the same keys and different values are not equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 3})
    assert dict1 != dict2

    # Test that two ImmutableDicts with different keys

# Generated at 2022-06-16 22:25:44.125798
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of ImmutableDict with itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d1

    # Test equality of ImmutableDict with a dict with the same content
    d2 = {'a': 1, 'b': 2}
    assert d1 == d2

    # Test equality of ImmutableDict with a dict with different content
    d3 = {'a': 1, 'b': 3}
    assert d1 != d3

    # Test equality of ImmutableDict with a different ImmutableDict
    d4 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d4

    # Test equality of ImmutableDict with a different object
    assert d1 != 'a'


# Generated at 2022-06-16 22:25:56.288853
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:26:05.950099
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable((x for x in range(10)))
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert is_iterable(None)
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable(object())


# Generated at 2022-06-16 22:26:14.980828
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(5) is False
    assert is_iterable(None) is False
    assert is_iterable('abc') is False
    assert is_iterable(u'abc') is False
    assert is_iterable(b'abc') is False
    assert is_iterable(bytearray(b'abc')) is False
    assert is_iterable(bytearray(u'abc')) is False
    assert is_

# Generated at 2022-06-16 22:26:27.512037
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(1) is False
    assert is_iterable(1.0) is False
    assert is_iterable(None) is False
    assert is_iterable(True) is False
    assert is_iterable(False) is False
    assert is_iterable(object()) is False
    assert is_iterable(object) is False