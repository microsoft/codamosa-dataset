

# Generated at 2022-06-16 22:17:17.801737
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})
    expected = ImmutableDict({'a': 1, 'c': 3, 'e': 5})
    assert original.difference(['b', 'd']) == expected


# Generated at 2022-06-16 22:17:29.551963
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(5) is False
    assert is_iterable('abc') is False
    assert is_iterable(u'abc') is False
    assert is_iterable(b'abc') is False
    assert is_iterable(bytearray(b'abc')) is False
    assert is_iterable(None) is False
    assert is_iterable(Exception) is False
    assert is_iterable(Exception('error')) is False



# Generated at 2022-06-16 22:17:37.056811
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert is_iterable(iter([]))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(u''))
    assert is_iterable(iter(bytearray(b'')))
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(object())


# Generated at 2022-06-16 22:17:48.224786
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(1))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(1)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict(a=1, b=2))
    assert is_iterable(ImmutableDict(a=1, b=2).items())
    assert is_iterable(ImmutableDict(a=1, b=2).keys())
    assert is_iter

# Generated at 2022-06-16 22:17:52.534127
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Test the difference method of ImmutableDict
    """
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    removed = original.difference(['a', 'c'])
    assert removed == ImmutableDict({'b': 2})


# Generated at 2022-06-16 22:17:59.751852
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(1) is False
    assert is_iterable(None) is False



# Generated at 2022-06-16 22:18:11.232270
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1, 'c': 3}

# Generated at 2022-06-16 22:18:22.069455
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test case 1:
    # Test case where the two ImmutableDict objects are equal
    # Expected result: True
    test_case_1_dict_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_case_1_dict_2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert test_case_1_dict_1 == test_case_1_dict_2

    # Test case 2:
    # Test case where the two ImmutableDict objects are not equal
    # Expected result: False
    test_case_2_dict_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
   

# Generated at 2022-06-16 22:18:34.373049
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:18:44.543159
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert original.difference(['a', 'b']) == ImmutableDict({'c': 3})
    assert original.difference(['a', 'b', 'c']) == ImmutableDict()
    assert original.difference(['a', 'b', 'c', 'd']) == ImmutableDict()
    assert original.difference(['d']) == original
    assert original.difference([]) == original
    assert original.difference(['a', 'b', 'c', 'd']) == ImmutableDict()
    assert original.difference(['a', 'b', 'c', 'd', 'e']) == ImmutableDict()

# Generated at 2022-06-16 22:18:58.317851
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test for method __eq__ of class ImmutableDict
    """
    # Test for equality with a dictionary
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = {'a': 1, 'b': 2}
    assert dict1 == dict2

    # Test for equality with a list
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ['a', 'b']
    assert dict1 != dict2

    # Test for equality with a tuple
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ('a', 'b')
    assert dict1 != dict2

    # Test for equality with a set
    dict1 = ImmutableDict({'a': 1, 'b': 2})
   

# Generated at 2022-06-16 22:19:08.333827
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(True)
    assert not is_iterable('abc')
    assert not is_iterable(u'abc')
    assert not is_iterable(b'abc')

#

# Generated at 2022-06-16 22:19:20.410753
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict
    """
    test_dict = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict == ImmutableDict({'a': 1, 'b': 2})
    assert test_dict == {'a': 1, 'b': 2}
    assert test_dict != ImmutableDict({'a': 1, 'b': 3})
    assert test_dict != {'a': 1, 'b': 3}
    assert test_dict != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert test_dict != {'a': 1, 'b': 2, 'c': 3}
    assert test_dict != ImmutableDict({'a': 1, 'c': 2})

# Generated at 2022-06-16 22:19:33.497111
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(xrange(1))
    assert is_iterable(xrange(2))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(xrange(1)))
    assert is_iterable(iter(xrange(2)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
   

# Generated at 2022-06-16 22:19:40.964618
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(u'abc'.encode('utf-8'))
    assert is_iterable(1) is False
    assert is_iterable(None) is False
    assert is_iterable(Exception()) is False


# Generated at 2022-06-16 22:19:45.877404
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test case 1:
    # Test case when both the ImmutableDict objects are equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test case 2:
    # Test case when both the ImmutableDict objects are not equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 3})
    assert dict1 != dict2

    # Test case 3:
    # Test case when both the ImmutableDict objects are not equal

# Generated at 2022-06-16 22:19:58.146703
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDict objects
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1})

# Generated at 2022-06-16 22:20:05.080887
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(1) is False
    assert is_iterable(None) is False



# Generated at 2022-06-16 22:20:10.731434
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1, 2, 3})
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(None)
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable(object())



# Generated at 2022-06-16 22:20:19.752994
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable('abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert is_iterable(5) is False
    assert is_iterable(None) is False



# Generated at 2022-06-16 22:20:36.054916
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test case 1:
    #   - ImmutableDict: {'a': 1, 'b': 2}
    #   - Other: {'a': 1, 'b': 2}
    #   - Expected result: True
    immutable_dict = ImmutableDict({'a': 1, 'b': 2})
    other = {'a': 1, 'b': 2}
    assert immutable_dict.__eq__(other)

    # Test case 2:
    #   - ImmutableDict: {'a': 1, 'b': 2}
    #   - Other: {'a': 1, 'b': 3}
    #   - Expected result: False
    immutable_dict = ImmutableDict({'a': 1, 'b': 2})


# Generated at 2022-06-16 22:20:47.117909
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(tuple())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(1) is False
    assert is_iterable(None) is False
    assert is_iterable(Exception()) is False
    assert is_iterable(Exception) is False
    assert is_iterable(Exception('abc')) is False
    assert is_iterable(Exception('abc'), include_strings=True)
    assert is_iterable(u'abc', include_strings=True)

# Generated at 2022-06-16 22:20:53.977661
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(text_type())
    assert is_iterable(binary_type())
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(object())



# Generated at 2022-06-16 22:21:01.285407
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1: 2, 3: 4})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(1, 3))
    assert is_iterable(xrange(1, 3))
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert is_iterable(True)
    assert is_iterable(False)
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')

# Generated at 2022-06-16 22:21:12.233081
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-16 22:21:20.200859
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(0, 10))
    assert is_iterable(xrange(0, 10))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(set([1, 2, 3])))
    assert is_iterable(iter(xrange(0, 10)))
    assert is_iterable(iter(range(0, 10)))
    assert is_iterable(iter(''))
    assert is_iterable(iter('abc'))
    assert is_

# Generated at 2022-06-16 22:21:31.344524
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-16 22:21:40.824330
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(2)
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert not is_iterable(None)
    assert not is_iterable(open(__file__))


# Generated at 2022-06-16 22:21:48.428772
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(iter(iter(range(10))))

# Generated at 2022-06-16 22:22:00.664355
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of the ImmutableDict class.
    """
    # Test equality of two ImmutableDict objects
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test inequality of two ImmutableDict objects
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test equality of an ImmutableDict and a dict
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test inequality of an ImmutableDict and a dict

# Generated at 2022-06-16 22:22:23.051131
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDicts
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test for equality of an ImmutableDict and a dict
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test for equality of an ImmutableDict and a list
    assert ImmutableDict({'a': 1, 'b': 2}) == [('a', 1), ('b', 2)]
    # Test for equality of an ImmutableDict and a tuple
    assert ImmutableDict({'a': 1, 'b': 2}) == (('a', 1), ('b', 2))
    # Test for equality of an ImmutableDict and a set
    assert Imm

# Generated at 2022-06-16 22:22:32.324922
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter(set()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))

# Generated at 2022-06-16 22:22:43.526017
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:22:52.864322
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test case 1:
    #   ImmutableDict1 = ImmutableDict({'a': 1, 'b': 2})
    #   ImmutableDict2 = ImmutableDict({'a': 1, 'b': 2})
    #   ImmutableDict3 = ImmutableDict({'a': 1, 'b': 3})
    #   ImmutableDict4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    #   ImmutableDict5 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    #   ImmutableDict6 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    #   ImmutableDict7 = Imm

# Generated at 2022-06-16 22:23:00.028205
# Unit test for method __eq__ of class ImmutableDict

# Generated at 2022-06-16 22:23:12.667183
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1, b=2) == ImmutableDict(b=2, a=1)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1, c=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1, c=3, d=4)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1, c=3, d=4, e=5)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1, c=3, d=4, e=5, f=6)

# Generated at 2022-06-16 22:23:25.041143
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)
    assert not is_iterable(0)
    assert not is_iterable(0.0)
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable('abc')
    assert not is_iterable(u'abc')

# Generated at 2022-06-16 22:23:36.022040
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:23:45.886628
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDict objects with the same content
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})

    # Test for inequality of two ImmutableDict objects with different content
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})

    # Test for inequality of an ImmutableDict object and a dict object with the same content
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 2}

    # Test for inequality of an ImmutableDict object and a dict object with different content

# Generated at 2022-06-16 22:23:58.319955
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test __eq__ method of ImmutableDict class
    """
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    d3 = ImmutableDict({'a': 1, 'b': 3})
    d4 = ImmutableDict({'a': 1})
    d5 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d6 = ImmutableDict({'b': 2, 'a': 1})
    d7 = ImmutableDict({'b': 2, 'a': 1, 'c': 3})
    d8 = ImmutableDict({'b': 2, 'a': 1, 'c': 3, 'd': 4})
    d9 = Imm

# Generated at 2022-06-16 22:24:28.559571
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(tuple())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'unicode')
    assert is_iterable(b'bytes')
    assert not is_iterable(10)
    assert not is_iterable(10.5)
    assert not is_iterable(True)
    assert not is_iterable(None)
    assert not is_iterable(object())


# Generated at 2022-06-16 22:24:38.557370
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != {'b': 2, 'a': 1}
    assert ImmutableDict({'a': 1, 'b': 2}) != {'b': 2, 'a': 3}
    assert Imm

# Generated at 2022-06-16 22:24:49.063952
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test if two ImmutableDict objects are equal
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test if two ImmutableDict objects are not equal
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test if an ImmutableDict object is equal to a dict object
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test if an ImmutableDict object is not equal to a dict object
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}
    # Test if an ImmutableDict

# Generated at 2022-06-16 22:25:00.850477
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:25:13.854120
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert is_iterable(True)
    assert is_iterable(False)
    assert is_iterable(object())

    assert is_iterable([], include_strings=True)
    assert is_iterable({}, include_strings=True)
    assert is_iterable(set(), include_strings=True)
    assert is_iterable('', include_strings=True)
    assert is_iterable(u'', include_strings=True)

# Generated at 2022-06-16 22:25:25.309831
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:25:38.886213
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of ImmutableDict with itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d1

    # Test equality of ImmutableDict with a copy of itself
    d2 = ImmutableDict(d1)
    assert d1 == d2

    # Test equality of ImmutableDict with a different ImmutableDict with the same items
    d3 = ImmutableDict({'b': 2, 'a': 1})
    assert d1 == d3

    # Test equality of ImmutableDict with a different ImmutableDict with the same items
    # but different order
    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 != d4

    # Test equality of ImmutableDict with a different Immutable

# Generated at 2022-06-16 22:25:47.544120
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict.
    """
    # Test case 1:
    #   Two ImmutableDicts are equal if they have the same keys and values
    #   regardless of the order of the keys and values.
    #   This test case tests the case where the order of the keys and values
    #   is the same.
    dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert dict1 == dict2

    # Test case 2:
    #   Two ImmutableDicts are equal if they have the same keys and values
    #   regardless of the order of the keys and values.
    #   This test case tests the case where the order of the keys

# Generated at 2022-06-16 22:26:00.400811
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:26:11.018522
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1, b=2) == ImmutableDict(b=2, a=1)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1, c=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=2)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1)
    assert ImmutableDict(a=1, b=2) != ImmutableDict()
    assert ImmutableDict(a=1, b=2) != {'a': 1, 'b': 2}
    assert Imm

# Generated at 2022-06-16 22:27:06.770069
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(5) is False
    assert is_iterable('abc') is False
    assert is_iterable(u'abc') is False
    assert is_iterable(b'abc') is False
    assert is_iterable(bytearray(b'abc')) is False
    assert is_iterable(None) is False
    assert is_iterable(Exception()) is False
    assert is_iterable(Exception) is False


# Generated at 2022-06-16 22:27:16.282601
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(object())
    assert not is_iterable(object)