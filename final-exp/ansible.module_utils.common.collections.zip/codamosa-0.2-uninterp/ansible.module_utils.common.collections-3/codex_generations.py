

# Generated at 2022-06-16 22:17:21.143053
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test case 1:
    #   - ImmutableDict with same keys and values
    #   - Expected result: True
    #   - Reason: The __eq__ method should return True if the hash of the ImmutableDict is the same
    #             as the hash of the other object
    test_dict_1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    test_dict_2 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert test_dict_1 == test_dict_2

    # Test case 2:
    #   - ImmutableDict with different keys and values
    #   - Expected result: False
    #   - Reason: The __

# Generated at 2022-06-16 22:17:27.825165
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(1) is False
    assert is_iterable(None) is False



# Generated at 2022-06-16 22:17:36.352850
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict
    """
    # Test for equality
    assert ImmutableDict({"a": 1, "b": 2}) == ImmutableDict({"a": 1, "b": 2})
    assert ImmutableDict({"a": 1, "b": 2}) == ImmutableDict({"b": 2, "a": 1})
    assert ImmutableDict({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert ImmutableDict({"a": 1, "b": 2}) == {"b": 2, "a": 1}
    assert ImmutableDict({"a": 1, "b": 2}) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-16 22:17:44.161971
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(())
    assert is_iterable(xrange(10))
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert not is_iterable(1)
    assert not is_iterable(None)
    assert not is_iterable(object())


# Generated at 2022-06-16 22:17:52.562632
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert original.difference(['a', 'b']) == ImmutableDict({'c': 3})
    assert original.difference(['a', 'b', 'c']) == ImmutableDict({})
    assert original.difference(['a', 'b', 'c', 'd']) == ImmutableDict({})
    assert original.difference(['d']) == ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert original.difference(['a', 'd']) == ImmutableDict({'b': 2, 'c': 3})
    assert original.difference(['d', 'a']) == ImmutableDict({'b': 2, 'c': 3})
   

# Generated at 2022-06-16 22:18:02.595214
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of ImmutableDict objects with different keys
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'b': 2, 'a': 1})
    assert d1 == d2

    # Test for equality of ImmutableDict objects with different values
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert not d1 == d2

    # Test for equality of ImmutableDict objects with different keys and values
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3, 'c': 4})
    assert not d1 == d2

   

# Generated at 2022-06-16 22:18:14.252830
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable(('a', 'b', 'c'))
    assert is_iterable(set(['a', 'b', 'c']))
    assert is_iterable({'a': 1, 'b': 2, 'c': 3})
    assert is_iterable(xrange(0, 10))
    assert is_iterable(xrange(0, 10))
    assert is_iterable(iter(['a', 'b', 'c']))
    assert is_iterable(iter(('a', 'b', 'c')))
    assert is_iterable(iter(set(['a', 'b', 'c'])))
    assert is_iterable(iter({'a': 1, 'b': 2, 'c': 3}))

# Generated at 2022-06-16 22:18:23.915221
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(text_type())
    assert is_iterable(binary_type())
    assert is_iterable(bytearray())
    assert not is_iterable(None)
    assert not is_iterable(1)


# Generated at 2022-06-16 22:18:29.725859
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Test that ImmutableDict.difference returns a new ImmutableDict with the specified keys removed.
    """
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    expected = ImmutableDict({'a': 1})
    actual = original.difference(['b', 'c'])
    assert expected == actual


# Generated at 2022-06-16 22:18:41.312996
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({})
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set())
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))

# Generated at 2022-06-16 22:18:54.122077
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(True)
    assert is_iterable(False)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object)
    assert is_iterable(is_iterable)
    assert is_iterable(test_is_iterable)
    assert is_iterable(Exception)
    assert is_iterable(Exception())

# Generated at 2022-06-16 22:19:05.828191
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(u''))
    assert is_iterable(iter(u'\u2603'))
    assert is_iterable(iter(u'\u2603'.encode('utf-8')))
    assert is_

# Generated at 2022-06-16 22:19:18.692047
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable('abc')

# Generated at 2022-06-16 22:19:31.866536
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__ returns True when comparing two ImmutableDicts with the same
    key-value pairs, and False when comparing two ImmutableDicts with different key-value pairs.
    """
    # Test that ImmutableDict.__eq__ returns True when comparing two ImmutableDicts with the same
    # key-value pairs
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test that ImmutableDict.__eq__ returns False when comparing two ImmutableDicts with different
    # key-value pairs
    d1 = ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-16 22:19:40.150704
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDict instances
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test for equality of an ImmutableDict instance and a dict instance
    d3 = ImmutableDict({'a': 1, 'b': 2})
    d4 = {'a': 1, 'b': 2}
    assert d3 == d4

    # Test for equality of an ImmutableDict instance and a list instance
    d5 = ImmutableDict({'a': 1, 'b': 2})
    d6 = [('a', 1), ('b', 2)]
    assert d5 == d6

    # Test for equality of an ImmutableDict instance and a tuple instance

# Generated at 2022-06-16 22:19:47.076924
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object)
    assert is_iterable(is_iterable)
    assert is_iterable(test_is_iterable)
    assert is_iterable(Exception)
    assert is_iterable(Exception())
    assert is_iterable(Exception('test'))
    assert is_iterable(Exception('test', 'test2'))


# Generated at 2022-06-16 22:19:56.321092
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert not is_iterable(None)
    assert not is_iterable(10)
    assert not is_iterable(10.2)
    assert not is_iterable(Exception('test'))


# Generated at 2022-06-16 22:20:06.969832
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1}) != {'a': 1}
    assert ImmutableDict({'a': 1}) != 'a'
    assert ImmutableDict({'a': 1}) != 1
    assert ImmutableDict({'a': 1}) != None

# Generated at 2022-06-16 22:20:19.962971
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality with a dictionary
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}
    # Test for equality with another ImmutableDict
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test for equality with a different type of object
    assert ImmutableDict({'a': 1, 'b': 2}) != 'a'

# Generated at 2022-06-16 22:20:31.940603
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:20:53.226923
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object)
    assert is_iterable(u'unicode')
    assert is_iterable(b'bytes')

# Generated at 2022-06-16 22:21:03.695165
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))

    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(True)
    assert not is_iterable(False)

# Generated at 2022-06-16 22:21:13.741880
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict
    """
    # Test equality of two ImmutableDicts
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test equality of an ImmutableDict and a dict
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test equality of an ImmutableDict and a list
    assert ImmutableDict({'a': 1, 'b': 2}) == ['a', 'b']
    # Test equality of an ImmutableDict and a tuple
    assert ImmutableDict({'a': 1, 'b': 2}) == ('a', 'b')
    # Test equality of an ImmutableDict and a set

# Generated at 2022-06-16 22:21:23.283186
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDicts
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test for inequality of two ImmutableDicts
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2

    # Test for equality of an ImmutableDict and a dict
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'a': 1, 'b': 2}
    assert d1 == d2

    # Test for inequality of an ImmutableDict and a dict
    d1 = Imm

# Generated at 2022-06-16 22:21:32.271663
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(2)
    assert is_iterable('string')
    assert is_iterable(u'unicode')
    assert is_iterable(b'bytes')
    assert is_iterable(object())
    assert is_iterable(object)
    assert is_iterable(Exception)
    assert is_iterable(Exception())
    assert is_iterable(Exception('message'))
    assert is_iterable(Exception('message', 'message2'))
    assert is_iterable(Exception('message', 'message2', 'message3'))
    assert is_iterable(Exception('message', 'message2', 'message3', 'message4'))

# Generated at 2022-06-16 22:21:43.858322
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of the ImmutableDict class.
    """
    # Test that two ImmutableDicts with the same key-value pairs are equal
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})

    # Test that two ImmutableDicts with the same key-value pairs but different order are equal
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})

    # Test that two ImmutableDicts with different key-value pairs are not equal
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})

    # Test that an ImmutableDict is not equal to a dict

# Generated at 2022-06-16 22:21:55.721567
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(3))
    assert is_iterable(xrange(3))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(xrange(3)))
    assert is_iterable(iter(range(3)))
    assert is_iterable(iter(set([1, 2, 3])))
    assert is_iterable(iter({'a': 1, 'b': 2}))
    assert is_iterable(iter((1, 2, 3)))

# Generated at 2022-06-16 22:22:05.807240
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(u''))
    assert is_iterable(iter(bytearray()))
    assert is_iter

# Generated at 2022-06-16 22:22:18.407690
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict.

    The __eq__ method of ImmutableDict should return True when the hash of the ImmutableDict
    is equal to the hash of the object being compared to.
    """
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_dict2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_dict3 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    test_dict4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})

# Generated at 2022-06-16 22:22:28.939694
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDict objects
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test for inequality of two ImmutableDict objects
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test for equality of an ImmutableDict object and a dict object
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test for inequality of an ImmutableDict object and a dict object
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}
    # Test for equality of an ImmutableDict

# Generated at 2022-06-16 22:22:55.564126
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert is_iterable(0)
    assert is_iterable(0.0)
    assert is_iter

# Generated at 2022-06-16 22:23:05.194916
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test 1: Test equality of two ImmutableDict objects
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test 2: Test equality of two ImmutableDict objects with different keys
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'c': 2})
    assert d1 != d2

    # Test 3: Test equality of two ImmutableDict objects with different values
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2

    # Test 4

# Generated at 2022-06-16 22:23:15.646200
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(u'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(True)
    assert is_iterable(False)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object)
    assert is_iterable(is_iterable)
    assert is_iterable(test_is_iterable)
    assert is_iterable(xrange(1))
    assert is_iterable(xrange(1, 2))

# Generated at 2022-06-16 22:23:26.746261
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # test for equality
    assert ImmutableDict(a=1, b=2) == ImmutableDict(b=2, a=1)
    assert ImmutableDict(a=1, b=2) == ImmutableDict(b=2, a=1, c=3)
    assert ImmutableDict(a=1, b=2) == ImmutableDict(b=2, a=1, c=3, d=4)
    assert ImmutableDict(a=1, b=2) == ImmutableDict(b=2, a=1, c=3, d=4, e=5)
    assert ImmutableDict(a=1, b=2) == ImmutableDict(b=2, a=1, c=3, d=4, e=5, f=6)
    assert Imm

# Generated at 2022-06-16 22:23:38.496665
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:23:47.466566
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(text_type())
    assert is_iterable(binary_type())
    assert is_iterable(bytearray())
    assert is_iterable(memoryview(binary_type()))
    assert not is_iterable(None)
    assert not is_iterable(10)
    assert not is_iterable(10.0)
    assert not is_iterable(object())
    assert not is_iterable(object)
    assert not is_iterable(type)

# Generated at 2022-06-16 22:23:59.987427
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:24:09.642425
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test for equality of two ImmutableDicts
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test for equality of an ImmutableDict and a dict
    dict3 = {'a': 1, 'b': 2}
    assert dict1 == dict3

    # Test for equality of an ImmutableDict and a list
    list1 = [('a', 1), ('b', 2)]
    assert dict1 == list1

    # Test for equality of an ImmutableDict and a tuple
    tuple1 = (('a', 1), ('b', 2))
    assert dict1 == tuple1

    # Test for equality

# Generated at 2022-06-16 22:24:17.987195
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(0, 3))
    assert is_iterable(xrange(0, 3))
    assert is_iterable(1)
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert not is_iterable(None)
    assert not is_iterable(object())


# Generated at 2022-06-16 22:24:29.149231
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of two ImmutableDicts
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    assert a == b

    # Test equality of an ImmutableDict and a dict
    a = ImmutableDict({'a': 1, 'b': 2})
    b = {'a': 1, 'b': 2}
    assert a == b

    # Test equality of an ImmutableDict and a list
    a = ImmutableDict({'a': 1, 'b': 2})
    b = [('a', 1), ('b', 2)]
    assert a == b

    # Test equality of an ImmutableDict and a tuple
    a = ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-16 22:25:18.400665
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:25:28.519035
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(set([1, 2, 3])))
    assert is_iterable(iter({'a': 1, 'b': 2}))
    assert is_iterable(iter((1, 2, 3)))

# Generated at 2022-06-16 22:25:41.306489
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test case 1:
    #   Two ImmutableDicts are equal
    #   Expected result:
    #       True
    test_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    test_dict_2 = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict_1 == test_dict_2

    # Test case 2:
    #   Two ImmutableDicts are not equal
    #   Expected result:
    #       False
    test_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    test_dict_2 = ImmutableDict({'a': 1, 'b': 3})
    assert test_dict_1 != test_dict

# Generated at 2022-06-16 22:25:52.808662
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict
    """
    # Test that two ImmutableDicts are equal if they have the same keys and values
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    assert a == b

    # Test that two ImmutableDicts are not equal if they have the same keys but different values
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 3})
    assert a != b

    # Test that two ImmutableDicts are not equal if they have different keys
    a = ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-16 22:26:04.325729
# Unit test for method __eq__ of class ImmutableDict

# Generated at 2022-06-16 22:26:13.936537
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)

# Generated at 2022-06-16 22:26:23.212130
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(u'abc'.encode('utf-8'))
    assert is_iterable(1) is False
    assert is_iterable(None) is False



# Generated at 2022-06-16 22:26:33.826802
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__ works as expected
    """
    # Test that ImmutableDict.__eq__ returns True when comparing two ImmutableDict instances
    # with the same key-value pairs
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test that ImmutableDict.__eq__ returns False when comparing two ImmutableDict instances
    # with the same keys but different values
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert not d1 == d2

    # Test that ImmutableDict.__eq__ returns False when

# Generated at 2022-06-16 22:26:43.288958
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict class.

    The __eq__ method of ImmutableDict class returns True if the hash of the object is equal to the hash of the other
    object.
    """
    # Test case 1:
    # Test if the __eq__ method returns True when the hash of the object is equal to the hash of the other object.
    # The hash of the object is equal to the hash of the other object.
    # The __eq__ method should return True.
    immutable_dict_1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    immutable_dict_2 = ImmutableDict({'key2': 'value2', 'key1': 'value1'})
    assert immutable_dict_1 == immutable_dict_2

    # Test case 2:

# Generated at 2022-06-16 22:26:53.841448
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of the ImmutableDict class.
    """
    # Test equality of two ImmutableDict objects
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'b': 2, 'a': 1})
    assert d1 == d2

    # Test equality of an ImmutableDict object and a dict object
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'b': 2, 'a': 1}
    assert d1 == d2

    # Test equality of an ImmutableDict object and a dict object with different keys
    d1 = ImmutableDict({'a': 1, 'b': 2})