

# Generated at 2022-06-16 22:17:20.859788
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1, 2, 3})
    assert is_iterable({1: 2, 3: 4})
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert is_iterable(range(1, 3))
    assert is_iterable(xrange(1, 3))
    assert is_iterable(set())
    assert is_iterable(frozenset())
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter((1, 2, 3)))
    assert is_

# Generated at 2022-06-16 22:17:28.987151
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(text_type())
    assert is_iterable(binary_type())
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(1) is False
    assert is_iterable(None) is False
    assert is_iterable(object()) is False



# Generated at 2022-06-16 22:17:36.768809
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object)
    assert is_iterable(Exception())
    assert is_iterable(Exception)
    assert is_iterable(is_iterable)
    assert is_iterable(is_iterable())
    assert is_iterable(test_is_iterable)
    assert is_iterable(test_is_iterable())

# Generated at 2022-06-16 22:17:45.452652
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(u'abc'.encode('utf-8'))
    assert is_iterable(5) is False
    assert is_iterable(5.0) is False
    assert is_iterable(None) is False



# Generated at 2022-06-16 22:17:57.461997
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({}))
    assert is_iterable(ImmutableDict({'a': 1}))

# Generated at 2022-06-16 22:18:04.206172
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test 1:
    # Test that ImmutableDict instances with the same content are equal
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test 2:
    # Test that ImmutableDict instances with different content are not equal
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2

    # Test 3:
    # Test that ImmutableDict instances with different content are not equal
    d1 = ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-16 22:18:14.985909
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of ImmutableDict with itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d1
    # Test equality of ImmutableDict with another ImmutableDict with the same key-value pairs
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2
    # Test equality of ImmutableDict with a dict with the same key-value pairs
    d3 = {'a': 1, 'b': 2}
    assert d1 == d3
    # Test equality of ImmutableDict with another ImmutableDict with the same key-value pairs
    # but in a different order
    d4 = ImmutableDict({'b': 2, 'a': 1})
    assert d1 == d4
    # Test equality of

# Generated at 2022-06-16 22:18:24.412232
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test equality of two ImmutableDict objects
    immutable_dict1 = ImmutableDict({'a': 1, 'b': 2})
    immutable_dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert immutable_dict1 == immutable_dict2

    # Test equality of an ImmutableDict object and a dict object
    immutable_dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict1 = {'a': 1, 'b': 2}
    assert immutable_dict1 == dict1

    # Test equality of an ImmutableDict object and a dict object with different order of keys
    immutable_dict1 = ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-16 22:18:36.463978
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(u''))
    assert is_iterable(iter(bytearray()))

    assert not is_

# Generated at 2022-06-16 22:18:45.983545
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1, 2, 3})
    assert is_iterable({1: 2, 3: 4})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(frozenset([1, 2, 3]))
    assert is_iterable(range(1, 3))
    assert is_iterable(xrange(1, 3))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(xrange(1, 3)))
    assert is_iterable(iter(range(1, 3)))
    assert is_iterable(iter(set([1, 2, 3])))
    assert is_iterable

# Generated at 2022-06-16 22:19:01.760172
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # test equal
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    assert a == b

    # test not equal
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 3})
    assert a != b

    # test not equal
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert a != b

    # test not equal
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'c': 2})
   

# Generated at 2022-06-16 22:19:09.798004
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__() works as expected
    """
    # Test that ImmutableDict.__eq__() returns True when comparing two ImmutableDicts with the same content
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test that ImmutableDict.__eq__() returns False when comparing two ImmutableDicts with different content
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test that ImmutableDict.__eq__() returns False when comparing an ImmutableDict with a dict with the same content

# Generated at 2022-06-16 22:19:14.189435
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:19:22.999365
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(text_type())
    assert is_iterable(binary_type())
    assert is_iterable(text_type(''))
    assert is_iterable(binary_type(''))

# Generated at 2022-06-16 22:19:32.256199
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(bytearray(b'abc'))
    assert is_iterable(5) is False
    assert is_iterable(None) is False



# Generated at 2022-06-16 22:19:41.465341
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that __eq__ method of ImmutableDict class works as expected.
    """
    # Test that two ImmutableDict instances with the same content are equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test that two ImmutableDict instances with different content are not equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 3})
    assert dict1 != dict2

    # Test that an ImmutableDict instance is not equal to a dict instance with the same content
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2

# Generated at 2022-06-16 22:19:52.078021
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object)
    assert is_iterable(test_is_iterable)
    assert is_iterable(is_iterable)
    assert is_iterable(is_iterable, include_strings=True)
    assert is_iterable(object, include_strings=True)

# Generated at 2022-06-16 22:20:04.352971
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of ImmutableDict with itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d1

    # Test for equality of ImmutableDict with a copy of itself
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test for equality of ImmutableDict with a different ImmutableDict
    d3 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d3

    # Test for equality of ImmutableDict with a different ImmutableDict
    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 != d4

    # Test for equality of ImmutableDict with a different ImmutableDict

# Generated at 2022-06-16 22:20:14.790502
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__() returns True when comparing two ImmutableDicts
    with the same key-value pairs and False when comparing two ImmutableDicts with
    different key-value pairs.
    """
    # Test that two ImmutableDicts with the same key-value pairs are equal
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})

    # Test that two ImmutableDicts with different key-value pairs are not equal
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})


# Generated at 2022-06-16 22:20:21.258052
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(u'')
    assert is_iterable(xrange(0))
    assert is_iterable(xrange(1))
    assert is_iterable(xrange(2))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(u''))
    assert is_

# Generated at 2022-06-16 22:20:36.460615
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert not is_iterable(1)
    assert not is_iterable(None)
    assert not is_iterable(set())
    assert is_iterable(set(), include_strings=True)
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable('abc', include_strings=True)
    assert is_iterable(u'abc', include_strings=True)
    assert is_iterable(b'abc', include_strings=True)


# Generated at 2022-06-16 22:20:47.919004
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    dict3 = ImmutableDict({'a': 1, 'b': 3})
    dict4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict5 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict6 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    dict7 = ImmutableDict({'a': 1, 'b': 2, 'd': 3})
    dict8 = ImmutableDict({'a': 1, 'b': 2, 'd': 4})

# Generated at 2022-06-16 22:20:58.068333
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)

# Generated at 2022-06-16 22:21:09.961822
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-16 22:21:18.502672
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 2, 'c': 3, 'a': 1})

# Generated at 2022-06-16 22:21:30.009102
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(3))
    assert is_iterable(xrange(3))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(xrange(3)))
    assert is_iterable(iter(range(3)))
    assert is_iterable(iter({'a': 1, 'b': 2}))
    assert is_iterable(iter(set([1, 2, 3])))
    assert is_iterable(iter((1, 2, 3)))

# Generated at 2022-06-16 22:21:41.940246
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable(())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(set()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))

    assert not is_iterable(None)

# Generated at 2022-06-16 22:21:51.742009
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test case 1:
    #   - ImmutableDict with same key-value pairs
    #   - Expected result: True
    immutable_dict_1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    immutable_dict_2 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert immutable_dict_1 == immutable_dict_2

    # Test case 2:
    #   - ImmutableDict with different key-value pairs
    #   - Expected result: False
    immutable_dict_1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})

# Generated at 2022-06-16 22:22:03.373424
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')

# Generated at 2022-06-16 22:22:15.845936
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of ImmutableDict with itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test equality of ImmutableDict with a dict
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'a': 1, 'b': 2}
    assert d1 == d2

    # Test equality of ImmutableDict with a dict with different order
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'b': 2, 'a': 1}
    assert d1 == d2

    # Test equality of ImmutableDict with a dict with different value
    d1 = Immutable

# Generated at 2022-06-16 22:22:41.064683
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)

# Generated at 2022-06-16 22:22:50.808243
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:22:58.645546
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({}))
    assert is_iterable(ImmutableDict(a=1))
    assert is_iterable(ImmutableDict(a=1, b=2))

# Generated at 2022-06-16 22:23:10.947702
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict
    """
    # Test that two ImmutableDicts are equal if they have the same key-value pairs
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test that two ImmutableDicts are not equal if they have different key-value pairs
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2

    # Test that two ImmutableDicts are not equal if they have different keys
    d1 = ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-16 22:23:16.980776
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(True)
    assert is_iterable(None)
    assert not is_iterable(object())


# Generated at 2022-06-16 22:23:27.454662
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:23:39.114538
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(x for x in [])
    assert is_iterable(x for x in ())
    assert is_iterable(x for x in {})
    assert is_iterable(x for x in set())
    assert is_

# Generated at 2022-06-16 22:23:47.807043
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:24:00.240215
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(tuple())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter([]))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(dict()))
    assert is_iterable(iter(tuple()))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(set())))
    assert is_iterable(iter(iter(dict())))

# Generated at 2022-06-16 22:24:06.495436
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:24:44.821478
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:24:55.639612
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__() works as expected.
    """
    # Test that two ImmutableDicts with the same key-value pairs are equal
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)

    # Test that two ImmutableDicts with different key-value pairs are not equal
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=3)

    # Test that an ImmutableDict is not equal to a MutableMapping with the same key-value pairs
    assert ImmutableDict(a=1, b=2) != MutableMapping(a=1, b=2)

    # Test that an ImmutableDict is not equal to a MutableMapping with different key-

# Generated at 2022-06-16 22:25:03.955832
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of two ImmutableDicts
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test inequality of two ImmutableDicts
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test equality of an ImmutableDict and a dict
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test inequality of an ImmutableDict and a dict
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}
    # Test equality of an ImmutableDict and a list

# Generated at 2022-06-16 22:25:16.177285
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of ImmutableDict with itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d1

    # Test equality of ImmutableDict with a copy of itself
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test equality of ImmutableDict with a different ImmutableDict
    d3 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d3

    # Test equality of ImmutableDict with a MutableDict
    d4 = {'a': 1, 'b': 2}
    assert d1 == d4

    # Test equality of ImmutableDict with a MutableDict
    d5 = {'a': 1, 'b': 3}

# Generated at 2022-06-16 22:25:27.311213
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable((1, 2, 3))
    assert is_iterable({})
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set())
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(10)))
    assert is_iter

# Generated at 2022-06-16 22:25:40.233878
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-16 22:25:50.889050
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of ImmutableDict with itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d1
    # Test equality of ImmutableDict with a copy of itself
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2
    # Test equality of ImmutableDict with a different ImmutableDict
    d3 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d3
    # Test equality of ImmutableDict with a different ImmutableDict
    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 != d4
    # Test equality of ImmutableDict with a different ImmutableDict

# Generated at 2022-06-16 22:25:59.587605
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != {'a': 1}
    assert ImmutableDict({'a': 1}) != 1


# Generated at 2022-06-16 22:26:10.210283
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(u'')
    assert is_iterable(xrange(0))
    assert is_iterable(xrange(1))
    assert is_iterable(xrange(2))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(u''))
    assert is_

# Generated at 2022-06-16 22:26:21.097345
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test the __eq__ method of the ImmutableDict class"""
    # Test equality of two ImmutableDict objects
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2
    assert d1.__eq__(d2)
    # Test equality of an ImmutableDict object and a dict object
    d3 = {'a': 1, 'b': 2}
    assert d1 == d3
    assert d1.__eq__(d3)
    # Test equality of an ImmutableDict object and a non-dict object
    d4 = 'a'
    assert d1 != d4
    assert d1.__eq__(d4) is False
    # Test equality of two Imm