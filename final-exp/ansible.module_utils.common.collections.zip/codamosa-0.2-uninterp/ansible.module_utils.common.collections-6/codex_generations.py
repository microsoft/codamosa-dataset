

# Generated at 2022-06-16 22:17:25.184201
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({'a': 1}))
    assert is_iterable(ImmutableDict({'a': 1}).keys())
    assert is_iterable(ImmutableDict({'a': 1}).values())

# Generated at 2022-06-16 22:17:32.970323
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != {'a': 1}
    assert ImmutableDict({'a': 1}) != 'a'


# Generated at 2022-06-16 22:17:45.501494
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=2, c=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, c=2)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1)
    assert ImmutableDict(a=1, b=2) != ImmutableD

# Generated at 2022-06-16 22:17:57.519438
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test for method __eq__ of class ImmutableDict"""
    # Test for equality of two ImmutableDict objects
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test for equality of an ImmutableDict object and a dict object
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = {'a': 1, 'b': 2}
    assert dict1 == dict2

    # Test for equality of an ImmutableDict object and a dict object
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = {'a': 1, 'b': 2, 'c': 3}
    assert dict

# Generated at 2022-06-16 22:18:09.951297
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:18:15.691907
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:18:24.911753
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of ImmutableDict with itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d1

    # Test equality of ImmutableDict with another ImmutableDict with the same content
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test equality of ImmutableDict with another ImmutableDict with different content
    d3 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d3

    # Test equality of ImmutableDict with a dict with the same content
    d4 = {'a': 1, 'b': 2}
    assert d1 == d4

    # Test equality of ImmutableDict with a dict with different content

# Generated at 2022-06-16 22:18:37.099018
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(3))
    assert is_iterable(xrange(3))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(xrange(3)))
    assert is_iterable(iter(range(3)))
    assert is_iterable(iter(set([1, 2, 3])))
    assert is_iterable(iter({'a': 1, 'b': 2}))
    assert is_iterable(iter((1, 2, 3)))


# Generated at 2022-06-16 22:18:47.245471
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of ImmutableDict with itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d1

    # Test equality of ImmutableDict with another ImmutableDict with the same content
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test equality of ImmutableDict with a MutableMapping with the same content
    d3 = {'a': 1, 'b': 2}
    assert d1 == d3

    # Test equality of ImmutableDict with a MutableMapping with the same content
    d4 = {'a': 1, 'b': 2}
    assert d1 == d4

    # Test equality of ImmutableDict with a MutableMapping with the same content
    d5

# Generated at 2022-06-16 22:18:54.367002
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of ImmutableDict with itself
    d = ImmutableDict({'a': 1, 'b': 2})
    assert d == d
    # Test for equality of ImmutableDict with a dict with the same content
    assert d == {'a': 1, 'b': 2}
    # Test for equality of ImmutableDict with a dict with different content
    assert not d == {'a': 1, 'b': 3}
    # Test for equality of ImmutableDict with a dict with different content
    assert not d == {'a': 1, 'b': 2, 'c': 3}
    # Test for equality of ImmutableDict with a dict with different content
    assert not d == {'a': 1}
    # Test for equality of ImmutableDict with a dict with different content

# Generated at 2022-06-16 22:19:08.481336
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test case 1
    # Test case with two ImmutableDict objects with same key-value pairs
    # Expected result: True
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})

    # Test case 2
    # Test case with two ImmutableDict objects with different key-value pairs
    # Expected result: False
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 3})

    # Test case 3
    # Test case with two ImmutableDict objects with different keys
    # Expected result: False
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'c': 1})

    # Test case

# Generated at 2022-06-16 22:19:20.486454
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test __eq__ method of ImmutableDict class

    :return: True if test is passed, False otherwise
    """
    test_dict = ImmutableDict({'a': 1, 'b': 2})
    test_dict_eq = ImmutableDict({'a': 1, 'b': 2})
    test_dict_neq = ImmutableDict({'a': 1, 'b': 3})
    test_dict_neq_2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_dict_neq_3 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_dict_neq_4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_dict_ne

# Generated at 2022-06-16 22:19:33.550943
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:19:43.294755
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality with a dictionary
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}

    # Test for equality with another ImmutableDict
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})

    # Test for equality with a non-dictionary
    assert ImmutableDict({'a': 1, 'b': 2}) != 'a'

# Generated at 2022-06-16 22:19:54.509743
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=2, c=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, c=2)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2)
    assert ImmutableDict(a=1, b=2) != ImmutableD

# Generated at 2022-06-16 22:20:04.215560
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)
    assert not is_iterable(42)
    assert not is_iterable(object())


# Generated at 2022-06-16 22:20:16.420078
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test case 1:
    #   - Two ImmutableDicts with the same key-value pairs
    #   - Expected result: True
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test case 2:
    #   - Two ImmutableDicts with different key-value pairs
    #   - Expected result: False
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 3})
    assert dict1 != dict2

    # Test case 3:
    #   - Two ImmutableDicts with the same key-value pairs, but in different order
    #   - Expected result

# Generated at 2022-06-16 22:20:28.484516
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict.
    """
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    d3 = ImmutableDict({'a': 1, 'b': 3})
    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d5 = ImmutableDict({'b': 2, 'a': 1})
    d6 = ImmutableDict({'b': 2, 'a': 1, 'c': 3})
    d7 = ImmutableDict({'b': 2, 'a': 1, 'c': 3})
    d8 = ImmutableDict({'b': 2, 'a': 1, 'c': 4})

# Generated at 2022-06-16 22:20:35.784568
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=2, c=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=1, a=2)
    assert ImmutableDict(a=1, b=2) != ImmutableD

# Generated at 2022-06-16 22:20:41.912420
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(1j)
    assert is_iterable(None)
    assert not is_iterable(object())



# Generated at 2022-06-16 22:20:59.105937
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:21:10.755237
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:21:18.292849
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2
    d3 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 != d3
    assert d1 != {'a': 1, 'b': 2}
    assert d1 != {'a': 1, 'b': 2, 'c': 3}
    assert d1 != {'a': 1, 'b': 3}
    assert d1 != {'a': 1}
    assert d1 != {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert d1 != {'b': 2, 'a': 1}

# Generated at 2022-06-16 22:21:29.883766
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({}))
    assert is_iterable(ImmutableDict([]))
    assert is_iterable(ImmutableDict(()))
   

# Generated at 2022-06-16 22:21:41.798846
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(u'')
    assert is_iterable(xrange(0))
    assert is_iterable(xrange(1))
    assert is_iterable(xrange(2))
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable(object())
    assert not is_iterable(object)
    assert not is_iterable(type)
   

# Generated at 2022-06-16 22:21:51.452077
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test case 1:
    # Two ImmutableDict instances with the same content are equal
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test case 2:
    # Two ImmutableDict instances with different content are not equal
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2

    # Test case 3:
    # Two ImmutableDict instances with different content are not equal
    d1 = ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-16 22:21:57.401121
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable((x for x in range(3)))
    assert is_iterable('abc')
    assert is_iterable(b'abc')
    assert not is_iterable(1)
    assert not is_iterable(None)



# Generated at 2022-06-16 22:22:06.845034
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(a=1, b=2)
    d3 = ImmutableDict(a=1, b=3)
    d4 = ImmutableDict(a=1, b=2, c=3)
    d5 = ImmutableDict(a=1, b=2, c=3)
    d6 = ImmutableDict(a=1, b=2, c=3, d=4)
    d7 = ImmutableDict(a=1, b=2, c=3, d=4)
    d8 = ImmutableDict(a=1, b=2, c=3, d=4, e=5)


# Generated at 2022-06-16 22:22:19.414112
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=2, c=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, c=3)
    assert ImmutableDict(a=1, b=2) != ImmutableD

# Generated at 2022-06-16 22:22:29.668988
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of the ImmutableDict class.
    """
    # Test equality of two ImmutableDict objects
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test equality of an ImmutableDict object and a dict object
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = {'a': 1, 'b': 2}
    assert dict1 == dict2

    # Test equality of an ImmutableDict object and a dict object with different order
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = {'b': 2, 'a': 1}

# Generated at 2022-06-16 22:22:54.495560
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    d3 = ImmutableDict({'a': 1, 'b': 3})
    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d5 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    d6 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    d7 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})

# Generated at 2022-06-16 22:23:03.904370
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test case 1:
    #   Two ImmutableDict objects are equal
    #   Expected result:
    #       True
    test_dict_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_dict_2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert test_dict_1 == test_dict_2

    # Test case 2:
    #   Two ImmutableDict objects are not equal
    #   Expected result:
    #       False
    test_dict_3 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-16 22:23:14.803556
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test case 1:
    #   - Two ImmutableDict objects with the same key-value pairs
    #   - Expected result: True
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test case 2:
    #   - Two ImmutableDict objects with the same key-value pairs but in different order
    #   - Expected result: True
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'b': 2, 'a': 1})
    assert d1 == d2

    # Test case 3:
    #  

# Generated at 2022-06-16 22:23:26.485790
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(u'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert not is_iterable(object())
    assert not is_iterable(object)
    assert not is_iterable(object())
    assert not is_iterable(object)
    assert not is_iterable(object)
    assert not is_iterable(object)
    assert not is_iterable(object)
    assert not is_iterable(object)
    assert not is_iterable(object)

# Generated at 2022-06-16 22:23:38.146496
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality with a dict
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'a': 1, 'b': 2}
    assert d1 == d2

    # Test equality with another ImmutableDict
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test inequality with a dict
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'a': 1, 'b': 3}
    assert d1 != d2

    # Test inequality with another ImmutableDict
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = Imm

# Generated at 2022-06-16 22:23:47.226613
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict

# Generated at 2022-06-16 22:23:59.718626
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of class ImmutableDict.
    """
    # Test case 1:
    # Test the equality of two ImmutableDict objects with the same keys and values
    # Expected result: True
    test_dict1 = ImmutableDict({'a': 1, 'b': 2})
    test_dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict1 == test_dict2

    # Test case 2:
    # Test the equality of two ImmutableDict objects with the same keys but different values
    # Expected result: False
    test_dict1 = ImmutableDict({'a': 1, 'b': 2})
    test_dict2 = ImmutableDict({'a': 1, 'b': 3})
    assert test_dict1 != test_

# Generated at 2022-06-16 22:24:09.507205
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality with another ImmutableDict
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test for equality with a regular dict
    d3 = {'a': 1, 'b': 2}
    assert d1 == d3

    # Test for equality with a regular dict with different order of keys
    d4 = {'b': 2, 'a': 1}
    assert d1 == d4

    # Test for equality with a regular dict with different order of keys
    d5 = {'b': 2, 'a': 1, 'c': 3}
    assert d1 != d5

    # Test for equality with a regular dict with different order of keys

# Generated at 2022-06-16 22:24:16.250957
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(1) is False
    assert is_iterable(None) is False


# Generated at 2022-06-16 22:24:27.413632
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 2, 'a': 1, 'c': 3})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 2, 'c': 3, 'a': 1})
   

# Generated at 2022-06-16 22:25:13.855549
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert is_iterable(bytearray(b''))
    assert is_iterable(0)
   

# Generated at 2022-06-16 22:25:23.673372
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable(())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(u'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object, include_strings=True)
    assert not is_iterable(object)
    assert not is_iterable(object, include_strings=False)


# Generated at 2022-06-16 22:25:30.046250
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable((x for x in range(10)))
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(ImmutableDict())
    assert is_iterable('abc')
    assert is_iterable(b'abc')
    assert is_iterable(u'abc')
    assert not is_iterable(1)
    assert not is_iterable(None)
    assert not is_iterable(True)
    assert not is_iterable(object())
    assert not is_iterable(object)


# Generated at 2022-06-16 22:25:42.588513
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert is_iterable(())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(u''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)
    assert not is_iterable(0)
    assert not is_iter

# Generated at 2022-06-16 22:25:54.820083
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of ImmutableDict with itself
    d1 = ImmutableDict(a=1, b=2)
    assert d1 == d1

    # Test equality of ImmutableDict with a copy of itself
    d2 = ImmutableDict(a=1, b=2)
    assert d1 == d2

    # Test equality of ImmutableDict with a different ImmutableDict
    d3 = ImmutableDict(a=1, b=3)
    assert d1 != d3

    # Test equality of ImmutableDict with a dict
    d4 = dict(a=1, b=2)
    assert d1 == d4

    # Test equality of ImmutableDict with a different dict
    d5 = dict(a=1, b=3)
    assert d1 != d5

    # Test equality

# Generated at 2022-06-16 22:26:06.340782
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:26:13.498258
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert is_iterable(1) is False
    assert is_iterable(None) is False
    assert is_iterable(Exception()) is False



# Generated at 2022-06-16 22:26:25.665324
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:26:35.772173
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(x for x in []))
    assert is_iterable(iter(x for x in ()))
    assert is_iterable(iter(x for x in {}))

# Generated at 2022-06-16 22:26:43.409204
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable((1, 2, 3))
    assert is_iterable(dict(a=1, b=2, c=3))
    assert is_iterable(range(3))
    assert is_iterable(xrange(3))
    assert is_iterable(3) is False
    assert is_iterable('abc') is False
    assert is_iterable(u'abc') is False
    assert is_iterable(b'abc') is False
