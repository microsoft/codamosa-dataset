

# Generated at 2022-06-16 22:17:26.690718
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:17:35.642735
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({}))
    assert is_iterable(ImmutableDict({'a': 1}))
    assert is_iterable(ImmutableDict(a=1))
    assert is_iterable(ImmutableDict(a=1, b=2))


# Generated at 2022-06-16 22:17:47.115999
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(1) is False
    assert is_iterable('abc') is False
    assert is_iterable(u'abc') is False
    assert is_iterable(b'abc') is False
    assert is_iterable(None) is False
    assert is_iterable(Exception()) is False
    assert is_iterable(Exception) is False
    assert is_iterable(is_iterable) is False

# Generated at 2022-06-16 22:17:54.363479
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equal dictionaries
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test for equal dictionaries with different order of keys
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'b': 2, 'a': 1})
    assert d1 == d2

    # Test for dictionaries with different keys
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 != d2

    # Test for dictionaries with different values

# Generated at 2022-06-16 22:18:03.273097
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test with two empty ImmutableDicts
    assert ImmutableDict() == ImmutableDict()
    # Test with two equal ImmutableDicts
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test with two different ImmutableDicts
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test with an ImmutableDict and a dict
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test with an ImmutableDict and a set

# Generated at 2022-06-16 22:18:09.175234
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict(a=1))
    assert is_iterable(ImmutableDict(a=1).keys())

# Generated at 2022-06-16 22:18:15.421238
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({'a': 1}))
    assert is_iterable(ImmutableDict(a=1))

# Generated at 2022-06-16 22:18:24.782176
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test case 1:
    #   ImmutableDict1 = ImmutableDict({'a': 1, 'b': 2})
    #   ImmutableDict2 = ImmutableDict({'a': 1, 'b': 2})
    #   ImmutableDict1 == ImmutableDict2
    #   Expected result: True
    ImmutableDict1 = ImmutableDict({'a': 1, 'b': 2})
    ImmutableDict2 = ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict1 == ImmutableDict2

    # Test case 2:
    #   ImmutableDict1 = ImmutableDict({'a': 1, 'b': 2})
    #   ImmutableDict2 = ImmutableDict({'a': 1, 'b': 3})
   

# Generated at 2022-06-16 22:18:36.858625
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 2, 'c': 3}
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 2, 'c': 3}
    assert ImmutableD

# Generated at 2022-06-16 22:18:46.156010
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(tuple())
    assert is_iterable(frozenset())
    assert is_iterable(ImmutableDict())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(dict()))
    assert is_iterable(iter(tuple()))
    assert is_iterable(iter(frozenset()))
    assert is_iterable(iter(ImmutableDict()))
    assert is_iterable(iter(range(0)))

# Generated at 2022-06-16 22:19:01.992042
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:19:09.894472
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Unit test for method __eq__ of class ImmutableDict
    """
    # Test case 1:
    # Two ImmutableDict objects with same key-value pairs are equal
    # Expected result: True
    immutable_dict_1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    immutable_dict_2 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert immutable_dict_1 == immutable_dict_2

    # Test case 2:
    # Two ImmutableDict objects with different key-value pairs are not equal
    # Expected result: False
    immutable_dict_1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    immutable_dict_2 = Immutable

# Generated at 2022-06-16 22:19:21.174984
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test 1: Test equality of two ImmutableDict objects with same key-value pairs
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test 2: Test equality of two ImmutableDict objects with different key-value pairs
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert not d1 == d2

    # Test 3: Test equality of two ImmutableDict objects with different keys
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2

# Generated at 2022-06-16 22:19:34.173760
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(dict(a=1, b=2))
    assert is_iterable(dict(zip(range(10), range(10))))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert is_iterable(memoryview(b'abc'))
    assert is_iterable(5) is False


# Generated at 2022-06-16 22:19:44.013660
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(xrange(0, 10))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(xrange(0, 10)))
    assert is_iterable(iter({'a': 1, 'b': 2}))
    assert is_iterable(iter(set([1, 2, 3])))
    assert is_iterable(iter((1, 2, 3)))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter([]))

# Generated at 2022-06-16 22:19:54.049224
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2
    # Test for inequality
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2
    # Test for inequality with non-ImmutableDict
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'a': 1, 'b': 2}
    assert d1 != d2


# Generated at 2022-06-16 22:20:05.822537
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test with different types
    assert ImmutableDict({'a': 1}) != 1
    assert ImmutableDict({'a': 1}) != 'a'
    assert ImmutableDict({'a': 1}) != [1, 2, 3]
    assert ImmutableDict({'a': 1}) != {'a': 1}
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})

# Generated at 2022-06-16 22:20:18.744698
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)

# Generated at 2022-06-16 22:20:30.850045
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({})
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set())
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(xrange(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(iter({'a': 1, 'b': 2}))

# Generated at 2022-06-16 22:20:38.769535
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDict objects
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test for inequality of two ImmutableDict objects
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2

    # Test for equality of ImmutableDict and MutableMapping
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'a': 1, 'b': 2}
    assert d1 == d2

    # Test for inequality of ImmutableDict and MutableMapping
   

# Generated at 2022-06-16 22:20:54.124981
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:21:01.362726
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:21:12.274128
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test that ImmutableDict is equal to itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d1

    # Test that ImmutableDict is equal to another ImmutableDict with the same items
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test that ImmutableDict is not equal to another ImmutableDict with different items
    d3 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d3

    # Test that ImmutableDict is not equal to a dict with the same items
    d4 = {'a': 1, 'b': 2}
    assert d1 != d4

    # Test that ImmutableDict is not equal to a dict with different items

# Generated at 2022-06-16 22:21:19.375693
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that the __eq__ method of ImmutableDict works as expected
    """
    # Test that two ImmutableDicts with the same keys and values are equal
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test that two ImmutableDicts with the same keys and different values are not equal
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test that two ImmutableDicts with different keys and the same values are not equal
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    # Test that two ImmutableDicts with different keys and different values are

# Generated at 2022-06-16 22:21:30.937662
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(dict().keys())
    assert is_iterable(dict().values())
    assert is_iterable(dict().items())
    assert is_iterable(dict().iterkeys())
    assert is_iterable(dict().itervalues())
    assert is_iterable(dict().iteritems())
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))

# Generated at 2022-06-16 22:21:42.756980
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict
    """
    # Test equality of two ImmutableDict objects
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test equality of an ImmutableDict and a dict
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'a': 1, 'b': 2}
    assert d1 == d2

    # Test equality of an ImmutableDict and a dict with different order of keys
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'b': 2, 'a': 1}
    assert d1 == d2

# Generated at 2022-06-16 22:21:53.516713
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')

# Generated at 2022-06-16 22:22:04.600216
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the method __eq__ of class ImmutableDict
    """
    # Test 1:
    # Test if two ImmutableDict objects are equal
    # Expected result: True
    test_dict1 = ImmutableDict({'a': 1, 'b': 2})
    test_dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict1 == test_dict2

    # Test 2:
    # Test if two ImmutableDict objects are not equal
    # Expected result: False
    test_dict1 = ImmutableDict({'a': 1, 'b': 2})
    test_dict2 = ImmutableDict({'a': 1, 'b': 3})
    assert test_dict1 != test_dict2

    # Test 3:
    # Test if an Imm

# Generated at 2022-06-16 22:22:17.353868
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(1)
    assert not is_iterable(None)
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(1))
    assert not is_iterable(iter(None))
    assert is_iterable(iter([]))
    assert is_

# Generated at 2022-06-16 22:22:28.110963
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality with a dict
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test for equality with an ImmutableDict
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test for inequality with a dict
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}
    # Test for inequality with an ImmutableDict
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test for inequality with a non-dict

# Generated at 2022-06-16 22:22:52.290466
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test case 1:
    # Two ImmutableDict objects with same key-value pairs
    # are equal
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 == d2

    # Test case 2:
    # Two ImmutableDict objects with same key-value pairs
    # but in different order are equal
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d2 = ImmutableDict({'c': 3, 'b': 2, 'a': 1})
    assert d1 == d2

    # Test case 3:

# Generated at 2022-06-16 22:22:59.679033
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of ImmutableDict objects
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:23:12.294677
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test equality of ImmutableDict with itself
    test_dict = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict == test_dict

    # Test equality of ImmutableDict with a different ImmutableDict with the same content
    test_dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict == test_dict2

    # Test equality of ImmutableDict with a different ImmutableDict with different content
    test_dict3 = ImmutableDict({'a': 1, 'b': 3})
    assert test_dict != test_dict3

    # Test equality of ImmutableDict with a MutableMapping with the same content

# Generated at 2022-06-16 22:23:19.928096
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)

# Generated at 2022-06-16 22:23:29.349563
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:23:38.446811
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert is_iterable(1) is False
    assert is_iterable(None) is False
    assert is_iterable(Exception()) is False


# Generated at 2022-06-16 22:23:45.885957
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(object())
    assert not is_iterable(object)



# Generated at 2022-06-16 22:23:58.321925
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:24:08.460043
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:24:19.286171
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__ works as expected.
    """
    # Test that ImmutableDict.__eq__ returns True when comparing two ImmutableDicts with the same
    # key-value pairs
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})

    # Test that ImmutableDict.__eq__ returns False when comparing two ImmutableDicts with different
    # key-value pairs
    assert not ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 3})

    # Test that ImmutableDict.__eq__ returns False when comparing an ImmutableDict with a dict

# Generated at 2022-06-16 22:24:59.305460
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})

# Generated at 2022-06-16 22:25:11.889844
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({})

# Generated at 2022-06-16 22:25:16.043316
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:25:27.193723
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test that ImmutableDict is equal to itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d1

    # Test that ImmutableDict is equal to a dictionary with the same key-value pairs
    d2 = {'a': 1, 'b': 2}
    assert d1 == d2

    # Test that ImmutableDict is not equal to a dictionary with different key-value pairs
    d3 = {'a': 1, 'b': 3}
    assert d1 != d3

    # Test that ImmutableDict is not equal to a dictionary with different keys
    d4 = {'a': 1, 'c': 2}
    assert d1 != d4

    # Test that ImmutableDict is not equal to a dictionary with different values

# Generated at 2022-06-16 22:25:40.102256
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test case 1:
    #   ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)
    #   Expected result: True
    #   Actual result: True
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)

    # Test case 2:
    #   ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=3)
    #   Expected result: False
    #   Actual result: False
    assert not ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=3)

    # Test case 3:
    #

# Generated at 2022-06-16 22:25:49.923215
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-16 22:26:01.939800
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDict objects
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)
    # Test for equality of an ImmutableDict object and a dict object
    assert ImmutableDict(a=1, b=2) == {'a': 1, 'b': 2}
    # Test for equality of an ImmutableDict object and a dict object
    assert ImmutableDict(a=1, b=2) == {'b': 2, 'a': 1}
    # Test for inequality of two ImmutableDict objects
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=3)
    # Test for inequality of an ImmutableDict object and a dict object
    assert ImmutableDict

# Generated at 2022-06-16 22:26:12.308163
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1})

# Generated at 2022-06-16 22:26:24.327296
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(frozenset())
    assert is_iterable(xrange(0))
    assert is_iterable(xrange(1))
    assert is_iterable(xrange(2))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(frozenset()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(xrange(1)))
    assert is_iterable(iter(xrange(2)))

# Generated at 2022-06-16 22:26:34.812700
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test that two ImmutableDicts with the same key-value pairs are equal
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test that two ImmutableDicts with different key-value pairs are not equal
    d3 = ImmutableDict({'a': 1, 'b': 2})
    d4 = ImmutableDict({'a': 1, 'b': 3})
    assert d3 != d4

    # Test that an ImmutableDict is not equal to a dict with the same key-value pairs
    d5 = ImmutableDict({'a': 1, 'b': 2})
    d6