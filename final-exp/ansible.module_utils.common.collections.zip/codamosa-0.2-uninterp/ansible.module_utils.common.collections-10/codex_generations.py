

# Generated at 2022-06-16 22:17:19.742675
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(dict({'a': 1, 'b': 2}))
    assert is_iterable(dict(a=1, b=2))
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter(set()))
    assert is_iterable(iter({}))

# Generated at 2022-06-16 22:17:30.561686
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({}))
    assert is_iterable(ImmutableDict({'a': 1}))

# Generated at 2022-06-16 22:17:43.149521
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict().items())
    assert is_iterable(ImmutableDict().keys())
    assert is_iterable(ImmutableDict().values())
   

# Generated at 2022-06-16 22:17:51.963085
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test equality of ImmutableDict with itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d1

    # Test equality of ImmutableDict with a copy of itself
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test equality of ImmutableDict with a different ImmutableDict
    d3 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d3

    # Test equality of ImmutableDict with a different ImmutableDict
    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 != d4

    #

# Generated at 2022-06-16 22:18:02.235683
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test for equality of two ImmutableDict objects
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test for inequality of two ImmutableDict objects
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test for inequality of ImmutableDict and MutableMapping objects
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 2}
    # Test for inequality of ImmutableDict and MutableMapping objects

# Generated at 2022-06-16 22:18:13.828159
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test method __eq__ of class ImmutableDict"""
    # Test case 1:
    #   Input:
    #       ImmutableDict({'a': 1, 'b': 2})
    #       ImmutableDict({'a': 1, 'b': 2})
    #   Expected result:
    #       True
    #   Actual result:
    #       True
    #   Test result:
    #       OK
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})

    # Test case 2:
    #   Input:
    #       ImmutableDict({'a': 1, 'b': 2})
    #       ImmutableDict({'a': 1, 'b': 3})
    #   Expected result:
    #      

# Generated at 2022-06-16 22:18:23.623500
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1: 'a', 2: 'b', 3: 'c'})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(1, 4))
    assert is_iterable(xrange(1, 4))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)


# Generated at 2022-06-16 22:18:31.185030
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(tuple())
    assert is_iterable(list())
    assert is_iterable(xrange(0))
    assert is_iterable(xrange(1))
    assert is_iterable(xrange(2))
    assert is_iterable(xrange(3))
    assert is_iterable(xrange(4))
    assert is_iterable(xrange(5))
    assert is_iterable(xrange(6))
    assert is_iterable(xrange(7))
    assert is_iterable(xrange(8))
    assert is_iterable(xrange(9))
    assert is_iterable(xrange(10))
    assert is_iterable

# Generated at 2022-06-16 22:18:42.209621
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)
    assert ImmutableDict(a=1, b=2) == dict(a=1, b=2)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=2, c=3)
    assert ImmutableDict(a=1, b=2) != dict(a=1, b=2, c=3)
    assert ImmutableDict(a=1, b=2) != dict(a=1, b=3)

# Generated at 2022-06-16 22:18:51.975891
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict
    """
    # Test for equality of two ImmutableDict objects
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test for inequality of two ImmutableDict objects
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test for equality of an ImmutableDict object and a dict object
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test for inequality of an ImmutableDict object and a dict object

# Generated at 2022-06-16 22:19:06.839986
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(a=1, b=2)
    d3 = ImmutableDict(a=1, b=3)
    d4 = ImmutableDict(a=1, b=2, c=3)
    d5 = ImmutableDict(a=1, b=2, c=3)
    d6 = ImmutableDict(a=1, b=2, c=4)
    d7 = ImmutableDict(a=1, b=2, c=4)
    d8 = ImmutableDict(a=1, b=2, c=3, d=4)
    d9 = ImmutableDict(a=1, b=2, c=3, d=4)
    d10 = Imm

# Generated at 2022-06-16 22:19:19.384369
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of the ImmutableDict class.
    """
    # Test equality of ImmutableDicts
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test equality of ImmutableDict and dict
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'a': 1, 'b': 2}
    assert d1 == d2

    # Test equality of ImmutableDict and OrderedDict
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = OrderedDict({'a': 1, 'b': 2})
    assert d1 == d2



# Generated at 2022-06-16 22:19:32.713891
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable((x for x in range(10)))
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert is_iterable(u'unicode')
    assert is_iterable(b'bytes')
    assert is_iterable(bytearray(b'bytearray'))
    assert is_iterable(memoryview(b'memoryview'))
    assert is_iterable(u'unicode', include_strings=True)
    assert is_iterable(b'bytes', include_strings=True)
    assert not is_iterable(u'unicode')

# Generated at 2022-06-16 22:19:40.670130
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDicts
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test for inequality of two ImmutableDicts
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test for equality of ImmutableDict and dict
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test for inequality of ImmutableDict and dict
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}
    # Test for equality of ImmutableDict and OrderedDict
    assert ImmutableD

# Generated at 2022-06-16 22:19:51.158673
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)
    assert not is_iterable(0)
    assert not is_iterable(0.0)
    assert not is_iterable('')
    assert not is_iterable(u'')
    assert not is_iterable(False)
    assert not is_iterable(True)
    assert not is_

# Generated at 2022-06-16 22:20:03.554268
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(2) is False
    assert is_iterable('foo') is False
    assert is_iterable(u'foo') is False
    assert is_iterable(b'foo') is False
    assert is_iterable(u'foo'.encode('utf-8')) is False
    assert is_iterable(u'foo'.encode('utf-8'), include_strings=True)
    assert is_iterable(u'foo', include_strings=True)
    assert is_iterable(b'foo', include_strings=True)

# Generated at 2022-06-16 22:20:15.391714
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test equality of ImmutableDict with itself
    d = ImmutableDict({'a': 1, 'b': 2})
    assert d == d

    # Test equality of ImmutableDict with another ImmutableDict with the same content
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test equality of ImmutableDict with another ImmutableDict with different content
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2

    # Test equality of ImmutableDict with

# Generated at 2022-06-16 22:20:27.319953
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object)
    assert is_iterable(is_iterable)
    assert is_iterable(test_is_iterable)
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(xrange(10), include_strings=True)

# Generated at 2022-06-16 22:20:35.478198
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(5) is False
    assert is_iterable('abc') is False
    assert is_iterable(u'abc') is False
    assert is_iterable(b'abc') is False
    assert is_iterable(bytearray(b'abc')) is False



# Generated at 2022-06-16 22:20:43.224337
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of ImmutableDict with itself
    d = ImmutableDict({'a': 1, 'b': 2})
    assert d == d

    # Test equality of ImmutableDict with a dict with the same key-value pairs
    d = ImmutableDict({'a': 1, 'b': 2})
    assert d == {'a': 1, 'b': 2}

    # Test equality of ImmutableDict with a dict with the same key-value pairs in different order
    d = ImmutableDict({'a': 1, 'b': 2})
    assert d == {'b': 2, 'a': 1}

    # Test equality of ImmutableDict with a dict with the same key-value pairs and additional keys
    d = ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-16 22:20:59.255436
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(u''))
    assert is_iterable(iter(bytearray(0)))
    assert is_

# Generated at 2022-06-16 22:21:10.755136
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(xrange(1, 10))
    assert is_iterable(xrange(1, 10), include_strings=True)
    assert is_iterable(u'abc')
    assert is_iterable(u'abc', include_strings=True)
    assert is_iterable(b'abc')
    assert is_iterable(b'abc', include_strings=True)
    assert not is_iterable(1)
    assert not is_iterable(1, include_strings=True)
    assert not is_iterable(None)
   

# Generated at 2022-06-16 22:21:18.292633
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test case 1:
    #   - Two ImmutableDicts with the same content
    #   - Expected result: True
    test_dict_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_dict_2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert test_dict_1 == test_dict_2

    # Test case 2:
    #   - Two ImmutableDicts with different content
    #   - Expected result: False
    test_dict_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-16 22:21:29.841345
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:21:41.747200
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test 1: Two ImmutableDicts with the same content are equal
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test 2: Two ImmutableDicts with different content are not equal
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2

    # Test 3: An ImmutableDict is not equal to a dict with the same content
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'a': 1, 'b': 2}
    assert d1 != d2

    # Test 4

# Generated at 2022-06-16 22:21:51.346954
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)

# Generated at 2022-06-16 22:22:03.067393
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)
    assert not is_iterable(42)
    assert not is_iterable(object())
    assert not is_iterable(Exception())
    assert not is_iterable(Exception)
    assert not is_iterable(Exception('foo'))
    assert not is_iterable(Exception('foo', 'bar'))

# Generated at 2022-06-16 22:22:15.407979
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test for equality of two ImmutableDict objects
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test for inequality of two ImmutableDict objects
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test for equality of ImmutableDict and dict
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test for inequality of ImmutableDict and dict
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}
    #

# Generated at 2022-06-16 22:22:20.047293
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__ returns True when comparing two ImmutableDicts with the same
    key-value pairs and False when comparing two ImmutableDicts with different key-value pairs.
    """
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    d3 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 == d2
    assert not d1 == d3


# Generated at 2022-06-16 22:22:30.089737
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(tuple())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(tuple()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))
    assert is_iterable(iter(iter(tuple())))
    assert is_iterable(iter(iter(xrange(0))))
    assert is_iter

# Generated at 2022-06-16 22:22:53.771542
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict
    """
    # Test equality of two ImmutableDict objects
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test inequality of two ImmutableDict objects
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 3})
    assert dict1 != dict2

    # Test equality of an ImmutableDict object and a dict object
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = {'a': 1, 'b': 2}
    assert dict1 == dict2



# Generated at 2022-06-16 22:23:03.624239
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) == {'a': 1}
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != {'a': 2}
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != {'b': 1}
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != {'a': 1, 'b': 2}

# Generated at 2022-06-16 22:23:12.623317
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(5))
    assert is_iterable(xrange(5))
    assert is_iterable(iter(range(5)))
    assert is_iterable(5) is False
    assert is_iterable('abc') is False
    assert is_iterable(u'abc') is False
    assert is_iterable(b'abc') is False
    assert is_iterable(bytearray(b'abc')) is False



# Generated at 2022-06-16 22:23:25.041265
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    dict3 = ImmutableDict({'a': 1, 'b': 3})
    dict4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict5 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict6 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    dict7 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    dict8 = ImmutableDict({'a': 1, 'b': 2, 'c': 4, 'd': 5})

# Generated at 2022-06-16 22:23:35.971092
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({'a': 1}))
    assert is_iterable(ImmutableDict(a=1))
    assert is_iterable(ImmutableDict([('a', 1)]))

# Generated at 2022-06-16 22:23:45.850209
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_

# Generated at 2022-06-16 22:23:58.320968
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    d3 = ImmutableDict({'a': 1, 'b': 3})
    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d5 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d6 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    d7 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    d8 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})

# Generated at 2022-06-16 22:24:08.457084
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    test_dict = ImmutableDict({"a": 1, "b": 2})
    test_dict_same = ImmutableDict({"a": 1, "b": 2})
    test_dict_diff = ImmutableDict({"a": 1, "b": 3})
    test_dict_diff_key = ImmutableDict({"a": 1, "b": 2, "c": 3})
    test_dict_diff_type = {"a": 1, "b": 2}

    assert test_dict == test_dict_same
    assert test_dict != test_dict_diff
    assert test_dict != test_dict_diff_key
    assert test_dict != test_dict_diff_type


# Generated at 2022-06-16 22:24:19.231307
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:24:30.297883
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-16 22:25:12.397044
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test that ImmutableDict is equal to itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d1

    # Test that ImmutableDict is equal to a dict with the same key-value pairs
    d2 = {'a': 1, 'b': 2}
    assert d1 == d2

    # Test that ImmutableDict is not equal to a dict with different key-value pairs
    d3 = {'a': 1, 'b': 3}
    assert d1 != d3

    # Test that ImmutableDict is not equal to a dict with different keys
    d4 = {'a': 1, 'c': 2}
    assert d1 != d4

    # Test that ImmutableDict is not equal to a dict with different values

# Generated at 2022-06-16 22:25:23.987282
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test case 1:
    # Test if two ImmutableDict objects are equal
    # when they have the same key-value pairs
    test_dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_dict2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert test_dict1 == test_dict2

    # Test case 2:
    # Test if two ImmutableDict objects are not equal
    # when they have different key-value pairs
    test_dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-16 22:25:31.651657
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict.
    """
    # Test that two ImmutableDict instances with the same contents are equal
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})

    # Test that two ImmutableDict instances with different contents are not equal
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})

    # Test that an ImmutableDict instance is not equal to a dict with the same contents
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 2}

    # Test that an ImmutableDict instance is not equal to a dict with different contents
    assert ImmutableDict

# Generated at 2022-06-16 22:25:43.239067
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1, b=2) == ImmutableDict(b=2, a=1)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1, c=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=2)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1)
    assert ImmutableDict(a=1, b=2) != ImmutableDict()
    assert ImmutableDict(a=1, b=2) != dict(a=1, b=2)
    assert Immutable

# Generated at 2022-06-16 22:25:55.167627
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert is_iterable(iter(b'abc'))
    assert is_iterable(iter(bytearray(b'abc')))
    assert is_iterable(iter(u'abc'))
    assert is_iterable

# Generated at 2022-06-16 22:26:06.959023
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(x for x in []))
    assert is_iterable(iter(x for x in ()))
    assert is_iterable(iter(x for x in {}))

# Generated at 2022-06-16 22:26:15.386602
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test equality of ImmutableDict with itself
    immutable_dict = ImmutableDict({'a': 1, 'b': 2})
    assert immutable_dict == immutable_dict
    # Test equality of ImmutableDict with a copy of itself
    immutable_dict_copy = ImmutableDict({'a': 1, 'b': 2})
    assert immutable_dict == immutable_dict_copy
    # Test equality of ImmutableDict with a different ImmutableDict
    immutable_dict_2 = ImmutableDict({'a': 1, 'b': 3})
    assert immutable_dict != immutable_dict_2
    # Test equality of ImmutableDict with a dict
    assert immutable_dict == {'a': 1, 'b': 2}
    # Test equality

# Generated at 2022-06-16 22:26:27.921725
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:26:37.663213
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({}))
    assert is_iterable(ImmutableDict(a=1))

# Generated at 2022-06-16 22:26:44.421534
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert not is_iterable(5)
    assert not is_iterable(None)

