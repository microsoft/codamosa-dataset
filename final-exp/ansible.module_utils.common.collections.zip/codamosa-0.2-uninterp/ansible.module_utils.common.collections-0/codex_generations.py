

# Generated at 2022-06-16 22:17:19.538170
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1, 'c': 3})

# Generated at 2022-06-16 22:17:30.410904
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of ImmutableDict with itself
    immutable_dict = ImmutableDict({'a': 1, 'b': 2})
    assert immutable_dict == immutable_dict

    # Test equality of ImmutableDict with a different ImmutableDict
    immutable_dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert immutable_dict == immutable_dict2

    # Test equality of ImmutableDict with a different ImmutableDict
    immutable_dict3 = ImmutableDict({'a': 1, 'b': 3})
    assert immutable_dict != immutable_dict3

    # Test equality of ImmutableDict with a different ImmutableDict
    immutable_dict4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert immutable_dict != immutable_dict4

   

# Generated at 2022-06-16 22:17:43.051609
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'c': 1, 'b': 2})

# Generated at 2022-06-16 22:17:51.896047
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'c': 3})

# Generated at 2022-06-16 22:18:02.174277
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:18:13.780507
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable(())
    assert is_iterable((1, 2, 3))
    assert is_iterable({})
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set())
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object, include_strings=True)
    assert not is_iterable

# Generated at 2022-06-16 22:18:23.622369
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:18:35.574567
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({}))
    assert is_iterable(ImmutableDict(a=1))
    assert is_iterable(ImmutableDict(a=1, b=2))

# Generated at 2022-06-16 22:18:45.400386
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Unit test for method __eq__ of class ImmutableDict
    """
    # Test case 1:
    # Two ImmutableDict objects are equal if they have the same key-value pairs
    # Test case 1.1:
    # Two ImmutableDict objects are equal if they have the same key-value pairs
    # and the same order of key-value pairs
    # Test case 1.1.1:
    # Two ImmutableDict objects are equal if they have the same key-value pairs
    # and the same order of key-value pairs and the same number of key-value pairs
    # Test case 1.1.1.1:
    # Two ImmutableDict objects are equal if they have the same key-value pairs
    # and the same order of key-value pairs and the same number of key-value pairs
    # and the

# Generated at 2022-06-16 22:18:53.635125
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test case 1
    # Input:
    #   - ImmutableDict({'a': 1, 'b': 2})
    #   - ImmutableDict({'a': 1, 'b': 2})
    # Expected output:
    #   - True
    # Actual output:
    #   - True
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})

    # Test case 2
    # Input:
    #   - ImmutableDict({'a': 1, 'b': 2})
    #   - ImmutableDict({'a': 1, 'b': 3})
    # Expected output:
    #   - False
    # Actual output:
    #   - False

# Generated at 2022-06-16 22:19:07.737356
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(u'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iter

# Generated at 2022-06-16 22:19:20.013667
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test __eq__ method of class ImmutableDict
    """
    # Test for equality of two ImmutableDict objects
    test_dict1 = ImmutableDict({'a': 1, 'b': 2})
    test_dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict1 == test_dict2

    # Test for equality of an ImmutableDict object and a dict object
    test_dict3 = ImmutableDict({'a': 1, 'b': 2})
    test_dict4 = {'a': 1, 'b': 2}
    assert test_dict3 == test_dict4

    # Test for equality of an ImmutableDict object and a dict object with different values
    test_dict5 = ImmutableDict({'a': 1, 'b': 2})


# Generated at 2022-06-16 22:19:33.087893
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:19:40.413886
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable(set())
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(xrange(0, 10))
    assert is_iterable(dict())
    assert is_iterable(dict(a=1, b=2, c=3))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(1) is False
    assert is_iterable(None) is False


# Generated at 2022-06-16 22:19:47.313524
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)

# Generated at 2022-06-16 22:19:59.808544
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:20:08.908477
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1, 2, 3})
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(3))
    assert is_iterable(xrange(3))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(xrange(3)))
    assert is_iterable(iter(range(3)))
    assert is_iterable(iter(set([1, 2, 3])))
    assert is_iterable(iter({'a': 1, 'b': 2}))

# Generated at 2022-06-16 22:20:21.582696
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict
    """
    # Test equality of two ImmutableDicts
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test equality of an ImmutableDict and a dict
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test equality of an ImmutableDict and a list
    assert ImmutableDict({'a': 1, 'b': 2}) == [('a', 1), ('b', 2)]
    # Test equality of an ImmutableDict and a tuple
    assert ImmutableDict({'a': 1, 'b': 2}) == (('a', 1), ('b', 2))
    # Test

# Generated at 2022-06-16 22:20:33.365885
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1, 'c': 3}).difference(['c'])

# Generated at 2022-06-16 22:20:41.581513
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test that two ImmutableDicts with the same key-value pairs are equal
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test that two ImmutableDicts with different key-value pairs are not equal
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2

    # Test that two ImmutableDicts with the same key-value pairs are equal
    # even if they have different order of key-value pairs
    d1 = ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-16 22:20:58.031152
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test case 1:
    #   Two ImmutableDict objects are equal
    #   Expected result:
    #       True
    #   Actual result:
    #       True
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test case 2:
    #   Two ImmutableDict objects are not equal
    #   Expected result:
    #       False
    #   Actual result:
    #       False
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})

# Generated at 2022-06-16 22:21:09.917136
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__ returns True when the two ImmutableDicts are equal,
    and False when they are not.
    """
    # Test that two empty ImmutableDicts are equal
    assert ImmutableDict() == ImmutableDict()

    # Test that two ImmutableDicts with the same keys and values are equal
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})

    # Test that two ImmutableDicts with the same keys and different values are not equal
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})

    # Test that two ImmutableDicts with different keys and the same values are not equal

# Generated at 2022-06-16 22:21:18.463901
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__() works as expected
    """
    # Test that ImmutableDict.__eq__() returns True when comparing two identical ImmutableDicts
    d1 = ImmutableDict({"a": 1, "b": 2})
    d2 = ImmutableDict({"a": 1, "b": 2})
    assert d1 == d2

    # Test that ImmutableDict.__eq__() returns False when comparing two different ImmutableDicts
    d1 = ImmutableDict({"a": 1, "b": 2})
    d2 = ImmutableDict({"a": 1, "b": 3})
    assert d1 != d2

    # Test that ImmutableDict.__eq__() returns False when comparing an ImmutableDict to a dict
    d1 = ImmutableD

# Generated at 2022-06-16 22:21:30.010935
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test 1: compare two ImmutableDict instances with the same content
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test 2: compare two ImmutableDict instances with different content
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2

    # Test 3: compare two ImmutableDict instances with different content
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 != d2

   

# Generated at 2022-06-16 22:21:41.991753
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)

# Generated at 2022-06-16 22:21:52.055292
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test the __eq__ method of ImmutableDict class"""
    # Test with two identical ImmutableDict objects
    immutable_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    immutable_dict_2 = ImmutableDict({'a': 1, 'b': 2})
    assert immutable_dict_1 == immutable_dict_2

    # Test with two different ImmutableDict objects
    immutable_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    immutable_dict_2 = ImmutableDict({'a': 1, 'b': 3})
    assert immutable_dict_1 != immutable_dict_2

    # Test with an ImmutableDict and a dict
    immutable_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    dict_

# Generated at 2022-06-16 22:22:03.540272
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test for method __eq__ of class ImmutableDict
    """
    dict1 = ImmutableDict({'a': 'b', 'c': 'd'})
    dict2 = ImmutableDict({'a': 'b', 'c': 'd'})
    dict3 = ImmutableDict({'a': 'b', 'c': 'e'})
    dict4 = ImmutableDict({'a': 'b', 'c': 'd', 'e': 'f'})
    dict5 = ImmutableDict({'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h'})
    dict6 = ImmutableDict({'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h', 'i': 'j'})
    dict7 = Imm

# Generated at 2022-06-16 22:22:16.059115
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test for inequality
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 3})
    assert dict1 != dict2

    # Test for inequality with a non-ImmutableDict
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = {'a': 1, 'b': 2}
    assert dict1 != dict2

    # Test for inequality with a non-ImmutableDict
    dict1 = ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-16 22:22:27.078117
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of ImmutableDict with itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d1

    # Test equality of ImmutableDict with a copy of itself
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test equality of ImmutableDict with a different ImmutableDict with the same key-value pairs
    d3 = ImmutableDict({'b': 2, 'a': 1})
    assert d1 == d3

    # Test equality of ImmutableDict with a different ImmutableDict with different key-value pairs
    d4 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d4

    # Test equality of ImmutableDict with a different Imm

# Generated at 2022-06-16 22:22:36.586875
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(5))
    assert is_iterable(xrange(5))
    assert is_iterable(iter(range(5)))
    assert is_iterable(5) is False
    assert is_iterable(None) is False
    assert is_iterable(is_iterable) is False
    assert is_iterable('abc') is False
    assert is_iterable(u'abc') is False
    assert is_iterable(b'abc') is False


# Generated at 2022-06-16 22:22:57.349032
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test for method __eq__ of class ImmutableDict
    """
    # Test for equality of two ImmutableDicts
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test for equality of an ImmutableDict and a MutableDict
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test for equality of an ImmutableDict and a MutableDict with different values
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}
    # Test for equality of an ImmutableDict and a MutableDict with different keys

# Generated at 2022-06-16 22:23:08.797350
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:23:15.460824
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(1) is False
    assert is_iterable(None) is False
    assert is_iterable(Exception()) is False


# Generated at 2022-06-16 22:23:26.744616
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    c = ImmutableDict({'a': 1, 'b': 3})
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    e = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    f = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    g = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})

# Generated at 2022-06-16 22:23:38.496299
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDict objects
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test for inequality of two ImmutableDict objects
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test for equality of an ImmutableDict object and a dict object
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test for inequality of an ImmutableDict object and a dict object
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}
    # Test for equality of an ImmutableDict

# Generated at 2022-06-16 22:23:47.464189
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(xrange(0)))

# Generated at 2022-06-16 22:23:59.987202
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of ImmutableDict with itself
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 == d1

    # Test equality of ImmutableDict with a copy of itself
    d2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 == d2

    # Test equality of ImmutableDict with a different ImmutableDict
    d3 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    assert d1 != d3

    # Test equality of ImmutableDict with a MutableMapping
    d4 = {'a': 1, 'b': 2, 'c': 3}
    assert d1 == d4

    # Test equality of ImmutableDict with a

# Generated at 2022-06-16 22:24:09.643200
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({}))
    assert is_iterable(ImmutableDict({'a': 1, 'b': 2}))
    assert is_iterable(ImmutableDict(a=1, b=2))

# Generated at 2022-06-16 22:24:20.676276
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(u''))
    assert is_iterable(iter(bytearray()))
    assert is_iter

# Generated at 2022-06-16 22:24:31.200308
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test method __eq__ of class ImmutableDict"""
    # Test case 1:
    #   - Two ImmutableDict objects are equal
    #   - Result: __eq__ should return True
    dict1 = ImmutableDict({"a": 1, "b": 2})
    dict2 = ImmutableDict({"a": 1, "b": 2})
    assert dict1 == dict2

    # Test case 2:
    #   - Two ImmutableDict objects are not equal
    #   - Result: __eq__ should return False
    dict1 = ImmutableDict({"a": 1, "b": 2})
    dict2 = ImmutableDict({"a": 1, "b": 3})
    assert dict1 != dict2

    # Test case 3:
    #   - One ImmutableDict object and one dict object

# Generated at 2022-06-16 22:25:05.212615
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test the __eq__ method of ImmutableDict"""
    # Test equality of ImmutableDict with itself
    test_dict = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict == test_dict

    # Test equality of ImmutableDict with a copy of itself
    test_dict_copy = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict == test_dict_copy

    # Test equality of ImmutableDict with a different ImmutableDict
    test_dict_different = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert test_dict != test_dict_different

    # Test equality of ImmutableDict with a different ImmutableDict

# Generated at 2022-06-16 22:25:14.476320
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    d3 = ImmutableDict({'a': 1, 'b': 3})
    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d5 = {'a': 1, 'b': 2}
    assert d1 == d2
    assert d1 != d3
    assert d1 != d4
    assert d1 != d5


# Generated at 2022-06-16 22:25:25.849064
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:25:39.334903
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test 1: Test equality of two ImmutableDict objects
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test 2: Test equality of two ImmutableDict objects with different order of keys
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'b': 2, 'a': 1})
    assert d1 == d2

    # Test 3: Test equality of two ImmutableDict objects with different values
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2

    #

# Generated at 2022-06-16 22:25:47.806634
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:26:00.551735
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:26:08.296215
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(1) is False
    assert is_iterable(None) is False
    assert is_iterable(Exception()) is False


# Generated at 2022-06-16 22:26:16.194881
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict
    """
    # Test equality of ImmutableDict with itself
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test equality of ImmutableDict with a dict
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test equality of ImmutableDict with a different ImmutableDict
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test equality of ImmutableDict with a different dict

# Generated at 2022-06-16 22:26:28.616038
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    d3 = ImmutableDict({'a': 1, 'b': 3})
    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 == d2
    assert d1 != d3
    assert d1 != d4
    assert d1 != {'a': 1, 'b': 2}
    assert d1 != {'a': 1, 'b': 2, 'c': 3}
    assert d1 != {'a': 1, 'b': 3}
    assert d1 != {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-16 22:26:38.186404
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__ returns True when the dictionaries are equal
    and False when they are not.
    """
    # Test that ImmutableDict.__eq__ returns True when the dictionaries are equal
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1, 'c': 3}