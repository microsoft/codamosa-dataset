

# Generated at 2022-06-16 22:17:20.484113
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert test_dict.difference(['a', 'b']) == ImmutableDict({'c': 3})
    assert test_dict.difference(['a', 'b', 'c']) == ImmutableDict({})
    assert test_dict.difference(['a', 'b', 'c', 'd']) == ImmutableDict({})
    assert test_dict.difference(['d']) == test_dict
    assert test_dict.difference([]) == test_dict
    assert test_dict.difference(['a', 'b', 'c', 'd']) == ImmutableDict({})
    assert test_dict.difference(['a', 'b', 'c', 'd', 'e'])

# Generated at 2022-06-16 22:17:31.311224
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:17:44.231086
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    assert a == b

    # Test for inequality
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 3})
    assert a != b

    # Test for inequality
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert a != b

    # Test for inequality
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1})
    assert a != b

# Generated at 2022-06-16 22:17:49.844463
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Unit test for method difference of class ImmutableDict
    """
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_subtractive_iterable = ['a', 'c']
    test_result = test_dict.difference(test_subtractive_iterable)
    assert test_result == ImmutableDict({'b': 2})


# Generated at 2022-06-16 22:18:00.723200
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(u'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object)
    assert is_iterable(is_iterable)
    assert is_iterable(test_is_iterable)
    assert is_iterable(xrange(1))
    assert is_iterable(xrange(1, 2))
    assert is_iterable(xrange(1, 2, 3))
    assert is_iter

# Generated at 2022-06-16 22:18:12.053665
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Test the difference method of ImmutableDict
    """
    # Test with a list of keys to remove
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})
    test_list = ['a', 'c', 'e']
    expected_dict = ImmutableDict({'b': 2, 'd': 4})
    assert test_dict.difference(test_list) == expected_dict

    # Test with a dict of keys to remove
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})
    test_dict2 = {'a': 1, 'c': 3, 'e': 5}

# Generated at 2022-06-16 22:18:22.641127
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDicts
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test for inequality of two ImmutableDicts
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test for inequality of an ImmutableDict and a MutableDict
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 2}
    # Test for inequality of an ImmutableDict and a MutableDict
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}
    # Test for inequality of an ImmutableDict

# Generated at 2022-06-16 22:18:26.574426
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    subtractive = ['a', 'b']
    expected = ImmutableDict({'c': 3})
    assert original.difference(subtractive) == expected

# Generated at 2022-06-16 22:18:31.702368
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Test the difference method of ImmutableDict
    """
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_dict_diff = test_dict.difference(['a', 'c'])
    assert test_dict_diff == ImmutableDict({'b': 2})


# Generated at 2022-06-16 22:18:39.598632
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({'a': 1}))

    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_

# Generated at 2022-06-16 22:18:52.010978
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable(set())
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(frozenset())
    assert is_iterable(frozenset([1, 2, 3]))
    assert is_iterable({})
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(())
    assert is_iterable((1, 2, 3))
    assert is_iterable(xrange(0))
    assert is_iterable(xrange(1))
    assert is_iterable(xrange(1, 10))
    assert is_iterable(xrange(1, 10, 2))

# Generated at 2022-06-16 22:19:03.609794
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:19:15.353308
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    d3 = ImmutableDict({'a': 1, 'b': 3})
    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d5 = ImmutableDict({'b': 2, 'a': 1})
    d6 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d7 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    d8 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})

# Generated at 2022-06-16 22:19:23.378708
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({}))
    assert is_iterable(ImmutableDict({'a': 'b'}))

# Generated at 2022-06-16 22:19:35.696697
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({'a': 'b'}))
    assert is_iterable(ImmutableDict({'a': 'b'}).items())

# Generated at 2022-06-16 22:19:45.608614
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(1, 10))
    assert is_iterable(xrange(1, 10))
    assert is_iterable(1)
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(xrange(1, 10)))

# Generated at 2022-06-16 22:19:57.834487
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:20:07.957186
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDicts
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'b': 2, 'a': 1})
    assert d1 == d2

    # Test for equality of an ImmutableDict and a dict
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'b': 2, 'a': 1}
    assert d1 == d2

    # Test for equality of an ImmutableDict and a dict with different order
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'a': 1, 'b': 2}
    assert d1 == d2

    # Test for equality of an ImmutableDict and a dict with different values


# Generated at 2022-06-16 22:20:20.650556
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test case 1:
    # Test case where the two ImmutableDict objects are equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test case 2:
    # Test case where the two ImmutableDict objects are not equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 3})
    assert dict1 != dict2

    # Test case 3:
    # Test case where the two ImmutableDict objects are not equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-16 22:20:32.555699
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(u'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(object())
    assert is_iterable(None)
    assert is_iterable(True)
    assert is_iterable(False)
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(''))
    assert is_

# Generated at 2022-06-16 22:20:45.057967
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object)



# Generated at 2022-06-16 22:20:56.624075
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:21:01.202933
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable((x for x in range(10)))
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert not is_iterable(None)


# Generated at 2022-06-16 22:21:09.765861
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(x for x in range(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(1)
    assert not is_iterable(None)
    assert not is_iterable(object())


# Generated at 2022-06-16 22:21:18.238959
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test case 1:
    #   ImmutableDict({"a": 1, "b": 2}) == ImmutableDict({"a": 1, "b": 2})
    #   Expected result: True
    assert ImmutableDict({"a": 1, "b": 2}) == ImmutableDict({"a": 1, "b": 2})

    # Test case 2:
    #   ImmutableDict({"a": 1, "b": 2}) == ImmutableDict({"a": 1, "b": 3})
    #   Expected result: False
    assert not ImmutableDict({"a": 1, "b": 2}) == ImmutableDict({"a": 1, "b": 3})

    # Test case 3:
    #   Imm

# Generated at 2022-06-16 22:21:29.841644
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:21:41.748830
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of ImmutableDict with itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d1

    # Test equality of ImmutableDict with a copy of itself
    d2 = ImmutableDict(d1)
    assert d1 == d2

    # Test equality of ImmutableDict with a different ImmutableDict with the same keys and values
    d3 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d3

    # Test equality of ImmutableDict with a different ImmutableDict with the same keys and values
    # but in a different order
    d4 = ImmutableDict({'b': 2, 'a': 1})
    assert d1 == d4

    # Test equality of ImmutableDict with a different Imm

# Generated at 2022-06-16 22:21:48.981668
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of ImmutableDict with itself
    d = ImmutableDict({'a': 1, 'b': 2})
    assert d == d

    # Test equality of ImmutableDict with a copy of itself
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d == d2

    # Test equality of ImmutableDict with a different ImmutableDict
    d3 = ImmutableDict({'a': 1, 'b': 3})
    assert d != d3

    # Test equality of ImmutableDict with a different ImmutableDict with the same hash
    d4 = ImmutableDict({'b': 2, 'a': 1})
    assert d == d4

    # Test equality of ImmutableDict with a different ImmutableDict with the same hash
    d5 = ImmutableD

# Generated at 2022-06-16 22:22:01.343118
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    assert a == b

    # Test for inequality
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 3})
    assert a != b

    # Test for inequality
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert a != b

    # Test for inequality
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'c': 2})


# Generated at 2022-06-16 22:22:13.736909
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict
    """
    # Test equality of ImmutableDict instances
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=2, c=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1)
    assert ImmutableDict(a=1, b=2) != ImmutableD

# Generated at 2022-06-16 22:22:27.951187
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    d3 = ImmutableDict({'a': 1, 'b': 3})
    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d5 = ImmutableDict({'b': 2, 'a': 1})
    d6 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d7 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d8 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})

# Generated at 2022-06-16 22:22:39.193636
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(xrange(1))
    assert is_iterable(xrange(2))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(xrange(1)))
    assert is_iterable(iter(xrange(2)))
    assert is_iterable(iter(xrange(3)))
    assert is_iterable(iter(xrange(4)))

# Generated at 2022-06-16 22:22:49.581675
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2})


# Generated at 2022-06-16 22:22:57.703721
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:23:05.761639
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test for equality of two ImmutableDict objects
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test for inequality of two ImmutableDict objects
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    # Test for inequality of an ImmutableDict object and a dict object
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 2}
    # Test for inequality of an ImmutableDict object and a list object
    assert ImmutableDict({'a': 1, 'b': 2}) != ['a', 'b']

# Generated at 2022-06-16 22:23:16.038444
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test __eq__ method of ImmutableDict class.
    """
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    dict3 = ImmutableDict({'a': 1, 'b': 3})
    dict4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict5 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict6 = dict({'a': 1, 'b': 2})
    dict7 = dict({'a': 1, 'b': 2})
    dict8 = dict({'a': 1, 'b': 3})

# Generated at 2022-06-16 22:23:23.007370
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(1))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(1)))
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(True)
    assert not is_iterable(None)
    assert not is_iterable('abc')
    assert not is_iterable(u'abc')
    assert not is_iterable(b'abc')

# Generated at 2022-06-16 22:23:32.779673
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(1, 10))
    assert is_iterable(xrange(1, 10))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(set([1, 2, 3])))
    assert is_iterable(iter(xrange(1, 10)))
    assert is_iterable(iter(range(1, 10)))
    assert is_iterable(iter({'a': 1, 'b': 2}))

# Generated at 2022-06-16 22:23:43.648812
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test __eq__ method of ImmutableDict class.
    """
    # Test case 1:
    # Test case when both ImmutableDict are equal
    d1 = ImmutableDict({"a": 1, "b": 2})
    d2 = ImmutableDict({"a": 1, "b": 2})
    assert d1 == d2

    # Test case 2:
    # Test case when both ImmutableDict are not equal
    d1 = ImmutableDict({"a": 1, "b": 2})
    d2 = ImmutableDict({"a": 1, "b": 3})
    assert not d1 == d2

    # Test case 3:
    # Test case when both ImmutableDict are not equal
    d1 = ImmutableDict({"a": 1, "b": 2})


# Generated at 2022-06-16 22:23:56.216101
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:24:20.640212
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')

# Generated at 2022-06-16 22:24:31.162830
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test __eq__ method of ImmutableDict class"""
    # Test case 1:
    # Two ImmutableDict objects are equal if they have the same key-value pairs
    # and the order of the key-value pairs does not matter
    dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict2 = ImmutableDict({'c': 3, 'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test case 2:
    # Two ImmutableDict objects are not equal if they have different key-value pairs
    dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict2 = ImmutableDict({'c': 3, 'a': 1, 'b': 4})
    assert dict1 != dict2

# Generated at 2022-06-16 22:24:42.658299
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test for method __eq__ of class ImmutableDict
    """
    # Test for equality of two ImmutableDict objects
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test for equality of an ImmutableDict object and a dict object
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = {'a': 1, 'b': 2}
    assert dict1 == dict2

    # Test for equality of an ImmutableDict object and a dict object with different order of keys
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = {'b': 2, 'a': 1}

# Generated at 2022-06-16 22:24:53.570394
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert is_iterable(0)
    assert is_iterable(0.0)
    assert is_iter

# Generated at 2022-06-16 22:25:05.608730
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert not is_iterable(10)
    assert not is_iterable(10.1)
    assert not is_iterable(None)
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable(Exception())
    assert not is_iterable(Exception)
    assert not is_iterable(object())
    assert not is_iterable(object)

# Generated at 2022-06-16 22:25:18.349991
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(xrange(10)))

    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable('abc')
    assert not is_iterable(u'abc')
    assert not is_iterable(b'abc')

    assert is_iterable('abc', include_strings=True)
    assert is_iterable(u'abc', include_strings=True)

# Generated at 2022-06-16 22:25:28.482307
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert not is_iterable(1)
    assert not is_iterable(None)
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable(object())
    assert not is_iterable(object)
    assert not is_iterable(is_iterable)
    assert not is_iterable(Exception)
    assert not is_iterable(Exception())

# Generated at 2022-06-16 22:25:41.258604
# Unit test for method __eq__ of class ImmutableDict

# Generated at 2022-06-16 22:25:48.945335
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test the __eq__ method of ImmutableDict"""
    # Test that two ImmutableDicts with the same key-value pairs are equal
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test that two ImmutableDicts with different key-value pairs are not equal
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2

    # Test that an ImmutableDict is not equal to a MutableMapping with the same key-value pairs
    d1 = ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-16 22:26:01.099006
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 2}

# Generated at 2022-06-16 22:26:37.518908
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1: 'a', 2: 'b', 3: 'c'})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(1, 4))
    assert is_iterable(xrange(1, 4))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter((1, 2, 3)))
    assert is_iterable(iter({1: 'a', 2: 'b', 3: 'c'}))
    assert is_iterable(iter(set([1, 2, 3])))
    assert is_iterable(iter(range(1, 4)))
    assert is_iterable

# Generated at 2022-06-16 22:26:45.665003
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable({'a': 1, 'b': 2, 'c': 3})
    assert is_iterable(range(1, 10))
    assert is_iterable(xrange(1, 10))
    assert is_iterable(1)
    assert not is_iterable('abc')
    assert not is_iterable(u'abc')
    assert not is_iterable(b'abc')


# Generated at 2022-06-16 22:26:55.973386
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality with a dictionary
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

    # Test for equality with an ImmutableDict
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})

    # Test for equality with a different dictionary
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 3}

    # Test for equality with a different ImmutableDict
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})

    # Test for equality with a different dictionary
    assert ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-16 22:27:03.351916
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'b': 2, 'a': 1})
    assert a == b

    # Test for inequality
    c = ImmutableDict({'a': 1, 'b': 3})
    assert a != c

    # Test for inequality with a non-ImmutableDict
    d = {'a': 1, 'b': 2}
    assert a != d

    # Test for equality with a non-ImmutableDict
    e = ImmutableDict({'a': 1, 'b': 2})
    assert e == d


# Generated at 2022-06-16 22:27:15.262735
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test for equality of two ImmutableDicts
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test for equality of an ImmutableDict and a dict
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test for equality of an ImmutableDict and a dict with different order of keys
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}
    # Test for equality of an ImmutableDict and a dict with different values