

# Generated at 2022-06-16 22:17:25.488652
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of ImmutableDict with itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d1

    # Test for equality of ImmutableDict with a copy of itself
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test for equality of ImmutableDict with a different ImmutableDict
    d3 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 != d3

    # Test for equality of ImmutableDict with a different ImmutableDict
    d4 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d4

    # Test for equality of ImmutableDict with a different ImmutableDict

# Generated at 2022-06-16 22:17:32.204466
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Test that ImmutableDict.difference() returns a new ImmutableDict with the keys
    from the subtractive_iterable removed.
    """
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    subtractive_iterable = ['a', 'c']
    expected = ImmutableDict({'b': 2})
    assert original.difference(subtractive_iterable) == expected


# Generated at 2022-06-16 22:17:44.908198
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test equality of two ImmutableDict objects
    test_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    test_dict_2 = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict_1 == test_dict_2

    # Test equality of two ImmutableDict objects with different order of keys
    test_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    test_dict_2 = ImmutableDict({'b': 2, 'a': 1})
    assert test_dict_1 == test_dict_2

    # Test equality of ImmutableDict and dict

# Generated at 2022-06-16 22:17:56.578686
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert not is_iterable(None)
    assert not is_iterable(10)
    assert not is_iterable(10.2)
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable(object())
    assert not is_iterable(object)
    assert not is_iterable(Exception())

# Generated at 2022-06-16 22:18:09.682928
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:18:15.692221
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(text_type())
    assert is_iterable(binary_type())
    assert is_iterable(text_type(''))
    assert is_iterable(binary_type(''))

# Generated at 2022-06-16 22:18:24.844966
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # Test case 1: subtractive_iterable is a list
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    subtractive_iterable = ['a', 'b']
    expected = ImmutableDict({'c': 3})
    assert original.difference(subtractive_iterable) == expected

    # Test case 2: subtractive_iterable is a tuple
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    subtractive_iterable = ('a', 'b')
    expected = ImmutableDict({'c': 3})
    assert original.difference(subtractive_iterable) == expected

    # Test case 3: subtractive_iterable is a set

# Generated at 2022-06-16 22:18:34.702225
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict(a=1, b=2, c=3)
    assert original.difference(['a', 'b']) == ImmutableDict(c=3)
    assert original.difference(['a', 'b', 'c']) == ImmutableDict()
    assert original.difference(['a', 'b', 'c', 'd']) == ImmutableDict()
    assert original.difference(['d']) == ImmutableDict(a=1, b=2, c=3)
    assert original.difference([]) == ImmutableDict(a=1, b=2, c=3)



# Generated at 2022-06-16 22:18:44.778352
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(tuple())
    assert is_iterable(xrange(0))
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(object())
    assert not is_iterable(object)
    assert not is_iterable(test_is_iterable)
    assert not is_iterable(test_is_iterable())
    assert is_iterable(test_is_iterable, include_strings=True)
    assert is_iter

# Generated at 2022-06-16 22:18:53.469686
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:19:06.725274
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(1))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(1)))
    assert is_iterable(1) is False
    assert is_iterable(1.0) is False
    assert is_iterable(None) is False
    assert is_iterable(True) is False
    assert is_iterable(False) is False
    assert is_iterable(object()) is False
    assert is_iterable(object) is False

# Generated at 2022-06-16 22:19:13.734707
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(tuple())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(u'')
    assert not is_iterable(1)
    assert not is_iterable(None)


# Generated at 2022-06-16 22:19:22.864124
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:19:35.366009
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test case 1:
    #   - ImmutableDict with same key-value pairs
    #   - ImmutableDict with same key-value pairs
    #   - Expected result: True
    test_dict_1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    test_dict_2 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert test_dict_1 == test_dict_2

    # Test case 2:
    #   - ImmutableDict with same key-value pairs
    #   - ImmutableDict with different key-value pairs
    #   - Expected result: False

# Generated at 2022-06-16 22:19:45.170149
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable('a')
    assert is_iterable(u'a')
    assert is_iterable(b'a')

# Generated at 2022-06-16 22:19:57.328554
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(xrange(1, 10))
    assert is_iterable(xrange(1, 10))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(xrange(1, 10)))
    assert is_iterable(iter(xrange(1, 10)))
    assert is_iterable(iter(xrange(1, 10)))
    assert is_iterable(iter(xrange(1, 10)))

# Generated at 2022-06-16 22:20:07.666047
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object, include_strings=True)
    assert not is_iterable(object)
    assert not is_iterable(object, include_strings=False)
    assert is_iterable(object, include_strings=True)
    assert is_iterable(object, include_strings=False)

# Generated at 2022-06-16 22:20:20.504924
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)

# Generated at 2022-06-16 22:20:24.952598
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__() works as expected
    """
    # Test that ImmutableDict.__eq__() returns True when comparing two equal ImmutableDicts
    test_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    test_dict_2 = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict_1 == test_dict_2

    # Test that ImmutableDict.__eq__() returns False when comparing two unequal ImmutableDicts
    test_dict_3 = ImmutableDict({'a': 1, 'b': 2})
    test_dict_4 = ImmutableDict({'a': 1, 'b': 3})
    assert test_dict_3 != test_dict_4

    # Test that ImmutableDict.

# Generated at 2022-06-16 22:20:35.830283
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test that ImmutableDict is equal to itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d1

    # Test that ImmutableDict is equal to a dictionary with the same key-value pairs
    d2 = {'a': 1, 'b': 2}
    assert d1 == d2

    # Test that ImmutableDict is not equal to a dictionary with different key-value pairs
    d3 = {'a': 1, 'b': 3}
    assert d1 != d3

    # Test that ImmutableDict is not equal to a dictionary with different keys
    d4 = {'a': 1, 'c': 2}
    assert d1 != d4

    # Test that ImmutableDict is not equal to a dictionary with different values

# Generated at 2022-06-16 22:20:50.571551
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(5) is False
    assert is_iterable(None) is False
    assert is_iterable(Exception) is False
    assert is_iterable(Exception()) is False
    assert is_iterable(Exception('test')) is False
    assert is_iterable(Exception('test'), include_strings=True) is False



# Generated at 2022-06-16 22:20:59.461227
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    assert a == b

    # Test for inequality
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 3})
    assert a != b

    # Test for inequality
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert a != b

    # Test for inequality
    a = ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-16 22:21:10.881723
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1, 2, 3})
    assert is_iterable({1: 'a', 2: 'b', 3: 'c'})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(frozenset([1, 2, 3]))
    assert is_iterable(xrange(1, 4))
    assert is_iterable(xrange(1, 4), include_strings=True)
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter((1, 2, 3)))
    assert is_iterable(iter({1, 2, 3}))

# Generated at 2022-06-16 22:21:19.129892
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(tuple())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(dict()))
    assert is_iterable(iter(tuple()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(set())))
    assert is_iterable(iter(iter(dict())))

# Generated at 2022-06-16 22:21:30.727468
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of ImmutableDict with itself
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test for equality of ImmutableDict with a dict
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # Test for equality of ImmutableDict with a list
    assert ImmutableDict({'a': 1, 'b': 2}) != ['a', 'b']
    # Test for equality of ImmutableDict with a tuple
    assert ImmutableDict({'a': 1, 'b': 2}) != ('a', 'b')
    # Test for equality of ImmutableDict with a set

# Generated at 2022-06-16 22:21:42.537060
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:21:53.116482
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDicts
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test for equality of two ImmutableDicts with different order of keys
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'b': 2, 'a': 1})
    assert dict1 == dict2

    # Test for equality of two ImmutableDicts with different values
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 3})
    assert not dict1 == dict2

    # Test for equality of two ImmutableD

# Generated at 2022-06-16 22:22:04.338228
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(tuple())
    assert is_iterable(xrange(0))
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(u'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert is_iterable(object())
    assert not is_iterable(set(), include_strings=True)
    assert not is_iterable(dict(), include_strings=True)
    assert not is_iterable(tuple(), include_strings=True)
    assert not is_iterable(xrange(0), include_strings=True)


# Generated at 2022-06-16 22:22:17.006348
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test for method __eq__ of class ImmutableDict.
    """
    # Test for equality of two ImmutableDict objects
    test_dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_dict2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert test_dict1 == test_dict2

    # Test for equality of an ImmutableDict object and a dict object
    test_dict3 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_dict4 = {'a': 1, 'b': 2, 'c': 3}
    assert test_dict3 == test_dict4

    # Test for equality of an ImmutableDict object and a list object
    test_

# Generated at 2022-06-16 22:22:23.994723
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    d3 = ImmutableDict({'a': 1, 'b': 3})
    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d5 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d6 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    d7 = ImmutableDict({'a': 1, 'b': 2, 'c': 4, 'd': 5})
    d8 = ImmutableDict({'a': 1, 'b': 2, 'c': 4, 'd': 5})

# Generated at 2022-06-16 22:22:41.491476
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(3))
    assert is_iterable(xrange(3))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(xrange(3)))
    assert is_iterable(iter(range(3)))
    assert is_iterable(iter(set([1, 2, 3])))
    assert is_iterable(iter({'a': 1, 'b': 2}))
    assert is_iterable(iter((1, 2, 3)))

# Generated at 2022-06-16 22:22:51.190560
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable(('a', 'b', 'c'))
    assert is_iterable(set(['a', 'b', 'c']))
    assert is_iterable(dict(a=1, b=2, c=3))
    assert is_iterable(range(3))
    assert is_iterable(xrange(3))
    assert is_iterable(iter(['a', 'b', 'c']))
    assert is_iterable(iter(('a', 'b', 'c')))
    assert is_iterable(iter(set(['a', 'b', 'c'])))
    assert is_iterable(iter(dict(a=1, b=2, c=3)))

# Generated at 2022-06-16 22:23:00.950498
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test equality of two ImmutableDict objects
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test equality of ImmutableDict and dict
    dict3 = {'a': 1, 'b': 2}
    assert dict1 == dict3

    # Test equality of ImmutableDict and other object
    assert dict1 != 'dict1'

    # Test equality of ImmutableDict and ImmutableDict with different order
    dict4 = ImmutableDict({'b': 2, 'a': 1})
    assert dict1 == dict4

    # Test equality of ImmutableDict and ImmutableDict with

# Generated at 2022-06-16 22:23:13.334160
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(1))
    assert is_iterable(xrange(1))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(1)))
    assert is_iterable(iter(xrange(1)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:23:25.502129
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDicts
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    assert a == b

    # Test for equality of an ImmutableDict and a dict
    a = ImmutableDict({'a': 1, 'b': 2})
    b = {'a': 1, 'b': 2}
    assert a == b

    # Test for equality of an ImmutableDict and a dict with different order
    a = ImmutableDict({'a': 1, 'b': 2})
    b = {'b': 2, 'a': 1}
    assert a == b

    # Test for equality of an ImmutableDict and a dict with different values

# Generated at 2022-06-16 22:23:36.639957
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test case 1:
    # Test that two ImmutableDict objects with the same key-value pairs are equal
    # Expected result: True
    immutable_dict_1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    immutable_dict_2 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert immutable_dict_1 == immutable_dict_2

    # Test case 2:
    # Test that two ImmutableDict objects with the same key-value pairs but different order are equal
    # Expected result: True
    immutable_dict_1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    immutable_

# Generated at 2022-06-16 22:23:46.271184
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDict instances
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test for equality of ImmutableDict instance and a dict
    d3 = {'a': 1, 'b': 2}
    assert d1 == d3

    # Test for equality of ImmutableDict instance and a set
    d4 = {'a', 'b'}
    assert d1 != d4

    # Test for equality of ImmutableDict instance and a list
    d5 = [1, 2]
    assert d1 != d5

    # Test for equality of ImmutableDict instance and a string
    d6 = 'ab'
    assert d1 != d6

# Generated at 2022-06-16 22:23:58.732964
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:24:08.773232
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test if two ImmutableDict objects are equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test if two ImmutableDict objects are not equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 3})
    assert dict1 != dict2

    # Test if two ImmutableDict objects are not equal
    dict1 = ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-16 22:24:19.959989
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(frozenset())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(ImmutableDict())
    assert is_iterable(object()) is False
    assert is_iterable(None) is False
    assert is_iterable(10) is False
    assert is_iterable(10.0) is False
    assert is_iterable(True) is False
    assert is_iterable(False) is False
    assert is_iterable(u'abc', include_strings=True)
   

# Generated at 2022-06-16 22:24:42.800707
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1: 2, 3: 4})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(1, 3))
    assert is_iterable(xrange(1, 3))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter((1, 2, 3)))
    assert is_iterable(iter({1: 2, 3: 4}))
    assert is_iterable(iter(set([1, 2, 3])))
    assert is_iterable(iter(range(1, 3)))
    assert is_iterable(iter(xrange(1, 3)))
    assert is_iter

# Generated at 2022-06-16 22:24:53.706117
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:25:05.705273
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test that ImmutableDict is equal to itself
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d1

    # Test that ImmutableDict is equal to a dict with the same key-value pairs
    d2 = {'a': 1, 'b': 2}
    assert d1 == d2

    # Test that ImmutableDict is not equal to a dict with different key-value pairs
    d3 = {'a': 1, 'b': 3}
    assert d1 != d3

    # Test that ImmutableDict is not equal to a dict with different keys
    d4 = {'a': 1, 'c': 2}
    assert d1 != d4

    # Test that ImmutableDict is not equal to a dict with different values

# Generated at 2022-06-16 22:25:18.447308
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test case 1:
    # Two ImmutableDict objects are equal if they have the same key-value pairs
    # regardless of the order of the key-value pairs
    dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert dict1 == dict2

    # Test case 2:
    # Two ImmutableDict objects are not equal if they have different key-value pairs
    dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict2 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    assert dict1 != dict2

    # Test case 3:
    # Two ImmutableDict objects are

# Generated at 2022-06-16 22:25:24.050993
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:25:31.674668
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-16 22:25:43.238575
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:25:55.173058
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:26:05.302460
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    d3 = ImmutableDict({'a': 1, 'b': 3})
    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 == d2
    assert d1 != d3
    assert d1 != d4
    assert d1 != {'a': 1, 'b': 2}
    assert d1 != {'a': 1, 'b': 2, 'c': 3}
    assert d1 != {'a': 1, 'b': 3}


# Generated at 2022-06-16 22:26:14.583416
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(tuple())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(dict()))
    assert is_iterable(iter(tuple()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(set())))
    assert is_iterable(iter(iter(dict())))

# Generated at 2022-06-16 22:26:45.247295
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert not is_iterable(None)
    assert not is_iterable(10)
    assert not is_iterable(10.1)
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable(object())



# Generated at 2022-06-16 22:26:55.552353
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(1, 10))
    assert is_iterable(xrange(1, 10))
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(True)
    assert is_iterable(None)
    assert is_iterable('abc')
    assert is_iterable(b'abc')
    assert is_iterable(u'abc')
    assert is_iterable(bytearray(b'abc'))

# Generated at 2022-06-16 22:27:04.135856
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(u''))
    assert is_iterable(iter(bytearray()))
    assert is_iter

# Generated at 2022-06-16 22:27:15.468125
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test 1:
    # Two ImmutableDict objects are equal if they have the same key-value pairs
    # regardless of the order of the key-value pairs
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})

    # Test 2:
    # Two ImmutableDict objects are not equal if they have different key-value pairs
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})

    # Test 3:
    # Two ImmutableDict objects are not equal if they have different keys
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})

    # Test 4:
    # Two