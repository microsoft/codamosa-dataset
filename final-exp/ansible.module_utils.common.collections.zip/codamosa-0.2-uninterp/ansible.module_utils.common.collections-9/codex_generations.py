

# Generated at 2022-06-16 22:17:19.024631
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test for equality of ImmutableDict instances
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test for equality of ImmutableDict instance and dict instance
    d3 = {'a': 1, 'b': 2}
    assert d1 == d3

    # Test for equality of ImmutableDict instance and OrderedDict instance
    try:
        from collections import OrderedDict
    except ImportError:
        pass
    else:
        d4 = OrderedDict({'a': 1, 'b': 2})
        assert d1 == d4

    # Test for inequality of ImmutableDict instances

# Generated at 2022-06-16 22:17:23.285691
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(5) is False
    assert is_iterable(None) is False
    assert is_iterable('abc') is False
    assert is_iterable(u'abc') is False
    assert is_iterable(b'abc') is False
    assert is_iterable(bytearray(b'abc')) is False
    assert is_iterable(5, include_strings=True) is False
    assert is_iterable(None, include_strings=True) is False

# Generated at 2022-06-16 22:17:33.996752
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(tuple())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(dict()))
    assert is_iterable(iter(tuple()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(1) is False
    assert is_iterable(1.0) is False
    assert is_iterable(object()) is False
    assert is_iterable(object) is False

# Generated at 2022-06-16 22:17:45.693337
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(5))
    assert is_iterable(xrange(5))
    assert is_iterable(iter(range(5)))
    assert is_iterable(5) is False
    assert is_iterable('abc') is False
    assert is_iterable(u'abc') is False
    assert is_iterable(b'abc') is False
    assert is_iterable(bytearray(b'abc'))
    assert is_iterable(iter(b'abc'))
    assert is_iterable(iter(bytearray(b'abc')))



# Generated at 2022-06-16 22:17:57.773247
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable(())
    assert is_iterable((1, 2, 3))
    assert is_iterable({})
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set())
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(xrange(10))
    assert is_iterable(xrange(1, 10))
    assert is_iterable(xrange(1, 10, 2))
    assert is_iterable(iter([]))
    assert is_iterable(iter([1, 2, 3]))
    assert is_iterable(iter(()))

# Generated at 2022-06-16 22:18:10.084292
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test case 1:
    # Two ImmutableDict objects are equal if they have the same key-value pairs
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    # Test case 2:
    # Two ImmutableDict objects are not equal if they have different key-value pairs
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d2

    # Test case 3:
    # Two ImmutableDict objects are not equal if they have different keys
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = Imm

# Generated at 2022-06-16 22:18:15.785712
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-16 22:18:24.876676
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1, 2, 3})
    assert is_iterable({1: 2, 3: 4})
    assert is_iterable(range(10))
    assert is_iterable(x for x in range(10))
    assert not is_iterable(1)
    assert not is_iterable(None)
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable(object())
    assert not is_iterable(object)
    assert is_iterable('abc')
    assert is_iterable(b'abc')
    assert is_iterable(u'abc')

# Generated at 2022-06-16 22:18:37.099092
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(tuple())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(dict()))
    assert is_iterable(iter(tuple()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(set())))
    assert is_iterable(iter(iter(dict())))

# Generated at 2022-06-16 22:18:47.249157
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)
    assert not is_iterable(object())
    assert not is_iterable(object)
    assert not is_

# Generated at 2022-06-16 22:19:03.196981
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test case 1:
    # Two ImmutableDict objects with the same key-value pairs are equal
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'b': 2, 'a': 1})
    assert a == b

    # Test case 2:
    # Two ImmutableDict objects with different key-value pairs are not equal
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'b': 2, 'a': 2})
    assert a != b

    # Test case 3:
    # An ImmutableDict object is not equal to a non-ImmutableDict object
    a = ImmutableDict({'a': 1, 'b': 2})
    b = {'b': 2, 'a': 1}

# Generated at 2022-06-16 22:19:10.399211
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:19:21.430544
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test case 1:
    #   Input:
    #       ImmutableDict1 = ImmutableDict({'a': 1, 'b': 2})
    #       ImmutableDict2 = ImmutableDict({'a': 1, 'b': 2})
    #   Expected output:
    #       True
    ImmutableDict1 = ImmutableDict({'a': 1, 'b': 2})
    ImmutableDict2 = ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict1 == ImmutableDict2

    # Test case 2:
    #   Input:
    #       ImmutableDict1 = ImmutableDict({'a': 1, 'b': 2})
    #       ImmutableDict2

# Generated at 2022-06-16 22:19:34.352352
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(u''))
    assert is_iterable(iter(bytearray(b'')))
    assert is_iterable(iter(memoryview(b'')))
    assert is_iterable(iter(range(0)))

# Generated at 2022-06-16 22:19:44.226000
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert not ImmutableDict({'a': 1}) == ImmutableDict({'a': 2})
    assert not ImmutableDict({'a': 1}) == ImmutableDict({'b': 1})
    assert not ImmutableDict({'a': 1}) == ImmutableDict({'a': 1, 'b': 2})
    assert not ImmutableDict({'a': 1}) == ImmutableDict({'b': 2, 'a': 1})
    assert not ImmutableDict({'a': 1}) == ImmutableDict({'b': 1, 'c': 2})
    assert not ImmutableDict({'a': 1}) == ImmutableDict({'b': 2, 'c': 3})
    assert not Immutable

# Generated at 2022-06-16 22:19:55.949089
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({}))
    assert is_iterable(ImmutableDict(a=1))
    assert is_iterable(ImmutableDict(a=1, b=2))

# Generated at 2022-06-16 22:20:06.860269
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({})
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object)
    assert is_iterable(is_iterable)
    assert is_iterable(is_iterable([]))
    assert is_iterable(is_iterable([]), include_strings=True)


# Generated at 2022-06-16 22:20:19.915704
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__ returns True when comparing two ImmutableDicts with the same keys and values
    and returns False when comparing two ImmutableDicts with different keys or values
    """
    # Test that ImmutableDict.__eq__ returns True when comparing two ImmutableDicts with the same keys and values
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-16 22:20:31.891765
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test with two ImmutableDict objects
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    assert a == b

    # Test with two ImmutableDict objects with different keys
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'c': 2})
    assert a != b

    # Test with two ImmutableDict objects with different values
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 3})
    assert a != b

    # Test with an ImmutableDict and a dict

# Generated at 2022-06-16 22:20:40.802927
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    c = ImmutableDict({'a': 1, 'b': 3})
    d = ImmutableDict({'a': 1})
    e = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    f = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    g = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})
    h = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6})
    i

# Generated at 2022-06-16 22:20:57.411613
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(())
    assert is_iterable(xrange(0))
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(None)
    assert is_iterable(object())
    assert not is_iterable(object, include_strings=True)
    assert not is_iterable(object, include_strings=False)


# Generated at 2022-06-16 22:21:04.943360
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(1) is False
    assert is_iterable(None) is False


# Generated at 2022-06-16 22:21:14.414788
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != {'b': 2, 'a': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1, 'c': 3})

# Generated at 2022-06-16 22:21:24.014278
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    d3 = ImmutableDict({'a': 1, 'b': 3})
    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d5 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d6 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d7 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})

# Generated at 2022-06-16 22:21:32.629582
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict
    """
    # Test for equality
    immutable_dict_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    immutable_dict_2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert immutable_dict_1 == immutable_dict_2

    # Test for inequality
    immutable_dict_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    immutable_dict_2 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    assert immutable_dict_1 != immutable_dict_2

    # Test for inequality

# Generated at 2022-06-16 22:21:44.086600
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(None) is False
    assert is_iterable(1) is False
    assert is_iterable(1.0) is False
    assert is_iterable(True) is False
    assert is_iterable(b'abc') is False
    assert is_iterable(u'abc') is False
    assert is_iterable(u'abc'.encode('utf-8')) is False
    assert is_iterable(u'abc'.encode('utf-8'), include_strings=True) is True
    assert is_iterable(u'abc', include_strings=True) is True
    assert is_iterable(u'abc') is False
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable((1, 2, 3)) is True
    assert is_iterable

# Generated at 2022-06-16 22:21:52.732558
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(1) is False
    assert is_iterable(None) is False
    assert is_iterable(object()) is False



# Generated at 2022-06-16 22:22:04.067281
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(1.0)

# Generated at 2022-06-16 22:22:16.687674
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(text_type())
    assert is_iterable(binary_type())
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable(object())
    assert not is_iterable(object)
    assert not is_iterable(Exception)

# Generated at 2022-06-16 22:22:27.577737
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDict objects with the same key-value pairs
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    # Test for equality of two ImmutableDict objects with the same key-value pairs in different order
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    # Test for equality of two ImmutableDict objects with the same key-value pairs and different types
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2.0, 'a': 1})
    # Test for equality of two ImmutableDict objects with the same key-value pairs and different types
    assert ImmutableDict

# Generated at 2022-06-16 22:22:52.699289
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-16 22:22:59.930384
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__() returns True when the hashes of the two dictionaries are equal
    and False when they are not.
    """
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    dict3 = ImmutableDict({'a': 1, 'b': 3})
    dict4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict5 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict6 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})

    assert dict1 == dict2
    assert dict1 != dict3
    assert dict1 != dict4


# Generated at 2022-06-16 22:23:09.671440
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(u'abc'.encode('utf-8'))
    assert is_iterable(1) is False
    assert is_iterable(None) is False



# Generated at 2022-06-16 22:23:20.670895
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Test case 1:
    #   - ImmutableDict1 = {'a': 1, 'b': 2}
    #   - ImmutableDict2 = {'a': 1, 'b': 2}
    #   - ImmutableDict3 = {'a': 1, 'b': 3}
    #   - ImmutableDict4 = {'a': 1, 'b': 2, 'c': 3}
    #   - ImmutableDict5 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    #   - ImmutableDict6 = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    #   - ImmutableDict7 = {'a

# Generated at 2022-06-16 22:23:29.821406
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter(range(10)))
    assert is_iterable(5) is False
    assert is_iterable('abc') is False
    assert is_iterable(u'abc') is False
    assert is_iterable(b'abc') is False
    assert is_iterable(bytearray(b'abc')) is False
    assert is_iterable(None) is False
    assert is_iterable(Exception()) is False
    assert is_iterable(Exception) is False
    assert is_iterable(Exception('abc')) is False


# Generated at 2022-06-16 22:23:41.656587
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != {'a': 1}
    assert ImmutableDict({'a': 1}) != {'a': 1, 'b': 2}


# Generated at 2022-06-16 22:23:48.657303
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test 1: Test equality of two ImmutableDict objects with same key-value pairs
    test_dict_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_dict_2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert test_dict_1 == test_dict_2

    # Test 2: Test equality of two ImmutableDict objects with different key-value pairs
    test_dict_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_dict_2 = ImmutableDict({'a': 1, 'b': 2, 'd': 3})
    assert test_dict_1 != test_dict_

# Generated at 2022-06-16 22:24:01.594419
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(1))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(1)))
    assert is_iterable(1) is False
    assert is_iterable(1.0) is False
    assert is_iterable('abc') is False
    assert is_iterable(u'abc') is False
    assert is_iterable(b'abc') is False
    assert is_iterable(bytearray(b'abc')) is False

# Generated at 2022-06-16 22:24:08.764886
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(iter(iter([])))
    assert is_iterable(iter(iter(())))
    assert is_iterable(iter(iter({})))
    assert is_iterable(iter(iter(set())))

# Generated at 2022-06-16 22:24:19.960433
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(object())
    assert is_iterable(object)
    assert is_iterable(is_iterable)
    assert is_iterable(test_is_iterable)
    assert is_iterable(Exception)
    assert is_iterable(Exception())
    assert is_iterable(Exception('test'))
    assert is_iterable(Exception('test', 'test'))

# Generated at 2022-06-16 22:25:05.264401
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(u'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(True)
    assert is_iterable(False)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object)
    assert is_iterable(is_iterable)
    assert is_iterable(test_is_iterable)
    assert is_iterable(test_is_iterable())
    assert is_iterable(lambda: None)

# Generated at 2022-06-16 22:25:17.923619
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(1j)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object)
    assert is_iterable(Exception())
    assert is_iterable(Exception)

# Generated at 2022-06-16 22:25:28.150312
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality of two ImmutableDicts
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)
    # Test for equality of an ImmutableDict and a dict
    assert ImmutableDict(a=1, b=2) == {'a': 1, 'b': 2}
    # Test for equality of an ImmutableDict and a list
    assert ImmutableDict(a=1, b=2) == [('a', 1), ('b', 2)]
    # Test for equality of an ImmutableDict and a tuple
    assert ImmutableDict(a=1, b=2) == (('a', 1), ('b', 2))
    # Test for equality of an ImmutableDict and a set

# Generated at 2022-06-16 22:25:40.925723
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(''))
    assert is_iterable(iter(b''))
    assert is_iterable(iter(range(0)))
    assert is_iterable(iter(xrange(0)))
    assert not is_iterable(None)

# Generated at 2022-06-16 22:25:52.567488
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test __eq__ method of ImmutableDict class"""
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) != Imm

# Generated at 2022-06-16 22:26:02.716685
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict()
    assert ImmutableDict({'a': 1}) != {'a': 1}
    assert ImmutableDict({'a': 1}) != 1


# Generated at 2022-06-16 22:26:12.842811
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__ of class ImmutableDict
    """
    # Test equality of two ImmutableDict instances
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    # Test equality of ImmutableDict instance and dict
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = {'a': 1, 'b': 2}
    assert dict1 == dict2

    # Test equality of ImmutableDict instance and dict with different order
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = {'b': 2, 'a': 1}
    assert dict1 == dict2

    # Test

# Generated at 2022-06-16 22:26:24.711228
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert is_iterable(iter([]))
    assert is_iterable(iter(()))
    assert is_iterable(iter({}))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(xrange(0)))
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(object())
    assert not is_iterable(None)
    assert not is_iterable(NotImplemented)


# Generated at 2022-06-16 22:26:29.267953
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert is_iterable(1)
    assert is_iterable(1.0)
    assert is_iterable(True)
    assert is_iterable(False)
    assert is_iterable(None)
    assert is_iterable(object())
    assert is_iterable(object)
    assert is_iterable(is_iterable)
    assert is_iterable(test_is_iterable)
    assert is_iterable(lambda: None)
    assert is_iterable(xrange(10))
    assert is_iter

# Generated at 2022-06-16 22:26:38.713249
# Unit test for method __eq__ of class ImmutableDict