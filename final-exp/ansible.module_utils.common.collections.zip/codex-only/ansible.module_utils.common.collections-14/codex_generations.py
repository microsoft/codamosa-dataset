

# Generated at 2022-06-22 21:20:07.596541
# Unit test for function is_string
def test_is_string():
    assert not is_string([])
    assert not is_string(set())
    assert not is_string({})
    assert not is_string(dict())
    assert not is_string(tuple())
    assert is_string('foo')
    assert is_string(u'foo')
    assert is_string(u'\u5f7c')
    assert is_string(u'')
    assert is_string('')
    assert is_string(b'foo')
    assert is_string(b'')
    assert is_string(1)
    # Test attribute defined by AnsibleVaultEncryptedUnicode class
    class Encr(object):
        __ENCRYPTED__ = True
    assert is_string(Encr())
    assert is_string(Encr())



# Generated at 2022-06-22 21:20:10.872519
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict(dict(a=1, b=2, c=3))

    assert d['a'] == 1
    assert d['b'] == 2
    assert d['c'] == 3



# Generated at 2022-06-22 21:20:15.214363
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """Unit test for method __len__ of class ImmutableDict"""
    # Verify that Instance of Class ImmutableDict has length 2
    idict = ImmutableDict({'a': 1, 'b': 2})
    assert len(idict) == 2


# Generated at 2022-06-22 21:20:20.206882
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """
    ImmutableDict should be hashable in Python 2.6 (issue #26114)
    """
    # In Python 2.6 hashable equals immutable
    # https://docs.python.org/2/glossary.html#term-immutable
    hash(ImmutableDict())

# Generated at 2022-06-22 21:20:27.489591
# Unit test for function count
def test_count():
    assert count([]) == {}
    assert count([2]) == {2: 1}
    assert count([2, 4]) == {2: 1, 4:1}
    assert count((2, 4)) == {2: 1, 4:1}
    assert count([2, 4, 2]) == {2: 2, 4:1}
    assert count([2, 4, 2, 4, 1, 4, 8]) == {2: 2, 4:3, 1:1, 8:1}
    assert count([]) != {5:5}
    assert count((2, 4, 2, 4, 1, 4, 8)) == {2: 2, 4:3, 1:1, 8:1}


# Generated at 2022-06-22 21:20:37.034028
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1])
    assert is_iterable({1, 2})
    assert is_iterable((1,))
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(range(1))

    assert not is_iterable("string")
    assert not is_iterable("string" * 10)
    assert not is_iterable("1")
    assert not is_iterable("")
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable(None)


# Generated at 2022-06-22 21:20:47.018369
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    from pytest import raises

    # setup
    test_dict = dict(a=1, b=2, c=3)
    input_dict = ImmutableDict(test_dict)

    # test
    expected_repr = 'ImmutableDict({0})'.format(repr(test_dict))
    assert repr(input_dict) == expected_repr

    # -------------------------------------------------------------------------
    # test with unprintable characters

    # setup
    input_dict = dict(chr(i) for i in range(256))
    test_dict = ImmutableDict(input_dict)

    # test
    expected_repr = 'ImmutableDict({0})'.format(repr(input_dict))
    assert repr(test_dict) == expected_repr



# Generated at 2022-06-22 21:20:54.719985
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():

    assert ImmutableDict(a=1, b=2, c=3)['a'] == 1
    assert ImmutableDict(a=1, b=2, c=3)['b'] == 2
    assert ImmutableDict(a=1, b=2, c=3)['c'] == 3
    assert ImmutableDict(a=1, b=2, c=3)['z'] == None  # noqa: E711


# Generated at 2022-06-22 21:21:03.548574
# Unit test for function is_iterable
def test_is_iterable():

    class Iterable(object):
        def __iter__(self):
            return iter(())

    class NotIterable(object):
        pass

    class NotIterableString(Sequence):
        def __getitem__(self, i):
            return "not an iterable"

    iterable = Iterable()
    not_iterable = NotIterable()
    not_iterable_string = NotIterableString()

    assert is_iterable(iterable)
    assert not is_iterable(not_iterable)
    assert not is_iterable(not_iterable_string)


# Generated at 2022-06-22 21:21:07.621439
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    original = dict(a='a', b='b', c='c')
    immut = ImmutableDict(original)

    for key in original:
        assert key in immut
        assert original[key] == immut[key]
    else:
        assert 'd' not in immut



# Generated at 2022-06-22 21:21:14.704510
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    immutable_dict = ImmutableDict({'a': "b"})
    print("immutable_dict.__hash__()", immutable_dict.__hash__())
    immutable_dict_1 = immutable_dict.union({'c': "d"})
    print("immutable_dict_1.__hash__()", immutable_dict_1.__hash__())
    immutable_dict_2 = immutable_dict.union({'a': "e"})
    print("immutable_dict_2.__hash__()", immutable_dict_2.__hash__())
    immutable_dict_3 = immutable_dict.difference(("a", ))
    print("immutable_dict_3.__hash__()", immutable_dict_3.__hash__())

# Generated at 2022-06-22 21:21:20.161453
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    # test that the representation of the ImmutableDict looks as expected
    reps = ['ImmutableDict(dict_values([1, 2, 3]))', 'ImmutableDict(dict_values([4, 5, 6]))']
    for r in reps:
        assert repr(ImmutableDict(dict(zip(range(3), range(1, 4))))) == r

# Generated at 2022-06-22 21:21:24.172677
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Unit test for method __hash__ of class ImmutableDict"""
    d = ImmutableDict(a=1, b=2)
    assert d.__hash__() == hash(frozenset(d.items()))


# Generated at 2022-06-22 21:21:33.204213
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    data_equal = {
        'a': 'a',
        'b': 'b'
    }

    data_unequal = {
        'a': 'a',
        'b': 'B',
    }

    d1 = ImmutableDict(data_equal)
    d2 = ImmutableDict(data_unequal)

    assert hash(d1) == hash(d1)
    assert hash(d2) == hash(d2)
    assert hash(d1) != hash(d2)

    # test when we got instance of class ImmutableDict(A) and ImmutableDict(B)
    # assert hash(A) == hash(B) and hash(A) != hash(A)

# Generated at 2022-06-22 21:21:41.678380
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(list())
    assert is_iterable(dict())
    assert is_iterable(tuple())
    assert is_iterable(set())
    assert is_iterable((i for i in range(10)))
    assert is_iterable(range(10))
    assert is_iterable(dict(a=1, b=2))
    assert is_iterable(ImmutableDict(a=1, b=2))
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable('abc')
    assert is_iterable('abc', True)


# Generated at 2022-06-22 21:21:53.470107
# Unit test for function is_iterable
def test_is_iterable():
    class TestClass():
        def __init__(self, arg):
            self.arg = arg

        def __iter__(self):
            yield self.arg

        def __nonzero__(self):
            return False

    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(())
    assert is_iterable({'key': 'value'}.keys())
    assert is_iterable({'key': 'value'}.values())
    assert is_iterable({'key': 'value'}.items())
    assert is_iterable({'key': 'value'}.iterkeys())
    assert is_iterable({'key': 'value'}.itervalues())
    assert is_iterable({'key': 'value'}.iteritems())
    assert is_iterable(xrange(10))

# Generated at 2022-06-22 21:22:05.838166
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    """Unit test for method __getitem__ of class ImmutableDict

    :return: None
    """
    from copy import copy
    from nose.tools import assert_equal, assert_raises
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE

    random_dict = {'one': 1, 'two': 2, 'three': 3}

    immutable_dict = ImmutableDict(random_dict)

    copied_dict = copy(random_dict)
    result_dict_one = immutable_dict['one']
    result_dict_two = immutable_dict['two']
    result_dict_three = immutable_dict['three']

    assert_equal(result_dict_one, copied_dict['one'])

# Generated at 2022-06-22 21:22:09.638777
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    data = {'a': 'b'}
    immutable_dict = ImmutableDict(data)
    res_dict = immutable_dict['a']
    assert 'b' == res_dict



# Generated at 2022-06-22 21:22:11.991519
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict(a=1, b=2, c=3)
    assert len(d) == 3


# Generated at 2022-06-22 21:22:21.767702
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    string_keys = ImmutableDict({'a': 1, 'b': 2})
    int_keys = ImmutableDict({1: 1, 2: 2})
    string_values = ImmutableDict({'a': 'a', 'b': 'b'})
    int_values = ImmutableDict({'a': 1, 'b': 2})
    assert string_keys.__repr__() == "ImmutableDict({'a': 1, 'b': 2})"
    assert int_keys.__repr__() == "ImmutableDict({1: 1, 2: 2})"
    assert string_values.__repr__() == "ImmutableDict({'a': 'a', 'b': 'b'})"

# Generated at 2022-06-22 21:22:30.764977
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():

    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict(sb=4) == ImmutableDict(sb=4)
    assert ImmutableDict(sb=4).union({'ab': 3}) == ImmutableDict(sb=4, ab=3)
    assert ImmutableDict(sb=4).difference(['sb']) == ImmutableDict()
    assert ImmutableDict(sb=4).difference(['sb']).union({'ab': 3}) == ImmutableDict(ab=3)
    assert ImmutableDict(sb2=4).difference(['sb']).union({'ab': 3}) == ImmutableDict(sb2=4, ab=3)

# Generated at 2022-06-22 21:22:37.666235
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # Test for losing an item
    a = ImmutableDict({"a": 1, "b": 2, "c": 3})
    b = a.difference(["b"])
    assert len(b) == 2
    assert b not in a
    # Test for losing a non-existent item
    c = a.difference(["c", "d"])
    assert len(c) == len(a)
    assert c == a



# Generated at 2022-06-22 21:22:47.365651
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():

    # Empty dict
    empty_dict = ImmutableDict()
    union_dict = empty_dict.union({'key': 'value'})
    assert 'key' in union_dict
    assert union_dict['key'] == 'value'
    assert union_dict.union({}) == union_dict

    # Non-empty dict
    d = ImmutableDict({'key1': 'value1'})
    d_copy = d.copy()

    d2 = d.union({'key2': 'value2'})
    assert 'key2' in d2
    assert d2['key2'] == 'value2'
    assert 'key1' in d2 and d2['key1'] == 'value1'

    d2_copy = d2.copy()


# Generated at 2022-06-22 21:22:51.865534
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    dict_test = ImmutableDict({"test_key": "original_value"})
    assert dict_test["test_key"] == "original_value"



# Generated at 2022-06-22 21:22:57.460049
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 3, 4])
    assert is_sequence((1, 3, 4))
    assert is_sequence(set((1, 3, 4)))
    assert is_sequence(getattr(set((1, 3, 4)), 'intersection')(set((3, 4))))

    assert is_sequence(range(5))

    assert not is_sequence({'one': 1, 'two': 2})
    assert not is_sequence(1)
    assert not is_sequence(u'not a tuple')



# Generated at 2022-06-22 21:23:02.111722
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    immutable_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    immutable_dict_1 = immutable_dict.difference(['c', 'd', 'e'])
    assert immutable_dict_1 == ImmutableDict({'a': 1, 'b': 2})


# Generated at 2022-06-22 21:23:03.413187
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict({'a': 1, 'b': 2})) == 2


# Generated at 2022-06-22 21:23:10.559893
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert(ImmutableDict({'k': 'v'}) == ImmutableDict({'k': 'v'}))
    assert(ImmutableDict({'k0': 'v0'}, k1='v1') == ImmutableDict({'k0': 'v0'}, k1='v1'))
    assert(not (ImmutableDict({'k': 'v'}) == ImmutableDict({'k2': 'v2'})))
    assert(not (ImmutableDict({'k0': 'v0'}, k1='v1') == ImmutableDict({'k0': 'v0'}, k2='v2')))
    assert(not (ImmutableDict({'k0': 'v0'}, k1='v1') == ImmutableDict({'k0': 'v0'})))

# Generated at 2022-06-22 21:23:21.827259
# Unit test for function is_iterable
def test_is_iterable():
    f = is_iterable

    # empty things of various types
    assert f(None) is False
    assert f(10) is False
    assert f(10.5) is False
    assert f(b'') is False
    assert f('') is False
    assert f({}) is False

    # things that are iterables
    assert f(list(range(10))) is True
    assert f(tuple(range(10))) is True
    assert f(range(10)) is True
    assert f(set(range(10))) is True
    assert f(dict(one=1, two=2)) is True
    assert f(xrange(10)) is True
    assert f({'one': 1, 'two': 2}) is True
    assert f('some_string') is True

# Generated at 2022-06-22 21:23:32.860117
# Unit test for function is_sequence
def test_is_sequence():
    class NotSequence(object):
        pass

    class SequenceSubclass(list):
        pass

    class SubSequence(Sequence):
        pass

    class SequenceSubclass2(list):
        __class__ = Sequence

    class OneButNotSequence(object):
        def __len__(self):
            return 1

        def __getitem__(self):
            return self

    assert is_sequence([1, 2, 3]) is True
    assert is_sequence(SequenceSubclass((1, 2, 3))) is True
    assert is_sequence(SubSequence((1, 2, 3))) is True
    assert is_sequence(SequenceSubclass2((1, 2, 3))) is True
    assert is_sequence(OneButNotSequence()) is False
    assert is_sequence(NotSequence()) is False

# Generated at 2022-06-22 21:23:39.163661
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2])
    assert is_sequence(())
    assert not is_sequence('foo', include_strings=True)
    assert not is_sequence({1: 2})
    class NonSequence(object):
        def __getitem__(self):
            raise NotImplementedError
    assert not is_sequence(NonSequence)



# Generated at 2022-06-22 21:23:45.236654
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # 1. Check the __hash__ method returns equal integers given input with unique items with order,
    #    which are all hashable, and given input with repeated items with order, which are all hashable.
    #    The __hash__ method of class ImmutableDict should return the same integer, because the
    #    contents of the two inputs are identical.
    immutable_dict_obj = ImmutableDict({1: 'a', 2: 'b', 3: 'c', 4: 'd', 5: 'e'})
    immutable_dict_obj_with_repeated_elements = ImmutableDict({1: 'a', 2: 'b', 3: 'c', 4: 'd', 5: 'e', 1: 'a', 2: 'b', 3: 'c', 4: 'd', 5: 'e'})

    assert immutable_dict_

# Generated at 2022-06-22 21:23:49.995875
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dictionary = ImmutableDict({'a':1, 'b':2})
    assert dictionary == {'a':1, 'b':2}
    assert dictionary != {'b':2, 'a':1}
    assert dictionary == ImmutableDict({'a':1, 'b':2})
    assert dictionary != ImmutableDict({'a':1, 'b':3})

# Generated at 2022-06-22 21:23:53.293330
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(True)
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable(set())



# Generated at 2022-06-22 21:24:00.965753
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    # type: () -> None
    from ansible.module_utils.basic import json

    # check a regular immutable dict (which is always the same)
    test_immutable_dict = ImmutableDict(dict(a=1, b=2, c='3'))
    test_immutable_dict_json = json.dumps(test_immutable_dict)
    assert test_immutable_dict_json == '{"a": 1, "b": 2, "c": "3"}', 'Incorrect json serialization of ImmutableDict'
    assert test_immutable_dict.__repr__() == "ImmutableDict({'a': 1, 'b': 2, 'c': '3'})", 'Incorrect object representation'

    # check the json representation of an immutable dict with a list (which is not the same each time)


# Generated at 2022-06-22 21:24:10.924317
# Unit test for function is_iterable
def test_is_iterable():
    test_list = ['a','b','c']
    assert is_iterable(test_list)
    test_dict = {'a':1,'b':2}
    assert is_iterable(test_dict)
    test_string = 'abc'
    assert is_iterable(test_string)
    # Test cases for when the argument is not iterable
    test_int = 123
    assert not is_iterable(test_int)
    test_float = 1.1
    assert not is_iterable(test_float)
    test_bool = False
    assert not is_iterable(test_bool)


# Generated at 2022-06-22 21:24:14.600652
# Unit test for function is_string
def test_is_string():
    assert is_string('test')
    assert is_string(u'test')
    assert is_string(b'test')
    assert not is_string(5)
    assert not is_string(['test'])



# Generated at 2022-06-22 21:24:23.295369
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    immutable_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    difference = immutable_dict.difference(['c'])
    if 'c' in difference:
        raise Exception('Expected key "c" to not be in result of ImmutableDict.difference')
    if difference == immutable_dict:
        raise Exception('Expected result of ImmutableDict.difference to not equal original ImmutableDict')
    if difference != ImmutableDict({'a': 1, 'b': 2}):
        raise Exception('Unexpected value of ImmutableDict.difference')
    if immutable_dict == ImmutableDict({'a': 1, 'b': 2, 'c': 3}):
        raise Exception('Expected the original ImmutableDict to be unchanged')



# Generated at 2022-06-22 21:24:25.366702
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict({1:1, 2:4, 3:9})
    assert len(d) == 3


# Generated at 2022-06-22 21:24:32.372131
# Unit test for function is_iterable
def test_is_iterable():
    class TestClass(object):
        pass

    t_obj = TestClass()
    assert is_iterable([])
    assert is_iterable((1,))
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(t_obj)
    assert is_iterable(t_obj)
    assert is_iterable((x for x in range(3)))
    assert is_iterable(xrange(3))
    assert not is_iterable(1)
    assert not is_iterable(None)
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable(float(1))
    assert not is_iterable('abc')
    assert not is_iterable(1.2)
    assert not is_iter

# Generated at 2022-06-22 21:24:40.028496
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence('foobar') == False
    assert is_sequence('foobar', include_strings=True) == True
    assert is_sequence( ('f', 'o', 'o', 'b', 'a', 'r') ) == True
    assert is_sequence( set(['f', 'o', 'o', 'b', 'a', 'r']) ) == False
    assert is_sequence( 42 ) == False
    assert is_sequence( {'f', 'o', 'o', 'b', 'a', 'r'} ) == False


# Generated at 2022-06-22 21:24:44.519296
# Unit test for function count
def test_count():
    seq = [0, 0, 0, 1, 1, 1, 1, 1, 2, 0]
    count1 = {0: 4, 1: 5, 2: 1}
    assert count(seq) == count1
    assert count([]) == {}



# Generated at 2022-06-22 21:24:50.396654
# Unit test for function count
def test_count():
    assert count([1, 2, 2, 4, 1, 5, 2, 4, 7, 1, 4, 1, 2, 1, 2, 4, 2, 5, 2, 2]) == \
        {1: 5, 2: 8, 4: 4, 5: 2, 7: 1}
    assert count([]) == {}



# Generated at 2022-06-22 21:24:59.978523
# Unit test for function count
def test_count():
    test_list = ['a', 'b', 'a', 'a', 'c']
    assert count(test_list) == {'a': 3, 'b': 1, 'c': 1}
    assert count('test') == {'e': 1, 's': 1, 't': 2}
    assert count(('a', 'b', 'a', 'a', 'c')) == {'a': 3, 'b': 1, 'c': 1}
    assert count([]) == {}
    try:
        count(123)
        raise Exception('Expected an exception for passing a non-iterable argument')
    except Exception:
        pass



# Generated at 2022-06-22 21:25:04.025168
# Unit test for function is_string
def test_is_string():
    assert(is_string("foo"))
    assert(is_string(u"foo"))
    assert(not is_string(1))
    assert(not is_string(None))
    assert(not is_string(Exception))
    assert(not is_string({"a" : "b"}))


# Generated at 2022-06-22 21:25:08.274769
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    """Basic Smoke test for ImmutableDict.__getitem__()."""
    the_dict = ImmutableDict({'ansible': 'cool', 'python': 'awesome'})
    assert the_dict['ansible'] == 'cool'
    assert the_dict['python'] == 'awesome'


# Generated at 2022-06-22 21:25:14.371778
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = {'a': 'b', 'c': [1, 2, 3]}
    a_immutable = ImmutableDict(a)
    b = {'a': 'b', 'c': [1, 2, 3]}
    b_immutable = ImmutableDict(b)
    assert a_immutable.__eq__(b_immutable)

    a1 = {'a': 'b', 'c': [1, 2, 3]}
    a1_immutable = ImmutableDict(a1)
    b1 = {'a': 'b', 'c': [1, 2, 3], 'd': 'e'}
    b1_immutable = ImmutableDict(b1)
    assert not a1_immutable.__eq__(b1_immutable)


# Generated at 2022-06-22 21:25:17.794168
# Unit test for function count
def test_count():
    assert count([1, 2, 2, 3, 2, 1]) == {1: 2, 2: 3, 3: 1}
    assert count([]) == {}
    try:
        count('abc')
        assert False
    except Exception:
        assert True


# Generated at 2022-06-22 21:25:22.808769
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    c = ImmutableDict({'a': 1, 'b': 3})
    d = ImmutableDict({'a': 1, 'c': 2})
    assert hash(a) == hash(b)
    assert a == b
    assert hash(a) != hash(c)
    assert a != c
    assert hash(a) != hash(d)
    assert a != d



# Generated at 2022-06-22 21:25:26.554166
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    test_dict = {x: x for x in range(10)}
    immutable_dict = ImmutableDict(test_dict)
    assert len(test_dict) == len(immutable_dict)



# Generated at 2022-06-22 21:25:32.818178
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """Test removing keys from ImmutableDict"""
    case = ImmutableDict(
        a=1, b=2, c=3,
        d=ImmutableDict(a=1, b=2, c=3),
        e=ImmutableDict(a=1, b=2, c=ImmutableDict(a=1, b=2, c=3))
    )

    result = case.difference(['x'])
    assert case == result

    result = case.difference(['a'])
    assert result == ImmutableDict(b=2, c=3, d=ImmutableDict(a=1, b=2, c=3), e=ImmutableDict(a=1, b=2, c=ImmutableDict(a=1, b=2, c=3)))

   

# Generated at 2022-06-22 21:25:44.526058
# Unit test for function is_iterable
def test_is_iterable():
    """Unit test for function is_iterable"""
    class UnixLike:
        def __getitem__(self, index):
            return None

    assert is_iterable(None) is False
    assert is_iterable(42) is False
    assert is_iterable(b'string is not iterable') is False
    assert is_iterable(u'sequence is iterable') is True
    assert is_iterable(b'sequence is iterable') is True
    assert is_iterable(UnixLike()) is True
    assert is_iterable([]) is True
    assert is_iterable(()) is True
    assert is_iterable({}) is True
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable(('a', 1)) is True

# Generated at 2022-06-22 21:25:56.357993
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    def assert_hash(obj, expected_hash):
        assert hash(obj) == expected_hash, \
            'Hash of object {0} is {1}, expected {2}'.format(obj, hash(obj), expected_hash)

    assert_hash(ImmutableDict(), 0)
    assert_hash(ImmutableDict({'first': 'value'}), -3874692873307859808)
    assert_hash(ImmutableDict({'first': 'value', 'second': 'value', 1: 'one'}), 6456173860318507318)
    assert_hash(ImmutableDict({'first': 1}), -3975204370221473585)

# Generated at 2022-06-22 21:25:59.489185
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    assert(hash(ImmutableDict({'a': 'b'})) == hash(ImmutableDict({'b': 'a', 'a': 'b'})))


# Generated at 2022-06-22 21:26:05.634071
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable((1, 2, 3)) is True
    assert is_iterable(set((1, 2, 3))) is True
    assert is_iterable('') is True
    assert is_iterable(b'') is True

    assert is_iterable(1) is False
    assert is_iterable(object()) is False



# Generated at 2022-06-22 21:26:13.487413
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence([1, 2, 3])
    assert not is_sequence('hello world')
    assert not is_sequence(123)
    assert not is_sequence(counters)
    # testing also text_type from ansible.module_utils.six
    assert is_sequence('hi', include_strings=True)
    assert is_sequence(u'\xab', include_strings=True)
    assert not is_sequence(b'\xab', include_strings=True)



# Generated at 2022-06-22 21:26:17.177514
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    assert set(ImmutableDict()) == set()
    assert set(ImmutableDict([('key1', 'value1'), ('key2', 'value2')])) == set(['key1', 'key2'])


# Generated at 2022-06-22 21:26:26.308714
# Unit test for function count
def test_count():
    # Test non-iterable input
    if is_iterable(None):
        raise Exception('None is considered an iterable')

    # Test iterable input
    list_with_duplicates = [1, 2, 3, 4, 3, 3, 2, 2, 2, 1, 2, 1, 2]
    expected = {1: 3, 2: 5, 3: 3, 4: 1}
    result = count(list_with_duplicates)
    if expected != result:
        raise Exception('Expected: %s got: %s' % (expected, result))

test_count()



# Generated at 2022-06-22 21:26:35.808223
# Unit test for function count
def test_count():
    try:
        count('string')
        assert False, 'Count should not work on strings'
    except Exception:
        pass
    assert count([]) == dict(), 'Count should work on empty lists'
    assert count([1, 2, 3]) == {1: 1, 2: 1, 3: 1}, 'Count should work on lists'
    assert count({}) == dict(), 'Count should work on empty dicts'
    assert count({1: 2, 3: 4}) == {1: 1, 3: 1}, 'Count should work on dicts'
    assert count([1, 2, 3, 1, 1, 2, 2, 2, 4, 5]) == {1: 3, 2: 4, 3: 1, 4: 1, 5: 1}, 'Count should work on long lists'

# Generated at 2022-06-22 21:26:46.198901
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d1 = ImmutableDict({'one': {'two': 'three'}, 'four': 'five', 'six': 6})

    # test: difference between two identical dictionaries is an empty dictionary
    d2 = ImmutableDict(d1)
    assert d1.difference(d2) == ImmutableDict()

    # test: difference against an empty dictionary is an identical copy
    assert d1.difference(ImmutableDict()) == ImmutableDict(d1)

    # test: difference between different dictionaries is an identical copy
    d2 = ImmutableDict({'one': {'two': 'three'}, 'four': 'five', 'six': 'six'})
    assert d1.difference(d2) == ImmutableDict(d1)

    # test: difference between a longer dictionary is a dictionary with the missing

# Generated at 2022-06-22 21:26:53.342973
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict(x=1, y=2, z=3)
    assert {k: v for k, v in d.items()}.__eq__({'x': 1, 'y': 2, 'z': 3}) is True, \
           'ImmutableDict failed basic __iter__'
    e = ImmutableDict(a=1, b=2)
    f = e.union(y=3, z=4)
    assert {k: v for k, v in f.items()}.__eq__({'a': 1, 'b': 2, 'y': 3, 'z': 4}) is True, \
           'ImmutableDict failed __iter__ of union'
    g = f.difference(['a', 'b'])
    assert {k: v for k, v in g.items()}.__

# Generated at 2022-06-22 21:26:56.908752
# Unit test for function count
def test_count():
    """
    count function test
    """
    seq = [1, 1, 2, 3, 2, 1, 2, 4]
    expect = {1: 3, 2: 3, 3: 1, 4: 1}
    result = count(seq)
    assert expect == result



# Generated at 2022-06-22 21:27:05.087060
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    # Test construction from no arguments
    f = ImmutableDict()
    assert(len(f) == 0)
    assert(f == ImmutableDict())

    # Test construction from a single positional argument
    f = ImmutableDict({'a': 1})
    assert(f == {'a': 1})
    assert(f == {'a': 1, 'b': 2}.viewitems())
    assert(f == ImmutableDict({'a': 1, 'b': 2}.viewitems()))
    assert(f == frozenset({'a': 1, 'b': 2}.viewitems()))

    # Test construction from multiple positional arguments
    f = ImmutableDict({'a': 1}, {'b': 2}, {'a': 3, 'b': 4})

# Generated at 2022-06-22 21:27:12.996665
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    # Common case - no change
    assert d.difference(['x', 'y', 'z']) == d
    # Common case - some changes
    assert d.difference(['a', 'c', 'd']) == ImmutableDict({'b': 2})
    # Corner cases
    assert d.difference([]) == d
    assert ImmutableDict().difference(['x']) == ImmutableDict()



# Generated at 2022-06-22 21:27:22.173435
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    import sys
    class ImmutableDict(object):
        def __init__(self, d):
            self.d = d
        def __repr__(self):
            return 'ImmutableDict({0})'.format(repr(self.d))
    # Creating an ImmutableDict object
    id1 = ImmutableDict({'a': 3, 'b': 6})
    # Print the object
    print (id1)
    # print the dictionary
    print (id1.d)


# Generated at 2022-06-22 21:27:33.088694
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    # Create ImmutableDict
    immutable = ImmutableDict({'name': 'alex', 'age': 21})
    # Test __getitem__
    actual_name = immutable['name']
    actual_age = immutable['age']
    assert actual_name == 'alex'
    assert actual_age == 21
    # Test __iter__
    actual_list = []
    for key in immutable:
        actual_list.append(key)
    assert 'name' in actual_list
    assert 'age' in actual_list
    # Test __len__
    assert len(immutable) == 2
    # Test __hash__
    same = ImmutableDict({'name': 'alex', 'age': 21})
    assert hash(immutable) == hash(same)
    # Test __eq__
    assert immutable == same
   

# Generated at 2022-06-22 21:27:38.364522
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    """Test ImmutableDict union method"""
    original_mapping = {'a': 1, 'b': 2, 'c': 3}
    test_mapping = {'b': 7, 'd': 4}

    combined_mapping = ImmutableDict(original_mapping).union(test_mapping)

    assert isinstance(combined_mapping, ImmutableDict)
    assert combined_mapping == {'a': 1, 'b': 7, 'c': 3, 'd': 4}


# Generated at 2022-06-22 21:27:41.984326
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) == True
    assert is_iterable(1) == False
    assert is_iterable('') == True
    assert is_iterable(None) == False


# Generated at 2022-06-22 21:27:45.171297
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():

    immutable_dict = ImmutableDict({"a": 1})
    assert immutable_dict['a'] == 1


# Generated at 2022-06-22 21:27:54.395714
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dct_1 = ImmutableDict({1:2, 3:4, 'a':'b'})
    dct_2 = ImmutableDict({1:2, 3:4, 'a':'b'})
    dct_3 = {1:2, 3:4, 'a':'b'}
    dct_4 = ImmutableDict({1:2, 3:4, 'a':'b', 'c':'d'})

    assert dct_1 == dct_2
    assert not dct_1 == dct_3
    assert not dct_1 == dct_4


# Generated at 2022-06-22 21:27:56.922661
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    store = ImmutableDict({'a': 1, 'b': 2})
    assert store['a'] == 1
    assert store['b'] == 2



# Generated at 2022-06-22 21:28:02.730151
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    # pylint: disable=missing-docstring
    # Original dict
    original = ImmutableDict({'key1':'value1', 'key2':'value2', 'key3':'value3'})
    # Union dict
    union = ImmutableDict({'key3':'value0', 'key4':'value4'})
    # Merged dict
    merged = original.union(union)
    expected = {'key1':'value1', 'key2':'value2', 'key3':'value0', 'key4':'value4'}
    assert(merged == expected)


# Generated at 2022-06-22 21:28:08.013625
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    """Unit test for method __iter__ of class ImmutableDict"""
    immutable_dict = ImmutableDict({0: 'a', 1: 'b'})
    assert set(immutable_dict.__iter__()) == set([0, 1])



# Generated at 2022-06-22 21:28:18.418701
# Unit test for function count
def test_count():
    assert count([]) == {}
    assert count([1]) == {1: 1}
    assert count(['a', 'a']) == {'a': 2}
    assert count(['a', 'b']) == {'a': 1, 'b': 1}
    assert count([1, 'a']) == {1: 1, 'a': 1}
    assert count((1, 1)) == {1: 2}
    assert count(set([1, 1, 1])) == {1: 1}
    assert count(['a', 'b', 'a', 'a']) == {'a': 3, 'b': 1}



# Generated at 2022-06-22 21:28:25.964724
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    '''
    Test method union of class ImmutableDict
    '''
    test_dict1 = ImmutableDict({'one': '1', 'two': '2'})
    test_dict1_union = test_dict1.union({'three': '3', 'four': '4'})

    test_dict2 = ImmutableDict({'one': '1', 'two': '2', 'three': '3'})
    test_dict2_union = test_dict2.union({'four': '4', 'one': '11'})

    assert test_dict1_union == {'one': '1', 'two': '2', 'three': '3', 'four': '4'}

# Generated at 2022-06-22 21:28:33.404520
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Test the difference method of ImmutableDict class
    :return:
    """
    a = ImmutableDict({1:'a', 2:'b', 3:'c'})
    b = a.difference({1})
    assert 1 not in b.keys()
    assert 3 in b.keys()
    assert b[3] == 'c'
    c = a.difference({3, 4})
    assert 1 in c.keys()
    assert 3 not in c.keys()
    assert c[1] == 'a'


# Generated at 2022-06-22 21:28:36.931149
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict(a=1, b=2, c=3)
    assert d['a'] == 1
    assert d['b'] == 2
    assert d['c'] == 3



# Generated at 2022-06-22 21:28:39.038363
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict({'a': 1, 'b': 2})
    assert d['a'] == 1
    assert d.__getitem__('a') == 1


# Generated at 2022-06-22 21:28:49.976683
# Unit test for function count
def test_count():
    seq = ['a', 'b', 'a', 'c', 'c', 'd', 'e']
    # Test that count works as expected
    assert count(seq) == {'a': 2, 'b': 1, 'c': 2, 'd': 1, 'e': 1}
    seq = [1, 2, 3, 4, 5, 1, 3, 3, 3, 2, 1]
    assert count(seq) == {1: 3, 2: 2, 3: 4, 4: 1, 5: 1}
    # Test that count raises exception with non-iterable input
    try:
        count(10)
        assert False, 'Expected Exception'
    except Exception:
        pass


# Generated at 2022-06-22 21:28:52.996136
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    immutable_dict = ImmutableDict({'a': 'A', 'b': 'B'})
    assert len(immutable_dict) == 2



# Generated at 2022-06-22 21:28:57.045712
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    temp = ImmutableDict({"a":1,"b":2})
    assert str(temp) == "ImmutableDict({'a': 1, 'b': 2})"

# Generated at 2022-06-22 21:29:04.995894
# Unit test for function is_sequence
def test_is_sequence():
    from ansible.module_utils.six import u
    from ansible.module_utils._text import to_bytes

    assert not is_sequence('foo')
    assert not is_sequence(to_bytes('foo'))
    assert is_sequence(('foo',))

    assert not is_sequence(u('foo'))
    assert is_sequence((u('foo'),))

    assert is_sequence('foo', include_strings=True)
    assert is_sequence(to_bytes('foo'), include_strings=True)
    assert is_sequence(u('foo'), include_strings=True)

    class CustomMapping(MutableMapping):
        pass

    custom_mapping = CustomMapping(foo='bar')
    assert not is_sequence(custom_mapping)

    class CustomSequence(Sequence):
        pass


# Generated at 2022-06-22 21:29:13.385380
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # Testing method __hash__ of class ImmutableDict

    import sys
    import pytest

    cur_py_ver = ".".join(map(str, sys.version_info))


# Generated at 2022-06-22 21:29:19.921487
# Unit test for function is_sequence
def test_is_sequence():
    """Tests for the is_sequence function"""

    # List should be a sequence
    assert is_sequence([]) == True

    # Strings and bytes should never be sequences
    assert is_sequence('') == False

    # Strings and bytes should be counted as sequences if specified
    assert is_sequence('', include_strings=True) == True

    # Non-indexable objects are not sequences
    assert is_sequence(None) == False

# Generated at 2022-06-22 21:29:22.399983
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    """__getitem__ method is working"""
    data = {'key1': 'value1', 'key2': 'value2'}
    id = ImmutableDict(data)
    assert id['key1'] == 'value1', '__getitem__ method is not working as expected!'


# Generated at 2022-06-22 21:29:27.585473
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    d = ImmutableDict([('a', 1), ('b', 2)], c=3, d=4)
    assert d == {'a': 1, 'b': 2, 'c': 3, 'd': 4}


# Generated at 2022-06-22 21:29:34.703554
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable(set())
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable((1, 2, 3))
    assert is_iterable('123')
    assert not is_iterable(1)
    assert not is_iterable(4.5)
    assert not is_iterable(None)


# Generated at 2022-06-22 21:29:39.333760
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    d1 = ImmutableDict(a=0, b=1, c=2)
    d2 = ImmutableDict(c=3, d=4)
    assert (d1.union(d2) == ImmutableDict(a=0, b=1, c=3, d=4))


# Generated at 2022-06-22 21:29:50.920223
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    subtractive_iterable = ('b', 'c', 'D')
    expected_result = ImmutableDict({'a': 1})
    assert original.difference(subtractive_iterable) == expected_result

    original = ImmutableDict({'a': 1})
    subtractive_iterable = ('a', 'b', 'c')
    expected_result = ImmutableDict({'a': 1})
    assert original.difference(subtractive_iterable) == expected_result

    original = ImmutableDict({'a': 1})
    subtractive_iterable = ['a', 'b', 'c']
    expected_result = ImmutableDict({'a': 1})

# Generated at 2022-06-22 21:29:59.796212
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Unit tests for __hash__ of ImmutableDict"""

    # When: ImmutableDict is instantiated with no parameters
    test_dict = ImmutableDict()

    # Then: __hash__ returns the same value for multiple calls
    assert test_dict.__hash__() == ImmutableDict().__hash__()

    # When: ImmutableDict is instantiated with a 1 item mapping
    test_dict = ImmutableDict({'key1': 'value1'})

    # Then: __hash__ returns an int value
    assert isinstance(test_dict.__hash__(), int)

    # And: __hash__ returns the same value for multiple calls
    assert test_dict.__hash__() == ImmutableDict({'key1': 'value1'}).__hash__()

    # And: __hash__ returns a different value