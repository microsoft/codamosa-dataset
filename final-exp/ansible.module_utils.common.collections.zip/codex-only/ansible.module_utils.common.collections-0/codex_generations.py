

# Generated at 2022-06-22 21:20:00.926023
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a = ImmutableDict(one=1, two=2, three=3)
    b = ImmutableDict(four=4, five=5, six=6)
    c = ImmutableDict(three=3, four=4, five=5)
    d = ImmutableDict(three=4, four=4, five=5)
    e = ImmutableDict(three='4', four=4, five=5)
    f = ImmutableDict(three=4, four='4', five=5)
    g = ImmutableDict(three=4, four=4, five='5')
    h = ImmutableDict(one=1, two=5, three=3)
    i = ImmutableDict(four=4, five=5, six=6)

# Generated at 2022-06-22 21:20:04.294552
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert not is_iterable(1)



# Generated at 2022-06-22 21:20:08.402155
# Unit test for function is_string
def test_is_string():
    """is_string unit test"""
    assert is_string('string')
    assert is_string('B')
    assert is_string(u'unicode')
    assert is_string(b'bytestring')
    assert is_string([]) is False
    assert is_string(()) is False
    assert is_string({}) is False



# Generated at 2022-06-22 21:20:20.427745
# Unit test for function is_sequence
def test_is_sequence():
    # this should be non-indexable
    assert not is_sequence(True)
    assert not is_sequence(False)
    assert not is_sequence(True)
    assert not is_sequence(False)
    assert not is_sequence(None)

    assert is_sequence([])
    assert is_sequence(())
    assert is_sequence([1, 2])
    assert is_sequence((1, 2))

    # sequences with similar interface
    assert is_sequence(object(), include_strings=True)

    # strings should not be sequences
    assert not is_sequence("")
    assert not is_sequence("hello")
    assert not is_sequence("123456")
    assert not is_sequence("12\n3\t456")
    assert not is_sequence("hello\x00\x01\x02")
    assert not is_sequence

# Generated at 2022-06-22 21:20:28.382206
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(text_type())
    assert is_iterable(binary_type())
    assert is_iterable(text_type())
    assert is_iterable(binary_type())
    assert is_iterable(range(10))
    assert is_iterable(x for x in range(10))
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(Mapping())
    assert not is_iterable(Hashable())
    assert not is_iterable(ImmutableDict())

# Generated at 2022-06-22 21:20:30.375716
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict({'a':1, 'b':2})
    for k in d:
        pass


# Generated at 2022-06-22 21:20:40.979194
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    """
    Test union method of ImmutableDict class
    """
    original = ImmutableDict({'a':1, 'b':2, 'c':3})
    overriding_mapping = {'c':4, 'd':5}

    unionized = original.union(overriding_mapping)

    assert(unionized['a'] == 1)
    assert(unionized['b'] == 2)
    assert(unionized['c'] == 4)
    assert(unionized['d'] == 5)

    assert(unionized['a'] == original['a'])
    assert(unionized['b'] == original['b'])
    assert(unionized['c'] != original['c'])
    assert(unionized.get('d', None) is None)


# Generated at 2022-06-22 21:20:49.580085
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence(None) is False
    assert is_sequence(3) is False
    assert is_sequence(bytearray(b'abc')) is False
    assert is_sequence(memoryview(b'abc')) is False
    assert is_sequence(object()) is False
    assert is_sequence(range(3)) is True
    assert is_sequence(Exception()) is True
    assert is_sequence(list(range(3))) is True
    assert is_sequence(tuple()) is True
    assert is_sequence(set(range(3))) is True
    assert is_sequence(dict(a=1)) is True

    assert is_sequence(u'abc') is False
    assert is_sequence(b'abc') is False
    assert is_sequence(bytearray(b'abc')) is False
    assert is_

# Generated at 2022-06-22 21:20:57.955398
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """
        Unit test to test the representation of instance of class ImmutableDict.
        The function test_ImmutableDict___repr__() should return True if representation of instance of
        class ImmutableDict is string otherwise False.
    """
    try:
        assert 'ImmutableDict' == str(ImmutableDict())[:13]
        assert 'ImmutableDict({0})'.format({'a':1}) == str(ImmutableDict({'a':1}))
        return True
    except Exception:
        return False

# Generated at 2022-06-22 21:21:03.191111
# Unit test for function count
def test_count():
    assert count([]) == {}
    assert count([1, 2, 3, 3, 3, 4, 1, 5]) == {1: 2, 2: 1, 3: 3, 4: 1, 5: 1}
    assert count('asdf') == {'a': 1, 's': 1, 'd': 1, 'f': 1}



# Generated at 2022-06-22 21:21:05.265844
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict({"a": "b"})
    assert d['a'] == "b"


# Generated at 2022-06-22 21:21:12.850276
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1])
    assert is_iterable(())
    assert is_iterable((1,))
    assert is_iterable({})
    assert is_iterable({1: 1})
    assert is_iterable(set())
    assert is_iterable(set([1]))

    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(bytearray('abc'))



# Generated at 2022-06-22 21:21:24.527599
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(u"this is a string")
    assert is_iterable(u"this is a string", include_strings=True)
    assert is_iterable(b"this is a string")
    assert not is_iterable(b"this is a string", include_strings=True)
    assert is_iterable([])
    assert is_iterable([], include_strings=True)
    assert is_iterable((1,2,3,4))
    assert is_iterable([1,2,3], set(['one', 'two', 'three']), {1,3,5},
                        {"a": "one", "b": "two", "c": "three"}, include_strings=True)
    assert not is_iterable(1)
    assert is_iterable(1, include_strings=True)


# Generated at 2022-06-22 21:21:31.766537
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert is_sequence(range(10))
    assert is_sequence(tuple())
    assert is_sequence(xrange(10))
    assert is_sequence(set())
    assert not is_sequence(3)
    assert not is_sequence(2.5)
    assert not is_sequence(None)
    assert is_sequence('abc', include_strings=True)
    assert is_sequence(u'abc', include_strings=True)
    assert is_sequence(b'abc', include_strings=True)
    assert not is_sequence('abc')

# Generated at 2022-06-22 21:21:34.505865
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    test_dict = {'key': 'value'}
    test_ImmutableDict = ImmutableDict(test_dict)
    assert len(test_dict) == len(test_ImmutableDict)
    assert len(test_dict) == 1


# Generated at 2022-06-22 21:21:39.698693
# Unit test for function is_string
def test_is_string():
    assert is_string("abs")
    assert is_string("")
    assert is_string(u"abs")
    assert is_string(b"abc")
    assert not is_string("abc")
    assert not is_string(1)
    assert not is_string(object())
    assert not is_string([1,2,3])



# Generated at 2022-06-22 21:21:47.302385
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence(())
    assert is_sequence({})
    assert is_sequence(frozenset())
    assert is_sequence(ImmutableDict())

    # assert that all Mappings are not sequences
    assert not is_sequence({1: 2})
    assert not is_sequence(ImmutableDict(a=1))

    # assert that iterator objects are sequences
    assert not is_sequence((x for x in range(0, 5)))

    # assert that strings, bytes and bytearrays are not sequences
    assert not is_sequence('string')
    assert not is_sequence(b'bytestring')

    # assert that strings, bytes and bytearrays are not sequences
    assert not is_sequence('string', include_strings=True)

# Generated at 2022-06-22 21:21:53.878360
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    from ansible.module_utils.common._collections_compat import Iterable

    test_dict = ImmutableDict({'FOO': 'bar', 'BAR': 'baz', 'BAZ': 'foo'})

    assert isinstance(test_dict, Iterable)
    assert sorted(['FOO', 'BAR', 'BAZ']) == sorted(test_dict.keys())


# Generated at 2022-06-22 21:22:00.877452
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    # Test for correct operation
    original_dict = {"key1": "value1", "key2": 2}
    my_immutable_dict = ImmutableDict(original_dict)
    assert my_immutable_dict["key1"] == original_dict["key1"]
    assert my_immutable_dict["key2"] == original_dict["key2"]

    # Test for expected exception
    try:
        tmp = my_immutable_dict["key3"]
    except KeyError:
        assert True
    except:
        assert False

    # Test for unexpected exception
    try:
        tmp = my_immutable_dict["key1"]
    except:
        assert False


# Generated at 2022-06-22 21:22:12.192739
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    hash1 = ImmutableDict({'a':1, 'b':2}).__hash__()
    hash2 = ImmutableDict({'a':1, 'b':2}).__hash__()
    hash3 = ImmutableDict({'a':1, 'b':1}).__hash__()
    hash4 = ImmutableDict({'a':2, 'b':2}).__hash__()

    if hash1 != hash2:
        raise Exception('ImmutableDict().__hash__() failed - identical dictionaries returned different hashes')
    if hash1 == hash3:
        raise Exception('ImmutableDict().__hash__() failed - different dictionaries returned the same hashes')
    if hash1 == hash4:
        raise Exception('ImmutableDict().__hash__() failed - different dictionaries returned the same hashes')




# Generated at 2022-06-22 21:22:17.096721
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(b=2, a=1)
    assert (hash(d1) == hash(d2))
    d3 = ImmutableDict(c=1, b=2)
    assert (hash(d1) != hash(d3))


# Generated at 2022-06-22 21:22:27.292602
# Unit test for function is_sequence
def test_is_sequence():
    """Check that is_sequence() returns the right answer for various data types."""
    assert is_sequence((1, 2, 3)) == True
    assert is_sequence([1, 2, 3]) == True
    assert is_sequence("abc") == False
    assert is_sequence("abc", include_strings=True) == True
    assert is_sequence(u"abc") == False
    assert is_sequence(u"abc", include_strings=True) == True
    assert is_sequence(123) == False
    assert is_sequence((i for i in range(3))) == True
    assert is_sequence(x for x in range(3)) == True
    assert is_sequence(ImmutableDict({'a': 'A'})) == True
    assert is_sequence(MappingProxyType({'a': 'A'})) == False
   

# Generated at 2022-06-22 21:22:33.361163
# Unit test for function is_sequence
def test_is_sequence():
    # Test cases for the list and tuple input
    assert is_sequence([]) == True
    assert is_sequence([1, 2]) == True
    assert is_sequence((1, 2)) == True

    # Test cases for the strings
    assert is_sequence('text') == False
    assert is_sequence('text', include_strings=True) == True

    # Test cases for the non-sequence objects
    assert is_sequence(1, include_strings=True) == False
    assert is_sequence({}, include_strings=True) == False
    assert is_sequence({1:2}, include_strings=True) == False
    assert is_sequence(set([1]), include_strings=True) == False
    assert is_sequence(is_sequence, include_strings=True) == False


# Generated at 2022-06-22 21:22:43.855178
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    simp_dict_a = ImmutableDict({'a': 1, 'b': 2})
    simp_dict_b = ImmutableDict({'c': 3, 'd': 4})
    simp_dict_c = ImmutableDict({'a': 5, 'c': 3})
    simp_dict_d = ImmutableDict({'a': 5, 'b': 2, 'c': 3})

    # Test basic init
    assert len(simp_dict_a) == 2
    assert len(simp_dict_b) == 2
    assert len(simp_dict_c) == 2
    assert len(simp_dict_d) == 3

    assert simp_dict_a['a'] == 1
    assert simp_dict_a['b'] == 2
    assert simp_dict_b

# Generated at 2022-06-22 21:22:46.852405
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    dictionary = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert dictionary['a'] == 1
    assert dictionary['b'] == 2
    assert dictionary['c'] == 3



# Generated at 2022-06-22 21:22:50.615860
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    # Basic test
    d1 = ImmutableDict({'key1': "value1", 'key2': "value2"})
    assert (d1['key1'] == 'value1')
    # Test for KeyError
    try:
        d1['key3']
    except KeyError:
        assert True
    else:
        assert False


# Generated at 2022-06-22 21:22:57.385846
# Unit test for function is_string
def test_is_string():
    assert is_string('hello') is True
    assert is_string(u'hello') is True
    assert is_string(b'hello') is True
    assert is_string(True) is False
    assert is_string(None) is False
    assert is_string(5) is False
    assert is_string(('hello',)) is False
    assert is_string([5]) is False
    assert is_string(['hello']) is False
    assert is_string({'a': 1}) is False
    assert is_string({}) is False

# Generated at 2022-06-22 21:23:09.158902
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import pytest
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    d3 = ImmutableDict({'a': 1, 'b': 3})
    d4 = ImmutableDict({'c': 1, 'b': 2})
    assert hash(d1) == hash(d2)
    assert d1 == d2
    assert d1 != d3
    assert d3 == d3
    assert d1 != d4
    assert d4 == d4
    assert d1 != 1
    assert d1 != {}
    assert d1 != []
    assert d1 != "abcd"
    assert d1 == d1
    with pytest.raises(TypeError):
        hash(1)

# Generated at 2022-06-22 21:23:17.968880
# Unit test for function is_iterable
def test_is_iterable():
    # Test for sequence
    data = []
    assert(is_iterable(data))
    data = [1, 2, 3]
    assert(is_iterable(data))
    data = (1, 2, 3)
    assert(is_iterable(data))
    data = {1, 2, 3}
    assert(is_iterable(data))
    data = set()
    assert(is_iterable(data))
    data = ImmutableDict()
    assert(is_iterable(data))
    data = {'key1': 'value1', 'key2': 'value2'}
    assert(is_iterable(data))
    data = ImmutableDict(**data)
    assert(is_iterable(data))
    data = 'ABCDE'

# Generated at 2022-06-22 21:23:24.261654
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert is_sequence((1, 2, 3))
    assert is_sequence({'a': 'b', 'c': 'd'}, include_strings=True)
    assert not is_sequence({"a": "b", "c": "d"})
    assert not is_sequence({(x, x + 1): x for x in range(10)})
    assert not is_sequence(set([(x, x + 1) for x in range(10)]))
    assert not is_sequence('abc')
    assert not is_sequence(b'abc')
    assert not is_sequence(b'abc', include_strings=True)
    assert not is_sequence(1)
    assert not is_sequence(None)
    assert not is_sequence(iter([1, 2, 3]))


# Generated at 2022-06-22 21:23:28.273079
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """Test method __len__"""
    d = ImmutableDict({'one': 1, 'two': 2, 'three': 3})
    assert len(d) == 3


# Generated at 2022-06-22 21:23:32.889677
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    d1 = ImmutableDict({'k1': 1})
    d2 = d1.union({'k2': 2})
    assert d1 == ImmutableDict({'k1': 1})
    assert d2 == ImmutableDict({'k1': 1, 'k2': 2})
    d3 = d2.union({'k2': 3})
    assert d3 == ImmutableDict({'k1': 1, 'k2': 3})



# Generated at 2022-06-22 21:23:36.850010
# Unit test for function count
def test_count():
    seq = 'abbc'
    assert count(seq) == {'a': 1, 'b': 2, 'c': 1}
    seq = [0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 9, 9, 9, 9, 9, 9, 9, 9]
    assert count(seq) == {0: 2, 1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 1, 7: 1, 8: 1, 9: 10}
    seq = (1, 2, 3, 4)
    assert count(seq) == {1: 1, 2: 1, 3: 1, 4: 1}
    assert count(1) == {}
    assert count(None) == {}
    assert count([]) == {}
    assert count(()) == {}

# Generated at 2022-06-22 21:23:39.595719
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    mapping = ImmutableDict(a=1, b=2)
    assert mapping['b'] == 2



# Generated at 2022-06-22 21:23:47.873044
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    immutable_dict_1 = ImmutableDict({'key1': 1, 'key2': 2, 'key3': 3})
    immutable_dict_2 = ImmutableDict({'key4': 4, 'key5': 5})
    immutable_dict_3 = ImmutableDict()

    # The order of the items in the list is not guaranteed.
    assert sorted(immutable_dict_1.__iter__()) == [('key1', 1), ('key2', 2), ('key3', 3)]
    assert sorted(immutable_dict_2.__iter__()) == [('key4', 4), ('key5', 5)]
    assert sorted(immutable_dict_3.__iter__()) == []



# Generated at 2022-06-22 21:23:57.960739
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    # Creation of immutable dictionary
    immutable_dict = ImmutableDict(a=1, b=2)
    # Trying to change a value of a key within immutable dictionary raises AttributeError
    try:
        immutable_dict['a'] = 1
    except AttributeError:
        pass
    # ImmutableDict can be used in a dictionary
    test_dict = {immutable_dict: [1, 2]}
    assert test_dict[immutable_dict] == [1, 2]
    # Union method
    immutable_dict2 = immutable_dict.union(c=3, d=4)
    assert immutable_dict2 == {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    # Difference method
    immutable_dict3 = immutable_dict2.difference(['a', 'd'])
   

# Generated at 2022-06-22 21:24:08.791892
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    test_case = {
        'key1': 'val1',
        'key2': 'val2'
    }
    result = ImmutableDict(test_case).__repr__()
    assert(result == "ImmutableDict({'key1': 'val1', 'key2': 'val2'})")

    test_case = {
        'key1': 'val1'
    }
    result = ImmutableDict(test_case).__repr__()
    assert(result == "ImmutableDict({'key1': 'val1'})")

    test_case = {}
    result = ImmutableDict(test_case).__repr__()
    assert(result == 'ImmutableDict({})')


# Generated at 2022-06-22 21:24:11.678281
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    obj = ImmutableDict({'a':'foo','b':'bar','c':'baz'})
    assert sorted(obj) == ['a','b','c']


# Generated at 2022-06-22 21:24:21.390834
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    same1 = ImmutableDict({"a": 1, "b": 2})
    same2 = ImmutableDict(a=1, b=2)
    different1 = ImmutableDict({"a": 1, "b": 3})
    different2 = ImmutableDict({"a": 1, "b": 2, "c": 3})
    different3 = ImmutableDict({"a": 1, "c": 2})

    assert same1.__hash__() == same2.__hash__()
    assert different1.__hash__() != same1.__hash__()
    assert different2.__hash__() != same1.__hash__()
    assert different3.__hash__() != same1.__hash__()

    assert same1 != different1
    assert same1 != different2
    assert same1 != different3


# Generated at 2022-06-22 21:24:26.026016
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """Unit test for method __len__ of class ImmutableDict"""
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict(a=1)) == 1
    assert len(ImmutableDict(a=1, b=2)) == 2
    assert len(ImmutableDict(a=1, b=2, c=3)) == 3



# Generated at 2022-06-22 21:24:32.825097
# Unit test for function is_iterable
def test_is_iterable():
    class MyContainer(MutableMapping):
        def __init__(self, *args, **kwargs):
            self._store = dict(*args, **kwargs)

        def __getitem__(self, key):
            return self._store[key]

        def __setitem__(self, key, value):
            self._store[key] = value

        def __delitem__(self, key):
            del self._store[key]

        def __iter__(self):
            return iter(self._store)

        def __len__(self):
            return len(self._store)

        def __repr__(self):
            return repr(self._store)

    assert is_iterable((1, 2, 3)) == True, 'tuple is iterable'
    assert is_iterable([1, 2, 3])

# Generated at 2022-06-22 21:24:36.326663
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict({'a': 1, 'b': 2})
    assert repr(d) == "ImmutableDict({'a': 1, 'b': 2})"


# Generated at 2022-06-22 21:24:38.934960
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert repr(ImmutableDict(a=1, b=2)) == 'ImmutableDict({\'a\': 1, \'b\': 2})'



# Generated at 2022-06-22 21:24:44.768126
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    """Test method __getitem__ of class ImmutableDict for basic functionality."""
    immutable_dict = ImmutableDict({'test1': 'test1_value',
                                    'test2': 'test2_value',
                                    'test3': 'test3_value'
                                })
    assert immutable_dict['test1'] == 'test1_value'



# Generated at 2022-06-22 21:24:57.734262
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    import pytest
    dict1 = ImmutableDict((('a', 0), ('b', 1), ('c', 2)))
    dict2 = dict1.difference(('c',))
    assert repr(dict1) == "ImmutableDict({'a': 0, 'b': 1, 'c': 2})"
    assert dict2 == {'a': 0, 'b': 1}
    dict3 = dict1.difference(set(['c']))
    assert dict3 == {'a': 0, 'b': 1}
    dict4 = dict1.difference(dict(a=0))
    assert dict4 == {'b': 1, 'c': 2}
    with pytest.raises(TypeError):
        dict5 = dict1.difference((0, 'c'))
    dict6 = dict1.difference

# Generated at 2022-06-22 21:25:06.054757
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Given
    d = {'a': 1, 'b': 2}
    original_dict = ImmutableDict(d)
    same_dict = ImmutableDict(d)
    # assert that the hash of two ImmutableDicts is the same when the dictionaries are the same
    assert hash(original_dict) == hash(same_dict)

    different_dict = ImmutableDict()
    # assert that the hash of two ImmutableDicts is not the same when the dictionaries are different
    assert hash(original_dict) != hash(different_dict)

    # When
    d1 = ImmutableDict(d)
    d2 = ImmutableDict()
    d3 = ImmutableDict({'a': 1, 'b': 2})

    # Then
    assert d1 == d3
    assert d1 != d2

# Generated at 2022-06-22 21:25:16.085877
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    class Car():
        def __repr__(self):
            return 'Car'

    class Garage():
        def __repr__(self):
            return 'Garage'

    # Empty dictionary
    s = ImmutableDict()
    assert repr(s) == 'ImmutableDict({})'

    # Dictionary with integers
    s = ImmutableDict({'Number': 1})
    assert repr(s) == "ImmutableDict({'Number': 1})"

    # Dictionary with strings
    s = ImmutableDict({'Name': 'Red'})
    assert repr(s) == "ImmutableDict({'Name': 'Red'})"

    # Dictionary with objects
    s = ImmutableDict({'Car': Car()})
    assert repr(s) == "ImmutableDict({'Car': Car()})"



# Generated at 2022-06-22 21:25:19.259182
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    immutable_dict = ImmutableDict({'k1': 'v1', 'k2': 'v2', 'k3': 'v3'})
    assert next(iter(immutable_dict)) == 'k1'



# Generated at 2022-06-22 21:25:28.052064
# Unit test for function count
def test_count():
    cases = {
        ('abc', 'a', 'b', 'c'): {'a': 1, 'b': 1, 'c': 1},
        ([1, 2, 3], [1, 'a', 2, 'b', 3]): {[1, 2, 3]: 1, [1, 'a', 2, 'b', 3]: 1},
        (): {},
        (1,): {1: 1}
    }
    for args, expected in cases.items():
        result = count(args)
        assert result == expected

# Generated at 2022-06-22 21:25:33.901051
# Unit test for function count
def test_count():
    # Test if a result of count is a dictionary
    assert isinstance(count([1, 2]), dict)

    # Test if count counts right
    assert count([1, 2, 1, 1, 2]) == {1: 3, 2: 2}

    # Test if the function raises an error if the argument is not an iterable
    from pytest import raises
    with raises(Exception):
        count(3)



# Generated at 2022-06-22 21:25:45.834855
# Unit test for function count
def test_count():
    # test with a string
    try:
        count('Hello')
        assert False
    except Exception:
        assert True
    # test with an int
    try:
        count(10)
        assert False
    except Exception:
        assert True
    # test with a list
    test_list = [1, 2, 2, 2, 2, 3, 4, 5, 5, 6, 7, 8, 8, 8, 9, 10]
    result = count(test_list)
    for elem, elem_count in result.items():
        assert test_list.count(elem) == elem_count
    # test with a tuple
    result = count(tuple(test_list))
    for elem, elem_count in result.items():
        assert test_list.count(elem) == elem_count

# Generated at 2022-06-22 21:25:51.923563
# Unit test for function is_string
def test_is_string():
    assert is_string('test')
    assert is_string(u'test')
    assert is_string(b'test')
    assert is_string(5) is False
    assert is_string(None) is False
    assert is_string(tuple()) is False
    assert is_string(list()) is False



# Generated at 2022-06-22 21:26:00.674030
# Unit test for function is_iterable
def test_is_iterable():
    class NotIterable(object):
        pass

    seq = [1, 2, 3]
    assert is_iterable(seq)
    assert is_iterable(seq, True)
    assert is_iterable((x for x in seq))
    assert is_iterable((x for x in seq), True)
    assert is_iterable(u'abcd')
    assert is_iterable(u'abcd', True)
    assert is_iterable(b'abcd')
    assert is_iterable(b'abcd', True)

    assert not is_iterable(NotIterable())
    assert not is_iterable(NotIterable(), True)
    assert not is_iterable(1)
    assert not is_iterable(1, True)

# Unit tests for function is_sequence

# Generated at 2022-06-22 21:26:02.108758
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict({'a': 1, 'b': 2})
    assert set(d) == {'a', 'b'}


# Generated at 2022-06-22 21:26:05.126460
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    id = ImmutableDict([('one', 1), ('two', 2)])
    assert repr(id) == "ImmutableDict({'one': 1, 'two': 2})"

# Generated at 2022-06-22 21:26:09.749423
# Unit test for function is_sequence
def test_is_sequence():
    iterable = [1, 2, 3]
    string = 'hello'
    assert is_iterable(iterable) is True
    assert is_sequence(iterable) is True
    assert is_sequence(string) is False
    assert is_sequence(string, True) is True

# Generated at 2022-06-22 21:26:16.642399
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence(('one', 'two', 'three'))
    assert is_sequence([1, 2, 3])
    assert is_sequence(())
    assert not is_sequence(ImmutableDict(dict(one=1, two=2, three=3)))
    assert is_sequence(set(('one', 'two', 'three')))
    assert is_sequence(frozenset(('one', 'two', 'three')))
    assert not is_sequence('one')
    assert is_sequence('one', True)
    assert not is_sequence(1)


if __name__ == '__main__':
    test_is_sequence()

# Generated at 2022-06-22 21:26:28.031505
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    import pytest
    # if dictionary to merged in is not a Mapping, raise TypeError
    with pytest.raises(TypeError):
        ImmutableDict({'a': 'b'}).union('foo')
    # if both dictionaries are empty, a new empty ImmutableDict is returned
    test = ImmutableDict({}).union({})
    assert isinstance(test, ImmutableDict)
    assert len(test) == 0
    # if the original dictionary is empty, a new ImmutableDict with the items from overriding_mapping
    # is returned
    test = ImmutableDict({}).union({'a': 'b', 'c': 'd'})
    assert len(test) == 2
    assert test['a'] == 'b'
    assert test['c'] == 'd'
    # if the overriding

# Generated at 2022-06-22 21:26:35.063454
# Unit test for function is_string
def test_is_string():
    from ansible.module_utils import vault
    assert is_string(u'text')
    assert is_string(b'bytes')
    assert is_string(vault.AnsibleVaultEncryptedUnicode(b'vaulted'))
    assert is_string(vault.AnsibleVaultEncryptedUnicode(u'vaulted'))



# Generated at 2022-06-22 21:26:42.263882
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    x = ImmutableDict({1: "a", 2: "b", 3: "c"})
    if x.__repr__() != 'ImmutableDict({1: \'a\', 2: \'b\', 3: \'c\'})':
        raise Exception('ImmutableDict.__repr__(x) returned "{0}" instead of "ImmutableDict({1: \'a\', 2: \'b\', 3: \'c\'})"'
                        .format(x.__repr__(), {1: "a", 2: "b", 3: "c"}))


# Generated at 2022-06-22 21:26:46.639108
# Unit test for function count
def test_count():
    test_list = [1, 2, 3, 3, 4, 5, 6, 7]
    expected_dict = {1: 1, 2: 1, 3: 2, 4: 1, 5: 1, 6: 1, 7: 1}
    actual_dict = count(test_list)
    assert expected_dict == actual_dict


# Generated at 2022-06-22 21:26:51.979577
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    test_dict = ImmutableDict({'foo': 1, 'bar': 2})
    if test_dict['foo'] != 1:
        raise AssertionError("The dictionary value is invalid")
    # This should raise an exception due to the fact that ImmutableDict is immutable
    try:
        test_dict['baz'] = 3
    except:
        print("Caught exception due to the fact that ImmutableDict is immutable")
    else:
        raise AssertionError("ImmutableDict raises an exception when modifying a key")


# Generated at 2022-06-22 21:26:56.502517
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    """ Unit test for method __iter__ of class ImmutableDict """

    d = ImmutableDict(a=1, b=2, c=3)
    _d = dict(a=1, b=2, c=3)

    assert list(d) == list(_d)


# Generated at 2022-06-22 21:26:59.552813
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    my_dict = ImmutableDict({"a": 1, "b": 2, "c": 3})
    assert my_dict['b'] == 2


# Generated at 2022-06-22 21:27:11.804330
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test whether ImmutableDict.__eq__ works as expected

    The test is comprised of the following steps:
    1) Create an ImmutableDict and a regular dict with the same contents. Check whether they are equal.
    2) Create two ImmutableDicts with different contents. Check whether they are equal.
    3) Create two ImmutableDicts with similar contents. Check whether they are equal.
    4) Create an ImmutableDict and a non-dict object. Check whether they are equal.
    5) Create an ImmutableDict and a dict with similar contents. Check whether they are equal.

    Expected result:
        Objects of class ImmutableDict are only equal to other ImmutableDicts with the same contents
    """
    assert ImmutableDict({'a': 'b'}) == {'a': 'b'}
    assert Immutable

# Generated at 2022-06-22 21:27:15.933029
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_dict = ImmutableDict({"a": 1, "b": 2})
    test_difference = test_dict.difference({"b"})
    assert test_difference == ImmutableDict({"a": 1})

# Generated at 2022-06-22 21:27:20.904413
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    test_dict = ImmutableDict({'one': 1, 'two': 2, 'three': 3})
    for k, v in test_dict.items():
        assert k in test_dict.keys()
        assert v in test_dict.values()



# Generated at 2022-06-22 21:27:32.356548
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    a = ImmutableDict()
    b = ImmutableDict(dict(b=1))
    c = ImmutableDict(dict(c=1))
    d = ImmutableDict(dict(a=1, b=2))
    e = ImmutableDict(dict(d=1, e=2), c=3, a=4)
    f = ImmutableDict(dict(d=1, e=2), **dict(c=3, a=4))

    assert list(a.__iter__()) == []
    assert list(b.__iter__()) == ['b']
    assert list(c.__iter__()) == ['c']
    assert list((d.__iter__())) == ['a', 'b']

# Generated at 2022-06-22 21:27:41.792014
# Unit test for function count
def test_count():
    import collections

    assert count([1, 1, 2]) == {1: 2, 2: 1}
    assert count([1, 1, 2]) == collections.Counter([1, 1, 2])

    assert count(('a', 'a', 'b')) == {'a': 2, 'b': 1}
    assert count(('a', 'a', 'b')) == collections.Counter(['a', 'a', 'b'])

    assert count([1, 'a', 'a', 2]) == {1: 1, 'a': 2, 2: 1}
    assert count([1, 'a', 'a', 2]) == collections.Counter([1, 'a', 'a', 2])

    assert count([1, 2, 3]) == {1: 1, 2: 1, 3: 1}
    assert count([1, 2, 3])

# Generated at 2022-06-22 21:27:52.434691
# Unit test for function count
def test_count():
    from ansible.module_utils._text import to_text
    assert count((1, 2, 3, 1, 1, 2)) == {1:3, 2:2, 3:1}
    assert count(to_text(u'\u9f2c').encode('utf-8')) == {to_text(u'\u9f2c').encode('utf-8'):1}
    assert count(to_text(u'\u9f2c')) == {to_text(u'\u9f2c'):1}
    try:
        count(42)
        assert False, "count argument is not an iterable"
    except Exception:
        pass


# Generated at 2022-06-22 21:27:56.960932
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Check the repr() method of ImmutableDict
    :return: None
    :rtype: None
    """
    d = ImmutableDict({'foo': 'bar', 'baz': 'bam'})
    assert str(d).startswith('ImmutableDict')



# Generated at 2022-06-22 21:28:01.436562
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """
    Test that ImmutableDict correctly generates a string representation
    """
    base_dict = {'a': 1, 'b': 2}
    original_repr = 'ImmutableDict({0})'.format(repr(base_dict))
    idict = ImmutableDict(base_dict)
    assert idict.__repr__() == original_repr



# Generated at 2022-06-22 21:28:11.480011
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    ImmutableDict1 = ImmutableDict({'one': 1, "two": 2})
    assert len(ImmutableDict1) == 2, 'Method ImmutableDict.__len__() failed. Test 1'
    ImmutableDict2 = ImmutableDict({'one': 1, "two": 2, "three": 3})
    assert len(ImmutableDict2) == 3, 'Method ImmutableDict.__len__() failed. Test 2'
    ImmutableDict3 = ImmutableDict()
    assert len(ImmutableDict3) == 0, 'Method ImmutableDict.__len__() failed. Test 3'


# Generated at 2022-06-22 21:28:15.575975
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict()
    d_len = len(d)
    assert d_len == 0

    d = ImmutableDict({'a': 1, 'b': 2})
    d_len = len(d)
    assert d_len == 2



# Generated at 2022-06-22 21:28:24.909432
# Unit test for function count
def test_count():
    empty_list = []
    assert count(empty_list) == {}
    assert count(range(10)) == {0: 1, 1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 1, 7: 1, 8: 1, 9: 1}
    assert count(range(10) + range(10)) == {0: 1, 1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 1, 7: 1, 8: 1, 9: 1}
    assert count(range(10) + range(10) + [0]) == {0: 2, 1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 1, 7: 1, 8: 1, 9: 1}

# Generated at 2022-06-22 21:28:29.475252
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():

    for d in [{}, {1: 2, 3: 4}, {"x": "y"}, {'answer': 42, 'the meaning': 'life'}]:
        immutable_dict = ImmutableDict(d)
        assert len(immutable_dict) == len(d)



# Generated at 2022-06-22 21:28:40.482888
# Unit test for function count
def test_count():
    """Test function count()"""
    import copy
    import datetime
    import random
    import types

    random.seed(datetime.datetime.now())
    seq = list()
    while len(seq) < 1000:
        seq.extend([random.randint(0, 10) for i in range(0, 2000)])
    seq_c = copy.deepcopy(seq)
    res = count(seq)
    # In case of a bug this test can fail with an exception
    # from the tested function or with the 'AsssertionError'
    # from the following assert
    assert len(res) == 11, \
        'Dictionary length should be 11 but is {}'.format(len(res))

# Generated at 2022-06-22 21:28:52.997535
# Unit test for function is_iterable
def test_is_iterable():
    class Object(object):
        pass

    # None is not iterable
    assert not is_iterable(None)

    # Class is not iterable
    assert not is_iterable(Object)

    # Object is not iterable
    assert not is_iterable(Object())

    # Empty dict is iterable
    assert is_iterable({})

    # Non-empty dict is iterable
    assert is_iterable({'key': 'value'})

    # Empty list is iterable
    assert is_iterable([])

    # Non-empty list is iterable
    assert is_iterable([1])

    # Strings are not iterable, unless asked for
    assert not is_iterable('a')
    assert is_iterable('a', include_strings=True)

    # Bytes are not iterable, unless asked for


# Generated at 2022-06-22 21:28:59.740347
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    assert hash(ImmutableDict({})) == hash(frozenset())
    assert hash(ImmutableDict({'a': 'b'})) == hash(frozenset({'a': 'b'}))
    assert hash(ImmutableDict({'a': 'b'})) != hash(frozenset({'a': 'c'}))

# Generated at 2022-06-22 21:29:06.149494
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():

    # setup
    d = ImmutableDict(a=1, b=2, c=3)

    # tests and assertions

    # ImmutableDict['a']
    assert d['a'] == 1

    # ImmutableDict['missing'] should raise a KeyError
    did_raise = False
    try:
        x = d['missing']
    except KeyError:
        did_raise = True
    assert did_raise


# Generated at 2022-06-22 21:29:13.799837
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    # cannot call dict() with no arguments
    base = ImmutableDict({'a': 'one', 'b': 'two'})
    overriding = {'c': 'three'}
    expected = ImmutableDict({'a': 'one', 'b': 'two', 'c': 'three'})
    result = base.union(overriding)
    assert result == expected

    base = ImmutableDict({'a': 'one', 'b': 'two'})
    overriding = {'b': 'second'}
    expected = ImmutableDict({'a': 'one', 'b': 'second'})
    result = base.union(overriding)
    assert result == expected

    base = ImmutableDict({'a': 'one', 'b': 'two'})

# Generated at 2022-06-22 21:29:20.940884
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert is_sequence(['1', '2', '3'])
    assert is_sequence([])
    assert not is_sequence('hello')
    assert is_sequence('hello', include_strings=True)
    assert is_sequence(('hello', 'world'))
    assert is_sequence(frozenset(['hello', 'world']))
    assert is_sequence(range(5))
    assert not is_sequence(5)
    assert not is_sequence(True)

# Generated at 2022-06-22 21:29:33.740542
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    import unittest
    import re
    # Unit tests for __getitem__ method
    class ImmutableDictTestCase(unittest.TestCase):
        def setUp(self):
            expected_dict = {'a': 2, 'b': 5, 'c': 8}
            self.immutable_dict = ImmutableDict(expected_dict)
        def test_get_existing_key(self):
            self.assertEqual(self.immutable_dict['a'], 2)
            self.assertEqual(self.immutable_dict['b'], 5)
            self.assertEqual(self.immutable_dict['c'], 8)
        def test_get_non_existing_key(self):
            with self.assertRaises(KeyError) as cm:
                self.immutable_dict['d']

# Generated at 2022-06-22 21:29:38.047075
# Unit test for function is_string
def test_is_string():
    assert is_string('test string') is True
    assert is_string(u'test string') is True
    assert is_string(b'test string') is True
    assert is_string([1, 2, 3]) is False
    assert is_string(['test string']) is False


# Generated at 2022-06-22 21:29:48.480101
# Unit test for function is_string
def test_is_string():

    # Test basic strings
    assert is_string("hello world") is True
    assert is_string(u"hello world") is True
    assert is_string(b"hello world") is True
    assert is_string("") is True
    assert is_string(u"") is True
    assert is_string(b"") is True

    # Test non-strings
    assert is_string(555) is False
    assert is_string(55.5) is False
    assert is_string(None) is False
    assert is_string([]) is False
    assert is_string(()) is False
    assert is_string({}) is False



# Generated at 2022-06-22 21:29:58.068250
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([], True)
    assert is_sequence([], False)
    assert is_sequence((), True)
    assert is_sequence((), False)
    assert is_sequence(xrange(0), True)
    assert is_sequence(xrange(0), False)
    assert is_sequence([1], True)
    assert is_sequence([1], False)
    assert is_sequence((1,), True)
    assert is_sequence((1,), False)
    assert is_sequence(xrange(1), True)
    assert is_sequence(xrange(1), False)

    assert not is_sequence({}, True)
    assert not is_sequence({}, False)
    assert not is_sequence('txt', True)
    assert not is_sequence('txt', False)