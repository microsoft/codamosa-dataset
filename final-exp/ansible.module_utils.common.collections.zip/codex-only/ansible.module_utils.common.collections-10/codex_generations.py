

# Generated at 2022-06-22 21:20:07.046722
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    assert ImmutableDict(a=3).union(b=2) == ImmutableDict(a=3, b=2)
    assert ImmutableDict(a=3).union(a=2) == ImmutableDict(a=2)
    assert ImmutableDict(a=3).union(ImmutableDict(b=2)) == ImmutableDict(a=3, b=2)
    assert ImmutableDict(a=3).union(ImmutableDict(a=2)) == ImmutableDict(a=2)
    assert ImmutableDict(a=3).union({b: 2}) == ImmutableDict(a=3, b=2)
    assert ImmutableDict(a=3).union({a: 2}) == ImmutableDict(a=2)


# Generated at 2022-06-22 21:20:18.629217
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Test that ImmutableDict acts as expected"""
    # Ensure that an ImmutableDict can be created with a dict
    d = dict(foo='bar', baz='qux')
    immutable_d = ImmutableDict(d)
    assert immutable_d == d

    # Ensure that an ImmutableDict can be created with kwargs
    immutable_d = ImmutableDict(foo='bar', baz='qux')
    assert immutable_d == d

    # Ensure that an ImmutableDict cannot be updated
    try:
        immutable_d['quux'] = 'waldo'
        raise ValueError('ImmutableDict was not immutable')
    except TypeError:
        pass

    # Ensure that an ImmutableDict cannot be deleted

# Generated at 2022-06-22 21:20:21.865492
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    t = ImmutableDict()
    assert len(t) == 0

    t = ImmutableDict(a=1, b=2)
    assert len(t) == 2



# Generated at 2022-06-22 21:20:32.420253
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d2 = d.difference(['c'])
    assert(d2 == ImmutableDict({'a': 1, 'b': 2}))
    d2 = d.difference('c')
    assert(d2 == ImmutableDict({'a': 1, 'b': 2}))
    d2 = d.difference({'c': 3})
    assert(d2 == ImmutableDict({'a': 1, 'b': 2}))
    d2 = d.difference(['x', 'y'])
    assert(d2 == d)
    d2 = d.difference([])
    assert(d2 == d)
    d2 = d.difference({})
    assert(d2 == d)

# Generated at 2022-06-22 21:20:39.591839
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d == ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d != ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    assert d == ImmutableDict(a=1, b=2, c=3)
    assert d != ImmutableDict(a=1, b=2, c=3, d=4)


# Generated at 2022-06-22 21:20:46.713306
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d = ImmutableDict(a=1, b=2)
    assert d.difference(['a']) == ImmutableDict(b=2)
    assert d.difference(['a']).difference(['b']) == ImmutableDict()
    assert d.difference(['a', 'b']) == ImmutableDict()
    assert d.difference(['a', 'b', 'c']) == ImmutableDict()
    assert d.difference('ab') == ImmutableDict()


# Generated at 2022-06-22 21:20:52.905238
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    # Setup
    base = ImmutableDict(a=1, b=2, c=3)
    expected = ImmutableDict(a=2, b=3, c=3, d=4)

    # Action
    result = base.union(dict(a=2, d=4))

    # Assert
    assert result == expected



# Generated at 2022-06-22 21:21:03.277658
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():

    # Dictionary that is used as the original in the test
    initial_dict = ImmutableDict(test_a=1, test_b=2, test_c=3)

    # Dictionary that is used as the overriding_mapping in the test
    overriding_dict = dict(test_d=4)

    # The expected outcome of the union method
    expected = ImmutableDict(test_a=1, test_b=2, test_c=3, test_d=4)

    # The outcome of the union method
    actual = initial_dict.union(overriding_dict)

    # Test that the actual outcome of the union method is the same as expected
    assert expected == actual


# Generated at 2022-06-22 21:21:06.967220
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    Immutable_Dict = ImmutableDict({'Key1':'Value1', 'Key2':'Value2', 'Key3':'Value3'})
    assert is_iterable(Immutable_Dict)


# Generated at 2022-06-22 21:21:13.019997
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}) == ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}) != ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}



# Generated at 2022-06-22 21:21:21.488409
# Unit test for function is_iterable
def test_is_iterable():
    # These are all iterable
    assert is_iterable([])
    assert is_iterable((x for x in range(2)))
    assert is_iterable([1, 2])
    assert is_iterable(['a', 'b'])
    assert is_iterable(set([1, 2]))
    assert is_iterable({'a':  1, 'b': 2})
    # These are not iterable
    assert not is_iterable(123)
    assert not is_iterable(None)
    assert not is_iterable('a')
    assert not is_iterable(True)
    assert not is_iterable(False)
    # These are all iterable, if string is count as iterable
    assert is_iterable('ab', True)
    assert is_iterable(b'ab', True)


# Generated at 2022-06-22 21:21:26.998938
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    immutable_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert immutable_dict.difference(['a']) == ImmutableDict({'b': 2, 'c': 3})
    assert immutable_dict.difference({'a': 1}) == ImmutableDict({'b': 2, 'c': 3})


# Generated at 2022-06-22 21:21:31.724409
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # Arrange
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    remove_elements = ('a','c','d','f')

    # Act
    actual = original.difference(remove_elements)

    # Assert
    expected = ImmutableDict({'b': 2})
    assert actual == expected


# Generated at 2022-06-22 21:21:37.114025
# Unit test for function is_string
def test_is_string():
    # test with regular string
    assert is_string('hello') is True
    # not RHS is not a string
    assert is_string(1) is False
    # test List, Set, Tuple and dictionary
    assert is_string([1, 2]) is False
    assert is_string(()) is False
    assert is_string({'key': 'value'}) is False
    assert is_string({1, 2}) is False


# Generated at 2022-06-22 21:21:47.440768
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    d = ImmutableDict({'a': 1, 'b': 2})
    assert d == ImmutableDict(d.union({}))
    assert ImmutableDict(a=1, b=2, c=3) == d.union({'c': 3})
    assert ImmutableDict(a=10, b=2, c=3) == d.union({'a': 10, 'c': 3})
    assert ImmutableDict(a=1, b=9, c=3) == d.union({'b': 9, 'c': 3})
    assert ImmutableDict(a=0, b=9, c=3) == d.union({'a': 0, 'b': 9, 'c': 3})


# Generated at 2022-06-22 21:21:51.088025
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    original = ImmutableDict({'a': 1, 'b': 2})
    other = ImmutableDict({'a': 1, 'b': 2})
    assert (original == other)



# Generated at 2022-06-22 21:21:58.528388
# Unit test for function is_string
def test_is_string():
    assert is_string(u'unicode')
    assert is_string(b'bytes')
    assert is_string('string')
    assert not is_string(['list'])
    assert not is_string((u'tuple', u'unicode'))
    assert not is_string((b'tuple', b'bytes'))
    assert not is_string((u'tuple', b'mix'))
    assert not is_string({u'mapping': u'unicode'})
    assert not is_string({b'mapping': b'bytes'})
    assert not is_string({u'mapping': b'mix'})



# Generated at 2022-06-22 21:22:03.358267
# Unit test for function is_sequence
def test_is_sequence():
    """Unit tests for function is_sequence"""
    array = [1, 2, 3, 4]
    assert is_sequence(array) is True
    assert is_sequence(array, include_strings=True) is True

    string = 'abc'
    assert is_sequence(string) is False
    assert is_sequence(string, include_strings=True) is True

# Generated at 2022-06-22 21:22:14.997050
# Unit test for function is_sequence
def test_is_sequence():
    class Foo(object):
        def __getitem__(self, item):
            pass

    foo = Foo()

    assert(is_sequence([]) is True)
    assert(is_sequence([0]) is True)
    assert(is_sequence(tuple()) is True)
    assert(is_sequence((0,)) is True)
    assert(is_sequence(set()) is False)
    assert(is_sequence(dict()) is False)
    assert(is_sequence("") is False)
    assert(is_sequence("1") is False)
    assert(is_sequence("12") is False)
    assert(is_sequence("123") is False)
    assert(is_sequence(foo) is True)
    assert(is_sequence(1) is False)



# Generated at 2022-06-22 21:22:20.305585
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    id = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert id['a'] == 1
    assert id['b'] == 2
    assert id['c'] == 3


# Generated at 2022-06-22 21:22:23.685716
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Verify ImmutableDict's representation is the same as that of the underlying dict."""
    dict_ = dict(a=1, b=2)
    assert repr(dict_) == repr(ImmutableDict(dict_))

# Generated at 2022-06-22 21:22:30.931113
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a = ImmutableDict(x=1, y=2, z=3)
    assert isinstance(a, ImmutableDict)
    assert a == ImmutableDict(x=1, y=2, z=3)
    assert a.union(dict(x=0, i=5)) == ImmutableDict(x=0, y=2, z=3, i=5)

    # Check that we are creating a copy and not modifying the original
    assert a == ImmutableDict(x=1, y=2, z=3)


# Generated at 2022-06-22 21:22:42.053304
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    '''
    Test __eq__ method of ImmutableDict class
    '''

    dict1 = ImmutableDict(key1='value1', key2='value2')
    dict2 = ImmutableDict(key1='value1', key2='value2')
    dict3 = ImmutableDict(key1='value1', key2='value22')
    dict4 = ImmutableDict(key1='value1')
    dict5 = ImmutableDict(key1='value1', key2='value2', key3='value3')

    # Test equality of objects with same key-value pairs
    assert dict1 == dict2

    # Test inequality of objects with same value but different key
    assert not(dict1 == dict4)

    # Test inequality of objects with same key but different value
    assert not(dict1 == dict3)

# Generated at 2022-06-22 21:22:50.554225
# Unit test for function is_iterable
def test_is_iterable():

    # Non-iterables
    assert not is_iterable(None)
    assert not is_iterable(False)
    assert not is_iterable(1)
    assert not is_iterable(1.0)

    assert not is_iterable('string', False)
    assert not is_iterable(u'unicode', False)
    assert not is_iterable(b'bytes', False)

    # Iterables
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable({'a', 'b'})  # Set
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))


# Generated at 2022-06-22 21:22:58.327415
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_dict = ImmutableDict({'a': 1, 'b': '2'})

    assert test_dict == ImmutableDict({'a': 1, 'b': '2'})
    assert not test_dict == ImmutableDict({'a': 1, 'b': '2', 'c': 3})
    assert not test_dict == ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert not test_dict == {'a': 1, 'b': 2}
    assert test_dict != {'a': 1, 'b': 2}
    assert not test_dict == dict()
    assert test_dict != dict()

# Generated at 2022-06-22 21:23:00.785632
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    idict = ImmutableDict({'key1': 'value1'})
    assert idict['key1'] == 'value1'


# Generated at 2022-06-22 21:23:06.876232
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """Unit test for method __len__ of class ImmutableDict

    Tests whether the length of the ImmutableDict is equal to the length of it's
    corresponding dict.
    """
    test_dict = {'a':1, 'b':2}
    immutable_dict = ImmutableDict(test_dict)
    assert len(test_dict) == len(immutable_dict)


# Generated at 2022-06-22 21:23:09.725935
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    dict1 = ImmutableDict({'a': 'b', 'c': 'd'})
    assert len(dict1) == 2



# Generated at 2022-06-22 21:23:12.785254
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    try:
        x = ImmutableDict(a=1, b=2)
        x['c'] = 3
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-22 21:23:18.203983
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    assert list(ImmutableDict(a=1, b=2, c=3)) == ['a', 'b', 'c']
    assert tuple(ImmutableDict(a=1, b=2, c=3)) == ('a', 'b', 'c')



# Generated at 2022-06-22 21:23:28.183717
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('string')
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert not is_iterable({'a': 1, 'b': 2}.items())
    assert not is_iterable({'a': 1, 'b': 2}.iteritems())
    assert not is_iterable({'a': 1, 'b': 2}.values())
    assert not is_iterable({'a': 1, 'b': 2}.itervalues())
    assert not is_iterable(1)


# Generated at 2022-06-22 21:23:37.250501
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_start_dict = ImmutableDict({'param1': 'value1', 'param2': 'value2'})
    test_subtractive_iterable = [ 'param1', 'param2' ]
    test_expected_dict = ImmutableDict()
    test_result_dict = test_start_dict.difference(test_subtractive_iterable)
    assert test_result_dict == test_expected_dict

    test_subtractive_iterable = [ 'param1' ]
    test_expected_dict = ImmutableDict({'param2': 'value2'})
    test_result_dict = test_start_dict.difference(test_subtractive_iterable)
    assert test_result_dict == test_expected_dict

    test_subtractive_iterable = [ 'param2' ]

# Generated at 2022-06-22 21:23:43.556121
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    """Unit tests for __iter__ method of class ImmutableDict"""
    # Create object
    immutable_dict = ImmutableDict({'a': 1, 'b': 2})
    # Check that iter is not None
    assert iter(immutable_dict) is not None
    # Check that we iterate over immutable_dict correctly
    assert sorted(list(iter(immutable_dict))) == ['a', 'b']



# Generated at 2022-06-22 21:23:47.653848
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    x = ImmutableDict()
    assert hash(x) == hash(frozenset())
    x = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert hash(x) == hash(frozenset({'a': 1, 'b': 2, 'c': 3}.items()))



# Generated at 2022-06-22 21:23:53.089087
# Unit test for function is_string
def test_is_string():
    assert is_string('abc')
    assert is_string('abc'.decode('utf-8'))
    assert not is_string(None)
    assert not is_string(1)
    assert not is_string(['a'])
    assert not is_string(('a', ))
    assert not is_string({'a': 'b'})



# Generated at 2022-06-22 21:23:56.052329
# Unit test for function count
def test_count():
    assert count([]) == {}
    assert count([1, 2, 3, 4, 1, 2, 3, 4]) == {1: 2, 2: 2, 3: 2, 4: 2}



# Generated at 2022-06-22 21:23:58.137142
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    i = ImmutableDict([('name', 'sean'), ('age', 31)])
    assert ['age', 'name'] == sorted(i.__iter__())


# Generated at 2022-06-22 21:24:09.510101
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # Test 1
    a = ImmutableDict({'a': 'foo', 'b': 'bar'})
    b = a.difference(['a'])
    assert len(b) == 1
    assert b['b'] == 'bar'

    # Test 2
    a = ImmutableDict({'a': 'foo', 'b': 'bar'})
    b = a.difference(['a', 'b'])
    assert len(b) == 0

    # Test 3
    a = ImmutableDict({'a': 'foo', 'b': 'bar'})
    b = a.difference(['c'])
    assert len(b) == 2
    assert b['a'] == 'foo'
    assert b['b'] == 'bar'

    # Test 4

# Generated at 2022-06-22 21:24:14.347221
# Unit test for function is_iterable
def test_is_iterable():
    class A(object):
        def __iter__(self):
            return [][:]

    assert is_iterable([])
    assert is_iterable((1, 2))
    assert is_iterable(set([1, 2]))
    assert is_iterable(A())
    assert not is_iterable(1)



# Generated at 2022-06-22 21:24:18.591427
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    imdict = ImmutableDict(a=1, b=2)
    assert imdict['a'] == 1
    assert imdict['b'] == 2
    try:
        imdict['c']
    except KeyError:
        pass
    else:
        assert "c"


# Generated at 2022-06-22 21:24:21.576739
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    # Arrange
    immutable_dict = ImmutableDict()

    # Act
    result = repr(immutable_dict)

    # Assert
    assert result == 'ImmutableDict({})', 'Wrong representation of an empty ImmutableDict'


# Generated at 2022-06-22 21:24:24.658877
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    expected_value = 5
    idict = ImmutableDict({'1': 1, '2': 2, '3': 3, '4': 4, '5': 5})
    actual_value = len(idict)
    assert expected_value == actual_value



# Generated at 2022-06-22 21:24:29.069894
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    dict_list = [
        {},
        {'a': 'b'},
        {'a': 'b', 'c': 'd'},
        {'a': 'b', 'c': 'd', 'e': 'f'},
        ]
    for dict_item in dict_list:
        dict_object_1 = ImmutableDict(dict_item)
        dict_object_2 = ImmutableDict(dict_item)
        assert hash(dict_object_1) == hash(dict_object_2)

# Generated at 2022-06-22 21:24:33.158130
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    dictionary = ImmutableDict(a=1, b=2)
    assert dictionary['a'] == 1
    assert dictionary['b'] == 2


# Generated at 2022-06-22 21:24:37.803037
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('string') is False
    assert is_iterable((1, 2, 3)) is True
    assert is_iterable(range(10)) is True
    assert is_iterable(1) is False
    assert is_iterable(['a', 'b']) is True


# Generated at 2022-06-22 21:24:44.822645
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    a = ImmutableDict({'key': 'value'})
    b = ImmutableDict({'key': 'value'})
    c = ImmutableDict({'key': 'value', 'new_key': 'new_value'})
    d = ImmutableDict({'key': 'value', 'new_key': 'new_value'})
    assert hash(a) == hash(b)
    assert hash(c) == hash(d)



# Generated at 2022-06-22 21:24:57.784615
# Unit test for function is_sequence
def test_is_sequence():
    # Test for negative cases
    assert is_sequence(None) is False
    assert is_sequence(True) is False
    assert is_sequence(1) is False
    assert is_sequence(object()) is False

    # Test for positive cases
    assert is_sequence([]) is True
    assert is_sequence((1, )) is True
    assert is_sequence((i for i in range(1, 10))) is True
    assert is_sequence(ImmutableDict((i, i) for i in range(1, 10))) is True

    # Test for negative cases with strings
    assert is_sequence('foo') is False
    assert is_sequence(b'bar') is False

    # Test for positive cases with strings included
    assert is_sequence('foo', include_strings=True) is True

# Generated at 2022-06-22 21:25:02.304914
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    test_dict = ImmutableDict({'a': 1, 2: 'b', 'd': 'e'})
    for key in test_dict:
        assert key in test_dict._store


# Generated at 2022-06-22 21:25:10.218334
# Unit test for function is_string
def test_is_string():
    assert is_string('text')
    assert is_string(u'text')
    assert is_string(b'bytes')
    assert not is_string(5)
    assert not is_string([])
    assert not is_string(())
    assert not is_string({})
    assert not is_string(set())
    class MyFakeStringObj(Sequence):
        def __iter__(self):
            return iter('MyFakeStringObj')
    assert not is_string(MyFakeStringObj())


# Generated at 2022-06-22 21:25:18.864862
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d1 = ImmutableDict([('one', 1), ('two', 2)])
    d2 = ImmutableDict({'one': 1, 'two': 2})
    d3 = ImmutableDict({'two': 2, 'one': 1})

    assert not (d1 == d2)
    assert d1 == d3
    assert d2 == d3
    assert d1 == {'one': 1, 'two': 2}
    assert d1 != {'one': 1, 'two': 3}

    assert hash(d1) == hash(d3)
    assert hash(d1) != hash(d2)
    assert hash(d1) != hash(frozenset([('one', 1), ('two', 2)]))

# Generated at 2022-06-22 21:25:21.290610
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    test_dict = ImmutableDict({'key': 'value'})
    assert test_dict['key'] == 'value'


# Generated at 2022-06-22 21:25:30.631287
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    original = ImmutableDict(a=1, b='foo', c=dict(c1=None))
    overriding = dict(a=2, c=dict(c1='bar', c2=dict(c2a=1, c2b=2)))
    override = original.union(overriding)
    assert override == ImmutableDict({'a': 2, 'b': 'foo', 'c': {'c1': 'bar', 'c2': {'c2a': 1, 'c2b': 2}}})



# Generated at 2022-06-22 21:25:42.158568
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Make sure ImmutableDicts are really immutable"""
    a = ImmutableDict(one=1, two=2)
    try:
        a['one'] = 3
        raise Exception('Setting a key in an ImmutableDict should be impossible')
    except TypeError:
        # This is how a TypeError is supposed to be raised
        pass
    else:
        raise Exception('Changing the value of a key should raise a TypeError')

    try:
        a['three'] = 3
        raise Exception('Adding a key to an ImmutableDict should be impossible')
    except TypeError:
        pass
    else:
        raise Exception('Adding a key should raise a TypeError')


# Generated at 2022-06-22 21:25:45.834797
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """
    Tests that __hash__ of ImmutableDict class works
    """
    d1 = ImmutableDict({})
    d2 = ImmutableDict({})
    assert d1 == d2
    assert hash(d1) == ha

# Generated at 2022-06-22 21:25:57.284199
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(foo=1, bar=2) == ImmutableDict(bar=2, foo=1)
    assert not (ImmutableDict(foo=1, bar=2) == ImmutableDict(bar=1, foo=2))
    assert ImmutableDict(foo=[1, 2]) == ImmutableDict(foo=[2, 1])
    assert not (ImmutableDict(foo=[1, 2]) == ImmutableDict(foo=[2, 3]))
    assert ImmutableDict(foo={1: "a", 2: "b"}) == ImmutableDict(foo={2: "a", 1: "b"})
    assert not (ImmutableDict(foo={1: "a", 2: "b"}) == ImmutableDict(foo={2: "a", 1: "c"}))


# Generated at 2022-06-22 21:26:02.982131
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    assert ImmutableDict({"a": 1, "b": 2}) == ImmutableDict(a=1, b=2)
    assert "a" in ImmutableDict({"a": 1, "b": 2})
    assert ImmutableDict() == ImmutableDict({})
    assert len(ImmutableDict({"a": 1, "b": 2})) == 2

# Generated at 2022-06-22 21:26:11.772281
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable((x for x in range(10)))

    assert not is_iterable(1)
    assert not is_iterable(1.1)
    assert not is_iterable(None)

    assert not is_iterable('a')
    assert is_iterable('a', True)

    assert is_iterable({1})
    assert not is_iterable({1: 2})



# Generated at 2022-06-22 21:26:15.374771
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    assert hash(ImmutableDict()) == hash(dict())
    assert hash(ImmutableDict([('foo', 'bar')])) == hash(dict(foo='bar'))


# Generated at 2022-06-22 21:26:19.317068
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict({'a': 1, 'b': 2})
    assert d['a'] == 1
    assert d['b'] == 2
    try:
        d['c']
        assert False, 'Should not be able to get non-existing item'
    except KeyError:  # pragma: no cover
        pass


# Generated at 2022-06-22 21:26:21.482632
# Unit test for function is_string
def test_is_string():
    assert is_string('')
    assert is_string('abc')
    assert is_string(u'abc')
    assert is_string(b'abc')
    assert not is_string([])
    assert not is_string({})


# Generated at 2022-06-22 21:26:29.487883
# Unit test for function is_iterable
def test_is_iterable():
    class NotIterable(object):
        pass

    class IsIterable(object):
        def __init__(self):
            self.x = 'y'
            self.data = ['one', 'two', 'three']

        def __iter__(self):
            return iter(self.data)

    # Basic test
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable((1, 2, 3)) is True
    assert is_iterable({"a": 1, "b": 2, "c": 3}) is True
    assert is_iterable("abc") is True
    assert is_iterable(1) is False

    # Test iterable and not iterable classes
    assert is_iterable(NotIterable()) is False
    assert is_iterable(IsIterable()) is True

#

# Generated at 2022-06-22 21:26:38.420821
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    a = ImmutableDict({"a": 1, "b": 2})
    a_equal = ImmutableDict({"a": 1, "b": 2})
    a_less = ImmutableDict({"a": 1, "b": 1})
    a_more = ImmutableDict({"a": 1, "b": 2, "c": 3})
    assert a.__hash__() == a_equal.__hash__()
    assert a.__hash__() != a_less.__hash__()
    assert a.__hash__() != a_more.__hash__()



# Generated at 2022-06-22 21:26:46.844487
# Unit test for function is_sequence
def test_is_sequence():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    # Validate for basic types
    assert is_sequence('string') is False
    assert is_sequence(b'bytes') is False
    assert is_sequence(1) is False
    assert is_sequence(1.1) is False
    assert is_sequence(True) is False
    assert is_sequence(None) is False
    # Validate for string-like types
    assert is_sequence('string', include_strings=True) is False
    assert is_sequence(b'bytes', include_strings=True) is False
    # Validate for iterable types
    assert is_sequence([1, 2]) is True
    assert is_sequence(set([1, 2])) is True

# Generated at 2022-06-22 21:26:51.635301
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    orig = ImmutableDict({'a':1, 'b':2, 'c':3})
    removing_keys = ['a', 'c']
    subtract = ImmutableDict.difference(orig, removing_keys)
    assert isinstance(subtract, ImmutableDict)
    assert subtract == ImmutableDict({'b':2})

# Generated at 2022-06-22 21:26:55.104725
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert not is_sequence('abc')
    assert not is_sequence(set((1, 2, 3)))
    assert is_sequence('abc', True)



# Generated at 2022-06-22 21:27:01.006720
# Unit test for function count
def test_count():
    # Testing a non-iterable input
    try:
        count(1)
    except Exception:
        pass
    else:
        raise Exception('count function should fail if non-iterable value is provided')

    # Testing a valid iterable
    seq = ['a', 'b', 'a', 'c']
    assert count(seq) == {'a': 2, 'b': 1, 'c': 1}, 'count function should return the correct result'



# Generated at 2022-06-22 21:27:13.085043
# Unit test for function is_iterable
def test_is_iterable():
    """Unit test for function is_iterable"""

    try:
        import collections
    except ImportError:  # pragma: no cover
        collections = None

    assert is_iterable('abc')
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    if collections is not None:
        assert is_iterable(collections.deque([1, 2, 3]))
        assert is_iterable(collections.Counter([1, 1, 2, 3]))
        assert is_iterable(collections.OrderedDict([(1, 2), (2, 3)]))
        assert is_iterable(collections.defaultdict(lambda: 'a'))


# Generated at 2022-06-22 21:27:17.496929
# Unit test for function count
def test_count():
    assert count([]) == {}
    assert count([1]) == {1: 1}
    assert count(['a', 'a', 'b', 'b', 'b']) == {'a': 2, 'b': 3}



# Generated at 2022-06-22 21:27:20.676219
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict({'key1': 'value1'})
    assert d['key1'] == 'value1'


# Generated at 2022-06-22 21:27:26.032933
# Unit test for function count
def test_count():
    """Function to test the functionality of the count function above"""
    test_sequence = ['a', 'a', 'b', 'c', 'c', 'c']
    test_dict = {'a': 2, 'b': 1, 'c': 3}
    assert count(test_sequence) == test_dict



# Generated at 2022-06-22 21:27:29.688831
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    test_dict = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert repr(test_dict) == 'ImmutableDict({\'key1\': \'value1\', \'key2\': \'value2\'})'


# Generated at 2022-06-22 21:27:36.410232
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence([0])
    assert is_sequence((0,))
    assert is_sequence(set())
    assert is_sequence(range(10))
    assert is_sequence(xrange(10))
    assert not is_sequence(1)
    assert not is_sequence(dict())
    assert not is_sequence(iter([]))
    assert not is_sequence(None)
    assert not is_sequence('abc')
    assert not is_sequence(b'abc')

    # Unit test for function count

# Generated at 2022-06-22 21:27:43.569059
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence([1, 2, 4, 8])
    assert not is_sequence({})
    assert not is_sequence('abc')
    assert is_sequence('abc', include_strings=True)
    assert not is_sequence({'a': 1, 'c': 2, 'e': 3}, include_strings=True)
    assert not is_sequence(['a', 'b', 'c'], include_strings=True)

# Generated at 2022-06-22 21:27:51.921906
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict()
    assert len(d) == 0
    d = ImmutableDict(a='a')
    assert len(d) == 1
    d = ImmutableDict(a='a', b='b')
    assert len(d) == 2
    d = ImmutableDict(a='a', b='b', c='c')
    assert len(d) == 3
    d = ImmutableDict(a='a', b='b', c='c', d='d')
    assert len(d) == 4


# Generated at 2022-06-22 21:28:01.500566
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    assert hash(ImmutableDict({'a': 1, 'b': 2})) == hash(ImmutableDict({'b': 2, 'a': 1}))
    assert hash(ImmutableDict({'a': 1, 'b': 2})) != hash(ImmutableDict({'a': 1, 'b': 3}))
    assert hash(ImmutableDict({'a': 1, 'b': 2})) != hash(ImmutableDict({'a': 1, 'b': 2, 'c': 3}))
    assert hash(ImmutableDict({'a': 1, 'b': 2})) != hash(ImmutableDict({'a': 1}))
    assert hash(ImmutableDict({'a': 1, 'b': 2})) != hash(ImmutableDict({'c': 1, 'b': 2}))

# Generated at 2022-06-22 21:28:13.556412
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    source = {'a': 1, 'b': 2}
    immutabledict = ImmutableDict(source)
    assert immutabledict['a'] == 1
    assert immutabledict['b'] == 2
    # mutate source
    source['b'] = 3
    assert immutabledict['b'] == 2
    # create a new ImmutableDict to overwrite key 'b' with a new value
    new_immutabledict = immutabledict.union({'a': 3, 'b': 4})
    assert new_immutabledict['a'] == 3
    assert new_immutabledict['b'] == 4
    # create a new ImmutableDict to remove key 'a'
    new_immutabledict = immutabledict.difference('a')
    assert new_immutabledict['a']

# Generated at 2022-06-22 21:28:17.754643
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Test the difference method
    """
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    subtractive_items = ['a', 'c']
    assert original.difference(subtractive_items) == ImmutableDict({'b': 2})



# Generated at 2022-06-22 21:28:23.341293
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'b': 3, 'c': 4})
    dict3 = dict1.union(dict2)
    assert dict2 == dict3, 'Failed to create ImmutableDict as union of dict1 and dict2'
    assert dict2 is not dict1, 'Failed to create ImmutableDict as union of dict1 and dict2'


# Generated at 2022-06-22 21:28:34.546186
# Unit test for function count
def test_count():
    assert count(list('abbccc')) == {'a': 1, 'b': 2, 'c': 3}
    assert count(set('abbccc')) == {'a': 1, 'b': 1, 'c': 1}
    assert count({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 1, 'c': 1}
    try:
        count('a')
    except Exception as e:
        assert e.message == 'Argument provided  is not an iterable'
    try:
        count(1)
    except Exception as e:
        assert e.message == 'Argument provided  is not an iterable'


# Generated at 2022-06-22 21:28:40.578716
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    # Construct ImmutableDict  using dict() and dict literal
    dict_one = ImmutableDict( {'a' : 1, 'b' : 2, 'c' : 3} )
    dict_two = ImmutableDict( dict(a=1,b=2,c=3) )

    assert dict_one['b'] == dict_two['b'] == 2  # both dictionaries defined above are equivalent



# Generated at 2022-06-22 21:28:53.076477
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """ Test that the hash of an ImmutableDict is the same as a hash of a frozenset(ImmutableDict.items()).
    This is required for hashes of ImmutableDicts to be equal, when the contents are equal.
    As ImmutableDicts are intended to be used as keys in other Dicts, this is important
    """
    immutable_dict_1 = ImmutableDict({'key1':'value1'})
    immutable_dict_2 = ImmutableDict({'key1':'value1'})
    immutable_dict_3 = ImmutableDict({'key1':'value1', 'key2':'value2'})

    # Test that the hash of the ImmutableDict is the same as a hash of a frozenset(ImmutableDict.items())
    assert hash(immutable_dict_1) == hash

# Generated at 2022-06-22 21:29:05.525481
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('Hello')
    assert is_iterable(['Hello'])
    assert not is_iterable('Hello', include_strings=False)
    assert is_iterable('Hello', include_strings=True)
    assert is_iterable({'hello': 'world'})
    assert not is_iterable({'hello': 'world'}.keys())
    assert is_iterable(dict({'hello': 'world'}.keys()))  # dict is iterable
    assert not is_iterable(None)
    # is_iterable should return False, but returns True in python3
    assert not is_iterable(bytearray('Hello', 'utf-8'))
    # is_iterable should return True, but returns False in python2
    assert is_iterable(type('', (), {}))


# Unit test

# Generated at 2022-06-22 21:29:12.829056
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    assert ImmutableDict({'k': 'v'}) == ImmutableDict({'k': 'v'})
    assert ImmutableDict({'k': 'v'}) != ImmutableDict({'k': 'v', 'k1': 'v1'})
    assert ImmutableDict({'k1': 'v1'}) != ImmutableDict({'k': 'v'})
    assert ImmutableDict({'k': 'v2'}) != ImmutableDict({'k': 'v'})
    assert ImmutableDict({'k': 'v'}) != {'k': 'v'}


# Generated at 2022-06-22 21:29:19.134517
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_dict = ImmutableDict({1: 'a', 2: 'b', 3: 'c', 4: 'd', 5: 'e'})
    expected_difference = ImmutableDict({1: 'a', 2: 'b', 3: 'c'})
    actual_difference = test_dict.difference({4, 5})

    assert expected_difference == actual_difference



# Generated at 2022-06-22 21:29:24.129645
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """
    Testing __len__ method by creating an ImmutableDict and asserting the results
    of len(ImmutableDict)
    """
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert len(d) == 3



# Generated at 2022-06-22 21:29:27.528960
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    arg = {'a': 1, 'b': 2, 'c': 0}
    t = ImmutableDict(arg)
    assert t['a'] == 1
    assert t['c'] == 0


# Generated at 2022-06-22 21:29:30.935891
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert ImmutableDict({'a': 1, 'b': 2}).__repr__() == "ImmutableDict({'a': 1, 'b': 2})"

# Generated at 2022-06-22 21:29:36.936957
# Unit test for function is_iterable
def test_is_iterable():
    """Tests for is_iterable function."""
    assert is_iterable(range(10))
    assert is_iterable([1, 2, 3])
    assert is_iterable(set([1, 2]))
    assert is_iterable({1: None, 2: None})
    assert is_iterable(u'unicode')
    assert not is_iterable(1)
    assert not is_iterable(None)

    assert is_iterable(range(10), include_strings=True)
    assert is_iterable([1, 2, 3], include_strings=True)
    assert is_iterable(set([1, 2]), include_strings=True)
    assert is_iterable({1: None, 2: None}, include_strings=True)

# Generated at 2022-06-22 21:29:49.294608
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d1 = ImmutableDict(a=1, b=2, c=3)
    d2 = ImmutableDict(a=1, b=2, c=3, d=4)
    d3 = ImmutableDict(a=1, b=2, c=3)

    d4 = d1.difference(['a'])
    assert d1 != d2
    assert d1 != d3
    assert d1 == d4.difference(['b', 'c'])
    assert d1 != d4.difference(['b'])
    assert d1 != d4.difference(['c'])
    assert d4 != d4.difference(['a'])
    assert d4 != d4.difference(['a', 'b'])

# Generated at 2022-06-22 21:29:53.312998
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    data = {'a': 1, 'b': 2}
    immutabledict = ImmutableDict(**data)
    assert len(immutabledict) == len(data)
    for k, v in immutabledict.items():
        assert k in data and data[k] == v


# Generated at 2022-06-22 21:29:58.958798
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Test class ImmutableDict constructor"""
    source = {'test1': 1, 'test2': 2}
    # Create an ImmutableDict using dict
    # Should pass
    ImmutableDict(source)

    # Create an ImmutableDict using **
    # Should pass
    ImmutableDict(**source)

    # Create an ImmutableDict using invalid args
    # Should fail
    try:
        ImmutableDict(1)
    except TypeError:
        pass
