

# Generated at 2022-06-22 21:20:02.134489
# Unit test for function is_iterable
def test_is_iterable():
    class TestIterable(object):
        def __iter__(self):
            return iter([1, 2, 3])

    class TestNonIterable(object):
        pass

    assert is_iterable('abc')
    assert is_iterable([1, 2, 3])
    assert is_iterable(TestIterable())

    assert not is_iterable(1)
    assert not is_iterable(TestNonIterable())



# Generated at 2022-06-22 21:20:13.611257
# Unit test for function count
def test_count():
    assert count((1, 2, 3, 4, 5, 1, 2, 3, 4, 1, 2, 3, 1, 2, 2, 3, 2, 3, 2)) == {1: 4, 2: 7, 3: 5, 4: 2, 5: 1}
    assert count(('a', 'a', 'a', 'a', 'a', 'a', 'b', 'b', 'b', 'b', 'c', 'c')) == {'a': 6, 'b': 4, 'c': 2}
    assert count(('a', 'b', 1, 2, 'a', 'b', 3, 4, 'a', 'b')) == {1: 1, 2: 1, 3: 1, 4: 1, 'a': 3, 'b': 3}

# Generated at 2022-06-22 21:20:16.161218
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict({1: 1, 2: 2, 3: 3})
    assert repr(d) == 'ImmutableDict({1: 1, 2: 2, 3: 3})'


# Generated at 2022-06-22 21:20:20.885246
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_dict_items = list(test_dict)
    assert len(test_dict_items) == 3
    test_dict_items.sort()
    assert test_dict_items == ['a', 'b', 'c']


# Generated at 2022-06-22 21:20:24.232194
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    immutableDict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})

    observed_items = set()
    for k in immutableDict:
        observed_items.add(k)

    assert observed_items == {'a', 'b', 'c'}


# Generated at 2022-06-22 21:20:34.173207
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    from ansible.module_utils.basic import AnsibleModule

    def run_module():
        module_args = dict(
            input_dict=dict(
                key1='value1',
                key2='value2',
                key3='value3',
            )
        )

        result = dict(
            changed=False,
            input_dict=dict(),
            key1='',
            key2='',
        )

        module = AnsibleModule(
            argument_spec=dict(
                input_dict=dict(type='dict', required=True),
            ),
            supports_check_mode=True
        )

        if module.params['input_dict']:
            result['input_dict'] = module.params['input_dict']
            immutable_dict = ImmutableDict(module.params['input_dict'])


# Generated at 2022-06-22 21:20:44.339497
# Unit test for function is_sequence
def test_is_sequence():
    assert not is_sequence(u'abcd')
    assert not is_sequence(b'abcd')
    assert is_sequence([u'abcd'])
    assert is_sequence([b'abcd'])
    assert is_sequence((1, 2, 3))
    assert is_sequence([1, 2, 3])
    assert not is_sequence(1)
    assert not is_sequence(None)
    assert not is_sequence(set([1, 2, 3]))
    assert is_sequence(set([1, 2, 3]), include_strings=True)
    assert not is_sequence(MutableMapping())
    assert not is_sequence(ImmutableDict())
    assert is_sequence(ImmutableDict(), include_strings=True)

# Generated at 2022-06-22 21:20:50.966296
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():

    d1 = ImmutableDict([('a', 1), ('b', 2), ('c', 3)])

    assert(d1.difference(['a']) == ImmutableDict([('b', 2), ('c', 3)]))

    assert(d1.difference(['a', 'b']) == ImmutableDict([('c', 3)]))

    assert(d1.difference(['a', 'b', 'c']) == ImmutableDict())

    # Tests for nested ImmutableDicts
    d1 = ImmutableDict([('a', 1), ('b', 2), ('c', ImmutableDict([('d', 3), ('e', 4)]))])

    assert(d1.difference(['c']) == ImmutableDict([('a', 1), ('b', 2)]))


# Generated at 2022-06-22 21:21:03.053723
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # test ImmutableDict with the same content
    dict_1 = dict(a=1, b=1)
    dict_2 = dict(a=1, b=1)
    immutable_dict_1 = ImmutableDict(dict_1)
    immutable_dict_2 = ImmutableDict(dict_2)
    assert immutable_dict_1 == immutable_dict_2

    # test ImmutableDict with the different content
    dict_1 = dict(a=1, b=1)
    dict_2 = dict(a=1, b=2)
    immutable_dict_1 = ImmutableDict(dict_1)
    immutable_dict_2 = ImmutableDict(dict_2)
    assert immutable_dict_1 != immutable_dict_

# Generated at 2022-06-22 21:21:07.821379
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable('test')
    assert is_iterable(1)
    assert is_iterable(True)
    assert is_iterable(1.0)
    assert is_iterable(object())

    assert not is_iterable()


# Generated at 2022-06-22 21:21:12.572956
# Unit test for function count
def test_count():
    assert count([1, 2, 3]) == {1: 1, 2: 1, 3: 1}
    assert count([1, 2, 2, 4, 5]) == {1: 1, 2: 2, 4: 1, 5: 1}
    assert count([1, 2, 2, 4, 5, 1]) == {1: 2, 2: 2, 4: 1, 5: 1}
    assert count([]) == {}



# Generated at 2022-06-22 21:21:24.151272
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    # Test union with an empty dict
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert test_dict.union({}) == test_dict
    # Test union with a non-empty dict
    assert test_dict.union({'d': 4}) == ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    # Test union with an ImmutableDict
    assert test_dict.union(ImmutableDict({'d': 4})) == ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    # Test union that replaces a key-value pair

# Generated at 2022-06-22 21:21:29.850846
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    d = ImmutableDict({'a': 1, 'b': 2})
    e = ImmutableDict({'c': 1})
    f = d.union(e)
    g = f.union({'b': 3})
    assert f == ImmutableDict({'a': 1, 'b': 2, 'c': 1})
    assert g == ImmutableDict({'a': 1, 'b': 3, 'c': 1})


# Generated at 2022-06-22 21:21:31.688971
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    dct = ImmutableDict({'a': 1, 'b': 2})
    assert len(dct) == 2


# Generated at 2022-06-22 21:21:39.779705
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    impl = ImmutableDict(a=1, b=2, c=3)

    # we do not use impl.__iter__() method directly, since
    # we want to be able to support python 2.6 as well
    iterator = iter(impl)
    result = {
        text_type(x): y
        for x, y in zip(iterator, iterator)
    }

    assert result == {
        'a': '1',
        'b': '2',
        'c': '3'
    }


# Generated at 2022-06-22 21:21:42.145566
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    ImmutableDict_obj = ImmutableDict()
    assert 0 == type(ImmutableDict_obj.__len__())

# Generated at 2022-06-22 21:21:44.273020
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    v = ImmutableDict({'a': 1, 'b': 2})
    assert v['a'] == 1


# Generated at 2022-06-22 21:21:56.080359
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    # Test for when there are no items in immutable dict
    assert repr(ImmutableDict()) == 'ImmutableDict({})'

    # Test for when there are items in immutable dict,
    # with key 'asd' and value 'foo'
    example_dict = {'asd':'foo'}
    assert repr(ImmutableDict(example_dict)) == "ImmutableDict({'asd': 'foo'})"

    # Test for when there are multiple items in immutable dict,
    # with key 'asd' and value 'foo',
    # and key 'qwe' and value 'bar'
    example_dict = {'asd':'foo', 'qwe':'bar'}

# Generated at 2022-06-22 21:21:56.974439
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    a = ImmutableDict(a=1, b=2)
    assert a["a"] == 1


# Generated at 2022-06-22 21:22:01.714053
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d = ImmutableDict(a='b', c='d', e='f')
    assert d.difference(('a')) == ImmutableDict(c='d', e='f')
    assert d.difference(('a', 'c')) == ImmutableDict(e='f')
    assert d.difference(('a', 'b', 'c', 'd', 'e', 'f')) == ImmutableDict()
    assert d.difference(('z')) == d

# Generated at 2022-06-22 21:22:04.024375
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    with pytest.raises(AttributeError):
        x = ImmutableDict(name='Ola', age=22)
        x.name = 'Ola'


# Generated at 2022-06-22 21:22:10.139080
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict({'a': 1, 'b': 2})
    overriding_mapping = {'b': 3, 'c': 4}
    result = original.union(overriding_mapping)
    assert result == ImmutableDict({'a': 1, 'b': 3, 'c': 4})



# Generated at 2022-06-22 21:22:14.254667
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    mydict = ImmutableDict({'key1':'value1', 'key2':'value2'})
    # items is a generator
    result = set(mydict.items())
    assert result == {('key1','value1'),('key2','value2')}



# Generated at 2022-06-22 21:22:18.471462
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Example usage:
        >>> immutable_dict = ImmutableDict({"a": 1, "b": 2})
        >>> immutable_dict.difference(["a", "b", "c"])
        ImmutableDict({})
        >>> immutable_dict.difference(["a"])
        ImmutableDict({'b': 2})
    """
    pass



# Generated at 2022-06-22 21:22:24.498036
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Arrange
    dict1 = ImmutableDict(
        {'a': 1, 'b': 2, 'c': 3}
    )
    dict2 = ImmutableDict(
        {'a': 1, 'b': 2, 'c': 3}
    )
    dict3 = ImmutableDict(
        {'a': 3, 'b': 2, 'c': 1}
    )

    # Assert
    assert(dict1 == dict2)
    assert(dict1 == dict3)


# Generated at 2022-06-22 21:22:31.943709
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2])
    assert is_iterable(("a", "b"))
    assert is_iterable(set())
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(iter([]))
    assert is_iterable(iter(set()))
    assert is_iterable(iter({'a': 1, 'b': 2}))
    assert not is_iterable(0)
    assert not is_iterable("")
    assert not is_iterable(True)
    assert not is_iterable(None)


# Generated at 2022-06-22 21:22:34.148655
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    result = ImmutableDict({'key': 'value'})
    assert result['key'] == 'value'



# Generated at 2022-06-22 21:22:40.265937
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d.__hash__() == hash(frozenset({'a': 1, 'b': 2, 'c': 3}.items()))
    with pytest.raises(TypeError):
        assert d == {'a': 1, 'b': 2, 'c': 3}


# Generated at 2022-06-22 21:22:44.340089
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    id1 = ImmutableDict(a=1, b=2)
    id2 = ImmutableDict(a=1, b=2)
    id3 = ImmutableDict(a=2, b=2)
    assert id1 == id2
    assert id1 != id3


# Generated at 2022-06-22 21:22:51.912837
# Unit test for function is_string
def test_is_string():
    """Validate behavior of is_string

    :raises: AssertionError if test fails
    """
    import ansible.parsing.vault as vault
    # Test for strings
    assert is_string('Hello')
    assert is_string(u'Hello')

# Generated at 2022-06-22 21:22:56.622813
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test1 = dict(a=1, b=2, c=3, d=4, e=5)
    test2 = ImmutableDict(test1)
    difference1 = test2.difference(['a', 'b'])
    difference2 = test2.difference(['c', 'd'])
    assert difference1.union(difference2) == test2


# Generated at 2022-06-22 21:23:00.324186
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    result = original.difference(['a', 'b'])
    assert result == ImmutableDict({'c': 3})


# Generated at 2022-06-22 21:23:02.063036
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2])
    assert not is_sequence(1)
    assert is_sequence(set([1,2]))
    assert not is_sequence(set([1,2]), include_strings=True)

# Generated at 2022-06-22 21:23:08.298983
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict(a=1) == ImmutableDict(a=1)
    assert ImmutableDict(a=3, b=4) == ImmutableDict(a=3, b=4)

    assert not (ImmutableDict() == ImmutableDict(a=3, b=4))
    assert not (ImmutableDict(a=1) == ImmutableDict(a=1, b=4))
    assert not (ImmutableDict(a=1, b=4) == ImmutableDict(a=1, b=1))

    assert not (ImmutableDict() == None)



# Generated at 2022-06-22 21:23:17.494622
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d = ImmutableDict({'a': 1, 'b': 2})
    d_self = ImmutableDict({'a': 1, 'b': 2})

    e = ImmutableDict({'a': 1, 'b': 2})
    e_self = ImmutableDict({'a': 1, 'b': 2})

    f = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    f_self = ImmutableDict({'a': 1, 'b': 2, 'c': 3})

    assert d == d_self
    assert e == e_self
    assert f == f_self

    assert d != e
    assert d != f
    assert e != f

    # testing the __hash__ method too
    assert hash(d) == hash(d_self)
    assert hash

# Generated at 2022-06-22 21:23:23.715408
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    expected = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    in_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    new_dict = in_dict.union({'d': 4})
    assert new_dict == expected
    expected = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    new_dict = in_dict.union({'c': 4})
    assert new_dict == expected
    expected = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    new_dict = in_dict.union({'c': 5})
    assert new_dict != expected


# Generated at 2022-06-22 21:23:29.527464
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    a = ImmutableDict(a='a', b='b', c='c')
    b = {'d': 'd', 'e': 'e'}
    assert a.difference(b.keys()).union(b).union(a) == dict(a=a.a, b=a.b, c=a.c, d=b['d'], e=b['e'])
    assert a.difference(b.keys()) == dict(a=a.a, b=a.b, c=a.c)

# Generated at 2022-06-22 21:23:33.504640
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    """Test for the iter() method for class ImmutableDict"""
    a = ImmutableDict(foo="bar", baz=42)
    assert set(iter(a)) == set(['foo', 'baz'])


# Generated at 2022-06-22 21:23:35.956513
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Test for method __repr__ of class ImmutableDict"""
    assert ImmutableDict({'a': 1}).__repr__() == "ImmutableDict({'a': 1})"



# Generated at 2022-06-22 21:23:39.061406
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    assert isinstance(hash(ImmutableDict([('a', 1), ('b', 2)])), int)


# Generated at 2022-06-22 21:23:43.113641
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    temp_dict = ImmutableDict({'a': 10, 'b': 20, 'c': 30, 'd': 40})
    test_dict = temp_dict.difference(['b', 'c'])
    assert test_dict == {'a': 10, 'd': 40}


# Generated at 2022-06-22 21:23:50.528689
# Unit test for function is_sequence
def test_is_sequence():
    assert not is_sequence(None)
    assert not is_sequence(0)
    assert not is_sequence(0.0)
    assert not is_sequence('not a sequence')
    assert not is_sequence(b'not a sequence')
    assert not is_sequence({'not a sequence': 0})

# Generated at 2022-06-22 21:23:59.796486
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence((1, 2, 3))
    assert is_sequence([1, 2, 3])
    assert is_sequence({'value': 1})
    assert is_sequence('one')
    assert is_sequence(b'one')
    assert is_sequence({'one', 'two'})
    assert is_sequence(frozenset({'one', 'two'}))
    assert is_sequence(range(3))

    assert is_sequence((1, 2, 3), include_strings=True)
    assert is_sequence([1, 2, 3], include_strings=True)
    assert is_sequence({'value': 1}, include_strings=True)
    assert is_sequence('one', include_strings=True)
    assert is_sequence(b'one', include_strings=True)

# Generated at 2022-06-22 21:24:08.906076
# Unit test for function count
def test_count():
    assert {'a': 4, 'b': 3, 'c': 2} == count('aabbbccaa')
    assert {1: 1, 2: 3, 3: 1} == count([1, 2, 2, 2, 3, 2])
    assert {(1, 2): 1, (3, 4): 1} == count([(1, 2), (3, 4)])
    assert {} == count({})
    assert {1: 1, 2: 1, 3: 1} == count({1: 2, 2: 3, 3: 1})

#
# Iterator over sequence and element index
#


# Generated at 2022-06-22 21:24:19.280574
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    assert hash(ImmutableDict()) == hash(ImmutableDict())
    assert hash(ImmutableDict(dict1="value1", dict2="value2")) == hash(ImmutableDict(dict1="value1", dict2="value2"))
    assert hash(ImmutableDict(dict1="value1", dict2="value2")) != hash(ImmutableDict(dict1="value1", dict2="value3"))
    assert hash(ImmutableDict(dict1="value1", dict2="value2", dict3="value3")) == hash(ImmutableDict(dict1="value1", dict2="value2", dict3="value3"))

# Generated at 2022-06-22 21:24:27.366814
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})

    class Foo:
        def __init__(self, adict):
            self._adict = adict

        def __hash__(self):
            return hash(frozenset(self._adict.items()))

    assert immutable_dict == Foo({'a': 1, 'c': 3, 'b': 2})
    assert immutable_dict != Foo({'a': 1, 'b': 2})
    assert immutable_dict != ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-22 21:24:31.467061
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():

    d = ImmutableDict({"k1": "v1", "k2": "v2"})

    assert list(d.__iter__()) == ["k1", "k2"]



# Generated at 2022-06-22 21:24:34.196432
# Unit test for function is_string
def test_is_string():
    assert is_string('string')
    assert is_string(u'string')
    assert not is_string([])


# Generated at 2022-06-22 21:24:38.050277
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    test_dict = ImmutableDict({"test1": "test1", "test2": "test2"})
    assert test_dict['test1'] == "test1"
    assert test_dict['test2'] == "test2"


# Generated at 2022-06-22 21:24:40.704182
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    iDict = ImmutableDict(a="b")
    assert repr(iDict) == "ImmutableDict({'a': 'b'})"


# Generated at 2022-06-22 21:24:43.085830
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    dictionary = ImmutableDict({'key': 'value'})
    assert dictionary['key'] == 'value'


# Generated at 2022-06-22 21:24:45.275005
# Unit test for function is_string
def test_is_string():
    assert not is_string([])
    assert is_string("abc")


# Generated at 2022-06-22 21:24:56.803082
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict(a=1, b=2)
    b = ImmutableDict(b=2, a=1)
    c = dict(a=1, b=2)
    # assert that two ImmutableDicts are equal if their stores are equal
    assert a == b
    # assert that an ImmutableDict does not equal a dict if the dict has equal key-value pairs
    assert a != c
    # assert that an ImmutableDict does not equal a dict even if the dict has the same hash value
    assert c.__hash__() == b.__hash__()
    # assert that an ImmutableDict does not equal a dict even if the dict has the same items
    assert a.items() == c.items()

# Generated at 2022-06-22 21:25:02.368455
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original_mapping = ImmutableDict({'a': 1, 'c': 3, 'd': 4})
    subtract_set = set(('a', 'c'))
    expected_difference = {'d': 4}
    actual_difference = original_mapping.difference(subtract_set)
    assert isinstance(actual_difference, ImmutableDict)
    assert actual_difference == expected_difference


# Generated at 2022-06-22 21:25:08.275924
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    data = { 'key1': 'value1', 'key2': 'value2'}
    immutable_dict = ImmutableDict(data)
    assert immutable_dict['key1'] == 'value1'
    assert immutable_dict['key2'] == 'value2'
    assert immutable_dict.get('key3') is None


# Generated at 2022-06-22 21:25:10.804552
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    assert list(ImmutableDict(a=1, b=2, c=3).__iter__()) == ['a', 'b', 'c']


# Generated at 2022-06-22 21:25:13.351689
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict({'a': 1, 'b': 2})
    for k in d:
        assert k in ('a', 'b')


# Generated at 2022-06-22 21:25:15.893673
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    x = ImmutableDict([('a', 3), ('b', 4)])
    y = x.__len__()
    assert y == 2


# Generated at 2022-06-22 21:25:19.956358
# Unit test for function is_iterable
def test_is_iterable():
    test_iterable = list(range(10))
    test_string = 'string'
    test_non_iterable = 123
    assert is_iterable(test_iterable)
    assert not is_iterable(test_string)
    assert not is_iterable(test_non_iterable)

# Generated at 2022-06-22 21:25:26.584760
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # now test difference
    # test passing a list containing the key that needs to be removed
    m = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    n = m.difference(['b'])
    assert 'b' not in n
    assert n == {'a': 1, 'c': 3}

    # test passing list containing keys
    n = m.difference(['c', 'a'])
    assert 'a' not in n
    assert 'c' not in n
    assert n == {'b': 2}

    # test passing an empty list
    n = m.difference([])
    assert n == m

    # test passing an empty tuple
    n = m.difference(())
    assert n == m

    # test passing an empty tuple
    n = m.difference

# Generated at 2022-06-22 21:25:29.004270
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict({1: 1, 2: 2})) == 2


# Generated at 2022-06-22 21:25:33.003705
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """Test that __len__ method of class ImmutableDict works as expected"""
    dct = ImmutableDict(a=100, b=200, c=300)
    assert len(dct) == 3


# Generated at 2022-06-22 21:25:35.633124
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    # Test that __len__ method of ImmutableDict class works as expected
    test_ImmutableDict_obj = ImmutableDict({1: 2, 3: 4, 5: 6})
    assert len(test_ImmutableDict_obj) == 3



# Generated at 2022-06-22 21:25:38.891485
# Unit test for function is_string
def test_is_string():
    assert is_string('A')
    assert is_string(u'A')
    assert is_string(b'A')
    assert is_string(5) is False



# Generated at 2022-06-22 21:25:51.201861
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d = ImmutableDict({'a': 1, 'b':2, 'c': 3})
    d = d.difference(['a'])
    assert len(d) == 2
    assert d['b'] == 2
    assert d['c'] == 3

    d = ImmutableDict({'a': 1, 'b':2, 'c': 3})
    d = d.difference({'a': 1})
    assert len(d) == 2
    assert d['b'] == 2
    assert d['c'] == 3

    d = ImmutableDict({'a': 1, 'b':2, 'c': 3})
    d = d.difference((('a', 1),))
    assert len(d) == 2
    assert d['b'] == 2
    assert d['c'] == 3

    d = Imm

# Generated at 2022-06-22 21:25:58.586113
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    try:
        my_store = {1: 'Larry', 2: 'Curly', 3: 'Moe'}
        my_immutable_dict = ImmutableDict(my_store)
        my_iterator = iter(my_immutable_dict)
        assert (next(my_iterator) == 1)
        assert (next(my_iterator) == 2)
        assert (next(my_iterator) == 3)
        assert (next(my_iterator) == StopIteration)
    except Exception as exception:
        print('Something went wrong: {0}'.format(exception))
        raise



# Generated at 2022-06-22 21:26:01.433925
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    id_ = ImmutableDict({1:2})
    assert hasattr(id_, '__len__')
    assert len(id_) == 1


# Generated at 2022-06-22 21:26:06.839726
# Unit test for function count
def test_count():
    assert count([1, 1, 2, 3]) == {1: 2, 2: 1, 3: 1}
    assert count([1, 1, 2, 3, 2, 4]) == {1: 2, 2: 2, 3: 1, 4: 1}
    assert count('aac') == {'a': 2, 'c': 1}



# Generated at 2022-06-22 21:26:12.909743
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    source = dict(a=1, b=2, c=3, d=4, e=5)
    immutable_dict = ImmutableDict(source)
    expected_result = dict(a=1, b=2)
    actual_result = immutable_dict.difference(dict(c=3, d=4, e=5))
    assert expected_result == actual_result

# Generated at 2022-06-22 21:26:20.774996
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Assert that __eq__ method of ImmutableDict returns True when passed other dict with same
    key-value pairs.
    """
    a = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})
    b = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})
    assert a == b

    c = {1: 'one', 2: 'two', 3: 'three'}
    assert a == c

    d = {1: 'one', 2: 'two', 3: 'three', 4: 'four'}
    assert a != d

    # Test comparison of object of different type
    assert a != 1



# Generated at 2022-06-22 21:26:29.250534
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_1 = ImmutableDict({'a': 1})
    immutable_dict_2 = ImmutableDict({'a': 1})
    immutable_dict_3 = ImmutableDict({'a': 2})
    immutable_dict_4 = ImmutableDict({'b': 2})
    dict_1 = {'a': 1}
    dict_2 = {'a': 1}
    dict_3 = {'a': 2}
    dict_4 = {'b': 2}
    assert immutable_dict_1 == immutable_dict_1
    assert immutable_dict_1 == immutable_dict_2
    assert immutable_dict_1 != immutable_dict_3
    assert immutable_dict_1 != immutable_dict_4
    assert immutable_dict_1 == dict_1
    assert immutable_dict_1 == dict_2

# Generated at 2022-06-22 21:26:40.677603
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    # Test case 1: Access element in the dictionary

    # Input: A dictionary with a key and value
    # Expected result: The value corresponding to the key
    dct_1 = ImmutableDict({"key1":"value1"})
    assert dct_1["key1"] == "value1"
    assert dct_1["key1"] is not "value1"

    # Test case 2: Access element in the dictionary

    # Input: A dictionary with keys and values
    # Expected result: The values corresponding to the keys
    dct_2 = ImmutableDict({"key1":"value1", "key2":"value2"})
    assert dct_2["key1"] == "value1"
    assert dct_2["key2"] == "value2"

# Generated at 2022-06-22 21:26:50.147336
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    import random

    class Object(object):

        def __init__(self, name):
            self.name = name

        def __hash__(self):
            class_hash = hash(type(self))
            return hash((class_hash, self.name))

        def __eq__(self, other):
            return (type(self) == type(other) and self.name == other.name)

        def __repr__(self):
            return "Object(%s)" % self.name

    class Object2(Object):
        pass

    # Generate random hashable objects
    objects = [Object(str(i)) for i in range(10)]
    random.shuffle(objects)

    # Create hashable mutable dict
    mutable_dict = dict()
    for obj in objects:
        mutable_dict[obj]

# Generated at 2022-06-22 21:26:57.265545
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence([1, 2, 3])
    assert is_sequence(['a', 'b', 'c'])
    assert not is_sequence(('a', 'b', 'c'))
    assert not is_sequence({'a': 1, 'b': 2})
    assert not is_sequence('abc')
    assert is_sequence('abc', include_strings=True)


# Generated at 2022-06-22 21:27:01.615755
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    a = ImmutableDict(a=1, b=2, c=3)
    b = a.difference(['a', 'b'])
    assert a == ImmutableDict(a=1, b=2, c=3)
    assert b == ImmutableDict(c=3)

# Generated at 2022-06-22 21:27:13.130339
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    test_dict = ImmutableDict({"a": 1, "b": 2})
    # Test __setitem__
    try:
        test_dict["a"] = 5
        assert False, "Test __setitem__ failed"
    except KeyError:
        pass
    # Test __delitem__
    try:
        del test_dict["a"]
        assert False, "Test __delitem__ failed"
    except KeyError:
        pass
    # Test update
    try:
        test_dict.update({"a": 5})
        assert False, "Test update failed"
    except AttributeError:
        pass
    # Test pop
    try:
        test_dict.pop("a")
        assert False, "Test pop failed"
    except AttributeError:
        pass
    # Test popitem

# Generated at 2022-06-22 21:27:23.185483
# Unit test for function count
def test_count():
    # Negative test
    try:
        count(10)
        assert False
    except:
        assert True

    # Positive tests
    # Iterable with duplicates
    assert count([1, 2, 3, 1, 1, 2, 3, 4, 5, 5]) == {1: 3, 2: 2, 3: 2, 4: 1, 5: 2}

    # Iterable without duplicates
    assert count([1, 2, 3, 4]) == {1: 1, 2: 1, 3: 1, 4: 1}

    # Non-iterable object
    assert count(10) == {10: 1}



# Generated at 2022-06-22 21:27:26.907294
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    lhs = ImmutableDict(a=1, b=2, c=3)
    rhs = ImmutableDict(a=1, b=2, c=3)

    assert hash(lhs) == hash(rhs)



# Generated at 2022-06-22 21:27:30.232626
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert is_sequence((1, 2, 3))
    assert not is_sequence('string')
    assert is_sequence('string', include_strings=True)

# Generated at 2022-06-22 21:27:34.548445
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    ID1 = ImmutableDict({"a": "aaa", "b": "bbb", "c": "ccc"})
    ID2 = ID1.difference(["a"])
    assert ID2 == ImmutableDict({"b": "bbb", "c": "ccc"})

# Generated at 2022-06-22 21:27:45.264145
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    a = ImmutableDict()
    b = ImmutableDict()
    assert hash(a) == hash(b)

    a = ImmutableDict({1:2, 3:4})
    b = ImmutableDict({3:4, 1:2})
    assert hash(a) == hash(b)

    a = ImmutableDict({1:2, 3:4})
    b = ImmutableDict({3:4, 1:2, 5:6})
    assert hash(a) != hash(b)

    a = ImmutableDict({1:2, 3:4})
    assert hash("not a ImmutableDict") != hash(a)


# Generated at 2022-06-22 21:27:50.710422
# Unit test for function is_string
def test_is_string():
    assert is_string('foobar')
    assert not is_string(['foo', 'bar'])
    assert not is_string([u'foo', u'bar'])
    assert not is_string(set(['foo', 'bar']))
    assert not is_string(12345)
    assert not is_string(None)
    assert not is_string(object())


# Generated at 2022-06-22 21:27:59.493283
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert ImmutableDict(a=1, b=2).__repr__() == "ImmutableDict({'a': 1, 'b': 2})"  # noqa
    assert ImmutableDict(a=1).__repr__() == "ImmutableDict({'a': 1})"  # noqa
    assert ImmutableDict(long_key_name="long_value_name").__repr__() == "ImmutableDict({'long_key_name': 'long_value_name'})"  # noqa
    assert ImmutableDict().__repr__() == "ImmutableDict({})"  # noqa


# Generated at 2022-06-22 21:28:08.014470
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence((1, 2, 3))
    assert is_sequence({1, 2, 3})
    assert is_sequence('abc') is False
    assert is_sequence(b'abc') is False
    assert is_sequence(set()) is False
    assert is_sequence('abc', include_strings=True)
    assert is_sequence(b'abc', include_strings=True)

# Generated at 2022-06-22 21:28:13.415851
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    dict_1 = ImmutableDict({'a1': '1a', 'b2': '2b', 'c3': '3c'})
    assert len(dict_1) == 3



# Generated at 2022-06-22 21:28:17.286066
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    a = ImmutableDict()
    assert len(a) == 0

    b = ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    assert len(b) == 3



# Generated at 2022-06-22 21:28:24.399923
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    >>> import ansible_collections.notstdlib.moveitallout.tests.test_utils as test_utils
    >>> test_utils.test_ImmutableDict___eq__()
    """
    a = ImmutableDict({'key1': 'value1', 'key2': 'value2',})
    b = ImmutableDict({'key1': 'value1', 'key2': 'value2',})
    c = ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3',})
    assert a == b
    assert a != c


# Generated at 2022-06-22 21:28:28.845824
# Unit test for function is_string
def test_is_string():
    assert is_string('Hello world!') is True
    assert is_string(b'Hello world!') is True
    assert is_string(1) is False
    assert is_string((1, 2, 3)) is False
    assert is_string([1, 2, 3]) is False
    assert is_string({'a': 1, 'b': 2}) is False



# Generated at 2022-06-22 21:28:33.120381
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    """
    ImmutableDict should return an iterator that iterates over its keys
    """
    immutable_dict = ImmutableDict({'a': 'b'})
    iterator = immutable_dict.__iter__()
    elements = list(iterator)
    assert('a' in elements)


# Generated at 2022-06-22 21:28:40.969193
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # test when hashes are equal, dicts are equal
    first_dict = ImmutableDict(a=1, b=2)
    second_dict = ImmutableDict(b=2, a=1)
    assert first_dict == second_dict
    # test when hashes are not equal, dicts are not equal
    first_dict = ImmutableDict(a=1, b=2)
    second_dict = ImmutableDict(b=2, a=2)
    assert first_dict != second_dict


# Generated at 2022-06-22 21:28:53.343248
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that ImmutableDict.__eq__ works as expected

    :return: Nothing
    """
    # Test that ImmutableDict.__eq__ works as expected

    # Test that 2 ImmutableDicts are equal if they have the same keys and values
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'b': 2, 'a': 1}) == ImmutableDict({'a': 1, 'b': 2})

    # Test that 2 ImmutableDicts are not equal if they have different keys
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableD

# Generated at 2022-06-22 21:28:57.732325
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    # create an ImmutableDict:
    a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    # check len:
    assert len(a) == 3



# Generated at 2022-06-22 21:29:08.861602
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    i_dict = ImmutableDict({'a': 1, 'b': '2', 'c': [1, 2, 3]})
    assert 'a' in i_dict
    assert i_dict['b'] == '2'
    assert i_dict.union({'a': 'new item'}) == ImmutableDict({'a': 'new item', 'b': '2', 'c': [1, 2, 3]})
    assert i_dict.union({'d': 'new item'}) == ImmutableDict({'a': 1, 'b': '2', 'c': [1, 2, 3], 'd': 'new item'})
    assert i_dict.difference(['b', 'c']) == ImmutableDict({'a': 1})

# Generated at 2022-06-22 21:29:20.684942
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    d = ImmutableDict({'a': 1, 'b': 2})
    assert d['a'] == 1
    assert d['b'] == 2
    assert len(d) == 2
    assert sorted(d.keys()) == ['a', 'b']
    assert sorted(d.values()) == [1, 2]
    assert sorted(d.items()) == [('a', 1), ('b', 2)]
    try:
        d['c'] = 3
    except Exception as e:
        assert isinstance(e, TypeError)
    try:
        d['a'] = '1'
    except Exception as e:
        assert isinstance(e, TypeError)
    try:
        d.update({'c': 3})
    except Exception as e:
        assert isinstance(e, TypeError)


# Generated at 2022-06-22 21:29:33.437650
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Unit test for ImmutableDict"""
    from ansible.compat.tests import unittest


    class TestIterable(object):
        def __init__(self, dict_test):
            self.dict_test = dict_test
            self.iter = iter(dict_test)

        def __iter__(self):
            return self

        def __next__(self):
            return next(self.iter)

    class TestImmutableDict(unittest.TestCase):
        """Unit test for ImmutableDict"""
        def __init__(self, *args, **kwargs):
            super(TestImmutableDict, self).__init__(*args, **kwargs)
            self.dict_test = {'key1': 'value1', 'key2': 'value2'}
            self.dict_empty

# Generated at 2022-06-22 21:29:37.419230
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    import pytest
    original = ImmutableDict(a=1, b=2, c=3)
    assert original.__repr__() == "ImmutableDict({'a': 1, 'b': 2, 'c': 3})"


# Generated at 2022-06-22 21:29:40.324206
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict({'a': 'b', 'c': 'd'})
    assert d['a'] == 'b'


# Generated at 2022-06-22 21:29:44.896265
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    dict_a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict_b = dict_a.union({'a': 2})
    assert dict_b == {'a': 2, 'b': 2, 'c': 3}



# Generated at 2022-06-22 21:29:51.188833
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    a = ImmutableDict({'a': 1, 'b': {'c': 'text'}})
    assert len(a) == 2 
    assert a['b']['c'] == 'text'
    assert 'a' in a
    assert 'c' not in a
    assert a.union({'a': 100})['a'] == 100
    assert a.difference(['b'])['b'] is not 'text'

# Generated at 2022-06-22 21:29:56.276450
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict({'key': 'value'})) == 1

    assert len(ImmutableDict()) == 0

    list_of_tuples = [('key1', 'value1'), ('key2', 'value2')]
    assert len(ImmutableDict(list_of_tuples)) == 2

