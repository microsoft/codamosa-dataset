

# Generated at 2022-06-22 21:20:05.430144
# Unit test for function is_string
def test_is_string():
    """Ensure is_string returns True for string-like types and False for others."""
    from ansible.module_utils.six import string_types
    from ansible.parsing.vault import VaultLib, VaultSecret

    for string_type in (text_type, binary_type):
        assert is_string(string_type())

    assert is_string(VaultLib.encrypt('test password', None))

    assert not is_string([])
    assert not is_string(())
    assert not is_string({})
    assert not is_string(test_is_string)



# Generated at 2022-06-22 21:20:07.118276
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    test = ImmutableDict({"abc": 123})
    assert repr(test) == "ImmutableDict({'abc': 123})"


# Generated at 2022-06-22 21:20:18.622825
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    original = {'a': 1, 'b': 2, 'c': 3}
    my_dict = ImmutableDict(original)
    test_result = set([key for key in my_dict._store.keys()])
    expected_result = set(original.keys())
    assert expected_result == test_result, ("Method __iter__ does not yield "
                                            "expected result for keys()")
    test_result = set([key for key in my_dict.keys()])
    assert expected_result == test_result, ("Method __iter__ does not yield "
                                            "expected result for keys()")
    test_result = set([item for item in my_dict.items()])
    assert set(original.items()) == test_result, "Method __iter__ does not yield expected result for items()"

# Generated at 2022-06-22 21:20:27.241655
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    # Arrange
    immutable_dict = ImmutableDict({'a': 1, 'b': 2})

    # Act
    updated_dict = immutable_dict.union({'c': 3, 'd': 4, 'b': 20})
    updated_dict_orig = immutable_dict.union({'c': 3, 'd': 4, 'b': 20})

    # Assert
    assert updated_dict == updated_dict_orig
    assert updated_dict.keys() == {'a', 'b', 'c', 'd'}
    assert updated_dict.values() == {1, 20, 3, 4}
    assert updated_dict['b'] == 20


# Generated at 2022-06-22 21:20:32.839760
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    immutable_dict = ImmutableDict({'a': 1, 'b': 2})

    # Iterate over the items
    result = dict(immutable_dict.items())
    assert result == immutable_dict._store
    # Make sure the ImmutableDict itself is not modified
    assert immutable_dict == {'a': 1, 'b': 2}



# Generated at 2022-06-22 21:20:35.840408
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():

    assert(ImmutableDict({'a': 1, 'b': 2})['a'] == 1)
    assert(ImmutableDict({'a': 1, 'b': 2})['b'] == 2)



# Generated at 2022-06-22 21:20:37.737157
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    mapping = ImmutableDict({'key': 'value'})
    assert len(mapping) == 1


# Generated at 2022-06-22 21:20:47.763535
# Unit test for function is_string
def test_is_string():
    """Test for function is_string."""
    assert is_string('string')
    assert is_string(u'unicode')
    assert is_string(b'bytes')
    # Make sure that AnsibleVaultEncryptedUnicode behaves like a string
    from ansible.parsing.vault import VaultLib
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n2d63303235326663363939663566666339336338626562626233633431613039383666633734613730\na396d0b8f7558259e7212a29a7c2d1eb07f73492a45e9de7af6c3a6a8a6bc963\n'.encode('utf-8')

# Generated at 2022-06-22 21:20:56.304746
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'e': 4, 'f': 5, 'g': 6})
    test_diff_dict = test_dict.difference(['b', 'e'])
    assert 'b' not in test_diff_dict
    assert 'e' not in test_diff_dict
    assert 'c' in test_diff_dict
    assert 'f' in test_diff_dict
    assert 'g' in test_diff_dict
    assert len(test_diff_dict) == 4


# Generated at 2022-06-22 21:21:00.099563
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    assert hash(ImmutableDict()) == hash(ImmutableDict())
    assert hash(ImmutableDict(a=1, b=2)) == hash(ImmutableDict(a=1, b=2))
    assert hash(ImmutableDict(a=1, b=2)) == hash(ImmutableDict(b=2, a=1))
    assert hash(ImmutableDict(a=1, b=2)) != hash(ImmutableDict(a=1))
    assert hash(ImmutableDict(a=1, b=2)) != hash(ImmutableDict(a=2, b=2))
    reordered_dict = ImmutableDict(a=1, b=2)
    assert hash(reordered_dict) == hash(ImmutableDict(b=2, a=1))
    reordered

# Generated at 2022-06-22 21:21:07.979177
# Unit test for function is_iterable
def test_is_iterable():
    # List
    assert is_iterable([1, 2, 3])
    # Set
    assert is_iterable(set([1, 2, 3]))
    # Tuple
    assert is_iterable((1, 2, 3))
    # String
    assert is_iterable('foo')
    # List of dicts
    assert is_iterable([{'key': 'value'}])
    # Generator
    assert is_iterable((i for i in [1,2, 3]))
    # Test with ``include_strings``
    assert is_iterable('foo', include_strings=True)



# Generated at 2022-06-22 21:21:10.548567
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    id = ImmutableDict(x=1, y=2)
    assert len(id) == 2
    assert id['x'] == 1
    assert id['y'] == 2



# Generated at 2022-06-22 21:21:15.214919
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    test_dict = ImmutableDict(a=1, b=2, c=3)
    assert test_dict.union(dict(b=4, c=5, d=6)) == dict(a=1, b=4, c=5, d=6)



# Generated at 2022-06-22 21:21:18.434621
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(u'foo') == True
    assert is_string(b'foo') == True
    assert is_string([]) == False


# Generated at 2022-06-22 21:21:28.182187
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    test_dict = ImmutableDict()
    assert iter(test_dict) == iter(test_dict._store)

    test_dict = ImmutableDict([])
    assert iter(test_dict) == iter(test_dict._store)

    test_dict = ImmutableDict([('k', 'v')])
    assert iter(test_dict) == iter(test_dict._store)

    test_dict = ImmutableDict([('k1', 'v1'), ('k2', 'v2')])
    assert iter(test_dict) == iter(test_dict._store)


# Generated at 2022-06-22 21:21:31.116737
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict({'first': 1, 'second': 2, 'third': 3})
    assert repr(d) == "ImmutableDict({'third': 3, 'second': 2, 'first': 1})"


# Generated at 2022-06-22 21:21:40.806396
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Basic tests for hashability of ImmutableDict."""
    dict_a = ImmutableDict({'a': 1, 'b': 2})
    dict_b = ImmutableDict({'b': 2, 'a': 1})
    dict_c = ImmutableDict({})
    dict_d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict_e = ImmutableDict({'a': 1, 'b': 2})
    dict_f = ImmutableDict({'a': 1, 'b': 3})

    assert isinstance(dict_a, Hashable)
    assert isinstance(dict_a, MutableMapping)

    assert dict_a == dict_b
    assert dict_b == dict_a
    assert dict_c == dict_c
    assert dict_

# Generated at 2022-06-22 21:21:43.984640
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict(a=1, b=2)
    assert d.__repr__() == 'ImmutableDict({\'a\': 1, \'b\': 2})'


# Generated at 2022-06-22 21:21:52.216590
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(())
    assert is_iterable(set())
    assert is_iterable(range(1, 10))
    assert not is_iterable(0)
    assert not is_iterable(object())

    assert is_iterable(text_type(), True)
    assert is_iterable(binary_type(), True)
    assert not is_iterable(text_type())
    assert not is_iterable(binary_type())


# Generated at 2022-06-22 21:21:53.671089
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict({'a': 2, 'b': 3})
    assert 'a' in d
    assert 'b' in d
    assert 'c' not in d
    assert len(d) == 2
    assert isinstance(d, Mapping)


# Generated at 2022-06-22 21:22:05.838168
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    class TestImmutableDict(ImmutableDict):
        pass

    original = {'id': 1, 'name': 'test'}
    new = TestImmutableDict(original)
    # Test removal of both keys
    new = new.difference(('id', 'name'))
    assert len(new) == 0
    assert not new
    # Test removal of no keys
    new = new.difference(())
    assert len(new) == 0
    assert not new
    # Test removal of one key
    new = TestImmutableDict(original)
    new = new.difference(('id',))
    assert len(new) == 1
    assert new == {'name': 'test', }
    # Test removal of an unknown key
    new = TestImmutableDict(original)
    new = new.difference

# Generated at 2022-06-22 21:22:16.859614
# Unit test for function count
def test_count():
    """Test the count function.
    """
    first_list = [1, 0, 1, 3, 3, 3, 3, 5, 0, 0, 0]
    second_list = ['1', 0, '1', '3', '3', '3', 3, 0, 0, 0]
    third_list = ['1', '0', '1', '3', '3', '3', 3.0, 0, 0, 0]
    fourth_list = [(1, 2), (1, 3), (2, 3), (3, 4), (3, 4), (3, 4)]

    # Test that count works correctly with an iterable containing integers
    assert count(first_list) == {0: 4, 1: 2, 3: 4, 5: 1}

    # Test that count works correctly with an iterable containing mixed integers and strings


# Generated at 2022-06-22 21:22:21.312057
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict({'a': 1, 'b': 2})
    a = set(['a', 'b'])
    b = set(d)
    assert(a == b)


# Generated at 2022-06-22 21:22:25.580575
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    # initialization
    d1 = ImmutableDict()
    d2 = ImmutableDict({"a": 1, "b": 2, "c": 3})

    # test
    assert list(d1.__iter__()) == []
    assert list(d2.__iter__()) == ['a', 'b', 'c']



# Generated at 2022-06-22 21:22:30.223774
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    from ansible.module_utils.six import iteritems
    d = ImmutableDict(spam=2, eggs=3)
    for k, v in iteritems(d):
        assert v == d[k]
    assert len(d) == 2


# Unit tests for ImmutableDict.union()

# Generated at 2022-06-22 21:22:33.709342
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert repr(ImmutableDict()) == "ImmutableDict({})"
    assert repr(ImmutableDict(a="b")) == "ImmutableDict({'a': 'b'})"


# Generated at 2022-06-22 21:22:44.467973
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """Test ImmutableDict.difference() function."""

    # Below is a list of test cases.
    # Each test case is a list of one or more tuples.
    # Each tuple has a name of the test and a set of arguments to ImmutableDict.difference

# Generated at 2022-06-22 21:22:52.000980
# Unit test for function is_sequence
def test_is_sequence():
    seq = [1, 2, 3, 4, 5]
    assert is_sequence(seq) is True
    # noinspection PyDictCreation
    seq = {1, 2, 3, 4, 5}
    assert is_sequence(seq) is True
    seq = ('a', 'b', 'c', 'd')
    assert is_sequence(seq) is True
    seq = 'a'
    assert is_sequence(seq) is False
    seq = u'a'
    assert is_sequence(seq) is False
    seq = b'a'
    assert is_sequence(seq) is False
    seq = 'abcdef'
    assert is_sequence(seq, include_strings=True) is True
    seq = u'abcdef'
    assert is_sequence(seq, include_strings=True) is True
    seq

# Generated at 2022-06-22 21:22:54.434295
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    print(str(ImmutableDict({'key1':'value1', 'key2':'value2'})))
    print(str(ImmutableDict()))


# Generated at 2022-06-22 21:23:05.462559
# Unit test for function count
def test_count():
    assert count(['a', 'b', 'a']) == {'a': 2, 'b': 1}
    assert count(['a', 'b', 1]) == {'a': 1, 'b': 1, 1: 1}
    assert count(['a', 'b', 'a', 1, 1]) == {'a': 2, 'b': 1, 1: 2}
    assert count(('a', 'b', 'a')) == {'a': 2, 'b': 1}
    assert count(('a', 'b', 1)) == {'a': 1, 'b': 1, 1: 1}
    assert count(('a', 'b', 'a', 1, 1)) == {'a': 2, 'b': 1, 1: 2}

# Generated at 2022-06-22 21:23:11.068249
# Unit test for function count
def test_count():
    seq = ('a', 'b', 'c', 'd', 'd', 'a', 'b', 'b')
    counters = count(seq)
    assert counters == {'a': 2, 'b': 3, 'c': 1, 'd': 2}


# Generated at 2022-06-22 21:23:22.096124
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict(dict1={'k1': 'v1'}, dict2={'k1': 'v1'})
    assert d.__repr__() == "ImmutableDict({'dict1': {'k1': 'v1'}, 'dict2': {'k1': 'v1'}})"
    e = ImmutableDict(dict1={'key1': 'val1', 'key2': 'val2'}, dict2={'key1': 'val1', 'key2': 'val2'})
    assert e.__repr__() == "ImmutableDict({'dict1': {'key2': 'val2', 'key1': 'val1'}, 'dict2': {'key2': 'val2', 'key1': 'val1'}})"

# Generated at 2022-06-22 21:23:26.253320
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    mydata = ImmutableDict({'a': 'b', 'c': 'd'})
    assert len(mydata.keys()) == len(mydata)
    assert len(mydata.keys()) == len(list(mydata))
    for key in mydata:
        assert key in mydata._store


# Generated at 2022-06-22 21:23:35.543280
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Unit test for method __hash__"""
    # hashes of ImmutableDict and dict are equal when they are equal
    # and the dict hash is represented as a set
    d1 = {'a':1, 'b':2}
    d2 = {'a':1, 'b':2}
    assert hash(ImmutableDict(d1)) == hash(frozenset(d2.items()))

    # hashes of ImmutableDict and dict are not equal when they are equal
    # and the dict hash is represented as a list
    d3 = [('a',1), ('b',2)]
    assert hash(ImmutableDict(d1)) != hash(d3)

    # hashes of ImmutableDict and dict are not equal when they are not equal
    # and the dict hash is represented as a set

# Generated at 2022-06-22 21:23:42.160311
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    dict1 = ImmutableDict(test='test')
    dict2 = dict1.union({'test': 'test1'})

    assert(dict1 == dict2)

    dict3 = dict1.difference(['test'])
    assert(dict3 == {})

    dict4 = dict1.union({'test2': 'test1'})
    dict5 = dict4.difference(['test2'])

    assert(dict1 == dict5)

# Generated at 2022-06-22 21:23:50.118492
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})

    # Test subtract with one key
    d2 = d1.difference(['b'])
    assert d1 != d2
    assert d2 == ImmutableDict({'a': 1, 'c': 3, 'd': 4})

    # Test subtract with two keys
    d2 = d1.difference(['b', 'c'])
    assert d1 != d2
    assert d2 == ImmutableDict({'a': 1, 'd': 4})

    # Test subtract with same key twice
    d2 = d1.difference(['d', 'd'])
    assert d1 != d2

# Generated at 2022-06-22 21:23:55.783917
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    import json
    from collections import OrderedDict

    orig_dict = ImmutableDict(OrderedDict(json.loads('{"foo":"bar", "baz":"qux"}')))
    new_dict = orig_dict.difference(['foo'])

    assert repr(new_dict) == "ImmutableDict({'baz': 'qux'})"



# Generated at 2022-06-22 21:23:58.727989
# Unit test for function is_string
def test_is_string():
    assert is_string('something')
    assert is_string(u'unicode')
    assert is_string('\x00')
    assert is_string(b'bytes')
    assert not is_string(42)
    assert not is_string(object())



# Generated at 2022-06-22 21:24:00.152869
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict(one=1, two=2, three=3)
    assert len(d) == 3



# Generated at 2022-06-22 21:24:10.920450
# Unit test for function count
def test_count():
    # Simple test
    seq = [1, 2, 3, 1, 1, 2, 3, 1, 2, 1, 1, 2, 3, 1, 1, 2, 1]
    expected_res = {1: 8, 2: 5, 3: 3}
    res = count(seq)
    assert res == expected_res, "%s != %s" %(res, expected_res)
    # Test non iterable
    try:
        count(1)
        assert False, 'Expected Exception not raised'
    except Exception as e:
        assert e.args[0] == 'Argument provided  is not an iterable', 'Wrong exception message : %s' %e.args[0]


# Generated at 2022-06-22 21:24:20.215332
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence(tuple())

    assert not is_sequence(None)
    assert not is_sequence(set())
    assert not is_sequence(dict())
    assert not is_sequence(object())

    try:
        # make a test class that's not iterable
        class NotIterable(object):
            pass
        assert not is_sequence(NotIterable())
    except NameError:
        # python 3.x
        pass

    # strings are not sequences
    assert not is_sequence(u'abc')
    assert not is_sequence('abc')

    # including strings False is default
    assert not is_sequence(u'abc', True)
    assert not is_sequence('abc', True)


# Generated at 2022-06-22 21:24:22.176940
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    m = ImmutableDict(a=1, b=2)
    assert m['b'] == 2
    assert m['a'] == 1


# Generated at 2022-06-22 21:24:26.277590
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    list_of_keys = ['a', 'b', 'c']
    dict_of_key_values = {'a': 1, 'b': 2, 'c': 3}
    test_immut_dict = ImmutableDict(dict_of_key_values)
    assert(list(test_immut_dict) == list_of_keys)


# Generated at 2022-06-22 21:24:39.371312
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Test the difference method of ImmutableDict
    """
    i_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})

    assert i_dict.difference(['c']) == ImmutableDict({'a': 1, 'b': 2, 'd': 4})
    assert i_dict.difference([]) == ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    assert i_dict.difference(['e']) == ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    assert i_dict.difference(['d', 'e', 'a']) == ImmutableDict({'b': 2, 'c': 3})
    assert i

# Generated at 2022-06-22 21:24:42.248767
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    immutable_dict = ImmutableDict(a=1, b=2, c=3, d=4)
    assert len(immutable_dict) == 4


# Generated at 2022-06-22 21:24:45.209250
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    test_dict = ImmutableDict({'a': 'b'})
    assert test_dict['a'] == 'b'



# Generated at 2022-06-22 21:24:49.750039
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    mutable = {'a': 1, 'b': 2}
    immutable = ImmutableDict(mutable)
    assert immutable.__hash__() == hash(frozenset(mutable.items()))



# Generated at 2022-06-22 21:25:01.191197
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert is_sequence({'one': 1, 'two': 2})
    assert is_sequence(set([1, 2, 2, 3, 2]))
    assert is_sequence(('one', 'two', 'three'))
    assert is_sequence(range(10))
    assert is_sequence(xrange(10))
    assert is_sequence(2) is False
    assert is_sequence('abc') is False
    assert is_sequence(u'abc') is False
    assert is_sequence(b'abc') is False
    assert is_sequence(None) is False
    assert is_sequence(Exception()) is False

    class FooIter:
        def __init__(self, iterable):
            self.iterable = iterable
        def __iter__(self):
            return iter

# Generated at 2022-06-22 21:25:11.021998
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    overriding_mapping_both_exist = {'key1': 'value1.1', 'key3': 'value3'}
    overriding_mapping_one_exist = {'key2': 'value2.1', 'key4': 'value4'}
    no_original = {'key5': 'value5', 'key6': 'value6'}

    assert original.union(overriding_mapping_both_exist) == {'key1': 'value1.1', 'key2': 'value2', 'key3': 'value3'}

# Generated at 2022-06-22 21:25:16.856184
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """
    Test method __len__ of class ImmutableDict.
    """
    immutable_dict = ImmutableDict((('key', 'value'),))
    assert len(immutable_dict) == 1
    immutable_dict = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert len(immutable_dict) == 2
    immutable_dict = ImmutableDict()
    assert len(immutable_dict) == 0


# Generated at 2022-06-22 21:25:20.505918
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    immutable_dict = ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    assert immutable_dict['key1'] == 'value1'
    assert immutable_dict['key2'] == 'value2'
    assert immutable_dict['key3'] == 'value3'


# Generated at 2022-06-22 21:25:24.292062
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict({'a': 1, 'b': 2})
    assert [('a', 1), ('b', 2)] == list(d)



# Generated at 2022-06-22 21:25:25.258204
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    return ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-22 21:25:30.929512
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    IMD1 = ImmutableDict({'a': 1, 'b': 2})
    IMD2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert IMD1['a'] == 1
    assert IMD1['b'] == 2
    assert IMD2['c'] == 3


# Generated at 2022-06-22 21:25:33.209882
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert str(ImmutableDict()) == 'ImmutableDict({})'
    assert str(ImmutableDict(a=1, b=2)) == "ImmutableDict({'a': 1, 'b': 2})"


# Generated at 2022-06-22 21:25:44.164086
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # ImmutableDict is equal to itself
    assert ImmutableDict(a=1) == ImmutableDict(a=1)
    assert ImmutableDict(a=1) != ImmutableDict(a=2)

    # ImmutableDict is equal to a dict with the same key-value pairs
    assert ImmutableDict(a=1) == {'a': 1}
    assert ImmutableDict(a=1) != {'a': 2}

    # ImmutableDict is not equal to other types
    assert ImmutableDict(a=1) != object()
    assert ImmutableDict(a=1) != 1
    assert ImmutableDict(a=1) != {'a'}



# Generated at 2022-06-22 21:25:47.675744
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert is_sequence((1,))
    assert not is_sequence(1)
    assert is_sequence(set([1, 2]), include_strings=True)



# Generated at 2022-06-22 21:25:51.623048
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict()
    d = d.union({'a':'A'})
    keys = d.keys()
    assert keys[0] == 'a'



# Generated at 2022-06-22 21:25:54.885145
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    for key in d:
        assert key == ('key1' or 'key2')
    assert len(d) == 2


# Generated at 2022-06-22 21:26:06.839814
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # hashable
    hashable = ['1', 2, 3.0]
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    # Test the case when comparing ImmutableDict with another ImmutableDict of the same values
    e = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    # Test the case when comparing ImmutableDict with a dictionary of the same values
    f = {'a': 1, 'b': 2, 'c': 3}
    # Test the case when comparing ImmutableDict with an ImmutableDict with different values
    g = ImmutableDict({'a': 2, 'b': 3, 'c': 4})
    # Test the case when comparing ImmutableDict with a dictionary with different values

# Generated at 2022-06-22 21:26:11.528454
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict(a=1)) == 1
    assert len(ImmutableDict(a=1, b=2)) == 2
    assert len(ImmutableDict(a=1, b=2, c=3)) == 3



# Generated at 2022-06-22 21:26:18.465605
# Unit test for function is_iterable
def test_is_iterable():
    class IterA(object):
        def __iter__(self):
            return iter([])

    class IterB(object):
        def __getitem__(self, _):
            return iter([])

    assert is_iterable({})
    assert is_iterable(IterA())
    assert is_iterable(IterB())

    assert not is_iterable('foo')
    assert not is_iterable(1)
    assert is_iterable('foo', include_strings=True)



# Generated at 2022-06-22 21:26:28.655753
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    d_removed_all = d.difference([])
    assert d_removed_all == d
    d_removed_a = d.difference(['a'])
    assert d_removed_a == ImmutableDict({'b': 2, 'c': 3, 'd': 4})
    d_removed_all = d.difference(['a', 'b', 'c', 'd'])
    assert d_removed_all == ImmutableDict()
    d_removed_a_c = d.difference(['a', 'c'])
    assert d_removed_a_c == ImmutableDict({'b': 2, 'd': 4})
    d_rem

# Generated at 2022-06-22 21:26:40.140424
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    d1 = ImmutableDict({'a': 1, 'b': 2})

    assert d1 == ImmutableDict({'a': 1, 'b': 2})
    assert d1 == ImmutableDict(b=2, a=1)
    assert d1 != ImmutableDict({'a': 1, 'b': 3})
    assert d1 != ImmutableDict(b=3, a=1)

    d2 = d1.union({'b': 3, 'c': 4})
    assert d2 == ImmutableDict({'a': 1, 'b': 3, 'c': 4})

    d3 = d2.difference('ac')
    assert d3 == ImmutableDict({'b': 3})

    d4 = ImmutableDict(a=[1], b=[2])
    assert d4 != Imm

# Generated at 2022-06-22 21:26:44.068312
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict({'key1': 1})) == 1
    assert len(ImmutableDict({'key1': 1, 'key2': 2})) == 2
    assert len(ImmutableDict()) == 0


# Generated at 2022-06-22 21:26:46.108930
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 'three'})
    assert d1['a'] == 1


# Generated at 2022-06-22 21:26:53.295730
# Unit test for function is_iterable
def test_is_iterable():
    """Unit test for function is_iterable."""
    # Make a string object that has an __iter__ method. This is to ensure that
    # users cannot define a class that inherits from string and make an object
    # that is_iterable() would see as an iterable.
    class CustomString(str):
        def __iter__(self):
            return iter(str(self))
    custom_string = CustomString('string')
    class DictSubclass(dict):
        pass
    dict_subclass = DictSubclass()

    # These are the things that we expect to be iterable.
    positive_iterables = [
        'string',
        u'unicode',
        [],
        (),
        set(),
        frozenset(),
        dict(),
        dict_subclass,
        custom_string,
    ]

# Generated at 2022-06-22 21:27:02.912907
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():

    ids_equal = ImmutableDict({'a': 1, 'b': 2})
    ids_equal_dup = ImmutableDict({'a': 1, 'b': 2})
    ids_not_equal = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    ids_not_hashable = ImmutableDict({'a': [1], 'b': 2})

    assert ids_equal.__hash__() == ids_equal_dup.__hash__()
    assert ids_equal.__hash__() != ids_not_equal.__hash__()

    # ImmutableDict should not be hashable if it contains unhashable items
    # This is tested by asserting that __hash__() raises an exception
    # if the ImmutableDict contains an unhashable

# Generated at 2022-06-22 21:27:09.680637
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Test that ImmutableDict.difference returns a new ImmutableDict without key-value pairs for the removed keys
    """
    original = {'a': 1, 'b': 2, 'c': 3}
    removed = ['b', 'c']
    new = ImmutableDict(original).difference(removed)
    assert 'a' in new
    assert 'b' not in new
    assert 'c' not in new


# Generated at 2022-06-22 21:27:14.754401
# Unit test for function count
def test_count():
    seq = ['a', 'c', 'b', 'd', 'a', 'c', 'b', 'a', 'a']
    expected_result = {'a': 4, 'c': 2, 'b': 2, 'd': 1}
    assert (count(seq) == expected_result)



# Generated at 2022-06-22 21:27:20.569803
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict(one=1)) == 1
    assert len(ImmutableDict(one=1, two=2)) == 2
    assert len(ImmutableDict(one=1, two=2, three=3)) == 3


# Generated at 2022-06-22 21:27:32.079892
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    immutable_dictionary = ImmutableDict({'a': 1, 'b': 2})

    # An ImmutableDict instance is hashable if it uses only immutable objects
    # as keys and values.
    assert isinstance(hash(immutable_dictionary), int)

    immutable_dictionary = ImmutableDict({'a': [1], 'b': 2})

    # A list is mutable, so this ImmutableDict instance should not be hashable.
    try:
        hash(immutable_dictionary)
        raise AssertionError('An ImmutableDict instance with a mutable value should not be hashable.')
    except TypeError:
        pass

    immutable_dictionary = ImmutableDict({1: 2, [1]: 2})

    # A list is mutable, so this ImmutableDict instance should not be hashable

# Generated at 2022-06-22 21:27:35.170797
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    data = {'a': 1, 'b': 2}
    test_subject = ImmutableDict(data)
    assert repr(test_subject) == 'ImmutableDict({0})'.format(str(data))


# Generated at 2022-06-22 21:27:46.262276
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    
    def check_ImmutableDict_len(ImmutableDict_obj, expected_len):
        ImmutableDict_obj_len = len(ImmutableDict_obj)
        if ImmutableDict_obj_len != expected_len:
            return False, 'Expected object of len {} got {}'.format(expected_len, ImmutableDict_obj_len)
        return True, ''
    
    success_message = 'Pass'
    fail_message = 'Fail'
    
    ImmutableDict_obj = ImmutableDict()
    is_success, message = check_ImmutableDict_len(ImmutableDict_obj, 0)
    print((success_message if is_success else fail_message), message)
    
    ImmutableDict_obj = ImmutableDict({'a':'1'})

# Generated at 2022-06-22 21:27:48.812688
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = {'b': 4, 'c': 3}
    assert d1.union(d2) == ImmutableDict({'a': 1, 'b': 4, 'c': 3})



# Generated at 2022-06-22 21:27:54.950870
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict()
    assert len(list(d.__iter__())) == 0
    d = ImmutableDict(a=1)
    assert len(list(d.__iter__())) == 1
    d = ImmutableDict(a=1, b=2, c=3)
    assert len(list(d.__iter__())) == 3


# Generated at 2022-06-22 21:27:56.852939
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    a = ImmutableDict({'A': 'B'})

    assert a.__hash__() == hash({'A': 'B'})

    b = ImmutableDict({'B': 'C'})

    assert a.__hash__() == b.__hash__()


# Generated at 2022-06-22 21:28:01.078615
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    expected = ImmutableDict({'a': 1, 'c': 3})
    actual = original.difference(['b'])
    assert expected == actual
    assert original == ImmutableDict({'a': 1, 'b': 2, 'c': 3})


# Generated at 2022-06-22 21:28:13.402265
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    test_original = ImmutableDict({1: 2, 'a': 'b', 'c': 'd'})
    test_overriding_mapping = {2: 3, 'b': 'c', 'd': 'e'}

    actual = test_original.union(test_overriding_mapping)
    expected = ImmutableDict({1: 2, 'a': 'b', 'c': 'd', 2: 3, 'b': 'c', 'd': 'e'})
    assert expected == actual

    test_overriding_mapping = {1: 4, 'a': 'd', 'c': 'e'}
    actual = test_original.union(test_overriding_mapping)
    expected = ImmutableDict({1: 4, 'a': 'd', 'c': 'e'})
   

# Generated at 2022-06-22 21:28:18.883342
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    test_dict = ImmutableDict({'a': '1', 'b': '2', 'c': '3'})
    assert {key: value for key, value in test_dict.__iter__()} == {'a': '1', 'b': '2', 'c': '3'}


# Generated at 2022-06-22 21:28:24.714124
# Unit test for function is_iterable
def test_is_iterable():
    # Test positive integer
    positive_integer = 10
    assert is_iterable(positive_integer) == False

    # Test list
    array = [0, 1, 2, 3]
    assert is_iterable(array) == True

    # Test dictionary
    dictionary = {'test': 10}
    assert is_iterable(dictionary) == True

    # Test tuple
    tuple = ('test', 10)
    assert is_iterable(tuple) == True

    # Test string
    string = "test"
    assert is_iterable(string) == False


# Generated at 2022-06-22 21:28:29.033497
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """check if immutabledict is Instance of ImmutableDict"""
    immutabledict = ImmutableDict({'name': 'bob'})
    assert isinstance(immutabledict, ImmutableDict)



# Generated at 2022-06-22 21:28:33.272422
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Test method ImmutableDict.__hash__

    Test the hash of an ImmutableDict
    """
    x = ImmutableDict({'test': ['dict']})
    y = ImmutableDict({'test': ['dict']})
    assert hash(x) == hash(y)


# Generated at 2022-06-22 21:28:41.775246
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():

    a = ImmutableDict({
        'a': 'apple',
        'b': 'banana',
        'c': 'coconut'
    })

    assert len(a) == 3

    # Test number of items returned
    i = 0
    for key in a:
        i += 1
    assert i == 3

    # Test that none of the items are mutable
    for key in a:
        assert isinstance(a.get(key), (text_type, binary_type))

    # Test that the item order is the same as the order in the original dictionary
    order = ['a', 'b', 'c']
    i = 0
    for key in a:
        assert key == order[i]
        i += 1



# Generated at 2022-06-22 21:28:54.411742
# Unit test for function count
def test_count():   # pylint: disable=unused-variable
    import platform  # pylint: disable=import-outside-toplevel,unused-variable
    if platform.python_version() < '2.6':
        return
    import collections  # pylint: disable=import-outside-toplevel,unused-variable

    str1 = "abracadabra"
    str2 = "python"
    list1 = ["a", "b", "a", "c", "b"]
    list2 = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55]
    set1 = {"a", "b", "a", "c", "b"}
    set2 = {1, 1, 2, 3, 5, 8, 13, 21, 34, 55}


# Generated at 2022-06-22 21:29:04.835101
# Unit test for function is_iterable
def test_is_iterable():
    """
    Test whether the is_iterable function returns correct results.

    These tests typically do not test whether it returns the correct type.
    """

    # Test if scalar variables and None are not iterable
    assert not is_iterable(123)
    assert not is_iterable(0.0)
    assert not is_iterable(None)

    # Test if strings are iterable
    assert is_iterable("abc")
    assert is_iterable("")

    # Test if list and dictionaries are iterable
    assert is_iterable([1, 2, 3])
    assert is_iterable([])
    assert is_iterable({1: 2})



# Generated at 2022-06-22 21:29:08.600854
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})
    assert d.difference([3, 4, 5]) == ImmutableDict({1: 'one', 2: 'two'})



# Generated at 2022-06-22 21:29:20.685757
# Unit test for function is_iterable
def test_is_iterable():
    def gen():
        yield 1

    # Test string/bytes
    assert is_string('abc')
    assert not is_string(u'abc')
    assert is_string(b'abc')
    assert not is_iterable('abc', include_strings=False)
    assert is_iterable('abc', include_strings=True)

    # Test dict
    assert is_iterable({'a': 1})
    assert is_iterable(dict(a=1))
    assert is_iterable(dict.fromkeys(('a', 'b')))
    assert is_iterable(ImmutableDict(a=1))
    assert is_iterable(ImmutableDict.fromkeys(('a', 'b')))
    assert not is_iterable(type({'a': 1}))

    # Test generator
    assert is_

# Generated at 2022-06-22 21:29:29.638302
# Unit test for function count
def test_count():
    # If a Python list is passed, the result should be a dictionary with
    # the number of appearances of each element of the list
    assert count([1, 2, 3, 3, 3]) == {1: 1, 2: 1, 3: 3}

    # If a Python set is passed, the result should be a dictionary with
    # the number of appearances of each element of the set
    assert count({1, 2, 3, 3, 3}) == {1: 1, 2: 1, 3: 3}


# Generated at 2022-06-22 21:29:31.753259
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence(())
    assert is_sequence({})
    asser

# Generated at 2022-06-22 21:29:43.083806
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    # Test ImmutableDict constructor
    # Test with args
    d1 = ImmutableDict({"a": 1, "b": 2}, c=3, d=4)
    assert d1 == {"a": 1, "b": 2, "c": 3, "d": 4}
    # Test with kwargs
    d1 = ImmutableDict(a=1, b=2, c=3, d=4)
    assert d1 == {"a": 1, "b": 2, "c": 3, "d": 4}
    # Test with kwargs and args

# Generated at 2022-06-22 21:29:54.384193
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    # Test passing an empty dictionary
    assert ImmutableDict({}) == ImmutableDict({})

    # Test passing an empty dictionary and non-empty dictionary
    assert ImmutableDict({}) != ImmutableDict({'key1': 'value1'})

    # Test passing dictionaries with one key and value
    assert ImmutableDict({'key1': 'value1'}) == ImmutableDict({'key1': 'value1'})

    # Test passing dictionaries with one key and value and one more key/value
    assert ImmutableDict({'key1': 'value1'}) != ImmutableDict({'key1': 'value1', 'key2': 'value2'})

    # Test passing a non-dictionary
    try:
        ImmutableDict('key1')
        assert False
    except TypeError:
        pass

# Generated at 2022-06-22 21:30:04.717248
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    # Method should return True when is compared with itself
    d = ImmutableDict({'a': 'b', 'c': 'd'})
    assert d == d

    # Method should return False when compared to another ImmutableDict with same data
    e = ImmutableDict({'a': 'b', 'c': 'd'})
    assert d != e

    # Method should return False when compared to another ImmutableDict with
    # same data but different order
    e = ImmutableDict({'c': 'd', 'a': 'b'})
    assert d != e

    # Method should return False when compared to another ImmutableDict with
    # different data
    e = ImmutableDict({'c': 'd', 'a': 'b', 'e': 'f'})
    assert d != e

    # Method should return False