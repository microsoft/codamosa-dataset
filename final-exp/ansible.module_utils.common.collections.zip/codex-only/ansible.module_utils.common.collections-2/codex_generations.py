

# Generated at 2022-06-22 21:20:08.042073
# Unit test for function is_sequence
def test_is_sequence():
    # list, tuple and set are all sequences
    assert is_sequence([]) and is_sequence(()), "Empty lists and tuples are sequences"
    assert is_sequence([1, 2, 3, 4, 5]), "Lists are sequences"
    assert is_sequence(set()), "Sets are sequences"
    assert is_sequence({'a': 1, 'b': 2, 'c': 3}), "Mappings are not sequences"
    assert is_sequence(range(1, 10, 2)), "Ranges are sequences"
    assert is_sequence(xrange(1, 10, 2)), "Ranges are sequences"



# Generated at 2022-06-22 21:20:09.954354
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    assert list(ImmutableDict({'a': 'b'})) == ['a']



# Generated at 2022-06-22 21:20:21.648838
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    d1 = ImmutableDict({'a': 1, 'c': 3})
    d2 = ImmutableDict(a=1, b=2, c=3)
    assert d1 == d2
    assert d2 == d1
    assert d1 == ImmutableDict(a=1, b=2, c=3)
    assert hash(d1) == hash(d2)
    assert hash(d1) == hash(ImmutableDict(a=1, b=2, c=3))
    assert hash(d1) == hash(ImmutableDict(a=1, c=3, b=2))

    # ImmutableDict does not allow updating the original

# Generated at 2022-06-22 21:20:29.250574
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    def test_value_equal(obj1, obj2):
        if obj1 == obj2:
            return True
        else:
            return False

    obj1 = ImmutableDict({'a': 1, 'b': 2})
    obj2 = ImmutableDict({'a': 1, 'b': 2})
    obj3 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    obj4 = ImmutableDict({'a': 1, 'b': 3})

    assert test_value_equal(hash(obj1), hash(obj2))
    assert test_value_equal(obj1, obj2)

    assert not test_value_equal(hash(obj1), hash(obj3))
    assert not test_value_equal(obj1, obj3)

    assert not test_value_equal

# Generated at 2022-06-22 21:20:32.839570
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict()
    assert len(d) == 0

    d = ImmutableDict({'foo': 'bar'})
    assert len(d) == 1


# Generated at 2022-06-22 21:20:43.705528
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # Both instances should have equal hashes
    instance1 = ImmutableDict({'a': 1})
    instance2 = ImmutableDict({'a': 1})
    assert(hash(instance1) == hash(instance2))

    # The hashes should be unequal
    instance3 = ImmutableDict({'a': 1, 'b': 2})
    assert(hash(instance3) != hash(instance2))

    # This instance should have the same hash as instance1
    instance4 = ImmutableDict({'a': 1, 'b': 2})
    instance4 = instance4.difference(['b'])
    assert(hash(instance4) == hash(instance1))

    # Empty instances should have the same hash
    instance5 = ImmutableDict()
    instance6 = ImmutableDict()

# Generated at 2022-06-22 21:20:46.780682
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict({'a': 1, 'b': 2})
    assert len(d) == 2



# Generated at 2022-06-22 21:20:58.871810
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    def _test_union(original, overriding, expected):
        result = original.union(overriding)
        assert result == expected, (
            '{0} union {1} is expected to produce {2} but produced {3}'
            .format(original, overriding, expected, result)
        )
        assert result != original, (
            '{0} union {1} is expected to produce a new instance'
            .format(original, overriding)
        )
        for k, v in original.items():
            assert result[k] == v, (
                '{0} union {1} is expected to keep all of {0} items'
                .format(original, overriding)
            )

# Generated at 2022-06-22 21:21:01.569091
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    data = ImmutableDict({'a':1, 'b':2, 'c':3})
    assert len(data) == 3


# Generated at 2022-06-22 21:21:05.096558
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence(set())
    assert is_sequence((1,))
    assert not is_sequence(1)
    assert not is_sequence({'a': 1})
    assert not is_sequence(None)



# Generated at 2022-06-22 21:21:13.867297
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    a = ImmutableDict()
    assert repr(a) == ("ImmutableDict({0})".format(repr({})))

    a = ImmutableDict({'a': 1})
    assert repr(a) == ("ImmutableDict({0})".format(repr({'a': 1})))

    a = ImmutableDict(a=1)
    assert repr(a) == ("ImmutableDict({0})".format(repr({'a': 1})))

    a = ImmutableDict([('a', 1), ('b', 2)])
    assert repr(a) == ("ImmutableDict({0})".format(repr(dict([('a', 1), ('b', 2)]))))


# Generated at 2022-06-22 21:21:25.293625
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d1 = ImmutableDict({'a': 1})
    d2 = ImmutableDict({'b': 2})
    d3 = ImmutableDict({'a': 1})
    d4 = ImmutableDict({'a': 2})
    d5 = ImmutableDict({'a': 1, 'b': 2})
    d6 = ImmutableDict({'c': 1, 'b': 2})
    d7 = ImmutableDict({'c': 1, 'b': 2})
    test_cases = [d1, d2, d3, d4, d5, d6, d7]

# Generated at 2022-06-22 21:21:28.957897
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    ifImmutableDict_repr_result = ImmutableDict({"a": 1, "b": 2})
    assert ifImmutableDict_repr_result.__repr__() == 'ImmutableDict({\'a\': 1, \'b\': 2})'

# Generated at 2022-06-22 21:21:34.302479
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    a = ImmutableDict({'a': 'b'})
    assert a['a'] == 'b'
    try:
        a['b']
    except KeyError:
        pass
    else:
        assert False, "Key was found in an ImmutableDict. It should not be possible."


# Generated at 2022-06-22 21:21:42.427090
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """Unit test for the ImmutableDict difference method"""

    # Create the original dictionary
    original_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})

    # Create the subtractive iterable
    subtractive_iterable = ('a', 'c')

    # Create an ImmutableDict from original_dict with a and c removed
    original_dict_without_a_and_c = original_dict.difference(subtractive_iterable)

    # Check that ImmutableDict is correctly created
    assert len(original_dict_without_a_and_c) == 1
    assert original_dict_without_a_and_c['b'] == 2

# Generated at 2022-06-22 21:21:45.401587
# Unit test for function is_string
def test_is_string():
    assert is_string("hello")
    assert is_string(u"hello")
    assert not is_string([])
    assert not is_string({})



# Generated at 2022-06-22 21:21:50.793123
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    immutable_dict = ImmutableDict()
    immutable_dict['a'] = 0
    immutable_dict['b'] = 1
    items = []
    for key in immutable_dict:
        items.append((key, immutable_dict[key]))
    assert items == [('a', 0), ('b', 1)]


# Generated at 2022-06-22 21:21:57.148616
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    id1 = ImmutableDict(a=1, b=2)
    id2 = id1.union(dict(c=3))
    assert id1 == ImmutableDict(a=1, b=2)
    assert id1 == id2.union(dict(b=2))
    assert id2 == ImmutableDict(a=1, b=2, c=3)
    assert id2 == id2.union(dict(c=3))


# Generated at 2022-06-22 21:21:59.625187
# Unit test for function is_string
def test_is_string():
    assert is_string('hello') == True
    assert is_string(b'hello') == True
    assert is_string(u'hello') == True
    assert is_string([u'hello']) == False
    assert is_string([b'hello']) == False
    assert is_string(ImmutableDict(key='value')) == False

# Generated at 2022-06-22 21:22:03.654603
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original_dict = ImmutableDict({'a': 1})
    new_dict = original_dict.union({'a': 2, 'b': 3})
    assert new_dict['a'] == 2
    assert new_dict['b'] == 3



# Generated at 2022-06-22 21:22:15.539594
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d = ImmutableDict({1: 2, 3: 4})
    d2 = ImmutableDict({1: 2, 3: 4})
    d3 = ImmutableDict({3: 4, 1: 2})
    d4 = ImmutableDict({1: 3, 3: 4})
    d5 = ImmutableDict({1: 2, 3: 4, 5: 6})
    d6 = ImmutableDict()
    d7 = ImmutableDict({1: 2, 3: 4, 'a': 5})
    assert hash(d) == hash(d2)
    assert hash(d) == hash(d3)
    assert hash(d) != hash(d4)
    assert hash(d) != hash(d5)
    assert hash(d) != hash(d6)
    assert hash(d) != hash

# Generated at 2022-06-22 21:22:22.857125
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable('text') is True)
    assert(is_iterable('text', include_strings=False) is False)
    assert(is_iterable(b'binary') is True)
    assert(is_iterable(b'binary', include_strings=False) is False)
    assert(is_iterable([1]) is True)
    assert(is_iterable({1}) is True)
    assert(is_iterable({'a': '1'}) is True)
    assert(is_iterable(1) is False)
    assert(is_iterable(None) is False)



# Generated at 2022-06-22 21:22:31.894090
# Unit test for function is_sequence
def test_is_sequence():
    """Use Python 2.6 to test is_sequence()."""
    import unittest
    class TestCases(unittest.TestCase):
        def test_is_sequence_with_list(self):
            self.assertTrue(is_sequence([1, 2, 3, 4]))

        def test_is_sequence_with_tuple(self):
            self.assertTrue(is_sequence((1, 2, 3, 4)))

        def test_is_sequence_with_string(self):
            self.assertFalse(is_sequence("1, 2, 3, 4"))

        def test_is_sequence_with_dictionary(self):
            self.assertFalse(is_sequence({1: 2, 3: 4}))


# Generated at 2022-06-22 21:22:42.788035
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Unit test for method __repr__ of class ImmutableDict """
    seq = ['a', 'b']
    result = ImmutableDict([('c', 1), ('d', 2)])
    result2 = ImmutableDict(a=3, b=4)
    result3 = ImmutableDict(seq)
    result4 = ImmutableDict(result)
    result5 = ImmutableDict(result2)
    result6 = ImmutableDict({'g': 1, 'h': 2})
    assert repr(result) == "ImmutableDict({'c': 1, 'd': 2})"
    assert repr(result2) == "ImmutableDict({'a': 3, 'b': 4})"
    assert repr(result3) == "ImmutableDict({'a': 'b'})"

# Generated at 2022-06-22 21:22:49.299339
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d1 = ImmutableDict()
    exp_repr = 'ImmutableDict({0})'
    assert d1.__repr__() == exp_repr.format({})
    d2 = ImmutableDict({'a':1})
    assert d2.__repr__() == exp_repr.format({'a':1})
    d3 = ImmutableDict({'a': {'b':{'c':3}}})
    assert d3.__repr__() == exp_repr.format({'a': {'b':{'c':3}}})


# Generated at 2022-06-22 21:22:54.264008
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    hash1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'}).__hash__()
    hash2 = ImmutableDict({'key1': 'value1', 'key2': 'value2'}).__hash__()
    assert hash1 == hash2



# Generated at 2022-06-22 21:23:05.013512
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test comparing ImmutableDict to ImmutableDict
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(a=1, b=2)
    d3 = ImmutableDict(b=2, a=1)
    d4 = ImmutableDict(a=1, b=3)
    d5 = ImmutableDict(a=1)

    assert d1 == d2
    assert d1 == d3
    assert d2 == d3

    assert not d1 == d4
    assert not d1 == d5
    assert not d1 == dict(d1)

    # Test comparing ImmutableDict to non-ImmutableDict

# Generated at 2022-06-22 21:23:15.668218
# Unit test for function is_sequence
def test_is_sequence():
    assert not is_sequence('a', include_strings=True)
    assert not is_sequence('a', include_strings=False)
    assert not is_sequence(u'a', include_strings=True)
    assert not is_sequence(u'a', include_strings=False)
    assert not is_sequence(1, include_strings=True)
    assert not is_sequence(1, include_strings=False)
    assert not is_sequence(1.0, include_strings=True)
    assert not is_sequence(1.0, include_strings=False)
    assert not is_sequence(True, include_strings=True)
    assert not is_sequence(True, include_strings=False)
    assert not is_sequence(object(), include_strings=True)
    assert not is_sequence(object(), include_strings=False)

# Generated at 2022-06-22 21:23:18.881877
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    mapping = {'a': 1, 'b': 2}
    immutable = ImmutableDict(mapping)
    assert 'a' in immutable
    assert 'b' in immutable
    assert 'c' not in immutable
    assert immutable['a'] == 1
    assert immutable['b'] == 2
  

# Generated at 2022-06-22 21:23:30.893262
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({"a": 1, "b": 2, "c": 3})
    dict2 = ImmutableDict({"a": 1, "b": 2, "c": 3})
    dict3 = ImmutableDict({"a": 1, "b": 3, "c": 3})
    dict4 = ImmutableDict({"a": 1, "b": 2})
    dict5 = {"a": 1, "b": 2, "c": 3}
    dict6 = 3
    dict7 = ImmutableDict()
    print("#1: ", dict1 == dict2)
    print("#2: ", dict1 == dict3)
    print("#3: ", dict1 == dict4)
    print("#4: ", dict1 == dict5)

# Generated at 2022-06-22 21:23:35.770832
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    id1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    id2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert id1 == id2
    assert not(id1 == {'a': 1, 'b': 2, 'c': 3})


# Generated at 2022-06-22 21:23:40.071192
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict([(1, 'value_1'), (2, 'value_2'), (3, 'value_3')])
    assert set(d.__iter__()) == set([1, 2, 3])



# Generated at 2022-06-22 21:23:48.976076
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original_dict = {'a': 1, 'b': 2, 'c': 3}
    new_dict = {'d': 4, 'e': 5, 'c': 6}
    idict = ImmutableDict(original_dict)
    union_dict = idict.union(new_dict)
    assert original_dict['a'] == 1
    assert new_dict['d'] == 4
    assert union_dict['a'] == 1
    assert union_dict['b'] == 2
    assert union_dict['c'] == 6
    assert len(union_dict) == 5
    assert 'a' in union_dict
    assert 'b' in union_dict
    assert 'c' in union_dict
    assert 'd' in union_dict
    assert 'e' in union_dict
    assert 'f' not in union_dict

# Generated at 2022-06-22 21:23:54.269536
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    # Test for not available key
    assert ImmutableDict({'a': 1})['b'] == KeyError()
    # Test for incorrect key type
    assert ImmutableDict({'a': 1})[1] == KeyError()
    # Test for regular key
    assert ImmutableDict({'a': 1})['a'] == 1


# Generated at 2022-06-22 21:24:01.366906
# Unit test for function is_sequence
def test_is_sequence():
    """Unit test for the is_sequence function."""
    # Numbers are not sequences
    assert not is_sequence(1)
    assert not is_sequence(1.6)
    # Sequences are sequences
    assert is_sequence([])
    assert is_sequence([1, 2, 3])
    assert is_sequence((1, 2, 3))
    assert is_sequence([1, 'a', 'b'])
    # Non-indexable things are never sequences
    class Foo:  # pylint: disable=too-few-public-methods
        """Class that is never a sequence."""

        def __iter__(self):  # pylint: disable=no-self-use
            """Iterable that is never a sequence."""
            return []

    assert not is_sequence(Foo())
    # Strings are sequences when told

# Generated at 2022-06-22 21:24:04.398941
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    empty = ImmutableDict()
    assert len(empty) == 0
    nonempty = ImmutableDict(one=1, two=2, three=3)
    assert len(nonempty) == 3



# Generated at 2022-06-22 21:24:07.906971
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3

# Generated at 2022-06-22 21:24:18.800005
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():

    _dict1 = ImmutableDict({"foo": 1, "bar": 2})

    # Test the properties of ImmutableDict
    assert _dict1["foo"] == 1
    assert len(_dict1) == 2
    assert isinstance(_dict1, MutableMapping) is False
    assert isinstance(_dict1, Mapping)
    assert isinstance(_dict1, Hashable)

    # Test the inner dict store
    assert _dict1._store is not _dict1
    assert _dict1._store["foo"] == _dict1["foo"]

    # Test the union method
    _dict2 = _dict1.union({"foo": 2, "bar": 6})
    assert _dict2["foo"] == 2
    assert _dict2 == {"bar": 6, "foo": 2}
    assert len(_dict2) == 2


# Generated at 2022-06-22 21:24:23.485378
# Unit test for function is_sequence
def test_is_sequence():
    assert not is_sequence('foo')
    assert not is_sequence(u'foo')
    assert is_sequence([])
    assert is_sequence(())
    assert is_sequence({})
    assert is_sequence(set())
    assert is_sequence((1, 2, 3))
    assert is_sequence(['foo', 'bar'])
    assert is_sequence(['bar', ['foo', 'bar']])



# Generated at 2022-06-22 21:24:25.796904
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    orgin = {'a':1,'b':2}
    test = ImmutableDict(orgin)
    assert test._store == orgin


# Generated at 2022-06-22 21:24:31.531502
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    dict3 = ImmutableDict({'a': 3, 'b': 2})
    dict4 = ImmutableDict({'b': 2, 'a': 1})

    assert hash(dict1) == hash(dict2)     # Same order
    assert hash(dict1) == hash(dict4)     # Different order
    assert hash(dict1) != hash(dict3)     # Same order, different values
    assert hash(dict1) != hash(ImmutableDict())       # Empty dict



# Generated at 2022-06-22 21:24:34.083463
# Unit test for function is_string
def test_is_string():
    assert is_string('a') is True
    assert is_string(u'a') is True
    assert is_string(b'a') is True
    assert is_string(1) is False
    assert is_string([1, 2, 3]) is False


# Generated at 2022-06-22 21:24:39.134539
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    immutable = ImmutableDict({"key1": 1, "key2": 2, "key3": 3})
    expected_immutable = ImmutableDict({"key1": 1})
    result_immutable = immutable.difference(["key2", "key3"])
    assert result_immutable == expected_immutable


# Generated at 2022-06-22 21:24:51.635811
# Unit test for function is_string
def test_is_string():
    from ansible.module_utils.common.text.extras import AnsibleVaultEncryptedUnicode as AVEU
    # pylint: disable=redefined-outer-name
    test_cases = [
        ('This is a string', True),
        (u'This is a Unicode string', True),
        (b'This is a bytes string', True),
        (AVEU('This is a string', b'ENC[credentials]'), True),
        ([], False),
        (set(), False),
        (dict(), False),
        (None, False)
    ]

    for test_case in test_cases:
        argument, expected_result = test_case
        actual_result = is_string(argument)

# Generated at 2022-06-22 21:24:57.582589
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert is_iterable([])
    assert is_iterable('')
    assert is_iterable([], True)
    assert is_iterable('', True)
    assert is_iterable((x for x in range(10)))


# Generated at 2022-06-22 21:25:05.958858
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    data = ImmutableDict({"key1":"value1", "key2":"value2", "key3":"value3"})
    test_data = ImmutableDict({"key1":"value1", "key2":"value2", "key3":"value3"})
    assert data == test_data
    assert data == data
    assert data == data.difference(["key1"])
    assert data == data.union({"key1":"value0"})
    assert data == {"key1":"value1", "key2":"value2", "key3":"value3"}
    assert data == {"key1":"value0", "key2":"value2", "key3":"value3"}
    assert data == {"key2":"value2", "key3":"value3"}
    # test for unequal case

# Generated at 2022-06-22 21:25:09.897231
# Unit test for function count
def test_count():
    from collections import Counter
    seq1 = [1, 2, 2, 3]
    seq2 = [2, 1, 3, 2]
    assert count(seq1) == Counter(seq1)
    assert count(seq2) == Counter(seq2)


# Generated at 2022-06-22 21:25:12.362096
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    my_dict = ImmutableDict({"a": "b", "c": "d"})
    assert(len(my_dict) == 2)


# Generated at 2022-06-22 21:25:14.967688
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert ImmutableDict({'1': '2', 3: 4}).__repr__() == 'ImmutableDict({\'1\': \'2\', 3: 4})'

# Generated at 2022-06-22 21:25:22.318477
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    immutable_dict = ImmutableDict({'a': 1, 'b': 2})
    assert(immutable_dict == {'a': 1, 'b': 2})

    ret_dict = immutable_dict.union({'b': 5, 'c': 2})
    assert(ret_dict == {'a': 1, 'b': 5, 'c': 2})
    assert(ret_dict != immutable_dict)

    ret_dict = immutable_dict.difference(['a', 'c'])
    assert(ret_dict == {'b': 2})

    ret_dict = immutable_dict.difference({'a': 1, 'c': 3})
    assert(ret_dict == {'b': 2})

    assert(ret_dict[0] is None)

# Generated at 2022-06-22 21:25:33.540750
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    '''
    Simple unit test for testing the difference method of class ImmutableDict.
    '''
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    immutable_test_dict = ImmutableDict(test_dict)
    immutable_test_dict_difference = immutable_test_dict.difference(['b'])
    if isinstance(immutable_test_dict_difference, ImmutableDict):
        result = True
    else:
        result = False
    assert result
    #Now check if the 'b' key is present in the difference dict
    if 'b' in immutable_test_dict_difference:
        result = True
    else:
        result = False
    assert result

# Generated at 2022-06-22 21:25:45.273997
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """Unit test for method difference of class ImmutableDict."""

    def test_one_key(idict, subtractive_iterable, expected_dict):
        idict_copy = ImmutableDict(idict)
        new_idict = idict_copy.difference(subtractive_iterable)
        assert new_idict == expected_dict

    def test_two_keys(idict, subtractive_iterable, expected_dict):
        first_key = subtractive_iterable[0]
        second_key = subtractive_iterable[1]

        first_idict = ImmutableDict(idict)
        second_idict = first_idict.difference(subtractive_iterable)
        third_idict = second_idict.difference(first_key)


# Generated at 2022-06-22 21:25:56.996385
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Verify that __eq__() method of ImmutableDict class
    works as expected
    """
    d = ImmutableDict({'a': 1, 'b': 2})
    f = frozenset([('a', 1), ('b', 2)])
    assert d == f
    d = ImmutableDict({'a': 1, 'b': 2})
    f = frozenset({'a': 1, 'b': 2})
    assert not d == f
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    assert a == b
    a = ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-22 21:26:01.118559
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence(['a', 'b'])
    assert is_sequence({'a': True, 'b': False})
    assert not is_sequence('string')
    assert is_sequence('string', include_strings=True)



# Generated at 2022-06-22 21:26:13.112624
# Unit test for function count
def test_count():
    assert count([]) == dict()
    assert count([1]) == {1: 1}
    assert count([1, 1, 1]) == {1: 3}
    assert count([1, 2, 1]) == {1: 2, 2: 1}
    assert count('abracadabra') == {'a': 5, 'b': 2, 'r': 2, 'c': 1, 'd': 1}
    assert count([1, 2, 3, 1, 2, 3, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 1]) == {1: 10, 2: 7, 3: 2}

# Generated at 2022-06-22 21:26:21.598994
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """
    >>> test_ImmutableDict().run_test()

    """
    # pylint: disable=too-few-public-methods
    class TestModule(object):
        """Unit test class"""
        # pylint: disable=no-self-use
        def run_test(self):
            """Run test"""
            # pylint: disable=invalid-name
            f_dict = {'a': 3}
            # pylint: disable=invalid-name
            ff_dict = ImmutableDict(f_dict, b=4)
            f_dict['a'] = 5
            f_dict['b'] = 6
            # pylint: disable=invalid-name
            fff_dict = ImmutableDict(f_dict)
            # Make sure object is immutable

# Generated at 2022-06-22 21:26:28.515252
# Unit test for function is_iterable
def test_is_iterable():
    class AList(list):
        pass

    class AString(str):
        pass

    assert not is_iterable('abc')
    assert is_iterable([1, 2, 3])
    assert is_iterable(AList('abc'))
    assert is_iterable({'a', 'b'})
    assert is_iterable({'a': 1, 'b': 2})

    assert is_iterable('abc', include_strings=True)
    assert is_iterable(AList('abc'), include_strings=True)
    assert is_iterable(AString('abc'), include_strings=True)



# Generated at 2022-06-22 21:26:38.691899
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():

    a = ImmutableDict({'a': 1, 'b': 2})
    assert hash(a) == hash(a)

    b = ImmutableDict({'b': 2, 'a': 1})
    assert hash(a) == hash(b)

    c = ImmutableDict({'b': 2, 'c': 3, 'a': 1})
    assert hash(a) != hash(c)

    d = ImmutableDict({'b': 1, 'a': 1})
    assert hash(a) != hash(d)

    e = ImmutableDict({'b': 2, 'a': 1}, extra='true')
    assert hash(a) == hash(e)


# Generated at 2022-06-22 21:26:46.362065
# Unit test for function is_iterable
def test_is_iterable():
    class NotIterable(object):
        pass

    class Iterable(object):
        def __iter__(self):
            return iter([])

    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(())
    assert is_iterable(Iterable())
    assert not is_iterable(NotIterable())
    assert not is_iterable({})
    assert not is_iterable('')
    assert not is_iterable(b'')

    assert is_iterable({}, include_strings=True)
    assert is_iterable('', include_strings=True)
    assert is_iterable(b'', include_strings=True)



# Generated at 2022-06-22 21:26:50.640570
# Unit test for function is_string
def test_is_string():
    assert is_string(u'123')
    assert is_string('123')
    assert is_string(u'123'.encode('utf-8'))
    assert is_string('123')

    assert not is_string(None)
    assert not is_string(123)
    assert not is_string(['1', '2', '3'])


# Generated at 2022-06-22 21:26:53.610185
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict()

    assert d['a'] == d._store['a']


# Generated at 2022-06-22 21:27:00.038655
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    dict_A = ImmutableDict([("k1", "v1"),("k2", "v2"), ("k3", "v3")])
    dict_A = dict_A.union({"k2": "v2B", "k4": "v4"})
    assert dict_A == ImmutableDict([("k1", "v1"),("k2", "v2B"), ("k3", "v3"),("k4", "v4")])


# Generated at 2022-06-22 21:27:06.613683
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a = ImmutableDict({"a": 1, "b": 2, "c": 3})
    b = ImmutableDict({"b": 2, "c": 3, "d": 4})
    assert a.union(b) == ImmutableDict({"a": 1, "b": 2, "c": 3, "d": 4})



# Generated at 2022-06-22 21:27:17.917438
# Unit test for function is_iterable
def test_is_iterable():
    for value in [None, 1, 5.4, 'a', [], {}, (1, 2), set()]:
        if not is_iterable(value):
            raise Exception(str(value) + ' is an iterable, but is_iterable() returned False')
    for value in [1, 5.4, 'a', {}, (1, 2), set()]:
        if is_iterable(value, include_strings=False):
            raise Exception(str(value) + ' is an iterable, but is_iterable(include_strings=False) returned True')

# Generated at 2022-06-22 21:27:30.087912
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_case1 = ImmutableDict({'key1': 'value1'})
    test_case2 = ImmutableDict({'key1': 'value1'})
    test_case3 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    test_case4 = {'key1': 'value1'}
    test_case5 = 'value1'

    if test_case1 == test_case2:
        print("Test case 1 and 2 are initialized with the same value and are equal")
    else:
        print("Test case 1 and 2 are initialized with the same value but are not equal")

    if test_case1 == test_case3:
        print("Test case 1 and 3 are initialized with different values but are equal")

# Generated at 2022-06-22 21:27:35.129399
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    dictionary = { 'a': 1, 'b': 2, 'c': 3 }
    expected_dictionary = { 'a': 1 }
    test_dictionary = ImmutableDict(dictionary)
    result_dictionary = test_dictionary.difference(list(dictionary.keys())[1:])
    assert result_dictionary == ImmutableDict(expected_dictionary)

# Generated at 2022-06-22 21:27:38.287752
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    id1 = ImmutableDict({1: 2, 3: 4})
    assert id1[1] == 2



# Generated at 2022-06-22 21:27:49.269837
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # 1. immuatble dict with none key
    d1 = ImmutableDict()
    d2 = ImmutableDict()
    assert hash(d1) == hash(d2)
    # 2. immutable dict with one key
    d1 = ImmutableDict({1: 'a'})
    d2 = ImmutableDict({1: 'a'})
    assert hash(d1) == hash(d2)
    # 3. immutable dict with two key
    d1 = ImmutableDict({1: 'a', 2: 'b'})
    d2 = ImmutableDict({1: 'a', 2: 'b'})
    assert hash(d1) == hash(d2)


# Generated at 2022-06-22 21:27:59.678387
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    module = AnsibleModule(
        argument_spec=dict(
            some_dict=dict(type='dict'),
            some_str=dict(type='str'),
            some_int=dict(type='int'),
            some_list=dict(type='list'),
            some_bool=dict(type='bool'),
            some_complex=dict(type='complex'),
        )
    )

    test_dict = dict(a=1, b='two')
    test_dict_repr = "ImmutableDict({'a': 1, 'b': 'two'})"

    mutable_dict = module.params['some_dict']
    mutable_dict['changed'] = True

    if sys.version_info.major == 2:
        assert repr

# Generated at 2022-06-22 21:28:08.624260
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(())
    assert is_iterable('')
    assert is_iterable('abc')
    assert not is_iterable(1)
    assert not is_iterable(5.5)
    assert not is_iterable(None)
    assert not is_iterable(object())


# Generated at 2022-06-22 21:28:11.630122
# Unit test for function is_string
def test_is_string():
    from ansible.module_utils.six import StringIO
    assert is_string("abc")
    assert is_string(u"abc")
    assert is_string(StringIO("abc"))



# Generated at 2022-06-22 21:28:23.492526
# Unit test for function is_iterable
def test_is_iterable():
    """
    Test is_iterable function.
    """
    # is_iterable returns true for iterable objects: list, tuple, set
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))

    # is_iterable returns true for dictionary
    assert is_iterable({'1': 'one', '2': 'two'})

    # is_iterable returns true for string-like objects: str, basestring and AnsibleVaultEncryptedUnicode
    # for compatibility with Python 3
    try:
        from ansible.parsing.vault import VaultLib
    except ImportError:
        pass
    else:
        test_string = VaultLib().encrypt('mystring')

# Generated at 2022-06-22 21:28:35.643039
# Unit test for method difference of class ImmutableDict

# Generated at 2022-06-22 21:28:39.244018
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'b': 3, 'c': 3})
    d = a.union(b)
    assert(d['a'] == 1)
    assert(d['b'] == 3)
    assert(d['c'] == 3)



# Generated at 2022-06-22 21:28:43.942020
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a = ImmutableDict({'a':1})
    b = ImmutableDict({'b':2,'c':3})
    d = a.union(b)
    assert d == ImmutableDict({'a':1,'b':2,'c':3})


# Generated at 2022-06-22 21:28:48.343674
# Unit test for function count
def test_count():
    test_seq = (1, 2, 2, 3, 2, 1, 2, 1, 2)
    res = count(test_seq)
    assert(res[1] == 3)
    assert(res[2] == 5)
    assert(res[3] == 1)


# Generated at 2022-06-22 21:28:51.750709
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict([('key', 'value')])) == 1


# Generated at 2022-06-22 21:28:59.128359
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict({
        'a': 1,
        'b': 2,
        'c': 3,
    })
    overriding_mapping = {
        'c': 4
    }
    new_dict = original.union(overriding_mapping)
    assert new_dict == ImmutableDict({
        'a': 1,
        'b': 2,
        'c': 4
    })



# Generated at 2022-06-22 21:29:10.119634
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    def check(original, subtractive_iterable, expected_result):
        result = original.difference(subtractive_iterable)
        assert result == expected_result
        assert isinstance(result, ImmutableDict)
        assert result is not original

    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    subtractive_iterable = {'a', 'z'}
    expected_result = ImmutableDict({'b': 2, 'c': 3})
    check(original, subtractive_iterable, expected_result)

    subtractive_iterable = ['a', 'z']
    expected_result = ImmutableDict({'b': 2, 'c': 3})
    check(original, subtractive_iterable, expected_result)


# Generated at 2022-06-22 21:29:16.949995
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    # arrange
    input_dict = {
        'key1': 1,
        'key2': 2,
        'key3': 3
    }
    answer = "ImmutableDict({'key1': 1, 'key2': 2, 'key3': 3})"
    # act
    result = ImmutableDict(input_dict).__repr__()
    # assert
    assert result == answer, 'Got incorrect string representation'


# Generated at 2022-06-22 21:29:19.356096
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    a = ImmutableDict({1: 2, 3: 4, 'string': 8})
    assert a.__iter__() == iter([1, 3, 'string'])



# Generated at 2022-06-22 21:29:26.904754
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence([1])
    assert is_sequence({'a': 1})
    assert is_sequence((1, 2, 3))
    assert is_sequence(set([1, 2, 3]))
    assert is_sequence('abcde')
    assert is_sequence(u'abcde')
    assert is_sequence(b'abcde')

    assert is_sequence([], True)
    assert is_sequence([1], True)
    assert is_sequence({'a': 1}, True)
    assert is_sequence((1, 2, 3), True)
    assert is_sequence(set([1, 2, 3]), True)
    assert is_sequence('abcde', True)
    assert is_sequence(u'abcde', True)
    assert is_sequence(b'abcde', True)



# Generated at 2022-06-22 21:29:34.982906
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    results = []

    # Test with empty dict
    id = ImmutableDict()
    results.append(id.__len__() == 0)

    # Test with non-empty dict
    id = ImmutableDict({'a': 1})
    results.append(id.__len__() == 1)

    # Test with non-empty dict
    id.__setitem__('b', 1)
    results.append(id.__len__() == 2)

    if False in results:
        return False
    else:
        return True


# Generated at 2022-06-22 21:29:47.099069
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    assert isinstance(ImmutableDict(), ImmutableDict)
    assert ImmutableDict() == ImmutableDict({})
    assert ImmutableDict({'a': 'b'}) == ImmutableDict(a='b')
    assert ImmutableDict({'a': 'b'}) == ImmutableDict(a='b')
    assert ImmutableDict({'a': 'b'}) != ImmutableDict(c='d')
    assert ImmutableDict({'a': 'b'}) != {'a': 'b'}
    assert ImmutableDict({'a': 'b'}) == ImmutableDict({'a': 'b'})

    a = ImmutableDict({'a': 'b'})
    b = ImmutableDict({'a': 'b'})
    assert a == b
    assert hash

# Generated at 2022-06-22 21:29:51.578559
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    immutable_dict = ImmutableDict({'a': 'A', 'b': 'B', 'c': 'C'})

    keys_in_dict = []
    for key in immutable_dict:
        keys_in_dict.append(key)

    assert keys_in_dict == ['a', 'b', 'c']


# Generated at 2022-06-22 21:29:54.339301
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert ImmutableDict({'a': 1, 'b': 2}).__repr__() == "ImmutableDict({'a': 1, 'b': 2})"


# Generated at 2022-06-22 21:29:57.093673
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    test_data = ImmutableDict(a='b')
    assert hash(test_data) == hash(frozenset(test_data.items()))

# Generated at 2022-06-22 21:30:04.806584
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    a1 = ImmutableDict(a=1, b=2, c=3)
    a2 = ImmutableDict(c=3, b=2, a=1)
    a3 = ImmutableDict(a=1, b=2, c=3, d=4)
    module.exit_json(count_tests=2, __hash___a1_a2=hash(a1) == hash(a2), __hash___a1_a3=hash(a1) != hash(a3))
