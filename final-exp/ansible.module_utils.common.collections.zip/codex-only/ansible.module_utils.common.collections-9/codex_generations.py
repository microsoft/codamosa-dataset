

# Generated at 2022-06-22 21:19:58.834326
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert str(ImmutableDict({'foo': 'bar'})) == "ImmutableDict({'foo': 'bar'})"


# Generated at 2022-06-22 21:20:02.278156
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict({'a': 'A', 'b': 'B'})) == 2
    assert len(ImmutableDict({'a': 'A', 'b': 'B', 'c': 'C'})) == 3


# Generated at 2022-06-22 21:20:10.475589
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    d = ImmutableDict(a=1, b=2, c=3)
    assert d == {
        'a': 1,
        'b': 2,
        'c': 3,
    }
    assert d == {
        'a': 1,
        'b': 2,
        'c': 3,
    }
    assert d == ImmutableDict(a=1, b=2, c=3)
    assert d == ImmutableDict(c=3, a=1, b=2)

    # Test equality to a regular dict
    assert d != {
        'a': 1,
        'b': 2,
        'c': 4,
    }
    assert d != {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4
    }

# Generated at 2022-06-22 21:20:16.613548
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2])
    assert is_iterable((1, 2))
    assert is_iterable({'1', '2'})
    assert is_iterable({'a': 'b'})
    assert is_iterable('12')
    assert is_iterable(bytearray(b'12'))
    assert not is_iterable(1)
    assert not is_iterable(1.2)



# Generated at 2022-06-22 21:20:21.609882
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict()
    assert repr(d) == 'ImmutableDict({})'

    d2 = ImmutableDict({'a': 'b'})
    assert repr(d2) == "ImmutableDict({'a': 'b'})"



# Generated at 2022-06-22 21:20:25.427426
# Unit test for function count
def test_count():
    assert count("test test test") == {'t': 4, 'e': 2, 's': 3}
    assert count([1, 1, 2, 3]) == {1: 2, 2: 1, 3: 1}
    assert count([(1, 2), (3, 4), (3, 4)]) == {(1, 2): 1, (3, 4): 2}



# Generated at 2022-06-22 21:20:30.570944
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """ Test if the len() method works as expected."""
    dict_1 = ImmutableDict()
    assert len(dict_1) == 0

    dict_2 = ImmutableDict(a=1)
    assert len(dict_2) == 1

    dict_3 = ImmutableDict(a=1, b=2)
    assert len(dict_3) == 2


# Generated at 2022-06-22 21:20:33.355832
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    assert ImmutableDict(a='A', b='B', c='C')['b'] == 'B'


# Generated at 2022-06-22 21:20:39.851192
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d1 = ImmutableDict({'spam': 1, 'eggs': 2})
    d2 = ImmutableDict({'eggs': 2, 'spam': 1})
    d3 = ImmutableDict({'foo': 3, 'bar': 4})

    assert hash(d1) == hash(d2)
    assert hash(d1) != hash(d3)

    assert d1 == d2
    assert d1 != d3


# Generated at 2022-06-22 21:20:45.957758
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    # Both can be considered as a pass of test
    #assert ImmutableDict({1: 'a'}).keys() == ImmutableDict(a=1).keys() == ImmutableDict({'a': 1}).keys() == ImmutableDict(a=1).keys() == ['a']
    assert list(ImmutableDict({1: 'a'})) == list(ImmutableDict(a=1)) == ['a']



# Generated at 2022-06-22 21:20:58.157771
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    test_dict = {'key1':'val1', 'key2':'val2', 'key3':'val3'}
    test_immut_dict = ImmutableDict(test_dict)
    test_immut_dict2 = ImmutableDict(test_dict)
    test_immut_dict3 = ImmutableDict(test_dict)
    assert test_immut_dict == test_immut_dict2
    assert hash(test_immut_dict) == hash(test_immut_dict2)
    assert hash(test_immut_dict) == hash(test_immut_dict3)
    test_immut_dict2.union({'key4':'val4', 'key5':'val5'})

# Generated at 2022-06-22 21:21:00.841675
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    immutable_dict_ = ImmutableDict(dict(a=1, b=2))
    assert immutable_dict_['a'] == 1


# Generated at 2022-06-22 21:21:09.016568
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    expected_output = {'a': 1, 'b': 2, 'c': 3}

    imm_dict = ImmutableDict({'a': 1, 'b': 2})

    # Test a combination of ImmutableDict and dict
    assert expected_output == imm_dict.union({'b': 2, 'c': 3})

    # Test a combination of ImmutableDict and ImmutableDict
    assert expected_output == imm_dict.union(ImmutableDict({'b': 2, 'c': 3}))

    # Test that the original ImmutableDict is unchanged
    assert imm_dict == ImmutableDict({'a': 1, 'b': 2})



# Generated at 2022-06-22 21:21:16.256767
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({'a': 'A', 'b': 'B'})
    dict2 = ImmutableDict({'a': 'A', 'b': 'B'})
    dict3 = ImmutableDict({'b': 'B', 'a': 'A'})

    assert dict1 == dict2
    assert dict1 == dict3
    assert dict1 != {'a': 'A', 'b': 'B'}


# Generated at 2022-06-22 21:21:28.480974
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    ImmutableDict_1 = ImmutableDict({"key1": 1, "key2": 2})
    ImmutableDict_2 = ImmutableDict({"key1": 3, "key3": 3})
    ImmutableDict_3 = ImmutableDict_1.union(ImmutableDict_2)
    assert len(ImmutableDict_1) == 2
    assert len(ImmutableDict_2) == 2
    assert len(ImmutableDict_3) == 3
    assert "key1" in ImmutableDict_1
    assert "key2" in ImmutableDict_1
    assert "key1" in ImmutableDict_2
    assert "key3" in ImmutableDict_2
    assert "key1" in ImmutableDict_3
    assert "key2" in ImmutableD

# Generated at 2022-06-22 21:21:31.391129
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    idict = ImmutableDict({'one': 1, 'two': 2})
    it = iter(idict)
    assert next(it) == 'one'
    assert next(it) == 'two'


# Generated at 2022-06-22 21:21:42.242881
# Unit test for function is_sequence
def test_is_sequence():

    class Dummy(object):
        def __getitem__(self, key):
            return key

    test_seq = [1, 2, 3]
    test_dict = {'a': 1, 'b': 2}
    test_set = set([1, 2, 3])
    test_string = '123'
    test_obj = Dummy()

    assert is_sequence(test_seq)
    assert not is_sequence(test_dict)
    assert not is_sequence(test_set)
    assert not is_sequence(test_string)
    assert not is_sequence(test_obj)
    assert is_sequence(test_seq, include_strings=True)
    assert is_sequence(test_string, include_strings=True)
    assert is_sequence(test_obj, include_strings=True)

# Generated at 2022-06-22 21:21:49.371197
# Unit test for function count
def test_count():
    # Check the happy path
    test_seq = [3, 4, 4, 2, 4, 4, 4, 1, 1, 0]
    test_counters = dict()
    for i in range(0, 5):
        test_counters[i] = test_seq.count(i)
    assert test_counters == count(test_seq)
    # Check the corner case with empty sequence
    test_seq = []
    assert dict() == count(test_seq)
    # Check the corner case with sequence containing duplicates of all elements
    test_seq = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
    test_counters[1] = 10
    assert test_counters == count(test_seq)



# Generated at 2022-06-22 21:21:53.314346
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    immutable_dict = ImmutableDict({'a': 1, 'b': 2})
    assert immutable_dict['a'] == 1
    try:
        _illegal_dict = immutable_dict['c']
    except KeyError:
        pass


# Generated at 2022-06-22 21:21:56.890305
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """Unit test for method __len__ of class ImmutableDict
    """
    d = ImmutableDict({})
    assert len(d) == 0
    d = ImmutableDict({"a": 1, "b": 2})
    assert len(d) == 2



# Generated at 2022-06-22 21:22:02.720542
# Unit test for function is_iterable
def test_is_iterable():
    class NotIterable(object):
        pass

    class Iterable(NotIterable):
        def __iter__(self):
            pass

    class Sequence(object):
        def __getitem__(self, item):
            pass

    assert not is_iterable(1)
    assert is_iterable(NotIterable())
    assert is_iterable(Iterable())
    assert is_iterable(Sequence())
    assert not is_iterable('not iterable')
    assert not is_iterable(u'not iterable')
    assert is_iterable('iterable', include_strings=True)
    assert is_iterable(u'iterable', include_strings=True)



# Generated at 2022-06-22 21:22:05.284350
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    temp = ImmutableDict()
    assert isinstance(temp.__iter__(), type(iter([])))


# Generated at 2022-06-22 21:22:12.090856
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    # Create a sample ImmutableDict and get a value
    d = ImmutableDict({'a':1, 'b':2})
    v = d['a']
    assert v == 1

    # Try to get an unexisting key and should get KeyError
    try:
        d['z']
    except KeyError:
        pass
    else:
        assert "KeyError should have been raised"


# Generated at 2022-06-22 21:22:18.162172
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Unit test for method __repr__ of class ImmutableDict"""
    idict = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    rep = repr(idict)
    assert(rep == "ImmutableDict({'key1': 'value1', 'key2': 'value2'})")
    assert(isinstance(idict, Hashable))
    assert(isinstance(idict, Mapping))
    assert(not isinstance(idict, MutableMapping))

# Generated at 2022-06-22 21:22:25.901005
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d3 = ImmutableDict({'a': 1, 'b': 2})
    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})

    assert hash(d1) == hash(d2)
    assert hash(d1) != hash(d3)
    assert hash(d1) != hash(d4)


# Generated at 2022-06-22 21:22:36.447615
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    assert ImmutableDict(x=1) == ImmutableDict(x=1)
    assert ImmutableDict(x=1) == {"x":1}
    assert ImmutableDict(x=1) == ImmutableDict({"x":1})
    assert ImmutableDict(x=1).union({"y":2}) == ImmutableDict({"x":1, "y":2})
    assert ImmutableDict(x=1).union({"x":2}) == ImmutableDict({"x":2})
    assert ImmutableDict(x=1).difference([]) == ImmutableDict({"x":1})
    assert ImmutableDict(x=1).difference(["x"]) == ImmutableDict({})
    assert ImmutableDict(x=1).difference(["y"])

# Generated at 2022-06-22 21:22:46.374092
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for two different ImmutableDict objects
    d1 = ImmutableDict({'k1': 'v1', 'k2': 'v2'})
    d2 = ImmutableDict({'k1': 'v1', 'k2': 'v2'})
    assert d1 == d2
    assert d2 == d1

    # Test for two ImmutableDict objects that are not equal
    d1 = ImmutableDict({'k1': 'v1', 'k2': 'v2'})
    d2 = ImmutableDict({'k1': 'v1', 'k2': 'v3'})
    assert d1 != d2
    assert d2 != d1

    # Test for a ImmutableDict and a non ImmutableDict object

# Generated at 2022-06-22 21:22:49.629764
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert is_string(u'foo')
    assert is_string(b'foo')
    assert not is_string(123)
    assert not is_string([1, 2, 3])
    assert not is_string((1, 2, 3))


# Generated at 2022-06-22 21:22:58.857844
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # test equal ImmutableDicts
    test_dict1 = ImmutableDict({'key1': 'val', 'key2': 'val2'})
    test_dict2 = ImmutableDict({'key1': 'val', 'key2': 'val2'})
    assert test_dict1 == test_dict2

    # test different ImmutableDicts
    test_dict1 = ImmutableDict({'key1': 'val', 'key2': 'val2'})
    test_dict2 = ImmutableDict({'key1': 'val', 'key2': 'val3'})
    assert test_dict1 != test_dict2

    # test equal internal data structure (mutable)
    test_dict1 = ImmutableDict({'key1': 'val', 'key2': 'val2'})
    test_dict2

# Generated at 2022-06-22 21:23:08.432788
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Test __repr__ - Function to test the ImmutableDict class's __repr__ method"""
    a_dict = {'a': 1, 'b': 2, 'c': 3}
    expected_repr = "ImmutableDict({'a': 1, 'c': 3, 'b': 2})"
    test_immutable_dict = ImmutableDict(a_dict)
    if test_immutable_dict.__repr__() == expected_repr:
        print('ImmutableDict.__repr__ successfully passed the test')
    else:
        print('ImmutableDict.__repr__ failed the test')


# Generated at 2022-06-22 21:23:19.744450
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': '1', 'b': '2', 'c': '3'})
    b = ImmutableDict({'a': '1', 'b': '2', 'c': '3', 'd': '4'})
    c = ImmutableDict({'a': '1', 'b': '2', 'c': '3'})
    d = ImmutableDict({'a': '1', 'b': 2, 'c': 3})
    e = ImmutableDict({'a': '1', 'b': '2', 'c': 3})
    f = ImmutableDict({'a': '1', 'b': '2', 'c': None})
    g = None

    assert not a.__eq__(b)
    assert a.__eq__(c)
    assert not a

# Generated at 2022-06-22 21:23:30.718730
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    def length_of(idict):
        return len(idict)

    invalid_inputs = [None, set()]
    expected_results = [0, 0]

    for invalid_input, expected_result in zip(invalid_inputs, expected_results):
        assert length_of(invalid_input) == expected_result

    valid_inputs = [{'a': 1}, {'b': 2}, {'c': 3, 'd': 4}]
    expected_results = [1, 1, 2]

    for valid_input, expected_result in zip(valid_inputs, expected_results):
        assert length_of(ImmutableDict(valid_input)) == expected_result


# Generated at 2022-06-22 21:23:34.036157
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    assert hash(ImmutableDict({'a':1,'b':2})) == hash(frozenset([('a',1),('b',2)]))


# Generated at 2022-06-22 21:23:41.426221
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({"a":1, "b":2, "c":3})
    b = ImmutableDict({"a":1, "b":2, "c":3})
    c = ImmutableDict({"a":1, "b":2, "c":4})
    d = {"a":1, "b":2, "c":3}
    e = {"a":1, "b":2, "c":4}

    assert(a == b)
    assert(b == a)
    assert(a is not b)
    assert(b is not a)
    assert(a != c)
    assert(c != a)
    assert(a != d)
    assert(d != a)
    assert(c != d)
    assert(d != c)
    assert(c != e)

# Generated at 2022-06-22 21:23:44.196086
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    immutable_dict = ImmutableDict({"key_1" : "value_1", "key_2" : "value_2"})
    assert len(immutable_dict) == 2


# Generated at 2022-06-22 21:23:54.616888
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    arg = {'a': 1, 'b': 2}
    new_dict = ImmutableDict(arg).union({'b': 4, 'c': 5})
    assert new_dict == {'a': 1, 'b': 4, 'c': 5} or new_dict == {'a': 1, 'c': 5, 'b': 4}

assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}).difference({'b'}) == ImmutableDict({'a': 1, 'c': 3}), "absent key difference"
assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}).difference({'d': 4}) == ImmutableDict({'a': 1, 'b': 2, 'c': 3}), "present key difference"
assert Immutable

# Generated at 2022-06-22 21:23:56.603737
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    dict1 = ImmutableDict({'a': 1, 'b': 2})

    assert len(dict1) == 2



# Generated at 2022-06-22 21:24:01.775208
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
   assert (ImmutableDict({'name': 'A', 'age': 1}) == ImmutableDict({'age': 1, 'name': 'A'}))
   assert (ImmutableDict({'name': 'A', 'age': 1}) != ImmutableDict({'name': 'B', 'age': 2}))
   assert (ImmutableDict({'name': 'A', 'age': 1}) != ImmutableDict({'name': 'A', 'age': 2}))
   assert (ImmutableDict({'name': 'A', 'age': 1}) != ImmutableDict({'age': 1}))


# Generated at 2022-06-22 21:24:09.213011
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    original_dict = ImmutableDict({'k1': 'v1', 'k2': 'v2'})
    original_dict_elements = []
    for elem in original_dict:
        original_dict_elements.append(elem)

    if len(original_dict_elements) != 2:
        return False

    if 'k1' not in original_dict_elements or 'k2' not in original_dict_elements:
        return False

    return True


# Generated at 2022-06-22 21:24:17.848615
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a = ImmutableDict(x='a', y='b')
    b = a.union({'y': 'c', 'z': 'd'})
    c = b.union({'a': 'e', 'b': 'f'})

    assert a['x'] == 'a'
    assert a['y'] == 'b'
    assert b['x'] == 'a'
    assert b['y'] == 'c'
    assert c['y'] == 'c'
    assert c['z'] == 'd'
    assert c['a'] == 'e'
    assert c['b'] == 'f'



# Generated at 2022-06-22 21:24:22.675731
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence(set())
    assert is_sequence(list())
    assert is_sequence(tuple())
    assert is_sequence(range(5))

    assert not is_sequence(5)
    assert not is_sequence(None)
    assert not is_sequence({})
    assert not is_sequence(object())

    assert is_sequence('', include_strings=True)
    assert is_sequence(b'', include_strings=True)



# Generated at 2022-06-22 21:24:24.977321
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    assert hash(ImmutableDict({'a': 2, 'b': 3})) == hash(frozenset([('a', 2), ('b', 3)]))


# Generated at 2022-06-22 21:24:28.833775
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert ImmutableDict().__repr__() == 'ImmutableDict({})'
    assert ImmutableDict({'key': 'value'}).__repr__() == "ImmutableDict({'key': 'value'})"
    assert ImmutableDict().union({'key': 'value'}).__repr__() == "ImmutableDict({'key': 'value'})"

# Generated at 2022-06-22 21:24:33.708024
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.basic import ImmutableDict
    imutDict = ImmutableDict()
    assert 0 == len(imutDict)

# Generated at 2022-06-22 21:24:39.516649
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert not ImmutableDict({'a': 1}) == ImmutableDict({'a': 2})
    assert not ImmutableDict({'a': 1}) == dict({'a': 1})
    # None is not hashable
    assert not ImmutableDict({'a': 1}) == None


# Generated at 2022-06-22 21:24:52.034142
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    assert hash(ImmutableDict()) == hash(ImmutableDict())
    assert hash(ImmutableDict(a=1)) == hash(ImmutableDict(a=1))
    assert hash(ImmutableDict(b=2)) == hash(ImmutableDict(b=2))
    assert hash(ImmutableDict(a=1, b=2)) == hash(ImmutableDict(a=1, b=2))
    assert hash(ImmutableDict(b=2, a=1)) == hash(ImmutableDict(a=1, b=2))

    assert hash(ImmutableDict(a=1)) != hash(ImmutableDict(a=2))
    assert hash(ImmutableDict(a=1)) != hash(ImmutableDict(a=1, b=2))

# Generated at 2022-06-22 21:25:02.802155
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    import pytest
    data = {'a': 1, 'b': 2, 'd': 'A', 'c': 3}
    data_id = id(data)
    id_a = id(ImmutableDict(data))
    id_b = id(ImmutableDict(data))
    id_c = id(ImmutableDict(data, a=4))
    id_d = id(ImmutableDict(data, a=4, d='B'))
    assert hash(ImmutableDict(data)) == hash(ImmutableDict(data))
    assert hash(ImmutableDict(data, a='B', d=4)) == hash(ImmutableDict(data, a='B', d=4))
    assert id_a != id_b
    assert id_a == id_c
    assert data_id

# Generated at 2022-06-22 21:25:12.036648
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Test for method __hash__ of class ImmutableDict

    The __hash__ method of ImmutableDict behaves as that
    of dict, with minor differences concerning unhashable
    keys/values. As __hash__ of dict itself can be tested
    in the Python standard library, we don't explicitly test
    it here. We only test what is different.
    """
    import pytest

    from itertools import chain, product

    from ansible.module_utils.common.collections import ImmutableDict

    # List of values for which ImmutableDict.__hash__
    # should raise a TypeError.
    # If a value is unhashable, the key is not even taken
    # into account. (The following is just a reminder.)

# Generated at 2022-06-22 21:25:19.127780
# Unit test for function is_string
def test_is_string():
    # Test type
    assert is_string(text_type())
    assert is_string(binary_type())
    assert not is_string(MutableMapping())
    assert not is_string(Sequence())
    assert not is_string([])
    assert not is_string(())
    assert not is_string(set())
    assert not is_string(2)

    # Test behavior of string-like objects
    class StringLike(Sequence):
        def __getitem__(self, key):
            pass
        def __len__(self):
            return 1

    assert is_string(StringLike())


# Generated at 2022-06-22 21:25:31.704113
# Unit test for function is_iterable
def test_is_iterable():
    # Test for strings
    assert not is_iterable('')
    assert not is_iterable('abcd')
    assert not is_iterable(b'')
    assert not is_iterable(b'abcd')
    assert not is_iterable(u'')
    assert not is_iterable(u'abcd')
    # Test for list
    assert is_iterable([])
    assert is_iterable([1, 2, 3, 4])
    # Test for tuple
    assert is_iterable(())
    assert is_iterable((1, 2, 3, 4))
    # Test for dict
    assert is_iterable({})
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(dict(a=1, b=2))
    assert is_iter

# Generated at 2022-06-22 21:25:37.766103
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d2 = d1.difference(['a', 'c'])
    assert d2 == ImmutableDict({'b': 2})
    assert d1 == ImmutableDict({'a': 1, 'b': 2, 'c': 3})


# Generated at 2022-06-22 21:25:44.567622
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d1 = ImmutableDict()
    d2 = ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    assert d1.__repr__() == 'ImmutableDict({})'
    assert d2.__repr__() == "ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})"



# Generated at 2022-06-22 21:25:53.933231
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict({"a":1, "b":2})
    overriding_mapping = ImmutableDict({"c":3, "d":4})
    new_immutable_dict = original.union(overriding_mapping)
    assert sorted(new_immutable_dict) == ["a", "b", "c", "d"]
    assert new_immutable_dict["a"] == 1
    assert new_immutable_dict["b"] == 2
    assert new_immutable_dict["c"] == 3
    assert new_immutable_dict["d"] == 4


# Generated at 2022-06-22 21:26:05.696820
# Unit test for function is_iterable
def test_is_iterable():
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six.moves.http_cookiejar import CookieJar
    from ansible.module_utils.six.moves import UserDict
    import io
    import csv
    import os
    import glob
    import zipfile
    import tarfile
    import xmltodict
    import xml.etree.ElementTree

    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable('abc')
    assert is_iterable(iter('abc'))
    assert is_iterable((n for n in range(5)))
    assert is_iterable(dict(a=1, b=2))
    assert is_iter

# Generated at 2022-06-22 21:26:08.797016
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence(u'unicode') is False
    assert is_sequence(b'bytes') is False
    assert is_sequence(b'bytes', include_strings=True) is True
    assert is_sequence(u'unicode', include_strings=True) is True

    assert is_sequence([]) is True
    assert is_sequence(range(5)) is True
    assert is_sequence((1, 2, 3)) is True
    assert is_sequence({'a': 1}) is False
    assert is_sequence({'a': 1}.keys()) is True
    assert is_sequence({'a': 1}.items()) is True
    assert is_sequence(1) is False
    assert is_sequence(None) is False



# Generated at 2022-06-22 21:26:10.905188
# Unit test for function count
def test_count():
    assert count([1, 2, 3, 1]) == {1: 2, 2: 1, 3: 1}



# Generated at 2022-06-22 21:26:17.017835
# Unit test for function count
def test_count():
    test_list = [1, 2, 3, 1, 4, 1]
    assert count(test_list) == {1: 3, 2: 1, 3: 1, 4: 1}
    assert count({1: 2, 3: 1, 4: 1}) == {1: 1, 3: 1, 4: 1}
    assert count('abcdab') == {'a': 2, 'b': 2, 'c': 1, 'd': 1}
    assert count(set('abcdab')) == {'a': 2, 'b': 2, 'c': 1, 'd': 1}
    assert count(1) == Exception

# Generated at 2022-06-22 21:26:24.847606
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(dict(a=1)) == ImmutableDict(dict(a=1))
    assert ImmutableDict(dict(a=1)) != ImmutableDict(dict(a=2))
    assert ImmutableDict(dict(a=1)) != ImmutableDict(dict(a=1, b=2))
    assert ImmutableDict(dict(a=1, b=2)) != ImmutableDict(dict(a=1))


# Generated at 2022-06-22 21:26:35.206440
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    arg1 = ImmutableDict(one=1, two=2)
    arg2 = ImmutableDict(one=1, two=2)
    assert arg1 == arg2

    arg3 = ImmutableDict(one=1, two=2, three=3)
    assert arg1 != arg3

    arg4 = ImmutableDict(one=1, three=3)
    assert arg1 != arg4

    arg5 = ImmutableDict(one=2, two=3)
    assert arg1 != arg5

    # unicode comparison
    arg1 = ImmutableDict(one=u'1', two='2')
    arg2 = ImmutableDict(one=u'1', two='2')
    assert arg1 == arg2

    # string comparison

# Generated at 2022-06-22 21:26:37.699478
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict({'a': 1, 2: 'b', 'c': []})) == 3



# Generated at 2022-06-22 21:26:44.973922
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    immutable_dict1 = ImmutableDict()
    assert repr(immutable_dict1) == 'ImmutableDict({})', 'failed to represent an empty ImmutableDict'
    immutable_dict2 = ImmutableDict({'a': 1, 'b': 2.0, 'c': 'three'})
    assert repr(immutable_dict2) == "ImmutableDict({'a': 1, 'c': 'three', 'b': 2.0})", 'failed to represent a quarter full ImmutableDict'
    assert "ImmutableDict" in repr(ImmutableDict(a=1, b=2, c=3))


# Generated at 2022-06-22 21:26:48.260393
# Unit test for function count
def test_count():
    test_list = ['one', 'one', 'two', 'two', 'three']
    counters = count(test_list)
    assert counters['one'] == 2
    assert counters['two'] == 2
    assert counters['three'] == 1
    assert len(counters) == 3



# Generated at 2022-06-22 21:26:51.140388
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict({'a': 1, 'b': 2})
    assert len(list(iter(d))) == 2


# Generated at 2022-06-22 21:26:57.820292
# Unit test for function count
def test_count():
    assert count([1,2,2,2,2,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3]) == {1: 1, 2: 4, 3: 21}
    assert count([1,2,2]) == {1: 1, 2: 2}
    assert count([3,3,3]) == {3: 3}
    assert count(['A','A','b','c','d',2,2,2,2]) == {'A': 2, 'b': 1, 'c': 1, 'd': 1, 2: 4}
    assert count('122') == {'1': 1, '2': 2}
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
   

# Generated at 2022-06-22 21:27:05.513861
# Unit test for function is_iterable
def test_is_iterable():
    """Function to test the is_iterable function"""
    # AnsibleVaultEncryptedUnicode has an extra attribute to distinguish it from str/unicode
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode
    assert is_iterable("123") is False
    assert is_iterable("123", include_strings=True) is True
    assert is_iterable(AnsibleVaultEncryptedUnicode("123")) is True
    assert is_iterable("123".encode("utf-8")) is False
    assert is_iterable("123".encode("utf-8"), include_strings=True) is True

    assert is_iterable(1) is False
    assert is_iterable(1.0) is False
    assert is_iterable(1j) is False

    assert is_

# Generated at 2022-06-22 21:27:12.234419
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    test_dict = ImmutableDict({1: 2, 3: 4})
    for key in test_dict:
        assert key in [1, 3]
    for key in test_dict.keys():
        assert key in [1, 3]
    for value in test_dict.values():
        assert value in [2, 4]
    for key, value in test_dict.items():
        assert (key, value) in [(1, 2), (3, 4)]


# Generated at 2022-06-22 21:27:16.311044
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict({'1': 'one', '2': 'two'})
    assert len(d) == 2
    # Empty ImmutableDict
    d = ImmutableDict()
    assert len(d) == 0


# Generated at 2022-06-22 21:27:28.524035
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    """Method __iter__ of class ImmutableDict returns an iterator which iterates over the keys of the dictionary"""
    # Create ImmutableDict
    immutable_dict = ImmutableDict({'1': 'one', '2': 'two', '3': 'three'})
    # Retrieve all of the keys using method __iter__
    keys = [i for i in immutable_dict]
    assert len(keys) == 3, 'There should be 3 keys.'
    assert '1' in keys and '2' in keys and '3' in keys
    # Test the iterator by iterating over it again
    keys = [i for i in immutable_dict]
    assert len(keys) == 3, 'There should be 3 keys.'
    assert '1' in keys and '2' in keys and '3' in keys


# Generated at 2022-06-22 21:27:33.628522
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = d1.union({'b': 5, 'c': 3})
    d3 = d1.difference(('b',))

    assert d1['a'] == 1
    assert d2['b'] == 5
    assert 'a' in d3
    assert 'b' not in d3

# Generated at 2022-06-22 21:27:36.127160
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict(a=1, b=2, c=3)
    expected = ImmutableDict(c=3)
    removed = original.difference(('a', 'b'))
    assert removed == expected
    assert isinstance(removed, ImmutableDict)



# Generated at 2022-06-22 21:27:46.405232
# Unit test for function is_string
def test_is_string():
    class A(Sequence):
        def __init__(self, *args):
            self.args = args

        def __getitem__(self, item):
            return self.args.__getitem__(item)

        def __len__(self):
            return len(self.args)

        def __iter__(self):
            return iter(self.args)

        def __contains__(self, item):
            return item in self.args

    assert is_string('string')
    assert is_string(u'string')
    assert is_string(b'string')
    assert not is_string(A('1', '2', '3'))
    assert not is_string(['1', '2', '3'])
    assert not is_string(set(['1', '2', '3']))


# Generated at 2022-06-22 21:27:55.696030
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_dict1 = {'a': 1, 'b': 2, 'c': 3}
    test_dict2 = {'a': 1, 'b': 2, 'c': 3}
    test_dict3 = {'a': 1, 'c': 2, 'b': 3}
    test_dict4 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

    test_ImmutableDict1 = ImmutableDict(test_dict1)
    test_ImmutableDict2 = ImmutableDict(test_dict2)
    test_ImmutableDict3 = ImmutableDict(test_dict3)
    test_ImmutableDict4 = ImmutableDict(test_dict4)

    assert test_ImmutableDict1 == test_ImmutableDict2

    assert test_

# Generated at 2022-06-22 21:28:01.798157
# Unit test for function count
def test_count():
    from nose.tools import assert_equals, assert_raises

    with assert_raises(Exception):
        count(1)

    assert_equals(count([1, 2, 1]), {1: 2, 2: 1})
    assert_equals(count([1.0, 2.0, 1.0]), {1.0: 2, 2.0: 1})
    assert_equals(count(['a', 'b', 'a', 'a']), {'a': 3, 'b': 1})
    assert_equals(count([]), {})



# Generated at 2022-06-22 21:28:13.702786
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    assert ImmutableDict() == ImmutableDict({})
    assert ImmutableDict({1: 2, 3: 4}) == ImmutableDict({1: 2, 3: 4})
    assert ImmutableDict({1: 2, 3: 4, 5: 6}) == ImmutableDict({3: 4, 5: 6, 1: 2})
    assert ImmutableDict({1: 2, 3: 4}) == ImmutableDict([(1, 2), (3, 4)])
    assert ImmutableDict([(1, 2), (3, 4)]) == ImmutableDict({3: 4, 1: 2})
    assert ImmutableDict([(3, 4), (1, 2)]) == ImmutableDict({1: 2, 3: 4})

# Generated at 2022-06-22 21:28:18.600659
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    im = ImmutableDict({'one': 1, 'two': 2, 'three': 3})
    assert im.difference(['two', 'three']) == {'one': 1}
    assert im.difference(['two']) == {'one': 1, 'three': 3}
    assert im.difference([]) == im._store


# Generated at 2022-06-22 21:28:24.814896
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict(a=1, b=2, c=3)
    overriding_mapping = dict(c='C', d='D', e='E')
    new_dict = original.union(overriding_mapping)
    assert len(new_dict) == 5
    assert new_dict.get('a') == 1
    assert new_dict.get('b') == 2
    assert new_dict.get('c') == 'C'
    assert new_dict.get('d') == 'D'
    assert new_dict.get('e') == 'E'



# Generated at 2022-06-22 21:28:28.103532
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict(a=1, b=2, c=3)
    expected = ImmutableDict(a=1, b=2)
    removed = original.difference(['c'])
    assert removed == expected


# Generated at 2022-06-22 21:28:34.908003
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    assert ImmutableDict({'key': 'value'}) == {'key': 'value'}
    assert ImmutableDict(key='value') == {'key': 'value'}
    assert ImmutableDict([('key', 'value')]) == {'key': 'value'}
    assert ImmutableDict([('key', 'value'), ('another_key', 'another_value')]) == {'key': 'value', 'another_key': 'another_value'}


# Unit tests for union()

# Generated at 2022-06-22 21:28:47.363011
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # Test case 1: Original dict has multiple values
    dict_original = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    dict_subtractive = ['c', 'd']
    assert dict_original.difference(dict_subtractive) == ImmutableDict({'a': 1, 'b': 2})

    # Test case 2: Original dict has multiple values and subtractive dict is an ImmutableDict
    dict_original = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    dict_subtractive = ImmutableDict({'c': 3, 'd': 4})
    assert dict_original.difference(dict_subtractive) == ImmutableDict({'a': 1, 'b': 2})

    #

# Generated at 2022-06-22 21:28:55.411961
# Unit test for function count
def test_count():
    assert count([]) == dict()
    assert count([1, 1]) == {1: 2}
    assert count([1, 1, 2, 3]) == {1: 2, 2: 1, 3: 1}
    assert count(('a', 'a', 'b')) == {'a': 2, 'b': 1}
    assert count(('a', 1, 'a')) == {'a': 2, 1: 1}
    try:
        count('a')
    except Exception as e:
        assert isinstance(e, Exception)


# Generated at 2022-06-22 21:29:01.318849
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    immutable_dict = ImmutableDict(a='A', b='B')
    for key in immutable_dict:
        if key == 'a':
            assert immutable_dict.__getitem__('a') == 'A'
        else:
            assert immutable_dict.__getitem__('b') == 'B'



# Generated at 2022-06-22 21:29:04.093823
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict({'key1': 'val1', 'key2': 'val2'})

    assert list(d) == ['key1', 'key2']


# Generated at 2022-06-22 21:29:12.915090
# Unit test for function is_iterable
def test_is_iterable():
    def my_iter():
        yield 1
    gen = (i for i in [5, 6, 7, 8, 9])
    assert is_iterable((5, 6, 7))                           # tuple
    assert is_iterable([5, 6, 7])                           # list
    assert is_iterable(gen)                                 # generator
    assert is_iterable(my_iter())                           # function with yield
    assert is_iterable(xrange(1, 10))                       # xrange
    assert is_iterable(set('abc'))                          # set
    assert is_iterable(dict(a=5, b=6, c=7).keys())          # dictionary keys
    assert is_iterable(dict(a=5, b=6, c=7).values())        # dictionary values

# Generated at 2022-06-22 21:29:25.251346
# Unit test for function is_sequence
def test_is_sequence():
    # "strings" are neither sequences nor iterables
    assert not is_sequence("")
    assert not is_sequence("abc")
    assert not is_sequence(u"")
    assert not is_sequence(u"abc")

    # bytes are a special case, let's call them "strings"
    assert not is_sequence(b"")
    assert not is_sequence(b"abc")

    # a bare object is not a sequence or iterable
    class Foo(object):
        pass

    foo = Foo()
    assert not is_sequence(foo)

    # lists, tuples and arrays are sequences, but not dicts
    assert is_sequence([])
    assert is_sequence(())
    assert is_sequence([1, 2, 3])
    assert is_sequence((1, 2, 3))

# Generated at 2022-06-22 21:29:36.726004
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test 1. Two different instances of ImmutableDict with the same content should be equal
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(a=1, b=2)
    assert(d1 == d2)

    # Test 2. Two different instances of ImmutableDict with different content should not be equal
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(b=1, c=2)
    assert(d1 != d2)

    # Test 3. MutableMapping with equal content should not be equal to ImmutableDict
    d1 = ImmutableDict(a=1, b=2)
    d2 = dict(a=1, b=2)
    assert(d1 != d2)

# Generated at 2022-06-22 21:29:49.070160
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Below are some unit tests for class ImmutableDict.

    Unit tests for method __eq__ are defined here.
    """
    # Test a case when two ImmutableDicts are equal
    dict1 = ImmutableDict(a=1, b=2)
    dict2 = ImmutableDict(b=2, a=1)
    assert dict1 == dict2

    # Test a case when two ImmutableDicts are not equal
    dict1 = ImmutableDict(a=1, b=2, c=3)
    dict2 = ImmutableDict(b=2, a=1)
    assert not dict1 == dict2

    # Test a case where ImmutableDict is compared to non-ImmutableDict
    dict1 = ImmutableDict(b=2, a=1)

# Generated at 2022-06-22 21:29:58.426346
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1= ImmutableDict({'a':1, 'b':2})
    dict2= ImmutableDict({'a':1, 'b':2})
    dict3= ImmutableDict({'a':1, 'b':2, 'c':3})
    dict4= ImmutableDict({'b':2, 'a':1})
    dict5= ImmutableDict({'b':3, 'a':1})
    assert (dict1 == dict2)
    assert (dict1 == dict4)
    assert (dict2 == dict4)
    assert (dict1 == dict1)
    assert not(dict1 == dict3)
    assert not(dict1 == dict5)
    assert not(dict1 == 'dict1')
    assert not(dict1 == 'dict5')