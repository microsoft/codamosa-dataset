

# Generated at 2022-06-22 21:20:00.419114
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    immutable_dict = ImmutableDict({'a': 0, 'b': 1, 'c': 2, 'd': 3})
    assert set(immutable_dict) == set(('a', 'b', 'c', 'd'))


# Generated at 2022-06-22 21:20:04.475341
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    b = a.difference(['a', 'x'])
    assert b == ImmutableDict({'b': 2, 'c': 3})


# Generated at 2022-06-22 21:20:12.021908
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    a = ImmutableDict()
    b = ImmutableDict()
    c = ImmutableDict({'1': 1, '2': 2, '3': 3})
    d = ImmutableDict({'1': 1, '2': 2, '3': 3})
    e = ImmutableDict({'1': 1, '2': 2, '3': 3})
    f = ImmutableDict({'1': 1, '3': 3, '2': 2})
    g = ImmutableDict({'3': 3, '2': 2, '1': 1})

    assert a.__hash__() == b.__hash__()
    assert a.__hash__() != c.__hash__()
    assert c.__hash__() == d.__hash__()
    assert c.__hash__() == e.__hash

# Generated at 2022-06-22 21:20:21.865514
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """Unit test for method difference of class ImmutableDict"""
    test_dict = ImmutableDict(dict(a=1, b=2, c=3, d=4, f=6))
    result1 = test_dict.difference(['a'])
    assert len(result1) == 4
    assert result1['a'] == 1
    assert result1['b'] == 2
    assert result1['c'] == 3
    assert result1['d'] == 4
    assert result1['f'] == 6

    result2 = test_dict.difference(['a', 'b', 'c'])
    assert len(result2) == 2
    assert result2['d'] == 4
    assert result2['f'] == 6



# Generated at 2022-06-22 21:20:29.363909
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    "Compare ImmutableDict objects created from the same dictionary"
    class1 = ImmutableDict({'a': 'A', 'b': 'B', 'c': 'C'})
    class2 = ImmutableDict(class1)
    assert class1 == class2

    "Compare ImmutableDict objects created from different dictionaries"
    class1 = ImmutableDict({'a': 'A', 'b': 'B', 'c': 'C'})
    class2 = ImmutableDict({'a': 'a', 'b': 'b', 'c': 'c'})
    assert not equals(class1, class2)

    "Compare ImmutableDict objects with different keys"
    class1 = ImmutableDict({'a': 'A', 'b': 'B', 'c': 'C'})
    class2 = ImmutableD

# Generated at 2022-06-22 21:20:40.108873
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # ImmutableDict is equal to itself
    d1 = ImmutableDict(x=1, y=2)
    assert d1 == d1

    # ImmutableDict is equal to another ImmutableDict with the same keys and values
    d2 = ImmutableDict(y=2, x=1)
    assert d1 == d2

    # ImmutableDict is not equal to other Mapping types if they have different keys and values
    assert d1 != dict(x=1, y=2)
    assert d1 != {'x': 1, 'y': 2}

    # ImmutableDict is not equal to other Mapping types if they have different keys
    assert d1 != dict(x=1, y=2, z=3)

# Generated at 2022-06-22 21:20:48.165527
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a1 = ImmutableDict(a=1, b=2)
    a2 = dict(a=3, c=1)
    a3 = ImmutableDict(a=3, c=1)
    a4 = ImmutableDict(a=3, c=2)
    a5 = dict(d=5, e=5)
    assert a1.union(a2) == a3
    assert a3.union(a5) == ImmutableDict(a=3, c=1, d=5, e=5)
    assert a3.union(a4) == a4
    assert a1.union(a3) == a3


# Generated at 2022-06-22 21:21:00.040521
# Unit test for function is_iterable
def test_is_iterable():

    # Test logic
    assert is_iterable(None) == False
    assert is_iterable([]) == True
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable((1, 2, 3)) == True
    assert is_iterable({'a': 1}) == True
    assert is_iterable(set([1, 2, 3])) == True
    assert is_iterable(123) == False
    assert is_iterable('abc') == True
    assert is_iterable(u'abc') == True

    # Test boundary cases
    assert is_iterable([[]]) == True
    assert is_iterable([[1, 2, 3]]) == True
    assert is_iterable([[], [0]]) == True
    assert is_iterable({}) == True

# Generated at 2022-06-22 21:21:09.609918
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable(range(5)) == True)
    assert(is_iterable([1,2,3,4]) == True)
    assert(is_iterable({'a':1, 'b':2, 'c':3}) == True)
    assert(is_iterable('abcd') == True)
    assert(is_iterable(bytearray(b'abcd')) == True)
    # None is not an iterable
    assert(is_iterable(None) == False)
    # integers are not iterables
    assert(is_iterable(1) == False)
    assert(is_iterable(1.0) == False)
    # test the include_strings option
    assert(is_iterable('1.0', include_strings=True) == True)


# Generated at 2022-06-22 21:21:21.224414
# Unit test for function is_iterable
def test_is_iterable():
    # A non-iterable thing
    assert not is_iterable(None)

    # A non-iterable thing
    assert not is_iterable(42)

    # Strings are iterable, but not sequence
    assert is_iterable("")
    assert is_iterable("1")
    assert not is_sequence("")
    assert not is_sequence("1")

    # Bytes are iterable, but not sequence by default
    assert is_iterable(b"")
    assert is_iterable(b"12")
    assert not is_sequence(b"")
    assert not is_sequence(b"12")

    # Strings are iterable, and sequence if requested
    assert is_iterable("", include_strings=True)
    assert is_iterable("123", include_strings=True)
    assert is_sequence

# Generated at 2022-06-22 21:21:27.541700
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # The hash of an ImmutableDict is the hash of its frozenset of items.
    # Therefore, the order of items does not matter.
    dict_unsorted = ImmutableDict({'foo': 'bar', 'a': 'b'})
    dict_sorted = ImmutableDict({'a': 'b', 'foo': 'bar'})
    assert hash(dict_unsorted) == hash(dict_sorted)



# Generated at 2022-06-22 21:21:32.944400
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert not is_iterable("test")
    assert not is_iterable(None)
    assert not is_iterable("test", True)
    assert not is_iterable(10)
    assert not is_iterable(["a", "b"], True)


# Generated at 2022-06-22 21:21:42.500694
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1, 'b': 2})
    a_1 = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 4, 'b': 2})
    c = ImmutableDict({'a': 1, 'b': 5})
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert a == a
    assert a == a_1
    assert a == d.difference(['c'])
    assert a == d.union({'c': 3})
    assert a != b
    assert a != c
    assert a != d

# Unit tests for method union of class ImmutableDict

# Generated at 2022-06-22 21:21:45.094170
# Unit test for function is_string
def test_is_string():
    """Test function is_string."""
    assert is_string('a')
    assert not is_string(['a'])



# Generated at 2022-06-22 21:21:50.082546
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    test_dictionary = ImmutableDict({'key_1': 'value_1', 'key_2': 'value_2'})
    assert test_dictionary['key_1'] == 'value_1'
    assert test_dictionary['key_2'] == 'value_2'


# Generated at 2022-06-22 21:21:59.451104
# Unit test for function is_iterable
def test_is_iterable():
    # Strings are not iterable since they are a sequence in python
    assert is_string('test')
    assert not is_iterable('test')
    assert is_sequence('test')

    # Bytes are not iterable since they are a sequence in python
    assert is_string(b'bytes_data')
    assert not is_iterable(b'bytes_data')
    assert is_sequence(b'bytes_data')

    # Strings are iterable if include_strings flag is passed
    assert is_string('test')
    assert is_iterable('test', include_strings=True)
    assert is_sequence('test', include_strings=True)

    # Bytes are iterable if include_strings flag is passed
    assert is_string(b'bytes_data')

# Generated at 2022-06-22 21:22:08.405256
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d2 = d1.difference(['a'])
    d3 = d1.difference({'a': 1, 'b': 2})
    d4 = d1.difference(['a', 'b', 'c', 'd'])
    d5 = d1.difference({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    d6 = d1.difference({})
    d7 = d1.difference(d1)

    assert d2 == ImmutableDict({'b': 2, 'c': 3})
    assert d3 == ImmutableDict({'c': 3})
    assert d4 == ImmutableDict({})
    assert d5 == ImmutableD

# Generated at 2022-06-22 21:22:12.737460
# Unit test for function count
def test_count():
    seq = [1, 2, 3, 1, 12, 2, 1, 1, 3, 5, 1, 2, 12, 2]
    counters = count(seq)
    expected = {1: 5, 2: 4, 3: 2, 5: 1, 12: 2}
    assert(counters == expected)



# Generated at 2022-06-22 21:22:19.155583
# Unit test for function is_string
def test_is_string():
    assert is_string(u'foo')
    assert is_string('foo')

    # No such thing as bytes on Py2
    # assert is_string(b'foo')
    assert not is_string(['foo'])
    assert not is_string(('foo',))
    assert not is_string({'foo': 'bar'})
    assert not is_string(3)
    assert not is_string(Exception('foo'))
    assert not is_string(True)

    class Foo:
        pass
    assert not is_string(Foo())



# Generated at 2022-06-22 21:22:22.835463
# Unit test for function count
def test_count():
    seq = [1, 2, 3, 1, 2, 4, 1, 2, 5, 2]
    result = count(seq)
    assert result == {1: 3, 2: 4, 3: 1, 4: 1, 5: 1}



# Generated at 2022-06-22 21:22:24.207398
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():

    d = ImmutableDict([(1, 2)])
    assert len(d) == 1



# Generated at 2022-06-22 21:22:32.716479
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    base_dict = ImmutableDict({'a': 'b', 'c': 'd'})
    assert base_dict == ImmutableDict({'a': 'b', 'c': 'd'})
    assert base_dict.union({'e': 'f'}) == ImmutableDict({'a': 'b', 'c': 'd', 'e': 'f'})
    assert base_dict.union({'a': 'g'}) == ImmutableDict({'a': 'g', 'c': 'd'})
    assert base_dict.union(ImmutableDict({'e': 'f'})) == ImmutableDict({'a': 'b', 'c': 'd', 'e': 'f'})

# Generated at 2022-06-22 21:22:43.406658
# Unit test for function is_iterable
def test_is_iterable():
    # Test that string-like objects are not considered iterable
    assert is_iterable(u'foo') is False, 'string-like objects are not iterable'
    assert is_iterable(b'foo') is False, 'bytes-like objects are not iterable'
    assert is_iterable('foo') is False, 'string-like objects are not iterable'
    assert is_iterable(u'foo'.encode()) is False, 'bytes-like objects are not iterable'

    # Test that strings are iterable if specified in the argument
    assert is_iterable(u'foo', include_strings=True) is True, 'string-like objects are iterable'
    assert is_iterable(b'foo', include_strings=True) is True, 'bytes-like objects are iterable'

# Generated at 2022-06-22 21:22:46.772099
# Unit test for function is_string
def test_is_string():
    assert is_string("a") is True
    assert is_string(b"a") is True
    assert is_string(u"a") is True
    assert is_string(1) is False
    assert is_string([]) is False
    assert is_string(dict()) is False

# Generated at 2022-06-22 21:22:49.993320
# Unit test for function count
def test_count():
    assert count(['foo', 'bar', 'foo']) == {'foo': 2, 'bar': 1}
    assert count('foobar') == {'foo': 2, 'bar': 1}
    assert count((1, 2, 2, 1)) == {1: 2, 2: 2}



# Generated at 2022-06-22 21:22:53.264742
# Unit test for function count
def test_count():
    c = count([1, 1, 2, 3, 5])
    assert c == {1: 2, 2: 1, 3: 1, 5: 1}



# Generated at 2022-06-22 21:23:00.180988
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(10))
    assert not is_iterable(1)
    assert not is_iterable(True)
    assert not is_iterable(None)



# Generated at 2022-06-22 21:23:07.067846
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    d1 = ImmutableDict(a='a')
    d2 = ImmutableDict(b='b')
    assert d1 != d2
    assert d1.union(d2) == ImmutableDict(a='a', b='b')
    assert d1.union(d2) != d1
    assert d1.difference(d2) == ImmutableDict(a='a')
    assert d1.difference(d2) != d1

# Generated at 2022-06-22 21:23:16.923746
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    if hash(ImmutableDict({})) != hash(ImmutableDict({})):
        module.fail_json(msg="Empty dictionaries are not equal")

    if hash(ImmutableDict({1: 1})) != hash(ImmutableDict({1: 1})):
        module.fail_json(msg="Dictionaries with the same key-value pairs are not equal")

    if hash(ImmutableDict({1: 1})) == hash(ImmutableDict({1: 2})):
        module.fail_json(msg="Dictionaries with different key-value pairs are equal")

    if hash(ImmutableDict({1: 1, 2: 2})) == hash(ImmutableDict({1: 1})):
        module

# Generated at 2022-06-22 21:23:19.846102
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    # ImmutableDict is initialized
    immutable_dict = ImmutableDict(one=1, two=2, three=3, four=4)

    # Result
    result = len(immutable_dict)

    # Assertion error
    assert result == 4



# Generated at 2022-06-22 21:23:22.434408
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert len(dict1) == 3



# Generated at 2022-06-22 21:23:27.429757
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """
    Test of method __hash__ in class ImmutableDict
    """
    id1 = ImmutableDict({'a' : 1, 'b' : 2, 'c' : 3})
    id2 = ImmutableDict({'c' : 3, 'a' : 1, 'b' : 2})

    assert (hash(id1) == hash(id2))


# Generated at 2022-06-22 21:23:30.042025
# Unit test for function count
def test_count():
    assert count(range(10)) == {x: 1 for x in range(10)}
    assert count([1, 1, 1, 2, 2, 2, 3, 3, 3, 3]) == {1: 3, 2: 3, 3: 4}



# Generated at 2022-06-22 21:23:35.694826
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original_dict = {'a': 'a', 'b': 'b', 'c': 'c'}
    immutable_dict = ImmutableDict(original_dict)
    diff = immutable_dict.difference(['a', 'c'])

    assert(diff == ImmutableDict({'b': 'b'}))
    assert(diff != ImmutableDict({'b': 'b', 'c': 'c'}))

# Generated at 2022-06-22 21:23:41.912732
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_dict_1 = ImmutableDict()
    test_dict_2 = ImmutableDict()
    assert test_dict_1 == test_dict_2
    test_dict_3 = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict_3 == test_dict_3
    assert test_dict_3 != dict({'a': 1, 'b': 2})


# Generated at 2022-06-22 21:23:45.190690
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    """
    Verify that a key can be accessed successfully
    """
    data = ImmutableDict({"key_one": "value_one", "key_two": "value_two"})
    assert data["key_one"] == "value_one"


# Generated at 2022-06-22 21:23:48.159983
# Unit test for function count
def test_count():
    assert count(['a', 'b', 'c', 'a', 'c', 'd', 'a']) == dict(a=3, b=1, c=2, d=1)



# Generated at 2022-06-22 21:23:58.205824
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """ImmutableDict constructor test"""
    # initialize with *args
    immutable_dict = ImmutableDict({"foo": "bar", "baz": "qux"}, foo="new foo", bar="new bar")
    assert immutable_dict == {"foo": "new foo", "baz": "qux", "bar": "new bar"}
    # initialize with **kwargs
    immutable_dict = ImmutableDict(foo="bar", baz="qux")
    assert bool(immutable_dict == {"foo": "bar", "baz": "qux"})
    # test that it's immutable
    try:
        immutable_dict["spam"] = "eggs"
    except TypeError:
        assert True
    else:
        assert False, "ImmutableDict allowed modification by assignment"

# Generated at 2022-06-22 21:24:00.467303
# Unit test for function count
def test_count():
    assert count([1,1,2,2,2,3,3,3,3]) == {1: 2, 2: 3, 3: 4}

# Generated at 2022-06-22 21:24:06.748226
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    idict = ImmutableDict()
    i = 0
    for elem in idict:
        i += 1
    assert i == 0
    idict = ImmutableDict(a=1,b=2)
    i = 0
    for elem in idict:
        i += 1
    assert i == 2


# Generated at 2022-06-22 21:24:11.102453
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict([("a", 1), ("b", 2), ("c", 3)])
    d2 = ImmutableDict([("a", 1), ("b", 2), ("c", 3)])
    assert d1 == d2
    assert d2 == d1


# Generated at 2022-06-22 21:24:19.712699
# Unit test for function is_string
def test_is_string():
    assert is_string('str')
    assert is_string(u'unicode string')
    assert is_string(b'bytes string')
    assert is_string(b'bytes string'.decode('ascii'))
    assert is_string(u'unicode string'.encode('ascii'))
    assert is_string(u'unicode string'.encode('utf-8'))
    assert is_string(u'unicode string'.encode('utf-16'))

    assert not is_string(1)
    assert not is_string(1.0)
    assert not is_string([])
    assert not is_string({})



# Generated at 2022-06-22 21:24:25.133133
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    s = ImmutableDict({1: "a", 2: "b", 3: "c"})
    # print(s)
    # should display ImmutableDict({1: "a", 2: "b", 3: "c"})
    assert str(s) == 'ImmutableDict({1: "a", 2: "b", 3: "c"})'



# Generated at 2022-06-22 21:24:31.956178
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    class NonHashable(object):
        def __eq__(self, other):
            return True

        def __ne__(self, other):
            return False

    # A Hashable class, but does not hash itself
    class DontHashMe(object):
        def __eq__(self, other):
            return True

        def __ne__(self, other):
            return False

        def __hash__(self):
            raise TypeError("Cannot hash")

    # A Hashable class that DOES hash itself
    class HashMe(object):
        def __eq__(self, other):
            return True

        def __ne__(self, other):
            return False

        def __hash__(self):
            return 12345

    # Creating an ImmutableDict of one item (key-value) pair,
    # where both the key

# Generated at 2022-06-22 21:24:37.096956
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    s1 = ImmutableDict({'a': 1, 'b': 2})
    s2 = ImmutableDict({'a': 1, 'b': 2})
    s3 = ImmutableDict({'a': 1, 'b': 3})

    assert s1 == s2
    assert s1 != s3


# Generated at 2022-06-22 21:24:39.654189
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert is_string(b'str')
    assert not is_string(['foo'])
    assert not is_string(['foo', 'bar'])
    assert not is_string((seq for seq in range(3)))



# Generated at 2022-06-22 21:24:43.218455
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable({1, 2, 3, 2})
    assert is_iterable({'a': 'b', 'c': 'd'})
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(0, 3))
    assert not is_iterable(1)
    assert not is_iterable('a')
    assert not is_iterable(None)


# Generated at 2022-06-22 21:24:55.993379
# Unit test for function is_string
def test_is_string():
    from ansible.module_utils._text import to_text
    assert is_string(u'abc')
    assert is_string(to_text('abc'))
    assert is_string(u'廿十')
    assert is_string(to_text('廿十'))
    assert is_string(u'\uD852\uDF62')
    assert is_string(to_text('\uD852\uDF62'))
    assert not is_string(object())
    assert not is_string([[u'abc'], [u'廿十'], [u'\uD852\uDF62']])
    assert not is_string((u'abc', u'廿十', u'\uD852\uDF62'))

# Generated at 2022-06-22 21:25:04.759340
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d = ImmutableDict(a=1, b=2, c=3)
    assert d.difference('a') == ImmutableDict(b=2, c=3)
    assert d.difference(('b', 'c')) == ImmutableDict(a=1)
    assert d.difference(['b']) == ImmutableDict(a=1, c=3)
    assert d.difference({'c': 'foo'}) == ImmutableDict(a=1, b=2)
    assert d.difference(frozenset(('a', 'c'))) == ImmutableDict(b=2)
    assert d.difference(ImmutableDict(a=1, c=3)) == ImmutableDict(b=2)



# Generated at 2022-06-22 21:25:12.460239
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    """
    Testing union method of ImmutableDict class
    """
    orig = ImmutableDict(a='original', b='original', c='original')

    assert orig.union(dict(a='original', b='replaced', c='original', d='added')) == ImmutableDict(a='original', b='replaced', c='original', d='added')

    assert orig.union(dict(a='original', b='replaced', c='original', d='added', orig=orig)) == ImmutableDict(a='original', b='replaced', c='original', d='added', orig=orig)



# Generated at 2022-06-22 21:25:20.803267
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    dict_obj = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    immutable_dict_obj = ImmutableDict()
    try:
        immutable_dict_obj['a']
        raise Exception('Expected keyError not thrown when accessing nonexistent key in ImmutableDict')
    except KeyError as e:
        pass

    immutable_dict_obj = ImmutableDict(dict_obj)
    for key, value in dict_obj.items():
        assert immutable_dict_obj[key] == value

test_ImmutableDict___getitem__()



# Generated at 2022-06-22 21:25:26.690624
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    """
    Test that the __getitem__ method following dictionary access
    """
    dict_in = {"name": "Ansible", "platform": "open source"}
    dict_out = ImmutableDict(dict_in)
    assert dict_out["name"] == "Ansible" and dict_out["platform"] == "open source"

# Generated at 2022-06-22 21:25:37.412654
# Unit test for function count
def test_count():
    assert count([1, 1, 2, 2, 3, 3]) == {1: 2, 2: 2, 3: 2}
    assert count([1, 1, 2, 2, 3, 3, 1, 1, 2, 2, 3, 3]) == {1: 4, 2: 4, 3: 4}
    assert count([1, 2, 3, 3, 3, 4, 5]) == {1: 1, 2: 1, 3: 3, 4: 1, 5: 1}
    assert count([1]) == {1: 1}
    assert count([]) == {}
    assert count('test') == {'t': 2, 'e': 1, 's': 1}



# Generated at 2022-06-22 21:25:44.610918
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    immutable_dict = ImmutableDict(dict(a='a', b='b', c='c'))
    # The key-value pairs are returned in an arbitrary, but consistent order
    assert sorted(immutable_dict.items()) == [('a', 'a'), ('b', 'b'), ('c', 'c')]
    # The iterable needs to be converted to list, otherwise the test will have a side effect
    assert len(list(immutable_dict.__iter__())) == 3


# Generated at 2022-06-22 21:25:56.440221
# Unit test for function count
def test_count():
    """Test function count"""
    assert count([]) == {}
    assert count([1, 2, 3, 1]) == {1: 2, 2: 1, 3: 1}
    assert count([1, 2, 2, 3, 2, 1, 2, 1, 2, 2, 2, 1]) == {1: 4, 2: 7, 3: 1}
    assert count(tuple()) == {}
    assert count((1, 2, 3, 1)) == {1: 2, 2: 1, 3: 1}
    assert count((1, 2, 2, 3, 2, 1, 2, 1, 2, 2, 2, 1)) == {1: 4, 2: 7, 3: 1}
    assert count(set()) == {}

# Generated at 2022-06-22 21:26:02.889220
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    dictionary = {"item1": 1, "item2": 2, "item3": 3}
    immutable_dict = ImmutableDict(dictionary)
    immutable_dict_union = immutable_dict.union({"item1": 10})
    assert immutable_dict_union == ImmutableDict({"item1": 10, "item2": 2, "item3": 3})
    assert immutable_dict_union != immutable_dict


# Generated at 2022-06-22 21:26:07.479403
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    repr_str = repr({'one': 1, 'two': 2})
    assert repr(ImmutableDict({'one': 1, 'two': 2})) == 'ImmutableDict({0})'.format(repr_str)


# Generated at 2022-06-22 21:26:18.606422
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    from ansible.module_utils.common._collections_compat import Mapping
    my_dict = ImmutableDict({'var1': 'value1', 'var2': 'value2'})
    overriding_mapping = {'var1': 'new_value1', 'var3': 'value3'}
    assert isinstance(overriding_mapping, Mapping), 'variable is not a Mapping'

    new_dict = my_dict.union(overriding_mapping)

    assert isinstance(new_dict, Mapping), 'variable is not a Mapping'
    assert isinstance(new_dict, ImmutableDict), 'variable is not an ImmutableDict'

# Generated at 2022-06-22 21:26:26.194430
# Unit test for function is_iterable
def test_is_iterable():
    iterable = (1, 2, 3)
    non_iterable = 3

    assert is_iterable(iterable) == True
    assert is_iterable(non_iterable) == False

    assert is_iterable(iterable, include_strings=True) == True
    assert is_iterable(non_iterable, include_strings=True) == False

    assert is_iterable('something') == False
    assert is_iterable('something', include_strings=True) == True



# Generated at 2022-06-22 21:26:35.781261
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import copy

    class TestImmutableDictDifference(unittest.TestCase):
        """Verify ImmutableDict.difference() returns expected results"""

        def test_return_type(self):
            """ImmutableDict.difference() should return an ImmutableDict"""
            test_dict = ImmutableDict(one=1, two=2, three=3)
            self.assertIs(type(test_dict.difference(['two'])), ImmutableDict)

        def test_remove_one_two(self):
            """ImmutableDict.difference() should remove multiple key/value pairs"""
            test_dict = ImmutableDict(one=1, two=2, three=3)

# Generated at 2022-06-22 21:26:41.684800
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Make sure method __repr__ returns the same representation as that of the builtin dict
    """
    obj_dict = {'a': 'A', 'b': 'B', 1: 2, 'c': 'C'}
    obj_immutabledict = ImmutableDict(obj_dict)

    assert obj_immutabledict.__repr__() == obj_dict.__repr__()


# Generated at 2022-06-22 21:26:47.025231
# Unit test for function is_iterable
def test_is_iterable():
    class MyClass(object):
        def __iter__(self):
            return iter([])

    class MyOtherClass(object):
        pass

    assert is_iterable([])
    assert is_iterable((x for x in range(1)))
    assert is_iterable(MyClass())
    assert is_iterable({})
    assert is_iterable(set())
    assert not is_iterable(0)
    assert not is_iterable(None)
    assert not is_iterable(MyOtherClass())



# Generated at 2022-06-22 21:26:49.400653
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict({'a': 1, 'b': 2})) == 2


# Generated at 2022-06-22 21:26:59.995599
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    d = ImmutableDict(foo='bar')
    assert d['foo'] == 'bar'

    d = ImmutableDict(d, baz='buzz')
    assert d['baz'] == 'buzz'

    assert d == d.union(dict(d))
    assert d == d.union(d)

    assert d != d.union(dict(foo='new'))
    assert d != d.union(foo='new')
    assert d != d.union(ImmutableDict(foo='new'))

    assert d.difference('baz') != d
    assert d.difference('baz') == d.union(foo='bar')

# Generated at 2022-06-22 21:27:04.555836
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    assert ImmutableDict({'a': 1, 'b': 2}).union({'b': 3, 'c': 4}) == ImmutableDict({'a': 1, 'b': 3, 'c': 4})

# Generated at 2022-06-22 21:27:09.719305
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Tests constructor ImmutableDict"""
    with pytest.raises(TypeError):
        ImmutableDict("dict")
    with pytest.raises(TypeError):
        ImmutableDict("dict", "dict")
    with pytest.raises(TypeError):
        ImmutableDict(("dict", "dict"))



# Generated at 2022-06-22 21:27:17.739873
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable([1, 2]) is True
    # assert is_iterable({}) is True
    assert is_iterable({1, 2}) is True
    assert is_iterable((1, 2)) is True
    assert is_iterable(set([1, 2])) is True
    assert is_iterable(set([1, 2])) is True
    assert is_iterable('abc') is False
    assert is_iterable(u'abc') is False



# Generated at 2022-06-22 21:27:29.894025
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # Test with dictionary as input argument
    assert ImmutableDict({'a': 1, 'b': 2}).difference({'a': 3}) == ImmutableDict({'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}).difference({'a': 3, 'c': 4}) == ImmutableDict({'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}).difference({'c': 4}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}).difference({}) == ImmutableDict({'a': 1, 'b': 2})
    # Test with list as input argument

# Generated at 2022-06-22 21:27:39.570890
# Unit test for function is_sequence
def test_is_sequence():
    def check(seq, include_strings=False):
        v = is_sequence(seq, include_strings=include_strings)
        if v:
            print('%s  is a sequence' % seq)
        else:
            print('%s is NOT a sequence' % seq)
        return v

    assert check('foo') is False
    assert check(u'foo') is False
    assert check('foo', include_strings=True) is True
    assert check(u'foo', include_strings=True) is True

    assert check([1, 2, 3]) is True
    assert check((1, 2, 3)) is True
    assert check([1, 2, 3], include_strings=True) is True
    assert check((1, 2, 3), include_strings=True) is True

    assert check([[1], 2, 3])

# Generated at 2022-06-22 21:27:42.537600
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    dictionary_to_test = ImmutableDict({'a': 1, 'b': 2})
    return dictionary_to_test.__repr__()


# Generated at 2022-06-22 21:27:47.974523
# Unit test for function is_iterable
def test_is_iterable():
    from ansible.module_utils.six import string_types
    pass_list = list()
    pass_dict = dict()
    pass_set = set()
    fail_int = 1
    fail_string = 'ansible'
    fail_unicode = u'ansible'
    fail_bytes = b'ansible'
    fail_text = 'unicode'.encode('utf-8')
    fail_nostring_unicode = string_types[0]()
    fail_nostring_bytes = string_types[1]()

    assert is_iterable(pass_list)
    assert is_iterable(pass_dict)
    assert is_iterable(pass_set)
    assert not is_iterable(fail_int)
    assert not is_iterable(fail_string)
    assert not is_iter

# Generated at 2022-06-22 21:27:50.364404
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    original = ImmutableDict({"foo": "bar"})
    assert original == ImmutableDict(foo="bar")


# Generated at 2022-06-22 21:28:00.481679
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    from ansible.module_utils.six import PY3
    from itertools import product

    immutable = ImmutableDict(a=1, b=2, c=3)

    # Verify that equal ImmutableDict objects have the same hash
    # Verify that ImmutableDict with the same content has the same hash, regardless
    # of the order of items
    for ordering in (('a', 'b', 'c'), ('c', 'a', 'b'), ('a', 'c', 'b')):
        test_immutable_dict = ImmutableDict()
        for key in ordering:
            test_immutable_dict[key] = immutable[key]
        assert hash(immutable) == hash(test_immutable_dict)

    # Verify that hash of ImmutableDict with different content is different

# Generated at 2022-06-22 21:28:08.353909
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():

    class ImmutableDict_test(ImmutableDict):
        pass

    assert isinstance(ImmutableDict(), Hashable)
    assert isinstance(ImmutableDict_test(), Hashable)

    assert hash(ImmutableDict({1: 1})) == hash({1: 1})
    assert hash(ImmutableDict_test({1: 1})) == hash({1: 1})



# Generated at 2022-06-22 21:28:15.833040
# Unit test for function is_string
def test_is_string():
    from ansible.module_utils.common._collections_compat import Mapping
    assert is_string("abc")
    assert is_string(u"abc")
    assert is_string("abc".encode('utf-8'))
    assert is_string("abc".encode('base64'))
    assert not is_string(Mapping())
    assert not is_string(object())


# Generated at 2022-06-22 21:28:25.028368
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # Test 1 - test that method __hash__ returns the same hash value
    # for the same keys if they are passed as strings, ints or bools
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_dict_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_dict_2 = ImmutableDict(a=1, b=2, c=3)
    assert test_dict_1.__hash__() == test_dict_2.__hash__()

    # Test 2 - test that method __hash__ returns different hash for
    # different order of keys
    test_dict_3 = ImmutableDict({'c': 3, 'b': 2, 'a': 1})

# Generated at 2022-06-22 21:28:29.123688
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3, 4])
    assert not is_sequence(1)
    assert not is_sequence([1, 2, 3, 4], include_strings=True)
    assert not is_sequence('string')



# Generated at 2022-06-22 21:28:32.972422
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    dict_ = {'a': 'A', 'b': 'B', 'c': 'C'}
    original = ImmutableDict(dict_)
    result = original.difference(['b', 'c'])
    assert result == {'a': 'A'}

# Generated at 2022-06-22 21:28:45.210857
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():

    assert(hash(ImmutableDict({'a': 1})) == hash(ImmutableDict({'a': 1})))

    assert(hash(ImmutableDict({'a': 1})) != hash(ImmutableDict({'b': 1})))
    assert(hash(ImmutableDict({'a': 1})) != hash(ImmutableDict({'a': 2})))
    assert(hash(ImmutableDict({'a': 1})) != hash(ImmutableDict({'b': 1, 'a': 1})))

    # comparing dictionaries where keys are ImmutableDicts
    assert(hash(ImmutableDict({'a': 1})) != hash(ImmutableDict({ImmutableDict({'a': 1}): 1})))

    # comparing dictionaries where keys are lists

# Generated at 2022-06-22 21:28:49.018207
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    test_dict = ImmutableDict({'key3': [3, 4], 'key1': 1, 'key2': 2})
    assert len(test_dict) == 3


# Generated at 2022-06-22 21:28:55.632834
# Unit test for function count
def test_count():
    string = 'aabbcc'
    seq = [1, 1, 2, 2, 3, 3]
    mapping = {'a': 1, 'b': 2}

    assert count(string) == {'a': 2, 'b': 2, 'c': 2}
    assert count(seq) == {1: 2, 2: 2, 3: 2}
    assert count(mapping) == {'a': 1, 'b': 2}
    assert count(None) is None



# Generated at 2022-06-22 21:28:59.316613
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict(a=1, b=2)

    assert repr(d) == 'ImmutableDict({\'a\': 1, \'b\': 2})'


# Generated at 2022-06-22 21:29:07.695315
# Unit test for function is_sequence
def test_is_sequence():
    """Unit test for function is_sequence."""
    assert is_sequence([])
    assert is_sequence([1])
    assert is_sequence([1, 2, 3])
    assert not is_sequence(None)
    assert not is_sequence({})
    assert not is_sequence(u'a')
    assert not is_sequence('a') or is_sequence('a', True)
    assert not is_sequence(1)
    assert not is_sequence(1.2)
    assert not is_sequence((1, 2))
    assert not is_sequence((1,))


# Generated at 2022-06-22 21:29:11.013758
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict(a=1, b=2)
    b = ImmutableDict(a=2, b=3)
    c = ImmutableDict()

    assert(not a == b)
    assert(a == a)
    c == c

# Generated at 2022-06-22 21:29:20.941047
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    x = ImmutableDict({'a': 1, 'b': 2, 'c': 3})

    assert (x.difference({'a', 'c'}) == ImmutableDict({'b': 2}))
    assert (x.difference({'a': 1, 'b': 2}) == ImmutableDict({'c': 3}))
    assert (x.difference(['a', 'c']) == ImmutableDict({'b': 2}))
    assert (x.difference(('a', 'c')) == ImmutableDict({'b': 2}))
    assert (x.difference(ImmutableDict({'a': 1, 'c': 3})) == ImmutableDict({'b': 2}))



# Generated at 2022-06-22 21:29:26.837897
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    result = ImmutableDict(a=1, b=2).__repr__()
    expected_result = 'ImmutableDict({0})'.format('{' + "'a': 1, 'b': 2" + '}')
    assert result == expected_result, 'Incorrect __repr__ result'


# Generated at 2022-06-22 21:29:37.914137
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 'b'}) == ImmutableDict({'a': 'b'})
    assert ImmutableDict({'a': 'b'}) == {'a': 'b'}
    assert ImmutableDict({'a': 'b'}) != {'a': 'a'}
    assert ImmutableDict({'a': 'b'}) != ImmutableDict({'a': 'a'})
    assert ImmutableDict({'a': 'b'}) != ImmutableDict({'a': 'a', 'b': 'a'})
    assert ImmutableDict({'a': 'b'}) != ImmutableDict({'a': 'b', 'b': 'a'})

# Generated at 2022-06-22 21:29:42.880509
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    """Unit test for method __iter__ of class ImmutableDict"""
    d = ImmutableDict([('key1', 'value1'), ('key2', 'value2')])
    assert all(i in d for i in ['key1', 'key2'])



# Generated at 2022-06-22 21:29:48.232153
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    test_dict = ImmutableDict(a=1, b=2, c=3)
    assert str(test_dict) == 'ImmutableDict({\'c\': 3, \'b\': 2, \'a\': 1})', \
        'Incorrect string representation of ImmutableDict'



# Generated at 2022-06-22 21:29:57.593459
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    immutable_dict = ImmutableDict(test_dict)
    # Test that constructor created a new object that is not a reference to its argument
    test_dict['d'] = 4
    try:
        # The test object has the key 'd' added to it.
        immutable_dict['d']
    except KeyError:
        # If the test object has not been changed as a result of adding 'd' to the original object,
        # this exception should be raised.
        pass
    else:
        # If the test object has been changed, that is unexpected and the test has failed.
        raise AssertionError('Adding a key to the original dictionary changed the ImmutableDict.')
    return True