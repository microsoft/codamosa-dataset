

# Generated at 2022-06-22 21:20:05.973525
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # Create a dictionary
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    # Create a list of keys to remove from dictionary
    l = ['a']
    # Create new dictionary from original minus those keys in 'l'
    i = d.difference(l)
    # Test that original remained as is
    assert d.items() == {'a': 1, 'b': 2, 'c': 3}.items()
    # Test that new dictionary is as expected
    assert i.items() == {'b': 2, 'c': 3}.items()

# Generated at 2022-06-22 21:20:12.843622
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    test_dict = ImmutableDict({'test_key':'test_value'})
    new_test_dict = test_dict.union({'new_test_key':'new_test_value'})
    assert new_test_dict == {'test_key':'test_value', 'new_test_key':'new_test_value'}

    new_test_dict = test_dict.union({'new_test_key':'new_test_value', 'test_key':'new_test_value'})
    assert new_test_dict == {'test_key':'new_test_value', 'new_test_key':'new_test_value'}

    test_dict = ImmutableDict({'test_key':'test_value', 'test_key_2':'test_value_2'})

# Generated at 2022-06-22 21:20:16.541967
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    immutable_dict = ImmutableDict(dict(key1='value1'))
    assert immutable_dict['key1'] == 'value1'


# Generated at 2022-06-22 21:20:20.955101
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert not is_sequence(object())
    assert not is_sequence("123")
    assert is_sequence("123", include_strings=True)

# Generated at 2022-06-22 21:20:26.201074
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(tuple())
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable([])
    assert not is_iterable(dict())
    assert not is_iterable(1)
    assert not is_iterable('test')
    assert not is_iterable(u'test')
    assert not is_iterable(b'test')


# Generated at 2022-06-22 21:20:28.559889
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2



# Generated at 2022-06-22 21:20:32.342345
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert not is_sequence(())
    assert is_sequence([], True)
    assert is_sequence((), True)
    assert is_sequence({})
    assert is_sequence({}, True)


# Generated at 2022-06-22 21:20:39.025694
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    testDict = ImmutableDict(apple='APPLE', lemon='LEMON', orange='ORANGE')
    testDict2 = testDict.difference(['apple', 'orange'])
    assert('apple' not in testDict2)
    assert('orange' not in testDict2)
    assert('apple' in testDict)
    assert('orange' in testDict)
    assert('lemon' in testDict)
    assert('lemon' in testDict2)


# Generated at 2022-06-22 21:20:41.158840
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert repr(d) == "ImmutableDict({'a': 1, 'b': 2, 'c': 3})"


# Generated at 2022-06-22 21:20:45.915728
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict({'a': 1, 'b': 2})
    expected = ImmutableDict({'a': 3, 'b': 2, 'c': 1})
    assert original.union({'a': 3, 'c': 1}) == expected, \
        'ImmutableDict.union does not override key value pairs properly'


# Generated at 2022-06-22 21:20:52.569398
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert is_sequence(set([1, 2, 3]))
    assert not is_sequence(1)
    assert not is_sequence([])
    assert not is_sequence({'a': 1})
    assert is_sequence(('a', 1))
    assert is_sequence(('a', 1), include_strings=True)


# Generated at 2022-06-22 21:20:55.116939
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert len(d) == 3



# Generated at 2022-06-22 21:21:06.120322
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert is_sequence([])
    assert is_sequence(())
    assert is_sequence(set([1, 2, 3]), include_strings=False)
    assert is_sequence("foo", include_strings=False) is False
    assert is_sequence("foo", include_strings=True)
    assert is_sequence(u"foo", include_strings=False) is False
    assert is_sequence(u"foo", include_strings=True)
    assert is_sequence(("foo", "bar"), include_strings=False)
    assert is_sequence(("foo", "bar"), include_strings=True)
    assert is_sequence(("foo", "bar", "foo"), include_strings=True)
    assert is_sequence(("foo", "bar", "foo"), include_strings=False)

# Generated at 2022-06-22 21:21:14.472861
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # Test method __hash__ of class ImmutableDict
    # Arrangement
    dict_1 = ImmutableDict({1:"a", 2:"b", 3:"c"})
    dict_2 = ImmutableDict({1:"a", 2:"b", 3:"c"})
    dict_3 = ImmutableDict({4:"a", 3:"b", 2:"c"}) 
    dict_4 = dict({1:"a", 2:"b", 3:"c"})

    # Act
    hash_1 = hash(dict_1)
    hash_2 = hash(dict_2)
    hash_3 = hash(dict_3)
    hash_4 = hash(dict_4)
    hash_f1 = frozenset(dict_1.items())
    hash_f2 = frozenset(dict_2.items())

# Generated at 2022-06-22 21:21:24.124475
# Unit test for function is_iterable
def test_is_iterable():
    class A():
        pass

    class B(A):
        pass

    class C(object):
        pass

    class D(C):
        pass

    class E(D):
        def __iter__(self):
            return iter(())

    class F(D):
        __iter__ = None

    class G(D):
        class __metaclass__(type):
            __instancecheck__ = None

    class H(D):
        pass

    assert is_iterable(A())
    assert is_iterable(B())
    assert is_iterable(C())
    assert is_iterable(D())
    assert is_iterable(E())
    assert not is_iterable(F())
    assert not is_iterable(G())
    assert not is_iterable(H())
    assert not is_iter

# Generated at 2022-06-22 21:21:30.492993
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable(set([1, 2, 3])) == True
    assert is_iterable(ImmutableDict(foo=1, bar=2)) == True
    assert is_iterable({'foo': 1, 'bar': 2}) == True
    assert is_iterable((1, 2, 3)) == True
    assert is_iterable('123') == False
    assert is_iterable(1) == False



# Generated at 2022-06-22 21:21:34.986796
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert repr(ImmutableDict({'a': 1, 'b': 2})) == 'ImmutableDict({\'a\': 1, \'b\': 2})'



# Generated at 2022-06-22 21:21:46.577960
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Unit tests for hash() method of ImmutableDict"""
    d1 = ImmutableDict({1: 'a', 2: 'b'})
    d2 = ImmutableDict({2: 'b', 1: 'a'})  # keys and values are in different order
    d3 = ImmutableDict({1: 'a', 2: 'b', 3: 'c'})  # d1 plus an extra key
    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})  # d1 plus strings as keys
    d5 = ImmutableDict({3: 'c', 1: 'a', 2: 'b'})  # d1 plus different order
    d6 = ImmutableDict({1: 'a', 2: 'b', 3: 'd'})  # d1 plus different value


# Generated at 2022-06-22 21:21:54.131748
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(list())
    assert is_iterable(set())
    assert is_iterable(tuple())
    assert is_iterable(dict())
    assert is_iterable(set(range(5)))
    assert is_iterable(range(5))
    assert is_iterable('abc')
    assert is_iterable(b'abc')
    assert not is_iterable(1)
    assert not is_iterable(None)



# Generated at 2022-06-22 21:22:02.613487
# Unit test for function is_sequence
def test_is_sequence():
    assert not is_sequence('test')
    assert not is_sequence(b'test')
    assert is_sequence('test', include_strings=True)
    assert is_sequence(b'test', include_strings=True)

    class NotSequence:
        pass

    assert not is_sequence(NotSequence())

    class SequenceWithoutIndex(object):
        def __getitem__(self, item):
            raise TypeError

    assert not is_sequence(SequenceWithoutIndex())



# Generated at 2022-06-22 21:22:04.490634
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    testDict = ImmutableDict(x=1, y=2)
    assert testDict['x'] == 1


# Generated at 2022-06-22 21:22:16.480741
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({"a":1, "b":2})
    b = ImmutableDict({"a":1, "b":2})
    c = ImmutableDict({"b":2, "a":1})
    d = ImmutableDict({"a":1, "b":2, "c":3})
    e = ImmutableDict({"a":1, "c":3})
    f = {"a":1, "b":2}
    g = {"a":1, "b":2, "c":3}
    h = {"a":1, "c":3}
    # test __eq__
    assert a == a
    assert a == b
    assert b == a
    assert a == c
    assert c == a
    assert a != d
    assert d != a
    assert a

# Generated at 2022-06-22 21:22:24.565475
# Unit test for function is_sequence
def test_is_sequence():
    for seq in (None, 'str', b'bytes', u'unicode', bytearray(), set(), frozenset(), dict(), ImmutableDict(), []):
        assert not is_sequence(seq)

    for seq in ([], (), [1, 2], (1, 2), range(10)):
        assert is_sequence(seq)

    for seq in ('str', b'bytes', u'unicode'):
        assert is_sequence(seq, include_strings=True)


# Generated at 2022-06-22 21:22:28.901791
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    dictionary = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert dictionary['key1'] == 'value1'
    assert dictionary['key2'] == 'value2'



# Generated at 2022-06-22 21:22:41.391150
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    dict1 = {'a':1, 'b':2, 'c':3}
    dict2 = {'d':4, 'e':5, 'f':6}
    immutable_dict_1 = ImmutableDict(dict1)
    immutable_dict_2 = ImmutableDict(dict2)
    # Verify no keys are lost when difference of dictionary and empty list occurs.
    assert immutable_dict_1.difference([]) == immutable_dict_1
    assert immutable_dict_2.difference([]) == immutable_dict_2
    # Verify no keys are lost when difference of dictionary and list containing present keys occurs.
    assert immutable_dict_1.difference(dict1.keys()) == ImmutableDict()
    # Verify no keys are lost when difference of dictionary and list containing present keys occurs.
    assert immutable_dict_2.diff

# Generated at 2022-06-22 21:22:50.099587
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    mapping_no_args = ImmutableDict()
    
    mapping_one_arg = ImmutableDict({"key1": "value1"})
    for key, value in mapping_one_arg.items():
        assert key == "key1"
        assert value == "value1"
    
    mapping_two_arg = ImmutableDict({"key1": "value1"}, {"key2": "value2"})
    for key, value in mapping_two_arg.items():
        assert key == "key1" or key == "key2"
        assert value == "value1" or value == "value2"
    
    mapping_args_and_kwargs = ImmutableDict({"key1": "value1"}, key2="value2")

# Generated at 2022-06-22 21:22:56.697234
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.misc.utils import ImmutableDict
    dict_ = ImmutableDict({"a": 1, "b": 2})
    expected_result = "ImmutableDict({'a': 1, 'b': 2})"
    assert repr(dict_) == expected_result, "expected repr(dict_) to be '%s', got '%s'" % (expected_result, repr(dict_))



# Generated at 2022-06-22 21:22:59.893536
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """Test __len__ method."""
    my_dict = ImmutableDict({1: 1, 2: 2, 3: 3})
    assert len(my_dict) == 3


# Generated at 2022-06-22 21:23:09.467978
# Unit test for function is_sequence
def test_is_sequence():
    import sys
    assert is_sequence(range(10)) == True
    assert is_sequence(xrange(10)) == True
    assert is_sequence(('a', 'b', 'c')) == True
    assert is_sequence(list()) == True
    assert is_sequence(set()) == True
    assert is_sequence(dict()) == True
    assert is_sequence('string') == (sys.version_info.major > 2)
    assert is_sequence('string', include_strings=True) == True

    try:
        iter([])  # noqa - not iterable
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-22 21:23:15.584047
# Unit test for function is_string
def test_is_string():
    assert is_string('String')
    assert is_string('\xc3\x84')
    assert is_string(u'String')
    assert is_string(u'\xc4')
    assert is_string(b'String')
    assert is_string(b'\xc4')
    assert is_string(2) == False
    assert is_string(['String']) == False
    assert is_string(('String',)) == False
    assert is_string({'String': 'String'}) == False



# Generated at 2022-06-22 21:23:22.152348
# Unit test for function is_iterable
def test_is_iterable():
    strings = ["a", "bb", "ccc"]
    numbers = [1, 2, 3]
    boolean = [True, True, False]
    empty = []
    not_iterable_string = "abc"
    not_iterable_number = 1

    assert is_iterable(strings)
    assert is_iterable(numbers)
    assert is_iterable(boolean)
    assert is_iterable(empty)
    assert not is_iterable(not_iterable_string)
    assert not is_iterable(not_iterable_number)


# Generated at 2022-06-22 21:23:33.301067
# Unit test for function is_sequence
def test_is_sequence():
    # Test case in which the function is run with include_strings = False
    assert not is_sequence('abc')
    assert not is_sequence(b'abc')
    assert is_sequence(['a', 'b', 'c'])
    assert is_sequence((1, 2, 3))
    assert not is_sequence(None)
    assert not is_sequence(1)
    assert not is_sequence(True)
    assert not is_sequence(dict())
    assert not is_sequence(set())

    # Test case in which the function is run with include_strings = True
    assert is_sequence('abc', True)
    assert is_sequence(b'abc', True)
    assert is_sequence(['a', 'b', 'c'], True)
    assert is_sequence((1, 2, 3), True)
    assert not is_

# Generated at 2022-06-22 21:23:39.111878
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original_dict = ImmutableDict({'key1': 'value1'})
    more_dict = {'key2': 'value2'}
    union_dict = original_dict.union(more_dict)
    assert union_dict['key1'] == 'value1'
    assert union_dict['key2'] == 'value2'



# Generated at 2022-06-22 21:23:42.062304
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict({'a': 1, 'b': 2})
    assert 'a' in d
    assert 'b' in d
    assert 'c' not in d


# Generated at 2022-06-22 21:23:52.781717
# Unit test for function count
def test_count():
    assert count([1, 1, 2, 2, 2, 3]) == {1: 2, 2: 3, 3: 1}
    assert count('abcdabcd') == {'a': 2, 'b': 2, 'c': 2, 'd': 2}
    assert count(['foo', 'bar', 'foo', 'bar']) == {'foo': 2, 'bar': 2}
    assert count(ImmutableDict(foo='bar', bar='foo')) == {'foo': 1, 'bar': 1}
    assert count(ImmutableDict({'foo': 'bar', 'bar': 'foo'})) == {'foo': 1, 'bar': 1}
    assert count('foo') == {'f': 1, 'o': 2}


# Generated at 2022-06-22 21:24:00.711265
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Tests for ImmutableDict
    dict1 = ImmutableDict(a=1, b=2, c=3)
    dict2 = ImmutableDict(a=1, b=2, c=3)
    dict3 = ImmutableDict(a=3, b=2, c=1)
    dict4 = ImmutableDict(a=1, b=2)
    dict5 = dict(a=1, b=2, c=3)
    dict6 = {'a': 1, 'b': 2, 'c': 3}
    assert(dict1 is not dict2)
    assert(dict1 == dict2)
    assert(dict1 != dict3)
    assert(dict1 != dict4)
    assert(dict1 != dict5)
    assert(dict1 != dict6)

# Generated at 2022-06-22 21:24:07.334108
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    diff_dict = test_dict.difference(['a', 'c'])
    assert diff_dict == {'b': 2}
    diff_dict = test_dict.difference([])
    assert diff_dict == test_dict


# Generated at 2022-06-22 21:24:10.916773
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict((('a', 1), ('b', 2), ('c', 3)))) == 3


# Generated at 2022-06-22 21:24:15.517700
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    sample_dict = {'test_key1': 'test_value1', 'test_key2': 'test_value2', 'test_key3': 'test_value3'}
    test = ImmutableDict(sample_dict)

    assert len(test) == len(sample_dict)


# Generated at 2022-06-22 21:24:24.187350
# Unit test for function count
def test_count():
    """ Test count function. """
    assert count([1, 2, 3, 2, 1, 2, 3, 2]) == {1: 2, 2: 4, 3: 2}
    assert count([]) == {}
    assert count(['a', 'b', 'a']) == {'a': 2, 'b': 1}
    assert count(('a', 'b', 'a')) == {'a': 2, 'b': 1}
    assert count({1: 'a', 2: 'b', 3: 'a'}) == {'a': 2, 'b': 1}
    assert count({'a': 1, 'b': 2, 'a': 3}) == {'a': 2, 'b': 1}

# Generated at 2022-06-22 21:24:29.902520
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    mydict = ImmutableDict({"a": 1, "b": 2, "c": 3, "d": 4})
    assert (mydict.get("a") == 1)
    # Test for difference method
    mydict_diff = mydict.difference(["a", "b", "c", "d"])
    assert (mydict_diff.get("a") is None)
    # Test for union method
    mydict_union = mydict.union({"e": 5, "f": 6})
    assert (mydict_union.get("e") == 5)
    assert (mydict_union.get("a") == 1)

# Generated at 2022-06-22 21:24:33.157963
# Unit test for function count
def test_count():
    assert count([1, 2, 1, 2, 1]) == {1: 3, 2: 2}

# Generated at 2022-06-22 21:24:34.958483
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict(a=1, b=2)) == 2
    assert len(ImmutableDict(a=1)) == 1
    assert len(ImmutableDict()) == 0


# Generated at 2022-06-22 21:24:41.856269
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable(()) is True
    assert is_iterable({}) is True
    assert is_iterable(set()) is True
    assert is_iterable((x for x in range(0))) is True
    assert is_iterable(0) is False
    assert is_iterable('') is False
    assert is_iterable(b'') is False
    assert is_iterable(False) is False



# Generated at 2022-06-22 21:24:54.508818
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Test the ImmutableDict class"""
    dct_1 = ImmutableDict()
    assert not dct_1
    assert dct_1 == ImmutableDict({})
    assert len(dct_1) == 0

    dct_2 = ImmutableDict({'a': 1, 'b': 2})
    assert dct_2 == ImmutableDict({'a': 1, 'b': 2})
    assert len(dct_2) == 2
    assert frozenset(dct_2) == frozenset(('a', 'b'))
    assert dct_2['a'] == 1
    assert dct_2['b'] == 2
    assert not dct_2.has_key('c')


# Generated at 2022-06-22 21:25:00.067465
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert not is_sequence((1, 2, 3))
    assert not is_sequence("test")
    assert not is_sequence(set([1, 2, 3]))
    assert is_sequence("test", include_strings=True)
    assert is_sequence(set([1, 2, 3]), include_strings=True)



# Generated at 2022-06-22 21:25:08.446215
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    dict_original = ImmutableDict({'a': 1, 'b': 2, 'c':  3, 'd': 4, 'e': 5})
    remove_keys = ('b', 'c', 'f')
    dict_expected = ImmutableDict({'a': 1, 'd': 4, 'e': 5})
    dict_result = dict_original.difference(remove_keys)
    dict_original_updated = dict_original.difference(remove_keys)
    assert dict_result == dict_expected, 'Difference gives expected result'
    assert dict_original == dict_original_updated, 'Original dict remains unchanged'



# Generated at 2022-06-22 21:25:16.937366
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    after_init = {'a': 1}
    before_init = dict(a=1)
    not_in_dict = {}
    test_dict = ImmutableDict(before_init)
    expected = after_init.get('a')
    actual = test_dict['a']
    assert actual == expected, 'Not equal'
    with pytest.raises(KeyError):
        _ = test_dict.__getitem__('undefined_key')
    assert test_dict.__getitem__('a') == after_init.__getitem__('a')
    with pytest.raises(KeyError):
        _ = not_in_dict.__getitem__('undefined_key')



# Generated at 2022-06-22 21:25:20.046743
# Unit test for function count
def test_count():
    assert count([1, 2, 1, 2, 4, 1, 1, 6, 5, 5, 5]) == {1: 4, 2: 2, 4: 1, 6: 1, 5: 3}



# Generated at 2022-06-22 21:25:23.108204
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    test_dict_obj = ImmutableDict({'a': 1})
    assert iter(test_dict_obj) == iter({'a': 1})


# Generated at 2022-06-22 21:25:25.645066
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    ImmutableDict(dict(a = 1, b = 2, c = 3))


# Generated at 2022-06-22 21:25:29.299078
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'b': 42, 'c': 3})
    c = a.union(b)
    assert c == {'a': 1, 'b': 42, 'c': 3}
    assert a == {'a': 1, 'b': 2}
    assert b == {'b': 42, 'c': 3}


# Generated at 2022-06-22 21:25:41.264240
# Unit test for function is_iterable
def test_is_iterable():
    class A(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
        def __iter__(self):
            for i in self.__dict__:
                yield i
    a = A()
    assert is_iterable(a)
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(tuple())
    assert is_iterable(dict())
    assert is_iterable("string")
    assert is_iterable(b"bytestring")
    assert is_iterable("string".encode("ascii", "ignore"))
    assert is_iterable("string".encode("utf-16", "ignore"))

    assert is_iterable(a, include_strings=True)

# Generated at 2022-06-22 21:25:53.316181
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    test_obj = ImmutableDict({'a': 'A', 'b': 'B'})
    test_obj1 = ImmutableDict({'c': 'C'})
    test_obj2 = ImmutableDict({'d': 'D'})
    test_obj3 = ImmutableDict({'a': 'a'})
    result_obj = test_obj.union(test_obj1)
    result_obj1 = test_obj.union(test_obj2)
    result_obj2 = test_obj.union(test_obj3)
    assert result_obj == {'a': 'A', 'b': 'B', 'c': 'C'}
    assert result_obj1 == {'a': 'A', 'b': 'B', 'd': 'D'}

# Generated at 2022-06-22 21:26:01.334097
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    assert hash(ImmutableDict(foo='bar')) == hash(ImmutableDict(foo='bar'))
    assert hash(ImmutableDict(foo='bar')) != hash(ImmutableDict(foo='buz'))
    assert hash(ImmutableDict(foo='bar')) != hash(ImmutableDict(buz='bar'))
    assert hash(ImmutableDict(foo='bar')) != hash(ImmutableDict(foo='bar', buz='qux'))



# Generated at 2022-06-22 21:26:07.517981
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    overriding_mapping = {'b': 22, 'd': 4}
    expected = ImmutableDict({'a': 1, 'b': 22, 'c': 3, 'd': 4})
    actual = original.union(overriding_mapping)

    assert actual == expected


# Generated at 2022-06-22 21:26:10.822233
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    immutable = ImmutableDict(foo='bar', moo='mar')
    assert len(immutable) == 2

    immutable = ImmutableDict()
    assert len(immutable) == 0


# Generated at 2022-06-22 21:26:16.585968
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d1 = ImmutableDict(a='1', b='2', c='3', d='4', e='5')
    d2 = d1.difference(('b',))
    assert d1 != d2
    assert set(d2.keys()) == set(('a', 'c', 'd', 'e'))
    assert d2['a'] == '1'
    assert d2['c'] == '3'
    assert d2['d'] == '4'
    assert d2['e'] == '5'


# Generated at 2022-06-22 21:26:26.264985
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence(range(10))
    assert is_sequence([])
    assert is_sequence((1, 2, 3))
    assert is_sequence({1: 1, 2: 2, 3: 3})
    assert is_sequence(set([1, 2, 3]))
    assert is_sequence(dict([(1, 1), (2, 2), (3, 3)]))
    assert is_sequence(u'str')
    assert not is_sequence(1)
    assert not is_sequence(True)
    assert not is_sequence(u'str', include_strings=True)



# Generated at 2022-06-22 21:26:29.641866
# Unit test for function is_string
def test_is_string():
    assert is_string('string')
    assert is_string(u'unicode string')
    assert not is_string(b'bytes string')
    assert is_string(set([u'unicode string']))



# Generated at 2022-06-22 21:26:34.519931
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Unit test for method __repr__ of class ImmutableDict."""
    d = ImmutableDict({'1': 'one', '2': 'two', '3': 'three'})
    assert repr(d) == "ImmutableDict({'1': 'one', '2': 'two', '3': 'three'})"



# Generated at 2022-06-22 21:26:36.759717
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    assert list(ImmutableDict({'a': 1, 'b': 2})) == ['a', 'b']

# Generated at 2022-06-22 21:26:39.392257
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    x = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert set(x.__iter__()) == set(['a', 'b', 'c'])


# Generated at 2022-06-22 21:26:44.337575
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    immutable_dict = ImmutableDict({'a':1, 'b':2})

    result = []
    for elem in immutable_dict:
        result.append(elem)

    if result != ['a', 'b']:
        raise Exception('method __iter__ of class ImmutableDict failed')


# Generated at 2022-06-22 21:26:46.681726
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    a = ImmutableDict(a=1, b=2, c=3)
    assert set(a) == set(('a', 'b', 'c'))


# Generated at 2022-06-22 21:26:51.788023
# Unit test for function count
def test_count():
    assert count([1, 2, 1, 1, 2, 5, 4, 1, 2, 5, 5]) == {1: 4, 2: 3, 5: 3, 4: 1}
    try:
        count(1)
        raise Exception('count function did not raise expected exception')
    except Exception:
        pass  # unit test passed
    try:
        count('string')
        raise Exception('count function did not raise expected exception')
    except Exception:
        pass  # unit test passed



# Generated at 2022-06-22 21:26:53.983342
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict({'a':1, 'b':2})
    assert(d.__repr__() == 'ImmutableDict({\'a\': 1, \'b\': 2})')


# Generated at 2022-06-22 21:26:57.087397
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    kwargs = dict(a=1, b=2, c=3)
    test_dict = ImmutableDict(*kwargs)
    assert test_dict['b'] == 2
    assert len(test_dict) == 3



# Generated at 2022-06-22 21:27:02.738329
# Unit test for function is_sequence
def test_is_sequence():
    s = 'abcdefg'
    l = [1, 2, 3, 4]
    t = (1, 2, 3, 4)
    assert is_sequence(s) is False
    assert is_sequence(l) is True
    assert is_sequence(t) is True
    assert is_sequence(s, True) is True
    assert is_sequence(l, True) is True
    assert is_sequence(t, True) is True

# Generated at 2022-06-22 21:27:12.044671
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    test_dict = ImmutableDict( {'a': 1, 'b': 2} )
    assert test_dict == ImmutableDict( {'a': 1, 'b': 2} )
    assert test_dict != ImmutableDict( {'c': 1, 'd': 2} )
    assert test_dict != {'a': 1, 'b': 2}
    assert test_dict.union({'a': 2, 'c': 3}) == ImmutableDict( {'a': 2, 'b': 2, 'c': 3} )
    assert test_dict.difference(['a']) == ImmutableDict( {'b': 2} )

# Generated at 2022-06-22 21:27:23.932048
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test key and value comparison
    mydict1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    mydict2 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert mydict1 == mydict2

    mydict1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    mydict2 = ImmutableDict({'key1': 'value1', 'key2': 'value3'})
    assert not mydict1 == mydict2

    mydict1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    mydict2 = ImmutableDict({'key1': 'value1', 'key3': 'value2'})

# Generated at 2022-06-22 21:27:29.642630
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    # Create a dummy dictionary for testing
    test_dict = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    # Create an ImmutableDict instance and access its value by index
    immutable_dict = ImmutableDict(test_dict)
    assert immutable_dict['key1'] == 'value1'
    assert immutable_dict['key2'] == 'value2'
    assert immutable_dict['key3'] == 'value3'


# Generated at 2022-06-22 21:27:34.020887
# Unit test for function is_string
def test_is_string():
    assert is_string('teststring')
    assert is_string(u'teststring')
    assert is_string(b'teststring')
    assert is_string('teststring'.encode('utf-8'))
    assert not is_string([1])
    assert not is_string(1)


# Generated at 2022-06-22 21:27:38.273211
# Unit test for function is_sequence
def test_is_sequence():
    # list, tuple, set and frozenset are sequences
    for seq_type in [list, tuple, set, frozenset]:
        assert is_sequence(seq_type())

    # str and bytes are not sequences
    assert not is_sequence(str())
    assert not is_sequence(bytes())

    # str and bytes are sequences if explicitly specified
    assert is_sequence(str(), include_strings=True)
    assert is_sequence(bytes(), include_strings=True)
    # Non-indexable things are not sequences
    assert not is_sequence(None)
    assert not is_sequence(0)
    assert not is_sequence({})


# Generated at 2022-06-22 21:27:42.588884
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    original = ImmutableDict({'a': 1})
    assert original == {'a': 1}
    assert original != {'a': 1, 'b': 2}
    assert original != ['a', 'b']


# Generated at 2022-06-22 21:27:54.585523
# Unit test for function is_sequence
def test_is_sequence():
    # Regular cases
    assert is_sequence([])
    assert is_sequence([1, 2, 3])
    assert is_sequence(set())
    assert is_sequence(tuple())
    assert is_sequence(range(0))

    # Strings and bytes
    assert not is_sequence('')
    assert not is_sequence('abc')
    assert not is_sequence(b'abc\xe9')  # UTF-8 string b'abc\xc3\xa9'

    # Non-indexable things
    assert not is_sequence(set([1, 2, 3]))
    assert not is_sequence({'a': 1, 'b': 2})
    assert not is_sequence(123)
    assert not is_sequence(lambda x: x)

    # Include strings
    assert is_sequence('', include_strings=True)


# Generated at 2022-06-22 21:28:00.787731
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d1 = ImmutableDict(
        {'a': 'b',
         'c': 'd',
         'e': 'f',
         'g': 'h'})
    d2 = d1.difference({'a', 'c'})
    d3 = d1.difference(('a', 'c'))
    if d1 != d2:
        raise Exception('d1 and d2 are not equal')
    if d1 == d3:
        raise Exception('d1 and d3 are equal')

# Generated at 2022-06-22 21:28:13.363179
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(1)
    assert not is_iterable(True)
    assert not is_iterable(None)
    assert not is_iterable(object())
    assert not is_iterable(set())
    assert not is_iterable(0.1)
    assert is_iterable(is_iterable)
    assert is_iterable([1, 2])
    assert is_iterable(['a', 0, 1])
    assert is_iterable(('a', 1, True))
    assert is_iterable({'a': 0, 1: True})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(2))
    assert is_iterable("abcd")
    assert is_iterable(u"abcd")
    assert is_iterable

# Generated at 2022-06-22 21:28:20.971810
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    id1 = ImmutableDict({"a":1})
    id2 = ImmutableDict({"a":1})
    id3 = ImmutableDict({"a":1, "b":2})
    id4 = ImmutableDict({"a":1, "b":2})

    assert id1 == id2
    assert id1 != id3
    assert id3 == id4

    assert id1 != {"a": 1}
    assert id1 != {"a": 2}


# Generated at 2022-06-22 21:28:26.868700
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    # Testing correct creation of ImmutableDict
    # ImmutableDict's constructor can be called in two ways
    # 1) With a positional argument being a dict
    # 2) With named arguments being key value pairs
    dict_pos = dict(a=1, b=2, c=3)
    dict_named = ImmutableDict(a=1, b=2, c=3)
    test_dict_pos = ImmutableDict(dict_pos)
    assert len(test_dict_pos) == len(dict_pos)
    assert all(test_dict_pos[key] == value for key, value in dict_pos.items())
    assert test_dict_pos == dict_named
    assert len(test_dict_pos) == len(dict_named)

# Generated at 2022-06-22 21:28:34.455283
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    d = ImmutableDict(a=1, b=2)

    assert d.union(dict(b=3, c=4)) == ImmutableDict(a=1, b=3, c=4)
    assert d.union(c=4, b=3) == ImmutableDict(a=1, b=3, c=4)
    assert d.union(ImmutableDict(b=3, c=4)) == ImmutableDict(a=1, b=3, c=4)



# Generated at 2022-06-22 21:28:40.476888
# Unit test for function count
def test_count():
    test_list = ['a', 'a', 'b', 'c', 'c', 'a']
    test_dict = count(test_list)
    assert test_dict['a'] == 3
    assert test_dict['b'] == 1
    assert test_dict['c'] == 2
    assert not test_dict.get('d', False)
    assert 'a' in test_dict
    assert 'd' not in test_dict



# Generated at 2022-06-22 21:28:43.312014
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    testcase = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    for k in testcase:
        assert k

# Generated at 2022-06-22 21:28:55.377779
# Unit test for function is_sequence
def test_is_sequence():
    from ansible.module_utils.six import string_types, binary_type

    assert not is_sequence(None)
    assert not is_sequence('')
    assert not is_sequence('foo')
    assert not is_sequence(b'foo')
    assert not is_sequence(True)
    assert not is_sequence(0)
    assert not is_sequence(0.0)
    assert not is_sequence(0j)
    assert not is_sequence(u'foo')

    class Foo(object):
        pass

    assert not is_sequence(Foo())

    assert not is_sequence(set())
    assert not is_sequence(frozenset())
    assert not is_sequence({})

    assert is_sequence(list())
    assert is_sequence(tuple())

    assert is_sequence([], True)
   

# Generated at 2022-06-22 21:28:58.700203
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    test = ImmutableDict({'a': 'b', 'b': 'c'})
    for i in test:
        assert i in {'a', 'b'}


# Generated at 2022-06-22 21:29:02.656828
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    """Unit test for method __iter__ of class ImmutableDict"""
    d = {'a': 1, 'b': 2}
    imd = ImmutableDict(d)
    assert set(d) == set(imd)


# Generated at 2022-06-22 21:29:08.904776
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    assert isinstance(ImmutableDict().__iter__(), type(ImmutableDict()._store.__iter__()))
    assert isinstance(ImmutableDict({1:2}).__iter__(), type(ImmutableDict()._store.__iter__()))
    assert isinstance(ImmutableDict({1:2, 'a':'b'}).__iter__(), type(ImmutableDict()._store.__iter__()))



# Generated at 2022-06-22 21:29:19.310308
# Unit test for function is_iterable
def test_is_iterable():
    x = ['a', 'b', 'c']
    assert is_iterable(x) == True

    x = 'abc'
    assert is_iterable(x) == True

    x = ('a', 'b', 'c')
    assert is_iterable(x) == True

    x = ['a', 'b', 'c']
    assert is_iterable(x) == True

    x = u'abc'
    assert is_iterable(x) == True
    assert is_iterable(x, True) == True
    assert is_iterable(x, False) == False

    x = 1
    assert is_iterable(x) == False


# Generated at 2022-06-22 21:29:21.917680
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Unit tests for ImmutableDict"""
    assert eval(repr(ImmutableDict({'a': 1, 'b': 2}))) == {'a': 1, 'b': 2}

# Generated at 2022-06-22 21:29:25.820596
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict(a=1, b=2)
    res = len(d)
    assert res == 2


# Generated at 2022-06-22 21:29:31.659508
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    iDict = ImmutableDict({"a": 1, "b": 2, "c": 3})
    subtrDict = iDict.difference(["a", "c"])
    assert isinstance(subtrDict, ImmutableDict)
    assert subtrDict == ImmutableDict({"b": 2})


# Generated at 2022-06-22 21:29:36.403596
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict({'a': 1, 'b': 2})
    expected = {'a': 2, 'b': 3, 'c': 4}
    new = ImmutableDict({'a': 2, 'c': 4})
    actual = original.union(new)
    assert actual._store == expected


# Generated at 2022-06-22 21:29:48.724820
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    import pytest
    test_cases = [
        {
            "name": "empty",
            "inputs": [{}],
            "expected": 'ImmutableDict({})',
        },
        {
            "name": "some",
            "inputs": [{'a': 'b', 'c': 'd'}],
            "expected": 'ImmutableDict({"a": "b", "c": "d"})',
        },
    ]

    for test_case in test_cases:
        test_dict = ImmutableDict(test_case['inputs'][0])
        assert repr(test_dict) == test_case['expected']
        assert hash(frozenset(test_case['inputs'][0].items())) == hash(test_dict)

# Generated at 2022-06-22 21:29:54.508624
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict({'one': 'first', 'two': 'second', 'three': 'third'})
    overriding_mapping = {'three': 'troisieme', 'four': 'quatrieme'}
    combined = original.union(overriding_mapping)
    assert combined == {'one': 'first', 'two': 'second', 'three': 'troisieme', 'four': 'quatrieme'}



# Generated at 2022-06-22 21:30:03.977908
# Unit test for function is_sequence
def test_is_sequence():
    assert not is_sequence('abc')
    assert not is_sequence(b'abc')
    assert not is_sequence(range(3))

    assert is_sequence(['abc'])
    assert is_sequence([b'abc'])
    assert is_sequence((1, 2, 3))
    assert is_sequence({'abc': 123})
    assert is_sequence({'abc', 'xyz'})
    assert is_sequence(set('abc'))
    assert is_sequence(range(2))

    assert is_sequence('abc', include_strings=True)
    assert is_sequence(b'abc', include_strings=True)
    assert is_sequence(range(3), include_strings=True)