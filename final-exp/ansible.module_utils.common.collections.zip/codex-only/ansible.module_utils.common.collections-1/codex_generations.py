

# Generated at 2022-06-22 21:20:07.352427
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    # Test union of two ImmutableDicts without overlap
    immutable_dict1 = ImmutableDict({'A': 'A', 'B': 'B', 'C': 'C'})
    immutable_dict2 = ImmutableDict({'D': 'D', 'E': 'E', 'F': 'F'})
    union = immutable_dict1.union(immutable_dict2)
    assert immutable_dict1.keys() == {'A', 'B', 'C'}
    assert immutable_dict2.keys() == {'D', 'E', 'F'}
    assert union.keys() == {'A', 'B', 'C', 'D', 'E', 'F'}

    # Test union of two ImmutableDicts with overlap

# Generated at 2022-06-22 21:20:12.105348
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    test_dict = ImmutableDict({'a': 1, 'b': 2})
    test_dict = test_dict.union({'b': 3})
    assert test_dict['b'] == 3
    assert test_dict['a'] == 1
    assert 'b' in test_dict
    assert 'a' in test_dict
    assert len(test_dict) == 2
    assert 'c' not in test_dict

    test_dict = ImmutableDict({'a': 1, 'b': 2})
    test_dict = test_dict.union({'a': 1, 'b': 2, 'c': 3})
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3
    assert 'a' in test_dict

# Generated at 2022-06-22 21:20:15.258233
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    my_dict = ImmutableDict({"a": 1, "b": 2, "c": 3})
    assert isinstance(my_dict.__iter__(), type(my_dict._store.__iter__()))



# Generated at 2022-06-22 21:20:24.549746
# Unit test for function count
def test_count():
    from six import PY2
    if PY2:
        from ansible.module_utils.common._collections_compat import Counter
    else:
        from collections import Counter
    assert count("") == {}
    assert count([1, 2, 3, 2, 1]) == {1: 2, 2: 2, 3: 1}
    assert count("Ansible") == {'A': 1, 's': 2, 'i': 1, 'b': 1, 'l': 1, 'e': 1, 'n': 1}
    assert count(dict(a=1, b=1, c=1)) == {'a': 1, 'b': 1, 'c': 1}
    assert count(1) == Exception

# Generated at 2022-06-22 21:20:29.104351
# Unit test for function is_string
def test_is_string():
    # Test with strings
    assert is_string('blah')
    assert is_string(u'blah')
    assert is_string(b'blah')
    assert is_string(u'blah'.encode('utf-8'))

    # Test with others
    assert not is_string([1, 2, 3])
    assert not is_string(['a', 'b', 'c'])
    assert not is_string({'key': 'value'})



# Generated at 2022-06-22 21:20:35.819256
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    my_dict = ImmutableDict({'a': 1, 'b': 2})
    assert hash(my_dict) == hash(ImmutableDict({'b': 2, 'a': 1}))
    assert hash(my_dict) != hash(ImmutableDict({'a': 1, 'b': 1}))
    assert hash(my_dict) != hash(ImmutableDict({'b': 2, 'a': 1, 'c': 3}))


# Generated at 2022-06-22 21:20:43.502820
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    idict = ImmutableDict({'key1': 'value1', 'key2': 'value2'})

    # Should return an iterator that is iterable
    itr = idict.__iter__()
    assert(next(itr) == 'key1')
    assert(next(itr) == 'key2')

    # Should return an iterator that has length equal to the number of entries in idict
    itr = idict.__iter__()
    assert(len(list(itr)) == 2)



# Generated at 2022-06-22 21:20:48.152377
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict(x=1)

    # Test regular and missing keys
    assert d['x'] == 1
    try:
        d['y']
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-22 21:21:00.040646
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    import json
    import os.path
    import shlex
    import subprocess
    import sys

    d = ImmutableDict({'a': 1, 'b': 2})
    hash_1 = d.__hash__()

    # get path to this file
    this_file = os.path.realpath(__file__)
    # get path to the dir of this file
    this_dir = os.path.dirname(this_file)
    # get path to the python interpreter
    python_interpreter = sys.executable
    # get path to the unit test runner
    # (which is in the same directory as this file)
    test_runner = os.path.join(this_dir, '_test_ImmutableDict___hash__.py')
    # get path to the test file

# Generated at 2022-06-22 21:21:05.217073
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Test that all keys are passed to the ImmutableDict constructor, in the right order.
    """
    ordered_dict = {'A': 1, 'B': 2}
    unordered_dict = {'B': 2, 'A': 1}
    assert repr(ImmutableDict(ordered_dict)) == repr(ImmutableDict(unordered_dict))



# Generated at 2022-06-22 21:21:08.358970
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    i_d = ImmutableDict({'user': 'root', 'uid': 0})
    assert i_d.__repr__() == "ImmutableDict({'user': 'root', 'uid': 0})"



# Generated at 2022-06-22 21:21:20.861974
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    """
    Create an ImmutableDict as a combination of the original and overriding_mapping

    :arg overriding_mapping: A Mapping of replacement and additional items
    :return: A copy of the ImmutableDict with key-value pairs from the overriding_mapping added

    If any of the keys in overriding_mapping are already present in the original ImmutableDict,
    the overriding_mapping item replaces the one in the original ImmutableDict.
    """
    original = ImmutableDict({"a": "old", "c": "old"})
    overriding_mapping = {"a": "new", "b": "new"}
    union = original.union(overriding_mapping)
    assert union == ImmutableDict({"a": "new", "c": "old", "b": "new"})


# Generated at 2022-06-22 21:21:28.000174
# Unit test for function is_string
def test_is_string():
    class DummyClass(object):
        def __str__(self):
            return 'dummy'

    assert is_string('string') is True
    assert is_string(u'unicodestring') is True
    assert is_string(b'bytes') is True
    assert is_string(1) is False
    assert is_string(1.1) is False
    assert is_string(['item']) is False
    assert is_string(DummyClass()) is False



# Generated at 2022-06-22 21:21:33.002543
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    first_mapping = ImmutableDict({'a': 1, 'b': 2})
    overriding_mapping = {'b': 20, 'c': 30}
    union_mapping = first_mapping.union(overriding_mapping)
    assert union_mapping == ImmutableDict({'a': 1, 'b': 20, 'c': 30})
    assert first_mapping == ImmutableDict({'a': 1, 'b': 2})


# Generated at 2022-06-22 21:21:43.085188
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for __eq__ method of class ImmutableDict"""

    a = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    z = ImmutableDict({'x': 2, 'y': 3, 'z': 4})

    assert a == a
    assert a == {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert a == ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    assert a == ImmutableDict(c=3, d=4, a=1, b=2)
    assert a == {'c': 3, 'd': 4, 'a': 1, 'b': 2}
    assert a != z
    assert a != ImmutableDict()

# Generated at 2022-06-22 21:21:50.892882
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
#
# Input data
#
    test_args = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
#
# Call method __repr__ of class ImmutableDict with input data
#
    result = ImmutableDict.__repr__(ImmutableDict, test_args)
#
# Compare the actual result with the expected result
#
    assert result == ImmutableDict(test_args).__repr__()


# Generated at 2022-06-22 21:21:57.814947
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict({'a': 2, 'b': 3})
    overriding_mapping = {'c': 4, 'b': 6}
    result = original.union(overriding_mapping)
    assert isinstance(result, ImmutableDict)
    assert isinstance(result, Mapping)
    assert not isinstance(result, MutableMapping)
    assert original.union(overriding_mapping) == ImmutableDict({'a': 2, 'b': 6, 'c': 4})


# Generated at 2022-06-22 21:22:07.248100
# Unit test for function count
def test_count():
    assert count([1, 2, 3, 4, 5]) == {1: 1, 2: 1, 3: 1, 4: 1, 5: 1}
    assert count([1, 1, 2, 3, 4, 5]) == {1: 2, 2: 1, 3: 1, 4: 1, 5: 1}
    assert count([1, 1, 1, 2, 3, 4, 5]) == {1: 3, 2: 1, 3: 1, 4: 1, 5: 1}
    assert count((1, )) == {1: 1}
    assert count([1]) == {1: 1}
    assert count(['a', 'b', 'c']) == {'a': 1, 'b': 1, 'c': 1}
    assert count((1, 1)) == {1: 2}
    assert count([1, 1])

# Generated at 2022-06-22 21:22:14.651558
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    import pytest

    test_map = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3',
        'key4': 'value4',
    }

    result_map = ImmutableDict(test_map)

    for k, v in test_map.items():
        assert result_map[k] == v

    with pytest.raises(KeyError):
        # pylint: disable=pointless-statement
        result_map['key5']


# Generated at 2022-06-22 21:22:26.017267
# Unit test for function is_sequence
def test_is_sequence():
    """
    Test function is_sequence

    ImmutableDict is a Mapping, but not a Sequence
    """

    # List with one element and trailing comma - tuple
    my_list = ['one_element',]
    assert isinstance(my_list, Sequence)
    assert is_sequence(my_list)

    # Empty tuple, immutable
    my_tuple = ()
    assert isinstance(my_tuple, Sequence)
    assert is_sequence(my_tuple)

    # Tuple with one element
    my_tuple = ('one_element',)
    assert isinstance(my_tuple, Sequence)
    assert is_sequence(my_tuple)

    # Integer in tuple
    my_tuple = (1,)
    assert isinstance(my_tuple, Sequence)

# Generated at 2022-06-22 21:22:32.662685
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d = d.difference({'a'})
    assert d['a'] == 1
    assert set(d.keys()) == {'a'}

    d = d.difference(['a', 'b', 'c'])
    assert d == ImmutableDict()

    # d is empty, calling difference again shouldn't break
    d = d.difference(['x', 'y', 'z'])
    assert d == ImmutableDict()


# Generated at 2022-06-22 21:22:36.980291
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    x = ImmutableDict({'a': 1, 'b': 2})
    x_items = list(x.items())
    x_items.sort()
    assert x_items == ['a', 'b'], "Failed to iterate over ImmutableDict"

# Generated at 2022-06-22 21:22:45.836337
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_a = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    dict_b = ImmutableDict({'key1': 'value1'})
    dict_a_copy = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    dict_c = {'key1': 'value1', 'key2': 'value2'}
    dict_d = [('key1', 'value1'), ('key2', 'value2')]

    assert dict_a != dict_b
    assert dict_a == dict_a_copy
    assert dict_a != dict_c
    assert dict_a != dict_d

# Generated at 2022-06-22 21:22:54.476982
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # __eq__ should return True if both objects are equal
    # and False otherwise. Equality holds when the items
    # match.
    d1 = ImmutableDict({'a': 1, 'b': 2})

    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    d3 = ImmutableDict({'a': 1, 'b': 3})
    assert d1 != d3

    d4 = ImmutableDict({'a': 5, 'b': 2})
    assert d1 != d4


# Generated at 2022-06-22 21:23:05.505629
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Run a unit test for the difference method of the ImmutableDict class

    :return: None
    """
    import unittest

    class TestImmutableDictDifference(unittest.TestCase):
        """
        Test case for difference method of ImmutableDict

        :return: None
        """
        def test_different_length(self):
            """
            Test that difference works even when the length of the original ImmutableDict and the
            length of the subtractive iterable are different

            :return: None
            """
            immutable_dict = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})
            self.assertEqual(immutable_dict.difference([1, 2]), ImmutableDict({3: 'three'}))


# Generated at 2022-06-22 21:23:09.974939
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d = ImmutableDict(dict(a=1, b=2))
    # __hash__ only relies on the hash of frozen items,
    # which is not affected by the order of the keys in dict
    assert hash(d) == hash(ImmutableDict(dict(b=2, a=1)))
    # __hash__ is not affected by the addition of new keys
    assert hash(d) == hash(ImmutableDict(dict(a=1, b=2, c=3)))
    # __hash__ is not affected by the addition of new keys when the original dict was empty
    assert hash(ImmutableDict()) == hash(ImmutableDict(dict(c=3)))
    # __hash__ is affected by the modification of existing keys

# Generated at 2022-06-22 21:23:21.254552
# Unit test for function is_sequence
def test_is_sequence():
    class MySequence(Sequence):
        # this class is not a valid sequence, it just inherits
        pass

    class MyDict(MutableMapping):
        # this class is not a sequence, it just implements non-sequential methods
        def __getitem__(self, *args):
            return None

        def __iter__(self):
            return iter([])

        def __len__(self):
            return 0

    class MyString(text_type):
        # this class is not a sequence, it just inherits from str
        pass

    class MyStringSequence(MyString, Sequence):
        # this class is a sequence
        def __getitem__(self, *args):
            return None

        def __iter__(self):
            return iter([])

        def __len__(self):
            return 0

   

# Generated at 2022-06-22 21:23:28.442210
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert test_dict['a'] == 1

    # Test __getitem__ on empty dictionary
    test_dict = ImmutableDict()
    assert test_dict['a'] == test_dict.__getitem__('a')


# Generated at 2022-06-22 21:23:31.765169
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    """Ensure ImmutableDict.__getitem__ is correctly implemented."""
    test_immutable_dict = ImmutableDict(test_k="test_v")
    assert test_immutable_dict.__getitem__('test_k') == "test_v"


# Generated at 2022-06-22 21:23:40.304095
# Unit test for function is_iterable
def test_is_iterable():
    """Unit test for function is_iterable"""
    class DummyIterable(object):
        """Serves as an iterable for testing purposes"""
        def __iter__(self):
            return iter([])

    dict_iter = dict().__iter__()
    list_iter = list().__iter__()
    seq_iter = tuple().__iter__()
    str_iter = ''.__iter__()

    assert is_iterable(dict_iter)
    assert is_iterable(list_iter)
    assert is_iterable(seq_iter)
    assert is_iterable(str_iter)
    assert is_iterable(DummyIterable())

    assert not is_iterable('')
    assert not is_iterable(2)
    # if python3, not is_iterable(b'')


#

# Generated at 2022-06-22 21:23:46.050860
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """
    Check that the hash key of ImmutableDict is equal to the hash key of frozenset,
    created from the tuple with key-value pairs from ImmutableDict. (the same as
    set, but with explicitly defined hash method)
    """
    test_dict = ImmutableDict(a=1, b=2, c=3)
    test_set = frozenset(test_dict.items())
    assert hash(test_dict) == hash(test_set)



# Generated at 2022-06-22 21:23:54.119800
# Unit test for function is_sequence
def test_is_sequence():
    class IterableReturningFalse(object):
        def __iter__(self):
            return self

        def next(self):
            return None

        def __next__(self):
            return None

    assert is_sequence(())
    assert is_sequence([])
    assert is_sequence(object)
    assert is_sequence(IterableReturningFalse)
    assert not is_sequence({'a': 1, 'b': 2})
    assert not is_sequence(3)
    assert is_sequence(set())
    assert is_sequence(frozenset())



# Generated at 2022-06-22 21:23:56.725587
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    m = ImmutableDict({'x': 1, 'y': 2})
    assert m['x'] == 1


# Generated at 2022-06-22 21:24:01.410989
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    original_dict = {'a': 'b', 'c': 'd', 'e': 'f'}
    immutable_dict = ImmutableDict(original_dict)
    assert immutable_dict['a'] == 'b'
    assert immutable_dict == original_dict


# Generated at 2022-06-22 21:24:06.287439
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    d = ImmutableDict(a=1, b=2)
    d1 = d.union(c=3)
    d1['d'] = 4
    assert d1['a'] == 1
    assert d1['b'] == 2
    assert d1['c'] == 3
    assert d1['d'] == 4

    d2 = d1.union(c=5, e=6)
    assert d2['c'] == 5
    assert d2['e'] == 6



# Generated at 2022-06-22 21:24:07.994178
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert repr(ImmutableDict({'a': 1})) == 'ImmutableDict({\'a\': 1})'

# Generated at 2022-06-22 21:24:18.800756
# Unit test for function is_iterable
def test_is_iterable():
    """
    Test if is_iterable correctly returns True for iterables, False for non-iterables,
    except for strings if include_strings is True
    """
    assert is_iterable([], include_strings=False)
    assert is_iterable((), include_strings=False)
    assert is_iterable({}, include_strings=False)
    assert is_iterable(set(), include_strings=False)
    assert is_iterable('string', include_strings=False)
    assert is_iterable(b'bytes', include_strings=False)

    assert is_iterable([], include_strings=True)
    assert is_iterable((), include_strings=True)
    assert is_iterable({}, include_strings=True)
    assert is_iterable(set(), include_strings=True)
    assert is_

# Generated at 2022-06-22 21:24:22.068534
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict(a=1,b=2,c=3,d=4,)
    if len(d) != 4:
        raise Exception("test_ImmutableDict___len__ failed")


# Generated at 2022-06-22 21:24:26.200256
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1,2,3])
    assert is_iterable(set([1,2,3]))
    assert is_iterable((1,2,3))
    assert is_iterable(dict(a=1, b=2))
    assert not is_iterable('not iterable')
    assert not is_iterable(3)



# Generated at 2022-06-22 21:24:30.400531
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert sorted(list(d)) == ['a', 'b', 'c']



# Generated at 2022-06-22 21:24:37.952020
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    from six import PY2
    idict_1 = ImmutableDict([('a', 1), ('b', 2)])
    idict_2 = ImmutableDict([('b', 2), ('a', 1)])
    if PY2:
        # __hash__ sets are not order dependent
        assert idict_1 == idict_2
    else:
        # Python 3 enforces order in sets
        assert idict_1 != idict_2

# Generated at 2022-06-22 21:24:40.615163
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict({'a': 1, 'b': 2, 'c': 3})) == 3
    assert len(ImmutableDict()) == 0



# Generated at 2022-06-22 21:24:44.822792
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    testdict = ImmutableDict(dict1=1, dict2=2, dict3=3)
    assert len(testdict) == 3
    testdict = ImmutableDict()
    assert len(testdict) == 0


# Generated at 2022-06-22 21:24:57.784818
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    test_dict = ImmutableDict([("a", 1), ("b", 2), ("c", 3)])
    assert(test_dict["a"] == 1)
    assert(test_dict["b"] == 2)
    assert(test_dict["c"] == 3)
    assert(test_dict.union({"d": 4, "e": 5}) == ImmutableDict([("a", 1), ("b", 2), ("c", 3), ("d", 4), ("e", 5)]))
    assert(test_dict.union({"a": 4, "e": 5}) == ImmutableDict([("a", 4), ("b", 2), ("c", 3), ("e", 5)]))
    assert(test_dict.difference(["a", "b"]) == ImmutableDict([("c", 3)]))

# Generated at 2022-06-22 21:25:01.927710
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict({'a': 1})) == 1
    assert len(ImmutableDict({'a': 1, 'b': 2})) == 2
    assert len(ImmutableDict({'a': 1, 'b': 2, 'c': 3})) == 3


# Generated at 2022-06-22 21:25:06.459526
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    assert(ImmutableDict([(1, 1), (2, 2)]).__iter__() == ImmutableDict([(1, 1), (2, 2)])._store.__iter__())


# Generated at 2022-06-22 21:25:14.091287
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    import pytest
    first = ImmutableDict({1: 2, 2: 3})
    second = ImmutableDict({1: 2, 2: 3})
    third = ImmutableDict({1: 2, 3: 3})
    fourth = ImmutableDict({1: 2, 2: 4})
    five = ImmutableDict({2: 3, 1: 2})
    six = {2: 3, 1: 2}
    assert (hash(first) == hash(second))
    assert (hash(first) != hash(third))
    assert (hash(first) != hash(fourth))
    assert (hash(first) == hash(five))
    assert (hash(first) != hash(six))
    assert (len(set([first, second, third, fourth, five, six])) == 5)

# Generated at 2022-06-22 21:25:17.271341
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    m1 = ImmutableDict({'a': 'b'})
    m2 = m1.difference(['a'])
    assert m2 == ImmutableDict()



# Generated at 2022-06-22 21:25:24.280521
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    c = ImmutableDict({'a': 1})
    assert a == b
    assert a != c
    assert a != {}
    assert a != a.union({'c': 3})
    assert a == a.union({'c': 4}).union({'c': 3})


# Generated at 2022-06-22 21:25:30.826979
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert ImmutableDict().__repr__() == "ImmutableDict({'()': None})"
    assert ImmutableDict(key='value').__repr__() == "ImmutableDict({'key': 'value'})"
    assert ImmutableDict((('key', 'value'),)).__repr__() == "ImmutableDict({'key': 'value'})"



# Generated at 2022-06-22 21:25:40.658066
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Check that ImmutableDict.__repr__ works correctly"""
    # Check with empty dictionary
    dct = ImmutableDict()
    assert repr(dct) == "ImmutableDict({0})"
    # Check with populated dictionary with only string keys
    dct = ImmutableDict({'test': 'value'})
    assert repr(dct) == "ImmutableDict({'test': 'value'})"
    # Check with populated dictionary with string and integer keys
    dct = ImmutableDict({'test': 'value', 1: 2})
    assert repr(dct) == "ImmutableDict({'test': 'value', 1: 2})"



# Generated at 2022-06-22 21:25:47.868454
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    orig_dict = {'a': 'b', 'c': 'd', 'e': 'f'}
    immut_dict = ImmutableDict(orig_dict)

    assert immut_dict == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert immut_dict.keys() == {'a', 'c', 'e'}
    assert immut_dict.values() == {'b', 'd', 'f'}
    assert immut_dict.items() == {('a', 'b'), ('c', 'd'), ('e', 'f')}
    assert immut_dict['a'] == 'b'
    assert immut_dict['c'] == 'd'
    assert immut_dict['e'] == 'f'


# Generated at 2022-06-22 21:25:52.114278
# Unit test for function is_string
def test_is_string():
    assert not is_string([])
    assert is_string(u'a')
    assert is_string('a')
    assert not is_string(1)
    assert not is_string(None)
    assert not is_string({})


# Generated at 2022-06-22 21:25:58.690563
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    # Create three ImmutableDict objects
    dict1 = ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    dict2 = ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    dict3 = ImmutableDict({'key1': 'value1'})

    assert dict1.__eq__(dict2) is True
    assert dict1.__eq__(dict3) is False



# Generated at 2022-06-22 21:26:10.229317
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Test ImmutableDict constructor"""

    # Verify that an ImmutableDict created with a single argument will have the correct elements
    # pylint: disable=line-too-long
    assert ImmutableDict({'a': 'b'}) == ImmutableDict({'a': 'b'})
    assert ImmutableDict({'a': 'b'}) != ImmutableDict({'b': 'a'})
    assert ImmutableDict({'a': 'b'}) != ImmutableDict({'a': 'c'})
    assert ImmutableDict({'a': 'b'}) != ImmutableDict({})

    # Verify that an ImmutableDict created with multiple arguments will have the correct elements

# Generated at 2022-06-22 21:26:17.708276
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({1: 2}) == ImmutableDict({1: 2})
    assert ImmutableDict({1: 2}) != ImmutableDict({2: 2})
    assert ImmutableDict({1: 2}) != ImmutableDict({1: 1})
    assert ImmutableDict({1: 2}) != ImmutableDict({1: 2, 3: 4})
    assert ImmutableDict({1: 2}) != {1: 2}
    assert ImmutableDict({1: 2}) != 1

# Generated at 2022-06-22 21:26:28.279565
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    keys = list(range(0, 3))
    values = list(range(3))
    original = ImmutableDict(zip(keys, values))
    overriding_mapping = {3:3, 4:4}

    new_dict = original.union(overriding_mapping)
    # New dictionary is created
    assert original is not new_dict
    # Overriding mapping is added
    for k in overriding_mapping.keys():
        assert k in new_dict
    # Original dictionary is not modified
    for k in original.keys():
        assert k in new_dict

    overriding_mapping = {0:999, 1:999}
    new_dict = original.union(overriding_mapping)
    # Keys with overriding mapping are replaced
    for k in overriding_mapping.keys():
        assert k in new

# Generated at 2022-06-22 21:26:36.704817
# Unit test for function count
def test_count():
    from ansible.compat.tests import unittest

    class CountTestCase(unittest.TestCase):
        def test_count(self):
            my_list = [1, 2, 3, 1, 2, 3, 1, 2, 3]
            self.assertEqual(count(my_list), {1: 3, 2: 3, 3: 3})
            my_tuple = (1, 2, 3, 1, 2, 3, 1, 2, 3)
            self.assertEqual(count(my_tuple), {1: 3, 2: 3, 3: 3})
            my_string = 'aaaabbbccc'
            self.assertEqual(count(my_string), {'a': 4, 'b': 3, 'c': 3})

# Generated at 2022-06-22 21:26:41.996924
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    """Test for the iter() method of ImmutableDict."""
    d = ImmutableDict(((1, 2), (3, 4), (5, 6)))
    e = ImmutableDict(((7, 8), (9, 10), (11, 12)))

    assert next(iter(d)) == 1
    assert next(iter(e)) == 7



# Generated at 2022-06-22 21:26:50.969935
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 'b', 'c': 'd'})

    # Mapping type with identical contents
    mapping_type = {'a': 'b', 'c': 'd'}
    assert d1 == mapping_type

    # Mapping type with different contents
    mapping_type = {'a': 'b', 'c': 'de'}
    assert d1 != mapping_type

    # Mapping type with additional contents
    mapping_type = {'a': 'b', 'c': 'd', 'e': 'f'}
    assert d1 != mapping_type

    # MutableMapping type with identical contents
    mapping_type = MutableMapping({'a': 'b', 'c': 'd'})
    assert d1 == mapping_type

    # MutableMapping type with different contents
   

# Generated at 2022-06-22 21:26:54.848837
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    assert tuple(ImmutableDict()) == tuple()
    assert tuple(ImmutableDict(a=1, b=2, c=3)) == ('a', 'b', 'c')


# Generated at 2022-06-22 21:27:00.426896
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    test = ImmutableDict(name=['test'], data=['test2'])
    expected = ['name', 'data']
    result = [x for x in test]
    if result == expected:
        print('ImmutableDict __iter__ method passed')
    else:
        print('ImmutableDict __iter__ method failed')


# Unit tests for method __len__ of class ImmutableDict

# Generated at 2022-06-22 21:27:12.678651
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    # Test for default values
    test_immutable_dict = ImmutableDict()
    assert list(test_immutable_dict) == []

    # Test for dict parameter
    test_immutable_dict = ImmutableDict({'test': 1})
    assert list(test_immutable_dict) == ['test']

    # Test for dict parameter and key-value parameters
    test_immutable_dict = ImmutableDict({'test': 1}, test2=2)
    assert list(test_immutable_dict) == ['test', 'test2']

    # Test for key-value parameters
    test_immutable_dict = ImmutableDict(test=1, test2=2, test3=3)
    assert list(test_immutable_dict) == ['test', 'test2', 'test3']


# Generated at 2022-06-22 21:27:24.268384
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    # Test initialization with dict(), dict(seq), dict(**kwargs)
    assert ImmutableDict() == ImmutableDict({}) == ImmutableDict(seq={}) == ImmutableDict(kwargs={})
    assert ImmutableDict(seq={1: 2, 3: 4}) == ImmutableDict({1: 2, 3: 4}) == ImmutableDict(kwargs={1: 2, 3: 4})
    assert ImmutableDict(seq={1: 2}, kwargs={3: 4}) == ImmutableDict({1: 2, 3: 4}) == ImmutableDict(kwargs={1: 2, 3: 4})

    # Test use of update method

# Generated at 2022-06-22 21:27:28.609693
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    dict1 = ImmutableDict({u"a": 1, u"b": 2, u"c": 3})
    assert hash(dict1) == hash(frozenset(dict1.items()))

    dict2 = dict1
    assert hash(dict2) == hash(frozenset(dict1.items()))

# Generated at 2022-06-22 21:27:30.709997
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    test_dict = ImmutableDict({"a": 1, "b": 2})
    assert len(test_dict) == 2


# Generated at 2022-06-22 21:27:36.314868
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    d3 = ImmutableDict({'b': 2, 'a': 1})
    d4 = ImmutableDict({'b': 3, 'a': 1})
    d5 = {'a': 1, 'b': 2}
    d6 = 3
    assert d1 == d2
    assert d1 == d3
    assert d1 != d4
    assert d1 != d5
    assert d1 != d6


# Generated at 2022-06-22 21:27:42.288541
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """
    Unit test for constructor of class ImmutableDict
    """
    x = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert x["a"] == 1
    assert x["b"] == 2
    assert x["c"] == 3



# Generated at 2022-06-22 21:27:54.251402
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'foo': 'bar'}) == {'foo': 'bar'}
    assert ImmutableDict({'foobar': 'bar'}) != {'foo': 'bar'}
    assert ImmutableDict({'foo': 'bar'}) != {'foo': 'bar', 'foobar': 'bar'}
    assert ImmutableDict({'foo': 'bar'}) != {'foobar': 'bar'}
    assert ImmutableDict({'list': [1, 2, 3]}) == {'list': [1, 2, 3]}
    assert ImmutableDict({'list': [1, 2, 3, 3]}) == {'list': [1, 2, 3, 3]}

# Generated at 2022-06-22 21:27:59.617996
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    test_dict = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    for key in test_dict:
        assert key in ['a', 'b']
    assert len(test_dict) == 2
    assert vars(test_dict) == {'_store': {'a': 1, 'b': 2}}



# Generated at 2022-06-22 21:28:08.541184
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """
    Test the __repr__ method
    :return: None
    """
    dic = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    result = dic.__repr__()
    if result != "ImmutableDict({'a': 1, 'b': 2, 'c': 3})":
        raise Exception("test_ImmutableDict___repr__ FAIL")


# Generated at 2022-06-22 21:28:13.464351
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    idict = ImmutableDict({"a":1, "b":2})
    assert(set(idict.__iter__()) == set(("a", "b")))


# Generated at 2022-06-22 21:28:16.632328
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    x = ImmutableDict([('a', 1), ('b', 2)])
    assert repr(x) == "ImmutableDict({'a': 1, 'b': 2})"


# Generated at 2022-06-22 21:28:21.127255
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    dict1 = ImmutableDict({"key1": "val1", "key2": "val2", "key3": "val3"})
    dict2 = dict1.difference(['key2'])
    assert dict2 == ImmutableDict({'key1': 'val1', 'key3': 'val3'})



# Generated at 2022-06-22 21:28:24.855934
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    base_dict = ImmutableDict(a=1, b=2)
    overriding_dict = dict(c=3, d=4)
    expected_result = dict(a=1, b=2, c=3, d=4)
    assert base_dict.union(overriding_dict) == ImmutableDict(**expected_result)


# Generated at 2022-06-22 21:28:34.435410
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    # Test when number of args is equal to 1
    union_test1 = ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    assert isinstance(union_test1, ImmutableDict)
    assert union_test1.union({'key4': 'value4'}) == ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4'})
    assert union_test1.union({'key4': {'key5': 'value5'}}) == ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': {'key5': 'value5'}})
    # Test when number of

# Generated at 2022-06-22 21:28:40.133163
# Unit test for function is_string
def test_is_string():
    assert is_string('string')
    assert is_string(u'unicode')
    assert is_string(b'bytes')

    assert not is_string(1)
    assert not is_string([1])
    assert not is_string(['string'])
    assert not is_string({1: 2})
    assert not is_string(object())



# Generated at 2022-06-22 21:28:42.397013
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})

# Generated at 2022-06-22 21:28:45.311629
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    assert ImmutableDict(dict(a=1, b=2, c=3))['a'] == 1



# Generated at 2022-06-22 21:28:51.023899
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d = ImmutableDict({'a': 1, 'b': 2})
    assert d == {'a': 1, 'b': 2}
    assert d == ImmutableDict({'a': 1, 'b': 2})
    assert not d == ImmutableDict({'b': 2, 'a': 1})



# Generated at 2022-06-22 21:28:56.100868
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert str(ImmutableDict(test_key='test value')) == "ImmutableDict({'test_key': 'test value'})"
    assert str(ImmutableDict({'test_key': 'test value'})) == "ImmutableDict({'test_key': 'test value'})"


# Generated at 2022-06-22 21:29:07.974448
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    """Test ImmutableDict.union() method"""
    # Create a simple dictionary from which ImmutableDict will be created
    d_original = {'key_1': 'value_1', 'key_2': 'value_2'}
    d_override = {'key_1': 'value_1_new', 'key_3': 'key_3_new'}
    d_combined = d_original.copy()
    d_combined.update(d_override)
    # Create an ImmutableDict from the original dictionary
    id_original = ImmutableDict(d_original)
    # Create an ImmutableDict as a combination of the original and overriding_mapping
    id_combined = id_original.union(d_override)
    assert id_combined == d_combined

# Unit test

# Generated at 2022-06-22 21:29:19.878680
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    immutable_dict_1 = ImmutableDict({'a': '1', 'b': '2'})
    immutable_dict_2 = ImmutableDict({'b': '3', 'c': '4'})
    immutable_dict_3 = ImmutableDict({'a': '1', 'b': '3', 'c': '4'})
    immutable_dict_4 = immutable_dict_1.union(immutable_dict_2)

    assert immutable_dict_1 == ImmutableDict({'a': '1', 'b': '2'})
    assert immutable_dict_2 == ImmutableDict({'b': '3', 'c': '4'})
    assert immutable_dict_4 == immutable_dict_3


# Generated at 2022-06-22 21:29:26.182690
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})
    keys_to_remove = ['a', 'c', 'e']
    expected = {'b': 2, 'd': 4}
    removal = original.difference(keys_to_remove)
    assert removal == expected



# Generated at 2022-06-22 21:29:33.920945
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('string')
    assert is_iterable(u'unicode')
    assert is_iterable(b'bytestring')
    assert is_iterable(123)
    assert is_iterable(object())

    assert not is_iterable(False)
    assert not is_iterable(None)



# Generated at 2022-06-22 21:29:37.510290
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    from ansible.module_utils.common.collections import ImmutableDict
    d = ImmutableDict({'a': 'b'})
    assert str(d) == 'ImmutableDict({\'a\': \'b\'})'


# Generated at 2022-06-22 21:29:49.823336
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Check error handling
    try:
        ImmutableDict() == None
        assert False
    except TypeError:
        pass

    # Check when empty dictionaries are equal
    assert ImmutableDict() == ImmutableDict()

    # Check when dictionaries have the same keys and values
    ini_dict = ImmutableDict({
        'host': 'localhost',
        'port': 5985,
        'mail': 'user@domain.com'
    })
    other_dict = ImmutableDict({
        'host': 'localhost',
        'port': 5985,
        'mail': 'user@domain.com'
    })
    assert ini_dict == other_dict

    # Check when dictionaries have different keys and values

# Generated at 2022-06-22 21:29:51.524957
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    assert ImmutableDict(foo="bar")["foo"] == "bar"


# Generated at 2022-06-22 21:29:55.917524
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    x = ImmutableDict({'a': 1, 'b': 2})
    x_copy = ImmutableDict({'a': 1, 'b': 2})
    y = ImmutableDict({'b': 2, 'a': 1})
    assert hash(x) == hash(x_copy)
    assert hash(x) == hash(y)