

# Generated at 2022-06-22 21:20:07.395397
# Unit test for function is_iterable
def test_is_iterable():
    # Test cases for function is_iterable
    # Test 1. Testing if a string is iterable
    assert is_iterable('Test string') is True

    # Test 2. Testing if a bytes is iterable
    assert is_iterable(b'Test string') is True

    # Test 3. Testing if a list is iterable
    assert is_iterable([1, 2, 3, 4, 5]) is True

    # Test 4. Testing if a dict is iterable
    assert is_iterable({1: 'one', 2: 'two', 3: 'three'}) is True

    # Test 5. Testing if a set is iterable
    assert is_iterable(set([1, 2, 3, 4, 4, 4])) is True

    # Test 6. Testing if a tuple is iterable

# Generated at 2022-06-22 21:20:12.187954
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    a = ImmutableDict({1: 1, 2: 2, 3: 3})
    b = a.difference([3, 4])
    assert 1 in b
    assert 2 in b
    assert 3 not in b
    assert 4 not in b
    assert len(b) == 2

# Generated at 2022-06-22 21:20:22.625333
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    from copy import copy
    from collections import MutableSequence, MutableMapping

    immutable_dict = ImmutableDict({'a': 0, 'b': 1, 'c': 2})
    assert immutable_dict == ImmutableDict({'a': 0, 'b': 1, 'c': 2})

    immutable_dict_copy = copy(immutable_dict)
    assert immutable_dict == immutable_dict_copy

    immutable_dict_copy_2 = immutable_dict.copy()
    assert immutable_dict == immutable_dict_copy_2

    immutable_dict_copy_3 = immutable_dict.copy()
    assert immutable_dict == immutable_dict_copy_3

    immutable_dict_updaeted = immutable_dict.union({'a': 3, 'd': 4})
    assert immutable_dict_updaeted != immutable

# Generated at 2022-06-22 21:20:32.942931
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Return an ImmutableDict that is copy of the original ImmutableDict without
    keys from the subtractive_iterable

    :arg subtractive_iterable: Any iterable containing keys that should not be present in the
        new ImmutableDict
    :return: A copy of the ImmutableDict with keys from the subtractive_iterable removed
    """
    original_dict = ImmutableDict({'key1': 1, 'key2': 2, 'key3': 3, 'key4': 4})
    subtractive_keys = {'key1', 'key3'}
    new_dict = original_dict.difference(subtractive_keys)
    assert new_dict == ImmutableDict({'key2': 2, 'key4': 4})


# Generated at 2022-06-22 21:20:37.234076
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    for cls in [dict, ImmutableDict]:
        a = cls({'a': 1, 'b': 2})
        b = a.union({'a': 3})
        assert a == {'a': 1, 'b': 2}
        assert b == {'a': 3, 'b': 2}

# Generated at 2022-06-22 21:20:39.399852
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert repr(ImmutableDict({'a': 1, 'b': 2})) == 'ImmutableDict({\'a\': 1, \'b\': 2})'
    assert repr(ImmutableDict()) == 'ImmutableDict({})'


# Generated at 2022-06-22 21:20:47.497646
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 'a'}) == ImmutableDict({'a': 'a'})
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({'a': 'a'}) != ImmutableDict({'a': 'b'})
    assert ImmutableDict({'a': 'a'}) != {'a': 'a'}
    assert ImmutableDict({'a': 'b'}) != ImmutableDict({'a': 'a'})
    assert ImmutableDict({'a': 'a', 'b': 'b'}) != ImmutableDict({'a': 'a'})



# Generated at 2022-06-22 21:20:49.937672
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    x = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert len(x) == 3


# Generated at 2022-06-22 21:20:54.672120
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    keys = ['key0', 'key1', 'key2']
    values = [0, 1, 2]
    imm_dict = ImmutableDict(zip(keys, values))

    len_ = len(imm_dict)

    assert len_ == len(keys)


# Generated at 2022-06-22 21:21:03.144970
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    # Generate empty ImmutableDict
    empty_dict = ImmutableDict()
    assert len(empty_dict) == 0

    # Generate ImmutableDict with one element
    one_element_dict = ImmutableDict(key1='value1')
    assert len(one_element_dict) == 1

    # Generate ImmutableDict with three elements
    three_elements_dict = ImmutableDict(key1='value1', key2='value2', key3='value3')
    assert len(three_elements_dict) == 3



# Generated at 2022-06-22 21:21:09.092340
# Unit test for function count
def test_count():
    assert count(list(range(10))) == {0: 1, 1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 1, 7: 1, 8: 1, 9: 1}
    assert count([0, 0, 1, 3, 3, 3, 3, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8]) == {0: 2, 1: 1, 3: 4, 7: 12, 8: 1}


# Generated at 2022-06-22 21:21:21.047999
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Check that an ImmutableDict can be created and that it is immutable."""
    initial_dict = {'a': 1, 'b': 2, 'c': 3}
    immutable_dict = ImmutableDict(initial_dict)

    assert immutable_dict == initial_dict
    assert immutable_dict.__hash__() == hash(initial_dict)
    assert immutable_dict.get('b') == 2
    assert immutable_dict.get('b', 'different') == 2
    assert immutable_dict.get('d') is None
    assert immutable_dict.get('d', 'different') == 'different'
    for x in immutable_dict.values():
        assert x in [1, 2, 3]
    for x in immutable_dict.keys():
        assert x in ['a', 'b', 'c']

# Generated at 2022-06-22 21:21:31.157760
# Unit test for function is_sequence
def test_is_sequence():
    # is_sequence should return False for these types
    assert not is_sequence(1)
    assert not is_sequence("string")
    assert not is_sequence({})
    assert not is_sequence(object())

    # out_of_range is a sequence subclass that cannot be indexed
    class out_of_range(Sequence):
        def __getitem__(self, key):
            raise IndexError('index out of range')

    assert not is_sequence(out_of_range())

    # lists, dicts, and tuples are sequences
    assert is_sequence([1, 2])
    assert is_sequence(range(5))
    assert is_sequence(tuple((1, 2)))
    assert is_sequence({1: 2, 3: 4})

    # by default, strings are not recognized as sequences

# Generated at 2022-06-22 21:21:40.848434
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    # Case 1: empty dict
    test = ImmutableDict({})
    assert isinstance(test, Mapping)
    assert isinstance(test, Hashable)
    assert not isinstance(test, MutableMapping)
    assert not isinstance(test, Sequence)
    assert len(test) == 0
    assert is_string(test) is False
    assert is_iterable(test) is True
    assert is_sequence(test) is False
    assert list(test.__iter__()) == []
    assert list(test) == []
    # Case 2: dict with a single element
    test = ImmutableDict({'key': 'value'})
    assert len(test) == 1
    assert list(test.__iter__()) == ['key']
    assert list(test) == ['key']
    # Case 3: dict with

# Generated at 2022-06-22 21:21:44.476510
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    test_immutabledict = ImmutableDict({'a': 1, 'b': 2})
    assert test_immutabledict['a'] == 1
    assert test_immutabledict['b'] == 2


# Generated at 2022-06-22 21:21:56.150383
# Unit test for function count
def test_count():
    list1 = [1, 5, 2, 'a', 'b', 'b', 'b', 5, 5, 'a', 'a', 'c']
    res1 = count(list1)
    assert res1 == {1:1, 5:3, 2:1, 'a':3, 'b':3, 'c':1}

    list1 = (1, 5, 2, 'a', 'b', 'b', 'b', 5, 5, 'a', 'a', 'c')
    res1 = count(list1)
    assert res1 == {1: 1, 5: 3, 2: 1, 'a': 3, 'b': 3, 'c': 1}

    list1 = {'a': 2, 'b': 3, 'c': 4}
    res1 = count(list1)

# Generated at 2022-06-22 21:22:06.114792
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Unit test for method difference of class ImmutableDict
    """
    from ansible.module_utils.common._collections_compat import Mapping

    class ImmutableDict(Mapping):
        """
        A dictionary that cannot be updated

        This implementation differs from ImmutableDict in ansible.module_utils.common._collections_compat
        in that it doesn't inherit from Hashable
        """
        def __init__(self, *args, **kwargs):
            self._store = dict(*args, **kwargs)

        def __getitem__(self, key):
            return self._store[key]

        def __iter__(self):
            return self._store.__iter__()

        def __len__(self):
            return self._store.__len__()


# Generated at 2022-06-22 21:22:12.706359
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Test for __hash__ method of class ImmutableDict"""
    imm_dict1 = ImmutableDict({'a': 'b', 'c': 'd'})
    imm_dict2 = ImmutableDict({'c': 'd', 'a': 'b'})
    imm_dict3 = ImmutableDict({'c': 'd', 'a': 'b', 'e': 'f'})

    assert imm_dict1.__hash__() == imm_dict2.__hash__()
    assert imm_dict1.__hash__() != imm_dict3.__hash__()
    assert imm_dict3.__hash__() != hash('string')


# Generated at 2022-06-22 21:22:22.355287
# Unit test for function is_sequence
def test_is_sequence():
    assert(is_sequence([1, 2, 3]))
    assert(is_sequence((1, 2, 3)))
    assert(is_sequence({'a': 1, 'b': 'c', 'c': 3}))
    assert(is_sequence([x for x in range(5)]))
    assert(is_sequence((x for x in range(5))))
    assert(is_sequence({x: x for x in range(5)}))
    assert(not is_sequence(1))
    assert(not is_sequence(None))
    assert(not is_sequence("abc"))
    assert(not is_sequence(True))
    assert(not is_sequence(set()))
    assert(not is_sequence(set([1, 2, 3])))
    assert(not is_sequence(frozenset()))

# Generated at 2022-06-22 21:22:25.741068
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    assert ImmutableDict({'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd'}).difference({'b'}) == ImmutableDict({'a': 'a', 'c': 'c', 'd': 'd'})

# Generated at 2022-06-22 21:22:30.781024
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert not is_iterable(None)
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable({1, 2, 3})
    assert is_iterable(range(10))
    assert not is_iterable(1)


# Generated at 2022-06-22 21:22:39.443159
# Unit test for function count
def test_count():
    assert count(range(10)) == {0: 1, 1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 1, 7: 1, 8: 1, 9: 1}
    assert count([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == {0: 2, 1: 2, 2: 2, 3: 2, 4: 2, 5: 2, 6: 2, 7: 2, 8: 2, 9: 2}



# Generated at 2022-06-22 21:22:47.886570
# Unit test for function is_string
def test_is_string():
    # test for strings
    assert is_string(u"a")
    assert is_string("a")
    assert is_string(u"")
    assert is_string("")
    assert is_string(u"aa")
    assert is_string("aa")
    # test for non-strings
    assert not is_string({"a": "a"})
    assert not is_string(["a"])
    assert not is_string(1)
    assert not is_string([1])
    assert not is_string(None)
    # test for is_iterable
    assert is_iterable(["a"])
    assert not is_iterable(1)
    assert is_iterable({"a": "a"})
    assert is_iterable([1])
    assert is_iterable(None)

# Generated at 2022-06-22 21:22:58.449486
# Unit test for function is_string
def test_is_string():
    assert is_string("")
    assert is_string("foo")
    assert is_string("foo\n")
    assert is_string("\tfoo\n")
    assert is_string("fóo")
    assert not is_string([])
    assert not is_string((""))
    assert not is_string(())
    assert not is_string({})
    assert not is_string(set())
    assert not is_string(frozenset())
    assert not is_string(False)
    assert not is_string(None)
    assert not is_string(42)
    assert not is_string(u'\u2603')
    assert not is_string(bytearray(b'foo'))
    assert not is_string(memoryview(b'foo'))



# Generated at 2022-06-22 21:23:02.530480
# Unit test for function is_string
def test_is_string():
    if not is_string('string'):
        fail("Failed test_is_string()")
    if not is_string(b'bytes'):
        fail("Failed test_is_string()")
    if is_string([]):
        fail("Failed test_is_string()")



# Generated at 2022-06-22 21:23:05.761260
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d1 = ImmutableDict({'a':  1, 'b':  2})
    d2 = d1.difference(['a'])
    assert d2 == {'b': 2}
    d3 = ImmutableDict()
    d4 = d3.difference(['a'])
    assert d3 == d4



# Generated at 2022-06-22 21:23:08.410110
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    given_dict = {'a': 1, 'b': 2, 'c': 3}
    immut_dict = ImmutableDict(given_dict)
    assert immut_dict == given_dict
    assert immut_dict['a'] == 1


# Generated at 2022-06-22 21:23:11.794575
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    dict_test = ImmutableDict({'key1':'value1', 'key2':'value2', 'key3':'value3'})
    assert (len(dict_test) == 3)

# Generated at 2022-06-22 21:23:20.310031
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():        # pylint: disable=invalid-name
    """
    Test that the method __repr__ returns the correct representation of the object.
    Should raise Exception otherwise.
    :return:
    """
    idict = ImmutableDict({"a":1, "b":2})
    result = repr(idict)
    if result != 'ImmutableDict({\'a\': 1, \'b\': 2})':
        raise Exception("The method __repr__ of class ImmutableDict does not return the correct representation of the object")


# Generated at 2022-06-22 21:23:30.223000
# Unit test for function is_sequence
def test_is_sequence():
    sequences = [
        (1, 2, 3),
        u'abcd',
        [1, 2, 3],
        {'a': 'b'},
        (1, [2, 3], {'a': 'b'}),
        {'a': 'b', 'c': [1, 2, 3]},
    ]
    non_sequences = [
        1,
        {1, 2, 3},
        True,
        None,
        object(),
    ]

    # Strings are not sequences by default
    for seq in sequences:
        assert is_sequence(seq) is True
        assert is_sequence(seq, True) is True

    # Strings are sequences when include_string is True
    for seq in sequences + non_sequences:
        assert is_sequence(seq, True) is True


# Generated at 2022-06-22 21:23:38.932869
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # Test single key
    orig = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    diff = orig.difference(['a'])
    assert list(diff.keys()) == ['b', 'c']

    # Test multiple keys
    diff = orig.difference(['a', 'b'])
    assert list(diff.keys()) == ['c']

    # Test non-existing keys
    diff = orig.difference(['a', 'b', 'd'])
    assert list(diff.keys()) == ['c']

    # Test empty keys
    diff = orig.difference([])
    assert list(diff.keys()) == ['a', 'b', 'c']

    # Test non-iterable keys

# Generated at 2022-06-22 21:23:45.905329
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable(xrange(10))
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable({'func': True, 'args': False})
    assert not is_iterable('abc')
    assert not is_iterable(1)
    assert not is_iterable(None)
    assert is_iterable('abc', True)
    assert is_iterable(1, True)
    assert is_iterable(None, True)



# Generated at 2022-06-22 21:23:54.369477
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable(()) is True
    assert is_iterable({}) is True
    assert is_iterable(set()) is True
    assert is_iterable('string') is True
    assert is_iterable(u'unicode string') is True
    assert is_iterable(b'bytes string') is True
    assert is_iterable(range(10)) is True
    assert is_iterable(x for x in range(10)) is True
    assert is_iterable(42) is False
    assert is_iterable(True) is False


# Generated at 2022-06-22 21:24:01.340345
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = d1.union({'c': 3, 'a': 4})

    # Check d2 has right value for key 'a'
    assert d2['a'] == 4

    # Check d2 has all keys from d1
    assert set(d2.keys()) == set(d1.keys()).union(set(['c']))



# Generated at 2022-06-22 21:24:11.100560
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 'a', 'b': 'b'})
    d2 = ImmutableDict({'a': 'a', 'b': 'b'})
    d3 = ImmutableDict({'a': 'a', 'c': 'c'})

    assert d1 == d2
    assert not d1 == d3
    assert d1 != d3
    assert not d1 != d2
    assert d1 == {'a': 'a', 'b': 'b'}
    assert not d1 == {'a': 'a', 'c': 'c'}
    assert not d1 == 'a'

# Generated at 2022-06-22 21:24:20.940700
# Unit test for function is_sequence
def test_is_sequence():
    # All sequences should be detected as sequences
    assert is_sequence([1, 2, 3, 4])
    assert is_sequence((1, 2, 3, 4))
    assert is_sequence(set())
    assert is_sequence(frozenset())
    assert is_sequence("abcdefg")
    assert is_sequence(("a", "b", "c"))
    assert is_sequence(("a", "b", "c", ("d", "e")))
    # By default is_sequence should not return true for strings
    assert not is_sequence("abcdefg", include_strings=False)
    # But if you explicitly put include_strings=True, then strings are also considered sequences
    assert is_sequence("abcdefg", include_strings=True)
    assert is_sequence(text_type("abcdefg"))

# Unit test

# Generated at 2022-06-22 21:24:24.412649
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    data = ImmutableDict({'foo': 1, 'bar': 2, 'baz': 3})
    result = data.difference(('bar', 'baz'))
    assert result == {'foo': 1}


# Generated at 2022-06-22 21:24:26.461520
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict({'x': 1, 'y': 2})
    assert set(iter(d)) == set(['y', 'x'])


# Generated at 2022-06-22 21:24:37.453654
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d1 = ImmutableDict({'a':1, 'b':2})
    d2 = ImmutableDict({'a':1, 'b':2})
    d3 = ImmutableDict({'a':1, 'b':3})

    assert hash(d1) == hash(d2)
    assert hash(d1) != hash(d3)

    d4 = ImmutableDict(a=1, b=2)
    d5 = ImmutableDict(b=2, a=1)

    assert hash(d4) == hash(d5)
    assert hash(d1) == hash(d4)


# Generated at 2022-06-22 21:24:43.031627
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    mydict = ImmutableDict({'a': 1, 'b': 2})
    newdict = mydict.union({'c': 3, 'b': 'b'})
    assert(len(newdict) == 3)
    assert(newdict['c'] == 3)
    assert(newdict['b'] == 'b')
    assert(newdict['a'] == 1)


# Generated at 2022-06-22 21:24:48.219500
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    # Initialize a ImmutableDict
    test_ImmutableDict= ImmutableDict(a=1, b=2, c=3, d=4)

    # Verify the ImmutableDict contains four elements
    assert len(test_ImmutableDict) == 4


# Generated at 2022-06-22 21:24:58.100242
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    '''
    >>> test_ImmutableDict_union()
    '''
    assert ImmutableDict({1: 'one'}).union({2: 'two'}) == ImmutableDict({1: 'one', 2: 'two'})
    assert ImmutableDict({1: 'one'}).union({1: 'eins'}) == ImmutableDict({1: 'eins'})
    assert ImmutableDict({1: 'one', 2: 'two'}).union({1: 'eins'}) == ImmutableDict({1: 'eins', 2: 'two'})


# Generated at 2022-06-22 21:25:05.444937
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    union = {'a': 'a', 'b': 'b'}
    union_test = ImmutableDict({'a': 'a'}).union({'b': 'b'})
    assert union == union_test
    union_test_2 = ImmutableDict({'a': 'a'}).union({'a': 'c'})
    union_2 = {'a': 'c', 'b': 'b'}
    assert union_2 != union_test_2


# Generated at 2022-06-22 21:25:09.292261
# Unit test for function is_string
def test_is_string():
    class TestString(text_type):
        pass

    class TestSequence(Sequence):
        pass

    seq_types = (text_type, binary_type, TestString, TestSequence)

    for seq in seq_types:
        assert not is_string(seq)



# Generated at 2022-06-22 21:25:18.705925
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Unit test for ImmutableDict().difference()
    """
    import sys
    import unittest

    if sys.version_info[0] == 2:
        class TestPython2(unittest.TestCase):
            """
            Unit test class for Python 2.
            """
            def test_ImmutableDict_difference(self):
                """
                Check that ImmutableDict().difference() removes all keys from the
                original ImmutableDict
                """
                test_dict = ImmutableDict({1: "one", 2: "two", 3: "three"})

                result_dict = test_dict.difference([1, 2])

                self.assertEqual(result_dict, ImmutableDict({3: "three"}), "Incorrect difference")


# Generated at 2022-06-22 21:25:25.840907
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    assert ImmutableDict().union({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}).union({'a': 2}) == ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}).union({'b': 2}) == ImmutableDict({'a': 1, 'b': 2})


# Generated at 2022-06-22 21:25:31.476784
# Unit test for function count
def test_count():
    seq1 = [1, 2, 3, 1, 2, 1]
    seq2 = [1]
    seq3 = []
    assert count(seq1) == {'1': 3, '2': 2, '3': 1}
    assert count(seq2) == {'1': 1}
    assert count(seq3) == {}



# Generated at 2022-06-22 21:25:39.941960
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    """Unit test for method __iter__ of class ImmutableDict."""
    result = ImmutableDict()
    result['key1'] = 'value1'
    result['key2'] = 'value2'
    result['key3'] = 'value3'
    result_keys = set({'key1', 'key2', 'key3'})
    result_keys_iter = set(result)
    if not result_keys == result_keys_iter :
        raise Exception('The method __iter__ of class ImmutableDict does not work.')


# Generated at 2022-06-22 21:25:45.504665
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """
    Test method __len__ of class ImmutableDict
    """
    test_dict_1 = ImmutableDict(dict(key1=1, key2=2, key3=3))
    assert len(test_dict_1) == 3

    test_dict_2 = ImmutableDict()
    assert len(test_dict_2) == 0



# Generated at 2022-06-22 21:25:53.166001
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    overriding_mapping = {'b': 99, 'd': 4}
    new = original.union(overriding_mapping)
    assert new.get('a', None) == 1
    assert new.get('b', None) == 99
    assert new.get('c', None) == 3
    assert new.get('d', None) == 4


# Generated at 2022-06-22 21:26:05.076305
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Method __eq__ of class ImmutableDict"""

    import pytest

    a = ImmutableDict()
    b = ImmutableDict()
    assert a.__eq__(b) is True

    a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    b = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert a.__eq__(b) is True

    a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    b = {'b': 2, 'c': 3, 'a': 1}
    assert a.__eq__(b) is True

    a = ImmutableDict({'a': 1})
    b = ImmutableDict({'a': 2})
    assert a

# Generated at 2022-06-22 21:26:14.098056
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """Verify ImmutableDict difference method works as expected.

    Actual usage is rare, so no need to have it in the main module.
    """
    original_dict = ImmutableDict({'a': 'one', 'b': 'two', 'c': 'three'})
    new_dict = original_dict.difference(['a', 'c'])
    assert 2 == len(new_dict)
    assert 'one' != new_dict['a']
    assert 'two' == new_dict['b']
    assert 'three' != new_dict['c']



# Generated at 2022-06-22 21:26:17.134493
# Unit test for function is_string
def test_is_string():
    assert is_string('a') is True
    assert is_string(u'a') is True
    assert is_string(['a']) is False
    assert is_string(()) is False


# Generated at 2022-06-22 21:26:28.065399
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Test to verify __hash__ of ImmutableDict"""
    # Test original value
    original = ImmutableDict({'hash_test': True, 'does_not_alter_hash': True})
    assert hash(original)

    # Test for if number of keys in the ImmutableDict is changed
    altered = ImmutableDict({'hash_test': False, 'does_not_alter_hash': True})
    assert hash(original) != hash(altered)

    # Test for if the values of the keys in the ImmutableDict are changed
    altered = ImmutableDict({'hash_test': True, 'does_not_alter_hash': False})
    assert hash(original) != hash(altered)

    # Test for if the relative order of keys in the ImmutableDict is changed

# Generated at 2022-06-22 21:26:38.108345
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence((1, 2, 3))
    assert is_sequence([1, 2, 3])
    assert not is_sequence((i for i in range(5)))
    assert not is_sequence((), include_strings=True)
    assert not is_sequence([], include_strings=True)
    assert not is_sequence([1, 2, 3], include_strings=True)
    assert not is_sequence((1, 2, 3), include_strings=True)
    assert is_sequence('string', include_strings=True)
    assert is_sequence(binary_type('string'), include_strings=True)



# Generated at 2022-06-22 21:26:41.640355
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Test for method __repr__ of class ImmutableDict"""
    d = ImmutableDict(a=1, b=2)
    assert repr(d) == "ImmutableDict({'a': 1, 'b': 2})"


# Generated at 2022-06-22 21:26:47.536327
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    mydict = ImmutableDict({'A': 1, 'B': 2})
    assert mydict.union({'a': 3, 'b': 4}) == ImmutableDict({'A': 1, 'B': 2, 'a': 3, 'b': 4})
    assert mydict.union({'A': 3, 'b': 4}) == ImmutableDict({'A': 3, 'B': 2, 'b': 4})
    assert mydict.union({'A': 3, 'b': 4, 'C': 5}) == ImmutableDict({'A': 3, 'B': 2, 'b': 4, 'C': 5})



# Generated at 2022-06-22 21:26:53.711133
# Unit test for function count
def test_count():
    """Unit test for count function"""
    seq1 = 'abracadabra'
    seq2 = (1, 2, 3, 1, 3, 3, 1)

    assert count(seq1) == {'a': 5, 'b': 2, 'r': 2, 'c': 1, 'd': 1}
    assert count(seq2) == {1: 3, 2: 1, 3: 3}
    try:
        count(120)
    except Exception:
        pass
    else:
        assert False



# Generated at 2022-06-22 21:27:03.143294
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # Test difference with a sequence of keys to be removed
    original = ImmutableDict({'k1': 'v1', 'k2': 'v2', 'k3': 'v3'})
    removed_keys = ('k3', 'k4')
    new_dict = original.difference(removed_keys)
    assert new_dict == ImmutableDict({'k1': 'v1', 'k2': 'v2'})
    # Test difference with a dictionary of keys to be removed
    removed_keys = {'k4': 'v4', 'k1': 'v1'}
    new_dict = original.difference(removed_keys)
    assert new_dict == ImmutableDict({'k2': 'v2', 'k3': 'v3'})
    # Test difference with a set of keys to be

# Generated at 2022-06-22 21:27:04.888380
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    assert ImmutableDict({'a': 1})['a'] == 1


# Generated at 2022-06-22 21:27:16.354971
# Unit test for function is_sequence
def test_is_sequence():
    """Test ``is_sequence`` function."""
    assert is_sequence([])
    assert is_sequence(())
    assert not is_sequence(set())
    assert is_sequence({})
    assert is_sequence(object())
    assert is_sequence(1)
    assert is_sequence(object())
    assert not is_sequence("yaml")
    assert is_sequence("yaml", include_strings=True)
    assert not is_sequence(b"yaml")
    assert is_sequence(b"yaml", include_strings=True)
    assert not is_sequence(ImmutableDict())
    # test with a class that has an __iter__ method
    class IterClass:
        def __iter__(self):
            pass
    assert not is_sequence(IterClass())
    # test with a class that has a next method


# Generated at 2022-06-22 21:27:21.119935
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    first = ImmutableDict({"a": 1, "b": 2})
    second = {"c": 3, "b": 4}
    result = first.union(second)
    assert result == {"a": 1, "b": 4, "c": 3}



# Generated at 2022-06-22 21:27:32.539293
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict({"a": 1, "b": 2, "c": 3})
    assert(original.difference([]) == original)

    original = ImmutableDict({"a": 1, "b": 2, "c": 3})
    assert(original.difference(["a", "b"]) == ImmutableDict({"c": 3}))

    original = ImmutableDict({"a": 1, "b": 2, "c": 3})
    assert(original.difference(["a", "b", "c"]) == ImmutableDict({}))

    original = ImmutableDict({"a": 1, "b": 2, "c": 3})
    assert(original.difference(["b", "c"]) == ImmutableDict({"a": 1}))

# Generated at 2022-06-22 21:27:34.918689
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    dict_orig = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert dict_orig['b'] == 2


# Generated at 2022-06-22 21:27:46.250587
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    i_dict = ImmutableDict({'a': '1', 'b': '2', 'c': '3'})
    remove_keys = ('a', 'b')
    i_dict_result = i_dict.difference(remove_keys)
    assert i_dict_result == ImmutableDict({'c': '3'})
    assert i_dict.difference(ImmutableDict(a=1, b=2)) == ImmutableDict({'c': '3'})
    assert i_dict.difference(MutableMapping(a=1, b=2)) == ImmutableDict({'c': '3'})
    assert i_dict.difference(dict(a=1, b=2)) == ImmutableDict({'c': '3'})

# Generated at 2022-06-22 21:27:51.268689
# Unit test for function is_string
def test_is_string():
    assert is_string(u'ansible')
    assert is_string(u'ansible'.encode('utf-8'))
    assert not is_string(dict())
    assert not is_string([u'ansible'])
    assert not is_string(set(['ansible']))
    assert not is_string(1)


# Generated at 2022-06-22 21:28:01.060738
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """ Unit test for method __hash__ of class ImmutableDict. """

    # Test that two ImmutableDicts with the same items return the same hash
    test_dict_1 = ImmutableDict({'a': 1, 'b': '2'})
    test_dict_2 = ImmutableDict({'a': 1, 'b': '2'})
    assert hash(test_dict_1) == hash(test_dict_2)

    # Test that two ImmutableDicts with different items return a different hash
    test_dict_3 = ImmutableDict({'x': 1, 'y': '2'})
    assert hash(test_dict_1) != hash(test_dict_3)

    # Test that an ImmutableDict and a regular dict with the same items return the same hash

# Generated at 2022-06-22 21:28:10.054895
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """The value for the key 'one' is used for the comparison"""
    d1 = ImmutableDict({'one': 1, 'two': 2})
    assert d1 == ImmutableDict({'one': 1, 'two': 2})
    assert d1 == ImmutableDict({'one': 1, 'two': 2, 'three': 3})
    assert d1 == ImmutableDict({'two': 2, 'one': 1})
    assert not d1 == ImmutableDict({'two': 2, 'one': 2})



# Generated at 2022-06-22 21:28:21.964232
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict()
    dict2 = ImmutableDict()
    assert dict1 == dict2
    dict1 = ImmutableDict([('key1', 'val1'), ('key2', 'val2')])
    dict2 = ImmutableDict({'key1': 'val1', 'key2': 'val2'})
    assert dict1 == dict2
    dict2 = ImmutableDict({'key2': 'val2', 'key1': 'val1'})
    assert dict1 == dict2
    dict2 = ImmutableDict({'key1': 'val1', 'key2': 'val22'})
    assert dict1 != dict2
    dict2 = ImmutableDict({'key1': 'val1', 'key2': 'val2', 'key3': 'val3'})
    assert dict1

# Generated at 2022-06-22 21:28:32.300569
# Unit test for function is_sequence
def test_is_sequence():
    from ansible.module_utils.six.moves import xrange as range
    import ansible.module_utils.basic

    # Test cases
    seq_like = (((), tuple()), ([], list()), set(),
                range(0), xrange(0), {},
                ansible.module_utils.basic.AnsibleVaultEncryptedUnicode('vaulted'),
                ansible.module_utils.basic.AnsibleVaultEncryptedUnicode(''),
                ansible.module_utils.basic.AnsibleVaultEncryptedUnicode(b'vaulted'),
                ansible.module_utils.basic.AnsibleVaultEncryptedUnicode(b''),
                )

# Generated at 2022-06-22 21:28:38.531383
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # Test that if ImmutableDict instances have the same keys-values pairs,
    # their hash is the same
    immutable_dict_instance_1 = ImmutableDict({'key': 'value'})
    immutable_dict_instance_2 = ImmutableDict({'key': 'value'})
    assert hash(immutable_dict_instance_1) == hash(immutable_dict_instance_2)



# Generated at 2022-06-22 21:28:42.398032
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict({'a': 1})
    expected = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert original.union({'b': 2, 'c': 3}) == expected


# Generated at 2022-06-22 21:28:46.125912
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert is_string(u'foo')
    assert not is_string(False)
    assert not is_string(1)
    assert not is_string([])



# Generated at 2022-06-22 21:28:56.644731
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(a=1, b=2)
    assert d1 == d2
    assert d2 == d1
    d3 = ImmutableDict(a=1, b=2, c=3)
    assert d1 != d3
    assert d2 != d3
    assert d3 != d1
    assert d3 != d2
    d4 = MutableMapping(a=1, b=2)
    assert d1 != d4
    # d4 != d1 makes sense only if d4 is hashable
    assert d4 != d1
    # d4 is hashable, so
    d4 = ImmutableDict(a=1, b=2)
    assert d1 == d4
    assert d4 == d

# Generated at 2022-06-22 21:28:59.392115
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict(dict(a='b'))) == 1
    assert len(ImmutableDict(dict(a='b', c='d'))) == 2


# Generated at 2022-06-22 21:29:03.010926
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict(key_1=1, key_2=2)) == 2
    try:
        len(ImmutableDict())
    except:
        assert False


# Generated at 2022-06-22 21:29:07.598099
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    # create an immutable dict
    immutable_dict = ImmutableDict({'key1': 'value1', 'key2': 'value2'})

    # check __iter__()
    assert iter(immutable_dict) == iter({'key1': 'value1', 'key2': 'value2'})



# Generated at 2022-06-22 21:29:20.306499
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    # pylint: disable=protected-access,unused-variable
    assert {'a': 1, 'b': 2} == ImmutableDict({'a': 1}, b=2)._store
    assert {'a': 1, 'b': 2} == ImmutableDict([('a', 1)], b=2)._store
    assert {'a': 1, 'b': 2, 'c': 3} == ImmutableDict({'a': 1}, b=2, c=3)._store

    # Test union
    assert ImmutableDict({'a': 1}).union({'a': 2, 'b': 3}) == ImmutableDict({'a': 2, 'b': 3})

# Generated at 2022-06-22 21:29:22.626055
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict({'a': 1})
    assert repr(d) == "ImmutableDict({'a': 1})"


# Generated at 2022-06-22 21:29:26.050615
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    testDict = ImmutableDict({"a":1,"b":2})
    assert testDict["a"] == 1


# Generated at 2022-06-22 21:29:37.511345
# Unit test for function is_iterable
def test_is_iterable():
    # Something that is not iterable
    assert not is_iterable(1)

    # A string, not iterable by default
    assert not is_iterable('a')
    assert is_iterable('a', True)
    assert is_iterable(u'a')
    assert is_iterable(b'a')
    assert is_iterable('a'.encode('utf-8'))

    # A list, iterable
    assert is_iterable([])
    assert is_iterable([1, 2, 3])

    # A tuple, iterable
    assert is_iterable(())
    assert is_iterable((1, 2, 3))

    # A generator, iterable
    assert is_iterable(xrange(1, 3))

# Generated at 2022-06-22 21:29:46.977023
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable(set())
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable((1, 2, 3))
    assert is_iterable(xrange(3))
    assert is_iterable(dict())
    assert is_iterable(dict(one=1, two=2, three=3))
    assert not is_iterable(3)
    assert not is_iterable(object())


# Generated at 2022-06-22 21:29:54.801500
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    a = ImmutableDict()
    assert True is True, "Empty dict initialized"

    b = ImmutableDict([('key1', 'value1'), ('key2', 'value2')])
    assert 'value1' == b['key1'], "Dict from list of tuples initialized"

    c = ImmutableDict(key1='value1', key2='value2')
    assert 'value1' == c['key1'], "Dict from keyword args initialized"

    d = ImmutableDict(c)
    assert 'value1' == d['key1'], "Dict copied initialized"



# Generated at 2022-06-22 21:29:57.992908
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    original = ImmutableDict({'a': 1, 'b': 2})
    assert original['a'] == 1
    assert original['b'] == 2

