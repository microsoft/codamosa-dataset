

# Generated at 2022-06-22 21:20:06.376581
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence((1, 2, 3)) is True
    assert is_sequence([1, 2, 3]) is True
    assert is_sequence(set([1, 2, 3])) is True
    assert is_sequence(u'text') is False
    assert is_sequence(b'bytes') is False
    assert is_sequence(u'text', include_strings=True) is True
    assert is_sequence(b'bytes', include_strings=True) is True



# Generated at 2022-06-22 21:20:17.928160
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # === Test cases ===
    # --- Test case when __eq__ compares to dictionary ---
    # Test case: dictionaries with equal keys and values
    test_dict = {'key': 'value'}
    test_immutable_dict = ImmutableDict({"key": "value"})
    assert test_immutable_dict.__eq__(test_dict)
    # Test case: dictionaries with equal keys, but not equal values
    test_dict = {'key': 'value'}
    test_immutable_dict = ImmutableDict({"key": "wrong value"})
    assert not test_immutable_dict.__eq__(test_dict)
    # Test case: dictionaries with equal values, but not equal keys
    test_dict = {'key': 'value'}
    test_immutable_dict = ImmutableD

# Generated at 2022-06-22 21:20:20.286396
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    # Test a new ImmutableDict
    my_dict = ImmutableDict({'a': 'a', 'b': 'b'})
    assert len(my_dict) == 2



# Generated at 2022-06-22 21:20:23.402320
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    result = [i for i in test_dict]
    assert(result == ['a', 'b', 'c'])


# Generated at 2022-06-22 21:20:33.712680
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    from ansible.module_utils.common._collections_compat import ImmutableDict
    d = {"a": "A"}
    assert ImmutableDict(d) == ImmutableDict(d) 
    assert ImmutableDict(d) == d
    assert ImmutableDict(d) != {}
    assert ImmutableDict(d).__repr__() == "ImmutableDict({'a': 'A'})"
    d1 = {"a": "A", "b": "B"}
    assert ImmutableDict(d1) == ImmutableDict(d1) 
    assert ImmutableDict(d1) == d1
    assert ImmutableDict(d1) != d

# Generated at 2022-06-22 21:20:39.851922
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({"a": 1, "b": 2})

    assert a == ImmutableDict({"a": 1, "b": 2})  # Dicts are equal
    assert a == {"a": 1, "b": 2}  # Dicts are equal
    assert a != {"a": 1, "b": 2, "c": 3}  # Not equal
    assert a != ("a", "b")  # Not equal



# Generated at 2022-06-22 21:20:41.821034
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    assert list(ImmutableDict(a='a', c='c')) == ['a', 'c']
    assert list(ImmutableDict(ImmutableDict(a='a'), b='b')) == ['a', 'b']


# Generated at 2022-06-22 21:20:43.613374
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})


# Generated at 2022-06-22 21:20:52.620341
# Unit test for function count
def test_count():
    c = count([1,2,3,6,7,6,3,6,7,6,3,6,7,6,3,6,7,6,3,6,7,6,3,6,7,6,3,6,7,6,3,6,7,6,3,6,7,6,3])

    assert c[6] == 14
    assert c[1] == 1
    assert c[2] == 1
    assert c[3] == 4
    assert c[7] == 7


# Generated at 2022-06-22 21:20:57.353594
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    x = ImmutableDict({'a': 1, 'b': 2})
    y = {'b': 3, 'c': 4}
    z = x.union(y)
    assert z == ImmutableDict({'a': 1, 'b': 3, 'c': 4})



# Generated at 2022-06-22 21:21:05.944910
# Unit test for function is_sequence
def test_is_sequence():
    # Check that string is not a sequence
    assert not is_sequence('string')
    assert not is_sequence(u'string')

    # Check that bytes is not a sequence
    assert not is_sequence(b'string')

    # Check that lists are sequences, even empty ones
    assert is_sequence([])
    assert is_sequence([1, 2, 3])
    assert is_sequence([None])
    assert is_sequence([[]])

    # Check that tuples are sequences
    assert is_sequence(tuple())
    assert is_sequence((1, 2, 3))
    assert is_sequence((None,))
    assert is_sequence(((),))

    # Check that strings are sequences only when requested
    assert is_sequence('string', include_strings=True)

# Generated at 2022-06-22 21:21:08.973031
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert ImmutableDict({'a': 1, 'b': 2}) == eval(repr(ImmutableDict({'a': 1, 'b': 2})))

# Generated at 2022-06-22 21:21:12.887353
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    # Test: Check if __len__ method correctly calculates the length of the dictionary
    test_dict = ImmutableDict({'a': 1, 'b': 2})
    assert len(test_dict) == 2



# Generated at 2022-06-22 21:21:20.411678
# Unit test for function count
def test_count():
    """
    Basic test for function count
    :return:
    """
    from copy import deepcopy
    from ansible.module_utils.common.collections import count
    from numbers import Number

    assert isinstance(count([1, 2, 1, 2, 3]), type({}))
    res = deepcopy(count([1, 2, 1, 2, 3]))
    for k, v in res.items():
        assert isinstance(k, Number)
        assert isinstance(v, Number)



# Generated at 2022-06-22 21:21:26.858544
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    a = ImmutableDict({1: 2, 3: 4})
    b = ImmutableDict({1: 2, 3: 4})
    c = ImmutableDict({3: 4, 1: 2})
    d = ImmutableDict({1: 3, 3: 4})
    assert hash(a) == hash(b)
    assert hash(a) == hash(c)
    assert hash(a) != hash(d)



# Generated at 2022-06-22 21:21:30.663115
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    immutable_dict = ImmutableDict({'a': 1, 'b': 2})
    assert immutable_dict.union({'c': 3, 'd': 4}) == \
        ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})



# Generated at 2022-06-22 21:21:36.403812
# Unit test for function is_iterable
def test_is_iterable():
    # pylint: disable=bad-whitespace

    assert is_iterable(True)              == False
    assert is_iterable(10)                == False
    assert is_iterable(10.10)             == False
    assert is_iterable("Hello")           == False
    assert is_iterable("Hello", True)     == True
    assert is_iterable(b"Hello")          == False
    assert is_iterable(b"Hello", True)    == True
    assert is_iterable([1, 2, 3])         == True
    assert is_iterable((1, 2, 3))         == True
    assert is_iterable({'one': 1, 'two': 2}) == True

    # pylint: enable=bad-whitespace


# Generated at 2022-06-22 21:21:44.823358
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(tuple())
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(frozenset())
    assert is_iterable(xrange(0))
    assert is_iterable((x for x in []))
    assert is_iterable(ImmutableDict())

    assert not is_iterable(1)
    assert not is_iterable(None)
    assert not is_iterable(object)
    assert not is_iterable(object())
    assert not is_iterable(...)



# Generated at 2022-06-22 21:21:56.309961
# Unit test for function count
def test_count():
    assert count([]) == {}
    assert count([1]) == {1: 1}
    assert count([1, 1, 2, 3, 4, 4, 4]) == {1: 2, 2: 1, 3: 1, 4: 3}
    assert count(['string']) == {'string': 1}
    assert count(['string', 'string', 'string']) == {'string': 3}
    try:
        count('string')
    except Exception as e:
        if not isinstance(e, Exception):
            raise
    try:
        count(None)
    except Exception as e:
        if not isinstance(e, Exception):
            raise
    try:
        count(1)
    except Exception as e:
        if not isinstance(e, Exception):
            raise



# Generated at 2022-06-22 21:22:06.152974
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable((None,))
    assert is_iterable({})
    assert is_iterable({None: None})
    assert is_iterable(set())
    assert is_iterable(set([None]))
    assert is_iterable(xrange(0))
    assert is_iterable(xrange(1))
    assert is_iterable(xrange(2))
    assert is_iterable(xrange(0, 1, 2))
    assert is_iterable((i for i in xrange(0)))
    assert is_iterable((i for i in xrange(1)))
    assert is_iterable((i for i in xrange(2)))

# Generated at 2022-06-22 21:22:16.900631
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    original = ImmutableDict(one=1, two=2, three=3)
    overriding = {'four': 4, 'five': 5, 'six': 6}
    overriding_dict = ImmutableDict(overriding)
    overriding_list = [('four', 4), ('five', 5), ('six', 6)]

    assert original['two'] == 2, 'Value of key "two" mismatches'
    assert original.union(overriding)['six'] == 6, 'Value of key "six" mismatches in merging of dict'
    assert original.union(overriding_dict)['six'] == 6, 'Value of key "six" mismatches in merging of ImmutableDict'
    assert original.union(overriding_list)['six'] == 6, 'Value of key "six" mismatches in merging of sequence'

   

# Generated at 2022-06-22 21:22:23.949774
# Unit test for function is_sequence
def test_is_sequence():
    assert not is_sequence("foo")
    assert not is_sequence(123)
    assert not is_sequence({})
    assert not is_sequence(None)

    assert is_sequence([])
    assert is_sequence(())
    assert is_sequence({}, include_strings=True)
    assert is_sequence([], include_strings=True)
    assert is_sequence(("asda", "asd"), include_strings=True)



# Generated at 2022-06-22 21:22:30.181218
# Unit test for function is_string
def test_is_string():
    assert is_string(b'bytes')
    assert is_string('text')
    assert is_string(u'unicode')
    assert not is_string(None)
    assert not is_string(u'unicode'.encode('utf-8'))
    assert not is_string(('tuple', 'of', 'strings'))
    assert not is_string(['list', 'of', 'strings'])
    assert not is_string({'dict': 'of', 'strings': ['list', 'of', 'strings']})


# Generated at 2022-06-22 21:22:37.856577
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence((1, 2, 3))
    assert not is_sequence([1, 2, 3])
    assert is_sequence(set((1, 2, 3)))
    assert not is_sequence(set([1, 2, 3]))
    assert is_sequence({'a': 1, 'b': 2})
    assert not is_sequence({'a': [1], 'b': (2,)})
    assert not is_sequence(1)
    assert not is_sequence(range(3))



# Generated at 2022-06-22 21:22:42.022687
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    assert ImmutableDict({'a': 1, 'b': 2}).union({'b': 3, 'c': 4}) == \
        ImmutableDict({'a': 1, 'b': 3, 'c': 4})


# Generated at 2022-06-22 21:22:46.373693
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    orig = ImmutableDict(base=7, foo=42, bar=12)
    removed_foo_bar = orig.difference(['foo', 'bar'])
    assert 'foo' not in removed_foo_bar
    assert 'bar' not in removed_foo_bar
    assert 'base' in removed_foo_bar


# Generated at 2022-06-22 21:22:53.019212
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_dict = {
        'name': 'Ralph',
        'age': 45,
        'address': '123 Elm St.',
        'children': {
            'Robert': 12,
            'Donna': 14
        },
        'favorite colors': [
            'blue',
            'green',
            'yellow'
        ],
        'pet': 'cat'
    }

    imm_test_dict = ImmutableDict(test_dict)
    assert imm_test_dict == ImmutableDict(test_dict)
    assert imm_test_dict.difference([]) == ImmutableDict(test_dict)
    assert imm_test_dict.difference(['pet']) == ImmutableDict(test_dict.copy().pop('pet'))
    assert imm_test_dict.difference(('pet',))

# Generated at 2022-06-22 21:23:00.325070
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert is_sequence((1, 2, 3))
    assert is_sequence(range(10))
    assert is_sequence('')
    assert not is_sequence('', include_strings=True)
    assert is_sequence('abc')
    assert not is_sequence('abc', include_strings=True)
    assert not is_sequence(set())
    assert not is_sequence(dict())
    assert not is_sequence(None)



# Generated at 2022-06-22 21:23:04.357754
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    test_dict = ImmutableDict({'key1': 'value1'})
    test_dict = test_dict.union({'key2': 'value2'})
    if not isinstance(test_dict, ImmutableDict):
        raise Exception('Failed test for method union of class ImmutableDict')


# Generated at 2022-06-22 21:23:10.635945
# Unit test for function count
def test_count():
    test_list = ['a', 'b', 'a', 'a', 'c', 'c', 'a', 'c', 'c']
    cnt = count(test_list)
    assert cnt == {'a': 4, 'b': 1, 'c': 4}



# Generated at 2022-06-22 21:23:16.572969
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    source_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert source_dict['a'] == 1
    assert source_dict['b'] == 2
    assert source_dict['c'] == 3


# Generated at 2022-06-22 21:23:28.229818
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    m = {'x': 'X', 'y': 'Y'}
    items = ('x', 'y')
    d = ImmutableDict.fromkeys(items)
    result = d.difference(items)
    assert result == {}
    d = ImmutableDict(a='A', b='B')
    assert isinstance(d, Mapping)

    # Test with a single argument
    result = d.difference('a')
    assert isinstance(result, ImmutableDict)
    assert result == ImmutableDict(b='B')

    # Test with a list as an argument
    result = d.difference(['a'])
    assert isinstance(result, ImmutableDict)
    assert result == ImmutableDict(b='B')

    # Test with a tuple as an argument
    result = d.diff

# Generated at 2022-06-22 21:23:32.347926
# Unit test for function count
def test_count():
    assert count(['a', 'a', 'a', 'b', 'c', 'c']) == {'a': 3, 'c': 2, 'b': 1}
    assert count([1, 2, 3, 4, 5]) == {1: 1, 2: 1, 3: 1, 4: 1, 5: 1}
    assert count(['a', 'a', 'b', 'c', 'c', 1, 2, 3]) == {'a': 2, 'c': 2, 'b': 1, 1: 1, 2: 1, 3: 1}
    assert count([]) == {}



# Generated at 2022-06-22 21:23:43.425744
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a = ImmutableDict({'a': '1', 'b': '2'})
    b = ImmutableDict({'c': '3', 'd': '4'})
    assert a.union(b) == ImmutableDict({'a': '1', 'b': '2', 'c': '3', 'd': '4'})
    assert a == ImmutableDict({'a': '1', 'b': '2'})
    assert b == ImmutableDict({'c': '3', 'd': '4'})

    c = ImmutableDict({'a': '5', 'c': '6'})
    assert a.union(c) == ImmutableDict({'a': '5', 'b': '2', 'c': '6'})

# Generated at 2022-06-22 21:23:47.490895
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    # Test empty immutable dict
    immutable_dict = ImmutableDict()
    assert len(immutable_dict) == 0

    # Test len(immutable_dict) for non-empty immutable dict
    immutable_dict = ImmutableDict(a=1, b=2, c=3)
    assert len(immutable_dict) == 3



# Generated at 2022-06-22 21:23:57.664270
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():

    original = ImmutableDict({'one': 1, 'two': 2, 'three': 3})
    new = original.difference({'two'})

    assert original['two'] == 2
    assert new['two'] == 2

    original = ImmutableDict({'one': 1, 'two': 2, 'three': 3})
    new = original.difference({'four'})

    assert original['two'] == 2
    assert new['two'] == 2

    original = ImmutableDict({'one': 1, 'two': 2, 'three': 3})
    new = original.difference(['two'])

    assert original['two'] == 2
    assert new['two'] == 2

    original = ImmutableDict({'one': 1, 'two': 2, 'three': 3})

# Generated at 2022-06-22 21:24:00.467175
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    immutable_dict = ImmutableDict({'key1': 'value1'})
    assert immutable_dict['key1'] == 'value1'


# Generated at 2022-06-22 21:24:04.544557
# Unit test for function count
def test_count():
    assert count(('red', 'blue', 'red', 'green', 'blue', 'blue')) == {'red': 2, 'blue': 3, 'green': 1}



# Generated at 2022-06-22 21:24:14.506584
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    a_expected = {'key1': 'value1', 'key2': 'value2'}

    b = a.union({'key1': 'newvalue1'})
    b_expected = {'key1': 'newvalue1', 'key2': 'value2'}

    c = a.union({'key3': 'value3'})
    c_expected = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}

    d = a.union({'key1': 'newvalue1', 'key3': 'value3'})

# Generated at 2022-06-22 21:24:23.417174
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    assert hash(ImmutableDict({'a': 1, 'b': 2})) == hash(ImmutableDict({'b': 2, 'a': 1}))
    assert hash(ImmutableDict({'a': 1, 'b': 2})) == hash({'b': 2, 'a': 1})
    assert hash(ImmutableDict({'a': 1, 'b': 2})) != hash({'b': 2, 'a': 2})


# Generated at 2022-06-22 21:24:26.636551
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict({u'a': 1, u'b': 2, u'c': 3})
    assert len(d) == 3

    d2 = ImmutableDict(d)
    assert len(d) == len(d2)


# Generated at 2022-06-22 21:24:34.985992
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    """Unit test for method union of class ImmutableDict"""
    id = ImmutableDict({"a": "answer", "b": "baseball"})
    hm = {'b': 'bull', "c": "cat"}
    id_hm = id.union(hm)
    expected_id_hm = {'a': 'answer', 'b': 'bull', 'c': 'cat'}
    assert id_hm, expected_id_hm


# Generated at 2022-06-22 21:24:47.014549
# Unit test for function is_sequence
def test_is_sequence():
    # Strings are not sequences
    assert is_sequence('abc') == False
    assert is_sequence('abc', include_strings=True) == True

    # Bytes are not sequences
    foo = b"abc"
    assert is_sequence(foo) == False
    assert is_sequence(foo, include_strings=True) == True

    # Non-indexable things are not sequences
    foo = object()
    assert is_sequence(foo) == False

    # List is a sequence
    foo = [1, 2, 3]
    assert is_sequence(foo) == True
    assert is_sequence(foo, include_strings=True) == True

    # Generator is a sequence
    foo = (1 for x in range(0, 100))
    assert is_sequence(foo) == True

# Generated at 2022-06-22 21:24:59.441709
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3]) is True
    assert is_sequence((1, 2, 3)) is True
    assert is_sequence([1, 2, 3], include_strings=True) is True
    assert is_sequence((1, 2, 3), include_strings=True) is True
    assert is_sequence('abc') is False
    assert is_string('abc') is True
    assert is_sequence(range(3)) is True
    assert is_sequence(range(0), include_strings=True) is True
    assert is_sequence(dict(a=1, b=2)) is False
    assert is_sequence({'a': 1, 'b': 2}) is False
    assert is_sequence(set([1, 2, 3])) is False
    assert is_sequence(123) is False

# Generated at 2022-06-22 21:25:08.702755
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """
    Unit test to validate that the hash of an ImmutableDict is indeed a hash
    of a frozenset of its items.
    """
    import hashlib

    immutable_dict = ImmutableDict({'a': 'b', 'c': 'd'})
    assert immutable_dict.__hash__() == hash(frozenset(immutable_dict.items()))

    # Test that we can store ImmutableDicts as keys in a dict.
    d = {immutable_dict: 'value'}
    assert d[immutable_dict] == 'value'

    # Test that we can use ImmutableDicts as keys in a set.
    s = {immutable_dict}
    assert immutable_dict in s

# Generated at 2022-06-22 21:25:14.789458
# Unit test for function is_string
def test_is_string():
    assert is_string("")
    assert is_string("foo")
    assert is_string(u"")
    assert is_string(u"foo")
    assert not is_string(None)
    assert not is_string({})
    assert not is_string([])
    assert not is_string(0)
    assert not is_string(1.0)
    assert not is_string(())
    assert not is_string(object())


# Generated at 2022-06-22 21:25:22.685773
# Unit test for function is_iterable
def test_is_iterable():
    # pylint: disable=R0903
    """Unit test for function is_iterable"""
    from ansible.module_utils.common._collections_compat import defaultdict

    class TestClass(object):
        """Test class for testing is_iterable"""
        # pylint: disable=too-few-public-methods
        def __init__(self, iterable):
            self.iterable = iterable
            self.list = list(iterable)

        def __iter__(self):
            return iter(self.list)

        def __getitem__(self, item):
            return self.list.__getitem__(item)

    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iter

# Generated at 2022-06-22 21:25:25.202698
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict([('a', 1), ('b', 2)])) == 2


# Generated at 2022-06-22 21:25:27.950714
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    assert {'hello': 'world'}.__iter__() == ImmutableDict({'hello': 'world'}).__iter__()


# Generated at 2022-06-22 21:25:30.678942
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict({'a': 1, 'b': 2})
    assert len(d) == 2



# Generated at 2022-06-22 21:25:35.501837
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    assert ImmutableDict(dict(a=1, b=2))['a'] == 1
    assert ImmutableDict(dict(a=1, b=2))['b'] == 2
    try:
        ImmutableDict(dict(a=1, b=2))['c']
    except KeyError:
        pass
    else:
        assert False, 'Expected KeyError due to missing key'
    assert ImmutableDict(dict(a={'c': 3}))['a']['c'] == 3


# Generated at 2022-06-22 21:25:47.331857
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('test_string')
    assert is_iterable(['item1', 1, {'dict': 'value'}])
    assert is_iterable((1, 2, 3, 4))
    assert is_iterable({'a': 'b', 'c': 2, 'd': ['a', 'tuple']})
    assert not is_iterable(1)

    class Iterable(object):
        def __init__(self):
            self.items = list()

        def append(self, item):
            self.items.append(item)

        def __iter__(self):
            return iter(self.items)

    iterable = Iterable()
    iterable.append(1)
    iterable.append(3)
    iterable.append(4)
    assert is_iterable(iterable)

# Generated at 2022-06-22 21:25:58.320479
# Unit test for function is_sequence
def test_is_sequence():
    """
    Test cases for is_sequence.
    """
    # Python 3.3+
    try:
        from collections import abc
        MutableSequence = abc.MutableSequence
        MutableMapping = abc.MutableMapping
    except ImportError:
        # Python 2.6+
        from collections import MutableSequence, MutableMapping
    # Python 3+
    try:
        from typing import Dict
    except ImportError:
        Dict = dict
    # Python 2.6+
    from collections import OrderedDict

    # Python 2.7+
    from fractions import Fraction, Complex

    from ansible.module_utils.six import binary_type, text_type

    # A mix of different types.

# Generated at 2022-06-22 21:26:01.928787
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    dictionary = ImmutableDict(key1="value1", key2="value2")
    assert dictionary.union({"key3": "value3"}) == ImmutableDict(key1="value1", key2="value2", key3="value3")
    assert dictionary.union({"key1": "new_value1"}) == ImmutableDict(key1="new_value1", key2="value2")


# Generated at 2022-06-22 21:26:14.101244
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    # test initialization
    imd = ImmutableDict({'a': 1, 'b': 2})
    assert len(imd) == 2

    # test key/values
    assert imd['a'] == 1
    assert imd['b'] == 2

    # test equality
    assert imd == ImmutableDict({'b': 2, 'a': 1})

    # test membership
    assert 'a' in imd

    # test iteration
    items = list(imd.items())
    assert items[0] == ('a', 1)
    assert items[1] == ('b', 2)

    # test immutability
    try:
        imd['c'] = 3
        raise Exception('Exception expected')
    except TypeError:
        pass

    # test union

# Generated at 2022-06-22 21:26:21.849625
# Unit test for function is_iterable
def test_is_iterable():
    """Test the function is_iterable."""
    # List of iterables, list of non-iterables and list of strings
    iterables = [[], (), {}]
    non_iterables = [None, 1, 3.14]
    strings = ['a', b'b', u'c']

    for iterable in iterables:
        assert is_iterable(iterable) is True
    for non_iterable in non_iterables:
        assert is_iterable(non_iterable) is False
    for string in strings:
        assert is_iterable(string) is False

    # Check if strings are treated as iterables when told so
    for string in strings:
        assert is_iterable(string, include_strings=True) is True


# Generated at 2022-06-22 21:26:25.017218
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    item1 = {'a': 1, 'b': 2}
    item2 = ImmutableDict(item1)
    if len(item1) != len(item2):
        return False
    return True


# Generated at 2022-06-22 21:26:28.818707
# Unit test for function is_string
def test_is_string():
    assert is_string('x')
    assert is_string(u'x')
    assert not is_string(5)
    assert not is_string([5])
    assert not is_string([u'x'])



# Generated at 2022-06-22 21:26:31.624710
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    dict_instance = ImmutableDict({"k1": "v1", "k2": "v2"})
    assert len(dict_instance) == 2


# Generated at 2022-06-22 21:26:41.956402
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    """
    Unit test for the ImmutableDict.union method

    :return: None
    """

# Generated at 2022-06-22 21:26:46.682469
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    mapping = ImmutableDict(one=1, two=2.0, three='three', four=[4, 4, 4])
    assert mapping['one'] == 1
    assert mapping['two'] == 2.0
    assert mapping['three'] == 'three'
    assert mapping['four'] == [4, 4, 4]
    assert mapping['five'] is None


# Generated at 2022-06-22 21:26:50.694831
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict({'a': 1})) == 1
    assert len(ImmutableDict({'a': 1}, {'b': 2})) == 2


# Generated at 2022-06-22 21:26:57.441609
# Unit test for function is_sequence
def test_is_sequence():
    class TestClass():
        pass

    class TestClass2(Sequence):
        def __getitem__(self):
            raise IndexError("test exception")

    assert is_sequence(["a", "b", "c"])
    assert is_sequence("abc")
    assert not is_sequence("abc", True)
    assert is_sequence(("a", "b", "c"))
    assert is_sequence(set(["a", "b", "c"]))
    assert is_sequence(frozenset(["a", "b", "c"]))
    assert not is_sequence({"a": "b", "c": "d"})
    assert not is_sequence(TestClass)
    assert not is_sequence(TestClass())
    assert not is_sequence(TestClass2())
    assert not is_sequence(TestClass2)

# Generated at 2022-06-22 21:27:00.429660
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    # Case 1: Empty ImmutableDict
    imm = ImmutableDict()
    assert repr(imm) == 'ImmutableDict({})'

    # Case 2: ImmutableDict with 2 items
    imm = ImmutableDict({"key1": "value1", "key2": "value2"})
    assert repr(imm) == "ImmutableDict({'key1': 'value1', 'key2': 'value2'})"



# Generated at 2022-06-22 21:27:12.678056
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Unit test to test the difference method of the ImmutableDict class
    """
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 == d1.difference([]), "Empty list should return the same ImmutableDict instance"
    assert d1 == d1.difference(set()), "Empty set should return the same ImmutableDict instance"
    assert d1 == d1.difference(frozenset()), "Empty frozenset should return the same ImmutableDict instance"
    d2 = d1.difference(['a', 'd'])
    d3 = d1.difference('abc')
    d4 = d1.difference(set(['a', 'd']))

# Generated at 2022-06-22 21:27:21.363272
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    test_dict = ImmutableDict({"a":1, "b":2, "c":3})
    assert test_dict["a"] == 1, "ImmutableDict __getitem__ did not return correct value"
    assert test_dict["b"] == 2, "ImmutableDict __getitem__ did not return correct value"
    assert test_dict["c"] == 3, "ImmutableDict __getitem__ did not return correct value"


# Generated at 2022-06-22 21:27:29.385851
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert is_sequence(set([1, 2, 3]))
    assert is_sequence('abc') is False
    assert is_sequence(b'abc') is False
    assert is_sequence(('a', 'b', 'c'))
    assert is_sequence(u'abc') is False
    assert is_sequence((1, 'a', [1, 2, 3]))
    assert is_sequence(ImmutableDict(x=1, y=2, z=3))



# Generated at 2022-06-22 21:27:31.926857
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert len(d) == 3



# Generated at 2022-06-22 21:27:36.294359
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(a=1, b=2)
    d3 = ImmutableDict(d=1, e=2)
    assert d1 != d3
    assert d1 != 'd1'
    assert d1 == d2
    assert d2 == d1

# Generated at 2022-06-22 21:27:42.911679
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([]) == True
    assert is_sequence(()) == True
    assert is_sequence({}) == False

    class Funky(object):
        def __getitem__(self, index):
            return index

    assert is_sequence(Funky()) == True

    assert is_sequence('string') == False
    assert is_sequence('string', include_strings=True) == True

# Generated at 2022-06-22 21:27:54.951021
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence([1, 2, 3])
    assert is_sequence(dict())
    assert is_sequence(dict().values())
    assert is_sequence(set())
    assert is_sequence(set([1, 2]))
    assert is_sequence('abc')

    assert not is_sequence(1)
    assert not is_sequence(True)
    assert not is_sequence(None)
    assert not is_sequence(dict()[key])
    assert not is_sequence(set().pop())

    assert is_sequence((1, 2))
    assert is_sequence(xrange(10))

    assert is_sequence(xrange(10), include_strings=True)
    assert is_sequence((1, 2), include_strings=True)

# Generated at 2022-06-22 21:27:57.923526
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    a = ImmutableDict(first=1, second=2, third=3)
    assert a['first'] == 1
    assert a['second'] == 2
    assert a['third'] == 3
    assert repr(a) == "ImmutableDict({'third': 3, 'second': 2, 'first': 1})"

    b = a.union({'third': 7})
    assert a['third'] == 3
    assert b['third'] == 7

    c = a.difference(['third'])
    assert 'third' in a
    assert 'third' not in c



# Generated at 2022-06-22 21:27:59.244183
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    assert sorted(list(ImmutableDict(name='ansible'))) == ['name']


# Generated at 2022-06-22 21:28:07.110025
# Unit test for function is_string
def test_is_string():
    cases = [
        u'',
        u'u',
        u'unicode',
        '',
        'ascii',
        b'',
        b'bytes',
        [],
        (),
        {},
    ]
    for case in cases:
        assert is_string(case) == isinstance(case, (text_type, binary_type))



# Generated at 2022-06-22 21:28:13.406126
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """Return an ImmutableDict with the elements of the original
    ImmutableDict that are not keys in the subtractive_iterable.
    """

    immutable_orig = ImmutableDict({"a": 1, "b": 2, "c": 3})

    immutable_diff = immutable_orig.difference(["a", "c"])

    assert len(immutable_diff) == 1
    assert immutable_diff == ImmutableDict({"b": 2})



# Generated at 2022-06-22 21:28:24.527937
# Unit test for function count
def test_count():
    test_data = [
        {'in': [1, 2, 3], 'out': {1: 1, 2: 1, 3: 1}},
        {'in': [1, 1, 1], 'out': {1: 3}},
        {'in': [1, 2, 3, 3, 3], 'out': {1: 1, 2: 1, 3: 3}},
        {'in': [{}, {}], 'out': {({},): 2}},
        {'in': [(1, 2, 3), (1, 2, 3)], 'out': {(1, 2, 3): 2}},
        {'in': [], 'out': {}},
    ]
    for test in test_data:
        assert count(test['in']) == test['out']



# Generated at 2022-06-22 21:28:31.116149
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert is_string(u'bar')
    assert not is_string(42)
    assert not is_string([1, 2, 3])
    assert not is_string({'foo': 1, 'bar': 2})
    assert not is_string(['foo', 42])
    assert not is_string((u'foo', 42, 3.14159265359))

# Generated at 2022-06-22 21:28:33.268139
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict({'a': 1})
    assert repr(d) == "ImmutableDict({'a': 1})"


# Generated at 2022-06-22 21:28:38.018343
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    """Unit test for method __getitem__ of class ImmutableDict"""
    testdict=ImmutableDict({'test': 'value'})
    if(testdict['test']=='value'):
        return True
    else:
        return False


# Generated at 2022-06-22 21:28:50.114039
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d = ImmutableDict({'a':'b', 'c':'d', 'e':'f'})
    assert d.difference(['c']) == {'a':'b', 'e':'f'}
    assert d.difference(['c', 'e']) == {'a':'b'}
    assert d.difference(['e', 'c']) == {'a':'b'}
    assert d.difference(['c', 'e', 'b']) == {'a':'b'}
    assert d.difference(['e', 'c', 'b']) == {'a':'b'}
    assert d.difference(['e', 'c', 'a']) == {'a':'b'}

# Generated at 2022-06-22 21:28:56.468126
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():

    test_dict = ImmutableDict({"a": 1, "b": 2})
    assert hash(test_dict) == hash(ImmutableDict({"a": 1, "b": 2}))
    assert hash(test_dict) != hash(ImmutableDict({"a": 1, "b": 1}))
    assert hash(test_dict) != hash(ImmutableDict({"a": 1}))
    assert hash(test_dict) != hash(ImmutableDict({}))



# Generated at 2022-06-22 21:29:00.124863
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    items = {'a': 1, 'b': 2}
    d = ImmutableDict(items)
    for k, v in items.items(): 
        assert d[k] == v


# Generated at 2022-06-22 21:29:01.891223
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert repr(ImmutableDict()) == 'ImmutableDict({0})'
    assert repr(ImmutableDict({'a': 1})) == "ImmutableDict({'a': 1})"


# Generated at 2022-06-22 21:29:03.889885
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict({'a': 1})
    assert d['a'] == 1



# Generated at 2022-06-22 21:29:11.014301
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Test __hash__ method of ImmutableDict class."""
    a = ImmutableDict(x=1, y=2, z=3)
    b = ImmutableDict(x=1, y=2, z=3)
    c = ImmutableDict(x=1, y=2)
    d = ImmutableDict(x=1, y=2)
    assert a.__hash__() == b.__hash__()
    assert c.__hash__() == d.__hash__()
    assert c.__hash__() != a.__hash__()

# Generated at 2022-06-22 21:29:15.125982
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Unit tests for __repr__"""
    test_dict = ImmutableDict({'test': 'test'})
    result = repr(test_dict)
    assert result == "ImmutableDict({'test': 'test'})"



# Generated at 2022-06-22 21:29:26.513117
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({1: 2}) == ImmutableDict({1: 2})
    assert ImmutableDict({1: 2}) == ImmutableDict({1: 2, 3: 4})
    assert ImmutableDict({1: 2, 3: 4}) == ImmutableDict({1: 2, 3: 4})
    assert not ImmutableDict({1: 2}) == ImmutableDict({1: 3})
    assert not ImmutableDict({1: 2}) == ImmutableDict({1: 2, 3: 4})
    assert not ImmutableDict({1: 2, 3: 4}) == ImmutableDict({1: 2})
    assert not ImmutableDict({1: 2, 3: 4}) == ImmutableDict({1: 3, 3: 4})

# Generated at 2022-06-22 21:29:37.826273
# Unit test for function is_sequence
def test_is_sequence():

    class FauxSequence(Sequence):
        def __init__(self, data):
            self.data = data

        def __len__(self):
            return len(self.data)

        def __getitem__(self, index):
            return self.data[index]

    class FauxNonSequence(object):
        def __init__(self, data):
            self.data = data

        def __len__(self):
            return len(self.data)

        def __getitem__(self, index):
            return self.data[index]

    class FauxNonIndexable(object):
        def __init__(self, data):
            self.data = data

        def __len__(self):
            return len(self.data)

    assert is_sequence([])
    assert is_sequence(())


# Generated at 2022-06-22 21:29:43.609586
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    test_dict = ImmutableDict(a=1, b=2, c=3)
    expected_output = 'ImmutableDict({a=1, b=2, c=3})'
    assert repr(test_dict) == 'ImmutableDict({a=1, b=2, c=3})'



# Generated at 2022-06-22 21:29:50.422970
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    """
    Ensure that __getitem__ method of class ImmutableDict behaves as expected
    """
    i_dict = ImmutableDict({'a': 1, 'b': 2})
    assert i_dict['a'] == 1
    assert i_dict['b'] == 2
    try:
        i_dict['c']
        assert False, "Should not be able to fetch an unknown key"
    except KeyError:
        pass


# Generated at 2022-06-22 21:29:59.506412
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test method __eq__ of class ImmutableDict."""
    # Assert that ImmutableDict is equal to itself
    test_dict = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict == test_dict

    # Assert that ImmutableDict is equal to a copy of itself
    assert test_dict == ImmutableDict({'a': 1, 'b': 2})

    # Assert that ImmutableDict is not equal to another ImmutableDict with different values
    assert not test_dict == ImmutableDict({'a': 1, 'b': 3})

    # Assert that ImmutableDict is not equal to an non ImmutableDict object
    assert not test_dict == {'a': 1, 'b': 2}

    # Assert that ImmutableDict is not equal to an