

# Generated at 2022-06-22 21:20:07.699603
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence(list())
    assert is_sequence(tuple())
    assert is_sequence(set())
    assert is_sequence(frozenset())
    assert is_sequence([1, 2, 3])
    assert is_sequence((1, 2, 3))
    assert is_sequence({1, 2, 3})
    assert is_sequence({1: 'a', 2: 'b', 3: 'c'})

    assert not is_sequence(1)
    assert not is_sequence(1.0)
    assert not is_sequence(u'abc')
    assert not is_sequence(b'abc')
    assert not is_sequence(u'abc', include_strings=True)
    assert not is_sequence(b'abc', include_strings=True)
    assert not is_sequence(None)
    assert not is_

# Generated at 2022-06-22 21:20:18.622881
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d1 = ImmutableDict()
    d2 = ImmutableDict()
    d3 = ImmutableDict()
    d4 = ImmutableDict()
    assert hash(d1) == hash(d2)
    assert hash(d1) != hash(d3)
    assert hash(d1) != hash(d4)
    d3 = ImmutableDict(one=1)
    assert hash(d1) != hash(d3)
    d1 = ImmutableDict(one=1)
    d2 = ImmutableDict(one=1)
    d3 = ImmutableDict(one=1)
    assert hash(d1) == hash(d2)
    assert hash(d1) == hash(d3)


# Generated at 2022-06-22 21:20:21.769412
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    idict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    idict = idict.difference(['a', 'c'])
    assert len(idict) == 1
    assert 'b' in idict
    assert idict['b'] == 2


# Generated at 2022-06-22 21:20:27.075458
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    idict = ImmutableDict(dict(a='a', b='b'))
    assert isinstance(idict, Mapping)
    assert isinstance(idict, Hashable)
    assert idict == dict(a='a', b='b')
    assert idict != dict(a='a', b='B')
    assert idict != dict(a='a')
    assert idict != dict(a='a', b='b', c='c')


# Generated at 2022-06-22 21:20:37.387879
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():

    from copy import copy

    # Given an ImmutableDict
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert original == {'a': 1, 'b': 2, 'c': 3}

    # When I create a new ImmutableDict with the same contents
    new = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert new == {'a': 1, 'b': 2, 'c': 3}
    # Then it should be equal to the original
    assert new == original

    # When I create a new ImmutableDict from the original with certain keys removed
    new = original.difference(['a', 'c'])
    assert new == {'b': 2}

    # Then I should not be able to modify the original

# Generated at 2022-06-22 21:20:47.532966
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence(())
    assert is_sequence({})
    assert is_sequence(set())
    assert not is_sequence(object())
    assert not is_sequence(1)
    assert not is_sequence(1.1)
    assert is_sequence(b'123')
    assert is_sequence('123')
    assert is_sequence(u'123')
    assert not is_sequence([1, 2, 3], include_strings=True)
    assert not is_sequence((1, 2, 3), include_strings=True)
    assert not is_sequence({1, 2, 3}, include_strings=True)
    assert not is_sequence({1: '1', 2: '2', 3: '3'}, include_strings=True)

# Generated at 2022-06-22 21:20:52.169014
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = dict1.union({'a': 3, 'c': 4})
    assert dict2 == {'a': 3, 'b': 2, 'c': 4}


# Generated at 2022-06-22 21:21:01.568565
# Unit test for function is_sequence
def test_is_sequence():
    seq = [1, 2, 3]
    not_seq = list()
    accum_seq = [1, 2, 3]
    while is_sequence(accum_seq):
        accum_seq = accum_seq[0]

    assert is_sequence(seq) is True
    assert is_sequence(seq, include_strings=True) is True
    assert is_sequence(not_seq) is False
    assert is_sequence(not_seq, include_strings=True) is False

    assert is_sequence(accum_seq) is False
    assert is_sequence(accum_seq, include_strings=True) is False


# Generated at 2022-06-22 21:21:04.720763
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict({'a': 'b', 'c': 'd'})

    assert d['a'] == 'b'
    assert d['c'] == 'd'



# Generated at 2022-06-22 21:21:10.705918
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    assert hash(ImmutableDict({'a': '1', 'b': '2'})) == hash(ImmutableDict({'b': '2', 'a': '1'}))
    assert hash(ImmutableDict({'b': '2', 'a': '1'})) == hash(ImmutableDict({'b': '2', 'a': '1'}))
    assert hash(ImmutableDict({'a': '1', 'b': '2'})) != hash(ImmutableDict({'b': '2'}))


# Generated at 2022-06-22 21:21:15.798889
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    id_dict = ImmutableDict({'a' : 1, 'b' : 2})
    assert id_dict == {'a' : 1, 'b' : 2}
    assert hash(id_dict) == hash({'a' : 1, 'b' : 2})


# Generated at 2022-06-22 21:21:22.124098
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    immutable_dict = ImmutableDict({'a': '1', 'b': '2'})
    immutable_dict = immutable_dict.union({'c': '3'})
    assert 'a' in immutable_dict
    assert 'b' in immutable_dict
    assert 'c' in immutable_dict
    assert immutable_dict['a'] == '1'
    assert immutable_dict['b'] == '2'
    assert immutable_dict['c'] == '3'



# Generated at 2022-06-22 21:21:23.130849
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    pass  # TODO: implement


# Generated at 2022-06-22 21:21:29.258255
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    d = ImmutableDict({'a': 1, 'b': 2}, c=3, d=4)
    assert d['a'] == 1
    assert d['b'] == 2
    assert d['c'] == 3
    assert d['d'] == 4
    assert len(d) == 4
    try:
        d['a'] == 1
        assert False, 'Expected exception'
    except TypeError:
        pass



# Generated at 2022-06-22 21:21:35.642253
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    piglet_dict = ImmutableDict(name='Piglet', age=11)
    piglet_clone_dict = ImmutableDict(name='Piglet', age=11)
    pooh_dict = ImmutableDict(name='Pooh', age=11)
    eeyore_dict = ImmutableDict(name='Eeyore', age=11)

    assert piglet_dict.__hash__() == piglet_clone_dict.__hash__()
    assert piglet_dict.__hash__() != pooh_dict.__hash__()
    assert piglet_dict.__hash__() != eeyore_dict.__hash__()
    assert pooh_dict.__hash__() != eeyore_dict.__hash__()



# Generated at 2022-06-22 21:21:38.546939
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    source = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    result = source.difference(['a', 'c'])
    assert result == ImmutableDict({'b': 2})



# Generated at 2022-06-22 21:21:40.249283
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    pass


# Generated at 2022-06-22 21:21:44.277610
# Unit test for function is_string
def test_is_string():
    from ansible.module_utils.six import binary_type, text_type
    assert is_string("abc")
    assert is_string(u"abc")
    assert is_string(b"abc")
    assert is_string(1) is False



# Generated at 2022-06-22 21:21:46.377636
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict(dict(a='b', c='d'))) == 2


# Generated at 2022-06-22 21:21:51.335696
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original_dict = ImmutableDict({'a': 1, 'b': 2})
    overriding_dict = {'c': 3}
    union = original_dict.union(overriding_dict)
    assert union == {'a': 1, 'b': 2, 'c': 3}


# Generated at 2022-06-22 21:21:56.696558
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    x = ImmutableDict()
    assert len(x) == 0
    x = ImmutableDict({'a', 'b', 1, 3}, c=4, d=5, e='6')
    assert len(x) == 5

# Generated at 2022-06-22 21:22:03.209445
# Unit test for function is_sequence
def test_is_sequence():
    """Test the function is_sequence()."""
    # Simple lists and tuples are sequences
    assert is_sequence([], True)
    assert is_sequence([1, 2, 3])
    assert is_sequence((1, 2, 3), True)
    assert is_sequence([1, 2, [3]])

    # Dictionaries are not sequences
    assert not is_sequence({})
    assert not is_sequence({1: 2})

    # Strings are sequences (if include_strings is True)
    assert is_sequence('a', include_strings=True)
    assert is_sequence(u'a', include_strings=True)
    assert is_sequence(b'a', include_strings=True)

    # By default consider strings as not sequences
    assert not is_sequence('a')

# Generated at 2022-06-22 21:22:08.897304
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_dict1 = ImmutableDict({
        'a': 1,
        'b': 2,
        'c': 3
    })

    test_dict2 = test_dict1.difference(['a', 'c'])

    assert test_dict2 == ImmutableDict({'b': 2})

# Generated at 2022-06-22 21:22:12.420938
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = dict(a=1, b=2)
    id = ImmutableDict(d)

    # Equivalent to: assert repr(d) == repr(id)
    assert repr(d) == repr(id)

# Generated at 2022-06-22 21:22:18.438136
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    dict1 = {'yellow': 1 , 'blue': 3 , 'red': 2}
    dict2 = {'green': 1 , 'blue': 2 , 'purple': 4}
    test_dicts = [
        dict1,
        dict2
    ]
    for dict_test in test_dicts:
        d_ = ImmutableDict(dict_test)
        assert d_.__repr__() == 'ImmutableDict({0})'.format(repr(dict_test))


# Generated at 2022-06-22 21:22:22.639391
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d2 = d1.difference(['a'])
    assert d1 == {'a': 1, 'b': 2, 'c': 3}
    assert d2 == {'b': 2, 'c': 3}

# Generated at 2022-06-22 21:22:31.713753
# Unit test for function is_sequence
def test_is_sequence():
    """Test is_sequence function."""
    assert is_sequence([])
    assert is_sequence([1, 2])
    assert not is_sequence(1)
    assert is_sequence((1, 2))
    assert not is_sequence(0)
    assert not is_sequence(None)
    assert is_sequence([None])
    assert not is_sequence(set([1, 1, 2]))  # noqa: F821
    assert not is_sequence(set([1, 2]))  # noqa: F821
    assert not is_sequence(set())  # noqa: F821
    assert is_sequence(frozenset([1, 1, 2]))
    assert is_sequence(frozenset([1, 2]))
    assert is_sequence(frozenset())
    assert not is_sequence

# Generated at 2022-06-22 21:22:35.376541
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    dict_ = {1: 'test'}
    new_dict = ImmutableDict(dict_)
    assert repr(new_dict) == "ImmutableDict({1: 'test'})"



# Generated at 2022-06-22 21:22:40.492825
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    x = ImmutableDict( {'a': 1, 'b': 2, 'c': 3})
    assert list(x) == ['a', 'b', 'c']
    y = ImmutableDict( {'a': 1, 'b': 2, 'c': 3})
    assert list(y) == ['a', 'b', 'c']


# Generated at 2022-06-22 21:22:49.410625
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    # Empty dict
    empty = ImmutableDict()
    assert repr(empty) == 'ImmutableDict({})'

    # Non-empty dict
    simple = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert repr(simple) == 'ImmutableDict({\'key1\': \'value1\', \'key2\': \'value2\'})'

    # Dict containing dicts
    nested = ImmutableDict({'key1': 'value1', 'key2': {'key21': 'value21', 'key22': 'value22'}})
    assert repr(nested) == 'ImmutableDict({\'key1\': \'value1\', \'key2\': {\'key21\': \'value21\', \'key22\': \'value22\'}})'



# Generated at 2022-06-22 21:22:58.507017
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Test for ImmutableDict constructor"""
    try:
        assert ImmutableDict(a='1') == ImmutableDict({'a': '1'})
    except AssertionError:
        raise Exception('ImmutableDict constructor with keyword argument failed')
    try:
        assert ImmutableDict({'a': '1'}) == ImmutableDict({'a': '1'})
    except AssertionError:
        raise Exception('ImmutableDict constructor with single object failed')
    try:
        assert ImmutableDict({'a': '1', 'b': '2'}) == ImmutableDict({'a': '1', 'b': '2'})
    except AssertionError:
        raise Exception('ImmutableDict constructor with multiple objects failed')


# Generated at 2022-06-22 21:23:01.236725
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    assert list(ImmutableDict(one=1, two=2, three=3)) == list({'one': 1, 'two': 2, 'three': 3})



# Generated at 2022-06-22 21:23:08.308955
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a = ImmutableDict([('a', 1), ('b', 2), ('c', 2)])
    b = {'c': 3, 'd': 4}

    expected = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    result = a.union(b)

    assert len(expected) == len(result)
    assert cmp(expected, result) == 0



# Generated at 2022-06-22 21:23:10.531179
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    a = ImmutableDict(a=1, b=2)
    assert len(a) == 2

    a = ImmutableDict()
    assert len(a) == 0


# Generated at 2022-06-22 21:23:13.807722
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(('a', 'b', 'c'))
    assert is_iterable([])
    assert not is_iterable(1)
    assert not is_iterable({})
    assert not is_iterable('abcd')
    assert not is_iterable(None)



# Generated at 2022-06-22 21:23:19.278711
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original_dict = ImmutableDict({'a': 'b', 'c': 'd', 'e': 'f'})
    sub_iterable = ['a', 'e']
    reduced_dict = original_dict.difference(sub_iterable)
    assert reduced_dict == {'c': 'd'}

# Generated at 2022-06-22 21:23:31.131175
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    import sys
    import pytest

    if sys.version_info.major < 3 or sys.version_info.minor < 6:
        pytest.skip('Skipping test', allow_module_level=True)

    def test_getitem(immutable_dict, expected_value):
        assert immutable_dict['a'] == expected_value

    immut = ImmutableDict({'a':1})

    test_getitem(immut, 1)

    immut2 = immut.union({'a':2})

    test_getitem(immut, 1)
    test_getitem(immut2, 2)

    immut3 = immut2.union({'b':3})
    test_getitem(immut2, 2)
    test_getitem(immut3, 2)
    test_getitem

# Generated at 2022-06-22 21:23:38.065861
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import pytest
    id1 = ImmutableDict((('a', 1), ('b', 2)))
    id2 = ImmutableDict((('a', 1), ('b', 2)))
    id3 = ImmutableDict((('b', 2), ('a', 1)))
    assert(id1 == id2 == id3)

    id1 = ImmutableDict((('a', 1), ('b', 2), ('c', 3)))
    id2 = ImmutableDict((('a', 1), ('b', 2)))
    assert(id1 != id2)

    with pytest.raises(TypeError):
        id1 == 123

# Generated at 2022-06-22 21:23:45.720616
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable({1:2})
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'123')
    assert is_iterable((1, 2, 3))
    assert is_iterable(None) is False
    assert is_iterable(object()) is False
    assert is_iterable(1) is False
    assert is_iterable(1.5) is False


# Generated at 2022-06-22 21:23:47.980388
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    test_dict = ImmutableDict(a=1,b=2,c=3)
    assert len(test_dict) == 3


# Generated at 2022-06-22 21:23:58.069062
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # scalar comparison
    assert hash(ImmutableDict()) == hash(ImmutableDict())
    assert hash(ImmutableDict({'a': 'b'})) == hash(ImmutableDict({'a': 'b'}))
    assert hash(ImmutableDict({'a': 'b'})) != hash(ImmutableDict({'a': 'c'}))

    # comparison of lists and tuples
    assert hash(ImmutableDict()) == hash(frozenset())
    assert hash(ImmutableDict({'a': 'b'})) == hash(frozenset({'a': 'b'}))
    assert hash(ImmutableDict({'a': 'b'})) == hash(frozenset({('a', 'b')}))

# Generated at 2022-06-22 21:24:03.620418
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    """Unit test for method __iter__ of class ImmutableDict"""
    d1 = ImmutableDict([('a', 1), ('b', 2), ('c', 3)])
    for elem in d1:
        assert elem in ('a', 'b', 'c')



# Generated at 2022-06-22 21:24:14.096147
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import sys
    import unittest

    if sys.version_info[0] < 3:
        class ImmutableDictTestCase(unittest.TestCase):
            def test_ImmutableDict___eq__(self):
                a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
                b = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
                c = ImmutableDict({'c': 1, 'b': 2, 'a': 3})
                d = ImmutableDict({'d': 1, 'b': 2, 'a': 3})
                self.assertEqual(a, b)
                self.assertEqual(b, a)
                self.assertEqual(a, c)
                self.assertEqual(c, a)

# Generated at 2022-06-22 21:24:22.359311
# Unit test for function is_iterable
def test_is_iterable():
    class CustomIterable(object):
        def __iter__(self):
            return iter([])

    class CustomNonIterable(object):
        pass

    assert is_iterable([])
    assert is_iterable([1])
    assert is_iterable(())
    assert is_iterable((1,))
    assert is_iterable({})
    assert is_iterable({'key': 'value'})
    assert is_iterable(set())
    assert is_iterable(set([1]))
    assert is_iterable(CustomIterable())
    assert not is_iterable(1)
    assert not is_iterable('string')
    assert not is_iterable(CustomNonIterable())



# Generated at 2022-06-22 21:24:29.169637
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    idict1 = ImmutableDict(foo=1, bar=2, baz=3)
    idict2 = ImmutableDict(baz=5, foo=4)

    assert isinstance(idict1, Mapping)
    assert isinstance(idict2, Mapping)

    assert isinstance(idict1, Hashable)
    assert isinstance(idict2, Hashable)

    assert idict1 != idict2

    idict3 = idict1.union(idict2)
    assert isinstance(idict3, ImmutableDict)

    assert idict3.difference(idict1) == idict2
    assert idict3.difference(idict2) == idict1

# Generated at 2022-06-22 21:24:41.226881
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    import unittest
    original_dict = {'a': 1, 'b': 2, 'c': 3}
    immutable_dict = ImmutableDict(original_dict)

    # Check if the two dictionaries were not modified (__init__ makes a copy)
    assert original_dict == {'a': 1, 'b': 2, 'c': 3}
    assert immutable_dict == {'a': 1, 'b': 2, 'c': 3}

    # Check if __iter__ method works as expected
    class TestIter(unittest.TestCase):
        def test_iteration(self):
            keys = set()
            for key in immutable_dict:
                keys.add(key)

            self.assertEquals(keys, {'a', 'b', 'c'})

    unittest.main()

# Unit

# Generated at 2022-06-22 21:24:54.012240
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Test __hash__ method of class ImmutableDict"""

    # Hashable ImmutableDicts must be equal when they have the same key-value pairs.
    dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict3 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    dict4 = ImmutableDict({'b': 2, 'a': 1, 'c': 3})
    dict5 = ImmutableDict({'a': 10, 'b': 2, 'c': 3})
    dict6 = ImmutableDict({'a': 1, 'b': 20, 'c': 3})
    dict7 = ImmutableD

# Generated at 2022-06-22 21:24:55.521619
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    assert d['key1'] == 'value1'
    assert d['key2'] == 'value2'
    assert d['key3'] == 'value3'


# Generated at 2022-06-22 21:25:05.846436
# Unit test for function is_sequence
def test_is_sequence():
    test_strings = (
        '',
        u'',
        b'',
        'hey',
        u'hey',
        b'hey',
    )
    test_sequences = (
        [],
        tuple(),
        (),
        [1, 2, 3, 4],
        (1, 2, 3, 4),
        (1, 'hey', 2, 'hey', 3, 'hey', 4),
    )
    test_non_sequences = [1, 2, 'hey', 'you']

    for seq in test_strings:
        assert not is_sequence(seq)
        assert is_sequence(seq, include_strings=True)

    for seq in test_sequences:
        assert is_sequence(seq)
        assert is_sequence(seq, include_strings=True)


# Generated at 2022-06-22 21:25:10.119832
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    fd = ImmutableDict(a=1, b=2, c=3)
    fd = fd.union({'d': 4, 'a': 5})
    assert fd == ImmutableDict({'a': 5, 'b': 2, 'c': 3, 'd': 4})



# Generated at 2022-06-22 21:25:19.389006
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.six import text_type

    # Test inequality of two completely different dictionaries
    assert ImmutableDict({'a':1, 'b':2}) != ImmutableDict({'c':3, 'd':4})
    assert ImmutableDict({'a':1, 'b':2}) != {'c':3, 'd':4}
    assert ImmutableDict({'a':1, 'b':2}) != ['c', 'd']
    assert ImmutableDict({'a':1, 'b':2}) != IndexError

# Generated at 2022-06-22 21:25:24.311038
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # Identity of instances
    assert hash(ImmutableDict()) == hash(ImmutableDict())
    assert hash(ImmutableDict([('a', 1), ])) == hash(ImmutableDict([('a', 1), ]))
    assert hash(ImmutableDict([('a', 1), ('b', 2)])) == hash(ImmutableDict([('a', 1), ('b', 2)]))
    assert hash(ImmutableDict([('b', 2), ('a', 1)])) == hash(ImmutableDict([('a', 1), ('b', 2)]))
    # Non identity of instances
    assert hash(ImmutableDict()) != hash(ImmutableDict([('a', 1), ('b', 2)]))

# Generated at 2022-06-22 21:25:30.683745
# Unit test for function count
def test_count():
    # Edge cases
    assert count([]) == {}
    assert count(tuple()) == {}
    assert count({}) == {}
    assert count('') == {}
    assert count('') == {}
    assert count(None) == Exception
    assert count(1) == Exception

    # Basic function of function
    assert count([1, 2, 2, 3, 3]) == {1: 1, 2: 2, 3: 2}
    assert count([1, 2, 2, 3, 3]) == {1: 1, 2: 2, 3: 2}
    assert count([1, 2, 2, 3, 3, 3]) == {1: 1, 2: 2, 3: 3}
    assert count([1, 2, 2, 3, 3, 3, 3]) == {1: 1, 2: 2, 3: 4}
    assert count

# Generated at 2022-06-22 21:25:41.366700
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Sequence

    initial_mapping = {'key1': 'value1', 'key2': 'value2'}
    immutable_mapping = ImmutableDict(initial_mapping)

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.exit_json(
        initial_mapping=initial_mapping,
        immutable_mapping=immutable_mapping,
        initial_mapping_is_sequence=isinstance(initial_mapping, Sequence),
        immutable_mapping_is_sequence=isinstance(immutable_mapping, Sequence),
    )

# Generated at 2022-06-22 21:25:44.299823
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    my_dict = ImmutableDict({'a':1, 'b':2})
    assert next(iter(my_dict)) == 'a'


# Generated at 2022-06-22 21:25:46.612849
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict(a=1, b=2)
    assert set(d) == {'a', 'b'}



# Generated at 2022-06-22 21:25:58.047827
# Unit test for function is_sequence
def test_is_sequence():
    """Unit test to test function is_sequence."""
    assert is_sequence([1, 2, 3])
    assert is_sequence((1, 2, 3))
    assert not is_sequence({1, 2, 3})
    assert not is_sequence({1: 'a', 2: 'b', 3: 'c'})
    assert not is_sequence('abc')
    assert not is_sequence(1)
    assert is_sequence([1, 2, 3], True)
    assert is_sequence((1, 2, 3), True)
    assert not is_sequence({1, 2, 3}, True)
    assert not is_sequence({1: 'a', 2: 'b', 3: 'c'}, True)
    assert is_sequence('abc', True)
    assert not is_sequence(1, True)

# Generated at 2022-06-22 21:26:08.662975
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert not is_iterable(set([1, 2, 3]))
    assert not is_iterable("an atom")
    assert is_iterable("an atom", include_strings=True)
    assert not is_iterable(10)
    assert not is_iterable(dict(a=1, b=2, c=3))
    assert is_iterable(dict(a=1, b=2, c=3).items())
    assert not is_iterable(Iterable(['a', 'b', 'c', 'd']))
    assert is_iterable(Iterable(['a', 'b', 'c', 'd']).values())



# Generated at 2022-06-22 21:26:12.283115
# Unit test for function is_string
def test_is_string():
    assert is_string('string')
    assert is_string(u'string')
    assert is_string(b'string')
    assert is_string(1) is False



# Generated at 2022-06-22 21:26:14.833962
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    immutable_dict = ImmutableDict({'a': '1'})

    assert immutable_dict['a'] == '1'


# Generated at 2022-06-22 21:26:17.936991
# Unit test for function count
def test_count():
    ''' Check function is working as expected. '''
    counts = count([1, 1, 2, 3, 1, 1, 4])
    assert counts == {1: 4, 2: 1, 3: 1, 4: 1}



# Generated at 2022-06-22 21:26:27.648760
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Test ImmutableDict constructor"""
    d1 = ImmutableDict({'a': 1, 'b': 2}, c='3')
    assert d1 == {'a': 1, 'b': 2, 'c': '3'}

    d2 = ImmutableDict(a=1, b=2, c='3')
    assert d2 == {'a': 1, 'b': 2, 'c': '3'}

    d3 = ImmutableDict([('a', 1), ('b', 2)], c='3')
    assert d3 == {'a': 1, 'b': 2, 'c': '3'}

    d4 = ImmutableDict()
    assert d4 == {}


# Generated at 2022-06-22 21:26:39.469425
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test case when both object (self and other) are ImmutableDict
    dict1 = ImmutableDict({'a':1, 'b':2})
    dict2 = ImmutableDict({'b':2, 'a':1})
    assert dict1 == dict2

    dict3 = ImmutableDict({'b':2})
    assert dict1 != dict3

    # Test case when only other is ImmutableDict, while self is a regular dict
    dict_regular = {'b':2, 'a':1}
    assert dict1 == dict_regular

    dict_regular = {'c':3}
    assert dict1 != dict_regular

    # Test case when other is a regular dict, while self is an ImmutableDict
    assert dict_regular != dict1


# Generated at 2022-06-22 21:26:44.022414
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable([1, 2, 3]) == True)
    assert(is_iterable(('a', 'b', 'c')) == True)
    assert(is_iterable((x for x in range(3))) == True)


# Generated at 2022-06-22 21:26:47.443369
# Unit test for function is_string
def test_is_string():
    '''
    Tests the is_string function
    '''
    assert is_string('hello')
    assert is_string(u'hello')
    assert is_string(b'hello')
    assert not is_string([])
    assert not is_string(dict())


# Generated at 2022-06-22 21:26:50.798537
# Unit test for function count
def test_count():
    res = count([3, 4, 2, 4, 2])
    assert res[3] == 1
    assert res[4] == 2
    assert res[2] == 2


# Generated at 2022-06-22 21:26:57.115639
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():

    # Create a dictionary with five keys
    d = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    e = ImmutableDict(d)

    # Create a tuple with two of the five keys
    t = ('a', 'b')

    # Create an ImmutableDict with the remaining three keys
    f = e.difference(t)

    # Ensure the ImmutableDict contains the correct keys
    assert 'a' not in f
    assert 'c' in f
    assert 'd' in f
    assert 'e' in f

    # Ensure the ImmutableDict contains the correct values
    assert f['c'] == 3
    assert f['d'] == 4
    assert f['e'] == 5

# Generated at 2022-06-22 21:27:03.931835
# Unit test for function is_sequence
def test_is_sequence():
    assert not is_sequence(42)
    assert not is_sequence(42, include_strings=True)
    assert not is_sequence('foo')
    assert not is_sequence(u'foo')
    assert is_sequence('foo', include_strings=True)
    assert is_sequence(u'foo', include_strings=True)
    assert not is_sequence({'a': 42})
    assert is_sequence([1, 2, 3])
    assert not is_sequence(None)
    assert not is_sequence(MutableMapping())
    assert not is_sequence(MutableMapping(), include_strings=True)

# Generated at 2022-06-22 21:27:08.027016
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Tests if ImmutableDict.__repr__ returns a type that can be parsed by python"""
    assert eval(repr(ImmutableDict({"a": "b"}))) == ImmutableDict({"a": "b"})



# Generated at 2022-06-22 21:27:19.993024
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    a = ImmutableDict()
    b = ImmutableDict({'a': 1})
    c = ImmutableDict({'b': 1})
    d = ImmutableDict({'a': 1})
    e = ImmutableDict({'a': 2})
    f = ImmutableDict({'b': 1})
    g = ImmutableDict({'a': 1, 'b': 1})
    h = ImmutableDict({'b': 1, 'a': 1})
    i = ImmutableDict({'a': 1, 'b': 2})
    j = ImmutableDict({'a': 1, 'c': 2})

# Generated at 2022-06-22 21:27:24.524908
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    dict_obj = ImmutableDict({'a': 1, 'b': 2})

    assert dict_obj['a'] == 1
    assert dict_obj['b'] == 2
    assert dict_obj['c']


# Generated at 2022-06-22 21:27:34.413900
# Unit test for function count
def test_count():
    assert count(['a', 'b', 'b', 'c', 'a']) == {'a': 2, 'b': 2, 'c': 1}
    assert count(['a', 'b', 'b', 'c', 'a', 'b']) == {'a': 2, 'b': 3, 'c': 1}
    assert count('ababa') == {'a': 3, 'b': 2}
    assert count('\x00\x01\x02\x01\x00') == {'\x00': 2, '\x01': 2, '\x02': 1}
    try:
        count(1)
    except Exception:
        pass
    else:
        assert False, "Failed to raise an exception on non-iterable argument"


# Generated at 2022-06-22 21:27:36.615973
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict([('a', 1), ('b', 2), ('c', 3)])
    keys = set()
    for k in d:
        keys.add(k)
    assert set(['a', 'b', 'c']) == keys



# Generated at 2022-06-22 21:27:46.547815
# Unit test for function count
def test_count():
    # Test with a list
    my_list = [1,2,2,2,3,3,3,3,3,3,3,3,3,3,3]
    result_dict  = count(my_list)
    assert result_dict[1] == 1
    assert result_dict[2] == 3
    assert result_dict[3] == 12
    # Test with a set
    my_set = {1,2,2,2,3,3,3,3,3,3,3,3,3,3,3}
    result_dict = count(my_set)
    assert result_dict[1] == 1
    assert result_dict[2] == 3
    assert result_dict[3] == 12
    # Test with a tuple

# Generated at 2022-06-22 21:27:55.852666
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    def is_equal(x, y): return hash(x) == hash(y)
    equivalent_dicts = [
        ImmutableDict({'a': 1, 'b': 2, 'c': 3}),
        ImmutableDict({'b': 2, 'c': 3, 'a': 1}),
        ImmutableDict({'a': 1, 'c': 3, 'b': 2}),
        ImmutableDict({'c': 3, 'b': 2, 'a': 1}),
        ImmutableDict({'c': 3, 'a': 1, 'b': 2}),
        ImmutableDict({'b': 2, 'a': 1, 'c': 3}),
    ]

# Generated at 2022-06-22 21:27:59.558039
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    a = {'A': '1', 'B': '2', 'C': '3'}
    b = ImmutableDict(a)
    assert set(a.keys()) == set(b.keys())

    c = ImmutableDict(a)
    for key in c.keys():
        c = c.union({key: c[key]})
    assert c == b


# Generated at 2022-06-22 21:28:08.445818
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 1, 'b'])
    assert is_iterable(set(['a', 1, 'b']))
    assert is_iterable((e for e in ['a', 1, 'b']))

    assert not is_iterable('a,1,b')
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(open)

# Generated at 2022-06-22 21:28:14.230982
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    a = {1:2, 3:4}
    b = {3:4, 1:2}
    c = ImmutableDict(a)
    d = ImmutableDict(b)
    assert(hash(c) == hash(d))


# Generated at 2022-06-22 21:28:21.638622
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence(())
    assert is_sequence(set())
    assert is_sequence(range(1))
    assert is_sequence(frozenset())
    assert is_sequence({}, include_strings=True)

    assert not is_sequence(None)
    assert not is_sequence(1)
    assert not is_sequence({})
    assert not is_sequence(True)
    assert not is_sequence(1.1)



# Generated at 2022-06-22 21:28:25.964832
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    assert ImmutableDict((('a', 1), ('b', 2), ('c', 3))) == {'a': 1, 'b': 2, 'c': 3}
    assert ImmutableDict(a=1, b=2, c=3) == {'a': 1, 'b': 2, 'c': 3}
    assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}



# Generated at 2022-06-22 21:28:37.057744
# Unit test for function is_string
def test_is_string():
    # Setting up test data
    iterables = (
        # True
        'ansible',
        u'ansible',
        'byte string',
        b'byte string',
        # False
        None,
        True,
        False,
        42,
        3.14159265359,
        [],
        (),
        {},
        set(),
        # True if include_strings=True
        set(['ansible']),
    )
    # Testing is_string
    for iterable in iterables:
        assert is_string(iterable) is (iterable is 'ansible' or iterable is u'ansible' or
                                       iterable is 'byte string' or iterable is b'byte string')

# Generated at 2022-06-22 21:28:49.641167
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    test_dict = dict()
    test_dict['key1'] = 'value1'
    test_dict['key2'] = 'value2'

    immut_dict = ImmutableDict(test_dict)

    # dict.__eq__ is same as ImmutableDict.__eq__
    assert immut_dict == test_dict

    # dict.__ne__ is same as ImmutableDict.__ne__
    immut_dict_diff = immut_dict.difference(['key2'])
    assert immut_dict != immut_dict_diff

    # dict.__getitem__ is same as ImmutableDict.__getitem__
    assert immut_dict['key1'] == test_dict['key1']

    # dict.__iter__ is same as ImmutableDict.__iter__

# Generated at 2022-06-22 21:28:53.342683
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    try:
        m = ImmutableDict(one=1, two=2)
    except TypeError as e:
        return False
    if m != {'one': 1, 'two': 2}:
        return False
    return True



# Generated at 2022-06-22 21:29:01.853484
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # __hash__ should return the same value for ImmutableDict instances that have the same data
    dict_1a = ImmutableDict([("a", 1), ("b", 2)])
    dict_1b = ImmutableDict({'a': 1, 'b': 2})
    dict_2 = ImmutableDict({'c': 1, 'd': 2})

    assert hash(dict_1a) == hash(dict_1b)
    assert hash(dict_1a) != hash(dict_2)

# Generated at 2022-06-22 21:29:04.636616
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    A = ImmutableDict({"a": 1, "b": 2})
    B = ImmutableDict({"b": 2, "a": 1})
    A == B


# Generated at 2022-06-22 21:29:07.552390
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    test_dict = ImmutableDict({'key1':'value1'})
    assert test_dict['key1'] == 'value1'


# Generated at 2022-06-22 21:29:10.609896
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    original_dict = ImmutableDict({"foo": "bar", "bar": "baz"})
    assert repr(original_dict) == "ImmutableDict({'foo': 'bar', 'bar': 'baz'})"



# Generated at 2022-06-22 21:29:21.276008
# Unit test for function count
def test_count():
    c = count([1, 2, 3, 1, 2, 1, 2, 3, 4, 1, 2, 4, 2, 1, 2, 1, 2, 4, 5])
    assert c == {1: 6, 2: 8, 3: 2, 4: 3, 5: 1}
    assert count('hello') == {'h': 1, 'e': 1, 'l': 2, 'o': 1}
    assert count([]) == {}
    assert count(123) == TypeError
    assert count('hello', True) == {'h': 1, 'e': 1, 'l': 2, 'o': 1}
    assert count([[1, 2], [3, 4]]) == ValueError

# Generated at 2022-06-22 21:29:24.686611
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict(a=1, b=2)) == 2


# Generated at 2022-06-22 21:29:31.705242
# Unit test for function is_iterable
def test_is_iterable():
    # Test iterable types
    assert(is_iterable([0, 1, 2]))
    assert(is_iterable((0, 1, 2)))
    assert(is_iterable({'a': 1, 2: 'b'}))
    # Test non-iterable types
    assert(not is_iterable('123'))
    assert(not is_iterable(1))
    assert(not is_iterable(None))



# Generated at 2022-06-22 21:29:34.192260
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    t1 = ImmutableDict({1: 'test1', 'test2': 2})
    assert set(iter(t1)) == {1,'test2'}


# Generated at 2022-06-22 21:29:37.002714
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert repr(ImmutableDict({'a':1, 'b':2})) == "ImmutableDict({'a': 1, 'b': 2})"


# Generated at 2022-06-22 21:29:43.082886
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict({'a': 1})) == 1
    assert len(ImmutableDict(a=1)) == 1
    assert len(ImmutableDict({'a': 1}, b=2)) == 2
    assert len(ImmutableDict([('a', 1)])) == 1



# Generated at 2022-06-22 21:29:54.383850
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    mydict1 = ImmutableDict(foo='bar', bar='foo')
    mydict2 = ImmutableDict(foo='bar', bar='foo')
    assert mydict1.__hash__() == mydict1.__hash__()
    assert mydict1.__hash__() == mydict2.__hash__()
    assert mydict1 == mydict2
    mydict3 = ImmutableDict(bar='foo', foo='bar')
    assert mydict1 == mydict3
    assert mydict1.__hash__() == mydict3.__hash__()

    mydict4 = ImmutableDict(foo='bar', bar='foo', baz='foo')
    mydict5 = ImmutableDict(foo='bar', bar='foo')
    assert mydict4 != mydict5
    assert mydict4.__hash__

# Generated at 2022-06-22 21:30:00.048645
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    temp_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    iter_result1 = iter(temp_dict)
    iter_result2 = temp_dict.__iter__()
    assert next(iter_result1) == 'a'
    assert next(iter_result2) == 'a'
    assert next(iter_result1) == 'b'
    assert next(iter_result2) == 'b'
    assert next(iter_result1) == 'c'
    assert next(iter_result2) == 'c'
