

# Generated at 2022-06-22 21:20:03.933636
# Unit test for function count
def test_count():
    assert count(['a', 'b', 'b', 'c', 'c', 'c']) == {'a': 1, 'c': 3, 'b': 2}
    assert count([1, 2, 3, 4, 5, 6]) == {1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 1}
    try:
        count('abc')
    except Exception:
        pass
    else:
        assert False, "count('abc') should have raised an Exception"


# Generated at 2022-06-22 21:20:06.744314
# Unit test for function count
def test_count():
    assert count(['a', 'b', 'a', 'c', 'b']) == {'a': 2, 'c': 1, 'b': 2}
    assert count([]) == dict()
    assert count({}) == dict()



# Generated at 2022-06-22 21:20:14.788751
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    import mock
    import pytest

    def test_args(fixture):
        actual = ImmutableDict().__hash__()
        assert fixture == actual

    @pytest.mark.parametrize('func', [frozenset], indirect=['func'])
    @mock.patch.object(ImmutableDict, 'items')
    def test_items(mock_items, func):
        mock_items.return_value = [1, 2, 3]
        fixture = func.return_value
        test_args(fixture)

# Generated at 2022-06-22 21:20:18.392371
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    test_dict = ImmutableDict({'key': 'value'})
    assert test_dict['key'] == 'value'


# Generated at 2022-06-22 21:20:23.174924
# Unit test for function count
def test_count():
    assert count([1, 2, 2, 3, 5, 6, 7, 8, 5, 6]) == {1: 1, 2: 2, 3: 1, 5: 2, 6: 2, 7: 1, 8: 1}
    assert count('bababaab') == {'a': 4, 'b': 4}
    assert count(('b', 'a', 'b', 'a', 'b', 'a', 'a')) == {'a': 4, 'b': 3}



# Generated at 2022-06-22 21:20:28.284744
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_dict_after_difference = test_dict.difference(['a'])
    assert not test_dict_after_difference.get('a')
    assert test_dict_after_difference.get('b') == 2
    assert test_dict_after_difference.get('c') == 3



# Generated at 2022-06-22 21:20:33.837014
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    test_dict = ImmutableDict(a=1, b=2)
    assert 'b' in test_dict and 'a' in test_dict
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert len(test_dict) == 2
    with pytest.raises(TypeError):
        test_dict['c'] = 3



# Generated at 2022-06-22 21:20:37.480916
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    from ansible.module_utils.common import ImmutableDict
    test_dict = ImmutableDict({'a': 'b', 'c': 'd'})

    assert test_dict['a'] == 'b'



# Generated at 2022-06-22 21:20:40.611844
# Unit test for function is_string
def test_is_string():
    assert(is_string('hello world'))
    assert(is_string(u'abc'))
    assert(not is_string([]))
    assert(not is_string(u''))


# Generated at 2022-06-22 21:20:44.875987
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    test_dict = ImmutableDict({'1':'one', '2':'two'})
    assert isinstance(test_dict, ImmutableDict)
    assert test_dict['1'] == 'one'
    assert len(test_dict) == 2


# Generated at 2022-06-22 21:20:57.211604
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Check __repr__ for class ImmutableDict"""
    import sys
    if sys.version_info[0] == 2:
        dut = ImmutableDict((('a', 1), ('b', 2), ('c', 3)))
        assert dut.__repr__() == 'ImmutableDict({0})'.format(repr(dict([('a', 1), ('b', 2), ('c', 3)])))
        #assert dut.__repr__() == 'ImmutableDict({0})'.format(repr(dict([('a', 1), ('b', 2), ('c', 3)]))) # failed
        #assert dut.__repr__() == 'ImmutableDict({0})'.format(repr(dict(('a', 1), ('b', 2), ('c', 3)) )) # failed
        #assert

# Generated at 2022-06-22 21:21:00.945533
# Unit test for function count
def test_count():
    seq = ['foo', 'bar', 'foo', 'bar', 'baz']
    result = count(seq)
    assert result == {'foo': 2, 'bar': 2, 'baz': 1}


# Generated at 2022-06-22 21:21:03.684458
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert len(test_dict) == 3


# Generated at 2022-06-22 21:21:11.460868
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Test ImmutableDict method difference

    - Create a set of strings
    - Create an ImmutableDict from the set with string length as value
    - Create a second ImmutableDict using the difference method for each string that is a subset of 'test'
    - Verify that the length of the second ImmutableDict is 3 (three items removed)
    """
    test_set = {'test', 'of', 'something', 'else'}
    test_immutdict = ImmutableDict({s: len(s) for s in test_set})
    test_subset = {'of', 'test', 'something'}
    test_diff_immutdict = test_immutdict.difference(test_subset)
    assert len(test_diff_immutdict) == 1

# Generated at 2022-06-22 21:21:13.761791
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    import doctest
    return doctest.testmod(ImmutableDict)

# Generated at 2022-06-22 21:21:25.154883
# Unit test for function is_string
def test_is_string():
    from ansible.module_utils._text import to_text
    # Test string_types
    assert(is_string('string') is True)
    assert(is_string(u'unicode-string') is True)

    # Test non-string types
    assert(is_string(42) is False)
    assert(is_string(None) is False)
    assert(is_string({'key': 'value'}) is False)
    assert(is_string(['item1', 'item2']) is False)

    # Test custom string types
    class TestString:
        def __init__(self, val):
            self.val = to_text(val)

    assert(is_string(TestString('TestString')) is False)
    TestString.__str__ = lambda x: x.val

# Generated at 2022-06-22 21:21:28.508877
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    """Test __getitem__ method of ImmutableDict class."""
    item = ImmutableDict({'a': 1, 'b': 2})
    assert item['a'] == 1
    assert item['b'] == 2


# Generated at 2022-06-22 21:21:34.161340
# Unit test for function is_string
def test_is_string():
    # check if it correctly identifies strings
    assert is_string(u'hello')
    assert is_string('hello')
    # check if it correctly identifies non-strings
    assert not is_string(123)
    assert not is_string([])
    assert not is_string(())
    assert not is_string(None)

# Generated at 2022-06-22 21:21:36.938675
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    test_dict = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert test_dict['key1'] == 'value1'


# Generated at 2022-06-22 21:21:48.357878
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    from ansible.module_utils.six import assertRaisesRegex
    from ansible.module_utils._text import to_bytes

    class FakeImmutableDict(Hashable, Mapping):
        """Dictionary that cannot be updated"""
        def __init__(self, *args, **kwargs):
            self._store = dict(*args, **kwargs)

        def __getitem__(self, key):
            return self._store[key]

        def __iter__(self):
            return self._store.__iter__()

        def __len__(self):
            return self._store.__len__()

        def __eq__(self, other):
            return hash(self) == hash(other)

        def __hash__(self):
            return hash(frozenset(self.items()))


# Generated at 2022-06-22 21:21:57.293168
# Unit test for function count
def test_count():
    assert count([1, 2]) == {1: 1, 2: 1}
    assert count([1, 2, 2, 2, 1]) == {1: 2, 2: 3}
    assert count([1, 2, 2, 2, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3]) == {1: 2, 2: 3, 3: 10}
    assert count(["5", "2", 1, 2, 2, 2, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3]) == {'5': 1, '2': 1, 1: 1, 2: 3, 3: 10}



# Generated at 2022-06-22 21:21:59.486643
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict({'one': 1, 'two': 2})
    assert 2 == len(d)



# Generated at 2022-06-22 21:22:03.142278
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    a = ImmutableDict(one=1, two=2, three=3)
    b = ImmutableDict(one=1, two=2, three=3)
    assert a.__hash__() == b.__hash__()



# Generated at 2022-06-22 21:22:09.640491
# Unit test for function count
def test_count():
    assert count([1, 2, 1, 1, 2]) == {1: 3, 2: 2}
    try:
        count(1)
        raise Exception('Expected exception when argument is not an iterable')
    except Exception:
        pass
    try:
        count('abc')
        raise Exception('Expected exception when argument is a string')
    except Exception:
        pass


# Generated at 2022-06-22 21:22:19.005116
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Unit test for method __repr__ of class ImmutableDict"""

    # Creating an ImmutableDict with int values
    immutable_dict_1 = ImmutableDict(a=1, b=2, c=3)

    # Creating an ImmutableDict with string values
    immutable_dict_2 = ImmutableDict(d='a', e='b', f='c')

    # creating an ImmutableDict with a mix of int and string values
    immutable_dict_3 = ImmutableDict(g=1, h='b', i=3)

    # creating an ImmutableDict with a nested ImmutableDict and a list
    immutable_dict_4 = ImmutableDict(j=[1, 2, 3], k=immutable_dict_3)

    # Asserts to verify the expected output of the __repr__

# Generated at 2022-06-22 21:22:24.124317
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict({'a': 'A', 'b': 'B'})) == 2
    assert len(ImmutableDict(**{'a': 'A', 'b': 'B'})) == 2
    assert len(ImmutableDict(a='A', b='B')) == 2



# Generated at 2022-06-22 21:22:30.297106
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2]) == True
    assert is_sequence(range(1, 10)) == True
    assert is_sequence((1, 2)) == True
    assert is_sequence('abc') == False
    assert is_sequence(set()) == True
    assert is_sequence(set()) == True
    assert is_sequence(dict()) == False
    assert is_sequence({'a': 1}) == False


# Generated at 2022-06-22 21:22:39.739438
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(ImmutableDict())
    assert is_iterable([])
    assert is_iterable(('',))
    assert is_iterable(set())
    assert is_iterable(xrange(0))
    assert not is_iterable(None)
    assert not is_iterable(42)
    assert not is_iterable(3.14)
    assert not is_iterable(u'abc')
    assert not is_iterable('abc')
    assert not is_iterable(b'abc')
    assert not is_iterable(True)
    assert not is_iterable(False)



# Generated at 2022-06-22 21:22:43.097192
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    test_dict = ImmutableDict(one=1, two=2, three=3)
    assert test_dict['one'] == 1
    assert test_dict['two'] == 2
    assert test_dict['three'] == 3


# Generated at 2022-06-22 21:22:46.811720
# Unit test for function is_string
def test_is_string():
    assert is_string(u'string') is True
    assert is_string(b'string') is True
    assert is_string([1, 2, 3]) is False
    assert is_string({u'a': 1}) is False
    assert is_string(1) is False


# Generated at 2022-06-22 21:22:53.240725
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    import copy
    import random

    copy.copy(ImmutableDict())
    hash(ImmutableDict())
    hash(ImmutableDict({'a': 1, 'b': 2, 'c': 3}))
    hash(ImmutableDict({'a': 1, 'b': 2}))
    hash(ImmutableDict({'b': 2, 'a': 1}))

    random_inputs = [
        {},
        {'random': random.random(), 'int': random.randint(0, 10)},
        {'random': random.random(), 'int': random.randint(0, 10), 'abcde': 'fghij', 5: 2}
    ]


# Generated at 2022-06-22 21:22:55.377003
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict({1: 2, 3: 4})
    assert len(d) == 2



# Generated at 2022-06-22 21:23:07.067686
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for testing __eq__ method of ImmutableDict class"""

    immutable_dict1 = ImmutableDict({'a': 1, 'b': 2})
    immutable_dict2 = ImmutableDict({'a': 1, 'b': 2})
    immutable_dict3 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    immutable_dict4 = ImmutableDict({'c': 3, 'a': 1, 'b': 2})
    hashable_dict = {'a': 1, 'b': 2}

    assert immutable_dict1 == immutable_dict2
    assert immutable_dict2 == immutable_dict1
    assert immutable_dict1 == immutable_dict1
    assert immutable_dict1 == immutable_dict3
    assert immutable_dict2 == immutable_dict4
    assert immutable_dict

# Generated at 2022-06-22 21:23:16.924287
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    import pytest
    from ansible.module_utils.six import assertRaisesRegex
    from ansible.module_utils.common.collections import ImmutableDict
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    len_hash = len(str(hash(d)))
    assert hash(d) == hash(d)
    assert hash(d) != hash(d.union({'a': 4}))
    assert hash(d) != hash(d.difference(['b']))
    assert hash(d) != hash(ImmutableDict({'a': 1, 'b': 2, 'c': 3}))
    assert hash(d) != hash(ImmutableDict({'a': 1, 'c': 3, 'b': 2}))
    assert len_hash == len

# Generated at 2022-06-22 21:23:28.660714
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    '''Have an option to choose key type'''
    tick = '\u2713'
    cross = '\u2717'
    original = {
        'name': 'test',
        'version': '1.0',
    }
    overrides = {
        'name': 'test',
        'version': '1.1',
        'software': 'ansible',
    }
    original_id = ImmutableDict(original)
    assert original_id == original
    assert isinstance(original_id, ImmutableDict)
    overrides_id = original_id.union(overrides)
    assert overrides_id == overrides
    assert isinstance(overrides_id, ImmutableDict)
    assert overrides_id != original_id

# Generated at 2022-06-22 21:23:30.504920
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    actual_result = ImmutableDict({'a': 'b'})['a']
    assert actual_result == 'b'


# Generated at 2022-06-22 21:23:34.281438
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    original = ImmutableDict(a=3, b=4, c=5)
    assert original['a'] == 3
    assert original['b'] == 4
    assert original['c'] == 5



# Generated at 2022-06-22 21:23:39.061370
# Unit test for function count
def test_count():
    res = count(['a', 'b', 'a', 'c', 'b', 'd'])
    assert res['a'] == 2
    assert res['b'] == 2
    assert res['c'] == 1
    assert res['d'] == 1

# Generated at 2022-06-22 21:23:41.962264
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():

    d = ImmutableDict()
    assert (iter(d) is not None)

    d = ImmutableDict(a=1)
    assert (iter(d) is not None)



# Generated at 2022-06-22 21:23:46.943131
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    mapping = {'a': 1}
    immutable_mapping = ImmutableDict(mapping)
    overriding_mapping = {'b': 2}
    copy = immutable_mapping.union(overriding_mapping)
    assert copy == ImmutableDict(mapping, **overriding_mapping)

    # test that the original ImmutableDict remained the same
    assert immutable_mapping == ImmutableDict(mapping)


# Generated at 2022-06-22 21:23:55.832073
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({'a': 'b'})
    dict2 = ImmutableDict({'a': 'b'})

    if dict1 == dict2:
        pass
    else:
        raise Exception("dict1 is equal to dict2")

    dict3 = ImmutableDict({'c': 'd'})

    if dict1 == dict3:
        raise Exception("dict1 is not equal to dict3")
    else:
        pass

    try:
        if dict1 == "blah":
            raise Exception("dict1 is equal to 'blah'")
        else:
            pass
    except TypeError:
        pass



# Generated at 2022-06-22 21:24:08.440982
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():

    test_dict = ImmutableDict({'a': 3, 'b': 2, 'c': 'wtf'})

# Generated at 2022-06-22 21:24:15.304502
# Unit test for function is_string
def test_is_string():
    test_dict = [
        ('1', True),
        ('', True),
        (1, False),
        (None, False),
        (['a', 'b'], False)
    ]
    for value, expected in test_dict:
        check_value = is_string(value)
        assert check_value is expected, 'Wrong result for {0}: {1} instead of {2}'.format(value, check_value, expected)


# Generated at 2022-06-22 21:24:24.032043
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    test_dict = ImmutableDict({u'str': u'Hello', u'int': 1, u'list': [1, 2, 3], u'tuple': (1, 2, 3), u'set': set([1, 2, 3]), u'dict': {'one': 1, 'two': 2, 'three': 3}})
    assert test_dict == {u'str': u'Hello', u'int': 1, u'list': [1, 2, 3], u'tuple': (1, 2, 3), u'set': set([1, 2, 3]), u'dict': {'one': 1, 'two': 2, 'three': 3}}

    test_dict_difference = test_dict.difference([u'dict'])

# Generated at 2022-06-22 21:24:30.961215
# Unit test for function is_sequence
def test_is_sequence():
    # set is not a sequence
    assert(not is_sequence(set([1, 2, 3])))

    # tuple is a sequence
    assert(is_sequence((1, 2, 3)))

    # list is a sequence
    assert(is_sequence([1, 2, 3]))

    # string is a sequence if include_strings = True
    assert(is_sequence('123', True))
    assert(is_sequence(u'123', True))

    # string is not a sequence if include_strings = False
    assert(not is_sequence('123', False))
    assert(not is_sequence(u'123', False))

    # empty dict is not a sequence
    assert(not is_sequence({}))

    # empty list is a sequence
    assert(is_sequence([]))



# Generated at 2022-06-22 21:24:37.657397
# Unit test for function is_string
def test_is_string():
    # Test strings
    assert is_string('test')
    assert is_string(u'test')
    assert is_string(b'test')

    # Test various iterables
    assert not is_string([])
    assert not is_string({})
    assert not is_string((x for x in range(3)))
    assert not is_string(set())
    assert not is_string(2)



# Generated at 2022-06-22 21:24:45.738110
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) == {'a': 1}
    assert ImmutableDict({'a': 1}) == dict({'a': 1})
    assert ImmutableDict({'a': 1}) != {'a': 2}
    assert ImmutableDict({'a': 1}) != dict({'a': 2})
    assert ImmutableDict({'a': 1}) != []

# Generated at 2022-06-22 21:24:52.376575
# Unit test for function is_string
def test_is_string():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    for v in (
        'lalala',
        b'lalala',
        1,
        dict,
        callable,
        vault.encrypt('lalala'),
    ):
        print(('Text: {0} = {1}'.format(v, is_string(v))))



# Generated at 2022-06-22 21:24:58.383412
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict()
    test_passed = str(d) == "ImmutableDict({'key': 'value'})"
    # TODO: replace with assert after a unit test framework is chosen
    if not test_passed:
        raise Exception("test_ImmutableDict___repr___failed")


# Generated at 2022-06-22 21:25:02.601037
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
	x=ImmutableDict({'a':3,'b':5})
	y=x.__getitem__('b')
	assert y==5
	print('test passed')



# Generated at 2022-06-22 21:25:13.632842
# Unit test for function count
def test_count():  # pylint: disable=unused-argument
    """Unit test for count function"""
    assert count('abcba') == {'a': 2, 'b': 2, 'c': 1}
    assert count('abbab') == {'a': 2, 'b': 3}
    assert count('abbab') != {'a': 2, 'b': 2}
    assert count('abbab') != {'a': 2, 'b': 2, 'c': 1}
    assert count('ab') == {'a': 1, 'b': 1}
    assert count('a') == {'a': 1}
    assert count('') == {}
    assert count([1, 2, 3, 2, 1]) == {1: 2, 2: 2, 3: 1}

# Generated at 2022-06-22 21:25:21.904108
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():

    import json
    import os
    import random
    import string
    import sys

    test_pass = True
    # Test for objects that cannot be hashed
    unhashable_objects = [
        range(10),
        set([1, 2, 3, 4, 5]),
        frozenset([1, 2, 3, 4, 5]),
        dict(),
        dict(a=1, b=2, c=3),
        ImmutableDict(a=1, b=2, c=3),
    ]

    # This can be used to check whether unhashable objects are hashed
    # Use this option with caution, unless you want to let the script run for
    # a long time and eat up your memory
    force_hashing = False


# Generated at 2022-06-22 21:25:29.237297
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_dict = ImmutableDict({"A": "a", "B": "b", "C": "c", "D": "d", "E": "e"})
    removed = ImmutableDict({"A": "a", "C": "c"})
    expected = ImmutableDict({"B": "b", "D": "d", "E": "e"})
    assert test_dict.difference(("A", "C")) == expected

# Generated at 2022-06-22 21:25:33.943764
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():

    # create an ImmutableDict
    immutable_dict = ImmutableDict({'key':'value'})

    # get the value that is mapped to 'key'
    immutable_dict['key']

    # get the value that is mapped to 'non_key'
    immutable_dict['non_key']



# Generated at 2022-06-22 21:25:45.885530
# Unit test for function is_sequence
def test_is_sequence():
    """Validate that is_sequence is behaving as expected"""
    # pylint: disable=too-many-branches
    assert(is_sequence([1, 2, 3]))
    assert(is_sequence((1, 2, 3)))
    assert(is_sequence(set([1, 2, 3])))
    assert(not is_sequence(1))
    assert(not is_sequence(None))
    assert(not is_sequence('abc'))
    assert(not is_sequence(b'abc'))
    assert(is_sequence([1, 2, 3], include_strings=True))
    assert(is_sequence((1, 2, 3), include_strings=True))
    assert(is_sequence(set([1, 2, 3]), include_strings=True))

# Generated at 2022-06-22 21:25:52.023034
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict(a=1)
    b = ImmutableDict({'a': 1})
    c = ImmutableDict(a=1)
    d = ImmutableDict(a=2)

    assert a == b
    assert a == c
    assert a != d
    assert not a == 'foo'
    assert not a == None

# Generated at 2022-06-22 21:26:00.733365
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence([1])
    assert is_sequence(tuple())
    assert is_sequence(tuple([1]))
    assert is_sequence(set())
    assert is_sequence(set([1]))
    assert not is_sequence(1)
    assert not is_sequence(None)
    assert not is_sequence(dict())

    assert is_sequence([], include_strings=True)
    assert is_sequence([1], include_strings=True)
    assert is_sequence(tuple(), include_strings=True)
    assert is_sequence(tuple([1]), include_strings=True)
    assert is_sequence(set(), include_strings=True)
    assert is_sequence(set([1]), include_strings=True)

# Generated at 2022-06-22 21:26:06.939290
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d = dict(a=1, b=2, c=3)
    id = ImmutableDict(d)
    id_d = id.difference(['a'])
    assert 'a' in id
    assert 'a' not in id_d
    assert 'b' in id_d
    assert 'c' in id_d
    assert len(id_d) == 2


# Generated at 2022-06-22 21:26:18.203206
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    import unittest
    import copy

    class TestImmutableDict(unittest.TestCase):

        def setUp(self):
            self.my_immutable_dict = ImmutableDict({'a': 1, 'b': 2})
            self.my_mutable_dict = {'c': 3, 'd': 4}

        def test_init(self):
            self.assertEqual(self.my_immutable_dict, ImmutableDict(a=1, b=2))

        def test_init_from_dict(self):
            self.assertEqual(self.my_immutable_dict, ImmutableDict(self.my_mutable_dict))

# Generated at 2022-06-22 21:26:21.904671
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    mydict = ImmutableDict({'a': 1, 'b': 2})
    assert len(mydict) == 2



# Generated at 2022-06-22 21:26:24.754339
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict(dict(a=1))
    actual = []
    for k in d:
        actual.append(k)
    assert actual == ['a']


# Generated at 2022-06-22 21:26:32.860776
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable([])
    assert is_iterable((1, 2, 3))
    assert is_iterable(())
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(set([]))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable({})
    assert is_iterable(range(3))

    assert not is_iterable('')
    assert not is_iterable(object())



# Generated at 2022-06-22 21:26:36.349944
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert repr(ImmutableDict()) == 'ImmutableDict({})'
    assert repr(ImmutableDict(dict(a=1, b=2))) == "ImmutableDict({'a': 1, 'b': 2})"


# Generated at 2022-06-22 21:26:41.124463
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    test_dict = {'key_1': 'key_1', 'key_2': 'key_2'}
    immutable_dict = ImmutableDict(test_dict)
    assert immutable_dict['key_1'] == 'key_1'
    assert immutable_dict['key_2'] == 'key_2'


# Generated at 2022-06-22 21:26:47.278947
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test __eq__ for ImmutableDict
    """
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    dict3 = ImmutableDict({'a': 1, 'b': 3})
    dict4 = ImmutableDict({'a': 2, 'b': 2})
    dict5 = ImmutableDict()
    dict6 = {}
    assert dict1 == dict2
    assert dict1 != dict3
    assert dict1 != dict4
    assert dict1 != dict5
    assert dict1 != dict6

# Generated at 2022-06-22 21:26:55.884660
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    assert ImmutableDict().union({1:2, 3:4}) == ImmutableDict({1:2, 3:4})
    assert ImmutableDict({1:2, 3:4}).union({1:10, 5:6}) == ImmutableDict({1:10, 3:4, 5:6})
    assert ImmutableDict({1:2, 3:4, 5:6}).union({1:10}) == ImmutableDict({1:10, 3:4, 5:6})
    assert ImmutableDict({1:2, 3:4, 5:6}).union({}) == ImmutableDict({1:2, 3:4, 5:6})

# Generated at 2022-06-22 21:27:04.529201
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    dictionary = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})
    assert dictionary == ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})
    assert dictionary != ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    assert dictionary != ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 99, 'e': 5})
    assert dictionary != ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6})

# Generated at 2022-06-22 21:27:07.925383
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    dictA = ImmutableDict({'name': 'apple', 'color': 'red'})
    assert dictA['name'] == 'apple'
    assert dictA['color'] == 'red'

# Generated at 2022-06-22 21:27:12.484026
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    subtractive_iterable = ['a', 'c']
    expected = ImmutableDict({'b': 2})
    assert original.difference(subtractive_iterable) == expected


# Generated at 2022-06-22 21:27:17.579172
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    original_dict = {u'key1': u'value1', u'key2': u'value2', u'key3': u'value3'}
    immutabledict = ImmutableDict(original_dict)
    assert len(original_dict) == len(immutabledict)


# Generated at 2022-06-22 21:27:24.954583
# Unit test for function is_string
def test_is_string():
    """Test if the function is_string works as expected."""
    assert is_string("test")
    assert is_string("u'uni'")
    assert is_string("")
    assert is_string("b'bytestring'")
    assert not is_string([])
    assert not is_string({'key': 'value'})
    assert not is_string(1)



# Generated at 2022-06-22 21:27:28.165021
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([]) == True
    assert is_sequence([0,1,2]) == True
    assert is_sequence('xyz') == False
    assert is_sequence('xyz', True) == True



# Generated at 2022-06-22 21:27:33.628392
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    idict = ImmutableDict({'a': 1, 'b': 2})
    assert idict['a'] == 1, 'Test 1 failed'
    assert idict['b'] == 2, 'Test 2 failed'
    try:
        idict['c']
    except KeyError:
        assert True, 'Test 3 failed'
    else:
        assert False, 'Test 3 failed'


# Generated at 2022-06-22 21:27:35.578011
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert len(a) == 3


# Generated at 2022-06-22 21:27:45.228381
# Unit test for function is_iterable
def test_is_iterable():
    for iterable in [[], {"key": "value"}, ("a", "tuple")]:
        assert is_iterable(iterable) is True

    for not_iterable in [None, 5, 5.5, "string", b"bytes"]:
        assert is_iterable(not_iterable) is False


if __name__ == '__main__':
    # Run unit tests
    import sys
    import pytest

    exit_status = pytest.main(['-q', __file__] + sys.argv[1:])  # pylint: disable=no-value-for-parameter
    sys.exit(exit_status)

# Generated at 2022-06-22 21:27:48.032672
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    immutable_dict = ImmutableDict({'a_key': 'a_value'})
    assert list(immutable_dict.__iter__()) == ['a_key']



# Generated at 2022-06-22 21:27:58.088941
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    base_dict = ImmutableDict({'a': 1, 'b': 2})

    result = base_dict.union({'a': 2, 'c': 3})
    assert result == ImmutableDict({'a': 2, 'b': 2, 'c': 3})

    result = base_dict.union({'x': 4, 'y': 5, 'z': 6})
    assert result == ImmutableDict({'a': 1, 'b': 2, 'x': 4, 'y': 5, 'z': 6})

    result = base_dict.union({'a': 2, 'c': 3})
    assert result != ImmutableDict({'a': 1, 'b': 2, 'c': 3})

    result = base_dict.union({'a': 2, 'c': 3})

# Generated at 2022-06-22 21:28:01.753908
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    with pytest.raises(TypeError) as e_info:
        assert len(ImmutableDict)
    assert '__len__' in e_info.value.args[0]



# Generated at 2022-06-22 21:28:11.905492
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    m1 = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})
    m2 = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})
    m3 = ImmutableDict({1: 'one', 2: 'two'})
    m4 = ImmutableDict({1: 'one', 2: 'two', 3: 'three', 4: 'four'})

    assert m1.__hash__() == m2.__hash__()
    assert m1.__hash__() != m3.__hash__()
    assert m1.__hash__() != m4.__hash__()


# Generated at 2022-06-22 21:28:14.452665
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict(aa=1)
    assert d.__getitem__('aa') == 1


# Generated at 2022-06-22 21:28:25.460459
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # Test hashing for empty dictionary
    assert hash(ImmutableDict()) == hash(frozenset())

    # Test hashing for dictionary with one element
    assert hash(ImmutableDict({'test': 1})) == hash(frozenset({'test': 1}))

    # Test hashing for dictionaries with several elements
    assert hash(ImmutableDict({'test': 1, 'test2': 2})) == hash(frozenset({'test2': 2, 'test': 1}))

    # Test hashing for different dictionaries
    assert hash(ImmutableDict({'test': 1})) != hash(ImmutableDict())

    # Test hashing for dictionaries with the same keys but different value
    assert hash(ImmutableDict({'test': 1})) != hash(ImmutableDict({'test': 2}))

# Generated at 2022-06-22 21:28:36.669627
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import copy
    idict1 = ImmutableDict({'key1': 'val1', 'key2': 'val2'})
    idict2 = idict1
    idict3 = ImmutableDict({'key1': 'val1', 'key2': 'val2'})
    idict4 = ImmutableDict({'key1': 'val1', 'key2': 'val2'})
    idict5 = ImmutableDict({'key1': 'val1'})
    idict6 = ImmutableDict({'key1': 'val1', 'key2': 'val2', 'key3': 'val3'})
    idict7 = ImmutableDict({'key1': 'val1', 'key2': 'val2', 'key3': 'val3', 'key4': 'val4'})
    id

# Generated at 2022-06-22 21:28:39.344574
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    test_instance = ImmutableDict([(1, 2), (3, 4)])
    result = list(test_instance.__iter__())
    assert result == [(1, 2), (3, 4)]


# Generated at 2022-06-22 21:28:49.540800
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    d1 = ImmutableDict({'a': 2})
    d2 = d1.union({'b': 3})
    d3 = d1.union({'a': 3})
    # Verifies that the new dict has all of the same items and no more, and that they are the same
    assert set(d1.items()) | set([('b', 3)]) == set(d2.items())
    # Verifies that the new dict has all of the same items, but with overriding values
    assert set([('a', 3)]) | set(d1.items()) - set([('a', 2)]) == set(d3.items())


# Generated at 2022-06-22 21:28:54.883898
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """
    Test method __repr__ of class ImmutableDict
    """
    instance_of_ImmutableDict = ImmutableDict({'a': 'b', 'c': 'd'})
    assert repr(instance_of_ImmutableDict) == "ImmutableDict({'a': 'b', 'c': 'd'})"

# Generated at 2022-06-22 21:29:01.856240
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert is_sequence(set())
    assert is_sequence(tuple([1, 2, 3]))
    assert is_sequence((x for x in range(3)))
    assert not is_sequence(3)
    assert not is_sequence(dict())
    assert not is_sequence(ImmutableDict())

# Generated at 2022-06-22 21:29:08.090077
# Unit test for function count
def test_count():
    import pytest
    from .common import ansible_run

    with pytest.raises(Exception):
        count(None)

    assert count([1, 2, 4 , 5, 6, 1, 2, 5, 3, 3, 3, 3, 9, 0, 0, 8, 9, 8]) == {1: 2, 2: 2, 4: 1, 5: 2, 6: 1, 3: 4, 9: 2, 0: 2, 8: 2}

# Generated at 2022-06-22 21:29:11.990199
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict([('a', 1), ('b', 2), ('c', 3)])
    assert len(d) == 3



# Generated at 2022-06-22 21:29:16.056884
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert is_string(u'foo')
    assert is_string(b'foo')
    assert not is_string([])
    assert not is_string({})



# Generated at 2022-06-22 21:29:19.921860
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    immutabledict = ImmutableDict({"key1": "value1", "key2": "value2"})
    assert immutabledict["key1"] == "value1"
    assert immutabledict["key2"] == "value2"
    assert immutabledict["key3"] is None


# Generated at 2022-06-22 21:29:26.982040
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():

    class A:
        pass

    # Define variables
    dict1 = {'a': 1, 'b': 2, 'c': 3}
    dict2 = dict(a=1, b=2, c=3)
    dict3 = ImmutableDict(a=1, b=2, c=3)
    dict4 = {'a': 2, 'b': 2, 'c': 3}
    dict5 = dict(a=1, b=2, c=3, d=4)
    dict6 = ImmutableDict(a=1, b=2, c=3, d=4)
    dict7 = {'a': A(), 'b': A()}
    dict8 = dict(a=A(), b=A())
    dict9 = ImmutableDict(a=A(), b=A())
    dict10

# Generated at 2022-06-22 21:29:30.177534
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict(a=1, b=2, c=3)) == 3



# Generated at 2022-06-22 21:29:33.741426
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d = ImmutableDict(dict(foo='bar', baz='qux'))
    assert hash(d) == hash(frozenset(dict(foo='bar', baz='qux').items()))



# Generated at 2022-06-22 21:29:45.702309
# Unit test for function count
def test_count():
    from ansible.module_utils._text import to_native
    assert count([]) == {}
    assert count(('a', 'a', 'b', 1)) == {'a': 2, 'b': 1, 1: 1}
    assert count(('a', 'b', 'a', 'a', 'b', 'c', 'd', 'e', 'd', 'd', 'd', 'f')) == {
        'a': 3,
        'b': 2,
        'c': 1,
        'd': 4,
        'e': 1,
        'f': 1,
    }

    try:
        count('a')
        assert False, 'count should fail when a non iterable is provided'
    except Exception as e:
        assert to_native(e) == 'Argument provided  is not an iterable'



# Generated at 2022-06-22 21:29:48.864173
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d1 = ImmutableDict([('a', 1), ('b', 2), ('c', 3)])
    assert len(d1) == 3


# Generated at 2022-06-22 21:29:54.266820
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    dict_a = {'a': 1, 'b': 2}
    dict_b = {'b': 3, 'c': 4}
    dict_ab = {'a': 1, 'b': 3, 'c': 4}

    assert ImmutableDict(dict_a)['a'] == 1
    assert ImmutableDict(dict_a, **dict_b) == dict_ab
    assert ImmutableDict(dict_a).union(dict_b) == dict_ab
    assert ImmutableDict(dict_a).difference(dict_b) == {'a': 1}

# Generated at 2022-06-22 21:30:02.625891
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert not is_sequence(set([1, 2, 3]))
    assert is_sequence(tuple([1, 2, 3]))
    assert not is_sequence(123)
    assert is_sequence(xrange(1, 10))
    assert not is_sequence('string')
    assert not is_sequence(b'bytes')
    assert is_sequence('string', include_strings=True)
    assert is_sequence(b'bytes', include_strings=True)
    assert not is_sequence(None)
    assert not is_sequence(object())
