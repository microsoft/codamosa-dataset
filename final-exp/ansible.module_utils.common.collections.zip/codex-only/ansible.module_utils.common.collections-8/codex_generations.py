

# Generated at 2022-06-22 21:20:07.046494
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    a = ImmutableDict({'a': 1})
    b = ImmutableDict({'a': 1, 'b': 2})
    c = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    assert a.difference(['b']) == a
    assert b.difference(['c']) == b
    assert b.difference(['a', 'b']) != b
    assert c.difference(['b', 'c']) == a
    assert c.difference(['a', 'b', 'c']) != b
    assert d.difference(['a', 'b', 'c', 'd']) != a

# Generated at 2022-06-22 21:20:14.397723
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    not_immutable = {'foo': 'bar', 'baz': 'quux'}
    immutable = ImmutableDict(not_immutable)
    overriding = {'foo': 'baz', 'quux': 'quuz'}
    union = immutable.union(overriding)
    assert union['foo'] == 'baz'
    assert union['baz'] == 'quux'
    assert union['quux'] == 'quuz'


# Generated at 2022-06-22 21:20:19.020886
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    data = ImmutableDict(a=1, b=2, c=3)
    if data['a'] != 1:
        return False
    if data['b'] != 2:
        return False
    if data['c'] != 3:
        return False
    return True


# Generated at 2022-06-22 21:20:22.561720
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(1)
    assert is_iterable([])
    assert is_iterable(range(10))
    assert is_iterable(u"string")
    assert is_iterable(b"bytes")



# Generated at 2022-06-22 21:20:33.287980
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # Test to ensure __hash__ works with all types of supported keys
    test_keys = [None, '', 'a', 'a1', (1, 2), (1, '2'), (1,), [1], [1, '2'], {1: 2}, {1: 2, 3: 4}, ImmutableDict(a=1),
                 ImmutableDict(a=1, b=2)]

    keys_hash = [hash(x) for x in test_keys]
    keys_set = set(test_keys)
    assert len(keys_hash) == len(keys_set)

    # Test to ensure __hash__ works with all types of supported values

# Generated at 2022-06-22 21:20:44.203137
# Unit test for function is_sequence
def test_is_sequence():
    def assert_is_sequence(seq):
        assert is_sequence(seq, include_strings=False), seq
        assert is_sequence(seq, include_strings=True), seq

    def assert_is_not_sequence(seq):
        assert not is_sequence(seq, include_strings=False)
        assert not is_sequence(seq, include_strings=True)

    assert_is_sequence([])
    assert_is_sequence([1])
    assert_is_sequence((1,))
    assert_is_sequence(set((1,)))
    assert_is_sequence(frozenset((1,)))
    assert_is_sequence({1: 1})
    assert_is_sequence(ImmutableDict())

    if not is_sequence_a_string:
        assert_is_sequence(u'abc')
        assert_

# Generated at 2022-06-22 21:20:53.565266
# Unit test for function count
def test_count():
    the_list = [1, 1, 2, 2, 2, 3, 3, 3, 3]
    the_dict = {'a': 5, 'b': 3, 'c': 1}
    res = count(the_list)
    assert(res[1] == 2 and res[2] == 3 and res[3] == 4)
    res = count(the_dict)
    assert(res['a'] == 5 and res['b'] == 3 and res['c'] == 1 and res.get('d') == None)



# Generated at 2022-06-22 21:21:04.902918
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a = ImmutableDict(one=1, two=2, three=3)
    b = ImmutableDict(four=4, five=5, six=6)
    c = ImmutableDict(four=4, five=5, six=6, three=3)

    assert a.union(b) == ImmutableDict(one=1, two=2, three=3, four=4, five=5, six=6)
    assert b.union(a) == ImmutableDict(four=4, five=5, six=6, one=1, two=2, three=3)
    assert b.union(c) == ImmutableDict(four=4, five=5, six=6, three=3)

# Generated at 2022-06-22 21:21:10.439792
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(MutableMapping())
    assert is_iterable(ImmutableDict())
    assert not is_iterable(5)
    assert is_iterable(5, include_strings=True)
    assert not is_iterable('a string', include_strings=False)
    assert is_iterable('a string', include_strings=True)



# Generated at 2022-06-22 21:21:13.761791
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d1 = ImmutableDict({"a": "v1"})
    assert hash(d1) == hash(frozenset(d1.items()))



# Generated at 2022-06-22 21:21:25.238949
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    def assert_(condition, message):
        if not condition: raise AssertionError(message)

    def check(d):
        assert_(isinstance(d, ImmutableDict), "This is not an ImmutableDict")
        assert_(hash(d) == hash(ImmutableDict(d)), "Hashes of ImmutableDict differ:\n{0}\n{1}".format(d,
                                                                                                       ImmutableDict(d)))
        assert_(isinstance(d.union({'a': 'b'}), ImmutableDict), "Returned a wrong instance.")

# Generated at 2022-06-22 21:21:29.933721
# Unit test for function count
def test_count():
    """Unit tests for function count"""
    result = count("abracadabra")
    assert len(result) == 5
    assert result['a'] == 5
    assert result['b'] == 2
    assert result['r'] == 2
    assert result['c'] == 1
    assert result['d'] == 1
    assert result.get('e', 0) == 0



# Generated at 2022-06-22 21:21:36.211670
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """
    Check that the hash of two ImmutableDict instances is equal if their contents are equal
    and is unequal if their contents are not equal.
    """
    test_dict_1 = ImmutableDict({1:2, 3:4})
    test_dict_2 = ImmutableDict({1:2, 3:4})
    test_dict_3 = ImmutableDict({3:4, 1:2})
    test_dict_4 = ImmutableDict({1:2, 5:6})
    test_dict_5 = ImmutableDict({1:2, 3:4, 5:6})

    assert test_dict_1.__hash__() == test_dict_2.__hash__()
    assert test_dict_1.__hash__() != test_dict_3.__hash__()
    assert test_

# Generated at 2022-06-22 21:21:39.823347
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    idict = ImmutableDict({'a': 1, 'b': 2})
    items = list(idict)
    assert items == ['a', 'b']
    items.sort()
    assert items == ['a', 'b']


# Generated at 2022-06-22 21:21:47.374704
# Unit test for function count
def test_count():
    for test_input in [
        'string_to_count',
        (1, 2, 3, 4, 5, 6),
        (1, 2, 3, 3, 4, 4, 5, 5, 5, 6),
        [1, 2, 3, 4, 5, 6],
        [1, 2, 3, 3, 4, 4, 5, 5, 5, 6],
        {1, 2, 3, 4, 5, 6},
        {1: 2, 3: 4, 5: 6},
        {1, 2, 3, 3, 4, 4, 5, 5, 5, 6},
        {1: 2, 2: 3, 3: 4}
    ]:
        result = count(test_input)
        assert isinstance(result, dict)

# Generated at 2022-06-22 21:21:53.108462
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    TEST_DATA = {'x': 1, 'y': 2, 'z': 3}
    original_immutable = ImmutableDict(TEST_DATA)
    result = original_immutable.__repr__()
    assert result == "ImmutableDict({'x': 1, 'y': 2, 'z': 3})"



# Generated at 2022-06-22 21:21:59.239764
# Unit test for function count
def test_count():
    values = [1, 2, 1, 2, 3, 4, 3, 2, 3, 2, 1, 2]
    c = count(values)
    assert(c == {1: 3, 2: 5, 3: 3, 4: 1})


# Generated at 2022-06-22 21:22:05.623344
# Unit test for function is_string
def test_is_string():
    assert is_string("string")
    assert is_string("")
    assert is_string(u"unicode string")
    assert is_string(u"")
    assert is_string(b"string")
    assert is_string(b"")
    assert not is_string(1)
    assert not is_string(1.0)
    assert not is_string({"a": 1})
    assert not is_string((1,))
    assert not is_string([1])


# Generated at 2022-06-22 21:22:10.716782
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    import pytest
    expected = ImmutableDict({"key": "value"})
    actual = ImmutableDict({"key": "value"})
    assert expected == actual
    assert actual.__repr__() == "ImmutableDict({'key': 'value'})"



# Generated at 2022-06-22 21:22:15.198289
# Unit test for function is_string
def test_is_string():
    assert is_string(b'some bytes')
    assert is_string('some text')
    assert not is_string([])
    assert not is_string((1, 2))
    assert not is_string({})
    assert not is_string(object())
    assert not is_string(123)


# Generated at 2022-06-22 21:22:24.864840
# Unit test for function is_string
def test_is_string():

    assert(is_string('test string'))
    assert(is_string(b'test string'))

    class FalseString(Sequence):
        def __getitem__(self, index):
            return 'string'
        def __len__(self):
            return 1

    class TrueString(object):
        def __getitem__(self, index):
            return 'string'
        def __len__(self):
            return 1
        __ENCRYPTED__ = True

    assert(not is_string(FalseString()))
    assert(is_string(TrueString()))


# Generated at 2022-06-22 21:22:30.366429
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    union_d = ImmutableDict({'a': 1, 'b': 2}).union({'b': 3, 'c': 4})
    assert isinstance(union_d, ImmutableDict)
    assert union_d.__hash__() == ImmutableDict({'a': 1, 'b': 3, 'c': 4}).__hash__()


# Generated at 2022-06-22 21:22:40.580383
# Unit test for function is_sequence
def test_is_sequence():
    seq_true = [i for i in range(3)]
    seq_false = {1}
    seq_false_string = 's'
    seq_true_string = ['s']
    assert is_sequence(seq_true)
    assert is_sequence(seq_true_string)
    assert not is_sequence(seq_false)
    assert not is_sequence(seq_false_string)
    assert is_sequence(seq_true, include_strings=True)
    assert is_sequence(seq_true_string, include_strings=True)
    assert not is_sequence(seq_false, include_strings=True)
    assert is_sequence(seq_false_string, include_strings=True)

# Generated at 2022-06-22 21:22:49.487252
# Unit test for function is_iterable
def test_is_iterable():
    class my_iterable(object):
        def __init__(self, *args):
            self.var = args

        def __iter__(self):
            return iter(self.var)

    class my_non_iterable(object):
        def __init__(self, *args):
            self.var = args

    # Test iterability of non iterable object
    assert is_iterable(my_non_iterable(1,2,3)) == False
    # Test iterability of iterable object
    assert is_iterable(my_iterable(1,2,3)) == True
    # Test iterability of a string
    assert is_iterable('string') == False
    # Test iterability of a dictionary
    assert is_iterable({'one': 1}) == True
    # Test iterability of a tuple

# Generated at 2022-06-22 21:22:54.091429
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    c = ImmutableDict(a=1, b=2)
    d = ImmutableDict(b="World", c="Hello")
    assert c.union(d) == {"a": 1, "b": "World", "c": "Hello"}


# Generated at 2022-06-22 21:23:02.446746
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    original = ImmutableDict(key='value', other=['items', 'here'])

    assert original == original
    assert original == {'key': 'value', 'other': ['items', 'here']}
    assert original == ImmutableDict(key='value', other=['items', 'here'])

    assert original != object()
    assert original != MutableMapping()
    assert original != {'key': 'value', 'other': ['items', 'here'], 'extra': 'values'}
    assert original != ImmutableDict(key='value', other=['items', 'here', 'not_the_same'])

# Generated at 2022-06-22 21:23:04.845455
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence((1, ))
    assert is_sequence(range(10))
    assert not is_sequence([1, 2, 3], include_strings=True)
    assert is_sequence('abc')



# Generated at 2022-06-22 21:23:10.336324
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """
    verify __hash__ function only returns True when both dict have equal values
    """
    testDict1 = ImmutableDict({'1': 2, '2': 3, '3': 4})
    testDict2 = ImmutableDict({'1': 2, '2': 3, '3': 4})
    testDict3 = ImmutableDict({'1': 2, '2': 3})
    assert testDict1.__hash__() == testDict2.__hash__()
    assert testDict1.__hash__() != testDict3.__hash__()


# Generated at 2022-06-22 21:23:21.604813
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    # Create an ImmutableDict
    ImmutableDict1 = ImmutableDict({'a': 'b'})
    # Create a new ImmutableDict by adding members of a mapping to the original ImmutableDict
    # In this case, ImmutableDict2 will be {'a': 'b', 'c': 5}
    ImmutableDict2 = ImmutableDict1.union({'c': 5})
    # Create a new ImmutableDict by replacing a member of the original ImmutableDict
    # In this case, ImmutableDict3 will be {'a': 3, 'c': 5}
    ImmutableDict3 = ImmutableDict2.union({'a': 3})
    # Create a new ImmutableDict by replacing a member of the original ImmutableDict
    # In this case, ImmutableDict4 will

# Generated at 2022-06-22 21:23:27.467883
# Unit test for function count
def test_count():
    li = [1, 1, 2, 3, 4, 4, 4]
    expected_counters = {1: 2, 2: 1, 3: 1, 4: 3}
    assert(expected_counters == count(li))
    assert(expected_counters == count(set(li)))


# This definition of first_or_default must match the definition used in
# ansible.utils.context_objects. AnsibleContextBase._default_vars

# Generated at 2022-06-22 21:23:36.661175
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    """
    Test union method of ImmutableDict
    """
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    overriding = {'c': 4, 'd': 5}
    expected = {'a': 1, 'b': 2, 'c': 4, 'd': 5}
    union = original.union(overriding)

    assert union == expected
    # Note: the below might seem to be a more straightforward assert.
    #     assert union._store == expected
    # Unfortunately, assertImmutableDict fails if the two dicts are not the same
    # instance. The reason is that Hashable.__eq__ looks for matching hashes,
    # and we cannot compare hashes of two different instances of the same
    # dictionary.
    assert original.difference(overriding) == ImmutableD

# Generated at 2022-06-22 21:23:46.607497
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    before = ImmutableDict({'a': 'b', 'b': 'c'})
    after = before.difference(['a', 'b'])
    if list(after.keys()) != []:
        raise Exception("Unable to remove keys from ImmutableDict")

    before = ImmutableDict({'a': 'b', 'b': 'c'})
    after = before.difference(['c'])
    if list(after.keys()) != ['a', 'b']:
        raise Exception("Did not remove non-existant key from ImmutableDict")

    before = ImmutableDict({'a': 'b', 'b': 'c'})
    after = before.difference(['a', 'b', 'd', 'e'])

# Generated at 2022-06-22 21:23:57.094458
# Unit test for function is_sequence
def test_is_sequence():
    a_tuple = (1, 2, 3)
    a_str = 'string'
    a_list = [1, 2, 3]
    a_dict = {'a': 1}
    a_obj = object()

    assert is_sequence(a_tuple)
    assert not is_sequence(a_str)
    assert is_sequence(a_list)
    assert not is_sequence(a_dict)
    assert not is_sequence(a_obj)

    assert is_sequence(a_tuple, include_strings=True)
    assert is_sequence(a_str, include_strings=True)
    assert is_sequence(a_list, include_strings=True)
    assert not is_sequence(a_dict, include_strings=True)

# Generated at 2022-06-22 21:24:00.188329
# Unit test for function is_string
def test_is_string():
    assert is_string(u'test')
    assert is_string('test')
    assert not is_string(1)
    assert not is_string([])


# Generated at 2022-06-22 21:24:05.088286
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    x = {"a": "b"}
    y = {'a': 'b'}
    assert ImmutableDict(x) == ImmutableDict(x)
    assert ImmutableDict(x) == ImmutableDict(y)



# Generated at 2022-06-22 21:24:06.874611
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    result = ImmutableDict(test_key1='value1', test_key2=2)
    assert list(result) == ['test_key1', 'test_key2']



# Generated at 2022-06-22 21:24:10.965630
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert(all('a' <= x <= 'c' for x in test_dict))



# Generated at 2022-06-22 21:24:17.594853
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    original = {'a': 1, 'b': 2, 'c': 3}
    expected = {'a': 1, 'b': 2, 'c': 3}
    immutable_dict = ImmutableDict(original)
    assert original == expected
    number_of_expected_keys = len(expected)
    assert len(immutable_dict) == number_of_expected_keys
    for key in expected.keys():
        assert immutable_dict[key] == expected[key]


# Generated at 2022-06-22 21:24:24.847612
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    x = ImmutableDict({'a': '1', 'b': '2', 'c': '3'})
    iterator = x.__iter__()
    assert next(iterator) == 'a'
    assert next(iterator) == 'b'
    assert next(iterator) == 'c'

    try:
        next(iterator)
    except StopIteration:
        pass
    else:
        assert False


# Generated at 2022-06-22 21:24:28.817177
# Unit test for function count
def test_count():
    test_iterable = ['foo', 'bar', 'xyzzy', 'bar', 'baz', 'foo', 'foo']
    result = count(test_iterable)
    assert result == {'foo': 3, 'bar': 2, 'xyzzy': 1, 'baz': 1}
    try:
        count('foo')
    except Exception:
        pass
    else:
        assert False, 'Should get an exception from count'



# Generated at 2022-06-22 21:24:34.889493
# Unit test for function is_string
def test_is_string():
    assert is_string('a')
    assert is_string(u'a')
    assert is_string(b'a')
    assert not is_string(5)
    assert not is_string(['a'])
    assert not is_string(set(['a']))
    assert not is_string({'a': 1})


# Generated at 2022-06-22 21:24:46.913492
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    b = ImmutableDict({'a': 1, 'b':2})
    assert b.difference(['a']) == ImmutableDict({'b':2})
    assert b.difference('a') == ImmutableDict({'b':2}) # test method with sequence
    assert b.difference(('a','b')) == ImmutableDict({}) # test method with sequence
    try:
        assert b.difference({'a','b'}) == ImmutableDict({}) # test method with sequence
    except:
        import traceback
        print(traceback.format_exc())
        raise Exception("Set should be iterable for difference method")
    try:
        assert b.difference(set('a')) == ImmutableDict({}) # test method with sequence
    except:
        import traceback
        traceback

# Generated at 2022-06-22 21:24:59.345268
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Test the ImmutableDict.difference(self, subtractive_iterable)
    Create an ImmutableDict as a combination of the original minus keys in subtractive_iterable

    :arg subtractive_iterable: Any iterable containing keys that should not be present in the
        new ImmutableDict
    :return: A copy of the ImmutableDict with keys from the subtractive_iterable removed
    """
    in_dict = {'test': {'testA': 'testB', 'testB': 'testA'}}
    out_dict = ImmutableDict(in_dict)

    result = out_dict.difference(['test'])
    assert result == ImmutableDict({})

    result = out_dict.difference(['test', 'testA'])
    assert result == ImmutableDict({})


# Generated at 2022-06-22 21:25:03.932482
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # ImmutableDict of the same content should have the same hash
    id1 = ImmutableDict({"a": "b", "c": "d"})
    id2 = ImmutableDict({"c": "d", "a": "b"})
    assert hash(id1) == hash(id2)



# Generated at 2022-06-22 21:25:12.791373
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    i1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})
    i2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})
    i3 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 6})
    i4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    i5 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 5, 'e': 4})

# Generated at 2022-06-22 21:25:19.259536
# Unit test for function is_iterable
def test_is_iterable():
    class UnimplementedIter(object):
        pass

    assert(is_iterable([]))
    assert(is_iterable((1, 2)))
    assert(is_iterable({}))
    assert(is_iterable({1: 2}))
    assert(is_iterable('a'))
    assert(is_iterable(UnimplementedIter()))

    assert(not is_iterable(1))
    assert(not is_iterable(None))



# Generated at 2022-06-22 21:25:24.174222
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict({'A': 1, 'B': 2, 'C': 3})
    expected_ret = ['A', 'B', 'C']
    for expected, actual in zip(expected_ret, d):
        assert actual == expected


# Generated at 2022-06-22 21:25:28.665368
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    test_dict = ImmutableDict({'a': 1})
    assert test_dict['a'] == 1
    try:
        test_dict[0]
    except KeyError:
        assert True
    except Exception:
        assert False
    else:
        assert False


# Generated at 2022-06-22 21:25:40.609973
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence(set())
    assert is_sequence((), include_strings=False)
    assert is_sequence((), include_strings=True)
    assert is_sequence([], include_strings=False)
    assert is_sequence([], include_strings=True)
    assert is_sequence({}, include_strings=False)
    assert is_sequence({}, include_strings=True)
    assert is_sequence('abc')
    assert is_sequence(u'abc')
    assert is_sequence(b'abc')

    assert not is_sequence(set(), include_strings=False)
    assert not is_sequence(set(), include_strings=True)
    assert not is_sequence({}, include_strings=False)
    assert not is_sequence({}, include_strings=True)
    assert not is_

# Generated at 2022-06-22 21:25:44.741475
# Unit test for function is_string
def test_is_string():
    assert is_string('str')
    assert is_string(u'unicode')
    assert is_string(b'bytes')
    assert not is_string([])
    assert not is_string({})
    assert not is_string(True)



# Generated at 2022-06-22 21:25:48.137239
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict({'1':2, 3:4})
    assert d['1'] == 2
    assert d[3] == 4


# Generated at 2022-06-22 21:25:53.931882
# Unit test for function count
def test_count():
    """Unit test for count function"""
    my_seq = ["a", "b", "a", "c"]
    result = count(my_seq)
    assert result[my_seq[0]] == 2
    assert result[my_seq[1]] == 1
    assert result[my_seq[2]] == 2
    assert result[my_seq[3]] == 1



# Generated at 2022-06-22 21:25:58.533558
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    dict_obj = ImmutableDict({'key': 'value'})
    assert dict_obj['key'] == 'value'

    try:
        dict_obj[123]
    except KeyError as e:
        assert '123' in str(e)



# Generated at 2022-06-22 21:26:01.220328
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    items = [('a', 1), ('b', 2), ('c', 3)]
    for i, item in enumerate(test_dict):
        assert item == items[i]



# Generated at 2022-06-22 21:26:04.184733
# Unit test for method __len__ of class ImmutableDict

# Generated at 2022-06-22 21:26:10.745681
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    original_dict = {'a': 1, 2: 3, 'c': {'d': 1}, 4: [5, 6]}
    immutabledict = ImmutableDict(original_dict)
    assert hash(immutabledict) == hash(original_dict)
    # Nested dictionary should produce different hash
    assert hash(immutabledict) != hash(dict(original_dict, c={'d':1}))


# Generated at 2022-06-22 21:26:12.557381
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict({1: 2, 3: 4, 5: 6})
    assert len(d) == 3


# Generated at 2022-06-22 21:26:20.817790
# Unit test for function count
def test_count():
    eq = assertEqual = getattr(__builtins__, 'cmp', __builtins__['cmp'])
    assertEqual(count([]), {})
    assertEqual(count([1, 2, 1, 4, 2]), {4: 1, 1: 2, 2: 2})
    assertEqual(count(['a', 'a', 'b', 'b', 'b']), {'a': 2, 'b': 3})
    assertEqual(count(['a', 'a', 'b', 'b', 'b', 1, 1, 2]), {'a': 2, 'b': 3, 1: 2, 2: 1})

    try:
        count(None)
        assert False
    except:
        pass



# Generated at 2022-06-22 21:26:31.720113
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d = {'a': '1', 'b': '2', 'c': '3'}
    i = ImmutableDict(d)

    assert i.difference(('b', 'c')) == ImmutableDict({'a': '1'})
    assert i.difference(('a', 'c')) == ImmutableDict({'b': '2'})
    assert i.difference(('a', 'b')) == ImmutableDict({'c': '3'})
    assert i.difference(('a', 'b', 'c')) == ImmutableDict({})

    assert i.difference(('x', 'y', 'z')) == i
    assert i.difference(('c', 'b', 'a')) == i

# Generated at 2022-06-22 21:26:41.995585
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    # This is a test for correct __getitem__ method in ImmutableDict
    from ansible.module_utils import basic

    ID1 = ImmutableDict(one=1, two=2, three=3)

    # Test typical usage of __getitem__
    assert ID1['one'] == 1
    assert ID1['two'] == 2
    assert ID1['three'] == 3

    # Test __getitem__ raises KeyError when expect it
    try:
        ID1['four']
        raise AssertionError('Expected KeyError on unassociated key')
    except KeyError:
        pass

    try:
        ID1['four'] = 4
        raise AssertionError('Expected type error when assigning to an ImmutableDict')
    except TypeError:
        pass

    # Test how __getitem__ works when used to

# Generated at 2022-06-22 21:26:48.056170
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])  # True
    assert is_iterable(set())  # True
    assert is_iterable((1, 2, 3))  # True
    assert is_iterable(xrange(5))  # True
    assert is_iterable({'a': 1, 'b': 2})  # True
    assert is_iterable('abc')  # True

    assert is_iterable(1)  # False
    assert is_iterable(None)  # False

# Generated at 2022-06-22 21:26:53.086498
# Unit test for function is_iterable
def test_is_iterable():
    iterable = [1,2,3]
    not_iterable = 1
    string = "abc"

    assert is_iterable(iterable) == True
    assert is_iterable(not_iterable) == False
    assert is_iterable(string) == False
    assert is_iterable(string, include_strings=True) == True


# Generated at 2022-06-22 21:26:55.476285
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert repr(ImmutableDict({'key1': 'value1', 'key2': 'value2'})) == 'ImmutableDict({\'key1\': \'value1\', \'key2\': \'value2\'})'



# Generated at 2022-06-22 21:26:57.945319
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert is_string(u'foo')
    assert not is_string(['f', 'o', 'o'])



# Generated at 2022-06-22 21:27:01.575710
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    test = ImmutableDict(one=1, two=2)
    assert hasattr(test, '__iter__')
    assert iter(test) == {'one':1, 'two':2}.__iter__()


# Generated at 2022-06-22 21:27:03.819420
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict()
    assert d1 == {}
    assert d1 == d1


# Generated at 2022-06-22 21:27:07.063572
# Unit test for function is_string
def test_is_string():
    assert is_string('test')
    assert is_string(u'test')
    assert is_string(b'test')
    assert not is_string(object())


# Generated at 2022-06-22 21:27:18.244408
# Unit test for function count
def test_count():
    # Test when string is passed as input
    try:
        count('abc')
    except Exception:
        pass
    else:
        raise AssertionError('String as input should raise an exception')

    # Test when list is passed as input
    cnt = count([1,1,1,2,2,3])
    assert cnt == {1: 3, 2: 2, 3:1}, 'Count of the elements in a list should work'

    #Test when tuple is passed as input
    cnt = count((1,1,1,2,2,3))
    assert cnt == {1: 3, 2: 2, 3:1}, 'Count of the elements in a tuple should work'

    #Test when set is passed as input
    cnt = count({1,1,1,2,2,3})
    assert cnt

# Generated at 2022-06-22 21:27:28.793373
# Unit test for function count
def test_count():
    from ansible.module_utils._text import to_native

    assert count([1, 2, 1]) == {1: 2, 2: 1}
    assert count([1, 2, 3]) == {1: 1, 2: 1, 3: 1}
    assert count([]) == {}
    assert count({'a': 1, 'b': 2}) == {'a': 1, 'b': 1}
    assert count(set(['a', 'b', 'a'])) == {'a': 2, 'b': 1}

    try:
        count('abc')
    except Exception as e:
        assert to_native(e) == 'Argument provided  is not an iterable'


# Generated at 2022-06-22 21:27:35.296338
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([]) is True
    assert is_sequence('') is False
    assert is_sequence(tuple()) is True
    assert is_sequence(set()) is False
    assert is_sequence(dict()) is False
    assert is_sequence(list()) is True
    assert is_sequence(lambda: None) is False
    assert is_sequence(u'foobar') is False
    assert is_sequence(b'foobar') is False
    assert is_sequence('foobar') is True



# Generated at 2022-06-22 21:27:41.266257
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict(a=1, b=2, c=3)
    removal_list = ['a', 'c']
    assert original.difference(removal_list) == ImmutableDict(b=2)


# Generated at 2022-06-22 21:27:45.305470
# Unit test for function is_string
def test_is_string():
    assert is_string('abc') == True
    assert is_string([]) == False
    assert is_string((1,2,3)) == False
    assert is_string({1:1}) == False


# Generated at 2022-06-22 21:27:56.471252
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1, b=2) == ImmutableDict(b=2, a=1)
    assert ImmutableDict(a=[1,2], b=2) == ImmutableDict(a=[1,2], b=2)
    assert ImmutableDict(a=[1,2], b=2) == ImmutableDict(a=[1,2], b=2, c=3)
    assert ImmutableDict(a=[1,2], b=2) != ImmutableDict(a=[1,3], b=2)
    assert ImmutableDict(a=[1,2], b=2) != ImmutableDict(a=[1,2], b=2, c=5)

# Generated at 2022-06-22 21:27:59.158128
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    a_dict = ImmutableDict({'a': 1, 'b': 2})
    assert a_dict['a'] == 1
    assert a_dict['b'] == 2


# Generated at 2022-06-22 21:28:06.489877
# Unit test for function is_sequence
def test_is_sequence():
    assert True == is_sequence([1, 2, 3])
    assert True == is_sequence(set([1, 2, 3]))
    assert False == is_sequence({'a': 1, 'b': 2})
    assert False == is_sequence('abc')
    assert True == is_sequence('abc', include_strings=True)


# Generated at 2022-06-22 21:28:11.257798
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """'difference' method of ImmutableDict class"""
    assert ImmutableDict(a=1, b=2).difference([]) == ImmutableDict(a=1, b=2)
    assert ImmutableDict(a=1, b=2).difference(['a']) == ImmutableDict(b=2)



# Generated at 2022-06-22 21:28:23.125351
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = dict(a=1, b=2)
    b = dict(c=1, d=2)
    c = dict(a=1, b=2)
    a1 = ImmutableDict(a=1, b=2)
    b1 = ImmutableDict(c=1, d=2)
    c1 = ImmutableDict(a=1, b=2)
    assert a1 != b1
    assert b1 != c1
    assert a1 != c1
    assert a1 != b
    assert b1 != a
    assert c1 != a
    assert a != c
    assert b != c
    assert a != a1
    assert b != b1
    assert c != c1
    assert a1 == a
    assert b1 == b
    assert c1 == c
    assert a1

# Generated at 2022-06-22 21:28:35.601839
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    dct = ImmutableDict(foo='bar')
    assert dct == ImmutableDict(foo='bar')
    assert dct != ImmutableDict(foo='baz')
    assert len(dct) == 1
    assert 'foo' in dct
    assert dct.get('foo') == 'bar'
    assert dct.get('bar', 'baz') == 'baz'
    assert dct['foo'] == 'bar'
    assert dct.keys() == list(dct.keys())
    assert dct.keys() == ['foo']
    assert dct.values() == ['bar']
    assert dct.items() == [('foo', 'bar')]
    assert dct.union(f='baz') == ImmutableDict(foo='bar', f='baz')

# Generated at 2022-06-22 21:28:37.795208
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d1 = ImmutableDict({'A': 1, 'B': 2, 'C': 3})
    assert len(d1) == 3



# Generated at 2022-06-22 21:28:49.885055
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():

    assert ImmutableDict(x=1, y=2) == ImmutableDict({'x': 1, 'y': 2})
    assert ImmutableDict(dict(x=1, y=2)) == ImmutableDict({'x': 1, 'y': 2})
    assert ImmutableDict(x=1, y=2) == ImmutableDict(x=1, y=2)
    assert ImmutableDict(x=1) != ImmutableDict(x=2)

    immutable = ImmutableDict(x=1)
    assert immutable.union(y=2) == ImmutableDict(x=1, y=2)
    assert immutable.union(x=2) == ImmutableDict(x=2)

    assert immutable.difference(['y']) == ImmutableDict(x=1)


# Generated at 2022-06-22 21:28:55.481458
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    test_mapping = {'luke': 'skywalker', 'alex': 'tig', 'anton': 'novoselov'}
    immdict = ImmutableDict(test_mapping)
    assert immdict['luke'] == 'skywalker'
    assert immdict['alex'] == 'tig'
    assert immdict['anton'] == 'novoselov'


# Generated at 2022-06-22 21:29:04.685669
# Unit test for function count
def test_count():
    assert count([1, 2, 3, 1, 2, 4]) == {1: 2, 2: 2, 3: 1, 4: 1}
    assert count((1, 2, 3, 1, 2, 4)) == {1: 2, 2: 2, 3: 1, 4: 1}
    assert count({1: 1, 2: 1, 3: 1, 1: 1, 2: 1, 4: 1}) == {1: 2, 2: 2, 3: 1, 4: 1}
    try:
        count(1)
        assert False
    except Exception as e:
        assert True



# Generated at 2022-06-22 21:29:13.233539
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict."""

    # Test for equality with a non-immutable dict
    test_dict = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict == {'a': 1, 'b': 2}

    # Test for equality with an ImmutableDict
    test_dict2 = ImmutableDict({'b': 2, 'a': 1})
    assert test_dict == test_dict2

    # Test for non-equality
    test_dict3 = ImmutableDict({'b': 2, 'a': 2})
    assert not test_dict == test_dict3

    # Test for equality
    test_dict4 = ImmutableDict({'b': '2', 'a': '1'})
    assert not test_dict == test_dict4

# Generated at 2022-06-22 21:29:25.495939
# Unit test for function is_iterable
def test_is_iterable():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib

    assert is_iterable([])
    assert is_iterable(["1"])
    assert is_iterable(iter(()))  # iterators are iterable
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable(dict())
    assert is_iterable(list())
    assert is_iterable(tuple())

    assert not is_iterable(1)
    assert not is_iterable(int)
    assert not is_iterable('str')
    assert not is_iterable(is_iterable)
    assert not is_iterable(None)

# Generated at 2022-06-22 21:29:35.083186
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_1 = ImmutableDict({"a":1,"b":2,"c":3})
    dict_2 = ImmutableDict({"a":1,"b":2,"c":3})
    dict_3 = ImmutableDict({"a":2,"b":2,"c":4})
    dict_4 = dict({"a":1,"b":2,"c":3})

    assert dict_1 == dict_2
    assert dict_1 != dict_3
    assert dict_1 != dict_4

    try:
        dict_1 == 1
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-22 21:29:38.468742
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    """ Test that the method getitem returns the correct value for the given key """
    test_dict = ImmutableDict({1:'one', 2:'two'})
    assert test_dict[1] == 'one'


# Generated at 2022-06-22 21:29:44.633912
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    initial_mapping = {'a': 1, 'b': 2, 'c': 3}
    immutable_mapping = ImmutableDict(initial_mapping)

    assert id(initial_mapping) != id(immutable_mapping)
    assert initial_mapping == immutable_mapping._store
    assert initial_mapping is not immutable_mapping._store



# Generated at 2022-06-22 21:29:47.350068
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    mapping = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})
    assert mapping.difference('bc') == ImmutableDict({'a': 1, 'd': 4, 'e': 5})



# Generated at 2022-06-22 21:29:53.313304
# Unit test for function count
def test_count():
    test_list = ['a', 'b', 'c', 'd', 'a', 'a', 'c', 'd', 'd', 'd', 'd']
    assert count(test_list) == {'a': 3, 'b': 1, 'c': 2, 'd': 5}
    assert count((1, 1, 1, 2, 3, 3, 3, 3, 3, 3, 3, 3)) == {1: 3, 2: 1, 3: 8}


# Generated at 2022-06-22 21:30:02.008361
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    src_dict = {'a':1, 'b':2}
    tmp_dict = ImmutableDict(src_dict)

    assert tmp_dict == ImmutableDict(a=1, b=2)
    assert tmp_dict == ImmutableDict({'a': 1, 'b': 2})

    # Valid operations on ImmutableDict
    assert tmp_dict['a'] == 1

    for key in tmp_dict:
        assert src_dict[key] == tmp_dict[key]

    assert len(tmp_dict) == 2

    # Invalid operations on ImmutableDict
    #  - Populate
    try:
        tmp_dict['c'] = 3
    except TypeError:
        pass
    else:
        raise Exception()
