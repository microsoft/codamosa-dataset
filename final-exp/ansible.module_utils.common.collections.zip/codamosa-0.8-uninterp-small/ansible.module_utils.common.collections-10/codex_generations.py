

# Generated at 2022-06-24 20:14:54.829090
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert not is_iterable("string")
    assert is_iterable("string", include_strings=True)
    assert not is_iterable("")
    assert is_iterable("", include_strings=True)


# Generated at 2022-06-24 20:14:57.884019
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:15:08.507571
# Unit test for function is_iterable
def test_is_iterable():
    my_mutable_dict = {'a': 0, 'b': 1}
    my_immutable_dict = ImmutableDict(my_mutable_dict)
    my_list = ['a', 'b', 'c']
    my_string = 'abc'
    my_int = 3

    assert is_iterable(my_mutable_dict)
    assert is_iterable(my_immutable_dict)
    assert is_iterable(my_list)
    assert is_iterable(my_string)
    assert not is_iterable(my_int)

    assert is_iterable(my_mutable_dict, include_strings=True)
    assert is_iterable(my_immutable_dict, include_strings=True)
    assert is_iterable(my_list, include_strings=True)


# Generated at 2022-06-24 20:15:14.138143
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # initialize data
    immutable_dict_0 = ImmutableDict()
    list_0 = [immutable_dict_0]
    # test the outcome
    var_0 = immutable_dict_0.difference(list_0)
    # result assertion
    assert var_0 is not immutable_dict_0


# Generated at 2022-06-24 20:15:18.728109
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0.__eq__("a")
    immutable_dict_0.__eq__("a")
    immutable_dict_0.__eq__("a")
    immutable_dict_0.__eq__("a")
    immutable_dict_0.__eq__("a")
    immutable_dict_0.__eq__("a")
    immutable_dict_0.__eq__("a")
    immutable_dict_0.__eq__("a")


# Generated at 2022-06-24 20:15:27.926990
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Test if ImmutableDict.difference() return a copy of the ImmutableDict with keys from the
    subtractive_iterable removed
    """
    immutable_dict = ImmutableDict(a=1, b=2, c=3)
    expected_keys = frozenset(('a', 'c'))
    immutable_dict_copy = immutable_dict.difference(('b'))
    assert (expected_keys == frozenset(immutable_dict_copy))
    assert immutable_dict_copy.__len__() == 2


# Generated at 2022-06-24 20:15:36.551463
# Unit test for function is_iterable
def test_is_iterable():
    """
    Test is_iterable
    """
    test_var = (
        'string',
        b'bytes',
        set(),
        [],
        {},
        (1, 2, 3),
        {'a': 'b'},
        None
    )

    expect_var = (
        True,
        True,
        True,
        True,
        True,
        True,
        True,
        False,
    )

    for i, test in enumerate(test_var):
        test_out = is_iterable(test)
        assert test_out == expect_var[i], "Expected '%s', got '%s'" % (expect_var[i], test_out)



# Generated at 2022-06-24 20:15:39.697180
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__()
    var_1 = immutable_dict_0.__eq__()

# Generated at 2022-06-24 20:15:42.439706
# Unit test for function is_iterable
def test_is_iterable():
    seq = ['a', 'b']
    assert is_iterable(seq)
    assert not is_iterable('a')
    assert not is_iterable(1)
    assert not is_iterable(None)
    assert is_iterable(set('a'))


# Generated at 2022-06-24 20:15:47.764027
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    immutable_dict_0 = ImmutableDict({})
    immutable_dict_1 = ImmutableDict({})
    immutable_dict_0.difference(immutable_dict_1)


# Generated at 2022-06-24 20:15:57.688555
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable({}) is True
    assert is_iterable(set()) is True
    # Generators are iterable
    assert is_iterable((i for i in range(10))) is True
    # Strings are iterable
    assert is_iterable('123') is True
    #
    assert is_iterable(u'123') is True
    # Byte strings are iterable too
    assert is_iterable(b'123') is True
    # Integers are not iterable
    assert is_iterable(1) is False
    #
    assert is_iterable(b'123') is True
    # In Py3k bytes are iterable, but not in Py26
    # So we can use a check like below
    import sys

# Generated at 2022-06-24 20:16:07.761727
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    try:
        immutable_dict_0.union(overriding_mapping=var_0)
    except Exception as e:
        assert len(e.args) == 1
        assert e.args[0] == 'This ImmutableDict may not be modified.'
    try:
        immutable_dict_0.difference(subtractive_iterable=var_0)
    except Exception as e:
        assert len(e.args) == 1
        assert e.args[0] == 'This ImmutableDict may not be modified.'
    try:
        immutable_dict_0.__eq__(other=var_0)
    except Exception as e:
        assert len(e.args) == 1

# Generated at 2022-06-24 20:16:14.238675
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_2 = immutable_dict_0.__eq__(immutable_dict_0)
    var_3 = immutable_dict_0.__eq__(immutable_dict_0)
    var_4 = immutable_dict_0.__eq__(immutable_dict_0)
    var_5 = ImmutableDict().__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:16:16.618475
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:16:22.675022
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)
    immutable_dict_0 = ImmutableDict()
    var_1 = immutable_dict_0.__eq__(immutable_dict_0)
    immutable_dict_1 = ImmutableDict()
    var_2 = immutable_dict_1.__eq__(immutable_dict_1)
    immutable_dict_1 = ImmutableDict()
    var_3 = immutable_dict_1.__eq__(immutable_dict_1)
    immutable_dict_2 = ImmutableDict()
    var_4 = immutable_dict_2.__eq__(immutable_dict_2)
    immutable_dict_2 = ImmutableDict()
    var_5 = immutable

# Generated at 2022-06-24 20:16:26.470746
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:16:31.343433
# Unit test for function is_iterable
def test_is_iterable():
    assert callable(is_iterable)
    assert not is_iterable(1)
    assert is_iterable([1, 2])
    assert is_iterable({1: 'a', 2: 'b'})



# Generated at 2022-06-24 20:16:40.391760
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    test_ImmutableDict___eq__()
    """
    immutable_dict_2 = ImmutableDict(foo=1)
    immutable_dict_3 = ImmutableDict(foo="bar")
    immutable_dict_4 = ImmutableDict(foo="baz")
    immutable_dict_5 = ImmutableDict(bar=1)
    immutable_dict_6 = ImmutableDict()
    immutable_dict_7 = ImmutableDict({"foo": 1})
    immutable_dict_8 = ImmutableDict({"foo": 1})
    immutable_dict_9 = ImmutableDict({"foo": "baz"})
    immutable_dict_10 = ImmutableDict({"foo": "baz"})

# Generated at 2022-06-24 20:16:51.112720
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'a': 1, 'b': 2})
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)
    immutable_dict_3 = ImmutableDict()
    var_3 = immutable_dict_3.__eq__(immutable_dict_3)
    true_0 = True
    var_4 = immutable_dict_3.__eq__(true_0)
    text_type_0 = text_type('a')
    immutable_dict_2 = ImmutableDict({'a': 1, 'b': 2})
    var_2 = immutable_dict_2.__eq__(text_type_0)
    immutable_dict_1 = ImmutableDict({text_type_0: 1, text_type_0: 2})
    var

# Generated at 2022-06-24 20:16:56.076451
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:17:11.528349
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # This test passes if the __eq__ method returns True if the hash of the 2 ImmutableDicts being compared is equal.
    # It also passes if the __eq__ method returns False if the hash of the 2 ImmutableDicts being compared is not equal.
    # It also passes if the __eq__ method fails when the 2 objects being compared have different types.
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict({'a': 1})
    immutable_dict_2 = ImmutableDict({'a': 1})

    assert type(immutable_dict_0) == type(immutable_dict_1) and hash(immutable_dict_0) == hash(immutable_dict_1)

# Generated at 2022-06-24 20:17:18.475790
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Call the method on an empty ImmutableDict with a non-empty Mapping
    # as the argument.
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__({'key':'val'})

    # Call the method on an empty ImmutableDict with a non-empty Sequence
    # as the argument.
    var_1 = immutable_dict_0.__eq__([1,2,3])

    # Call the method on an empty ImmutableDict with a non-empty ImmutableDict
    # as the argument.
    var_2 = immutable_dict_0.__eq__(immutable_dict_0)

    # Call the method on an empty ImmutableDict with a non-empty ImmutableDict
    # as the argument.
    var_3 = immutable_

# Generated at 2022-06-24 20:17:28.123502
# Unit test for function is_iterable
def test_is_iterable():
    # Tests for function is_iterable
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(MappingProxyType({1:2, 3:4}))
    assert is_iterable('123')
    assert is_iterable(bytes('123'))
    assert not is_iterable(123)
    assert is_iterable(range(3))
    assert is_iterable(k for k in (1,2,3))
    assert is_iterable(None)
    assert is_iterable({}, include_strings=True)
    assert is_iterable('abc', include_strings=True)



# Generated at 2022-06-24 20:17:39.468590
# Unit test for function is_iterable
def test_is_iterable():
    immutable_dict_0 = ImmutableDict({'a': 'b'})
    var_0 = is_iterable(immutable_dict_0)
    immutable_dict_1 = ImmutableDict(a='b', c='d')
    var_1 = is_iterable(immutable_dict_1)
    immutable_dict_2 = ImmutableDict()
    var_2 = is_iterable(immutable_dict_2)
    var_3 = is_iterable(immutable_dict_2, True)
    var_4 = is_iterable(['a','b','c'])
    var_5 = is_iterable('foo')
    var_6 = is_iterable('foo', True)


# Generated at 2022-06-24 20:17:40.452700
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    pass


# Generated at 2022-06-24 20:17:51.702206
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(list())
    assert is_iterable(tuple())
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(frozenset())
    assert is_iterable({})
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable(set([]))
    assert is_iterable(['hello', 'world'])
    assert is_iterable(('hello', 'world'))
    assert is_iterable(set(['hello', 'world']))
    assert is_iterable({'hello': 'world'})
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({'hello': 'world'}))
    assert not is_iterable(None)

# Generated at 2022-06-24 20:18:01.901115
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) # List
    assert is_iterable([1, 2, 3])
    assert is_iterable(()) # Tuple
    assert is_iterable(range(1,4)) # Range
    assert is_iterable({'a':1, 'b':2}) # Dict
    assert is_iterable({1, 2, 3}) # Set
    assert is_iterable(2) # int
    assert is_iterable(2.) # float
    assert is_iterable(2+3j) # complex
    assert is_iterable(True) # bool
    assert is_iterable('string') # str
    assert is_iterable(b'bytes') # bytes
    assert is_iterable(bytearray(range(0, 10))) # bytearray

# Generated at 2022-06-24 20:18:08.526975
# Unit test for function is_iterable
def test_is_iterable():
    list_0 = []
    assert is_iterable(list_0)
    tuple_0 = ()
    assert is_iterable(tuple_0)
    string_0 = ""
    assert is_iterable(string_0)
    string_1 = ""
    assert is_iterable(string_1) == True
    dict_0 = {}
    assert is_iterable(dict_0)
    bool_0 = bool()
    assert is_iterable(bool_0) == False
    int_0 = int()
    assert is_iterable(int_0) == False
    float_0 = float()
    assert is_iterable(float_0) == False
    list_1 = []
    assert is_iterable(list_1) == True


# Generated at 2022-06-24 20:18:10.037193
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()

    var_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:18:14.645294
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = 'Test'

    result_0 = is_iterable(str_0)
    assert not result_0

    list_0 = list()
    result_1 = is_iterable(list_0)
    assert result_1

    result_2 = is_iterable(str_0, include_strings=True)
    assert result_2


# Generated at 2022-06-24 20:18:27.072115
# Unit test for function is_iterable
def test_is_iterable():
    # Test a list
    test_list = list()
    assert is_iterable(test_list)

    # Test a string
    test_string = "Test String"
    assert is_iterable(test_string, include_strings=True)
    assert is_iterable(test_string) is False

    # Test a number
    test_number = 12
    assert is_iterable(test_number) is False


# Generated at 2022-06-24 20:18:36.180756
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test case for method ImmutableDict.__eq__"""
    dict_0 = dict()
    dict_0[3] = 5
    dict_0[4] = 4
    dict_0[5] = 4
    dict_0[10] = 1
    dict_0[7] = 2
    dict_0[9] = 3
    dict_1 = dict()
    dict_1[0] = 2
    dict_1[1] = 3
    dict_1[2] = 2
    dict_1[3] = 3
    dict_1[4] = 3
    dict_1[5] = 4
    dict_1[6] = 1
    class_0 = ImmutableDict(dict_0)
    class_1 = class_0

# Generated at 2022-06-24 20:18:44.625659
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['abc', 'def']) == True
    assert is_iterable([10, 20, 30]) == True
    assert is_iterable(['a', 'b']) == True
    assert is_iterable([0, 1]) == True
    assert is_iterable(['a', 'b']) == True
    assert is_iterable(['a']) == True

# Generated at 2022-06-24 20:18:52.630890
# Unit test for function is_iterable
def test_is_iterable():
    var_0 = (1, 2, 3, 4)
    var_1 = [1, 2, 3, 4]
    var_2 = 'text'
    var_3 = 2387
    var_4 = 4.218

    var_5 = is_iterable(var_0)
    var_6 = is_iterable(var_1)
    var_7 = is_iterable(var_2)
    var_8 = is_iterable(var_3)
    var_9 = is_iterable(var_4)


# Generated at 2022-06-24 20:18:57.867155
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(["a", "b", "c"]) == True
    assert is_iterable("abcde") == False
    assert is_iterable("abcde", include_strings=True) == True
    assert is_iterable("abcde", include_strings=False) == False



# Generated at 2022-06-24 20:19:06.261888
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict()
    d2 = ImmutableDict()
    d3 = ImmutableDict({"a": 1})
    d4 = ImmutableDict({"a": 1})
    d5 = ImmutableDict({"a": 1.0})
    d6 = ImmutableDict({"a": 1.0})
    d7 = ImmutableDict({1.0: "a"})
    d8 = ImmutableDict({1.0: "a"})
    d9 = ImmutableDict({"a": 1, "b": 2})
    d10 = ImmutableDict({"a": 1, "b": 2})

    if d1 != d2:
        print("error!")
    if d3 != d4:
        print("error!")

# Generated at 2022-06-24 20:19:09.759919
# Unit test for function is_iterable
def test_is_iterable():
    print('Testing the is_iterable function')
    # Test case 0
    try:
        test_case_0()
        print('Test case 0 passed')
    except Exception:
        print('Test case 0 failed')



# Generated at 2022-06-24 20:19:18.911062
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality between a ImmutableDict and a Hashable
    original = ImmutableDict({"a": 1, "b": 2})
    other_hashable = frozenset({"a": 1, "b": 2})
    assert original == other_hashable

    # Test for equality between a ImmutableDict and a MutableMapping
    original = ImmutableDict({"a": 1, "b": 2})
    other_mapping = {"a": 1, "b": 2}
    assert original == other_mapping

    # Test for equality between a ImmutableDict and a ImmutableDict
    original = ImmutableDict({"a": 1, "b": 2})
    other = ImmutableDict({"a": 1, "b": 2})
    assert original == other


# Generated at 2022-06-24 20:19:25.770487
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test that the ImmutableDict can be compared to other Mappings"""
    first_dict = ImmutableDict({"testkey":"testvalue"})
    second_dict = ImmutableDict({"testkey":"testvalue"})
    assert(first_dict == second_dict)
    assert(first_dict == {"testkey":"testvalue"})
    assert(first_dict != second_dict.union({"other_key":"other_value"}))
    assert(first_dict != {"other_key":"other_value"})


# Generated at 2022-06-24 20:19:34.432414
# Unit test for function is_iterable
def test_is_iterable():
    from unittest import TestCase

    class TestIsIterable(TestCase):

        def test_true(self):
            self.assertTrue(is_iterable('foo'))
            self.assertTrue(is_iterable(['foo', 'bar']))
            self.assertTrue(is_iterable(('foo', 'bar')))
            self.assertTrue(is_iterable(set(['foo', 'bar'])))
            self.assertTrue(is_iterable(dict(a='a', b='b')))
            self.assertTrue(is_iterable(x for x in ['foo', 'bar']))
            self.assertTrue(is_iterable({'foo', 'bar'}))

        def test_false(self):
            self.assertFalse(is_iterable(object))

# Generated at 2022-06-24 20:19:50.963091
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict(((('y', 'c'), 4377), (('w', '{'), 4377)))
    dict_1 = ImmutableDict(((('y', 'c'), 4377), (('w', '{'), 4377)))
    bool_0 = dict_0 == dict_1
    assert bool_0


# Generated at 2022-06-24 20:20:01.895817
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_1 = ImmutableDict()

    assert dict_0 == dict_1
    # Equality depends on the inner state
    dict_2 = ImmutableDict({'a': 5, 'c': 7, 'b': 2})
    dict_3 = ImmutableDict({'c': 7, 'b': 2, 'a': 5})
    dict_4 = ImmutableDict({'c': 7, 'b': 2, 'a': 6})
    dict_5 = ImmutableDict({'a': 5, 'c': 7})
    dict_6 = ImmutableDict({'a': 5, 'c': 7, 'b': 2, 'd': 3})

    assert dict_2 == dict_3
    assert dict_2 != dict_4
    assert dict_2 != dict_

# Generated at 2022-06-24 20:20:11.917799
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(2345)
    assert not is_iterable(float(34))
    assert not is_iterable(2384.887)
    assert is_iterable([])
    assert is_iterable((2, 3, 4, 5))
    assert is_iterable({2: 3, 4: 5})
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert not is_iterable('234')
    assert not is_iterable(u'234')
    assert not is_iterable(b'234')
    assert not is_iterable(binary_type(b'234'))
    assert not is_iterable(text_type(b'234', 'ascii'))
    test_case_0()



# Generated at 2022-06-24 20:20:21.852093
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3, 4, 5]) == True
    assert is_iterable("Ansible") == True
    assert is_iterable((1, 2, 3, 4, 5)) == True
    assert is_iterable({"a": "apple", "b": "bat"}) == True
    assert is_iterable({"a", "b", "c"}) == True
    assert is_iterable(range(5)) == True
    assert is_iterable({1, 2, 3, 4, 5}) == True
    assert is_iterable(2384.887) == False
    assert is_iterable(1) == False


# Generated at 2022-06-24 20:20:26.257305
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test of parameter length is 0.
    destination = ImmutableDict({})
    destination = destination.union({'dict': 'overwrite'})
    destination = destination.union({'dict': 'overwrite'})
    destination = destination.difference(['dict'])
    assert destination == {}
    if destination != {}:
        raise Exception("Test of parameter length is 0. failed")


# Generated at 2022-06-24 20:20:28.548188
# Unit test for function is_iterable
def test_is_iterable():
    var_0 = is_iterable([0])
    assert True == var_0
    var_1 = is_iterable(0)
    assert False == var_1



# Generated at 2022-06-24 20:20:30.588230
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2])
    assert not is_iterable(1)


# Generated at 2022-06-24 20:20:32.812031
# Unit test for function is_iterable
def test_is_iterable():
    float_0 = 2384.887
    var_0 = is_iterable(float_0)
    assert var_0 == False



# Generated at 2022-06-24 20:20:38.475525
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({"one": "two"}) == ImmutableDict({"one": "two"})
    assert ImmutableDict({"one": "two"}) != ImmutableDict({"two": "one"})
    assert ImmutableDict({"one": "two"}) != ImmutableDict({"one": "one"})
    assert ImmutableDict({"one": "two"}) != object()


# Generated at 2022-06-24 20:20:47.471023
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1,2,3,4,5]), "The outcome should be True"
    assert is_iterable([1,2,3,4,5]), "The outcome should be True"
    assert is_iterable((1,2,3,4,5)), "The outcome should be True"
    assert is_iterable(set([1,2,3,4,5])), "The outcome should be True"
    assert is_iterable({"1":"hello", "2":"world"}), "The outcome should be True"
    assert not is_iterable(0), "The outcome should be False"
    assert not is_iterable(None), "The outcome should be False"
    assert not is_iterable(is_iterable), "The outcome should be False"


# Generated at 2022-06-24 20:21:03.803778
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict()
    var_1 = ImmutableDict()
    assert var_0 == var_1


# Generated at 2022-06-24 20:21:08.673856
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable(set())
    assert is_iterable("")
    assert not is_iterable(23)
    assert not is_iterable(1.2)


# Generated at 2022-06-24 20:21:12.965428
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # 1) Test case when there are no hash collisions
    immutable_dict_0 = ImmutableDict(key1="value1", key2="value2")
    immutable_dict_1 = ImmutableDict(key1="value1", key2="value2")
    var_0 = immutable_dict_0 == immutable_dict_1
    # 2) Test case when there is a hash collision
    immutable_dict_2 = ImmutableDict(key1=["value1", "value2"], key2="value2")
    immutable_dict_3 = ImmutableDict(key1=["value2", "value1"], key2="value2")
    var_1 = immutable_dict_2 == immutable_dict_3


# Generated at 2022-06-24 20:21:21.908616
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_1 = ImmutableDict({'foo': 1, 'bar': 2}, bar=4)
    var_2 = ImmutableDict({'foo': 1, 'bar': 2}, bar=4)
    var_3 = ImmutableDict({'foo': 1, 'bar': 2}, bar=3)
    var_4 = ImmutableDict({'foo': 1, 'bar': 2}, zap=3)
    var_5 = ImmutableDict({'foo': 1, 'bar': 2})
    var_6 = ImmutableDict({'foo': 1, 'bar': 2})
    var_7 = ImmutableDict({'foo': 1, 'bar': 3})
    var_8 = ImmutableDict({'foo': 1, 'baz': 2})
    var_9 = ImmutableDict({})
   

# Generated at 2022-06-24 20:21:29.279343
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_0['D'] = dict_0
    dict_0.__setitem__('B', dict_0)
    dict_0['F'] = dict_0
    dict_0['L'] = dict_0
    dict_0['H'] = dict_0
    dict_0.__setitem__('K', dict_0)
    dict_0['A'] = dict_0
    dict_0.__setitem__('O', dict_0)
    dict_0.__setitem__('C', dict_0)
    dict_0['G'] = dict_0
    dict_0.__setitem__('N', dict_0)
    dict_0['E'] = dict_0
    dict_0.__setitem__('I', dict_0)
    dict

# Generated at 2022-06-24 20:21:41.022490
# Unit test for function is_iterable
def test_is_iterable():
    iterable_0 = ['Hello', 'World']
    iterable_1 = ('World', 'Hello')
    iterable_2 = set(('Hello', 'World'))
    iterable_3 = {'Hello': 'World', 'Key0': 'Value0'}
    iterable_4 = 'Hello World, is it me you are looking for?'
    iterable_5 = ['Hello', 'World']
    iterable_6 = ['Hello', 'World']


    # Argument is an iterable, include_string is False

    # Argument is an iterable
    result = is_iterable(iterable_0)
    assert result == True

    # Argument is an iterable, include_string is False
    result = is_iterable(iterable_1)
    assert result == True

    # Argument is an iterable

# Generated at 2022-06-24 20:21:51.500661
# Unit test for function is_iterable
def test_is_iterable():
    # Example usage of is_iterable
    float_0 = 2384.887
    var_0 = is_iterable(float_0)

    # Example usage of is_iterable
    int_0 = 8274
    var_0 = is_iterable(int_0)

    # Example usage of is_iterable
    float_0 = 7933.819
    var_0 = is_iterable(float_0)

    # Example usage of is_iterable
    str_0 = 'a string'
    var_0 = is_iterable(str_0)

    # Example usage of is_iterable
    str_0 = 'a string'
    var_0 = is_iterable(str_0)

    # Example usage of is_iterable
    str_0 = 'a string'

# Generated at 2022-06-24 20:21:55.257371
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(a=1, b=2)
    if not (d1 == d1):
        raise AssertionError
    if d1 == d1.union(dict()):
        raise AssertionError
    d2 = d1.union(c=3)
    if d1 == d2:
        raise AssertionError
    d3 = d1.union(b=2)
    if not (d1 == d3):
        raise AssertionError

# Generated at 2022-06-24 20:21:58.709662
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_1 = dict()
    dict_2 = ImmutableDict()

    dict_0 == dict_1
    dict_0 == dict_2


# Generated at 2022-06-24 20:21:59.532900
# Unit test for function is_iterable
def test_is_iterable():
    test_case_0()



# Generated at 2022-06-24 20:22:37.227197
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    '''
    Test for method ImmutableDict __eq__
    '''
    dict_1 = {'key': 'value'}
    dict_2 = {'key': 'value2'}
    dict_3 = {'key': 'value'}
    dict_4 = {'key2': 'value'}

    imm_dict_1 = ImmutableDict(dict_1)
    imm_dict_2 = ImmutableDict(dict_2)
    imm_dict_3 = ImmutableDict(dict_3)
    imm_dict_4 = ImmutableDict(dict_4)

    assert imm_dict_1.__eq__(dict_1) == True
    assert imm_dict_1.__eq__(dict_2) == False

# Generated at 2022-06-24 20:22:41.036729
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({'key_0': 'value_0'})
    dict_1 = ImmutableDict({'key_1': 'value_1'})
    assert dict_0 == dict_0
    assert dict_0 != dict_1



# Generated at 2022-06-24 20:22:48.697626
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Creating some test data
    immutable_dict_0 = ImmutableDict({'a': 'a', 'c': 'c'})
    immutable_dict_1 = ImmutableDict({'b': 'b', 'c': 'c'})
    immutable_dict_2 = ImmutableDict({'a': 'a', 'c': 'c'})

    assert immutable_dict_0 == immutable_dict_0
    assert immutable_dict_0 == immutable_dict_2
    assert immutable_dict_0 != immutable_dict_1
    assert {'a': 'a', 'c': 'c'} == immutable_dict_0
    assert {'a': 'a', 'c': 'c'} == immutable_dict_2
    assert immutable_dict_0 != immutable_dict_1



# Generated at 2022-06-24 20:22:53.302538
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = dict()
    dict_1 = dict()
    dict_0["foo"] = 1
    dict_1["foo"] = 1
    dict_2 = dict()
    dict_2["foo"] = 2

    immutable_dict_0 = ImmutableDict(dict_0)

    assert immutable_dict_0 == ImmutableDict(dict_1)
    assert immutable_dict_0 != ImmutableDict(dict_2)
    assert immutable_dict_0 != dict_1

if __name__ == '__main__':
    test_case_0()
    test_ImmutableDict___eq__()

# Generated at 2022-06-24 20:23:03.242069
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    pass# TODO: Move to a proper test case

    # Testing actual == self
    var_1 = ImmutableDict({'a': 'b', 'c': 123})
    # Testing actual == self
    if var_1 is var_1:
        print('Test ok')
    else:
        print('Test failed')
    # Testing actual == other value
    if var_1 == ImmutableDict({'a': 'b', 'c': 123}):
        print('Test ok')
    else:
        print('Test failed')
    # Testing actual == other value
    if var_1 == {'a': 'b', 'c': 123}:
        print('Test ok')
    else:
        print('Test failed')
    if var_1 == {'a': 'b', 'c': 123, 'd': 1}:
        print

# Generated at 2022-06-24 20:23:06.099035
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable("")
    assert is_iterable([])
    assert is_iterable({})
    assert not is_iterable(1)
    assert not is_iterable(False)

# Generated at 2022-06-24 20:23:08.816898
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    float_0 = 2384.887
    var_0 = ImmutableDict({'a': float_0})
    float_1 = 2384.887
    var_1 = ImmutableDict({'a': float_1})
    var_2 = (var_0 == var_1)
    pass


# Generated at 2022-06-24 20:23:11.445118
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({})
    dict_1 = ImmutableDict({})
    if dict_0.__eq__(dict_1):
        return 1
    return 0


# Generated at 2022-06-24 20:23:12.238532
# Unit test for function is_iterable
def test_is_iterable():
    test_case_0()


# Generated at 2022-06-24 20:23:16.989050
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable({'key': 'value'})
    assert is_iterable(['value'])
    assert is_iterable(('value',))
    assert is_iterable(xrange(1, 2))
    assert is_iterable(set(['value']))
    assert is_iterable(u'text')
    assert is_iterable(b'text')
    assert is_iterable(42) is False


# Generated at 2022-06-24 20:24:25.965118
# Unit test for function is_iterable
def test_is_iterable():
    test_case_0()


# Generated at 2022-06-24 20:24:31.756880
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    initial_dict = {'a': 'b'}
    test_dict = ImmutableDict(initial_dict)
    assert test_dict == initial_dict
    assert not test_dict == initial_dict.update({'c': 'd'})
    assert test_dict == ImmutableDict({'a': 'b'})
    assert test_dict == ImmutableDict({'a': 'b', 'c': 'd'}) == {'a': 'b', 'c': 'd'}


# Generated at 2022-06-24 20:24:38.261794
# Unit test for function is_iterable
def test_is_iterable():
    # Test case #0
    float_0 = 2384.887
    var_0 = is_iterable(float_0)
    assert var_0 == False
    # Test case #1
    str_0 = "hello"
    var_1 = is_iterable(str_0)
    assert var_1 == False
    # Test case #2
    str_1 = "hello"
    var_2 = is_iterable(str_1, include_strings=True)
    assert var_2 == True
    # Test case #3
    list_0 = [3, 6]
    var_3 = is_iterable(list_0)
    assert var_3 == True
    # Test case #4
    tuple_0 = (4, 8)
    var_4 = is_iterable(tuple_0)


# Generated at 2022-06-24 20:24:43.430903
# Unit test for function is_iterable
def test_is_iterable():
    """Test for function is_iterable."""
    test_cases = []

    # test_case_0
    test_case_0_args = [
        2384.887,
    ]
    test_case_0_kwargs = {}
    test_case_0_correct_result = False
    test_cases.append((test_case_0_args, test_case_0_kwargs, test_case_0_correct_result))
    # test_case_1
    test_case_1_args = [
        '',
    ]
    test_case_1_kwargs = {}
    test_case_1_correct_result = True
    test_cases.append((test_case_1_args, test_case_1_kwargs, test_case_1_correct_result))
    # test_case

# Generated at 2022-06-24 20:24:50.428573
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict(('key0', var_0, 'key1', var_1), **kwargs)
    var_1 = ImmutableDict(('key0', var_0, 'key1', var_1), **kwargs)
    var_2 = ImmutableDict(('key0', var_0, 'key1', var_1), **kwargs)
    var_3 = ImmutableDict(**kwargs)
    var_4 = ImmutableDict(var_0, var_1, var_2, var_3)
