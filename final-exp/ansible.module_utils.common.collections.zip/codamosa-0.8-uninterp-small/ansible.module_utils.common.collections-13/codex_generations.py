

# Generated at 2022-06-24 20:14:54.588741
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1,2,3]) is True
    assert is_iterable({'test': 'test'}) is True
    assert is_iterable(1) is False
    assert is_iterable('test') is True
    assert is_iterable('test', include_strings=False) is False


# Generated at 2022-06-24 20:15:02.066136
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    # Set up some test values
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict(timbre='d')
    immutable_dict_2 = ImmutableDict()

    # Call the method
    var_0 = immutable_dict_0.__eq__(immutable_dict_2)
    var_1 = immutable_dict_0.__eq__(immutable_dict_1)
    var_2 = immutable_dict_1.__eq__(immutable_dict_2)


# Generated at 2022-06-24 20:15:06.680030
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__('string')


# Generated at 2022-06-24 20:15:12.681738
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    immutable_dict_0 = ImmutableDict({'a': 'b', 'c': 'd'})
    immutable_dict_0.difference(['a'])


# Generated at 2022-06-24 20:15:14.659338
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    immutable_dict_0 = ImmutableDict({'a': '1', 'b': '2'})
    var_0 = immutable_dict_0.difference(('a',))


# Generated at 2022-06-24 20:15:24.936285
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(frozenset())
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable('flibble')
    assert is_iterable(b'some bytes')
    assert is_iterable(b'decoded string')
    assert is_iterable(1)
    assert is_iterable(set())
    assert is_iterable(frozenset())
    assert is_iterable(None)
    assert is_iterable(range(3))
    assert is_iterable((x for x in range(3)))
    assert is_iterable(xrange(5))
    assert is_iterable(iter([]))
    assert is_iterable(iter('abc'))
   

# Generated at 2022-06-24 20:15:27.570291
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('hello world') == True
    assert is_iterable(['hello world']) == True



# Generated at 2022-06-24 20:15:33.702192
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(None) is False
    assert is_iterable(['test']) is True
    assert is_iterable('test') is True
    assert is_iterable(None, include_strings=True) is False
    assert is_iterable(['test'], include_strings=True) is True
    assert is_iterable('test', include_strings=True) is True
    assert is_iterable(b'test') is True
    assert is_iterable(b'test', include_strings=True) is True


# Generated at 2022-06-24 20:15:43.789373
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict(a=1)
    immutable_dict_2 = ImmutableDict(b=2)
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)
    var_1 = immutable_dict_0.__eq__(None)
    var_2 = immutable_dict_0.__eq__(immutable_dict_1)
    var_3 = immutable_dict_0.__eq__(immutable_dict_2)
    var_4 = immutable_dict_1.__eq__(immutable_dict_2)
    var_5 = immutable_dict_1.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:15:45.904075
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = ImmutableDict()
    var_1 = immutable_dict_0.__eq__(var_0)


# Generated at 2022-06-24 20:15:54.938586
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    from collections import OrderedDict
    keys = ['first', 'second', 'third']
    values = [1, 2, 3]
    ordered_dict = OrderedDict(zip(keys, values))
    immutable_dict = ImmutableDict(ordered_dict)
    print(immutable_dict)
    print(immutable_dict.difference(['first']))



# Generated at 2022-06-24 20:15:59.871065
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert not is_iterable(None)
    assert not is_iterable('not iterable')
    assert is_iterable(u'unicode')



# Generated at 2022-06-24 20:16:02.884490
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:16:05.920111
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(1)
    immutable_dict_1 = ImmutableDict()
    var_1 = immutable_dict_1.union({})
    immutable_dict_2 = ImmutableDict()
    var_2 = immutable_dict_2.__eq__(var_1)


# Generated at 2022-06-24 20:16:09.434774
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)
    var_1 = immutable_dict_1.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:16:11.513246
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    immutable_dict_0 = ImmutableDict()
    var_0 = ImmutableDict()
    immutable_dict_1 = immutable_dict_0.difference(var_0)

# Generated at 2022-06-24 20:16:14.993721
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    immutable_dict_2 = ImmutableDict()
    subtractive_iterable = ['key_1', 'key_2']
    immutable_dict_1 = immutable_dict_2.difference(subtractive_iterable)


# Generated at 2022-06-24 20:16:18.289901
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_dict_0 = ImmutableDict()
    test_dict_1 = ImmutableDict()
    # test_dict_0.__eq__(test_dict_1)
    # test_dict_0.__eq__(test_dict_0)
    # test_dict_1.__eq__(test_dict_0)


# Generated at 2022-06-24 20:16:23.336799
# Unit test for function is_iterable
def test_is_iterable():
    # Test that iterable detects various iterables
    assert is_iterable(dict()) is True
    assert is_iterable(set()) is True
    assert is_iterable(str()) is True
    assert is_iterable(list()) is True
    assert is_iterable(tuple()) is True

    # Test that iterable does not detect non-iterables
    assert is_iterable(object()) is False
    assert is_iterable(int()) is False
    assert is_iterable(float()) is False


# Generated at 2022-06-24 20:16:25.457509
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('string') == True
    assert is_iterable({'key':'value'}) == True
    assert is_iterable([1,2,3]) == True
    assert is_iterable(3) == False


# Generated at 2022-06-24 20:16:35.266857
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__({})


# Generated at 2022-06-24 20:16:44.383444
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_1 = ImmutableDict()
    immutable_dict_2 = ImmutableDict({'a': 1})
    immutable_dict_3 = ImmutableDict({'a': 1})
    var_0 = (immutable_dict_2 == immutable_dict_3)
    var_1 = (immutable_dict_2 == immutable_dict_1)
    var_2 = (immutable_dict_1 == immutable_dict_2)
    var_3 = (immutable_dict_1 == immutable_dict_1)


# Generated at 2022-06-24 20:16:48.942447
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    print('Test for method __eq__ of class ImmutableDict')
    ImmutableDict_obj = ImmutableDict(var_0)
    test_ImmutableDict___eq___testcase_0(ImmutableDict_obj)


# Generated at 2022-06-24 20:16:56.244390
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = isinstance(immutable_dict_0, ImmutableDict)
    immutable_dict_1 = ImmutableDict({})
    immutable_dict_2 = ImmutableDict()
    immutable_dict_3 = ImmutableDict({'a':1})
    immutable_dict_4 = ImmutableDict({'a':2})
    immutable_dict_5 = ImmutableDict({'a':1})
    var_1 = immutable_dict_0 == immutable_dict_1
    var_2 = immutable_dict_0 == immutable_dict_2
    var_3 = immutable_dict_1 == immutable_dict_2
    var_4 = immutable_dict_1 == immutable_dict_3
    var_5 = immutable_dict_1 == immutable_dict_4

# Generated at 2022-06-24 20:17:01.981750
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'key_0': 'value_0'})
    assert immutable_dict_0.__eq__({'key_0': 'value_0'})
    assert not immutable_dict_0.__eq__({'key_0': 'value_1'})


# Generated at 2022-06-24 20:17:07.742198
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('foo') is True
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable(set('foo')) is True
    assert is_iterable({'a': 1, 'b': 2}) is True
    assert is_iterable(1) is False
    assert is_iterable((1,)) is True



# Generated at 2022-06-24 20:17:10.464118
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:17:13.288529
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['foo', 'bar']) == True
    assert is_iterable('foo') == False



# Generated at 2022-06-24 20:17:17.991517
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    immutable_dict_1.__eq__(immutable_dict_0)
    # TODO: Add tests for ImmutableDict.__eq__



# Generated at 2022-06-24 20:17:23.263913
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:17:29.364084
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:17:32.944539
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    _eq = immutable_dict_0.__eq__(immutable_dict_0)
    print(_eq)


# Generated at 2022-06-24 20:17:43.819140
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = ''
    b_0 = b''
    int_0 = 0
    float_0 = 0.0
    list_0 = []
    dict_0 = {}
    tuple_0 = ()
    str_1 = 'a'
    b_1 = b'b'
    int_1 = 1
    float_1 = 0.1
    list_1 = [1, 2]
    dict_1 = {'a': 1}
    tuple_1 = (1, 2)
    # Test for str
    assert is_iterable(str_0) == True, 'Failed for str'
    assert is_iterable(str_1) == True, 'Failed for str'
    assert is_iterable(b_0) == True, 'Failed for bytes'

# Generated at 2022-06-24 20:17:52.292514
# Unit test for function is_iterable
def test_is_iterable():

    # Test with given value
    value_0 = ImmutableDict({"a": "c"})
    result_0 = is_iterable(value_0)
    # Test with given value
    value_1 = ["c", "d"]
    result_1 = is_iterable(value_1)
    # Test with given value
    value_2 = "c"
    result_2 = is_iterable(value_2)
    # Test with given value
    value_3 = ["c", "b"]
    result_3 = is_iterable(value_3, include_strings=True)
    # Test with given value
    value_4 = ImmutableDict({"a": "c"})
    result_4 = is_iterable(value_4, include_strings=True)
    # Test with given value
   

# Generated at 2022-06-24 20:17:56.919028
# Unit test for function is_iterable
def test_is_iterable():
    d = {'a':1, 'b':2}
    s = 'string'
    assert is_iterable(d) is True
    assert is_iterable(s) is True
    assert is_iterable(s, include_strings=True) is True
    assert is_iterable(d, include_strings=True) is True
    assert is_iterable(1) is False


# Generated at 2022-06-24 20:17:59.494290
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    '''
    Test __eq__ of ImmutableDict
    '''
    immutable_dict_0 = ImmutableDict({'key': 0})
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)
    #assert var_0 == False
    print(var_0)


# Generated at 2022-06-24 20:18:08.518278
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('123') is True
    assert is_iterable(123) is True
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable(tuple([1, 2, 3])) is True
    assert is_iterable(set([1, 2, 3])) is True
    assert is_iterable(frozenset([1, 2, 3])) is True
    assert is_iterable(dict({'a': 1, 'b': 2})) is True
    assert is_iterable(1) is False
    assert is_iterable(int) is False


# Generated at 2022-06-24 20:18:11.453539
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_1 = ImmutableDict()
    immutable_dict_2 = ImmutableDict()
    var_1 = immutable_dict_1.__eq__(immutable_dict_2)


# Generated at 2022-06-24 20:18:14.128219
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:18:16.926577
# Unit test for function is_iterable
def test_is_iterable():
    immutable_dict_1 = ImmutableDict()
    var_1 = is_iterable(immutable_dict_1)


# Generated at 2022-06-24 20:18:29.212275
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable({})
    assert is_iterable({1: 2})
    assert is_iterable(set())
    assert is_iterable(set([1, 2]))

    assert not is_iterable(None)
    assert not is_iterable(3)
    assert not is_iterable(str())
    assert not is_iterable(str('abcd'))
    assert not is_iterable(object())

# Generated at 2022-06-24 20:18:32.569401
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = {'b':2}
    var_1 = immutable_dict_0.__eq__(var_0)


# Generated at 2022-06-24 20:18:37.696336
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    assert immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:18:43.093911
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict({1: 2})
    immutable_dict_2 = ImmutableDict({'foo': 'bar'})
    immutable_dict_3 = ImmutableDict({'foo': 'bar'})
    immutable_dict_4 = ImmutableDict({1: 2})
    immutable_dict_5 = ImmutableDict({1: 2, 'foo': 'bar'})
    immutable_dict_6 = ImmutableDict({'foo': 'bar', 1: 2})
    assert not (immutable_dict_3 == immutable_dict_2)
    assert not (immutable_dict_5 == immutable_dict_6)
    assert not (immutable_dict_5 == immutable_dict_2)


# Generated at 2022-06-24 20:18:45.976287
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__('ImmutableDict({0})')
    assert var_0 == 0


# Generated at 2022-06-24 20:18:57.909350
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    '''
    Test that the ImmutableDict __eq__ method works as expected
    '''
    # Set up
    immutable_dict_1 = ImmutableDict({'key_1': 1, 'key_2': 2})
    immutable_dict_2 = ImmutableDict({'key_1': 1, 'key_2': 2})
    immutable_dict_3 = ImmutableDict({'key_1': 1, 'key_2': 3})
    immutable_dict_4 = ImmutableDict({'key_1': 1, 'key_2': 2, 'key_3': 3})
    immutable_dict_5 = ImmutableDict({'key_1': 1, 'key_3': 3, 'key_2': 2})

# Generated at 2022-06-24 20:19:04.823200
# Unit test for function is_iterable
def test_is_iterable():
    # Example
    var_0 = is_iterable([1, 2, 3])
    assert var_0 is True
    # Example
    var_1 = is_iterable({'a': 1, 'b': 2, 'c': 3})
    assert var_1 is True
    # Example
    var_2 = is_iterable((1, 2, 3, 4))
    assert var_2 is True
    # Example
    var_3 = is_iterable('')
    assert var_3 is True
    # Example
    var_4 = is_iterable(None)
    assert var_4 is False



# Generated at 2022-06-24 20:19:12.731360
# Unit test for function is_iterable
def test_is_iterable():
    test_iterable = ["This", "is", "iterable"]
    test_string = "This is not iterable"
    test_integer = 42
    assert is_iterable(test_iterable), 'Should evaluate to true'
    assert is_iterable(test_string), 'Strings are iterable'
    assert not is_iterable(test_integer), 'Should evaluate to false'
    assert not is_iterable(test_integer, include_strings=True), 'Should evaluate to false'
    assert is_iterable(test_string, include_strings=True), 'Should evaluate to true'



# Generated at 2022-06-24 20:19:13.684855
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # assertions
    assert True


# Generated at 2022-06-24 20:19:15.667326
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    count_0 = immutable_dict_0.__eq__(3)


# Generated at 2022-06-24 20:19:34.366036
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict([('a', 'b'), ('c', 'd')])
    hashable_0 = Hashable()
    mapping_0 = Mapping()
    immutable_dict_2 = ImmutableDict([('e', 'f'), ('g', 'h')])
    test_case_0()
    test_case_1()

    var_0 = immutable_dict_0.__eq__(immutable_dict_1)

    var_1 = immutable_dict_0.__eq__(immutable_dict_2)

    var_2 = immutable_dict_0.__eq__(immutable_dict_0)

    var_3 = immutable_dict_0.__eq__(hashable_0)

    var_4 = immutable_dict_

# Generated at 2022-06-24 20:19:37.543109
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_1 = immutable_dict_0.__eq__(immutable_dict_1)
    assert var_1 == True


# Generated at 2022-06-24 20:19:49.697003
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    immutable_dict_2 = ImmutableDict()
    immutable_dict_3 = ImmutableDict()
    immutable_dict_4 = ImmutableDict()
    immutable_dict_5 = ImmutableDict()
    immutable_dict_6 = ImmutableDict()
    immutable_dict_7 = ImmutableDict()
    immutable_dict_8 = ImmutableDict()
    immutable_dict_9 = ImmutableDict()
    immutable_dict_10 = ImmutableDict()
    immutable_dict_11 = ImmutableDict()
    immutable_dict_12 = ImmutableDict()
    immutable_dict_13 = ImmutableDict()
    immutable_dict_0.__eq__({})
    immutable_dict

# Generated at 2022-06-24 20:19:54.684634
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict(((1, 1), (1, 1)))
    var_0 = immutable_dict_0.__eq__(1)
    immutable_dict_1 = ImmutableDict(((1, 1), (1, 1)))
    var_1 = immutable_dict_0.__eq__(immutable_dict_1)
    immutable_dict_2 = ImmutableDict(((1, 2), (1, 1)))
    var_2 = immutable_dict_0.__eq__(immutable_dict_2)


# Generated at 2022-06-24 20:20:04.691624
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    immutable_dict_2 = ImmutableDict(a=1)
    immutable_dict_3 = ImmutableDict({'a': 1, 'b': 2})

    # Is equal
    var_0 = immutable_dict_1 == immutable_dict_3

    # Is different
    var_1 = immutable_dict_2 != immutable_dict_3

    # Is different
    var_2 = immutable_dict_1 != immutable_dict_2

    # Is different
    var_3 = immutable_dict_1 != immutable_dict_0

    # Is equal
    var_4 = immutable_dict_1 == immutable_dict_1

    # Is different
    var_5 = immutable_dict

# Generated at 2022-06-24 20:20:08.802214
# Unit test for function is_iterable
def test_is_iterable():
    # Test with dict
    dict_0 = dict()
    var_0 = is_iterable(dict_0)

    # Test with list
    list_0 = list()
    var_1 = is_iterable(list_0)


# Generated at 2022-06-24 20:20:10.851328
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'key': 'value'})
    dict_0 = dict()
    var_0 = immutable_dict_0.__eq__(dict_0)


# Generated at 2022-06-24 20:20:17.401286
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable({}) is True
    assert is_iterable(()) is True
    assert is_iterable('') is False
    assert is_iterable(object()) is False



# Generated at 2022-06-24 20:20:20.441301
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    arg_0 = ImmutableDict()
    ret_0 = immutable_dict_0.__eq__(arg_0)


# Generated at 2022-06-24 20:20:25.090962
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'x': 1})
    var_0 = immutable_dict_0.__eq__({'x': 1})
    var_1 = ImmutableDict({'x': 1}).__eq__({'x': 1})
    var_2 = ImmutableDict({}).__eq__({})


# Generated at 2022-06-24 20:20:58.483755
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    if immutable_dict_0 == immutable_dict_0:
        pass
    if (not immutable_dict_0) == immutable_dict_0:
        pass
    if immutable_dict_0 == (not immutable_dict_0):
        pass



# Generated at 2022-06-24 20:21:01.608252
# Unit test for function is_iterable
def test_is_iterable():

    assert is_iterable(tuple()) == True
    assert is_iterable(list()) == True
    assert is_iterable(dict()) == True
    assert is_iterable(set()) == True
    assert is_iterable(str()) == True
    assert is_iterable(unicode()) == True

    assert is_iterable(None) == False
    assert is_iterable(0) == False


# Generated at 2022-06-24 20:21:04.607569
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_1 = ImmutableDict()
    assert immutable_dict_1.__eq__(immutable_dict_1)
    immutable_dict_2 = ImmutableDict()
    assert immutable_dict_2.__eq__(immutable_dict_2)
    assert immutable_dict_1.__eq__(immutable_dict_2)


# Generated at 2022-06-24 20:21:07.800150
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    immutable_dict_2 = immutable_dict_0.__eq__(immutable_dict_1)
    immutable_dict_2 = immutable_dict_1.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:21:13.978429
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(ImmutableDict()) == True
    assert is_iterable(None) == False
    assert is_iterable((1, 2, 3)) == True
    assert is_iterable((i for i in range(10))) == True



# Generated at 2022-06-24 20:21:24.925389
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    t0 = ImmutableDict({'a': '1', 'b': '2'})
    t1 = ImmutableDict({'a': '1', 'b': '2'})
    assert t0 == t1

    t3 = ImmutableDict({'a': '1', 'b': '3'})
    assert t0 != t3

    t4 = ImmutableDict(a='1', b='2')
    assert t0 == t4

    # Ensure it never raises a TypeError
    class foo:
        pass

    f = foo()
    assert t0 != f
    assert t0 != 0
    assert t0 != 'abc'
    assert t0 != (1, 2, 3)


# Generated at 2022-06-24 20:21:32.058413
# Unit test for function is_iterable
def test_is_iterable():
    sequences = (
        'abc',
        u'abc',
        [1, 2, 3],
        (1, 2, 3),
        {1: '1', 2: '2', 3: '3'},
        lambda x: x + 1,
        {1, 2, 3},
        set([1, 2, 3]),
    )
    for seq in sequences:
        assert is_iterable(seq)

    # non-iterables
    non_iterables = (
        'abc',
        u'abc',
        1,
        3.141592653589793,
        True,
        False,
        None,
    )
    for seq in non_iterables:
        assert not is_iterable(seq)


# Generated at 2022-06-24 20:21:36.479899
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable((1, 2))
    assert is_iterable({})
    assert is_iterable({1, 2})
    assert is_iterable(1)
    assert is_iterable(None)
    assert not is_iterable("")


# Generated at 2022-06-24 20:21:40.306873
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test ImmutableDict::__eq__"""
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(dict())
    assert(var_0 == True)


# Generated at 2022-06-24 20:21:51.429788
# Unit test for function is_iterable
def test_is_iterable():
    assert (is_iterable(['a', 'b']) == True)
    assert (is_iterable('ab') == True)
    assert (is_iterable(('a', 'b')) == True)
    assert (is_iterable(set(['a', 'b'])) == True)
    assert (is_iterable(range(0, 10)) == True)
    assert (is_iterable(test_is_iterable) == True)
    assert (is_iterable({'a': 1, 'b': 2}) == True)
    assert (is_iterable(ImmutableDict({'a': 1, 'b': 2})) == True)

    assert (is_iterable(10) == False)
    assert (is_iterable(None) == False)


# Generated at 2022-06-24 20:22:51.124352
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    # Test case:
    test_case_0()



# Generated at 2022-06-24 20:22:56.313398
# Unit test for function is_iterable
def test_is_iterable():
    seq = (1, 2, 3)
    assert(is_iterable(seq) is True)

    seq = '123'
    assert(is_iterable(seq) is False)

    seq = 123
    assert(is_iterable(seq) is False)


# Generated at 2022-06-24 20:23:03.217359
# Unit test for function is_iterable
def test_is_iterable():
    data = {'a': 123, 'b': 'test', 'c': None}
    result = is_iterable(data)
    assert result is True
    #
    result = is_iterable(iter(data))
    assert result is True
    #
    result = is_iterable('test', include_strings=True)
    assert result is True
    #
    result = is_iterable(123)
    assert result is False


# Generated at 2022-06-24 20:23:07.747866
# Unit test for function is_iterable
def test_is_iterable():
    try:
        assert is_iterable([1, 2, 3]) and is_iterable({'a': 1, 'b': 2}) and is_iterable(set([1, 2, 3])) and is_iterable(
            'a string') and is_iterable(u'a string')
    except AssertionError:
        print('Expected True, but got False!')


# Generated at 2022-06-24 20:23:10.189825
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:23:16.858843
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'b': 2, 'a': 1})
    c = ImmutableDict({'a': 1})
    d = {'a': 1, 'b': 2}
    e = 'ImmutableDict({0})'.format(repr({'a': 1, 'b': 2}))

    assert(a.__eq__(b))
    assert(not a.__eq__(c))
    assert(not a.__eq__(d))
    assert(not a.__eq__(e))


# Generated at 2022-06-24 20:23:21.167369
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({"a": "b"})
    immutable_dict_1 = ImmutableDict({"a": "c"})
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:23:27.343269
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(None)
    assert not is_iterable(123)
    assert is_iterable([])
    assert is_iterable((1, 2, 3))
    assert is_iterable({})
    assert is_iterable(range(10))
    assert is_iterable('abc')
    assert is_iterable({'a': 1, 'b': 2}.keys())
    assert is_iterable({'a': 1, 'b': 2}.values())
    assert is_iterable({'a': 1, 'b': 2}.items())
    assert not is_iterable(None, include_strings=True)
    assert not is_iterable(123, include_strings=True)
    assert is_iterable([], include_strings=True)

# Generated at 2022-06-24 20:23:29.331633
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    dict_0 = dict()
    var_0 = immutable_dict_0.__eq__(dict_0)


# Generated at 2022-06-24 20:23:34.373719
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    hash_0 = hash(immutable_dict_0)
    hash_1 = hash(immutable_dict_1)
    assert immutable_dict_0 == immutable_dict_1
    assert immutable_dict_0 == immutable_dict_0
    assert immutable_dict_0 != immutable_dict_1


# Generated at 2022-06-24 20:24:34.988330
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(())


# Generated at 2022-06-24 20:24:45.410694
# Unit test for function is_iterable
def test_is_iterable():
    from ansible.module_utils.common._collections_compat import Iterable
    from ansible.module_utils.six import string_types

    variables = [
        ("Test string", False),
        ("Another string", False),
        (["String element"], True),
        (["Another string element"], True),
        ({"String key": "String value"}, True),
        ({"Another string key": "Another string value"}, True),
        ((1, 2), True),
        ((3, 4), True),
        ((5, 6, 7), True),
        (Iterable(1,2), True),
        (Iterable(3,4), True),
        (Iterable(5,6,7), True),
    ]

    for value, expected in variables:
        result = is_iterable(value)