

# Generated at 2022-06-24 20:15:00.372056
# Unit test for function is_iterable
def test_is_iterable():

    assert is_iterable(['1', 2])
    assert not is_iterable('_')
    assert not is_iterable((2.99))
    assert is_iterable(('_', '_'))
    assert not is_iterable(ImmutableDict())
    assert is_iterable(immutable_dict_0)
    assert not is_iterable(('',))
    assert is_iterable([])
    assert is_iterable((2, 1))
    assert is_iterable({})
    assert not is_iterable(2)
    assert not is_iterable(str_0)
    assert not is_iterable(tuple())
    assert not is_iterable(dict())
    assert not is_iterable((3,))
    assert is_iterable(('', '_'))

# Generated at 2022-06-24 20:15:07.963017
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = 'M^U'
    float_0 = 0.5
    # Testing for expected results
    result = is_iterable(str_0)
    assert result == True

    result = is_iterable(float_0)
    assert result == False

    result = is_iterable(float_0, include_strings=True)
    assert result == False

    result = is_iterable(str_0, include_strings=True)
    assert result == True


# Generated at 2022-06-24 20:15:11.604629
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1,2,3,4,5])
    assert is_iterable({})
    assert is_iterable({1:1, 2:2})
    assert is_iterable(1) == False
    assert is_iterable('ansible')
    assert is_iterable(u'ansible')


# Generated at 2022-06-24 20:15:18.392423
# Unit test for function is_iterable
def test_is_iterable():
    not_iterable_0 = 'G<V'
    assert not is_iterable(not_iterable_0)

    not_iterable_1 = 0.49
    assert not is_iterable(not_iterable_1)

    iterable_0 = ['C^M', 'WYM', 'D^A']
    assert is_iterable(iterable_0)

    iterable_1 = [0.42, 0.12, 0.24]
    assert is_iterable(iterable_1)

    iterable_2 = [['UZP', 'E[G'], ['C^M', 'WYM', 'D^A']]
    assert is_iterable(iterable_2)


# Generated at 2022-06-24 20:15:30.358650
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_1 = ImmutableDict()
    immutable_dict_2 = ImmutableDict()
    ret_val_0 = immutable_dict_1.__eq__(immutable_dict_2)
    immutable_dict_3 = ImmutableDict()
    immutable_dict_4 = immutable_dict_3
    ret_val_1 = immutable_dict_3.__eq__(immutable_dict_4)
    immutable_dict_5 = ImmutableDict()
    tuple_0 = (1, 2, 3)
    ret_val_2 = immutable_dict_5.__eq__(tuple_0)
    test_str_0 = '6o'
    test_str_1 = '6R'
    test_str_2 = 'M_'
    ret_val_3 = immutable_dict_1

# Generated at 2022-06-24 20:15:34.466701
# Unit test for function is_iterable
def test_is_iterable():
    assert(not is_iterable('M^U'))
    assert(is_iterable(0.5))
    assert(not is_iterable(ImmutableDict()))
    assert(is_iterable(ImmutableDict().union(0.5)))


# Generated at 2022-06-24 20:15:44.240277
# Unit test for function is_iterable
def test_is_iterable():
    list_0 = ['W', 'z', 'g', 'bP', 'R', 'W', '8']
    tuple_0 = (0, '', 4, 1)
    str_0 = 'M^U'
    immutable_dict_0 = ImmutableDict({'P': 'j', 'Z': 'x'})
    int_0 = 8
    float_0 = 0.5
    int_1 = 50
    tuple_1 = (0.5, 'Y', int_0, 3.14)
    tuple_2 = (1, 1, int_1)
    dict_0 = dict()
    dict_0['key_0'] = 'value_0'
    dict_1 = dict()
    dict_1['key_0'] = 'value_0'
    dict_2 = dict()
    dict_

# Generated at 2022-06-24 20:15:47.456574
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = 'M^U'
    float_0 = 0.5
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.union(float_0)
    var_1 = immutable_dict_0.difference(float_0)
    var_2 = is_iterable(str_0)
    assert var_2 is False


# Generated at 2022-06-24 20:15:57.186200
# Unit test for function is_iterable
def test_is_iterable():

    print('Testing function is_iterable')

    # Testing with some example values
    print('Testing with some example values')

    # Testing with a value of type string
    str_0 = 'C=2'
    result = is_iterable(str_0)
    assert result == False

    # Testing with a value of type float
    float_0 = 0.1
    result = is_iterable(float_0)
    assert result == False

    # Testing with the integer type
    int_0 = 1
    result = is_iterable(int_0)
    assert result == False

    # Testing with a boolean type
    bool_0 = False
    result = is_iterable(bool_0)
    assert result == False

    # Testing with a list
    list_0 = ['', '']
    result = is_iterable

# Generated at 2022-06-24 20:16:04.638822
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['string', 'list']) == True
    assert is_iterable('string') == False
    assert is_iterable(['list']) == True
    assert is_iterable('string', True) == True
    assert is_iterable(['list'], False) == True
    assert is_iterable('string', False) == False
    assert is_iterable(['string', 'list'], True) == True
    assert is_iterable(['string', 'list'], False) == True
    assert is_iterable(['string', 'list', ['embedded list']], True) == True
    assert is_iterable({}) == True
    assert is_iterable({}, True) == True
    assert is_iterable({}, False) == True


# Generated at 2022-06-24 20:16:13.883567
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    str_0 = 'fE'
    int_0 = -1
    float_0 = 0.28
    bool_0 = True
    converter_0 = ImmutableMapping(((int_0, float_0), (float_0, str_0)), ((float_0, float_0), (bool_0, str_0)))
    converter_1 = ImmutableMapping(((int_0, float_0), (float_0, str_0)), ((float_0, float_0), (bool_0, str_0)))
    converter_2 = ImmutableMapping(((int_0, float_0), (float_0, str_0)), ((str_0, str_0), (bool_0, str_0)))



# Generated at 2022-06-24 20:16:16.083985
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1})
    d2 = ImmutableDict({'a': 1})
    assert d1.__eq__(d2) == True


# Generated at 2022-06-24 20:16:25.232329
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    ImmutableDict_0 = ImmutableDict()
    ImmutableDict_0.update({'ls': 'ls'})
    ImmutableDict_1 = ImmutableDict()
    ImmutableDict_1.update({'ls': 'ls'})
    ImmutableDict_2 = ImmutableDict()
    ImmutableDict_2.update({'ls': 'ls'})
    ImmutableDict_3 = ImmutableDict()
    ImmutableDict_3.update({'ls': 'ls'})
    ImmutableDict_4 = ImmutableDict()
    ImmutableDict_4.update({'ls': 'ls'})
    ImmutableDict_5 = ImmutableDict()
    ImmutableDict_5.update({'ls': 'ls'})
    ImmutableDict_6

# Generated at 2022-06-24 20:16:30.919516
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = 'W]T'
    float_0 = -0.8
    bool_0 = True
    var_0 = is_iterable(float_0, bool_0)



# Generated at 2022-06-24 20:16:37.346338
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = 'n'
    list_0 = [45, 'F', -7, '-', False, float, 'y', '6', -7, '']
    dict_0 = {'D': 'w', 'b': -5.8, ' ': ['-', -7, 'O', -0.0, 'f'], 'N': str_0, 'Q': False}
    bool_0 = False
    var_0 = is_iterable(str_0, bool_0)
    var_1 = is_iterable(dict_0, bool_0)
    var_2 = is_iterable(list_0, bool_0)
    assert var_0 == True
    assert var_1 == True
    assert var_2 == True


# Generated at 2022-06-24 20:16:38.379774
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = 'm[o'
    var_1 = is_iterable(str_0)


# Generated at 2022-06-24 20:16:42.001554
# Unit test for function is_iterable
def test_is_iterable():
    a = 'test'
    result = is_iterable(a)
    assert result == False

    b = ['test', 'test']
    result = is_iterable(b)
    assert result == True


# Generated at 2022-06-24 20:16:52.750216
# Unit test for function is_iterable
def test_is_iterable():
    seq1 = (1, 2, 3)
    seq2 = 'abc'
    seq3 = [[1, 2], [3, 4, 5]]
    seq4 = {'a': 1, 'b': 2}
    seq5 = (1, 2, 'a')
    value_set1 = {seq1, seq2, seq3, seq4, seq5}
    value_set2 = {True, False, None}
    value_set3 = {(1, 2), 'abc', [1, 2], {1, 2}, {'a': 1}, 1, 2, 3.14}
    value_set = value_set1.union(value_set2).union(value_set3)
    for value in value_set:
        result = is_iterable(value)

# Generated at 2022-06-24 20:16:59.307089
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(None) == False
    assert is_iterable([]) == True
    assert is_iterable(()) == True
    assert is_iterable({}) == True
    assert is_iterable(set()) == True
    assert is_iterable('') == False
    assert is_iterable(b'') == False
    assert is_iterable(1) == False
    assert is_iterable(1.2) == False
    assert is_iterable(True) == False
    assert is_iterable(is_iterable) == False


# Generated at 2022-06-24 20:17:01.744473
# Unit test for function is_iterable
def test_is_iterable():
    str_lst = ['first', 'second', 'third']
    assert is_iterable(str_lst) == True



# Generated at 2022-06-24 20:17:11.528187
# Unit test for method __eq__ of class ImmutableDict

# Generated at 2022-06-24 20:17:16.368222
# Unit test for function is_iterable
def test_is_iterable():
    dict_0 = dict()
    dict_0['dict_0'] = 'test_value_1'
    dict_0['dict_1'] = 'test_value_2'
    dict_0['dict_2'] = 'test_value_3'
    dict_0['dict_3'] = -0.8
    dict_0['dict_4'] = -0.8
    dict_0.get('dict_3')
    dict_0.get('dict_4')
    list_0 = list()
    list_0.append('test_value_4')
    list_0.append('test_value_5')
    list_0.append('test_value_6')
    list_0.append(0.7)
    list_0.append(0.7)
    list_0[0]
   

# Generated at 2022-06-24 20:17:21.736322
# Unit test for function is_iterable
def test_is_iterable():
    # Test for is_iterable
    float_0 = -0.8
    bool_0 = True
    var_0 = is_iterable(float_0, bool_0)

# Generated at 2022-06-24 20:17:27.495794
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # TODO: Write test for ImmutableDict.__eq__
    # Create the input data
    test_type = 'dict'
    other = None
    tests = []
    expected = []
    test_case_results = []
    # Create the test case
    test_case = ImmutableDict(dict())
    tests.extend([test_type, other])
    expected.extend([False])
    test_case_results.append(test_case.__eq__(*tests))
    test_case = ImmutableDict(dict({'test_name': 'test_value'}))
    tests.extend([test_type, other])
    expected.extend([False])
    test_case_results.append(test_case.__eq__(*tests))

# Generated at 2022-06-24 20:17:32.738117
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    arg0 = ImmutableDict(['key', 'value'])
    arg1 = ImmutableDict(['key', 'value'])
    arg2 = ImmutableDict(['key', 'value'])
    result = arg0.__eq__(arg1, arg2)
    assert isinstance(result, bool)
    assert result


# Generated at 2022-06-24 20:17:33.895770
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    pass


# Generated at 2022-06-24 20:17:40.316893
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({'hello': 'world'})
    dict_1 = ImmutableDict({'goodbye': 'cruel world'})
    bool_0 = dict_0 == dict_1
    dict_2 = ImmutableDict({'hello': 'world'})
    bool_1 = dict_0 == dict_2
    bool_2 = dict_0 == dict_1


# Generated at 2022-06-24 20:17:48.074858
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    # Test basic equality
    test_dict_0 = ImmutableDict({'var_0': 'blah', 'var_1': 1})
    test_dict_1 = ImmutableDict({'var_0': 'blah', 'var_1': 1})
    assert test_dict_0 == test_dict_1

    # Test equality when order of items does not match
    test_dict_0 = ImmutableDict({'var_0': 'blah', 'var_1': 1})
    test_dict_1 = ImmutableDict({'var_1': 1, 'var_0': 'blah'})
    assert test_dict_0 == test_dict_1

    # Test inequality when data does not match

# Generated at 2022-06-24 20:17:55.654699
# Unit test for function is_iterable
def test_is_iterable():
    float_0 = 0.0
    bool_0 = True
    var_0 = is_iterable(float_0, bool_0)
    bool_1 = bool_0 and bool_0
    bool_2 = bool_1 and bool_1
    bool_3 = bool_2 and bool_2
    bool_4 = bool_3 and bool_3
    bool_5 = bool_4 and bool_4
    bool_6 = bool_5 and bool_5
    bool_7 = bool_6 and bool_6
    bool_8 = bool_7 and bool_7
    bool_9 = bool_8 and bool_8
    bool_10 = bool_9 and bool_9
    bool_11 = bool_10 and bool_10
    bool_12 = bool_11 and bool_11
    bool_13 = bool_12

# Generated at 2022-06-24 20:17:57.565622
# Unit test for function is_iterable
def test_is_iterable():
    # Test for case 0
    float_0 = -0.8
    bool_0 = True
    try:
        var_0 = is_iterable(float_0, bool_0)
    except TypeError:
        var_0 = False
    assert var_0 == False



# Generated at 2022-06-24 20:18:00.620538
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test when given any other type (the comparison will result in a hash error, hence returning false)
    d = ImmutableDict({'a': 1})
    result = d.__eq__({'a': 1})
    assert result == False


# Generated at 2022-06-24 20:18:10.064206
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_0 = dict_0.union({'foo': 'bar', 'baz': 'qux'})
    str_0 = 'boz'
    bool_0 = dict_0[str_0] == 'boz'
    str_1 = 'foo'
    bool_1 = dict_0[str_1] == 'boz'
    str_2 = 'foo'
    bool_2 = dict_0[str_2] == 'bar'
    list_0 = [str_1, str_2]
    bool_3 = all(list_0)
    bool_4 = not all(list_0) or bool_0
    # print(bool_4) \n


# Generated at 2022-06-24 20:18:17.791428
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_0['a'] = dict_5
    dict_0['b'] = dict_5
    dict_0['c'] = dict_5
    dict_1['a'] = dict_5
    dict_1['b'] = dict_5
    dict_1['c'] = dict_5
    dict_2['a'] = dict_5
    dict_2['b'] = dict_5
    dict_2['c'] = dict_5
    dict_3['a'] = dict_5
    dict_3['b'] = dict_5
    dict_4['a'] = dict_5
    dict_4['b']

# Generated at 2022-06-24 20:18:22.842354
# Unit test for function is_iterable
def test_is_iterable():
    with pytest.raises(Exception) as err:
        count(float_0)
    assert str(err.value) == 'Argument provided  is not an iterable'



# Generated at 2022-06-24 20:18:32.249645
# Unit test for function is_iterable
def test_is_iterable():
    float_0 = -0.8
    bool_0 = True
    var_0 = is_iterable(float_0, bool_0)
    assert var_0 is False
    var_1 = is_iterable(float_0, var_0)
    assert var_1 is False
    var_2 = is_iterable(float_0, True)
    assert var_2 is False
    var_3 = is_iterable(float_0, var_2)
    assert var_3 is False
    str_0 = "wG2_:)O>q4"
    var_4 = is_iterable(float_0, str_0)
    assert var_4 is False
    b_0 = -0.7
    var_5 = is_iterable(float_0, b_0)

# Generated at 2022-06-24 20:18:40.138861
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(()), "Expected True"
    assert is_iterable({}), "Expected True"
    assert is_iterable([]), "Expected True"
    assert not is_iterable(1), "Expected False"
    assert is_iterable(1, False), "Expected True"
    assert not is_iterable(1, True), "Expected False"


# Generated at 2022-06-24 20:18:49.603937
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict()
    var_1 = ImmutableDict()
    var_2 = ImmutableDict()
    var_3 = ImmutableDict()
    var_4 = ImmutableDict()
    var_5 = ImmutableDict()
    var_6 = ImmutableDict()
    var_7 = ImmutableDict()
    var_7 = ImmutableDict()
    var_8 = ImmutableDict()
    var_9 = ImmutableDict()
    var_10 = ImmutableDict()
    var_11 = ImmutableDict()
    var_12 = ImmutableDict()
    var_13 = ImmutableDict()
    var_13 = ImmutableDict()
    var_14 = ImmutableDict()
    var_15 = ImmutableDict()
   

# Generated at 2022-06-24 20:18:50.962589
# Unit test for function is_iterable
def test_is_iterable():
    pass


# Generated at 2022-06-24 20:18:54.478162
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    val_0 = ImmutableDict()
    val_1 = False
    val_2 = ImmutableDict()
    val_2 = val_0.__eq__(val_1)


# Generated at 2022-06-24 20:19:03.910237
# Unit test for function is_iterable
def test_is_iterable():
    print("Testing is_iterable...")
    a = {'a': 2, 'b': 4}
    b = [3, 5, 7]
    c = 'Hello'
    d = {'a': 'b', 'c': 'd'}
    # Test 1
    if is_iterable(a):
        print("Test 1 passed\n")
    else:
        print("Test 1 failed\n")
    # Test 2
    if is_iterable(b):
        print("Test 2 passed\n")
    else:
        print("Test 2 failed\n")
    # Test 3
    if not is_iterable(c):
        print("Test 3 passed\n")
    else:
        print("Test 3 failed\n")
    # Test 4

# Generated at 2022-06-24 20:19:08.645003
# Unit test for function is_iterable
def test_is_iterable():
    string_0 = "0123456789"
    string_1 = "0123456789"
    var_0 = is_iterable(string_0, string_1)


# Generated at 2022-06-24 20:19:17.933525
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict(['a', 'b', 'c'], 'a', 1, 'b', 2, 'c', 3)
    var_1 = ImmutableDict(['a', 'b', 'c'], 'a', 1, 'b', 2, 'c', 3)
    var_2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3}, {'a': 1, 'b': 2, 'c': 3})
    var_3 = ImmutableDict({'a': 1, 'b': 2, 'c': 3}, {'a': 1, 'b': 2, 'c': 3})
    var_4 = ImmutableDict({'a': 1}, {'a': 1})
    var_5 = ImmutableDict({'a': 1}, {'a': 1})

# Generated at 2022-06-24 20:19:23.311507
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    int_0 = 0
    dict_0 = dict()
    dict_0['str_0'] = "value"
    dict_0[int_0] = -1
    dict_1 = dict()
    dict_1["str_0"] = "anothervalue"
    dict_1["key2"] = 3
    dict_1[int_0] = -1
    dict_0 = ImmutableDict(dict_0)
    dict_1 = ImmutableDict(dict_1)
    bool_0 = dict_0.__eq__(dict_1)


# Generated at 2022-06-24 20:19:28.342854
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict((('key', 'value'),))
    var_1 = ImmutableDict((('key', 'value'),))
    var_2 = ImmutableDict((('key2', 'value2'),))
    var_3 = ImmutableDict()
    assert var_0 == var_1
    assert var_0 != var_2
    assert var_0 != var_3
    assert var_2 != var_3
    assert ImmutableDict() != {}


# Generated at 2022-06-24 20:19:34.969041
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_ImmutableDict = ImmutableDict({'dict': {'key': 'value'}, 'key': 'value', 'simple': True})
    assert test_ImmutableDict == [{'dict': {'key': 'value'}, 'key': 'value', 'simple': True}]
    assert test_ImmutableDict == {'dict': {'key': 'value'}, 'key': 'value', 'simple': True}
    assert test_ImmutableDict == {'simple': True, 'dict': {'key': 'value'}, 'key': 'value'}
    assert test_ImmutableDict != {'dict': {'key': 'value'}, 'key': 'value'}
    assert test_ImmutableDict != [{'dict': {'key': 'value'}, 'key': 'value'}]
   

# Generated at 2022-06-24 20:19:40.289092
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_1 = ImmutableDict()
    dict_1['A'] = 'A'
    dict_0.union(dict_1)
    dict_0['B'] = 'B'
    dict_0.union(dict_1)
    dict_0.difference(dict_1)
    dict_0['C'] = 'C'
    dict_0.union(dict_1)
    dict_0.difference(dict_1)
    dict_0.union(dict_1)
    dict_0['D'] = 'D'
    dict_0.difference(dict_1)
    dict_0.union(dict_1)
    dict_0.difference(dict_1)
    dict_0.union(dict_1)

# Generated at 2022-06-24 20:19:50.261819
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    float_0 = -0.1
    float_1 = float_0
    bool_0 = True
    bool_1 = bool_0
    dict_0 = {float_0: float_1, bool_0: bool_1}
    dict_1 = {bool_1: bool_0, float_0: float_1}
    bool_2 = bool_1
    immutabledict_0 = ImmutableDict(dict_0, **dict_1)
    bool_3 = bool_2
    immutabledict_1 = ImmutableDict(dict_1, **dict_0)
    bool_3 = immutabledict_0.__eq__(immutabledict_1)
    if bool_3:
        # Accepts an ImmutableDict with the same items
        return
    test_case_0

# Generated at 2022-06-24 20:19:56.668414
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(a=1, b=2, c=3)
    d2 = ImmutableDict(a=1, b=4, c=3)
    d3 = ImmutableDict(b=4, c=3, a=1)
    null = None
    assert d1 == d1
    assert d2 == d3
    assert d1 != d2
    assert d1 != null


# Generated at 2022-06-24 20:20:03.879763
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    val_0 = ImmutableDict(k_0="v_0", k_1="v_1")
    val_1 = ImmutableDict(k_0="v_0", k_1="v_1")
    val_2 = ImmutableDict(k_0="v_0", k_1="v_1")

    res_0 = val_0 == val_1
    assert res_0

    res_1 = val_1 == val_2
    assert res_1

    res_2 = val_2 == val_0
    assert res_2



# Generated at 2022-06-24 20:20:08.764486
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'key_0': 'var_0', 'key_1': 'var_1'})
    d2 = ImmutableDict({'key_0': 'var_0', 'key_1': 'var_1'})
    assert d1 == d2


# Generated at 2022-06-24 20:20:16.888363
# Unit test for function is_iterable
def test_is_iterable():
    mock_0 = ["blog"]
    assert is_iterable(mock_0) == True
    assert is_iterable(-0.8) == False



# Generated at 2022-06-24 20:20:26.079986
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    arg_0 = ImmutableDict()
    arg_1 = ImmutableDict()
    arg_2 = None
    arg_3 = ImmutableDict()
    arg_4 = ImmutableDict()
    arg_5 = ImmutableDict()
    arg_6 = ImmutableDict()
    ret_0 = arg_0.__eq__(arg_1)
    ret_1 = arg_2.__eq__(arg_3)
    ret_2 = arg_4.__eq__(arg_5)
    ret_3 = arg_6.__eq__(arg_1)


# Generated at 2022-06-24 20:20:28.379333
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    float_0 = ImmutableDict(24)
    bool_0 = 0.6
    var_0 = float_0 == bool_0


# Generated at 2022-06-24 20:20:29.270535
# Unit test for function is_iterable
def test_is_iterable():
    test_case_0()


# Generated at 2022-06-24 20:20:39.279903
# Unit test for function is_iterable
def test_is_iterable():
    var_0 = ImmutableDict({"a": 1, "b": 2}, c=3, d=4)
    var_1 = var_0.union({"a": 10})
    var_2 = var_1.difference(["c"])
    assert var_0 == {"a": 1, "b": 2, "c": 3, "d": 4}
    assert var_1 == {"a": 10, "b": 2, "c": 3, "d": 4}
    assert var_2 == {"a": 10, "b": 2, "d": 4}
    assert var_0 != var_1
    assert var_1 != var_2
    assert hash(var_0) == hash(var_0)
    assert hash(var_1) == hash(var_1)
    assert hash(var_2)

# Generated at 2022-06-24 20:20:42.946491
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({'key3': False, 'key1': 'value1', 'key2': 1})
    dict_0 = dict_0.union({'key2': 3})
    dict_0 = dict_0.difference(['key3'])
    assert dict_0 == {'key1': 'value1', 'key2': 3}

# Generated at 2022-06-24 20:20:51.571707
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 1, None], True) is True
    assert is_iterable({
        'b': 1,
        'a': 2
    }, True) is True
    assert is_iterable(set([1, 2, 3]), True) is True
    assert is_iterable(1, False) is False
    assert is_iterable(1.1, True) is True
    assert is_iterable('a', True) is True
    assert is_iterable(True, True) is False
    assert is_iterable(None, True) is False
    assert is_iterable(memoryview(b'123'), True) is True
    assert is_iterable(bytearray(b'123'), True) is True
    assert is_iterable((x for x in range(3)), True) is True



# Generated at 2022-06-24 20:20:54.605973
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(range(5), False)
    assert not is_iterable("Foo Bar Baz")


# Generated at 2022-06-24 20:20:57.992900
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(set(['a', 1, 2]))
    assert not is_iterable(1.2)
    assert is_iterable(str(''))
    assert not is_iterable(str(''), include_strings=True)



# Generated at 2022-06-24 20:21:04.660924
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict({'a': 1, 'b': 2})
    var_1 = ImmutableDict({'a': 1})
    var_0.__eq__(var_1)
    var_1 = ImmutableDict({'a': 1, 'b': 2})
    var_0.__eq__(var_1)


# Generated at 2022-06-24 20:21:15.330216
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d = ImmutableDict({1: 2, 3: 4})
    d2 = ImmutableDict({1: 3, 3: 4})
    assert d != d2
    assert d != 1234
    assert d != {1: 2, 3: 4}
    assert d != frozenset([(1, 2), (3, 4)])
    d2 = ImmutableDict({1: 2, 3: 4})
    assert d == d2


# Generated at 2022-06-24 20:21:19.388832
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(24)
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(x for x in range(10))
    assert is_iterable(iter(range(10)))
    assert not is_iterable(24, include_strings=True)
    assert is_iterable("", include_strings=True)



# Generated at 2022-06-24 20:21:26.396019
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = dict()
    dict_1 = dict()
    dict_1['a'] = 'a'
    dict_1['b'] = 'b'
    dict_1['d'] = 'd'
    dict_1['c'] = 'c'
    dict_2 = dict()
    dict_2['c'] = 'c'
    dict_2['d'] = 'd'
    dict_2['b'] = 'b'
    dict_2['a'] = 'a'
    return_value_0 = ImmutableDict(dict_1)
    assert return_value_0 == return_value_0
    return_value_1 = ImmutableDict(dict_2)
    assert return_value_0 != return_value_1
    assert return_value_0 != dict_0



# Generated at 2022-06-24 20:21:28.969166
# Unit test for function is_iterable
def test_is_iterable():
    # Zero
    try:
        test_case_0()
    except Exception as e:
        if str(e) == 'Argument provided  is not an iterable':
            print('Test passed')
            return True
        print('Test failed')
        return False
    print('Test failed')
    return False

# Unit test execution
test_is_iterable()



# Generated at 2022-06-24 20:21:32.368461
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Initialize test variables
    var_0 = is_string("Hello World!")


# Generated at 2022-06-24 20:21:43.793058
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({'abc': 'abc', 'def': 'def'})
    dict_1 = ImmutableDict({'abc': 'abc', 'def': 'def'})
    dict_2 = ImmutableDict({'abc': 'abc', 'def': 'ghi'})
    dict_3 = ImmutableDict({'xyz': 'xyz', 'klm': 'klm'})
    dict_4 = dict({'abc': 'abc', 'def': 'def'})
    dict_5 = dict({'abc': 'abc', 'def': 'def'})
    dict_6 = dict({'abc': 'abc', 'def': 'ghi'})
    dict_7 = dict({'xyz': 'xyz', 'klm': 'klm'})

# Generated at 2022-06-24 20:21:45.529237
# Unit test for function is_iterable
def test_is_iterable():
    assert False == is_iterable(24)
    assert True == is_iterable(list())


# Generated at 2022-06-24 20:21:47.289690
# Unit test for function is_iterable
def test_is_iterable():
    int_0 = 24
    var_0 = is_iterable(int_0)
    assert var_0 == False



# Generated at 2022-06-24 20:21:51.534726
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    running_dict = ImmutableDict(var_1=1, var_2=2, var_3=3)
    running_dict_2 = ImmutableDict(var_1=1, var_2=2, var_3=3)
    assert running_dict == running_dict_2, "__eq__ method of ImmutableDict didn't give expected result"


# Generated at 2022-06-24 20:21:56.053464
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict()
    var_1 = ImmutableDict()
    var_2 = (var_0 == var_1)
    var_3 = ImmutableDict(os='linux', distro='centos')
    var_4 = ImmutableDict(distro='centos', os='linux')
    var_5 = (var_3 == var_4)
    var_6 = ImmutableDict(os='linux', distro='centos')
    var_7 = (var_3 == var_6)
    var_8 = ImmutableDict(os='linux', distro='centos', other=True)
    var_9 = (var_3 == var_8)


# Generated at 2022-06-24 20:22:08.082702
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    # Create a simple ImmutableDict object
    test_dict = ImmutableDict({'key1': 'val1', 'key2': 'val2', 'key3': 'val3'})

    # Check that two ImmutableDict objects with the same content are equal
    assert test_dict == ImmutableDict({'key1': 'val1', 'key2': 'val2', 'key3': 'val3'})

    # Check that two ImmutableDict objects with the same content are equal even if they
    # are created in different ways
    assert test_dict == ImmutableDict(key1='val1', key2='val2', key3='val3')

    # Check that two ImmutableDict objects with the same content are equal even if one of
    # them is empty
    assert test_dict == ImmutableDict()

   

# Generated at 2022-06-24 20:22:17.385089
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict(['a', 'b'], {'a':1, 'b':2})
    dict_1 = ImmutableDict(['b', 'a'], {'a':1, 'b':2})
    dict_2 = ImmutableDict(['a', 'b'], {'a':1, 'b':3})
    dict_3 = ImmutableDict(['a', 'b'], {'a':1, 'b':2, 'c':3})
    dict_4 = ImmutableDict(['b', 'a'], {'a':1, 'b':2, 'c':3})
    dict_5 = ImmutableDict(['a', 'b'], {'a':1, 'b':2, 'd':3})

# Generated at 2022-06-24 20:22:18.338813
# Unit test for function is_iterable
def test_is_iterable():
    assert test_case_0() == False


# Generated at 2022-06-24 20:22:23.895156
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_1 = ImmutableDict(foo='bar')
    immutable_dict_2 = ImmutableDict(foo='bar')
    immutable_dict_3 = ImmutableDict()

    # Given
    assert immutable_dict_1 == immutable_dict_2  # Then
    assert immutable_dict_2 != immutable_dict_3  # Then
    # Check for using the same objects for comparison
    assert immutable_dict_1 != immutable_dict_1  # Then
    assert immutable_dict_1 is immutable_dict_1  # Then
    assert immutable_dict_1 == immutable_dict_1  # Then

    # Given
    int_test = 1
    # Then
    assert immutable_dict_1 != int_test  # Then
    # Then
    assert immutable_dict_1 is not int_test  # Then

    #

# Generated at 2022-06-24 20:22:29.214341
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}) == ImmutableDict({'a': 1, 'b': 2, 'c': 3})


# Generated at 2022-06-24 20:22:31.726146
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_1 = ImmutableDict()
    var_0 = dict_0 == dict_1


# Generated at 2022-06-24 20:22:36.249386
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    my_dict = ImmutableDict({'a': 1, 'b': 2})
    same_dict = ImmutableDict({'a': 1, 'b': 2})
    not_same_dict = ImmutableDict({'a': 1, 'b': 1})
    try:
        bool_0 = my_dict.__eq__(1)
        raise Exception('An exception should have been raised')
    except TypeError:
        pass
    else:
        raise Exception('The test should have failed here')
    bool_1 = my_dict.__eq__(same_dict)
    bool_2 = my_dict == same_dict
    bool_3 = my_dict.__eq__(not_same_dict)
    bool_4 = my_dict == not_same_dict


# Generated at 2022-06-24 20:22:38.543551
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable((1, 2)) is True
    assert is_iterable({'a', 'b'}) is True
    assert is_iterable({'a': 1, 'b': 2}) is True
    assert is_iterable(1) is False



# Generated at 2022-06-24 20:22:44.257504
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict({u'one': 1, u'two': 2, u'three': 3})
    var_1 = ImmutableDict({u'one': 1, u'two': 2, u'three': 3})
    var_2 = ImmutableDict({u'one': 2, u'two': 2, u'three': 3})
    assert var_0 == var_1
    assert var_0 != var_2


# Generated at 2022-06-24 20:22:51.155669
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_5 = ImmutableDict()
    var_4 = ImmutableDict()
    var_3 = ImmutableDict(__a="val_0", __b="val_1")
    var_2 = ImmutableDict(__b="val_1", __a="val_0")
    var_1 = ImmutableDict(__a="val_0")
    var_0 = ImmutableDict()
    try:
        assert var_3 == var_2
    except AssertionError:
        raise AssertionError("%s != %s" % (var_3, var_2))

    try:
        assert var_1 == var_1
    except AssertionError:
        raise AssertionError("%s != %s" % (var_1, var_1))


# Generated at 2022-06-24 20:23:09.004507
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    my_dict_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    my_dict_2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    # positive test: comparing two ImmutableDicts with the same key-value pairs
    assert (my_dict_1 == my_dict_2)
    # negative test: comparing an ImmutableDict with a list
    assert (my_dict_1 != [1, 2, 3])
    # negative test: comparing an ImmutableDict with a new ImmutableDict containing different key-value pairs
    my_dict_3 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    assert (my_dict_1 != my_dict_3)

#

# Generated at 2022-06-24 20:23:17.260308
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({
        'a': 'a',
        'b': 'b',
        'c': 'c'
    })
    dict_1 = ImmutableDict({
        'a': 'a',
        'b': 'b',
        'c': 'c'
    })
    dict_2 = ImmutableDict({
        'c': 'c',
        'b': 'b',
        'a': 'a'
    })
    dict_3 = ImmutableDict({
        'a': 'a',
        'b': 'b',
        'c': 'c',
        'd': 'd'
    })
    dict_4 = ImmutableDict({
        'a': 'a',
        'b': 'b',
        'c': 'd'
    })
   

# Generated at 2022-06-24 20:23:25.558904
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Definition of local function
    def func_0():
        # Call of local function
        func_0()
    # Definition of local class
    class TestClass_0:
        def __init__(self, test_parameter_0):
            self.test_parameter_0 = test_parameter_0
        def __eq__(self, other):
            return (self.test_parameter_0 == other.test_parameter_0) and isinstance(other, self.__class__)
    str_0 = 'str'
    int_0 = 9
    float_0 = 2.3
    list_0 = [int_0, float_0, str_0]
    tuple_0 = (int_0, float_0, str_0)

# Generated at 2022-06-24 20:23:31.435629
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    int_0 = 24
    int_1 = 24
    int_2 = 25
    int_3 = 26
    int_4 = 27
    int_5 = 28
    int_6 = 29
    str_0 = 'dict1'
    str_1 = 'dict2'
    str_2 = 'dict3'
    str_3 = 'dict4'
    str_4 = 'dict1'
    str_5 = 'dict2'
    str_6 = 'dict3'
    str_7 = 'dict4'
    float_0 = float(float_0)
    float_1 = float(float_0)
    float_2 = float(float_0)
    float_3 = float(float_0)
    float_4 = float(float_0)

# Generated at 2022-06-24 20:23:34.928010
# Unit test for function is_iterable
def test_is_iterable():
    # Test with a list
    var_1 = [1, 2, 3]
    var_2 = is_iterable(var_1)

    # Test with a set
    var_3 = {1, 2, 3}
    var_4 = is_iterable(var_3)



# Generated at 2022-06-24 20:23:44.748891
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    int_0 = ImmutableDict()
    int_1 = ImmutableDict()
    int_2 = ImmutableDict()
    int_3 = ImmutableDict()
    int_4 = ImmutableDict()
    int_5 = ImmutableDict()
    int_6 = ImmutableDict()
    int_7 = ImmutableDict()
    int_8 = ImmutableDict()
    int_9 = ImmutableDict()
    int_10 = ImmutableDict()
    int_11 = ImmutableDict()
    int_12 = ImmutableDict()
    int_13 = ImmutableDict()
    int_14 = ImmutableDict()
    int_15 = ImmutableDict()
    int_16 = ImmutableDict()
    int_17 = ImmutableDict()
   

# Generated at 2022-06-24 20:23:52.359971
# Unit test for function is_iterable
def test_is_iterable():
    # The function should return "True" for an iterable input.
    iterable_0 = [1, 2, 3]
    assert is_iterable(iterable_0)

    # The function should return "False" for a non-iterable input.
    non_iterable_0 = 3
    assert not is_iterable(non_iterable_0)

    # The function should return "False" for a string input.
    string_0 = 'test'
    assert not is_iterable(string_0)

    # The function should return "True" for a string input when "include_strings" is "True".
    string_1 = 'test'
    assert is_iterable(string_1, include_strings=True)

    # The function should raise an Exception when the provided input is not an iterable.
    non_iterable

# Generated at 2022-06-24 20:23:56.852989
# Unit test for function is_iterable
def test_is_iterable():
    # Test case 0
    int_0 = 24
    var_0 = is_iterable(int_0)

    if var_0 is True:
        print('Test case 0 failed:')
        print(is_iterable(int_0))
    else:
        print('Test case 0 passed:')
        print(is_iterable(int_0))


# Generated at 2022-06-24 20:24:05.873994
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({1: 1, 2: 2, 3: 3})
    dict_1 = ImmutableDict({1: 1, 2: 2, 3: 3})
    dict_2 = ImmutableDict({1: 0, 2: 2, 3: 3})
    dict_3 = frozenset([1, 2, 3])
    dict_4 = set([1, 2, 3])

    assert dict_0 == dict_1
    assert not dict_0 == dict_2
    assert not dict_0 == dict_3
    assert not dict_0 == dict_4


# Generated at 2022-06-24 20:24:15.638496
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test 0: Test whether the __eq__ method returns true if the dictionaries have the same keys and values
    test_dict_1 = {'key1': 'value1', 'key2': 'value2'}
    test_dict_2 = {'key2': 'value2', 'key1': 'value1'}
    assert ImmutableDict(test_dict_1) == ImmutableDict(test_dict_2)

    # Test 1: Test whether the __eq__ method returns true when the dictionaries are the same
    assert ImmutableDict(test_dict_1) == ImmutableDict(test_dict_1)

    # Test 2: Test whether the __eq__ method returns false when the dictionaries are different

# Generated at 2022-06-24 20:24:34.956321
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_1 = ImmutableDict()
    var_2 = ImmutableDict()
    var_3 = ImmutableDict()
    if var_1.__eq__(var_2) and var_2.__eq__(var_1):
        print("Var 1, 2 and 3 are equal")
    else:
        print("Cannot prove that 1, 2 and 3 are equal")


# Generated at 2022-06-24 20:24:44.972943
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_1 = ImmutableDict({'a':34, 'c':1})
    dict_2 = ImmutableDict({'c':1, 'a':34})
    set_0 = {'a':34, 'c':1}

    assert dict_1 == dict_2, "Two ImmutableDicts with the same values are equal"
    assert dict_1 == set_0, "An ImmutableDict and a set with the same values are equal"
    assert dict_1 != dict_0, "An empty ImmutableDict is not equal to a non-empty one"
    assert dict_1 != 1, "An ImmutableDict is not equal to an arbitrary value"


# Generated at 2022-06-24 20:24:53.690542
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict(['a', 'b', 'c'], a=1, b=2, c=3)
    dict_1 = ImmutableDict(['a', 'b', 'c'], a=1, b=2, c=3)
    dict_2 = ImmutableDict(['a', 'b', 'c'], a=1, b=2, c=4)
    dict_3 = ImmutableDict(['a', 'b', 'c'], a=1, b=3, c=3)
    dict_4 = ImmutableDict(['a', 'b', 'c'], a=2, b=2, c=3)
    dict_5 = ImmutableDict(['a', 'b', 'c'], a=1, b=2)
