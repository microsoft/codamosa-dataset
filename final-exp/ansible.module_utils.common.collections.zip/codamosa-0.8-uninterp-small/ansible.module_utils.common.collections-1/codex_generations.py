

# Generated at 2022-06-24 20:14:51.968033
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # Test for a subclass of ImmutableDict
    class SubImmutableDict(ImmutableDict):
        pass

    mapping = Mapping((('a', 1), ('b', 2), ('c', 3)))
    immutable_dict = ImmutableDict(mapping)

    # Test for an equal ImmutableDict
    assert mapping == immutable_dict.difference(('a', 'b', 'c'))

    # Test for a different ImmutableDict
    assert ImmutableDict(mapping) == immutable_dict.difference(('a', 'b'))
    assert mapping == immutable_dict.difference(('a',))

    # Test for an empty ImmutableDict
    assert ImmutableDict() == immutable_dict.difference(('a', 'b', 'c'))

    # Test with a Mapping subclass

# Generated at 2022-06-24 20:14:59.747416
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # Test case 1
    # Setup
    var_0 = ImmutableDict({"a": "b", "c": "d"}, e="f")
    var_1 = ["a"]
    expected_0 = ImmutableDict({"c": "d", "e": "f"})
    # Run
    actual_0 = var_0.difference(var_1)
    # Verify
    if not (actual_0 == expected_0):
        raise Exception('Returned value does not match expected value')


# Generated at 2022-06-24 20:15:09.757598
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # No error is raised if the key is not found
    d1 = ImmutableDict({'test': 'test'})
    d2 = d1.difference(['wrong_key'])
    assert d2 == ImmutableDict({'test': 'test'})

    # Original keys are removed
    d1 = ImmutableDict({'test': 'test', 'test2': 'test2'})
    d2 = d1.difference(['wrong_key', 'test'])
    assert d2 == ImmutableDict({'test2': 'test2'})

    # Subtractive iterable items in the dict preserves the dict
    d1 = ImmutableDict({'test': 'test', 'test2': 'test2'})

# Generated at 2022-06-24 20:15:13.849586
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    var_0 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    var_1 = frozenset({'a', 'b'})
    var_2 = var_0.difference(var_1)
    assert var_2.get('b') ==  None


# Generated at 2022-06-24 20:15:16.755230
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    immutable_dict = ImmutableDict({"key1": "val1", "key2": "val2", "key3": "val3"})
    result = immutable_dict.difference(["key1"])

    assert result == ImmutableDict({"key2": "val2", "key3": "val3"})


# Generated at 2022-06-24 20:15:21.912998
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # set up all of the inputs
    subtractive_iterable = ImmutableDict()
    
    # create the ImmutableDict object
    obj_ImmutableDict = ImmutableDict()
    obj_ImmutableDict.difference(subtractive_iterable)


# Generated at 2022-06-24 20:15:23.667936
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    byte_1 = ImmutableDict()
    byte_2 = ImmutableDict()
    var_0 = byte_1.__eq__(byte_2)


# Generated at 2022-06-24 20:15:25.833620
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    dict_0 = ImmutableDict({"hi":"hi"})
    dict_1 = dict_0.difference([])


# Generated at 2022-06-24 20:15:30.620256
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_dict = ImmutableDict({"a":1,"b":2,"c":3,"d":4,"e":5})
    test_dict_b = test_dict.difference(['a','c'])
    assert test_dict_b == ImmutableDict({'b':2,'d':4,'e':5})


# Generated at 2022-06-24 20:15:32.975022
# Unit test for function is_iterable
def test_is_iterable():
    bytes_0 = tuple([1, 2, 3])
    var_0 = is_iterable(bytes_0)
    assert var_0 == True



# Generated at 2022-06-24 20:15:43.214011
# Unit test for function is_iterable
def test_is_iterable():
    seq = [1, 2, 3]
    seq_dict = {'a': 1, 'b': 2, 'c': 3}
    seq_str = 'abc'
    assert is_iterable(seq)
    assert is_iterable(seq_dict)
    assert is_iterable(seq_str)
    assert is_iterable(seq_str, include_strings=True)
    assert not is_iterable(seq_str, include_strings=False)
    assert not is_iterable(seq, include_strings=True)
    assert not is_iterable(seq_dict, include_strings=True)


# Generated at 2022-06-24 20:15:49.024134
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Scenario 1
    # Try to build immutable dictionary with empty argument
    # Compare it with a mapping
    mapping = {'a': 1, 'b': 2}
    immutable_dict = ImmutableDict()
    assert immutable_dict == mapping


# Generated at 2022-06-24 20:15:51.639818
# Unit test for function is_iterable
def test_is_iterable():
    var_0 = is_iterable(10)
    var_1 = is_iterable([1, 2])

if __name__ == '__main__':
    print(test_case_0())
    print(test_is_iterable())

# Generated at 2022-06-24 20:15:57.536158
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert '0' == '0.0'
    assert '0' == '00'
    assert ['0'] == ['00']
    assert '0' == 0
    assert '0' == 0.0
    assert '0.0' == 0
    assert '0.0' == 0.0
    assert '0' == ['0']
    assert '0' == ('0', '0')
    assert '0' == {'0': '0'}
    assert '0' == [0]
    assert '0' == (0,)
    assert '0' == {0: '0'}
    assert '0.0' == [0.0]
    assert '0.0' == (0.0,)
    assert '0.0' == {0.0: '0.0'}
    assert '0' == ''

# Generated at 2022-06-24 20:16:03.319682
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d_0 = ImmutableDict({'1': '1', '2': '2', '3': '3'})
    l_2 = ['1', '2', '3']
    l_3 = ['1', '2', '3']
    f_2 = True
    if set(l_2) != set(l_3):
        f_2 = False
    assert_equals(f_2, d_0.__eq__(frozenset(l_2)))


# Generated at 2022-06-24 20:16:07.550684
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    bytes_input = {'input_a': ['a', 'b', 'c'], 'input_b': ['d', 'e', 'f']}
    var_0 = ImmutableDict(bytes_input)
    bytes_input_1 = {'input_a': ['a', 'b', 'c'], 'input_b': ['d', 'e', 'f']}
    var_1 = ImmutableDict(bytes_input_1)
    assert(var_0 != var_1)


# Generated at 2022-06-24 20:16:09.397098
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_1 = dict()
    assert dict_0 == dict_1


# Generated at 2022-06-24 20:16:13.094976
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable(('a', 'b', 'c'))
    assert is_iterable(set(['a', 'b', 'c']))
    assert not is_iterable('abc')
    assert is_iterable('abc', include_strings=True)



# Generated at 2022-06-24 20:16:15.071526
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({}).__eq__(ImmutableDict({})), 'ImmutableDict.__eq__'


# Generated at 2022-06-24 20:16:17.761600
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    i_dict_0 = ImmutableDict({'one': 1, 'two': 2})
    assert i_dict_0.__eq__(ImmutableDict({'one': 1, 'two': 2}))


# Generated at 2022-06-24 20:16:30.170777
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict()
    var_1 = ImmutableDict(((('a', 'b'),),))
    var_2 = {'a': 'b'}
    var_3 = ImmutableDict(((('a', 'c'),),))
    var_4 = ImmutableDict(((('c', 'b'),),))
    var_5 = None
    var_6 = ImmutableDict(((('a', 'b'),))).__eq__(var_2)
    var_7 = ImmutableDict(((('a', 'b'),))).__eq__(var_3)
    var_8 = ImmutableDict(((('a', 'b'),))).__eq__(var_4)

# Generated at 2022-06-24 20:16:32.343958
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    args = {'z': 1}
    test = ImmutableDict(args)
    other = ImmutableDict(args)
    expected = True
    actual = test == other
    assert expected == actual


# Generated at 2022-06-24 20:16:39.751558
# Unit test for function is_iterable
def test_is_iterable():
    test_list = ['a', 'b']
    test_tuple = ('a', 'b')
    test_dict = {'h': 'house', 'c': 'car'}
    test_string = 'N/A'
    assert is_iterable(test_list), "test_is_iterable: List is not an iterable"
    assert is_iterable(test_tuple), "test_is_iterable: Tuple is not an iterable"
    assert is_iterable(test_dict), "test_is_iterable: Dict is not an iterable"
    assert not is_iterable(test_string), "test_is_iterable: String is iterable"


# Generated at 2022-06-24 20:16:42.805576
# Unit test for function is_iterable
def test_is_iterable():
    var_1 = is_iterable(None)
    var_2 = is_iterable('abcdef')
    var_3 = is_iterable(123)
    var_4 = is_iterable([1, 2, 3])


# Generated at 2022-06-24 20:16:53.297978
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    i1 = ImmutableDict(
        [
            (
                'a', 1
            ),
            (
                'b', 2
            )
        ]
    )
    i2 = ImmutableDict(
        [
            (
                'a', 1
            ),
            (
                'b', 2
            )
        ]
    )
    i3 = ImmutableDict(
        [
            (
                'a', 1
            ),
            (
                'b', 3
            )
        ]
    )

    assert i1.__eq__(i2)
    assert not i1.__eq__(i3)
    assert not i1.__eq__(dict(i1))

if __name__ == '__main__':
    test_case_0()
    test_ImmutableDict

# Generated at 2022-06-24 20:17:01.142923
# Unit test for function is_iterable
def test_is_iterable():
    """Check that is_iterable works as expected"""
    assert is_iterable([], include_strings=False)
    assert is_iterable((), include_strings=False)
    assert is_iterable(dict(), include_strings=False)
    assert not is_iterable(dict(), include_strings=True)
    assert not is_iterable(None, include_strings=False)
    assert not is_iterable(None, include_strings=True)
    assert not is_iterable(1, include_strings=False)
    assert not is_iterable(1, include_strings=True)
    assert is_iterable('', include_strings=False)
    assert is_iterable('', include_strings=True)
    assert is_iterable(u'', include_strings=False)

# Generated at 2022-06-24 20:17:04.771910
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    arg_1 = None
    var_0 = ImmutableDict(arg_1)
    arg_1 = var_0
    var_1 = var_0 == arg_1


# Generated at 2022-06-24 20:17:08.421209
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(1) == False
    assert is_iterable('test') == True
    assert is_iterable([1,2,3]) == True
    assert is_iterable(('test1','test2')) == True



# Generated at 2022-06-24 20:17:10.359517
# Unit test for function is_iterable
def test_is_iterable():
    bytes_0 = None
    var_0 = is_iterable(bytes_0)


# Generated at 2022-06-24 20:17:18.077060
# Unit test for function is_iterable
def test_is_iterable():
    assert isinstance(list(), bool)
    assert isinstance(dict(), bool)
    assert isinstance(set(), bool)
    assert isinstance(None, bool)
    assert isinstance(False, bool)
    assert isinstance(True, bool)
    assert isinstance(int(), bool)
    assert isinstance(float(), bool)
    assert isinstance(str(), bool)
    assert isinstance(tuple(), bool)
    assert isinstance(is_iterable, bool)
    assert isinstance(count, bool)


# Generated at 2022-06-24 20:17:25.049768
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    bytes_0 = ImmutableDict()
    var_0 = ImmutableDict()
    var_0 = var_0.__eq__(bytes_0)


# Generated at 2022-06-24 20:17:31.286734
# Unit test for function is_iterable
def test_is_iterable():
    if not is_iterable(None):
        raise Exception('Failed assert 1')
    try:
        is_iterable(None, True)
    except Exception as e:
        raise Exception('Failed assert 2')
    try:
        is_iterable(None, False)
    except Exception as e:
        raise Exception('Failed assert 3')



# Generated at 2022-06-24 20:17:40.030347
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    ImmutableDict_instance_0 = ImmutableDict({'foo': 'bar'})
    ImmutableDict_instance_1 = ImmutableDict({'foo': 'bar'})
    var_0 = ImmutableDict_instance_0.__eq__(ImmutableDict_instance_1)
    bytes_0 = False
    var_1 = ImmutableDict_instance_0.__eq__(bytes_0)
    var_2 = ImmutableDict_instance_0.__eq__(ImmutableDict_instance_0)


# Generated at 2022-06-24 20:17:42.716179
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(str, include_strings = True) == True
    assert is_iterable(ImmutableDict()) == True
    assert is_iterable(None) == False


# Generated at 2022-06-24 20:17:49.597043
# Unit test for function is_iterable
def test_is_iterable():
    # Try with string
    try:
        string_0 = 'Hello'
        bool_0 = is_iterable(string_0)
        assert bool_0 is True
    except Exception as err:
        raise AssertionError(err)

    # Try with list
    try:
        list_0 = ['hello', 'world']
        bool_0 = is_iterable(list_0)
        assert bool_0 is True
    except Exception as err:
        raise AssertionError(err)

    # Try with set
    try:
        set_0 = set(['hello', 'world'])
        bool_0 = is_iterable(set_0)
        assert bool_0 is True
    except Exception as err:
        raise AssertionError(err)

    # Try with dict

# Generated at 2022-06-24 20:17:53.423039
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    obj_0 = ImmutableDict()
    obj_0.__eq__(None)
    

# Generated at 2022-06-24 20:17:59.432563
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test case variables
    bytes_0 = None
    str_0 = None
    str_1 = None
    str_2 = None
    bool_0 = None
    str_3 = None
    str_4 = None
    str_5 = None
    str_6 = None
    # Call the method
    var_0 = ImmutableDict.__eq__(bytes_0, str_0)
    var_1 = ImmutableDict.__eq__(str_1, str_2)
    var_2 = ImmutableDict.__eq__(bool_0, str_3)
    var_3 = ImmutableDict.__eq__(str_4, str_5)
    var_4 = ImmutableDict.__eq__(str_6, bytes_0)


# Generated at 2022-06-24 20:18:01.656325
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    try:
        # Unit test for method __eq__ of class ImmutableDict
        count('h')
    except Exception as e:
        raise Exception("Failed to check __eq__ of class ImmutableDict") from e

# Generated at 2022-06-24 20:18:04.153573
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    ab = ImmutableDict(a=1, b=2)
    ba = ImmutableDict(b=2, a=1)
    abc = ImmutableDict(a=1, b=2, c=3)
    ab_dict = dict(a=1, b=2)

    assert ab == ba
    assert ab == ab_dict
    assert not ab == abc
    assert not ab == dict(a=1, b=2, c=3)


# Generated at 2022-06-24 20:18:07.500943
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable((1, 2, 3)) == True
    assert is_iterable(set((1, 2, 3))) == True
    assert is_iterable({'a': 1, 'b': 2}) == True
    assert is_iterable('abcd') == True


# Generated at 2022-06-24 20:18:16.802005
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_1 = ImmutableDict()
    boolean_0 = ImmutableDict.__eq__(dict_0, dict_1)
    assert boolean_0



# Generated at 2022-06-24 20:18:22.804082
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    str_0 = 'ImmutableDict({0})'
    bytes_0 = 'Dict({0})'
    class_0 = ImmutableDict
    assert str_0.format(bytes_0.format(repr(class_0._store))) == class_0.__repr__()


# Generated at 2022-06-24 20:18:31.150062
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    cases = [
        # TODO: Define the expected kwargs to the __init__ method above
        # in the ImmutableDict class itself and pass those as **kwargs here
        {'kwargs': {}, 'expected': True},
        {'kwargs': {}, 'expected': False},
    ]
    for case in cases:
        # TODO: Add the kwargs to the call to the ImmutableDict class __init__ method
        subject = ImmutableDict()
        other = ImmutableDict()
        expected = case['expected']
        actual = subject == other
        assert actual == expected, 'Expected {0}, but got {1}'.format(expected, actual)


# Generated at 2022-06-24 20:18:36.867850
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Init ImmutableDict instance
    # Init ImmutableDict instance
    # Init ImmutableDict instance
    # Init ImmutableDict instance
    # Init ImmutableDict instance
    # Init ImmutableDict instance
    # Init ImmutableDict instance
    # Init ImmutableDict instance
    # Init ImmutableDict instance
    # Init ImmutableDict instance
    var_0 = ImmutableDict({"key_0": "val_0", "key_1": "val_1", "key_2": "val_2"})
    # Init ImmutableDict instance
    var_1 = ImmutableDict({"key_0": "val_0", "key_1": "val_1", "key_2": "val_2"})
    # Init ImmutableDict instance
    var_2 = Immutable

# Generated at 2022-06-24 20:18:40.277896
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict(None, None, None)
    dict_1 = ImmutableDict(None, None, None)
    var_0 = dict_0 == dict_1


# Generated at 2022-06-24 20:18:49.710961
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(str()) == True, "str should be iterable."
    assert is_iterable(set()) == True, "set should be iterable."
    assert is_iterable(dict()) == True, "dict should be iterable."
    assert is_iterable(tuple()) == True, "tuple should be iterable."
    assert is_iterable(list()) == True, "list should be iterable."
    assert is_iterable(int()) == False, "int should not be iterable."
    assert is_iterable(str(), include_strings=True) == True, "str should be iterable."
    assert is_iterable(set(), include_strings=True) == True, "set should be iterable."

# Generated at 2022-06-24 20:18:56.575590
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    obj = ImmutableDict({1:1,2:2})
    obj2 = {1:1}
    obj3 = {1:1,2:2}
    obj4 = ImmutableDict({1:2,2:2})
    assert not obj.__eq__(obj2)
    assert obj.__eq__(obj3)
    assert not obj.__eq__(obj4)

# Generated at 2022-06-24 20:19:02.110314
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    bytes_0 = ImmutableDict({})
    bytes_2 = ImmutableDict({'ansible': 2, 'modules': 7, 'are': 2, 'always': 1, 'awesome': 1})
    bytes_1 = ImmutableDict({'awesome': 1, 'modules': 7, 'are': 2, 'always': 1, 'ansible': 2})
    var_0 = bytes_2 == bytes_1
    var_1 = bytes_1.__eq__(bytes_0)
    var_2 = bytes_2 != bytes_1


# Generated at 2022-06-24 20:19:07.928418
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Input 0:
    bytes_0 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict_0 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    bool_0 = bytes_0.__eq__(dict_0)
    print(bool_0)
    # Output 0:
    # True


# Generated at 2022-06-24 20:19:13.470749
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(())
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable('me')
    assert not is_iterable(None)
    assert not is_iterable(1)


# Generated at 2022-06-24 20:19:29.427136
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable([]) == True)
    assert(is_iterable([1, 2, 3]) == True)
    assert(is_iterable(b'abcd') == True)
    assert(is_iterable(None) == False)
    assert(is_iterable(42) == False)
    assert(is_iterable('Fourty two') == False)

# Generated at 2022-06-24 20:19:32.223330
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable([1, 2, 3])
    assert is_iterable(('a', 'b', 'c'))
    assert is_iterable({'a': 1, 'b': 2, 'c': 3})


# Generated at 2022-06-24 20:19:41.097568
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d = ImmutableDict(a=1)
    assert d == d  # self-test
    assert d == immutable_dict_copy(d)  # same content
    assert hash(d) == hash(immutable_dict_copy(d))
    assert d == {'a': 1}  # same keys
    assert hash(d) == hash({'a': 1})
    assert not (d == {'a': 2})  # different values
    assert d != {'a': 2}  # different values
    assert not (d == {'a': 1, 'b': 1})  # different keys
    assert d != {'a': 1, 'b': 1}  # different keys


# Generated at 2022-06-24 20:19:48.234131
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    from ansible.module_utils.common._collections_compat import Mapping

    ImmutableDict = ImmutableDict()
    Mapping = Mapping()

    arg1 = ImmutableDict.pop('name')
    arg2 = ImmutableDict.get('')

    # Call method on class
    result = ImmutableDict.__eq__(arg1, arg2)
    assert isinstance(ImmutableDict, ImmutableDict)
    assert result is False



# Generated at 2022-06-24 20:19:51.569216
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(list()) is True
    assert is_iterable(tuple()) is True
    assert is_iterable(dict()) is True
    assert is_iterable(set()) is True
    assert is_iterable(binary_type()) is True
    assert is_iterable(text_type()) is True
    assert is_iterable(binary_type(), True) is True
    assert is_iterable(text_type(), True) is True
    assert is_iterable(42) is False



# Generated at 2022-06-24 20:19:54.222406
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})


# Generated at 2022-06-24 20:20:04.367566
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('a string') == True, "Failed test for is_iterable of type: String"
    assert is_iterable(bytes('a string')) == True, "Failed test for is_iterable of type: bytes"
    assert is_iterable(123) == False, "Failed test for is_iterable of type: int"
    assert is_iterable(bool(True)) == False, "Failed test for is_iterable of type: bool"
    assert is_iterable(dict(a='a', b='b', c='c')) == True, "Failed test for is_iterable of type: dict"
    assert is_iterable(set(a='a', b='b', c='c')) == True, "Failed test for is_iterable of type: set"
    assert is_

# Generated at 2022-06-24 20:20:13.205011
# Unit test for function is_iterable
def test_is_iterable():
    bytes_0 = None
    var_0 = is_iterable(bytes_0)
    bytes_1 = 0
    var_1 = is_iterable(bytes_1)
    bytes_2 = 0.0
    var_2 = is_iterable(bytes_2)
    bytes_3 = ""
    var_3 = is_iterable(bytes_3)
    bytes_4 = []
    var_4 = is_iterable(bytes_4)
    bytes_5 = {}
    var_5 = is_iterable(bytes_5)
    bytes_6 = tuple()
    var_6 = is_iterable(bytes_6)
    bytes_7 = set()
    var_7 = is_iterable(bytes_7)
    bytes_8 = frozenset()
    var_8 = is_iterable

# Generated at 2022-06-24 20:20:21.484493
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Testing with non-ImmutableDict object
    # Should return False
    x = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    y = [{'a': 1, 'b': 2, 'c': 3}]
    assert x == y

    # Testing with ImmutableDict object
    # Should return True
    x = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    y = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert x == y



# Generated at 2022-06-24 20:20:28.324030
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_1 = ImmutableDict()
    dict_2 = ImmutableDict()
    dict_3 = ImmutableDict()

    # Test when both dicts are empty
    assert dict_0 == dict_1
    assert not (dict_0 != dict_1)

    dict_0 = ImmutableDict(a='1', b='2')
    # Test when both dicts are not empty and equal
    assert dict_0 == dict_1
    assert not (dict_0 != dict_1)

    dict_1 = ImmutableDict(b='2', a='1')
    # Test when both dicts are not empty, have the same keys and values but different in ordering
    assert dict_0 == dict_1
    assert not (dict_0 != dict_1)

    dict_

# Generated at 2022-06-24 20:21:02.526500
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Check that ImmutableDict properly implements the equality operator."""

    # Test cases with non-equal dictionaries
    a_0 = ImmutableDict({'a': 'b'})
    a_1 = ImmutableDict({'a': 'c'})
    a_2 = ImmutableDict({'b': 'b'})
    a_3 = ImmutableDict({'a': 'b', 'b': 'a'})
    b_1 = ImmutableDict({'a': 'c'})
    b_2 = ImmutableDict({'b': 'b'})
    b_3 = ImmutableDict({'a': 'b', 'b': 'a'})
    assert not a_0 == a_1
    assert not a_0 == a_2
    assert not a_0 == a_3
   

# Generated at 2022-06-24 20:21:03.901810
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    inst_0 = ImmutableDict()
    inst_1 = ImmutableDict()
    inst_0.__eq__(inst_1)



# Generated at 2022-06-24 20:21:11.917926
# Unit test for function is_iterable
def test_is_iterable():
    bytes_0 = None
    assert is_iterable(bytes_0) is False, 'is_iterable(bytes_0) is %s' % (is_iterable(bytes_0))
    bytes_0 = 'A:A:A:A:A:A:A:A:A:A:A:A:A:A:A:A'
    assert is_iterable(bytes_0) is False, 'is_iterable(bytes_0) is %s' % (is_iterable(bytes_0))
    bytes_0 = b'A:A:A:A:A:A:A:A:A:A:A:A:A:A:A:A'

# Generated at 2022-06-24 20:21:18.268933
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict()
    d2 = ImmutableDict()
    assert(d1 == d2)
    d3 = ImmutableDict({'a':1})
    assert(d1 == d2)
    assert(d1 != d3)
    assert(d2 != d3)
    d4 = ImmutableDict({'a':1})
    assert(d3 == d4)


# Generated at 2022-06-24 20:21:26.983386
# Unit test for function is_iterable
def test_is_iterable():
    dict_0 = dict()
    dict_0['param_key'] = 'param_value'
    dict_1 = dict()
    dict_1['param_key'] = 'param_value'
    dict_1['another_key'] = 'another_value'
    dict_2 = dict()
    dict_2['param_key'] = 'param_value'
    dict_2['another_key'] = 'another_value'
    dict_2['yet_another_key'] = 'yet_another_value'
    assert 'param_key' in dict_0
    assert dict_0['param_key'] == 'param_value'
    assert 'param_key' in dict_1
    assert dict_1['param_key'] == 'param_value'
    assert 'another_key' in dict_1
    assert dict_1

# Generated at 2022-06-24 20:21:29.858164
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Hashable, Mapping
    kwargs = dict(zip(['one', 'two', 'three'], [1, 2, 3]))
    a = ImmutableDict(kwargs)
    b = ImmutableDict(kwargs)
    equal = a == b
    return equal


# Generated at 2022-06-24 20:21:41.079301
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_2 = ImmutableDict((('b', 'q'), ('a', 'w'), ('d', 'e'), ('c', 'r')))
    var_3 = ImmutableDict((('c', 'r'), ('d', 'e'), ('b', 'q'), ('a', 'w')))
    var_4 = ImmutableDict((('a', 'w'), ('b', 'q'), ('c', 'r'), ('d', 'e')))
    var_5 = ImmutableDict((('d', 'e'), ('b', 'q'), ('c', 'r'), ('a', 'w')))
    var_6 = ImmutableDict((('b', 'q'), ('a', 'w'), ('d', 'e'), ('c', 'r')))

# Generated at 2022-06-24 20:21:42.626934
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    bytes_0 = None
    var_0 = ImmutableDict()
    var_1 = ImmutableDict()
    var_1.__eq__(var_0)


# Generated at 2022-06-24 20:21:49.880396
# Unit test for function is_iterable
def test_is_iterable():
    import types
    import collections

    # Test case 0
    bytes_0 = "Hello World"
    var_0 = is_iterable(bytes_0)

    assert var_0 is True

    # Test case 1
    int_1 = 1
    var_0 = is_iterable(int_1)

    assert var_0 is False

    # Test case 2
    bytes_1 = b"Hello World"
    var_0 = is_iterable(bytes_1)

    assert var_0 is True

    # Test case 3
    list_0 = list()
    var_0 = is_iterable(list_0)

    assert var_0 is True

    # Test case 4
    iterator_0 = iter("Hello World")
    var_0 = is_iterable(iterator_0)

    assert var_0 is True

# Generated at 2022-06-24 20:21:54.018042
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Ensure that ImmutableDict.__eq__ method works as expected
    """
    dict_a = ImmutableDict(A=1)
    dict_b = ImmutableDict(A=1)
    dict_c = ImmutableDict(B=2)

    assert dict_a == dict_b
    assert dict_a != dict_c


# Generated at 2022-06-24 20:22:47.641950
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict()
    var_1 = None
    var_2 = var_0.__eq__(var_1)


# Generated at 2022-06-24 20:22:57.993863
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_1 = ImmutableDict({'x': 1, 'y': 2})
    var_2 = ImmutableDict(x=1, y=2)
    var_3 = {'x': 1, 'y': 2}
    var_1.__eq__(var_2)
    assert var_1 == var_2, "ImmutableDict.__eq__() failed: expected <ImmutableDict({'x': 1, 'y': 2})> but got <ImmutableDict({'x': 1, 'y': 2})>"
    var_1.__eq__(var_3)

# Generated at 2022-06-24 20:23:00.337541
# Unit test for function is_iterable
def test_is_iterable():
    # just one example to verify the logic
    # > is_iterable('abc')
    # False
    assert is_iterable('abc') == False


# Generated at 2022-06-24 20:23:09.786865
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    my_dict = ImmutableDict(a=1)
    assert my_dict == ImmutableDict(a=1)
    assert my_dict != 1
    assert my_dict != ImmutableDict(a=2)
    assert my_dict != ImmutableDict(b=1)
    assert my_dict != ImmutableDict(a=1, b=2)
    assert my_dict == {'a': 1}
    value = "__ENCRYPTED__"
    setattr(value, '__ENCRYPTED__', True)
    assert my_dict == value
    value = "__ENCRYPTED__"
    setattr(value, '__ENCRYPTED__', False)
    assert my_dict != value
    value = ImmutableDict(a=1, b=2)


# Generated at 2022-06-24 20:23:17.903471
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable("is_iterable") is True
    assert is_iterable("is_iterable", True) is True
    assert is_iterable("is_iterable", False) is False
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable([1, 2, 3], True) is True
    assert is_iterable([1, 2, 3], False) is True
    assert is_iterable({"a": 1, "b": 2, "c": 3}) is True
    assert is_iterable({"a": 1, "b": 2, "c": 3}, True) is True
    assert is_iterable({"a": 1, "b": 2, "c": 3}, False) is True
    assert is_iterable(1.234) is False
    assert is_iter

# Generated at 2022-06-24 20:23:21.993342
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    other_0 = ImmutableDict({'a': 1, 'b': 2})
    x = ImmutableDict({'a': 1, 'b': 2})
    var_1 = x.__eq__(other_0)


# Generated at 2022-06-24 20:23:30.055420
# Unit test for function is_iterable
def test_is_iterable():
    bytes_0 = 'test case 0'
    var_0 = is_iterable(bytes_0)
    assert var_0 == True
    var_1 = is_iterable(var_0)
    assert var_1 == True
    var_2 = is_iterable(b'test case 1')
    assert var_2 == True
    var_3 = is_iterable([])
    assert var_3 == True
    var_4 = is_iterable({})
    assert var_4 == True
    var_5 = is_iterable(1)
    assert var_5 == False
    var_6 = is_iterable(None)
    assert var_6 == False
    var_7 = is_iterable('test case 6')
    assert var_7 == True

# Generated at 2022-06-24 20:23:41.117606
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dummy_ImmutableDict_0 = ImmutableDict({'key_0': 'value_0', 'key_1': 'value_1', 'key_2': 'value_2', 'key_3': 'value_3', 'key_4': 'value_4'})
    dummy_ImmutableDict_1 = ImmutableDict({'key_0': 'value_0', 'key_1': 'value_1', 'key_2': 'value_2', 'key_3': 'value_3', 'key_4': 'value_4'})

# Generated at 2022-06-24 20:23:43.719751
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    i_dict_0 = ImmutableDict({'test': 'ImmutableDict __eq__'})
    var_0 = i_dict_0 == i_dict_0
    var_1 = i_dict_0 == i_dict_0


# Generated at 2022-06-24 20:23:48.158710
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Create an instance of ImmutableDict
    var_1 = ImmutableDict({})

    # Call method __eq__ with argument 
    # var_1 -> instance of ImmutableDict
    # var_2 -> instance of ImmutableDict
    var_1.__eq__(var_2)
