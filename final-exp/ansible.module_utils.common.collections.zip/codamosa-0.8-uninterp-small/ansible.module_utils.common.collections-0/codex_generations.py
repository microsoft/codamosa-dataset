

# Generated at 2022-06-24 20:14:48.802732
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([0, 1, 2])
    assert is_iterable(set((0, 1, 2)))
    assert not is_iterable('string')
    assert not is_iterable(1)

    assert is_iterable('string', include_strings=True)
    assert is_iterable(1, include_strings=True)



# Generated at 2022-06-24 20:14:53.861519
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_1 = dict()
    dict_1 = ImmutableDict(dict_1)

    dict_2 = dict()
    dict_2 = ImmutableDict(dict_2)

    dict_3 = dict()

    dict_4 = dict()
    dict_4['a'] = 1
    dict_4 = ImmutableDict(dict_4)

    dict_5 = dict()
    dict_5['a'] = 1

    dict_6 = dict()
    dict_6['a'] = 1
    dict_6 = ImmutableDict(dict_6)

    assert dict_1 == dict_2
    assert dict_1.__eq__(dict_3) == dict_3.__eq__(dict_1)
    assert dict_4 == dict_6

# Generated at 2022-06-24 20:15:05.854145
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0_copy = immutable_dict_0.copy()
    immutable_dict_1 = immutable_dict_0.union({'key 1': 'value 1'})
    immutable_dict_1_copy = immutable_dict_1.copy()
    immutable_dict_2 = ImmutableDict({'key 2': 'value 2'})
    immutable_dict_2_copy = immutable_dict_2.copy()
    var_0 = immutable_dict_0 == immutable_dict_0_copy
    var_1 = immutable_dict_0 == immutable_dict_1
    var_2 = immutable_dict_0 == immutable_dict_2
    var_3 = immutable_dict_1 == immutable_dict_1_copy
    var_4 = immutable_dict_1 == immutable_

# Generated at 2022-06-24 20:15:10.652365
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = ImmutableDict()
    var_1 = immutable_dict_0.__eq__(var_0)
    immutable_dict_1 = ImmutableDict({'key_0': 'value_0'})
    var_2 = ImmutableDict({'key_0': 'value_0'})
    var_3 = immutable_dict_1.__eq__(var_2)


# Generated at 2022-06-24 20:15:14.013978
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    try:
        immutable_dict_0.__eq__("")
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-24 20:15:15.669003
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    bool_var_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:15:20.381956
# Unit test for function is_iterable
def test_is_iterable():
    iterable_0 = (1, 2, 3)
    iterable_1 = [1, 2, 3]
    iterable_2 = []
    iterable_3 = (1, 2, 3)
    iterable_4 = []
    iterable_5 = ()
    iterable_6 = {}
    iterable_7 = {}
    iterable_8 = {}
    iterable_9 = {}
    test_value_0 = is_iterable(iterable_0)
    test_value_1 = is_iterable(iterable_1, True)
    test_value_2 = is_iterable(iterable_2, True)
    test_value_3 = is_iterable(iterable_3, False)
    test_value_4 = is_iterable(iterable_4, False)
    test_

# Generated at 2022-06-24 20:15:23.498124
# Unit test for function is_iterable
def test_is_iterable():
    # This is a simple example
    var_0 = is_iterable(var_0)
    # Another example
    var_1 = is_iterable(var_1)
    # This is a simple example
    var_2 = is_iterable(var_2)
    # This is a simple example
    var_3 = is_iterable(var_3)


# Generated at 2022-06-24 20:15:25.627102
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(ImmutableDict())


# Generated at 2022-06-24 20:15:30.785973
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    # object_0 is of type object_type_0
    object_0 = {"foo": "bar"}
    # object_0 is of type object_type_1
    object_1 = {"foo": "baz"}
    var_0 = immutable_dict_0.__eq__(object_0)


# Generated at 2022-06-24 20:15:39.752422
# Unit test for function is_iterable
def test_is_iterable():
    a = is_iterable(3)
    assert(not a)
    b = is_iterable([1, 2, 3])
    assert(b)
    c = is_iterable('a string')
    assert(c)
    d = is_iterable(('a tuple', 2))
    assert(d)
    e = is_iterable(set([1, 2, 3]))
    assert(e)
    f = is_iterable(u'unicode string')
    assert(f)

# Generated at 2022-06-24 20:15:42.677920
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)
    var_1 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:15:54.004642
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    print ('immutable_dict_0='+str(immutable_dict_0))
    print ('immutable_dict_0.__class__='+str(immutable_dict_0.__class__))
    # __eq__ is not implemented for class ImmutableDict
    # print ('immutable_dict_0.__eq__='+str(immutable_dict_0.__eq__))
    immutable_dict_1 = immutable_dict_0.union({"init0":2, "init1":2})
    immutable_dict_2 = immutable_dict_1.union({"init3":"init3"})
    immutable_dict_3 = immutable_dict_2.union({"init3":"init3"})
    immutable_dict_4 = immutable_dict_2.difference

# Generated at 2022-06-24 20:15:57.693874
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:15:59.387281
# Unit test for function is_iterable
def test_is_iterable():
    seq_0 = is_iterable((1, 2, 3))
    assert seq_0 == True


# Generated at 2022-06-24 20:16:01.213468
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict(var_0)
    var_2 = immutable_dict_0.__eq__(var_1)


# Generated at 2022-06-24 20:16:08.742471
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    first_immutable_dict = ImmutableDict()
    second_immutable_dict = ImmutableDict()
    assert first_immutable_dict.__eq__(second_immutable_dict) == True
    assert second_immutable_dict.__eq__(first_immutable_dict) == True

    third_immutable_dict = ImmutableDict({1: 2})
    fourth_immutable_dict = ImmutableDict({1: 2})
    assert third_immutable_dict.__eq__(fourth_immutable_dict) == True
    assert fourth_immutable_dict.__eq__(third_immutable_dict) == True

    fifth_immutable_dict = ImmutableDict({1: 2, 2: 3})
    sixth_immutable_dict = ImmutableDict({1: 2, 2: 3})

# Generated at 2022-06-24 20:16:14.022206
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable((1, 2, 3)) == True
    assert is_iterable(range(0, 3)) == True
    assert is_iterable('abc') == True
    assert is_iterable('abc'.encode('utf-8')) == True
    assert is_iterable({'a': 'b'}) == True
    assert is_iterable('a') == False
    assert is_iterable(1) == False


# Generated at 2022-06-24 20:16:16.192349
# Unit test for function is_iterable
def test_is_iterable():
    immutable_dict_0 = ImmutableDict()
    var_0 = is_iterable(immutable_dict_0, False)


# Generated at 2022-06-24 20:16:22.879947
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    equal_dicts = ImmutableDict(dict(a='b', c='d'))
    before = equal_dicts.__eq__(dict(a='b', c='d'))
    after = True if (equal_dicts == dict(a='b', c='d')) else False
    assert before == after
    assert after == True

# Generated at 2022-06-24 20:16:36.625700
# Unit test for function is_iterable
def test_is_iterable():
    from ansible.module_utils.common._collections_compat import Generator

# Generated at 2022-06-24 20:16:39.056662
# Unit test for function is_iterable
def test_is_iterable():
    foo_seq = ['foo', 'bar', 'baz']
    foo_not_seq = 'foo'

    assert is_iterable(foo_seq)

    assert not is_iterable(foo_not_seq, include_strings=False)
    assert is_iterable(foo_not_seq, include_strings=True)


# Generated at 2022-06-24 20:16:44.107552
# Unit test for function is_iterable
def test_is_iterable():
    list_0 = ['redis', 'http', 'ssh', 'redis', 'http', 'redis', 'ssh', 'ssh', 'ssh', 'redis']
    var_0 = count(list_0)
    var_1 = {'redis': 4, 'http': 2, 'ssh': 4}
    if var_0 != var_1:
        raise Exception("Test 0: Unexpected result")

# Generated at 2022-06-24 20:16:48.227155
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    dict_0 = dict()
    var_0 = immutable_dict_0.__eq__(dict_0)


# Generated at 2022-06-24 20:16:57.082954
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0 = ImmutableDict(((k, v) for (k, v) in (('abc', 'abc'),)))
    dictionary_0 = {}
    immutable_dict_1 = ImmutableDict(((k, v) for (k, v) in (('abc', 'abc'),)))
    immutable_dict_0.__eq__(immutable_dict_1)
    immutable_dict_0.__eq__(dictionary_0)
    immutable_dict_0.__eq__(('abc', 'abc'))

# Generated at 2022-06-24 20:17:08.723817
# Unit test for function is_iterable
def test_is_iterable():
    # Tests that the function returns 'True'
    # when it receives a string as input
    assert is_iterable('') is True
    # Tests that the function returns 'True'
    # when it receives a dictionary as input
    assert is_iterable({}) is True
    # Tests that the function returns 'True'
    # when it receives a tuple as input
    assert is_iterable(()) is True
    # Tests that the function returns 'True'
    # when it receives a list as input
    assert is_iterable([]) is True
    # Tests that the function returns 'True'
    # when it receives a set as input
    assert is_iterable(set()) is True
    # Tests that the function returns 'False'
    # when it receives an integer as input
    assert is_iterable(5) is False
    # Tests that

# Generated at 2022-06-24 20:17:19.525287
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    '''Unit test for method ImmutableDict.__eq__'''
    immutable_dict_0 = ImmutableDict({})
    immutable_dict_1 = ImmutableDict({'a': 1})
    immutable_dict_2 = ImmutableDict({'b': 2})
    immutable_dict_3 = ImmutableDict()
    immutable_dict_4 = ImmutableDict({'b': 2})
    immutable_dict_5 = ImmutableDict({'a': 1})

    if immutable_dict_0 == immutable_dict_3:
        pass

    if immutable_dict_1 == immutable_dict_5:
        pass

    if immutable_dict_2 == immutable_dict_4:
        pass

    if immutable_dict_1 != immutable_dict_2:
        pass


# Generated at 2022-06-24 20:17:28.787713
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('foo') == True
    assert is_iterable('foo', True) == True
    assert is_iterable('foo', False) == True
    assert is_iterable(1) == False
    assert is_iterable(['foo', 'bar']) == True
    assert is_iterable(('foo', 'bar')) == True
    assert is_iterable({'foo': 'bar'}) == True
    assert is_iterable(dict) == True
    assert is_iterable(int) == True
    assert is_iterable(1.0) == False
    assert is_iterable(test_is_iterable) == True
    assert is_iterable(['bar', 'baz']) == True
    assert is_iterable('foo', True) == True

# Generated at 2022-06-24 20:17:37.480493
# Unit test for function is_iterable
def test_is_iterable():
    from ansible.module_utils._text import to_text
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1: 'a', 2: 'b', 3: 'c'})
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(to_text(b'abc', encoding='utf-8'))
    assert is_iterable(range(0, 10))
    assert not is_iterable(1)


# Generated at 2022-06-24 20:17:43.193720
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable('test') is True)
    assert(is_iterable(['test', 'test2']) is True)
    assert(is_iterable(('test', 'test2')) is True)
    assert(is_iterable({'test_key': 'test_value'}) is True)
    assert(is_iterable(10) is False)
    assert(is_iterable(False) is False)
    assert(is_iterable(['test', 10]) is False)


# Generated at 2022-06-24 20:17:48.852423
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    assert (immutable_dict_0.__eq__(immutable_dict_1))


# Generated at 2022-06-24 20:17:50.278165
# Unit test for function is_iterable
def test_is_iterable():
    output = is_iterable([])
    assert (output is True)


# Generated at 2022-06-24 20:17:55.534693
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    chr_0 = 'Z'
    immutable_dict_0[chr_0] = 'y4'
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)
    return var_0


# Generated at 2022-06-24 20:17:56.235626
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_case_0()



# Generated at 2022-06-24 20:18:00.090429
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    another_immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(another_immutable_dict_0)



# Generated at 2022-06-24 20:18:01.420489
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)
    assert var_0 == False


# Generated at 2022-06-24 20:18:05.195214
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0 = ImmutableDict({'a': 1, 'b': 2})
    var_0 = immutable_dict_0.__eq__({'b': 2, 'a': 1})
    var_1 = immutable_dict_0.__eq__({'b': 1, 'a': 2})
    print(var_0,var_1)


# Generated at 2022-06-24 20:18:08.919170
# Unit test for function is_iterable
def test_is_iterable():
    seq_0 = 'asdfasdf'
    var_0 = is_iterable(seq_0)
    assert var_0 is False


# Generated at 2022-06-24 20:18:13.276873
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'key': 'value'})
    immutable_dict_1 = ImmutableDict({'key': 'value'})
    # The next line should not raise an exception as the dictionaries should be equal
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)



# Generated at 2022-06-24 20:18:16.548999
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:18:24.079899
# Unit test for function is_iterable
def test_is_iterable():
    seq = "abcd"
    assert is_iterable(seq) == True, 'is_iterable is not behaving as expected'


# Generated at 2022-06-24 20:18:31.069359
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    try:
        a = ImmutableDict({"a": 1})
        b = ImmutableDict({"a": 1})
        c = {"a": 1}
        d = {"a": 2}
        # __eq__ between two ImmutableDicts compared should be True
        assert (a == b)
        # __eq__ between an ImmutableDict and something else should be False
        assert (a != c)
        # __eq__ between two ImmutableDicts that have different keys should be False
        assert (a != d)
    finally:
        pass


# Generated at 2022-06-24 20:18:32.880812
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(set()) == True
    assert is_iterable({}) == True
    assert is_iterable(list()) == True
    assert is_iterable(tuple()) == True



# Generated at 2022-06-24 20:18:45.302058
# Unit test for function is_iterable
def test_is_iterable():
    ansible_module_utils_basic_common_is_iterable = is_iterable('Test')
    assert ansible_module_utils_basic_common_is_iterable == True
    ansible_module_utils_basic_common_is_iterable_1 = is_iterable(0)
    assert ansible_module_utils_basic_common_is_iterable_1 == False
    ansible_module_utils_basic_common_is_iterable_2 = is_iterable(True)
    assert ansible_module_utils_basic_common_is_iterable_2 == False
    ansible_module_utils_basic_common_is_iterable_3 = is_iterable(())
    assert ansible_module_utils_basic_common_is_iterable_3 == True
    ansible_module_utils_

# Generated at 2022-06-24 20:18:49.744443
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = ['a', 'b']
    bool_0 = is_iterable(str_0)
    assert bool_0
    str_1 = 'a'
    bool_0 = is_iterable(str_1, True)
    assert bool_0
    str_2 = ''
    bool_0 = is_iterable(str_2, True)
    assert bool_0


# Generated at 2022-06-24 20:18:59.381772
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict(42, b=43, c=44, d=45)
    immutable_dict_1 = ImmutableDict(42, b=43, c=44, d=46)
    immutable_dict_2 = ImmutableDict(42, b=43, c=44, d=45)
    assert immutable_dict_0.__eq__(immutable_dict_1) == False
    assert immutable_dict_0.__eq__(immutable_dict_2) == True
    var_0 = immutable_dict_0.__eq__(immutable_dict_2)


# Generated at 2022-06-24 20:19:01.679839
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0_hash = immutable_dict_0.__hash__()
    variable_0 = equal_hash(immutable_dict_0_hash, immutable_dict_0)


# Generated at 2022-06-24 20:19:10.932895
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict({'a': 1})
    immutable_dict_2 = ImmutableDict({'a': 1, 'b': 2})
    var_0 = immutable_dict_1.__eq__(immutable_dict_2)
    var_1 = immutable_dict_0.__eq__(immutable_dict_2)
    var_2 = immutable_dict_1.__eq__(immutable_dict_0)
    immutable_dict_3 = ImmutableDict({'a': 1, 'b': True})
    var_3 = immutable_dict_2.__eq__(immutable_dict_3)



# Generated at 2022-06-24 20:19:16.439053
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(())
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable({})
    assert is_iterable({'a': 1, 'b': 2})
    assert not is_iterable('test')
    assert not is_iterable(1)
    assert not is_iterable(tuple())
    assert is_iterable(is_iterable)



# Generated at 2022-06-24 20:19:19.109522
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:19:31.552056
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = ImmutableDict().__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:19:35.321188
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert isinstance(test_case_0().__eq__(test_case_0()), bool)


# Generated at 2022-06-24 20:19:38.007760
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    assert immutable_dict_0.__eq__(None) is False, "Expected false, got true"


# Generated at 2022-06-24 20:19:40.852443
# Unit test for function is_iterable
def test_is_iterable():
    # No test for function is_iterable - It is a predicate with no return
    pass


# Generated at 2022-06-24 20:19:45.314013
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:19:54.374982
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable((1))
    assert is_iterable(xrange(10))
    assert is_iterable(set([]))
    assert is_iterable(set((1, 2, 3)))
    assert is_iterable({})
    assert is_iterable({'key': 'value'})
    assert is_iterable(ImmutableDict())
    assert is_iterable(ImmutableDict({'key': 'value'}))
    assert is_iterable(count([]))

    obj_0 = list()
    assert is_iterable(obj_0.__iter__())

    obj_1 = list()
    assert is_iterable(obj_1.__getitem__())

   

# Generated at 2022-06-24 20:20:04.500203
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    immutable_dict_0 = ImmutableDict()
    immutable_dict_0['hello'] = 'hi'
    immutable_dict_0['hi'] = 'hi'
    immutable_dict_1 = ImmutableDict(immutable_dict_0)
    immutable_dict_2 = ImmutableDict(immutable_dict_0)
    immutable_dict_3 = ImmutableDict()
    immutable_dict_3['hi'] = 'hi'
    immutable_dict_3['hello'] = 'hi'
    immutable_dict_4 = ImmutableDict()
    immutable_dict_4['hi'] = 'hi'
    immutable_dict_4['hello'] = 'hi'
    immutable_dict_5 = ImmutableDict()
    immutable_dict_5['hi'] = 'im'
    immutable_dict_5['hello']

# Generated at 2022-06-24 20:20:11.598691
# Unit test for function is_iterable
def test_is_iterable():
    list_0 = list()
    assert is_iterable(list_0)

    str_0 = str()
    assert is_iterable(str_0)

    dict_0 = dict()
    assert is_iterable(dict_0)

    set_0 = set()
    assert is_iterable(set_0)

    tuple_0 = tuple()
    assert is_iterable(tuple_0)

    # Returns False in Python 3.
    # func_0 = is_iterable(test_case_0)
    # assert func_0



# Generated at 2022-06-24 20:20:18.519511
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Try comparing an ImmutableDict against a subset of itself
    immutable_dict_0 = ImmutableDict({'Key_5': 'Value_5', 'Key_2': 'Value_2', 'Key_4': 'Value_4', 'Key_3': 'Value_3', 'Key_0': 'Value_0' })
    immutab

# Generated at 2022-06-24 20:20:21.546087
# Unit test for function is_iterable
def test_is_iterable():
    # Vars
    var_0 = 'abc'
    var_1 = ('abc', 'def')
    # Testing
    assert True == is_iterable(var_0)
    assert True == is_iterable(var_1)


# Generated at 2022-06-24 20:20:41.679929
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(u'x')
    assert is_iterable(b'x')
    assert is_iterable(u'x'.encode('utf-8'))
    assert is_iterable(list())
    assert is_iterable(dict())
    assert is_iterable(set())
    assert is_iterable(tuple())
    assert is_iterable(frozenset())
    assert is_iterable(object())
    assert not is_iterable(lambda: None)
    assert not is_iterable(None)
    assert not is_iterable(0)
    assert not is_iterable(0.0)
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert is_iterable(b'x', True)
    assert is_iter

# Generated at 2022-06-24 20:20:45.089156
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable('a') == True
    assert is_iterable({1:1, 2:2}) == True
    assert is_iterable(3) == False


# Generated at 2022-06-24 20:20:47.852293
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) == True
    assert is_iterable({}) == True
    assert is_iterable('') == True
    assert is_iterable('str') == True
    assert is_iterable(1) == False


# Generated at 2022-06-24 20:20:52.803118
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable((), include_strings=True)
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable('', include_strings=True)
    assert is_iterable(1)
    assert not is_iterable(1, include_strings=True)
    assert is_iterable(object)
    f = lambda: None
    assert is_iterable(f)



# Generated at 2022-06-24 20:20:55.337889
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.difference([])
    var_1 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:21:02.088687
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((i for i in range(10)))
    assert is_iterable({})
    assert is_iterable({1, 2, 3})
    assert is_iterable({'A': 'B', 'C': 'D'})
    assert is_iterable('foo')
    assert is_iterable(u'hello, world')
    assert is_iterable(b'some bytes')



# Generated at 2022-06-24 20:21:07.843205
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)

    immutable_dict_0 = ImmutableDict({'a': 'b'})
    immutable_dict_1 = ImmutableDict({'a': 'b', 'c': 'd'})
    var_1 = immutable_dict_0.__eq__(immutable_dict_1)

    immutable_dict_0 = ImmutableDict({'a': 'b'})
    immutable_dict_1 = ImmutableDict({'a': 'c'})
    var_2 = immutable_dict_0.__eq__(immutable_dict_1)

    immutable_dict_0 = ImmutableDict()

# Generated at 2022-06-24 20:21:11.354017
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(text_type())
    assert is_iterable(b'')
    assert is_iterable(u'')
    assert is_iterable(ImmutableDict())
    assert not is_iterable(5)
    assert not is_iterable(None)



# Generated at 2022-06-24 20:21:16.830096
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('qwertyu') == True
    assert is_iterable(12345) == True
    assert is_iterable(['qwertyu','werew']) == True
    assert is_iterable({'qwertyu','werew'}) == True


# Generated at 2022-06-24 20:21:24.736048
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = {'a':1, 'b':2}
    immutable_dict_0 = ImmutableDict(dict_0)
    var_0 = immutable_dict_0.__eq__(dict_0)
    assert var_0 == True

    dict_1 = {'a':2, 'b':2}
    immutable_dict_0 = ImmutableDict(dict_0)
    var_0 = immutable_dict_0.__eq__(dict_1)
    assert var_0 == False


# Generated at 2022-06-24 20:21:50.762371
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)
    immutable_dict_1 = ImmutableDict()
    var_1 = immutable_dict_1.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:21:57.575468
# Unit test for function is_iterable
def test_is_iterable():
    # Variables initialization
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    immutable_list_0 = [immutable_dict_0, immutable_dict_1]
    var_0 = is_iterable(immutable_list_0)



# Generated at 2022-06-24 20:22:03.495555
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    immutable_dict_1_dict = immutable_dict_1.__dict__
    immutable_dict_1_dict[None] = None
    immutable_dict_1.__dict__ = immutable_dict_1_dict
    immutable_dict_1_dict = immutable_dict_1.__dict__
    immutable_dict_1_dict[None] = None
    immutable_dict_1.__dict__ = immutable_dict_1_dict
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:22:06.135699
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:22:15.874747
# Unit test for function is_iterable
def test_is_iterable():
    print('in is_iterable')
    var_0 = is_iterable(('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'))
    print('ret var_0', var_0)
    assert var_0

    var_0 = is_iterable(('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'), 1)
    print('ret var_0', var_0)
    assert var_0


# Generated at 2022-06-24 20:22:18.875168
# Unit test for function is_iterable
def test_is_iterable():
    test_mapping = {'key_1': 'value_1', 'key_2': 'value_2'}
    assert is_iterable(test_mapping) is True



# Generated at 2022-06-24 20:22:29.119220
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_obj_0 = ImmutableDict(dict([]))
    var_0 = immutable_dict_obj_0.__eq__(('_0', '_1', '_2'))
    immutable_dict_obj_1 = ImmutableDict(dict([]))
    var_1 = immutable_dict_obj_1.__eq__(())
    immutable_dict_obj_2 = ImmutableDict(dict([]))
    var_2 = ImmutableDict({('_0', '_1', '_2'): {}})
    immutable_dict_obj_2.__eq__(var_2)
    immutable_dict_obj_3 = ImmutableDict(dict([]))

# Generated at 2022-06-24 20:22:35.988074
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(1) is False
    assert is_iterable(False) is False
    assert is_iterable(True) is False
    assert is_iterable('test') is True
    assert is_iterable(text_type('test')) is True
    assert is_iterable(binary_type('test')) is True
    assert is_iterable([]) is True
    assert is_iterable({}) is True
    assert is_iterable(()) is True
    assert is_iterable(set()) is True
    assert is_iterable((x * 2 for x in range(10))) is True
    assert is_iterable(is_iterable) is True
    assert is_iterable(is_iterable, include_strings=True) is True
    assert is_iterable(None) is False
    assert is_

# Generated at 2022-06-24 20:22:38.948768
# Unit test for function is_iterable
def test_is_iterable():
    args = (0, [1, 2, 3], (), {'a': 'b'}, {'a': 'b'}.items())
    for arg in args:
        assert is_iterable(arg)

    args = ('a', {}, 0)
    for arg in args:
        assert not is_iterable(arg)

    args = ('a', 'b', {}, 0)
    for arg in args:
        assert is_iterable(arg, include_strings=True)



# Generated at 2022-06-24 20:22:42.587306
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test __eq__ method on ImmutableDict (using mocked class) """
    immutable_dict_0 = ImmutableDict()
    bool_var = immutable_dict_0.__eq__(immutable_dict_0)
    assert bool_var == True


# Generated at 2022-06-24 20:23:47.707051
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    immutableDict_0 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    immutableDict_1 = ImmutableDict({'a': 1, 'c': 3, 'b': 2})
    assert immutableDict_0 == immutableDict_1, 'Expected condition not found for ImmutableDict.__eq__'
    assert not immutableDict_0 != immutableDict_1, 'Expected condition not found for ImmutableDict.__eq__'
    assert immutableDict_0.__eq__(immutableDict_1) is True, 'Expected condition not found for ImmutableDict.__eq__'



# Generated at 2022-06-24 20:23:50.790494
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    x = ImmutableDict()
    y = ImmutableDict()
    assert x == y
    assert y == x
    z = ImmutableDict()
    assert x == z
    assert z == x
    # This assertion fails, the else condition gets executed
    assert False is False


# Generated at 2022-06-24 20:23:56.230215
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = 'a'
    list_0 = ['a', 'b', 'c']
    dict_0 = {'a': 'a', 'b': 'b', 'c': 'c'}
    var_0 = is_iterable(str_0)
    var_1 = is_iterable(list_0)
    var_2 = is_iterable(dict_0)
    var_3 = is_iterable(str_0, include_strings=True)
    var_4 = is_iterable(list_0, include_strings=True)
    var_5 = is_iterable(dict_0, include_strings=True)

test_is_iterable()


# Generated at 2022-06-24 20:24:06.161935
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Try to compare ImmutableDict with Immutable Dict
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)

    # Try to compare ImmutableDict with Mapping
    immutable_dict_0 = ImmutableDict()
    mapping_0 = {}
    var_1 = immutable_dict_0.__eq__(mapping_0)

    # Try to compare ImmutableDict with String
    immutable_dict_0 = ImmutableDict()
    var_2 = immutable_dict_0.__eq__('abc')


# Generated at 2022-06-24 20:24:08.509543
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('test') is True
    assert is_iterable([1, 2]) is True
    assert is_iterable(()) is True
    assert is_iterable({}) is True
    assert is_iterable(1) is False


# Generated at 2022-06-24 20:24:10.466062
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    # Make assertions about the equality of immutable_dict_0 and immutable_dict
    assert isinstance(immutable_dict_0, object)


# Generated at 2022-06-24 20:24:16.558631
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    immutable_dict_2 = ImmutableDict(1, 2, 3)
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)
    var_1 = immutable_dict_0.__eq__(immutable_dict_2)


# Generated at 2022-06-24 20:24:18.226502
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_1 = immutable_dict_0.__eq__("")


# Generated at 2022-06-24 20:24:21.979619
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    bool_0 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:24:28.621678
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)
    if var_0:
        print(var_0)
