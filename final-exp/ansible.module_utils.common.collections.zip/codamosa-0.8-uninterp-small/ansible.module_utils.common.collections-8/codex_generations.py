

# Generated at 2022-06-24 20:14:53.317705
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({'key1': 1, 'key2': 2, 'key3': 3})
    dict2 = ImmutableDict(key1=1, key2=2, key3=3)

    assert dict1 == dict2


# Generated at 2022-06-24 20:14:59.409258
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    #
    # Test without keyword arguments
    #

    # Test ImmutableDict initialization
    first = ImmutableDict([('a', 1), ('b', 2), ('c', 3)])
    second = ImmutableDict([('d', 1), ('e', 2), ('f', 3)])

    # Perform the function test on the ImmutableDict
    result = first.difference(second)

    assert result == ImmutableDict({'a': 1, 'b': 2, 'c': 3})


# Generated at 2022-06-24 20:15:06.174966
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict({'foo': 'bar'})
    var_1 = ImmutableDict({'foo': 'bar'})
    var_2 = ImmutableDict({'foo': 'bar'})
    if var_0 != var_1 or not (var_1 == var_2):
        raise Exception('TestCase failed: var_0 != var_1 or not (var_1 == var_2)')



# Generated at 2022-06-24 20:15:13.035109
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    idict = ImmutableDict({'A': 2, 'B': 3, 'C': 4})
    new_idict = idict.difference(['A'])
    assert({'B': 3, 'C': 4} == new_idict)

    new_idict = idict.difference({'B': 4, 'C': 5})
    assert({'A': 2} == new_idict)

    new_idict = idict.difference(['A', 'B'])
    assert({'C': 4} == new_idict)

    new_idict = idict.difference(['D'])
    assert({'A': 2, 'B': 3, 'C': 4} == new_idict)


# Generated at 2022-06-24 20:15:20.045718
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    from copy import deepcopy
    from types import GeneratorType
    from collections import OrderedDict

    str_0 = OrderedDict([(0, 0), (1, 1), (2, 2)])
    var_0 = ImmutableDict()
    var_1 = ImmutableDict()
    var_2 = ImmutableDict({})
    var_3 = ImmutableDict(str_0)

    var_4 = ImmutableDict({0: 0, 1: 1, 2: 2})
    var_5 = ImmutableDict({0: 0, 1: 1, 2: '2'})
    var_6 = ImmutableDict({0: 0, 1: 1, 2: 2})
    test_0 = var_4 == var_5
    test_1 = var_4 == var_6
    test_

# Generated at 2022-06-24 20:15:21.665096
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    dict_0 = ImmutableDict({'foo':'bar'})

    dict_1 = dict_0.difference(('foo'))


# Generated at 2022-06-24 20:15:26.715549
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():

    i_dict = ImmutableDict()

    i_dict_expected = ImmutableDict({'foo':'bar'})
    i_dict_observed = i_dict.difference(['baz'])
    assert i_dict_expected == i_dict_observed

    i_dict_expected = ImmutableDict({})
    i_dict_observed = i_dict.difference(['foo'])
    assert i_dict_expected == i_dict_observed

    i_dict_expected = ImmutableDict({'foo':'bar', 'baz':'qux'})
    i_dict_observed = i_dict.difference([])
    assert i_dict_expected == i_dict_observed



# Generated at 2022-06-24 20:15:35.609785
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test type and value of argument
    arg_1 = ImmutableDict({'key0': 'value0', 'key1': 'value1'})
    arg_2 = ImmutableDict({'key1': 'value1', 'key0': 'value0'})
    arg_3 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    arg_4 = ImmutableDict(key0='value0', key1='value1')
    arg_5 = ImmutableDict([('key1', 'value1'), ('key0', 'value0')])
    arg_6 = ImmutableDict(key1='value1', key0='value0')
    arg_7 = ImmutableDict(key1='value1', key2='value2')
    arg_8 = ImmutableDict

# Generated at 2022-06-24 20:15:41.723153
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    dict_0 = ImmutableDict( {'a': 1, 'b': 2, 'c': 3, 'd': 4} )
    dict_1 = dict_0.difference({'c', 'a'})
    assert dict_0 == ImmutableDict( {'a': 1, 'b': 2, 'c': 3, 'd': 4} )
    assert dict_1 == ImmutableDict( {'b': 2, 'd': 4} )


# Generated at 2022-06-24 20:15:47.700608
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # SUTED: method ImmutableDict.difference of class ImmutableDict
    method_0 = ImmutableDict({'ansible': 'python'}).difference(['ansible'])
    assert method_0 == ImmutableDict({})
    method_1 = ImmutableDict({'ansible': 'python'}).difference(['ansible', 'foo'])
    assert method_1 == ImmutableDict({})
    method_2 = ImmutableDict({'ansible': 'python'}).difference(['hi', 'foo'])
    assert method_2 == ImmutableDict({'ansible': 'python'})
    method_3 = ImmutableDict({'foo': 'bar'}).difference(['foo'])
    assert method_3 == ImmutableDict({})
    method_4

# Generated at 2022-06-24 20:15:54.243555
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    str_0 = ImmutableDict({})
    str_1 = None
    var_0 = str_0.__eq__(str_1)



# Generated at 2022-06-24 20:15:56.931312
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = None
    var_0 = is_iterable(str_0)



# Generated at 2022-06-24 20:16:02.996147
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict(
        {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    )
    new = original.difference(['a', 'b'])
    assert new == ImmutableDict(
        {'c': 3, 'd': 4}
    )

# Generated at 2022-06-24 20:16:14.700358
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    from ansible.module_utils.common._collections_compat import OrderedDict

    d1 = ImmutableDict({'key1': 'val1', 'key2': 'val2'})
    d2 = ImmutableDict({'key2': 'val2', 'key1': 'val1'})
    d3 = ImmutableDict(OrderedDict({'key1': 'val1', 'key2': 'val2'}))
    d4 = ImmutableDict(OrderedDict({'key2': 'val2', 'key1': 'val1'}))

    assert d1 == d2
    assert d1 == d3
    assert d1 == d4
    assert d2 == d3
    assert d2 == d4
    assert d3 == d4



# Generated at 2022-06-24 20:16:22.710627
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dct_0 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    dct_1 = ImmutableDict({'x': 1})
    dct_2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    dct_3 = ImmutableDict()
    dct_4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    dct_5 = ImmutableDict({2: 3, 1: 4, 4: 1, 3: 5})
    # Test case 1: Evaluate equals on 2 different MutableDict objects
    assert dct_0.__eq__(dct_1) == False
    # Test case 2: Evaluate equals

# Generated at 2022-06-24 20:16:33.442634
# Unit test for function is_iterable
def test_is_iterable():
    # Test 1.1 - str_0 is a str type (expected: False)
    str_0 = "str"
    var_0 = is_iterable(str_0)
    assert False

    # Test 1.2 - str_1 is a str type (expected: False)
    str_1 = "str"
    var_0 = is_iterable(str_1)
    assert False

    # Test 1.3 - str_2 is a str type (expected: False)
    str_2 = "str"
    var_0 = is_iterable(str_2)
    assert False

    # Test 2.1 - dict_0 is a dict type (expected: True)
    dict_0 = {1: 0, 2: 1}
    var_0 = is_iterable(dict_0)
    assert True

   

# Generated at 2022-06-24 20:16:35.180822
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    str_0 = ImmutableDict([('x', 4)])
    var_0 = str_0.__eq__(str_0)


# Generated at 2022-06-24 20:16:44.615875
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = None
    # Test the is_iterable function with input str_0, the expectation is that it returns False.
    assert not is_iterable(str_0)

    str_0 = str()
    # Test the is_iterable function with input str_0, the expectation is that it returns True.
    assert is_iterable(str_0)

    str_0 = u''
    # Test the is_iterable function with input str_0, the expectation is that it returns True.
    assert is_iterable(str_0)


# Generated at 2022-06-24 20:16:52.843473
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d_0 = ImmutableDict({'a': 1, 'b': 2})
    d_1 = ImmutableDict({'a': 1, 'b': 3})
    d_2 = ImmutableDict({'a': 1, 'b': 2})
    d_3 = {'a': 1, 'b': 2}
    assert d_0 == d_2, "AssertionError: Exception occurred at line 8, column 8"
    assert not (d_0 == d_1), "AssertionError: Exception occurred at line 9, column 8"
    assert not (d_0 == d_3), "AssertionError: Exception occurred at line 10, column 8"


# Generated at 2022-06-24 20:16:54.838438
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # prepare input for method ImmutableDict.__eq__
    self = ImmutableDict()
    # method ImmutableDict.__eq__
    # assert False
    assert False




# Generated at 2022-06-24 20:17:03.791547
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    param0 = ImmutableDict()
    param1 = ImmutableDict()
    result = param0.__eq__(param1)


# Generated at 2022-06-24 20:17:05.417718
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = None
    var_1 = is_iterable(str_0)


# Generated at 2022-06-24 20:17:14.433002
# Unit test for function is_iterable
def test_is_iterable():
    arg_0 = [1, 2, 3]
    assert is_iterable(arg_0)

    arg_1 = None
    assert is_iterable(arg_1) is False

    arg_2 = (1, 2, 3)
    assert is_iterable(arg_2)

    arg_3 = {'a': 1, 'b': 2}
    assert is_iterable(arg_3)

    arg_4 = 'something'
    assert is_iterable(arg_4)

    arg_5 = bytearray('something')
    assert is_iterable(arg_5)

# Generated at 2022-06-24 20:17:17.042442
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_ImmutableDict = ImmutableDict()
    other = None
    assert test_ImmutableDict.__eq__(other) == False


# Generated at 2022-06-24 20:17:22.624609
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_1 = ImmutableDict()
    dict_2 = ImmutableDict()
    dict_3 = ImmutableDict()
    dict_4 = ImmutableDict()
    dict_5 = ImmutableDict()
    dict_6 = ImmutableDict()
    dict_7 = ImmutableDict()

    assert dict_0 == dict_1
    assert dict_2 == dict_3
    assert dict_4 == dict_5
    assert dict_6 == dict_7



# Generated at 2022-06-24 20:17:29.187605
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 'b', 'c': 2, 'd': {'e': 'f'}})
    b = ImmutableDict({'a': 'b', 'c': 2, 'd': {'e': 'f'}})
    c = ImmutableDict({'a': 'b', 'c': 2, 'd': {'e': 'f'}, 'g': 'h'})
    assert a == b
    assert not a == c


# Generated at 2022-06-24 20:17:41.232329
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({})
    dict_1 = ImmutableDict({'a': 'b'})
    dict_2 = ImmutableDict({'a': 'b'})
    dict_3 = ImmutableDict({'c': 'd'})
    dict_4 = {}
    dict_5 = []
    dict_6 = dict(a='b')
    dict_7 = ImmutableDict({1: '2'})
    dict_8 = ImmutableDict({1.0: '2'})
    dict_9 = ImmutableDict({True: '2'})

    assert dict_0 == dict_0
    assert dict_1 == dict_1
    assert dict_2 == dict_2
    assert dict_3 == dict_3
    assert dict_0 == dict_4
    assert dict_

# Generated at 2022-06-24 20:17:48.154017
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_1 = ImmutableDict()
    dict_2 = ImmutableDict()
    dict_3 = ImmutableDict()
    var_0 = dict_0.difference(dict_1)
    var_1 = dict_2.difference(dict_3)
    var_2 = var_0.__eq__(var_1)

# Generated at 2022-06-24 20:17:50.157795
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict({'1': 2, '3': 4})
    var_0.__eq__(var_0)

# Generated at 2022-06-24 20:17:53.802257
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    str_0 = ImmutableDict()
    result = str_0._ImmutableDict__eq__(None)
    assert result == False



# Generated at 2022-06-24 20:18:04.537849
# Unit test for function is_iterable
def test_is_iterable():
    pass


# Generated at 2022-06-24 20:18:12.957961
# Unit test for function is_iterable
def test_is_iterable():
    string_var_0 = "test string"
    list_var_0 = [0, 1, 2]

    assert(is_iterable(string_var_0, include_strings=True) is True)
    assert(is_iterable(string_var_0, include_strings=False) is True)
    assert(is_iterable(list_var_0, include_strings=True) is True)
    assert(is_iterable(list_var_0, include_strings=False) is True)


# Generated at 2022-06-24 20:18:16.926394
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_1 = dict()
    var_2 = ImmutableDict(var_1)
    var_3 = ImmutableDict(var_1)
    var_4 = var_2.__eq__(var_3)


# Generated at 2022-06-24 20:18:24.629317
# Unit test for function is_iterable
def test_is_iterable():
    try:
        assert is_iterable([1, 2, 3]) is True
        assert is_iterable({'a': 1, 'b': 2}) is True
        assert is_iterable((1, 2, 3)) is True
        assert is_iterable(1) is False
        assert is_iterable(False) is False
    except AssertionError as e:
        print('test_is_iterable(): {err}'.format(err=e))



# Generated at 2022-06-24 20:18:27.407079
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) == True
    assert is_iterable(('a','b','c')) == True
    assert is_iterable({}) == True
    assert is_iterable(None) == False


# Generated at 2022-06-24 20:18:30.728305
# Unit test for function is_iterable
def test_is_iterable():
    try:
        assert not is_iterable(None)
        assert is_iterable(bytearray())
        assert is_iterable({})
        assert is_iterable([])
        assert is_iterable(())
        assert not is_iterable(1)
    except Exception as e:
        fail(e.message)


# Generated at 2022-06-24 20:18:38.155496
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_1 = ImmutableDict({1: 1, 2: 2})
    dict_2 = ImmutableDict({1: 1, 2: 2})
    dict_3 = ImmutableDict({1: 1, 2: 3})
    dict_4 = ImmutableDict({1: 1, 3: 2})
    dict_5 = ImmutableDict(dict_1, **{3: 3})
    dict_6 = ImmutableDict({1: 1, 2: 2, 3: 3})
    dict_7 = ImmutableDict({1: 1, 2: 2, 3: 4})
    dict_8 = ImmutableDict({1: 1, 2: 2, 4: 3})
    assert dict_1 == dict_2
    assert not dict_1 == dict_3
   

# Generated at 2022-06-24 20:18:43.262376
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(('a','b','c'))
    assert is_iterable({'a':1,'b':2}), \
        "is_iterable fails when checking if a dictionary is iterable"
    assert not is_iterable('abc'), \
        "is_iterable fails when a string is provided as the argument"



# Generated at 2022-06-24 20:18:47.808240
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = None
    assert not is_iterable(str_0)
    assert is_iterable([1, 2, 3])
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable((1, 2, 3))
    assert is_iterable(dict(a=1, b=2, c=3))



# Generated at 2022-06-24 20:18:50.912469
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    str_0 = {}
    str_1 = {}
    assert ImmutableDict(str_0) == ImmutableDict(str_1)


# Generated at 2022-06-24 20:19:12.876882
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = {'key_1': 1, 'key_2': 2}
    o = ImmutableDict(dict_0)
    o_copy = ImmutableDict(dict_0)
    assert o == o_copy # The __eq__ method returns True as expected
    assert o != 'string' # The __eq__ method returns False as expected


# Generated at 2022-06-24 20:19:15.623171
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    print('Test case 0')
    try:
        test_case_0()
        print('Test case 1 passed')
    except AssertionError:
        print('Test case 1 failed')



# Generated at 2022-06-24 20:19:22.715634
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = ''
    str_1 = 'a'
    str_2 = b'abcd'
    str_3 = b'1234'
    str_4 = None
    str_5 = []
    str_6 = [b'abcd']
    str_7 = {'a': 1}
    assert not is_iterable(str_0)
    assert not is_iterable(str_1)
    assert is_iterable(str_2, True)
    assert not is_iterable(str_3, True)
    assert not is_iterable(str_4)
    assert is_iterable(str_5)
    assert is_iterable(str_6)
    assert is_iterable(str_7)



# Generated at 2022-06-24 20:19:23.590636
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable is not None


# Generated at 2022-06-24 20:19:28.534111
# Unit test for function is_iterable
def test_is_iterable():
    iter_0 = [1, 2, 3]
    str_0 = 'a b c'
    var_0 = is_iterable(iter_0)
    var_1 = is_iterable(str_0, include_strings=True)
    var_2 = is_iterable(str_0)
    var_3 = is_iterable(1)
    var_4 = is_iterable(None)
    var_5 = is_iterable(var_0, include_strings=True)


# Generated at 2022-06-24 20:19:31.777589
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(list(range(0,10)))
    assert not is_iterable(2)
    assert is_iterable(2, include_strings=True)
    assert is_iterable('test')
    assert is_iterable('test', include_strings=True)


# Generated at 2022-06-24 20:19:40.388165
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(None) == False, 'is not iterable'
    # test a string
    assert is_iterable('string') == True, 'is an iterable'
    # test a list
    assert is_iterable([]) == True, 'is an iterable'
    # test a tuple
    assert is_iterable(()) == True, 'is an iterable'
    # test a set
    assert is_iterable(set({})) == True, 'is an iterable'
    # test a dict
    assert is_iterable({}) == True, 'is an iterable'


# Generated at 2022-06-24 20:19:45.996331
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    kwargs = {'arg_0': ImmutableDict(arg_0=1)}
    p = ImmutableDict(kwargs)
    q = ImmutableDict(kwargs)
    if (p != q):
        raise Exception('AssertionError')

test_case_0()
test_ImmutableDict___eq__()

# Generated at 2022-06-24 20:19:52.905728
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({'x', 'x'})
    dict_1 = ImmutableDict({'x': 'y'})
    dict_2 = ImmutableDict({'x': 'x'})
    dict_3 = ImmutableDict({'x': 'x'})
    dict_4 = ImmutableDict({'x': 'z'})
    dict_5 = ImmutableDict({'x': 'x'})
    dict_5__eq__ = dict_3
    dict_5 == dict_5__eq__
    dict_4 == dict_5
    dict_1 == dict_2


# Generated at 2022-06-24 20:19:58.713352
# Unit test for function is_iterable
def test_is_iterable():
    list_0 = list()
    str_0 = "test_string"
    int_0 = 1
    float_0 = 1.1

    assert is_iterable(list_0)
    assert is_iterable(str_0)
    assert is_iterable(int_0)
    assert is_iterable(float_0)


# Generated at 2022-06-24 20:20:31.897231
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    empty_dict_0 = ImmutableDict()
    empty_dict_1 = ImmutableDict()
    if (empty_dict_0 == empty_dict_1):
        return True
    else:
        return False


# Generated at 2022-06-24 20:20:41.095593
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
  deque_0 = ImmutableDict({})
  deque_1 = ImmutableDict()
  str_0 = 'st'
  str_1 = 'st'
  str_2 = 's' + 't'
  str_3 = 'a' + 'b'
  str_4 = 's' + 't'
  str_5 = 'a' + 'b'
  str_6 = 's' + 't'
  dict_0 = dict(str_0 = str_1, str_2 = str_3)
  dict_1 = dict(str_4 = str_5, str_6 = str_0)
  dict_2 = dict(str_0 = str_1, str_2 = str_3)
  dict_3 = dict()
  dict_4 = dict()
  dict_

# Generated at 2022-06-24 20:20:46.372843
# Unit test for function is_iterable
def test_is_iterable():
    # Test all combinations of parameters
    str_0 = None
    var_0 = is_iterable(str_0)
    str_0 = 'string'
    var_0 = is_iterable(str_0)
    str_0 = 'string'
    var_0 = is_iterable(str_0, include_strings='string')
    # Return a non-zero value for test case success
    return 0


# Generated at 2022-06-24 20:20:49.378790
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = {"1": "2", "3": "4"}
    dict_1 = ImmutableDict(dict_0)
    dict_2 = ImmutableDict(dict_0)
    #assert dict_2.__eq__(dict_1)

# Generated at 2022-06-24 20:20:56.565348
# Unit test for function is_iterable
def test_is_iterable():
    arg = "This is a string"
    arg2 = b"This is a bytes object"
    assert not is_iterable(arg)
    assert not is_iterable(arg2)
    assert is_iterable(arg, include_strings=True)
    assert is_iterable(arg2, include_strings=True)
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert not is_iterable(1)
    assert not is_iterable(1.0)



# Generated at 2022-06-24 20:21:05.357467
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    list_0 = list()
    i = count(list_0)
    int_0 = 2
    int_1 = 3
    int_2 = 4
    int_3 = 5
    assert isinstance(test_case_0(), bool)
    dict_0 = dict()
    dict_0[int_1] = int_0
    dict_0[int_2] = int_3
    assert isinstance(test_case_0(), bool)
    dict_0[int_0] = int_1
    dict_0[int_2] = int_2
    assert isinstance(test_case_0(), bool)
    assert test_case_0()


# Generated at 2022-06-24 20:21:12.265896
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dummy_dict_0 = ImmutableDict()
    dummy_dict_1 = ImmutableDict()
    dummy_dict_2 = ImmutableDict()
    dummy_dict_3 = ImmutableDict()
    dummy_dict_4 = ImmutableDict()
    dummy_dict_5 = ImmutableDict()
    dummy_dict_6 = ImmutableDict()
    dummy_dict_7 = ImmutableDict()
    dummy_dict_8 = ImmutableDict()
    dummy_dict_9 = ImmutableDict()
    dummy_dict_10 = ImmutableDict()
    dummy_dict_11 = ImmutableDict()
    dummy_dict_12 = ImmutableDict()
    dummy_dict_13 = ImmutableDict()
    dummy_dict_14 = ImmutableDict()
    dummy_dict

# Generated at 2022-06-24 20:21:21.858327
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Building the test data, using the same values as in the __hash__ test
    # to make it easier to verify that the __eq__ and __hash__ are in sync
    test_dict_a = ImmutableDict({'foo': 'bar', 'baz': 'faz', 'answer': 42, 'some_list': [0, 1, 2]})
    test_dict_b = ImmutableDict({'baz': 'faz', 'foo': 'bar', 'some_list': [0, 1, 2], 'answer': 42})
    test_dict_c = ImmutableDict({'baz': 'faz', 'foo':'bar', 'some_list': [0, 1, 2], 'answer': 43})

# Generated at 2022-06-24 20:21:23.767603
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d_0 = ImmutableDict()
    d_1 = ImmutableDict()
    assert not d_0 == d_1


# Generated at 2022-06-24 20:21:29.942920
# Unit test for function is_iterable
def test_is_iterable():
    input = [0, 'a', {'b': 1}, {0, 'a'}, 'ab', 0.1]
    output = [True, True, True, True, True, True]
    index = 0
    for item in input:
        value = is_iterable(item)
        if value != output[index]:
            return False
        index += 1
    return True


# Generated at 2022-06-24 20:22:42.517429
# Unit test for function is_iterable
def test_is_iterable():
    try:
        assert not is_iterable([])
        assert not is_iterable(())
        assert not is_iterable('')
        assert not is_iterable(b'')
        assert not is_iterable({})
        assert not is_iterable(set())
        assert is_iterable([], True)
        assert is_iterable((), True)
        assert is_iterable({}, True)
        assert is_iterable(set(), True)
    except Exception as e:
        pass

    return



# Generated at 2022-06-24 20:22:49.495879
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert is_iterable([1, 2])
    assert is_iterable((1, 2))
    assert is_iterable(set([1, 2]))
    assert is_iterable(dict(zip(['a', 'b'], ['c', 'd'])))
    assert is_iterable("something")
    assert is_iterable(u"something")
    assert is_iterable(b"something")
    assert is_iterable(bytearray(b"something"))
    if hasattr(__builtins__, 'file') and isinstance(__builtins__.file, object):
        assert is_iterable(__builtins__.file)



# Generated at 2022-06-24 20:22:54.074203
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    param_0 = None
    param_1 = ImmutableDict({"a": 1})
    param_1.__eq__(param_0)


# Generated at 2022-06-24 20:22:55.081571
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('test_string') == True


# Generated at 2022-06-24 20:22:55.906596
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    pass


# Generated at 2022-06-24 20:23:00.770705
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({})
    dict_1 = ImmutableDict({})
    var_0 = dict_0 == dict_1


# Generated at 2022-06-24 20:23:04.188286
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable(set([1, 2, 3])) is True
    assert is_iterable({1: 2, 3: 4}) is True
    assert is_iterable('abc') is True
    assert is_iterable(1) is False
    assert is_iterable(None) is False


# Generated at 2022-06-24 20:23:07.928358
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    obj_0 = ImmutableDict()
    var_0 = isinstance(obj_0, Mapping)
    var_1 = isinstance(obj_0, Hashable)


# Generated at 2022-06-24 20:23:11.444775
# Unit test for function is_iterable
def test_is_iterable():
    case_0_input = ("foo", ["foo", "bar"])
    case_0_expected = True
    case_0_output = is_iterable(case_0_input)
    assert case_0_expected == case_0_output



# Generated at 2022-06-24 20:23:13.138320
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    str_0 = None
    obj_0 = ImmutableDict()
    obj_0.__eq__(str_0)
