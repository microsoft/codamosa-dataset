

# Generated at 2022-06-24 20:14:49.971186
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable(tuple()) == True)
    assert(is_iterable(range(10)) == True)
    assert(is_iterable(set()) == True)
    assert(is_iterable(dict()) == True)
    assert(is_iterable(float) == False)


# Generated at 2022-06-24 20:14:57.965010
# Unit test for function is_iterable
def test_is_iterable():
    # We make a list
    myList = [1, 2, 3]
    # We check if the list is iterable
    assert is_iterable(myList) == True
    # Now we check if a number like 3 is iterable
    assert is_iterable(3) == False
    # Now we check if a string is iterable
    assert is_iterable("hello") == True
    # Now we check if a tuple is iterable
    assert is_iterable(("hello", "world")) == True


# Generated at 2022-06-24 20:15:08.534068
# Unit test for function is_iterable
def test_is_iterable():
    float_0 = -199.577
    var_0 = is_iterable(float_0)

    assert not var_0
    float_0 = -199.577
    var_0 = is_iterable(float_0, True)
    assert not var_0

    float_1 = -161.555
    var_1 = is_iterable(float_1)
    assert not var_1

    float_1 = -161.555
    var_1 = is_iterable(float_1, True)
    assert not var_1

    list_0 = ['']
    var_0 = is_iterable(list_0)
    assert var_0

    list_0 = ['']
    var_0 = is_iterable(list_0, False)
    assert var_0


# Generated at 2022-06-24 20:15:16.363582
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['abc', 'def', 'ghi']) == True
    assert is_iterable(('abc', 'def', 'ghi')) == True
    assert is_iterable('abc') == False
    assert is_iterable(1) == False
    assert is_iterable(1.2) == False
    assert is_iterable({'a': 1, 'b': 2}) == True
    assert is_iterable({1, 2, 3}) == True
    assert is_iterable(range(10)) == True
    assert is_iterable({}) == True


# Generated at 2022-06-24 20:15:25.031468
# Unit test for function is_iterable
def test_is_iterable():
    #assert is_iterable([]) == True
    assert is_iterable(list()) == True
    assert is_iterable(bytearray(b'abc')) == True
    assert is_iterable(dict()) == True
    assert is_iterable(set()) == True
    assert is_iterable(frozenset()) == True
    assert is_iterable(int()) == False
    assert is_iterable(float()) == False
    assert is_iterable(bool()) == False
    assert is_iterable(complex()) == False
    assert is_iterable(None) == False
    assert is_iterable(b'abc') == False
    assert is_iterable('abc') == False
    assert is_iterable((1, 2, 3)) == True
    assert is_iterable(range(10)) == True


# Generated at 2022-06-24 20:15:28.078132
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    idict_0 = ImmutableDict()
    dict_0 = {}
    bool_0 = idict_0.__eq__(dict_0)


# Generated at 2022-06-24 20:15:32.472716
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    float_0 = -199.577
    dict_0 = ImmutableDict(var_0=float_0)
    dict_1 = ImmutableDict(var_0=float_0)
    dict_2 = ImmutableDict(var_0=-199.577)
    assert dict_0 == dict_1
    assert dict_0 != dict_2


# Generated at 2022-06-24 20:15:43.211624
# Unit test for function is_iterable
def test_is_iterable():
    var_0 = ImmutableDict({'a': 1, 'b': 2})
    assert is_iterable(var_0)
    var_1 = {'a': 1, 'b': 2}
    assert is_iterable(var_1)
    var_2 = (1, 2, 3)
    assert is_iterable(var_2)
    var_3 = [1, 2, 3]
    assert is_iterable(var_3, include_strings=True)
    var_4 = 'foo'
    assert is_iterable(var_4, include_strings=True)
    var_5 = 'foo'
    assert not is_iterable(var_5)
    var_6 = -199.577
    assert not is_iterable(var_6)



# Generated at 2022-06-24 20:15:54.153840
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    float_0 = -38.045886
    float_1 = 71.5
    float_2 = -9.9
    int_0 = 27
    float_3 = -16.99
    float_4 = 5.2
    float_5 = -15.7

    # Test ImmutableDict: using _store
    var_0 = ImmutableDict(float_0, float_1, float_2, int_0, float_3, float_4, float_5)
    # Test ImmutableDict: using getitem
    var_1 = ImmutableDict(float_0, float_1, float_2, int_0, float_3, float_4, float_5)
    # Test ImmutableDict: using getitem

# Generated at 2022-06-24 20:16:03.728696
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    float_0 = -199.577
    float_1 = -483.993
    float_2 = -483.993
    float_3 = -199.577
    str_0 = 'a string'
    float_4 = float_2
    str_1 = str_0
    float_5 = float_1
    ImmutableDict_0 = ImmutableDict({str_0: float_0, str_1: float_1, str_1: float_2, str_1: float_3, str_0: float_4, str_1: float_5})
    ImmutableDict_1 = ImmutableDict({str_0: float_0})
    ImmutableDict_2 = ImmutableDict({str_0: float_0})

# Generated at 2022-06-24 20:16:12.564788
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    float_0 = -199.577
    var_0 = ImmutableDict({}) == {}
    var_1 = ImmutableDict({}) == 1
    dict_0 = {'key_0': float_0}
    var_2 = ImmutableDict(dict_0) == dict_0
    dict_1 = {'key_0': float_0}
    var_3 = ImmutableDict(dict_0) == dict_1


if __name__ == '__main__':
    import sys
    import os

    sys.path.append(os.getcwd())

    test_case_0()
    test_ImmutableDict___eq__()

# Generated at 2022-06-24 20:16:18.145559
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Create an ImmutableDict object
    # Note that the dict constructor in this case will take the result from locals() as argument
    # which will contain all the variables in the current function
    var_0 = ImmutableDict()
    print(var_0)

    # Create another ImmutableDict object
    var_1 = ImmutableDict(test_case_0.__code__.co_locals)
    print(var_1)

    # Are they equal?
    assert var_0 == var_1

# Unit test

# Generated at 2022-06-24 20:16:20.321086
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict({})
    var_1 = ImmutableDict({})

    assert(var_0 == var_1)



# Generated at 2022-06-24 20:16:25.771189
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Setup the dummy test case
    var_0 = ImmutableDict()
    var_1 = ImmutableDict()
    # Invoke the __eq__ method
    var_0.__eq__(var_1)


# Generated at 2022-06-24 20:16:34.516782
# Unit test for function is_iterable
def test_is_iterable():
    try:
        assert is_iterable(u'a') == True
    except AssertionError:
        raise AssertionError('a')
    try:
        assert is_iterable([1,2,3]) == True
    except AssertionError:
        raise AssertionError('a')
    try:
        assert is_iterable('a') == False
    except AssertionError:
        raise AssertionError('a')
    try:
        assert is_iterable(1) == False
    except AssertionError:
        raise AssertionError('a')


# Generated at 2022-06-24 20:16:40.995228
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_1 = ImmutableDict({'var_0': 1, 'var_1': 2})
    var_2 = ImmutableDict({'var_0': 1, 'var_1': 2, 'var_2': 3, 'var_3': 4, 'var_4': 5, 'var_5': 6, 'var_6': 7, 'var_7': 8, 'var_8': 9})
    var_3 = ImmutableDict({'var_0': 1, 'var_1': 2})
    var_4 = var_2.union({'var_0': 1, 'var_1': 2, 'var_2': 3, 'var_3': 4, 'var_4': 5, 'var_5': 6, 'var_6': 7, 'var_7': 8, 'var_8': 9})


# Generated at 2022-06-24 20:16:43.723637
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict({'a': 1, 'b': 2})
    boolean_0 = var_0.__eq__(ImmutableDict({'a': 1, 'b': 2, 'c': 3}))


# Generated at 2022-06-24 20:16:51.145598
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict({'a': 'b', 'c': 'd'})
    var_1 = ImmutableDict({'c': 'd', 'a': 'b'})
    assert not var_0 != var_1
    var_2 = ImmutableDict({'a': 'b', 'c': 'd'})
    var_3 = ImmutableDict({'a': 'c', 'c': 'd'})
    assert not var_2 == var_3


# Generated at 2022-06-24 20:16:56.192136
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict({'key1': 'value1'}, key2='value2')
    var_1 = ImmutableDict({'key1': 'value1'}, key2='value2')
    var_2 = ImmutableDict({'key1': 'value1'})
    var_3 = {'key1': 'value1'}
    var_4 = 'not a dict'

    assert(var_0 == var_1)
    assert(var_0 != var_2)
    assert(var_0 != var_3)
    assert(var_0 != var_4)



# Generated at 2022-06-24 20:17:08.637431
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({})
    dict_0 = ImmutableDict.union(dict_0, dict_0)
    dict_1 = ImmutableDict({})
    dict_1 = ImmutableDict.union(dict_1, dict_1)
    assert dict_0 == dict_1
    dict_2 = ImmutableDict({})
    dict_2 = ImmutableDict.union(dict_2, dict_2)
    dict_3 = ImmutableDict({})
    dict_3 = ImmutableDict.union(dict_3, dict_3)
    dict_3 = ImmutableDict.union(dict_3, dict_3)
    assert dict_2 != dict_3

if __name__ == '__main__':
    import inspect
    import sys
    globals_ = dict

# Generated at 2022-06-24 20:17:21.795058
# Unit test for function is_iterable
def test_is_iterable():
    float_0 = -199.577
    var_0 = is_iterable(float_0)
    assert var_0 == False, 'Result is not False'
    string_0 = 'test_value'
    var_1 = is_iterable(string_0)
    assert var_1 == True, 'Result is not  True'
    list_0 = [1.058, 1.058, 1.058, 1.058, 1.058]
    var_2 = is_iterable(list_0)
    assert var_2 == True, 'Result is not  True'
    tuple_0 = (60.78, 60.78, 60.78, 60.78, 60.78)
    var_3 = is_iterable(tuple_0)

# Generated at 2022-06-24 20:17:32.036062
# Unit test for function is_iterable
def test_is_iterable():

    # Test case 0 - floats
    float_0 = -199.577
    try:
        var_0 = is_iterable(float_0)
    except TypeError as e:
        raise Exception("Test case 0 failed - unexpected exception.")


    # Test case 1 - list
    list_0 = [7, 0, 3, -1]
    var_1 = is_iterable(list_0)


    # Test case 2 - set
    set_0 = set()
    var_2 = is_iterable(set_0)


    # Test case 3 - string
    str_0 = "abcdefghijklmnopqrstuvwxyz"
    var_3 = is_iterable(str_0)


    # Test case 4 - tuple
    tuple_0 = (1, 2, 3, 4)

# Generated at 2022-06-24 20:17:37.716820
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict()
    var_1 = ImmutableDict()
    if (var_0 == var_1):
        print('True')
    else:
        print('False')

if __name__ == '__main__':
    test_ImmutableDict___eq__()

# Generated at 2022-06-24 20:17:40.625285
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    id_0 = [{'a': 3}, {'b': 3}]
    id_1 = [{'a': 3}, {'b': 3}]
    assert id_0 == id_1


# Generated at 2022-06-24 20:17:44.354844
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_1 = ImmutableDict({'a': 1, 'b': 2})
    dict_2 = ImmutableDict({'c': 3, 'd': 4})
    dict_3 = ImmutableDict({'a': 1, 'b': 2})
    dict_4 = ImmutableDict({'b': 2, 'a': 1})

    print(dict_1 == dict_2)
    print(dict_1 == dict_3)
    print(dict_1 == dict_4)



# Generated at 2022-06-24 20:17:46.462043
# Unit test for function is_iterable
def test_is_iterable():
    print('Testing is_iterable with:')
    assert test_case_0() is None
    print('0 assertions')



# Generated at 2022-06-24 20:17:49.187088
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:17:59.936405
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    case_0 = ImmutableDict({'key_0': 'value_0', 'key_1': 'value_1', 'key_2': 'value_2'})
    case_0_copy = ImmutableDict({'key_0': 'value_0', 'key_1': 'value_1', 'key_2': 'value_2'})
    case_1 = ImmutableDict({'key_0': 'value_1', 'key_1': 'value_1', 'key_2': 'value_2'})
    case_2 = ImmutableDict({'key_0': 'value_0', 'key_1': 'value_1'})

# Generated at 2022-06-24 20:18:04.228706
# Unit test for function is_iterable
def test_is_iterable():
    # Test function with list
    list_1 = [0, 1, 2, 3, 4]
    var_0 = is_iterable(list_1)
    assert var_0 == True, "error in is_iterable()"
    # Test function with string
    str_1 = "string"
    var_1 = is_iterable(str_1)
    assert var_1 == True, "error in is_iterable()"
    # Test function with integer
    int_1 = 1
    var_2 = is_iterable(int_1)
    assert var_2 == False, "error in is_iterable()"


# Generated at 2022-06-24 20:18:12.367678
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({}).__eq__(ImmutableDict({}))
    assert not ImmutableDict({}).__eq__(ImmutableDict({1: 1}))
    assert ImmutableDict({1: 1}).__eq__(ImmutableDict({1: 1}))
    assert not ImmutableDict({1: 2}).__eq__(ImmutableDict({1: 1}))
    assert not ImmutableDict({2: 2}).__eq__(ImmutableDict({1: 1}))


# Generated at 2022-06-24 20:18:29.533378
# Unit test for function is_iterable
def test_is_iterable():
    # We don't support strings
    string_0 = '7iRm'
    assert is_iterable(string_0, include_strings=False) is False
    assert is_iterable(string_0, include_strings=True) is True

    # Lists are iterable
    list_0 = ['8', 'nQ', '2H']
    assert is_iterable(list_0, include_strings=True) is True

    # Tuples are iterable
    tuple_0 = ('fNi', '5O', 'Zz')
    assert is_iterable(tuple_0, include_strings=True) is True

    # Sets are iterable
    set_0 = {'tN9', 'p', 'zCf'}
    assert is_iterable(set_0, include_strings=True) is True



# Generated at 2022-06-24 20:18:36.328575
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_dict_0 = ImmutableDict({"a": 1, "b": 2})
    assert(test_dict_0.__eq__(test_dict_0))
    assert(test_dict_0.__eq__({"a": 1, "b": 2}))
    assert(test_dict_0.__eq__(ImmutableDict({"a": 1, "b": 2})))
    assert(test_dict_0.__eq__(frozenset({"a": 1, "b": 2})))
    assert(not test_dict_0.__eq__({"a": 1, "b": 2, "c": 3}))
    assert(not test_dict_0.__eq__(ImmutableDict({"a": 1, "b": 3})))

# Generated at 2022-06-24 20:18:44.660208
# Unit test for function is_iterable
def test_is_iterable():
    list_0 = ['t', '9', '_', 'l', 'i', 'k', 'a', 'H', 'O', 'S']
    list_1 = [['s', '(_4', 'Y'], ['Q', 'B', 'D'], ['r', '6']]
    list_2 = ['o', '@', 'g', '^', '%', 'n', 'F', 'n', 'b']
    list_3 = ['2', '=', 'j', 'M', 'x', 'W', 'q', 'Q']
    list_4 = ['8', 'Y', 'p', 'R', '!', '_', 'w', '.']
    list_5 = ['e', 'k', 'Y', 'B', 'h', 'm', 'm', '7']

# Generated at 2022-06-24 20:18:46.026756
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(float_0) == False



# Generated at 2022-06-24 20:18:57.952293
# Unit test for function is_iterable
def test_is_iterable():
    if not is_iterable(2):
        raise Exception('Expected True, got False')
    if not is_iterable([2]):
        raise Exception('Expected True, got False')
    if not is_iterable((2,)):
        raise Exception('Expected True, got False')
    if not is_iterable(set([2])):
        raise Exception('Expected True, got False')
    if not is_iterable({2: 3}):
        raise Exception('Expected True, got False')
    if not is_string('2'):
        raise Exception('Expected True, got False')
    if not is_iterable('2'):
        raise Exception('Expected True, got False')
    if not is_iterable(u'2'):
        raise Exception('Expected True, got False')

# Generated at 2022-06-24 20:19:06.068600
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    i_dict = {'1': 'first', '2': 'second', '3': 'third'}
    i_dict_2 = ImmutableDict(i_dict)
    assert i_dict_2 == ImmutableDict(i_dict)
    assert i_dict_2 == {'1': 'first', '2': 'second', '3': 'third'}
    assert not i_dict_2 == ImmutableDict({'1': 'first', '2': 'second'})
    assert not i_dict_2 == {'1': 'first', '2': 'second'}
    assert not i_dict_2 == 7
    assert not isinstance(i_dict_2, Hashable)
    assert isinstance(i_dict_2, ImmutableDict)


# Generated at 2022-06-24 20:19:16.036343
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = u'bGluZSBjaGFpbiBwYXJ0bmVyCmJsb2NrIHN0cmluZ3MKZnJhZ21lbnRzIGFuZCBpbnRlcnByZXRlZCByZWdleHMKdW5pdmVyc2FsIGluc3RydW1lbnRzCmFycm93IGZ1bmN0aW9ucwoK'
    list_0 = ['Badger', 'Badger', 'Badger', 'Mushroom', 'Mushroom']
    dict_0 = {'badger': 'badger', 'mushroom': 'mushroom'}

    var_0 = is_iterable(str_0)
    var_1 = is_iterable(list_0)


# Generated at 2022-06-24 20:19:17.218129
# Unit test for function is_iterable
def test_is_iterable():
    test_case_0()

test_is_iterable()

# Generated at 2022-06-24 20:19:27.405169
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    print("Test #1: test_ImmutableDict___eq__")
    float_0 = 17.75
    d_1 = ImmutableDict()
    float_1 = float_0
    d_2 = ImmutableDict()
    var_0 = d_1 == float_1
    assert var_0 is False, "Incorrect result of comparing ImmutableDict to {0}".format(str(float_1))
    var_1 = d_1 == d_2
    assert var_1 is True, "Incorrect result of comparing two ImmutableDicts"
    float_2 = float_0
    str_0 = str(float_2)
    var_2 = d_1 == str_0

# Generated at 2022-06-24 20:19:34.358311
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['0','1','2','3','4','5','6','7','8','9']) == True
    assert is_iterable((0,1,2,3,4,5,6,7,8,9)) == True
    assert is_iterable([1]) == True
    assert is_iterable((1,)) == True
    assert is_iterable({'x':1,'y':2,'z':3}) == True
    assert is_iterable({0:1,1:2,2:3}) == True
    assert is_iterable('abcde') == True
    assert is_iterable('') == True
    assert is_iterable(12345) == False
    assert is_iterable(1) == False
    assert is_iterable(1.1) == False

# Generated at 2022-06-24 20:19:53.777470
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    from collections import OrderedDict

    immutable_dict = ImmutableDict({"a":1, "b":2})
    dict_ = {"a":1, "b":2}
    ordered_dict = OrderedDict({"a":1, "b":2})

    assert(immutable_dict == dict_)
    assert(immutable_dict == ordered_dict)
    assert(not immutable_dict == ImmutableDict({"a":1, "b":2, "c":3}))
    assert(not immutable_dict == {"a":1, "b":2, "c":3})

    new_immutable_dict = ImmutableDict({"a":1, "b":2, "c":3})
    assert(not new_immutable_dict == immutable_dict)


# Generated at 2022-06-24 20:20:00.631413
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(()) == True
    assert is_iterable([]) == True
    assert is_iterable({}) == True
    assert is_iterable({'foo', 'bar'}) == True
    #
    assert is_iterable(1) == False
    assert is_iterable('foo') == False
    assert is_iterable(1.1) == False
    assert is_iterable(False) == False
    assert is_iterable(None) == False


# Generated at 2022-06-24 20:20:06.221022
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    first = ImmutableDict({'a': 1, 4: '1', 'c': None, 'd': True})
    second = ImmutableDict({'a': 1, 4: '1', 'c': None, 'd': True})
    assert first == second
    assert hash(first) == hash(second)



# Generated at 2022-06-24 20:20:13.953674
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    float_0 = -0.24
    float_1 = 0.26
    float_2 = -0.23
    float_3 = -199.577
    float_4 = 97.06
    float_5 = -0.24
    float_6 = 0.26
    float_7 = -0.23
    float_8 = -199.577
    float_9 = 97.06
    var_0 = ImmutableDict({float_0: float_1, float_2: float_3, float_4: float_5})
    var_1 = ImmutableDict({float_6: float_7, float_8: float_9})
    var_2 = var_0.__eq__(var_1)

# Generated at 2022-06-24 20:20:17.364973
# Unit test for function is_iterable
def test_is_iterable():
    """
    Assert that is_iterable returns correct values for various inputs
    """
    assert is_iterable([]) is True
    assert is_iterable(set()) is True
    assert is_iterable(tuple()) is True
    assert is_iterable(dict()) is True
    assert is_iterable(iter([])) is True
    assert is_iterable(int) is True
    assert is_iterable('example') is False
    assert is_iterable(test_case_0) is False



# Generated at 2022-06-24 20:20:24.487469
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(range(0, 10, 2)) == True
    assert is_iterable(range(0, 10, 2), include_strings=False) == True
    assert is_iterable(range(0, 10, 2), include_strings=True) == True
    assert is_iterable("ansible") == True
    assert is_iterable("ansible", include_strings=False) == True
    assert is_iterable("ansible", include_strings=True) == True
    assert is_iterable("123") == True
    assert is_iterable("123", include_strings=False) == True
    assert is_iterable("123", include_strings=True) == True
    assert is_iterable(123) == False
    assert is_iterable(123, include_strings=False) == False
    assert is_

# Generated at 2022-06-24 20:20:27.039976
# Unit test for function is_iterable
def test_is_iterable():
    # var_0 = is_iterable(float_0)
    list_1 = [0]
    var_0 = is_iterable(list_1)
    assert var_0


# Generated at 2022-06-24 20:20:30.814801
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({1: "one"})
    dict_1 = ImmutableDict({1: "two"})

    if dict_0 == dict_1:
        print("Equal")
    else:
        print("Not Equal")


# Generated at 2022-06-24 20:20:34.869571
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    float_0 = -199.577
    float_1 = -199.577
    float_2 = float_1
    sequence_0 = is_string(float_0)
    # print(sequence_0)
    # print(float_2)
    # print(float_0 == float_2)


# Generated at 2022-06-24 20:20:38.060850
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict()
    var_1 = ImmutableDict()
    var_2 = var_0.__eq__(var_1)


# Generated at 2022-06-24 20:21:17.415207
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    dict_0 = dict(
        (('a', 'b'), ('cd', 'ef'))
    )
    immutableDict_0 = ImmutableDict((('abc', 'cba'), ('abc', 'abc'), (1, 1)))
    dict_1 = dict(
        (('a', 'b'), ('cd', 'ef'))
    )
    immutableDict_1 = ImmutableDict(
        ((dict_0, dict_1),)
    )
    immutableDict_1 = immutableDict_1.difference(immutableDict_0)
    immutableDict_2 = immutableDict_0.union(immutableDict_1)
    immutableDict_3 = immutableDict_0.union(immutableDict_0)

# Generated at 2022-06-24 20:21:21.487952
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict([(1, 2), (3, 4)])
    d2 = ImmutableDict([(3, 4), (1, 2)])
    assert d1 == d2


# Generated at 2022-06-24 20:21:23.728204
# Unit test for function is_iterable
def test_is_iterable():

    """
    This function tests is_iterable function.
    It uses pytest.
    Test case 0, the input is a float
    """

    test_case_0()



# Generated at 2022-06-24 20:21:32.172690
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([0,1,2]) == True
    assert is_iterable({'x':'y'}) == True
    assert is_iterable(100) == False
    assert is_iterable(set([0,1,2])) == True
    assert is_iterable(100) == False
    assert is_iterable(complex(1,2)) == True
    assert is_iterable((1,2,3)) == True
    assert is_iterable('hello') == True
    assert is_iterable(b'hello') == True
    assert is_iterable(False) == False
    assert is_iterable(True) == False
    assert is_iterable(None) == False
    assert is_iterable(object()) == False


# Generated at 2022-06-24 20:21:39.321296
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable(5) == False
    assert is_iterable('abcde') == True
    assert is_iterable(b'abcde') == True
    assert is_iterable([1, 2, 3], True) == True
    assert is_iterable(5, True) == False
    assert is_iterable('abcde', True) == True
    assert is_iterable(b'abcde', True) == True


# Generated at 2022-06-24 20:21:47.662706
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    # Test case for equal dictionaries
    d1 = {'a': 1, 'b': 2, 'c': 3}
    d2 = {'a': 1, 'b': 2, 'c': 3}
    id1 = ImmutableDict(d1)
    id2 = ImmutableDict(d2)
    assert id1 == id2
    assert not id1 != id2

    # Test case for equal dictionaries with same reference
    id3 = id1
    assert id1 == id3
    assert not id1 != id3

    # Test case for not equal dictionaries
    d3 = {'a': 1, 'b': 2, 'c': 3}
    d4 = {'a': 1, 'b': 2, 'c': 4}
    id4 = ImmutableDict(d3)

# Generated at 2022-06-24 20:21:51.500576
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 'b'])
    assert is_iterable((1, 2))
    assert is_iterable({'a': 'b'})
    assert not is_iterable(123)
    assert not is_iterable('abc')
    assert not is_iterable(test_case_0)


# Generated at 2022-06-24 20:21:55.127824
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict({'a': 1})
    var_1 = ImmutableDict({'a': 1})
    assert var_0 == var_1
    var_2 = ImmutableDict({'a': 2})
    assert var_0 != var_2
    var_3 = [('a', 1)]
    assert var_0 == var_3
    var_4 = [('a', 2)]
    assert var_0 != var_4


# Generated at 2022-06-24 20:21:59.256325
# Unit test for function is_iterable
def test_is_iterable():
    my_list = [-20, -10, 0, 10, 20]
    my_string = 'my string'
    my_tuple = ('my', 'tuple')
    my_set = set([1, 2, 3])
    my_dict = {'my': 'dict'}
    my_float = 1.0

    assert not is_iterable(my_float)
    assert is_iterable(my_list)
    assert is_iterable(my_string)
    assert is_iterable(my_tuple)
    assert is_iterable(my_set)
    assert is_iterable(my_dict)

    assert is_iterable(my_float, True)
    assert is_iterable(my_list, True)
    assert is_iterable(my_string, True)
    assert is_

# Generated at 2022-06-24 20:22:05.546097
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(a=1, b=2)
    rv = d1.__eq__(d2)
    # assertEquals(rv, True)
    print("test_ImmutableDict___eq__: rv %r" % (rv,))
    # d2.update({'a': 2})  # fails with: AttributeError: 'ImmutableDict' object has no attribute 'update'
    # test_case_0()
    # test_ImmutableDict___eq__()

# Generated at 2022-06-24 20:23:18.539594
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict({'a': 'b'})
    assert var_0 == var_0
    assert var_0 == dict(a='b')
    assert var_0 == {'a': 'b'}
    assert var_0 == ImmutableDict(a='b')
    assert var_0 == {'b': 'a'}



# Generated at 2022-06-24 20:23:26.498046
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict_2 = ImmutableDict({'a': 1, 'b': 2, 'd': 4})
    int_0 = ImmutableDict.__eq__(dict_0, dict_1)
    int_1 = ImmutableDict.__eq__(dict_1, dict_2)

    assert int_0 == int_1

# Generated at 2022-06-24 20:23:35.204164
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    class ImmutableDict___eq__0():
        def __init__(self,):
            self.var_0 = ImmutableDict(x=123)

    class ImmutableDict___eq__1():
        def __init__(self,):
            self.var_0 = ImmutableDict(x=123)
            self.var_0._store['y'] = 456

        def test_case_0(self):
            var_0 = ImmutableDict(x=123)
            var_1 = ImmutableDict(x=123, y=456)
            var_2 = ImmutableDict()
            var_2.update(x=123, y=456)
            var_3 = ImmutableDict(x=123, y=456)
            var_4 = ImmutableDict(x=123)


# Generated at 2022-06-24 20:23:41.615243
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Creating a immutable dictionary
    immutableDict_0 = ImmutableDict({'a': 1, 'b': 2})

    # Trying to compare the immutable dictionary with a different dictionary and checking if they are not equal
    if immutableDict_0 == {'a': 1, 'd': 2}:
        print("Tests pass.")
    else:
        print("Tests fail.")


# Generated at 2022-06-24 20:23:43.676438
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    arg = ImmutableDict()
    var_0 = arg.__eq__()


# Generated at 2022-06-24 20:23:46.642083
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # __eq__ of ImmutableDict
    pass


# Generated at 2022-06-24 20:23:50.654341
# Unit test for function is_iterable
def test_is_iterable():
    assert False == is_iterable('abc')
    assert False == is_iterable(b'abc')
    assert False == is_iterable(999)
    assert True == is_iterable([1, 2, 3])
    assert True == is_iterable((1, 2, 3))
    assert True == is_iterable({'a': 1, 'b': 2, 'c': 3})



# Generated at 2022-06-24 20:24:02.101124
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    dict_1 = {'e': 5, 'c': 3, 'b': 2, 'd': 4, 'a': 1}
    immut_0 = ImmutableDict(dict_0)
    immut_1 = ImmutableDict(dict_1)
    immut_2 = ImmutableDict(dict_0)

    assert(immut_1 == immut_0)
    assert(immut_1 == immut_2)
    assert(immut_0 == immut_2)
    assert(immut_1 == dict_0)
    assert(dict_1 == immut_0)
    assert(immut_0 == dict_1)

# Generated at 2022-06-24 20:24:05.780432
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_1 = ImmutableDict({})
    var_2 = ImmutableDict({})
    var_0 = (var_1 == var_2)


# Generated at 2022-06-24 20:24:15.614582
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    case_0 = ImmutableDict()
    case_1 = ImmutableDict(a=1)
    case_2 = ImmutableDict(b=1)
    case_3 = ImmutableDict(a=1, b=2)
    case_4 = ImmutableDict(a=1, b=2)
    case_5 = ImmutableDict(b=2, a=1)

    assert case_0.__eq__(case_0)
    assert case_1.__eq__(case_1)
    assert case_2.__eq__(case_2)
    assert case_3.__eq__(case_4)
    assert case_4.__eq__(case_3)
    assert case_3.__eq__(case_5)