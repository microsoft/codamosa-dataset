

# Generated at 2022-06-24 20:14:59.908670
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    str_0 = '4'
    str_1 = '>dj'
    immutable_dict_0 = ImmutableDict(**{str_0: str_1})
    str_2 = '4'
    str_3 = '>dj'
    immutable_dict_1 = ImmutableDict(**{str_2: str_3})
    assert set(sorted(immutable_dict_0.keys())) == set(sorted(immutable_dict_1.keys()))
    assert set(sorted(immutable_dict_0.values())) == set(sorted(immutable_dict_1.values()))
    assert immutable_dict_0.__eq__(immutable_dict_1) == True


# Generated at 2022-06-24 20:15:09.861687
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    str_1 = 'R'
    dict_1 = {str_1: str_1}
    immutable_dict_1 = ImmutableDict(**dict_1)

    str_2 = 'R'
    dict_2 = {str_2: str_2}
    immutable_dict_2 = ImmutableDict(**dict_2)

    str_3 = 'Q'
    dict_3 = {str_3: 'R'}
    immutable_dict_3 = ImmutableDict(**dict_3)

    # Test __eq__ with ImmutableDict, ImmutableDict
    assert immutable_dict_1 == immutable_dict_2
    # Test __eq__ with ImmutableDict, ImmutableDict
    assert immutable_dict_1 != immutable_dict_3
    #Test __eq__ with ImmutableDict

# Generated at 2022-06-24 20:15:17.005324
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('foo') is False
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable((1, 2, 3)) is True
    assert is_iterable(set([1, 2, 3])) is True
    assert is_iterable({'a': 1, 'b': 2, 'c': 3}) is True
    assert is_iterable(ImmutableDict({'a': 1, 'b': 2, 'c': 3})) is True
    assert is_iterable(range(0, 3)) is True
    assert is_iterable(xrange(0, 3)) is True
    assert is_iterable(1) is False
    assert is_iterable(1.0) is False


# Generated at 2022-06-24 20:15:19.831553
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    str_0 = 'R'
    dict_0 = {str_0: str_0}
    immutable_dict_0 = ImmutableDict(**dict_0)
    immutable_dict_1 = ImmutableDict()
    bool_0 = immutable_dict_0 == immutable_dict_1


# Generated at 2022-06-24 20:15:28.237505
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    str_0 = 'k'
    int_0 = 1
    list_0 = [str_0]
    immutable_dict_0 = ImmutableDict(int_0, **{str_0: list_0})
    str_1 = 'k'
    int_1 = 1
    list_1 = [str_0]
    immutable_dict_1 = ImmutableDict(int_1, **{str_1: list_1})
    assert immutable_dict_0.__eq__(immutable_dict_1) == True


# Generated at 2022-06-24 20:15:33.581561
# Unit test for function is_iterable
def test_is_iterable():

    assert(is_iterable([]) == True)
    assert(is_iterable(()) == True)
    assert(is_iterable({}) == True)
    assert(is_iterable(set()) == True)
    assert(is_iterable('') == True)
    assert(is_iterable(1) == False)
    assert(is_iterable(False) == False)
    assert(is_iterable(True) == False)
    assert(is_iterable(None) == False)


# Generated at 2022-06-24 20:15:39.299472
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    str_0 = 'R'
    dict_0 = {str_0: str_0}
    immutable_dict_0 = ImmutableDict(**dict_0)
    immutable_dict_1 = ImmutableDict(**dict_0)

    assert(immutable_dict_0 == immutable_dict_1), 'The result should be %s.' % immutable_dict_1



# Generated at 2022-06-24 20:15:46.387151
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    str_0 = 'R'
    dict_0 = {str_0: str_0}
    immutable_dict_0 = ImmutableDict(**dict_0)
    immutable_dict_1 = ImmutableDict(**dict_0)
    assert immutable_dict_0.__eq__(immutable_dict_1) == True

# Test for method __eq__ of class ImmutableDict

# Generated at 2022-06-24 20:15:50.289782
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    str_0 = 'a'
    str_1 = 'b'
    dict_0 = {str_0: str_0, str_1: str_1}
    immutable_dict_0 = ImmutableDict(**dict_0)
    assert immutable_dict_0 == immutable_dict_0
    assert immutable_dict_0 != dict_0


# Generated at 2022-06-24 20:15:57.180696
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    str_0 = 'Y'
    str_1 = '_'
    list_0 = [str_0, str_1]
    dict_0 = {str_0: list_0}
    immutable_dict_0 = ImmutableDict(**dict_0)
    immutable_dict_1 = ImmutableDict(**dict_0)
    assert immutable_dict_0 == immutable_dict_1
    list_1 = ['_']
    dict_1 = {str_0: list_0, str_0: list_1}
    immutable_dict_2 = ImmutableDict(**dict_1)
    assert not immutable_dict_0 == immutable_dict_2
    list_2 = ['Y']
    dict_2 = {str_1: list_2}

# Generated at 2022-06-24 20:16:02.037003
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dictionary = ImmutableDict()
    assert immutable_dictionary.__eq__() == immutable_dictionary


# Generated at 2022-06-24 20:16:09.618313
# Unit test for function is_iterable
def test_is_iterable():

    # Check if the function is_iterable returns True if the given input is a mutable mapping
    mutable_mapping = {'key_0': 'value_0', 'key_1': 'value_1'}
    assert is_iterable(mutable_mapping) is True

    # Check if the function is_iterable returns True if the given input is an immutable mapping
    immutable_mapping = ImmutableDict({'key_0': 'value_0', 'key_1': 'value_1'})
    assert is_iterable(immutable_mapping) is True

    # Check if the function is_iterable returns True if the given input is an array
    array_0 = ['value_0', 'value_1']
    assert is_iterable(array_0) is True

    # Check if the function is_iterable returns

# Generated at 2022-06-24 20:16:15.572768
# Unit test for function is_iterable
def test_is_iterable():
    thing_1 = 1
    thing_2 = "abcdef"
    thing_3 = []
    thing_4 = {'a': 1, 'b': 2, 'c': 3}

    assert is_iterable(thing_1) is False
    assert is_iterable(thing_2) is True
    assert is_iterable(thing_3) is True
    assert is_iterable(thing_4) is True



# Generated at 2022-06-24 20:16:22.615667
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable(1) == False
    assert is_iterable({1:2, 1:2}) == True
    assert is_iterable({1, 2, 3}) == True
    assert is_iterable('123') == False


# Generated at 2022-06-24 20:16:27.556216
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({'a':1, 'b':2, 'c':3})
    assert dict_0 == ImmutableDict({'a':1, 'b':2, 'c':3})
    assert dict_0 != ImmutableDict({'a':2, 'b':2, 'c':3})


# Generated at 2022-06-24 20:16:36.779766
# Unit test for function is_iterable

# Generated at 2022-06-24 20:16:38.678080
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Initialize the class
    obj = ImmutableDict()
    # Check if the two objects are equal
    assert obj.__eq__(ImmutableDict())


# Generated at 2022-06-24 20:16:43.417648
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    other_0 = ImmutableDict({})
    other_1 = ImmutableDict()
    ImmutableDict({}).__eq__(other_1)
    ImmutableDict({}).__eq__(other_0)
    ImmutableDict().__eq__(other_1)
    ImmutableDict().__eq__(other_0)


# Generated at 2022-06-24 20:16:51.590359
# Unit test for function is_iterable
def test_is_iterable():
    assert (is_iterable(2) == False)
    assert (is_iterable("Test") == True)
    assert (is_iterable([1, 2, 3]) == True)
    assert (is_iterable(['123', '456', '789']) == True)
    assert (is_iterable((1, 2, 3)) == True)
    assert (is_iterable({"a", "b", "c"}) == False)
    assert (is_iterable({"a":1, "b":2, "c":3}) == False)


# Generated at 2022-06-24 20:16:58.262981
# Unit test for function is_iterable
def test_is_iterable():
    list_0 = [1, 'a', 4.0]
    assert is_iterable(list_0)
    dict_0 = dict(a=1, b='a', c=4.0)
    assert is_iterable(dict_0)
    string_0 = 'xyz123'
    assert not is_iterable(string_0)
    assert is_iterable(string_0, True)


# Generated at 2022-06-24 20:17:09.002313
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(3)
    assert not is_iterable(3.4)
    assert is_iterable('foo')
    assert is_iterable(u'bar')
    assert is_iterable([2, 3, 5])
    assert is_iterable((3, 4))



# Generated at 2022-06-24 20:17:17.413777
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    keys = ['a', 'b', 'c', 'd']
    values = ['first', 'second', 'third', 'fourth']
    var_1 = ImmutableDict(zip(keys, values))
    var_2 = ImmutableDict(zip(keys, values))
    assert var_1 == var_2
    assert var_2 == var_1
    keys[0] = 'aa'
    var_3 = ImmutableDict(zip(keys, values))
    assert var_1 != var_3
    assert var_3 != var_1


# Generated at 2022-06-24 20:17:25.771307
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1,2,3]) == True
    assert is_iterable((1,2,3)) == True
    assert is_iterable({'a': 1, 'b': 2, 'c': 3}) == True
    assert is_iterable(ImmutableDict({'a': 1, 'b': 2, 'c': 3})) == True
    assert is_iterable(42) == False
    assert is_iterable(is_iterable) == False
    assert is_iterable('string') == True
    assert is_iterable('string') == True



# Generated at 2022-06-24 20:17:30.025674
# Unit test for function is_iterable
def test_is_iterable():
    var_8 = [1, 2, 3]
    if is_iterable(var_8):
        var_9 = "Iterable"
    else:
        var_9 = "Not Iterable"
    assert var_9 == "Iterable"


# Generated at 2022-06-24 20:17:41.924949
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert test_dict == ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert test_dict != ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    assert test_dict != ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    assert test_dict != ImmutableDict({'a': 1, 'b': 3, 'c': 3})
    assert test_dict != ImmutableDict({'a': 2, 'b': 2, 'c': 3})
    assert test_dict != {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-24 20:17:51.999541
# Unit test for function is_iterable
def test_is_iterable():
    float_0 = (float(0))
    bool_0 = is_iterable(float_0)
    assert bool_0 == False, \
        "Wrong value returned when calling 'is_iterable' on a Float."
    dict_0 = dict()
    bool_1 = is_iterable(dict_0)
    assert bool_1 == True, \
        "Wrong value returned when calling 'is_iterable' on a Dict."
    list_0 = list()
    bool_2 = is_iterable(list_0)
    assert bool_2 == True, \
        "Wrong value returned when calling 'is_iterable' on a List."
    str_0 = str()
    bool_3 = is_iterable(str_0)

# Generated at 2022-06-24 20:17:57.272282
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(list())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(tuple())
    assert is_iterable('abc')
    assert not is_iterable(int())
    assert not is_iterable(1)
    assert not is_iterable(None)

try:
    test_case_0()
except Exception as ex:
    print('Exception: {}'.format(ex))

# Generated at 2022-06-24 20:18:00.981097
# Unit test for function is_iterable
def test_is_iterable():
    # Test case 0
    float_0 = 2375.1
    result = is_iterable(float_0)
    assert not result
    # Test case 1
    var_1 = is_iterable(var_0)
    assert var_1


# Generated at 2022-06-24 20:18:04.784691
# Unit test for function is_iterable
def test_is_iterable():
    assert immutabledict_is_iterable(float_0)


# Generated at 2022-06-24 20:18:15.461127
# Unit test for function is_iterable
def test_is_iterable():
    try:
        var_1 = is_iterable(a, True)
    except Exception as e:
        print(str(e))

    try:
        var_2 = is_iterable(2375.1)
    except Exception as e:
        print(str(e))

    try:
        var_3 = is_iterable([0, 1, 2, 3, 4, 5, 6])
    except Exception as e:
        print(str(e))

    try:
        a = (0, 1, 2, 3, 4, 5, 6)
        var_4 = is_iterable(a)
    except Exception as e:
        print(str(e))


# Generated at 2022-06-24 20:18:31.207516
# Unit test for function is_iterable
def test_is_iterable():
    float_0 = 2375.1
    float_1 = 4.2562E+12
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()


# Generated at 2022-06-24 20:18:33.031156
# Unit test for function is_iterable
def test_is_iterable():
    string_0 = 'abcdefg'
    int_0 = 1236
    list_0 = [string_0, int_0]
    var_0 = is_iterable(list_0)


# Generated at 2022-06-24 20:18:38.173585
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Testing if the method __eq__ of class ImmutableDict is working as expected
    from testcases_ImmutableDict import test_ImmutableDict___eq__
    test_ImmutableDict___eq__()

# Generated at 2022-06-24 20:18:48.237684
# Unit test for function is_iterable
def test_is_iterable():
    float_1 = 2375.1
    string_0 = 'This is a string'
    bool_0 = True
    bool_1 = False
    list_0 = [float_1, string_0, bool_0, bool_1]
    tuple_0 = (float_1, string_0, bool_0, bool_1)
    set_0 = {float_1, string_0, bool_0, bool_1}
    dict_0 = {'What' : bool_0, 'Ever' : bool_1}

    assert(is_iterable(string_0))
    assert(is_iterable(list_0))
    assert(is_iterable(tuple_0))
    assert(is_iterable(set_0))
    assert(is_iterable(dict_0))

# Generated at 2022-06-24 20:18:52.994561
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable({}) is True
    assert is_iterable(2375.1) is False
    assert is_iterable('2375.1') is True
    assert is_iterable('2375.1', True) is True


# Generated at 2022-06-24 20:19:03.540980
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = {'key_0': 'value_0', 'key_1': 'value_1'}
    dict_1 = {'key_0': 'value_0', 'key_1': 'value_1'}
    dict_2 = {'key_0': 'value_2', 'key_1': 'value_1'}
    dict_3 = {'key_0': 'value_0', 'key_1': 'value_1', 'key_2': 'value_2'}
    dict_4 = ImmutableDict(dict_0)
    dict_5 = ImmutableDict(dict_1)
    dict_6 = ImmutableDict(dict_2)
    dict_7 = ImmutableDict(dict_3)
    dict_8 = ImmutableDict(dict_0)

    dict

# Generated at 2022-06-24 20:19:06.857355
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict({'var_0': 'var_0'})

    assert var_0 == ImmutableDict({'var_0': 'var_0'})


# Generated at 2022-06-24 20:19:14.282465
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1) == ImmutableDict(a=1)
    assert not ImmutableDict(a=1) == dict(a=1)
    assert ImmutableDict(a=1) != ImmutableDict(a=2)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1)
    assert ImmutableDict(a=1, b=2) != dict(a=1)
    assert ImmutableDict(a=1, b=2) != set([1])


# Generated at 2022-06-24 20:19:16.926961
# Unit test for function is_iterable
def test_is_iterable():
    list_0 = [1, 2, 3]
    float_0 = 2375.1

    assert(is_iterable(list_0))
    assert(is_iterable(float_0) is False)


# Generated at 2022-06-24 20:19:21.858853
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert not is_iterable(set())
    assert not is_iterable(23)
    assert not is_iterable(23.6)
    assert not is_iterable(56.34 + 0.254j)
    assert not is_iterable(b'string')
    assert not is_iterable('string')
    assert is_iterable(b'string')


# Generated at 2022-06-24 20:19:40.093494
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(()) == True
    assert is_iterable([]) == True
    assert is_iterable({}) == True
    assert is_iterable(set()) == True
    assert is_iterable('') == True
    assert is_iterable(0) == False
    assert is_iterable(None) == False
    assert is_iterable(True) == False
    assert is_iterable(False) == False
    assert is_iterable(is_iterable) == False


# Generated at 2022-06-24 20:19:46.291508
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test _ImmutableDict__eq__(self, other)
    """
    test_obj_0 = ImmutableDict(['a', 'b'], [1, 2], [3, 4])
    test_obj_1 = ImmutableDict(['a', 'b'], [1, 2], [3, 4])
    assert test_obj_0 == test_obj_1


# Generated at 2022-06-24 20:19:55.138242
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict()
    var_1 = hash(var_0)
    var_2 = hash(var_1)
    var_3 = hash(var_2)
    var_4 = hash(var_3)
    var_5 = hash(var_4)
    var_6 = hash(var_5)
    var_7 = hash(var_6)
    var_8 = hash(var_7)
    var_9 = hash(var_8)
    var_10 = hash(var_9)
    var_11 = hash(var_10)
    var_12 = hash(var_11)
    var_13 = hash(var_12)
    var_14 = hash(var_13)
    var_15 = hash(var_14)

# Generated at 2022-06-24 20:19:58.463832
# Unit test for function is_iterable
def test_is_iterable():
    initial_iterable='tiger'
    initial_uniterable=12
    assert is_iterable(initial_iterable) is True
    assert is_iterable(initial_uniterable) is False


# Generated at 2022-06-24 20:20:05.715824
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    pass
    ImmutableDict_0 = ImmutableDict()
    ImmutableDict_1 = ImmutableDict({"aaa": 1})
    ImmutableDict_2 = ImmutableDict({"aaa": 1})
    ImmutableDict_3 = ImmutableDict({"bbb": 1})
    assert ImmutableDict_1 == ImmutableDict_2, "test_ImmutableDict___eq__: ImmutableDict_1 == ImmutableDict_2"
    assert ImmutableDict_1 != ImmutableDict_3, "test_ImmutableDict___eq__: ImmutableDict_1 != ImmutableDict_3"



# Generated at 2022-06-24 20:20:12.080393
# Unit test for function is_iterable
def test_is_iterable():

    # 1) When an iterable parameter is provided the function should return True
    assert is_iterable([1, 2, 3]) == True

    # 2) When a non iterable parameter is provided the function should return False
    assert is_iterable("hello") == False


# Generated at 2022-06-24 20:20:20.406233
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable((1, 2, 3)) == True
    assert is_iterable(set([1, 2, 3])) == True
    assert is_iterable(dict(a=1, b=2)) == True
    assert is_iterable(1) == False
    assert is_iterable('a') == False
    assert is_iterable(None) == False

    # Unit test for function is_string

# Generated at 2022-06-24 20:20:26.471571
# Unit test for function is_iterable
def test_is_iterable():

    assert is_iterable(['one', 'two', 'three'], include_strings=True)
    assert is_iterable(set(['one', 'two', 'three']), include_strings=True)
    assert not is_iterable(['one', 'two', 'three'])
    assert not is_iterable(set(['one', 'two', 'three']))
    assert not is_iterable('one')
    assert is_iterable('one', include_strings=True)



# Generated at 2022-06-24 20:20:31.312836
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert test_dict == test_dict
    assert test_dict == {'a': 1, 'b': 2, 'c': 3}
    assert test_dict != {'a': 1, 'b': 2}


# Generated at 2022-06-24 20:20:40.623895
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    float_0 = 2375.1
    float_1 = 3774.4
    float_2 = float_1
    float_3 = 2375.1
    float_4 = 2375.0
    float_5 = 2375.0
    var_0 = ImmutableDict({float_0: float_0, float_1: float_1, float_2: float_2})
    var_1 = ImmutableDict({float_0: float_0, float_1: float_1, float_3: float_3})
    var_2 = ImmutableDict({float_2: float_2, float_3: float_3, float_4: float_4, float_5: float_5})
    var_3 = ImmutableDict({float_2: float_0})
    assert var_0.__eq

# Generated at 2022-06-24 20:21:08.844356
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(object) == False
    assert is_iterable(test_is_iterable) == True


# Generated at 2022-06-24 20:21:17.434227
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Verify that the __eq__ method compares the hashes of 2 instances of a
    ImmutableDict class. It shouldn't raise an exception.
    """
    immutable_mapping_0 = ImmutableDict({1: 2, 3: 4})
    immutable_dict_0 = ImmutableDict()
    immutable_mapping_1 = ImmutableDict({1: 2, 3: 4})
    assert immutable_dict_0.__eq__(immutable_dict_0)
    assert immutable_dict_0.__eq__(immutable_mapping_1)
    assert immutable_mapping_0.__eq__(immutable_mapping_0)
    assert immutable_mapping_0.__eq__(immutable_mapping_1)

# Generated at 2022-06-24 20:21:26.921969
# Unit test for function is_iterable
def test_is_iterable():
    var_0 = is_iterable('test')
    var_1 = is_iterable(['test1', 'test2', 'test3'])
    var_2 = is_iterable({'test1': 'test1', 'test2': 'test2', 'test3': 'test3'})
    var_3 = is_iterable(('test1', 'test2', 'test3'))
    var_4 = is_iterable('set1')
    var_5 = is_iterable({'test1', 'test2'})
    var_6 = is_iterable(['test1', 'test2', 'test3'])
    var_7 = is_iterable(['test1', 'test2', 'test3'])
    var_8 = is_iterable('set2')

# Generated at 2022-06-24 20:21:35.432341
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(None)
    assert is_iterable('')
    assert is_iterable('abc')
    assert not is_iterable(u'abc')
    assert is_iterable(u'abc', include_strings=True)
    assert not is_iterable(u'abc'.encode('utf-8'))
    assert not is_iterable('')
    assert not is_iterable(u'')
    assert is_iterable(())
    assert is_iterable((1, 2, 3))
    assert is_iterable([])
    assert is_iterable([3, 4, 5])
    assert is_iterable({})
    assert is_iterable({'a': 4, 'b': 5})
    assert is_iterable(set())

# Generated at 2022-06-24 20:21:41.272652
# Unit test for function is_iterable
def test_is_iterable():
    float_0 = 3.2
    str_0 = 'Ima string'
    list_0 = ['Ima string', 3.2, 3]
    dict_0 = {'Ima string': 3.2, '3': 3}
    assert is_iterable(float_0) == False
    assert is_iterable(str_0) == True
    assert is_iterable(list_0) == True
    assert is_iterable(dict_0) == True

# Generated at 2022-06-24 20:21:43.496673
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([4, 3, 2, 1])

    class Foo(object):  # noqa
        pass

    assert not is_iterable(Foo)



# Generated at 2022-06-24 20:21:50.361928
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a']) is True
    assert is_iterable('a') is True
    assert is_iterable(('a')) is True
    assert is_iterable('a'.encode()) is True
    assert is_iterable({'foo': 'bar'}) is True
    assert is_iterable(iter(['a'])) is True
    assert is_iterable(None) is False
    assert is_iterable(int) is False
    assert is_iterable(23) is False
    assert is_iterable(23, include_strings=True) is False


# Generated at 2022-06-24 20:21:56.457654
# Unit test for function is_iterable
def test_is_iterable():
    # Check if an integer is an iterable
    int_0 = 2594
    assert not is_iterable(int_0, False)

    # Check if a tuple is an iterable
    tuple_0 = (9415, )
    assert is_iterable(tuple_0, True)

    # Check if a dictionary is an iterable
    dict_0 = {'key0': 'value'}
    assert is_iterable(dict_0, True)

    # Check if a float is an iterable
    float_0 = 0.8123
    assert not is_iterable(float_0, False)

    # Check if a string is an iterable
    string_0 = 'string'
    assert not is_iterable(string_0, False)

    # Check if a list is an iterable

# Generated at 2022-06-24 20:21:59.896271
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict(((1, 'a'), (2, 'b')))
    var_1 = ImmutableDict(((2, 'b'), (1, 'a')))
    assert var_0 == var_1


# Generated at 2022-06-24 20:22:03.815039
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = {u: 2}
    dict_1 = ImmutableDict()
    dict_2 = ImmutableDict({'a': 0}, a=1, b=2, c=3)
    dict_3 = ImmutableDict(dict_0)
    dict_4 = ImmutableDict(dict_2)


# Generated at 2022-06-24 20:23:07.928436
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    m1 = ImmutableDict({'key': 'value'})
    m2 = ImmutableDict({'key': 'value'})
    assert m1 == m2
    assert not m1 == {'key': 'value'}
    assert not m1 == None
    assert not m1 == 'a'


# Generated at 2022-06-24 20:23:16.567158
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test case for method __eq__ of class ImmutableDict."""

    float_0 = 2375.1
    float_1 = float_0
    str_0 = 'test'
    str_1 = str_0
    dict_0 = ImmutableDict({str_0: float_0})
    dict_1 = ImmutableDict({str_1: float_1})
    dict_2 = ImmutableDict({str_1: float_1, str_0: float_0})
    dict_3 = dict_0
    dict_4 = dict_1
    dict_5 = dict_2
    dict_6 = ImmutableDict({str_0: float_1})
    dict_7 = dict_6
    dict_8 = ImmutableDict({str_1: float_0})

# Generated at 2022-06-24 20:23:22.796351
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    string_0 = 'httpd_sys_content_t'
    mapping_0 = ImmutableDict()
    mapping_1 = ImmutableDict()
    mapping_2 = ImmutableDict()
    mapping_3 = ImmutableDict()
    mapping_3.__eq__(string_0)
    mapping_0.__eq__(mapping_1)
    mapping_0.__eq__(mapping_2)
    mapping_0.__eq__(mapping_3)
    return


# Generated at 2022-06-24 20:23:30.924729
# Unit test for function is_iterable
def test_is_iterable():
    from collections import Iterable
    assert is_iterable(None) is True
    assert is_iterable("") is True
    assert is_iterable({}) is True
    assert is_iterable([]) is True
    assert is_iterable(Range(0)) is True
    assert is_iterable(Range(1,2)) is True
    assert is_iterable(Range(1,2,3)) is True
    assert is_iterable(Sequence()) is True
    assert is_iterable(Iterable()) is True
    assert is_iterable(object()) is False
    assert is_iterable(1) is False



# Generated at 2022-06-24 20:23:41.753688
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    float_0 = 2375.1
    float_1 = float_0
    set_0 = set([2375.1, float_1, float_0])
    dict_0 = {'0': 6184, '1': float_1, '2': float_0, '3': float_1, '4': '0'}
    dict_1 = dict_0
    dict_2 = {'0': 6184, '1': float_0, '2': float_0, '3': float_1, '4': '0'}
    dict_3 = dict_2
    dict_4 = dict_2
    dict_5 = dict_2
    dict_6 = dict_2
    dict_7 = dict_2
    dict_8 = dict_2
    dict_9 = dict_2

# Generated at 2022-06-24 20:23:43.177760
# Unit test for function is_iterable
def test_is_iterable():
    answer = is_iterable(2375.1)
    assert answer == False



# Generated at 2022-06-24 20:23:50.967971
# Unit test for function is_iterable
def test_is_iterable():

    def test_case_0():
        int_0 = 5
        var_0 = is_iterable(int_0)
        assert var_0 == False

    def test_case_1():
        int_0 = 5
        var_0 = is_iterable(int_0, include_strings=True)
        assert var_0 == False

    def test_case_2():
        str_0 = "Hello"
        var_0 = is_iterable(str_0)
        assert var_0 == True

    def test_case_3():
        str_0 = "Hello"
        var_0 = is_iterable(str_0, include_strings=True)
        assert var_0 == True



# Generated at 2022-06-24 20:23:52.431670
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable('Hello world')
    assert not is_iterable(234)


# Generated at 2022-06-24 20:23:56.224838
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    float_0 = 2375.1
    ImmutableDict_0 = ImmutableDict(float_0)
    float_1 = 2375.1
    ImmutableDict_1 = ImmutableDict(float_1)
    var_0 = ImmutableDict_0 == ImmutableDict_1


# Generated at 2022-06-24 20:24:07.018097
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # initialization
    var_0 = ImmutableDict({})
    var_1 = ImmutableDict({})

    assert var_0 == var_1

    # initialization
    var_0 = ImmutableDict({"1": 1})
    var_1 = ImmutableDict({"1": 1})

    assert var_0 == var_1

    # initialization
    var_0 = ImmutableDict({"1": 1})
    var_1 = ImmutableDict({})

    assert not var_0 == var_1

    # initialization
    var_0 = ImmutableDict({})
    var_1 = ImmutableDict({"1": 1})

    assert not var_0 == var_1

    # initialization
    var_0 = ImmutableDict({"1": 1})
    var_1 = ImmutableDict