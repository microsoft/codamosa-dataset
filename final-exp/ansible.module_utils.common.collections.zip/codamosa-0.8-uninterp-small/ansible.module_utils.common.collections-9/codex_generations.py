

# Generated at 2022-06-24 20:14:48.881748
# Unit test for function is_iterable
def test_is_iterable():
    # BAD
    assert is_iterable('{}')
    assert is_iterable('')
    # GOOD
    assert not is_iterable(1)
    assert not is_iterable(None)

# Generated at 2022-06-24 20:14:54.961996
# Unit test for function is_iterable
def test_is_iterable():
    iterable = [1, 2, 3]
    assert is_iterable(iterable) is True
    assert is_iterable(str) is False
    assert is_iterable(str, include_strings=True) is True

# Generated at 2022-06-24 20:14:59.234333
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_input = {'k1': 'v1', 'k2': 'v2', 'k3': 'v3'}
    immutable_dict = ImmutableDict(test_input)
    assert immutable_dict.difference(['k2']) == ImmutableDict({'k1': 'v1', 'k3': 'v3'})


# Generated at 2022-06-24 20:15:03.936153
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('string')
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(range(0, 10))


# Generated at 2022-06-24 20:15:08.130266
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    args = (1, 2)
    kwargs = {'a': 3, 'b': 4}
    im_d = ImmutableDict(*args, **kwargs)
    assert im_d.difference((2, 3)) == ImmutableDict({'a': 3, 'b': 4, 1: 2})


# Generated at 2022-06-24 20:15:18.085466
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    str_0 = '_r'
    lst_0 = [1, 'b', 'c']
    lst_1 = [2, 'b']
    dct_0 = ImmutableDict(a='a', b='b', c='c')
    dct_1 = ImmutableDict(a='a')
    dct_2 = ImmutableDict(a=1)
    dct_3 = ImmutableDict(a=1, b=1)
    # Test that only keys in the subtractive_iterable are not in the resulting ImmutableDict
    assert dct_0.difference(str_0) == ImmutableDict(a='a', b='b', c='c')

# Generated at 2022-06-24 20:15:25.254027
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    dict_0 = ImmutableDict(a='b', c='d', e='f')
    dict_1 = dict_0.difference(['a'])
    str_0 = 'c'
    str_1 = 'e'
    str_2 = 'f'
    assert dict_1[str_0] == 'd'
    assert dict_1[str_1] == str_2


# Generated at 2022-06-24 20:15:28.657487
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_1 = ImmutableDict()
    assert dict_0.__eq__(dict_1) == dict_1.__eq__(dict_0)


# Generated at 2022-06-24 20:15:31.671506
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = 'drained'
    var_0 = count(str_0)
    flag_0 = True
    if is_iterable(var_0):
        flag_0 = False
    assert flag_0 == False



# Generated at 2022-06-24 20:15:40.714769
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1, 'b': 2}, c=3, d=4)
    d2 = ImmutableDict({'a': 1, 'b': 2}, c=3, d=4)
    assert d1 == d2  # Matching items
    assert not d1 == 'd1'  # Non-mapping

    d4 = ImmutableDict({'a': 1, 'b': 2}, c=3, d=4)
    d3 = ImmutableDict({'a': 1, 'b': 2}, c=3)
    assert not d3 == d4  # Different items
    

# Generated at 2022-06-24 20:15:51.298309
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d = ImmutableDict(a=1, b='two', c=3.0)
    assert d == d
    assert not d == {}
    assert not d == {'a': 2}
    assert d == {'a': 1, 'b': 'two', 'c': 3.0}
    assert not d == {'a': 1, 'b': 'two', 'c': 3.0, 'd': 4}
    assert not d == [('a', 1), ('b', 'two'), ('c', 3.0)]


# Generated at 2022-06-24 20:15:53.262770
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = 'drained'
    var_0 = is_iterable(str_0)


# Generated at 2022-06-24 20:15:57.898229
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(immutable_dict_0)
    assert is_iterable(str_1)
    assert is_iterable(str_2)
    assert is_iterable(str_3)


# Generated at 2022-06-24 20:15:59.282168
# Unit test for function is_iterable
def test_is_iterable():
	assert(is_iterable(str_0) == True)


# Generated at 2022-06-24 20:16:01.145203
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = 'some\ntext'
    var_0 = is_iterable(str_0)
    assert var_0 == True


# Generated at 2022-06-24 20:16:09.610965
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    ####
    # Testing simple comparison
    i_d_0 = ImmutableDict(test_0=0, test_1=1)
    assert i_d_0 == i_d_0

    ####
    # Testing comparison with copy of class object
    i_d_1 = i_d_0
    assert i_d_1 == i_d_0
    assert i_d_0 == i_d_1

    ####
    # Testing comparison with immutable dictionary
    i_d_2 = ImmutableDict(test_0=0, test_1=1)
    assert i_d_2 == i_d_0
    assert i_d_0 == i_d_2

    ####
    # Testing comparison with mutable dictionary

# Generated at 2022-06-24 20:16:11.055270
# Unit test for function is_iterable
def test_is_iterable():
    data = [5, 6, 7, 8, 9, 10]
    assert is_iterable(data)


# Generated at 2022-06-24 20:16:18.500577
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(list())
    assert is_iterable([1, 2, 3, 4])
    assert not is_iterable(1)
    assert not is_iterable({'a': 1, 'b': 2})
    assert is_iterable(tuple())
    assert not is_iterable(tuple('abc'))
    assert is_iterable((1, 2, 3, 4))
    assert not is_iterable('abcd')
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable(set((1, 2, 3)))
    assert is_iterable(frozenset([7, 6, 5, 4]))
    assert is_iterable(frozenset((3, 2, 1)))
    assert is_

# Generated at 2022-06-24 20:16:24.816133
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable((1,2,3)) == True
    assert is_iterable('My String') == True
    assert is_iterable(['My String']) == True
    assert is_iterable({'a':1, 'b':2}) == True
    assert is_iterable(1) == False



# Generated at 2022-06-24 20:16:29.566058
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immu_dict_b = ImmutableDict({'key_b': 'value_b'})
    immu_dict_a = ImmutableDict({'key_a': 'value_a'})
    assert immu_dict_a == immu_dict_b == ImmutableDict({'key_b': 'value_b'})
    assert immu_dict_a != immu_dict_b != ImmutableDict({'key_c': 'value_c'})


# Generated at 2022-06-24 20:16:35.137517
# Unit test for function is_iterable
def test_is_iterable():
    result = is_iterable(['test', 'is', 'iterable'])
    assert result is True



# Generated at 2022-06-24 20:16:40.105987
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    pass #TODO: test method __eq__ of class ImmutableDict



# Generated at 2022-06-24 20:16:46.153523
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict()
    var_0['key'] = 45
    var_0['key2'] = 46
    var_1 = ImmutableDict()
    var_1['key'] = 45
    var_1['key2'] = 46
    assert var_0 == var_1


# Generated at 2022-06-24 20:16:51.209741
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    Immut_0 = ImmutableDict({'k': 0, 'j': 1, 'l': 2})
    Immut_1 = ImmutableDict({'j': 1, 'l': 2, 'k': 0})
    Immut_1.__eq__(Immut_0)
    Immut_0.__eq__(Immut_1)
    Immut_0.__eq__(str_0)


# Generated at 2022-06-24 20:16:54.976854
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_1 = ImmutableDict(var_0)
    var_1 = ImmutableDict(var_0)
    var_2 = var_1.__eq__(var_0)
    var_2 = var_1.__eq__(var_0)
    var_3 = var_1.__eq__(var_0)
    var_3 = var_1.__eq__(var_0)


# Generated at 2022-06-24 20:17:01.662695
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict().__eq__({}) == True
    assert ImmutableDict({'a': 'b'}).__eq__({}) == False
    assert ImmutableDict().__eq__({'a': 'b'}) == False
    assert ImmutableDict({'a': 'b'}).__eq__({'a': 'b'}) == True
    assert ImmutableDict({'a': 'b', 'c': 'd'}).__eq__({'a': 'b'}) == False
    assert ImmutableDict({'a': 'b'}).__eq__({'a': 'b', 'c': 'd'}) == False
    assert ImmutableDict({'a': 'c'}).__eq__({'a': 'b'}) == False

# Generated at 2022-06-24 20:17:06.284561
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable(['1', '2', '3']))
    assert(not is_iterable('drained'))
    assert(not is_iterable(1))
    assert(not is_iterable(True))
    assert(not is_iterable(None))



# Generated at 2022-06-24 20:17:10.049598
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = 'drained'
    assert is_iterable(str_0, False) == True
    str_0 = 'drained'
    assert is_iterable(str_0, True) == True


# Generated at 2022-06-24 20:17:13.289023
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_1 = ImmutableDict(var_0)
    var_2 = ImmutableDict()
    assert var_1.__eq__(var_2)


# Generated at 2022-06-24 20:17:22.346832
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    mocked_frozenset = ['a','b','c']
    mocked_self_hash = 'xyz'
    mocked_other_hash = 'abc'
    mocked_self_store = {'a':'b'}
    mocked_other_store = {'b':'c'}
    mocked_self_hash_exception = {'a':'b'}
    mocked_other_hash_exception = {'b':'c'}
    mocked_typ_exception = 'mocked_typ_exception'
    mocked_other = {'a':'b'}
    mocked_other_iter = {'a':'b'}
    mocked_other_typ_exception = 'mocked_other_typ_exception'


# Generated at 2022-06-24 20:17:31.972342
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    obj_0 = ImmutableDict({'foo': 'bar'})
    obj_1 = ImmutableDict({'baz': 'quux'})
    obj_2 = ImmutableDict({'foo': 'bar'})
    assert obj_0 != obj_1
    assert obj_0 == obj_2


# Generated at 2022-06-24 20:17:43.217536
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = 'is_iterable'
    var_1 = is_iterable(str_0)
    str_1 = 'is_iterable_is_iterable_is_iterable_is_iterable'
    list_0 = [str_0, str_1]
    var_2 = is_iterable(list_0)
    list_1 = [str_0, str_1, list_0, var_1]
    var_3 = is_iterable(list_1)
    var_4 = is_iterable(var_1)
    str_2 = 'is_iterable_is_iterable_is_iterable_is_iterable_is_iterable'
    list_2 = [str_0, str_1, str_2]

# Generated at 2022-06-24 20:17:45.906169
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    str_0 = 'drained'
    str_1 = 'nictitate'
    var_0 = ImmutableDict({str_0: str_1})
    str_2 = 'drained'
    str_3 = 'nictitate'
    var_1 = ImmutableDict({str_2: str_3})
    assert var_0.__eq__(var_1) == True


# Generated at 2022-06-24 20:17:50.089047
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) == True
    assert is_iterable(()) == True
    assert is_iterable({}) == True
    assert is_iterable(set()) == True
    assert is_iterable(0) == False
    assert is_iterable(False) == False
    assert is_iterable(True) == False


# Generated at 2022-06-24 20:17:59.968788
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    if ImmutableDict(ImmutableDict(dict_0)) != ImmutableDict(dict_0):
        raise Exception("ImmutableDict does not equal itself")
    dict_1 = ImmutableDict(dict_0)
    if dict_1 != dict_0:
        raise Exception("ImmutableDict does not equal equivalent dict")
    dict_0_orig = dict(dict_0)
    dict_0["key"] = "value"
    if dict_0 == dict_1:
        raise Exception("ImmutableDict still equals equivalent dict after it has changed")
    dict_1["key"] = "different_value"
    if dict_0 == dict_1:
        raise Exception("ImmutableDict still equals equivalent dict after it has changed differently")
    dict_0 = dict_

# Generated at 2022-06-24 20:18:06.742191
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import os
    import sys
    import unittest
    from random import randrange

    from contextlib import redirect_stderr
    from io import StringIO

    from ansible.module_utils.six import PY3

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestImmutableDict(unittest.TestCase):

        def test_immutable_dict_key_value(self):
            from ansible.module_utils._text import to_text
            test_dict = {'a': 1}
            immutable_dict = ImmutableDict(test_dict)
            self.assertEqual(immutable_dict['a'], test_dict['a'])


# Generated at 2022-06-24 20:18:08.478866
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    result = ImmutableDict() == ImmutableDict()
    assert result


# Generated at 2022-06-24 20:18:13.170777
# Unit test for function is_iterable
def test_is_iterable():
    iterable_vars = [
        [1, 2, 3],
        ('foo', 'bar'),
        {'apple': 1, 'pear': 2},
        range(5),
        set([1, 2, 2, 3]),
        'drained'
    ]

    for var in iterable_vars:
        assert is_iterable(var)

    non_iterable_vars = [1, 12.5, set(), True]

    for var in non_iterable_vars:
        assert not is_iterable(var)

    # test case for is_iterable(seq, include_strings=False)
    assert is_iterable(iterable_vars[-1], include_strings=True)
    assert not is_iterable(iterable_vars[-1])



# Generated at 2022-06-24 20:18:19.126124
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    str_0 = 'hash'
    ImmutableDict_0 = ImmutableDict({'home_host': 'localhost', 'salt_netapi_auth': str_0}, home_port=4505)
    bool_0 = ImmutableDict_0 == ImmutableDict({'home_host': 'localhost', 'salt_netapi_auth': str_0}, home_port=4505)
    print(bool_0)


# Generated at 2022-06-24 20:18:27.457120
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict(a='a', b='b')
    var_1 = ImmutableDict(b='b', a='a')
    assert var_0 == var_1
    var_0 = ImmutableDict(a='a', b='b')
    var_2 = ImmutableDict(b='c', a='a')
    assert var_0 != var_2
    var_0 = ImmutableDict(a='a', b='b')
    var_3 = ImmutableDict(b='c', a='a', c='c')
    assert var_0 != var_3


# Generated at 2022-06-24 20:18:40.237815
# Unit test for function is_iterable
def test_is_iterable():
    assert True == is_iterable([])
    assert True == is_iterable({})
    assert False == is_iterable('foo')
    assert False == is_iterable(5)



# Generated at 2022-06-24 20:18:49.675447
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    str_0 = 'assiduity'
    str_1 = 'validity'
    str_2 = 'validity'
    dict_0 = ImmutableDict()
    dict_1 = ImmutableDict()
    dict_1 = ImmutableDict(dict_1)
    dict_1 = ImmutableDict(dict_1)
    dict_1 = ImmutableDict(dict_1)
    dict_1 = ImmutableDict(dict_1)
    dict_1 = ImmutableDict(dict_1)
    dict_1 = ImmutableDict(dict_1)
    dict_1 = ImmutableDict(dict_1)
    dict_1 = ImmutableDict(dict_1)
    dict_1 = ImmutableDict(dict_1)

# Generated at 2022-06-24 20:18:53.082257
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = 'ansible'
    str_1 = 'ansible'
    var_0 = is_iterable(str_0)
    var_1 = is_iterable(str_1)


# Generated at 2022-06-24 20:19:01.437594
# Unit test for function is_iterable
def test_is_iterable():
    res = is_iterable(str())
    assert res is True
    res = is_iterable(list())
    assert res is True
    res = is_iterable(dict())
    assert res is True
    res = is_iterable(bool())
    assert res is False
    res = is_iterable(int())
    assert res is False
    res = is_iterable(set())
    assert res is True
    res = is_iterable(10)
    assert res is False
    res = is_iterable('abc')
    assert res is True


# Generated at 2022-06-24 20:19:11.744247
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_1 = {'a': 'apple', 'b': 'bear', 'c': 'camel'}
    dict_2 = {'a': 'apple', 'b': 'bear', 'c': 'camel'}
    dict_3 = {'c': 'camel', 'a': 'apple', 'b': 'bear'}
    dict_4 = {'a': 'apple', 'b': 'bear', 'c': 'camel', 'd': 'duck'}
    dict_5 = {'a': 'apple', 'b': 'bear'}
    dict_6 = {'a': 'apple', 'b': 'bear', 'c': 'camel', 'd': 'duck'}

# Generated at 2022-06-24 20:19:15.709933
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1,2,3,4])
    assert not is_iterable('str')
    assert is_iterable({1:'1',2:'2',3:'3'})
    assert is_iterable({})
    assert not is_iterable(1)



# Generated at 2022-06-24 20:19:23.191067
# Unit test for function is_iterable
def test_is_iterable():
    test_string = 'this is a test'
    assert is_iterable(test_string) is True

    test_int = 4
    assert is_iterable(test_int) is False

    test_list = ['a', 'b', 'c']
    assert is_iterable(test_list) is True

    test_dict = {
        'k1': 'v1',
        'k2': 'v2',
        'k3': 'v3',
    }
    assert is_iterable(test_dict) is True



# Generated at 2022-06-24 20:19:29.965402
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = {'d': 'd', 'b': 'b', 'g': 'f', 'a': 'e'}
    dict_1 = {'a': 'e', 'd': 'd', 'b': 'b', 'g': 'f'}
    dict_2 = {'a': 'e', 'd': 'd', 'b': 'b', 'g': 'f', 'z': 'c'}
    dict_3 = {'a': 'e', 'd': 'd', 'b': 'b', 'g': 'f'}
    var_0 = ImmutableDict(**dict_2)
    var_1 = ImmutableDict(**dict_3)
    assert var_0 == var_1


# Generated at 2022-06-24 20:19:32.225930
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    param_0 = ImmutableDict(a=1, b=2, c=3)
    param_1 = ImmutableDict(a=1, b=2, c=3)
    try:
        assert param_0 == param_1
    except AssertionError:
        raise


# Generated at 2022-06-24 20:19:40.858149
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    obj_0 = ImmutableDict({u'AAA': u'Bee', u'CCC': u'dee'})
    obj_1 = ImmutableDict({u'CCC': u'dee', u'BBB': u'Dog', u'AAA': u'Bee'})
    bool_0 = obj_0 == obj_1
    obj_0 = ImmutableDict({u'DDD': u'Geek', u'BBB': u'Gog'})
    obj_1 = ImmutableDict({u'CCC': u'Bee', u'BBB': u'Dog', u'AAA': u'fee'})
    bool_1 = obj_0 == obj_1

# Generated at 2022-06-24 20:20:02.313039
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable((4, 5, 6))
    assert is_iterable({'a': 1, 'b': 2})
    assert not is_iterable(1)
    assert not is_iterable('a string')



# Generated at 2022-06-24 20:20:03.499015
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_case_0()

# Generated at 2022-06-24 20:20:12.677921
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([], False)
    assert is_iterable(['a'], False)
    assert is_iterable(('a', 'b'), False)
    assert is_iterable({}, False)
    assert is_iterable({'a':'b'}, False)
    assert is_iterable(set(), False)
    assert is_iterable(set(['a']), False)
    assert is_iterable(range(1), False)

    assert is_iterable('', False)
    assert is_iterable('a', False)
    assert is_iterable(u'', False)
    assert is_iterable(u'a', False)

    assert not is_iterable('', True)
    assert is_iterable('a', True)
    assert not is_iterable(u'', True)


# Generated at 2022-06-24 20:20:17.637398
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    input_d_1 = ImmutableDict({'1': 1, '2': 2})
    input_d_2 = ImmutableDict({'2': 2, '1': 1})
    input_d_3 = ImmutableDict({'2': 2})
    input_d_4 = ImmutableDict({'3': 3})
    input_d_5 = {'1': 1, '2': 2}
    input_d_6 = {'2': 2}
    test_1 = input_d_1.__eq__(input_d_2)
    test_2 = input_d_1.__eq__(input_d_3)
    test_3 = input_d_1.__eq__(input_d_4)

# Generated at 2022-06-24 20:20:24.735402
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('my_var') is False
    assert is_iterable('my_var', include_strings=True) is True
    assert is_iterable(('my_var', 0)) is True
    assert is_iterable([]) is True
    assert is_iterable({}) is True
    assert is_iterable(1) is False


# Generated at 2022-06-24 20:20:29.232889
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable('test') == False)
    assert(is_iterable(['test','test']) == True)
    assert(is_iterable([1,2,3]) == True)
    assert(is_iterable(['test', 1]) == True)
    assert(is_iterable(set('test')) == True)
    assert(is_iterable({'test':'test'}) == True)

# Generated at 2022-06-24 20:20:34.738525
# Unit test for function is_iterable
def test_is_iterable():
    pass
    assert is_iterable((1, 2))
    assert not is_iterable('test')
    assert is_iterable(['test', 'me'])
    assert is_iterable({'test': 1})
    assert not is_iterable(9)
    assert is_iterable(set([1, 2]))
    assert not is_iterable(1)


# Generated at 2022-06-24 20:20:40.681898
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    str_0 = 'fired'
    int_0 = 2
    obj_0 = ImmutableDict()
    obj_0._store = {str_0: int_0}
    obj_1 = ImmutableDict()
    obj_1._store = {str_0: int_0}
    bool_0 = obj_0.__eq__(obj_1)
    assert bool_0


# Generated at 2022-06-24 20:20:42.134860
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = 'drained'
    var_0 = is_iterable(str_0)



# Generated at 2022-06-24 20:20:50.809624
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}
    assert {'b': 2, 'a': 1} == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert {'a': 1, 'b': 2} != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert {'a': 1, 'b': 2, 'c': 3} != ImmutableDict({'a': 1, 'b': 2})
   

# Generated at 2022-06-24 20:21:35.926697
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('abc')
    assert is_iterable([1, 'a', 3, 'b'])
    assert is_iterable((1, 'a', 3, 'b'))
    assert is_iterable({'a': 1, 'b': 2})

    assert not is_iterable(None)
    assert not is_iterable(123)



# Generated at 2022-06-24 20:21:45.306280
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    str_0 = 'rqfqrq'
    str_1 = 'rrnnyt'
    var_0 = ImmutableDict({(1, 2, 1): 'zjfz'})
    str_2 = 'pk'
    str_3 = 'wc'
    var_1 = ImmutableDict({(1, 2, 1): 'zjfz'})
    var_2 = ImmutableDict({str_0: str_1})
    var_3 = ImmutableDict({str_2: str_3})
    str_5 = 'av'
    str_6 = 'jd'
    var_4 = ImmutableDict({str_5: str_6})
    assert ((var_0 == var_0) is True)

# Generated at 2022-06-24 20:21:49.115933
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('iterable')
    assert is_iterable(['list'])
    assert is_iterable(('tuple'))
    assert is_iterable({'dictionary': 'value'})
    assert not is_iterable(1)
    assert not is_iterable(object)


# Generated at 2022-06-24 20:21:54.992454
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(range(4))
    assert is_iterable([1, 2, 3, 4])
    assert is_iterable(set([1, 2, 3, 4]))

    assert is_iterable(range(0))
    assert is_iterable([])
    assert is_iterable(set())

    assert is_iterable(ImmutableDict({}))
    assert is_iterable(ImmutableDict({'a': 1, 'b': 2}))

    assert not is_iterable(object())
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(1.1)



# Generated at 2022-06-24 20:22:01.053713
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('1') is True
    assert is_iterable([]) is True
    assert is_iterable((1,2,3)) is True
    assert is_iterable(1) is False
    assert is_iterable([i for i in range(10)]) is True
    assert is_iterable({i for i in range(10)}) is True
    assert is_iterable({'1': 2}) is True
    assert is_iterable(2) is False
    assert is_iterable(object) is False


# Generated at 2022-06-24 20:22:02.120325
# Unit test for function is_iterable
def test_is_iterable():
    seq = [1, 2]
    assert seq is iterable


# Generated at 2022-06-24 20:22:06.562544
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    # Run test.
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})

    # Run test.
    assert not ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 3})



# Generated at 2022-06-24 20:22:10.264314
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dic_0 = ImmutableDict()
    if dic_0 == dict():
        print('UnitTest: ' + 'Passed')
    else:
        print('UnitTest: ' + 'Failed')


# Generated at 2022-06-24 20:22:18.864521
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = 'drained'
    var_0 = is_iterable(str_0)
    assert (var_0)
    dict_0 = dict()
    dict_0['str_0'] = 'str_0'
    dict_0['dict_0'] = dict(dict_0)
    dict_0['list_0'] = [dict_0['str_0']]
    dict_0['tuple_0'] = (dict_0['dict_0'], dict_0['list_0'])
    dict_0['set_0'] = set({dict_0['tuple_0']})
    dict_0['var_0'] = dict_0.values()
    var_0 = is_iterable(var_0)
    assert (var_0)

# Generated at 2022-06-24 20:22:24.423582
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    bool_0 = ImmutableDict().__eq__(ImmutableDict())
    bool_1 = ImmutableDict().__eq__('d')
    bool_2 = ImmutableDict().__eq__(ImmutableDict())
    bool_3 = ImmutableDict().__eq__('d')


# Generated at 2022-06-24 20:24:02.376882
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = 'drained'
    assert is_iterable(str_0) == True
    assert is_iterable(str_0, True) == True
    # assert is_iterable(str_0, False) == False


# Generated at 2022-06-24 20:24:10.364169
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    str_0 = 'TQZrK6'
    var_0 = ImmutableDict({'id': '1', 'name': 'test1', 'age': '23', 'sex': 'f'})
    var_1 = ImmutableDict({'id': '1', 'name': 'test1', 'age': '23', 'sex': 'f'})
    var_2 = ImmutableDict({'id': '2', 'name': 'test2', 'age': '24', 'sex': 'm'})
    var_3 = ImmutableDict({'id': '1', 'name': 'test1', 'age': '23', 'sex': 'f'})
    assert var_0.__eq__(var_1) == True
    assert var_0.__eq__(var_2) == False
    assert var

# Generated at 2022-06-24 20:24:17.083245
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    Imm_Dict_0 = ImmutableDict(["milk", "breakfast"], ["eggs", "breakfast"], ["bread", "breakfast"], ["banana", "fruit"])
    Imm_Dict_1 = ImmutableDict(["milk", "breakfast"], ["eggs", "breakfast"], ["bread", "breakfast"], ["banana", "fruit"])
    boolean_var_0 = Imm_Dict_0 == Imm_Dict_1
    assert boolean_var_0


# Generated at 2022-06-24 20:24:21.979183
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable({1, 2, 3}) == True, "Testcase Failed"
    assert is_iterable([1, 2, 3]) == True, "Testcase Failed"
    assert is_iterable(range(10)) == True, "Testcase Failed"
    assert is_iterable(1) == False, "Testcase Failed"

# Generated at 2022-06-24 20:24:27.973602
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1,2,3,4])
    assert is_iterable((1,2,3,4))
    assert is_iterable(range(1,4))
    assert is_iterable({'a':1,'c':2})
    assert is_iterable(set([1,2,3,4]))
    assert not is_iterable(5)
    assert not is_iterable('d')
    assert not is_iterable(None)


# Generated at 2022-06-24 20:24:32.942080
# Unit test for function is_iterable
def test_is_iterable():
    # Test with an integer argument
    int_0 = 5
    expect_0 = False
    res_0 = is_iterable(int_0)
    assert res_0 == expect_0

    # Test with a string argument
    res_1 = str
    expect_1 = True
    res_1 = is_iterable(res_1)
    assert res_1 == expect_1

    # Test with a list argument
    list_0 = []
    expect_2 = True
    res_2 = is_iterable(list_0)
    assert res_2 == expect_2



# Generated at 2022-06-24 20:24:38.262118
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_1 = ImmutableDict({'a': 1, 'b': 2})
    dict_2 = ImmutableDict({'a': 1, 'b': 1, 'c': 3})
    dict_3 = ImmutableDict({'a': 1, 'b': 2})
    dict_4 = ImmutableDict()

    assert dict_1 == dict_1
    assert dict_1 != dict_2
    assert dict_1 == dict_3
    assert dict_1 != dict_4
    assert dict_2 != dict_3
    assert dict_2 != dict_4
    assert dict_3 != dict_4


# Generated at 2022-06-24 20:24:40.108535
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict(a=1)
    var_1 = ImmutableDict(a=1)
    assert var_0.__eq__(var_1) == True


# Generated at 2022-06-24 20:24:47.000075
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('test') == True
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable({'a': 1, 'b': 2}) == True
    assert is_iterable(1) == False
    assert is_iterable((1, 2)) == True
    assert is_iterable(None) == False
    assert is_iterable(True) == False
    assert is_iterable(b'test') == True
    assert is_iterable(set([])) == True
    assert is_iterable(set([1])) == True
    assert is_iterable(set(['a'])) == True
    assert is_iterable(binary_type(b"")) == True
    assert is_iterable(text_type("")) == True
