

# Generated at 2022-06-24 20:14:52.684248
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    obj = ImmutableDict()
    assert True == obj.__eq__(obj)


# Generated at 2022-06-24 20:14:59.019390
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_dict = ImmutableDict({'test': 'dict'})
    test_dict2 = ImmutableDict({'test': 'dict'})
    test_dict3 = ImmutableDict({'test': 'dict3'})
    assert test_dict == test_dict2
    assert test_dict != test_dict3
    assert test_dict == {'test': 'dict'}
    assert test_dict != {'test': 'dict3'}
    assert test_dict != {'test': 'dict', 'another': 'value'}

# Generated at 2022-06-24 20:15:09.322496
# Unit test for function is_iterable
def test_is_iterable():
    # Iterable
    assert is_iterable(list())
    assert is_iterable(tuple())
    assert is_iterable(dict())
    assert is_iterable(set())
    assert is_iterable(lazy_iterator())
    assert is_iterable(range(5))
    assert is_iterable(xrange(5))

    # Strings
    assert is_iterable('')
    assert is_iterable('abc')
    assert is_iterable(b'abc')
    assert is_iterable(u'abc')

    # Numbers
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(-1)
    assert not is_iterable(-1.0)

    # Bool

# Generated at 2022-06-24 20:15:13.776092
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    params = tuple()
    kwargs = {
        u'args': params,
    }

    idict_0 = ImmutableDict(*params, **kwargs)
    assert ImmutableDict.__eq__(idict_0, idict_0)



# Generated at 2022-06-24 20:15:19.169192
# Unit test for function is_iterable
def test_is_iterable():
    # Test case as string
    assert is_iterable('12345') == True

    # Test case as a list
    assert is_iterable(['2', '3']) == True

    # Test case as a tuple
    assert is_iterable(('2', '3')) == True

    # Test case as a set
    assert is_iterable(set(['2', '3'])) == True

    # Test case as a dictionary
    assert is_iterable({'a':'1', 'b':'2'}) == True

    # Test case as an int
    assert is_iterable(1) == False


# Generated at 2022-06-24 20:15:22.509672
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    assert dict_0 == ImmutableDict()


# Generated at 2022-06-24 20:15:28.955630
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(dict()), 'Expected dict() to be iterable'
    assert is_iterable(list()), 'Expected list() to be iterable'
    assert is_iterable(set()), 'Expected set() to be iterable'
    assert not is_iterable(123), 'Expected integer 123 not to be iterable'
    assert not is_iterable('string'), 'Expected string not to be iterable'

# Unit tests for function is_sequence

# Generated at 2022-06-24 20:15:38.900942
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_1 = ImmutableDict({'key_0': 'value_0'})
    var_2 = ImmutableDict({'key_0': 'value_0'})
    var_3 = ImmutableDict({'key_1': 'value_1'})
    var_4 = 'value_0'
    var_5 = False
    if var_1 == var_2:
        var_5 = True
    var_6 = False
    if var_1 == var_3:
        var_6 = True
    var_7 = False
    if var_2 == var_3:
        var_7 = True
    var_8 = False
    if var_1 == var_4:
        var_8 = True
    var_9 = False
    if var_2 == var_4:
        var_9

# Generated at 2022-06-24 20:15:42.179510
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('abc')
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))

    assert not is_iterable(2)
    assert not is_iterable(None)



# Generated at 2022-06-24 20:15:46.434105
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable('test')  # string is not an iterable
    assert not is_iterable('test', True)  # string is not an iterable
    assert is_iterable({'test': 'test'})  # dict is iterable
    assert is_iterable([1, 2, 3, 4])  # list is iterable
    assert is_iterable((1, 2, 3, 4))  # tuple is iterable



# Generated at 2022-06-24 20:15:53.754773
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict(('test', 'test'), **{})
    dict_1 = ImmutableDict(('test', 'test'), **{})
    assert True == (dict_0 == dict_1)


# Generated at 2022-06-24 20:16:00.870883
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('foo')
    assert is_iterable(['foo', 'bar'])
    assert is_iterable(('foo', 'bar', 'baz'))
    assert is_iterable({'foo': 'bar'})
    assert not is_iterable(1)
    assert not is_iterable(None)
    assert not is_iterable(object())
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable(object())


# Generated at 2022-06-24 20:16:04.651712
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Create two ImmutableDict instances
    test_immutable_1 = ImmutableDict({1: 1, 2: 2, 3: 3})
    test_immutable_2 = ImmutableDict({3: 3, 2: 2, 1: 1})

    # This assertion should be True as the two ImmutableDict instances are equal
    assert(test_immutable_1 == test_immutable_2)



# Generated at 2022-06-24 20:16:08.423072
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    tpl0 = (None,)
    par0 = ImmutableDict(tpl0)
    par0 = par0.__eq__(tpl0)


# Generated at 2022-06-24 20:16:14.420262
# Unit test for function is_iterable
def test_is_iterable():
    var_0 = ImmutableDict(a=1)
    var_1 = is_iterable(var_0)
    var_2 = ImmutableDict()
    var_3 = is_iterable(var_2)
    var_4 = is_iterable('test')
    var_5 = is_iterable(None)


# Generated at 2022-06-24 20:16:16.151830
# Unit test for function is_iterable
def test_is_iterable():
    tuple_0 = None
    var_0 = is_iterable(tuple_0)


# Generated at 2022-06-24 20:16:24.170863
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({"f"}, "z", "t", 1, "z")
    dict_1 = ImmutableDict({"w"}, "z", "t", 1, "z")
    bool_0 = (dict_0 == dict_1)
    #
    dict_2 = ImmutableDict({"t", "f", "z", "z"}, 1)
    dict_3 = ImmutableDict({"f"}, "z", "t", 1, "z")
    bool_1 = (dict_2 == dict_3)


# Generated at 2022-06-24 20:16:26.317507
# Unit test for function is_iterable
def test_is_iterable():
    tuple_0 = None
    bool_0 = is_iterable(tuple_0)
    assert bool_0 == False


# Generated at 2022-06-24 20:16:36.657627
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = dict()
    dict_1 = dict()
    dict_1['a'] = 1
    dict_1['b'] = 2
    dict_2 = dict()
    dict_2['a'] = 1
    dict_2['c'] = 3
    dict_3 = dict()
    dict_3['a'] = 2
    dict_4 = dict()
    dict_4['a'] = 2
    dict_4['b'] = 2
    dict_5 = dict()
    dict_5['a'] = 2
    dict_5['c'] = 3
    dict_6 = dict()
    dict_6['a'] = 1
    dict_6['b'] = 2
    dict_7 = dict()
    dict_7['a'] = 1
    dict_7['c'] = 2

# Generated at 2022-06-24 20:16:41.722958
# Unit test for function is_iterable
def test_is_iterable():
    """Test function is_iterable"""
    # Test the function with an iterable (str)
    iterable = 'Test'
    expected_result = True
    assert is_iterable(iterable) == expected_result



# Generated at 2022-06-24 20:16:53.567903
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Case 1
    tuple_0 = None
    dict_0 = ImmutableDict(tuple_0)
    var_0 = dict_0.__eq__(dict_0)
    assert var_0 == False
    # Case 2
    tuple_0 = None
    dict_0 = ImmutableDict(tuple_0)
    dict_1 = ImmutableDict(Hashable)
    var_0 = dict_0.__eq__(dict_1)
    assert var_0 == True
    # Case 3
    tuple_0 = None
    dict_0 = ImmutableDict(tuple_0)
    dict_1 = ImmutableDict(Hashable)
    var_0 = dict_0.__eq__(dict_1)
    assert var_0 == True
    # Case 4
    tuple_0

# Generated at 2022-06-24 20:17:01.164276
# Unit test for function is_iterable
def test_is_iterable():
    # Test iterable args
    iterable_args = [([1, 2, 3],),
                     ({'key1': 'val1', 'key2': 'val2'},),
                     (('a', 'b', 'c'),)]

    for arg in iterable_args:
        if not is_iterable(arg):
            raise Exception('Argument %s should be iterable, but is not!' % arg)

    # Test non-iterable args
    non_iterable_args = ['string', 1, 1.1]
    for arg in non_iterable_args:
        if is_iterable(arg):
            raise Exception('Argument %s should not be iterable, but is!' % arg)

    # Test string args
    string_args = ['string', b'string', u'string']

# Generated at 2022-06-24 20:17:06.395541
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable(('a', 'b', 'c'))
    assert is_iterable({'key': 'val'})
    assert is_iterable('abc')
    assert not is_iterable(1)
    assert not is_iterable(True)



# Generated at 2022-06-24 20:17:06.861595
# Unit test for function is_iterable
def test_is_iterable():
    pass

# Generated at 2022-06-24 20:17:12.106821
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = dict()
    # dict_0 = ImmutableDict()
    dict_0 = ImmutableDict(dict_0)

    dict_1 = dict()
    dict_1 = ImmutableDict(dict_1)

    res_0 = ImmutableDict.__eq__(dict_0, dict_1)


# Generated at 2022-06-24 20:17:13.092668
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    obj = ImmutableDict()
    other = ImmutableDict()
    assert obj == other


# Generated at 2022-06-24 20:17:23.870006
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_0 = dict_0.union({'test1': 'test1', 'test2': 'test2'})
    dict_0 = ImmutableDict(dict_0)
    dict_1 = ImmutableDict()
    dict_1 = dict_1.union({'test1': 'test1', 'test2': 'test2'})
    dict_1 = ImmutableDict(dict_1)
    dict_0.__eq__(dict_1)
    dict_2 = ImmutableDict()
    dict_2 = dict_2.union({'test1': 'test1', 'test2': 'test2'})
    dict_2 = ImmutableDict(dict_2)
    dict_2.__eq__(dict_0)
    dict_3 = Imm

# Generated at 2022-06-24 20:17:28.965610
# Unit test for function is_iterable
def test_is_iterable():
    # test for string input
    assert is_iterable("") is True
    # test for dictionary input
    assert is_iterable({}) is True
    # test for list input
    assert is_iterable([]) is True
    # test for tuple input
    assert is_iterable(tuple()) is True
    # test for file input
    assert is_iterable(open("/dev/null")) is True
    # Negative Test
    assert is_iterable(1) is False
    assert is_iterable(True) is False
    assert is_iterable(open("/dev/null", 'rw+')) is False


# Generated at 2022-06-24 20:17:36.731899
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'a': 'b'})
    immutable_dict_1 = ImmutableDict({'c': 'd'})
    immutable_dict_2 = ImmutableDict({'a': 'b'})
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)
    var_1 = immutable_dict_0.__eq__(immutable_dict_2)


# Generated at 2022-06-24 20:17:45.600749
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict(**{'a': 2})
    dict_1 = ImmutableDict(**{'a': 2})
    dict_2 = ImmutableDict(**{'b': 2})
    dict_3 = ImmutableDict()
    dict_4 = ImmutableDict(**{'a': 3})
    dict_5 = ImmutableDict(**{'a': 2, 'b': 2})
    dict_6 = ImmutableDict(**{'b': 2, 'a': 2})
    dict_7 = dict(**{'a': 2})
    dict_8 = dict(**{'a': 2})
    dict_9 = dict(**{'b': 2})
    dict_10 = dict()
    dict_11 = dict(**{'a': 3})
    dict

# Generated at 2022-06-24 20:17:53.765273
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    obj_0 = ImmutableDict({'X': True})
    obj_1 = ImmutableDict({'X': True})
    # Note: ImmutableDict instances have no method __hash__,
    # but are hashable because they are immutable.
    # The hash algorithm is that hash(frozenset(self.items()))
    # is used to generate the hash from the hash of a
    # frozenset of the underlying dictionary items.
    # This is why we need to create a frozenset with
    # the same key-value pairs to compare two ImmutableDict instances.
    assert obj_0.__hash__() == hash(frozenset({'X': True}))
    assert obj_1.__hash__() == hash(frozenset({'X': True}))
    assert obj_0.__hash__

# Generated at 2022-06-24 20:18:04.148993
# Unit test for function is_iterable
def test_is_iterable():
    item_0 = 'abc'
    var_0 = is_iterable(item_0)
    assert var_0

    item_1 = ['a', 'b', 'c']
    var_1 = is_iterable(item_1)
    assert var_1

    item_2 = ('a', 'b', 'c')
    var_2 = is_iterable(item_2)
    assert var_2

    item_3 = {'a': 1, 'b': 2, 'c': 3}
    var_3 = is_iterable(item_3)
    assert var_3

    item_4 = {1, 2, 3}
    var_4 = is_iterable(item_4)
    assert var_4

    item_5 = 1

# Generated at 2022-06-24 20:18:05.842144
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict(**[])
    var_1 = ImmutableDict(**[])
    assert (var_0 == var_1)



# Generated at 2022-06-24 20:18:15.614257
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Initializing ImmutableDict instances
    tuple_0 = None
    tuple_1 = None
    tuple_2 = None
    tuple_3 = None
    tuple_4 = None
    tuple_5 = None
    tuple_6 = None
    tuple_7 = None
    tuple_8 = None
    immutable_dict_0 = ImmutableDict(tuple_0)
    immutable_dict_1 = ImmutableDict(tuple_1)
    immutable_dict_2 = ImmutableDict(tuple_2)
    immutable_dict_3 = ImmutableDict(tuple_3)
    immutable_dict_4 = ImmutableDict(tuple_4)
    immutable_dict_5 = ImmutableDict(tuple_5)
    immutable_dict_6 = ImmutableDict(tuple_6)


# Generated at 2022-06-24 20:18:19.576948
# Unit test for function is_iterable
def test_is_iterable():
    var_1 = list()
    var_1 = {'key_0': 'value_0', 'key_1': 'value_1'}
    var_1 = 'string_0'
    var_1 = is_iterable(var_1, True)
    var_1 = is_iterable(var_1, False)


# Generated at 2022-06-24 20:18:25.190211
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_0 = dict_0.union({'a': 1, 'b': 2})
    dict_1 = ImmutableDict()
    dict_1 = dict_1.union({'b': 2, 'a': 1})
    bool_0 = dict_0.__eq__(dict_1)
    assert bool_0


# Generated at 2022-06-24 20:18:29.012996
# Unit test for function is_iterable
def test_is_iterable():
    # Test that is_iterable returns true for a string
    assert is_iterable('foo')
    # Test that is_iterable returns false for a non iterable
    assert not is_iterable(1)
    # Test that is_iterable returns true for a list
    assert is_iterable([1, 2, 3])


# Generated at 2022-06-24 20:18:37.557342
# Unit test for function is_iterable
def test_is_iterable():
    # """Return type of is_iterable() is boolean."""
    assert is_iterable([1, 2, 3]) == True

    # """Return true for a non-empty iterable."""
    assert is_iterable([1, 2, 3]) == True

    # """Return False for an empty iterable."""
    assert is_iterable([]) == False

    # """Return false for an integer."""
    assert is_iterable(1) == False

    # """Return false for a string."""
    assert is_iterable("test_string") == False

    # """Return false for a string."""
    assert is_iterable("test_string") == False

    # """Return false for an integer."""
    assert is_iterable(1) == False

    # """Return true for an iterable string."""

# Generated at 2022-06-24 20:18:40.802319
# Unit test for function is_iterable
def test_is_iterable():
    dict_0 = dict()
    dict_0['foo'] = 'bar'
    dict_0['foobar'] = 'foobar'
    assert is_iterable(dict_0) is True
    assert is_iterable(None) is False
    assert is_iterable(dict_0['foo']) is False
    assert is_iterable(dict_0.values()) is True
    assert is_iterable(tuple()) is True


# Generated at 2022-06-24 20:18:44.067696
# Unit test for function is_iterable
def test_is_iterable():
    print("idtest_is_iterable")
    is_iterable_test_result = is_iterable("Test", True)
    print(is_iterable_test_result)


# Generated at 2022-06-24 20:18:54.473246
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('is_iterable')
    assert is_iterable([1,2])
    assert is_iterable((1,2))
    assert not is_iterable(1)


# Generated at 2022-06-24 20:19:00.934555
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({"jV7A8": "NRIH7"}, hjBxN="7x0S1", qHFum="0CpMu", D7eUZ="4mHD7")
    dict_1 = ImmutableDict({"jV7A8": "NRIH7"}, D7eUZ="4mHD7", hjBxN="7x0S1", qHFum="0CpMu")
    # return statement omitted, test passes


# Generated at 2022-06-24 20:19:05.039532
# Unit test for function is_iterable
def test_is_iterable():
    seq = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
    assert is_iterable(seq) == True


# Generated at 2022-06-24 20:19:11.136640
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(()) == True
    assert is_iterable(("ho", "ma", "pa", "te")) == True
    assert is_iterable({}) == True
    assert is_iterable({1: "one", 2: "two", 3: "three"}) == True
    assert is_iterable({1, 2, 3, 4}) == True
    assert is_iterable("text") == True
    assert is_iterable(34) == False


# Generated at 2022-06-24 20:19:13.602851
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_1 = ImmutableDict()
    bool_0 = dict_0 == dict_1
    assert bool_0 is False


# Generated at 2022-06-24 20:19:15.995414
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable("test") is True
    assert is_iterable("") is True
    assert is_iterable(12345) is False


# Generated at 2022-06-24 20:19:19.646339
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    tuple_0 = ImmutableDict({"a": "1", "b": "2", "c": "3"})
    tuple_1 = ImmutableDict({})
    if tuple_0 == tuple_1:
        raise Exception('ValueError: ImmutableDict.__eq__(a, b)')
    return tuple_0


# Generated at 2022-06-24 20:19:21.875335
# Unit test for function is_iterable
def test_is_iterable():
    value_0 = None
    bool_0 = is_iterable(value_0)


# Generated at 2022-06-24 20:19:29.814544
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    from collections import OrderedDict
    d = ImmutableDict([('key1', 'val1'), ('key2', 'val2')])
    m1 = {'key1': 'val1', 'key2': 'val2'}
    m2 = OrderedDict([('key1', 'val1'), ('key2', 'val2')])
    m3 = {'key1': 'val0', 'key2': 'val2'}
    m4 = {'key0': 'val0', 'key2': 'val2'}
    assert m1 == m2
    assert not m3 == m4
    assert m1 == d
    assert d == m1
    assert not m3 == d
    assert not d == m3


# Generated at 2022-06-24 20:19:34.729007
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    ImmutableDict___eq___obj_0 = ImmutableDict(None, None)
    ImmutableDict___eq___obj_1 = ImmutableDict(None, None)
    ImmutableDict___eq___obj_2 = ImmutableDict(dict(None, **None), **None)
    ImmutableDict___eq___ret_0 = ImmutableDict___eq___obj_0.__eq__(ImmutableDict___eq___obj_1)
    ImmutableDict___eq___ret_2 = ImmutableDict___eq___obj_1.__eq__(ImmutableDict___eq___obj_2)


# Generated at 2022-06-24 20:19:45.556070
# Unit test for function is_iterable
def test_is_iterable():
    string_iterable = 'string'
    assert is_iterable(string_iterable)
    assert is_iterable(string_iterable, include_strings=True)
    assert not is_iterable(string_iterable, include_strings=False)



# Generated at 2022-06-24 20:19:54.672658
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    '''Unit test for method __eq__ of ImmutableDict'''
    # Unit test for method __eq__ of class ImmutableDict
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})

    # Check that two ImmutableDicts are equal if they are the same object
    assert d == d

    # Check that two ImmutableDicts are equal if they have the same content
    d2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d == d2

    # Check that two ImmutableDicts are not equal if they have different
    # content
    d2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    assert d != d2

    # Check that two ImmutableDicts

# Generated at 2022-06-24 20:20:01.017339
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    equals_0 = ImmutableDict()
    equals_1 = ImmutableDict()
    equals_2 = equals_1
    equals_3 = ImmutableDict()
    tuple_0 = None
    var_0 = equals_1.__eq__(tuple_0)
    var_1 = equals_2.__eq__(equals_3)
    var_2 = equals_0.__eq__(equals_1)


# Generated at 2022-06-24 20:20:08.764271
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert not is_iterable({1: 2, 3: 4})
    assert is_iterable([1, 2, 3], include_strings=True)
    assert is_iterable("abcdefg", include_strings=True)
    assert not is_iterable("abcdefg")
    assert is_iterable((1, 2, 4))
    assert is_iterable((1, 2, 4), include_strings=True)


# Generated at 2022-06-24 20:20:15.210017
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    arg_0 = dict()
    arg_0['key_0'] = 'val_0'
    arg_0['key_1'] = 'val_1'
    arg_0['key_2'] = 'val_2'
    arg_0['key_3'] = 'val_3'
    arg_0['key_4'] = 'val_4'
    arg_0['key_5'] = 'val_5'
    arg_0['key_6'] = 'val_6'
    arg_0['key_7'] = 'val_7'
    arg_0['key_8'] = 'val_8'
    arg_0['key_9'] = 'val_9'
    arg_0['key_10'] = 'val_10'
    arg_0['key_11'] = 'val_11'

# Generated at 2022-06-24 20:20:18.201642
# Unit test for function is_iterable
def test_is_iterable():
    try:
        ansible_0 = is_iterable(test_case_0())
    except Exception as ansible_1:
        ansible_0 = str(ansible_1)

# unit testing:

# Generated at 2022-06-24 20:20:21.773860
# Unit test for function is_iterable
def test_is_iterable():
    tuple_0 = None
    var_0 = is_iterable(tuple_0)
    tuple_1 = (None,)
    var_1 = is_iterable(tuple_1)
    tuple_2 = ()
    var_2 = is_iterable(tuple_2)


# Generated at 2022-06-24 20:20:25.838403
# Unit test for function is_iterable
def test_is_iterable():
    print("in test_is_iterable")
    list_0 = ['upster', 'fred', 'wilma', 'betty', 'barney', 'din', 'pebbles']
    var_1 = is_iterable(list_0)
    assert var_1 == True

# Testing function is_iterable

# Generated at 2022-06-24 20:20:33.647532
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    t1 = ImmutableDict({'key': 'value'})
    t2 = ImmutableDict({'key': 'value1'})
    t3 = ImmutableDict({'key': 'value'})
    t4 = ImmutableDict({'key': 'value1'})
    t5 = ImmutableDict({'key': 'value2'})
    t6 = ImmutableDict({'key': 'value3'})
    assert t1 == t3
    assert t1 != t2
    assert t2 != t3
    assert t1 != t4
    assert t2 != t5
    assert t3 != t6



# Generated at 2022-06-24 20:20:42.462115
# Unit test for function is_iterable
def test_is_iterable():
    try:
        var_0 = is_iterable(None)
        assert var_0 == False
    except Exception as exc:
        var_0 = exc

    seq_0 = 'Hello'
    var_1 = is_iterable(seq_0)
    assert var_1 == False

    seq_0 = 'Hello, world!'
    var_2 = is_iterable(seq_0)
    assert var_2 == False

    list_0 = ['Hello,']
    var_3 = is_iterable(list_0)
    assert var_3 == True

    list_1 = ['Hello,']
    var_4 = is_iterable(list_1, include_strings=True)
    assert var_4 == True

    tuple_0 = ('Hello,')

# Generated at 2022-06-24 20:21:02.676289
# Unit test for function is_iterable
def test_is_iterable():
    # Test when iterable is a list
    assert is_iterable([1, 2, 3])
    # Test when iterable is a tuple
    assert is_iterable((1, 2, 3))
    # Test when iterable is a dictionary
    assert is_iterable({'1': 1, '2': 2, '3': 3})
    # Test when iterable is a set
    assert is_iterable({1, 2, 3})
    # Test when the input is a string
    assert is_iterable('Hello')
    # Test when the input is a string containing integer values
    assert is_iterable('123')

# Generated at 2022-06-24 20:21:09.939264
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dct_0 = ImmutableDict()
    dct_1 = ImmutableDict({'affix': 'antipasto'})
    dct_2 = ImmutableDict({'affix': 'antipasto'})
    dct_3 = ImmutableDict({'affix': 'antipasto', 'bison': 'beef'})
    dct_4 = ImmutableDict({'affix': 'antipasto', 'bison': 'beef', 'cabal': 'cadet'})
    dct_5 = ImmutableDict({'affix': 'antipasto', 'bison': 'beef', 'cabal': 'cadet', 'dandy': 'duke'})

# Generated at 2022-06-24 20:21:15.198608
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    input_0 = ImmutableDict({'a': 1, 'b': 2})
    input_1 = ImmutableDict({'a': 1, 'b': 2})
    var_0 = input_0.__eq__(input_1)


# Generated at 2022-06-24 20:21:16.859113
# Unit test for function is_iterable
def test_is_iterable():
    tuple_0 = None
    var_0 = is_iterable(tuple_0)


# Generated at 2022-06-24 20:21:22.462159
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test for the equality of two ImmutableDict instances.
    """
    dict_a = ImmutableDict(a=1, b=2)
    dict_b = ImmutableDict(a=1, b=2)
    assert dict_a == dict_b



# Generated at 2022-06-24 20:21:29.651294
# Unit test for function is_iterable
def test_is_iterable():
    test_str = "this is a string"
    test_list = ["this", "is", "a", "list"]
    test_tuple = ("this", "is", "a", "tuple")
    test_dict = {'this': 'is', 'a': 'dictionary'}
    test_set = {'this', 'is', 'a', 'set'}
    test_class_obj = test_case_0()

    assert is_iterable(test_str)
    assert is_iterable(test_list)
    assert is_iterable(test_tuple)
    assert is_iterable(test_dict)
    assert is_iterable(test_set)
    assert is_iterable(test_class_obj)

    assert not is_iterable(None)

# Generated at 2022-06-24 20:21:32.402883
# Unit test for function is_iterable
def test_is_iterable():
    tuple_0 = None
    var_0 = is_iterable(tuple_0)


# Generated at 2022-06-24 20:21:35.696936
# Unit test for function is_iterable
def test_is_iterable():
    is_iterable('foo')

# Generated at 2022-06-24 20:21:38.604486
# Unit test for function is_iterable
def test_is_iterable():
    assert False == is_iterable('foo')
    assert False == is_iterable('foo', True)
    assert True  == is_iterable(['foo', 'bar'])


# Generated at 2022-06-24 20:21:47.160272
# Unit test for function is_iterable
def test_is_iterable():
    import platform
    import traceback
    tuple_1 = ImmutableDict()
    var_1 = is_iterable(tuple_1)
    tuple_2 = None
    var_2 = is_iterable(tuple_2)
    tuple_3 = ImmutableDict()
    var_3 = is_iterable(tuple_3)
    tuple_4 = None
    var_4 = is_iterable(tuple_4)
    tuple_5 = ImmutableDict()
    var_5 = is_iterable(tuple_5)
    tuple_6 = ImmutableDict()
    var_6 = is_iterable(tuple_6)
    tuple_7 = ImmutableDict()
    var_7 = is_iterable(tuple_7)
    tuple_8 = ImmutableDict

# Generated at 2022-06-24 20:22:01.246608
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    arg_0 = None
    arg_1 = None
    ret_1 = ImmutableDict.__eq__(arg_0, arg_1)


# Generated at 2022-06-24 20:22:11.006336
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({1: 1, 2: 2})
    dict_1 = ImmutableDict({1: 1, 2: 2})
    dict_2 = ImmutableDict({2: 2, 1: 1})
    dict_3 = ImmutableDict({1: 2})
    dict_4 = ImmutableDict({1: 1})
    dict_5 = ImmutableDict({})
    to_test_0 = (dict_1 == dict_0)
    to_test_1 = (dict_2 == dict_0)
    to_test_2 = (dict_3 == dict_0)
    to_test_3 = (dict_4 == dict_0)
    to_test_4 = (dict_5 == dict_0)

# Generated at 2022-06-24 20:22:17.051503
# Unit test for function is_iterable
def test_is_iterable():
    class TestClass(object):
        pass

    assert not is_iterable(TestClass())
    assert is_iterable([TestClass()])
    assert is_iterable((TestClass(), TestClass()))
    assert not is_iterable({TestClass()})
    assert not is_iterable({1: TestClass()})
    assert is_iterable(set([TestClass()]))
    assert is_iterable(3)
    assert not is_iterable(None)
    assert is_iterable(TestClass)

# Generated at 2022-06-24 20:22:23.947394
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
  # Test case for __eq__ of class ImmutableDict
  tuple_0 = None
  tuple_1 = ImmutableDict()
  var_0 = tuple_0 == tuple_1
  tuple_0 = None
  tuple_1 = ImmutableDict()
  var_1 = tuple_0 == tuple_1
  # Test case for __eq__ of class ImmutableDict
  tuple_0 = None
  tuple_1 = ImmutableDict()
  var_2 = tuple_0 == tuple_1
  # Test case for __eq__ of class ImmutableDict
  # Test case for __eq__ of class ImmutableDict
  # Test case for __eq__ of class ImmutableDict
  tuple_0 = ImmutableDict(('a', 'b'), ('c', 'd'))
  tuple_1 = Immutable

# Generated at 2022-06-24 20:22:30.345709
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1,2,3])
    assert not is_iterable(0)
    assert is_iterable(set([1,2,3,4]))
    assert not is_iterable("ansible")
    assert is_iterable("ansible", include_strings=True)


# Generated at 2022-06-24 20:22:38.601823
# Unit test for function is_iterable
def test_is_iterable():
    tuple_1 = ()
    var_1 = is_iterable(tuple_1)

    list_1 = []
    var_2 = is_iterable(list_1)

    str_1 = ""
    var_3 = is_iterable(str_1)

    dict_1 = {}
    var_4 = is_iterable(dict_1)

    tuple_2 = ("a", "b", 1, 2)
    var_5 = is_iterable(tuple_2)

    list_2 = ['Python', 'Java', 'Ruby', 'C#']
    var_6 = is_iterable(list_2)

    str_2 = "Programming"
    var_7 = is_iterable(str_2)


# Generated at 2022-06-24 20:22:43.113370
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    idict_0 = ImmutableDict({'a': 1})
    idict_1 = ImmutableDict({'a': 2})
    idict_2 = ImmutableDict({'a': 1})
    var_0 = (idict_0 == idict_1)
    var_1 = (idict_0 == idict_2)


# Generated at 2022-06-24 20:22:45.454896
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_1 = ImmutableDict()
    var_0 = dict_0 == dict_1


# Generated at 2022-06-24 20:22:48.664976
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({'a': 1, 'b': 2, 'c': 3}, d=4, e=5)
    dict_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3}, d=4, e=5)
    assert dict_0 == dict_1


# Generated at 2022-06-24 20:22:53.233505
# Unit test for function is_iterable
def test_is_iterable():
    # Input parameters
    # Arguments used to test the is_iterable function
    tuple_0 = [10, 20]
    var_0 = is_iterable(tuple_0)

    # Output
    assert var_0 == True



# Generated at 2022-06-24 20:23:27.894201
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(foo=1, bar=2)
    d2 = ImmutableDict(foo=1, bar=2)
    assert d1 == d2
    d3 = ImmutableDict(foo=1, bar=3)
    assert d1 != d3


# Generated at 2022-06-24 20:23:30.203874
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    v1 = ImmutableDict({"1": 1})
    v2 = ImmutableDict({"1": 1})
    assert(v1 == v2)


# Generated at 2022-06-24 20:23:33.294302
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    ImmutableDict_0 = ImmutableDict()
    var_0 = ImmutableDict_0.__eq__(object)
    var_1 = ImmutableDict_0.__eq__(ImmutableDict_0)


# Generated at 2022-06-24 20:23:43.047462
# Unit test for function is_iterable
def test_is_iterable():
    var_1 = is_iterable('', True)  # should return False
    var_2 = is_iterable('a string', False)  # should return False
    var_3 = is_iterable({'a': 'dict'}, True)  # should return True
    var_4 = is_iterable([1, 2], True)  # should return True
    var_5 = is_iterable(3, False)  # should return False
    var_6 = is_iterable(range(0, 10), True)  # should return True
    var_7 = is_iterable('a string', True)  # should return True
    var_8 = is_iterable('a string', 'definitely not a boolean')  # should return False



# Generated at 2022-06-24 20:23:49.392594
# Unit test for function is_iterable
def test_is_iterable():
    import collections
    # Test case #0
    tuple_0 = ["a", "b"]
    bool_0 = is_iterable(tuple_0)
    # Test case #1
    tuple_1 = ["a", "b"]
    bool_1 = is_iterable(tuple_1, True)
    # Test case #2
    bool_2 = is_iterable("abcdef")
    # Test case #3
    tuple_3 = ["a", "b"]
    bool_3 = is_iterable(tuple_3, True)


# Generated at 2022-06-24 20:23:58.247946
# Unit test for function is_iterable
def test_is_iterable():
    tuple_0 = ()
    var_0 = is_iterable(tuple_0)
    tuple_1 = ()
    var_1 = is_iterable(tuple_1)
    tuple_2 = ()
    var_2 = is_iterable(tuple_2)
    tuple_3 = ()
    var_3 = is_iterable(tuple_3)
    tuple_4 = ()
    var_4 = is_iterable(tuple_4)
    tuple_5 = ()
    var_5 = is_iterable(tuple_5)
    tuple_6 = ()
    var_6 = is_iterable(tuple_6)
    tuple_7 = ()
    var_7 = is_iterable(tuple_7)
    tuple_8 = ()
    var_8 = is_iter

# Generated at 2022-06-24 20:24:02.750748
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    tuple_0 = ImmutableDict({})
    tuple_1 = ImmutableDict({})
    var_0 = tuple_0.__eq__(tuple_1)


# Generated at 2022-06-24 20:24:08.205383
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(())
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(range(5))
    assert is_iterable(5) is False
    assert is_iterable(5.5) is False
    assert is_iterable('abc', include_strings=True)
    assert is_iterable(u'abc', include_strings=True)
    assert is_iterable(b'abc', include_strings=True)
    assert is_iterable(object()) is False


# Generated at 2022-06-24 20:24:10.925952
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    dic_0 = ImmutableDict()
    ImmutableDict.__eq__(dic_0, 'dic_0')
    dic_0 = ImmutableDict()
    ImmutableDict.__eq__(dic_0, (1, 2))


# Generated at 2022-06-24 20:24:16.387614
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(None)
    assert not is_iterable(0)
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable("")
    assert is_iterable(set())
    assert not is_iterable(set(), include_strings=True)

