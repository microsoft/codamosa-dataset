

# Generated at 2022-06-24 20:14:47.839212
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable("test") is True

# Generated at 2022-06-24 20:14:50.020547
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = {}
    dict_1 = {}
    var_0 = ImmutableDict(dict_0)
    # assertEqual does not work due to dict_0 != dict_1
    assertImmutableDictEqual(var_0, dict_1)


# Generated at 2022-06-24 20:14:59.163359
# Unit test for function is_iterable
def test_is_iterable():
    # Testing string, list, set, tuple
    string = "ansible"
    list_ = [1, 2, 3, 4]
    set_ = {1, 2, 3, 4}
    tuple_ = (1, 2, 3, 4)

    assert is_iterable(string)
    assert not is_iterable(string, include_strings=False)
    assert is_iterable(list_)
    assert is_iterable(set_)
    assert is_iterable(tuple_)
    assert not is_iterable(1)
    assert not is_iterable(1, include_strings=True)



# Generated at 2022-06-24 20:15:06.291885
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    int_0 = 2
    var_0 = ImmutableDict({'a': 1, 'b': 2})
    if var_0 != 2:
        with raise_from(raise_(ValueError())):
            pass
    if not var_0 == 0:
        with raise_from(raise_(ValueError())):
            pass
    if not var_0 != 2:
        with raise_from(raise_(ValueError())):
            pass



# Generated at 2022-06-24 20:15:09.321414
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    dict_0 = ImmutableDict(test1 = 'test1', test2 = 'test2')
    dict_1 = dict_0.difference(('test1', 'test2'))
    expected_result = {}
    assert dict_1 == expected_result


# Generated at 2022-06-24 20:15:13.141714
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    dict_0 = ImmutableDict({'hello': 'world'})
    iterable = ['hello']
    result = dict_0.difference(iterable)
    assert result == ImmutableDict()



# Generated at 2022-06-24 20:15:19.223284
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({'a': 'b'})
    assert dict_0 == dict_0
    assert dict_0 == {'a': 'b'}
    assert dict_0 == dict(a='b')
    # dict() can't handle dict_0 because it is not a dict, but an immutable dict
    assert dict_0 != dict()
    assert dict_0 != ImmutableDict()
    assert dict_0 != {'a': 'c'}
    assert dict_0 != ImmutableDict({'a': 'c'})
    assert dict_0 != {'b': 'b'}
    assert dict_0 != ImmutableDict({'b': 'b'})


# Generated at 2022-06-24 20:15:28.428562
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({0: 0, 1: 1, 2: 4})
    dict_1 = ImmutableDict({0: 0, 1: 1, 2: 4})
    dict_2 = ImmutableDict({0: 0, 1: 1, 2: 2})
    dict_3 = 'foo'
    var_0 = dict_0.__eq__(dict_1)
    var_1 = dict_0.__eq__(dict_2)
    var_2 = dict_0.__eq__(dict_3)


# Generated at 2022-06-24 20:15:31.798072
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    dict_0 = {u'7': u'6', u'8': u'6', u'9': u'6'}
    immutable_dict_0 = ImmutableDict(dict_0)
    immutable_dict_0.difference((u'8',))


# Generated at 2022-06-24 20:15:40.136452
# Unit test for function is_iterable
def test_is_iterable():
    x = {1: "1"}
    y = [1, 2, 3]
    z = b"456"
    a = (1, 2, 3)
    b = "abc"
    c = 5
    print(is_iterable(x))   # True
    print(is_iterable(y))   # True
    print(is_iterable(z))   # True
    print(is_iterable(a))   # True
    print(is_iterable(b))   # True
    print(is_iterable(c))   # False


# Generated at 2022-06-24 20:15:56.266190
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Case 0: Empty dictionary
    dict_1 = ImmutableDict({})
    assert dict_1 == {}

    # Case 1: Empty dictionary == Empty ImmutableDict
    dict_1 = ImmutableDict({})
    assert dict_1 == ImmutableDict({})

    # Case 2: Two ImmutableDict are equal
    dict_1 = ImmutableDict({'foo': 'bar', 'baz': 'bat'})
    dict_2 = ImmutableDict({'baz': 'bat', 'foo': 'bar'})
    assert dict_1 == dict_2

    # Case 3: Two ImmutableDict are not equal
    dict_1 = ImmutableDict({'foo': 'bar', 'baz': 'bat'})

# Generated at 2022-06-24 20:16:02.803943
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(6)
    assert not is_iterable(6.0)
    assert is_iterable('a')
    assert is_iterable(u'a')
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(0))


# Generated at 2022-06-24 20:16:14.677738
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict({'a': 'b', 'c': 'd'})
    var_1 = ImmutableDict({'c': 'd', 'a': 'b'})
    var_2 = ImmutableDict({'c': 'd', 'a': 'b'})
    var_3 = ImmutableDict({'c': 'd', 'a': 'e'})
    var_4 = ImmutableDict({'c': 'd', 'a': 'b', 'e': 'f'})
    var_5 = ImmutableDict({'c': 'd', 'a': 'b', 'f': 'g'})
    var_6 = ImmutableDict({'c': 'd', 'a': 'b', 'e': 'f'})

# Generated at 2022-06-24 20:16:16.191343
# Unit test for function is_iterable
def test_is_iterable():
    list_0 = []
    var_0 = is_iterable(list_0)


# Generated at 2022-06-24 20:16:23.639747
# Unit test for function is_iterable
def test_is_iterable():
    dict_0 = {}
    dict_1 = {"key_0": "value_0"}
    str_0 = "string_0"
    list_0 = ["item_0", "item_1"]
    var_0 = is_iterable(dict_0)
    var_1 = is_iterable(dict_1)
    var_2 = is_iterable(str_0)
    var_3 = is_iterable(list_0)


# Generated at 2022-06-24 20:16:28.440593
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable({})
    assert is_iterable([])
    assert not is_iterable(0)
    assert not is_iterable(None)


# Generated at 2022-06-24 20:16:36.868019
# Unit test for function is_iterable
def test_is_iterable():
    # Check if is_iterable returns False when an integer is passed as an argument
    assert is_iterable(2) is False

    # Check if is_iterable returns False when a bool is passed as an argument
    assert is_iterable(False) is False

    # Check if is_iterable returns True when a list is passed as an argument
    assert is_iterable([]) is True

    # Check if is_iterable returns True when a dictionary is passed as an argument
    assert is_iterable({}) is True

    # Check if is_iterable returns False when an integer is passed as an argument with include_strings as True
    assert is_iterable(2, True) is False

    # Check if is_iterable returns True when a str is passed as an argument with include_strings as True
    assert is_iterable('', True) is True



# Generated at 2022-06-24 20:16:39.754498
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict({"a": "b"})
    var_1 = ImmutableDict({"a": "b"})
    var_2 = ImmutableDict({"a": "b", "c": "d"})
    assert var_0 == var_1
    assert var_0 != var_2

# Generated at 2022-06-24 20:16:41.046197
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    data = ImmutableDict()
    data["key"] = "value"
    assert data == ImmutableDict({'key': 'value'})


# Generated at 2022-06-24 20:16:46.113485
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('str')
    assert is_iterable(['list'])
    assert is_iterable(('tuple', 'tuple2'))
    assert is_iterable({'diction': 'ary'})



# Generated at 2022-06-24 20:17:01.741808
# Unit test for function is_iterable
def test_is_iterable():
    dict_1 = {}
    var_1 = is_iterable(dict_1)
    assert(var_1)

    dict_2 = {'a': 'b'}
    var_2 = is_iterable(dict_2)
    assert(var_2)

    dict_3 = ImmutableDict({'a': 'b'})
    var_3 = is_iterable(dict_3)
    assert(var_3)

    dict_4 = 'dummy string'
    var_4 = is_iterable(dict_4)
    assert(var_4)

    dict_5 = u"dummy unicode string"
    var_5 = is_iterable(dict_5)
    assert(var_5)

    dict_6 = b"dummy string"
    var_6 = is_iter

# Generated at 2022-06-24 20:17:04.820190
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_1 = ImmutableDict()
    var_0 = dict_0.__eq__(dict_1)



# Generated at 2022-06-24 20:17:11.929115
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = {}
    dict_1 = {}
    var_0 = is_iterable(dict_1)
    dict_1['key'] = dict_0
    dict_0['key2'] = dict_1
    dict_1['key2'] = dict_0
    var_1 = ImmutableDict(dict_0)
    var_2 = ImmutableDict(dict_1)
    var_3 = var_1 == var_2


# Generated at 2022-06-24 20:17:14.847548
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({}, )
    var_0 = dict_0.__eq__({})
    assert (var_0 == True)


# Generated at 2022-06-24 20:17:22.358868
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_dict1 = ImmutableDict(dict1)
    test_dict2 = ImmutableDict(dict2)
    if test_dict1 == test_dict2:
        raise Exception('The given dictionaries are equal')
    test_dict3 = ImmutableDict(dict3)
    if not test_dict3 == test_dict2:
        raise Exception('Expected equality not found')


# Generated at 2022-06-24 20:17:32.090533
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Case 1
    a = ImmutableDict({"a": 1, "b": True})
    b = ImmutableDict({"a": 1, "b": True})
    assert (a == b)
    assert not (a != b)
    # Case 2
    a = ImmutableDict({"a": 1, "b": True})
    b = {"a": 1, "b": True}
    assert not (a == b)
    assert (a != b)
    # Case 3
    a = ImmutableDict({"a": 1, "b": True})
    b = ImmutableDict({"a": 1, "b": False})
    assert not (a == b)
    assert (a != b)
    # Case 4
    a = ImmutableDict({"a": 1, "b": True})


# Generated at 2022-06-24 20:17:43.338845
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict(('DICT_KEY_1', 'VALUE_1'), ('DICT_KEY_2', 'VALUE_2'), ('DICT_KEY_3', 'VALUE_3'))
    dict_1 = ImmutableDict(('DICT_KEY_1', 'VALUE_4'), ('DICT_KEY_2', 'VALUE_2'), ('DICT_KEY_3', 'VALUE_3'))
    dict_2 = ImmutableDict(('DICT_KEY_1', 'VALUE_1'), ('DICT_KEY_2', 'VALUE_2'), ('DICT_KEY_3', 'VALUE_3'))
    assert dict_0.__eq__(dict_1) == False
    assert dict_0.__eq__(dict_2) == True


# Generated at 2022-06-24 20:17:51.746808
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'buzz': 2, 'foo': 1, 'bar': 3}) == ImmutableDict({'foo': 1, 'bar': 3, 'buzz': 2})
    assert ImmutableDict({'buzz': 2, 'foo': 1, 'bar': 3}) != ImmutableDict({'foo': 1, 'bar': 3})
    assert ImmutableDict({'buzz': 2, 'foo': 1, 'bar': 3}) != ImmutableDict({'foo': 1, 'buzz': 2})
    assert ImmutableDict({'buzz': 2, 'foo': 1, 'bar': 3}) != ImmutableDict({'foo': 1, 'bar': 2, 'buzz': 2})

# Generated at 2022-06-24 20:17:53.295853
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(is_iterable)



# Generated at 2022-06-24 20:17:57.131414
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_1 = {'a': 1, 'b': 2, 'c': 3}
    immutable_dict_0 = ImmutableDict(dict_1)
    bool_0 = immutable_dict_0.__eq__(dict_1)
    if not (not bool_0):
        raise Exception("AssertionError")


# Generated at 2022-06-24 20:18:17.437534
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    list_0 = []
    var_0 = dict_0 == list_0
    assert not var_0


# Generated at 2022-06-24 20:18:18.242565
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])


# Generated at 2022-06-24 20:18:24.348136
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dicts = [{1: 2}, ImmutableDict({1: 2})]
    for dict_0 in dicts:
        for dict_1 in dicts:
            if dict_0 == dict_1:
                var_0 = True
            else:
                var_0 = False


# Generated at 2022-06-24 20:18:28.032904
# Unit test for function is_iterable
def test_is_iterable():
    dict_2 = dict
    dict_4 = dict_2(())
    dict_4 = dict_4.fromkeys(())
    dict_4 = dict_4.items()
    dict_4 = dict_4.keys()
    dict_4 = dict_4.values()
    dict_4 = dict_4.__iter__()


# Generated at 2022-06-24 20:18:32.609348
# Unit test for function is_iterable
def test_is_iterable():
    dict_0 = {}
    var_0 = is_iterable(dict_0)
    dict_0 = dict()
    var_1 = is_iterable(dict_0)
    dict_0 = 'value_0'
    var_2 = is_iterable(dict_0)



# Generated at 2022-06-24 20:18:41.640930
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({'first': 'a', 'second': 'b'})
    dict_0_eq_dict_0_1 = (dict_0 == ImmutableDict({'second': 'b', 'first': 'a'}))
    # second ==
    # assertEquals(dict_0_eq_dict_0_1, True, "Unexpected value")
    dict_0_0 = ImmutableDict({'first': 'b', 'second': 'a'})
    dict_0_eq_dict_0_0 = (dict_0 == dict_0_0)
    # second ==
    # assertEquals(dict_0_eq_dict_0_0, False, "Unexpected value")



# Generated at 2022-06-24 20:18:44.203355
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('abc')
    assert is_iterable([])
    assert not is_iterable(1)
    assert not is_iterable(is_iterable)


# Generated at 2022-06-24 20:18:49.611091
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    try:
        dict_0 = ImmutableDict({'1': '1', '3': '3', '2': '2'})
        dict_1 = ImmutableDict({'1': '1', '3': '3'})
        assert not (dict_0 == dict_1)
    except AssertionError:
        raise AssertionError('Failure')


# Generated at 2022-06-24 20:19:00.740179
# Unit test for function is_iterable
def test_is_iterable():
    ans_str = is_iterable('hello')
    assert ans_str == True

    dict_1 = {}
    var_1 = is_iterable(dict_1)
    assert var_1 == True

    dict_2 = ()
    var_2 = is_iterable(dict_2)
    assert var_2 == True

    dict_3 = []
    var_3 = is_iterable(dict_3)
    assert var_3 == True

    dict_4 = 'hello'
    var_4 = is_iterable(dict_4, False)
    assert var_4 == False

    dict_5 = 'hello'
    var_5 = is_iterable(dict_5, True)
    assert var_5 == True



# Generated at 2022-06-24 20:19:04.630265
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = {}
    var_0 = ImmutableDict(dict_0)
    var_1 = ImmutableDict(dict_0)
    var_2 = ImmutableDict({'key2': 'value2', 'key1': 'value1'})
    if var_0 == var_1 and var_1 == var_2:
        return var_0


# Generated at 2022-06-24 20:19:28.321643
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = {}
    var_0 = ImmutableDict(dict_0)
    dict_1 = {}
    dict_1[0] = 'abc'
    var_1 = ImmutableDict(dict_1)
    assert var_0.__eq__(var_0)
    assert var_1.__eq__(var_1)
    assert var_0.__eq__(var_1)
    assert var_1.__eq__(var_0)


# Generated at 2022-06-24 20:19:31.235103
# Unit test for function is_iterable
def test_is_iterable():
    var_0 = is_iterable([])
    var_1 = is_iterable({})
    var_2 = is_iterable(2)
    var_3 = is_iterable('foo')
    var_4 = is_iterable(u'bar')


# Generated at 2022-06-24 20:19:41.582742
# Unit test for function is_iterable
def test_is_iterable():
    iterable_list = [1, 2, 3]
    iterable_dict = {1: 'one'}
    iterable_set = {1, 2, 3}
    iterable_string = 'string'
    iterable_generator = range(10)

    assert is_iterable(iterable_list)
    assert is_iterable(iterable_dict)
    assert is_iterable(iterable_set)
    assert is_iterable(iterable_string)
    assert is_iterable(iterable_generator)

    assert is_iterable(iterable_list, include_strings=True)
    assert is_iterable(iterable_dict, include_strings=True)
    assert is_iterable(iterable_set, include_strings=True)

# Generated at 2022-06-24 20:19:46.108336
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = {}
    dict_1 = {'a': 1, 'b': [3, 4]}
    set_0 = {'a': 1, 'b': [3, 4]}
    set_1 = {'d': 99, 'b': [4, 3]}
    set_2 = {}
    dict_2 = {'a': 1, 'b': [3, 4]}
    dict_3 = {}
    dict_4 = {'a': 1, 'b': [3, 4]}
    assert isinstance(ImmutableDict(dict_0, dict_1).__eq__(set_0), bool)
    assert ImmutableDict(dict_0, dict_1).__eq__(set_0)
    assert isinstance(ImmutableDict(set_1).__eq__(set_1), bool)


# Generated at 2022-06-24 20:19:50.344861
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(set()) is True
    assert is_iterable('string') is False
    assert is_iterable('string', True) is True
    assert is_iterable(1) is False
    assert is_iterable({}) is True
    assert is_iterable(()) is True
    assert is_iterable([]) is True
    assert is_iterable(object) is False


# Generated at 2022-06-24 20:19:52.089639
# Unit test for function is_iterable
def test_is_iterable():
    str_0 = 'Test'
    var_0 = is_iterable(str_0)


# Generated at 2022-06-24 20:19:56.121890
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict(('test', 'value'))
    dict_1 = ImmutableDict(('test', 'value'))
    assert dict_0.__eq__(dict_1)


# Generated at 2022-06-24 20:20:05.379691
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = {1: "a", 2: "b", 3: [1, 2, 3], 4: {"a": [1, 2, 3], "b": {"a": "b"}}}
    tup_0 = (1, 2, 3)
    tup_1 = (1, 2, 3)
    tup_2 = (1, 2, 4)
    tup_3 = (1, 2, 3, "a")
    imm_dict_0 = ImmutableDict(dict_0)
    imm_dict_1 = ImmutableDict(dict_0)
    imm_dict_2 = ImmutableDict(dict_0)
    imm_dict_2._store[3].append(4)
    assert (imm_dict_0 == imm_dict_1)

# Generated at 2022-06-24 20:20:14.582481
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}  # Dict does not raise TypeError when __hash__ is unavailable
    assert ImmutableDict({'a': 1, 'b': 2}) != {'b': 2, 'a': 1, 'c': 3}


# Generated at 2022-06-24 20:20:21.662846
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = {"a": True, "b": False, "c": True}
    assert ImmutableDict(dict_0).__eq__(dict_0) == True
    assert ImmutableDict({"a": True, "b": False, "c": True}).__eq__(dict_0) == True
    assert ImmutableDict({"a": True, "b": False}).__eq__(dict_0) == False
    assert ImmutableDict({"a": True, "b": False, "c": False}).__eq__(dict_0) == False


# Generated at 2022-06-24 20:21:05.156767
# Unit test for function is_iterable
def test_is_iterable():
    # Function should return True if argument is an iterable
    assert is_iterable(['test', 'foo', 'bar']) is True
    assert is_iterable(('test', 'foo', 'bar')) is True
    assert is_iterable({'test': 1, 'foo': 2, 'bar': 3}) is True

    # Function should return True if argument is a string if include_strings is True
    assert is_iterable('I am a string', include_strings=True) is True

    # Function should return False if argument is a string if include_strings is False
    # Default setting for include_strings is False
    assert is_iterable('I am not a string') is False
    assert is_iterable('I am not a string', include_strings=False) is False

    # Function should return False if argument is an integer

# Generated at 2022-06-24 20:21:11.975740
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(0)
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('string')
    assert is_iterable(u'unicode')
    assert not is_iterable('string', include_strings=False)
    assert not is_iterable(u'unicode', include_strings=False)
    assert is_iterable(range(0, 1))  # python 2: xrange
    assert is_iterable(b'bytes')
    assert not is_iterable(b'bytes', include_strings=False)

    # list of non-iterable objects, expected to return False

# Generated at 2022-06-24 20:21:21.774844
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({"a": "b"})
    dict_1 = ImmutableDict({"a": "b"})
    var_0 = dict_0 == dict_1
    dict_2 = {"a": "b"}
    var_1 = dict_0 == dict_2
    dict_3 = ImmutableDict({"a": "b", "c": "d"})
    var_2 = dict_0 == dict_3
    var_3 = dict_0 == dict_2
    dict_4 = {"a": "b", "c": "d"}
    var_4 = dict_0 == dict_4
    dict_5 = ImmutableDict({"a": "b", "c": "d"})
    var_5 = dict_0 == dict_5


# Generated at 2022-06-24 20:21:24.002729
# Unit test for function is_iterable
def test_is_iterable():
    """Test is_iterable."""
    seq_0 = ('', 'value1')

    var_0 = is_iterable(seq_0, False)


# Generated at 2022-06-24 20:21:29.553448
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    mapping_0 = ImmutableDict({0:0, 1:1, 2:2})
    mapping_1 = ImmutableDict({0:0, 1:1, 2:2})
    mapping_2 = ImmutableDict({0:0, 1:1, 2:3})
    mapping_3 = ImmutableDict({0:0, 1:1, 2:4})
    mapping_4 = ImmutableDict({0:0, 1:1, 2:5})
    mapping_5 = ImmutableDict({0:0, 1:1, 2:6})
    mapping_6 = ImmutableDict({0:0, 1:1, 2:7})
    # Test if 2 ImmutableDict's with the same content are equal
    assert mapping_0 == mapping_1
    # Test if 2 ImmutableDict's with

# Generated at 2022-06-24 20:21:38.489906
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = {'foo': 1, 'bar': 2}
    dict_1 = ImmutableDict(dict_0)
    dict_2 = ImmutableDict(dict_0)
    dict_3 = ImmutableDict({'foo': 2, 'bar':1})
    print(dict_1 == dict_1)
    print(dict_1 == dict_2)
    print(dict_1 == dict_3)
    print('foo' in dict_1.union({'bar': 3}))


# Generated at 2022-06-24 20:21:41.942589
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = {}
    dict_1 = ImmutableDict(dict_0)
    dict_2 = ImmutableDict(dict_0)
    result = dict_1.__eq__(dict_2)
    print(result)


# Generated at 2022-06-24 20:21:44.382392
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # self._eq__ needs to be tested with a callable as well
    var_0 = ImmutableDict() == print
    var_1 = ImmutableDict() == ImmutableDict()


# Generated at 2022-06-24 20:21:52.665837
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test object identity: x is y
    assert isinstance(ImmutableDict({}), ImmutableDict)
    assert isinstance(ImmutableDict({}), Mapping)
    assert isinstance(ImmutableDict({}), Hashable)
    assert isinstance(ImmutableDict({}), Sequence)
    # Test actual equality: x == y
    assert ImmutableDict({}) == ImmutableDict({})
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1, 'b': 2})
    # Test iterable
    assert isinstance(ImmutableDict({}), Sequence)
    assert isinstance(ImmutableDict({}), Mapping)

# Generated at 2022-06-24 20:21:59.085430
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = {}
    var_0 = ImmutableDict(dict_0, **{'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7})
    var_0 = var_0 == var_0


# Generated at 2022-06-24 20:23:27.520543
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) == True
    assert is_iterable({}) == True
    assert is_iterable(()) == True
    assert is_iterable(0) == False
    assert is_iterable("test") == True

test_case_0()
test_is_iterable()

# Generated at 2022-06-24 20:23:31.638987
# Unit test for function is_iterable
def test_is_iterable():
    dict_0 = {}
    var_0 = is_iterable(dict_0)
    dict_1 = {'a'}
    var_1 = is_iterable(dict_1)
    dict_2 = {'a', 'b'}
    var_2 = is_iterable(dict_2)


# Generated at 2022-06-24 20:23:42.282232
# Unit test for function is_iterable
def test_is_iterable():
    assert is_string('hello')
    assert is_string(u'hello')
    assert is_string(b'hello')
    assert is_string(['hello'])
    assert not is_string(0)
    assert is_iterable(['hello', u'world'])
    assert is_iterable(['hello', b'world'])
    assert not is_iterable('hello')
    assert not is_iterable(u'hello')
    assert not is_iterable(b'hello')
    assert not is_iterable('hello', True)
    assert not is_iterable(u'hello', True)
    assert not is_iterable(b'hello', True)
    assert is_iterable('hello', False)
    assert is_iterable(u'hello', False)

# Generated at 2022-06-24 20:23:49.467447
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(list([1, 2, 3]))
    assert is_iterable(set({1, 2, 3}))
    assert is_iterable(tuple((1, 2, 3)))
    assert is_iterable(dict({1: 2, 3: 4}))
    assert is_iterable('abc')
    assert is_iterable(b'abc')
    assert is_iterable(is_iterable)
    assert is_iterable(ImmutableDict({'a': 1}))
    assert not is_iterable(is_iterable())
    assert not is_iterable(None)


# Generated at 2022-06-24 20:23:50.907018
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_1 = ImmutableDict()
    assert dict_0 == dict_1



# Generated at 2022-06-24 20:24:00.797348
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable(['a', 'b']) == True)
    assert(is_iterable(['a', 'b'], include_strings = True) == True)
    assert(is_iterable('cba') == True)
    assert(is_iterable('cba', include_strings = True) == True)
    assert(is_iterable(('a', 'b')) == True)
    assert(is_iterable(('a', 'b'), include_strings = True) == True)
    assert(is_iterable(1) == False)
    assert(is_iterable(1, include_strings = True) == False)


# Generated at 2022-06-24 20:24:06.604491
# Unit test for function is_iterable
def test_is_iterable():
    # Testing if we have a string type
    var_1 = 'string'
    var_2 = is_iterable(var_1)
    assert var_2 == False

    # Testing if we have a list type
    var_3 = []
    var_4 = is_iterable(var_3)
    assert var_4 == True


# Generated at 2022-06-24 20:24:10.011899
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = {}
    dict_1 = dict_0



# Generated at 2022-06-24 20:24:12.590875
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = {}
    var_0 = ImmutableDict(dict_0)
    var_1 = ImmutableDict(dict_0)
    var_0.__eq__(var_1)

# Generated at 2022-06-24 20:24:14.988019
# Unit test for function is_iterable
def test_is_iterable():
    dict_1 = {}
    var_1 = is_iterable(dict_1)
    assert var_1
