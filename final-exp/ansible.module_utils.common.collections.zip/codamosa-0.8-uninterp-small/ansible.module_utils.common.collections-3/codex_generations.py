

# Generated at 2022-06-24 20:15:01.657418
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(set())
    assert is_iterable({'a': 1, 'b': 2, 'c': 3})
    assert is_iterable(dict())
    assert is_iterable([1, 2, 3, 4])
    assert is_iterable(tuple([1, 2, 3, 4]))
    assert is_iterable('mockups')
    assert is_iterable((1, 2, 3))
    my_class = type('', (), {})
    assert is_iterable(my_class)
    assert not is_iterable('qwerty')
    assert not is_iterable(12345)
    assert not is_iterable(2 ** 3)
    assert not is_iterable(1)
    assert not is_iterable(5 + 5)



# Generated at 2022-06-24 20:15:08.755169
# Unit test for function is_iterable
def test_is_iterable():
    # try with string as input
    assert is_iterable('string')
    # try with string as input and include_strings=False
    assert not is_iterable('string', include_strings=False)
    # try with list as input
    assert is_iterable([0, 1, 2])
    # try with tuple as input
    assert is_iterable(('a', 'b', 'c'))
    # try with generator as input
    iterable = (item for item in range(3))
    assert is_iterable(iterable)



# Generated at 2022-06-24 20:15:15.931877
# Unit test for function is_iterable
def test_is_iterable():
    s = 'some string'
    i = [1, 4, 1, 'a']
    assert is_iterable(s) is True
    assert is_iterable(i) is True
    assert is_iterable(1) is False
    assert is_iterable((1, 2, 3)) is True
    assert is_iterable(dict(a=1, b=2)) is True
    assert is_iterable(1, include_strings=True) is False
    assert is_iterable(s, include_strings=True) is True


# Generated at 2022-06-24 20:15:21.606445
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict({'a': 3, 'b': 2})
    var_0 = immutable_dict_1.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:15:24.182842
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)
    immutable_dict_1 = ImmutableDict()
    var_1 = immutable_dict_1.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:15:33.827304
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict(a='b', b=[], c=object())
    var_0 = (immutable_dict_0 == immutable_dict_0)
    var_1 = (immutable_dict_0 == dict(a='b', b=[], c=object()))
    var_2 = (immutable_dict_0 == dict(a='b', c=object(), b=[]))
    var_3 = (immutable_dict_0 == dict(b=[], a='b', c=object()))
    var_4 = (immutable_dict_0 == dict(b=[], c=object(), a='b'))
    var_5 = (immutable_dict_0 == dict(c=object(), b=[], a='b'))

# Generated at 2022-06-24 20:15:35.888946
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    bool_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:15:45.089901
# Unit test for function is_iterable
def test_is_iterable():
    x = [[1,2], [2,4]]
    assert is_iterable(x)

    x = [[1,2], (2,6)]
    assert is_iterable(x)

    x = [[1,2], [3,6], 'test', 8]
    assert is_iterable(x)

    x = {1:2, 2:4}
    assert is_iterable(x)

    x = {1:2, 'test': 4}
    assert is_iterable(x)

    x = 'x'
    assert not is_iterable(x)

    x = (1, [2, 4])
    assert is_iterable(x)

    x = (1, [2, 4], 'test')
    assert is_iterable(x)

    x = (1, 2, 3)

# Generated at 2022-06-24 20:15:46.916704
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    immutable_dict_1 = ImmutableDict({'a': 'b'}, b='c')
    immutable_dict_2 = ImmutableDict({'a': 'b', 'b': 'c'})

    assert immutable_dict_1.__eq__(immutable_dict_2) == True


# Generated at 2022-06-24 20:15:49.940321
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) == True, "Test failed"
    assert is_iterable('a') == False, "Test failed"
    assert is_iterable(None) == False, "Test failed"
    assert is_iterable({}) == True, "Test failed"


# Generated at 2022-06-24 20:15:57.579032
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable({}) == True
    assert is_iterable([]) == True
    assert is_iterable(()) == True
    assert is_iterable(list()) == True
    assert is_iterable(dict()) == True
    assert is_iterable(set()) == True
    assert is_iterable(tuple()) == True
    assert is_iterable(frozenset()) == True
    assert is_iterable('') == False
    assert is_iterable('hello world') == False
    assert is_iterable(0) == False
    assert is_iterable(1) == False
    #assert is_iterable(True) == False
    #assert is_iterable(False) == False
    #assert is_iterable(None) == False


# Generated at 2022-06-24 20:16:01.414423
# Unit test for function is_iterable
def test_is_iterable():
    # stdout, stderr, rc = run_module_with_fail_json(module_name='is_iterable')
    var_ret_0 = is_iterable('foo')
    var_ret_1 = is_iterable({})
    var_ret_2 = is_iterable(())
    var_ret_3 = is_iterable([])



# Generated at 2022-06-24 20:16:05.152663
# Unit test for function is_iterable
def test_is_iterable():
    # Make sure is_iterable returns False if not iterable
    assert is_iterable(1) is False
    assert is_iterable('') is False

    # Make sure is_iterable returns True if iterable
    assert is_iterable('hello') is True
    assert is_iterable(['a', 'b']) is True
    assert is_iterable({'a': 'b'}) is True

# Generated at 2022-06-24 20:16:11.417157
# Unit test for function is_iterable
def test_is_iterable():
    # Testing on an empty string
    assert is_iterable('')

    # Testing on an empty list
    assert is_iterable([])

    # Testing on an empty tuple
    assert is_iterable(())

    # Testing on an empty dict
    assert is_iterable({})

    # Testing on an empty set
    assert is_iterable(set())

    # Testing on an empty generator
    assert is_iterable((i for i in range(0) if i % 2 == 0))

    # Testing on an empty generator with comma in the expression

# Generated at 2022-06-24 20:16:15.322246
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable((1, 2, 3)) is True
    assert is_iterable(set([1, 2, 3])) is True
    assert is_iterable({'key': 'value'}) is True
    assert is_iterable('abc') is True
    assert is_iterable(1) is False



# Generated at 2022-06-24 20:16:19.288356
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    immutable_dict_1 = ImmutableDict(**{'a': 'b'})
    immutable_dict_0 = ImmutableDict()
    var_2 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:16:29.565845
# Unit test for function is_iterable
def test_is_iterable():
    examples = [
        ("abc", True),
        ([1, 2, 3], True),
        ((1, 2, 3), True),
        ({}, True),
        (dict(x=1), True),
        (1, False),
        ]
    for obj, expected in examples:
        result = is_iterable(obj)
        assert result is expected, "Expected {0}, but got {1} for {2}".format(expected, result, obj)
    # Additional test for string that should not be considered iterable
    examples = [
        ("abc", False),
        ("abc", True),
        ]
    for obj, expected in examples:
        result = is_iterable(obj, include_strings=True)

# Generated at 2022-06-24 20:16:34.248714
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict(['hello', 'world'], {'hello': 'world'})
    immutable_dict_1 = ImmutableDict(['hello', 'world'], {'hello': 'world'})
    immutable_dict_2 = ImmutableDict('hello', world=1)
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)
    var_1 = immutable_dict_0.__eq__(immutable_dict_2)

# Generated at 2022-06-24 20:16:36.793038
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    try:
        immutable_dict_0.__eq__(1)
        bool_0 = True
    except TypeError:
        bool_0 = False
    assert bool_0


# Generated at 2022-06-24 20:16:38.675683
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_1 = ImmutableDict(abc = 'abc')
    immutable_dict_2 = ImmutableDict(abc = 'abc')

    var_1 = (immutable_dict_1 == immutable_dict_2)

# Generated at 2022-06-24 20:16:48.141863
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(1)
    assert not is_iterable('1')
    assert is_iterable('1', include_strings=True)
    assert not is_iterable(set())
    assert not is_iterable(object())


# Generated at 2022-06-24 20:16:55.390891
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(None)
    assert not is_iterable(False)
    assert not is_iterable(object)
    assert is_iterable([])
    assert is_iterable(dict())
    assert is_iterable((1, 2))
    assert is_iterable(set())
    assert is_iterable('')
    assert not is_iterable('')
    assert is_iterable('', True)



# Generated at 2022-06-24 20:16:58.701271
# Unit test for function is_iterable
def test_is_iterable():
    assert False, 'Not implemented'


# Generated at 2022-06-24 20:17:00.310920
# Unit test for function is_iterable
def test_is_iterable():
    result = is_iterable('variable')
    assert result is not None


# Generated at 2022-06-24 20:17:05.130504
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable(1) is False
    assert is_iterable(1, include_strings=True) is False
    assert is_iterable('abc')
    assert is_iterable('abc', include_strings=True)
    assert is_iterable(u'abc')
    assert is_iterable(u'abc', include_strings=True)
    assert is_iterable(b'abc')
    assert is_iterable(b'abc', include_strings=True)


# Generated at 2022-06-24 20:17:08.076567
# Unit test for function is_iterable
def test_is_iterable():
    x = 'text'
    is_iterable(x)
    y = ['text']
    is_iterable(y, include_strings=True)


# Generated at 2022-06-24 20:17:10.781422
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    bool_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:17:13.964586
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    hash_0 = ImmutableDict().__eq__(ImmutableDict())


if __name__ == '__main__':
    print(test_case_0())



# Generated at 2022-06-24 20:17:17.135449
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    if  immutable_dict_0.__eq__(immutable_dict_0):
        pass

# Generated at 2022-06-24 20:17:20.031806
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1]) is True
    assert is_iterable([]) is True
    assert is_iterable({}) is True
    assert is_iterable("test") is True
    assert is_iterable(1) is False


# Generated at 2022-06-24 20:17:28.482747
# Unit test for function is_iterable
def test_is_iterable():
    iterable_0 = ('a', 'b', 'c')
    var_0 = is_iterable(iterable_0)
    var_1 = is_iterable(iterable_0, True)



# Generated at 2022-06-24 20:17:32.012624
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:17:43.259349
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(range(3))
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable("")
    assert is_iterable(b"")
    assert not is_iterable(1)
    assert not is_iterable(None)
    assert not is_iterable(dict())
    assert is_iterable([], include_strings=True)
    assert is_iterable(range(3), include_strings=True)
    assert is_iterable({}, include_strings=True)
    assert is_iterable(set(), include_strings=True)
    assert is_iterable("", include_strings=True)
    assert is_iterable(b"", include_strings=True)

# Generated at 2022-06-24 20:17:44.546277
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    assert immutable_dict_0 == immutable_dict_1


# Generated at 2022-06-24 20:17:51.846310
# Unit test for function is_iterable
def test_is_iterable():
    ans = is_iterable([])
    assert ans == True

    ans = is_iterable(1)
    assert ans == False

    ans = is_iterable("test")
    assert ans == True

    ans = is_iterable({"test"})
    assert ans == True

    ans = is_iterable(set())
    assert ans == True

    ans = is_iterable((2, 3, 4))
    assert ans == True

    ans = is_iterable(range(6))
    assert ans == True

    ans = is_iterable(5.5)
    assert ans == False


# Generated at 2022-06-24 20:17:54.703508
# Unit test for function is_iterable
def test_is_iterable():
    assert True == is_iterable([])
    assert False == is_iterable(True)
    # if no suitable type is provided, the assert will fail
    assert False == is_iterable(None)


# Generated at 2022-06-24 20:17:56.532773
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    try:
        var_0 = immutable_dict_0.__eq__()
    except NotImplementedError:
        var_0 = None


# Generated at 2022-06-24 20:18:01.237247
# Unit test for function is_iterable
def test_is_iterable():
    sequence = "test"
    assert is_iterable(sequence) == True

    sequence = u'test'
    assert is_iterable(sequence) == True

    sequence = b'test'
    assert is_iterable(sequence) == True

    sequence = ['a', 'b', 'c']
    assert is_iterable(sequence) == True


# Generated at 2022-06-24 20:18:02.684558
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:18:04.179398
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_ImmutableDict = ImmutableDict()
    print(test_ImmutableDict.__eq__())


# Generated at 2022-06-24 20:18:15.961227
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    bool_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:18:20.051372
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0.__eq__(True)
    immutable_dict_0.__eq__("test_value")
    immutable_dict_0.__eq__("test_value")
    immutable_dict_0.__eq__("test_value")


# Generated at 2022-06-24 20:18:27.920462
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'a':'b'})
    immutable_dict_1 = ImmutableDict({'a':'b'})
    immutable_dict_2 = ImmutableDict({'a':'c'})
    immutable_dict_3 = {'a':'b'}
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)
    var_1 = immutable_dict_0.__eq__(immutable_dict_2)
    var_2 = immutable_dict_0.__eq__(immutable_dict_3)


# Generated at 2022-06-24 20:18:34.105407
# Unit test for function is_iterable
def test_is_iterable():
    string_test_0 = 'foo'
    string_test_1 = 'bar'
    string_test_2 = 'baz'
    string_test_2_alt = 'baz'
    list_test_0 = ['foo', 'bar', 'baz']
    list_test_1 = ['a', 'b', 'c']
    list_test_2 = ['a', 'd', 'e']
    assert is_iterable(list_test_0) == True, 'is_iterable(list_test_0) must return True'
    assert is_iterable(list_test_1) == True, 'is_iterable(list_test_1) must return True'
    assert is_iterable(list_test_2) == True, 'is_iterable(list_test_2) must return True'


# Generated at 2022-06-24 20:18:38.024800
# Unit test for function is_iterable
def test_is_iterable():
    for arg in [False, True, 0, 1, (), (0,), [], [0], {}, {0: 0}]:
        assert is_iterable(arg)
    for arg in [None]:
        assert not is_iterable(arg)
    for arg in ['', u'', b'']:
        assert not is_iterable(arg)
        assert is_iterable(arg, include_strings=True)


# Generated at 2022-06-24 20:18:40.457687
# Unit test for function is_iterable
def test_is_iterable():
    # assert_that(is_iterable(iter([]))).is_true()
    assert(is_iterable(range(10))) is True
    assert(is_iterable(10)) is False
    assert(is_iterable('')) is False
    assert(is_iterable([])) is True
    assert(is_iterable({})) is True
    assert(is_iterable(())) is True


test_is_iterable()

# Generated at 2022-06-24 20:18:43.352478
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    bool_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:18:46.250973
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    bool_0 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:18:48.245261
# Unit test for function is_iterable
def test_is_iterable():
    result = is_iterable([1,2])
    assert result == True


# Generated at 2022-06-24 20:18:57.658959
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0 = immutable_dict_0.union({'foo': 'bar'})
    if immutable_dict_0 != immutable_dict_0.union({'foo': 'bar'}):
        raise Exception("immutable_dict_0 != immutable_dict_0.union({'foo': 'bar'})")
    if immutable_dict_0 == immutable_dict_0.union({'foo': 'foo'}):
        raise Exception("immutable_dict_0 == immutable_dict_0.union({'foo': 'foo'})")


# Generated at 2022-06-24 20:19:12.962378
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) == True, \
        'Test 1: is_iterable([]) did not return True'

    assert is_iterable([1]) == True, \
        'Test 2: is_iterable([1]) did not return True'

    assert is_iterable([1, 2, 3, 4]) == True, \
        'Test 3: is_iterable([1, 2, 3, 4]) did not return True'

    assert is_iterable('') == False, \
        'Test 4: is_iterable(\'\') did not return False'

    assert is_iterable('hello') == False, \
        'Test 5: is_iterable(\'hello\') did not return False'


# Generated at 2022-06-24 20:19:16.398892
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test case 0
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = deepcopy(immutable_dict_0)
    assert immutable_dict_0.__eq__(immutable_dict_1) == True


# Generated at 2022-06-24 20:19:26.525500
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0 == immutable_dict_1
    immutable_dict_0 = ImmutableDict(a=1)
    immutable_dict_0 = ImmutableDict({'a': 1}, b=2)
    immutable_dict_0 = ImmutableDict({'a': 1}, b=2)
    immutable_dict_1 = ImmutableDict({'a': 1}, b=2)
    var_1 = immutable_dict_0 == immutable_dict_1
    immutable_dict_0 = ImmutableDict(a=1, b=2)
    immutable_dict_1 = ImmutableDict(b=2, a=1)
    var_2 = immutable_dict_0 == immutable_dict

# Generated at 2022-06-24 20:19:28.978482
# Unit test for function is_iterable
def test_is_iterable():
    iterable = [1, 2, 3]
    assert is_iterable(iterable)
    non_iterable = 1
    assert not is_iterable(non_iterable)


# Generated at 2022-06-24 20:19:32.583100
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable((x for x in range(0)))
    assert not is_iterable(1)
    assert not is_iterable('a string')
    assert not is_iterable(True)
    assert not is_iterable(None)
    assert not is_iterable(object)



# Generated at 2022-06-24 20:19:36.565073
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:19:43.430555
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'a': 1, 'b': 2})
    immutable_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)
    assert var_0 == True



# Generated at 2022-06-24 20:19:51.599232
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    print("Testing __eq__()")

    id0 = ImmutableDict()
    id1 = ImmutableDict({'a': 1, 'b': 2})
    id2 = ImmutableDict({'a': 1, 'b': 2})
    id3 = ImmutableDict({'a': 1})

    print("AssertFalse: id0 eq id1")
    assert not id0 == id1

    print("AssertFalse: id1 eq id3")
    assert not id1 == id3

    print("AssertTrue:  id1 eq id2")
    assert id1 == id2

    print("AssertFalse: id0 eq 'string'")
    assert not id0 == 'string'

if __name__ == '__main__':
    test_case_0()
    test_ImmutableDict___eq__

# Generated at 2022-06-24 20:19:57.492928
# Unit test for function is_iterable
def test_is_iterable():
    immutable_dict_0 = ImmutableDict()
    var_0 = is_iterable(immutable_dict_0)
    binary_type_0 = Binary()
    var_1 = is_iterable(binary_type_0)
    text_type_0 = Text()
    var_2 = is_iterable(text_type_0)


# Generated at 2022-06-24 20:19:59.040577
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0.__eq__()



# Generated at 2022-06-24 20:20:19.718207
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('foo')
    assert is_iterable([1, 2, 3])
    assert is_iterable({'a': 1, 'b': 2})
    assert not is_iterable(1)
    assert not is_iterable(True)
    assert not is_iterable(None)


# Generated at 2022-06-24 20:20:25.071586
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    assert immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:20:26.873575
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(bool())


# Generated at 2022-06-24 20:20:28.504065
# Unit test for function is_iterable
def test_is_iterable():
    result = is_iterable((1, 2, 3))
    assert result is True


# Generated at 2022-06-24 20:20:34.305031
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1,2,3])
    assert is_iterable((1,2,3))
    assert not is_iterable(1)
    assert not is_iterable(None)
    assert not is_iterable(str())
    assert not is_iterable('abc')
    assert not is_iterable(unicode())
    assert not is_iterable(u'abc')


# Generated at 2022-06-24 20:20:42.675775
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('a string', False)
    assert is_iterable(('a', 'tuple'), False)
    assert is_iterable(['a', 'list'], False)
    assert is_iterable({'a': 'dictionary'}, False)
    assert is_iterable(54, False)
    assert is_iterable(5.4, False)

    assert is_iterable('a string', True)
    assert is_iterable(('a', 'tuple'), True)
    assert is_iterable(['a', 'list'], True)
    assert is_iterable({'a': 'dictionary'}, True)
    assert not is_iterable(54, True)
    assert not is_iterable(5.4, True)



# Generated at 2022-06-24 20:20:51.311820
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    immutable_dict_2 = ImmutableDict()

    # Test when the object being compared is the same object
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)
    # Test when the object being compared is a different object that is equal to the original
    var_1 = immutable_dict_0.__eq__(immutable_dict_1)
    # Test when the object being compared is a different object that is not equal to the original
    var_2 = immutable_dict_0.__eq__(immutable_dict_2)

    # Test when the object being compared is not an ImmutableDict
    var_3 = immutable_dict_0.__eq__(1.2)

# Test

# Generated at 2022-06-24 20:20:54.633050
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({})
    mutable_dict_0 = {}
    var_0 = immutable_dict_0 == mutable_dict_0


# Generated at 2022-06-24 20:21:00.043429
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    immutable_dict_2 = ImmutableDict()
    immutable_dict_3 = ImmutableDict()
    # Test case for condition: when isinstance(other, Hashable) is True
    immutable_dict_1.__eq__(immutable_dict_2)
    # Test case for condition: when other is not isinstance(other, Hashable)
    immutable_dict_1.__eq__(immutable_dict_3)
    # Test case for condition: when other is not isinstance(other, Hashable)
    immutable_dict_1.__eq__(immutable_dict_3)


# Generated at 2022-06-24 20:21:02.750807
# Unit test for function is_iterable
def test_is_iterable():
    result = is_iterable('test', True)
    assert result == True


# Generated at 2022-06-24 20:21:39.520822
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_1.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:21:41.905266
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable("abc") is True
    assert is_iterable("abc", True) is True
    assert is_iterable("abc", False) is False



# Generated at 2022-06-24 20:21:46.935021
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable('text')
    assert not is_iterable(u'unicode')
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({})
    assert is_iterable({1: 2, 3: 4})
    assert is_iterable({'a': 'b'})
    assert not is_iterable(1)


# Generated at 2022-06-24 20:21:53.471078
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(u'abc') == True
    assert is_iterable(u'abc', True) == True
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable(tuple([1, 2, 3])) == True
    assert is_iterable(set([1, 2, 3])) == True
    assert is_iterable(frozenset([1, 2, 3])) == True
    assert is_iterable({1: 2, 3: 4}) == True
    assert is_iterable({1: 2, 3: 4}.keys()) == True
    assert is_iterable(1) == False


# Generated at 2022-06-24 20:22:02.530575
# Unit test for function is_iterable
def test_is_iterable():
    try:
        assert is_iterable([])
        assert is_iterable((), include_strings=True)
        assert is_iterable({})
        assert is_iterable('some_string')
        assert is_iterable(True)
        assert is_iterable(1)
        assert is_iterable((x for x in range(10)))
        assert is_iterable(is_iterable)
        assert not is_iterable(None)
        assert not is_iterable(False)
        assert not is_iterable(0)
        assert not is_iterable(is_iterable, include_strings=False)
        assert not is_iterable([], include_strings=True)
        assert not is_iterable((), include_strings=False)
    except Exception:
        import traceback
        traceback.print_

# Generated at 2022-06-24 20:22:04.728372
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(1)


# Generated at 2022-06-24 20:22:08.650342
# Unit test for function is_iterable
def test_is_iterable():
    check_iterable = ["string", 1, {"key": "value"}, [2, 3]]
    not_iterable = 1

    for item in check_iterable:
        assert is_iterable(item)

    assert not is_iterable(not_iterable)


# Generated at 2022-06-24 20:22:11.287669
# Unit test for function is_iterable
def test_is_iterable():
    a = [1, 2, 3]
    assert is_iterable(a)

    b = 3
    assert is_iterable(b) == False

# Generated at 2022-06-24 20:22:20.170125
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    return ImmutableDict()
    return ImmutableDict({})
    return ImmutableDict(dict_a=1, dict_b=2)
    return ImmutableDict({'dict_a': 1, 'dict_b': 2})
    return ImmutableDict((('dict_a', 1), ('dict_b', 2)))
    return ImmutableDict(zip(('dict_a', 'dict_b'), (1, 2)))
    return ImmutableDict([['dict_a', 1], ['dict_b', 2]])
    return ImmutableDict({'dict_b': 2, 'dict_a': 1})
    return ImmutableDict(dict(dict_a=1, dict_b=2))
    return ImmutableDict([['dict_b', 2], ['dict_a', 1]])
    return Imm

# Generated at 2022-06-24 20:22:21.787783
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)
    assert var_0 == True


# Generated at 2022-06-24 20:23:49.684638
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) == True
    assert is_iterable(()) == True
    assert is_iterable({}) == True
    assert is_iterable('') == False
    assert is_iterable(None) == False
    assert is_iterable(1) == False



# Generated at 2022-06-24 20:23:55.319586
# Unit test for function is_iterable
def test_is_iterable():
    # Testing if the function raises an exception for non iterable input
    arg = 1
    try:
        is_iterable(arg)
        assert False, "Expected TypeError for non iterable input"
    except TypeError:
        assert True
    # Testing if the function returns proper value for iterable input, including string
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable("Hello World!") == True
    # Testing if the function returns proper value for iterable input, excluding string
    assert is_iterable([1, 2, 3], include_strings=False) == True
    assert is_iterable("Hello World!", include_strings=False) == False


# Generated at 2022-06-24 20:23:57.369313
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
  assert ImmutableDict.__eq__(ImmutableDict(), ImmutableDict())


# Generated at 2022-06-24 20:23:59.214855
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0 == ImmutableDict()
    var_1 = immutable_dict_0 == None


# Generated at 2022-06-24 20:24:02.824036
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:24:04.527599
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)
    assert var_0 == False


# Generated at 2022-06-24 20:24:05.938288
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert not is_iterable({})
    assert is_iterable(())


# Generated at 2022-06-24 20:24:11.218952
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(1)
    assert not var_0


# Generated at 2022-06-24 20:24:15.141929
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:24:24.902339
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert is_true(isinstance(immutable_dict_0, Hashable))
    assert is_true(isinstance(immutable_dict_0, Mapping))
    assert immutable_dict_0 == immutable_dict_1
    assert immutable_dict_0 == immutable_dict_0
    assert not immutable_dict_0 == immutable_dict_2
    assert not immutable_dict_0 == mutable_dict_0
    assert mutable_dict_0 == mutable_dict_0
    assert not mutable_dict_0 == immutable_dict_1
    assert mutable_dict_0 == mutable_dict_1
    assert not mutable_dict_0 == mutable_dict_2
