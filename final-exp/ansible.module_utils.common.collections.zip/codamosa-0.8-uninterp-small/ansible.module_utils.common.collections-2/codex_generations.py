

# Generated at 2022-06-24 20:14:52.039686
# Unit test for function is_iterable
def test_is_iterable():
    string = 'hello'
    int_list = [1, 2, 3]
    dict_a = dict()
    dict_b = {'key_a': 'value_a', 'key_b': 'value_b'}
    empty_set = None
    dict_c = dict(key_a=1, key_b=2)
    dict_d = dict(zip(['key_a', 'key_b'], ['value_a', 'value_b']))
    assert is_iterable(string)
    assert is_iterable(int_list)
    assert is_iterable(dict_a)
    assert is_iterable(dict_b)
    assert not is_iterable(empty_set)
    assert is_iterable(dict_c)
    assert is_iterable(dict_d)




# Generated at 2022-06-24 20:14:53.275853
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('a') == True


# Generated at 2022-06-24 20:14:59.876031
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    sample = ImmutableDict({'z':3, 'b':2, 'a':1, 'c':1, 'd':1})
    assert sample.difference({'z':3}) == ImmutableDict({'b':2, 'a':1, 'c':1, 'd':1})
    try:
        sample.difference({'z':4})
        assert False
    except Exception:
        pass
    assert sample.difference(['z','a','c']) == ImmutableDict({'b':2, 'd':1})


# Generated at 2022-06-24 20:15:08.946889
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # Create an example dictionary
    example = ImmutableDict(a=1, b=2, c=3)
    # Create an ImmutableDict as a copy of example with key 'b' removed
    without_b = example.difference(['b'])
    # Check that key 'b' has been removed
    assert without_b == ImmutableDict(a=1, c=3)
    # Check that no other keys have been removed
    assert 'a' in without_b and 'c' in without_b
    # Check that 'without_b' is a different object from 'example'
    assert 'without_b' is not 'example'


# Generated at 2022-06-24 20:15:14.721997
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    arg_0 = ImmutableDict()
    if arg_0 == {'foo': 'bar'}:
        var_0 = 5
    else:
        var_0 = 3
    if arg_0 == ImmutableDict():
        var_1 = 7
    else:
        var_1 = 2
    return var_0, var_1



# Generated at 2022-06-24 20:15:15.863909
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    i = ImmutableDict({'one': 1, 'two': 2})
    assert i == i


# Generated at 2022-06-24 20:15:25.008973
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    int_0 = 1378
    var_1 = ImmutableDict({})
    var_1 = ImmutableDict({})
    var_2 = ImmutableDict({})
    var_2 = ImmutableDict({})
    var_3 = ImmutableDict({})
    var_3 = ImmutableDict({})
    var_4 = ImmutableDict({})
    var_4 = ImmutableDict({})
    var_5 = ImmutableDict({})
    var_5 = ImmutableDict({})
    var_6 = ImmutableDict({})
    var_6 = ImmutableDict({})
    var_7 = ImmutableDict({})
    var_7 = ImmutableDict({})
    var_8 = ImmutableDict({})
    var_8 = ImmutableDict({})

# Generated at 2022-06-24 20:15:28.849296
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    var_0 = ImmutableDict({'a': 1, 'b': 2})
    var_1 = var_0.difference(('a',))
    assert var_1 == {'b': 2}



# Generated at 2022-06-24 20:15:37.425813
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test for __eq__ method of class ImmutableDict"""
    dict_0 = ImmutableDict({1:1, 2:2})
    dict_1 = ImmutableDict({1:1, 2:2})
    dict_2 = ImmutableDict({1:1, 2:2, 3:3})
    dict_3 = ImmutableDict({1:1, 2:2, 3:4})
    dict_4 = ImmutableDict({1:1, 2:4})
    dict_5 = ImmutableDict({1:1, 2:2, 3:6})
    dict_6 = ImmutableDict({1:1, 2:2, 3:3, 4:5})
    dict_7 = ImmutableDict({1:1, 2:2, 3:3, 4:4, 5:7})

# Generated at 2022-06-24 20:15:40.759278
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict({"a": 1, "b": 2, "c": 3})
    new = original.difference(["b", "c"])
    assert new == ImmutableDict({"a": 1})


# Generated at 2022-06-24 20:15:50.066804
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    float_9 = float()
    float_10 = float()
    float_11 = float()
    float_12 = float()
    float_13 = float()
    float_14 = float()
    float_15 = float()
    float_16 = float()
    float_17 = float()
    float_18 = float()
    int_0 = int()
    list_0 = []
    str_0 = str()
    tuple_0 = (str_0, int_0, )

# Generated at 2022-06-24 20:15:53.768916
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1,2,3])
    assert is_iterable((1,2,3))
    assert is_iterable({'a':1,'b':2})
    assert is_iterable(range(10))
    assert not is_iterable(123)



# Generated at 2022-06-24 20:16:00.871905
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable(1) == False
    assert is_iterable((1, 2, 3)) == True
    assert is_iterable('foo') == True
    assert is_iterable({'foo':1}) == True
    assert is_iterable(None) == False
    assert is_iterable(set([1, 2, 3])) == True
    assert is_iterable(True) == False
    assert is_iterable(1.0) == False


# Generated at 2022-06-24 20:16:05.215414
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    immutable_dict_0 = ImmutableDict({'c': '', 'b': 4, 'v': 4, 'y': 7, 'z': 3, 'e': 5, 'a': 3, 'n': '', 'd': 5})
    immutable_dict_1 = immutable_dict_0.difference(['z', 'd', 'e', 'a', 'c', 'y'])
    assert immutable_dict_1 == {'b': 4, 'v': 4, 'n': ''}

# Generated at 2022-06-24 20:16:10.360873
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    new_dict = ImmutableDict({u'a': u'1', u'b': u'2', u'c': u'3', u'd': u'4'})
    differences = new_dict.difference([u'b', u'c'])
    assert differences == ImmutableDict({u'a': u'1', u'd': u'4'})


# Generated at 2022-06-24 20:16:15.659626
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_map = {'key_0': 'value_0', 'key_1': 'value_1', 'key_2': 'value_2'}
    test_map_0 = ImmutableDict(test_map)
    test_map_1 = ImmutableDict(test_map)
    assert test_map_0 == test_map_1


# Generated at 2022-06-24 20:16:24.161773
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_obj = ImmutableDict({"a": 1, "b": 2})
    test_obj2 = ImmutableDict({"a": 1, "b": 2, "c": 3})
    test_obj3 = ImmutableDict({"a": 1, "b": 2, "c": 3})
    test_obj4 = ImmutableDict({"a": 1, "b": 2, "c": 4})
    assert test_obj != test_obj2
    assert test_obj2 == test_obj3
    assert test_obj3 != test_obj4


# Generated at 2022-06-24 20:16:29.733682
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'srv': '172.16.30.250', 'username': 'admin', 'password': '', 'port': '12306', 'timeout': '300', 'privatekey_passphrase': None, 'become_method': 'enable', 'become_username': 'admin', 'become_password': '', 'become': True, 'remote_user': 'root', 'transport': 'cli'})

# Generated at 2022-06-24 20:16:31.874662
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    class_0 = ImmutableDict(var_0)
    class_1 = ImmutableDict(var_0)
    assert class_0 == class_1

test_case_0()

# Generated at 2022-06-24 20:16:33.474967
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['1','2','3']) == True
    assert is_iterable('a') == True


# Generated at 2022-06-24 20:16:50.432379
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    float_0 = 14.9818876958
    list_0 = [float_0, float_0]
    str_0 = 3.2
    dict_0 = {list_0: list_0}
    dict_1 = dict_0
    dict_2 = dict_0
    dict_3 = dict_0
    dict_4 = dict_0
    dict_5 = dict_0
    dict_6 = dict_0
    dict_7 = dict_0
    dict_8 = dict_0
    dict_9 = dict_0
    dict_10 = dict_0
    dict_11 = dict_0
    dict_12 = dict_0
    dict_13 = dict_0
    dict_14 = dict_0
    dict_15 = dict_0
    dict_16 = dict_0
    dict_

# Generated at 2022-06-24 20:16:59.398973
# Unit test for function is_iterable
def test_is_iterable():
    assert(not is_iterable(5.5))
    assert(is_iterable([1, 2, 3]))
    assert(is_iterable((1, 2, 3)))
    assert(is_iterable({'key1': 'value1', 'key2':'value2'}))
    assert(not is_iterable(None))
    assert(is_iterable('string'))
    assert(is_iterable(b'string'))
    assert(not is_iterable('string', include_strings=False))
    assert(not is_iterable(b'string', include_strings=False))



# Generated at 2022-06-24 20:17:05.928857
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    var_2 = ImmutableDict({'c': 3, 'b': 2, 'a': 1})
    var_3 = ImmutableDict({'a': 2, 'b': 2, 'c': 3})
    var_4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    var_5 = ImmutableDict({'l': 1, 'm': 2, 'n': 3})
    var_6 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    assert var_1 == var_2
    assert var_1 != var_3
    assert var_1 != var_4
    assert var

# Generated at 2022-06-24 20:17:09.129179
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    def __eq__(self, other):
        try:
            if self.__hash__() == hash(other):
                return True
        except TypeError:
            pass

        return False



# Generated at 2022-06-24 20:17:17.182493
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable(123) == False)
    assert(is_iterable('this_is_string') == True)
    assert(is_iterable('this_is_string', True) == True)
    assert(is_iterable((1, 2, 3)) == True)
    assert(is_iterable([1, 2, 3]) == True)
    assert(is_iterable({1, 2, 3}) == True)
    assert(is_iterable({'a': 1, 'b': 2}) == True)


# Generated at 2022-06-24 20:17:19.443970
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    arg_0 = ImmutableDict()
    arg_1 = ImmutableDict()
    arg_0.__eq__(arg_1)


# Generated at 2022-06-24 20:17:25.237177
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d_0 = ImmutableDict(one=1, two=2)
    d_1 = ImmutableDict(one=1, two=2)
    d_2 = ImmutableDict(one=1, two=3)
    d_3 = {'one': 1, 'two': 2}
    try:
        assert ((d_0 == d_1) is True)
    except Exception:
        assert False
    try:
        assert ((d_0 == d_2) is False)
    except Exception:
        assert False
    try:
        assert ((d_0 == d_3) is False)
    except Exception:
        assert False


# Generated at 2022-06-24 20:17:34.192304
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    from ansible.module_utils.six import PY3

    if not PY3:
        return

    immutable_dict_0 = (ImmutableDict())
    immutable_dict_1 = ImmutableDict()
    immutable_dict_1.__eq__(immutable_dict_0)

    immutable_dict_0 = (ImmutableDict({'1': 1, '2': 2}))
    immutable_dict_1 = ImmutableDict({'2': 2, '1': 1})
    immutable_dict_1.__eq__(immutable_dict_0)



# Generated at 2022-06-24 20:17:44.623523
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_data = {'param_0': 'value_0', 'param_1': 'value_1', 'param_2': 'value_2'}
    test_data_1 = {'param_2': 'value_2', 'param_0': 'value_0', 'param_1': 'value_1'}
    test_data_2 = {'param_0': 'value_0'}
    test_data_3 = {'param_1': 'value_1'}
    var_0 = ImmutableDict(test_data)
    var_1 = ImmutableDict(test_data_1)
    var_2 = ImmutableDict(test_data_2)
    var_3 = ImmutableDict(test_data_3)

# Generated at 2022-06-24 20:17:47.709150
# Unit test for function is_iterable
def test_is_iterable():
    # lets check if the function is_iterable works
    assert is_iterable({1: 1, 2: 2}) == True
    assert is_iterable([1, 2]) == True
    assert is_iterable(1) == False


# Generated at 2022-06-24 20:17:55.680384
# Unit test for function is_iterable
def test_is_iterable():
    pass    # Filled in the test below


# Generated at 2022-06-24 20:17:57.746094
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    m1 = ImmutableDict(mykey='myvalue')
    m2 = ImmutableDict(mykey='myvalue')
    m3 = ImmutableDict(mykey=dict(mykey='myvalue'))
    assert m1 == m2
    assert m1 != m3


# Generated at 2022-06-24 20:18:01.685008
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    string_0 = ImmutableDict({ImmutableDict({})})
    #
    # eq
    #
    string_0 = ImmutableDict({})
    assert string_0 == ImmutableDict({})
    assert not string_0 == ImmutableDict({},)


# Generated at 2022-06-24 20:18:08.526611
# Unit test for function is_iterable
def test_is_iterable():
    # Testing for expected list
    test_list = [1,2,3,4]
    assert is_iterable(test_list)
    # Testing for expected string
    test_string = "This is a test string"
    assert is_iterable(test_string)
    # Testing for expected string when include_strings is set to True
    test_string = "This is a test string"
    assert is_iterable(test_string, include_strings=True)
    # Testing for expected string when include_strings is set to False
    test_string = "This is a test string"
    assert not is_iterable(test_string, include_strings=False)
    # Testing for expected dictionary
    test_dict = {'Key1': 'value1', 'Key2': 'value2'}

# Generated at 2022-06-24 20:18:16.800454
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    float_0 = 2673.737
    str_2 = "ImmutableDict({1: 'a', 2: 'b'})".format(float_0)
    str_3 = "ImmutableDict({1: 'a', 2: 'b'})".format(float_0)
    str_4 = "ImmutableDict({1: 'a', 2: 'b'})".format(float_0)
    int_0 = 5
    list_0 = [0, 1, int_0]
    list_1 = [1, 2, 3]
    dict_0 = {0: list_0, 1: list_1, 2: list_1}
    dict_1 = {1: 'a', 2: 'b'}

# Generated at 2022-06-24 20:18:22.803695
# Unit test for function is_iterable
def test_is_iterable():
    test_iter = (1, 2, 3, 4, 5)
    test_str = '12345'

    assert is_iterable(test_iter)
    assert is_iterable(test_str, True)
    assert is_iterable(test_str) == False


# Generated at 2022-06-24 20:18:31.018898
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable((1, 2, 3)) == True)
    assert(is_iterable([1, 2]) == True)
    assert(is_iterable([]) == True)
    assert(is_iterable(set((1, 2, 3))) == True)
    assert(is_iterable(set()) == True)
    assert(is_iterable(range(1, 10)) == True)
    assert(is_iterable(range(0)) == True)
    assert(is_iterable(dict([(1, 2), (3, 4)])) == True)
    assert(is_iterable((1, 2, 3), include_strings=True) == True)
    assert(is_iterable('abc') == False)
    assert(is_iterable('abc', include_strings=True) == True)
   

# Generated at 2022-06-24 20:18:35.942253
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    float_0 = 9.0
    var_0 = ImmutableDict(float_0)
    float_1 = 9.0
    var_1 = ImmutableDict(float_1)
    float_2 = 9.0
    var_2 = ImmutableDict(float_2)
    # AssertionError: False != True
    assert var_0 == var_2
    # AssertionError: True != False
    assert var_1 == var_2


# Generated at 2022-06-24 20:18:46.720253
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Testing an empty ImmutableDict
    x = ImmutableDict()
    assert x == {}
    assert x != {'foo': 'bar'}
    y = ImmutableDict()
    assert x == y

    # Testing a populated ImmutableDict
    x = ImmutableDict(dict(foo='bar', baz='qux'))
    assert x == {'foo': 'bar', 'baz': 'qux'}
    assert x != {'foo': 'bar'}
    assert x != {'foo': 'bar', 'baz': 'quux'}
    assert x != {}
    y = ImmutableDict(dict(foo='bar', baz='qux'))
    assert x == y
    z = ImmutableDict(dict(foo='bar', baz='quux'))
    assert x

# Generated at 2022-06-24 20:18:52.538944
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(0)
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(range(0))
    assert is_iterable(set())
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')


# Generated at 2022-06-24 20:19:13.344884
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = dict({'key_2': 'value_2'})
    var_1 = ImmutableDict(var_0)
    var_2 = ImmutableDict({'key_3': 'value_3'})
    var_3 = dict({'key_2': 'value_2'})
    var_4 = ImmutableDict(var_0)
    var_4['key_4'] = 'value_4'
    print('{0:<30}'.format("Identity of var_0"), id(var_0))
    print('{0:<30}'.format("Identity of var_1"), id(var_1))
    print('{0:<30}'.format("Identity of var_2"), id(var_2))

# Generated at 2022-06-24 20:19:16.076179
# Unit test for function is_iterable
def test_is_iterable():
    assert (is_iterable(ImmutableDict()) is True)
    assert (is_iterable('string') is True)
    assert (is_iterable(1) is False)

# Generated at 2022-06-24 20:19:26.035132
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    float_0 = 8002.067
    tuple_0 = (string_0,)
    float_1 = 0.823
    dict_0 = dict()
    dict_0[string_0] = float_0
    tuple_1 = (string_0,)
    dict_1 = dict()
    dict_1[string_0] = float_1
    dict_2 = dict()
    dict_2[string_0] = float_1
    tuple_2 = (float_0,)
    list_0 = [float_0, string_0]
    dict_3 = dict()
    dict_3[string_0] = float_0
    tuple_3 = (float_0,)
    dict_4 = dict()
    dict_4[string_0] = float_0
    dict_4[string_1]

# Generated at 2022-06-24 20:19:31.669017
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 'b', 'c']) == True
    assert is_iterable(('a', 'b', 'c')) == True
    assert is_iterable(set('a', 'b', 'c')) == True
    assert is_iterable('abc') == False
    assert is_iterable('abc', include_strings=True) == True
    assert is_iterable(1) == False
    assert is_iterable(3.14159) == False
    assert is_iterable(None) == False


# Generated at 2022-06-24 20:19:34.962559
# Unit test for function is_iterable
def test_is_iterable():
    # Testing input argument that is of type String
    assert is_iterable('test_string', include_strings=True)
    # Testing input argument that is of type Dictionary
    assert is_iterable({'test': 'dict'})
    # Testing input argument that is of type List
    assert is_iterable([1, 2, 3])
    # Testing input argument that is not iterable
    assert not is_iterable(5)


# Generated at 2022-06-24 20:19:37.725924
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict({2: 2, 3: 2})
    dict_1 = ImmutableDict({3: 2, 2: 2})
    assert dict_0 == dict_1


# Generated at 2022-06-24 20:19:49.726303
# Unit test for function is_iterable
def test_is_iterable():
    try:
        float_0 = 5533.1354
        var_0 = is_iterable(float_0)
        float_1 = float_0
        var_1 = is_iterable(float_1)
    except Exception:
        var_1 = None
    try:
        float_0 = 40.25
        var_0 = is_iterable(float_0)
        float_1 = float_0
        var_1 = is_iterable(float_1)
    except Exception:
        var_1 = None
    try:
        float_0 = 40.25
        var_0 = is_iterable(float_0)
        float_1 = float_0
        var_1 = is_iterable(float_1, False)
    except Exception:
        var_1 = None

# Generated at 2022-06-24 20:19:52.090056
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_tmp = ImmutableDict()
    var_tmp_2 = ImmutableDict()
    assert not var_tmp == var_tmp_2



# Generated at 2022-06-24 20:19:55.616281
# Unit test for function is_iterable
def test_is_iterable():
    with pytest.raises(TypeError) as exception_info:
        test_case_0()
    assert "object of type 'float' has no len()" in str(exception_info.value)



# Generated at 2022-06-24 20:19:58.918467
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict({'key1': 'val1', 'key2': 'val2'})
    assert var_0.__eq__(var_0)


# Generated at 2022-06-24 20:20:37.676412
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    from ansible.module_utils.common._collections_compat import Hashable, Mapping
    immutable_dict_0 = ImmutableDict({})
    immutable_dict_1 = ImmutableDict({})
    if immutable_dict_0 == immutable_dict_1:
        var_0 = True
    else:
        var_0 = False
    var_1 = True
    if var_0 == var_1:
        var_2 = True
    else:
        var_2 = False
    var_3 = True
    if var_2 == var_3:
        var_4 = True
    else:
        var_4 = False
    immutable_dict_2 = ImmutableDict({})
    immutable_dict_3 = ImmutableDict({})
    immutable_dict_4 = ImmutableDict({})
   

# Generated at 2022-06-24 20:20:41.304387
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    mapping1 = ImmutableDict({'key': 'value', 'key2': 'value2'})
    mapping2 = ImmutableDict({'key': 'value', 'key2': 'value2'})
    assert mapping1.__eq__(mapping2)


# Generated at 2022-06-24 20:20:43.787586
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable((1, 2, 3))
    assert is_iterable([1, 2, 3])
    assert is_iterable({1: 1, 2: 2, 3: 3})
    assert is_iterable(set([1, 2, 3]))


# Generated at 2022-06-24 20:20:44.654130
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_case_0()

# Generated at 2022-06-24 20:20:49.868647
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable('abc') is False
    assert is_iterable('abc', include_strings=True) is True
    assert is_iterable(b'abc') is False
    assert is_iterable(b'abc', include_strings=True) is True
    assert is_iterable(2) is False
    assert is_iterable(1.1) is False
    assert is_iterable({'a': 1}) is True



# Generated at 2022-06-24 20:20:58.789200
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict = ImmutableDict({1: 1, 2: 2})
    # Test against the same dictionary
    assert (immutable_dict == {1: 1, 2: 2})

    # Test against another dictionary with the same content
    assert (immutable_dict == {2: 2, 1: 1})

    # Test against a different dictionary
    assert (not immutable_dict == {1: 2, 2: 2})

    # Test against a different iterable
    assert (not immutable_dict == (1, 2, 3))

    # Test against a tuple with the same content
    assert (immutable_dict == ((2, 2), (1, 1)))

    # Test against a tuple with the same content but in a different order
    assert (not immutable_dict == ((2, 2), (1, 1), (3, 3)))

    # Test against

# Generated at 2022-06-24 20:21:04.031526
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({'k': 'v'})
    assert is_iterable('abc')
    assert not is_iterable(42)



# Generated at 2022-06-24 20:21:08.356321
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    x = ImmutableDict({'a': 0, 'b': 1})
    x_repr = repr(x)
    x_hash = hash(x)
    y = ImmutableDict({'b': 1, 'a': 0})
    z = ImmutableDict({'b': 1, 'a': 1})
    assert x == x
    assert x == y
    assert x != z
    assert x != x_repr
    assert x != x_hash


# Generated at 2022-06-24 20:21:14.539133
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_1 = ImmutableDict()
    var_2 = dict()
    var_3 = var_1.__eq__(var_2)

if __name__ == '__main__':
    test_case_0()

    # Unit tests for method __eq__ of class ImmutableDict
    test_ImmutableDict___eq__()

# Generated at 2022-06-24 20:21:21.477342
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict({'7': 'a', '9': 'e', '3': 'a', '6': 'c', '0': 'f', '8': '9', '2': '1', '4': 'b', '5': 'd', '1': '0'})
    var_1 = ImmutableDict({'1': '0', '2': '1', '3': 'a', '4': 'b', '5': 'd', '6': 'c', '7': 'a', '8': '9', '9': 'e', '0': 'f'})
    if not var_0.__eq__(var_1):
        raise Exception('Test failed')


# Generated at 2022-06-24 20:21:59.305066
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    x = ImmutableDict({'a': 1})
    y = ImmutableDict({'a': 1})

    assert x == y
    assert x == {'a': 1}
    assert {'a': 1} == x

    assert x != {'a': 2}
    assert x != '1'


# Generated at 2022-06-24 20:22:01.507460
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict({1: 2})
    var_1 = ImmutableDict({2: 3})
    var_0.__eq__(var_1)


# Generated at 2022-06-24 20:22:05.176286
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    float_0 = 5533.1354
    param = {'x': text_type(float_0)}
    param_0 = ImmutableDict(param)
    param_1 = {'x': float_0}
    equ_0 = param_0.__eq__(param_1)


# Generated at 2022-06-24 20:22:11.835748
# Unit test for function is_iterable
def test_is_iterable():
    var_9 = [1, 2, 3]
    var_10 = 'string'
    var_11 = {'test': 'value'}
    var_12 = False
    var_13 = (1, 2, 3)

    assert is_iterable(var_9)
    assert is_iterable(var_10)
    assert is_iterable(var_11)
    assert not is_iterable(var_12)
    assert is_iterable(var_13)


# Generated at 2022-06-24 20:22:19.611940
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable({}) == True
    assert is_iterable([]) == True
    assert is_iterable(()) == True
    assert is_iterable(set()) == True
    assert is_iterable(1) == False
    assert is_iterable(1.1) == False
    assert is_iterable('test') == True
    assert is_iterable('test', include_strings=True) == True
    assert is_iterable('test', include_strings=False) == False
    assert is_iterable(b'test', include_strings=True) == True
    assert is_iterable(b'test', include_strings=False) == False



# Generated at 2022-06-24 20:22:29.190880
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    float_0 = 3516.8491
    int_0 = 3928
    ImmutableDict_0 = dict()
    ImmutableDict_0_copy = dict()
    ImmutableDict_0_copy['key1'] = "value1"
    ImmutableDict_0_copy['key2'] = "value2"
    ImmutableDict_0_copy['key3'] = "value3"
    ImmutableDict_0_copy['key4'] = "value4"
    ImmutableDict_0_copy['key5'] = "value5"
    ImmutableDict_0_copy['key6'] = "value6"
    ImmutableDict_0_copy['key7'] = "value7"
    ImmutableDict_0_copy['key8'] = "value8"
    ImmutableD

# Generated at 2022-06-24 20:22:30.568651
# Unit test for function is_iterable
def test_is_iterable():
    var_0 = 'random_word'
    assert is_iterable(var_0)


# Generated at 2022-06-24 20:22:35.581541
# Unit test for function is_iterable
def test_is_iterable():
  """Unit test for is_iterable"""
  assert is_iterable('') == False
  assert is_iterable([]) == True
  assert is_iterable({}) == True
  assert is_iterable(set()) == True
  assert is_iterable(range(0,10)) == True
  assert is_iterable(0) == False
  assert is_iterable(0.0) == False
  assert is_iterable(True) == False
  assert is_iterable(False) == False
  assert is_iterable('', include_strings=True) == True

# Generated at 2022-06-24 20:22:36.535279
# Unit test for function is_iterable
def test_is_iterable():
    x = is_iterable(float)
    assert x == False



# Generated at 2022-06-24 20:22:41.832700
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict(('d', 0))
    var_1 = ImmutableDict(('a', 4), ('b', 2))
    var_2 = ImmutableDict(('a', 4), ('b', 3))
    var_3 = frozenset(('a', 'b'))
    var_4 = frozenset(('a', 'b', 'c'))
    var_5 = var_0.union(var_1)
    var_6 = var_0.union(var_4)
    var_7 = var_6.difference(var_1)
    assert var_7 == ImmutableDict(('a', 4), ('c', None))
    assert (var_5 == var_6) == False
    assert (var_0 == var_3) == False

# Generated at 2022-06-24 20:23:24.223832
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    mydict = ImmutableDict({'1':2, '2':3, '3':4})
    assert mydict == mydict
    assert not mydict == ImmutableDict({'1':2, '2':3, '3':4, '5':6})
    assert mydict != ImmutableDict({'1':2, '2':3, '3':4, '5':6})
    assert mydict == ImmutableDict({'3':4, '2':3, '1':2})


# Generated at 2022-06-24 20:23:29.049673
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Case 1: if the hashes are identical, return True
    a = ImmutableDict({'a': 1})
    b = ImmutableDict({'a': 1})
    assert a.__eq__(b) is True
    # Case 2: if the hashes are not identical, return False
    a = ImmutableDict({'a': 1})
    b = ImmutableDict({'b': 2})
    assert a.__eq__(b) is False
    # Case 3: if the input is not an ImmutableDict, return False
    a = ImmutableDict({'a': 1})
    b = {'a': 1}
    assert a.__eq__(b) is False


# Generated at 2022-06-24 20:23:34.059957
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('string') is True
    assert is_iterable('string', include_strings=False) is False
    assert is_iterable(b'bytes') is True
    assert is_iterable(b'bytes', include_strings=False) is False
    assert is_iterable([]) is True
    assert is_iterable({}) is True
    assert is_iterable(()) is True

# Generated at 2022-06-24 20:23:40.391558
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('test')
    assert is_iterable(5)
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1, 2, 3})
    assert is_iterable({1: 2, 3: 4})



# Generated at 2022-06-24 20:23:44.689418
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_0 = ImmutableDict({'a': 2})
    var_1 = {'a': 2}
    var_2 = (var_0 == var_1)
    var_2 = (var_0 == var_0)


# Generated at 2022-06-24 20:23:47.309125
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_1 = ImmutableDict({'foo': 'bar'})
    var_2 = ImmutableDict({'foo': 'bar'})
    var_1 == var_2


# Generated at 2022-06-24 20:23:52.483939
# Unit test for function is_iterable
def test_is_iterable():
    # assert type(is_iterable('example')) == bool
    assert is_iterable('example') == True
    assert is_iterable('example', True) == True
    assert is_iterable('example', False) == False
    assert is_iterable([]) == True
    assert is_iterable({}) == True
    assert is_iterable(()) == True
    assert is_iterable(1) == False
    assert is_iterable(1, True) == False
    assert is_iterable(1, False) == False


# Generated at 2022-06-24 20:23:57.327219
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable(123) == False
    assert is_iterable('not_iterable') == False
    assert is_iterable(iter([1, 2, 3])) == True
    assert is_iterable((1, 2, 3)) == True
    assert is_iterable(iter((1, 2, 3))) == True


# Generated at 2022-06-24 20:24:05.236729
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dct_0 = ImmutableDict(['d', 'e', 'c', 'a', 'b'], [8.9, 'r', 10.2, 8.3, 12.7], range(10))
    dct_1 = ImmutableDict(['b', 'c', 'a', 'e', 'd'], [12.7, 10.2, 8.3, 'r', 8.9], range(10))
    var_0 = dct_0 == dct_1


# Generated at 2022-06-24 20:24:12.557804
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # A basic test of the equality method of ImmutableDict
    var_0 = ImmutableDict({'dogs': 4, 'cats': 3})
    expected = ImmutableDict({'dogs': 4, 'cats': 3})
    actual = var_0.__eq__(expected)
    assert eq(actual, 1)
