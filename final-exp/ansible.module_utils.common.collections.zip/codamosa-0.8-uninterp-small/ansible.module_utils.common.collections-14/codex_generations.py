

# Generated at 2022-06-24 20:15:00.470605
# Unit test for function is_iterable
def test_is_iterable():
    param_0 = ('', '', )
    # Assertion: bool (param_0)
    try:
        assert is_iterable(param_0)
    except AssertionError:
        raise

    param_1 = None
    # Assertion: bool (param_1)
    try:
        assert not is_iterable(param_1)
    except AssertionError:
        raise

    param_2 = 'a'
    # Assertion: bool (param_2)
    try:
        assert is_iterable(param_2)
    except AssertionError:
        raise

    param_3 = 0
    # Assertion: bool (param_3)
    try:
        assert is_iterable(param_3)
    except AssertionError:
        raise

    param_4

# Generated at 2022-06-24 20:15:07.074397
# Unit test for function is_iterable
def test_is_iterable():
    test_iterable = [1, 2, 3]
    test_non_iterable = 42
    test_string = 'test'
    assert is_iterable(test_iterable)
    assert not is_iterable(test_non_iterable)
    assert not is_iterable(test_string)
    assert is_iterable(test_string, include_strings=True)


# Generated at 2022-06-24 20:15:16.477214
# Unit test for function is_iterable
def test_is_iterable():
    for seq, expected in [
            ("", True),
            ("abc", True),
            (u"abc", True),
            (u"abc", True),
            (b"abc", True),
            (b"abc", True),
            ([], True),
            ({}, True),
            (set(), True),
            (True, False),
            (False, False),
            (None, False),
            (1, False),
    ]:
        result = is_iterable(seq)
        assert result == expected, '`{0}` => {1} != {2}'.format(seq, result, expected)


# Generated at 2022-06-24 20:15:19.474187
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0 = immutable_dict_0.union({'pepper': 'black', 'cumin': 'ground'})
    immutable_dict_1 = ImmutableDict()
    immutable_dict_1 = immutable_dict_1.union({'cumin': 'ground', 'pepper': 'black'})
    boolean_0 = immutable_dict_0.__eq__(immutable_dict_1)



# Generated at 2022-06-24 20:15:22.696367
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:15:26.114094
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = ImmutableDict.__eq__(immutable_dict_0, immutable_dict_1)
    assert var_0 == True, ('ImmutableDict.__eq__(immutable_dict_0, immutable_dict_1) returned unexpected result.'
                           '\nExpected: True\nActual: %s' % (str(var_0)))


# Generated at 2022-06-24 20:15:35.303527
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'as': 8, 'a': 'a', 'd': 'd', 'F': 'F', 'h': 'h'})
    immutable_dict_1 = ImmutableDict({'d': 'd', 'a': 'a', 'h': 'h', 'as': 8, 'F': 'F'})
    immutable_dict_2 = ImmutableDict({'a': 'a', 'h': 'h', 'as': 8, 'd': 'd', 't': 't'})
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)
    var_1 = immutable_dict_1.__eq__(immutable_dict_2)

# Generated at 2022-06-24 20:15:38.015064
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    bool_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:15:42.390743
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable('string')
    assert not is_iterable(1)
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable((x for x in range(3)))
    assert is_iterable('string', True)
    assert not is_iterable(1, True)


# Generated at 2022-06-24 20:15:43.523592
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0.__eq__()


# Generated at 2022-06-24 20:15:48.684680
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'key_3' : 'value_3'})
    val_0 = immutable_dict_0.__eq__(mutable_dict_0)
    assert( val_0 == True)


# Generated at 2022-06-24 20:15:54.698988
# Unit test for function is_iterable
def test_is_iterable():
    # Test with a string object
    test_string = 'Hello'
    assert True == is_iterable(test_string)

    # Test with a dictionary object
    test_dict = {'key1': 'value1', 'key2': 'value2'}
    assert True == is_iterable(test_dict)


# Generated at 2022-06-24 20:15:56.757716
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(['a', 'b', 1, 2])
    assert not is_iterable('a')
    assert not is_iterable(1)



# Generated at 2022-06-24 20:16:02.302786
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'b': 'a', 'f': 'd', 'd': 'a'})
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)
    assert var_0 == True


# Generated at 2022-06-24 20:16:04.000560
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:16:14.182133
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)
    immutable_dict_1 = ImmutableDict({'a': 1, 'c': 3, 'b': 2})
    var_1 = immutable_dict_1.__eq__(immutable_dict_1)
    immutable_dict_2 = ImmutableDict({'a': 1, 'b': 2})
    var_2 = immutable_dict_2.__eq__(immutable_dict_2)
    immutable_dict_3 = ImmutableDict()
    var_3 = immutable_dict_3.__eq__(immutable_dict_3)


# Generated at 2022-06-24 20:16:16.618277
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = ImmutableDict()
    immutable_dict_0.__eq__(var_0)


# Generated at 2022-06-24 20:16:25.268019
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('asdf') == True, 'Argument provided is string, so the method should return True'
    assert is_iterable(['a', 'b', 'c']) == True, 'Argument provided is list, so the method should return True'
    assert is_iterable(15) == False, 'Argument provided is int, so the method should return False'
    assert is_iterable(['a', 'b', 'c'], include_strings=True) == True, 'Argument provided is list, so the method should return True'
    assert is_iterable('asdf', include_strings=False) == False, 'Argument provided is string and include_strings is False, so the method should return False'

# Generated at 2022-06-24 20:16:30.551282
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:16:37.289306
# Unit test for function is_iterable
def test_is_iterable():
    from ansible.module_utils.common._collections_compat import UserDict
    import types
    immutable_dict_0 = ImmutableDict()
    some_tuple = ('a', 'b', 'c')
    some_string = '123456789'
    user_dict = UserDict()
    user_dict['hi'] = 'there'
    user_dict['other'] = 'thing'
    user_dict['hey'] = 'man'
    dict_0 = dict()
    dict_0['key_0'] = 'value_0'
    dict_0['key_1'] = 'value_1'
    dict_0['key_2'] = 'value_2'
    dict_0['key_3'] = 'value_3'
    dict_0['key_4'] = 'value_4'

# Generated at 2022-06-24 20:16:40.516922
# Unit test for function is_iterable
def test_is_iterable():
    var_0 = is_iterable(var_0)


# Generated at 2022-06-24 20:16:50.691916
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(list()) == True
    assert is_iterable('abc') == True
    assert is_iterable(set()) == True
    assert is_iterable(dict()) == True
    assert is_iterable(dict().keys()) == True
    assert is_iterable((1, 2)) == True
    assert is_iterable(range(0)) == True
    assert is_iterable(1) == False
    assert is_iterable(dict().items()) == True
    assert is_iterable(dict().values()) == True
    assert is_iterable(dict().viewkeys()) == True
    assert is_iterable(dict().viewitems()) == True
    assert is_iterable(dict().viewvalues()) == True


# Generated at 2022-06-24 20:16:56.633554
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_eq_0 = immutable_dict_0.__eq__(immutable_dict_0)
    assert not immutable_dict_eq_0


# Generated at 2022-06-24 20:17:04.535432
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('abc')
    assert is_iterable(['abc', 'def'])
    assert is_iterable(('abc', 123))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable({1, 2, 3})
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())



# Generated at 2022-06-24 20:17:08.663254
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Initializing object
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict({'a': 1})

    # Testing for equality
    assert immutable_dict_1 == immutable_dict_0

    # Testing for non-equality
    assert immutable_dict_1 != immutable_dict_0


# Generated at 2022-06-24 20:17:17.458511
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test case 0
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()

    # Test case 1
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = None

    # Test case 2
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict(with_key="with_value")

    # Test case 3
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict(without_key="without_value")


# Generated at 2022-06-24 20:17:22.633337
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:17:27.373318
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Verify that __eq__ compares the hashes of two ImmutableDicts
    immutable_dict_0 = ImmutableDict()

    assert(immutable_dict_0.__eq__(ImmutableDict()) == True)


# Generated at 2022-06-24 20:17:33.836962
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """ Test for method ImmutableDict.__eq__ """
    immutable_dict_0 = ImmutableDict()
    try:
        immutable_dict_0.__eq__(1)
    except TypeError:
        assert True


# Generated at 2022-06-24 20:17:44.339144
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(None) is False
    assert is_iterable(42) is False
    assert is_iterable(set()) is True
    assert is_iterable({}) is True
    assert is_iterable([]) is True
    assert is_iterable(b'') is True
    assert is_iterable(u'') is True
    assert is_iterable(()) is True
    assert is_iterable('foo') is False
    assert is_iterable('foo', include_strings=True) is True
    assert is_iterable(b'foo') is False
    assert is_iterable(b'foo', include_strings=True) is True
    assert is_iterable(u'foo') is False
    assert is_iterable(u'foo', include_strings=True) is True


# Generated at 2022-06-24 20:17:48.518346
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    try:
        immutable_dict_0.__eq__(0)
    except TypeError:
        pass
    else:
        pass


# Generated at 2022-06-24 20:17:51.055026
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:17:53.607115
# Unit test for function is_iterable
def test_is_iterable():
    # Set up mock
    isinstance = MagicMock(side_effect=(False, True))
    # Call method
    result = is_iterable([], include_strings=True)
    # Check that correct method was called and return correct value
    isinstance.assert_called_once_with([], collections.Iterable)
    assert result == True



# Generated at 2022-06-24 20:18:00.053364
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'a': 1, 'b': 2})
    immutable_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:18:02.967626
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    immutable_dict_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    immutable_dict_2 = ImmutableDict({'b': 2, 'a': 1, 'c': 3})

    var_1 = immutable_dict_0.__eq__(immutable_dict_1)
    var_2 = immutable_dict_0.__eq__(immutable_dict_2)



# Generated at 2022-06-24 20:18:05.967690
# Unit test for function is_iterable
def test_is_iterable():
    assert True == is_iterable(42)
    assert False == is_iterable('string')
    assert True == is_iterable([1, 2, 3])
    assert True == is_iterable((1, 2, 3))
    assert True == is_iterable({})
    assert True == is_iterable(set())


# Generated at 2022-06-24 20:18:08.090619
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = isinstance(immutable_dict_0.__eq__(immutable_dict_0), bool)


# Generated at 2022-06-24 20:18:13.219344
# Unit test for function is_iterable
def test_is_iterable():
    dct = {'ansible': 'rocks'}
    assert is_iterable(dct), "Dictionary is iterable"
    assert not is_iterable(dct, include_strings=True), "Dictionary is not a string"
    assert is_iterable(dict), "Dictionary class is iterable"
    assert not is_iterable(dict, include_strings=True), "Dictionary class is not a string"

    lst = ['list', 'is', 'iterable']
    assert is_iterable(lst), "List is iterable"
    assert not is_iterable(lst, include_strings=True), "List is not a string"

    buf = buffer('buffer is not iterable in py2')
    assert not is_iterable(buf), "Buffer is not iterable"
    assert not is_iter

# Generated at 2022-06-24 20:18:17.174926
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([2, 3, 4])
    assert not is_iterable('test_string')
    assert is_iterable('test_string', include_strings=True)



# Generated at 2022-06-24 20:18:24.187685
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable((x for x in range(1, 10)))

    # String types are not iterable
    assert not is_iterable('string')
    assert not is_iterable(u'unicode')
    assert not is_iterable(b'bytes')



# Generated at 2022-06-24 20:18:31.459239
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    str_0 = immutable_dict_0.__eq__('*q')
    str_1 = immutable_dict_0.__eq__(':')
    str_2 = immutable_dict_0.__eq__('2')


# Generated at 2022-06-24 20:18:36.284322
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict(var_0())
    var_1 = immutable_dict_0.__eq__(immutable_dict_0)
    var_2 = immutable_dict_0.__eq__('QW50ZWdlZGQgZGVmYXVsdCBmb3Igb3RoZXIgZWxlbWVudHMnKSBpcyBub3Qgc3VwcG9ydGVk.')


# Generated at 2022-06-24 20:18:40.204818
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:18:43.929921
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'a': 1})
    var_0 = immutable_dict_0.__eq__(ImmutableDict({'a': 1}))
    assert var_0 == True


# Generated at 2022-06-24 20:18:51.765138
# Unit test for function is_iterable
def test_is_iterable():
    seq = (1, 2, 3)
    assert is_iterable(seq)
    seq = [1, 2, 3]
    assert is_iterable(seq)
    seq = "this is a string"
    assert is_iterable(seq)
    seq = "this is\na string"
    assert is_iterable(seq)
    assert is_string(seq)
    seq = b'0123456789'
    assert is_iterable(seq)
    assert is_string(seq)
    assert not is_sequence(seq)
    seq = {'one': 1, 'two': 2}
    assert is_iterable(seq)
    seq = {'one', 'two', 'three'}
    assert is_iterable(seq)
    assert is_sequence(seq)

# Generated at 2022-06-24 20:18:55.953202
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(var_0)


# Generated at 2022-06-24 20:19:02.108244
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Create an instance of ImmutableDict
    immutable_dict_0 = ImmutableDict()

    # Assert that the two dicts are not equal
    var_0 = immutable_dict_0.__eq__({})
    assert var_0 == False, "%s" % var_0
    # Assert that the two dicts are equal
    var_1 = immutable_dict_0.__eq__(ImmutableDict())
    assert var_1 == True, "%s" % var_1



# Generated at 2022-06-24 20:19:05.325083
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_1 = ImmutableDict()
    immutable_dict_2 = ImmutableDict()
    var_1 = (immutable_dict_1 == immutable_dict_2)


# Generated at 2022-06-24 20:19:08.470602
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:19:15.488310
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable((1, 2)) is True
    assert is_iterable([1, 2]) is True
    assert is_iterable({'a': 'b'}) is True
    assert is_iterable({}) is True
    assert is_iterable(None) is False
    assert is_iterable(1) is False
    assert is_iterable('not iterable') is False
    assert is_iterable(u'unicode is not iterable') is False
    assert is_iterable('unicode is not iterable', include_strings=True) is True



# Generated at 2022-06-24 20:19:23.478042
# Unit test for function is_iterable
def test_is_iterable():
    seq_0 = 'hello'
    var_0 = is_iterable(seq_0)
    return var_0


# Generated at 2022-06-24 20:19:24.478462
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable("")


# Generated at 2022-06-24 20:19:28.891699
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable({})
    assert is_iterable([])
    assert is_iterable(tuple())
    assert not is_iterable(None)
    assert is_iterable(u'content')
    assert is_iterable(b'content')
    assert is_iterable('content')
    assert not is_iterable(12345)
    assert not is_iterable(10.4)
    assert is_iterable({1, 2, 3})
    assert is_iterable(set({1, 2, 3}))


# Generated at 2022-06-24 20:19:30.820297
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:19:39.579779
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_1 = ImmutableDict({'b': 2, 'a': 1, 'c': 3})
    var_1 = immutable_dict_1.__eq__({'a': 1, 'b': 2, 'c': 3})
    immutable_dict_2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    var_2 = immutable_dict_2.__eq__({'a': 1, 'b': 2, 'c': 3})


# Generated at 2022-06-24 20:19:50.103173
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    immutable_dict_2 = ImmutableDict(foo='bar')
    immutable_dict_3 = ImmutableDict(foo='bar')
    immutable_dict_4 = ImmutableDict(foo='baz')
    var_0 = immutable_dict_0 == immutable_dict_1
    # True
    var_1 = immutable_dict_2 == immutable_dict_3
    # True
    var_2 = immutable_dict_2 == immutable_dict_4
    # False
    var_3 = immutable_dict_4 == immutable_dict_1
    # False
    var_4 = immutable_dict_2 == 'not_a_dict'
    # False
    var_5 = immutable_dict_2
    var_

# Generated at 2022-06-24 20:19:51.299295
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict().__eq__(0)


# Generated at 2022-06-24 20:19:58.014882
# Unit test for function is_iterable
def test_is_iterable():
    #test if the function returns True
    assert is_iterable(ImmutableDict())
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable((i for i in range(1)))
    assert is_iterable('abc')
    assert is_iterable(None)
    # test if the function returns False
    assert not is_iterable(123)


# Generated at 2022-06-24 20:20:06.394758
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test method __eq__ of class ImmutableDict"""

    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()

    # Test case for equality of two ImmutableDicts that have the same contents
    immutable_dict_1.__setitem__('test_key', 'test_value')
    immutable_dict_0.__setitem__('test_key', 'test_value')
    immutable_dict_2 = immutable_dict_0.union(immutable_dict_1)
    try:
        immutable_dict_1.__eq__(immutable_dict_2)
    except Exception as e:
        output = False
    else:
        output = True
    assert output

    # Test case for equality of two ImmutableDict that are different

# Generated at 2022-06-24 20:20:09.088691
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__('ImmutableDict({})')


# Generated at 2022-06-24 20:20:27.409978
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    i1 = ImmutableDict({"a": "b"})
    i2 = ImmutableDict({"a": "b"})
    assert i1.__hash__() == i2.__hash__()
    assert i1.__eq__(i2) == True
    assert i1.__eq__(i1) == True
    # compare to a different ImmutableDict
    assert i1.__eq__(i2.difference(["a"])) == False
    # compare to a regular dict
    assert i1.__eq__({"a": "b"}) == False
    assert i1.difference(["a"]).__eq__({"a": "b"}) == False


# Generated at 2022-06-24 20:20:30.446388
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_2 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:20:37.511708
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable((x for x in range(10)))
    assert is_iterable([1, 2, 3])
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(dict([(1, 1), (2, 2)]))
    assert is_iterable(ImmutableDict([(1, 1), (2, 2)]))
    assert is_iterable(u'abc')
    assert not is_iterable(1)
    assert not is_iterable(None)



# Generated at 2022-06-24 20:20:45.254312
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()

    if immutable_dict_0.__eq__(immutable_dict_1):
        raise AssertionError('ImmutableDict.__eq__ returned True, expected False')

    immutable_dict_2 = ImmutableDict({"var_0": True})
    immutable_dict_3 = ImmutableDict({"var_0": True})

    if not immutable_dict_2.__eq__(immutable_dict_3):
        raise AssertionError('ImmutableDict.__eq__ returned False, expected True')


# Generated at 2022-06-24 20:20:47.660353
# Unit test for function is_iterable
def test_is_iterable():
    var_0 = is_iterable({})
    var_1 = is_iterable(())
    var_2 = is_iterable([])
    var_3 = is_iterable(True)


# Generated at 2022-06-24 20:20:49.837404
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """ Test that two ImmutableDicts are equal based on their contents """
    list_0 = [('var_0', 'var_1'), ('var_2', 'var_3')]
    immutable_dict_0 = ImmutableDict(list_0)
    immutable_dict_1 = ImmutableDict(list_0)
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:20:53.033193
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict({'a' : 'b'})
    immutable_dict_0 == immutable_dict_1


# Generated at 2022-06-24 20:20:56.741191
# Unit test for function is_iterable
def test_is_iterable():
    from ansible.module_utils.common.collections import is_iterable
    assert is_iterable(None) == False
    assert is_iterable([1,2,3]) == True
    assert is_iterable(range(10)) == True
    assert is_iterable((1,2,3,4)) == True
    assert is_iterable({"a":"1", "b":"2"}) == True


# Generated at 2022-06-24 20:21:06.656608
# Unit test for function is_iterable
def test_is_iterable():
    def _assert(should_be_iterable, *args, **kwargs):
        assert should_be_iterable == is_iterable(*args, **kwargs)

    # True
    _assert(True, [])
    _assert(True, {})
    _assert(True, [1, 2, 3])
    _assert(True, 'abc')
    _assert(True, True)
    _assert(True, None)
    _assert(True, (1, 2, 3))
    _assert(True, 1)
    _assert(True, b'abc')
    _assert(True, (1,))

    # False
    _assert(False, 'abc', include_strings=False)
    _assert(False, b'abc', include_strings=False)



# Generated at 2022-06-24 20:21:11.533189
# Unit test for function is_iterable
def test_is_iterable():
    # Test with a list
    list_0 = []
    var_0 = is_iterable(list_0)
    # Test with a tuple
    tuple_0 = ()
    var_0 = is_iterable(tuple_0)
    # Test with a string
    string_0 = str()
    var_0 = is_iterable(string_0)
    # Test with a dictionary
    dictionary_0 = {}
    var_0 = is_iterable(dictionary_0)
    # Test with a set
    set_0 = set()
    var_0 = is_iterable(set_0)


# Generated at 2022-06-24 20:21:38.356391
# Unit test for function is_iterable
def test_is_iterable():
    x = 'test'
    assert is_iterable(x) == True
    x = ['test']
    assert is_iterable(x) == True
    x = {'test': 'tes2'}
    assert is_iterable(x) == True

# Generated at 2022-06-24 20:21:42.132905
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    data_0 = ImmutableDict()
    data_1 = ImmutableDict(test_var='test')
    data_1.test_var
    data_2 = ImmutableDict(test_var='test2', test_var2='test3')
    data_2.test_var


# Generated at 2022-06-24 20:21:49.577033
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'d': '6', 'f': 'g', 'a': 'b'})
    immutable_dict_1 = ImmutableDict({'d': '6', 'f': 'g', 'a': 'b'})
    immutable_dict_2 = ImmutableDict({'a': 'b', 'd': '6', 'f': 'g'})
    immutable_dict_3 = ImmutableDict({'d': '6', 'f': 'x', 'a': 'b'})

    var_0 = immutable_dict_0.__eq__(immutable_dict_1)  # True
    var_1 = immutable_dict_0.__eq__(immutable_dict_2)  # True

# Generated at 2022-06-24 20:21:53.581774
# Unit test for function is_iterable
def test_is_iterable():

    immutable_dict_0 = ImmutableDict()
    # Test with a case where is_iterable should return True
    assert is_iterable(immutable_dict_0)

    # Test with a case where is_iterable should return False
    assert not is_iterable("string")


# Generated at 2022-06-24 20:21:59.957991
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert not is_iterable(1)
    assert not is_iterable('abc')
    assert is_iterable({1, 2, 3})
    assert is_iterable({1:2, 3:4})
    assert not is_iterable(None)


# Generated at 2022-06-24 20:22:04.219579
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_1 = {'a': 2, 'c': 3}
    dict_2 = {'a': 2, 'b': 3}
    immutable_dict_1 = ImmutableDict(dict_1)
    immutable_dict_2 = ImmutableDict(dict_2)
    assert(immutable_dict_1.__eq__(immutable_dict_2))


# Generated at 2022-06-24 20:22:14.013530
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    arg_0 = dict(a=1, b=2, c=3)
    arg_1 = dict(b=2, a=1, c=3)
    arg_2 = dict(a=1, b=2, c=3)
    arg_3 = dict(d=4)
    arg_4 = dict(a=1, b=2, c=4)
    arg_5 = set(['a', 'b', 'c'])
    immutable_dict_0 = ImmutableDict(arg_0)
    immutable_dict_1 = ImmutableDict(arg_1)
    immutable_dict_2 = ImmutableDict(arg_2)
    immutable_dict_3 = ImmutableDict(arg_3)
    immutable_dict_4 = ImmutableDict(arg_4)
    var_0

# Generated at 2022-06-24 20:22:19.873735
# Unit test for function is_iterable
def test_is_iterable():
    # assert is_iterable('stringlike')
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable(('a', 'b', 'c'))
    assert is_iterable({})
    assert is_iterable({'one': 1, 'two': 2})
    assert is_iterable(frozenset((1, 2, 3)))

    # assert is_iterable(1)
    # assert is_iterable(True)



# Generated at 2022-06-24 20:22:25.064389
# Unit test for function is_iterable
def test_is_iterable():
    # Check if is_iterable returns true for sequence type
    sequence = ('a', 'b', 'c')
    assert is_iterable(sequence)

    # Check if is_iterable returns true for dictionary type
    dictionary = {'a': 1, 'b': 2, 'c': 3}
    assert is_iterable(dictionary)

    # Check if is_iterable returns false for string type
    string = 'abc'
    assert is_iterable(string) == False

    # Check if is_iterable returns true for sequence type by including string
    sequence = ('a', 'b', 'c')
    assert is_iterable(sequence, include_strings=True)

    # Check if is_iterable returns true for dictionary type by including string
    dictionary = {'a': 1, 'b': 2, 'c': 3}
   

# Generated at 2022-06-24 20:22:30.197900
# Unit test for function is_iterable
def test_is_iterable():
    seq = [1, 2, 3]  # list
    assert is_iterable(seq)
    seq = (1, 2, 3)  # tuple
    assert is_iterable(seq)
    seq = {1, 2, 3}  # set
    assert is_iterable(seq)
    seq = {1: 'a', 2: 'b', 3: 'c'}  # dict
    assert is_iterable(seq)
    seq = 'abc'  # str
    assert is_iterable(seq)

# Generated at 2022-06-24 20:23:40.903742
# Unit test for function is_iterable
def test_is_iterable():
    # Test with an empty array
    list_0 = []
    var_0 = is_iterable(list_0)
    var_1 = is_iterable(list_0, True)
    # Test with a non-empty array
    list_1 = [1, 2, 3]
    var_2 = is_iterable(list_1)
    var_3 = is_iterable(list_1, True)
    # Test with a tuple a
    tuple_0 = ()
    var_4 = is_iterable(tuple_0)
    var_5 = is_iterable(tuple_0, True)
    # Test with a non-empty tuple
    tuple_1 = (1, 2, 3)
    var_6 = is_iterable(tuple_1)
    var_7 = is_iterable

# Generated at 2022-06-24 20:23:43.723596
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:23:51.643311
# Unit test for function is_iterable
def test_is_iterable():
    assert callable(is_iterable)
    assert is_iterable(['a', 'b'])
    assert is_iterable(('a', 'b'))
    assert is_iterable(set(['a', 'b']))
    assert is_iterable({'a': 1})
    assert is_iterable({'a': 1, 'b': 2})
    assert not is_iterable('ab')
    assert not is_iterable(1)
    assert not is_iterable(True)
    assert not is_iterable(None)
    assert is_iterable('ab', include_strings=True)
    assert not is_iterable(1, include_strings=True)
    assert not is_iterable(True, include_strings=True)
    assert not is_iterable(None, include_strings=True)

# Generated at 2022-06-24 20:23:54.183546
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = {'foo': 'bar'}
    var_1 = immutable_dict_0.__eq__(var_0)
    assert ((var_1 == True))


# Generated at 2022-06-24 20:24:03.356275
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'a': 'b'})
    immutable_dict_1 = ImmutableDict({'c': 'd', 'e': 'f'})
    immutable_dict_2 = ImmutableDict({'c': 'd', 'e': 'f', 'g': 'h'})
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)
    var_1 = immutable_dict_1.__eq__(immutable_dict_2)


# Generated at 2022-06-24 20:24:06.117667
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)



# Generated at 2022-06-24 20:24:15.658332
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    immutable_dict_2 = ImmutableDict()
    immutable_dict_3 = ImmutableDict()
    immutable_dict_3.update({'key': 'value'})
    immutable_dict_4 = ImmutableDict()
    immutable_dict_5 = ImmutableDict()
    immutable_dict_5.update({'key': 'value'})
    immutable_dict_6 = ImmutableDict()
    immutable_dict_6.update({'key2': 'value2'})
    immutable_dict_7 = ImmutableDict()
    immutable_dict_7.update({'key': 'value2'})
    immutable_dict_8 = ImmutableDict()

# Generated at 2022-06-24 20:24:20.003797
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 'b'])
    assert is_iterable('a')
    assert is_iterable(('a', 'b'))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set(['a', 'b']))
    assert not is_iterable(1)


# Generated at 2022-06-24 20:24:24.395319
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(list)
    assert not is_iterable(1)
    assert is_iterable(range(5))
    assert is_iterable("abc")
    assert is_iterable(u"abc")
    assert not is_iterable(1, include_strings=True)
    assert is_iterable(u"abc", include_strings=True)


# Generated at 2022-06-24 20:24:32.386132
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    assert immutable_dict_0.__eq__(immutable_dict_0) == True
    assert immutable_dict_0.__eq__(dict()) == False
    immutable_dict_1 = ImmutableDict()
    assert immutable_dict_1.__eq__(immutable_dict_1) == True
    assert immutable_dict_1.__eq__(dict()) == False
    immutable_dict_2 = ImmutableDict()
    assert immutable_dict_2.__eq__(immutable_dict_2) == True
    assert immutable_dict_2.__eq__(dict()) == False
    immutable_dict_3 = ImmutableDict()
    assert immutable_dict_3.__eq__(immutable_dict_3) == True