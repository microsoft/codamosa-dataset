

# Generated at 2022-06-24 20:14:51.941056
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2, 'c': 3})
    assert is_iterable(1) is False
    assert is_iterable(True) is False


# Generated at 2022-06-24 20:14:53.218851
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert(ImmutableDict() == ImmutableDict())


# Generated at 2022-06-24 20:14:56.876556
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(tuple())
    assert is_iterable({})
    assert is_iterable("")
    assert is_iterable(b"")
    assert is_iterable((x for x in range(2)))
    assert is_iterable(iter(""))
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(set())
    assert is_iterable("", include_strings=True)
    assert is_iterable(b"", include_strings=True)



# Generated at 2022-06-24 20:15:02.162902
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    assert immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:15:12.461909
# Unit test for function is_iterable
def test_is_iterable():
    class X:
        pass

    class Y(Sequence):
        def __getitem__(self, i):
            return i

        def __len__(self):
            return 1

    class Z:
        def __iter__(self):
            yield 1

    class W(X, Y):
        pass

    class K(Sequence):
        pass

    class M:
        def __getitem__(self, i):
            return i

        def __len__(self):
            return 1

    class N(Y):
        def __iter__(self):
            yield 1

    class O(M):
        def __iter__(self):
            yield 1

    class P(N):
        def __iter__(self):
            yield 1


# Generated at 2022-06-24 20:15:17.796355
# Unit test for function is_iterable
def test_is_iterable():
    test_iterable = [1, 2, 3]
    assert is_iterable(test_iterable) == True

    test_iterable = (4, 5, 6)
    assert is_iterable(test_iterable) == True

    test_iterable = {7, 8, 9}
    assert is_iterable(test_iterable) == True

    test_iterable = {1: 2, 3: 4, 5: 6}
    assert is_iterable(test_iterable) == True

    test_iterable = 'this is a string'
    assert is_iterable(test_iterable) == False

    test_iterable = 1
    assert is_iterable(test_iterable) == False



# Generated at 2022-06-24 20:15:19.241752
# Unit test for function is_iterable
def test_is_iterable():
    assert True is is_iterable([])
    assert False is is_iterable(1)



# Generated at 2022-06-24 20:15:30.576407
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(dict())
    assert is_iterable(list())
    assert is_iterable(tuple())
    assert is_iterable(set())
    assert is_iterable(unicode())
    assert is_iterable(bytearray())

    assert is_iterable(count(dict()))
    assert is_iterable(count(list()))
    assert is_iterable(count(tuple()))
    assert is_iterable(count(set()))
    assert is_iterable(count(unicode()))
    assert is_iterable(count(bytearray()))

    assert not is_iterable(1)
    assert not is_iterable(None)
    assert not is_iterable(is_iterable)


# Generated at 2022-06-24 20:15:33.832388
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable({}) is True
    assert is_iterable("") is True
    assert is_iterable(set()) is True
    assert is_iterable(1) is False



# Generated at 2022-06-24 20:15:44.093624
# Unit test for function is_iterable
def test_is_iterable():

    assert is_iterable((1, 2, 3)) == True
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable({1: 2, 3: 4}) == True
    assert is_iterable('string') == True
    assert is_iterable(True) == False
    assert is_iterable(54) == False

    assert is_iterable((1, 2, 3), include_strings=False) == True
    assert is_iterable([1, 2, 3], include_strings=False) == True
    assert is_iterable({1: 2, 3: 4}, include_strings=False) == True
    assert is_iterable('string', include_strings=False) == False
    assert is_iterable(True, include_strings=False) == False

# Generated at 2022-06-24 20:15:50.326738
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable((1, 2))
    assert is_iterable({})
    assert is_iterable(dict())
    assert is_iterable(set())
    assert is_iterable(frozenset())
    assert not is_iterable(None)
    assert not is_iterable(1)



# Generated at 2022-06-24 20:15:54.694862
# Unit test for function is_iterable
def test_is_iterable():
    test_dict = dict(test="test")
    test_list = ["test1", "test2"]
    test_str = "test"
    test_int = 8
    assert is_iterable(test_dict)
    assert is_iterable(test_list)
    assert not is_iterable(test_str)
    assert not is_iterable(test_int)



# Generated at 2022-06-24 20:16:04.088853
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert(ImmutableDict() == ImmutableDict())
    assert(ImmutableDict(a=1) == ImmutableDict(a=1))
    assert(ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2))
    assert(ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=3))
    assert(ImmutableDict(a=1, b=2) != ImmutableDict(a=1))
    assert(ImmutableDict(a=1, b=2) != ImmutableDict(a=2, b=2))
    assert(ImmutableDict(a=1, b=2) != ImmutableDict(a=2, b=1))

# Generated at 2022-06-24 20:16:06.895788
# Unit test for function is_iterable
def test_is_iterable():
    assert True == is_iterable([])
    assert True == is_iterable(str())
    assert True == is_iterable(dict())
    assert False == is_iterable(None)
    assert False == is_iterable(ImmutableDict())


# Generated at 2022-06-24 20:16:11.555593
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict(insert_1_1=value_1)
    immutable_dict_2 = ImmutableDict(insert_1_1=value_1)
    assert immutable_dict_0 == immutable_dict_1
    assert immutable_dict_0 == immutable_dict_2
    assert immutable_dict_1 == immutable_dict_2


# Generated at 2022-06-24 20:16:21.046733
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('')
    assert not is_iterable('')
    assert not is_iterable('')
    assert not is_iterable('')
    assert is_iterable('')
    assert not is_iterable('')
    assert is_iterable('')
    assert not is_iterable('')
    assert is_iterable('')
    assert not is_iterable('')
    assert is_iterable('')
    assert not is_iterable('')
    assert is_iterable('')
    assert not is_iterable('')
    assert not is_iterable('')
    assert not is_iterable('')
    assert not is_iterable('')
    assert not is_iterable('')
    assert not is_iterable

# Generated at 2022-06-24 20:16:29.476886
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict(['t', 'l'], l='t', l='l', l='t', l='t')
    immutable_dict_1 = ImmutableDict()
    immutable_dict_1.__eq__(immutable_dict_0)
    immutable_dict_1 = ImmutableDict()
    immutable_dict_1.__eq__(None)
    immutable_dict_1 = ImmutableDict()
    immutable_dict_1.__eq__(list())
    immutable_dict_1 = ImmutableDict()
    immutable_dict_1.__eq__(dict())


# Generated at 2022-06-24 20:16:36.225327
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict({'key': 'value'})
    immutable_dict_2 = ImmutableDict({'key': 'value_1'})
    immutable_dict_3 = ImmutableDict({'key': 'value'})
    assert(immutable_dict_1 == immutable_dict_3)
    assert(immutable_dict_1 != immutable_dict_2)
    assert(immutable_dict_0 == {})
    assert(immutable_dict_1 != None)
    assert(immutable_dict_1 != 'test')


# Generated at 2022-06-24 20:16:45.929930
# Unit test for function is_iterable
def test_is_iterable():
    sequence_0 = [0, 1, 2, 3]
    set_0 = {0, 1, 2, 3}
    dict_0 = {0: '0', 1: '1', 2: '2', 3: '3'}
    string_0 = "abcd"
    int_0 = 5

    if not is_iterable(sequence_0):
        raise AssertionError()

    if not is_iterable(set_0):
        raise AssertionError()

    if not is_iterable(dict_0):
        raise AssertionError()

    if not is_iterable(string_0):
        raise AssertionError()

    if is_iterable(int_0):
        raise AssertionError()


# Generated at 2022-06-24 20:16:50.269905
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'a': 'a', 'b': 'b', })
    immutable_dict_1 = ImmutableDict({'a': 'a', 'b': 'b', })
    if not (immutable_dict_0 == immutable_dict_1):
        raise Exception()


# Generated at 2022-06-24 20:17:01.277926
# Unit test for function is_iterable
def test_is_iterable():
    """Unit test for function is_iterable"""
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable((3, 4, 5))
    assert is_iterable({'k1': 'v1', 'k2': 'v2'})
    assert is_iterable(set(('a', 'b', 'c')))
    assert is_iterable('abc', include_strings=True)
    assert is_iterable(iter(['d', 'e', 'f']))

    assert not is_iterable(None)
    assert not is_iterable('abc', include_strings=False)
    assert not is_iterable(42)
    assert not is_iterable(MutableMapping())



# Generated at 2022-06-24 20:17:09.088343
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test with one argument
    '''
    Test with one argument
    '''
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0.__eq__(immutable_dict_0)
    # Test with two arguments
    '''
    Test with two arguments
    '''
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    immutable_dict_0.__eq__(immutable_dict_1, immutable_dict_0)


# Generated at 2022-06-24 20:17:13.740732
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict({'a': 'a', 'b': 'b'})
    assert not ImmutableDict.__eq__(immutable_dict_0, immutable_dict_1)


# Generated at 2022-06-24 20:17:16.498901
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    assert immutable_dict_0 == immutable_dict_0
    immutable_dict_0 = ImmutableDict({'a': 1})
    assert immutable_dict_0 == immutable_dict_0


# Generated at 2022-06-24 20:17:27.403127
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()

    # Test for equality
    immutable_dict_1.__eq__(immutable_dict_0)

    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = None

    # Test for equality
    immutable_dict_1.__eq__(immutable_dict_0)

    immutable_dict_0 = ImmutableDict({'a': 1})
    immutable_dict_1 = ImmutableDict({'a': 1})

    # Test for equality
    immutable_dict_1.__eq__(immutable_dict_0)

    immutable_dict_0 = ImmutableDict({'a': (1, 2)})

# Generated at 2022-06-24 20:17:33.077077
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) == True
    assert is_iterable(set()) == True
    assert is_iterable({}) == True
    assert is_iterable('') == True
    assert is_iterable(b'') == True
    assert is_iterable(0) == False
    assert is_iterable(None) == False


# Generated at 2022-06-24 20:17:43.934583
# Unit test for method __eq__ of class ImmutableDict

# Generated at 2022-06-24 20:17:45.724710
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()


# Generated at 2022-06-24 20:17:50.982130
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'a': 1})
    immutable_dict_1 = ImmutableDict()
    immutable_dict_1.__eq__(immutable_dict_0)  # No return value.
    immutable_dict_2 = ImmutableDict()
    immutable_dict_3 = ImmutableDict({'b': 2})
    immutable_dict_2.__eq__(immutable_dict_3)  # No return value.



# Generated at 2022-06-24 20:18:00.946054
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    immutable_dict_2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    immutable_dict_3 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    immutable_dict_4 = ImmutableDict({'a': '1', 'c': 3, 'b': '2'})
    immutable_dict_5 = ImmutableDict({'a': '1', 'c': 3, 'b': 2})
    immutable_dict_6 = ImmutableDict({'a': 1, 'c': 3, 'b': 2})
    immutable_dict_7 = ImmutableDict({})
    immutable_dict_8 = Imm

# Generated at 2022-06-24 20:18:17.840961
# Unit test for function is_iterable
def test_is_iterable():
    # Creating an ImmutableDict
    immutable_dict_1 = ImmutableDict()
    # Test for a dictionary
    immutable_dict_1_result = is_iterable(immutable_dict_1, True)
    assert immutable_dict_1_result == True

    # Creating a ImmutableDict and adding a key and a value
    immutable_dict_2 = ImmutableDict()
    immutable_dict_2['key'] = 'value'
    # Test for a dictionary with keys and values
    immutable_dict_2_result = is_iterable(immutable_dict_2, True)
    assert immutable_dict_2_result == True

    # Creating a tuple
    tuple_1 = (1, 2, 3)
    # Test for a tuple

# Generated at 2022-06-24 20:18:25.657503
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) == True
    assert is_iterable(tuple()) == True
    assert is_iterable({}) == True
    assert is_iterable(set()) == True
    assert is_iterable(0) == False
    assert is_iterable(0.0) == False
    assert is_iterable(None) == False
    assert is_iterable('string') == True
    assert is_iterable(b'string') == True


# Generated at 2022-06-24 20:18:34.162998
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable(set())
    assert is_iterable(range(5))
    assert is_iterable(u'hello') == is_iterable('hello') == True
    assert is_iterable(b'hello') == is_iterable('hello') == True
    assert not is_iterable(None)
    assert not is_iterable(0)
    assert not is_iterable(str())
    assert not is_iterable(bool())
    assert not is_iterable(dict())
    assert not is_iterable(Exception())



# Generated at 2022-06-24 20:18:38.829226
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(dict())
    assert is_iterable(set())
    assert is_iterable(tuple())
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable((1 for i in range(0)))
    assert is_iterable('test')
    assert not is_iterable(1)
    assert not is_iterable(None)
    assert not is_iterable(stdout)
    assert not is_iterable(stderr)


# Generated at 2022-06-24 20:18:43.491065
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    assert hash(immutable_dict_0) == 0
    immutable_dict_0 = ImmutableDict({'foo': 'bar'})
    assert hash(immutable_dict_0) == dict({'foo': 'bar'}).__hash__()


# Generated at 2022-06-24 20:18:45.596925
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:18:50.989789
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_dict = {'Hostname': 'localhost', 'Port': 22}
    immutable_dict_1 = ImmutableDict(test_dict)
    immutable_dict_2 = ImmutableDict(test_dict)
    immutable_dict_3 = ImmutableDict({'Port': 22, 'Hostname': 'localhost'})
    assert (immutable_dict_1 == immutable_dict_2)
    assert (immutable_dict_1 == immutable_dict_3)
    assert (immutable_dict_1 != immutable_dict_0)



# Generated at 2022-06-24 20:18:59.577966
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    first_dictionary = ImmutableDict({'a': 1, 'b': 2})
    second_dictionary = ImmutableDict({'b': 2, 'a': 1})
    third_dictionary = ImmutableDict({'c': 3, 'b': 2, 'a': 1})
    fourth_dictionary = ImmutableDict({'a': 1, 'b': 4})

    assert first_dictionary == second_dictionary
    assert not first_dictionary == third_dictionary
    assert not first_dictionary == fourth_dictionary


# Generated at 2022-06-24 20:19:09.089163
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Case 0
    immutable_dict_0 = ImmutableDict()

    assert immutable_dict_0 == immutable_dict_0

    # Case 1
    immutable_dict_0 = ImmutableDict()
    frozen_set_0 = frozenset({})

    assert immutable_dict_0 == frozen_set_0

    # Case 2
    immutable_dict_0 = ImmutableDict()
    tuple_0 = ()

    assert immutable_dict_0 == tuple_0

    # Case 3
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()

    assert immutable_dict_0 == immutable_dict_1

    # Case 4
    immutable_dict_0 = ImmutableDict()

# Generated at 2022-06-24 20:19:16.117675
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0__eq__ = immutable_dict_0.__eq__({})
    immutable_dict_1 = ImmutableDict()
    immutable_dict_1__eq__ = immutable_dict_1.__eq__({})
    immutable_dict_1_union = immutable_dict_1.union({'for':'hfk'})
    immutable_dict_1_union__eq__ = immutable_dict_1_union.__eq__({'for':'hfk'})



# Generated at 2022-06-24 20:19:40.886716
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Instantiate a new ImmutableDict and compare it to:
    #    1) iteslf
    #    2) an ImmutableDict with the same k/v pairs
    immutable_dict_0 = ImmutableDict({'a': 'b'})
    immutable_dict_1 = ImmutableDict({'a': 'b'})

    assert(immutable_dict_0 == immutable_dict_0)
    assert(immutable_dict_0 == immutable_dict_1)


# Generated at 2022-06-24 20:19:46.279734
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['foo', 'bar'])
    assert is_iterable({'k0': 'v0', 'k1': 'v1'})
    assert not is_iterable(42)
    assert not is_iterable('foo')
    assert not is_iterable(None)


# Generated at 2022-06-24 20:19:51.841247
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    assert (immutable_dict_0 == immutable_dict_1)
    assert (not (immutable_dict_0 != immutable_dict_1))



# Generated at 2022-06-24 20:20:02.536187
# Unit test for function is_iterable
def test_is_iterable():
    # test if non-iterable objects are properly identified
    assert(not is_iterable(None))
    assert(not is_iterable(123))
    assert(not is_iterable(1.23))
    assert(not is_iterable(True))
    assert(not is_iterable(False))
    # test if iterable objects are properly identified
    assert(is_iterable([]))
    assert(is_iterable({}))
    assert(is_iterable(()))
    assert(is_iterable(""))
    assert(is_iterable("abcdef"))
    assert(is_iterable("123456"))
    assert(is_iterable("123456.12"))
    assert(is_iterable("True"))
    assert(is_iterable("False"))
    assert(is_iterable("None"))

# Generated at 2022-06-24 20:20:06.221585
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) == True
    assert is_iterable(()) == True
    assert is_iterable({}) == True
    assert is_iterable('') == True
    assert is_iterable(b'') == True
    assert is_iterable(1) == False



# Generated at 2022-06-24 20:20:09.229430
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    if not isinstance(immutable_dict_0, ImmutableDict):
        raise Exception("Expected TypeError")
    else:
        return


# Generated at 2022-06-24 20:20:12.955732
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0 = ImmutableDict()


# Generated at 2022-06-24 20:20:20.438654
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    try:
        return_value_0 = test_case_0()
    except TypeError as error:
        return_value_1 = error

    return_value_2 = test_case_0()
    try:
        if return_value_0 == return_value_2:
            return_value_3 = True
        else:
            return_value_3 = False
    except TypeError as error:
        return_value_3 = error
    assert return_value_3 is True

# Generated at 2022-06-24 20:20:22.534838
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    value0 = ImmutableDict()
    value1 = ImmutableDict({})
    assert not (value0 == value1)


# Generated at 2022-06-24 20:20:25.242472
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    try:
        if 'ImmutableDict' == ImmutableDict():
            pass
        else:
            raise AssertionError
    except AssertionError:
        raise AssertionError



# Generated at 2022-06-24 20:21:15.023263
# Unit test for method __eq__ of class ImmutableDict

# Generated at 2022-06-24 20:21:24.735147
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    assert not (immutable_dict_0 == ImmutableDict())
    assert (immutable_dict_0 == ImmutableDict())
    immutable_dict_0 = ImmutableDict({'a': 50})
    assert immutable_dict_0 == immutable_dict_0
    assert immutable_dict_0 == ImmutableDict({'a': 50})
    assert not (immutable_dict_0 == ImmutableDict({'a': 2}))
    assert not (immutable_dict_0 == ImmutableDict({'b': 50}))


# Generated at 2022-06-24 20:21:29.988765
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0[0] = 0
    immutable_dict_1 = ImmutableDict()
    immutable_dict_1[0] = 0
    immutable_dict_2 = ImmutableDict()
    immutable_dict_2[1] = 1
    immutable_dict_2[2] = 2
    immutable_dict_3 = ImmutableDict()
    immutable_dict_3[1] = 1
    immutable_dict_3[2] = 3
    immutable_dict_3[3] = 3
    immutable_dict_4 = ImmutableDict()
    immutable_dict_4[1] = 1
    immutable_dict_4[2] = 2
    immutable_dict_4[3] = 3
    immutable_dict_5 = ImmutableDict()
   

# Generated at 2022-06-24 20:21:41.079567
# Unit test for function is_iterable
def test_is_iterable():
    iterable_types = [
        [1, 2, 3],  # list
        (1, 2, 3),  # tuple
        {1, 2, 3},  # set
        ImmutableDict(),
        ImmutableDict({'x': 1, 'y': 2}),
        ImmutableDict(x=1, y=2),
    ]
    non_iterable_types = [
        None,
        1,
        1.0,
        'foo',
        b'baz',
        Exception('Error'),
    ]

    for iterable in iterable_types:
        assert is_iterable(iterable) is True
    for non_iterable in non_iterable_types:
        assert is_iterable(non_iterable) is False


# Generated at 2022-06-24 20:21:48.842338
# Unit test for function is_iterable
def test_is_iterable():
    # Test a dictionary
    dictionary_0 = {
        'key_0': 'value_0',
        'key_1': 'value_1',
        'key_2': 'value_2'
    }
    assert is_iterable(dictionary_0)
    # Test a list
    list_0 = ['value_0', 'value_1', 'value_2']
    assert is_iterable(list_0)
    # Test a string
    string_0 = 'string_0'
    assert is_iterable(string_0)
    # Test a string with include_strings set to True
    string_1 = 'string_1'
    assert is_iterable(string_1, True)
    # Test a tuple
    tuple_0 = ('value_0', 'value_1', 'value_2')
   

# Generated at 2022-06-24 20:21:53.357491
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict() != ImmutableDict({})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict()


# Generated at 2022-06-24 20:22:00.898630
# Unit test for function is_iterable
def test_is_iterable():
    assert True == is_iterable([])
    assert True == is_iterable(set())
    assert True == is_iterable(dict())
    assert True == is_iterable({})
    assert True == is_iterable(tuple())
    assert True == is_iterable(range(3))
    assert True == is_iterable('string')
    assert True == is_iterable(1)
    assert True == is_iterable(1.0)
    assert False == is_iterable(None)



# Generated at 2022-06-24 20:22:10.682024
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_0 = ImmutableDict()
    dict_1 = ImmutableDict(
        {'key': 'value'},
    )
    dict_2 = ImmutableDict()
    dict_3 = ImmutableDict()
    dict_4 = dict(
        {'key': 'value'},
    )
    dict_5 = ImmutableDict(
        {'key': 'value'},
    )
    dict_6 = ImmutableDict()
    dict_7 = dict(
        {'key': 'value'},
    )
    dict_8 = dict(
        {'key': 'value'},
    )
    dict_9 = dict(
        {'key': 'value'},
    )
    dict_10 = dict(
        {'key': 'value'},
    )
    dict

# Generated at 2022-06-24 20:22:18.892897
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for immutable dict versus dict
    immutable_dict_0 = ImmutableDict()
    dict_0 = dict()
    assert immutable_dict_0 is not dict_0
    assert immutable_dict_0 == dict_0
    assert hash(immutable_dict_0) == hash(dict_0)

    # Test for immutable dict versus immutable dict
    immutable_dict_1 = ImmutableDict()
    immutable_dict_2 = ImmutableDict()
    assert immutable_dict_1 is not immutable_dict_2
    assert immutable_dict_1 == immutable_dict_2
    assert hash(immutable_dict_1) == hash(immutable_dict_2)

    # Test for immutable dict versus object
    immutable_dict_1 = ImmutableDict()
    object_1 = object()

# Generated at 2022-06-24 20:22:28.835192
# Unit test for function is_iterable
def test_is_iterable():
    # is_iterable
    # Test if is_iterable returns True when provided with an iterable sequence
    assert is_iterable([1, 2, 3])

    # Test if is_iterable returns True when provided with an iterable string
    assert is_iterable("Sample Iterable String")

    # Test if is_iterable returns False when provided with an non-iterable object
    assert is_iterable(5) is False

    # Test if is_iterable returns False when provided with an empty iterable
    assert is_iterable([]) is False

    # Test if is_iterable returns False when provided with an iterable string
    # and include_strings is False
    assert is_iterable("Sample Iterable String", include_strings=False) is False



# Generated at 2022-06-24 20:24:07.973704
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable(('a', 'b', 'c'))
    assert is_iterable({'a': 1, 'b' : 2})

    assert is_iterable('abc')
    assert is_iterable('abc', include_strings=True)
    assert is_iterable(u'abc')
    assert is_iterable(u'abc', include_strings=True)

    assert not is_iterable(1)
    assert not is_iterable(None)



# Generated at 2022-06-24 20:24:15.737599
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0 = ImmutableDict({'a': 'b'})
    immutable_dict_0 = ImmutableDict([('a', 'b')], a='a', b='b', c='c')
    immutable_dict_0 = ImmutableDict([('a', 'b')], a=1, b=2)
    immutable_dict_0 == immutable_dict_0
    immutable_dict_0 == dict({'a': 'b'})
    immutable_dict_0 == dict({'a': 'b'})
    immutable_dict_0 != immutable_dict_0
    immutable_dict_0 != dict({'a': 'b'})
    immutable_dict_0 != dict({'a': 'b'})


# Generated at 2022-06-24 20:24:26.014640
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    assert not (immutable_dict_0 == immutable_dict_1)
    immutable_dict_1 = ImmutableDict((('b', 3), ('a', 2), ('c', 1)))
    assert not (immutable_dict_0 == immutable_dict_1)
    immutable_dict_1 = ImmutableDict((('a', 3), ('b', 2), ('c', 1)))
    assert not (immutable_dict_0 == immutable_dict_1)
    immutable_dict_1 = ImmutableDict((('a', 2), ('b', 3), ('c', 1)))
    assert not (immutable_dict_0 == immutable_dict_1)

# Generated at 2022-06-24 20:24:31.019047
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test case for ImmutableDict.__eq__"""
    immutable_dict_0 = ImmutableDict()
    ImmutableDict.__eq__(immutable_dict_0, immutable_dict_0)

    immutable_dict_1 = ImmutableDict({"a": 1})
    ImmutableDict.__eq__(immutable_dict_1, immutable_dict_1)


# Generated at 2022-06-24 20:24:39.576031
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable(()) is True
    assert is_iterable({}) is True
    assert is_iterable('1') is False
    assert is_iterable(1) is False
    assert is_iterable(True) is False
    assert is_iterable(1.0) is False
    assert is_iterable(b'1') is False
    assert is_iterable(None) is False
    assert is_iterable(is_iterable) is False
    assert is_iterable(MapType(1, 2)) is True
    assert is_iterable(SetType(1, 2)) is True
    assert is_iterable(ImmutableDict()) is True
    assert is_iterable(is_iterable, True) is True

# Generated at 2022-06-24 20:24:46.284111
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1,2,3]) == True
    assert is_iterable(123) == False
    assert is_iterable('abcd') == True
    assert is_iterable('abcd', include_strings=False) == False
    assert is_iterable(ImmutableDict({'a': 1, 'b': 2})) == True
    assert is_iterable(ImmutableDict({'a': 1, 'b': 2}).items()) == True
    assert is_iterable(ImmutableDict({'a': 1, 'b': 2}).values()) == True
    assert is_iterable(ImmutableDict({'a': 1, 'b': 2}).keys()) == True
