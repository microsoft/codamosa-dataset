

# Generated at 2022-06-24 20:15:00.397902
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'a': 1, 'b': 2, 'c': 2})
    dict_0 = {'c': 2, 'b': 2, 'a': 1}
    ImmutableDict_eq_0 = immutable_dict_0.__eq__(dict_0)

    immutable_dict_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 2})
    dict_1 = {'c': 2, 'b': 2, 'a': 2}
    ImmutableDict_eq_1 = immutable_dict_1.__eq__(dict_1)

    immutable_dict_2 = ImmutableDict({'a': 1, 'b': 2, 'c': 2})
    dict_2 = 'str_0'

# Generated at 2022-06-24 20:15:09.675005
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('') is False
    assert is_iterable(None) is False
    assert is_iterable(5) is False
    assert is_iterable(5.5) is False
    assert is_iterable({}) is True
    assert is_iterable([]) is True
    assert is_iterable(set()) is True
    assert is_iterable(tuple()) is True
    assert is_iterable('a') is True
    assert is_iterable(b'b') is True
    assert is_iterable(u'c') is True
    assert is_iterable(xrange(0, 5)) is True
    assert is_iterable(xrange(0, 5), include_strings=True) is False



# Generated at 2022-06-24 20:15:17.505429
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
        Arguments:
            * immutable_dict_0: ImmutableDict
            * immutable_dict_1: ImmutableDict
            * immutable_dict_2: ImmutableDict
        Expected Result: True
        Return Value: is_equal
    """
    immutable_dict_0 = ImmutableDict({'key': "value"})
    immutable_dict_1 = ImmutableDict({'key': "value"})
    immutable_dict_2 = ImmutableDict({'key': "value_1"})
    is_equal = immutable_dict_0 == immutable_dict_1
    is_equal = immutable_dict_0 == immutable_dict_2
    return is_equal


# Generated at 2022-06-24 20:15:19.281753
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__('value')


# Generated at 2022-06-24 20:15:22.614938
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    assert False == True


# Generated at 2022-06-24 20:15:32.134448
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'1': 'abc', '2': 'cde'}) == ImmutableDict({'2': 'cde', '1': 'abc'})
    assert ImmutableDict({'1': 'abc', '2': 'cde'}) == {'2': 'cde', '1': 'abc'}
    assert ImmutableDict({'1': 'abc', '2': 'cde'}) != {'2': 'cde', '1': 'abcd'}
    assert ImmutableDict({'1': 'abc', '2': 'cde'}) != 'abcdef'
    assert ImmutableDict({'1': 'abc', '2': 'cde'}) != ImmutableDict({'2': 'cde'})


# Generated at 2022-06-24 20:15:36.451713
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict(type='dict')
    immutable_dict_1 = ImmutableDict(type='dict')
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:15:38.658834
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = isinstance(immutable_dict_0, Hashable)


# Generated at 2022-06-24 20:15:46.117948
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    assert not immutable_dict_0.__eq__("")
    assert not immutable_dict_0.__eq__("")
    assert not immutable_dict_0.__eq__("")
    assert not immutable_dict_0.__eq__("")
    assert not immutable_dict_0.__eq__("")
    assert immutable_dict_0.__eq__(immutable_dict_0)
    assert not immutable_dict_0.__eq__("")
    assert not immutable_dict_0.__eq__("")
    assert not immutable_dict_0.__eq__("")
    assert not immutable_dict_0.__eq__("")


# Generated at 2022-06-24 20:15:47.857954
# Unit test for function is_iterable
def test_is_iterable():
    immutable_dict_0 = None
    var_0 = is_iterable(immutable_dict_0)
    print(var_0)


# Generated at 2022-06-24 20:15:56.723468
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)
    var_1 = immutable_dict_0.__eq__(immutable_dict_0)
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_1.__eq__(immutable_dict_1)
    var_1 = immutable_dict_1.__eq__(immutable_dict_1)
    immutable_dict_2 = ImmutableDict()
    var_0 = immutable_dict_2.__eq__(immutable_dict_2)
    var_1 = immutable_dict_2.__eq__(immutable_dict_2)
    immutable_dict_3 = ImmutableDict()
    var_0 = immutable_dict_

# Generated at 2022-06-24 20:16:03.273220
# Unit test for function is_iterable
def test_is_iterable():
    immutable_dict_1 = None
    if is_iterable(immutable_dict_1):
        immutable_dict_1 = immutable_dict_1
    var_0 = is_sequence(immutable_dict_1, include_strings=True)
#
# # Unit test for function count
# def test_count():
#     immutable_dict_3 = None
#     var_0 = count(immutable_dict_3)

# Generated at 2022-06-24 20:16:04.831789
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:16:11.400496
# Unit test for function is_iterable
def test_is_iterable():
    iterable_0 = []
    iterable_1 = (1, 2, 3)
    iterable_2 = {'a': 1, 'b': 2}
    iterable_3 = set([1, 2, 3])
    iterable_4 = [1, 2, 3]
    iterable_5 = (1, 2, 3)
    iterable_6 = {'a': 1, 'b': 2}
    iterable_7 = set([1, 2, 3])
    iterable_8 = (),
    iterable_9 = {'a': 1, 'b': 2}
    iterable_10 = set([1, 2, 3])
    iterable_11 = {'a': 1, 'b': 2}
    iterable_12 = set([1, 2, 3])

# Generated at 2022-06-24 20:16:20.919987
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Both dicts are equal
    dict_0 = dict()
    dict_1 = dict()
    immutable_dict_0 = ImmutableDict(dict_0)
    immutable_dict_1 = ImmutableDict(dict_1)
    var_0 = immutable_dict_0 == immutable_dict_1
    # Both dicts are not equal
    dict_0['key_0'] = 'value_0'
    dict_1['key_0'] = 'value_1'
    immutable_dict_0 = ImmutableDict(dict_0)
    immutable_dict_1 = ImmutableDict(dict_1)
    var_1 = immutable_dict_0 == immutable_dict_1
    # Compare dict to non-dict
    immutable_dict_0 = ImmutableDict(dict_0)
    var_2 = immutable

# Generated at 2022-06-24 20:16:26.316795
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({1 : 2})
    immutable_dict_1 = ImmutableDict({1 : 3})
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:16:30.648785
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    with pytest.raises(Exception):
        immutable_dict_0 = ImmutableDict()
        immutable_dict_0.__eq__()


# Generated at 2022-06-24 20:16:40.336913
# Unit test for function is_iterable
def test_is_iterable():
    obj = range(10)
    assert is_iterable(obj) is True
    assert is_iterable(obj, True) is True
    assert is_iterable(obj, False) is True
    assert is_iterable(obj, True, True) is True
    assert is_iterable(obj, False, True) is True

    obj = set(range(10))
    assert is_iterable(obj) is True
    assert is_iterable(obj, True) is True
    assert is_iterable(obj, False) is True
    assert is_iterable(obj, True, True) is True
    assert is_iterable(obj, False, True) is True

    obj = frozenset(range(10))
    assert is_iterable(obj) is True
    assert is_iterable(obj, True) is True

# Generated at 2022-06-24 20:16:45.637120
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable({1, 2, 3})
    assert is_iterable((1, 2, 3))
    assert is_iterable('test')
    assert not is_iterable(1)
    assert not is_iterable(None)


# Generated at 2022-06-24 20:16:48.900349
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for method __eq__ of class ImmutableDict (0 args)
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0.__eq__()


# Generated at 2022-06-24 20:16:55.475094
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('string') == False
    assert is_iterable([]) == True
    assert is_iterable(()) == True
    assert is_iterable({}) == True
    assert is_iterable(1) == False
    assert is_iterable(None) == False
    assert is_iterable('') == False


# Generated at 2022-06-24 20:17:04.772780
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict(())
    immutable_dict_1 = ImmutableDict((1, "one"))
    immutable_dict_2 = ImmutableDict((0, "zero"))
    immutable_dict_3 = ImmutableDict((1, "one"))

    var_0 = immutable_dict_0 == immutable_dict_2
    var_1 = immutable_dict_1 == immutable_dict_3
    var_2 = immutable_dict_2 == immutable_dict_0



# Generated at 2022-06-24 20:17:14.962245
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_1 = ImmutableDict({'a': 1, 2: 'b'})
    var_2 = ImmutableDict({(1, 2, 3): 'a', 'bb': 'cc', 'd': 'e'})
    var_3 = ImmutableDict(a=1, b=2)
    var_4 = ImmutableDict({'1': 1, '2': 2})
    var_5 = ImmutableDict({'a': 1, 2: 'b'})
    var_6 = var_1 == var_2
    var_7 = var_1 == var_3
    var_8 = var_1 == var_4
    var_9 = var_1 == var_5


# Generated at 2022-06-24 20:17:25.188983
# Unit test for function is_iterable
def test_is_iterable():

    d = ImmutableDict({"k1": "v1", "k2": "v2", "k3": "v3"})
    s = "a"

    assert is_iterable(d)
    assert is_iterable(d.keys())
    assert is_iterable(d.values())
    assert is_iterable(d.items())
    assert is_iterable(d.items(), True)
    assert is_iterable(d.keys(), True)
    assert is_iterable(d.values(), True)
    assert is_iterable(d, True)

    assert is_iterable(s)
    assert not is_iterable(s, False)
    assert is_iterable(s, True)



# Generated at 2022-06-24 20:17:31.800262
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Equality test for two ImmutableDict classes"""
    immutable_dict_0 = ImmutableDict({'key':'value'})
    immutable_dict_1 = ImmutableDict({'key':'value'})
    assert immutable_dict_0 == immutable_dict_1
    immutable_dict_2 = ImmutableDict({'key':'value2'})
    assert immutable_dict_0 != immutable_dict_2

# Generated at 2022-06-24 20:17:39.069806
# Unit test for function is_iterable
def test_is_iterable():
    # Case 0:
    var_0 = is_iterable(None)

    # Case 1:
    array_0 = []
    var_1 = is_iterable(array_0)

    # Case 2:
    dict_0 = {'foo': 'bar'}
    var_2 = is_iterable(dict_0)

    # Case 3
    var_3 = is_iterable('abcd')


# Generated at 2022-06-24 20:17:43.181418
# Unit test for function is_iterable
def test_is_iterable():
    # Run the test against all three possible input types (dict, list, and set).
    # Assume that a list is being used as the input iterable.
    mutable_mapping_0 = MutableMapping()
    var_0 = mutable_mapping_0
    mutable_mapping_0.update({'a': 0})
    var_1 = is_iterable(var_0)
    # Assume that a set is being used as the input iterable.
    mutable_mapping_1 = MutableMapping()
    var_2 = mutable_mapping_1
    mutable_mapping_1.update({'a': 0})
    var_3 = is_iterable(var_2)
    # Assume that a string is being used as the input iterable.
    immutable_dict_1 = Imm

# Generated at 2022-06-24 20:17:51.054030
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    '''
    Unit test for method __eq__ of class ImmutableDict
    '''
    immutable_dict_0 = ImmutableDict(var_0)
    immutable_dict_1 = immutable_dict_0
    assert immutable_dict_1.__eq__(immutable_dict_0) == True

    immutable_dict_2 = ImmutableDict(var_1)
    assert immutable_dict_2.__eq__(immutable_dict_0) == False

    immutable_dict_3 = ImmutableDict(var_0, var_1)
    assert immutable_dict_3.__eq__(immutable_dict_2) == False


# Generated at 2022-06-24 20:18:01.050479
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    immutable_dict_0 = ImmutableDict({"a": 1, "b": 2, "c": 3})
    immutable_dict_1 = ImmutableDict({"a": 1, "b": 2, "c": 3})
    immutable_dict_2 = ImmutableDict({"a": 1, "c": 2, "b": 3})
    immutable_dict_3 = {"a": 1, "b": 2, "c": 3}
    immutable_dict_4 = {"a": 1, "b": 2, "c": 3}
    var_0 = immutable_dict_1 == immutable_dict_0
    var_1 = immutable_dict_0 == immutable_dict_2
    var_2 = immutable_dict_2 == immutable_dict_1
    var_3 = immutable_dict_3 == immutable_dict_4
   

# Generated at 2022-06-24 20:18:05.385240
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict(('k0', 'v0'))
    immutable_dict_1 = ImmutableDict(('k0', 'v0'))
    immutable_dict_2 = ImmutableDict(('k0', 'v1'))
    var_0 = immutable_dict_0 == immutable_dict_1
    var_1 = immutable_dict_0 == immutable_dict_2


# Generated at 2022-06-24 20:18:11.204465
# Unit test for function is_iterable
def test_is_iterable():
    immutable_dict_0 = ImmutableDict({})
    var_1 = is_iterable(immutable_dict_0)


# Generated at 2022-06-24 20:18:15.079155
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict(['B:s#\\D', [0, {}], (1,), (1,), 'N\\{;']).union({(1,): 0}).difference({(1,): 0})
    var_0 = immutable_dict_0.__eq__(hash('_'))


# Generated at 2022-06-24 20:18:18.948490
# Unit test for function is_iterable
def test_is_iterable():
    immutable_dict_0 = ImmutableDict([('key_0', 'value_0'), ('key_1', 'value_1'), ('key_2', 'value_2')])
    var_0 = is_iterable(immutable_dict_0)
    assert var_0 == True


# Generated at 2022-06-24 20:18:28.869667
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = isinstance(immutable_dict_0, Hashable)
    var_1 = isinstance(immutable_dict_0, Mapping)
    var_2 = isinstance(immutable_dict_0, MutableMapping)
    immutable_dict_1 = ImmutableDict()
    var_3 = immutable_dict_0 == immutable_dict_1
    immutable_dict_2 = ImmutableDict(a="b", c="d")
    var_4 = immutable_dict_0 == immutable_dict_2
    immutable_dict_3 = ImmutableDict(a="b", c="d")
    var_5 = immutable_dict_2 == immutable_dict_3
    var_6 = immutable_dict_3 == immutable_dict_1
    immutable_dict

# Generated at 2022-06-24 20:18:32.569306
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({}, **{'remove_keys': frozenset((frozenset(),))})
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:18:39.233590
# Unit test for function is_iterable
def test_is_iterable():
    def _test_not_iterable(value):
        return not is_iterable(value)

    assert _test_not_iterable(u'')
    assert _test_not_iterable(0)
    assert _test_not_iterable(None)
    assert _test_not_iterable(dict())


# Generated at 2022-06-24 20:18:44.679052
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_1 = hash(immutable_dict_0)
    assert isinstance(var_1, int)
    immutable_dict_1 = ImmutableDict()
    var_2 = immutable_dict_1.__eq__(immutable_dict_0)
    assert isinstance(var_2, bool)


# Generated at 2022-06-24 20:18:48.098914
# Unit test for function is_iterable
def test_is_iterable():
    # Test function
    '''Identify whether the input is an iterable.'''
    immutable_dict_0 = None
    var_0 = is_iterable(immutable_dict_0)


# Generated at 2022-06-24 20:18:52.861908
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_0._store = None
    immutable_dict_1 = ImmutableDict()
    immutable_dict_1._store = {}
    assert immutable_dict_0.__eq__(immutable_dict_1) == False


# Generated at 2022-06-24 20:19:00.084715
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    if "foo" is not immutable_dict_0.get("foo"):
        raise Exception('Failed to retrieve value for foo')
    if not immutable_dict_0.__eq__({  }):
        raise Exception('Failed to check if they are equal')
    if not immutable_dict_0.__eq__(immutable_dict_0):
        raise Exception('Failed to check if they are equal')


# Generated at 2022-06-24 20:19:13.796856
# Unit test for function is_iterable
def test_is_iterable():
    empty = []
    string = ''
    non_iterable = 1
    string_iterable = ['Example', 'Example']
    
    assert(is_iterable(empty) == True)
    assert(is_iterable(string) == True)
    assert(is_iterable(non_iterable) == False)
    assert(is_iterable(string_iterable) == True)

# Generated at 2022-06-24 20:19:20.763212
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    try:
        import collections
    except ImportError:
        import ansible.module_utils.common.collections_compat as collections
    a = ImmutableDict({"a": 1, "b": 2, "c": 3})
    b = collections.OrderedDict()
    b["a"] = 1
    b["b"] = 2
    b["c"] = 3
    c = collections.OrderedDict()
    c["c"] = 3
    c["b"] = 2
    c["a"] = 1
    assert a == b
    assert a.__eq__(b)
    assert a != c
    assert a.__eq__(c) == False

# Generated at 2022-06-24 20:19:29.855381
# Unit test for function is_iterable
def test_is_iterable():
    immutable_dict_0 = None
    var_0 = is_iterable(immutable_dict_0)

    immutable_dict_1 = None
    var_1 = is_iterable(immutable_dict_1, True)

    immutable_dict_2 = ImmutableDict()
    var_2 = is_iterable(immutable_dict_2)

    immutable_dict_3 = ImmutableDict()
    var_3 = is_iterable(immutable_dict_3, True)

    immutable_dict_4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    var_4 = is_iterable(immutable_dict_4)

    immutable_dict_5 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-24 20:19:32.313751
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['']) == True
    assert is_iterable(('')) == True
    assert is_iterable([''], True) == True
    assert is_iterable('') == False
    assert is_iterable('') == False

# Generated at 2022-06-24 20:19:41.096842
# Unit test for function is_iterable
def test_is_iterable():
    immutable_dict_0 = ImmutableDict(('a', 1), ('b', 2))
    var_0 = is_iterable(immutable_dict_0)
    var_1 = is_iterable([('a', 1), ('b', 2)])
    var_2 = is_iterable('hello')
    var_3 = is_iterable(set(['hello', 'world']))
    var_4 = is_iterable(str, True)
    var_5 = is_iterable([], True)
    var_6 = is_iterable(dict({}), True)
    var_7 = is_iterable(set(['hello', 'world']), True)


# Generated at 2022-06-24 20:19:45.151508
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable("")
    assert is_iterable("", include_strings = False)
    assert not is_iterable("", include_strings = True)



# Generated at 2022-06-24 20:19:47.853386
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    assert immutable_dict_0.__eq__(ImmutableDict())
    assert isinstance(immutable_dict_0.__eq__(ImmutableDict()), bool)


# Generated at 2022-06-24 20:19:49.287427
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) == True
    assert is_iterable(None) == False


# Generated at 2022-06-24 20:19:55.208143
# Unit test for function is_iterable
def test_is_iterable():
    immutable_dict_0 = ImmutableDict({'foo': 'bar'})
    var_0 = is_iterable(immutable_dict_0, include_strings=False)
    assert var_0 == True
    immutable_dict_1 = ImmutableDict({'foo': 'bar'})
    var_1 = is_iterable(immutable_dict_1, include_strings=False)
    assert var_1 == True


# Generated at 2022-06-24 20:19:58.917913
# Unit test for function is_iterable
def test_is_iterable():
    immutable_dict_0 = {
        'key_0': 'value_0',
        'key_1': 'value_1',
    }
    var_0 = is_iterable(immutable_dict_0)
    pass


# Generated at 2022-06-24 20:20:16.927950
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict(('k', 'v'))
    var_0 = immutable_dict_0.__eq__('v')


# Generated at 2022-06-24 20:20:19.391857
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)
    assert var_0 == False


# Generated at 2022-06-24 20:20:21.515024
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) == True
    assert is_iterable({}) == True
    assert is_iterable(1) == False


# Generated at 2022-06-24 20:20:24.749389
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    assert immutable_dict_0 == {}
    assert immutable_dict_0 != {'a': 1}
    assert immutable_dict_0 != 'string'


# Generated at 2022-06-24 20:20:26.476306
# Unit test for function is_iterable
def test_is_iterable():
    immutable_dict_0 = ImmutableDict()
    var_0 = is_iterable(immutable_dict_0, False)


# Generated at 2022-06-24 20:20:32.316676
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict1 = ImmutableDict(a=1, b=2, c=3)
    immutable_dict2 = ImmutableDict(a=1, b=2, c=3)
    immutable_dict3 = ImmutableDict(a=1)

    assert immutable_dict1 == immutable_dict2
    assert not immutable_dict1 == immutable_dict3
    assert not immutable_dict1 == {}



# Generated at 2022-06-24 20:20:38.943544
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'var_0': 'var_1', 'var_2': 'var_3', 'var_2': 'var_2'})
    var_0 = immutable_dict_0.__eq__({'var_0': 'var_1', 'var_2': 'var_3'})
    var_1 = ImmutableDict({'var_0': 'var_1', 'var_2': 'var_3'}).__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:20:42.248133
# Unit test for function is_iterable
def test_is_iterable():
    print("Testing if argument is iterable")
    assert is_iterable("string") == True
    assert is_iterable("") == True
    assert is_iterable([]) == True
    assert is_iterable(1) == False


# Generated at 2022-06-24 20:20:43.673507
# Unit test for function is_iterable
def test_is_iterable():
    immutable_dict_1 = ImmutableDict({})
    var_1 = is_iterable(immutable_dict_1)


# Generated at 2022-06-24 20:20:49.335328
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    var_1 = ImmutableDict({'a': 1, 'b': 2})
    var_2 = ImmutableDict({'a': 1, 'b': 2})
    var_3 = ImmutableDict({'b': 2, 'a': 1})
    var_4 = ImmutableDict({'b': 2, 'a': 2})
    var_5 = {'a': 1, 'b': 2}
    var_6 = set([1, 2, 3])
    var_7 = {'b': 2, 'a': 1}
    var_8 = ImmutableDict({'b': 2, 'a': 2})
    var_9 = ImmutableDict({'b': 2, 'a': 1, 'c': 3})

# Generated at 2022-06-24 20:21:08.628806
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'key_0': 'value_0'})
    var_0 = immutable_dict_0 == immutable_dict_0
    immutable_dict_1 = ImmutableDict({'key_0': 'value_0'})
    var_1 = immutable_dict_0 == immutable_dict_1
    immutable_dict_2 = ImmutableDict({'key_0': 'value_1'})
    var_2 = immutable_dict_0 == immutable_dict_2
    var_3 = immutable_dict_0 == 'value_0'



# Generated at 2022-06-24 20:21:10.507263
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    immutable_dict_0 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_0)


# Generated at 2022-06-24 20:21:15.384626
# Unit test for function is_iterable
def test_is_iterable():
    immutable_dict_0 = ImmutableDict(**{'roses': 'are red', 'violets': 'are blue', 'I': 'am a'})
    assert is_iterable(immutable_dict_0)


# Generated at 2022-06-24 20:21:18.478867
# Unit test for function is_iterable
def test_is_iterable():
    assert(not is_iterable(None))
    assert(is_iterable([]))
    assert(is_iterable({}))
    assert(is_iterable(tuple()))
    assert(is_iterable('test'))
    assert(is_iterable(b'test'))


# Generated at 2022-06-24 20:21:27.010205
# Unit test for function is_iterable
def test_is_iterable():
    class FakeIter(object):
        def __iter__(self):
            return iter(())

    class FakeNonIter(object):
        pass

    # Test iterables
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(FakeIter())

    # Test strings and bytes
    assert is_iterable(u'asdf')
    assert is_iterable(b'asdf')
    assert not is_iterable(u'asdf', include_strings=False)
    assert not is_iterable(b'asdf', include_strings=False)
    assert is_iterable(u'asdf', include_strings=True)
    assert is_iterable(b'asdf', include_strings=True)

    # Test non iterables
   

# Generated at 2022-06-24 20:21:29.653293
# Unit test for function is_iterable
def test_is_iterable():
    with pytest.raises(TypeError):
        is_iterable(0)
    assert is_iterable([]) == True
    assert is_iterable('') == False
    assert is_iterable(()) == True
    assert is_iterable({}) == True



# Generated at 2022-06-24 20:21:34.416959
# Unit test for function is_iterable
def test_is_iterable():
    y = {'1':1, '2': 2}
    x = is_iterable(y)
    assert x == True
    y = 1
    x = is_iterable(y)
    assert x == False


# Generated at 2022-06-24 20:21:38.933949
# Unit test for function is_iterable
def test_is_iterable():
    immutable_dict_0 = ImmutableDict(a=1, b=2)
    immutable_dict_1 = ImmutableDict(a=1, b=2)
    assert is_iterable(immutable_dict_0)
    assert is_iterable(immutable_dict_1)


# Generated at 2022-06-24 20:21:47.451716
# Unit test for function is_iterable
def test_is_iterable():
    item_0 = 'abcdefg'
    item_1 = (1, 2, 3, 4, 5, 6)
    item_2 = {'a':'b'}
    item_3 = 100
    item_4 = b'1234567890'


# Generated at 2022-06-24 20:21:51.917583
# Unit test for function is_iterable
def test_is_iterable():
    # Test with ImmutableDict
    immutable_dict_0 = ImmutableDict()
    var_0 = is_iterable(immutable_dict_0)
    # Test with string
    string_0 = "str"
    var_1 = is_iterable(string_0)
    # Test with list
    list_0 = []
    var_2 = is_iterable(list_0)



# Generated at 2022-06-24 20:22:29.157051
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    # This test would fail because of bug in __eq__ implementation:
    #
    #     def __eq__(self, other):
    #         if self.__hash__() == hash(other):
    #             return True
    #
    #         return False
    #
    # This will fail because immutable dicts are not Hashable themselves
    assert(immutable_dict_0 != immutable_dict_1)



# Generated at 2022-06-24 20:22:34.573373
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test eq operation on ImmutableDict."""
    dict_0 = ImmutableDict({'name': 'nginx'})
    dict_1 = ImmutableDict({'name': 'nginx'})
    dict_2 = None

    # equality of two ImmutableDict instances
    var_0 = dict_0 == dict_1



# Generated at 2022-06-24 20:22:41.036656
# Unit test for function is_iterable
def test_is_iterable():
    immutable_dict_0 = ImmutableDict()
    var_0 = is_iterable(immutable_dict_0)
    var_1 = is_iterable([])
    var_2 = is_iterable(())
    var_3 = is_iterable('a')
    var_4 = is_iterable(1)



# Generated at 2022-06-24 20:22:51.398759
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = immutable_dict_0.__eq__(immutable_dict_1)
    immutable_dict_2 = ImmutableDict()
    immutable_dict_1.__init__()
    var_1 = immutable_dict_2.__eq__(immutable_dict_1)
    immutable_dict_3 = ImmutableDict()
    immutable_dict_3.__init__()
    immutable_dict_3.__init__()
    var_2 = immutable_dict_3.__eq__(immutable_dict_1)
    immutable_dict_0.__init__()
    immutable_dict_0.__init__()
    immutable_dict_1.__init__()
    immutable_dict_1

# Generated at 2022-06-24 20:22:57.073145
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'a': 1, 'b': 2})
    var_0 = immutable_dict_0.__eq__({'a': 1, 'b': 2})
    var_1 = is_iterable(immutable_dict_0)
    var_2 = is_sequence(immutable_dict_0)


# Generated at 2022-06-24 20:23:07.780350
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_1 = ImmutableDict({0: 0, 1: 1})
    immutable_dict_2 = ImmutableDict({0: 0, 1: 1})
    immutable_dict_3 = ImmutableDict({1: 1, 0: 0})
    immutable_dict_4 = ImmutableDict({1: 1})
    immutable_dict_5 = ImmutableDict({})
    var_2 = (immutable_dict_1 == immutable_dict_2)
    var_3 = (immutable_dict_1 == immutable_dict_3)
    var_4 = (immutable_dict_1 == immutable_dict_4)
    var_5 = (immutable_dict_1 == immutable_dict_5)
    var_6 = (immutable_dict_1 == 4)

# Generated at 2022-06-24 20:23:10.231732
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict(True)
    var_0 = immutable_dict_0.__eq__(var_0)


# Generated at 2022-06-24 20:23:12.631566
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable({}) is True
    assert is_iterable([]) is True
    assert is_iterable(set()) is True
    assert is_iterable(1) is False


# Generated at 2022-06-24 20:23:16.821543
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict((2, 3))
    immutable_dict_1 = ImmutableDict()
    immutable_dict_2 = ImmutableDict()
    immutable_dict_3 = ImmutableDict((1, 2))
    var_0 = str(immutable_dict_0.__eq__(immutable_dict_1))

# Generated at 2022-06-24 20:23:25.175738
# Unit test for function is_iterable
def test_is_iterable():
    # When 'seq' is not iterable, then the function should return False.
    # For example, if 'seq' is of type:
    #   bool
    #   int
    #   float
    #   None
    # Then the function should return False.
    bool_0 = True
    int_0 = 0x0000
    float_0 = 100.000
    none_0 = None
    test_cases = [bool_0, int_0, float_0, none_0]
    for test_case in test_cases:
        assert is_iterable(test_case) is False

    # When 'seq' is iterable, then the function should return True.
    # For example, if 'seq' is of type:
    #   list
    #   tuple
    #   set
    #   frozenset
    #

# Generated at 2022-06-24 20:24:36.811342
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    immutable_dict_1 = ImmutableDict({'key2': 'value2', 'key1': 'value1'})
    immutable_dict_0__eq__immutable_dict_1 = immutable_dict_0.__eq__(immutable_dict_1)


# Generated at 2022-06-24 20:24:40.066105
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict_0 = ImmutableDict()
    immutable_dict_1 = ImmutableDict()
    var_0 = (immutable_dict_0 == immutable_dict_1)



# Generated at 2022-06-24 20:24:41.246244
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert not test_case_0()

# Generated at 2022-06-24 20:24:46.339936
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable('123') == True
    assert is_iterable({4, 5, 6}) == True
    assert is_iterable({'a': ('b', 'c', 'd')}) == True
    assert is_iterable(frozenset([1, 2, 3])) == True
    assert is_iterable(1) == False
    assert is_iterable(None) == False
