

# Generated at 2022-06-20 15:33:49.457604
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence([1, 2, 3])
    assert is_sequence((1, 2, 3))
    assert is_sequence((1, ))
    assert is_sequence(set())
    assert is_sequence(set((1, 2, 3)))
    assert is_sequence(xrange(5))
    assert not is_sequence(5)
    assert not is_sequence(None)
    assert not is_sequence(object())



# Generated at 2022-06-20 15:33:53.413250
# Unit test for function is_string
def test_is_string():
    assert is_string('string')
    assert is_string(u'unicode')
    assert is_string(b'bytes')

    assert not is_string(['list'])
    assert not is_string(('tuple',))
    assert not is_string(set(['set']))
    assert not is_string({'dict': 'yes'})



# Generated at 2022-06-20 15:33:59.219203
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = dict(a=1, b=2)
    dict2 = dict(a=1, b=2)
    dict3 = dict(a=1, b=2, c=3)
    dict4 = dict(a=1, b=2, c=4)

    assert(ImmutableDict(dict1) == dict1)
    assert(ImmutableDict(dict1) == dict2)
    assert(ImmutableDict(dict1) == ImmutableDict(dict2))

    assert(dict1 != dict3)
    assert(dict1 != dict4)
    assert(dict1 != ImmutableDict(dict3))
    assert(dict1 != ImmutableDict(dict4))

    assert(ImmutableDict(dict1) != dict3)

# Generated at 2022-06-20 15:34:08.071885
# Unit test for function count
def test_count():
    class ABunchOfSiblings(object):
        def __init__(self, *kids):
            self.kids = list(kids)

        def __len__(self):
            return len(self.kids)

        def __getitem__(self, idx):
            return self.kids[idx]

    a = ABunchOfSiblings('Alice', 'Bob', 'Charlie', 'Bob', 'Charlie', 'Eve')
    b = count(a)
    assert b == {'Alice': 1, 'Bob': 2, 'Charlie': 2, 'Eve': 1}



# Generated at 2022-06-20 15:34:10.765166
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    immutable_dict = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert len(immutable_dict) == 2


# Generated at 2022-06-20 15:34:22.987599
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # equal and equal
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(a=1, b=2)
    assert d1 == d2

    # equal and not equal
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(a=1, b=3)
    assert not d1 == d2

    # equal and not equal
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(a=1, b=2, c=3)
    assert not d1 == d2

    # not equal and equal
    d1 = ImmutableDict(a=1, b=2, c=3)

# Generated at 2022-06-20 15:34:28.958165
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert is_string(u'foo')
    assert is_string(b'foo')
    assert not is_string(['foo', 'bar'])
    assert not is_string({'foo', 'bar'})
    assert not is_string(dict(foo='bar'))


# Generated at 2022-06-20 15:34:31.592707
# Unit test for function count
def test_count():
    seq1 = [1, 1, 2, 3, 3, 3]
    assert count(seq1) == {1: 2, 2: 1, 3: 3}


# Generated at 2022-06-20 15:34:41.307784
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert not is_sequence({'a': 1, 'b': 2})
    assert is_sequence((1, 2, 3))
    assert not is_sequence((1, 2, 3), include_strings=True)
    assert not is_sequence('abc')
    assert is_sequence('abc', include_strings=True)
    assert is_sequence(ImmutableDict(a=1, b=2))
    assert not is_sequence((1, 2, 3), include_strings=True)
    assert is_sequence({1, 2, 3})
    assert not is_sequence({1, 2, 3}, include_strings=True)



# Generated at 2022-06-20 15:34:50.844220
# Unit test for function is_string
def test_is_string():
    """Perform unit tests on is_string function."""
    assert is_string('String')
    assert is_string(u'Unicode String')
    assert is_string(b'Bytes')
    assert is_string(b'Bytes String')
    assert not is_string(None)
    assert not is_string(1)
    assert not is_string(1.0)
    assert not is_string([1, 2, 3])
    assert not is_string([1, 'two', 3])
    assert not is_string({'one': 1, 'two': 2})
    assert not is_string((1, 'two', 3))



# Generated at 2022-06-20 15:35:06.646919
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2])
    assert is_iterable((1, 2))
    assert is_iterable({'x': 1})
    assert is_iterable(('x',))
    assert is_iterable(range(3))
    assert is_iterable(set([1, 2]))
    assert is_iterable(ImmutableDict(x=1))
    assert is_iterable({}.keys())
    assert is_iterable({}.items())
    assert is_iterable({}.values())
    assert is_iterable(x for x in range(3))

    assert not is_iterable(None)
    assert not is_iterable(42)
    assert not is_iterable('string')



# Generated at 2022-06-20 15:35:17.636506
# Unit test for function is_sequence
def test_is_sequence():
    class NonSequence:
        def __getitem__(self, key):
            raise TypeError

    # Python 2 class
    class Sequence2(object):
        def __len__(self):
            return 1

        def __getitem__(self, key):
            return 'a'

    # Python 3 class
    class Sequence3:
        def __len__(self):
            return 1

        def __getitem__(self, key):
            return 'a'

    assert is_sequence([])
    assert is_sequence([1])
    assert is_sequence((1, 2))
    assert is_sequence(set([1, 2]))
    assert is_sequence(Sequence2())
    assert is_sequence(Sequence3())
    assert not is_sequence(NonSequence())
    assert not is_sequence(1)
   

# Generated at 2022-06-20 15:35:29.822761
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    assert hash(ImmutableDict()) == hash(dict())
    assert hash(ImmutableDict({1: 2})) == hash(dict({1: 2}))
    assert hash(ImmutableDict([(1, 2)])) == hash(dict([(1, 2)]))
    assert hash(ImmutableDict(zip([1], [2]))) == hash(dict(zip([1], [2])))
    assert hash(ImmutableDict({1: 2, 3: 4})) == hash(dict({1: 2, 3: 4}))
    assert hash(ImmutableDict(one=1)) == hash(dict(one=1))

# Generated at 2022-06-20 15:35:33.054654
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = d1.difference(['a'])
    assert 'a' not in d2
    assert 'b' in d2



# Generated at 2022-06-20 15:35:38.116402
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    immutable_dict = ImmutableDict({'foo': 'bar', 'baz': 'qux'})
    assert immutable_dict['foo'] == 'bar'


# Generated at 2022-06-20 15:35:48.459723
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    a = ImmutableDict((("a", 1), ("b", 5), ("c", 10)))
    b = ImmutableDict((("b", 5), ("c", 10), ("a", 1)))
    assert a.__hash__() == b.__hash__()
    b = ImmutableDict((("b", 5), ("c", 10), ("a", 2)))
    assert a.__hash__() != b.__hash__()
    b = ImmutableDict((("b", 5), ("c", 10), ("d", 1)))
    assert a.__hash__() != b.__hash__()
    b = ImmutableDict((("b", 6), ("c", 10), ("a", 1)))
    assert a.__hash__() != b.__hash__()


# Generated at 2022-06-20 15:35:58.071956
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    assert ImmutableDict({'a':'a1', 'b':'b1', 'c':{'d':'d1'}}) == ImmutableDict({'a':'a1', 'b':'b1', 'c':{'d':'d1'}})
    assert ImmutableDict({'a':'a1', 'b':'b1', 'c':{'d':'d1'}}) != ImmutableDict({'a':'a1', 'b':'b1'})

# Generated at 2022-06-20 15:36:00.107534
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    immutable_dict = ImmutableDict({'name': 'Jim'})
    assert immutable_dict['name'] == 'Jim'


# Generated at 2022-06-20 15:36:04.683138
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    x = ImmutableDict(a=1, b=2, c=3)
    assert x['a'] == 1
    assert x['b'] == 2
    assert x['c'] == 3
    assert len(x) == 3
    assert set(x.keys()) == set(['a', 'b', 'c'])
    assert set(x.values()) == set((1, 2, 3))


# Generated at 2022-06-20 15:36:08.553252
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    data1 = {
        'a': 1,
        'b': 2
    }
    id1 = ImmutableDict(data1)
    for k in id1:
        assert isinstance(k, text_type)


# Generated at 2022-06-20 15:36:20.732643
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    from nose.tools import assert_equals
    d = ImmutableDict(a=1, b=2, c=3)
    assert_equals(len(d), 3)

# Generated at 2022-06-20 15:36:29.803613
# Unit test for function count
def test_count():
    assert count([]) == dict()
    assert count([1, 2, 3]) == {1: 1, 2: 1, 3: 1}
    assert count(['a', 'b', 'a', 'c']) == {'a': 2, 'b': 1, 'c': 1}
    assert count(['a', 'b', 'a', 'a']) == {'a': 3, 'b': 1}
    assert count('abc') == {'a': 1, 'b': 1, 'c': 1, 'd': 0}
    assert count(range(4)) == {0: 1, 1: 1, 2: 1, 3: 1}
    assert count(set([1, 2])) == {1: 1, 2: 1}
    # Test some iterable objects

# Generated at 2022-06-20 15:36:39.329649
# Unit test for function is_iterable
def test_is_iterable():
    def func():
        pass

    class Cls(object):
        pass

    assert is_iterable([1, 2, 3]) is True
    assert is_iterable((1, 2, 3)) is True
    assert is_iterable(set((1, 2, 3))) is True
    assert is_iterable(dict(one=1, two=2, three=3)) is True
    assert is_iterable(xrange(5)) is True
    assert is_iterable(func) is True
    assert is_iterable(Cls) is True

    assert is_iterable(1) is False
    assert is_iterable('string') is False
    assert is_iterable(None) is False



# Generated at 2022-06-20 15:36:41.439290
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    idict = ImmutableDict(dict(a=1, b=2, c=3))
    assert hash(idict)


# Generated at 2022-06-20 15:36:44.112084
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert repr(ImmutableDict({'a': 1, 'b': 2})) == "ImmutableDict({'a': 1, 'b': 2})"



# Generated at 2022-06-20 15:36:52.004596
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1, 2, 3})
    assert is_iterable({1: 3, 4: 5})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable((i for i in range(10)))

    assert is_iterable({1, 2, 3}, include_strings=True)
    assert is_iterable('string', include_strings=True)
    assert is_iterable(b'string', include_strings=True)

    assert not is_iterable(1)
    assert not is_iterable(object())
    assert not is_iterable(object)
    assert not is_iterable(Exception())

# Generated at 2022-06-20 15:36:56.477984
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict()
    # The same type
    d2 = ImmutableDict()
    assert d1 == d2
    # Not ImmutableDict type, but has the same content
    d3 = dict()
    assert not d1 == d3


# Generated at 2022-06-20 15:36:57.770419
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    assert len(ImmutableDict()) == 0


# Generated at 2022-06-20 15:37:00.535950
# Unit test for function count
def test_count():
    assert count([1, 1, 2, 3, 4, 5, 1, 4]) == {1: 3, 2: 1, 3: 1, 4: 2, 5: 1}



# Generated at 2022-06-20 15:37:07.546502
# Unit test for function count
def test_count():
    """Test for ansible.module_utils.basic.count"""
    seq = [1,2,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5]
    assert count(seq) == {1:1, 2:1, 3:1, 4:17, 5:40}


# Generated at 2022-06-20 15:37:35.773881
# Unit test for function is_iterable
def test_is_iterable():
    # Define some test data
    some_list = [1, 2, 3]
    some_set = set([1, 2, 3])
    some_tuple = ('a', 'b', 'c')
    some_dict = {'a': 'b', 'c': 'd'}
    some_int = 1
    some_string = 'a'
    some_binary = b'a'
    some_file = open(__file__)

    assert is_iterable(some_list)
    assert is_iterable(some_set)
    assert is_iterable(some_tuple)
    assert is_iterable(some_dict)
    assert is_iterable(some_file)
    assert not is_iterable(some_int)
    assert not is_iterable(some_string)

# Generated at 2022-06-20 15:37:41.930829
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    keys_dict_1 = ImmutableDict(a=1, b=2, c=3)
    subtractive_iterable = ['a', 'b']
    keys_dict_2 = keys_dict_1.difference(subtractive_iterable)
    assert len(keys_dict_2) == 1 and keys_dict_2['c'] == 3


# Generated at 2022-06-20 15:37:46.614269
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a = ImmutableDict(b=1, c=3)
    b = a.union(dict(b=0, d=5))
    assert b == ImmutableDict(b=0, c=3, d=5)
    assert a == ImmutableDict(b=1, c=3)


# Generated at 2022-06-20 15:37:52.098610
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a = ImmutableDict(a=1, b=2)
    b = {'b': 3, 'c': 4}

    c = a.union(b)
    assert c == dict(a=1, b=3, c=4)

    # Ensure that 'a' and 'b' are not modified
    assert a == dict(a=1, b=2)
    assert b == dict(b=3, c=4)


# Generated at 2022-06-20 15:37:56.481170
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict({'a': 'A', 'b': 'B'})
    el = [x for x in d]
    expected_elements = [('a', 'A'), ('b', 'B')]
    assert el == expected_elements


# Generated at 2022-06-20 15:38:00.740944
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original_dict = ImmutableDict({'foo': 'bar', 'test': 'string', 'exclude': 'key'})
    subtract_list = ['exclude']
    new_dict = original_dict.difference(subtract_list)
    assert new_dict == ImmutableDict({'foo': 'bar', 'test': 'string'})


# Generated at 2022-06-20 15:38:05.244797
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
#
# The code below is generated, do not edit it directly.
# Generation date: 2018-08-09T12:53:53.261181
#
# Original file name: testcases_v2/test_ansible_module_utils_low_level.py
# GID: 1757
#

    my_immutable_instance = ImmutableDict({'a': 1})
    assert 'a' in my_immutable_instance
 

# Generated at 2022-06-20 15:38:12.619663
# Unit test for function is_sequence
def test_is_sequence():
    """Unit test for function is_sequence.
    """

    import numbers
    from collections import Mapping
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves.urllib.parse import quote

    assert is_sequence([])
    assert is_sequence(())
    assert is_sequence(set())
    assert is_sequence(frozenset())
    assert is_sequence(range(1, 10))
    assert is_sequence(xrange(1, 10))

    assert not is_sequence(None)
    assert not is_sequence(1)
    assert not is_sequence(dict())
    assert not is_sequence(quote)
    assert not is_sequence(Mapping)
    assert not is_sequence(string_types)


# Generated at 2022-06-20 15:38:15.592081
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    x = dict(a='b', c='d')
    y = ImmutableDict(x)
    assert x == y
    assert y.__getitem__('a') == 'b'



# Generated at 2022-06-20 15:38:21.206054
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict({"a": 1, "b": 2, "c": 3})
    overriding_mapping = {"a": 1, "d": 2, "e": 3}
    expected = {"a": 1, "b": 2, "c": 3, "d": 2, "e": 3}
    assert original.union(overriding_mapping) == expected



# Generated at 2022-06-20 15:39:04.552298
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    m1 = ImmutableDict(
        {
            'k0': 'v0',
            'k1': 'v1',
            'k2': 'v2',
        }
    )
    m2 = ImmutableDict(
        {
            'k0': 'v0',
            'k1': 'v1',
            'k2': 'v2',
        }
    )
    m3 = ImmutableDict(
        {
            'k1': 'v1',
            'k2': 'v2',
            'k0': 'v0',
        }
    )
    assert m1 == m2
    assert m2 == m3
    assert hash(m1) != hash(m3)
    assert m1 != m3
    assert not (m1 != m2)

# Generated at 2022-06-20 15:39:05.873904
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    x = ImmutableDict({'a': 1, 'b': 2})
    assert x['a'] == 1


# Generated at 2022-06-20 15:39:11.231605
# Unit test for function count
def test_count():
    """Verify count function return values with expected results."""
    assert count([1, 2, 3, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2]) == {1: 7, 2: 8, 3: 1}
    assert count([]) == {}
    assert count('') == {}



# Generated at 2022-06-20 15:39:12.921777
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict(text='text1', number=1)) == 2


# Generated at 2022-06-20 15:39:16.966326
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    immutable_dict = ImmutableDict(a='1', b='2', c='3')

    removed_keys = ['a', 'b']
    new_dict = immutable_dict.difference(removed_keys)

    assert new_dict.keys() == ['c']



# Generated at 2022-06-20 15:39:25.559330
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    import sys

    dict_ = ImmutableDict()
    assert len(dict_) == 0
    assert dict_.get("any key") is None
    assert dict_.get("any key", "default") == "default"

    dict_ = ImmutableDict([("key", "value")])
    assert len(dict_) == 1
    assert dict_["key"] == "value"
    assert dict_.get("key") == "value"

    dict_ = ImmutableDict([("key", "value"), ("another key", "another value")])
    assert len(dict_) == 2
    assert dict_["key"] == "value"
    assert dict_["another key"] == "another value"



# Generated at 2022-06-20 15:39:32.225404
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    d1 = ImmutableDict({"a": 1, "b": 2})
    d2 = ImmutableDict({"b": 10, "c": 20})
    d3 = d1.union(d2)
    assert len(d3) == 3
    assert d3["a"] == 1
    assert d3["b"] == 10
    assert d3["c"] == 20


# Generated at 2022-06-20 15:39:37.278747
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    immutable_dict = ImmutableDict({'a': 1, 'b': 2})
    assert immutable_dict['a'] == 1
    # Since the class is immutable, it should not allow changes
    try:
        immutable_dict['a'] = 3
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-20 15:39:42.197630
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    dict_a = ImmutableDict(one=1, two=2)
    dict_b = ImmutableDict(two=2, three=3)
    dict_c = dict_a.union(dict_b)
    dict_d = ImmutableDict(one=1, two=2, three=3)

    assert dict_c == dict_d


# Generated at 2022-06-20 15:39:45.534064
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    dictionary = ImmutableDict(a=1, b=2, c=3)
    assert repr(dictionary) == 'ImmutableDict({\'a\': 1, \'c\': 3, \'b\': 2})'


# Generated at 2022-06-20 15:41:02.573253
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Unit test for method __repr__ of class ImmutableDict"""

    # Test an empty dictionary
    result = ImmutableDict().__repr__()
    assert result == 'ImmutableDict({0})'.format(repr(dict()))

    # Check that unicode values are correctly handled
    # Note that unicode can be stored in a dict only on Python 2, not 3,
    # and so the test does not work on Python 3.
    # The source code for this function is such that unicode values,
    # whether or not stored in a dict, should be correctly handled.
    # So this test can safely be skipped on Python 3.
    import sys
    if sys.version_info[0] < 3:
        result = ImmutableDict({'unicode value': u'test'}).__repr__()
        assert result

# Generated at 2022-06-20 15:41:07.440219
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict({'a': 1, 'b': 2})
    overriding_mapping = {'b': 20, 'c': 3}
    new_dict = original.union(overriding_mapping)
    assert new_dict == ImmutableDict({'a': 1, 'b': 20, 'c': 3})


# Generated at 2022-06-20 15:41:12.338891
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert ImmutableDict({"key1":"value1"}).__repr__() == "ImmutableDict({'key1': 'value1'})"
    assert ImmutableDict({"key1":"value1"},{"key2":"value2"}).__repr__() == "ImmutableDict({'key1': 'value1', 'key2': 'value2'})"

# Generated at 2022-06-20 15:41:17.135661
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # First we create a normal dictionary
    d = {'a': 1, 'b': 2, 'c': 3}
    # Then we create an ImmutableDict with the same keys and values
    imd = ImmutableDict(d)
    # Finally we compare the hash value of the ImmutableDict with
    # the hash value of the normal dictionary
    assert hash(imd) == hash(d)

# Generated at 2022-06-20 15:41:23.885032
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Unit test for method __hash__ of class ImmutableDict."""
    from ansible.module_utils.common._collections_compat import Mapping

    iterable = [('a', 1), ('b', 2)]
    d1 = ImmutableDict(iterable)
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert isinstance(d1, Mapping)
    assert isinstance(d2, Mapping)
    assert d1 == d2
    assert d1.__hash__() == d2.__hash__()

# Generated at 2022-06-20 15:41:27.073180
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    test_dict = ImmutableDict({'a': 1, 'b': 2})
    assert repr(test_dict) == 'ImmutableDict({\'a\': 1, \'b\': 2})'


# Generated at 2022-06-20 15:41:29.706564
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    assert len(d) == 4


# Generated at 2022-06-20 15:41:37.208436
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():

    immutable_dict = ImmutableDict(hello='world')
    assert immutable_dict['hello'] == 'world'

    override_dict = {'hello': 'planet'}
    updated_immutable_dict = immutable_dict.union(override_dict)
    assert updated_immutable_dict['hello'] == 'planet'

    subtractive_iter = ['hello']
    subsetted_immutable_dict = immutable_dict.difference(subtractive_iter)
    assert subsetted_immutable_dict == ImmutableDict()

# Generated at 2022-06-20 15:41:45.968092
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    i = ImmutableDict({'a': 'b', 'c': 'd', 'e': 'f'})
    j = i.difference(['a'])
    assert len(j) == 2
    assert 'a' not in j
    assert j.get('a') is None

    k = i.difference(['x'])
    assert len(k) == 3
    assert k == i

    l = i.difference(['a', 'b', 'c', 'd', 'e', 'f'])
    assert len(l) == 0
    assert l == ImmutableDict()


# Generated at 2022-06-20 15:41:53.942772
# Unit test for function is_string
def test_is_string():
    # pylint: disable=no-name-in-module,import-error
    from ansible.module_utils.common.collections import AnsibleVaultEncryptedUnicode
    assert is_string('test')
    assert is_string(b'test')
    assert is_string(u'test')
    assert is_string(AnsibleVaultEncryptedUnicode(u'test'))
    assert not is_string([])
    assert not is_string((1, 2))
    assert not is_string(object())
    assert not is_string(None)
    assert not is_string({})
    assert not is_string(Exception())
