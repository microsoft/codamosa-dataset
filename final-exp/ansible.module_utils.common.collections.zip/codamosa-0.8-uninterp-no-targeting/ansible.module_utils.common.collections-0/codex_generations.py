

# Generated at 2022-06-20 15:33:50.065963
# Unit test for function is_iterable
def test_is_iterable():
    """Test the is_iterable function.

    This function only tests is_iterable that is not a sequence by itself,
    since is_sequences just calls is_iterable.
    """
    assert is_iterable([1, 2]), 'List is not iterable'
    assert is_iterable((1, 2)), 'Tuple is not iterable'
    assert is_iterable({1, 2}), 'Set is not iterable'
    assert is_iterable({1: 1, 2: 2}), 'Dictionary is not iterable'
    assert is_iterable(xrange(10)), 'xrange is not iterable'

    class Iterable(object):
        def __iter__(self):
            return iter([])

    assert is_iterable(Iterable()), 'Class with __iter__ is not iterable'


# Generated at 2022-06-20 15:33:57.269363
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    # Test namespace
    # Base namespace
    base = {'a': 'a', 'b': 'b'}
    ns_base = ImmutableDict(base)
    assert ns_base['a'] == 'a'
    assert ns_base['b'] == 'b'

    # Overriding base namespace
    override = {'a': 'override'}
    ns_override = ns_base.union(override)
    assert ns_override['a'] == 'override'
    assert ns_override['b'] == 'b'

    # Addition to base namespace
    addition = {'c': 'c'}
    ns_addition = ns_base.union(addition)
    assert ns_addition['a'] == 'a'
    assert ns_addition['b'] == 'b'

# Generated at 2022-06-20 15:34:09.501477
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    '''Test ImmutableDict class'''

    # Test without parameters
    # Constructor __init__
    i = ImmutableDict()
    # Testing __getitem__
    assert i['key1'] == 'value1'
    # Testing __getitem__
    assert i['key2'] == 'value2'

    # Test with parameters
    # Constructor __init__
    i = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    # Testing __getitem__
    assert i['key1'] == 'value1'
    # Testing __getitem__
    assert i['key2'] == 'value2'

    # Testing __iter__
    # Testing __len__
    assert len(i) == 2

    # Testing __hash__
    # Testing __eq__
    assert i

# Generated at 2022-06-20 15:34:19.065249
# Unit test for function is_iterable
def test_is_iterable():
    # make it True on Python 3
    STRINGS_ARE_ITERABLE = False

    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())

    if STRINGS_ARE_ITERABLE:  # only True on Python 3
        assert is_iterable('')
        assert is_iterable(b'')
    else:
        assert not is_iterable('')
        assert not is_iterable(b'')

    assert not is_iterable(1)
    assert not is_iterable(None)



# Generated at 2022-06-20 15:34:25.297817
# Unit test for function count
def test_count():
    sample = range(10)
    output = count(sample)
    reversed = dict()
    for k, v in output.items():
        reversed[v] = reversed.get(v, []) + [k]
    assert isinstance(output, dict)
    assert output == {0: 1, 1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 1, 7: 1, 8: 1, 9: 1}
    assert len(reversed) == 10
    assert len(reversed[1]) == 10



# Generated at 2022-06-20 15:34:32.646769
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    class Dictionary(ImmutableDict):
        def __init__(self, values):
            ImmutableDict.__init__(self, values)

    d = Dictionary({'a': 4, 'b': 5, 'c': 6})
    assert d['a'] == 4
    assert d['b'] == 5
    assert d['c'] == 6
    try:
        d['d']
    except KeyError:
        pass
    else:
        assert False, 'd["d"] should produce KeyError'



# Generated at 2022-06-20 15:34:35.669796
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict({1: 'a', 2: 'b'})
    assert sorted(d.__iter__()) == [1, 2]


# Generated at 2022-06-20 15:34:40.440117
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict({'a': 1, 'b': 2})) == 2
    assert len(ImmutableDict(a=1, b=2)) == 2


# Generated at 2022-06-20 15:34:51.856221
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Testing __repr__ method of class ImmutableDict"""
    # Test against some invalid inputs
    for bad_input in [123, 3.14, lambda x: x, None]:
        try:
            ImmutableDict(bad_input)
        except Exception as err:
            assert "__init__() argument after ** must be a mapping, not" in str(err)

    # Test against some valid inputs

# Generated at 2022-06-20 15:34:54.161148
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    data = {'a': 'A', 'b': 'B'}
    immutableDict = ImmutableDict(data)
    assert immutableDict['a'] == 'A'


# Generated at 2022-06-20 15:35:08.570921
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    assert (ImmutableDict({'a': 'b', 'c': 'd', 'e': 'f'}).difference(('a', 'c')) == ImmutableDict({'e': 'f'}))
    assert (ImmutableDict({'a': 'b', 'c': 'd', 'e': 'f'}).difference(['a', 'c']) == ImmutableDict({'e': 'f'}))
    assert (ImmutableDict({'a': 'b', 'c': 'd', 'e': 'f'}).difference(('a', 'c', 'e', 'g')) == ImmutableDict({}))

# Generated at 2022-06-20 15:35:14.989341
# Unit test for function is_string
def test_is_string():
    assert not is_string(list())
    assert is_string(u'a')
    assert is_string(u'\u2713')
    assert is_string(b'a')
    assert is_string(bytearray(b'a'))
    assert is_string(b'\xe2\x9c\x93')
    assert not is_string([1])


# Generated at 2022-06-20 15:35:22.641248
# Unit test for function is_sequence
def test_is_sequence():
    assert not is_sequence(3)
    assert is_sequence([])
    assert is_sequence([1, 2, 3])
    assert is_sequence((1, 2, 3))
    assert is_sequence({'a': 1})
    assert is_sequence({'a': 1}.keys())
    assert is_sequence({'a': 1}.values())
    assert is_sequence({'a': 1}.items())
    assert not is_sequence(set([1, 2, 3]))
    assert is_sequence(frozenset([1, 2, 3]))
    assert is_sequence(range(1, 4))
    assert not is_sequence(dict())
    assert not is_sequence(dict().keys())
    assert not is_sequence(dict().values())
    assert not is_sequence(dict().items())
    assert not is_sequence

# Generated at 2022-06-20 15:35:34.053869
# Unit test for function count
def test_count():
    from nose.tools import assert_equals
    assert_equals(count([]), {})
    assert_equals(count([1, 2, 3]), {1: 1, 2: 1, 3: 1})
    assert_equals(count([1, 2, 1, 2, 1]), {1: 3, 2: 2})
    assert_equals(count([7, 7, 1, 2]), {1: 1, 2: 1, 7: 2})
    assert_equals(count([1, 1, 2, 5, 5, 5]), {1: 2, 2: 1, 5: 3})
    assert_equals(count('hello'), {'h': 1, 'e': 1, 'l': 2, 'o': 1})

    import nose

# Generated at 2022-06-20 15:35:38.313350
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d = ImmutableDict(a=42, b=100)
    assert hash(d) == hash(frozenset(d.items()))


# Generated at 2022-06-20 15:35:40.752986
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    x = ImmutableDict({'foo': 'bar'})
    assert x['foo'] == 'bar'


# Generated at 2022-06-20 15:35:41.843490
# Unit test for function is_string
def test_is_string():
    assert is_string('ansible') is True



# Generated at 2022-06-20 15:35:44.844233
# Unit test for function is_string
def test_is_string():
    assert is_string('abc')
    assert is_string(u'abc')
    assert is_string(b'abc')
    assert not is_string(123)
    assert not is_string([])


# Generated at 2022-06-20 15:35:50.668306
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():

    assert len(ImmutableDict()) == 0

    assert len(ImmutableDict({})) == 0

    assert len(ImmutableDict({'a': 1})) == 1

    assert len(ImmutableDict({'a': 1, 'b': 2})) == 2

    assert len(ImmutableDict({'a': 1, 'b': 2, 'c': 3})) == 3



# Generated at 2022-06-20 15:35:56.760298
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1) == ImmutableDict(a=1)
    assert not ImmutableDict(a=1) == ImmutableDict(b=1)
    assert not ImmutableDict(a=1) == ImmutableDict(a=2)
    assert not ImmutableDict(a=1, b=2) == ImmutableDict(a=1)
    assert not ImmutableDict(a=1) == ImmutableDict(a=1, b=2)


# Generated at 2022-06-20 15:36:06.383251
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    assert ImmutableDict((('foo', 42), ('bar', 43)))['foo'] == 42
    assert ImmutableDict((('foo', 42), ('bar', 43)))['bar'] == 43



# Generated at 2022-06-20 15:36:12.786873
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    idict = ImmutableDict({'1': 'one', '2': 'two', '3': 'three', '4': 'four'})
    removed = idict.difference(['2', '3'])
    assert len(removed) == 2
    assert '1' in removed
    assert removed['1'] == 'one'
    assert '4' in removed
    assert removed['4'] == 'four'


# Generated at 2022-06-20 15:36:18.359127
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    # create and test trivial cases
    a = ImmutableDict()
    assert(a.union({}) == a)
    assert(a.union({'a': 1}) == ImmutableDict({'a': 1}))

    # Test overwriting
    a = ImmutableDict({'a': 1, 'b': 2})
    assert(a.union({'a': 0}) == ImmutableDict({'a': 0, 'b': 2}))

    # Test adding entries
    assert(a.union({'c': 3}) == ImmutableDict({'a': 1, 'b': 2, 'c': 3}))

    # Test adding and overwriting
    assert(a.union({'b': 0, 'c': 3}) == ImmutableDict({'a': 1, 'b': 0, 'c': 3}))

# Generated at 2022-06-20 15:36:27.420987
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    test_dict = {
        1: 'foo',
        'bar': 'baz'
    }
    immutable_dict = ImmutableDict(test_dict)

    assert(immutable_dict[1] == 'foo')
    assert(immutable_dict['bar'] == 'baz')

    immutable_dict2 = immutable_dict.union({1: 'bar', 2: 'foo'})

    # Ensure that original has not been modified
    assert(immutable_dict[1] == 'foo')
    assert(immutable_dict2[1] == 'bar')

    exclude_keys = ImmutableDict({1: 'bar', 2: 'foo'}, exclude_keys=['bar'])
    assert('bar' not in exclude_keys)

# Generated at 2022-06-20 15:36:31.659265
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    for text in [
        ImmutableDict(),
        ImmutableDict({'one': 1, 'two': 2}),
    ]:
        assert repr(text) == 'ImmutableDict({0})'.format(repr(text._store))


# Generated at 2022-06-20 15:36:41.290962
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Check two empty ImmutableDict objects.
    empty_dict1 = ImmutableDict()
    empty_dict2 = ImmutableDict()
    assert empty_dict1 == empty_dict2

    # Check two ImmutableDict objects with different keys.
    dict1 = ImmutableDict(a=1)
    dict2 = ImmutableDict(b=1)
    assert dict1 != dict2

    # Check two ImmutableDict objects with different values.
    dict1 = ImmutableDict(a=1)
    dict2 = ImmutableDict(a=2)
    assert dict1 != dict2

    # Check ImmutableDict is equal to the original dict, with the same keys and values.
    dict1 = ImmutableDict(a=1, b=2)

# Generated at 2022-06-20 15:36:46.792374
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    id = ImmutableDict()
    assert len(str(id)) > 0
    id = ImmutableDict({'a': 1, 'b': 2})
    assert str(id) == "ImmutableDict({'a': 1, 'b': 2})"
    id = ImmutableDict(a=1, b=2)
    assert str(id) == "ImmutableDict({'a': 1, 'b': 2})"


# Generated at 2022-06-20 15:36:52.361532
# Unit test for function count
def test_count():
    SEQ = [1, 'a', (1, 1), (1, 1), 'a', 'a', 1, 1, 2, 1, 2, 1, 2, 'a', 1, 2, 1]
    CT = count(SEQ)
    assert CT[1] == 7
    assert CT['a'] == 4
    assert CT[(1, 1)] == 2
    assert CT[2] == 4
    assert not CT[(1, 2)]
    try:
        count('a')
        assert False
    except Exception as ex:
        assert 'Argument provided  is not an iterable' in ex



# Generated at 2022-06-20 15:36:59.036140
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch, Mock

    with patch('ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils.ImmutableDict._store',
               new_callable=Mock) as mocked__store:
        ImmutableDict().__getitem__('test')

        mocked__store.__getitem__.assert_called_once_with('test')


# Generated at 2022-06-20 15:37:00.808694
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    idx = ImmutableDict({'foo': 'bar', 'baz': 42})
    assert len(idx) == 2



# Generated at 2022-06-20 15:37:22.085786
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    """Test the union method of ImmutableDict
    """
    immutable_dict = ImmutableDict(dict(a=1, b=2, c=3))
    immutable_dict2 = immutable_dict.union(dict(d=4, e=5))
    assert immutable_dict['c'] == 3
    assert immutable_dict2['e'] == 5
    assert immutable_dict2['c'] == 3
    assert 'd' in immutable_dict2


# Generated at 2022-06-20 15:37:26.944351
# Unit test for function is_sequence
def test_is_sequence():
    """Tests for function is_sequence"""
    # Assert function correctly identifies a sequence
    assert(is_sequence(['a', 'b', 'c']) == True)
    assert(is_sequence({'a', 'b', 'c'}) == True)
    assert(is_sequence(('a', 'b', 'c')) == True)
    # Assert function correctly identifies a string
    assert(is_sequence('abc') == False)
    # Assert function correctly identifies an integer
    assert(is_sequence(1) == False)
    # Assert function correctly identifies a dictionary
    assert(is_sequence({'a': 1, 'b': 2, 'c': 3}) == False)



# Generated at 2022-06-20 15:37:37.226144
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Add an element and then update it, using union() method
    original = ImmutableDict({'key1': 'value1','key2': 'value2','key3': 'value3'})
    overriding = {'key1': 'value1', 'key2': 'value2_updated'}
    updated = original.union(overriding)
    assert original == updated

    # Add an element and then update it, using __setitem__() method
    original = ImmutableDict({'key1': 'value1','key2': 'value2','key3': 'value3'})
    updated = ImmutableDict({'key1': 'value1','key2': 'value2_updated','key3': 'value3'})
    assert original == updated

    # Update an existing element and then delete it, using difference() method
    original = Imm

# Generated at 2022-06-20 15:37:41.899566
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    from six import assertRaisesRegex

    from ansible.module_utils._text import to_text

    # test Hashable implementation
    x = ImmutableDict(a=1)
    y = ImmutableDict(a=1)
    assert hash(x) == hash(y)

    # test hash propagation
    m = MutableMapping(x=1)
    x = ImmutableDict(m)
    assertRaisesRegex(TypeError,
                      to_text("unhashable type: 'MutableMapping'"),
                      hash,
                      x)

    # test hash propagation
    m = MutableMapping()
    x = ImmutableDict(a=1, b=m)

# Generated at 2022-06-20 15:37:46.692851
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Tests for ImmutableDict."""
    # Creating instances of ImmutableDict
    original = ImmutableDict([('one', 'one'), ('two', 'two')])
    assert ImmutableDict(original) == original
    assert ImmutableDict(dict(original)) == original
    assert ImmutableDict(**dict(original)) == original
    assert ImmutableDict(one='one', two='two') == original

    # Testing union(overriding_mapping)
    overriding_mapping = MutableMapping({'three': 'three'})
    result = ImmutableDict({'one': 'one', 'two': 'two', 'three': 'three'})
    assert original.union(overriding_mapping) == result

    # Testing difference(subtractive_iterable)

# Generated at 2022-06-20 15:37:54.073704
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    from ansible.module_utils._text import to_text
    test_dict = dict(one=1, two=2)
    test_immutabledict = ImmutableDict(test_dict)
    keys_immutabledict = [key for key in test_immutabledict]
    keys_dict = [key for key in test_dict]
    assert keys_immutabledict == keys_dict


# Generated at 2022-06-20 15:37:56.906509
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    a = ImmutableDict(foo='bar', baz='quux', qux=42)
    b = a.difference(['foo', 'qux'])
    assert b == ImmutableDict(baz='quux')


# Generated at 2022-06-20 15:38:05.244625
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    items = dict(a=1, b=2, c=3)
    mapping = ImmutableDict(items)

    mapping_subtracted = mapping.difference([])
    assert mapping_subtracted == mapping

    mapping_subtracted = mapping.difference(['a', 'b'])
    assert mapping_subtracted == ImmutableDict(dict(c=3))

    mapping_subtracted = mapping.difference(['a', 'b', 'c'])
    assert mapping_subtracted == ImmutableDict(dict())

    mapping_subtracted = mapping.difference(['d', 'e', 'f'])
    assert mapping_subtracted == mapping



# Generated at 2022-06-20 15:38:09.632439
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    expected = [1, 2, 3]
    test_dict = ImmutableDict([(1, 1), (2, 2), (3, 3)])
    for index, value in enumerate(test_dict):
        assert value == expected[index]



# Generated at 2022-06-20 15:38:14.589615
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict(one=1, two=2, three=3, four=4, five=5)
    one_to_three = original.difference([3, 4, 5])
    assert(one_to_three == {'one': 1, 'two': 2})


# Generated at 2022-06-20 15:38:51.594158
# Unit test for function count
def test_count():
    assert count([]) == {}
    assert count(['a','b','c','a','a','a','a','c','d','a','a','a','c','b','b','b','a','a']) == {'a': 10, 'c': 4, 'b': 4, 'd': 1}
    assert count(set(['a','b','c'])) == {'a': 1, 'c': 1, 'b': 1}
    try:
        count(5)
        assert False  # This line should not execute
    except Exception:
        assert True # An exception should occur


# Generated at 2022-06-20 15:38:53.951853
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    result = repr(ImmutableDict({'a': 'b'}))
    assert result == "ImmutableDict({'a': 'b'})"

# Generated at 2022-06-20 15:39:03.087354
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict()
    c = a.union(b)
    assert c == a
    assert c is not a
    assert c == ImmutableDict({'a': 1, 'b': 2})
    assert c is not ImmutableDict({'a': 1, 'b': 2})
    assert c == ImmutableDict(a)
    assert c is not ImmutableDict(a)
    assert c == ImmutableDict(b, **a)
    assert c is not ImmutableDict(b, **a)

    b = ImmutableDict({'b': 20, 'c': 30})
    c = a.union(b)
    assert c == a
    assert c is not a

# Generated at 2022-06-20 15:39:14.043682
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    assert ImmutableDict({'a': 'b', 'c': 'd'}) == ImmutableDict({'a': 'b', 'c': 'd'})
    assert ImmutableDict({'a': 'b', 'c': 'd'}) != ImmutableDict({'a': 'b', 'c': 'd', 'e': 'f'})
    assert ImmutableDict({'a': 'b', 'c': 'd'}) != ImmutableDict({'a': 'b', 'e': 'f'})
    assert ImmutableDict({'a': 'b', 'c': 'd'}).union({'c': 'f', 'e': 'f'}) == {'a': 'b', 'c': 'f', 'e': 'f'}

# Generated at 2022-06-20 15:39:22.813509
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():

    ORIGINAL_DICT = dict(item1=1, item2=2, item3=3)

    # Create two ImmutableDicts with the same key-value pairs
    ORIGINAL_IMMUTABLE_DICT = ImmutableDict(ORIGINAL_DICT)
    DUPLICATE_IMMUTABLE_DICT = ImmutableDict(ORIGINAL_DICT)

    assert ORIGINAL_IMMUTABLE_DICT == DUPLICATE_IMMUTABLE_DICT
    assert hash(ORIGINAL_IMMUTABLE_DICT) == hash(DUPLICATE_IMMUTABLE_DICT)

    # Add a new item to the original dictionary
    MODIFIED_DICT = dict(ORIGINAL_DICT)
    MODIFIED_DICT['item4'] = 4

    EXPECTED_IMM

# Generated at 2022-06-20 15:39:26.332148
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    base_dict = {'a': 1, 'b': 2}
    test_dict = ImmutableDict(base_dict)
    assert test_dict == ImmutableDict(base_dict)

# Generated at 2022-06-20 15:39:32.431318
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(dict())
    assert not is_iterable(3)
    assert not is_iterable(3.0)
    assert is_iterable((i for i in range(3)))
    assert not is_iterable(None)
    return True



# Generated at 2022-06-20 15:39:43.618584
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    test_dict1 = ImmutableDict({'a': 1, 'b': 2})
    test_dict2 = ImmutableDict({'c': 3, 'd': 4})
    test_dict3 = ImmutableDict({'b': 5, 'e': 6})

    # Test that __eq__ and __hash__ methods work as intended
    assert test_dict1 == test_dict1
    assert test_dict1 != test_dict2
    assert hash(test_dict1) != hash(test_dict2)

    # Test that __len__ and __iter__ methods work as intended
    assert len(test_dict1) == 2
    assert len(test_dict2) == 2
    assert len(test_dict3) == 2
    assert list(test_dict1) == ['a', 'b']

# Generated at 2022-06-20 15:39:48.546873
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    test_dict = ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    assert(test_dict == test_dict)
    assert(len(test_dict) == 3)

    test_dict = ImmutableDict()
    assert(len(test_dict) == 0)



# Generated at 2022-06-20 15:39:54.615965
# Unit test for function is_string
def test_is_string():
    """
    Test function is_string
    """
    assert is_string("abc") is True
    assert is_string(u"abc") is True
    assert is_string("abc".encode("utf-8")) is True
    assert is_string(10) is False
    assert is_string([1, 2, 3]) is False


# Generated at 2022-06-20 15:41:02.175055
# Unit test for function is_sequence
def test_is_sequence():
    """Unit test for function is_sequence."""
    assert is_sequence([])
    assert is_sequence(())
    assert is_sequence(set())
    assert is_sequence({'x': 'y'})
    assert is_sequence('')
    assert is_sequence(b'123')
    assert is_sequence('123')
    assert is_sequence(u'123')

    assert is_sequence([], include_strings=True)

# Generated at 2022-06-20 15:41:09.012333
# Unit test for function count
def test_count():
    assert count([1, 2, 3, 1, 1]) == {1: 3, 2: 1, 3: 1}
    assert count(('abc', 'abc', 'bcd', 'bcd', 'cde')) == {'abc': 2, 'bcd': 2, 'cde': 1}
    assert count({'apple', 'apple', 'banana', 'pear'}) == {'apple': 2, 'banana': 1, 'pear': 1}


# Generated at 2022-06-20 15:41:10.932932
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert repr(ImmutableDict())=='ImmutableDict({})'


# Generated at 2022-06-20 15:41:18.883555
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    # Test that default constructor return empty description
    d1 = ImmutableDict()
    assert d1.__repr__() == 'ImmutableDict({})'

    # Test that constructor with empty input returns empty description
    d2 = ImmutableDict({})
    assert d2.__repr__() == 'ImmutableDict({})'

    # Test that constructor with numeric keys returns corresponding description
    d3 = ImmutableDict({0: 1, 1: 2, 2: 3})
    assert d3.__repr__() == 'ImmutableDict({0: 1, 1: 2, 2: 3})'

    # Test that constructor with string keys returns corresponding description
    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-20 15:41:20.793339
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    immutable_dict = ImmutableDict(a=1, b=2, c=3)

    assert set(immutable_dict.__iter__()) == set(['a', 'b', 'c'])


# Generated at 2022-06-20 15:41:23.067076
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict({"A": 1, "B": 2})
    assert len(list(d.__iter__())) == 2



# Generated at 2022-06-20 15:41:27.560182
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence('a') is False
    assert is_sequence(b'a') is False
    assert is_sequence('a', include_strings=True) is True
    assert is_sequence(b'a', include_strings=True) is True
    assert is_sequence(((1, 2),)) is True
    assert is_sequence([1, 2]) is True
    assert is_sequence([[[[1, 2], [3, 4]]]]) is True
    assert is_sequence({1: 'a', 2: 'b'}) is False
    assert is_sequence(1) is False
    assert is_sequence(True) is False

# Generated at 2022-06-20 15:41:38.757473
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """
    Tests for method __hash__ of class ImmutableDict
    """

# Generated at 2022-06-20 15:41:42.845413
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Check that ImmutableDict class works correctly"""
    adict = ImmutableDict({1: "first", 2: "second"})
    anotherdict = ImmutableDict({1: "first", 2: "second"})
    assert adict == anotherdict

# Generated at 2022-06-20 15:41:47.864165
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    a = ImmutableDict()
    b = ImmutableDict()
    c = ImmutableDict(a={'a': 'b'})
    d = ImmutableDict(a={'a': 'b'})
    assert hash(a) == hash(b)
    assert hash(c) == hash(d)
    assert hash(a) != hash(c)