

# Generated at 2022-06-20 15:33:49.593403
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    # Test union between an empty ImmutableDict and a mapping without common keys
    test_dict = ImmutableDict()
    immutable_dict_union = ImmutableDict({'a': 1, 'b': 2})
    assert repr(test_dict.union(immutable_dict_union)) == repr(ImmutableDict({'a': 1, 'b': 2}))
    # Test union between an empty ImmutableDict and a mapping with common keys
    immutable_dict_union = ImmutableDict({'a': 2})
    assert repr(test_dict.union(immutable_dict_union)) == repr(ImmutableDict({'a': 2}))
    # Test union between an ImmutableDict and a mapping without common keys
    test_dict = ImmutableDict({'a': 1, 'b': 2})
    immutable_dict

# Generated at 2022-06-20 15:33:56.439421
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    dict_under_test = ImmutableDict(a=1, b=2, c=3)
    expected_result = 1
    actual_result = dict_under_test['a']
    assert expected_result == actual_result


# Generated at 2022-06-20 15:34:01.183973
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    # expected_return_value = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    # Actual_return_value = repr(ImmutableDict({'a': 1, 'b': 2, 'c': 3}))
    # assert(expected_return_value == Actual_return_value)
    None

# Generated at 2022-06-20 15:34:04.892039
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = {'one': 1, 'two': 2, 'three': 3}
    id = ImmutableDict(d)
    assert [k for k in d] == [k for k in id]


# Generated at 2022-06-20 15:34:06.996124
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    assert ImmutableDict({'a': 3})['a'] == 3


# Generated at 2022-06-20 15:34:19.281495
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():

    # Test construction of an ImmutableDict
    map1 = ImmutableDict({"a": 1, "b": 2})
    assert map1["a"] == 1
    assert map1["b"] == 2

    # Test construction of an ImmutableDict with keyword arguments
    map2 = ImmutableDict(a=1, b=2)
    assert map2["a"] == 1
    assert map2["b"] == 2

    # Test construction of an ImmutableDict with no arguments
    map3 = ImmutableDict()
    assert map3 == {}

    # Test that an ImmutableDict is immutable
    try:
        map1["c"] = 3
    except TypeError:
        pass
    else:
        raise Exception('ImmutableDict is mutable')

    # Test that an ImmutableDict cannot be instantiated from

# Generated at 2022-06-20 15:34:21.034840
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict(a=1)) == 1
    assert len(ImmutableDict(a=1, b=2)) == 2


# Generated at 2022-06-20 15:34:26.381189
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    idict1 = ImmutableDict(one=1, two=2, three=3)
    assert idict1['one'] == 1
    assert idict1['two'] == 2
    assert idict1['three'] == 3
    try:
        idict1['four']
    except KeyError as e:
        assert str(e) == 'Key not found: four'
    except Exception as e:
        raise Exception('Exception not of type KeyError: exception: {0}'.format(str(e)))
    else:
        raise Exception('No exception raised')


# Generated at 2022-06-20 15:34:29.013211
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict({'a': 1, 'b': 2, 'c': 3})) == 3



# Generated at 2022-06-20 15:34:34.387960
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    testdict = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert isinstance(testdict, Mapping), "testdict should be an instance of class Mapping"
    assert iter(testdict) == testdict.__iter__(), "__iter__ should return an iterator"
    assert not isinstance(testdict.__iter__(), list), "__iter__ should not return a list"


# Generated at 2022-06-20 15:34:49.205724
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    """
    Unit test for method union of class ImmutableDict
    """

    original = ImmutableDict({'key_to_be_updated': 'original_value', 'common_key': 'common_value', 'key_to_be_removed': 'value_to_be_removed'})
    override = {'key_to_be_updated': 'overriding_value', 'key_to_be_added': 'new_value'}
    updated = original.union(override)
    assert updated['key_to_be_updated'] == 'overriding_value'
    assert updated['common_key'] == 'common_value'
    assert updated['key_to_be_added'] == 'new_value'
    assert 'key_to_be_removed' not in updated


# Generated at 2022-06-20 15:34:54.472956
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Unittest for constructor of class ImmutableDict"""
    test_dict = ImmutableDict({'a_key': 'a_value', 'b_key': 'b_value'})
    assert(test_dict['a_key'] == 'a_value')
    assert(test_dict['b_key'] == 'b_value')


# Generated at 2022-06-20 15:35:03.147632
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    x=ImmutableDict({'a':1, 'b':2})
    y=ImmutableDict({'a':1, 'b':2})
    z=ImmutableDict({'a':1})

    if x.__hash__() != y.__hash__():
        raise Exception('Hash function failed: x and y are equal but have different hashes')

    if x.__hash__() == z.__hash__():
        raise Exception('Hash function failed: x and z are different but have the same hashes')



# Generated at 2022-06-20 15:35:06.062158
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    test_dict = ImmutableDict({'a':1, 'b':2, 'c':3})
    assert len(test_dict) == 3


# Generated at 2022-06-20 15:35:09.396841
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict(a=1, b=2)
    assert d['a'] == 1
    assert d['b'] == 2


# Generated at 2022-06-20 15:35:17.089821
# Unit test for function is_string
def test_is_string():
    test_string = 'test_string'
    test_list = ['test', 'list']
    test_bytes = b'abcd'

    assert is_string(test_string)
    assert not is_string(test_list)
    assert is_string(test_bytes)

    assert is_string(test_string, include_strings=True)
    assert is_string(test_list, include_strings=True)
    assert is_string(test_bytes, include_strings=True)


# Generated at 2022-06-20 15:35:28.798395
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    dictionary = ImmutableDict()
    assert dict(dictionary) == {}, 'Initialized ImmutableDict should contain empty dict as stored data'
    assert len(dictionary) == 0, 'Empty ImmutableDict object should have zero length'
    dictionary = ImmutableDict({'a': 'b', 'c': 'd'})
    assert dict(dictionary) == {'a': 'b', 'c': 'd'}, 'Initialized ImmutableDict should contain the same data as provided dict'
    assert len(dictionary) == 2, 'Initialized ImmutableDict should have length of 2'

    try:
        dictionary['a'] = 'b'
    except:
        exception_raised = True
    assert exception_raised, "Exception should have been raised when trying to reassign to the ImmutableDict"


# Generated at 2022-06-20 15:35:35.823154
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(None) == False
    assert is_iterable(False) == False
    assert is_iterable(True) == False
    assert is_iterable(0) == False
    assert is_iterable(1) == False
    assert is_iterable(3.14) == False
    assert is_iterable('a') == False
    assert is_iterable({'a': 'b'}) == True
    assert is_iterable([]) == True
    assert is_iterable(xrange(0, 1)) == True
    assert is_iterable(set()) == True


# Generated at 2022-06-20 15:35:40.602157
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    subtracted = [ 'b', 'd', 'z' ]
    assert original.difference(subtracted) == {'a': 1, 'c': 3}


# Generated at 2022-06-20 15:35:44.793630
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """
    test for method __len__ of class ImmutableDict
    """
    D = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert len(D) == 2

    D = ImmutableDict()
    assert len(D) == 0



# Generated at 2022-06-20 15:35:52.008120
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Test the ImmutableDict.__repr__() method."""
    test = ImmutableDict(a=1, b=2)
    assert repr(test) == 'ImmutableDict({\'a\': 1, \'b\': 2})'
    test = ImmutableDict()
    assert repr(test) == 'ImmutableDict({})'


# Generated at 2022-06-20 15:35:57.401885
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    '''Testing method __repr__ from class ImmutableDict'''
    test_dict = ImmutableDict()
    test_dict['test_key'] = "test_value"
    test_dict['test_key2'] = "test_value2"
    assert repr(test_dict) == "ImmutableDict({'test_key2': 'test_value2', 'test_key': 'test_value'})"



# Generated at 2022-06-20 15:36:06.171179
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    class CustomEqualityChecker(object):
        def __init__(self, other):
            self.other = other

        def __eq__(self, other):
            return self.other == other

    idict = ImmutableDict({1: 1})
    assert hash(idict) == hash(ImmutableDict({1: 1}))
    assert hash(idict) != hash(ImmutableDict({1: 2}))
    assert hash(idict) != hash(ImmutableDict({2: 1}))
    assert hash(idict) != hash(ImmutableDict({1: 1, 2: 2}))

    assert hash(idict) == hash(CustomEqualityChecker(idict))
    assert hash(idict) == hash(CustomEqualityChecker(ImmutableDict({1: 1})))

# Generated at 2022-06-20 15:36:11.151667
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Unit test for method __hash__ of class ImmutableDict"""
    immutable_dict = ImmutableDict({'a': 1, 'b': 2})
    assert hash(immutable_dict) == hash(ImmutableDict({'a': 1, 'b': 2}))


# Generated at 2022-06-20 15:36:22.142146
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    from ansible.module_utils.six.moves import cStringIO

    import os

    import pytest

    class ImmutableDictTest(ImmutableDict):
        def __init__(self, data):
            super(ImmutableDictTest, self).__init__(data)
            self._hash = None

        def __hash__(self):
            if self._hash is None:
                self._hash = super(ImmutableDictTest, self).__hash__()
            return self._hash

    @pytest.fixture
    def tempfile_hash_data(tmpdir):
        with open(os.path.join(tmpdir, "hash_data.txt"), 'wb') as temp_file_hash_data:
            temp_file_hash_data.write("Hello, World!")
        return tmpdir


# Generated at 2022-06-20 15:36:24.605124
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    import pytest
    original = ImmutableDict({'foo': 'bar'})
    assert len(original) == 1
    assert original.__len__() == 1


# Generated at 2022-06-20 15:36:28.894692
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    from ansible.module_utils.common._collections_compat import ImmutableDict
    immutable_dict = ImmutableDict({"name": "John", "age": "32", "gender": "Male"})
    assert(repr(immutable_dict) == "ImmutableDict({'name': 'John', 'age': '32', 'gender': 'Male'}")

# Generated at 2022-06-20 15:36:31.496638
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():

    dic = ImmutableDict({'a': 'alpha', 'b': 'beta'})
    assert len(dic) == 2


# Generated at 2022-06-20 15:36:36.596902
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    """
    test_ImmutableDict___getitem__ method:
    This method is to test ImmutableDict.__getitem__()
    """
    idict = ImmutableDict({"a": 1, "b": 2})
    assert idict["a"] == 1
    assert idict["b"] == 2
    return 0


# Generated at 2022-06-20 15:36:39.329880
# Unit test for function is_string
def test_is_string():
    assert is_string('testing')
    assert is_string(u'testing')
    assert not is_string(('testing',))


# Generated at 2022-06-20 15:36:48.297714
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    assert ImmutableDict(dict(foo = 'bar')) == ImmutableDict(foo = 'bar')
    assert ImmutableDict(dict(foo = 'bar')) == ImmutableDict(dict(dict(foo = 'bar')))
    assert ImmutableDict(dict(foo = 'bar')) == ImmutableDict(dict([('foo', 'bar')]))
    assert ImmutableDict(dict(foo = 'bar')) == ImmutableDict(dict(('foo', 'bar')))


# Generated at 2022-06-20 15:36:59.209533
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Testing __eq__() method

    # Checking equality of empty ImmutableDicts
    assert ImmutableDict() == ImmutableDict()
    # Checking equality of ImmutableDicts with values
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    # Checking inequality of ImmutableDicts with different keys
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    # Checking inequality of ImmutableDicts with different values
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    # Checking equality of union()
    assert ImmutableDict({'a': 1}).union({'b': 3}) == ImmutableDict({'a': 1, 'b': 3})
    # Checking equality of difference()

# Generated at 2022-06-20 15:37:05.327742
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    def _test():
        d1 = ImmutableDict(dict({"a": 1, "b": 2}))
        d2 = ImmutableDict(dict({"a": 1, "b": 2}))
        d3 = ImmutableDict(dict({"a": 3, "b": 2}))
        d4 = ImmutableDict(dict({"a": 1, "b": 2, "c": 3}))
        l = [d1, d2, d3, d4]
        assert len(set(l)) == 3

    _test()


# Generated at 2022-06-20 15:37:12.507677
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence(())
    assert is_sequence({})
    assert is_sequence(set())
    assert not is_sequence('foo')
    assert is_sequence('foo', include_strings=True)
    assert not is_sequence(u'foo')
    assert is_sequence(u'foo', include_strings=True)
    assert not is_sequence(b'foo')
    assert is_sequence(b'foo', include_strings=True)
    assert not is_sequence(1)
    assert not is_sequence(object())
    assert not is_sequence(Exception())



# Generated at 2022-06-20 15:37:23.151076
# Unit test for function count
def test_count():
    assert count([1, 2, 1, 2, 1, 2, 1, 2, 1, 1]) == {1: 6, 2: 4}
    assert count([1, 2, 3, 1, 2, 3, 1, 2, 3]) == {1: 3, 2: 3, 3: 3}
    assert count(['a', 'b', 'c', 'a', 'b', 'c']) == {'a': 2, 'b': 2, 'c': 2}
    assert count([]) == {}

    # Test that it raises if the input is not an iterable
    try:
        count(1)
    except Exception as e:
        assert True
    else:
        assert False


# Generated at 2022-06-20 15:37:25.657269
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict({1: 2})
    assert len(d) == 1
    assert len({1: 2}) == 1


# Generated at 2022-06-20 15:37:36.519958
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    # Input is an ImmutableDict and overriding_mapping is none
    i1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    i2 = i1.union(None)
    assert i1 is i2

    # Input is an ImmutableDict and overriding_mapping is an ImmutableDict
    i1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    i2 = ImmutableDict({'a': 100, 'b': 200, 'd': 300})
    i3 = i1.union(i2)
    assert i3 == ImmutableDict({'a': 100, 'b': 200, 'c': 3, 'd': 300})

    # Input is an ImmutableDict and overriding_mapping is a Dict
    i1

# Generated at 2022-06-20 15:37:41.600439
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3, 4, 5])
    assert not is_sequence((1, 2, 3, 4, 5))

    assert not is_sequence("Is this a sequence?")
    assert not is_sequence(b"Is this a sequence?")
    assert not is_sequence(123)


# Generated at 2022-06-20 15:37:50.678731
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([], True)
    assert is_sequence([], False)
    assert is_sequence((), True)
    assert is_sequence((), False)
    assert is_sequence(set(), True)
    assert is_sequence(set(), False)
    assert is_sequence(dict(), True)
    assert not is_sequence(dict(), False)
    assert is_sequence(range(10), True)
    assert is_sequence(range(10), False)
    assert is_sequence('abc', True)
    assert not is_sequence('abc', False)
    assert is_sequence(u'abc', True)
    assert not is_sequence(u'abc', False)

# Generated at 2022-06-20 15:37:53.228283
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert ImmutableDict({'a': 1, 'b': 2}).__repr__() == 'ImmutableDict({\'a\': 1, \'b\': 2})'



# Generated at 2022-06-20 15:38:08.978485
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence('abc')
    assert not is_sequence('abc', include_strings=True)
    assert is_sequence('abc', include_strings=True)
    assert is_sequence(set())
    assert is_sequence(ImmutableDict())
    assert is_sequence(('a', 'b', 'c'))
    assert is_sequence(('a', 'b', 'c'), include_strings=True)
    assert is_sequence(('a', 'b', 'c', set('abc')))
    assert is_sequence(('a', 'b', 'c', set('abc')), include_strings=True)
    assert not is_sequence(('a', 'b', 'c', set('abc')), include_strings=False)
    assert is_sequence(['a', 'b', 'c'])

# Generated at 2022-06-20 15:38:20.166940
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    d = ImmutableDict()

    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})

    d = ImmutableDict(a=1, b=2, c=3)

    d = ImmutableDict([('a', 1), ('b', 2), ('c', 3)])

    d = ImmutableDict([['a', 1], ['b', 2], ['c', 3]])

    d = ImmutableDict(dict(a=1, b=2, c=3))

    d = ImmutableDict(dict([('a', 1), ('b', 2), ('c', 3)]))

    d = ImmutableDict(dict((['a', 1], ['b', 2], ['c', 3])))

    d = ImmutableDict(dict([('a', 1)]))

   

# Generated at 2022-06-20 15:38:27.606313
# Unit test for function count
def test_count():
    import operator as op
    seq = ['a', 'b', 'c', 'd', 'a', 'a', 'b']
    counter = count(seq)
    assert op.eq(counter['a'], 3)
    assert op.eq(counter['b'], 2)
    assert op.eq(counter['c'], 1)
    assert op.eq(counter['d'], 1)
    assert op.eq(counter['e'], 0)
    assert op.eq(len(counter), 4)



# Generated at 2022-06-20 15:38:34.982768
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    from copy import copy
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping

    assert not isinstance(dict(), ImmutableDict)
    assert not issubclass(Mapping, ImmutableDict)

    imd = ImmutableDict()
    assert not imd
    assert str(imd) == 'ImmutableDict({})'
    assert repr(imd) == 'ImmutableDict({})'

    imd = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert len(imd) == 3
    assert 'a' in imd
    assert 'd' not in imd
    assert imd['b'] == 2
    assert imd.get('c') == 3

# Generated at 2022-06-20 15:38:44.344542
# Unit test for function is_string
def test_is_string():
    text_types = [
        u'Unicode',
        '',
        'Ansi',
        '\xe2\x80\x99'  # byte representation of the UTF-8 apostrophe '
    ]

    binary_types = [
        b'Binary',
        b'\xce\xb1',
        b'\xe2\x80\x99'
    ]

    for string_type in text_types + binary_types:
        assert is_string(string_type)

    for item in text_types:
        assert not is_string([item])

    mappings = [
        dict(a=1),
        dict({u'k': u'Unicode'}),
        ImmutableDict({u'k': u'Unicode'})
    ]


# Generated at 2022-06-20 15:38:49.791785
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'b': 10, 'c': 11})
    result = dict1.union(dict2)
    assert result == ImmutableDict({'a': 1, 'b': 10, 'c': 11})


# Generated at 2022-06-20 15:38:59.796590
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Ensure ImmutableDict comparison is behaving as expected"""
    # Create ImmutableDict using default constructor
    dict_instance_1 = ImmutableDict()
    dict_instance_2 = ImmutableDict()
    dict_instance_3 = dict_instance_1

    # Create ImmutableDict using positional arguments
    dict_instance_4 = ImmutableDict((('one', 1), ('two', 2), ('three', 3)))
    dict_instance_5 = ImmutableDict((('one', 1), ('two', 2), ('three', 3)))

    # Create ImmutableDict using keyword arguments
    dict_instance_6 = ImmutableDict(one=1, two=2, three=3)

    # Create ImmutableDict with same elements as dict_instance_4, but different order
    dict_instance_7 = ImmutableD

# Generated at 2022-06-20 15:39:01.607762
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict({'a': 'A'})) == 1


# Generated at 2022-06-20 15:39:07.579580
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence(())
    assert is_sequence({})
    assert not is_sequence(set())
    assert is_sequence('foo', include_strings=True)
    assert is_sequence(u'foo', include_strings=True)
    assert not is_sequence('foo')
    assert not is_sequence(u'foo')
    assert is_sequence(None)  # None is iterable at least

# Generated at 2022-06-20 15:39:15.664822
# Unit test for function is_iterable
def test_is_iterable():
    test_list = ['a', 'b']
    assert is_iterable(test_list)
    assert is_iterable(test_list, include_strings=True)
    test_string = 'some_string'
    assert is_iterable(test_string, include_strings=True)
    assert not is_iterable(test_string)
    test_dict = {'a': 1, 'b': 2}
    assert is_iterable(test_dict)
    class TestClass(object):
        def __init__(self):
            self.test_var = 1
    assert is_iterable(TestClass)


# Generated at 2022-06-20 15:39:34.051769
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    """Test case for method __getitem__ of class ImmutableDict."""
    class_name = 'ImmutableDict'
    method_name = '__getitem__'
    test_dict = ImmutableDict({'key_1': 'value_1', 'key_2': 'value_2'})
    assert test_dict['key_1'] == 'value_1', \
        '{0} {1} method is not working properly'.format(class_name, method_name)



# Generated at 2022-06-20 15:39:37.578954
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    test_dict = {'apple': 'red', 'lemon': 'yellow'}
    test_object = ImmutableDict(test_dict)
    assert set(test_object.keys()) == set(test_dict.keys())



# Generated at 2022-06-20 15:39:40.489755
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    a = ImmutableDict([('a', 1), ('b', 2), ('d', 4)])
    assert set(a) == {'a', 'b', 'd'}


# Generated at 2022-06-20 15:39:49.128026
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    from ansible.module_utils.six import PY2

    test_input = {'1': '1', '2': '2', '3': '3'}

    # subtraction by a list
    result = ImmutableDict(test_input).difference(['1', '2'])
    assert result == ImmutableDict({'3': '3'})

    # subtraction by another ImmutableDict
    result = ImmutableDict(test_input).difference(ImmutableDict({'1': '1'}))
    assert result == ImmutableDict({'2': '2', '3': '3'})

    # subtraction by a set
    result = ImmutableDict(test_input).difference(set(['1']))

# Generated at 2022-06-20 15:40:00.815967
# Unit test for function is_sequence
def test_is_sequence():
    def assert_eq(primitive, expected, include_strings=False):
        """Helper to check the outcome of is_sequence"""
        result = is_sequence(primitive, include_strings=include_strings)
        msg = "type:{} include_strings:{}".format(type(primitive), include_strings)
        assert result == expected, msg

    # Test strings
    assert_eq(b'', string=True)
    assert_eq('', string=True)
    assert_eq(b'abc', string=True)
    assert_eq(u'abc', string=True)

    # Test strings and bytes as sequences
    assert_eq(b'', True, string=True)
    assert_eq('', True, string=True)
    assert_eq(b'abc', True, string=True)

# Generated at 2022-06-20 15:40:05.619897
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():

    d = ImmutableDict({'a': 1, 'b': 2})

    assert d.union({'c': 3}) == ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d.union({'b': 4}) == ImmutableDict({'a': 1, 'b': 4})
    assert d == ImmutableDict({'a': 1, 'b': 2})



# Generated at 2022-06-20 15:40:09.637185
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    """Perform unit test for method __iter__ of class ImmutableDict."""
    test_immutable_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert list(test_immutable_dict) == ['a', 'b', 'c']



# Generated at 2022-06-20 15:40:11.561137
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    im_dict = ImmutableDict({'key': 'value'})
    assert im_dict['key'] == 'value'



# Generated at 2022-06-20 15:40:17.269011
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # Single hash for two immutable dictionaries with the same items
    hash_1 = hash(ImmutableDict({'a': 1, 2: 'b'}))
    hash_2 = hash(ImmutableDict({'a': 1, 2: 'b'}))
    assert hash_1 == hash_2, 'Hash of two identical immutable dictionaries has to be equal'

    # Multiple hashes for two immutable dictionaries with different items
    hash_1 = hash(ImmutableDict({'a': 1, 2: 'b'}))
    hash_2 = hash(ImmutableDict({2: 'b', 'a': 1}))
    assert hash_1 != hash_2, 'Hash of two different immutable dictionaries has to be different'


# Generated at 2022-06-20 15:40:27.691542
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    air_config1 = dict()
    air_config1['country'] = 'us'
    air_config1['region'] = 'na'
    air_config1['locale'] = 'en_US'
    air_config1['timezone'] = 'us'
    air_config1['profile'] = 'redhat_register'

    air_config2 = dict()
    air_config2['country'] = 'us'
    air_config2['region'] = 'na'
    air_config2['locale'] = 'en_US'
    air_config2['timezone'] = 'us'
    air_config2['profile'] = 'redhat_register'

    air_config3 = dict()
    air_config3['country'] = 'us'
    air_config3['region'] = 'na'
    air

# Generated at 2022-06-20 15:40:58.298301
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict([('a', 1), ('b', 2), ('c', 3)])
    expected_result = "ImmutableDict({'a': 1, 'b': 2, 'c': 3})"
    assert(repr(d) == expected_result)


# Generated at 2022-06-20 15:41:02.690030
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({1, 2, 3})
    assert is_iterable({'a': 'b'})
    assert is_iterable('a')
    assert not is_iterable(1)


# Generated at 2022-06-20 15:41:09.372714
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    dict_1 = ImmutableDict({"a": 1, "b": 2})
    dict_2 = ImmutableDict({"a": "one", "c": "three"})
    dict_3 = ImmutableDict(dict_1.union(dict_2))
    assert dict_3["a"] == "one"
    assert dict_3["b"] == 2
    assert dict_3["c"] == "three"
    assert len(dict_3) == 3


# Generated at 2022-06-20 15:41:11.787860
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    _ = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert list(_) == ['a', 'b', 'c']



# Generated at 2022-06-20 15:41:19.722514
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test case 1: normal usage
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1.__eq__(ImmutableDict({'a': 1, 'b': 2}))
    assert d1 == ImmutableDict({'a': 1, 'b': 2})
    assert d1.__eq__(ImmutableDict({'b': 2, 'a': 1}))
    assert not d1.__eq__(ImmutableDict({'b': 3, 'a': 1}))
    assert not d1.__eq__(ImmutableDict({'b': 2}))
    assert not d1.__eq__(ImmutableDict({'c': 3, 'd': 4}))

    # Test case 2: mixed usage

# Generated at 2022-06-20 15:41:26.925890
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """Test method difference of class ImmutableDict"""
    keys = ['a', 'b', 'c', 'd', 'e', 'f']
    values = range(len(keys))
    original_dict = ImmutableDict(zip(keys, values))

    subtractive_iterable = ['b', 'e', 'h']
    expected_dict = ImmutableDict(sorted((k, v) for k, v in zip(keys, values)
                                         if k not in subtractive_iterable))
    assert original_dict.difference(subtractive_iterable) == expected_dict



# Generated at 2022-06-20 15:41:38.108949
# Unit test for function is_sequence
def test_is_sequence():
    """Test for is_sequence()."""
    assert is_sequence([1, 2, 3]) is True
    assert is_sequence((1, 2, 3)) is True
    assert is_sequence((1,)) is True
    assert is_sequence((1,), include_strings=True) is True
    assert is_sequence('one', include_strings=True) is True
    assert is_sequence('', include_strings=True) is True
    assert is_sequence(u'one', include_strings=True) is True
    assert is_sequence(u'', include_strings=True) is True
    assert is_sequence(set([1, 2, 3])) is False
    assert is_sequence({1: 'one', 2: 'two', 3: 'three'}) is False
    assert is_sequence('123') is False
    assert is_

# Generated at 2022-06-20 15:41:45.744882
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(10))
    assert is_iterable(dict(a=1, b=2, c=3))
    assert is_iterable('abc')
    assert is_iterable(b'abc')
    assert is_iterable(u'abc')
    assert not is_iterable(1)



# Generated at 2022-06-20 15:41:48.643324
# Unit test for function is_string
def test_is_string():
    assert is_string('abcdef')
    assert not is_string([1, 2, 3, 4, 5, 6])



# Generated at 2022-06-20 15:41:56.329383
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # comparing 2 identical objects
    obj1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    obj2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert obj1 == obj2, 'Objects obj1 and obj2 should be equal'
    # comparing object with itself
    obj1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    obj2 = obj1
    assert obj1 == obj2, 'Objects obj1 and obj2 should be equal'
    # comparing object with different content
    obj1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    obj2 = ImmutableDict({'a': 1, 'b': 2, 'c': 1})

# Generated at 2022-06-20 15:43:03.961542
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    a = ImmutableDict({'a': 'a'})
    b = a.difference(['a'])
    assert len(b) == 0

    a = ImmutableDict({'a': 'a'})
    b = a.difference(['b'])
    assert len(b) == 1

    a = ImmutableDict({'a': 'a', 'b': 'a'})
    b = a.difference(['a'])
    assert len(b) == 1
    assert b['b'] == 'a'

    a = ImmutableDict({'a': 'a', 'b': 'a', 'c': 'a'})
    b = a.difference(['a', 'b'])
    assert len(b) == 1
    assert b['c'] == 'a'

    a = Imm

# Generated at 2022-06-20 15:43:07.713600
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    my_dict = ImmutableDict({'a':1,'b':2})
    assert repr(my_dict) == "ImmutableDict({'a': 1, 'b': 2})"


# Generated at 2022-06-20 15:43:14.374782
# Unit test for function count
def test_count():
    a = [1, 2, 3]
    assert count(a) == {1: 1, 2: 1, 3: 1}, "Exception in count"
    b = [1, 1, 1]
    assert count(b) == {1: 3}, "Exception in count"
    c = [1, 1, 2, 3, 3, 3]
    assert count(c) == {1: 2, 2: 1, 3: 3}, "Exception in count"



# Generated at 2022-06-20 15:43:19.617380
# Unit test for function is_string
def test_is_string():
    """Unit test for function `is_string`"""
    assert is_string(u'hello')
    assert is_string(b'hello')
    assert not is_string([u'hello'])
    assert not is_string((u'hello'))
    assert not is_string({'a': 'hello'})

# Generated at 2022-06-20 15:43:29.761229
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    from ansible.module_utils.common._collections_compat import Mapping

    empty_dict = ImmutableDict()
    assert empty_dict == {}
    assert empty_dict == ImmutableDict()
    assert empty_dict != set()

    nonempty_dict = ImmutableDict({'A': 1, 'B': 2})
    assert nonempty_dict == {'A': 1, 'B': 2}
    assert nonempty_dict == ImmutableDict({'A': 1, 'B': 2})
    assert nonempty_dict != {'A': 1}
    assert nonempty_dict != {'A': 1, 'B': 2, 'C': 3}
    assert nonempty_dict != ImmutableDict({'B': 2, 'A': 1})

# Generated at 2022-06-20 15:43:31.890897
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    a = ImmutableDict()
    assert len(a) == 0
    a = ImmutableDict({'foo': 'bar', 'bar': 'baz'})
    assert len(a) == 2


# Generated at 2022-06-20 15:43:36.637518
# Unit test for function count
def test_count():
    """Unit test for function count"""
    result_expected = {'a': 3, 'b': 2, 'c': 3}
    result_actual = count(['a', 'b', 'a', 'c', 'c', 'b', 'a', 'c'])
    assert result_expected == result_actual, 'Unexpected result'
