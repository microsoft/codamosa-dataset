

# Generated at 2022-06-20 15:33:43.208828
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    test_dict = ImmutableDict({'a': 'b'})
    assert repr(test_dict) == 'ImmutableDict({\'a\': \'b\'})'


# Generated at 2022-06-20 15:33:45.763877
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict({'a': 'b', 'c': 'd'})
    new = ImmutableDict({'e': 'f'})

    union = original.union(new)
    assert union == {'a': 'b', 'c': 'd', 'e': 'f'}



# Generated at 2022-06-20 15:33:48.859787
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    test_immutable_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_immutable_dict.__len__() == 3


# Generated at 2022-06-20 15:33:54.430615
# Unit test for function is_sequence
def test_is_sequence():
    """Unit test for function is_sequence"""
    assert is_sequence([1, 2, 3]) is True
    assert is_sequence((1, 2, 3)) is True
    assert is_sequence([]) is True
    assert is_sequence(set([1, 2, 3])) is False
    assert is_sequence({1, 2, 3}) is False
    assert is_sequence(dict([('a', 1), ('b', 2)])) is False
    assert is_sequence(100) is False
    assert is_sequence('a') is False


# Generated at 2022-06-20 15:34:01.631356
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence(frozenset())
    assert not is_sequence("")
    assert not is_sequence('abc')
    assert not is_sequence(object())
    assert is_sequence([], include_strings=True)
    assert is_sequence("", include_strings=True)
    assert is_sequence('abc', include_strings=True)
    assert is_sequence(u'abc', include_strings=True)
    assert not is_sequence(object(), include_strings=True)


# Generated at 2022-06-20 15:34:06.932964
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict(a=1, b=2)
    assert d['a'] == 1
    assert d['b'] == 2
    try:
        d['c']
        assert False
    except KeyError:
        assert True



# Generated at 2022-06-20 15:34:19.229963
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # Tests for different ways of initializing an ImmutableDict
    test_dict_1 = ImmutableDict(a=1, b='hello', c=[1, 2, 3], d=(1, 2, 3))
    test_dict_2 = ImmutableDict({'a': 1, 'b': 'hello', 'c': [1, 2, 3], 'd': (1, 2, 3)})
    test_dict_3 = ImmutableDict({'a': 1, 'b': 'hello', 'c': [1, 2, 3], 'd': (1, 2, 3)}.items())
    test_dict_4 = ImmutableDict()
    # Test for equal ImmutableDicts
    assert test_dict_1.__hash__() == test_dict_2.__hash__()

# Generated at 2022-06-20 15:34:29.730280
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    from ansible.module_utils.common._collections_compat import Mapping

# Generated at 2022-06-20 15:34:34.005691
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    a = ImmutableDict({"a": 1, "b": 2, "c": 3})
    b = a.difference(["a"])
    assert b == ImmutableDict({"b": 2, "c": 3})
    assert a == ImmutableDict({"a": 1, "b": 2, "c": 3})



# Generated at 2022-06-20 15:34:38.548742
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict({1:2, 3:4})
    assert repr(d) == 'ImmutableDict({1: 2, 3: 4})'
    assert repr(ImmutableDict()) == 'ImmutableDict({})'

# Generated at 2022-06-20 15:34:51.947811
# Unit test for function is_sequence
def test_is_sequence():
    # String-like objects except strings and bytes should be sequences
    seq = 'abc'
    assert is_sequence(seq, include_strings=True)

    seq = b'xyz'
    assert is_sequence(seq, include_strings=True)

    # Strings and bytes are not sequences
    seq = 'abc'
    assert not is_sequence(seq)

    seq = b'xyz'
    assert not is_sequence(seq)

    # Test for non-indexable things
    seq = True
    assert not is_sequence(seq)

    # Test for a list
    seq = ['a', 'b', 'c']
    assert is_sequence(seq)

    # Test for a tuple
    seq = ('x', 'y', 'z')
    assert is_sequence(seq)


# Generated at 2022-06-20 15:34:57.055374
# Unit test for function count
def test_count():
    arr = ['a', 'b', 'b', 'c', 'c', 'c', 'c']

    counters = count(arr)
    if counters != {'a': 1, 'b': 2, 'c': 4}:
        return False

    try:
        counters = count('abcd')
    except:
        pass
    else:
        return False

    return True

# Generated at 2022-06-20 15:35:08.397808
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    # compare identical dictionaries
    immutable_dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    immutable_dict2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert immutable_dict1 == immutable_dict2

    # compare different dictionaries
    immutable_dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    immutable_dict2 = ImmutableDict({'a': 2, 'b': 1, 'c': 4})
    assert not immutable_dict1 == immutable_dict2

    # compare dictionaries with different sortkeys
    immutable_dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-20 15:35:11.766729
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    immutable_dict = ImmutableDict({'name':'Joe', 'age':'25'})
    assert immutable_dict['name'] == 'Joe'


# Generated at 2022-06-20 15:35:13.455888
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    assert ImmutableDict(dict(one=1, two=2))['one'] == 1


# Generated at 2022-06-20 15:35:22.119367
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(object(), include_strings=True)
    assert is_iterable(tuple(),       include_strings=True)  # tuple
    assert is_iterable((),            include_strings=True)  # tuple
    assert is_iterable(RangeIterator(), include_strings=True)  # iterator
    assert is_iterable(set(),         include_strings=True)  # set
    assert is_iterable(frozenset(),   include_strings=True)  # frozenset
    assert is_iterable(set(),         include_strings=True)  # set
    assert is_iterable(dict(),        include_strings=True)  # dict
    assert is_iterable(MutableMapping(), include_strings=True)  # dict
    assert is_iterable({},            include_strings=True)

# Generated at 2022-06-20 15:35:24.053862
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    assert ImmutableDict({'a': 'b'})['a'] == 'b'



# Generated at 2022-06-20 15:35:29.040539
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    test_dict = ImmutableDict({'A': 'B', 'C': 'D'})
    test_keys = []
    for key in test_dict:
        test_keys.append(key)
    assert test_keys == ['A', 'C']



# Generated at 2022-06-20 15:35:32.745404
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    assert ImmutableDict({'a': 1, 'b': 2}) == \
           ImmutableDict({'a': 1, 'b': 2}).union({})
    assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}) == \
           ImmutableDict({'b': 2, 'a': 1}).union({'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}) == \
           ImmutableDict({'a': 1, 'b': 2}).union({'c': 3, 'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}) == \
           ImmutableDict({'a': 1, 'b': 2, 'd': 4}).union

# Generated at 2022-06-20 15:35:45.854566
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    # Test simple union of two ImmutableDicts
    a = ImmutableDict(test=1)
    b = ImmutableDict(test=2)
    c = a.union(b)
    assert a == ImmutableDict(test=1)
    assert b == ImmutableDict(test=2)
    assert c == ImmutableDict(test=2)

    # Test union of ImmutableDict and regular dict
    regular_dict = dict(test=2)
    d = a.union(regular_dict)
    assert d == ImmutableDict(test=2)

    # Test deep copy of ImmutableDict when it is passed as an immutable argument
    e = ImmutableDict(test=dict(a=1, b=2))
    f = ImmutableDict(foo=e)

# Generated at 2022-06-20 15:35:55.997982
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert is_sequence((1, 2, 3))
    assert is_sequence((i for i in range(3)))
    assert not is_sequence({1: 'one', 2: 'two'})
    assert not is_sequence({'one': 1, 'two': 2})
    assert is_sequence({1, 2, 3})
    assert not is_sequence(None)
    assert is_sequence('foo')
    assert is_sequence(b'bar')
    assert not is_sequence('foo', include_strings=False)
    assert not is_sequence(b'bar', include_strings=False)

# Generated at 2022-06-20 15:36:01.244873
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    try:
        dict()
    except NameError:
        dict = dict   # Python 2.6 and above
    test_dict = dict()
    test_dict["a"] = "A"
    test_dict["b"] = "B"
    test_dict["c"] = "C"
    result = ImmutableDict(test_dict)
    assert len(dict) == len(result)


# Generated at 2022-06-20 15:36:07.996962
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Check that equality is correctly implemented
    # Test case 1: comparing with a dictionary with the same key value pairs
    d1 = ImmutableDict({'k1': 'v1', 'k2': 'v2'})
    d2 = ImmutableDict({'k2': 'v2', 'k1': 'v1'})
    assert d1 == d2
    # Test case 2: comparing with a dictionary with different key-value pairs
    d2 = ImmutableDict({'k2': 'v2', 'k1': 'v3'})
    assert not d1 == d2
    # Test case 3: comparing with a non-dictionary object
    d2 = 'test string'
    assert not d1 == d2
    # Test case 4: comparing with an empty dictionary
    d2 = {}
    assert not d1 == d

# Generated at 2022-06-20 15:36:12.660599
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_dict = ImmutableDict({'a':1, 'b':2, 'c':3})
    modified_dict = test_dict.difference(['a'])
    assert modified_dict == ImmutableDict({'b': 2, 'c': 3})
    modified_dict = test_dict.difference(['a', 'b'])
    assert modified_dict == ImmutableDict({'c': 3})
    modified_dict = test_dict.difference(['b', 'c'])
    assert modified_dict == ImmutableDict({'a': 1})


# Generated at 2022-06-20 15:36:23.779201
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """Unit test for difference() method of class ImmutableDict"""
    test_dict_immutable = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    subtractive_iterable = ['b', 'd']
    assert test_dict_immutable.difference(subtractive_iterable) == ImmutableDict({'a': 1, 'c': 3})
    subtractive_iterable = set(['b', 'd'])
    assert test_dict_immutable.difference(subtractive_iterable) == ImmutableDict({'a': 1, 'c': 3})
    subtractive_iterable = (['b', 'd'], {'a': 1})

# Generated at 2022-06-20 15:36:35.993677
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    imd1 = ImmutableDict({'a': 1, 'b': 2})
    imd2 = imd1.union({'c': 3})

    assert len(imd2) == 3
    assert imd2['a'] == 1
    assert imd2['b'] == 2
    assert imd2['c'] == 3

    imd3 = imd2.union({'b': 42})

    assert len(imd3) == 3
    assert imd3['a'] == 1
    assert imd3['b'] == 42
    assert imd3['c'] == 3

    imd3 = imd2.union({'x': None})

    assert len(imd3) == 4
    assert imd3['a'] == 1
    assert imd3['b'] == 2

# Generated at 2022-06-20 15:36:42.141748
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    test_dict = ImmutableDict({'a': 1, 'b': 2})

    assert test_dict['a'] == 1
    assert test_dict['b'] == 2

    test_dict2 = ImmutableDict(test_dict)
    assert test_dict is not test_dict2
    assert test_dict == test_dict2

    test_dict3 = ImmutableDict(a=1, b=2)
    assert test_dict == test_dict3



# Generated at 2022-06-20 15:36:50.578845
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence(('bar', 'baz'))
    assert is_sequence([1, 2])
    assert is_sequence([])
    assert is_sequence(set())
    assert is_sequence(tuple())
    assert is_sequence(dict().items())
    assert is_sequence(dict())
    assert is_sequence(None) is False
    assert is_sequence(False) is False

    assert is_sequence(('bar', 'baz'), include_strings=True)
    assert is_sequence([1, 2], include_strings=True)
    assert is_sequence([], include_strings=True)
    assert is_sequence(set(), include_strings=True)
    assert is_sequence(tuple(), include_strings=True)
    assert is_sequence(dict().items(), include_strings=True)
    assert is_sequence

# Generated at 2022-06-20 15:36:59.867898
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    """Unit test for ImmutableDict.union() method."""
    a = ImmutableDict(a='A', b='B', c='C')
    b = ImmutableDict(d='D', e='E', f='F')

    combined = a.union(b)
    assert isinstance(combined, ImmutableDict)
    assert combined == dict(a='A', b='B', c='C', d='D', e='E', f='F')

    # a is still the same
    assert a == dict(a='A', b='B', c='C')

    # b is still the same
    assert b == dict(d='D', e='E', f='F')



# Generated at 2022-06-20 15:37:04.529942
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    mydict = ImmutableDict({'a': 1, 'b': 2})
    assert repr(mydict) == "ImmutableDict({'a': 1, 'b': 2})"
    mydict = ImmutableDict({})
    assert repr(mydict) == "ImmutableDict({})"
    mydict = ImmutableDict()
    assert repr(mydict) == "ImmutableDict({})"

# Generated at 2022-06-20 15:37:10.414012
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    key = 'key'
    value = 'value'
    adict = ImmutableDict({key: value})

    assert adict[key] == value


# Generated at 2022-06-20 15:37:13.965423
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    values = ImmutableDict(a=1, b=2)

    it = iter(values)
    assert it is iter(it)

    assert next(it) == "a"
    assert next(it) == "b"

    assert list(it) == []
    assert list(iter(values)) == ["a", "b"]


# Generated at 2022-06-20 15:37:19.406867
# Unit test for function is_string
def test_is_string():
    """Ensures that function is_string works as expected."""
    assert is_string("text")
    assert is_string(u"unicode text")
    assert is_string(b"bytes")
    assert not is_string([1, 2, 3])
    assert not is_string({'a': 1})
    assert not is_string(None)



# Generated at 2022-06-20 15:37:22.599413
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():

    immutable_dict = ImmutableDict({'a': 1})
    try:
        immutable_dict['b']
    except KeyError:
        pass
    else:
        raise Exception("KeyError expected")
    v = immutable_dict['a'] # no exception expected
    if v != 1:
        raise Exception("Expected v==1, got {0}".format(v))



# Generated at 2022-06-20 15:37:31.376610
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    # Test with an empty dictionary
    x = ImmutableDict()
    try:
        for i in x:
            raise Exception("iteration over empty ImmutableDict")
    except TypeError:
        pass

    # Test with a non-empty dictionary
    x = ImmutableDict([("a", 1), ("b", 2)])
    try:
        for i in x:
            pass
    except TypeError:
        raise Exception("iteration over non-empty ImmutableDict")



# Generated at 2022-06-20 15:37:37.074875
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict({})) == 0
    assert len(ImmutableDict((('a', 1), ('b', 2)))) == 2
    assert len(ImmutableDict({'a': 1, 'b': 2})) == 2
    assert len(ImmutableDict(a=1, b=2)) == 2
    assert len(ImmutableDict([[('a', 1), ('b', 2)], [('c', 3), ('d', 4)]])) == 4


# Generated at 2022-06-20 15:37:42.525240
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d_initial = ImmutableDict({"key3":"value3","key2":"value2","key1":"value1"})
    d_subtractive = ("key1","key3")
    d_expected = ImmutableDict({"key2":"value2"})

    d_returned = d_initial.difference(d_subtractive)

    assert d_returned == d_expected


# Generated at 2022-06-20 15:37:50.072606
# Unit test for function is_string
def test_is_string():
    assert is_string('str') is True
    assert is_string(u'unicode') is True
    assert is_string(b'bytes') is True

    assert is_string(['list']) is False
    assert is_string(('tuple',)) is False

    assert is_string({'d': 'dict'}) is False
    assert is_string({'d': 'dict'}.values()) is False
    assert is_string({'d': 'dict'}.items()) is False



# Generated at 2022-06-20 15:37:55.765755
# Unit test for function is_sequence
def test_is_sequence():
    sequence = (1, 2, 3)
    assert is_sequence(sequence)
    assert not is_string(sequence)

    assert not is_sequence('foo')
    assert is_sequence(u'foo')

    class DummyClass:
        # pylint: disable=unused-variable
        def __len__(self):
            return 0

        def __getitem__(self, item):
            raise TypeError
    assert not is_sequence(DummyClass())



# Generated at 2022-06-20 15:38:00.742921
# Unit test for function is_string
def test_is_string():
    assert is_string('1')
    assert is_string('a')
    assert is_string(u'1')
    assert is_string(u'a')
    assert is_string(b'1')
    assert is_string(b'a')

    assert not is_string(1)
    assert not is_string(u'\u2014')
    assert not is_string([])
    assert not is_string({})
    assert not is_string(None)



# Generated at 2022-06-20 15:38:17.731384
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    assert ImmutableDict({'a': 1}).difference(['a']) == ImmutableDict({'a': 1}).difference(set(['a']))
    assert ImmutableDict({'a': 1}).difference([]) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}).difference(['a']) == ImmutableDict({'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}).difference(['a', 'c']) == ImmutableDict({'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}).difference(['a', 'b']) == ImmutableDict({})

# Generated at 2022-06-20 15:38:25.200600
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence(())
    assert is_sequence([1, 2, 3])
    assert is_sequence('abcde')
    assert is_sequence(u'abcde')
    assert is_sequence(bytearray('abcde'))
    assert not is_sequence(object())
    assert not is_sequence(object)
    assert not is_sequence({})
    assert not is_sequence(dict(a=1))
    assert not is_sequence(set())
    assert not is_sequence(set([1, 2, 3]))
    assert not is_sequence(range(10))
    assert not is_sequence(3)
    assert not is_sequence(True)
    assert not is_sequence(None)
    # Strings are not sequences unless include_strings is True
    assert not is_sequence

# Generated at 2022-06-20 15:38:27.272634
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict({1:2})) == 1
    assert len(ImmutableDict({1:2, 3:4, 5:6})) == 3


# Generated at 2022-06-20 15:38:28.001624
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict({'a': 1})) == 1



# Generated at 2022-06-20 15:38:33.686694
# Unit test for function count
def test_count():
    assert count(['a', 'b', 'a', 'c']) == {'a' : 2, 'b' : 1, 'c' : 1}
    assert count([]) == {}
    assert count('') == {}
    try:
        count(1)
    except Exception:
        pass
    else:
        raise Exception('count() did not raise an exception')


# Generated at 2022-06-20 15:38:37.213250
# Unit test for function is_iterable
def test_is_iterable():

    def foo():
        """Creating a dummy function"""
        return

    assert not is_iterable('foo')
    assert is_iterable(['foo'])
    assert is_iterable(('foo',))
    assert is_iterable({'foo': 'bar'})
    assert is_iterable(foo)



# Generated at 2022-06-20 15:38:40.768145
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    D = ImmutableDict()
    assert list(D.__iter__()) == []

    D = ImmutableDict({'a': 1})
    assert list(D.__iter__()) == ['a']



# Generated at 2022-06-20 15:38:44.345130
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict({'a': 1})) == 1

    d = ImmutableDict({})
    assert len(d) == 0

    d = ImmutableDict(test_ImmutableDict___len__.__dict__)
    assert len(d) == 6



# Generated at 2022-06-20 15:38:55.333296
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    """Test union method of ImmutableDict class"""
    d1 = ImmutableDict(dict(one=1, two=2, three=3))
    d2 = ImmutableDict(dict(one=1, four=4, five=5))
    d3 = ImmutableDict(dict(one=1, five=5, six=6))

    d1_union_d2 = d1.union(d2)
    d1_union_d3 = d1.union(d3)

    assert d1_union_d2.get('two') == 2
    assert d1_union_d2.get('four') == 4
    assert d1_union_d2.get('six') is None
    assert d1_union_d3.get('six') == 6

# Generated at 2022-06-20 15:38:58.759081
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1['a'] == 1
    assert d1['b'] == 2
    assert d1['c'] == 3

    d2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3}, d=4)
    assert d2['a'] == 1
    assert d2['b'] == 2
    assert d2['c'] == 3
    assert d2['d'] == 4


# Generated at 2022-06-20 15:39:13.581181
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    m = ImmutableDict(a='b', c='d', e='f')
    keys = []
    for k in m:
        keys.append(k)
    assert keys == ['a', 'c', 'e']



# Generated at 2022-06-20 15:39:16.889628
# Unit test for function count
def test_count():
    list1 = ['a', 'b', 'b', 'c']
    dict1 = count(list1)
    assert(dict1 == {'a':1, 'b':2, 'c':1})



# Generated at 2022-06-20 15:39:20.926553
# Unit test for function count
def test_count():
    assert count(['a', 'b', 'c', 'd', 'a', 'b']) == {'a': 2, 'b': 2, 'c': 1, 'd': 1}
    assert count(('a', 'b', 'c', 'd', 'a', 'b')) == {'a': 2, 'b': 2, 'c': 1, 'd': 1}
    assert count('abcdab') == {'a': 2, 'b': 2, 'c': 1, 'd': 1}
    assert count(set(['a', 'b', 'c', 'd', 'a', 'b'])) == {'a': 1, 'b': 1, 'c': 1, 'd': 1}



# Generated at 2022-06-20 15:39:28.302871
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict({'a': 1, 'b': 2, 'c': 3})) == 3
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict({'a': 1, 'b': 2, 'c': 3}).union({'d': 4})) == 4
    assert len(ImmutableDict({'a': 1, 'b': 2, 'c': 3}).difference(['a', 'b', 'd'])) == 1


# Generated at 2022-06-20 15:39:35.576600
# Unit test for function is_iterable
def test_is_iterable():
    class TestObject(object):
        def __iter__(self):
            return self
        def next(self):
            raise StopIteration

    assert is_iterable([]) is True
    assert is_iterable((x for x in range(0))) is True

    assert is_iterable(42) is False
    assert is_iterable('ansible') is False
    assert is_iterable(TestObject()) is False

    assert is_iterable('ansible', include_strings=True) is True


# Generated at 2022-06-20 15:39:39.432107
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict({'a':1, 'b':2, 'c':3, 'd':4})
    assert d['a'] == 1
    assert d['b'] == 2
    assert d['c'] == 3
    assert d['d'] == 4


# Generated at 2022-06-20 15:39:47.634943
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    from random import random, randrange, sample
    length = randrange(1, 100)
    key_range = range(1, 10000)
    keys = sample(key_range, length)
    value_range = range(-10000, 10000)
    values = sample(value_range, length)
    original_dict = {k: v for k, v in zip(keys, values)}
    immut_dict = ImmutableDict(original_dict)
    assert repr(immut_dict) == 'ImmutableDict({0})'.format(repr(original_dict))
    assert isinstance(immut_dict, ImmutableDict)
    assert not isinstance(immut_dict, MutableMapping)


# Generated at 2022-06-20 15:39:52.763326
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(u'abc')
    assert is_iterable('abc')
    assert is_iterable(1) is False


# Generated at 2022-06-20 15:39:55.711511
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    obj = ImmutableDict({'a': 1, 'b': 2, 'c': 3})

    assert obj['c'] == 3
    assert obj['a'] == 1

    try:
        obj['d']
        assert False
    except KeyError:
        assert True



# Generated at 2022-06-20 15:40:05.852707
# Unit test for function is_iterable
def test_is_iterable():
    # * Empty sequences
    # * Sequences of strings
    # * Sequences of iterables
    # * Sequences of dictionaries
    # * Sequences of both
    seq1 = []
    assert(is_iterable(seq1) == True)
    seq2 = ['abc', 'def']
    assert(is_iterable(seq2) == True)
    seq3 = [[1,2,3],[4,5]]
    assert(is_iterable(seq3) == True)
    seq4 = [{'a': 1,'b' : 2}, {'c': 3,'d' :4}]
    assert(is_iterable(seq4) == True)

# Generated at 2022-06-20 15:40:36.874287
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence(['a', 'b', 'c'])
    assert is_sequence((1, 2, 3))
    assert is_sequence(xrange(6))
    assert not is_sequence('abc')
    assert is_sequence('abc', include_strings=True)
    class MySequence(object):
        def __getitem__(self, key):
            raise NotImplemented
    assert is_sequence(MySequence())



# Generated at 2022-06-20 15:40:48.416972
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Method __repr__ should return the correct representation of the ImmutableDict"""

    # Empty dictionary
    immutable_dict = ImmutableDict()
    assert immutable_dict.__repr__() == "ImmutableDict({0})"

    # Dictionary with no string items
    immutable_dict = ImmutableDict({1: 1, 2: 2})
    assert immutable_dict.__repr__() == "ImmutableDict({1: 1, 2: 2})"

    # Dictionary with items with single quote
    immutable_dict = ImmutableDict({'a': 'b', 'c': "d"})
    assert immutable_dict.__repr__() == "ImmutableDict({'a': 'b', 'c': 'd'})"

    # Dictionary with items with double quote

# Generated at 2022-06-20 15:40:51.175759
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict({'A':1, 'B':2, 'C':3})
    d = original.difference(['A', 'C'])
    assert(d == ImmutableDict({'B':2}))



# Generated at 2022-06-20 15:40:56.579712
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    from ansible.module_utils.common._collections_compat import Sequence

    expected_len = 4

    given_dict = ImmutableDict({"a": 1, "b": 2})
    assert (len(given_dict) == expected_len)

    given_dict = ImmutableDict([("a", 1), ("b", 2), ("c", 3)])
    assert (len(given_dict) == expected_len)

    given_dict = ImmutableDict(a=1, b=2, c=3, d=4)
    assert (len(given_dict) == expected_len)



# Generated at 2022-06-20 15:41:00.519492
# Unit test for function count
def test_count():
    assert count(['a', 'a', 'b', 'c', 'c', 'c']) == {'a': 2, 'b': 1, 'c': 3}
    assert count([]) == {}
    assert count(123) == {123: 1}
    assert count(set()) == {}
    assert count(['a', 'a', 'a']) == {'a': 3}
    assert count([1, 1, 1, 1]) == {1: 4}
    assert count('aac') == {'a': 2, 'c': 1}



# Generated at 2022-06-20 15:41:11.016954
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict()
    assert repr(d) == "ImmutableDict({})", "Empty ImmutableDict not printed properly"

    d = ImmutableDict(a=1)
    assert repr(d) == "ImmutableDict({'a': 1})", "One item ImmutableDict not printed properly"

    d = ImmutableDict(a=1, b=2)
    assert repr(d) == "ImmutableDict({'a': 1, 'b': 2})", "Two items ImmutableDict not printed properly"

    d = ImmutableDict(a=1, b=2, c=3)
    assert repr(d) == "ImmutableDict({'a': 1, 'b': 2, 'c': 3})", "Three items ImmutableDict not printed properly"



# Generated at 2022-06-20 15:41:12.813722
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    id1 = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})
    assert len(id1) == 3


# Generated at 2022-06-20 15:41:20.598179
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    assert ImmutableDict({"1": "one", "2": "two"}).union({"3": "three"}) == ImmutableDict({"1": "one", "2": "two", "3": "three"})
    # Test that "union" is commutative
    assert ImmutableDict({"1": "one", "2": "two"}).union({"3": "three"}) == ImmutableDict({"3": "three"}).union({"1": "one", "2": "two"})
    # Test that the original ImmutableDict is not modified in the union
    orig_imm_dict = ImmutableDict({"1": "one", "2": "two", "3": "three"})

# Generated at 2022-06-20 15:41:27.229050
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    """Unit test for __getitem__"""
    a_string = ImmutableDict({'key': 'value'})
    assert a_string['key'] == 'value'
    assert 'key' in a_string
    assert a_string.get('key') == 'value'
    assert a_string.get('other_key', 'default_value') == 'default_value'
    assert a_string.get('other_key') is None
    assert a_string.keys() == list(a_string.keys())


# Generated at 2022-06-20 15:41:38.408164
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    dict_ = dict(a=1, c=2, b=3)
    imm_dict = ImmutableDict(dict_)
    assert imm_dict.union(dict(a=4)) == dict(a=4, c=2, b=3)
    assert imm_dict.union(a=4) == dict(a=4, c=2, b=3)
    assert imm_dict.difference(['a']) == dict(c=2, b=3)
    assert imm_dict.difference(('a',)) == dict(c=2, b=3)
    assert dict_ == dict(a=1, c=2, b=3)
    assert imm_dict == dict(a=1, c=2, b=3)

# Generated at 2022-06-20 15:42:34.271180
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """Unit test for method difference of ImmutableDict"""
    a = ImmutableDict(name='a', item='apple', item2='cat')
    b = a.difference(('item2', 'item3'))
    assert b == ImmutableDict(name='a', item='apple')



# Generated at 2022-06-20 15:42:38.836450
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    # Empty dict
    i_d = ImmutableDict()
    assert not len(i_d)
    assert len(i_d) == 0
    # Non-empty dict
    i_d = ImmutableDict((n, 2*n) for n in range(10))
    assert len(i_d)
    assert len(i_d) == 10


# Generated at 2022-06-20 15:42:45.276263
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a = ImmutableDict(one=1, two=2)
    b = a.union({'two': 'zwei', 'three': 3})
    c = a.union(ImmutableDict(two='zwei', three=3))

    assert a['one'] == 1
    assert b['two'] == 'zwei'
    assert c['three'] == 3

    try:
        a['two'] = 3
    except Exception:
        pass
    else:
        raise AssertionError('Failed to reject change to read-only ImmutableDict')

    try:
        b['two'] = 2
    except Exception:
        pass
    else:
        raise AssertionError('Failed to reject change to read-only ImmutableDict')


# Generated at 2022-06-20 15:42:55.434413
# Unit test for function is_sequence
def test_is_sequence():
    class TestIterable:
        def __iter__(self):
            pass

    # ! include_strings
    assert is_string('')
    assert not is_string(u'')
    assert not is_string(''.encode('utf-8'))
    assert not is_iterable('')
    assert not is_iterable(u'')
    assert not is_iterable(''.encode('utf-8'))
    assert not is_sequence('')
    assert not is_sequence(u'')
    assert not is_sequence(''.encode('utf-8'))
    assert is_iterable(TestIterable())
    assert not is_sequence(TestIterable())
    assert is_iterable([])
    assert is_sequence([])
    assert is_iterable(())
    assert is_sequence(())

# Generated at 2022-06-20 15:43:04.597996
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2])
    assert is_sequence({'a': 1, 'b': 2})
    assert is_sequence(1.34)
    assert is_sequence(['abc', 'def'])
    assert not is_sequence('abc')
    assert not is_sequence(True)
    assert is_sequence('abc', include_strings=True)
    # tuple and set are sequences, by definition, even though they are hashable
    assert is_sequence(('abc', 'def'))
    # FrozenSet is a hashable sequence, but it is not hashable, so it is not a sequence as far as this code is concerned
    assert not is_sequence(frozenset(['abc', 'def']))
    assert is_sequence((1, 2), include_strings=True)

# Generated at 2022-06-20 15:43:11.848120
# Unit test for function is_sequence
def test_is_sequence():
    test_list = [1, 2, 3]
    test_tuple = (1, 2, 3)
    test_dict = {"key1": 1, "key2": 2}
    test_string = 'test'
    assert is_sequence(test_list)
    assert is_sequence(test_tuple)
    assert not is_sequence(test_dict)
    assert not is_sequence(test_string)
    assert not is_sequence(None)



# Generated at 2022-06-20 15:43:15.335125
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """Unit test for method __len__ of class ImmutableDict"""
    idict = ImmutableDict()
    assert len(idict) == 0
    idict = ImmutableDict(a="a")
    assert len(idict) == 1


# Generated at 2022-06-20 15:43:26.214547
# Unit test for function is_sequence
def test_is_sequence():
    def assert_is_sequence(check_input):
        if not is_sequence(check_input):
            raise AssertionError('Expected {} to be a sequence'.format(check_input))

    def assert_not_is_sequence(check_input):
        if is_sequence(check_input):
            raise AssertionError('Expected {} not to be a sequence'.format(check_input))

    def assert_is_sequence_with_strings(check_input):
        if not is_sequence(check_input, include_strings=True):
            raise AssertionError('Expected {} to be a sequence'.format(check_input))


# Generated at 2022-06-20 15:43:29.378644
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    immutable_dict = ImmutableDict(a=1, b=2, c=3)
    assert immutable_dict.__class__.__name__ == 'ImmutableDict'


# Generated at 2022-06-20 15:43:32.991331
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d = ImmutableDict({"a":1,"b":2,"c":2,"d":2,"e":3,"f":4,"g":5})
    remove_keys = ImmutableDict({"a":1,"b":2,"c":2,"d":2})
    val = d.difference(remove_keys)
    assert val == {"e":3,"f":4,"g":5}