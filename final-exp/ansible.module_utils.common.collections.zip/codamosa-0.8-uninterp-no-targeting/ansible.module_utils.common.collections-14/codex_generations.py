

# Generated at 2022-06-20 15:33:44.571357
# Unit test for function is_string
def test_is_string():
    # Test the string-like types.
    assert is_string('a')
    assert is_string(u'a')
    assert is_string(b'a')

    # Test non string types.
    assert is_string(1) is False

    # Test string-like objects with custom attributes.
    class CustomStringObject(text_type):
        pass

    assert is_string(CustomStringObject('a'))

    # Test sequence types.
    assert is_string((1, 2, 3)) is False
    assert is_string([1, 2, 3]) is False
    assert is_string({'a': 1, 'b': 2}) is False



# Generated at 2022-06-20 15:33:53.456787
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    # test basic constructor
    result = ImmutableDict()
    assert result == {}

    # test iterable constructor
    result = ImmutableDict([('a', 'b'), ('c', 'd')])
    assert result == {'a': 'b', 'c': 'd'}

    # test mapping constructor
    result = ImmutableDict({'a': 'b'})
    assert result == {'a': 'b'}

    # test kwargs constructor
    result = ImmutableDict(a='b', c='d')
    assert result == {'a': 'b', 'c': 'd'}

    # test equality
    result = ImmutableDict(a='b', c='d')
    assert result == ImmutableDict(c='d', a='b')

# Generated at 2022-06-20 15:33:58.098170
# Unit test for function is_string
def test_is_string():
    class Foo:
        pass

    s = 'foobar'
    b = b'foobar'
    u = u'foobar'
    foo = Foo()

    assert is_string(s)
    assert is_string(b)
    assert is_string(u)

    # Foo() is not a string or a sequence
    assert not is_string(foo)

    # [] is not a string, even though it is a Sequence
    assert not is_string([1, 2, 3])
    assert not is_string(['a', 'b', 'c'])
    assert not is_string([])
    assert not is_string({'a': 'b'})
    assert not is_string(('a', 'b'))



# Generated at 2022-06-20 15:34:02.059779
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():

    adict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert len(adict) == 3

    adict = ImmutableDict(a=1, b=2, c=3)
    assert len(adict) == 3


# Generated at 2022-06-20 15:34:14.875209
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    # constructor
    id_1 = ImmutableDict({"a": 1, "b": 2})
    assert id_1 == ImmutableDict(a=1, b=2)

    # constructor from empty dictionary and from single key-value pair
    assert ImmutableDict() == ImmutableDict({})
    assert ImmutableDict(a=1) == ImmutableDict(**{"a":1})

    # constructor from multiple key-value pairs
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, **{"b":2})

    # constructor from non-empty dictionary
    id_2 = ImmutableDict({"a": 1, "b": 2})
    assert id_2 == ImmutableDict(a=1, **{"b":2})


# Generated at 2022-06-20 15:34:24.889378
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    set_test = set()
    dict_test = ImmutableDict({'a': 1})
    assert dict_test == {'a': 1}
    assert hash(dict_test) == hash({'a': 1})
    assert dict_test not in set_test
    set_test.add(dict_test)
    set_test.add(dict_test)
    assert len(set_test) == 1
    assert hash(ImmutableDict()) == hash(ImmutableDict())
    assert hash(ImmutableDict({'a': 1})) == hash({'a': 1})
    assert hash(ImmutableDict({'a': 1})) != hash({'a': 2})
    assert hash(ImmutableDict({'a': 1})) != hash({'a': 1, 'b': 1})

# Generated at 2022-06-20 15:34:30.628222
# Unit test for function is_sequence
def test_is_sequence():
    assert not is_sequence(None)
    assert not is_sequence(1)
    assert not is_sequence("foo")
    assert is_sequence([])
    assert is_sequence([1])
    assert is_sequence((1, 2, 3))
    assert is_sequence(set([1]))
    assert is_sequence("foo", include_strings=True)



# Generated at 2022-06-20 15:34:37.554422
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    my_dict = ImmutableDict({"Key1": "value1", "Key2": "value2"})
    assert my_dict == ImmutableDict({"Key2": "value2", "Key1": "value1"})
    assert my_dict != ImmutableDict({"Key1": "value2", "Key2": "value2"})
    assert my_dict != ImmutableDict({"Key1": "value1", "Key2": "value2", "Key3": "value3"})
    assert my_dict != ImmutableDict({"Key3": "value3"})
    assert my_dict == ImmutableDict(my_dict)

# Generated at 2022-06-20 15:34:43.567496
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    obj = ImmutableDict({'a': 1, 'b': 2})
    for key, val in obj.items():
        try:
            assert(key in obj.keys())
        except AssertionError:
            print("ImmutableDict.__iter__: Failed")
        else:
            print("ImmutableDict.__iter__: Passed")



# Generated at 2022-06-20 15:34:46.717898
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    a = ImmutableDict({"a": 1, "b": 2, "c": 3})
    b = ImmutableDict({"b": 2})
    c = a.difference(b)
    assert c == ImmutableDict({"a": 1, "c": 3})


# Generated at 2022-06-20 15:35:01.144145
# Unit test for function is_sequence
def test_is_sequence():
    assert not is_sequence(True)
    assert not is_sequence('str')
    assert not is_sequence(None)
    assert not is_sequence({'a': 1})
    assert is_sequence(['a', 1])
    assert is_sequence(('a', 1))



# Generated at 2022-06-20 15:35:12.320043
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Verify __hash__ method of ImmutableDict works as expected."""
    d = ImmutableDict(foo=1, bar=2)
    d1 = ImmutableDict(foo=1, bar=2)
    d2 = ImmutableDict(foo=1, bar=2, baz=3)
    d3 = ImmutableDict(foo=1, baz=3, bar=2)
    d4 = ImmutableDict(bar=2, baz=3, foo=1)
    d5 = ImmutableDict(bar=2, baz=3, foo=2)
    assert d.__hash__() == d
    assert d.__hash__() == d1
    assert d.__hash__() != d2
    assert d2.__hash__() == d3

# Generated at 2022-06-20 15:35:21.469736
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert test_dict == ImmutableDict({'a': 1, 'c': 3, 'b': 2}), test_dict
    assert test_dict.difference(['b']) == ImmutableDict({'a': 1, 'c': 3}), test_dict.difference(['b'])
    assert test_dict.difference(['a', 'b', 'd']) == ImmutableDict({'c': 3}), test_dict.difference(['a', 'b', 'd'])
    assert test_dict.difference(['a', 'b', 'c']) == ImmutableDict({}), test_dict.difference(['a', 'b', 'c'])

# Generated at 2022-06-20 15:35:25.850537
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    a = ImmutableDict(a=1, b=2, c=3)
    b = a.difference(['a', 'c'])
    assert b == ImmutableDict(b=2)



# Generated at 2022-06-20 15:35:30.011945
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert repr(ImmutableDict()) == 'ImmutableDict({})'
    assert repr(ImmutableDict({'a': 1, 'b': 2})) == "ImmutableDict({'a': 1, 'b': 2})"



# Generated at 2022-06-20 15:35:36.511215
# Unit test for function is_string
def test_is_string():
    assert is_string("foo") == True
    assert is_string("") == True
    assert is_string("") == True
    assert is_string("") == True
    assert is_string("") == True
    assert is_string("") == True
    assert is_string(0) == False
    assert is_string(1) == False
    assert is_string(True) == False
    assert is_string(False) == False
    assert is_string(None) == False
    assert is_string([]) == False
    assert is_string([1, 2, 5]) == False


# Generated at 2022-06-20 15:35:40.952056
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = d1.union({'b': 3, 'c': 4})
    assert d2.a == 1 and d2.b == 3 and d2.c == 4



# Generated at 2022-06-20 15:35:43.502648
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict({'a': 1, 'b': 2})
    assert d['a'] == 1
    assert d['b'] == 2


# Generated at 2022-06-20 15:35:54.282476
# Unit test for function count
def test_count():
    assert count('') == {}
    assert count('a') == {'a': 1}
    assert count('abcd') == {'a': 1, 'b': 1, 'c': 1, 'd': 1}
    assert count('aaa') == {'a': 3}
    assert count([]) == {}
    assert count([1, 2, 3]) == {1: 1, 2: 1, 3: 1}
    assert count([1, 2, 1, 2, 1, 2]) == {1: 3, 2: 3}
    assert count([[], 1, 2, [], [], 1, 1]) == {[]: 3, 1: 3, 2: 1}
    assert count((1, 2, 3)) == {1: 1, 2: 1, 3: 1}

# Generated at 2022-06-20 15:36:00.010332
# Unit test for function is_string
def test_is_string():
    assert is_string("string")
    assert is_string("string".encode("ascii"))
    assert not is_string(u"unicode string")
    assert is_string(u"unicode string".encode("ascii"))
    assert isinstance(u"unicode string", Sequence)
    assert not is_string([1, 2, 3])
    assert not is_string(1)
    assert not is_string(object)



# Generated at 2022-06-20 15:36:16.896527
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    b = {'key2': 'value2.2', 'key3': 'value3'}

    c = a.union(b)

    assert isinstance(c, ImmutableDict)
    assert c['key1'] == 'value1'
    assert c['key2'] == 'value2.2'
    assert c['key3'] == 'value3'



# Generated at 2022-06-20 15:36:19.831690
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict({'a': 1, 'b': 2})) == 2


# Generated at 2022-06-20 15:36:28.869270
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    a = ImmutableDict({"a": 1})
    assert dict(a) == {"a": 1}
    b = a.union({"b": 2})
    assert dict(b) == {"a": 1, "b": 2}
    try:
        a.union(b)
    except TypeError:
        pass
    else:
        assert False, "TypeError should be raised as b is not a Mapping"
    d = a.difference(["a"])
    assert dict(d) == {}
    try:
        a.difference("a")
    except TypeError:
        pass
    else:
        assert False, "TypeError should be raised as 'a' is not an iterable"
    a["a"] = 2
    assert dict(a) == {"a": 1}


# pylint: disable

# Generated at 2022-06-20 15:36:38.215001
# Unit test for function count
def test_count():
    def test_empty():
        assert count([]) == {}

    def test_one_element():
        assert count(['a']) == {'a': 1}

    def test_many_elements():
        assert count(['a', 'b', 'a', 'a']) == {'a': 3, 'b': 1}

    def test_not_a_sequence():
        try:
            count('string')
        except Exception:
            pass
        else:
            raise AssertionError('Expected exception not raised')

    test_empty()
    test_one_element()
    test_many_elements()
    test_not_a_sequence()



# Generated at 2022-06-20 15:36:48.630448
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """
    Test cases for the ImmutableDict class.
    """
    data = dict(a=1, b=2)
    immutable_data = ImmutableDict(data)
    assert immutable_data == data
    assert immutable_data.union(dict(c=3)) == dict(a=1, b=2, c=3)
    assert immutable_data.difference(('a',)) == dict(b=2)
    assert immutable_data.difference(('m',)) == dict(a=1, b=2)
    assert immutable_data['a'] == 1
    assert immutable_data['b'] == 2

    # test keys and values functions
    assert sorted(immutable_data.keys()) == ['a', 'b']
    assert sorted(immutable_data.values()) == [1, 2]

    # Test

# Generated at 2022-06-20 15:36:59.505083
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    import pytest
    # Two ImmutableDict instances are equivalent if they have equivalent contents.
    # This equivalence is represented by the equal value of their hashes.

    # The hash of an ImmutableDict is equal to the hash of a frozenset containing its items.
    original = ImmutableDict()
    assert hash(original) == hash(frozenset(original.items()))

    original = ImmutableDict(x=1, y=2, z=3)
    assert hash(original) == hash(frozenset(original.items()))

    # The hash of an ImmutableDict is equal to the hash of an equivalent MutableMapping
    dict_like = dict(x=1, y=2, z=3)
    assert hash(original) == hash(dict_like)

# Generated at 2022-06-20 15:37:01.639812
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    initial = {'key1': 1, 'key2': 2, 'key3': 3}
    immutable = ImmutableDict(initial)
    assert immutable == initial



# Generated at 2022-06-20 15:37:09.527745
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():

    # Test non-destructive modification of ImmutableDict
    d = ImmutableDict({'a': 1, 'b': 2})
    e = d.union({'c': 3, 'd': 4})
    assert d == ImmutableDict({'a': 1, 'b': 2})
    assert e == ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})

    # Test destructive modification of ImmutableDict
    d = ImmutableDict({'a': 1, 'b': 2})
    e = d.union({'a': 4, 'b': 5})
    assert d == ImmutableDict({'a': 1, 'b': 2})
    assert e == ImmutableDict({'a': 4, 'b': 5})


# Generated at 2022-06-20 15:37:14.269766
# Unit test for function is_sequence
def test_is_sequence():
    # Create a class that is not a Sequence
    class NotSequence(object):
        pass

    # Create a new instance to test with
    notSequence = NotSequence()

    # Test that is_sequence returns false for an instance of NotSequence
    assert not is_sequence(notSequence)

    # Test that is_sequence returns false for an instance of NotSequence even
    # when include_strings is True
    assert not is_sequence(notSequence, include_strings=True)

    # Create a class that is a Sequence
    class Sequence(object):
        def __getitem__(self, index):
            return self.data[index]

    # Create a new instance to test with
    sequence = Sequence()

    # Test that is_sequence returns false for an instance of NotSequence
    assert is_sequence(sequence)

    #

# Generated at 2022-06-20 15:37:20.115910
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    # Test union when overriding_mapping is empty
    original = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    overriding_mapping = ImmutableDict()
    expected_result = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    actual_result = original.union(overriding_mapping)
    assert actual_result == expected_result

    # Test union when overriding_mapping has one new key-value pair
    original = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    overriding_mapping = ImmutableDict({'key3': 'value3'})

# Generated at 2022-06-20 15:37:37.254573
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    first_dict = ImmutableDict({
        'aaa': 0,
        'bbb': [1, 2, 3],
        'ccc': {'a': 1},
    })

    second_dict = ImmutableDict({
        'bbb': 0,
        'ddd': [1, 2, 3],
        'ccc': {'b': 2},
    })

    result = first_dict.union(second_dict)

    assert result == ImmutableDict({
        'aaa': 0,
        'bbb': 0,
        'ddd': [1, 2, 3],
        'ccc': {'b': 2},
    })

# Generated at 2022-06-20 15:37:40.988637
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 'a'}) == ImmutableDict({'a': 'a'})
    assert ImmutableDict({'a': 'a'}) == {'a': 'a'}
    assert not ImmutableDict({'a': 'a'}) == {'a': 'b'}
    assert not ImmutableDict({'a': 'a'}) == {'b': 'a'}
    assert not ImmutableDict({'a': 'a'}) == ImmutableDict({'a': 'b'})
    assert not ImmutableDict({'a': 'a'}) == ImmutableDict({'b': 'a'})



# Generated at 2022-06-20 15:37:43.702508
# Unit test for function is_string
def test_is_string():
    assert is_string("hello")
    assert is_string("")
    assert is_string(u"hello")
    assert is_string(u"")



# Generated at 2022-06-20 15:37:55.211484
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    original_dict = {'a': 'original_1', 'b': 'original_2', 'c': 'original_3'}
    immutable_dict = ImmutableDict(original_dict)
    assert original_dict == immutable_dict._store

    overriding = {'a': 'override_1', 'd': 'additional_1'}
    new_immutable_dict = immutable_dict.union(overriding)
    assert new_immutable_dict['a'] == 'override_1'
    assert new_immutable_dict['b'] == immutable_dict['b']
    assert new_immutable_dict['d'] == 'additional_1'
    try:
        new_immutable_dict['e'] = 'additional_2'
    except AttributeError:
        assert True

# Generated at 2022-06-20 15:38:03.188403
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """ assert __eq__ returns expected results """
    dict1 = ImmutableDict({'a': 1, 'b': 2})

    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2

    dict2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert dict1 != dict2

    dict2 = ImmutableDict({'a': 1, 'b': 4})
    assert dict1 != dict2

    dict2 = ImmutableDict([('a', 1), ('b', 2)])
    assert dict1 == dict2

    dict2 = ImmutableDict()
    assert dict1 != dict2

    dict2 = ImmutableDict({})
    assert dict1 != dict2


# Generated at 2022-06-20 15:38:07.592273
# Unit test for function is_string
def test_is_string():
    from ansible.module_utils.six import text_type, binary_type

    assert is_string(text_type())
    assert is_string(binary_type())
    assert is_string(text_type('example'))
    assert is_string(binary_type(b'example'))



# Generated at 2022-06-20 15:38:17.411633
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(None)
    assert is_iterable(['1', '2', '3'])
    assert is_iterable(('1', '2', '3'))
    assert is_iterable(set(['1', '2', '3']))
    assert is_iterable({'one': 1, 'two': 2, 'three': 3})
    assert is_iterable('123')
    assert is_iterable(range(1, 10))
    assert is_iterable(range(1, 10), include_strings=True)
    assert not is_iterable(1.23)
    assert not is_iterable(123)



# Generated at 2022-06-20 15:38:22.904849
# Unit test for function is_iterable
def test_is_iterable():
    class Foo:
        def __iter__(self):
            yield 1
    class Bar:
        pass

    string = 'foo'
    iterable = [1, 2, 3]
    foo = Foo()
    bar = Bar()

    assert is_iterable(iterable)
    assert is_iterable(string)
    assert is_iterable(foo)
    assert not is_iterable(bar)


# Generated at 2022-06-20 15:38:28.903997
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    # Test function
    def test_immutable_dict_repr(test_dict):
        assert ImmutableDict(test_dict).__repr__() == 'ImmutableDict({0})'.format(repr(test_dict))

    # Do the tests
    test_immutable_dict_repr({"key1": 1, "key2": 2})
    test_immutable_dict_repr({})



# Generated at 2022-06-20 15:38:35.658788
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    """
    Test for method __iter__ of class ImmutableDict
    """
    empty_dict = ImmutableDict()
    assert isinstance(empty_dict, ImmutableDict)
    assert isinstance(empty_dict, Mapping)
    assert isinstance(empty_dict, Hashable)
    assert not isinstance(empty_dict, MutableMapping)
    assert empty_dict == ImmutableDict()
    assert empty_dict == {}
    assert empty_dict is not immutable_dict
    assert ImmutableDict() is not immutable_dict
    assert empty_dict is not {}
    assert empty_dict is not ImmutableDict()
    assert empty_dict == ImmutableDict()
    assert empty_dict == {}
    assert empty_dict is not {}
    assert empty_dict is not ImmutableDict()
    assert empty

# Generated at 2022-06-20 15:38:50.480873
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence((), include_strings=True)
    assert is_sequence(set())
    assert is_sequence("abc") is False

    assert is_sequence("abc", include_strings=True) is True
    assert is_sequence("abc", include_strings=True) is True



# Generated at 2022-06-20 15:38:54.687117
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence((0,))
    assert is_sequence([])
    assert is_sequence(range(0))
    assert is_sequence(tuple())
    assert not is_sequence({'a': 0})
    assert not is_sequence(0)
    assert is_sequence(0, True)



# Generated at 2022-06-20 15:38:57.308966
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    items = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert len(items) == 2


# Generated at 2022-06-20 15:39:00.375111
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """Verify that __len__ works."""
    assert len(ImmutableDict({'a': 1, 'b': 2, 'c': 3})) == 3
    assert len(ImmutableDict()) == 0



# Generated at 2022-06-20 15:39:08.808891
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable(object())
    assert is_iterable('abc')
    assert is_iterable(b'abc')
    assert is_iterable(u'abc')
    assert not is_iterable('abc', include_strings=False)
    assert not is_iterable(b'abc', include_strings=False)
    assert not is_iterable(u'abc', include_strings=False)



# Generated at 2022-06-20 15:39:16.976713
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    assert ImmutableDict({'a': 4, 'b': 5, 'c': 6}).difference(['a']) == ImmutableDict({'b': 5, 'c': 6})
    assert ImmutableDict({'a': 4, 'b': 5, 'c': 6}).difference(['b', 'c']) == ImmutableDict({'a': 4})
    assert ImmutableDict({'a': 4, 'b': 5, 'c': 6}).difference(['a', 'b', 'c']) == ImmutableDict({})
    assert ImmutableDict({}).difference(['a']) == ImmutableDict({})


# Generated at 2022-06-20 15:39:19.436611
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    assert [1, 2, 3] == list(ImmutableDict({'a': 1, 'b': 2, 'c': 3}))


# Generated at 2022-06-20 15:39:23.002484
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Unit test for constructor of class ImmutableDict"""

    data = dict(key="value")
    immutable_data = ImmutableDict(data)
    assert immutable_data == data



# Generated at 2022-06-20 15:39:32.622038
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    # type: () -> None
    d = ImmutableDict({'one': 1, 'two': 2})
    assert isinstance(d, ImmutableDict)
    assert set(d.keys()) == {'one', 'two'}
    assert set(d.values()) == {1, 2}
    assert set(d.items()) == {('one', 1), ('two', 2)}
    assert 'one' in d
    assert 'three' not in d
    assert d['one'] == d.get('one')
    assert d.get('three') is None
    assert d.get('three', 'foo') == 'foo'



# Generated at 2022-06-20 15:39:42.573886
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d1 = ImmutableDict({"a": 1, "b": 2, "c": 3})
    d2 = d1.difference(["c"])
    assert d2 == ImmutableDict({"a": 1, "b": 2})
    assert d1 == ImmutableDict({"a": 1, "b": 2, "c": 3})
    assert d1 != d2
    assert d1 != {"a": 1, "b": 2, "c": 3}
    assert d2 != d1
    assert d2 != {"a": 1, "b": 2}
    assert {"a": 1, "b": 2, "c": 3} != d1
    assert {"a": 1, "b": 2} != d2


# Generated at 2022-06-20 15:40:04.305074
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """Unit test for method __len__ of class ImmutableDict."""
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert len(d) == 3



# Generated at 2022-06-20 15:40:12.695590
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    id1 = ImmutableDict({'a': 1, 'b': 2})
    id2 = ImmutableDict({'a': 1, 'b': 2})
    id3 = ImmutableDict({'a': 1, 'b': 3})
    id4 = ImmutableDict({'a': 4, 'b': 2})
    assert hash(id1) == hash(id2), "Hashes should be equal for equal dictionaries"
    assert hash(id1) != hash(id3), "Hashes should not be equal for dictionaries with different value for some key"
    assert hash(id1) != hash(id4), "Hashes should not be equal for dictionaries with different value for some key"


# Generated at 2022-06-20 15:40:15.568289
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict(a=1, b=2)
    assert d['a'] == 1
    assert d['b'] == 2


# Generated at 2022-06-20 15:40:17.999917
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict(a=1, b=2, c=3)
    assert len(d) == 3


# Generated at 2022-06-20 15:40:20.979260
# Unit test for function is_sequence
def test_is_sequence():
    assert(is_sequence([1, 2, 3]))
    assert(not is_sequence([]))
    assert(not is_sequence('a'))
    assert(is_sequence((1, 2, 3)))
    assert(not is_sequence(()))
    assert(not is_sequence({'a': 1}))
    assert(is_sequence(set([1, 2, 3])))
    assert(not is_sequence(set()))



# Generated at 2022-06-20 15:40:23.648288
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    expected_result = {'ansible': 2}
    input_dict = ImmutableDict(expected_result)
    assert input_dict['ansible'] == 2



# Generated at 2022-06-20 15:40:28.710265
# Unit test for function is_string
def test_is_string():
    assert is_string('a')
    assert is_string(u'a')
    assert is_string(b'a')
    assert not is_string([])
    assert not is_string(dict())
    assert not is_string(set())
    assert not is_string((1, 2))
    assert not is_string(2)
    assert not is_string(None)



# Generated at 2022-06-20 15:40:38.084383
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    orig = ImmutableDict({'a': 'b', 'c': 'd', 'e': 'f'})
    updating = {'a': 'B', 'g': 'h'}
    unioned = orig.union(updating)
    assert unioned == orig.union(updating)
    assert unioned['a'] == updating['a']
    assert unioned['c'] == orig['c']
    assert unioned['g'] == updating['g']
    assert unioned.keys() == set(['a', 'c', 'e', 'g'])

    subtracting = ('a', 'g')
    subtracted = orig.difference(subtracting)
    assert subtracted == orig.difference(subtracting)
    assert subtracted['c'] == orig['c']

# Generated at 2022-06-20 15:40:44.484570
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence(['a', 'b', 'c'])
    assert is_sequence((1, 2, 3))
    assert not is_sequence('abc')
    assert not is_sequence({1, 2, 3})
    assert not is_sequence(set(['a', 'b', 'c']))
    assert not is_sequence(1)
    assert not is_sequence(None)



# Generated at 2022-06-20 15:40:52.251880
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence((0, 1, 2))
    assert is_sequence(set())
    assert is_sequence({'key': 'value'})  # Note that this is not necessarily a good idea
    assert is_sequence(range(5))
    assert is_sequence('abc')
    assert is_sequence(b'abc')
    assert is_sequence(123)
    assert is_sequence(object())

    assert not is_sequence((0, 1, 2), include_strings=True)
    assert not is_sequence('abc', include_strings=True)
    assert not is_sequence(b'abc', include_strings=True)


# Generated at 2022-06-20 15:41:43.249736
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('str')
    assert is_iterable('')
    assert is_iterable(1)
    assert is_iterable(['item1', 'item2'])
    assert is_iterable(['item1', 'item2', 1])
    assert is_iterable(['item1', 'item2', ['item3', 'item4']])
    assert is_iterable(('item1', 'item2'))
    assert is_iterable({'item1': 1, 'item2': 2})
    assert is_iterable(set(('item1', 'item2')))
    assert is_iterable(frozenset(('item1', 'item2')))
    assert is_iterable(range(1, 10))
    assert is_iterable(2.1)
    assert is_

# Generated at 2022-06-20 15:41:53.037438
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test trivial cases when one of the dicts is empty
    empty_dict = ImmutableDict({})
    single_item = ImmutableDict({1: 1})
    assert empty_dict.__eq__(empty_dict)
    assert not empty_dict.__eq__(single_item)
    assert not single_item.__eq__(empty_dict)

    # Test equality when there is a single key-value pair in both dicts
    single_item_one = ImmutableDict({1: 1})
    single_item_two = ImmutableDict({1: 1})
    single_item_different_key = ImmutableDict({2: 1})
    single_item_different_value = ImmutableDict({1: 2})
    assert single_item_one.__eq__(single_item_two)

# Generated at 2022-06-20 15:41:55.307074
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    dictionary = ImmutableDict(Key1='Value1', Key2='Value2')
    assert 'Value1' == dictionary['Key1']
    assert 'Value2' == dictionary['Key2']
    assert 2 == len(dictionary)


# Generated at 2022-06-20 15:41:58.414676
# Unit test for function is_string
def test_is_string():
    assert is_string('abc')
    assert is_string(u'abc')
    assert is_string(b'abc')
    assert not is_string([1, 2, 3])



# Generated at 2022-06-20 15:42:07.627728
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    c = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    e = ImmutableDict({'a': 1, 'b': 2, 'e': 5})
    f = ImmutableDict({'a': 1, 'f': 6})
    g = {'a': 1, 'b': 2}

    assert a == a
    assert a == b
    assert a != c
    assert a != d
    assert a != e
    assert a != f
    assert a != g



# Generated at 2022-06-20 15:42:10.655153
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """ Test for constructor of class ImmutableDict."""
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict([('a', 1), ('b', 2)])
    assert ImmutableDict(a=1, b=2) == ImmutableDict([('a', 1), ('b', 2)])



# Generated at 2022-06-20 15:42:17.139958
# Unit test for constructor of class ImmutableDict

# Generated at 2022-06-20 15:42:20.335839
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({'a':1, 'b':2})
    dict2 = {'a':1, 'b':2}
    dict3 = {'a':1, 'b':2}
    dict4 = {'a':2, 'b':2}
    assert dict1 == dict2
    assert dict1 == dict3
    assert dict1 != dict3
    assert dict1 != dict4

# Generated at 2022-06-20 15:42:24.462278
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    import pytest

    sample_dict = {'a': 1, 'b': 2}
    immutable_dict = ImmutableDict(sample_dict)
    assert repr(immutable_dict) == 'ImmutableDict({0})'.format(repr(sample_dict))

# Generated at 2022-06-20 15:42:29.791412
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    # setup test data
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_immutable_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    # test
    for iter in test_immutable_dict:
        assert iter in test_dict.keys()

