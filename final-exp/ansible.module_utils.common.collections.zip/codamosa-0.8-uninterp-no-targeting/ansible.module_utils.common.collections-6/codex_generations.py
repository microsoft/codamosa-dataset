

# Generated at 2022-06-20 15:33:50.725464
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    class NestedImmutableDict(ImmutableDict):
        pass

    class NonHashable(object):
        def __eq__(self, other):
            return True

        def __hash__(self):
            raise TypeError

    class HashableNonEqual(object):
        def __eq__(self, other):
            return False

        def __hash__(self):
            return 1

    orig_dict = ImmutableDict({'a': 'b'})
    # Different types should be different
    assert orig_dict != {'a': 'b'}
    assert orig_dict != NestedImmutableDict({'a': 'b'})
    # Non-hashed types should not be equal
    assert orig_dict != NonHashable()
    # Hashable but non-eq types should not be equal
    assert orig_dict

# Generated at 2022-06-20 15:33:53.715367
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(tuple())
    assert is_iterable('abc')
    assert not is_iterable(None)
    assert not is_iterable(object())


# Generated at 2022-06-20 15:34:01.466815
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    dict1 = ImmutableDict({'key1': 'val1', 'key2': 'val2', 'key3': 'val3'})
    dict2 = ImmutableDict({'key1': 'val1', 'key2': 'val2', 'key3': 'val3'})
    dict3 = ImmutableDict({'key1': 'val1', 'key2': 'val2', 'key3': 'val33'})
    assert hash(dict1) == hash(dict2)
    assert hash(dict1) != hash(dict3)


# Generated at 2022-06-20 15:34:09.450638
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    foo = ImmutableDict()
    bar = ImmutableDict({"x": 1, "y": 2, "z": 3})
    foobar = ImmutableDict({"x": 1, "y": 2, "z": 3})

    # Test the returned type and the hash results
    assert type(foo.__hash__()) is int
    assert foo.__hash__() != bar.__hash__()
    assert bar.__hash__() == foobar.__hash__()

# Generated at 2022-06-20 15:34:15.209680
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    d1 = ImmutableDict({1:2, 2:3})
    d2 = ImmutableDict({2:5, 3:6})
    d3 = d1.union(d2)
    if d3 != ImmutableDict({1:2, 2:5, 3:6}):
        raise Exception('union method of ImmutableDict class produced incorrect result')


# Generated at 2022-06-20 15:34:24.629815
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1})
    b = ImmutableDict({'a': 1})
    c = ImmutableDict({'a': 2})
    d = {'a': 1}
    # equal objects
    assert a == a
    assert a == b
    # different objects
    assert a != c
    assert b != c
    assert a != d
    assert b != d
    assert c != d

    assert a == {'a': 1}
    assert a != {'a': 2}
    assert a != {'a': 1, 'b': 2}
    assert a != {'b': 1}
    assert a != {'a': 1, 'b': 2}
    assert a != ImmutableDict()


# Generated at 2022-06-20 15:34:28.325521
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    immutable_dict = ImmutableDict({'key1':'value1','key2':'value2','key3':'value3'})
    assert len(immutable_dict) == 3


# Generated at 2022-06-20 15:34:35.033977
# Unit test for function count
def test_count():
    import pytest
    assert count([]) == {}
    assert count('abc') == {'a': 1, 'b': 1, 'c': 1}
    assert count([1, 2, 3]) == {1: 1, 2: 1, 3: 1}
    with pytest.raises(Exception) as excinfo:
        count(1)
    assert 'not an iterable' in str(excinfo.value)
    with pytest.raises(Exception) as excinfo:
        count({})
    assert 'not an iterable' in str(excinfo.value)



# Generated at 2022-06-20 15:34:38.346509
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    assert len(test_dict) == 4


# Generated at 2022-06-20 15:34:50.575891
# Unit test for function is_string
def test_is_string():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.parsing.vault import VaultLib
    vault_secret = 'hello world'
    vault_password = 'foobar'
    vault = VaultLib(vault_password)

    assert is_string(b'test')
    assert is_string('test')
    assert not is_string(OrderedDict())
    assert not is_string(MutableMapping())
    assert not is_string(ImmutableDict())
    assert not is_string([])
    assert not is_string(10)
    assert not is_string(10.5)

    # Test that is_string returns True for encrypted strings
    encrypted_string = vault.encrypt(vault_secret)
    assert is_string(encrypted_string)


# Generated at 2022-06-20 15:35:01.926544
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """
    Make sure that __hash__ is not affected by order of items
    """
    d1 = ImmutableDict(a=1, b=2, c=3)
    d2 = ImmutableDict(c=3, b=2, a=1)

    # __eq__ is based on __hash__,
    # which is based on frozenset of items...
    # therefore it should not be sensitive to order of items
    assert d1 == d2



# Generated at 2022-06-20 15:35:12.590731
# Unit test for function count
def test_count():
    test_list = [1, 1, 2, 3, 2, 1, 2, 3, 3]
    assert count(test_list) == {1: 3, 2: 3, 3: 3}
    assert count((1, 1, 2, 3, 2, 1, 2, 3, 3)) == {1: 3, 2: 3, 3: 3}
    assert count((i for i in test_list)) == {1: 3, 2: 3, 3: 3}
    assert count({1: 2, 2: 3}) == {1: 1, 2: 1}
    assert count({1, 2, 3}) == {1: 1, 2: 1, 3: 1}
    assert count('123123') == {'1': 2, '2': 2, '3': 2}


# Generated at 2022-06-20 15:35:18.199513
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    initial_dict = ImmutableDict(one=1, two=2, three=3)
    overriding_dict = dict(two='TWO', four=4, five=5)
    unioned_dict = initial_dict.union(overriding_dict)
    assert unioned_dict == ImmutableDict(one=1, two='TWO', three=3, four=4, five=5)



# Generated at 2022-06-20 15:35:29.964419
# Unit test for function is_iterable
def test_is_iterable():
    # test string-like things
    assert not is_iterable('a')
    assert not is_iterable(u'a')
    assert not is_iterable(b'a')
    assert not is_iterable(u'\u20ac')

    # test iterable-like things
    assert is_iterable(['a'])
    assert is_iterable(('a',))
    assert is_iterable({'a': 'b'})
    assert is_iterable(set())
    assert is_iterable(range(5))

    # test non-iterable-like things
    assert not is_iterable(5)
    assert not is_iterable(b'a'.decode())
    assert not is_iterable(lambda: None)



# Generated at 2022-06-20 15:35:34.800789
# Unit test for function is_string
def test_is_string():
    """Unit-test the function is_string."""
    assert is_string("hello") == True
    assert is_string("") == True
    assert is_string(b"hello") == True
    assert is_string(b"") == True
    assert is_string(u"hello") == True
    assert is_string(u"") == True
    assert is_string(1) == False


# Generated at 2022-06-20 15:35:46.157039
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    # pylint: disable=missing-docstring
    # This function is meant to be used by unit tests only
    # Unit tests are not required to have docstrings

    original = ImmutableDict({'a': 1})
    new_mapping = {'a': 2, 'b': 3}
    result = original.union(new_mapping)

    assert isinstance(result, ImmutableDict)
    assert result['a'] == 2
    assert result['b'] == 3

    original = ImmutableDict({'a': 1, 'b': 2})
    new_mapping = {'b': 3, 'c': 4}
    result = original.union(new_mapping)

    assert isinstance(result, ImmutableDict)
    assert result['a'] == 1
    assert result['b'] == 3
    assert result

# Generated at 2022-06-20 15:35:49.226755
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    config = ImmutableDict({'a':1, 'b':2, 'c':3})
    for key in config:
        print(key)


# Generated at 2022-06-20 15:35:51.466288
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    assert tuple(ImmutableDict(x='1', y='2', z='3')) == ('x', 'y', 'z')


# Generated at 2022-06-20 15:36:00.216690
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    """
    Union with a normal dict
    """
    original = ImmutableDict({'key': 'value'})
    override = {'key': 'override', 'extra_key': 'extra_value'}
    union = original.union(override)
    assert union == {'key': 'override', 'extra_key': 'extra_value'}

    """
    Union with another ImmutableDict
    """
    original = ImmutableDict({'key': 'value'})
    override = ImmutableDict({'key': 'override', 'extra_key': 'extra_value'})
    union = original.union(override)
    assert union == {'key': 'override', 'extra_key': 'extra_value'}

    """
    Union with a non-dict
    """
    original = Immutable

# Generated at 2022-06-20 15:36:02.891990
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    """Test method __iter__ of class ImmutableDict"""

    immutable_dict = ImmutableDict(a=1, b=2, c=3)
    expected_dict = {'c': 3, 'b': 2, 'a': 1}
    assert(expected_dict == dict(immutable_dict.__iter__()))


# Generated at 2022-06-20 15:36:18.482605
# Unit test for function is_string
def test_is_string():
    assert is_string('test')
    assert is_string(u'test')
    assert is_string(b'test')

    assert not is_string([])
    assert not is_string({})
    assert not is_string(1)
    assert not is_string(object())



# Generated at 2022-06-20 15:36:23.327714
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    my_dict = {'hello': 1, 'world': 2}
    immutable = ImmutableDict(my_dict)
    counter = 0
    for _ in immutable:
        counter += 1
    assert counter == len(my_dict)


# Generated at 2022-06-20 15:36:31.581283
# Unit test for function count
def test_count():
    """Unit test for the method count."""
    assert count([]) == {}
    assert count([1, 2, 2, 3]) == {1: 1, 2: 2, 3: 1}
    assert count({1: 2, 3: 4}) == {1: 1, 3: 1}
    assert count({1: 2}) == {1: 1}
    assert count('abracadabra') == {'a': 5, 'b': 2, 'r': 2, 'c': 1, 'd': 1}
    assert count(('a', 'b', 'r', 'a', 'c', 'a', 'd', 'a', 'b', 'r', 'a')) == {'a': 5, 'b': 2, 'r': 2, 'c': 1, 'd': 1}

# Generated at 2022-06-20 15:36:41.253828
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d1 = ImmutableDict({"a": 1, "b": 2, "c": 3, "x": "X", "y": "Y"})
    d2 = d1.difference(("c", "x"))
    assert(len(d2) == 4)
    assert(d2["a"] == 1)
    assert(d2["b"] == 2)
    assert(d2["c"] == 3)
    assert(d2["x"] == "X")
    assert(d2["y"] == "Y")

    # try to remove from empty dictionary
    d3 = ImmutableDict()
    d4 = d3.difference(("c", "x", "y", "z"))
    assert(len(d4) == 0)

    # try to remove unknown key
    d5 = ImmutableDict

# Generated at 2022-06-20 15:36:45.355056
# Unit test for function is_string
def test_is_string():
    assert is_string(u'foo')
    assert is_string(b'foo')

    assert not is_string(['foo'])
    assert not is_string(set(['foo']))
    assert not is_string(True)
    assert not is_string(3)



# Generated at 2022-06-20 15:36:49.470587
# Unit test for function is_string
def test_is_string():
    assert is_string('hello world') is True
    assert is_string(b'hello world') is True
    assert is_string(u'hello world') is True
    assert is_string({}) is False
    assert is_string([]) is False
    assert is_string(None) is False
    assert is_string(1) is False
    assert is_string(1.5) is False

# Generated at 2022-06-20 15:36:55.488632
# Unit test for function is_string
def test_is_string():
    assert is_string('abc') is True
    assert is_string(u'abc') is True
    assert is_string(b'abc') is True
    assert is_string([]) is False
    assert is_string(()) is False
    assert is_string({}) is False
    assert is_string(1) is False
    assert is_string(b'\xe9') is False



# Generated at 2022-06-20 15:36:59.080122
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    base = ImmutableDict(first='one', second='two', third='three')
    subtractive = ('first', 'third')
    expected = ImmutableDict(second='two')
    result = base.difference(subtractive)
    assert result == expected

# Generated at 2022-06-20 15:37:01.865364
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert not is_sequence('abc')
    assert is_sequence('abc', True)
    assert is_sequence(u'abc')
    assert is_sequence(u'abc', True)



# Generated at 2022-06-20 15:37:04.271078
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict(a=1, b=2)
    assert repr(d) == "ImmutableDict({'a': 1, 'b': 2})"


# Generated at 2022-06-20 15:37:24.457827
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(())
    assert is_iterable(set())
    assert is_iterable(u"abc")
    assert is_iterable([1])
    assert is_iterable((1,))
    assert is_iterable(set([1]))
    assert is_iterable(u"a")
    assert is_iterable(b"a")
    assert not is_iterable(None)
    assert not is_iterable(1)



# Generated at 2022-06-20 15:37:31.148163
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    from nose.tools import assert_equal
    from ansible.module_utils.common.collections import ImmutableDict

    ids1 = ImmutableDict({'A': 1, 'C': 2, 'B': 3})
    ids2 = ImmutableDict({'A': 1, 'B': 3, 'C': 2})
    assert_equal(hash(ids1), hash(ids2))



# Generated at 2022-06-20 15:37:37.206932
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    b = ImmutableDict({'c': 3, 'b': 2, 'a': 1})
    c = ImmutableDict({'x': 42, 'b': 2, 'a': 1})
    d = ImmutableDict({'c': 3, 'b': 2, 'a': 1})

    assert a != b
    assert a == a
    assert c != d
    assert (a == c) == False
    assert (b == d) == True



# Generated at 2022-06-20 15:37:41.856563
# Unit test for function is_sequence
def test_is_sequence():
    """Test is_sequence function."""
    assert is_sequence(['seq'])
    assert is_sequence(())
    assert is_sequence({})
    assert is_sequence(set())
    assert is_sequence([2, 3, 5, 7, 11, 13])
    assert is_sequence({2, 3, 5, 7, 11, 13})
    assert is_sequence({'a': 2, 'b': 3, 'c': 5})
    assert is_sequence(('a', 2, 'c', 5))
    assert is_sequence(('a', ['b', 'c'], {'d': 5}, set('e')))

    assert not is_sequence(1)
    assert not is_sequence(object())
    assert not is_sequence('hello')
    assert not is_sequence(b'world')



# Generated at 2022-06-20 15:37:46.996784
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():

    ids = ImmutableDict({"key1": "value1", "key2": "value2"})
    id2 = ImmutableDict(ids, key3="value3")
    id3 = ImmutableDict(id2, key4="value4")

    assert hash(ids) == hash(id2)
    assert hash(ids) != hash(id3)
    assert hash(id2) != hash(id3)


# Generated at 2022-06-20 15:37:58.791060
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    def _test_equal(x, y):
        assert x == y
        assert y == x
        assert not (x != y)
        assert not (y != x)

    def _test_notequal(x, y):
        assert x != y
        assert y != x
        assert not (x == y)
        assert not (y == x)

    idict = ImmutableDict(foo=42, bar=23)
    assert idict == idict
    assert not (idict != idict)

    _test_equal(idict, ImmutableDict(foo=42, bar=23))
    _test_equal(idict, ImmutableDict(bar=23, foo=42))
    _test_notequal(idict, ImmutableDict(bar=23))

# Generated at 2022-06-20 15:38:07.665522
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """
    Test the creation of an instance of ImmutableDict
    """

    # Check that we can create instance of ImmutableDict from a regular dict
    regular_dict = {'one': 1, 'two': 2}
    imm_dict = ImmutableDict(regular_dict)

    assert imm_dict == regular_dict
    assert isinstance(imm_dict, Mapping)
    assert not isinstance(imm_dict, MutableMapping)
    assert isinstance(imm_dict, Hashable)

    # Check that we can create instance of ImmutableDict from a keyword
    imm_dict2 = ImmutableDict(three=3, four=4)

    assert imm_dict2 == {'three': 3, 'four': 4}
    assert isinstance(imm_dict2, Mapping)

# Generated at 2022-06-20 15:38:19.171295
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence(None) is False
    assert is_sequence("a string") is False
    assert is_sequence("a string", include_strings=True) is True
    assert is_sequence(u"a string") is False
    assert is_sequence(u"a string", include_strings=True) is True
    assert is_sequence("") is False
    assert is_sequence("", include_strings=True) is True
    assert is_sequence(u"") is False
    assert is_sequence(u"", include_strings=True) is True
    assert is_sequence(5) is False
    assert is_sequence(dict()) is False
    assert is_sequence(set()) is False
    assert is_sequence(tuple()) is True
    assert is_sequence([]) is True
    assert is_sequence(ImmutableDict()) is False

# Generated at 2022-06-20 15:38:24.773906
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence(())
    assert is_sequence({})
    assert is_sequence(set())

    assert is_sequence(range(10))

    assert not is_sequence((x for x in range(10)))  # generator expression
    assert not is_sequence(is_sequence)  # function
    assert not is_sequence(1)  # int
    assert not is_sequence(None)

# Generated at 2022-06-20 15:38:33.716913
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a = ImmutableDict({'a': '1'})
    b = ImmutableDict({'b': '2'})
    c = ImmutableDict({'a': '3'})
    assert a.union(b) == ImmutableDict({'a': '1', 'b': '2'})
    assert a.union(c) == ImmutableDict({'a': '3'})
    assert b.union(a) == ImmutableDict({'b': '2', 'a': '1'})
    assert b.union(c) == ImmutableDict({'b': '2', 'a': '3'})
    assert a.union(a) == ImmutableDict({'a': '1'})

# Generated at 2022-06-20 15:39:08.486520
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """
    Unit test for method __len__ of class ImmutableDict

    This test verifies the method __len__ of class ImmutableDict.
    """
    test_data = [
        (1, 2, 3),
        ("a", "b", "c"),
        ("A", "b", 3),
        ("A", ("b", "c"), 5, "foo", {"bar": "baz"}),
    ]
    for td in test_data:
        assert len(td) == len(ImmutableDict(zip(td, td)))



# Generated at 2022-06-20 15:39:12.233148
# Unit test for function is_string
def test_is_string():
    '''
    >>> assert is_string("a string")
    >>> assert not is_string(None)
    >>> assert not is_string(1)
    >>> assert not is_string([1,2,3])
    '''
    pass


# Generated at 2022-06-20 15:39:20.784312
# Unit test for function count
def test_count():
    """This function is used to run unit tests for ``count`` function."""
    assert count([1, 2, 3, 1, 4]) == {1: 2, 2: 1, 3: 1, 4: 1}
    assert count([1, 2, 3, 1, 3, 4]) == {1: 2, 2: 1, 3: 2, 4: 1}
    assert count('aaaa') == {'a': 4}
    assert count(1) == {1: 1}
    assert count('a') == {'a': 1}
    assert count(['test']) == {'test': 1}
    assert count([]) == {}
    assert count({'test': 1}) == {'test': 1}
    assert count({'test': 1}, 'test') == {'test': 1}



# Generated at 2022-06-20 15:39:25.904045
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    data = {'a': 10, 'b': 20}
    i_data = ImmutableDict(data)
    assert i_data == data
    assert i_data['a'] == 10
    try:
        i_data['a'] = 20
    except Exception as e:
        assert type(e) is TypeError
    else:
        raise Exception('Wrong constructor')

# Generated at 2022-06-20 15:39:36.250435
# Unit test for function is_iterable
def test_is_iterable():
    # True tests
    assert is_iterable([])
    assert is_iterable([0])
    assert is_iterable((0, 1))
    assert is_iterable(set([0, 1]))
    assert is_iterable({0: 1})
    assert is_iterable(xrange(0, 1))
    assert is_iterable('123')
    assert is_iterable(u'123')
    assert is_iterable(b'123')
    # False tests
    assert not is_iterable(0)
    assert not is_iterable(dict())
    assert not is_iterable('')
    assert not is_iterable(u'')
    assert not is_iterable(b'')



# Generated at 2022-06-20 15:39:40.367995
# Unit test for function is_string
def test_is_string():
    assert is_string('abc')
    assert not is_string(u'abc')
    assert not is_string(b'abc')
    assert not is_string(1)

    assert is_string(u'abc')
    assert not is_string('abc')
    assert not is_string(b'abc')
    assert not is_string(1)

    assert is_string(b'abc')
    assert not is_string('abc')
    assert not is_string(u'abc')
    assert not is_string(1)



# Generated at 2022-06-20 15:39:43.254983
# Unit test for function count
def test_count():
    assert count([1, 2, 1, 3, 2]) == {1: 2, 2: 2, 3: 1}
    assert count([]) == {}



# Generated at 2022-06-20 15:39:47.081047
# Unit test for function is_string
def test_is_string():
    assert is_string('')
    assert is_string('Hey there!')
    assert is_string(u'Hey there!')
    assert is_string(b'Hey there!')
    assert not is_string({})
    assert not is_string([])
    assert not is_string(())
    assert not is_string(None)



# Generated at 2022-06-20 15:39:50.923149
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    immutable_dict = ImmutableDict(a=1, b=2, c=3)
    assert immutable_dict['a'] == 1
    assert immutable_dict['b'] == 2
    assert immutable_dict['c'] == 3


# Generated at 2022-06-20 15:40:02.489356
# Unit test for function is_sequence
def test_is_sequence():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.utils import string_types

    # This is a class to test is_sequence
    class SomeClass(object):
        def __init__(self, _list=None):
            if _list is None:
                _list = []
            self._list = _list

        def __getitem__(self, i):
            return self._list[i]

        def __len__(self):
            return len(self._list)

    someclass = SomeClass(list(range(10)))
    assert is_sequence(someclass)

    # These are classes that are sequences
    assert is_sequence('abc')
    assert is_sequence(u'abc')
    assert is_sequence(string_types)

# Generated at 2022-06-20 15:41:05.042162
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({1: 'a', 2: 'b'})
    d2 = ImmutableDict({1: 'a', 2: 'b'})
    assert d1 == d2
    assert not d1 == dict({1: 'a', 2: 'b'})
    assert not d1 == ImmutableDict({1: 'a', 2: 'c'})


# Generated at 2022-06-20 15:41:14.957961
# Unit test for function count
def test_count():
    from ansible.module_utils._text import to_native
    from sys import version_info

    if version_info < (2, 7):
        try:
            # Test for exception when seq param is not iterable
            count(None)
            raise Exception('Exception was not raised')
        except Exception as exc:
            assert 'is not an iterable' in to_native(exc)

        # Test for proper counting
        assert count([1, 2, 3]) == {1: 1, 2: 1, 3: 1}
        assert count([1, 2, 3, 1]) == {1: 2, 2: 1, 3: 1}
        assert count([]) == {}

        # Test for proper counting of Unicode strings

# Generated at 2022-06-20 15:41:23.191866
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a = ImmutableDict({'a': 1, 'b': 2})
    b = {'c': 3, 'd': 4, 'e': 5}
    # Test that union produces expected output
    assert a.union(b) == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    # Test that union a ImmutableDict with a non-Mapping object
    # produces the expected error
    try:
        a.union([1,2,3])
    except TypeError as e:
        assert e.args[0] == 'expected mapping but got {0}'.format(
            [1,2,3].__class__.__name__)

# Generated at 2022-06-20 15:41:29.899338
# Unit test for function is_sequence
def test_is_sequence():
    """is_sequence() should only return True for instances of collections.Sequence"""
    try:
        from collections import Sequence
    except ImportError:
        try:
            from UserList import UserList
            Sequence = UserList
        except ImportError:
            Sequence = None
    if not Sequence:
        raise ImportError('Could not import Sequence from collections or UserList')
    class MySequence(Sequence):
        pass
    class NotSequence(object):
        pass
    assert(is_sequence([1, 2, 3]))
    assert(is_sequence([]))
    assert(is_sequence(MySequence((1, 2, 3))))
    assert(not is_sequence("123"))
    assert(not is_sequence(NotSequence()))
    assert(is_sequence("123", include_strings=True))

# Generated at 2022-06-20 15:41:41.512784
# Unit test for function is_sequence
def test_is_sequence():
    class MySequence(object):
        def __getitem__(self, i):
            pass

    class MyNonSequence(object):
        pass

    # Sequence behaves like a sequence
    assert is_sequence(MySequence())
    assert not is_sequence(MyNonSequence())

    # Sequence behaves like a sequence (non-indexable things are not sequences)
    assert is_sequence([])
    assert is_sequence(())
    assert is_sequence({})
    assert not is_sequence(object())

    # Strings are not sequences (unless explicitly requested)
    assert not is_sequence('abc')
    assert not is_sequence(b'abc')
    assert not is_sequence(u'abc')
    assert is_sequence('abc', include_strings=True)
    assert is_sequence(b'abc', include_strings=True)

# Generated at 2022-06-20 15:41:46.897331
# Unit test for function count
def test_count():
    assert count([1, 2, 3, 2, 1, 2]) == {1: 2, 2: 3, 3: 1}
    assert count('123') == {'1': 1, '2': 1, '3': 1}
    try:
        count('foo')
    except Exception as e:
        assert 'is not an iterable' in str(e)



# Generated at 2022-06-20 15:41:49.718810
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict(key='value')
    expected_repr = "ImmutableDict({'key': 'value'})"
    assert repr(d) == expected_repr



# Generated at 2022-06-20 15:41:53.036440
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    i_d = ImmutableDict({'x': 42, 'y': 43})
    assert len(i_d) == 2


# Generated at 2022-06-20 15:41:59.266109
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d = ImmutableDict({'a': 1, 'b': 2})
    assert d == d
    assert d == {'a': 1, 'b': 2}
    assert d == ImmutableDict({'a': 1, 'b': 2})
    assert d == ImmutableDict({'b': 2, 'a': 1})
    assert not d == {'b': 1, 'a': 2}
    assert not d == ImmutableDict({'b': 1, 'a': 2})
    assert not d == {'a': 1, 'b': 2, 'c': 3}
    assert not d == ImmutableDict({'a': 1, 'b': 2, 'c': 3})


# Generated at 2022-06-20 15:42:00.915034
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d = ImmutableDict({'a': 2, 'b': 3})
    assert hash(d) == hash(frozenset([('a', 2), ('b', 3)]))