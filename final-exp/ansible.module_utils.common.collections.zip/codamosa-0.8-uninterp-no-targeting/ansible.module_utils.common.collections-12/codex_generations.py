

# Generated at 2022-06-20 15:33:42.393362
# Unit test for function count
def test_count():
    assert count([]) == {}
    assert count([1, 2, 1, 1, 2, 3]) == {1: 3, 2: 2, 3: 1}



# Generated at 2022-06-20 15:33:47.061331
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    immutableDict_ = ImmutableDict({'foo': 'bar'})
    assert immutableDict_.__repr__() == "ImmutableDict({'foo': 'bar'})"
    assert str(immutableDict_) == "ImmutableDict({'foo': 'bar'})"
# end of test method __repr__ of class ImmutableDict


# Generated at 2022-06-20 15:33:51.146190
# Unit test for function is_sequence
def test_is_sequence():
    # is_sequence should return False for strings and bytes
    str_val = "abc"
    b_val = b"abc"

    assert not is_sequence(str_val)
    assert not is_sequence(b_val)

    # is_sequence should return True for lists and tuples
    assert is_sequence([1,2,3])
    assert is_sequence((1,2,3))

    # is_sequence should return True for user defined classes that are subclasses of Sequence
    class seq_test_class(Sequence):
        def __init__(self, *args):
            self.value = args

        def __len__(self):
            return len(self.value)

    assert is_sequence(seq_test_class(1,2,3))

    # Unless is_sequence is told otherwise, it should return False for strings

# Generated at 2022-06-20 15:33:56.223589
# Unit test for function is_sequence
def test_is_sequence():
    seq_types_true = [
        [], (), [1], (1, ), {1}, {1: 2}, set(), set([1]), tuple([1]), tuple([1, 2])
    ]
    seq_types_false = [
        1, 1.0, 'a', b'a'
    ]
    assert all(is_sequence(seq, include_strings=False) for seq in seq_types_true)
    assert not any(is_sequence(seq, include_strings=False) for seq in seq_types_false)



# Generated at 2022-06-20 15:33:58.561442
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """
    Tests for the ImmutableDict
    """
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-20 15:34:01.758804
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    data = ImmutableDict(foo=1, bar=2)
    assert data.__iter__() == ['foo', 'bar']
    assert list(data.__iter__()) == ['foo', 'bar']


# Generated at 2022-06-20 15:34:11.472758
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Verify that ImmutableDict works as expected."""
    orig = ImmutableDict(a=1, b=2, c=3, d=4)
    overriding = {'b': 'foo', 'z': 'bar'}

    combined = orig.union(overriding)
    assert combined == ImmutableDict({'a': 1, 'b': 'foo', 'c': 3, 'd': 4, 'z': 'bar'})

    stripped = orig.difference(['a', 'c', 'z'])
    assert stripped == ImmutableDict({'b': 2, 'd': 4})

# Generated at 2022-06-20 15:34:19.760873
# Unit test for function is_string
def test_is_string():
    assert is_string("myString")
    assert is_string("myString-2")
    assert is_string("myString_3")
    assert not is_string(u"myString")
    assert not is_string(b"myString")
    assert not is_string(["myString"])
    assert not is_string(("myString"))
    assert not is_string(("myString", "myString"))
    assert not is_string({"myString": "myString"})


# Generated at 2022-06-20 15:34:22.553045
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_dict = ImmutableDict(a=1, b=2, c=3, d=4)
    assert test_dict.difference(['c', 'd']) == ImmutableDict(a=1, b=2)

# Generated at 2022-06-20 15:34:27.630520
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict({'a': 1, 'b': 2})) == 2
    assert len(ImmutableDict(a=1, b=2)) == 2



# Generated at 2022-06-20 15:34:35.420959
# Unit test for function is_string
def test_is_string():
    assert is_string('1234') is True
    assert is_string(b'1234') is True
    assert is_string([]) is False
    assert is_string(dict()) is False
    assert is_string(u'1234') is True
    assert is_string(set()) is False
    assert is_string(('a', 'b')) is False
    assert is_string(1) is False



# Generated at 2022-06-20 15:34:41.847979
# Unit test for function is_iterable
def test_is_iterable():
    iterable = [1, 2, 3]
    string = 'str'
    int_number = 5
    assert is_iterable(iterable) == True
    assert is_iterable(string, include_strings=True) == True
    assert is_iterable(string) == False
    assert is_iterable(int_number) == False


# Generated at 2022-06-20 15:34:45.586451
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict(a=1, b=2)
    assert repr(d) == 'ImmutableDict({\'a\': 1, \'b\': 2})'



# Generated at 2022-06-20 15:34:49.215466
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    dct = ImmutableDict({"one":1, "two":2})
    assert repr(dct) == "ImmutableDict({'one': 1, 'two': 2})"


# Generated at 2022-06-20 15:34:56.633485
# Unit test for function is_string
def test_is_string():
    ''' test for function is_string '''
    import ansible.module_utils.common.crypto
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

    test_string = "This is a test string"

    # Test text type
    assert is_string(test_string) is True

    # Test string sub classes
    class TestSubClass(text_type):
        pass

    assert is_string(TestSubClass(test_string)) is True

    # Test encrypted data string
    vault_pass = 'VauLt_PaSsWoRd'
    test_bytes = to_bytes(test_string)

# Generated at 2022-06-20 15:35:08.033026
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # Create an ImmutableDict with a few keys
    dic = ImmutableDict({'name': 'ansible', 'version': 'awesome'})

    # Remove keys from the ImmutableDict and verify the result
    new_dic = dic.difference(['version'])
    assert new_dic == ImmutableDict({'name': 'ansible'})

    # Remove a non-existent key from the ImmutableDict and verify the result
    new_dic = dic.difference(['yea'])
    assert new_dic == ImmutableDict({'name': 'ansible', 'version': 'awesome'})

    # Remove multiple keys from the ImmutableDict and verify the result
    new_dic = dic.difference(['version', 'name'])

# Generated at 2022-06-20 15:35:09.298701
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    return ['one', 'two', 'three']


# Generated at 2022-06-20 15:35:20.031664
# Unit test for function count
def test_count():
    # Test basic functionality
    test_dict = {1: 1, 2: 2, 3: 3, 4: 4}
    assert count([1, 2, 3, 4, 5, 6]) == test_dict

    # Test that the function works with string providing an argument
    assert count(['1', '2', '3', '4', '5', '6']) == test_dict

    # Test that the function fails if not provided with an iterable
    # and raises an exception
    try:
        count('This is a string')
        raise Exception
    except Exception:
        pass

    # Test that the function works with a sequence
    test_dict = {
        (1, 2): 1,
        ('a', 'b'): 1,
        ('c', 'd', 'e'): 1
    }

# Generated at 2022-06-20 15:35:24.719634
# Unit test for function is_string
def test_is_string():
    assert is_string('str')
    assert not is_string((1, 2))
    assert not is_string([1, 2])
    assert not is_string(set([1, 2]))
    assert not is_string(dict())

    class NonText(object):
        pass

    assert not is_string(NonText())



# Generated at 2022-06-20 15:35:31.067079
# Unit test for function count
def test_count():
    assert count([]) == {}
    assert count([1]) == {1: 1}
    assert count([1, 2]) == {1: 1, 2: 1}
    assert count([1, 2, 1]) == {1: 2, 2: 1}
    assert count([1, 2, 1, 2, 1, 2, 1, 2]) == {1: 4, 2: 4}



# Generated at 2022-06-20 15:35:48.232892
# Unit test for function count
def test_count():
    assert count([1, 1, 1, 2, 3, 3, 3, 3]) == {1: 3, 2: 1, 3: 4}
    assert count('haha') == {'h': 2, 'a': 2}
    try:
        count(1)
    except:
        assert True
    else:
        assert False



# Generated at 2022-06-20 15:35:57.934834
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    test_dict = ImmutableDict({'username': 'admin', 'password': 'secret'})

    assert test_dict['username'] == 'admin'
    assert test_dict['password'] == 'secret'
    assert len(test_dict) == 2

    test_dict2 = test_dict.union({'host': 'localhost', 'port': 80})
    assert test_dict2['host'] == 'localhost'
    assert test_dict2['port'] == 80
    assert len(test_dict2) == 4

    # test_dict should not be changed by test_dict2
    assert test_dict2['username'] == 'admin'
    assert test_dict2['password'] == 'secret'

    test_dict3 = test_dict2.difference(['password'])
    assert test_dict3['username'] == 'admin'


# Generated at 2022-06-20 15:36:05.011703
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """
    __hash__ is not defined in all versions of Python and can be overriden in subclasses.
    This can cause problems with Python where dictionary keys need to be hashable.
    """
    hash_imm_dict = ImmutableDict(a=1)
    assert hash(hash_imm_dict) == hash(ImmutableDict(a=1))
    assert hash(hash_imm_dict) != hash(ImmutableDict(b=1))
    assert hash(hash_imm_dict) != hash(dict(a=1))
    assert hash(hash_imm_dict) != hash(dict(b=1))



# Generated at 2022-06-20 15:36:15.583817
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(a=1, b=2,c=3)
    d2 = ImmutableDict(a=1, b=2,c=3)
    d3 = ImmutableDict(a=1, b=2,c=4)
    d4 = ImmutableDict()
    d5 = ImmutableDict(a=1, b=2,c=3, d={'x':1, 'y':2})
    d6 = ImmutableDict(a=1, b=2,c=3, d={'x':1, 'y':2})
    d7 = ImmutableDict(a=1, b=2,c=3, d={'x':1, 'y':22})

# Generated at 2022-06-20 15:36:23.337272
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('a string')
    assert is_iterable(b'a bytestring')
    assert is_iterable((1, 2, 3))
    assert is_iterable([1, 2, 3])
    assert is_iterable({1: 2, 3: 4})
    assert is_iterable({1, 2, 3})
    assert is_iterable(1) is False
    assert is_iterable(True) is False
    assert is_iterable(None) is False

# Generated at 2022-06-20 15:36:31.614759
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    import collections
    import operator
    from random import shuffle

    i_dict = ImmutableDict()
    assert hash(i_dict) == hash(dict())

    d = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    i_dict = ImmutableDict(d)
    assert hash(i_dict) == hash(dict(d))

    i_dict = ImmutableDict((('a', 1), ('b', 2), ('c', 3), ('d', 4)))
    assert hash(i_dict) == hash(dict(d))

    i_dict = ImmutableDict((('a', 1), ('b', 2), ('c', 3), ('d', 4)))

# Generated at 2022-06-20 15:36:41.290377
# Unit test for function count
def test_count():
    assert count('') == {}
    assert count(()) == {}
    assert count([]) == {}
    assert count({}) == {}
    assert count([1, 1, 2, 3, 3, 3]) == {1: 2, 2: 1, 3: 3}
    # Strings are iterables, but unfortunately,
    # so are bytes and unicode on Python 2
    assert count('abcd') == {'a': 1, 'b': 1, 'c': 1, 'd': 1}
    assert count('aabc') == {'a': 2, 'b': 1, 'c': 1}
    assert count('aaa') == {'a': 3}

# Generated at 2022-06-20 15:36:45.398178
# Unit test for function is_string
def test_is_string():
    assert is_string("string")
    assert is_string(u"unicode")
    assert is_string("")
    assert is_string(b"bytes")
    assert is_string(b"")
    assert not is_string(None)
    assert not is_string(42)


# Generated at 2022-06-20 15:36:48.359769
# Unit test for function is_string
def test_is_string():
    assert is_string("abc")
    assert is_string(u"abc")
    assert is_string(b"abc")
    assert not is_string([1,2,3])
    assert not is_string((1,2,3))


# Generated at 2022-06-20 15:36:56.371037
# Unit test for function count
def test_count():
    assert count([1, 1, 1, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 5, 5, 6, 7, 'a', 'a', 'a', 'b']) == {
        1: 3,
        2: 3,
        3: 11,
        4: 3,
        5: 2,
        6: 1,
        7: 1,
        'a': 3,
        'b': 1
    }


# Generated at 2022-06-20 15:37:17.324313
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    from ansible.module_utils.common.collections import ImmutableDict

    m = ImmutableDict({1: "one", 2: "two", 3: "three"})
    assert set(m.__iter__()) == set([1, 2, 3])



# Generated at 2022-06-20 15:37:23.324520
# Unit test for function is_sequence
def test_is_sequence():
    sequence = range(10)
    not_sequence = range(10).__iter__()
    string = "string"
    assert is_sequence(sequence)
    assert not is_sequence(not_sequence)
    assert not is_sequence(string)
    assert is_sequence(sequence, include_strings=True)
    assert is_sequence(string, include_strings=True)



# Generated at 2022-06-20 15:37:34.889045
# Unit test for function count
def test_count():
    """
    Check count() function on a set of simple-made test cases
    """
    # Test on a simple str
    assert count('abcabcabc') == {'a': 3, 'b': 3, 'c': 3}
    # Test on a simple list
    assert count([1, 2, 3, 2, 3, 4, 1, 2, 3]) == {1: 2, 2: 3, 3: 3, 4: 1}
    # Test on a simple tuple
    assert count((0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1)) == {0: 7, 1: 5}
    # Test on a simple dict
    assert count({'a': 1, 'b': 1, 'c': 2}) == {'a': 1, 'b': 1, 'c': 2}
    # Test

# Generated at 2022-06-20 15:37:45.650078
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    """Test the union method of the ImmutableDict class with different inputs."""
    # Test the union method with a list
    input_mapping = dict(first='array', second='list', third='dict')
    try:
        value = ImmutableDict(input_mapping).union(['fourth', 'fifth'])
        raise AssertionError('Expected TypeError exception')
    except TypeError:
        pass

    # Test the union method with a dict
    input_mapping = dict(first='array', second='list', third='dict')
    result = ImmutableDict(input_mapping).union(dict(fourth='obj', fifth='Undefined'))
    expected_result = dict(first='array', second='list', third='dict',
                           fourth='obj', fifth='Undefined')
    assert result == expected_result



# Generated at 2022-06-20 15:37:50.452775
# Unit test for function is_string
def test_is_string():
    assert is_string('hello')
    assert is_string(u'hello')
    assert is_string(b'hello')
    assert not is_string(1)
    assert not is_string(dict())
    assert not is_string([1,2])
    assert not is_string(tuple())
    assert not is_string(set())



# Generated at 2022-06-20 15:37:55.163427
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d1 = ImmutableDict()
    assert hash(d1) == hash(frozenset([]))

    d2 = ImmutableDict({'a': 1, 'b': 2})
    d2_frozen = frozenset([('a', 1), ('b', 2)])
    assert hash(d2) == hash(d2_frozen)



# Generated at 2022-06-20 15:38:03.897834
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():

    # Create a dict
    d = {'name': 'tom', 'age': 18}
    d1 = {'name': 'tom', 'age': 19}
    # Create an ImmutableDict
    d2 = ImmutableDict(name='tom', age=18)
    d3 = ImmutableDict(name='tom', age=19)

    # Test the method __hash__
    assert hash(d2) == hash(d)
    assert hash(d2) != hash(d1)
    assert hash(d3) != hash(d)
    assert hash(d3) == hash(d1)



# Generated at 2022-06-20 15:38:07.604307
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence('')
    assert is_sequence([])
    assert not is_sequence(None)
    assert not is_sequence({})
    assert not is_sequence({'a': 1, 'b': 2})
    assert is_sequence((), True)
    assert is_sequence({1, 2})



# Generated at 2022-06-20 15:38:12.897433
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    dict_1 = ImmutableDict(a=1,b=2,c=3)
    dict_2 = ImmutableDict()
    assert repr(dict_1) == "ImmutableDict({'a': 1, 'b': 2, 'c': 3})"
    assert repr(dict_2) == "ImmutableDict({})"


# Generated at 2022-06-20 15:38:15.463603
# Unit test for function is_string
def test_is_string():
    assert is_string(u'unicode')
    assert is_string(b'bytes')
    assert not is_string([1, 2, 3])
    assert not is_string(123)

# Generated at 2022-06-20 15:38:51.594128
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    from six import iteritems
    from collections import Iterator
    for d in [{}, {'a': 1, 2: 3.3}]:
        idict = ImmutableDict(d)
        assert isinstance(idict.__iter__(), Iterator)
        assert dict(idict) == dict(iteritems(d))


# Generated at 2022-06-20 15:38:56.478439
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    '''
    Tester to test the ImmutableDict constructor
    '''
    immutable_dict1 = ImmutableDict()
    immutable_dict2 = ImmutableDict({'key1': 'value1'})
    assert immutable_dict1 != immutable_dict2
    assert immutable_dict2 != immutable_dict1


# Generated at 2022-06-20 15:39:04.722702
# Unit test for function is_iterable
def test_is_iterable():
    # True:
    data = [
        ([], True),
        ([1, 2, 3], True),
        (set(), True),
        (set([1, 2, 3]), True),
        (dict(), True),
        (dict(a=1, b=2, c=3), True),
        (u'abc', True),
        (b'abc', True),
        (object(), True)
    ]

    for arg, expected in data:
        assert(is_iterable(arg) == expected), 'is_iterable({}) should be {}'.format(arg, expected)
        assert(is_iterable(arg, True) == expected), 'is_iterable({}, True) should be {}'.format(arg, expected)

    # False:

# Generated at 2022-06-20 15:39:10.265719
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    immutable_dict = ImmutableDict({'a': 'b', 'c': 'd'})
    assert immutable_dict == {'a': 'b', 'c': 'd'}
    immutable_dict2 = immutable_dict.difference(('a', 'c'))
    assert immutable_dict2 == {}



# Generated at 2022-06-20 15:39:12.935449
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict()
    assert len(d) == 0
    d = ImmutableDict({'a': 1, 'b': 2})
    assert len(d) == 2


# Generated at 2022-06-20 15:39:17.176151
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    keys = ('key1', 'key2', 'key3')
    values = ('val1', 'val2', 'val3')
    f = ImmutableDict(zip(keys, values))
    assert  f[keys[0]] == values[0]
    assert f[keys[1]] == values[1]
    assert f[keys[2]] == values[2]


# Generated at 2022-06-20 15:39:19.687837
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert (repr(ImmutableDict({'key': 'value'})) == "ImmutableDict({'key': 'value'})")


# Generated at 2022-06-20 15:39:28.845398
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    i = ImmutableDict({'a': 1, 'b': 2})
    assert i == i
    assert i != 'hi'
    assert i != 1
    assert i != ImmutableDict({'b': 2, 'a': 1})
    assert i == ImmutableDict({'a': 1, 'b': 2})
    assert not set([i, 'hi', 1, ImmutableDict({'b': 2, 'a': 1}), ImmutableDict({'a': 1, 'b': 2})])
    assert len(set([i, ImmutableDict({'a': 1, 'b': 2})])) == 1


# Generated at 2022-06-20 15:39:30.046850
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    pass


# Generated at 2022-06-20 15:39:39.868728
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Unit test for constructor of class ImmutableDict"""
    # Pass in empty dict
    assert ImmutableDict() == {}

    # Pass in dict with items
    d = ImmutableDict({'a': 1, 'b': 2})
    assert d['a'] == 1
    assert d['b'] == 2
    assert len(d) == 2
    assert 'a' in d and 'b' in d

    d = ImmutableDict({'a': 1, 'b': 2}, {'b': 3})
    # ImmutableDict with new dict added should replace 'b' key
    assert d['b'] == 3
    # 'a' key is not replaced
    assert d['a'] == 1
    assert len(d) == 2
    assert 'a' in d and 'b' in d

    # Construct dict with dict-

# Generated at 2022-06-20 15:40:49.113255
# Unit test for function is_string
def test_is_string():
    assert is_string('test') is True
    assert is_string(b'test') is True
    assert is_string(1) is False
    assert is_string(['test']) is False
    assert is_string((1,)) is False
    assert is_string({'test': 1}) is False



# Generated at 2022-06-20 15:40:54.630854
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    dict = ImmutableDict({"keyA": "valueA", "keyB": "valueB"})
    assert dict["keyA"] == "valueA"
    assert dict["keyB"] == "valueB"
    assert dict.union({"keyC": "valueC"}) == ImmutableDict({"keyA": "valueA", "keyB": "valueB", "keyC": "valueC"})
    assert dict.union({"keyA": "newValueA"}) == ImmutableDict({"keyA": "newValueA", "keyB": "valueB"})

# Generated at 2022-06-20 15:41:00.469981
# Unit test for function is_iterable
def test_is_iterable():
    test_inputs = [123,
                   "abc",
                   bytearray(b"abc"),
                   [1, 2, 3],
                   [123],
                   [],
                   (1, 2, 3),
                   (123,),
                   (),
                   {1: "a", 2: "b", 3: "c"},
                   {123: None},
                   ImmutableDict([("a", 1), ("b", 2), ("c", 3)]),
                   ImmutableDict(),
                   ImmutableDict({123: None})
    ]
    for item in test_inputs:
        assert is_iterable(item) == isinstance(item, (Sequence, MutableMapping))



# Generated at 2022-06-20 15:41:10.265265
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Arrange
    iDict1 = ImmutableDict({'method': 'get', 'url': 'https://api.github.com/user'})
    iDict2 = ImmutableDict({'url': 'https://api.github.com/user', 'method': 'get'})
    iDict3 = ImmutableDict({'method': 'get', 'url': 'https://api.github.com/users'})
    iDict4 = ImmutableDict()

    # Act and Assert
    assert iDict1.__eq__(iDict2)
    assert iDict1.__eq__(iDict3) == False
    assert iDict4.__eq__(iDict3) == False

# Generated at 2022-06-20 15:41:13.227481
# Unit test for function count
def test_count():
    """Test cases for :func:`count`."""
    assert count([]) == {}
    assert count([1]) == {1: 1}
    assert count([1, 1, 1, 2, 2, 3]) == {1: 3, 2: 2, 3: 1}



# Generated at 2022-06-20 15:41:18.872766
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for equality
    a = ImmutableDict({'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4})
    b = ImmutableDict({'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4})
    assert a == b

    # Test for inequality
    c = ImmutableDict({'a': 4, 'b': {'c': 2, 'd': 3}, 'e': 1})
    assert a != c


# Generated at 2022-06-20 15:41:22.988004
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    not_strict_immutable = ImmutableDict({'a': 1, 'b': 2})
    strict_immutable = ImmutableDict({'a': 1, 'b': 2}, b=3, c=4)
    assert strict_immutable == not_strict_immutable.union({'b': 3, 'c': 4})



# Generated at 2022-06-20 15:41:29.605517
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    mapping = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    new_mapping = mapping.union({'b': 'new_b', 'd': 'new_d'})
    assert new_mapping == ImmutableDict({'a': 1, 'b': 'new_b', 'c': 3, 'd': 'new_d'})
    assert mapping == ImmutableDict({'a': 1, 'b': 2, 'c': 3})



# Generated at 2022-06-20 15:41:41.038669
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    from ansible.module_utils.common.removed import removed
    removed('test_ImmutableDict_union', collection_name='ansible_collections.misc')
    original_dict = ImmutableDict({'a': 1, 'b': 2})
    overriding_dict = {'c': 3, 'd': 4}
    union_dict = original_dict.union(overriding_dict)
    expected = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert union_dict == expected

    original_dict = ImmutableDict({'a': 1, 'b': 2})
    overriding_dict = {'a': 0, 'c': 3, 'd': 4}
    union_dict = original_dict.union(overriding_dict)

# Generated at 2022-06-20 15:41:45.561960
# Unit test for function is_string
def test_is_string():
    assert is_string('hi') == True
    assert is_string(u'hi') == True
    class TestClass(object):
        def __init__(self):
            self.prop = 'hi'
    assert is_string(TestClass()) == False
