

# Generated at 2022-06-20 15:33:46.469533
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Hash of an ImmutableDict is equal to a hash of the underlying dict"""
    a = ImmutableDict({'v': '2.6', 'a': 1, 'b': 2, 'c': 3})
    b = {'c': 3, 'a': 1, 'b': 2, 'v': '2.6'}
    assert hash(a) == hash(b)



# Generated at 2022-06-20 15:33:55.101366
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    immutable_dict_orig = ImmutableDict()
    immutable_dict_union = immutable_dict_orig.union({'foo': 'bar'})
    assert immutable_dict_union == {'foo': 'bar'}
    assert type(immutable_dict_union) == ImmutableDict

    immutable_dict_orig = ImmutableDict({'foo': 'bar'})
    immutable_dict_orig2 = ImmutableDict(baz='qux')
    immutable_dict_union = immutable_dict_orig.union(immutable_dict_orig2)
    assert immutable_dict_union == {'foo': 'bar', 'baz': 'qux'}
    assert type(immutable_dict_union) == ImmutableDict

    immutable_dict_orig = ImmutableDict({'foo': 'bar'})
    immutable_

# Generated at 2022-06-20 15:34:06.188775
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_dict_0 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    # test against ImmutableDict
    test_dict_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert test_dict_0 == test_dict_1
    test_dict_2 = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict_0 != test_dict_2
    test_dict_3 = ImmutableDict({'a': 2, 'b': 2, 'c': 3})
    assert test_dict_0 != test_dict_3
    test_dict_4 = ImmutableDict({'a': 1, 'b': 3, 'c': 3})
    assert test_dict_0 != test_dict_4

# Generated at 2022-06-20 15:34:18.459132
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    d = ImmutableDict({"one": 1, "two": 2})
    try:
        d.clear()
    except AttributeError:
        # clear attribute is not found, so it means we can't change the dict
        pass
    else:
        # clear attribute is found, but it should not be there
        assert False, "'d.clear()' is found, but it should not be there"

    try:
        d.popitem()
    except AttributeError:
        # popitem attribute is not found, so it means we can't change the dict
        pass
    else:
        # popitem attribute is found, but it should not be there
        assert False, "'d.popitem()' is found, but it should not be there"


# Generated at 2022-06-20 15:34:20.074698
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict(a=1)) == 1



# Generated at 2022-06-20 15:34:26.459006
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    import pytest
    from ansible.module_utils.common.utils import ImmutableDict
    # Test dict with a mix of int, str, unicode, and complex values
    original_dict = {
        1: '1',
        'two': u'tres',
        '4': 4,
        '5': 5.5,
        '6': (5 + 5j),
    }
    immutable_dict = ImmutableDict(original_dict)
    assert repr(immutable_dict) == "ImmutableDict({0!r})".format(original_dict)

    with pytest.raises(TypeError):
        immutable_dict[0] = 1



# Generated at 2022-06-20 15:34:28.638189
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict({'a':1, 'b':2})) == 2



# Generated at 2022-06-20 15:34:34.749172
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():

    # Test 1: No argument is passed
    immut_dic = ImmutableDict()
    for key in immut_dic:
        assert False, "Error: Object was iterated but it shouldn't be an iterable"

    # Test 2: Argument is passed
    immut_dic = ImmutableDict(a=1, b=2)
    assert frozenset(('a', 'b')) == frozenset(immut_dic), "Error: Object was not iterated correctly"


# Generated at 2022-06-20 15:34:47.543576
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():

    # Scenario: subtract keys from an empty dictionary
    # Expectation: returns an empty dictionary
    d1 = ImmutableDict()
    d2 = ImmutableDict()
    d3 = d1.difference(d2.keys())
    assert len(d3) == 0

    # Scenario: subtract keys from a non-empty dictionary
    # Expectation: returns a dictionary with the same content
    d1 = ImmutableDict({1: 'One'})
    d2 = ImmutableDict({2: 'Two'})
    d3 = d1.difference(d2.keys())
    assert len(d3) == 1
    assert d3 == d1

    # Scenario: subtract keys from a non-empty dictionary
    # Expectation: returns a dictionary with the keys removed

# Generated at 2022-06-20 15:34:48.709529
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict(a=1, b=2, c=3)) == 3



# Generated at 2022-06-20 15:35:03.436974
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # This test is not a real unit test, but rather compares several ImmutableDict instances to
    # see if the __eq__ method works as expected. If an exception is raised the test fails.
    d1 = ImmutableDict({'a': 1, 'c': 2, 'b': 3})
    d2 = ImmutableDict({'a': 1, 'c': 2, 'b': 3})
    d3 = ImmutableDict({'a': 1, 'c': 2, 'b': 4})
    d4 = ImmutableDict({'a': 1, 'c': 2})
    d5 = ImmutableDict({'b': 3, 'a': 1, 'c': 2})
    assert d1 == d2  # Two ImmutableDicts containing the same key-value pairs are equal
    assert d2 == d1  # __

# Generated at 2022-06-20 15:35:13.673930
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d1 = ImmutableDict()
    d2 = ImmutableDict({'x': 1, 'y': 2})
    d3 = ImmutableDict({'x': 1, 'y': 2})
    d4 = ImmutableDict({'y': 2, 'x': 1})
    assert d1.__hash__() == hash(frozenset())
    assert d2.__hash__() == hash(frozenset([('x', 1), ('y', 2)]))
    assert d3.__hash__() == hash(frozenset([('x', 1), ('y', 2)]))
    assert d4.__hash__() == hash(frozenset([('x', 1), ('y', 2)]))


# Generated at 2022-06-20 15:35:20.030615
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """
    Ensure __repr__ returns correct representation of dictionary.
    """
    my_dict = ImmutableDict({"key1": "value1", "key2": "value2"})
    if str(my_dict) != "ImmutableDict({'key1': 'value1', 'key2': 'value2'})":
        raise AssertionError("Repr of ImmutableDict waits for {'key1': 'value1', 'key2': 'value2'}")



# Generated at 2022-06-20 15:35:31.707225
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable(())
    assert is_iterable(set())
    assert not is_iterable('ABC')
    assert not is_iterable(55)
    assert not is_iterable(['A', 'B', 55])
    assert not is_iterable(set(['A', 'B', 55]))
    assert not is_iterable(('A', 'B', 55))
    assert is_iterable('ABC', include_strings=True)
    assert is_iterable(['A', 'B', 55], include_strings=True)
    assert is_iterable(set(['A', 'B', 55]), include_strings=True)
    assert is_iterable(('A', 'B', 55), include_strings=True)



# Generated at 2022-06-20 15:35:35.825878
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    source = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert len(source) == 3



# Generated at 2022-06-20 15:35:42.261225
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """
    Tests for the __hash__ method of the class ImmutableDict.
    """
    from ansible.module_utils.six import PY3

    if PY3:
        import pytest
        pytest.skip("Cannot test __hash__ under Python 3")

    mydict = ImmutableDict({'password': 'secret'})
    assert hash(mydict) == hash((('password', 'secret'),))



# Generated at 2022-06-20 15:35:45.609931
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    idict = ImmutableDict(a=1, b=2, c=3)
    assert idict['a'] == 1
    assert idict['b'] == 2
    assert idict['c'] == 3


# Generated at 2022-06-20 15:35:52.409757
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    '''
    Unit test for method __repr__ of class ImmutableDict
    :return:
    '''
    test_dictionary = {"key1": "value1", "key2": "value2"}
    test_immutable_dict = ImmutableDict(test_dictionary)
    assert repr(test_immutable_dict) == "ImmutableDict({'key1': 'value1', 'key2': 'value2'})"


# Generated at 2022-06-20 15:36:00.708325
# Unit test for function is_iterable
def test_is_iterable():
    # is_iterable() should return True for iterable types
    class TestClass:
        def __iter__(self):
            pass

    class TestClass2(object):
        def __iter__(self):
            pass

    class TestClass3(object):
        pass

    assert(is_iterable(test_iterable) is True)
    assert(is_iterable(TestClass()) is True)
    assert(is_iterable(TestClass2()) is True)
    assert(is_iterable(TestClass3()) is False)

    # is_iterable() should return True for all sequences, except for str and bytes, by default
    # (unless include_strings is explicitly set to True)
    assert(is_iterable([]) is True)
    assert(is_iterable(set()) is True)

# Generated at 2022-06-20 15:36:04.571236
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    test_data = ImmutableDict({"a": 1, "b": 2, "c": 3})
    assert(test_data.union({"b": 4, "foo": "bar"}) == ImmutableDict({"a": 1, "b": 4, "c": 3, "foo": "bar"}))


# Generated at 2022-06-20 15:36:20.032723
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    """
    Make sure that ImmutableDict.__iter__ works as expected
    """
    # TODO: remove explicit import
    from ansible.module_utils.common._collections_compat import OrderedDict

    expected_dict = OrderedDict([(2, 3), (1, 'test'), ('a', True), ('c', [1, 2, 3, 4]), ('d', {'e': 1})])
    test_dict = ImmutableDict(expected_dict)

    for key in expected_dict:
        assert key in test_dict.keys()



# Generated at 2022-06-20 15:36:24.611730
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original_dict = ImmutableDict(a=1, b=2, c=3)
    subtracted_keys = ('a', 'c')
    expected_dict = ImmutableDict(b=2)
    result_dict = original_dict.difference(subtracted_keys)
    assert result_dict == expected_dict

# Generated at 2022-06-20 15:36:34.041129
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # Positive test case:
    # Confirm that an ImmutableDict is created with expected difference
    # between the original and subtractive_iterable
    original = ImmutableDict({"key1": "value1", "key2": "value2", "key3": "value3"})
    subtractive_iterable = ["key3", "key4"]
    expected = ImmutableDict({"key1": "value1", "key2": "value2"})
    assert original.difference(subtractive_iterable) == expected



# Generated at 2022-06-20 15:36:44.536760
# Unit test for function is_sequence
def test_is_sequence():
    from collections import deque, namedtuple

    seqs = [
        [], (), (1,),
        set(), frozenset(),
        range(0),
        deque(),
        namedtuple('namedseq', 'attr')(attr=''),
        # Sequence classes that behave as mappings
        # (e.g. are indexed with a non-integer 'key')
        text_type(),
        byte_type(),
        # Non-sequence classes that call __iter__ and __len__ magic methods
        # (e.g. has __iter__ and __len__, but behaves neither as a sequence
        # nor as a mapping)
        object()
    ]
    non_seqs = [
        None,
        # Non-sequence classes that don't call magic methods
        object,
    ]


# Generated at 2022-06-20 15:36:49.623259
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    dict1 = ImmutableDict({'a': 'b', 'c': 'd'})
    dict2 = ImmutableDict({'a': 'b2', 'e': 'f'})
    dict3 = dict1.union(dict2)
    assert dict1['a'] == 'b'
    assert dict2['a'] == 'b2'
    assert dict3['a'] == 'b2'
    assert dict1['e'] is None
    assert dict2['e'] == 'f'
    assert dict3['e'] == 'f'

# Generated at 2022-06-20 15:36:58.727791
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # checking if user provided hash method works as expected by creating a immutable
    # dictionary from a dictionary that has user provided __hash__ method.
    class A(object):
        def __init__(self, a):
            self.a = a

        def __eq__(self, other):
            return (isinstance(other, type(self)) and
                    self.a == other.a)

        def __hash__(self):
            return hash(self.a)

    imm_dict = ImmutableDict({A('a'): 'value'})
    assert hash(imm_dict) == hash(ImmutableDict({A('a'): 'value'}))



# Generated at 2022-06-20 15:37:05.829226
# Unit test for function is_sequence
def test_is_sequence():
    sequence = [
        [],
        (1, 2, 3),
        [1, 2, 3],
        # Set
        {1, 2, 3},
        # Range
        range(1, 3),
        # ImmutableDict
        ImmutableDict({'a': 1, 'b': 2}),
    ]

    for item in sequence:
        assert is_sequence(item) is True

    non_sequence = [
        {'a': 1, 'b': 2},
        # MutablMapping
        MutableMapping,
        # String
        'a',
    ]

    for item in non_sequence:
        assert is_sequence(item) is False



# Generated at 2022-06-20 15:37:08.457624
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict(a=1, b=2)
    a = d['a']
    assert a == 1
    assert d['c'] == KeyError


# Generated at 2022-06-20 15:37:15.792125
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict()
    b = ImmutableDict()
    assert a == b
    assert a == {}
    assert not (a == set())

    a = ImmutableDict({'a': 1})
    b = ImmutableDict({'a': 1})
    assert a == b

    b = ImmutableDict({'a': 2})
    assert not (a == b)
    assert not (a == {'b': 1})
    assert not (a == {'a': 1, 'b': 2})

    b = a.union({'b': 2})
    assert not (a == b)

    a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    b = ImmutableDict({'c': 3, 'a': 1, 'b': 2})

# Generated at 2022-06-20 15:37:18.201105
# Unit test for function is_string
def test_is_string():
    assert is_string(u"test") == True
    assert is_string(b"test") == True
    assert is_string(None) == False
    assert is_string(42) == False
    assert is_string(["test"]) == False
    assert is_string((u"test",)) == False


# Generated at 2022-06-20 15:37:40.884813
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    def setUp():
        test_dict = ImmutableDict({"first_key": "first_value", "second_key": "second_value"})
        test_dict.__getitem__("first_key")
        return test_dict

    def test_correct_item():
        assert test_dict.__getitem__("first_key") == "first_value"

    def test_wrong_item():
        assert test_dict.__getitem__("third_key") != "third_value"



# Generated at 2022-06-20 15:37:52.339179
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():

    # Test with a regular dictionary as source for ImmutableDict
    source_dict = {'a': 1, 'b': 2}
    im_dict = ImmutableDict(source_dict)
    assert im_dict['a'] == 1
    assert im_dict['b'] == 2

    # Test with a dictionary containing a dictionary as source for ImmutableDict
    # and a missing key
    source_dict = {'a': 1, 'b': {'c': 2, 'd': 3}}
    im_dict = ImmutableDict(source_dict)
    assert im_dict['a'] == 1
    assert im_dict['b'] == {'c': 2, 'd': 3}
    try:
        im_dict['c']
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-20 15:37:55.123106
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    assert sorted(list(ImmutableDict({'a': 1, 'b': 2, 'c': 3}))) == ['a', 'b', 'c']



# Generated at 2022-06-20 15:38:02.205545
# Unit test for function is_sequence
def test_is_sequence():
    """Test method used in unit tests in unit_test_is_sequence."""
    import collections
    import six

    assert is_sequence([1, 2, 3])
    assert is_sequence((1, 2, 3))
    assert not is_sequence(set([1, 2, 3]))
    assert is_sequence(collections.deque([1, 2, 3]))
    assert is_sequence(collections.Counter([1, 2, 3]))
    assert not is_sequence({'1': 1, '2': 2, '3': 3})
    assert is_sequence(u'abc')
    assert is_sequence(six.binary_type(b'abc'))
    assert not is_seq

# Generated at 2022-06-20 15:38:10.708555
# Unit test for function count
def test_count():
    # pylint: disable=C0111,C0103
    from copy import copy
    from unittest import TestCase
    from numbers import Number

    class count_TestCase(TestCase):
        """Class for testing the count function"""

        def setUp(self):
            """Sets up the env for running tests"""
            pass

        def tearDown(self):
            """Returns the env to previous state after running tests"""
            pass

        def test_empty_list(self):
            """Tests count with empty lists"""
            self.assertEqual(count([]), dict(), 'Failed when given an empty list')

        def test_empty_string(self):
            """Tests count with empty strings"""
            self.assertRaises(Exception, count, '')


# Generated at 2022-06-20 15:38:14.060585
# Unit test for function is_string
def test_is_string():
    assert is_string(u'a')
    assert is_string(b'a')
    assert not is_string([u'a'])
    assert not is_string([b'a'])



# Generated at 2022-06-20 15:38:23.319579
# Unit test for function count
def test_count():
    from pytest import raises
    from collections import Counter

    # test count on list
    assert count([1, 2]) == Counter([1, 2])
    result = count([1, 1, 2, 3])
    expected = {1: 2, 2: 1, 3: 1}
    assert result == expected
    assert count([]) == Counter([])

    # test count on string
    assert count('abcd') == Counter('abcd')
    result = count('aaaa')
    expected = {'a': 4}
    assert result == expected
    assert count('') == Counter('')

    # test count on other iterable
    result = count(range(5))
    expected = {0: 1, 1: 1, 2: 1, 3: 1, 4: 1}
    assert result == expected

# Generated at 2022-06-20 15:38:32.653598
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """
    Test that __hash__ method of ImmutableDict is consistent
    """

    # Test 1:
    # Test that hash values of instances of ImmutableDict are equal to hash of frozenset
    # with the same key-value values

    # Build a sample dictionary
    key1 = "key1"
    key2 = "key2"
    value1 = "value1"
    value2 = "value2"
    sample_dictionary = {key1: value1, key2: value2}
    frozenset_with_same_elements = frozenset(sample_dictionary.items())

    # Build instance of ImmutableDict from sample dictionary
    immutable_dict = ImmutableDict(sample_dictionary)

    # Test that hash values are equal

# Generated at 2022-06-20 15:38:39.110258
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'b': 2, 'a': 1})
    dict3 = ImmutableDict({'b': 2, 'a': 1, 'c': 3})
    dict4 = ImmutableDict({'d': 1, 'b': 2, 'a': 1})
    dict5 = ImmutableDict({'a': 1, 'b': 2}, c=3)

    assert dict1 == dict1
    assert dict1 == dict2
    assert dict1 != dict3
    assert dict1 != dict4
    assert dict1 != dict5

# Generated at 2022-06-20 15:38:41.998782
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    x = ImmutableDict({"a": 1, "b": 2})
    assert x.__repr__() == "ImmutableDict({'a': 1, 'b': 2})"


# Generated at 2022-06-20 15:39:20.242353
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict()
    b = ImmutableDict()

    assert(a.__eq__(b))

    a = ImmutableDict({"foo": 123, "bar": 456})
    b = ImmutableDict({"foo": 123, "bar": 456})

    assert(a.__eq__(b))

    a = ImmutableDict({"foo": 123, "bar": 456})
    b = ImmutableDict({"bar": 456, "foo": 123})

    assert(a.__eq__(b))

    a = ImmutableDict({"foo": 123, "bar": 456})
    b = ImmutableDict({"bar": 456, "foo": 122})

    assert(not a.__eq__(b))


# Generated at 2022-06-20 15:39:22.468551
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    test_dict = ImmutableDict(a=1, b=2, c=3)
    for k in test_dict.__iter__():
        assert k in ['a', 'b', 'c']


# Generated at 2022-06-20 15:39:33.765307
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # Testcase 1
    d1 = ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    d2 = ImmutableDict({'key1': 'value4', 'key2': 'value5', 'key3': 'value6'})
    d3 = ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    assert hash(d1)
    assert hash(d2)
    assert hash(d1) == hash(d3)
    assert hash(d1) != hash(d2)
    assert d1 == d3
    assert d1 != d2
    # Testcase 2

# Generated at 2022-06-20 15:39:37.586547
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    from nose.tools import assert_equal
    from . import ImmutableDict
    mydict = ImmutableDict({'foo': 'bar', 'baz': 'qux'})
    assert_equal(len(mydict), 2)



# Generated at 2022-06-20 15:39:40.180333
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    with pytest.raises(NotImplementedError):
        ImmutableDict({'a': 1, 'b': 2, 'c': 3}).__repr__()

# Generated at 2022-06-20 15:39:42.367880
# Unit test for function is_string
def test_is_string():
    assert is_string('test')
    assert is_string(u'test')
    assert is_string(b'test')



# Generated at 2022-06-20 15:39:46.319850
# Unit test for function count
def test_count():
    assert count([1, 2, 1]) == {1: 2, 2: 1}
    assert count(('apple', 'banana')) == {'apple': 1, 'banana': 1}
    assert count((1, 2, 3, 2, 1)) == {1: 2, 2: 2, 3: 1}



# Generated at 2022-06-20 15:39:47.991503
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    my_dict = ImmutableDict({'a': 1, 'b': 2})
    assert len(my_dict) == 2


# Generated at 2022-06-20 15:39:59.666379
# Unit test for function is_iterable
def test_is_iterable():
    # make sure that ImmutableDict is not iterable
    if is_iterable(ImmutableDict()):
        raise TypeError('ImmutableDict must not be iterable')

    # make sure that ImmutableDict is iterable when explicitly asked
    if not is_iterable(ImmutableDict(), include_strings=True):
        raise TypeError('ImmutableDict must be iterable as strings')

    # make sure that immutable containers are not iterable
    if is_iterable(frozenset()):
        raise TypeError('frozenset must not be iterable')

    if is_iterable(None):
        raise TypeError('NoneType must not be iterable')

    if is_iterable((x for x in range(5))):
        raise TypeError('generator must not be iterable')


# Generated at 2022-06-20 15:40:06.560167
# Unit test for function count
def test_count():
    import pytest

    with pytest.raises(Exception) as e:
        count(3)
    assert "Argument provided  is not an iterable" in str(e.value)

    assert count([]) == {}
    assert count([1, 2, 3, 2, 1]) == {1: 2, 2: 2, 3: 1}
    assert count('any string') == {'a': 1, 'n': 2, 'y': 1, ' ': 1, 's': 1, 't': 1, 'r': 1, 'i': 1, 'g': 1}
    assert count(['abc', 'abc', 'abc']) == {'abc': 3}



# Generated at 2022-06-20 15:41:13.756981
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    from ansible.module_utils.common.collections import ImmutableDict
    testdict = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    otherdict = testdict.difference(['a', 'b'])
    assert otherdict == {'c': 3, 'd': 4}
    assert not isinstance(otherdict, ImmutableDict)
    assert not isinstance(otherdict, MutableMapping)

# Generated at 2022-06-20 15:41:18.792029
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    d1 = ImmutableDict(a=1, b=2, c=3)
    d2 = d1.union({'b': 4, 'd': 5})
    d1['b'] = 10

    assert len(d1) == 3
    assert d1 == ImmutableDict(a=1, b=2, c=3)
    assert d2 == ImmutableDict(a=1, b=4, c=3, d=5)



# Generated at 2022-06-20 15:41:23.174532
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    id_1 = ImmutableDict({"a": 1, "b": 2})
    id_2 = ImmutableDict({"a": 1, "b": 2})
    id_3 = ImmutableDict({"a": 2, "b": 3})

    assert id_1 == id_2
    assert id_1 != id_3
    assert id_1 != "id_1"
    assert id_1 != {"a": 1, "b": 2}
    assert id_1 != {"b": 2, "a": 1}


# Generated at 2022-06-20 15:41:26.026016
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict(a='a', b='b')
    new = {'c': 'c', 'd': 'd'}
    updated = original.union(new)
    assert updated['a'], 'a'
    assert updated['b'], 'b'
    assert updated['c'], 'c'
    assert updated['d'], 'd'


# Generated at 2022-06-20 15:41:30.629210
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d = {'a': 1, 'b': 2}
    e = {'b': 2, 'a': 1}
    f = {'a': 1}
    h = ImmutableDict(d)
    i = ImmutableDict(e)
    j = ImmutableDict(f)

    assert hash(h) == hash(i)
    assert hash(h) != hash(j)


# Generated at 2022-06-20 15:41:33.955726
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    data = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert data['a'] == 1
    assert data['b'] == 2
    assert data['c'] == 3



# Generated at 2022-06-20 15:41:45.563752
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """ImmutableDict.__eq__ raises TypeError if its argument is mutable"""
    idict_mutable = ImmutableDict({'a': 1})
    mdict_mutable = {'a': 1}
    idict_immutable = ImmutableDict({'a': 1})
    mdict_immutable = {'a': 1}
    idict_immutable_equal = ImmutableDict({'a': 1})
    mdict_immutable_equal = {'a': 1}
    idict_immutable_different = ImmutableDict({'a': 2})
    mdict_immutable_different = {'a': 2}

    # ImmutableDict should be equal to itself
    assert idict_immutable == idict_immutable

    # ImmutableDict should be equal to another ImmutableDict with

# Generated at 2022-06-20 15:41:54.748370
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d = ImmutableDict({'a': '1', 'b': '2', 'c': '3'})
    d_alt = ImmutableDict({'a': '1', 'b': '2', 'c': '3'})
    d_diff = ImmutableDict({'a': '1', 'b': '2', 'c': '3', 'd': '4'})

    assert d == d_alt
    assert d != d_diff
    assert d == {'a': '1', 'b': '2', 'c': '3'}
    assert d == {'c': '3', 'a': '1', 'b': '2'}
    assert d != {'a': '1', 'b': '2'}


# Generated at 2022-06-20 15:41:57.733900
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(None)
    assert is_iterable([])
    assert not is_iterable("")
    assert not is_iterable("abc")


# Generated at 2022-06-20 15:42:01.859298
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    x = ImmutableDict({'one': 1, 'two': 2})
    assert repr(x) == 'ImmutableDict({\'one\': 1, \'two\': 2})', \
        "ImmutableDict({'one': 1, 'two': 2}) is not a valid representation for ImmutableDict"
