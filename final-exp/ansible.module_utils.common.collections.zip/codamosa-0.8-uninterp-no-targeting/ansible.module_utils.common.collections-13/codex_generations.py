

# Generated at 2022-06-20 15:33:45.811405
# Unit test for function is_iterable
def test_is_iterable():
    # dictionaries
    assert is_iterable(dict())
    assert is_iterable(dict(one=1))

    # lists
    assert is_iterable(list())
    assert is_iterable(list((1, 2, 3)))
    assert is_iterable([])
    assert is_iterable([1, 2, 3])

    # tuples
    assert is_iterable(tuple())
    assert is_iterable(tuple((1, 2, 3)))
    assert is_iterable((1, 2, 3))

    # sets
    assert is_iterable(set())
    assert is_iterable(set((1, 2, 3)))

    # generators
    def generator():
        yield 1

    assert is_iterable(generator())

    # iterables

# Generated at 2022-06-20 15:33:50.530022
# Unit test for function is_iterable
def test_is_iterable():
    # Python2 and 3 compatible way to create a list.
    assert is_iterable(iter([]))
    assert not is_iterable([])
    assert not is_iterable(())
    assert not is_iterable({})
    assert not is_iterable(None)
    assert not is_iterable(0)
    assert not is_iterable('')


# Generated at 2022-06-20 15:33:55.911174
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    assert hash(ImmutableDict({'a': 1, 'b': 2})) == hash(ImmutableDict({'a': 1, 'b': 2}))



# Generated at 2022-06-20 15:33:59.477443
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    test_dict = ImmutableDict({"foo": "bar", "ans": "ble"})
    assert len(test_dict) == 2

    test_dict = ImmutableDict()
    assert len(test_dict) == 0



# Generated at 2022-06-20 15:34:11.175440
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    test_immutable_dict = ImmutableDict({'one': 'eins', 'two': 'zwei'})
    test_dict = {'three': 'drei'}
    test_override_dict = {'one': 'uno'}
    test_multiple_override_dict = {'one': 'uno', 'two': 'dos'}
    test_simple_dict = {'one': 'uno', 'two': 'dos', 'three': 'tres'}
    test_multiple_dict = {'one': 'uno', 'two': 'dos', 'three': 'tres', 'four': 'cuatro'}

    assert test_immutable_dict.union(test_dict) == ImmutableDict(test_simple_dict)

# Generated at 2022-06-20 15:34:14.884550
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    test_dict = ImmutableDict({'key1': 'val1', 'key2': 'val2'})
    for key in test_dict:
        print(key)



# Generated at 2022-06-20 15:34:22.503419
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """Unit test case for method __len__ of class ImmutableDict"""
    # Create a simple list
    elems = [1, 2, 3, 4]
    # Create a dictionary from this list
    elems_dict = dict(((elem, elem) for elem in elems))
    # Create an ImmutableDict from this dictionary
    idict = ImmutableDict(elems_dict)
    # Check the length
    assert len(idict) == 4, "Number of elements in the dictionary is not equal to 4."


# Generated at 2022-06-20 15:34:34.140497
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    assert ImmutableDict({1: "one", 2: "two"}) == ImmutableDict({2: "two", 1: "one"})
    assert ImmutableDict({1: "one"}) != ImmutableDict({1: "two"})
    assert len(ImmutableDict({'one': 1, 'two': 2, 'three': 3})) == 3
    assert hash(ImmutableDict({'one': 1, 'two': 2, 'three': 3})) == hash(frozenset([('two', 2), ('three', 3), ('one', 1)]))

    assert ImmutableDict({'one': 1, 'two': 2, 'three': 3}).union({'four': 4}) == ImmutableDict({'one': 1, 'two': 2, 'three': 3, 'four': 4})

# Generated at 2022-06-20 15:34:44.513345
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    print('Testing ImmutableDict.__getitem__')
    print('')

    # Prepare
    d = ImmutableDict({'key': 'value'})

    # Pre-assert
    print('Testing preconditions')
    assert 'key' in d

    # Run
    print('Running ImmutableDict.__getitem__')
    v = d['key']

    # Post-assert
    print('Testing postconditions')
    assert 'key' in d
    assert d['key'] == 'value'
    assert v == 'value'

    print('ImmutableDict.__getitem__ tested successfully')
    print('')


# Generated at 2022-06-20 15:34:49.527624
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'key': 'value', 'foo': 'bar'})
    d2 = ImmutableDict({'key': 'value', 'foo': 'bar'})
    d3 = ImmutableDict({'key': 'value', 'foo': 'baz'})
    d4 = MutableMapping({'key': 'value', 'foo': 'bar'})
    d5 = {'key': 'value', 'foo': 'bar'}
    assert d1 == d2
    assert d1 != d3
    assert d1 != d4
    assert d1 != d5


# Generated at 2022-06-20 15:35:03.063047
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    assert ImmutableDict().__getitem__(1) is KeyError
    assert ImmutableDict().__getitem__(None) is KeyError
    assert ImmutableDict({1: 2, None: 1}).__getitem__(1) == 2
    assert ImmutableDict({1: 2, None: 1}).__getitem__(None) == 1
    assert ImmutableDict({1: 2, None: 1}).__getitem__(None) is not 2
    assert ImmutableDict({1: 2, None: 1}).__getitem__(1) is not 1

# Generated at 2022-06-20 15:35:09.421518
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    original_dict = ImmutableDict({'a': 1, 'b': 2})
    assert original_dict == ImmutableDict({'a': 1, 'b': 2})
    assert original_dict != ImmutableDict({'a': 1, 'b': 5})
    assert original_dict != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert original_dict != {'a': 1, 'b': 2}



# Generated at 2022-06-20 15:35:13.586497
# Unit test for function count
def test_count():
    thelist = ['a', 'a', 'b', 'c', 'c', 'c']
    expected = {'a': 2, 'b': 1, 'c': 3}
    assert count(thelist) == expected



# Generated at 2022-06-20 15:35:20.555823
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    m1 = ImmutableDict(a=1, b=2)
    assert m1.difference(('a', 'b')) == ImmutableDict()
    assert m1.difference(['a', 'b']) == ImmutableDict()
    assert m1.difference({'a': 1, 'b': 2}) == ImmutableDict()
    assert m1.difference(set(['a', 'b'])) == ImmutableDict()
    assert set(m1.difference({'a': 1}).keys()) == {'b'}



# Generated at 2022-06-20 15:35:25.591356
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    from nose.tools import assert_raises

    mydict = ImmutableDict()
    mydict['key'] = 'value'

    assert mydict['key'] == 'value'

    with assert_raises(KeyError):
        assert mydict['non_existing_key']


# Generated at 2022-06-20 15:35:30.621818
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert repr(ImmutableDict()) == 'ImmutableDict({})'
    assert repr(ImmutableDict({})) == 'ImmutableDict({})'
    assert repr(ImmutableDict({1: 2})) == "ImmutableDict({1: 2})"



# Generated at 2022-06-20 15:35:37.546279
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = {'a': 1, 'b': 2, 'c': 3}
    idict = ImmutableDict(original)
    subtractive = {'b', 'd'}
    assert idict.difference(subtractive) == ImmutableDict({'a': 1, 'c': 3})


# Generated at 2022-06-20 15:35:48.513148
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit testing of ImmutableDict.__eq__ method"""
    import pytest
    d1 = ImmutableDict()
    d2 = ImmutableDict()
    assert d1 == d2

    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'b': 2, 'a': 1})
    assert d1 == d2

    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert not d1 == d2

    d1 = ImmutableDict({'a': 1})
    d2 = ImmutableDict({'e': '2'})
    assert not d1 == d2

    d1 = ImmutableDict({'a': 1})
    d2 = ImmutableDict()
    assert not d1 == d

# Generated at 2022-06-20 15:35:51.883155
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    immutable_dict = ImmutableDict({'key': 'value'})
    assert immutable_dict.__repr__() == "ImmutableDict({'key': 'value'})"


# Generated at 2022-06-20 15:35:56.892244
# Unit test for function is_string
def test_is_string():
    assert is_string(u'foo')
    assert is_string('foo')
    assert is_string(b'foo')
    assert not is_string({})
    assert not is_string([])
    assert not is_string(1)
    assert not is_string(1.1)
    assert not is_string(set())
    assert not is_string(frozenset())



# Generated at 2022-06-20 15:36:11.594830
# Unit test for function is_string
def test_is_string():
    from ansible.module_utils.six import text_type, binary_type

    assert is_string("string")
    assert is_string(text_type("string"))
    assert is_string(binary_type("string"))
    assert is_string(b"string")
    assert not is_string([])
    assert not is_string((1,))
    assert not is_string({})
    assert not is_string(1)



# Generated at 2022-06-20 15:36:22.613043
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """Unit test for method difference of class ImmutableDict."""
    class OrderingList(Sequence):
        def __init__(self, *items):
            try:
                if hash(items) == hash(tuple(items)):
                    self._items = tuple(items)
                else:
                    raise TypeError('OrderingList argument is unhashable')
            except TypeError:
                raise TypeError('OrderingList argument is unhashable')

        def __getitem__(self, index):
            return self._items[index]

        def __len__(self):
            return len(self._items)

        def index(self, value):
            return self._items.index(value)

    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})

# Generated at 2022-06-20 15:36:31.105825
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    # Test the construction and getitem methods
    test_dict = ImmutableDict(a=1, b=2, c=3)
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3

    # Test the unio method
    union_dict = test_dict.union({'d': 4, 'e': 5})
    assert union_dict['a'] == 1
    assert union_dict['b'] == 2
    assert union_dict['c'] == 3
    assert union_dict['d'] == 4
    assert union_dict['e'] == 5

    # Test the difference method
    diff_dict = union_dict.difference('de')
    assert diff_dict['a'] == 1
    assert diff_dict['b'] == 2
    assert diff_

# Generated at 2022-06-20 15:36:35.891863
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([]) == True
    assert is_sequence(()) == True
    assert is_sequence(set()) == False
    assert is_sequence({}) == False
    assert is_sequence("string") == False
    assert is_sequence("string", True) == True
    assert is_sequence("string", False) == False

# Generated at 2022-06-20 15:36:45.533785
# Unit test for function is_sequence
def test_is_sequence():

    class TestClass(object):
        def __init__(self, x):
            self.x = x

        def __getitem__(self, item):
            return self.x[item]

    assert not is_sequence(None)
    assert not is_sequence(42)
    assert is_sequence(u'hello')
    assert is_sequence(b'hello')
    assert is_sequence([])
    assert is_sequence((1, 2, 3))
    assert is_sequence({1: 'first', 2: 'second'})
    assert is_sequence(set())
    assert not is_sequence(TestClass([]))
    assert not is_sequence(TestClass('hello'))



# Generated at 2022-06-20 15:36:49.671292
# Unit test for function is_string
def test_is_string():
    assert is_string('str')
    assert is_string(u'unicode')
    assert is_string(b'bytes')
    assert not is_string([])
    assert not is_string({})
    assert not is_string(ImmutableDict())
    assert not is_string(object())



# Generated at 2022-06-20 15:36:55.332979
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    dict = ImmutableDict({"a": "1", "b": "2", "c": "3", "d": "4"})
    dict_new = dict.difference(["a", "e", "d"])
    assert(len(dict_new) == 2)
    assert(dict_new == ImmutableDict({"b": "2", "c": "3"}))

# Generated at 2022-06-20 15:37:00.609837
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """Testing ImmutableDict.__len__()"""

    # Testing with an empty ImmutableDict
    test_dict = ImmutableDict()
    assert len(test_dict) == 0

    # Testing with an ImmutableDict with values
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    assert len(test_dict) == 4



# Generated at 2022-06-20 15:37:06.722328
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    from future.utils import PY2
    from future.builtins import range

    d = ImmutableDict()
    assert hash(d) == hash(frozenset())
    for i in range(10):
        d = d.union({i: i})
        assert hash(d) == hash(frozenset(list(zip(list(range(i + 1)), list(range(i + 1))))))

    if not PY2:
        assert hash(d) == hash(dict(list(zip(list(range(i + 1)), list(range(i + 1))))))



# Generated at 2022-06-20 15:37:12.761439
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    ''' Test method ImmutableDict.__eq__ with ImmutableDict as param '''
    a = ImmutableDict({'a': 'b', 'c': 'd'})
    b = ImmutableDict({'a': 'b', 'c': 'd'})
    assert a == b, 'TestImmutableDict: Two ImmutableDict objects with same content are not equal'
    a = ImmutableDict({'a': 'b', 'c': 'd'})
    b = ImmutableDict({'a': 'b', 'c': 'd', 'e': 'f'})
    assert a != b, 'TestImmutableDict: Two ImmutableDict objects with same keys and different content are equal'
    a = ImmutableDict({'a': 'b', 'c': 'd'})
    b = Imm

# Generated at 2022-06-20 15:37:39.559773
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    immutable_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    immutable_dict_keys = []
    for key in immutable_dict:
        immutable_dict_keys.append(key)
    assert immutable_dict_keys == ['a', 'b', 'c']


# Generated at 2022-06-20 15:37:41.507252
# Unit test for function count
def test_count():
    l = [1, 2, 3, 3, 3, 4, 4, 5]
    assert count(l) == {1: 1, 2: 1, 3: 3, 4: 2, 5: 1}

# Generated at 2022-06-20 15:37:51.814959
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    src_dict = ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    input_dict = {'key1': 'value1_replacement', 'key4': 'value4'}
    expected_dict = {'key1': 'value1_replacement', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4'}
    result_dict = src_dict.union(input_dict)

    assert len(result_dict) == len(expected_dict)
    for entry in result_dict:
        assert entry in expected_dict
        assert result_dict[entry] == expected_dict[entry]



# Generated at 2022-06-20 15:37:55.657079
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    imd = ImmutableDict(a=1)
    actual = imd.union({'a': 2, 'b': 3})
    assert actual == ImmutableDict(a=2, b=3)



# Generated at 2022-06-20 15:37:59.077041
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})

    assert d1['a'] == 1
    assert d1['b'] == 2
    assert d1['c'] == 3
    assert d1['d'] == 4


# Generated at 2022-06-20 15:38:04.564383
# Unit test for function count
def test_count():
    result = count('mississippi')
    assert result['i'] == 4
    assert result['s'] == 4
    assert result['m'] == 1
    assert result['p'] == 2
    try:
        count(1)
    except Exception:
        pass
    else:
        raise Exception('An exception was expected')



# Generated at 2022-06-20 15:38:09.358360
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():

    # Create an empty dictionary
    empty_dict = ImmutableDict()
    assert len(empty_dict) == 0

    # Create a standard dictionary
    dict = ImmutableDict({'a': 1})
    assert len(dict) == 1



# Generated at 2022-06-20 15:38:14.722171
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(key1='val1', key2='val2')
    d2 = ImmutableDict(key1='val1', key2='val2')
    d3 = dict(key1='val1', key2='val2')
    assert d1 == d2
    assert d1 != d3


# Generated at 2022-06-20 15:38:19.475401
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    # Arrange
    test_items = ImmutableDict({'a': 1, 'b': 2})
    # Act
    res = [key for key in test_items]
    # Assert
    assert len(res) == 2
    assert 'a' in res and 'b' in res


# Generated at 2022-06-20 15:38:23.996265
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    test_dict = {'alpha': 1, 'beta': 2, 'gamma': 3}
    immutable_dict = ImmutableDict(test_dict)

    assert immutable_dict['alpha'] == 1
    assert immutable_dict['beta'] == 2
    assert immutable_dict['gamma'] == 3



# Generated at 2022-06-20 15:39:05.820396
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    keys = ["1", "2", "3"]
    # test for dict
    value = ImmutableDict({"1": 100, "2": 200, "3": 300})
    result = sorted(list(value))
    if result != keys:
        raise Exception('test_ImmutableDict___iter__ failed for dict.\n Expected keys: {0}\n Result: {1}'.format(keys, result))
    # test for kwargs
    value = ImmutableDict(**{"1": 100, "2": 200, "3": 300})
    result = sorted(list(value))
    if result != keys:
        raise Exception('test_ImmutableDict___iter__ failed for kwargs.\n Expected keys: {0}\n Result: {1}'.format(keys, result))


# Generated at 2022-06-20 15:39:15.552314
# Unit test for function is_sequence
def test_is_sequence():
    """Tests for function is_sequence."""
    from ansible.module_utils.basic import AnsibleVaultEncryptedUnicode

    assert is_sequence([])
    assert not is_sequence([], include_strings=True)
    assert is_sequence((), include_strings=True)
    assert not is_sequence(u'', include_strings=False)
    assert is_sequence(u'', include_strings=True)
    assert not is_sequence(b'', include_strings=False)
    assert is_sequence(b'', include_strings=True)

    encrypted = AnsibleVaultEncryptedUnicode(u'34EC21')
    assert is_sequence(encrypted, include_strings=False)
    assert is_sequence(encrypted, include_strings=True)



# Generated at 2022-06-20 15:39:23.002382
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    test_dict = ImmutableDict({'key1': 'value1', 'key2': 'value2'})

    # Test __getitem__ where item has a key in the dictionary
    assert test_dict['key1'] == 'value1', 'ImmutableDict[key1] should return value1'

    # Test __getitem__ where item has a key that is not in the dictionary
    try:
        test_dict['non-existent-key']
    except KeyError:
        pass
    else:
        assert False, 'ImmutableDict[non-existent-key] should throw a KeyError'


# Generated at 2022-06-20 15:39:34.462940
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_dict_1 = ImmutableDict({'key':'value', 'key1':'value1'})
    test_dict_2 = ImmutableDict({'key':'value', 'key1':'value1'})
    assert test_dict_1 == test_dict_2
    assert test_dict_2 == test_dict_1
    test_dict_3 = ImmutableDict({'key':'value', 'key1':'value3'})
    assert test_dict_1 != test_dict_3
    assert test_dict_2 != test_dict_3
    test_dict_4 = ImmutableDict({'key':'value'})
    assert test_dict_1 != test_dict_4
    assert test_dict_2 != test_dict_4
    assert test_dict_3 != test_dict

# Generated at 2022-06-20 15:39:37.170557
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    c = ImmutableDict({'a': 1, 'c': 2})
    assert a.__hash__() == b.__hash__()
    assert a.__hash__() != c.__hash__()


# Generated at 2022-06-20 15:39:46.778109
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict({1: 1, 2: 2, 3: 3, 4: 4})
    overriding_mapping = {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd'}
    union_dict = original.union(overriding_mapping)

    # Verify that union_dict is a new instance of ImmutableDict
    assert union_dict is not original

    # Verify that the union_dict contains all the key-values from original and overriding_mapping
    assert union_dict.items() == original.items() | set(overriding_mapping.items())

    # Verify that there are no original items in the union_dict
    assert list(union_dict.difference(original.keys())) == list(overriding_mapping)


# Generated at 2022-06-20 15:39:49.522512
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert repr(ImmutableDict({'a': 1})) == 'ImmutableDict({\'a\': 1})'



# Generated at 2022-06-20 15:40:01.466567
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    """Test the union method of ImmutableDict class"""
    # Case 1: Test the union of 2 ImmutableDict objects
    test_immutabledict_1 = ImmutableDict({'foo': 'bar', 'baz': 'qux'})
    test_immutabledict_2 = ImmutableDict({'foo': 'bar_2', 'key': 'value'})
    result_immutabledict = test_immutabledict_1.union(test_immutabledict_2)
    assert result_immutabledict == ImmutableDict({'foo': 'bar_2', 'baz': 'qux', 'key': 'value'})
    # Case 2: Test the union of an immutable dict with a mutable dict

# Generated at 2022-06-20 15:40:07.586531
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Makes sure that __hash__ for ImmutableDict is working correctly."""
    d1 = ImmutableDict({'a': 1, 'b': 3})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    d3 = ImmutableDict({'a': 1, 'b': 4})
    assert d1.__hash__() == d2.__hash__()
    assert hash(d1) == hash(d2)
    assert d1.__hash__() != d3.__hash__()
    assert hash(d1) != hash(d3)


# Generated at 2022-06-20 15:40:15.402799
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Unit test for constructor of class ImmutableDict"""
    assert ImmutableDict() == {}
    assert ImmutableDict({'a': 1}) == {'a': 1}
    assert ImmutableDict(a=1) == {'a': 1}
    assert ImmutableDict([('a', 1)]) == {'a': 1}
    assert ImmutableDict(zip(['a', 'b'], [1, 2])) == {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}, a=3) == {'a': 3, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}, b=3, c=4) == {'a': 1, 'b': 3, 'c': 4}


# Unit

# Generated at 2022-06-20 15:41:37.309779
# Unit test for function is_iterable
def test_is_iterable():
    # Test for is_iterable and not is_sequence
    for i in (1, 2, -1, 0, '', ' ', None, object()):
        assert is_iterable(i) and not is_sequence(i)

    # Test iterator
    class Iter(object):
        def __init__(self, data):
            self.data = data
            self.index = 0

        def next(self):
            if self.index >= len(self.data):
                raise StopIteration()

            elem = self.data[self.index]
            self.index += 1
            return elem

    assert is_iterable(Iter('abc'))

    # Test for non-iterable
    class NotIter(object):
        pass

    assert not is_iterable(NotIter())



# Generated at 2022-06-20 15:41:44.571602
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Test the ImmutableDict difference method
    """
    test_mapping1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    test_mapping2 = ImmutableDict({'b': 2, 'e': 5})
    assert test_mapping1.difference(test_mapping2.keys())._store == {'a': 1, 'c': 3, 'd': 4}



# Generated at 2022-06-20 15:41:52.656547
# Unit test for function is_string
def test_is_string():
    from ansible.module_utils.parsing.convert_bool import boolean
    assert is_string('a')
    assert is_string(u'a')
    assert is_string(b'a')
    assert not is_string([1, 2, 3])
    assert not is_string(['a', 'b', 'c'])
    assert not is_string((1, 2, 3))
    assert not is_string(boolean('yes'))
    assert not is_string(set([1, 2, 3]))
    assert not is_string({'a':1, 'b':2, 'c':3})
    assert not is_string(1)
    assert not is_string(object)



# Generated at 2022-06-20 15:41:56.480361
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_dictionary = ImmutableDict({"a": 1, "b": 2, "c": 3, "d": 4, "e": 5})
    test_subtractive_iterable = ["c", "e"]
    test_dictionary = test_dictionary.difference(test_subtractive_iterable)
    assert test_dictionary == ImmutableDict({"a": 1, "b": 2, "d": 4})


# Generated at 2022-06-20 15:42:00.961509
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    '''Test __getitem__ method of class ImmutableDict'''
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})

    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3



# Generated at 2022-06-20 15:42:06.591326
# Unit test for function count
def test_count():
    seq = [1, 2, 2, 1, 2, 3, 4, 5, 6, 7, 1, 3, 3, 3, 3, 3, 3]
    counters = count(seq)
    assert(counters[1] == 3)
    assert(counters[2] == 3)
    assert(counters[3] == 6)
    assert(counters[4] == 1)
    assert(counters[5] == 1)
    assert(counters[6] == 1)
    assert(counters[7] == 1)
    try:
        count('hello')
        assert(False)
    except Exception:
        pass


# Generated at 2022-06-20 15:42:10.499421
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    a = ImmutableDict()
    b = ImmutableDict()
    c = ImmutableDict([('1', '1'), ('2', '2')])

    for case in ((a, b, c), (a, c), (c, b)):
        assert len(set(case)) == len(case)

# Generated at 2022-06-20 15:42:14.267318
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict({'key1': 'value1'})
    overriding_mapping = {'key2': 'value2', 'key3': 'value3'}
    result = original.union(overriding_mapping)
    assert result == ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})


# Generated at 2022-06-20 15:42:15.644443
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    m1 = ImmutableDict({'a': 1, 'b': 2})
    assert len(m1) == 2


# Generated at 2022-06-20 15:42:21.469582
# Unit test for function count
def test_count():
    seqs = ['', [], set(), dict(), (), frozenset()]
    for s in seqs:
        try:
            c = count(s)
        except Exception as e:
            assert type(e) == Exception
            assert e.args[0] == 'Argument provided  is not an iterable'
    seqs = [
        list(range(10)),
        tuple(range(10)),
        set(range(10)),
        frozenset(range(10)),
        range(10),
        '0123456789',
    ]
    for s in seqs:
        assert count(s) == {0: 1, 1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 1, 7: 1, 8: 1, 9: 1}

