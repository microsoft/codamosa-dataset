

# Generated at 2022-06-20 15:33:48.208481
# Unit test for function is_sequence
def test_is_sequence():
    seqs = [
        's',
        u's',
        [],
        (1, 2),
        [1, 2, 3],
        (1, 2, 3),
    ]

    for each in seqs:
        assert is_sequence(each, include_strings=False)

    # AnsibleVaultEncryptedUnicode is a sequence, yet is string like
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode
    ciphertext = VaultLib.encrypt(VaultLib(), 'test_password', u'foo')
    assert is_sequence(AnsibleVaultEncryptedUnicode(ciphertext, 'test_password'), include_strings=True)

# Generated at 2022-06-20 15:33:53.219557
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    # input
    original_dict = {'a': 1, 'b': 2, 'c': 3}
    expected_dict = {'a': 1, 'b': 2, 'c': 3}

    # test execution
    immutable_dict = ImmutableDict(original_dict)
    actual_dict = {key: immutable_dict[key] for key in immutable_dict}

    # test verification
    assert actual_dict == expected_dict


# Generated at 2022-06-20 15:33:59.136111
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Test for method __repr__ of class ImmutableDict"""
    # ImmutableDict()
    dict1 = ImmutableDict()
    assert repr(dict1) == 'ImmutableDict({})'

    # ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict2 = ImmutableDict(a=1, b=2, c=3)
    assert repr(dict2) == "ImmutableDict({'a': 1, 'b': 2, 'c': 3})"

    # ImmutableDict(('a', 1), ('b', 2), ('c', 3))
    dict3 = ImmutableDict([('a', 1), ('b', 2), ('c', 3)])

# Generated at 2022-06-20 15:34:10.869240
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    original = ImmutableDict()
    assert len(original) == 0

    # Test __eq__ and __hash__
    assert hash(original) == hash(ImmutableDict())
    assert original == ImmutableDict()
    assert original != {}

    original = ImmutableDict(a=1, b=2)
    assert original['a'] == 1
    assert original['b'] == 2
    assert len(original) == 2

    assert hash(original) == hash(ImmutableDict(a=1, b=2))
    assert original == ImmutableDict(a=1, b=2)
    assert original != ImmutableDict(b=2, a=1)

    assert hash(original) != hash(ImmutableDict(a=1))
    assert original != ImmutableDict(a=1)
    assert original

# Generated at 2022-06-20 15:34:16.084405
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict()
    if len(d) != 0:
        raise AssertionError(d.__len__())
    d1 = ImmutableDict({'a': 2, 'b': 3})
    if len(d1) != 2:
        raise AssertionError(d1.__len__())



# Generated at 2022-06-20 15:34:20.444621
# Unit test for method __getitem__ of class ImmutableDict

# Generated at 2022-06-20 15:34:23.077326
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert is_string(u'foo')
    assert not is_string([])
    assert not is_string(None)



# Generated at 2022-06-20 15:34:26.664195
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict(a='1', b='2', c='3')) == 3

    assert len(ImmutableDict()) == 0



# Generated at 2022-06-20 15:34:29.265788
# Unit test for function is_string
def test_is_string():
    assert is_string('text')
    assert is_string(u'text')
    assert is_string(b'bytes')


# Generated at 2022-06-20 15:34:31.878673
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    expect = {'hello': 'world'}
    actual = ImmutableDict(expect)
    assert actual['hello'] == 'world'


# Generated at 2022-06-20 15:34:41.746380
# Unit test for function is_string
def test_is_string():
    assert is_string("foo")
    assert is_string(u"foo")
    assert is_string("Fo0")
    assert is_string("Fo0".encode("utf-8"))
    assert not is_string([])
    assert not is_string({})
    assert not is_string(0)
    assert not is_string(())


# Generated at 2022-06-20 15:34:48.328296
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(1)
    assert is_iterable([1, 2, 3])
    assert is_iterable('abc')
    assert is_iterable({})
    assert is_iterable((1, 2, 3))
    assert is_iterable((i for i in range(3)))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(ImmutableDict(a=1, b=2, c=3))
    assert is_iterable(range(1))
    assert is_iterable(xrange(1))
    assert is_iterable(frozenset([1, 2, 3]))

    assert not is_iterable(None)
    assert not is_iterable(type)
    assert not is_iterable(is_iterable)

# Generated at 2022-06-20 15:34:56.300633
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    import unittest

    class TestImmutableDict___len__(unittest.TestCase):
        def test__len__(self):
            my_obj = ImmutableDict(name="Ansible", automation="Simple")
            self.assertEqual(len(my_obj), 2)

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_native

    runner = unittest.TextTestRunner(verbosity=3)
    result = runner.run(basic.AnsibleModuleTestCase.parametrize(TestImmutableDict___len__, basic._ANSIBLE_ARGS))
    basic.exit_json(changed=False, ansible_facts=dict(test_results=result.success, test_results_message=to_native(result)))



# Generated at 2022-06-20 15:35:04.264514
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict()
    iter_d = iter(d)
    assert not next(iter_d).__dict__
    d = ImmutableDict({'1': '1', '2': '2', '3': '3'})
    iter_d = iter(d)
    for elem in ['1', '2', '3']:
        assert elem == next(iter_d)
    d = ImmutableDict({'1': '1'})
    assert '1' == next(iter(d))



# Generated at 2022-06-20 15:35:09.007555
# Unit test for function count
def test_count():
    test_string = 'abbcc'
    test_list = ['a', 'b', 'b', 'c', 'c']
    test_dict = {'a': 1, 'b': 2, 'c': 2}
    assert test_dict == count(test_string)
    assert test_dict == count(test_list)



# Generated at 2022-06-20 15:35:19.806349
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    original = ImmutableDict({'a': 1, 'b': 2})
    equal_to_original = ImmutableDict({'a': 1, 'b': 2})
    different_value_for_a = ImmutableDict({'a': 3, 'b': 2})
    different_value_for_b = ImmutableDict({'a': 1, 'b': 3})
    duplicate_value_for_a = ImmutableDict({'a': 1, 'b': 2, 'c': 1})
    duplicate_value_for_b = ImmutableDict({'a': 1, 'b': 2, 'c': 2})
    duplicate_key_for_a = ImmutableDict({'a': 2, 'b': 1, 'c': 2})

# Generated at 2022-06-20 15:35:22.278223
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict({'a': 1, 'b': 2})
    assert set(d.__iter__()) == {'a', 'b'}



# Generated at 2022-06-20 15:35:27.780186
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    dictionary = ImmutableDict({'1' : 'a', '2' : 'b', '3' : 'c'})
    dictionary_str = 'ImmutableDict({\'1\': \'a\', \'2\': \'b\', \'3\': \'c\'})'
    assert repr(dictionary) == dictionary_str


# Generated at 2022-06-20 15:35:33.557080
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    # create a ImmutableDict object
    immutabledict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert immutabledict['a'] == 1, 'a == 1'
    assert immutabledict['b'] == 2, 'b == 2'
    assert immutabledict['c'] == 3, 'c == 3'


# Generated at 2022-06-20 15:35:39.456938
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    test_dict = ImmutableDict({'first': 1, 'second': 2})
    # Attempt to update test_dict
    try:
        test_dict['third'] = 3
    except Exception:
        assert(True)
    else:
        assert(False)

# Generated at 2022-06-20 15:35:50.362789
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict(a=1, b=2)
    if d['a'] != 1 or d['b'] != 2:
        # If this fails, then the ImmutableDict is being updated.
        raise Exception('ImmutableDict can be updated')


# Generated at 2022-06-20 15:36:00.107919
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Unit test for making sure __hash__ for the class ImmutableDict is deterministic"""
    d1 = ImmutableDict({'a':2, 'b':3})
    d2 = ImmutableDict({'a':2, 'b':3})
    d3 = ImmutableDict({'a':2, 'b':4})
    d4 = ImmutableDict({'a':2, 'c':3})
    d5 = ImmutableDict({'d':2, 'b':3})
    d6 = {'a':2, 'b':3}
    hash1 = d1.__hash__()
    hash2 = d2.__hash__()
    hash3 = d3.__hash__()
    hash4 = d4.__hash__()
    hash5 = d5.__hash__()
   

# Generated at 2022-06-20 15:36:03.079597
# Unit test for function is_string
def test_is_string():
    assert is_string('123')
    assert is_string(u'123')
    assert is_string(b'123')
    assert not is_string(123)
    assert not is_string([1,2,3])



# Generated at 2022-06-20 15:36:12.481139
# Unit test for function is_iterable
def test_is_iterable():
    # Test for basic iterables
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable(xrange(1, 10)) == True
    assert is_iterable((1, 2, 3)) == True
    assert is_iterable(set((1, 2, 3))) == True
    # Test for iterables that raise exceptions when iter() is called on them
    class MockIterable(object):
        def __iter__(self):
            raise Exception
    assert is_iterable(MockIterable()) == True
    # Test for non-iterables
    assert is_iterable(1) == False
    assert is_iterable(set()) == False

#-----------------------------------

# Generated at 2022-06-20 15:36:18.160181
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    # Test 1: Ensure the right value is returned when one key and one value are provided
    i_dict = ImmutableDict({"key1": "value1"})
    assert len(i_dict) == 1
    # Test 2: Ensure the right value is returned even when a default value is provided
    i_dict = ImmutableDict({"key1": "value1"}, key2="value2")
    assert len(i_dict) == 2
    # Test 3: Ensure the right value is returned when two keys and values are provided
    i_dict = ImmutableDict({"key1": "value1", "key2": "value2"})
    assert len(i_dict) == 2
    # Test 4: Ensure the right value is returned when no keys and values are provided
    i_dict = ImmutableDict()

# Generated at 2022-06-20 15:36:24.503126
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert is_sequence((1, 2, 3))
    assert is_sequence({'a': 1, 'b': 2})
    assert not is_sequence(set([1, 2, 3]))
    assert not is_sequence({1: 'a', 2: 'b'})
    assert not is_sequence(1)
    assert not is_sequence(None)
    assert not is_sequence(NotImplemented)



# Generated at 2022-06-20 15:36:32.224285
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    This tests the ImmutableDict.difference method.
    """
    test_dict = dict(
        key1='value1',
        key2='value2',
        key3='value3',
        key4='value4'
    )
    extra_dict = dict(
        extra1='extra1',
        extra2='extra2'
    )
    test_immutable_dict = ImmutableDict(test_dict, **extra_dict)
    test_remove_keys = {'key1', 'key2', 'extra1'}
    new_immutable_dict = test_immutable_dict.difference(test_remove_keys)

    assert new_immutable_dict['key3'] == 'value3'
    assert new_immutable_dict['key4'] == 'value4'
    assert new

# Generated at 2022-06-20 15:36:41.655075
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # Empty dictionaries
    d1 = ImmutableDict()
    d1_diff = d1.difference([])
    assert d1 == d1_diff
    d1_diff = d1.difference(['a'])
    assert d1 == d1_diff

    # Non-empty dictionaries
    d2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d2_diff = d2.difference([])
    assert d2 == d2_diff
    d2_diff = d2.difference(['a'])
    assert ImmutableDict({'b': 2, 'c': 3}) == d2_diff
    d2_diff = d2.difference(['b', 'c'])
    assert ImmutableDict({'a': 1}) == d2

# Generated at 2022-06-20 15:36:50.398341
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # prepare all possible types of inputs
    d = dict(a=1, b=2, c=3)
    dict1 = dict(a=1, b=2, c=3)
    dict2 = dict(a=1, b=2, c=4)
    dict3 = dict(a=1, b=2)
    tupledict1 = ('a', 1, 'b', 2, 'c', 3)
    tupledict2 = ('a', 1, 'b', 2, 'c', 4)
    tupledict3 = ('a', 1, 'b', 2)
    listdict1 = ['a', 1, 'b', 2, 'c', 3]
    listdict2 = ['a', 1, 'b', 2, 'c', 4]
    listdict3 = ['a', 1, 'b', 2]


# Generated at 2022-06-20 15:36:55.640548
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d1 = ImmutableDict({'a': 1, 'b': 2, 'd': 1, 'e': 2})
    d2 = d1.difference('b')
    assert d2.keys() == {'a', 'd', 'e'}
    assert d2.values() == [1, 1, 2]



# Generated at 2022-06-20 15:37:16.031044
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Unit test for constructor of class ImmutableDict"""
    immutable_dict = ImmutableDict(dict(a=1, b=2))
    immutable_dict2 = ImmutableDict(immutable_dict, c=3)
    assert dict(immutable_dict2) == dict(immutable_dict, c=3)
    assert immutable_dict2 == ImmutableDict(immutable_dict, c=3)
    assert immutable_dict2 != ImmutableDict(immutable_dict, c=4)
    assert immutable_dict2.union(dict(d=4)) == ImmutableDict(immutable_dict, c=3, d=4)
    assert immutable_dict2.union(dict(c=4, d=4)) == ImmutableDict(immutable_dict, c=4, d=4)

# Generated at 2022-06-20 15:37:23.034224
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    """Unit test for method __getitem__ of class ImmutableDict

    :rtype: int
    :return: The number of failed tests.
    """

    ik = ImmutableDict(dict(key1='value1', key2='value2'))
    ret = 0
    if ik['key2'] != 'value2':
        ret += 1
    try:
        ik['key3']
    except KeyError:
        pass
    else:
        ret += 1

    return ret


# Generated at 2022-06-20 15:37:26.246764
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    obj = ImmutableDict(
        {'name': 'Python', 'version': '3.6'}
    )
    res = obj['name']
    assert res == 'Python'


# Generated at 2022-06-20 15:37:36.449186
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({'a': 'b', 'c': 'd'})
    dict2 = ImmutableDict({'a': 'b', 'c': 'd'})
    dict3 = ImmutableDict({'a': 'b', 'c': 'd', 'e': 'f'})
    dict4 = ImmutableDict({'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h'})
    dict5 = ImmutableDict({'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h'})

    assert dict1 == dict2
    assert dict1 != dict3
    assert dict3 != dict4
    assert dict4 == dict5


# Generated at 2022-06-20 15:37:42.344574
# Unit test for function is_iterable
def test_is_iterable():
    class iterable(object):
        def __iter__(self):
            return self

    class notiterable(object):
        def __iter__(self):
            raise TypeError()

    assert not is_iterable(1)
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(iterable())
    assert not is_iterable(notiterable())


# Generated at 2022-06-20 15:37:47.937914
# Unit test for function is_sequence
def test_is_sequence():
    assert not is_sequence("String")
    assert not is_sequence("String", include_strings=True)
    assert not is_sequence(None)
    assert not is_sequence({'a':1})
    assert is_sequence([1,2,3,4])
    assert is_sequence(set([1,2,3,4]))
    assert is_sequence((1,2,3,4))
    assert is_sequence(xrange(4))


# Generated at 2022-06-20 15:37:52.843713
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    my_dict = ImmutableDict(dict(a=1, b=2))
    # __getitem__ should return value for existing key
    assert my_dict['a'] == 1
    # __getitem__ should raise KeyError for missing key
    try:
        assert my_dict['d'] == 1
        assert False, 'Should have raised KeyError for missing key'
    except KeyError:
        pass


# Generated at 2022-06-20 15:38:03.774742
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    # Covering all the possible cases. Also, it's interesting
    # to see how Python actually handles that
    immdict = ImmutableDict([(1, 'one'), (2, 'two'), (3, 'three')])
    # Simple int key
    if immdict[1] != 'one':
        raise Exception()
    # Simple text key
    immdict = ImmutableDict([('one', 1), ('two', 2), ('three', 3)])
    if immdict['one'] != 1:
        raise Exception()
    # Boolean key
    immdict = ImmutableDict([(True, 'Yes'), (False, 'No')])
    if immdict[True] != 'Yes':
        raise Exception()
    # Tuple key

# Generated at 2022-06-20 15:38:11.759252
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}).__eq__(ImmutableDict({'a': 1})) == True
    assert ImmutableDict({'a': 1}).__eq__(ImmutableDict({})) == False
    assert ImmutableDict({'a': 1}).__eq__(ImmutableDict({'a': 2})) == False
    assert ImmutableDict({'a': 1}).__eq__(ImmutableDict({'a': 1, 'b': 1})) == False
    assert ImmutableDict({'a': 1}).__eq__({'a': 1}) == False

# Generated at 2022-06-20 15:38:18.097802
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict(a=1, b=2)
    assert a == ImmutableDict(b=2, a=1)
    assert a != ImmutableDict(a=1)
    assert a != ImmutableDict(a=1, b=3)
    assert a != MutableMapping(a=1, b=2)
    assert a != {'a': 1, 'b': 2}
    assert a != 1

# Generated at 2022-06-20 15:38:54.646329
# Unit test for function count
def test_count():
    """Test the count function for dictionaries."""
    elems = [1, 1, 2, 2, 2, 3]
    as_counted = count(elems)
    assert(len(as_counted) == 3)
    assert(as_counted[1] == 2)
    assert(as_counted[2] == 3)
    assert(as_counted[3] == 1)
    assert(as_counted[4] == 0)  # Not there
    # Make sure we don't break with something else
    assert(count('abc') == {'a': 1, 'b': 1, 'c': 1})


# Generated at 2022-06-20 15:38:59.619782
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    dic = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert dic == dic.difference([])
    assert dic == dic.difference({})
    assert dic != dic.difference(['a', 'b'])
    assert dic != dic.difference({'a': 1, 'b': 2})
    assert ImmutableDict({'c': 3}) == dic.difference(['a', 'b'])
    assert ImmutableDict({'c': 3}) == dic.difference({'a': 1, 'b': 2})
    assert ImmutableDict() == dic.difference(['a', 'b', 'c'])

# Generated at 2022-06-20 15:39:08.489303
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(range(10))
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable(list())
    assert is_iterable(tuple())
    assert is_iterable(u'\u5929\u7684\u795e\u793e')
    assert is_iterable(b'\xe5\xa4\xa9\xe7\x9a\x84\xe7\xa5\x9e\xe7\xa5\x9e')
    assert not is_iterable(3.2)
    assert not is_iterable(True)



# Generated at 2022-06-20 15:39:13.277215
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """Unit test for method __len__ of class ImmutableDict."""
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict({'key1': 'value1'})) == 1
    assert len(ImmutableDict({'key1': 'value1', 'key2': 'value2'})) == 2


# Generated at 2022-06-20 15:39:20.202081
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([0, 1, 2])
    assert is_sequence((0, 1, 2))
    assert is_sequence(set([0, 1, 2]))
    assert not is_sequence(set([0, 1, 2]), include_strings=True)
    assert is_sequence(range(0, 3))
    assert is_sequence({'a': 0, 'b': 1}, include_strings=True)
    assert not is_sequence({'a': 0, 'b': 1})
    assert is_sequence('test', include_strings=True)
    assert not is_sequence('test')


# Generated at 2022-06-20 15:39:26.722963
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d1 = ImmutableDict(a=12, b=23, c=34)
    d2 = ImmutableDict(c=34, b=23, a=12)
    d3 = ImmutableDict(c=34, b=23, a=12)
    d4 = ImmutableDict(c=34, b=23, a=12)

    assert(hash(d1) == hash(d2))
    assert(hash(d1) == hash(d3))
    assert(hash(d1) == hash(d4))

    d1 = ImmutableDict(a=12, b=23, c=34)
    d2 = ImmutableDict(a=11, b=23, c=34)
    d3 = ImmutableDict(a=11, b=23, c=34)



# Generated at 2022-06-20 15:39:31.590812
# Unit test for function is_sequence
def test_is_sequence():
    string_types = (text_type('test'), binary_type('test'))
    assert all(is_sequence(i) is False for i in string_types)
    assert all(is_sequence(i, include_strings=True) is True for i in string_types)



# Generated at 2022-06-20 15:39:36.237466
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict(original_mapping=1)
    additional = ImmutableDict(overriding_mapping=2)
    resulting = original.union(additional)
    assert resulting['original_mapping'] == 1
    assert resulting['overriding_mapping'] == 2


# Generated at 2022-06-20 15:39:38.946819
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    d = ImmutableDict(a=1, b=2, c=3)
    assert d == {'a': 1, 'b': 2, 'c': 3}



# Generated at 2022-06-20 15:39:45.410868
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) == True
    assert is_iterable({}) == True
    assert is_iterable(set()) == True
    assert is_iterable(range(5)) == True
    # On Python 2 strings are iterables
    assert is_iterable('This is a test string') == True

    assert is_iterable(True) == False
    assert is_iterable(False) == False
    assert is_iterable(7) == False
    assert is_iterable(None) == False


# Generated at 2022-06-20 15:40:43.242963
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    imm_dict = ImmutableDict(a='b')
    assert repr(imm_dict) == "ImmutableDict({'a': 'b'})"

# Generated at 2022-06-20 15:40:49.847927
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    base_dict = {'a': 1, 'b': 2, 'c': 3}
    immutable_dict = ImmutableDict(base_dict)
    remove_keys = frozenset(['b', 'c'])

    new_dict = immutable_dict.difference(remove_keys)
    assert len(new_dict) == 1
    assert new_dict.get('a') == 1
    assert new_dict.get('b') is None
    assert new_dict.get('c') is None



# Generated at 2022-06-20 15:40:54.171695
# Unit test for function count
def test_count():
    list_with_duplicates = [1, 1, 2, 3, 4, 4, 5]
    dict_with_counts = count(list_with_duplicates)
    assert dict_with_counts[1] == 2
    assert dict_with_counts[4] == 2
    try:
        count('not a list')
        assert False
    except Exception:
        pass
    assert count([]) == {}



# Generated at 2022-06-20 15:40:57.478982
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict(
        a=1,
        b=2,
        c=3
    )
    keys = []
    for k in d:
        keys.append(k)
    assert 'a' in keys
    assert 'b' in keys
    assert 'c' in keys
    assert len(keys) == 3


# Generated at 2022-06-20 15:40:59.368126
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    idict = ImmutableDict({1:2, 3:4})
    if hash(idict) != hash(idict):
        raise Exception('The hash of an ImmutableDict is not reproducible')


# Generated at 2022-06-20 15:41:03.516449
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    dict = ImmutableDict({"test": "123"})
    for key in dict:
        assert key == 'test'
        assert dict[key] == '123'
    assert "test" in dict
    assert dict['test'] == '123'

    assert dict.get("test") == '123'


# Generated at 2022-06-20 15:41:07.695878
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict()
    assert repr(d) == 'ImmutableDict({})'
    d = ImmutableDict({'a': 3})
    assert repr(d) == "ImmutableDict({'a': 3})"


# Generated at 2022-06-20 15:41:16.400064
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_dict = ImmutableDict(name='foo', age=50)
    test_list = ['name']
    test_set = {'age'}

    test_dict_difference1 = test_dict.difference(test_set)
    test_dict_difference2 = test_dict.difference(test_list)

    test_dict_result1 = ImmutableDict(name='foo')
    test_dict_result2 = ImmutableDict(age=50)

    assert test_dict_difference1 == test_dict_result1, "test_dict_difference1 should be ImmutableDict(name='foo')"
    assert test_dict_difference2 == test_dict_result2, "test_dict_difference2 should be ImmutableDict(age=50)"

# Generated at 2022-06-20 15:41:25.866875
# Unit test for function is_sequence
def test_is_sequence():
    str_obj = 'string'
    byte_obj = b'byte'
    list_obj = [1, 2, 3]
    tuple_obj = (1, 2, 3)
    set_obj = {1, 2, 3}
    dict_obj = {'key': 'value'}

    assert is_sequence(list_obj)
    assert is_sequence(tuple_obj)
    assert is_sequence(set_obj)
    assert not is_sequence(dict_obj)
    assert not is_sequence(str_obj)
    assert not is_sequence(byte_obj)

    # Strings are not sequences by default
    assert not is_sequence(str_obj)
    assert is_sequence(str_obj, include_strings=True)

    # Bytes are not sequences by default

# Generated at 2022-06-20 15:41:30.018739
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    id = ImmutableDict({'1': '1', '2': '2', '3': '3'})
    assert(repr(id) == "ImmutableDict({'1': '1', '2': '2', '3': '3'})")

