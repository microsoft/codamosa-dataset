

# Generated at 2022-06-20 15:33:45.367507
# Unit test for function count
def test_count():
    l = [1, 1, 2, 3, 4, 5, 5, 7, 1]
    c = count(l)
    assert c == {1: 3, 2: 1, 3: 1, 4: 1, 5: 2, 7: 1}



# Generated at 2022-06-20 15:33:49.827150
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():

    base = ImmutableDict([(1, 'one'), (2, 'two')])
    overriding = {2: 'dos', 3: 'tres'}
    result = base.union(overriding)

    assert result == ImmutableDict([(1, 'one'), (2, 'dos'), (3, 'tres')])



# Generated at 2022-06-20 15:33:54.356309
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    a = {"a":["1","2"], "b":["3","4"]}
    b = ["a", "b"]
    result = ImmutableDict(a).difference(b)
    assert result == {}

    a = ImmutableDict({"a":["1","2"], "b":["3","4"]})
    b = ["b"]
    result = a.difference(b)
    assert result == {"a":["1","2"]}

# Generated at 2022-06-20 15:34:05.519226
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    immutableDict = ImmutableDict({"a":1, "b":2, "c":3, "d":4})
    result = immutableDict.difference(['b'])
    assert len(result) == 3
    assert result == ImmutableDict({"a":1, "c":3, "d":4})

    result = immutableDict.difference(['c','d','e','f'])
    assert len(result) == 2
    assert result == ImmutableDict({"a":1, "b":2})

    result = immutableDict.difference([])
    assert len(result) == 4
    assert result == ImmutableDict({"a":1, "b":2, "c":3, "d":4})


# Generated at 2022-06-20 15:34:10.350336
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    i_dict = ImmutableDict({'a':1, 'b':2, 'c':3})
    i_dict_new = i_dict.difference(['a', 'c'])
    assert (i_dict_new['b'] == 2)



# Generated at 2022-06-20 15:34:20.580203
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable((1,))
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable({})
    assert is_iterable(2) is False
    assert is_iterable('abc') is False
    assert is_iterable(b'abc') is False
    assert is_iterable(b'abc', include_strings=True) is True
    assert is_iterable('abc', include_strings=True) is True
    assert is_iterable(2, include_strings=True) is False
    assert is_iterable(is_iterable, include_strings=True) is False


# Generated at 2022-06-20 15:34:27.887605
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    # Create a simple ImmutableDict
    a_dict = ImmutableDict({'a': 1, 'b': 2})
    ovr_dict = {'b': 3, 'c': 4}
    new_dict = a_dict.union(ovr_dict)

    assert isinstance(new_dict, ImmutableDict)
    assert new_dict == {'a': 1, 'b': 3, 'c': 4}


# Generated at 2022-06-20 15:34:32.111602
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    dict1 = {'a':1,'b':2}
    dict1 = ImmutableDict(dict1)
    dict2 = dict1.difference(['b'])
    assert dict2 == {'a':1}
    dict2 = dict1.difference(['a','b'])
    assert dict2 == {}

# Generated at 2022-06-20 15:34:42.831192
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Provide unit-test coverage for the ImmutableDict __eq__ method"""
    # Create two ImmutableDict instances that are supposed to be equal
    id1 = ImmutableDict(a=1, b=2)
    id2 = ImmutableDict(b=2, a=1)
    assert hash(id1) == hash(id2)
    assert id1 == id2

    # Test against a non-hashable object
    assert not id1 == ['b', 2, 'a', 1]

    # Test against an ImmutableDict with a different key set
    assert not id1 == ImmutableDict(a=1, b=2, c=3)



# Generated at 2022-06-20 15:34:47.637827
# Unit test for function is_string
def test_is_string():
    """Unit test for function is_string"""
    assert is_string('str')
    assert not is_string(u'str')
    assert not is_string(list('str'))
    assert not is_string(dict(str=str))



# Generated at 2022-06-20 15:34:53.333444
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    immdict = ImmutableDict(a=1, b=2)

    assert(immdict['a'] == 1)
    assert(immdict['b'] == 2)


# Generated at 2022-06-20 15:34:56.485721
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    dict1 = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})
    assert dict1[2] == 'two'



# Generated at 2022-06-20 15:35:04.462071
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    assert hash(ImmutableDict()) == hash(ImmutableDict()) == hash(frozenset())
    assert hash(ImmutableDict({'a': 1, 'b': 2, 'c': 3})) == hash(ImmutableDict({'b': 2, 'c': 3, 'a': 1}))
    assert hash(ImmutableDict({'a': 1, 'b': 2, 'c': 3})) == hash(frozenset({'c': 3, 'a': 1, 'b': 2}))



# Generated at 2022-06-20 15:35:08.887482
# Unit test for function is_string
def test_is_string():
    assert is_string('hello')
    assert is_string(u'unicode')
    assert is_string(b'binary')
    assert not is_string([1,2,3])
    assert not is_string((1,2,3))
    assert not is_string({'a': 1})


# Generated at 2022-06-20 15:35:19.645055
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    original_dict = ImmutableDict([('a', 'b'), ('b', 'c')])

    # Test if the ImmutableDict returns the correct value when it is
    # compared to a regular dict with the same key-value pairs
    equal_dict = ImmutableDict([('a', 'b'), ('b', 'c')])
    assert original_dict == equal_dict

    # Test if the ImmutableDict returns the correct value when it is
    # compared to a regular dict with the same key-value pairs but
    # in a different order
    equal_dict = ImmutableDict([('b', 'c'), ('a', 'b')])
    assert original_dict == equal_dict

    # Test if the ImmutableDict returns the correct value when it is
    # compared to a regular dict with the same key-value pairs but
    #

# Generated at 2022-06-20 15:35:31.255398
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """
    Test the ImmutableDict class
    """
    import copy

    # Basic constructor tests
    input_dict = {1: 2, 3: 4, 5: 6}

    idict = ImmutableDict(input_dict)
    ansible_assert(idict[1] == 2)
    ansible_assert(idict[3] == 4)
    ansible_assert(idict[5] == 6)

    # Test __eq__ and __hash__
    idict2 = ImmutableDict(input_dict)
    ansible_assert(idict2 == idict)
    idict3 = ImmutableDict({1: 2, 5: 6, 3: 8})
    ansible_assert(idict2 != idict3)

    # Need to do this to avoid an exception when comparing
    # a list and

# Generated at 2022-06-20 15:35:42.308157
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Create two ImmutableDict instances with the same contents
    a = ImmutableDict({'a': 'b', 'b': 'c'})
    b = ImmutableDict({'b': 'c', 'a': 'b'})

    # Test that they are recognized as equal
    assert a == b
    assert b == a

    # Create two ImmutableDict instances with different contents
    a = ImmutableDict({'a': 'b', 'b': 'c'})
    b = ImmutableDict({'b': 'c', 'a': 'x'})

    # Test that they are recognized as unequal
    assert a != b
    assert b != a


# Generated at 2022-06-20 15:35:53.042485
# Unit test for function is_iterable
def test_is_iterable():
    """Test function is_iterable."""
    assert not is_iterable(None)
    assert not is_iterable(3)
    assert not is_iterable(is_iterable)
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1, 2, 3})
    assert is_iterable({1: 2, 3: 4})
    assert is_iterable(xrange(5))
    assert is_iterable(set([1, 2, 3]))

    # strings and unicode are iterable
    assert is_iterable("ansible rocks")
    assert is_iterable(u"ansible rocks")

    # strings are not iterable if include_strings == False

# Generated at 2022-06-20 15:35:56.551218
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    a = ImmutableDict(zip('abcdefghijklmnopqrstuvwxyz', range(26)))
    b = ImmutableDict(zip('acegikmqsuwy', range(13)))
    assert hash(a) == hash(b)



# Generated at 2022-06-20 15:35:59.001794
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    test = ImmutableDict(dict(a=1, b=2, c=3))
    assert 3 == len(test)



# Generated at 2022-06-20 15:36:09.687365
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert len(d) == 3



# Generated at 2022-06-20 15:36:12.611430
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    orig_dict = ImmutableDict({"foo":"bar", "baz":"baz"})
    assert("foo" in orig_dict)
    assert("baz" in orig_dict)


# Generated at 2022-06-20 15:36:18.378697
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    mutable_dict = {'a': 'b', 'c': 'd', 'e': 'f'}
    immutable_dict = ImmutableDict(mutable_dict)
    diff_immutable_dict = immutable_dict.difference(['a', 'c'])
    assert diff_immutable_dict == {'e': 'f'}


# Generated at 2022-06-20 15:36:28.079746
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict(a=0, b=0, c=0, d=0)
    assert original.union(dict(e=1, f=1)) == ImmutableDict(a=0, b=0, c=0, d=0, e=1, f=1)
    assert original.union(dict(a=1, d=1)) == ImmutableDict(a=1, b=0, c=0, d=1)
    assert original.union(dict(g=1, h=1)) == ImmutableDict(a=0, b=0, c=0, d=0, g=1, h=1)
    assert original.union(dict(a=1, c=1)) == ImmutableDict(a=1, b=0, c=1, d=0)


#

# Generated at 2022-06-20 15:36:39.330413
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    '''
    This routine tests __getitem__ of class ImmutableDict

    User input is None
    Expected result: Exception

    User input is str
    Expected result: Exception

    User input is Invalid Key
    Expected result: Exception

    User input is Valid Key
    Expected result: return Value

    User input is Multiple Keys(Valid & Invalid)
    Expected result: raises an exception

    '''
    test_dict = ImmutableDict({'Key1': 'Value1', 'Key2': 'Value2', 'Key3': 'Value3'})
    #Test Cases
    #TC1
    try:
        test_dict[None]
    except Exception as e:
        assert 'unhashable type: NoneType' in str(e)
    #TC2

# Generated at 2022-06-20 15:36:49.067475
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """
    Two equivalent ImmutableDict objects should produce the same hash and only the same
    hash.

    Invariant:
       I1. __hash__() of two equivalent ImmutableDict objects is equal
       I2. __hash__() of two non-equivalent ImmutableDict objects is not equal
    """
    # Test vectors
    similar_dicts = [{'a': 1},
                     {'a': 1, 'b': 2},
                     {'b': 2, 'a': 1}]
    dissimilar_dicts = [{'a': 1, 'b': 2},
                       {'b': 2, 'c': 3},
                       {'c': 3, 'b': 2, 'a': 1}]

    # Create ImmutableDict objects from test vectors

# Generated at 2022-06-20 15:36:59.589258
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # assert the equality with an identical ImmutableDict
    eq_test_ImmutableDict_1 = ImmutableDict(a=1, b=2, c=3)
    eq_test_ImmutableDict_2 = ImmutableDict(a=1, b=2, c=3)
    assert eq_test_ImmutableDict_1 == eq_test_ImmutableDict_2

    # assert the equality with a dictionary equal to the ImmutableDict
    eq_test_ImmutableDict_3 = ImmutableDict(a=1, b=2, c=3)
    eq_test_dict_1 = dict(a=1, b=2, c=3)
    assert eq_test_ImmutableDict_3 == eq_test_dict_1

    # assert the equality with a list of tuples

# Generated at 2022-06-20 15:37:01.557649
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    dict_ = ImmutableDict({1: 'a', 2: 'b', 3: 'c'})
    assert set(dict_) == {1, 2, 3}



# Generated at 2022-06-20 15:37:05.957660
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    test_dict = ImmutableDict({'a': 1, 'b': 2})
    assert (test_dict.union({'c': 3})) == {'a': 1, 'b': 2, 'c': 3}
    assert (test_dict.difference(['a', 'b'])) == {}
    assert (test_dict.difference(['c'])) == {'a': 1, 'b': 2}

# Generated at 2022-06-20 15:37:14.315253
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    # 1) __getitem__() returns the item identified by key from a given ImmutableDict, or throws
    #    a KeyError exception if the key is not present in the ImmutableDict
    # 2) __getitem__() supports non-hashable keys
    hashable_keys = [ 123, "a string", (1, 2, 3), None ]
    non_hashable_keys = [ [ 1, 2 ] ]
    keys = hashable_keys + non_hashable_keys
    all_items = zip(keys, range(len(keys)))
    test_dict = ImmutableDict(all_items)
    index = 0
    for key in keys:
        assert test_dict[key] == index
        index += 1

# Generated at 2022-06-20 15:37:34.047016
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert is_string(u'foo')
    assert is_string(b'foo')
    assert not is_string(['foo', 'bar'])
    assert not is_string(('foo', 'bar'))
    assert not is_string({'foo': 'bar'})
    assert not is_string(None)



# Generated at 2022-06-20 15:37:43.298459
# Unit test for function is_string
def test_is_string():
    # Testing for different types of strings
    assert is_string("hello")
    assert is_string(u"hello")
    assert is_string("")
    assert is_string(u"")
    assert is_string("123")
    assert is_string(u"123")

    # Testing for other types
    assert not is_string(1)
    assert not is_string(1.0)
    assert not is_string(True)
    assert not is_string((1,2))
    assert not is_string([1,2])
    assert not is_string({1:2})


# Generated at 2022-06-20 15:37:46.312587
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    orig_dict = ImmutableDict({'a': 'b'})
    other_dict = {'a': 'b'}
    assert orig_dict == other_dict


# Generated at 2022-06-20 15:37:55.879565
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    from ansible.module_utils.common.collections import ImmutableDict, MutableMapping
    a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert a['a'] == 1 and a['b'] == 2 and a['c'] == 3

    # Test getting and setting of items
    assert a['a'] == 1
    try:
        a['a'] = 1
        assert False
    except TypeError:
        assert True

    # Test that insert, update, and setdefault functions raise an error
    try:
        a['a'] = 1
        assert False
    except TypeError:
        assert True

    # Test that pop, popitem, clear, and del functions raise an error

# Generated at 2022-06-20 15:38:03.720098
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # setup
    i_dict_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    i_dict_2 = ImmutableDict({'b': 2, 'c': 3, 'a': 1})
    i_dict_3 = ImmutableDict({'b': 2, 'c': 3, 'ax': 1})
    i_dict_4 = ImmutableDict({'b': 2, 'c': 3, 'a': 4})
    i_dict_5 = ImmutableDict({'b': 2, 'c': 3, 'a': 4})
    # test 1
    assert i_dict_1 == i_dict_2
    # test 2
    assert not i_dict_1 == i_dict_3
    # test 3
    assert not i_dict_1 == i_

# Generated at 2022-06-20 15:38:07.450371
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    originalDict = ImmutableDict({1: "1", 2: "2", 3: "3", 4: "4"})
    newDict = originalDict.difference([1, 2])
    assert(newDict == ImmutableDict({3: "3", 4: "4"}))



# Generated at 2022-06-20 15:38:13.966972
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """
    Make sure that comparing ImmutableDict objects with varrying values and keys
    always returns the expected result.
    """

    # Check that hash of empty dicts returns the same value
    d1 = ImmutableDict()
    d2 = ImmutableDict()
    assert d1 == d2, 'Expected empty dicts to have the same hash'

    # Check that hash of dicts with the same content returns the same value
    d1 = ImmutableDict(a=7, c=9)
    d2 = ImmutableDict(c=9, a=7)
    assert d1 == d2, 'Expected dicts with the same content to have the same hash'

    # Check that hash of dicts with different content returns different values
    d1 = ImmutableDict(a=4, b=4, c=4)

# Generated at 2022-06-20 15:38:21.972701
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    test_dict = {'key1': 'value1', 'key2': 'value2'}
    immutable_dict = ImmutableDict(test_dict)
    overriding_mapping = {'key2': 'overriding_value2', 'key3': 'value3'}
    expected_dict = {'key1': 'value1', 'key2': 'overriding_value2', 'key3': 'value3'}
    new_immutable_dict = immutable_dict.union(overriding_mapping)

    assert expected_dict == dict(new_immutable_dict)

# Unit tests for method difference of class ImmutableDict

# Generated at 2022-06-20 15:38:29.520573
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == {'a': 1}
    assert ImmutableDict({'a': 1}) != {'b': 1}
    assert ImmutableDict({'a': 1}) != {'a': 2}
    assert ImmutableDict({'a': 1}) != {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})


# Generated at 2022-06-20 15:38:38.602071
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Unit test for class ImmutableDict.

    There is a test for each method of ImmutableDict class. Then, it is tested
    that ImmutableDict can be unpacked from the dictionary to which it was
    successfully converted. Finally, it is tested that ImmutableDict can be
    used as a key of a dictionary.
    """
    assert ImmutableDict() == dict()
    empty_dict = ImmutableDict()
    assert empty_dict == dict()

    simple_map = {'a': 1, 'b': 1}
    assert ImmutableDict(simple_map) == dict(simple_map)
    map_with_unicode = {'a': 1, 'b': u'\u03a3'}
    assert ImmutableDict(map_with_unicode) == dict(map_with_unicode)

# Generated at 2022-06-20 15:39:14.619589
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    import ast
    import re
    import six
    d = ImmutableDict(a=1, b=2)
    repr_d = repr(d)
    if six.PY2:
        repr_d = repr_d.decode('string-escape')
    pattern = r'^ImmutableDict\({0}\)$'.format(re.escape(repr({'a': 1, 'b': 2})))
    if six.PY3:
        pattern = r'^ImmutableDict\({0}\)$'.format(re.escape(repr({'a': 1, 'b': 2})))
    assert re.match(pattern, repr_d), repr(repr_d)



# Generated at 2022-06-20 15:39:17.533882
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """Unit test for method __len__ of class ImmutableDict"""
    d = ImmutableDict({'a': 1, 'b': 2})
    assert len(d) == 2


# Generated at 2022-06-20 15:39:19.258371
# Unit test for function is_string
def test_is_string():
    assert is_string(u'unicode')
    assert is_string(b'bytes')



# Generated at 2022-06-20 15:39:30.297646
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    def update_mapping(mapping):
        mapping.update({'new': 'hi'})

    def delete_item(mapping):
        del mapping['x']

    from collections import OrderedDict
    from copy import copy

    # Verify that you cannot update
    mapping = ImmutableDict({'x': 'y'})
    assert mapping == {'x': 'y'}
    assert_raises(AttributeError, update_mapping, mapping)

    # Verify that you cannot delete
    mapping = ImmutableDict({'x': 'y'})
    assert mapping == {'x': 'y'}
    assert_raises(AttributeError, delete_item, mapping)

    # Verify that you can create it from a dictionary
    mapping = ImmutableDict({'a': 'b', 'c': 'd'})

# Generated at 2022-06-20 15:39:38.170939
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Two ImmutableDicts are equal when they contain the same items
    assert ImmutableDict({'a':1, 'b':2}) == ImmutableDict({'a':1, 'b':2})

    # Two ImmutableDicts are equal when one contains the same items as the other but in a different order
    assert ImmutableDict({'a':1, 'b':2}) == ImmutableDict({'b':2, 'a':1})

    # Two ImmutableDicts are not equal when they contain different items
    assert ImmutableDict({'a':1, 'b':2}) != ImmutableDict({'a':100, 'b':2})

# Generated at 2022-06-20 15:39:47.634783
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    assert repr(ImmutableDict()) == 'ImmutableDict({})'
    assert repr(ImmutableDict({'a': 1})) == "ImmutableDict({'a': 1})"
    assert repr(ImmutableDict({'a': 1}, b=2)) == "ImmutableDict({'b': 2, 'a': 1})"
    assert repr(ImmutableDict({'a': 1}, b=2, c=3)) == "ImmutableDict({'b': 2, 'a': 1, 'c': 3})"
    assert repr(ImmutableDict([('a', 1), ('b', 2)])) == "ImmutableDict({'b': 2, 'a': 1})"

# Generated at 2022-06-20 15:39:51.793204
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    from ansible.module_utils._text import to_text
    tmp_dict = ImmutableDict({'var1': 'a', 'var2': 'b'})
    result = repr(tmp_dict)
    assert result == "ImmutableDict({'var1': 'a', 'var2': 'b'})"

# Generated at 2022-06-20 15:39:54.920751
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict({'a': 1, 'b': 2})
    assert sorted(list(d)) == sorted(['a', 'b'])



# Generated at 2022-06-20 15:40:01.507921
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    # No input data
    assert len(ImmutableDict()) == 0

    # Empty dict
    assert len(ImmutableDict({})) == 0

    # One element
    assert len(ImmutableDict({1: 1})) == 1

    # Several elements
    assert len(ImmutableDict({'k1': 'v1', 'k2': 'v2'})) == 2



# Generated at 2022-06-20 15:40:06.643814
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Equals
    x = ImmutableDict({'key1': 'value1'})
    y = ImmutableDict({'key1': 'value1'})
    assert x == y

    # Different
    x = ImmutableDict({'key1': 'value1'})
    y = ImmutableDict({'key1': 'value2'})
    assert not x == y

    # Different (other is None)
    x = ImmutableDict({'key1': 'value1'})
    y = None
    assert not x == y

# Generated at 2022-06-20 15:41:08.106869
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    import copy
    collection = {'a': 1, 'b': 2, 'c': 3}
    mapping = ImmutableDict(collection)
    assert len(mapping) == len(collection)
    assert len(mapping) == 3



# Generated at 2022-06-20 15:41:12.869998
# Unit test for function is_string
def test_is_string():
    assert is_string("Hello")
    assert is_string(u"Hello")
    assert is_string(b"Hello")
    assert is_string("Hello")
    assert not is_string([])
    assert not is_string({})
    assert not is_string(set())
    assert not is_string(())
    assert not is_string(1)


# Generated at 2022-06-20 15:41:15.899925
# Unit test for function is_string
def test_is_string():
    assert is_string("abc")
    assert is_string(u"abc")
    assert is_string(b"abc")
    assert not is_string(123)
    assert not is_string(None)


# Generated at 2022-06-20 15:41:20.167809
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d = dict()
    id1 = ImmutableDict()
    id2 = ImmutableDict()

    d[id1] = 'd1'
    d[id2] = 'd2'

    assert d[id1] == 'd1'
    assert d[id2] == 'd2'



# Generated at 2022-06-20 15:41:21.737629
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    m = ImmutableDict(key='value')
    assert len(m) == 1



# Generated at 2022-06-20 15:41:24.293468
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    # create a dictionary
    test_dict = ImmutableDict(a='a', b='b', c='c')

    # test
    assert test_dict['a'] == 'a'


# Generated at 2022-06-20 15:41:27.176471
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    immutable = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    for key in immutable:
        print(key)



# Generated at 2022-06-20 15:41:29.397325
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    dict_ = ImmutableDict({"a": 1, "b": 2})
    assert sorted(dict_) == ['a', 'b']


# Generated at 2022-06-20 15:41:40.835548
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    imut_dict = ImmutableDict({"a": 1, "b": 2, "c": 3, "d": 4})
    assert imut_dict.difference(("b", "c")) == ImmutableDict({"a": 1, "d": 4})
    assert imut_dict.difference(set(("b", "c"))) == ImmutableDict({"a": 1, "d": 4})
    assert imut_dict.difference(("b", "c", "z")) == ImmutableDict({"a": 1, "d": 4})
    assert imut_dict.difference(("a",)) == ImmutableDict({"b": 2, "c": 3, "d": 4})

# Generated at 2022-06-20 15:41:51.121247
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    test_dict = ImmutableDict(
        {'os_auth_url': 'http://192.0.2.1/identity/v3',
         'os_identity_api_version': '3',
         'os_interface': 'internal',
         'os_project_domain_name': 'Default',
         'os_project_name': 'admin',
         'os_region_name': 'RegionOne',
         'os_token': 'token',
         'os_user_domain_name': 'Default',
         'os_username': 'admin'}
    )