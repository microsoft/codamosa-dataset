

# Generated at 2022-06-20 15:33:49.501267
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    # Test 1
    t1 = ImmutableDict()
    assert repr(t1) == 'ImmutableDict({})'

    # Test 2
    t2 = ImmutableDict({'a': 1, 'b': 2})
    assert repr(t2) == "ImmutableDict({'a': 1, 'b': 2})"

    # Test 3
    t3 = ImmutableDict([('a', 1), ('b', 2)])
    assert repr(t3) == "ImmutableDict([('a', 1), ('b', 2)])"

    # Test 4
    t4 = ImmutableDict(a=1, b=2)
    assert repr(t4) == "ImmutableDict({'a': 1, 'b': 2})"

    # Test 5

# Generated at 2022-06-20 15:34:01.421440
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    """
    Create an ImmutableDict as a combination of the original and overriding_mapping

    :arg overriding_mapping: A Mapping of replacement and additional items
    :return: A copy of the ImmutableDict with key-value pairs from the overriding_mapping added

    If any of the keys in overriding_mapping are already present in the original ImmutableDict,
    the overriding_mapping item replaces the one in the original ImmutableDict.
    """
    original_mapping = {'a': 1}
    overriding_mapping = {'b': 2}
    assert(ImmutableDict(original_mapping, **overriding_mapping) == ImmutableDict(original_mapping).union(overriding_mapping))

# Generated at 2022-06-20 15:34:14.083417
# Unit test for function is_iterable
def test_is_iterable():
    '''
    Validate is_iterable function
    '''
    assert is_iterable(u'string_like')
    assert is_iterable(u'\u2014')
    assert is_iterable(b'bytes_string_like')
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(dict([(1, 1), (2, 2)]))
    assert is_iterable(range(3))

    assert is_iterable(u'string_like', include_strings=True)
    assert is_iterable(u'\u2014', include_strings=True)

# Generated at 2022-06-20 15:34:24.434968
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Test usage of ImmutableDict's __hash__ method.

    This test verifies that ImmutableDict's __hash__ method correctly
    calculates the hash value of the dictionary.
    """
    from __future__ import print_function
    import sys

    ids1 = ImmutableDict({'key1': 'value1'})
    ids2 = ImmutableDict({'key2': 'value2'})
    ids3 = ImmutableDict({'key1': 'value1'})
    ids4 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})

    # Ensures that the hashes of two ImmutableDicts created from the
    # same dictionary are equal
    assert hash(ids1) == hash(ids3)

    # Ensures that the hashes of two different ImmutableD

# Generated at 2022-06-20 15:34:34.744523
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original_dict = {'one': 1, 'two': 2}
    subtracted_dict = {'two': 2}
    result_dict = ImmutableDict(original_dict).difference(subtracted_dict)
    assert(original_dict['one'] == result_dict['one'])
    assert(original_dict['two'] == result_dict['two'])

    subtracted_dict = {'two': 20}
    result_dict = ImmutableDict(original_dict).difference(subtracted_dict)
    assert(original_dict['one'] == result_dict['one'])
    assert(original_dict['two'] == result_dict['two'])

    subtracted_dict = {'two': 2, 'three': 3}

# Generated at 2022-06-20 15:34:39.233008
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict2 = ImmutableDict({'a': 2, 'b': 2, 'c': 3})

    assert dict1 != dict2

# Generated at 2022-06-20 15:34:51.147781
# Unit test for function is_sequence
def test_is_sequence():
    class IterableButNotSequence(object):
        def __iter__(self):
            return iter([])

    seq = (1, 2, 3)
    assert is_sequence(seq)
    # assert is_sequence(IterableButNotSequence()) is False
    assert is_sequence('123') is False
    assert is_sequence('123', include_strings=True)
    assert is_sequence((1,))
    assert is_sequence((1, 2))
    assert is_sequence([])
    assert is_sequence_m(seq)
    assert is_sequence_m(IterableButNotSequence()) is False
    assert is_sequence_m('123')
    assert is_sequence_m((1,))
    assert is_sequence_m((1, 2))
    assert is_sequence_m([])



# Generated at 2022-06-20 15:34:52.970263
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict(some_key=some_value)
    assert d['some_key'] == some_value


# Generated at 2022-06-20 15:35:04.556268
# Unit test for function count
def test_count():
    # Tests the count function when proper iterable is provided
    from ansible.module_utils.common._collections_compat import OrderedDict
    test_iterable = [1, 2, 3, 4, 4, 4, 5, 5, 6, 7]
    test_dict = count(test_iterable)
    test_dict_expected = {1: 1, 2: 1, 3: 1, 4: 3, 5: 2, 6: 1, 7: 1}
    if test_dict != test_dict_expected:
        raise AssertionError('Function count did not return expected dict')

    # Tests the count function when an ordered dict is provided
    test_ordered_dict = OrderedDict()
    test_ordered_dict[1] = 1
    test_ordered_dict[2] = 1

# Generated at 2022-06-20 15:35:11.766530
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence(list)
    assert is_sequence(tuple)
    assert is_sequence([])
    assert is_sequence(())

    assert not is_sequence(1)
    assert not is_sequence("nope")
    assert not is_sequence(dict())
    assert not is_sequence(set())

    assert is_sequence("yep", include_strings=True)
    assert is_sequence(dict().items(), include_strings=True)



# Generated at 2022-06-20 15:35:18.456591
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    # __repr__ should return a string with ImmutableDict and dictionary representation
    assert repr(ImmutableDict({'foo':'bar'})) == "ImmutableDict({'foo': 'bar'})"


# Generated at 2022-06-20 15:35:22.364347
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict({'a': 1})) == 1
    assert len(ImmutableDict({'a': 1, 'b': 2})) == 2


# Generated at 2022-06-20 15:35:25.122077
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    dict_ = ImmutableDict({1: 'one', 2: 'two'})
    assert len(dict_) == 2


# Generated at 2022-06-20 15:35:32.278836
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(5)
    assert is_iterable([])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(dict([(1, 2), (3, 4)]))
    assert is_iterable(u'unicode string')
    assert is_iterable('string')
    assert is_iterable(b'bytes')



# Generated at 2022-06-20 15:35:44.841856
# Unit test for function is_string
def test_is_string():
    assert not is_string([])
    assert not is_string(["a"])
    assert not is_string([1, 2])
    assert not is_string({})
    assert not is_string({"a": "b"})
    assert not is_string(None)
    assert not is_string(42)
    assert not is_string(object())
    assert is_string("")
    assert is_string("foo")
    assert is_string(u"")
    assert is_string(u"foo")
    assert is_string(b"")
    assert is_string(b"foo")

    class MyStr(text_type):
        pass

    assert is_string(MyStr(u"foo"))

# Unit-test for function count

# Generated at 2022-06-20 15:35:50.344785
# Unit test for function is_iterable
def test_is_iterable():
    # Bytes are iterable
    assert is_iterable(b'foo')
    # Strings are iterable
    assert is_iterable('foo')
    # Tuples are iterable
    assert is_iterable(('foo',))
    # Strings and bytes are not iterable if include_strings is False
    assert not is_iterable('foo', include_strings=False)
    # Strings and bytes are iterable if include_strings is True
    assert is_iterable('foo', include_strings=True)



# Generated at 2022-06-20 15:35:57.073840
# Unit test for function count
def test_count():
    assert count([1, 1]) == {1: 2}
    assert count(['1', '1', '1']) == {'1': 3}
    assert count(['1', '1', '2']) == {'1': 2, '2': 1}
    assert count([]) == {}
    assert count(['1']) == {'1': 1}
    try:
        count('1')
    except Exception:
        pass
    else:
        raise Exception('Expected exception when passing a non iterable to count function')



# Generated at 2022-06-20 15:36:04.065393
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert ImmutableDict({'a': 1}).__repr__() == 'ImmutableDict({\'a\': 1})'
    assert ImmutableDict(_store={'a': 1}).__repr__() == 'ImmutableDict({\'a\': 1})'
    assert ImmutableDict({'a': 1, 'b': 2}).__repr__() == 'ImmutableDict({\'a\': 1, \'b\': 2})'
    assert ImmutableDict().__repr__() == 'ImmutableDict({})'


# Generated at 2022-06-20 15:36:09.548457
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict({'a':1, 'b':2, 'c':3})
    override = {'b':4, 'd':5}
    new = original.union(override)

    assert isinstance(new, ImmutableDict)
    assert new == {'a':1, 'b':4, 'c':3, 'd':5}

# Generated at 2022-06-20 15:36:12.831773
# Unit test for function is_sequence
def test_is_sequence():
    assert not is_sequence(None)
    assert is_sequence([])
    assert is_sequence(())
    assert is_sequence({})
    assert not is_sequence(set())
    assert not is_sequence(object())



# Generated at 2022-06-20 15:36:29.009371
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    empty_dict = ImmutableDict()
    empty_dict_args = ImmutableDict(({}))
    assert empty_dict == empty_dict_args
    assert isinstance(empty_dict, Hashable)
    assert isinstance(empty_dict, Mapping)
    assert not isinstance(empty_dict, MutableMapping)

    simple_dict = ImmutableDict({'a': 'b'})
    assert isinstance(simple_dict, Hashable)
    assert isinstance(simple_dict, Mapping)
    assert not isinstance(simple_dict, MutableMapping)
    assert simple_dict['a'] == 'b'

    simple_dict_args = ImmutableDict((('a', 'b')))
    assert simple_dict == simple_dict_args

# Generated at 2022-06-20 15:36:37.659522
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    d = ImmutableDict({'a':1, 'b':2})
    assert d == ImmutableDict(d)
    assert d['a'] == 1
    assert d['b'] == 2
    assert d.get('c') is None
    assert d.get('c', 'z') == 'z'
    assert d.union({'c':3, 'd':4}) == ImmutableDict({'a':1, 'b':2, 'c':3, 'd':4})
    assert d.difference(['a', 'c']) == ImmutableDict({'b':2})



# Generated at 2022-06-20 15:36:41.567571
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d1 = ImmutableDict(a='a', b='b', c='c', d='d')
    d2 = d1.difference(('b', 'c'))
    assert d2 == ImmutableDict(a='a', d='d')



# Generated at 2022-06-20 15:36:45.705990
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    original = ImmutableDict(a=1, b=2)
    overriding_mapping = dict(b=3, c=3)
    expected = dict(a=1, b=3, c=3)
    result = original.union(overriding_mapping)
    assert result == expected


# Generated at 2022-06-20 15:36:47.318643
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d1 = ImmutableDict({'A': 1, 'B': 2, 'C': 3})
    assert len(d1) == 3



# Generated at 2022-06-20 15:36:53.768705
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(b=2, c=3)
    assert d1 != d2
    assert d2 != d1

    d2 = ImmutableDict(a=1, b=2)
    assert d1 == d2
    assert d2 == d1


# Generated at 2022-06-20 15:37:00.724801
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert original == ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert original != ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    assert original != {'a': 1, 'b': 2, 'c': 3}
    assert original != [('a', 1), ('b', 2), ('c', 3)]
    assert original != ('a', 1, 'b', 2, 'c', 3)

# Generated at 2022-06-20 15:37:04.695838
# Unit test for function count
def test_count():
    test = 'test'
    simple_test = count(test)
    assert simple_test.get('t', 0) == 2
    assert simple_test.get('e', 0) == 1
    assert simple_test.get('s', 0) == 1
    assert simple_test.get('x', 0) == 0



# Generated at 2022-06-20 15:37:06.514385
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    immutable_dict = ImmutableDict({"a": 1, "b": 2, "c": 3})
    assert len(immutable_dict) == 3


# Generated at 2022-06-20 15:37:12.253900
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    d = ImmutableDict({"k1": "v1", "k2": "v2"})
    assert d["k1"] == "v1"
    assert d["k2"] == "v2"
    assert len(d) == 2
    assert len(d.union(k3="v3")) == 3
    assert len(d.difference(["k2"])) == 1
    assert d.union(k2="v2")["k2"] == "v2"

# Generated at 2022-06-20 15:37:36.953917
# Unit test for function count
def test_count():
    from ansible.module_utils.six import iteritems

    # Test basic iterables
    assert count(range(10)) == dict([(element, 1) for element in range(10)])
    assert count([1, 2, 3, 1, 2, 3]) == dict([(element, 2) for element in [1, 2, 3]])

    # Test dictionaries, ensure no key collisions
    assert count(dict([(element, element) for element in range(10)])) \
        == dict([(element, 1) for element in range(10)])
    assert count(dict([(element, element + 1) for element in range(10)]))\
        == dict([(element + 1, 1) for element in range(10)])

# Generated at 2022-06-20 15:37:46.711075
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    import inspect

    # Create an ImmutableDict with int as key and value
    my_id = ImmutableDict({1: 2})
    assert my_id.__repr__() == 'ImmutableDict({1: 2})'

    # Create an ImmutableDict with str as key and int as value
    my_id = ImmutableDict({'a': 3})
    assert my_id.__repr__() == "ImmutableDict({'a': 3})"

    # Create an ImmutableDict with str as key and str as value
    my_id = ImmutableDict({'a': 'a'})
    assert my_id.__repr__() == "ImmutableDict({'a': 'a'})"

    # Create an ImmutableDict with str as key and tuple as value
    my_id

# Generated at 2022-06-20 15:37:58.518111
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Test ImmutableDict class for method __hash__"""
    import pytest
    from ansible.module_utils.common._collections_compat import OrderedDict

    test_immutable_dict = ImmutableDict({"a": 1, "b": 2})
    assert isinstance(test_immutable_dict.__hash__(), int)
    assert hash(test_immutable_dict) == hash(frozenset({"a": 1, "b": 2}))

    test_immutable_dict_1 = ImmutableDict(OrderedDict({"a": 1, "b": 2}))
    assert isinstance(test_immutable_dict_1.__hash__(), int)

# Generated at 2022-06-20 15:38:08.598075
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    input_dict = {'a': 1, 'b': 2, 'c': 3}
    output_dict = ImmutableDict(input_dict)
    output_dict_minus_a = ImmutableDict({'b': 2, 'c': 3})
    output_dict_minus_ab = ImmutableDict({'c': 3})
    output_dict_minus_abc = ImmutableDict()
    output_dict_minus_d = ImmutableDict(input_dict)

    assert isinstance(output_dict_minus_a, ImmutableDict)
    assert output_dict.difference(['a']) == output_dict_minus_a
    assert output_dict.difference(['a', 'b']) == output_dict_minus_ab

# Generated at 2022-06-20 15:38:14.936026
# Unit test for function is_string
def test_is_string():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.vault import VaultLib
    import sys

    assert is_string(to_text(b'12345'))
    assert is_string(to_bytes('12345'))
    assert is_string(VaultLib().new_key().encrypt(b'123456').decode("utf-8"))
    assert is_string(VaultLib().new_key().encrypt('123456'))
    assert not is_string(['123', '456'])
    assert not is_string(('123', '456'))
    assert not is_string((x for x in range(10)))

# Generated at 2022-06-20 15:38:19.808459
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Unit test for method __hash__ of class ImmutableDict"""
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d3 = ImmutableDict({'a': 1, 'b': 2, 'd': 3})
    d4 = ImmutableDict({'a': 1})

    assert isinstance(d1, dict)
    assert isinstance(d1, ImmutableDict)
    assert d1 == d2
    assert d1.__hash__() == d2.__hash__()
    assert d1 != d3
    assert d1.__hash__() != d3.__hash__()
    assert d1 != d4
    assert d1.__hash

# Generated at 2022-06-20 15:38:29.098942
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    """
    Construct a sample ImmutableDict with several key-value pairs,
    then use the .union() method to augment it with a MutableMapping
    and confirm that the resulting ImmutableDict has the additional
    keys and values.

    :return: ``True`` if the test succeeds, ``False`` otherwise
    """
    test_dict = ImmutableDict({'a': 1, 'b': 2})
    test_dict = test_dict.union({'c': 3})
    if test_dict == ImmutableDict({'a': 1, 'b': 2, 'c': 3}):
        return True
    else:
        return False


# Generated at 2022-06-20 15:38:33.216952
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    init_dict = ImmutableDict({"x": 1, "y": 2})
    override_mapping = {"x": 2, "z": 3}
    expected_dict = ImmutableDict({"x":2, "y":2, "z":3})

    actual_dict = init_dict.union(override_mapping)
    assert actual_dict == expected_dict



# Generated at 2022-06-20 15:38:40.684399
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    # During the comparison, the method __hash__ of the ImmutableDict class is called,
    # and the method __hash__ of the MutableMapping class is called.
    # If these two methods return the same value,
    # it means that they represent the same dictionary,
    # and the comparison returns True.

    # If both dictionaries are empty, their hashes are equal.
    assert ImmutableDict({}) == {}

    # The hash of the empty dictionary is 0, therefore we will set the hash of the dictionary
    # that we will use in the test equal to 0
    d = MutableMapping.__hash__({})
    assert d == 0

    def set_dict_hash(hash_number):
        MutableMapping.__hash__ = lambda self: hash_number
    set_dict_hash(1)

    # Now the hashes

# Generated at 2022-06-20 15:38:45.888622
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    testdict = ImmutableDict(one=1, two=2, three=3)
    # it should be empty
    if len(testdict) != 3:
        testdict = False
    # dict should be immutable - update should fail
    try:
        testdict.update({'four': 4})
    except AttributeError:
        pass
    except:
        testdict = False
    if len(testdict) != 3:
        testdict = False
    return testdict


# Generated at 2022-06-20 15:39:15.859081
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    assert(ImmutableDict({"a":1})["a"] == 1)


# Generated at 2022-06-20 15:39:23.002309
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({"a": 2, "b": 3})
    d2 = ImmutableDict({"b": 3, "a": 2})
    assert d1 == d2

    d1 = ImmutableDict({"a": 2, "b": 3})
    d2 = ImmutableDict({"b": 3, "a": 2, "c": 4})
    assert not (d1 == d2)

    d1 = ImmutableDict({"a": 2, "b": 3})
    d2 = ImmutableDict({"b": 4, "a": 2})
    assert not (d1 == d2)



# Generated at 2022-06-20 15:39:34.462908
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    # assertIn is new in Python2.7 and Python3.1
    # see http://docs.python.org/library/unittest.html#unittest.TestCase.assertIn
    # and http://docs.python.org/library/unittest.html#unittest.TestCase.assertNotIn
    try:
        assertIn
    except NameError:
        def assertIn(expected, actual):
            assert expected in actual

    try:
        assertNotIn
    except NameError:
        def assertNotIn(expected, actual):
            assert expected not in actual

    test_values = {"a": 1, "b": 2, "c": 3}
    test_dict = ImmutableDict(test_values)
    assert test_values == test_dict
    assertIn(test_dict["a"], test_dict)

# Generated at 2022-06-20 15:39:36.327216
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict(a=1, b=2, c=3)) == 3



# Generated at 2022-06-20 15:39:37.869144
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    immutable_dict = ImmutableDict({"a": 1, "b": 2})
    assert len(immutable_dict) == 2

# Generated at 2022-06-20 15:39:42.771412
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable([1, 2]))
    assert(is_iterable((1, 2)))
    assert(is_iterable(set([1, 2])))
    assert(is_iterable(ImmutableDict(a=1, b=2)))
    assert(not is_iterable(None))
    assert(not is_iterable(1))
    assert(not is_iterable(1.2))
    assert(not is_iterable(True))
    assert(not is_iterable('abc'))
    assert(not is_iterable(b'abc'))
    assert(is_iterable('abc', include_strings=True))
    assert(is_iterable(b'abc', include_strings=True))


# Generated at 2022-06-20 15:39:44.934911
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict(a=1,b=2)

    assert d['a'] == 1
    assert d['b'] == 2


# Generated at 2022-06-20 15:39:51.590081
# Unit test for function is_iterable
def test_is_iterable():
    import copy
    import collections

    _is_iterable = [
        # Container types
        dict(),
        dict(),
        list(),
        collections.defaultdict(),
        tuple(),
        set(),

        # Iterables
        range(10),
        (x for x in range(10)),
        'a string',
        b'a bytes string',
        u'a unicode string',

        # Miscellaneous
        None,
        object(),
        object(),
        1,
    ]

    not_iterables = [
        # Non-container types
        0,
        '',
        b'',
        u'',
        True,
        False,
        None,
    ]


# Generated at 2022-06-20 15:39:55.451604
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    test_mapping_1 = ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    assert test_mapping_1['key2'] == 'value2'


# Generated at 2022-06-20 15:39:59.550212
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    idict = ImmutableDict(one=1, two=2, three=3)
    for key1, key2 in zip(idict, idict):
        assert key1 == key2


# Generated at 2022-06-20 15:41:10.761016
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Test for method __hash__ of ImmutableDict class.

    This method is used as an attribute for set and frozenset,
    so we need to ensure the results are the same with __hash__
    and hash builtin function.
    """

    # Test cases
    # Regular dict that does not contain any mutable data
    dictionary1 = ImmutableDict({'key1': 'value1', 'key2': ['value21', 'value22']})
    assert dictionary1.__hash__() == hash(dictionary1)

    # Regular dict that contains mutable data
    dictionary2 = ImmutableDict({'key1': 'value1', 'key2': {'key3': ['value31', 'value32']}})
    assert dictionary2.__hash__() == hash(dictionary2)

    # Empty dict
    dictionary3 = Imm

# Generated at 2022-06-20 15:41:12.228988
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    assert ImmutableDict({'1': 'x', '2': 'y'})['1'] == 'x'



# Generated at 2022-06-20 15:41:13.792199
# Unit test for function is_string
def test_is_string():
    assert is_string("foo")
    assert not is_string(999)



# Generated at 2022-06-20 15:41:18.051073
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    test_dict = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})
    union_dict = test_dict.union({2: 'two_new', 4: 'four'})
    assert union_dict == ImmutableDict({1: 'one', 2: 'two_new', 3: 'three', 4: 'four'})


# Generated at 2022-06-20 15:41:22.692620
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Tests for method __hash__ of class ImmutableDict"""
    id_a = ImmutableDict(a='1', b='2')
    id_b = ImmutableDict(b='2', a='1')
    assert(isinstance(hash(id_a), int))
    assert(hash(id_a) == hash(id_b))



# Generated at 2022-06-20 15:41:33.357857
# Unit test for function count
def test_count():
    test_list = [1, 2, 3, 4, 2, 5, 6, 7, 2, 1]
    test_dict = {
        1: 2,
        2: 3,
        3: 1,
        4: 1,
        5: 1,
        6: 1,
        7: 1,
    }
    assert count(test_list) == test_dict
    test_list = ['1', '2', '3', '4', '2', '5', '6', '7', '2', '1']
    test_dict = {
        '1': 2,
        '2': 3,
        '3': 1,
        '4': 1,
        '5': 1,
        '6': 1,
        '7': 1,
    }
    assert count(test_list) == test_dict

# Generated at 2022-06-20 15:41:37.957696
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    # Test that correct length is returned
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict({'a': 1})) == 1
    assert len(ImmutableDict({'a': 1, 'b': 2, 'c': 3})) == 3


# Generated at 2022-06-20 15:41:44.786518
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence(list())
    assert is_sequence(tuple())
    assert is_sequence(set())
    assert is_sequence(frozenset())
    assert is_sequence(dict())
    assert is_sequence({1, 2}, include_strings=True)
    assert is_sequence(range(5))
    assert not is_sequence('string')
    assert is_sequence('string', include_strings=True)



# Generated at 2022-06-20 15:41:47.864578
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    test_dict = ImmutableDict()
    test_dict['test1'] = 'python'
    test_dict['test2'] = 'ansible'
    for key in test_dict:
        assert test_dict[key] == key


# Generated at 2022-06-20 15:41:49.829571
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict({'name': 'Sviat'})
    assert len(d) == 1



# Generated at 2022-06-20 15:43:00.761218
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    dict1 = ImmutableDict(a=1, b=2)
    dict2 = ImmutableDict(c=3)
    dict3 = dict1.union(dict2)
    assert len(dict3) == 3
    assert dict3.get('a') == 1
    assert dict3.get('b') == 2
    assert dict3.get('c') == 3


# Generated at 2022-06-20 15:43:07.564559
# Unit test for function count
def test_count():
    l1 = range(5)
    l2 = ['a', 'a', 'a', 'b', 'b', 'b', 'c', 'c', 'c']
    assert count(l1) == {0: 1, 1: 1, 2: 1, 3: 1, 4: 1}
    assert count(l2) == {'a': 3, 'b': 3, 'c': 3}
    assert count('') == {}

# pylint: disable=unused-argument

# Generated at 2022-06-20 15:43:16.806047
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert is_sequence([])
    assert is_sequence((1, 2, 3))
    assert is_sequence(())
    assert is_sequence(set([1, 2, 3]))
    assert is_sequence(frozenset([1, 2, 3]))
    assert is_sequence([None, 'str', 1, 2.0, [4, 5, 6], {'key': 'value'}, (7, 8, 9)])

    assert not is_sequence(None)
    assert not is_sequence(10)
    assert not is_sequence(2.3)
    assert not is_sequence('string')
    assert not is_sequence(u'unicode')
    assert not is_sequence(set())
    assert not is_sequence(frozenset())

# Generated at 2022-06-20 15:43:22.917661
# Unit test for function is_string
def test_is_string():
    assert is_string('abc')
    assert is_string(u'abc')
    assert is_string(b'abc')
    assert not is_string(['a', 'b', 'c'])
    assert not is_string(('a', 'b', 'c'))
    assert not is_string(None)
    assert not is_string(object())



# Generated at 2022-06-20 15:43:31.981043
# Unit test for function count
def test_count():
    """Check count function behaviour.

    Check that it works as expected on different iterable types.
    And that it raises an exception when the argument provided is not an iterable.
    """
    import pytest

    seq_list = [1, 1, 2, 2, 2, 3, 3, 4, 4, 4, 4]
    assert count(seq_list) == {1: 2, 2: 3, 3: 2, 4: 4}
    seq_tuple = (1, 1, 2, 2, 2, 3, 3, 4, 4, 4, 4)
    assert count(seq_tuple) == {1: 2, 2: 3, 3: 2, 4: 4}
    seq_set = {1, 1, 2, 2, 2, 3, 3, 4, 4, 4, 4}
    assert count(seq_set)

# Generated at 2022-06-20 15:43:41.924823
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence({}) is False
    assert is_sequence([]) is True
    assert is_sequence(()) is True
    assert is_sequence(set([])) is False
    assert is_sequence(object()) is False
    assert is_sequence(is_sequence) is False
    assert is_sequence('test') is False
    assert is_sequence(b'test') is False
    assert is_sequence(1) is False

    assert is_sequence({}, include_strings=True) is False
    assert is_sequence([], include_strings=True) is True