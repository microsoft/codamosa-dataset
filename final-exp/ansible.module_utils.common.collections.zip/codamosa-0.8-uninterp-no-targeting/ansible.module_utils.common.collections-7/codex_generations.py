

# Generated at 2022-06-20 15:33:46.132930
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that it return True if the ImmutableDict is
    equal to the provided object.
    """
    d = ImmutableDict({'a': 1, 'b': 2})
    assert d == {'b': 2, 'a': 1}
    assert d != {'a': 2}
    assert d is not d
    assert d != ImmutableDict([])
    assert d == ImmutableDict({'a': 1, 'b': 2})



# Generated at 2022-06-20 15:33:48.859027
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    assert hash(ImmutableDict({1:1, 2:2})) == ImmutableDict({2:2, 1:1}).__hash__()


# Generated at 2022-06-20 15:33:53.488308
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Ensure that the hashing function works as expected."""
    d1 = ImmutableDict(dict(one=1, two=2))
    d2 = ImmutableDict(dict(two=2, one=1))
    d3 = ImmutableDict(dict(three=3, two=2))
    assert hash(d1) == hash(d2)
    assert hash(d1) != hash(d3)


# Generated at 2022-06-20 15:33:57.104904
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    # Test with __getitem__ method
    test_obj = ImmutableDict(key1='value1', key2='value2')
    assert test_obj['key1'] == 'value1'
    assert test_obj['key2'] == 'value2'
    try:
        test_obj['key3']
    except KeyError:
        assert True
    else:
        assert False
    try:
        test_obj[3]
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-20 15:34:00.182683
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutableDict = ImmutableDict()
    assert immutableDict.__eq__(dict()) == True
    assert immutableDict.__eq__('hello') == False


# Generated at 2022-06-20 15:34:03.199728
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    assert ImmutableDict({'a': 1})['a'] == 1
    assert ImmutableDict({'a': 1})['b'] == Exception


# Generated at 2022-06-20 15:34:08.958346
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3]) is True
    assert is_sequence('abc') is False
    assert is_sequence('abc', include_strings=True) is True
    assert is_sequence(u'abc') is False
    assert is_sequence(u'abc', include_strings=True) is True

# Generated at 2022-06-20 15:34:14.770306
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_dict = ImmutableDict({'a': '1', 'b': '2', 'c': '3'})
    test_item = ['a']
    expected_dict = ImmutableDict({'b': '2', 'c': '3'})
    assert(test_dict.difference(test_item) == expected_dict)



# Generated at 2022-06-20 15:34:21.371682
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    d1 = ImmutableDict({'a': 'b', 'c': 'd'})
    d2 = d1.union({'a': 'e', 'f': 'g'})
    assert d2 == {'a': 'e', 'c': 'd', 'f': 'g'}
    assert d1 == {'a': 'b', 'c': 'd'}
    assert d2 != d1



# Generated at 2022-06-20 15:34:26.620937
# Unit test for function is_string
def test_is_string():
    assert is_string('abc')
    assert is_string(u'abc')
    assert is_string(b'abc')
    assert not is_string(1)
    assert not is_string([1])
    assert not is_string({'a': 'b'})



# Generated at 2022-06-20 15:34:30.576912
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    test_dict = ImmutableDict({"a": 1, "b": 2, "c": 3})
    assert test_dict.union({"b": 4, "d": 5}) == ImmutableDict({"a": 1, "b": 4, "c": 3, "d": 5})


# Generated at 2022-06-20 15:34:35.615092
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    dummy_dict = ImmutableDict({1: '1', 2: '2'})
    dummy_dict_eq = ImmutableDict({1: '1', 2: '2'})
    dummy_dict_diff = ImmutableDict({1: '1', 3: '2'})

    assert hash(dummy_dict) == hash(dummy_dict_eq)
    assert hash(dummy_dict) != hash(dummy_dict_diff)


# Generated at 2022-06-20 15:34:38.548278
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert repr(ImmutableDict({'key': 'value'})) == "ImmutableDict({'key': 'value'})"


# Generated at 2022-06-20 15:34:44.512739
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    dct = ImmutableDict()
    try:
        dct[1]
        assert False
    except KeyError:
        assert True
    dct = ImmutableDict({1:1})
    assert dct[1] == 1
    try:
        dct[2]
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-20 15:34:47.929147
# Unit test for function count
def test_count():
    assert count(['a', 'b', 'a', 'b']) == {'a': 2, 'b': 2}
    assert count([]) == {}
    assert count('a') == {}
    assert count(1) == {}
    try:
        count({})
    except Exception as e:
        assert 'is not an iterable' in str(e)


# Generated at 2022-06-20 15:34:52.303337
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # Testing that the __hash__ method works correctly
    d1 = ImmutableDict()
    d2 = ImmutableDict()
    d3 = ImmutableDict()

    d1['a'] = 1
    d2['a'] = 1
    d3['b'] = 1

    assert hash(d1) == hash(d2)
    assert hash(d1) != hash(d3)


# Generated at 2022-06-20 15:34:58.282134
# Unit test for function is_string
def test_is_string():
    assert is_string(None) == False
    assert is_string(33) == False
    assert is_string(True) == False
    assert is_string([1, 2]) == False
    assert is_string((1, 2)) == False
    assert is_string({'a': 'b'}) == False
    assert is_string(set()) == False
    assert is_string('string') == True


# Generated at 2022-06-20 15:35:00.833938
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict()
    assert d.__iter__() is d._store.__iter__()


# Generated at 2022-06-20 15:35:05.130831
# Unit test for function count
def test_count():
    """Unit tests for count."""
    my_dict = count(['python', 'python', 'c', 'python', 'c', 'bash', 'c'])
    assert my_dict == {'python': 3, 'c': 3, 'bash': 1}


# Generated at 2022-06-20 15:35:11.267411
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Call __eq__ with a different hash to trigger the TypeError catch
    assert ImmutableDict(a=1) != 1
    assert ImmutableDict(a=1) == ImmutableDict(a=1)
    assert not ImmutableDict(a=1) == ImmutableDict(b=2)
    assert ImmutableDict(a=1) != ImmutableDict(b=1)


# Generated at 2022-06-20 15:35:17.410174
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():

    ansible_dict = ImmutableDict({'key_1': 'value_1', 'key_2': 'value_2'})

    assert ansible_dict['key_1'] == 'value_1'
    assert ansible_dict['key_2'] == 'value_2'



# Generated at 2022-06-20 15:35:20.695272
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    # This will work since the constructor is not overridden
    immutable_dict = ImmutableDict({'key1': 1, 'key2': 2})
    assert immutable_dict['key1'] == '1'


# Generated at 2022-06-20 15:35:28.240827
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    my_dict = {'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5}
    my_immutable_dict = ImmutableDict(my_dict)

    expected_immutable_dict = {'two': 2, 'three': 3, 'four': 4, 'five': 5}

    immutable_dict_without_one = my_immutable_dict.difference(['one'])
    assert immutable_dict_without_one == expected_immutable_dict


# Generated at 2022-06-20 15:35:35.099597
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    """Unit test for method __iter__ of class ImmutableDict"""
    immutable_dict = ImmutableDict({'key1': 'val1', 'key2': 'val2', 'key3': 'val3'})
    iterable_immutable_dict = iter(immutable_dict)
    assert (next(iterable_immutable_dict) == 'key1')
    assert (next(iterable_immutable_dict) == 'key2')
    assert (next(iterable_immutable_dict) == 'key3')


# Generated at 2022-06-20 15:35:37.558435
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    test_input = {"key1": "value1", "key2": "value2"}
    test_immutabledict = ImmutableDict(test_input)
    assert(test_immutabledict['key1'] == 'value1')


# Generated at 2022-06-20 15:35:39.958732
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    dict = ImmutableDict({'a': 1, 'b': 2})
    assert next(iter(dict)) == 'a'


# Generated at 2022-06-20 15:35:48.737670
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 'b', 'c': 'd'}) == ImmutableDict({'a': 'b', 'c': 'd'})
    assert ImmutableDict({'a': 'b', 'c': 'd'}) != ImmutableDict({'a': 'b'})
    assert ImmutableDict({'a': 'b', 'c': 'd'}) != ImmutableDict({'a': 'b', 'c': 'e'})
    assert ImmutableDict({'a': 'b', 'c': 'd'}) != ImmutableDict({'c': 'd', 'a': 'b'})

# Generated at 2022-06-20 15:35:58.955616
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('') is True
    assert is_iterable('hello') is True
    assert is_iterable(u'hello') is True
    assert is_iterable(0) is True
    assert is_iterable(1) is True
    assert is_iterable([]) is True
    assert is_iterable(dict(a=1)) is True
    assert is_iterable(()) is True
    assert is_iterable(set()) is True
    assert is_iterable(frozenset()) is True
    assert is_iterable(1.0) is True
    assert is_iterable({'a': 1}) is True
    assert is_iterable(ImmutableDict({'a': 1})) is True
    assert is_iterable(False) is False

# Generated at 2022-06-20 15:36:02.015924
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    test_dict = ImmutableDict({1: 2, 3: 4, 5: 6})
    assert repr(test_dict) == 'ImmutableDict({1: 2, 3: 4, 5: 6})'


# Generated at 2022-06-20 15:36:08.290735
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    dct = ImmutableDict({'a': 'A', 'b': 'B'})
    assert (dct == {'a': 'A', 'b': 'B'})
    assert (dct.union({'c': 'C'}) == {'a': 'A', 'b': 'B', 'c': 'C'})
    assert (dct.union({'a': 'X'}) == {'a': 'X', 'b': 'B'})
    assert (dct.union({'a': 'X'}).union({'d': 'D'}) == {'a': 'X', 'b': 'B', 'd': 'D'})
    assert (dct.difference(['a']) == {'b': 'B'})

# Generated at 2022-06-20 15:36:15.495347
# Unit test for function is_string
def test_is_string():
    """Verify is_string function returns correct result"""

    assert is_string(u'test')
    assert is_string('test')
    assert is_string(b'test')

    assert not is_string([u'test'])
    assert not is_string(['test'])
    assert not is_string([b'test'])



# Generated at 2022-06-20 15:36:20.897917
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    id = ImmutableDict(dict1={'a': 1, 'b': 2})
    expected = ['dict1', 'a', 'b']

    iter = id.__iter__()
    for i in range(3):
        assert expected[i] == next(iter)


# Generated at 2022-06-20 15:36:29.899561
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a = ImmutableDict(foo='bar')

    assert a == a.union({'foo': 'bar'})
    assert a == a.union(ImmutableDict(foo='bar'))
    assert a == a.union(dict(foo='bar'))
    assert a == a.union(foo='bar')

    b = ImmutableDict(foo='not bar')

    assert b == a.union(foo='not bar')
    assert b == a.union(ImmutableDict(foo='not bar'))
    assert b == a.union(dict(foo='not bar'))

    c = a.union(foo='not bar', bar='baz')

    assert c != a
    assert c != b
    assert c == ImmutableDict(foo='not bar', bar='baz')
    assert c == ImmutableD

# Generated at 2022-06-20 15:36:34.525392
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    a = ImmutableDict([('a', 1), ('b', 2), ('c', 3)])
    assert a['a'] == 1
    assert len(a) == 3
    assert a['c'] == 3
    assert a['d'] == KeyError


# Generated at 2022-06-20 15:36:37.185994
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    assert list(ImmutableDict({'a': 1, 'b': 2})) == ['a', 'b']
    assert list(ImmutableDict(a=1, b=2)) == ['a', 'b']



# Generated at 2022-06-20 15:36:42.877787
# Unit test for function is_sequence
def test_is_sequence():
    assert isinstance([1, 2, 3], list)
    assert is_sequence([1, 2, 3])
    assert not is_sequence([1, 2, 3], include_strings=True)
    assert not is_sequence(set([0, 1, 2, 3]))
    assert not is_sequence(set([0, 1, 2, 3]), include_strings=True)



# Generated at 2022-06-20 15:36:45.705693
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    foo = ImmutableDict(bar='baz')
    assert repr(foo) == "ImmutableDict({'bar': 'baz'})"

# Generated at 2022-06-20 15:36:49.218460
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict(dict1)
    list1 = list(dict1)
    list2 = list(dict2)
    assert dict1 == dict2
    assert list1 == list2



# Generated at 2022-06-20 15:36:54.793711
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d == d.difference([])
    assert ImmutableDict() == d.difference(d)
    assert ImmutableDict({'a': 1}) == d.difference(['b', 'c'])

# Generated at 2022-06-20 15:36:57.407167
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    assert hash(ImmutableDict({'a': 1, 'b': 2})) == hash(frozenset({'a': 1, 'b': 2}.items()))

# Generated at 2022-06-20 15:37:12.375139
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    print('hash of ImmutableDict(one=1, two=2) is {0}'.format(hash(ImmutableDict(one=1, two=2))))
    print('hash of ImmutableDict(two=2, one=1) is {0}'.format(hash(ImmutableDict(two=2, one=1))))

    print('hash of ImmutableDict(one=1, two=2) == hash of ImmutableDict(one=1, two=2) is {0}'.format(hash(ImmutableDict(one=1, two=2)) == hash(ImmutableDict(one=1, two=2))))

# Generated at 2022-06-20 15:37:23.758089
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    input_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})
    expected_dict = ImmutableDict({'a': 1, 'b': 2, 'd': 4})
    assert input_dict.difference(['c', 'e']) == expected_dict
    assert input_dict.difference(('c', 'e')) == expected_dict
    assert input_dict.difference({'c', 'e'}) == expected_dict
    assert input_dict.difference({'c': 'x', 'e': 'x'}) == expected_dict
    assert input_dict.difference(ImmutableDict({'c': 'x', 'e': 'x'})) == expected_dict


# Generated at 2022-06-20 15:37:34.928367
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # create the basic immutable dict
    immutable_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    # create another immutable dict
    immutable_dict_2 = immutable_dict.difference({'a'})
    # check if the key-value pair {'a': 1} is removed
    assert immutable_dict != immutable_dict_2
    # create another immutable dict
    immutable_dict_3 = immutable_dict.difference({'a', 'b', 'c'})
    # check if the immutable dict is empty
    assert not immutable_dict_3
    # create the basic immutable dict
    immutable_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    # create another immutable dict
    immutable_dict_4 = immutable_dict.diff

# Generated at 2022-06-20 15:37:39.153280
# Unit test for function is_string
def test_is_string():
    assert not is_string(obj=4)
    assert is_string('foo')
    assert is_string(u'foo')
    assert is_string(b'foo')



# Generated at 2022-06-20 15:37:43.638678
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2])
    assert is_sequence((1, 2))
    assert is_sequence(set([1, 2]))
    assert is_sequence({1, 2})
    assert is_sequence(dict())
    assert is_sequence(dict({'a': 1}))
    assert is_sequence(range(1, 5))
    assert is_sequence(xrange(1, 5))
    assert not is_sequence(1)
    assert not is_sequence(1.0)
    assert not is_sequence(None)
    assert not is_sequence('a string')



# Generated at 2022-06-20 15:37:48.255789
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    test_dict = ImmutableDict({"key1": "val", "key2": "val2"})
    assert isinstance(test_dict, Mapping)
    assert isinstance(test_dict, Hashable)
    assert "key1" in test_dict
    assert test_dict["key2"] == "val2"


# Generated at 2022-06-20 15:37:51.504482
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """
    Ensure __len__ works as expected
    """
    testDict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert len(testDict) == 3



# Generated at 2022-06-20 15:37:54.446352
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    # Given
    d = ImmutableDict({'answer': 42})

    # When
    size = len(d)

    # Then
    assert size == 1


# Generated at 2022-06-20 15:37:58.598332
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    mydict = ImmutableDict({'abc': 1, 'xyz': 'def'})
    # in python 2.6 repr of a class does not show the class name so it is tested in test_ImmutableDict___repr__
    assert repr(mydict) == "ImmutableDict({'abc': 1, 'xyz': 'def'})"



# Generated at 2022-06-20 15:38:01.444504
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('abc')
    assert is_iterable([1, 2])
    assert not is_iterable(None)



# Generated at 2022-06-20 15:38:19.601952
# Unit test for function count
def test_count():
    l = [1, 2, 1, 3]
    expected = {1: 2, 2: 1, 3: 1}
    actual = count(l)
    assert expected == actual
    d = {'a': 1, 'b': 2, 'a': 1, 'c': 3}
    expected = {'a': 2, 'b': 1, 'c': 1}
    actual = count(d)
    assert expected == actual
    assert count(1) is None



# Generated at 2022-06-20 15:38:29.146973
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """ Ensure that the equality operator of ImmutableDict performs as expected """
    test_dict = ImmutableDict({'test': 'dict'})
    assert test_dict == test_dict
    assert test_dict == {'test': 'dict'}
    assert test_dict == ImmutableDict({'test': 'dict'})
    assert test_dict == {'test': 'dict'}
    assert test_dict != {'test': 'invalid'}
    assert test_dict != {'test': 'dict', 'invalid': 'key'}
    assert test_dict != ImmutableDict({'test': 'invalid'})
    assert test_dict != set([('test', 'dict')])


# Generated at 2022-06-20 15:38:35.773301
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Unit test for method __hash__ of class ImmutableDict"""

    def assert_hash_equal(dict1, dict2):
        """Assert that hashes of the input ImmutableDicts are equal"""
        if abs(hash(dict1) - hash(dict2)) > 1e-6:
            raise AssertionError('Hashes of the input ImmutableDicts are not equal')

    base_dict = ImmutableDict()
    assert_hash_equal(base_dict, ImmutableDict())

    base_dict = ImmutableDict(one=1)
    assert_hash_equal(base_dict, ImmutableDict(one=1))

    base_dict = ImmutableDict(one=1, two=2)
    assert_hash_equal(base_dict, ImmutableDict(two=2, one=1))

# Generated at 2022-06-20 15:38:41.415165
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'k1': 'v1', 'k2': 'v2'})
    b = ImmutableDict({'k1': 'v1', 'k2': 'v2'})
    assert a == b
    assert a.__eq__(b)
    assert not a.__eq__({'k1': 'v1'})
    assert not b.__eq__({})


# Generated at 2022-06-20 15:38:48.282214
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'x': 1, '2': 3}) == ImmutableDict({'x': 1, '2': 3})
    assert ImmutableDict({'x': 1, '2': 3}) != ImmutableDict({'x': 1})
    assert ImmutableDict({'x': 1, '2': 3}) != ImmutableDict({'x': 1, '2': 3, 'y': 5})
    assert ImmutableDict({'x': 1, '2': 3}) == {'x': 1, '2': 3}
    assert ImmutableDict({'x': 1, '2': 3}) != {'x': 1}
    assert ImmutableDict({'x': 1, '2': 3}) != {'x': 1, '2': 3, 'y': 5}

# Generated at 2022-06-20 15:38:53.487006
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    try:
        assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    except AssertionError:
        raise AssertionError('Method __eq__ of class ImmutableDict failed')


# Generated at 2022-06-20 15:38:57.111236
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    test_dict = ImmutableDict(a=1, b=2, c=3)
    assert test_dict["a"] == 1
    assert test_dict["b"] == 2
    assert test_dict["c"] == 3


# Generated at 2022-06-20 15:38:58.681083
# Unit test for function is_string
def test_is_string():

    assert is_string("test")
    assert not is_string(None)
    assert not is_string(1)
    assert not is_string(1.0)
    assert not is_string({'a':1})

# Generated at 2022-06-20 15:39:03.711780
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(3)
    assert not is_iterable('foo')
    assert not is_iterable(b'bar')
    assert is_iterable([1, 2, 3])
    assert is_iterable({'a': 'A', 'b': 'B'})
    assert is_iterable({})
    # added by sysdoren@redhat.com
    assert is_iterable(range(5))
    assert is_iterable(5)



# Generated at 2022-06-20 15:39:06.067353
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1})
    b = ImmutableDict({'a': 1})
    assert a == b

# Generated at 2022-06-20 15:39:36.009988
# Unit test for function count
def test_count():
    from ansible.module_utils._text import to_native
    seq = [3,4,4,4,4,4,4,4,3,3,3]
    counters = count(seq)
    assert (counters[3] == 4 and counters[4] == 7)
    try:
        count('string')
        assert False, "Expected a TypeError exception"
    except TypeError as e:
        assert to_native(e) == 'Argument provided  is not an iterable', "Unexpected exception message"



# Generated at 2022-06-20 15:39:38.724619
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict({'a': 1, 'b': 2})
    assert d['a'] == 1
    assert d['b'] == 2


# Generated at 2022-06-20 15:39:44.864604
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Ensure that ImmutableDict supports all dict operations, except update."""
    immutable_dict = ImmutableDict({'a': 1, 'b': 2})
    assert(immutable_dict['a'] == 1)
    assert(len(immutable_dict) == 2)
    assert(immutable_dict.get('a') == 1)
    assert(immutable_dict.get('c') is None)
    assert('c' not in immutable_dict)



# Generated at 2022-06-20 15:39:48.887155
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    assert ImmutableDict({"a": 1, "b": 2, "c": 3}).difference(['a', 'c']) == ImmutableDict({"b": 2})
    assert ImmutableDict({"a": 1, "b": 2, "c": 3}).difference(['d']) == ImmutableDict({"a": 1, "b": 2, "c": 3})


# Generated at 2022-06-20 15:40:00.561743
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()

    assert ImmutableDict({'key': 'value'}) == ImmutableDict({'key': 'value'})
    assert ImmutableDict({'key': 'value'}) == {'key': 'value'}

    assert ImmutableDict({'keys': ['value1', 'value2']}) == ImmutableDict({'keys': ['value1', 'value2']})
    assert ImmutableDict({'keys': ['value1', 'value2']}) == {'keys': ['value1', 'value2']}

    assert ImmutableDict({'nested_key': {'nested_key': 'value'}}) == ImmutableDict({'nested_key': {'nested_key': 'value'}})

# Generated at 2022-06-20 15:40:06.643787
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Check that ImmutableDict objects are compared correctly.
    """
    assert ImmutableDict({'foo': 1, 'bar': 2}) == ImmutableDict({'foo': 1, 'bar': 2})
    assert ImmutableDict({'foo': 1, 'bar': 2}) != ImmutableDict({'foo': 1})
    assert ImmutableDict({'foo': 1}) != ImmutableDict({'foo': 2})
    assert ImmutableDict({'foo': 1}) != 'ImmutableDict({\'foo\': 1})'

# Unit tests for method union of class ImmutableDict

# Generated at 2022-06-20 15:40:14.860021
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    empty_dict = ImmutableDict()
    assert len(empty_dict) == 0

    a_dict = ImmutableDict()
    assert len(a_dict) == 0

    a_dict = ImmutableDict({'a': 1, 'b': 2})
    assert len(a_dict) == 2
    assert a_dict['a'] == 1
    assert a_dict['b'] == 2

    a_dict = ImmutableDict(a=1, b=2)
    assert len(a_dict) == 2
    assert a_dict['a'] == 1
    assert a_dict['b'] == 2

    a_dict = ImmutableDict([('a', 1), ('b', 2)])
    assert len(a_dict) == 2
    assert a_dict['a'] == 1
    assert a_dict

# Generated at 2022-06-20 15:40:17.674979
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict({'a': 1, 'b': 2})
    assert list(d) == ['a', 'b']


# Generated at 2022-06-20 15:40:26.113255
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():

    # Input data
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 'abc'})

    # Test valid keys
    assert d['a'] == 1
    assert d['c'] == 'abc'

    # Test empty key
    from ansible.module_utils.common.collections import KeyError
    try:
        d['']
        assert False
    except KeyError:
        pass
    except Exception:
        raise

    # Test invalid key
    try:
        d['d']
        assert False
    except KeyError:
        pass
    except Exception:
        raise



# Generated at 2022-06-20 15:40:30.877460
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d2 = d1.difference(('b', 'd'))
    assert d2 == {'a': 1, 'c': 3}
    assert d2 != {'a': 1, 'b': 2, 'c': 3}
    assert d1 == {'a': 1, 'b': 2, 'c': 3}



# Generated at 2022-06-20 15:41:27.400437
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    print('TEST ImmutableDictunion')
    data1 = {'a': 1, 'b': 2}
    data2 = ImmutableDict(data1)
    data2 = data2.union({'b': 'new value', 'c': 3})
    print('data1: ' + str(data1))
    print('data2: ' + str(data2))


# Generated at 2022-06-20 15:41:35.716609
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict(dict({"first": 1, "second": 2, "third": 3}))
    assert original.difference(["first", "second"]) == ImmutableDict({"third": 3})
    assert original.difference(["first", "second", "third"]) == ImmutableDict({})
    assert original.difference(["third", "first"]) == ImmutableDict({"second": 2})
    assert original.difference(["fourth"]) == ImmutableDict(original)
    assert original.difference([]) == ImmutableDict(original)

# Generated at 2022-06-20 15:41:44.989988
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    d = ImmutableDict({'a': 1, 'b': 2})
    d1 = d.union({'a': 3})
    d2 = d.union({'c': 3})
    d3 = d.union({'c': 3, 'd': 4})
    assert d1 == {'a': 3, 'b': 2}
    assert d2 == {'a': 1, 'b': 2, 'c': 3}
    assert d3 == {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert d == {'a': 1, 'b': 2}


# Generated at 2022-06-20 15:41:49.536956
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    immutable_dict = ImmutableDict({"a": 1})
    immutable_dict = immutable_dict.union({"b": 2})
    assert(immutable_dict.get("a") == 1)
    assert(immutable_dict.get("b") == 2)


# Generated at 2022-06-20 15:41:53.036952
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    ID = ImmutableDict({'a':1, 'b':2})
    keys = ['a', 'b']
    assert(all(elem in keys for elem in ID))


# Generated at 2022-06-20 15:41:56.570348
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict({'a': 'b'})) == 1


# Unit tests for method union of class ImmutableDict

# Generated at 2022-06-20 15:42:05.127043
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # ImmutableDict of "original" key-value pairs
    d1 = ImmutableDict(first=1, second=2, third=3, fourth=4)
    # Iterable of keys to be subtracted from the ImmutableDict
    subtractive_iterable = ['second', 'third']
    # ImmutableDict of keys not in subtractive_iterable
    d2 = d1.difference(subtractive_iterable)

    # Original ImmutableDict should not be modified
    assert d1 == ImmutableDict(first=1, second=2, third=3, fourth=4)
    # ImmutableDict of removed keys should be returned
    assert d2 == ImmutableDict(first=1, fourth=4)


# Generated at 2022-06-20 15:42:13.532463
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d = ImmutableDict({'a': '1', 'b': '2'})
    a = hash(ImmutableDict({'a': '1', 'b': '2'}))
    assert d.__hash__() == a
    assert hash(ImmutableDict({'a': '1', 'b': '2'})) != hash(ImmutableDict({'a': '1', 'B': '2'}))
    assert hash(ImmutableDict({'a': '1', 'b': '2'})) != hash(ImmutableDict({'a': '1', 'b': '2', 'c': '3'}))

# Generated at 2022-06-20 15:42:16.263285
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    immutable_dict = ImmutableDict(a=1, b=2)
    assert immutable_dict.union(dict(c=3)) == ImmutableDict(a=1, b=2, c=3)
    assert immutable_dict.union(dict(b=3)) == ImmutableDict(a=1, b=3)



# Generated at 2022-06-20 15:42:19.199443
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    d = ImmutableDict(a=1, b=2, c=3)
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d2 = ImmutableDict(**{'a': 1, 'b': 2, 'c': 3})
    assert d1 == d2 == d

