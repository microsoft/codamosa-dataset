

# Generated at 2022-06-20 15:33:44.706508
# Unit test for function is_sequence
def test_is_sequence():
    """Test that is_sequence() works as expected."""
    assert is_sequence([1, 2, 3])
    assert not is_sequence((1, 2, 3))
    assert not is_sequence((x for x in range(3)))
    assert not is_sequence("Hello")
    assert is_sequence("Hello", include_strings=True)



# Generated at 2022-06-20 15:33:51.033331
# Unit test for function is_iterable
def test_is_iterable():
    class Test:
        def __init__(self, a, b):
            self.a = a
            self.b = b
        def __iter__(self):
            for i in (self.a, self.b):
                yield i

    assert not is_iterable(None)
    assert not is_iterable(5)
    assert is_iterable("5")
    assert is_iterable(("5",))
    assert is_iterable([5])
    assert is_iterable(Test("5", "6"))



# Generated at 2022-06-20 15:34:01.632029
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """Make sure the ImmutableDict __hash__ implementation meets the following rules:

    1) hash(d) == hash(e) iff d == e
    2) hash(d) == hash(e) iff d == e even if d and e are instances of different classes
    """
    a = ImmutableDict({'a': 1})
    b = ImmutableDict({'b': 1})
    c = ImmutableDict({'a': 1})
    d = ImmutableDict({'a': 1, 'b': 1})
    e = ImmutableDict({'a': 1, 'b': 1, 'c': 1})
    f = dict({'a': 1})
    g = dict({'b': 1})
    h = dict({'a': 1})

# Generated at 2022-06-20 15:34:13.516220
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable((1, 2))
    assert is_iterable((x for x in range(3)))
    assert is_iterable({})
    assert is_iterable({1: 1, 2: 2})
    assert is_iterable(set())
    assert is_iterable(set([1, 2]))
    assert not is_iterable(1)
    assert not is_iterable("abc")
    assert not is_iterable(b"abc")
    assert is_iterable("abc", include_strings=True)
    assert is_iterable(b"abc", include_strings=True)
    assert not is_iterable(None)
    assert not is_iterable(object())



# Generated at 2022-06-20 15:34:24.021306
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for __eq__ method of class ImmutableDict"""
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({1: 2}) == ImmutableDict({1: 2})
    assert not ImmutableDict({1: 2}) == ImmutableDict({1: 3})
    assert not ImmutableDict({1: 2}) == ImmutableDict({1: 2, 3: 4})
    assert (ImmutableDict({1: 2, 3: 4}) == ImmutableDict({1: 2, 3: 4})) == True
    assert (ImmutableDict({1: 2, 3: 4}) == ImmutableDict({1: 2, 3: 5})) == False

# Generated at 2022-06-20 15:34:29.515040
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    # create new object
    i_dict = ImmutableDict({'a': 'value_a', 'b': 'value_b'})

    # check if repr is correct
    assert repr(i_dict) == 'ImmutableDict({\'a\': \'value_a\', \'b\': \'value_b\'})'



# Generated at 2022-06-20 15:34:32.464726
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    d = ImmutableDict({'a': 'b'})
    assert d['a'] == 'b'
    assert repr(d) == "ImmutableDict({'a': 'b'})"



# Generated at 2022-06-20 15:34:37.410054
# Unit test for function is_string
def test_is_string():
    assert is_string(b'hi') is True
    assert is_string('hi') is True
    assert is_string([b'hi']) is False
    assert is_string([1]) is False
    assert is_string(1) is False



# Generated at 2022-06-20 15:34:40.822024
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict({'a': 1, 'b': 2})

    assert d['a'] == 1
    assert d['b'] == 2


# Generated at 2022-06-20 15:34:52.141596
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    # Test different key types
    test_dict = ImmutableDict({
        'a' : 'a',
        1 : 1,
        object() : 'object',
        None : None,
        True : False,
        False : True,
        1.0 : 1.0,
        'b' : 'b'
    })

    other_dict = ImmutableDict({
        'a' : 'a',
        1 : 1,
        object() : 'object',
        None : 'None',
        True : False,
        False : True,
        1.0 : 1.0,
        'b' : 'b'
    })

    assert hash(test_dict) == hash(other_dict)

    # Test for different order of key-value pairs

# Generated at 2022-06-20 15:34:58.197717
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable(object())
    assert not is_iterable(42)
    assert is_iterable(range(5))


# Generated at 2022-06-20 15:35:07.348319
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == {}
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict(a=1, b=2) == ImmutableDict(b=2, a=1)
    assert ImmutableDict(a=1, b=2) == {'a': 1, 'b': 2}
    assert ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1, c=3)
    assert ImmutableDict(a=1, b=2) != {'a': 1, 'b': 2, 'c': 3}



# Generated at 2022-06-20 15:35:18.198733
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([1, 2, 3])
    assert not is_sequence([1, 2, 3][0:0])
    assert not is_sequence((1, 2, 3))
    assert is_sequence((1, 2, 3)[1:])
    assert not is_sequence({1, 2, 3})
    assert not is_sequence({1: 2, 3: 4})
    assert is_sequence({1, 2, 3}.copy())
    assert is_sequence(frozenset([1, 2, 3]))
    assert is_sequence(frozenset([1, 2, 3]).copy())
    assert is_sequence({1, 2, 3}.intersection())
    assert not is_sequence(xrange(3))
    assert not is_sequence(xrange(3)[0:0])

# Generated at 2022-06-20 15:35:28.989910
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    try:
        test_dict['a'] = 7
    except TypeError:
        pass
    else:
        assert False, "ImmutableDict class is not immutable"

    test_dict_2 = ImmutableDict({'a': 5, 'b': 6})
    try:
        assert test_dict_2['a'] == 5, "ImmutableDict class is not immutable"
        assert test_dict_2['b'] == 6, "ImmutableDict class is not immutable"
    except TypeError:
        assert False, "ImmutableDict class is not immutable"



# Generated at 2022-06-20 15:35:31.793965
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    context_dict = ImmutableDict({'a':'A', 'b':'B', 'c':'C'})
    assert len(context_dict) == 3


# Generated at 2022-06-20 15:35:42.121857
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():

    original = ImmutableDict({'key1': 'value1'})
    overriding_mapping = {'key2': 'value2'}
    union = original.union(overriding_mapping)
    assert union == ImmutableDict({'key1': 'value1', 'key2': 'value2'})

    original = ImmutableDict({'key1': 'value1'})
    overriding_mapping = {'key1': 'value2'}
    union = original.union(overriding_mapping)
    assert union == ImmutableDict({'key1': 'value2'})



# Generated at 2022-06-20 15:35:45.523007
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert len(d) == 3
    d = ImmutableDict()
    assert len(d) == 0


# Generated at 2022-06-20 15:35:49.655086
# Unit test for function is_string
def test_is_string():
    assert is_string("mystring")
    assert is_string("mystring".encode("utf-8"))
    assert is_string(u"mystring")
    assert not is_string(None)
    assert not is_string([])
    assert not is_string({})
    assert not is_string(("mystring"))


# Generated at 2022-06-20 15:35:50.582183
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    pass



# Generated at 2022-06-20 15:35:55.953627
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    initial_dict = ImmutableDict(a=1, b=2)
    assert initial_dict == ImmutableDict(a=1, b=2)
    overriding_dict = ImmutableDict(a=3)
    combined_dict = initial_dict.union(overriding_dict)
    assert combined_dict == ImmutableDict(a=3, b=2)


# Generated at 2022-06-20 15:36:05.736876
# Unit test for function count
def test_count():
    assert count([1, 5, 3, 1, 3, 5, 3]) == {1: 2, 3: 3, 5: 2}



# Generated at 2022-06-20 15:36:12.134555
# Unit test for function count
def test_count():
    assert count([1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3]) == {1: 4, 2: 4, 3: 4}
    assert count("The rain in Spain") == {'h': 1, 'a': 3, 'n': 2, ' ': 2, 'i': 2, 'T': 1, 'e': 1, 'r': 1, 's': 1, 'p': 1}



# Generated at 2022-06-20 15:36:23.328138
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    # Create a class to be used as a comparison
    class Test_ImmutableDict(ImmutableDict):
        def __init__(self, *args, **kwargs):
            self._store = dict(*args, **kwargs)

        def union(self, overriding_dict):
            self.update(overriding_dict)
            return self

    # Create two dictionaries:
    # original_dict for the ImmutableDict class
    # original_dict_test for the Test_ImmutableDict class
    original_dict_test = Test_ImmutableDict(a=1, b=2)
    original_dict = ImmutableDict(a=1, b=2)

    # Create the overrinding dictionary to be used in the union
    overriding_dict = {'b': 3, 'c': 4}

    # Create the

# Generated at 2022-06-20 15:36:29.423388
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    dict1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    dict2 = ImmutableDict({'key1': 'value3', 'key3': 'value4'})
    dict3 = dict1.union(dict2)
    assert len(dict3) == 3
    assert dict3['key1'] == 'value3'
    assert dict3['key2'] == 'value2'
    assert dict3['key3'] == 'value4'

# Test for method difference of class ImmutableDict

# Generated at 2022-06-20 15:36:33.698223
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    expected_result = ImmutableDict({'a': 1, 'b': 2})
    actual_result = ImmutableDict({'a': 1, 'b': 2})
    assert repr(expected_result) == repr(actual_result)


# Generated at 2022-06-20 15:36:43.982109
# Unit test for function count
def test_count():
    from ansible.module_utils._text import to_native, to_text
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins

    def mockprint(*args):
        print(*args, file=output)

    items = [1, 1, 1, 2, 2, 'a', 'a', 'b', 'c']
    output = StringIO()
    mockbuiltin = {'print': mockprint}
    counts = count(items)
    with mock.patch.multiple('ansible.module_utils.common._collections_compat', print_function=mockprint, builtins=mockbuiltin):
        assert counts == {1: 3, 2: 2, 'a': 2, 'b': 1, 'c': 1}


# Generated at 2022-06-20 15:36:46.319552
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    idict = ImmutableDict({'key1': 'val1', 'key2': 'val2'})
    assert idict['key1'] == 'val1'



# Generated at 2022-06-20 15:36:48.893251
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict([(1,'one'),(2,'two')],three='three')
    assert list(d.__iter__()) == [1,2,'three']


# Generated at 2022-06-20 15:36:55.498870
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    # Test case 1: {1:1, 2:2, 3:3}
    dict_1 = ImmutableDict({1:1, 2:2, 3:3})
    iter_1 = iter(dict_1)
    assert getattr(iter_1, '__iter__', False)
    next(iter_1) == 1
    next(iter_1) == 2
    next(iter_1) == 3



# Generated at 2022-06-20 15:37:00.130272
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    mutable_dictionary = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    immutable_dictionary = ImmutableDict(mutable_dictionary)

    # assert that dictionary 'key1' will return expected value
    assert(immutable_dictionary.__getitem__('key1') == 'value1')


# Generated at 2022-06-20 15:37:25.121480
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    import pytest
    from six import PY2

    d1 = ImmutableDict({'a': 1, 'b': 2})
    if PY2:
        msg = 'unhashable type: \'ImmutableDict\''
    else:
        msg = 'unhashable type: \'dict\''
        assert hash(d1) == hash(d1)
        assert hash(d1) != hash(d1.union({'c': 3}))

    with pytest.raises(TypeError, message=msg) as excinfo:
        hash({})
    assert excinfo.match(msg)

    with pytest.raises(TypeError, message=msg) as excinfo:
        hash({'a': 1, 'b': 2})
    assert excinfo.match(msg)


# Generated at 2022-06-20 15:37:30.722283
# Unit test for function count
def test_count():
    assert count([1, 1, 1, 2, 2, 3]) == {1: 3, 2: 2, 3: 1}
    assert count([]) == dict()
    try:
        count("test")
        assert False, "string should not be counted"
    except Exception:
        pass



# Generated at 2022-06-20 15:37:38.924724
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    # Constructing from multiple sources
    class MyMapping(Mapping):
        def __init__(self, d):
            self.d = d
        def __getitem__(self, key):
            return self.d[key]
        def __iter__(self):
            return self.d.__iter__()
        def __len__(self):
            return self.d.__len__()

    input_dict = {'a': 1, 'b': 2}
    input_mapping = MyMapping(input_dict)
    input_keywords = {'c': 3, 'd': 4}
    m = ImmutableDict(input_dict, **input_keywords)
    m2 = ImmutableDict(input_mapping, **input_keywords)
    assert m == m2

# Generated at 2022-06-20 15:37:46.673513
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    assert ImmutableDict(a=1, b=2).union(dict(c=3)) == ImmutableDict(a=1, b=2, c=3)
    assert ImmutableDict(a=1, b=2).union(dict(b=3)) == ImmutableDict(a=1, b=3)
    assert ImmutableDict().union(dict(b=1)) == ImmutableDict(b=1)
    assert ImmutableDict(a=1, b=2).union(dict()) == ImmutableDict(a=1, b=2)


# Generated at 2022-06-20 15:37:51.089438
# Unit test for function count
def test_count():
    c = count([])
    assert c == {}

    c = count([1, 2, 1, 4, 5, 2, 4, 5, 5, 1, 4, 5, 5, 1, 4, 5, 5, 4])
    assert c == {1: 4, 2: 2, 4: 6, 5: 8}



# Generated at 2022-06-20 15:37:55.129646
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    """Test of the method __repr__ of the ImmutableDict"""
    test_dict = {'key': 'value'}
    result = ImmutableDict(test_dict).__repr__()
    assert result == 'ImmutableDict({0})'.format(repr(test_dict))


# Generated at 2022-06-20 15:37:58.441745
# Unit test for function is_string
def test_is_string():
    assert not is_string([])
    assert is_string("")
    assert is_string("a")
    assert not is_string({})
    assert not is_string({'k': 42})
    assert not is_string(42)


# Generated at 2022-06-20 15:37:58.992315
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    pass

# Generated at 2022-06-20 15:38:07.835687
# Unit test for function is_iterable
def test_is_iterable():
    # pylint: disable=unused-variable
    assert not is_iterable(None)
    assert not is_iterable('')
    assert not is_iterable(b'')
    assert not is_iterable(10)
    assert not is_iterable(1.1)
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable(set())
    assert is_iterable(dict())
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable(None)
    assert not is_iterable(1, include_strings=True)
    assert is_iterable('', include_strings=True)
    assert is_iterable(b'', include_strings=True)



# Generated at 2022-06-20 15:38:16.162996
# Unit test for function is_sequence
def test_is_sequence():
    seqs = [
        [1, 2, 3],
        (1, 2, 3),
        'abc',
        b'abc',
        u'abc',
        ImmutableDict(),
        ImmutableDict({'a': 1, 'b': 2}),
    ]
    for seq in seqs:
        assert is_sequence(seq, include_strings=True)
        assert is_iterable(seq, include_strings=True)
        assert not is_sequence(seq, include_strings=False)
        assert not is_iterable(seq, include_strings=False)



# Generated at 2022-06-20 15:38:39.662889
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    # test 1 - simple
    original_dict = ImmutableDict({'a': '1', 'b': '2', 'c': '3'})
    overriding_mapping = {'d': '4', 'e': '5'}
    result_dict = original_dict.union(overriding_mapping)
    assert result_dict['a'] == '1'
    assert result_dict['b'] == '2'
    assert result_dict['c'] == '3'
    assert result_dict['d'] == '4'
    assert result_dict['e'] == '5'
    # test 2 - with replacements
    original_dict = ImmutableDict({'a': '1', 'b': '2', 'c': '3'})

# Generated at 2022-06-20 15:38:43.707056
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """Test that __len__() works as expected"""
    a = ImmutableDict(a=1, b=2, c=3)
    assert len(a) == 3
    assert len(a.union(replacement_a=0)) == 3
    assert len(a.difference(['b'])) == 2



# Generated at 2022-06-20 15:38:49.500058
# Unit test for function is_iterable
def test_is_iterable():
    # Check that strings are not treated as iterable by default
    assert not is_iterable("test_str")

    # Check that AnsibleVaultEncryptedUnicode is treated as iterable
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode
    vault = VaultLib([])
    vault = AnsibleVaultEncryptedUnicode(vault, "test_pass")

    assert is_iterable("test_str", include_strings=True)
    assert is_iterable(["test_str"], include_strings=True)
    assert is_iterable(vault, include_strings=True)

    # Check that non iterable objects are not treated as iterable
    assert not is_iterable(object(), include_strings=True)



# Generated at 2022-06-20 15:38:54.889180
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d1 = ImmutableDict(a=1, b="2")

    d2 = ImmutableDict(
        {
            "a": 1,
            "b": "2"
        }
    )

    d3 = ImmutableDict(a=1, b=[2, 3])

    assert d1 == d2
    assert d1 != d3
    assert d2 != d3



# Generated at 2022-06-20 15:38:57.189780
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict({'test': 'success'})
    assert d['test'] == 'success'


# Generated at 2022-06-20 15:38:59.321952
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable({2: 3}) is True
    assert is_iterable(range(0, 2)) is True
    assert is_iterable(()) is True
    assert is_iterable(xrange(0, 2)) is False
    assert is_iterable('test') is False


# Generated at 2022-06-20 15:39:07.912690
# Unit test for function is_sequence
def test_is_sequence():
    """Unit tests for function is_sequence."""
    assert is_sequence([])
    assert is_sequence((1, 2))
    assert is_sequence(())
    assert is_sequence(range(1, 10))
    assert not is_sequence({})
    assert not is_sequence({1: 2})
    assert not is_sequence(set())
    assert not is_sequence(1)
    assert not is_sequence(str())
    assert not is_sequence(u'unicode')
    assert not is_sequence(b'binary')
    assert not is_sequence(bytearray(b'bytearray'))



# Generated at 2022-06-20 15:39:13.020440
# Unit test for function count
def test_count():
    test_list = [1, 2, 2, 1, 2, 3]
    assert count(test_list) == {1: 2, 2: 3, 3: 1}
    try:
        count(5)
    except Exception:
        pass
    else:
        raise Exception('No exception raised when trying to use a non iterable argument')



# Generated at 2022-06-20 15:39:23.002137
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    from ansible.module_utils.pycompat24 import collections
    # Positive cases
    val = ImmutableDict({'d1': '1', 'd2': '2'})
    assert val.__hash__() == hash(collections.OrderedDict({'d1': '1', 'd2': '2'}))
    val = ImmutableDict(value1='1', value2='2')
    assert val.__hash__() == hash(collections.OrderedDict({'value1': '1', 'value2': '2'}))

    # Negative cases
    val = ImmutableDict({'d1': '1', 'd2': '2'})
    assert val.__hash__() != hash(collections.OrderedDict({'d2': '2'}))
    val = Immutable

# Generated at 2022-06-20 15:39:34.462141
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1) == ImmutableDict(a=1)
    assert ImmutableDict(a=1) == {'a': 1}
    assert ImmutableDict(a=1) == {'a': 1, 'b': 2}
    assert ImmutableDict(a=1, b=2) == {'a': 1, 'b': 2}
    assert ImmutableDict(a=1) == ImmutableDict(a=2)
    assert ImmutableDict(a=1) == ImmutableDict(b=1)
    assert ImmutableDict(a=1) != ImmutableDict(b=1)
    assert ImmutableDict(a=1) != 'a'
    assert ImmutableDict(a=1) != ['a']

# Generated at 2022-06-20 15:40:13.817397
# Unit test for function count
def test_count():
    # List
    my_list = range(10)
    counters = count(my_list)
    # Each element should appear only once
    for elem in my_list:
        assert counters[elem] == 1
    # Tuple
    my_tuple = (1, 2, 3, 2)
    counters = count(my_tuple)
    # 1 appears once
    assert counters[1] == 1
    # 2 appears twice
    assert counters[2] == 2
    # 3 appears once
    assert counters[3] == 1
    # Nonexistent element
    from pytest import raises
    with raises(KeyError):
        assert counters[4]
    # Dict (__iter__)
    my_dict = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-20 15:40:24.624160
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    """Test the ImmutableDict union() method."""
    assert ImmutableDict(a='b').union(dict(c='d')) == ImmutableDict(a='b', c='d')
    assert ImmutableDict(a='b').union(ImmutableDict(c='d')) == ImmutableDict(a='b', c='d')
    assert ImmutableDict(a='b').union(dict(a='d')) == ImmutableDict(a='d')
    assert ImmutableDict(a='b').union(dict(a='d', c='d')) == ImmutableDict(a='d', c='d')
    assert ImmutableDict().union(dict()) == ImmutableDict()


# Generated at 2022-06-20 15:40:33.234108
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Test the consturctor of ImmutableDict"""
    from ansible.module_utils._text import to_bytes

    # The ImmutableDict constructor is pretty simple and hence can be tested in one unit test
    # The constructor takes in *args and **kwargs
    # The output should be a dict

    # args is a tuple of dicts. Convert args to list
    # test with args, and kwargs
    args = [{'arg1': 'val1', 'arg2': 'val2'}, {'arg3': 'val3', 'arg4': 'val4'}]
    # kwargs is a dict
    kwargs = {'kwarg5': 'v5', 'kwarg6': 'v6'}
    # The output should have all the key-value pairs of the dicts in args and kwargs
   

# Generated at 2022-06-20 15:40:35.414985
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    temp_dict = ImmutableDict({"test": "succeed"})
    assert temp_dict["test"] == "succeed"


# Generated at 2022-06-20 15:40:40.611957
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    from collections import OrderedDict

    d = OrderedDict((('a', 1), ('b', 2), ('c', 3)))
    id = ImmutableDict(d)

    for i, v in enumerate(id.__iter__()):
        assert v == list(d.keys())[i]


# Generated at 2022-06-20 15:40:42.628764
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert not is_iterable(5)


# Generated at 2022-06-20 15:40:48.375967
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict({'a': '1', 'b': '2', 'c': '3'})
    subtractive_iterable = frozenset(['a', 'c'])
    result = original.difference(subtractive_iterable)
    expected = ImmutableDict({'b': '2'})
    assert result == expected

# Generated at 2022-06-20 15:40:55.648766
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    temp = ImmutableDict(key='value')
    assert temp.items() == {'key': 'value'}
    assert ImmutableDict(key='value').union({'key': 'value2'}).items() == {'key': 'value2'}
    assert ImmutableDict(key='value').union({'key2': 'value'}).items() == {'key': 'value', 'key2': 'value'}
    assert ImmutableDict(key='value', key2='value').union({'key': 'value2'}).items() == {'key': 'value2', 'key2': 'value'}
    assert ImmutableDict(key='value').difference(['key']).items() == {}
    assert ImmutableDict(key='value', key2='value').difference(['key']).items

# Generated at 2022-06-20 15:40:57.535040
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert ImmutableDict({'a': 'b', 'c': 'd'}).__repr__() == 'ImmutableDict({\'c\': \'d\', \'a\': \'b\'})'


# Generated at 2022-06-20 15:41:00.939182
# Unit test for function is_iterable
def test_is_iterable():
    iterable = [1, 2, 3]
    non_iterable = 10
    assert is_iterable(iterable)
    assert not is_iterable(non_iterable)



# Generated at 2022-06-20 15:42:08.297169
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """Test the constructor of ImmutableDict"""
    d = ImmutableDict(a=1, b=2)
    assert d['a'] == 1
    assert d['b'] == 2
    assert repr(d) == "ImmutableDict({'a': 1, 'b': 2})"

    e = ImmutableDict(d, a=2, c=3)
    assert e['a'] == 2
    assert e['b'] == 2
    assert e['c'] == 3
    assert repr(e) == "ImmutableDict({'a': 2, 'b': 2, 'c': 3})"

    f = ImmutableDict({'a': 4, 'b': 5, 'c': 6})
    assert f['a'] == 4
    assert f['b'] == 5
    assert f['c'] == 6



# Generated at 2022-06-20 15:42:15.351046
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    ImmutableDict1 = ImmutableDict()
    ImmutableDict2 = ImmutableDict(foo='bar')
    ImmutableDict3 = ImmutableDict(foo='bar', bar='baz')

    assert hasattr(ImmutableDict1, '__iter__')
    assert hasattr(ImmutableDict2, '__iter__')
    assert hasattr(ImmutableDict3, '__iter__')

    assert list(ImmutableDict1) == []
    assert list(ImmutableDict2) == ['foo']
    assert ('foo' in list(ImmutableDict2))
    assert ('bar' not in list(ImmutableDict2))
    assert ('bar' in list(ImmutableDict3))
    assert ('foo' in list(ImmutableDict3))



# Generated at 2022-06-20 15:42:17.114952
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert repr(ImmutableDict({'a': 1, 'b': 2, 'c': 3})) == "ImmutableDict({'a': 1, 'b': 2, 'c': 3})"



# Generated at 2022-06-20 15:42:18.709992
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    t_id = ImmutableDict({"a": 1, "b": 2, "c": 3})
    assert t_id["a"] == 1


# Generated at 2022-06-20 15:42:22.626632
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert ImmutableDict().__repr__() == 'ImmutableDict({})'
    assert ImmutableDict({'foo': 'bar'}).__repr__() == "ImmutableDict({'foo': 'bar'})"



# Generated at 2022-06-20 15:42:29.592558
# Unit test for function is_string
def test_is_string():
    class Test:
        pass

    assert is_string(u"text")
    assert is_string("text")
    assert is_string(b"bytes")
    assert is_string(b"bytes".decode("ascii"))

    assert not is_string("text".encode("utf-8"))
    assert not is_string([])
    assert not is_string(Test())
    assert not is_string(1)
    assert not is_string(None)



# Generated at 2022-06-20 15:42:31.579519
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict({'a': 1})
    assert d['a'] == 1


# Generated at 2022-06-20 15:42:34.386409
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict(a = 1, b = 2)
    assert d.__repr__() == "ImmutableDict({'a': 1, 'b': 2})"


# Generated at 2022-06-20 15:42:40.707217
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable(()) is True
    assert is_iterable(set()) is True
    assert is_iterable(dict()) is True
    assert is_iterable(['foo']) is True
    assert is_iterable(('foo',)) is True
    assert is_iterable({'foo': 'bar'}) is True
    assert is_iterable('foo') is True
    assert is_iterable(u'foo') is True
    assert is_iterable(1) is False
    assert is_iterable(2.0) is False
    assert is_iterable(1j) is False
    assert is_iterable(False) is False
    assert is_iterable(None) is False

    class Foo():
        def __iter__(self):
            return iter(())

# Generated at 2022-06-20 15:42:46.343515
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    """Test for value extraction from ImmutableDict object"""
    idict = ImmutableDict([('key1', 'value1'), ('key2', 'value2')])
    assert idict['key1'] == 'value1'
    assert idict['key2'] == 'value2'
    try:
        idict['key3'] == 'value3'
    except KeyError:
        pass
    else:
        raise AssertionError

