

# Generated at 2022-06-20 15:33:46.596296
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import collections
    assert ImmutableDict(val='first') == ImmutableDict(val='first')
    assert not ImmutableDict(val='first', val1='second') == ImmutableDict(val='first')
    assert ImmutableDict(val='first', val1='second') == ImmutableDict(val1='second', val='first')
    assert not ImmutableDict(val='first', val1='second') == ImmutableDict(val1='first', val='second')
    assert not ImmutableDict(val='first') == 'first'
    assert not ImmutableDict(val='first') == {'val': 'first'}
    assert not ImmutableDict(val='first') == collections.Counter('first')


# Generated at 2022-06-20 15:33:51.531726
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    d1 = ImmutableDict([("a", 1), ("b", 2), ("c", 3)])
    d2 = ImmutableDict([("a", 1), ("c", 4), ("d", 5)])
    d3 = ImmutableDict([("a", 1), ("c", 4), ("b", 2), ("d", 5)])
    assert d1.union(d2) == d3


# Generated at 2022-06-20 15:33:56.981185
# Unit test for function count
def test_count():
    assert count([1, 2, 3, 2, 3, 2, 3, 2, 3, 2, 3, 2, 3]) == {1: 1, 2: 7, 3: 6}
    assert count([1, 1, 1]) == {1: 3}
    assert count([]) == {}
    assert count((1, 1, 1)) == {1: 3}
    assert count(x for x in range(10)) == {0: 1, 1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 1, 7: 1, 8: 1, 9: 1}



# Generated at 2022-06-20 15:34:02.151253
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d2 = ImmutableDict({'b': 'four', 'd': 5})

    assert d1.union(d2) == ImmutableDict({'a': 1, 'b': 'four', 'c': 3, 'd': 5})



# Generated at 2022-06-20 15:34:14.929745
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence([1])
    assert not is_sequence(1)
    assert is_sequence((1,2))
    assert is_sequence((1,))
    assert not is_sequence(set([1]))
    assert is_sequence({1:2})
    assert not is_sequence({})  # dict is not an sequence
    assert is_sequence(['a','b'])
    assert is_sequence('abc')
    assert not is_sequence('a')
    assert not is_sequence(u'a')
    assert is_sequence({'a':1}, include_strings=False) # dict is not an sequence
    assert is_sequence('abc', include_strings=True)
    assert is_sequence(u'abc', include_strings=True)
    assert is_sequence(('abc',))


# Generated at 2022-06-20 15:34:21.151375
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    """ImmutableDict union method unit test"""
    d0 = ImmutableDict([('a', 'a'), ('b', 3)])
    d1 = ImmutableDict([('a', 'A'), ('c', 'C')])
    assert d0.union(d1) == ImmutableDict([('a', 'A'), ('b', 3), ('c', 'C')])



# Generated at 2022-06-20 15:34:26.246896
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    immutable_dict = ImmutableDict(dict(first=1, second=2))
    immutable_dict_union = immutable_dict.union(dict(third=3))
    assert(isinstance(immutable_dict_union, ImmutableDict))
    assert(len(immutable_dict_union) == 3)
    assert(immutable_dict_union.get("first") == 1)
    assert(immutable_dict_union.get("second") == 2)
    assert(immutable_dict_union.get("third") == 3)


# Generated at 2022-06-20 15:34:30.071949
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    d = ImmutableDict()
    assert d[1] == {}
    d = ImmutableDict({'a': 1, 'b': 2})
    assert d['a'] == 1
    assert d['b'] == 2



# Generated at 2022-06-20 15:34:36.573685
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    assert hash(ImmutableDict((('a', 'a'), ('b', 'b'), ('c', 'c')))) == hash(ImmutableDict((('b', 'b'), ('c', 'c'), ('a', 'a'))))
    assert hash(ImmutableDict((('a', 'a'), ('b', 'b'), ('c', 'c')))) != hash(ImmutableDict((('a', 'a'), ('b', 'b'), ('d', 'c'))))
    assert hash(ImmutableDict((('a', 'a'), ('b', 'b'), ('c', 'c')))) != hash(ImmutableDict((('a', 'a'), ('b', 'b'))))


# Generated at 2022-06-20 15:34:49.593895
# Unit test for function count
def test_count():
    assert count("abca") == {'a': 2, 'c': 1, 'b': 1}
    assert count("aaaa") == {'a': 4}
    assert count("abcaabca") == {'a': 4, 'c': 2, 'b': 2}
    assert count("") == {}
    assert count(["a", "b"]) == {'a': 1, 'b': 1}
    assert count(("a", "b")) == {'a': 1, 'b': 1}
    try:
        count("test", [])
    except Exception as e:
        assert e.message == 'Argument provided  is not an iterable'
    try:
        count(["test", "test"], [])
    except Exception as e:
        assert e.message == 'Argument provided  is not an iterable'



# Generated at 2022-06-20 15:34:58.741342
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    i = ImmutableDict({'a1': 1, 'a2': 2, 'a3': 3, 'a4': 4})
    i_diff = i.difference(['a1', 'a3'])
    assert len(i_diff) == 2 and 'a1' not in i_diff and 'a3' not in i_diff

# Generated at 2022-06-20 15:35:09.512840
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict0 = ImmutableDict()
    dict1 = ImmutableDict({1: 2})
    dict2 = ImmutableDict({1: 2})
    dict3 = ImmutableDict({1: 2, 3: 4})

    assert(dict0 == dict0)
    assert(dict1 == dict1)
    assert(dict2 == dict2)
    assert(dict3 == dict3)

    assert(dict0 != dict1)
    assert(dict0 != dict2)
    assert(dict0 != dict3)
    assert(dict1 != dict0)
    assert(dict2 != dict0)
    assert(dict3 != dict0)

    assert(dict1 != dict2)
    assert(dict1 != dict3)
    assert(dict2 != dict1)
    assert(dict3 != dict1)


# Generated at 2022-06-20 15:35:14.885502
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    """
    Test the method __len__ of class ImmutableDict

    """
    d = ImmutableDict()
    assert len(d) == 0
    d = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert len(d) == 2


# Generated at 2022-06-20 15:35:18.498945
# Unit test for function is_string
def test_is_string():
    """
    Tests the function is_string
    """
    assert is_string(u'Test')
    assert is_string('Test')
    assert not is_string([u'Test'])
    assert not is_string({u'Test': u'Test'})

# Generated at 2022-06-20 15:35:30.840004
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    source = ImmutableDict(a_key='source_value', b_key='source_value')
    difference_set = set(['a_key'])
    expected_result = {'b_key': 'source_value'}
    actual_result = source.difference(difference_set)
    assert len(actual_result) == len(expected_result)
    assert len(actual_result) == 1
    assert actual_result == expected_result

    difference_set = set(['non_existing_key'])
    actual_result = source.difference(difference_set)
    assert len(actual_result) == len(expected_result)
    assert len(actual_result) == 2
    assert actual_result == source

    difference_set = set()

# Generated at 2022-06-20 15:35:39.457691
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    # create an ImmutableDict and retrieve an existing key
    a = ImmutableDict(dict(a='a', b='b'))
    assert a['a'] == 'a'

    # create an ImmutableDict and retrieve a non-existing key
    b = ImmutableDict(dict(a='a', b='b'))
    try:
        b['c']
    except KeyError as e:
        c = e
    assert c is not None


# Generated at 2022-06-20 15:35:46.119402
# Unit test for function is_string
def test_is_string():
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.common.text.converters import to_unicode

    assert not is_string(removed)
    assert not is_string(None)
    assert not is_string(True)
    assert not is_string(False)
    assert not is_string(1)
    assert not is_string(0)
    assert not is_string(1.2)
    assert not is_string(1.0)
    assert not is_string({})
    assert not is_string([])
    assert is_string(to_unicode(u'foo'))
    assert is_string(b'foo')



# Generated at 2022-06-20 15:35:53.389854
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    test_dict = ImmutableDict(test1='value1', test2='value2', test3='value3')
    test_keys = ['test1', 'test2', 'test3']
    for key in test_dict:
        try:
            assert key in test_keys
            test_keys.remove(key)
        except ValueError:
            assert False, "the tested object returned a key that was not expected"
    assert not test_keys, "the tested object does not return all keys"


# Generated at 2022-06-20 15:36:01.156519
# Unit test for function is_string
def test_is_string():
    from ansible.parsing.vault import VaultLib
    assert is_string('hello')
    assert is_string(u'hello')
    assert not is_string([u'hello'])
    assert not is_string((u'hello',))
    assert not is_string({'hello': 'world'})
    assert not is_string({u'hello': u'world'})
    assert not is_string(None)

    # Vault encrypted string is considered a string
    vl = VaultLib([])
    assert is_string(vl.encrypt('hello'))


# Generated at 2022-06-20 15:36:04.683664
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    assert len(ImmutableDict()) == 0
    assert len(ImmutableDict({'a': 1})) == 1
    assert len(ImmutableDict(a=1, b=2)) == 2
    assert len(ImmutableDict([('a', 1), ('b', 2)])) == 2


# Generated at 2022-06-20 15:36:14.584394
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    assert repr(ImmutableDict({'a': 1, 'b': 2})) == 'ImmutableDict({u\'a\': 1, u\'b\': 2})'


# Generated at 2022-06-20 15:36:24.533507
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d1 = ImmutableDict((('a', 1), ('b', 2)))
    d2 = ImmutableDict((('a', 1), ('b', 2)))
    d3 = ImmutableDict((('a', 1), ('b', 2), ('c', 3)))
    d4 = ImmutableDict((('A', 1), ('b', 2)))
    assert d1.__hash__() == d2.__hash__()
    assert d1.__hash__() == hash(d2)
    assert d1.__hash__() != hash(d3)
    assert d1.__hash__() != hash(d4)
    assert hash(d1) == hash(d2)


# Generated at 2022-06-20 15:36:31.361112
# Unit test for function count
def test_count():
    assert count("abca") == {'a': 2, 'b': 1, 'c': 1}
    assert count("") == {}
    assert count(['a', 'b', 'c', 'b', 'a']) == {'a': 2, 'b': 2, 'c': 1}
    assert count((0, 0, 0, 1, 1, 1)) == {0: 3, 1: 3}
    assert count({}) == {}
    assert count({1: 0, 'a': 'a', 'b': 0, 'c': 'c'}) == {1: 0, 'a': 'a', 'b': 0, 'c': 'c'}


# Generated at 2022-06-20 15:36:36.094600
# Unit test for function count
def test_count():
    assert count([]) == dict()
    assert count([1, 2, 3]) == {1: 1, 2: 1, 3: 1}
    assert count([1, 2, 1, 1]) == {1: 3, 2: 1}
    assert count([1, 1, 1]) == {1: 3}



# Generated at 2022-06-20 15:36:39.819864
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict([("a", 1), ("b", 2)])
    assert d.__repr__() == 'ImmutableDict({0})'.format(repr(dict([("a", 1), ("b", 2)])))


# Generated at 2022-06-20 15:36:48.638799
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    def test_immutable():
        immutable_dict_1 = ImmutableDict({'a': 1, 'b': 2})
        assert immutable_dict_1 == {'b': 2, 'a': 1}

        immutable_dict_2 = immutable_dict_1.union({'b': 3})
        assert immutable_dict_1 == {'b': 2, 'a': 1}
        assert immutable_dict_2 == {'b': 3, 'a': 1}

        immutable_dict_3 = immutable_dict_1.difference(['a'])
        assert immutable_dict_1 == {'b': 2, 'a': 1}
        assert immutable_dict_3 == {'b': 2}

    test_immutable()

# Generated at 2022-06-20 15:36:54.973715
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    testdict = {1: 2, 4: 6, 10: 54}
    expected_repr = "ImmutableDict({0})".format(repr(testdict))
    assert repr(ImmutableDict(testdict)) == expected_repr, (
        "expected {0}, got {1}".format(expected_repr, repr(ImmutableDict(testdict)))
    )


# Generated at 2022-06-20 15:37:01.978371
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable([]) is True
    assert is_iterable({'k1': 'v1', 'k2': 'v2'}) is True
    assert is_iterable({}) is True
    assert is_iterable(set([1, 2, 3])) is True
    assert is_iterable(set()) is True
    assert is_iterable(is_iterable) is True
    assert is_iterable('abcd') is True
    assert is_iterable(b'abcd') is True
    assert is_iterable(1) is False



# Generated at 2022-06-20 15:37:05.696127
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    a = ImmutableDict({'a': 1, 'b': 2})
    b = a.union({'b': 3, 'c': 4})
    assert a == {'a': 1, 'b': 2}
    assert b == {'a': 1, 'b': 3, 'c': 4}


# Generated at 2022-06-20 15:37:14.149731
# Unit test for method union of class ImmutableDict
def test_ImmutableDict_union():
    # given
    immutable_dict = ImmutableDict({'a': 1, 'b': 2})

    # when
    immutable_dict_union = immutable_dict.union({'a': 3, 'c': 4})

    # then
    assert (immutable_dict != immutable_dict_union)
    assert (immutable_dict_union.union({'d': 5}) == ImmutableDict({'a': 1, 'b': 2, 'c': 4, 'd': 5}))
    assert (immutable_dict_union['a'] == 3)
    assert (immutable_dict_union['b'] == 2)
    assert (immutable_dict_union['c'] == 4)
    assert (not immutable_dict_union.union({}))
    assert (not immutable_dict_union.union({}))


# Unit test

# Generated at 2022-06-20 15:37:38.230185
# Unit test for function is_string
def test_is_string():
    # AnsibleVaultEncryptedUnicode inherits from Sequence, but is expected to be a string like object
    assert is_string('foo') is True
    assert is_string('') is True
    assert is_string(u'foo') is True
    assert is_string(u'') is True
    assert is_string(u'foo'.encode('utf-8')) is True
    assert is_string(b'foo') is True
    assert is_string(b'') is True
    assert is_string(1) is False
    assert is_string(None) is False
    assert is_string(True) is False
    assert is_string(False) is False
    assert is_string([]) is False
    assert is_string(()) is False
    assert is_string({}) is False

# Generated at 2022-06-20 15:37:40.497729
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    original = {'name': 'test1', 'value': 4}
    immutable_dict = ImmutableDict(original)
    repr_result = repr(immutable_dict)
    assert repr(original) == repr_result, \
        'repr(ImmutableDict) did not return the same representation as repr(dict)'


# Generated at 2022-06-20 15:37:42.099897
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d1 = ImmutableDict()
    assert len(d1) == 0

    d2 = ImmutableDict({"a": 1, "b": 2, "c": 3})
    assert len(d2) == 3



# Generated at 2022-06-20 15:37:52.925474
# Unit test for function is_sequence
def test_is_sequence():
    """Test function is_sequence to verify correct work.

    Test cases:
    1. Test is_sequence returns False for a string.
    2. Test is_sequence returns True for a list.
    3. Test is_sequence returns False for an object with __getitem__.
    """
    from ansible_collections.ansible.misc.tests.unit.compat.mock import Mock

    # Test case 1
    assert not is_sequence('string')

    # Test case 2
    assert is_sequence([], True)

    # Test case 3
    assert not is_sequence(Mock(spec=['__getitem__']))


# Generated at 2022-06-20 15:37:56.442599
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    data={"a":1,"b":2}
    immudata = ImmutableDict(data)
    assert immudata['a'] == 1
    assert immudata['b'] == 2


# Generated at 2022-06-20 15:38:04.458915
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    k, v = 'k', 'v'

    # Default constructor
    i = ImmutableDict()
    assert(len(i) == 0)

    # Dictionary constructor
    i = ImmutableDict({k: v})
    assert(i[k] == v)

    # Keyword arguments constructor
    i = ImmutableDict(k=v)
    assert(len(i) == 1)
    assert(i[k] == v)

    # __getitem__
    assert(i.get(k) == v)
    assert(i.get('invalid') is None)

    # __iter__
    assert(list(i) == [k])

    # __len__
    assert(len(i) == 1)

    # __hash__

# Generated at 2022-06-20 15:38:11.426654
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence([1, 2])
    assert not is_sequence({})
    assert not is_sequence(set())
    assert not is_sequence('unicode')
    assert not is_sequence(u'unicode')
    assert not is_sequence(b'bytes')
    assert not is_sequence(1)
    assert is_sequence([], include_strings=True)
    assert is_sequence([1, 2], include_strings=True)
    assert is_sequence('unicode', include_strings=True)
    assert is_sequence(u'unicode', include_strings=True)
    assert is_sequence(b'bytes', include_strings=True)


# Generated at 2022-06-20 15:38:21.724751
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """Ensure ImmutableDict.difference works as expected"""
    data_dict = ImmutableDict({'a': 'a', 'b': 'b'})
    data_list = ['b', 'c']
    data_dict2 = data_dict.difference(data_list)

    # Ensure ImmutableDict.difference returns a new instance of ImmutableDict
    assert data_dict2 is not data_dict
    # Ensure ImmutableDict.difference has removed the key 'b'
    assert data_dict2 == ImmutableDict({'a': 'a'})

    # Ensure multiple occurances of the same key are removed
    data_dict3 = ImmutableDict({'a': 'a', 'b': 'b', 'c': 'c'})

# Generated at 2022-06-20 15:38:24.201191
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    d = ImmutableDict([('key1', 'value1'), ('key2', 'value2')])
    i = d.__iter__()
    assert next(i) == 'key1'
    assert next(i) == 'key2'


# Generated at 2022-06-20 15:38:31.241166
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('abc') == False
    assert is_iterable(['1', '2', '3']) == True
    assert is_iterable(('1', '2', '3')) == True
    assert is_iterable(['1', 2, '3']) == True
    assert is_iterable(['1', 2, '3'], include_strings=True) == True
    assert is_iterable({'1', 2, '3'}) == True
    assert is_iterable({'k1': 'v1', 'k2': 'v2'}) == True

# Generated at 2022-06-20 15:39:02.355764
# Unit test for function count
def test_count():
    assert count([1, 1, 2, 2, 3, 3, 3, 4, 5]) == {1: 2, 2: 2, 3: 3, 4: 1, 5: 1}



# Generated at 2022-06-20 15:39:05.757616
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    d = ImmutableDict({'a':'b'})
    assert(repr(d) == "ImmutableDict({'a': 'b'})")



# Generated at 2022-06-20 15:39:13.919241
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    # Using ImmutableDict constructor with arguments
    my_dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert my_dict1['a'] == 1
    assert my_dict1['b'] == 2
    assert my_dict1['c'] == 3
    # Using ImmutableDict constructor with keyword arguments
    my_dict2 = ImmutableDict(a=1, b=2, c=3)
    assert my_dict2['a'] == 1
    assert my_dict2['b'] == 2
    assert my_dict2['c'] == 3


# Generated at 2022-06-20 15:39:21.075931
# Unit test for method __repr__ of class ImmutableDict
def test_ImmutableDict___repr__():
    '''
    Unit test for method __repr__ of class ImmutableDict by verifying the format of the string representation
    '''
    # Create a test dictionary to be used in ImmutableDict
    test_dict = {'key1': 1, 'key2': 'value2'}
    # Create ImmutableDict object
    immut_dict = ImmutableDict(test_dict)
    # Validate that the string representation is correct
    assert str(immut_dict) == 'ImmutableDict({\'key1\': 1, \'key2\': \'value2\'})'


# Generated at 2022-06-20 15:39:32.545426
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    testDict = ImmutableDict({'a': 1, 'b': 2})
    assert testDict.__eq__({'a': 1, 'b': 2})
    assert testDict.__eq__(ImmutableDict({'a': 1, 'b': 2}))
    assert not testDict.__eq__({'a': 1})
    assert not testDict.__eq__(ImmutableDict({'a': 1}))
    assert testDict.union({'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
    assert testDict.union({'a': 3}) == {'a': 3, 'b': 2}
    assert testDict.union({'b': 3}) == {'a': 1, 'b': 3}
    assert testDict.diff

# Generated at 2022-06-20 15:39:39.074383
# Unit test for function is_sequence
def test_is_sequence():
    assert is_sequence([])
    assert is_sequence((x for x in range(3)))
    assert is_sequence(range(3))
    assert not is_sequence(set())
    assert not is_sequence(dict())
    assert not is_sequence(u'abc')
    assert not is_sequence(b'abc')
    assert is_sequence(u'abc', True)
    assert is_sequence(b'abc', True)



# Generated at 2022-06-20 15:39:45.492132
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test case 1
    a = ImmutableDict({'name': 'Foo', 'age': '25'})
    b = ImmutableDict({'name': 'Foo', 'age': '25'})
    assert a == b
    # Test case 2
    a = ImmutableDict({'name': 'Foo', 'age': '25'})
    b = ImmutableDict({'name': 'Foo', 'age': '26'})
    assert not a == b


# Generated at 2022-06-20 15:39:51.936320
# Unit test for constructor of class ImmutableDict
def test_ImmutableDict():
    """
    Test for the ImmutableDict function
    """

    # Test construction of ImmutableDict from an iterable and from keyword args
    test_dict = ImmutableDict([(1, 'one'), ('two', 2), ('three', 'four')])
    test_dict2 = ImmutableDict((('five', 'six'), ('seven', 'eight'), ('one', 'nine')))
    test_imm_dict = ImmutableDict(test_dict)
    assert test_dict == test_imm_dict
    assert isinstance(test_imm_dict, ImmutableDict)
    test_imm_dict2 = ImmutableDict(one=1, two=2, three=3)
    assert test_imm_dict2 == {'one': 1, 'two': 2, 'three': 3}

# Generated at 2022-06-20 15:39:59.932606
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    """
    >>> test_data = dict()
    >>> test_data[ImmutableDict({'key': 'value'})] = True
    >>> test_data[ImmutableDict({'key': 'value'})]
    True
    >>> test_data[ImmutableDict({'other_key': 'value'})] = True
    >>> test_data[ImmutableDict({'other_key': 'value'})]
    True
    >>> len(test_data)
    2
    """


# Generated at 2022-06-20 15:40:03.755913
# Unit test for method __iter__ of class ImmutableDict
def test_ImmutableDict___iter__():
    immutable_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    iterator = iter(immutable_dict)
    items = list(immutable_dict.items())
    for item in immutable_dict:
        assert item in items
        items.remove(item)


# Generated at 2022-06-20 15:41:07.122374
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    d = ImmutableDict([(1, 2), ('3', 4), (5, 6)])
    assert 3 == len(d)



# Generated at 2022-06-20 15:41:11.177610
# Unit test for method __len__ of class ImmutableDict
def test_ImmutableDict___len__():
    foo_dict = ImmutableDict({"a": "b", "c": "d", "e": "f"})
    if len(foo_dict) != 3:
        raise Exception("test_ImmutableDict___len__: len(foo_dict) != 3")


# Generated at 2022-06-20 15:41:14.292921
# Unit test for function count
def test_count():
    assert len(count({'a': 1, 'b': 2})) == 2
    assert count(['a', 'a', 'b']) == {'a': 2, 'b': 1}

# TODO: Drop this when support for Python < 2.7 is dropped.

# Generated at 2022-06-20 15:41:23.433747
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    from random import randint
    from random import shuffle

    dict_ = dict()
    for i in range(1, 10):
        key = randint(0, 1000)
        value = randint(0, 1000)
        dict_[key] = value

    for i in range(1, 10):
        dict_keys = list(dict_.keys())
        shuffle(dict_keys)
        shuffled_dict_key_1 = dict_keys
        shuffled_dict_key_2 = dict_keys.copy()

        shuffled_dict_value_1 = list(dict_values)
        shuffled_dict_value_2 = list(dict_values.copy())


# Generated at 2022-06-20 15:41:34.308656
# Unit test for function is_sequence
def test_is_sequence():
    from ansible.module_utils.common.text.converters import to_text
    assert is_sequence([])
    assert is_sequence(())
    assert is_sequence([1, 2, 3])
    assert is_sequence((1, 2, 3))
    assert is_sequence((1, (2, 3)))
    assert not is_sequence(None)
    assert not is_sequence(1)
    assert not is_sequence(set())
    assert is_sequence(set((1, 2, 3)))
    assert not is_sequence({})
    assert is_sequence({'a': 2, 'b': 3})
    assert not is_sequence(u'abc')
    assert not is_sequence(to_text(u'abc'))
    assert not is_sequence(b'abc')
    assert is_sequence(range(3))

# Generated at 2022-06-20 15:41:39.006050
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    from ansible.module_utils._text import to_bytes
    d1 = ImmutableDict(((u'a', 1), (u'b', 2)))
    b1 = ImmutableDict(((u'a', 1), (u'b', 2)))
    d2 = ImmutableDict(((u'a', 1), (u'b', 2)))
    d3 = ImmutableDict(((u'a', 1.0), (u'b', 2.0)))
    d4 = ImmutableDict(((u'a', u'1'), (u'b', u'2')))
    d5 = ImmutableDict(((u'b', 2), (u'a', 1)))

    e1 = frozenset(((u'a', 1), (u'b', 2)))

# Generated at 2022-06-20 15:41:43.838240
# Unit test for method __getitem__ of class ImmutableDict
def test_ImmutableDict___getitem__():
    immutable_dict = ImmutableDict({'1': '1', '3': '3', '2': '2'})
    assert immutable_dict['1'] == '1'
    assert immutable_dict['2'] == '2'
    assert immutable_dict['3'] == '3'


# Generated at 2022-06-20 15:41:53.292572
# Unit test for function is_iterable
def test_is_iterable():
    positive_test = ('TEST_STRING_POSITIVE', ['TEST_SEQUENCE_POSITIVE'], ('TEST_TUPLE_POSITIVE',))
    negative_test = 'TEST_STRING_NEGATIVE'
    negative_test_string = True
    negative_test_sequence = False

    for test_item in positive_test:
        assert is_iterable(test_item)

    assert is_iterable(negative_test, include_strings=True)
    assert not is_iterable(negative_test, include_strings=False)
    assert is_iterable(negative_test_string, include_strings=True)
    assert not is_iterable(negative_test_string, include_strings=False)
    assert is_iterable(negative_test_sequence, include_strings=True)


# Generated at 2022-06-20 15:42:00.260391
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_dict = dict(a=1, b=2, c=3)
    test_immutable_dict = ImmutableDict(a=1, b=2, c=3)
    test_immutable_dict_difference = test_immutable_dict.difference(['a'])
    assert test_immutable_dict is not test_immutable_dict_difference
    assert isinstance(test_immutable_dict, ImmutableDict)
    assert isinstance(test_immutable_dict_difference, ImmutableDict)
    assert test_dict == test_immutable_dict._store
    assert test_dict != test_immutable_dict_difference._store
    assert test_immutable_dict_difference._store == dict(b=2, c=3)


# Generated at 2022-06-20 15:42:02.886191
# Unit test for method __hash__ of class ImmutableDict
def test_ImmutableDict___hash__():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert hash(d1) == hash(d2)
