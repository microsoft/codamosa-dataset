

# Generated at 2022-06-11 00:47:49.147743
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable("test") is False
    assert is_iterable("test", include_strings=True) is True
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable(1) is False
    assert is_iterable(set([1, 2, 3])) is True
    assert is_iterable({1, 2, 3}) is True
    assert is_iterable(1, 2, 3) is True
    assert is_iterable(True) is False
    assert is_iterable(1.1) is False
    assert is_iterable(None) is False
    assert is_iterable(object()) is False
    assert is_iterable(frozenset([1, 2, 3])) is True



# Generated at 2022-06-11 00:47:54.196108
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test of ImmutableDict.__eq__()"""
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    c = ImmutableDict({'a': 1, 'b': 3})
    d = ImmutableDict({'a': 1, 'c': 3})
    e = {'a': 1, 'b': 2}

    assert a == b
    assert a != c
    assert a != d
    assert a != e

# Generated at 2022-06-11 00:48:06.702486
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict

    :return: void. if this function fails, it throws assertion errors.
    """
    # Tests that hash function is consistent
    assert hash(ImmutableDict({"a": "b"})) == hash(ImmutableDict({"a": "b"}))
    assert hash(ImmutableDict({"a": "c"})) == hash(ImmutableDict({"a": "c"}))
    assert hash(ImmutableDict({"a": "b"})) != hash(ImmutableDict({"a": "c"}))
    assert hash(ImmutableDict({"a": "b", "c": "d"})) != hash(ImmutableDict({"a": "b"}))

# Generated at 2022-06-11 00:48:16.977594
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Note that this test is not exhaustive.

    # Create an immutable dictionary
    immutable_dict = ImmutableDict(soft_cheese=9999, crunchy_cheese=9, extra_crunchy_cheese=True)

    # Check that argument __eq__ should be a mapping
    assert not immutable_dict.__eq__(0), '__eq__ should be a mapping'
    assert not immutable_dict.__eq__([]), '__eq__ should be a mapping'
    assert not immutable_dict.__eq__(tuple()), '__eq__ should be a mapping'

    # Check that argument __eq__ should have the same keys as original immutable_dict
    assert not immutable_dict.__eq__({'soft_cheese': 9999}), '__eq__ should have the same keys as original immutable_dict'

    # Check that

# Generated at 2022-06-11 00:48:29.204524
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Tests for equality by calling the __eq__ method
    x = ImmutableDict({'a': 1, 'b': 2})
    y = ImmutableDict({'a': 3, 'b': 2})

    xy_same_dict = x.__eq__(y)
    assert not xy_same_dict
    xy_same_dict = y.__eq__(x)
    assert not xy_same_dict

    ydict = dict(y)
    x_eq_y_dict = x.__eq__(ydict)
    assert not x_eq_y_dict
    y_eq_x_dict = y.__eq__(ydict)
    assert not y_eq_x_dict

    ydict['a'] = 1

# Generated at 2022-06-11 00:48:40.524055
# Unit test for function is_iterable
def test_is_iterable():
    """
    Test cases for function is_iterable
    """
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    assert is_iterable([]) == True
    assert is_iterable({}) == True
    assert is_iterable(set()) == True
    assert is_iterable(()) == True
    assert is_iterable(1) == False
    assert is_iterable('test') == False
    assert is_iterable(u'test') == False
    assert is_iterable(to_bytes('test')) == False
    try:
        assert is_iterable('test'.encode('ascii')) == False
    except UnicodeDecodeError:
        assert is_iterable

# Generated at 2022-06-11 00:48:49.646120
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    # test each possible combination
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict() == {}
    assert ImmutableDict() == dict()
    assert ImmutableDict(a=1) == ImmutableDict(a=1)
    assert ImmutableDict(a=1) == {'a': 1}
    assert ImmutableDict(a=1) == dict(a=1)
    assert ImmutableDict() != ImmutableDict(a=1)
    assert ImmutableDict() != {'a': 1}
    assert ImmutableDict() != dict(a=1)
    assert ImmutableDict(a=1) != ImmutableDict(a=2)
    assert ImmutableDict(a=1) != {'a': 2}

# Generated at 2022-06-11 00:48:52.584837
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    adict = ImmutableDict(a=1, b=2)
    bdict = ImmutableDict(b=2, a=1)
    adict == bdict



# Generated at 2022-06-11 00:49:02.674018
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())

    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable((element for element in range(0)))

    assert is_iterable(x for x in range(0))

    assert is_iterable('')
    assert is_iterable(b'')

    assert not is_iterable(1)
    assert not is_iterable(None)
    assert not is_iterable(True)


# Generated at 2022-06-11 00:49:11.311436
# Unit test for function is_iterable
def test_is_iterable():
    class Iterable(object):
        def __iter__(self):
            return []

    class Iterator(object):
        def __next__(self):
            return 1

    class NotIterable(object):
        pass

    assert is_iterable([])
    assert is_iterable(Iterable())
    assert is_iterable(iter([]))
    assert is_iterable(Iterator())
    assert not is_iterable(None)
    assert not is_iterable(NotIterable())
    assert not is_iterable('abc')


# Generated at 2022-06-11 00:49:17.365976
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 'b']) is True
    assert is_iterable('ab') is False
    # Empty lists and dicts are iterable
    assert is_iterable([]) is True
    assert is_iterable({}) is True



# Generated at 2022-06-11 00:49:25.354933
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable({})
    assert is_iterable([])
    assert not is_iterable(1)
    assert not is_iterable(True)
    assert not is_iterable(None)
    assert is_iterable(set())
    assert is_iterable((i for i in [1, 2]))
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable(b'')
    assert is_iterable('str')
    assert is_iterable(u'str')
    assert is_iterable(b'str')
    assert is_iterable(set())
    assert not is_iterable(set(), include_strings=True)
    assert not is_iterable('str', include_strings=True)

# Generated at 2022-06-11 00:49:36.231349
# Unit test for function is_iterable
def test_is_iterable():
    class NonIterableClass(object):
        def __init__(self):
            pass
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable(set(['a', 'b', 'c']))
    assert is_iterable(set(['a', 'b', 'c']), include_strings=True)
    assert is_iterable((x for x in [1, 2, 3]))
    assert is_iterable(NonIterableClass()) == False
    assert is_iterable(dict(a=1, b=2, c=3))
    assert is_iterable(dict(a=1, b=2, c=3).keys())
    assert is_iterable(dict(a=1, b=2, c=3).values())

# Generated at 2022-06-11 00:49:39.125612
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    assert (ImmutableDict({'name': 'joe'}) == ImmutableDict({'name': 'joe'}))


# Generated at 2022-06-11 00:49:41.046430
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    lhs = ImmutableDict(a=1)
    rhs = ImmutableDict(a=1)

    assert(lhs == rhs)


# Generated at 2022-06-11 00:49:52.488932
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable(list()))
    assert(is_iterable(list()))
    assert(is_iterable(set()))
    assert(is_iterable(dict()))
    assert(is_iterable(tuple([])))

    # Strings are not iterable unless we set "include_strings=True"
    assert(is_iterable("", include_strings=True))
    assert(not is_iterable(""))

    # Strings are sequences
    assert(is_sequence("", include_strings=True))
    assert(not is_sequence(""))

    # String are not iterable
    assert(not is_iterable("", include_strings=False))

    # Arrays are iterable
    assert(is_iterable(array('i', [1, 2, 3]), include_strings=True))


# Generated at 2022-06-11 00:50:02.878902
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import copy
    import random
    import string

    random_strings = [''.join(random.choice(string.ascii_letters) for _ in range(10))
                      for _ in range(20)]
    random_ints = [random.randint(-100, 100) for _ in range(20)]


# Generated at 2022-06-11 00:50:14.367044
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Given
    d1 = ImmutableDict({'foo': 'bar'})
    d2 = ImmutableDict({'foo': 'baz'})
    d3 = ImmutableDict({'foo': 'bar'})

    # Then
    assert d1 == d3
    assert d1 == {'foo': 'bar'}
    assert {'foo': 'bar'} == d1
    assert d1 != d2
    assert d1 != {}
    assert {} != d1
    assert d1 != 'foo'
    assert 'foo' != d1
    assert d1 != ['foo']
    assert ['foo'] != d1
    assert d1 != 1
    assert 1 != d1
    assert d1 != 1.1
    assert 1.1 != d1
    assert d1 != True
    assert True != d1

# Generated at 2022-06-11 00:50:20.994292
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('')
    assert is_iterable('123')
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1: 1, 2: 2, 3: 3})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(object()) is False
    assert is_iterable(None) is False

    assert is_iterable('')
    assert is_iterable('123')
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1: 1, 2: 2, 3: 3})
    assert is_iterable(set([1, 2, 3]))
    assert is_iter

# Generated at 2022-06-11 00:50:27.252455
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 'b'})
    b = ImmutableDict({'a': 'b'})
    c = ImmutableDict({'a': 'c'})

    assert a == b, "ImmutableDict.__eq__ is not working properly"
    assert a != c, "ImmutableDict.__eq__ is not working properly"



# Generated at 2022-06-11 00:50:34.430933
# Unit test for function is_iterable
def test_is_iterable():
    """Verifies function is_iterable."""
    # pylint: disable=R0903,R0201
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert is_iterable([])
    assert is_iterable([0])
    assert is_iterable((0,))
    assert is_iterable({'a': 0})
    assert is_iterable(set())
    assert is_iterable(set([0]))
    assert is_iterable(range(1))
    assert is_iterable('abc')



# Generated at 2022-06-11 00:50:38.785386
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict(a=5) == ImmutableDict(a=5)
    assert ImmutableDict(a=5) != ImmutableDict(b=5)
    assert ImmutableDict(a=5) != ImmutableDict(a=6)
    assert ImmutableDict(a=5) != ImmutableDict(a=5, b=6)


# Generated at 2022-06-11 00:50:45.058805
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    #Compares the two ImmutableDicts
    immutableDict1 = ImmutableDict({'a':1, 'b':2})
    immutableDict2 = ImmutableDict({'b':2, 'a':1})
    assert(immutableDict1 == immutableDict2)
    assert(immutableDict1.__eq__(immutableDict2))


# Generated at 2022-06-11 00:50:47.680605
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({1: 'foo', 2: 'bar'})
    b = ImmutableDict({2: 'bar', 1: 'foo'})
    assert a == b

# Generated at 2022-06-11 00:50:52.995239
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([0])
    assert is_iterable((0,))
    assert is_iterable({0: 0})
    assert is_iterable([[0], {0: 0}])
    assert is_iterable(set((0,)))
    assert is_iterable(range(10))
    assert not is_iterable(0)
    assert not is_iterable(object())


# Generated at 2022-06-11 00:50:56.395134
# Unit test for function is_iterable
def test_is_iterable():
    """Identify whether the input is an iterable."""
    assert is_iterable([])
    assert is_iterable("string")
    assert not is_iterable(1)
    assert not is_iterable(None)



# Generated at 2022-06-11 00:51:08.070655
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a'])
    assert is_iterable([])
    assert is_iterable((1,))
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(dict())
    assert is_iterable(3) is False
    assert is_iterable('3') is False
    assert is_iterable(iter(['a', 'b', 'c']))
    assert is_iterable(range(5))
    assert is_iterable(iter(range(5)))
    assert is_iterable(iter(range(5)), include_strings=True)
    assert is_iterable(b'abc', include_strings=True)
    assert not is_iterable(3)
    assert not is_iterable('3')
    assert not is_iterable

# Generated at 2022-06-11 00:51:19.733468
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(text_type('123')), "Strings must be iterable"
    assert is_iterable(binary_type('123')), "binary strings must be iterable"
    assert is_iterable(b'123'), "binary strings must be iterable"
    assert is_iterable(['1', 2, 3]), "Lists must be iterable"
    assert is_iterable((1, 2, 3)), "Tuples must be iterable"
    assert is_iterable({"one": 1, "two": 2}), "Dictionaries must be iterable"
    assert not is_iterable('123'), "Characters must not be iterable"
    assert not is_iterable(123), "Numbers must not be iterable"
    assert not is_iterable(object), "Classes must not be iterable"

# Generated at 2022-06-11 00:51:28.549969
# Unit test for function is_iterable
def test_is_iterable():
    """Unit test for is_iterable function."""
    from numbers import Integral
    from collections import Mapping, Sequence

    class A(Integral):
        def __init__(self, value):
            self._value = value

        def __int__(self):
            return self._value

        def __index__(self):
            return self._value

    class NamedSequence(Sequence):
        def __init__(self, name, sequence):
            self._name = name
            self._sequence = list(sequence)

        def __getitem__(self, index):
            return self._sequence[index]

        def __len__(self):
            return len(self._sequence)

    class NamedMapping(Mapping):
        def __init__(self, name, mapping):
            self._name = name
            self._mapping

# Generated at 2022-06-11 00:51:40.351787
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(a=1, b=2)
    d3 = ImmutableDict(a=2, b=1)
    d4 = ImmutableDict(a=2)
    d5 = dict(a=1, b=2)

    assert d1 == d1
    assert d1 == d2
    assert d2 == d1
    assert d1.__eq__(d1)
    assert d1.__eq__(d2)
    assert d2.__eq__(d1)

    assert not (d1 == d3)
    assert not (d1 == d4)
    assert not (d1 == d5)

    assert not d1.__eq__(d3)

# Generated at 2022-06-11 00:51:58.294058
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    class SomeClass:
        pass
    class_instance = SomeClass()
    mut_dict = {'a': 'b', 'c': [1, 2, 3], 'd': {class_instance: 'a'}}
    non_hashable_item = {class_instance: 'a'}
    # Test case 1:
    test_dict = ImmutableDict(mut_dict)
    assert test_dict == mut_dict
    # Test case 2:
    test_dict = ImmutableDict()
    assert test_dict != mut_dict
    # Test case 3:
    mut_dict['d'] = non_hashable_item
    test_dict = ImmutableDict(mut_dict)
    assert test_dict != mut_dict
    # Test case 4:

# Generated at 2022-06-11 00:52:01.257768
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert not is_iterable(1)



# Generated at 2022-06-11 00:52:12.154321
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict()
    d2 = ImmutableDict()
    assert d1 == d2

    d1 = ImmutableDict(something='else')
    assert d1 != d2

    d2 = ImmutableDict(something='else')
    assert d1 == d2

    d2 = ImmutableDict(something='different')
    assert d1 != d2

    d2 = ImmutableDict(different='else')
    assert d1 != d2

    d1 = ImmutableDict(something=ImmutableDict())
    d2 = ImmutableDict(something=ImmutableDict())
    assert d1 == d2

    d1 = ImmutableDict(something=ImmutableDict())

# Generated at 2022-06-11 00:52:22.680578
# Unit test for function is_iterable

# Generated at 2022-06-11 00:52:29.006955
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable('')
    assert is_iterable(b'')
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(object())
    assert not is_iterable(set() - set())



# Generated at 2022-06-11 00:52:34.948951
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})

    assert not is_iterable(None)
    assert not is_iterable('a')

    # test is_iterable is False for string-like items
    class TestString(text_type):
        pass

    assert TestString()
    assert not is_iterable(TestString())


# Generated at 2022-06-11 00:52:43.002356
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # check two identical dicts
    a = ImmutableDict({'foo': 1, 'bar': 2})
    b = ImmutableDict({'foo': 1, 'bar': 2})
    assert(a == b)

    # check two dicts with same values but different keys
    b = ImmutableDict({'foo': 1, 'bar': 2, 'baz': 3})
    assert(a != b)

    # check two dicts with same keys but different values
    b = ImmutableDict({'foo': 2, 'bar': 2})
    assert(a != b)

    # check against non-dicts
    assert(a != 1)
    assert(a != [1, 2])



# Generated at 2022-06-11 00:52:55.780581
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # trivial tests
    assert not ImmutableDict() == ImmutableDict({'a': 1})
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})

    # repeating items are counted
    assert not ImmutableDict({'a': 1, 'b': 1}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 1}) == ImmutableDict({'a': 1, 'b': 1})
    assert ImmutableDict({'a': 1, 'b': 1}) == ImmutableDict({'b': 1, 'a': 1})

    # item order doesn't matter

# Generated at 2022-06-11 00:53:04.152305
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import unittest
    import sys

    class test_ImmutableDict(unittest.TestCase):
        def test_ImmutableDict(self):
            a = ImmutableDict({'a':1})
            c = ImmutableDict({'a':1})
            self.assertEqual(a, c)
            self.assertTrue(a == c)
            self.assertFalse(a is c)
            self.assertFalse(a != c)

    suite = unittest.TestLoader().loadTestsFromTestCase(test_ImmutableDict)
    unittest.TextTestRunner(stream=sys.stdout, verbosity=2).run(suite)

# Generated at 2022-06-11 00:53:15.603086
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # In this test method, we only test the case, when both of the objects
    # are instances of class ImmutableDict.
    # The reason for this is, that this method uses both __hash__ and __eq__
    # methods at the same time, and both these methods were already tested.
    # So (re)testing them here totally would be an overkill.
    dict1 = ImmutableDict()
    dict2 = ImmutableDict()
    dict3 = ImmutableDict({'a': 1, 'b': 2})
    dict4 = ImmutableDict({'b': 2, 'a': 1})
    dict5 = ImmutableDict({'b': 2, 'a': 2})
    dict6 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict7 = ImmutableDict

# Generated at 2022-06-11 00:53:36.557537
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of class ImmutableDict
    """
    dict_1 = ImmutableDict(a=1)
    dict_2 = ImmutableDict(a=1)
    dict_3 = ImmutableDict(a=2)
    dict_4 = ImmutableDict(b=1)

    assert dict_1 == dict_2
    assert dict_1 != dict_3
    assert dict_1 != dict_4
    assert dict_1 != text_type('a')

# Generated at 2022-06-11 00:53:47.374654
# Unit test for function is_iterable
def test_is_iterable():
    # Basic types should not be iterable
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable("hello")
    assert not is_iterable(b"hello")
    assert not is_iterable(set())
    assert not is_iterable(())
    # Sequences should be iterable
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set("hello"))
    assert is_iterable(set([1, 2, 3]))
    # Streaming should be iterable
    assert is_iterable(x for x in range(10))
    # Mappings should be iterable
    assert is_iterable({})
    assert is_iter

# Generated at 2022-06-11 00:53:57.451448
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit tests for ImmutableDict class method __eq__

    :return: True if test passed, False if test failed
    :rtype: bool
    """
    def test(a, b, expected_result, test_name):
        """Compare object equality with expected_result.

        :arg a, b: Objects to compare
        :arg expected_result: Expected equality result
        :arg test_name: Name of the test
        :return: True if test passed, False if test failed
        :rtype: bool
        """
        a_eq_b = a == b
        b_eq_a = b == a
        msg = 'Test {0} failed:'.format(test_name)

# Generated at 2022-06-11 00:54:05.412586
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({1: 2, 3: 4}) == ImmutableDict({1: 2, 3: 4})
    assert not ImmutableDict({1: 2, 3: 4}) == ImmutableDict({1: 2, 3: 6})
    assert not ImmutableDict({1: 2, 3: 4}) == {}
    assert not {} == ImmutableDict({1: 2, 3: 4})
    assert ImmutableDict({1: 2, 3: 4}) == ImmutableDict({3: 4, 1: 2})
    assert ImmutableDict() == ImmutableDict()

# Generated at 2022-06-11 00:54:15.426515
# Unit test for function is_iterable
def test_is_iterable():
    if is_iterable([]):
        print("list is an iterable")
    else:
        print("list is not an iterable")

    if is_iterable(dict()):
        print("dict is an iterable")
    else:
        print("dict is not an iterable")

    if is_iterable(set()):
        print("set is an iterable")
    else:
        print("set is not an iterable")

    if is_iterable(tuple()):
        print("tuple is an iterable")
    else:
        print("tuple is not an iterable")

    if is_iterable("string"):
        print("string is an iterable")
    else:
        print("string is not an iterable")


# Generated at 2022-06-11 00:54:21.702844
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    class DerivedImmutableDict(ImmutableDict):
        def __hash__(self):
            return hash(frozenset(self.items()))
    base_dict = ImmutableDict(state2name={'AK': 'Alaska'})
    other_dict = ImmutableDict(state2name={'AK': 'Alaska'})
    derived_dict = DerivedImmutableDict(state2name={'AK': 'Alaska'})
    not_hashable_dict = ImmutableDict(state2name={'AK': 'Alaska'}, state2abbrev=['AL', 'AK'])
    assert (base_dict == other_dict)
    assert (base_dict == derived_dict)
    assert (not (base_dict == not_hashable_dict))



# Generated at 2022-06-11 00:54:28.599734
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(range(10))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable('string')
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(1.1)
    assert not is_iterable(True)
    assert is_iterable((1, 2, 3))

# Generated at 2022-06-11 00:54:34.355639
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable("1")
    assert is_iterable("")
    assert is_iterable(1)
    assert is_iterable([1])
    assert is_iterable((1))
    assert is_iterable({1})
    assert is_iterable({})
    assert is_iterable((1,2))
    assert is_iterable((1,))


# Generated at 2022-06-11 00:54:40.066431
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable(set((1, 2, 3)))
    assert is_iterable(dict(a=1, b=2, c=3))
    assert is_iterable(1) is False
    assert is_iterable('Hello, World!') is False

    class NonIterable(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    assert is_iterable(NonIterable()) is False



# Generated at 2022-06-11 00:54:51.164964
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2, 'c': 3})
    assert not is_iterable(10)
    assert not is_iterable(10.5)
    assert is_iterable('abc')
    assert is_iterable(u'a\N{GREEK CAPITAL LETTER THETA}')
    assert not is_iterable(b'abc')  # why?
    assert is_iterable(b'abc', include_strings=True)
    assert is_iterable(u'a\N{GREEK CAPITAL LETTER THETA}', include_strings=True)
    class Foo(object):
        def __iter__(self):
            return iter('')


# Generated at 2022-06-11 00:55:21.976275
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d = ImmutableDict(a=1)
    assert (d == d)
    assert (d == {'a': 1})
    assert (d != {'b': 1})
    assert (d != ImmutableDict(a=1,b=2))

# Generated at 2022-06-11 00:55:28.562140
# Unit test for function is_iterable

# Generated at 2022-06-11 00:55:35.598339
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == dict()
    assert ImmutableDict() == ImmutableDict()
    assert not ImmutableDict() == ImmutableDict(a=1)
    assert ImmutableDict(a=1) == ImmutableDict(a=1)
    assert not ImmutableDict(a=1) == ImmutableDict(b=1)
    assert not ImmutableDict(a=1) == ImmutableDict(a=2)


# Generated at 2022-06-11 00:55:41.431258
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Arrange
    empty_immutable_dict = ImmutableDict()
    dict_with_value = ImmutableDict({'b': 'b'})
    other_immutable_dict = ImmutableDict({'b': 'b'})
    other_dict = {'b': 'b'}
    # Act and assert
    assert empty_immutable_dict.__eq__(other_immutable_dict) == True
    assert dict_with_value.__eq__(other_immutable_dict) == True
    assert other_immutable_dict.__eq__(empty_immutable_dict) == True
    assert empty_immutable_dict.__eq__(other_dict) == False

# Generated at 2022-06-11 00:55:48.255411
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({"k1": "v1", "k2": "v2"})
    d2 = ImmutableDict({"k1": "v1", "k2": "v2"})
    assert d1 == d2
    d2 = ImmutableDict({"k1": "v1"})
    assert not d1 == d2
    d2 = ImmutableDict({"k1": "v1", "k2": "v2"})
    assert not d1 == d2
    assert not d1 == object()
    assert not d1 == 1


# Generated at 2022-06-11 00:55:51.361255
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('str') == False
    assert is_iterable(1) == False
    assert is_iterable(b'bytes') == False
    assert is_iterable(set()) == True
    assert is_iterable(['a', 'b', 'c']) == True

# Generated at 2022-06-11 00:56:02.493243
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({1: 2})

    # __eq__ expects an ImmutableDict on the right hand side
    assert a == ImmutableDict({1: 2})
    assert not a == ImmutableDict({1: 1})

    # Preserving the __hash__ of frozenset, ImmutableDict should
    # compare equal to a frozenset with identical key-value pairs
    # (i.e. hashable items and the number of occurrences of those items).
    assert a == frozenset([(1, 2)])
    assert a != frozenset([(1, 1), (1, 2)])

    # Other types don't compare equal as the fallback mechanism is
    # to compute the hash and compare it to the hash of the ImmutableDict,
    # which naturally doesn't match.

# Generated at 2022-06-11 00:56:05.954708
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({1: 'A', 2: 'B'})
    b = ImmutableDict({1: 'A', 2: 'B'})

    assert a == b
    assert a.__eq__(b)



# Generated at 2022-06-11 00:56:14.761715
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert (ImmutableDict({'a': 1}) == ImmutableDict({'a': 1}))
    assert (ImmutableDict({'a': 1}) != ImmutableDict({'a': 2}))
    assert (ImmutableDict({'a': 1}) != ImmutableDict({'b': 1}))
    assert (ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2}))
    assert (ImmutableDict({'a': 1}) != {'a': 1})
    assert (ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2}))
    assert (ImmutableDict({'a': 1}) != ImmutableDict({'a': 1}).union({'b': 2}))


# Unit test

# Generated at 2022-06-11 00:56:23.417269
# Unit test for function is_iterable
def test_is_iterable():
    """Tests for function is_iterable"""
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1: 'a', 2: 'b', 3: 'c'})
    assert is_iterable({1, 2, 3})
    assert is_iterable('abc')
    assert is_iterable('abc', include_strings=True)
    assert is_iterable(b'abc')
    assert is_iterable(b'abc', include_strings=True)
    assert is_iterable(1) is False


# Generated at 2022-06-11 00:57:29.274463
# Unit test for function is_iterable
def test_is_iterable():
    """
    Run tests on function 'is_iterable'.
    """
    # tests on sequences
    test_sequence = [1, 2, 3]
    assert is_iterable(test_sequence)
    assert is_iterable(test_sequence, include_strings=True)
    assert is_sequence(test_sequence)
    assert is_sequence(test_sequence, include_strings=True)

    # tests on strings
    test_string = '123'
    assert not is_iterable(test_string)
    assert is_iterable(test_string, include_strings=True)
    assert not is_sequence(test_string)
    assert not is_sequence(test_string, include_strings=True)

    # tests on byte strings
    test_bytes = b'123'

# Generated at 2022-06-11 00:57:37.447492
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_one = ImmutableDict()
    dict_two = ImmutableDict()
    assert dict_one == dict_two
    dict_one = ImmutableDict({'a': 4, 'b': 'foo'})
    dict_two = ImmutableDict({'a': 4, 'b': 'foo'})
    dict_three = ImmutableDict({'a': 5, 'b': 'foo'})
    assert dict_one == dict_two
    assert dict_one != dict_three
    assert dict_one != 'foo'

