

# Generated at 2022-06-11 00:47:40.415259
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """ImmutableDict.__eq__() should return True if the hashes of both ImmutableDicts are the same"""

    # Arrange
    d1 = ImmutableDict([
        ('a', [1, 2, 3])
    ])
    d2 = ImmutableDict([
        ('a', [1, 2, 3])
    ])
    d3 = ImmutableDict([
        ('a', [1, 2, 3]),
        ('b', {
            'c': 4
        })
    ])

    # Act/Assert - It should be equal to itself
    assert d1 == d1

    # Act/Assert - It should be equal to a copy of itself
    assert d1 == d2

    # Act/Assert - It should not be equal to another ImmutableDict
    assert not d1 == d3

   

# Generated at 2022-06-11 00:47:50.127354
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    id1 = ImmutableDict({'x':1, 'y':[1,2,3]})
    id2 = ImmutableDict({'x':1, 'y':[1,2,3]})
    id3 = ImmutableDict({'x':3, 'y':[1,2,3]})

    # equality checks
    assert id1 == id1
    assert id1 == id2
    assert id1 != id3

    # iterable equality checks
    assert id1 == {'x':1, 'y':[1,2,3]}
    assert id1 != {'x':1, 'y':[1,2,4]}

    # double equality check
    assert id1 == id2 == {'x':1, 'y':[1,2,3]}

# Generated at 2022-06-11 00:47:52.699123
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(a=1, b=2)

    assert d1 == d2

# Generated at 2022-06-11 00:47:59.212988
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable1 = ImmutableDict({"foo": {"bar": 1}})
    immutable2 = ImmutableDict({"foo": {"bar": 1}})
    assert immutable1 == immutable2
    assert immutable2 == immutable1
    immutable3 = ImmutableDict({"foo": {"bar": 2}})
    assert immutable1 != immutable3
    assert immutable3 != immutable1
    assert immutable2 != immutable3
    assert immutable3 != immutable2

# Generated at 2022-06-11 00:48:07.453121
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1) == ImmutableDict(a=1)
    assert not ImmutableDict(a=1) == ImmutableDict(a=2)
    assert not ImmutableDict(a=1) == ImmutableDict(a=1, b=2)
    assert not ImmutableDict(a=1) == ImmutableDict(b=1)
    assert not ImmutableDict(a=1) == {'a': 1}


# Generated at 2022-06-11 00:48:11.343021
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    source_dict = dict(one=1, two=2)
    immutable_dict = ImmutableDict(one=1, two=2)
    assert immutable_dict == source_dict
    assert immutable_dict == immutable_dict



# Generated at 2022-06-11 00:48:18.406220
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3, 4])
    assert not is_iterable(0)
    assert not is_iterable(object())
    assert not is_iterable('42')
    assert is_iterable('42', include_strings=True)
    assert is_iterable(u'42')
    assert is_iterable(u'42', include_strings=True)
    assert is_iterable(b'42')
    assert is_iterable(b'42', include_strings=True)
    assert is_iterable((i for i in range(10)))



# Generated at 2022-06-11 00:48:30.691140
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(k=1, x=[1, 2, 3]) == ImmutableDict(k=1, x=[1, 2, 3])
    assert ImmutableDict(x=1) != ImmutableDict(x=2)
    assert ImmutableDict(x=[1, 2, 3]) != ImmutableDict(x=[1, 2, 3, 4])
    assert ImmutableDict(k=1, x=[1, 2, 3]) == ImmutableDict(x=[1, 2, 3], k=1)
    assert ImmutableDict(k=1, x=[1, 2, 3]) != ImmutableDict(k=1, x=[1, 2, 3, 4])
    assert ImmutableDict(x=1) != 'x'
    assert ImmutableDict(x=1) != 1

# Generated at 2022-06-11 00:48:41.696805
# Unit test for function is_iterable
def test_is_iterable():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.unittest import TestCase

    class TestIsIterable(TestCase):

        @patch('ansible_collections.notstdlib.moveitallout.plugins.module_utils.common._collections_compat.is_string')
        def test_is_iterable_no_string(self, mock_is_string):
            mock_is_string.return_value = False
            self.assertTrue(is_iterable({1, 2, 3}))


# Generated at 2022-06-11 00:48:51.270854
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # expected:
    #   returns True for ImmutableDicts with equal content
    #   returns False for ImmutableDicts with different content
    #   returns False for ImmutableDicts and MutableDicts with equal content
    #   returns False for ImmutableDicts and MutableDicts with different content
    #   returns False for ImmutableDicts and non-Mappings
    immutable1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    immutable2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    immutable3 = ImmutableDict({'a': 1, 'b': 2, 'd': 3})
    mutable1 = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-11 00:49:04.934293
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    # Test that __eq__ is True for self equality
    dict1 = ImmutableDict({'a': 1})
    assert dict1 == dict1
    assert dict1 == dict1.union({'b': 2})
    # Test that __eq__ is True for equal dicts
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    dict3 = ImmutableDict({'a': 1, 'b': 2})
    assert dict2 == dict3
    assert dict2.union({'c': 3}) == dict3.union({'c': 3})
    # Test that __eq__ is False for unequal dicts
    dict4 = dict2.difference(['b'])
    dict5 = dict2.difference(['a'])
    dict6 = dict4.union({'c': 3})


# Generated at 2022-06-11 00:49:14.831750
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable((1, 2, 3)) is True
    assert is_iterable(set([1, 2, 2, 3])) is True
    assert is_iterable({'a': 1, 'b': 2}) is True
    assert is_iterable(ImmutableDict({'a': 1, 'b': 2})) is True
    assert is_iterable('abc') is True
    assert is_iterable(u'abc') is True
    assert is_iterable(range(10)) is True
    assert is_iterable(object()) is False
    assert is_iterable(None) is False



# Generated at 2022-06-11 00:49:19.178427
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import copy

    TEST_CASES = [
        dict(),
        dict(a=42),
        dict(a=dict(b=42)),
        dict(a=dict()),
        dict([('a', 0), ('b', 42), ('c', dict())]),
    ]

    for i, dct in enumerate(copy.deepcopy(TEST_CASES)):
        idct = ImmutableDict(dct)
        for j, edct in enumerate(TEST_CASES):
            if i == j == 0:
                assert idct == edct
            else:
                assert not idct == edct

            assert idct != edct

# Generated at 2022-06-11 00:49:27.046395
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert not is_iterable(object())
    assert is_iterable(range(3))
    assert is_iterable({})
    assert is_iterable('')
    assert is_string('')
    assert is_iterable(b'')
    assert is_string(b'')
    assert not is_iterable(b'', include_strings=True)
    assert not is_iterable('', include_strings=True)
    assert is_iterable(set())
    assert is_iterable(frozenset())
    assert is_iterable(True)
    assert is_iterable(1)
    assert is_iterable({'x': 'y'})
    assert is_iterable((1, 2, 3))
    assert is_iterable(range(3))


# Generated at 2022-06-11 00:49:38.075811
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import pytest
    id1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    id2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    assert id1 == id2
    id3 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 5})
    assert id1 != id3
    assert id1 == {'a': 1, 'b': 2, 'c': 3, 'd': 4}

    assert id1 != {'a': 1, 'c': 3, 'b': 2, 'd': 4}
    assert id1 != {'a': 1, 'b': 3, 'c': 3, 'd': 4}

# Generated at 2022-06-11 00:49:44.857557
# Unit test for function is_iterable
def test_is_iterable():
    from collections import Iterable
    from ansible.module_utils.common._collections_compat import Hashable, Mapping, MutableMapping, Set, Sequence

    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2, 'c': 3})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(1, 4))
    assert is_iterable('abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))

    # A generator
    def gen_func(iterable):
        for i in iterable:
            yield i

    assert is_iterable(gen_func())

# Generated at 2022-06-11 00:49:52.356436
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    idict = ImmutableDict({'a': 'b', 'c': 'd'})
    assert idict == idict
    assert idict == {'a': 'b', 'c': 'd'}
    assert not idict == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert not idict == {'a': 'b', 'c': 'ef'}
    assert not idict == 123


# Generated at 2022-06-11 00:50:02.792551
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    from ansible.module_utils.common._collections_compat import Mapping
    assert ImmutableDict(a=1) == ImmutableDict(a=1)
    assert ImmutableDict(a=1) in [ImmutableDict(a=1)]
    assert ImmutableDict(a=1) != ImmutableDict(a=1, b=2)
    assert ImmutableDict(a=1) not in [ImmutableDict(a=1, b=2)]
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2, c=3)
    assert ImmutableDict(a=1, b=2, c=3) == ImmutableDict(a=1, b=2)

# Generated at 2022-06-11 00:50:14.270904
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a':1,'b':2}) == ImmutableDict({'a':1,'b':2})
    assert ImmutableDict({'a':1,'b':2}) == {'a':1,'b':2}
    assert ImmutableDict({'a':1,'b':2}) == dict({'a':1,'b':2})
    assert ImmutableDict({'a':1,'b':2,'c':3}) != ImmutableDict({'a':1,'b':2})
    assert ImmutableDict({'a':1,'b':2}) != ImmutableDict({'a':1,'b':2,'c':3})
    assert ImmutableDict({'a':1,'b':2}) != {'a':1,'b':2,'c':3}
    assert ImmutableDict

# Generated at 2022-06-11 00:50:19.422238
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable((1, 2, 3)) is True
    assert is_iterable({'a': 1, 'b': 2}) is True
    assert is_iterable('foo') is True
    assert is_iterable(1) is False
    assert is_iterable(['foo', 1]) is True
    assert is_iterable((1, ['foo', 2])) is True
    assert is_iterable({1, 2, 3}) is True



# Generated at 2022-06-11 00:50:34.219455
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable('abc') == True
    assert is_iterable(text_type('abc')) == True
    assert is_iterable((1, 2, 3)) == True
    assert is_iterable(range(10)) == True
    assert is_iterable(u'abc') == True
    assert is_iterable(1) == False
    assert is_iterable(set([1, 2, 3])) == True
    assert is_iterable(set((1, 2, 3))) == True
    assert is_iterable({'a': 1, 'b': 2, 'c': 3}) == True
    assert is_iterable({'a', 'b', 'c'}) == True
    assert is_iterable(None) == False

# Generated at 2022-06-11 00:50:36.779350
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(dict())
    assert not is_iterable(42)
    assert is_iterable(iter(range(42)))



# Generated at 2022-06-11 00:50:41.369835
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({"a": "1", "b": "2"})
    b = ImmutableDict({"a": "1", "b": "2"})
    c = {"a": "1", "b": "2"}
    assert (a == b)
    assert (a != c)


if __name__ == '__main__':
    # Unit test for method __eq__ of class ImmutableDict
    test_ImmutableDict___eq__()

# Generated at 2022-06-11 00:50:52.733010
# Unit test for function is_iterable
def test_is_iterable():
    results = [
        (0, False),
        (None, False),
        (0.0, True),
        (None, False),
        (dict(), True),
        ({}, True),
        (set(), True),
        (frozenset(), True),
        (list(), True),
        (tuple(), True),
        (xrange(0), True),
        (text_type(), True),
        (binary_type(), True),
        (bool(), False),
        (complex(), False),
        (type, False),
        (dict, False),
        (set, False),
        (frozenset, False),
        (list, False),
        (tuple, False),
        (unicode, False),
        (xrange, False),
    ]


# Generated at 2022-06-11 00:51:04.153406
# Unit test for function is_iterable
def test_is_iterable():
    # Test whether static iterables are correctly identified
    assert True == is_iterable(())
    assert True == is_iterable([])
    assert True == is_iterable({})
    assert True == is_iterable(set())
    # Test whether dynamic iterables are correctly identified
    assert True == is_iterable(range(0))
    assert True == is_iterable(xrange(0))
    assert True == is_iterable(iter([]))
    assert True == is_iterable(iter(()))
    assert True == is_iterable((i for i in []))
    assert True == is_iterable(dict())
    # Test whether static non-iterables are correctly identified
    assert False == is_iterable(0)
    assert False == is_iterable(None)
    # Test whether dynamic non-iterables are

# Generated at 2022-06-11 00:51:09.972124
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """confirm that the __eq__ function is correct
    """
    foo = {'a': 1, 'b': 2}
    original = ImmutableDict(foo)
    # test mapping equality
    assert original == {'a': 1, 'b': 2}
    assert original != {'a': 1, 'b': 3}
    # ensure that __eq__ can handle non mapping types
    assert original != object()



# Generated at 2022-06-11 00:51:18.596509
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable(ImmutableDict()) == True)
    assert(is_iterable(Hashable()) == True)
    assert(is_iterable(MutableMapping()) == True)
    assert(is_iterable(Sequence()) == True)
    assert(is_iterable('str') == False)
    assert(is_iterable('str', include_strings=True) == True)
    assert(is_iterable(u'unicode') == False)
    assert(is_iterable(u'unicode', include_strings=True) == True)

# Generated at 2022-06-11 00:51:27.930427
# Unit test for function is_iterable
def test_is_iterable():
    try:
        from io import StringIO, BytesIO
    except ImportError:
        from StringIO import StringIO
        BytesIO = StringIO  # python2 does not have BytesIO. It is just StringIO

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-11 00:51:35.204295
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))
    assert not is_iterable(1)
    assert not is_iterable(u'abc')
    assert not is_iterable(b'abc')
    assert not is_iterable('abc')
    assert not is_iterable(None)


# Generated at 2022-06-11 00:51:46.168766
# Unit test for function is_iterable
def test_is_iterable():
    # Test for non-iterable
    assert(not is_iterable(None))
    assert(not is_iterable(1))
    assert(not is_iterable('Test'))
    assert(not is_iterable(b'Test'))

    # Test for iterable
    assert(is_iterable([]))
    assert(is_iterable(set()))
    assert(is_iterable({}))
    assert(is_iterable(dict()))
    assert(is_iterable(xrange(0)))
    assert(is_iterable((None,)))
    assert(is_iterable((1,)))
    assert(is_iterable(('Test',)))

    # Strings can be iterable if include_strings is True
    assert(is_iterable('Test', include_strings=True))

# Generated at 2022-06-11 00:52:04.127916
# Unit test for function is_iterable
def test_is_iterable():
    """Test suite for is_iterable function."""
    class IterableA(object):
        def __init__(self, data):
            self.data = data

        def __iter__(self):
            for elem in self.data:
                yield elem

    class IterableB(object):
        def __init__(self, data):
            self.data = data

        def __iter__(self):
            for elem in self.data:
                yield elem

    class NotIterable(object):
        def __init__(self, data):
            self.data = data

    def test_object(obj, expected_value):
        assert(is_iterable(obj) == expected_value)

    # Test iterable objects
    test_object(IterableA([]), True)

# Generated at 2022-06-11 00:52:12.938150
# Unit test for function is_iterable
def test_is_iterable():
    iterable_types = (
        [0],
        [],
        {},
        (),
        set(),
        generator(),
        ImmutableDict(one=1),  # This is a bit of an exception
    )
    non_iterable_types = (
        None,
        0,
        '',
    )

    for i in iterable_types:
        assert is_iterable(i)

    for i in iterable_types:
        assert is_iterable(i, True)

    for i in non_iterable_types:
        assert not is_iterable(i)

    for i in non_iterable_types:
        assert not is_iterable(i, True)



# Generated at 2022-06-11 00:52:23.839526
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import sys
    import copy
    if sys.version_info < (2, 7):
        obj1 = ImmutableDict(a=1, b=2, c=3)
        obj2 = ImmutableDict(a=1, b=2, c=3)
        assert(obj1 == obj2)
        obj3 = ImmutableDict(b=2, c=3, d=4)
        assert(obj1 != obj3)

        # Test that method __eq__ does not raise TypeError in case
        # it was given non-comparable object
        try:
            obj1 == 'string'
            assert(True)
        except TypeError:
            assert(False)


# Generated at 2022-06-11 00:52:35.047237
# Unit test for function is_iterable
def test_is_iterable():
    """Verify behaviour of the is_iterable function"""
    assert is_iterable([1, 2, 3])
    assert is_iterable(set((1, 2, 3)))
    assert not is_iterable((1, 2, 3))
    assert not is_iterable('string_like')
    assert not is_iterable(u'unicode_like')
    assert not is_iterable(u'unicode_like'.encode('utf-8'))
    assert not is_iterable(None)
    assert not is_iterable(3)
    assert not is_iterable(3.5)
    assert not is_iterable({'a': 'b', 'c': 'd'})
    assert not is_iterable(['string_like'])

# Generated at 2022-06-11 00:52:43.836841
# Unit test for function is_iterable
def test_is_iterable():
    tests = [
        # Input, is_iterable, is_string
        (str, False, True),
        (unicode, False, True),
        (dict, True, False),
        (list, True, False),
        (tuple, True, False),
        (xrange, True, False),
        (set, True, False),
        (frozenset, True, False),
        (lambda: None, True, False),
        (123, False, False),
    ]

    for input, expected_iterable, expected_string in tests:
        iterable = is_iterable(input)
        string = is_string(input)

# Generated at 2022-06-11 00:52:55.633614
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert not is_iterable(None)
    assert is_iterable((1,))
    assert not is_iterable(1)
    assert not is_iterable(is_iterable)
    assert is_iterable('')
    assert is_iterable('abc')
    assert is_iterable(u'')
    assert is_iterable(u'abc')
    assert not is_iterable(b'')
    assert not is_iterable(b'abc')
    assert is_iterable(xrange(1))
    assert not is_iterable(1, include_strings=True)
    assert is_iterable('', include_strings=True)
    assert is_iterable(b'', include_strings=True)



# Generated at 2022-06-11 00:53:02.418643
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != {'a': 1}


# Generated at 2022-06-11 00:53:06.867271
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    data = dict(a='123', b='234')
    x = ImmutableDict(data)
    y = ImmutableDict(data)
    z = ImmutableDict(data)
    zz = z.union(data)

    assert x == y
    assert hash(x) == hash(y)

    assert x == data
    assert x == z
    assert x != zz
    assert x != dict(a='123', b='234', c='345')

# Generated at 2022-06-11 00:53:10.920376
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict(k='v')
    b = ImmutableDict(k='v')
    assert(a == a)
    assert(a == b)
    assert(not a == 1)


# Generated at 2022-06-11 00:53:22.519829
# Unit test for function is_iterable
def test_is_iterable():
    # Test for string
    assert not is_iterable("string")
    assert is_iterable("string", include_strings=True)

    # Test for generator
    assert is_iterable((x for x in range(0, 5)))

    # Test for dictionary
    assert is_iterable({'a': 1, 'b': 2})

    # Test for list
    assert is_iterable([1, 2, 3])

    # Test for empty list
    assert is_iterable([])

    # Test for set
    assert is_iterable({1, 2, 3})

    # Test for tuple
    assert is_iterable((1, 2, 3))

    # Test for int
    assert not is_iterable(1)

    # Test for float
    assert not is_iterable(1.0)



# Generated at 2022-06-11 00:53:36.778516
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable({}) is True
    assert is_iterable(set()) is True
    assert is_iterable(ImmutableDict()) is True
    assert is_iterable(u'foo') is False
    assert is_iterable('foo') is False
    assert is_iterable(b'foo') is False
    assert is_iterable(42) is False
    assert is_iterable(object()) is False



# Generated at 2022-06-11 00:53:40.385671
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    my_dict = ImmutableDict(key1='val1', key2='val2')
    new_dict = ImmutableDict(key1='val1', key2='val2')
    assert my_dict == new_dict


# Generated at 2022-06-11 00:53:46.337669
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'var': 'value'}) == ImmutableDict({'var': 'value'})
    assert ImmutableDict({'var': 'value'}) == {'var': 'value'}
    assert ImmutableDict({'var': 'value'}) != {'var': 'value', 'var2': 'value2'}
    assert not ImmutableDict({'var': 'value'}).__eq__(None)

# Generated at 2022-06-11 00:53:56.896595
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(u'abc'.encode('utf-8'))
    assert is_iterable((1, 2, 3))
    assert is_iterable([1, 2, 3])
    assert is_iterable({1, 2, 3})
    assert is_iterable({1: 2, 3: 4})
    assert not is_iterable((i for i in range(3)))

    class Iterator(object):
        def __init__(self, items):
            self.items = items
        def __iter__(self):
            return self
        def __next__(self):
            try:
                return self.items.pop()
            except IndexError:
                raise Stop

# Generated at 2022-06-11 00:53:59.180941
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Verify that ImmutableDict is equal to itself."""
    mydict = ImmutableDict({'k': 'v'})
    assert mydict == mydict


# Generated at 2022-06-11 00:54:07.699616
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # test equal case
    dict1 = ImmutableDict(test1=1, test2=2, test3=3)
    dict2 = ImmutableDict(test1=1, test2=2)
    dict2 = dict2.union(dict1)
    assert dict1 == dict2

    # test not equal case
    dict3 = ImmutableDict(test1=1, test2=2, test3=3)
    dict4 = ImmutableDict(test1=1, test2=2, test3=3, test4=4)
    assert dict3 != dict4



# Generated at 2022-06-11 00:54:15.426630
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict() != None
    assert not ImmutableDict() == None
    assert not ImmutableDict() == set()
    assert ImmutableDict({'a': 'b'}) == ImmutableDict({'a': 'b'})
    assert not ImmutableDict({'a': 'b'}) == ImmutableDict({'a': 'c'})
    assert not ImmutableDict({'a': 'b'}) == ImmutableDict({'a': 'b', 'c': 'd'})


# Generated at 2022-06-11 00:54:24.180581
# Unit test for function is_iterable
def test_is_iterable():
    """Tests for function is_iterable."""
    from ansible.module_utils.common._collections_compat import Iterable
    from ansible.module_utils.common._collections_compat import MutableSequence
    from ansible.module_utils.common._collections_compat import MutableSet
    from ansible.module_utils.common._collections_compat import MutableMapping
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable({})
    assert is_iterable({1: 'a', 2: 'b'})
    assert is_iterable((1, 2, 3))
    assert not is_iterable(None)
    assert not is_iterable(object)
    assert not is_iterable(object())

# Generated at 2022-06-11 00:54:30.355068
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([3, 4])
    assert not is_iterable(3)
    assert not is_iterable('3')
    assert is_iterable({3, 4})
    assert is_iterable({'key': 'value'})
    assert not is_iterable((3, 4))
    assert is_iterable(set([3, 4, 3]))



# Generated at 2022-06-11 00:54:36.964692
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('a')
    assert is_iterable(['a', 'b'])
    assert is_iterable(('a', 'b'))
    assert is_iterable((x for x in 'abc'))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set(['a', 'b']))
    assert is_iterable(ImmutableDict({'a': 1, 'b': 2}))



# Generated at 2022-06-11 00:55:06.488450
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    original = ImmutableDict({'A': 'a'}, B='b', C='c')
    assert original.union({'C': 'd'}) == ImmutableDict({'A': 'a'}, B='b', C='d')
    assert not original.union({'C': 'd'}) == ImmutableDict({'A': 'a'}, B='b', C='c')
    assert not original.union({'C': 'd'}) == ImmutableDict({'A': 'a'}, B='b', C='not d')



# Generated at 2022-06-11 00:55:17.689884
# Unit test for function is_iterable
def test_is_iterable():
    """Test is_iterable() with the following cases:

      1. empty list
      2. empty tuple
      3. dict
      4. string
      5. int
      6. bytes
      7. True
      8. False
    """
    # 1. empty list
    assert is_iterable([])
    # 2. empty tuple
    assert is_iterable(())
    # 3. dict
    assert is_iterable({})
    # 4. string
    assert is_iterable(u'hi')
    # 5. int
    assert not is_iterable(7)
    # 6. bytes
    assert is_iterable(b'hi')
    # 7. True
    assert not is_iterable(True)
    # 8. False
    assert not is_iterable(False)



# Generated at 2022-06-11 00:55:27.553508
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # To ensure that ImmutableDict.__eq__ works as expected,
    # we define 2 dictionary like objects and compare them
    # alternatively with ImmutableDict.__eq__, '==' and '!='
    # Both should always provide the same result.
    d1 = {'key1': 'value1', 'key2': 'value2'}
    d2 = {'key1': 'value1', 'key2': 'value2'}
    d3 = {'key1': 'value1', 'key2': 'value3'}

    # Create ImmutableDict from dicts
    id1 = ImmutableDict(d1)
    id2 = ImmutableDict(d2)
    id3 = ImmutableDict(d3)

    # Compare ImmutableDict with dict
    assert id1 == d1


# Generated at 2022-06-11 00:55:38.361305
# Unit test for function is_iterable
def test_is_iterable():
    from ansible.module_utils.six.moves import UserString

    class MyString(UserString):
        def __init__(self, s):
            self.data = s

    s = 'string'
    assert is_iterable(s, include_strings=True)
    assert not is_iterable(s, include_strings=False)

    l = ['a', 'b', 'c']
    assert is_iterable(l, include_strings=True)
    assert is_iterable(l, include_strings=False)

    d = {'a': 1, 'b': 2}
    assert is_iterable(d, include_strings=True)
    assert is_iterable(d, include_strings=False)

    t = ('a', 'b', 'c')

# Generated at 2022-06-11 00:55:45.156073
# Unit test for function is_iterable
def test_is_iterable():
    not_iterables = [
        'string',
        [],
        123,
        False,
        None,
        object(),
        u'string',
        {'m': 1, 'm': 2}
    ]
    for not_iterable in not_iterables:
        assert not is_iterable(not_iterable)

    iterables = [
        [1, 2, 3],
        (1, 2, 3),
        {'m': 1}
    ]
    for iterable in iterables:
        assert is_iterable(iterable)



# Generated at 2022-06-11 00:55:49.481341
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(str()) is False
    assert is_iterable(dict()) is True
    assert is_iterable(set()) is True
    assert is_iterable(list()) is True
    assert is_iterable(tuple()) is True
    assert is_iterable(123) is False
    assert is_iterable(12.3) is False
    assert is_iterable(u'abc') is False


# Generated at 2022-06-11 00:56:00.183106
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_cases = [
        ({'a': 1, 'b': 2}, {'a': 1, 'b': 2}, True),
        ({'a': 1, 'b': 2}, {'a': 1, 'b': 3}, False),
        ({'a': 1, 'b': 2}, None, False),
        ({'a': 1, 'b': 2}, 'x', False),
        ({'a': 1, 'b': 2}, ImmutableDict({'a': 1, 'b': 2}), True),
        ({'a': 1, 'b': 2}, ImmutableDict({'a': 1, 'b': 3}), False),
    ]
    for left, right, expected in test_cases:
        actual = ImmutableDict(left) == right

# Generated at 2022-06-11 00:56:09.271215
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Sanity check for __eq__ method of ImmutableDict class
    """
    # Test for equal dictionaries of strings and integers
    a = ImmutableDict()
    b = ImmutableDict()
    assert a == b
    a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    b = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert a == b
    a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    b = ImmutableDict({'c': 3, 'b': 2, 'a': 1})
    assert a == b
    a = ImmutableDict({'a': 'a', 'b': 'b', 'c': 'c'})
    b = Immutable

# Generated at 2022-06-11 00:56:19.710581
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test: __eq__"""
    # Test type check
    a = ImmutableDict({"name": "George", "age": 45})
    if not a.__eq__(a):
        raise AssertionError("ImmutableDict.__eq__ : test #1 failed")
    b = 'George'
    if a.__eq__(b):
        raise AssertionError("ImmutableDict.__eq__ : test #2 failed")
    # Test content check
    c = ImmutableDict({"name": "Mary", "age": 45})
    if a.__eq__(c):
        raise AssertionError("ImmutableDict.__eq__ : test #3 failed")
    d = ImmutableDict({"name": "George", "age": 45})

# Generated at 2022-06-11 00:56:27.077231
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(tuple())
    assert is_iterable(set())
    assert is_iterable(dict())

    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(object())

    assert is_iterable(text_type())
    assert is_iterable(binary_type())

    assert is_iterable(dict(a='b'))
    assert not is_iterable('abc')
    assert not is_iterable(b'abc')



# Generated at 2022-06-11 00:57:20.475892
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test that the __eq__ method of ImmutableDict works as expected"""
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 == ImmutableDict({'a': 1, 'c': 3, 'b': 2})
    assert d1 == {'a': 1, 'c': 3, 'b': 2}
    assert d1 == {'b': 2, 'c': 3, 'a': 1}
    assert not (d1 == {'c': 3, 'b': 2})
    assert not (d1 == {'c': 3, 'a': 1})
    d2 = ImmutableDict(a=1, b=2, c=3)
    assert d1 == d2

# Generated at 2022-06-11 00:57:24.977901
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(range(10))
    assert is_iterable(dict())
    assert is_iterable(set())
    assert is_iterable("non-iterable", include_strings=True)
    assert not is_iterable("non-iterable", include_strings=False)



# Generated at 2022-06-11 00:57:34.385986
# Unit test for function is_iterable
def test_is_iterable():
    class MyUnhashable(object):
        def __init__(self, x):
            self.x = x

        def __eq__(self, other):
            return self.x == other.x

    assert is_iterable([1, 2, 3])
    assert is_iterable(dict(a=1, b=2))
    assert is_iterable(MyUnhashable(1))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(ImmutableDict(a=1, b=2))
    assert is_iterable((1, 2, 3))
    assert not is_iterable(None)
    assert not is_iterable(1)

