

# Generated at 2022-06-11 00:47:41.033270
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    b = a.difference(['a'])
    assert 'a' not in b
    assert b['b'] == 2
    assert b['c'] == 3
    assert b == {'b': 2, 'c': 3}

    c = a.difference(['a', 'b'])
    assert set(c.keys()) == set(['c'])
    # This assertion fails, because 'a' and 'b' are not keys of the dictionary,
    # but trying to remove them anyway went without errors
    # assert set(b.keys()) == set(['c'])

    # This assertion fails, because 'a' and 'b' are not keys of the dictionary,
    # but trying to remove them anyway went without errors
    #

# Generated at 2022-06-11 00:47:50.085804
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d1 = ImmutableDict(z=1, a=2, b=3, c=4, d=5, e=6)
    d2 = d1.difference(['a', 'e', 'z'])
    d1_repr = 'ImmutableDict({0})'.format(repr({'d': 5, 'b': 3, 'c': 4, 'a': 2, 'z': 1, 'e': 6}))
    d2_repr = 'ImmutableDict({0})'.format(repr({'d': 5, 'b': 3, 'c': 4}))
    assert repr(d1) == d1_repr
    assert repr(d2) == d2_repr


# Generated at 2022-06-11 00:47:58.498767
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """Test whether ImmutableDict.difference removes keys from an ImmutableDict correctly"""
    idict_orig = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})
    idict_new = idict_orig.difference(['a', 'c', 'e'])
    assert idict_new == ImmutableDict({'b': 2, 'd': 4})
    assert idict_orig == ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})


# Generated at 2022-06-11 00:48:04.359448
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():

    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    test_expected = ImmutableDict({'a': 1, 'b': 2})

    assert set(test_dict.difference(('c', 'd')).keys()) == set(test_expected.keys())

# Generated at 2022-06-11 00:48:15.369450
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-locals
    # Initialize data to test
    imm_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    # ImmutableDict difference: list
    list_obj = ['a', 'b', 'c', 'd']
    imm_dict_diff = imm_dict.difference(list_obj)
    # Expected data
    imm_dict_diff_exp = ImmutableDict({'c': 3})
    assert imm_dict_diff == imm_dict_diff_exp
    # ImmutableDict difference: set
    set_obj = set(['a', 'b', 'd'])
    imm_dict_diff = imm_dict.difference(set_obj)

# Generated at 2022-06-11 00:48:23.578017
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():

    # Setup
    immutable_dict1 = ImmutableDict(dict1=1, dict2=2, dict3=3, dict4=4)
    subtract_list1 = (['dict1', 'dict3'])
    subtract_dict1 = {'dict2': 2, 'dict4': 4}

    # Verify
    assert immutable_dict1.difference(subtract_list1) == ImmutableDict({'dict2': 2})
    assert immutable_dict1.difference(subtract_dict1) == ImmutableDict()


# Generated at 2022-06-11 00:48:33.340472
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Difference operator for ImmutableDict should return a new instance of ImmutableDict that
    includes all of the key-value pairs of the original ImmutableDict except for the keys that
    match those in the subtractive iterable.
    """
    # Setup
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})
    subset = {'b', 'c', 'e'}

    # Test
    result = original.difference(subset)

    # Verify
    assert result == ImmutableDict({'a': 1, 'd': 4})



# Generated at 2022-06-11 00:48:38.272722
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    initial_dict = ImmutableDict({"a": 1, "b": 2, "c": 3, "d": 4, "e": 5})
    assert initial_dict.difference(["a", "b", "c"]) == ImmutableDict({"d": 4, "e": 5})


# Generated at 2022-06-11 00:48:41.142209
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    modified = original.difference(('b', 'c'))

    assert len(modified) == 1
    assert 'b' not in modified
    assert 'c' not in modified
    assert 'a' in modified



# Generated at 2022-06-11 00:48:43.824814
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    immutable_dict = ImmutableDict({'foo': 'bar', 'baz': 3})
    expected = {'baz': 3}
    actual = immutable_dict.difference(('foo',))
    assert actual == expected


# Generated at 2022-06-11 00:48:56.741574
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Providing two different ImmutableDicts that are equal
    immutable_dict_1 = ImmutableDict({'a':'1', 'b':'2'})
    immutable_dict_2 = ImmutableDict({'b':'2', 'a':'1'})
    # Testing that they are equal
    assert(immutable_dict_1 == immutable_dict_2)
    # One of them is equal to a dictionary that is equal to it
    immutable_dict_3 = ImmutableDict({'a':'1', 'b':'2'})
    dict_2 = dict({'b':'2', 'a':'1'})
    # Testing that they are equal
    assert(immutable_dict_1 == dict_2)
    # Another of them

# Generated at 2022-06-11 00:49:01.511276
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable(ImmutableDict({1: 1}))
    assert is_iterable((1, 2, 3))
    assert not is_iterable(1)
    assert is_iterable(1, include_strings=True)



# Generated at 2022-06-11 00:49:13.099021
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict(key1='value1', key2='value2')
    b = ImmutableDict(key2='value2', key1='value1')
    c = ImmutableDict(key1='value1', key2='value2', key3='value3')
    d = ImmutableDict(key1='value1', key2='value2', key3='value4')
    e = ImmutableDict(key1='value1', key3='value3')
    f = {}

    assert a == b
    assert a != c
    assert a != d
    assert a != e
    assert a != f
    assert b != c
    assert b != d
    assert b != e
    assert b != f
    assert c != d
    assert c != e
    assert c != f
    assert d != e

# Generated at 2022-06-11 00:49:23.250249
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_dict = {'one': 1, 'two': 2, 'three': 3, 'four': 4}
    test_dict2 = {'one': 1, 'three': 3, 'two': 2, 'four': 4}
    test_dict3 = {'one': 1, 'three': 3, 'two': 2, 'four': 4, 'five': 5}
    test_dict4 = {'five': 5, 'one': 1, 'three': 3, 'two': 2, 'four': 4}

    assert ImmutableDict(test_dict) == ImmutableDict(test_dict)
    assert ImmutableDict(test_dict) == ImmutableDict(test_dict2)
    assert ImmutableDict(test_dict) != ImmutableDict(test_dict3)

# Generated at 2022-06-11 00:49:26.020067
# Unit test for function is_iterable
def test_is_iterable():
    test1 = 'my_string'
    test2 = [1, 2, 3, 4, 5]
    assert is_iterable(test1)
    assert is_iterable(test2)


# Generated at 2022-06-11 00:49:36.980955
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # All instances of ImmutableDict should be equal to another instance of ImmutableDict
    # with the same key-value pairs.
    # The following dictionaries only differ in their order of key-values
    dict_1 = {'a': 1, 'b': 2, 'c': 3}
    dict_2 = {'a': 1, 'c': 3, 'b': 2}
    dict_3 = ImmutableDict(dict_1)
    dict_4 = ImmutableDict(dict_2)
    assert dict_3 == dict_4
    # An instance of ImmutableDict should not be equal to a non-ImmutableDict
    dict_5 = dict(dict_3)
    assert dict_3 != dict_5
    # A non-ImmutableDict should not be equal to an ImmutableDict
    assert dict

# Generated at 2022-06-11 00:49:44.558279
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # define a common dictionary for the tests
    dictionary = {'a': 1}

    # instantiate an ImmutableDict
    imm_dict = ImmutableDict(dictionary)

    # test equality vs an ImmutableDict with same content
    assert imm_dict == ImmutableDict(dictionary)

    # test equality vs an ImmutableDict with different content
    assert not imm_dict == ImmutableDict({'b': 2})

    # test equality vs a dict with same content
    assert imm_dict == dictionary

    # test equality vs a dict with different content
    assert not imm_dict == {'b': 2}

    # test equality vs a frozenset with same content
    assert imm_dict == frozenset(dictionary.items())

    # test equality vs a frozenset with different content
    assert not imm_dict == fro

# Generated at 2022-06-11 00:49:56.529047
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_dict = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict == ImmutableDict({'a': 1, 'b': 2})
    assert test_dict == {'a': 1, 'b': 2}
    assert test_dict != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert test_dict != ImmutableDict({'a': 1, 'b': 3})
    assert test_dict != ImmutableDict({'a': 1, 'c': 2})
    assert test_dict != ImmutableDict({'b': 1, 'c': 2})
    assert test_dict != ImmutableDict({'a': 2})
    assert test_dict != ImmutableDict({'a': 2, 'b': 3})

# Generated at 2022-06-11 00:50:01.466276
# Unit test for function is_iterable
def test_is_iterable():
    """
    """
    assert is_iterable('')
    assert is_iterable(u'')
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable((i for i in range(0)))

    assert not is_iterable(0)
    assert not is_iterable(None)


# Generated at 2022-06-11 00:50:09.471946
# Unit test for function is_iterable
def test_is_iterable():
    class A(object):
        def __iter__(self):
            pass

    class B(object):
        def __getitem__(self, item):
            pass

    assert is_iterable("abc") == False
    assert is_iterable("abc", include_strings=True) == True
    assert is_iterable(1) == False
    assert is_iterable(1.0) == False
    assert is_iterable(A()) == True
    assert is_iterable(B()) == False
    assert is_iterable(('a', 'b', 'c')) == True

# Generated at 2022-06-11 00:50:18.817030
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(a=1, b=2)
    assert d1 == d2
    d3 = ImmutableDict(a=1, b=2, c=3)
    assert d1 != d3


# Generated at 2022-06-11 00:50:25.850209
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import collections
    # Test might fail here if you are not running Python < 2.7
    assert collections.OrderedDict([(1, 2), (3, 4)]) != ImmutableDict({3: 4, 1: 2})
    # Test might fail here if you are not running Python >= 2.7
    assert collections.OrderedDict([(1, 2), (3, 4)]) == ImmutableDict({3: 4, 1: 2})



# Generated at 2022-06-11 00:50:32.210196
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(1)
    assert is_iterable(None) is False



# Generated at 2022-06-11 00:50:33.729783
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict(key1=10)
    b = ImmutableDict(key2=20)
    assert a != b
    c = ImmutableDict(key1=10)
    assert a == c

# Generated at 2022-06-11 00:50:41.079306
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict()
    b = ImmutableDict()
    c = ImmutableDict(a=1)
    d = ImmutableDict(a=1)
    e = ImmutableDict(a=2, b=3)
    f = ImmutableDict(a=2, b=3)
    g = ImmutableDict(b=3, a=2)
    h = ImmutableDict(a=2, b=4)
    i = ImmutableDict(a=2, b=3, c=5)
    j = ImmutableDict(a=2, b=3, c=5)
    assert a == b
    assert c == d
    assert e == f
    assert e == g
    assert e != h
    assert i == j
    assert i != c
    assert c

# Generated at 2022-06-11 00:50:52.417675
# Unit test for function is_iterable
def test_is_iterable():
    # Test iterables
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(xrange(10))
    assert not is_iterable(1)
    assert is_iterable(lambda x: x)
    assert is_iterable(x for x in xrange(10))

    # Test strings
    assert is_iterable('', include_strings=True)
    assert is_iterable('foobar', include_strings=True)
    assert is_iterable(b'', include_strings=True)
    assert is_iterable(b'foobar', include_strings=True)
    assert not is_iterable('', include_strings=False)
    assert not is_iterable('foobar', include_strings=False)

# Generated at 2022-06-11 00:51:03.946345
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'c': 2}) != ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'c': 2}) != ImmutableDict({'c': 2, 'a': 1,'b': 1})
    assert ImmutableDict({'a': 1, 'c': 2}) != ImmutableDict({'a': 2,'b': 1})
    assert ImmutableDict({'a': 1, 'c': 2}) != ImmutableDict({'a': 1,'b': 1})

# Generated at 2022-06-11 00:51:08.018272
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict1 = ImmutableDict(a_key='a_value', another_key='another_value')
    immutable_dict2 = ImmutableDict(a_key='a_value', another_key='another_value')
    assert immutable_dict1 == immutable_dict2



# Generated at 2022-06-11 00:51:15.699758
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Verify that same dicts of different types are equal
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = dict({'a': 1, 'b': 2})
    assert d1 == d2

    # Verify that dicts with different order of elements are equal
    d2 = dict({'b': 2, 'a': 1})
    assert d1 == d2

    # Verify that dicts with missing element are not equal
    d2 = dict({'b': 2})
    assert d1 != d2

# Generated at 2022-06-11 00:51:26.351995
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({"one": 1, "two": 2})
    dict2 = ImmutableDict({"one": 1, "two": 2})
    dict3 = ImmutableDict({"one": 1, "two": 3})
    dict4 = ImmutableDict({"one": 1, "two": 4})
    dict5 = ImmutableDict({"one": 0, "two": 2})
    dict6 = ImmutableDict({"one": 1, "two": 2, "three": 3})
    assert dict1 == dict2
    assert not dict1 == dict1.union(dict3)
    assert not dict1 == dict3
    assert not dict1 == dict4
    assert not dict1 == dict5
    assert not dict1 == dict6
    assert not dict1 == 3

# Generated at 2022-06-11 00:51:42.915588
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable({})
    assert is_iterable([1, 2, 3])
    assert is_iterable(set([1, 2, 3]))
    assert not is_iterable('foo')
    assert not is_iterable(1)
    assert not is_iterable(None)
    assert not is_iterable(object)
    assert not is_iterable(Exception())


# Generated at 2022-06-11 00:51:51.251603
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict() == ImmutableDict({})
    assert not ImmutableDict() == ImmutableDict({'a': 1})
    assert not ImmutableDict({'a': 1}) == ImmutableDict()
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1, 'b': None})

# Generated at 2022-06-11 00:52:02.659659
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(a=1)
    d2 = ImmutableDict(a=1)
    d3 = ImmutableDict(a=2)
    d4 = ImmutableDict({'a': 1})
    d5 = ImmutableDict(a=1, b=2)
    d6 = ImmutableDict({'a': 1, 'b': 2})

    assert d1 == d2
    assert not d1 == d3
    # Should be equivalent to d1 == d4
    assert d1 == d4
    # Should be equivalent to d1 != d4
    assert not d1 == d5
    # Should be equivalent to d1 != d4
    assert not d1 == d6


# Generated at 2022-06-11 00:52:07.313135
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable('str')
    assert not is_iterable(5)
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())



# Generated at 2022-06-11 00:52:15.509294
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({"key1": 1, "key2": 2, "key3": 3}) == ImmutableDict({"key1": 1, "key2": 2, "key3": 3})
    assert ImmutableDict({"key1": 1, "key2": 2, "key3": 3}) == ImmutableDict({"key1": 1, "key3": 3, "key2": 2})
    assert ImmutableDict({"key1": 1, "key2": 2, "key3": 3}) != ImmutableDict({"key1": 1, "key2": 2, "key3": 4})

# Generated at 2022-06-11 00:52:22.315601
# Unit test for function is_iterable
def test_is_iterable():
    class IterNoLen(object):
        def __iter__(self):
            yield

    class NoIterNoLen(object):
        pass

    assert is_iterable(IterNoLen())
    assert not is_iterable(NoIterNoLen())
    assert not is_iterable(object())
    assert not is_iterable(42)
    assert is_iterable((1, 2, 3))
    assert not is_iterable(set([1, 2, 3]))

# Generated at 2022-06-11 00:52:29.077641
# Unit test for function is_iterable
def test_is_iterable():
    """Unit test for function is_iterable"""
    assert is_iterable(list())
    assert is_iterable(dict())
    assert is_iterable(set())
    assert is_iterable(tuple())
    assert is_iterable('')
    assert not is_iterable('')
    assert is_iterable(1)
    assert not is_iterable(1)
    assert is_iterable(object())
    assert not is_iterable(object())


# Generated at 2022-06-11 00:52:37.270245
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'b': 2, 'a': 1})
    d3 = ImmutableDict({'a': 1, 'b': 3})
    d4 = ImmutableDict({'c': 3, 'b': 2})

    assert d1 != d2
    assert d1 == d1
    assert d1 != d3
    assert d1 != d4
    assert d2 != d3
    assert d2 != d4
    assert d3 != d4


# Generated at 2022-06-11 00:52:42.254640
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('test') is False
    assert is_iterable('test', include_strings=True) is True
    assert is_iterable(range(5)) is True
    assert is_iterable(1.0) is False
    assert is_iterable(1) is False
    assert is_iterable(['test']) is True
    assert is_iterable(dict({'test': 'test'})) is True



# Generated at 2022-06-11 00:52:54.907120
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test case for ImmutableDict.__eq__

    It should return False
      - if compared to None
      - if compared to a different type of object
      - if compared to a MutableMapping with the same items
    It should return True
      - if compared to an ImmutableDict with the same items

    This function is meant to be used as a unit test. It should be defined here,
    outside the class ImmutableDict, in order to allow its use as a unit test.

    :return: The result of the test. If True, the test succeeded.
    """
    original_dict = dict(A=1, B=[1, 2, 3], C=[4, 5])
    immutable_dict = ImmutableDict(A=1, B=[1, 2, 3], C=[4, 5])

# Generated at 2022-06-11 00:53:27.175319
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    d3 = ImmutableDict({'b': 2, 'a': 1})
    assert d1 == d3

    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert not d1 == d4

    d5 = ImmutableDict({'a': 1})
    assert not d1 == d5

    for i in range(100):
        assert d1 == d1
        assert d1 == d2
        assert d2 == d1
        assert d2 == d2



# Generated at 2022-06-11 00:53:32.043226
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # 2 ImmutableDicts with the same content should be equal
    assert ImmutableDict({'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    # 2 ImmutableDicts with different content should not be equal
    assert ImmutableDict({'b': 2}) != ImmutableDict({'b': 3})
    # ImmutableDict should not be equal to other types
    assert ImmutableDict({'b': 2}) != 'nothing'



# Generated at 2022-06-11 00:53:38.799250
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    idict1 = ImmutableDict({'key1': '1', 'key2': '2'})
    idict2 = ImmutableDict({'key1': '1', 'key2': '2'})
    idict3 = ImmutableDict({'key1': '1', 'key2': '3'})

    assert idict1 == idict2
    assert idict1 != idict3


# Generated at 2022-06-11 00:53:49.541777
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(None) == False
    assert is_iterable(1) == False

    assert is_iterable([]) == True
    assert is_iterable((2, 3)) == True
    assert is_iterable({}) == True
    assert is_iterable(set()) == True
    assert is_iterable(frozenset()) == True
    assert is_iterable(xrange(1)) == True

    assert is_iterable('') == False
    assert is_iterable(u'') == False
    assert is_iterable(b'') == False

    assert is_iterable('', include_strings=True) == True
    assert is_iterable(u'', include_strings=True) == True
    assert is_iterable(b'', include_strings=True) == True

# Unit test

# Generated at 2022-06-11 00:53:54.042292
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    mapping1 = ImmutableDict({'a': 1, 'b': 2})
    mapping2 = ImmutableDict({'a': 1, 'b': 2})
    mapping3 = ImmutableDict({'a': 1, 'b': 3})
    assert mapping1 == mapping2
    assert not mapping1 == mapping3

# Generated at 2022-06-11 00:54:04.408305
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict()
    d2 = ImmutableDict()
    assert d1 == d2, "Empty ImmutableDict are equal"

    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(a=1, b=2)
    assert d1 == d2, "ImmutableDict with same items are equal"

    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(a=1, b=3)
    assert d1 != d2, "ImmutableDict with different items are not equal"

    d1 = ImmutableDict(a=1, b=2)
    assert d1 == dict(a=1, b=2), "ImmutableDict with same items as a dict are equal"



# Generated at 2022-06-11 00:54:14.563473
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'k1': 'v1', 'k2': 'v2'}) == ImmutableDict({'k1': 'v1', 'k2': 'v2'})
    assert ImmutableDict({'k1': 'v1', 'k2': 'v2'}) != ImmutableDict({'k1': 'v1', 'k2': 'v3'})
    assert ImmutableDict(k1='v1', k2='v2') != ImmutableDict({'k1': 'v1', 'k2': 'v2'})
    assert ImmutableDict({'k1': 'v1', 'k2': 'v2'}) != ImmutableDict(k1='v1', k2='v2')

# Generated at 2022-06-11 00:54:21.358959
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(xrange(1, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert not is_iterable('foo')
    assert is_iterable('foo', include_strings=True)
    assert is_iterable(b'foo')
    assert is_iterable(1)
    assert not is_iterable(2, 3)
    assert not is_iterable(None)


# Generated at 2022-06-11 00:54:27.932459
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2])
    assert is_iterable((4, 5, 7))
    assert is_iterable(range(6, 10))
    assert is_iterable({6})
    assert is_iterable({'key1': 'val1', 'key2': 'val2'})
    assert not is_iterable(3)
    assert not is_iterable('test')
    assert is_iterable(set())



# Generated at 2022-06-11 00:54:38.050549
# Unit test for function is_iterable
def test_is_iterable():
    class NonIterable(object):
        pass

    class Iterable(object):
        def __iter__(self):
            yield

    assert is_iterable('foo')
    assert not is_iterable('foo', include_strings=False)
    assert is_iterable(u'foo')
    assert not is_iterable(u'foo', include_strings=False)
    assert is_iterable(b'foo')
    assert not is_iterable(b'foo', include_strings=False)
    assert is_iterable(list())
    assert is_iterable(dict())
    assert is_iterable(tuple())
    assert is_iterable(set())
    assert is_iterable(Iterable())
    assert not is_iterable(NonIterable())
    assert is_iterable(iter('foo'))


# Generated at 2022-06-11 00:55:26.219076
# Unit test for function is_iterable
def test_is_iterable():
    class NotIterable:
        pass

    class Iterable:
        def __iter__(self):
            return iter(self)

    not_iterable = NotIterable()
    iterable = Iterable()

    assert is_iterable(iterable)
    assert not is_iterable(not_iterable)



# Generated at 2022-06-11 00:55:35.082356
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d = ImmutableDict(dict(a=[1,2,3],b=[1,2,3]))
    e = ImmutableDict(dict(a=[1,2,3],b=[1,2,3]))
    f = ImmutableDict(dict(a=[1,2,3]))
    g = ImmutableDict(dict(a=[1,2,3],b=[1,2,3,4]))
    assert d == e
    assert not d == f
    assert not d == g
    assert e == d
    assert not e == f
    assert not e == g
    assert not f == d
    assert not f == e
    assert not g == d
    assert not g == e


# Generated at 2022-06-11 00:55:41.614649
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test eq."""
    d1 = ImmutableDict({'key1': 'value1'})

    assert d1.__eq__(d1)
    assert d1.__eq__(MutableMapping(d1))
    assert not d1.__eq__(MutableMapping({'key1': 'value1', 'key2': 'value2'}))
    assert not d1.__eq__(MutableMapping({'key2': 'value1'}))
    assert not d1.__eq__(MutableMapping())



# Generated at 2022-06-11 00:55:44.876162
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    b = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert a == b



# Generated at 2022-06-11 00:55:50.255304
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    id1 = ImmutableDict({1:1, 2:2})
    id2 = ImmutableDict({1:1, 2:2})
    id3 = ImmutableDict({2:2, 1:1})
    id4 = ImmutableDict({3:3, 2:2})
    assert id1 == id2
    assert id1 == id3
    assert id2 == id3
    assert id1 != id4
    assert id2 != id4
    assert id3 != id4
    assert id1 != 1
    assert id1 != "original"

# Generated at 2022-06-11 00:56:01.210072
# Unit test for function is_iterable
def test_is_iterable():
    # Check that empty lists, tuples, sets and dictionaries are iterable
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())

    # Check that non-empty lists, tuples, sets and dictionaries are iterable
    assert is_iterable([1])
    assert is_iterable((1,))
    assert is_iterable({1: 1})
    assert is_iterable({1})

    # Check that strings are not iterable
    assert not is_iterable('hello')
    assert not is_iterable(u'hello')
    assert not is_iterable(b'hello')

    # Check that strings are iterable if the include_strings flag is True
    assert is_iterable('hello', include_strings=True)
   

# Generated at 2022-06-11 00:56:09.863687
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({'a': 'b'}) != ImmutableDict()
    assert ImmutableDict({'a': 'b'}) == ImmutableDict({'a': 'b'})
    assert ImmutableDict({'a': 'b'}) != ImmutableDict({'a': 'c'})
    assert ImmutableDict({'a': 'b'}) != ImmutableDict({'a': 'b', 'c': 'd'})
    assert ImmutableDict({'a': 'b', 'c': 'd'}) != ImmutableDict({'a': 'b'})
    assert ImmutableDict({'c': 'd'}) != ImmutableDict({'a': 'b'})

# Generated at 2022-06-11 00:56:15.102274
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    id1 = ImmutableDict([('a', 'b')])
    id2 = ImmutableDict({'a': 'b'})
    id3 = ImmutableDict()
    assert id1 == id2
    assert not id1 == id3
    assert not id1 == {'a': 'b'}
    assert not id1 == 'b'
    assert not id1 == [3, 2, 1]


# Generated at 2022-06-11 00:56:26.093530
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    # Test __eq__ when the other object is a Hashable and has the same hash as
    # the ImmutableDict.
    class OtherHashable(Hashable):
        def __hash__(self):
            return hash(('a', 'b', 'c'))

    assert ImmutableDict(a='b', c='d') != OtherHashable()

    # Test __eq__ when the other object has the same hash as but is not a Hashable.
    class OtherNotHashable:
        def __hash__(self):
            return hash(('a', 'b', 'c'))

    assert ImmutableDict(a='b', c='d') != OtherNotHashable()

    # Test __eq__ when the other object is not a Hashable but has the same elements
    # as the ImmutableDict.

# Generated at 2022-06-11 00:56:31.040337
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('string') == False
    assert is_iterable(1) == False
    assert is_iterable({}) == True

    class MyClass(object):
        pass

    assert is_iterable(MyClass()) == False

    class MyOtherClass(object):
        def __iter__(self):
            pass

    assert is_iterable(MyOtherClass()) == True



# Generated at 2022-06-11 00:57:21.802685
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_dict = {'test': 1}
    test_dict_copy = {'test': 1}
    test_dict_other = ImmutableDict({'test': 1})

    assert test_dict == test_dict_copy
    assert ImmutableDict(test_dict) == test_dict_other
    assert test_dict_other == ImmutableDict(test_dict)
    assert test_dict_other == {'test': 1}

# Generated at 2022-06-11 00:57:32.827025
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(key='value') == ImmutableDict(key='value')
    assert ImmutableDict(key='value') != ImmutableDict(key='another value')
    assert ImmutableDict(key='value') != ImmutableDict(None, key='value')
    assert ImmutableDict(key='value') != ImmutableDict(dict(key='value'))
    assert ImmutableDict(key='value') != ImmutableDict(key='value', second_key='second')
    assert ImmutableDict(key='value') != 'A string'
    assert ImmutableDict(key='value') != ['A', 'string']
    assert ImmutableDict(key='value') != ['A', 'string', 'that', 'is', 'a', 'list']