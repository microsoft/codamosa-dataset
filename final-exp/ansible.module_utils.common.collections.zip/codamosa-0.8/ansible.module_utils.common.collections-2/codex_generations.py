

# Generated at 2022-06-11 00:47:48.800865
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Tests to validate the immutabledict.__eq__ works with ImmutableDict, MutableMapping and plain Mapping
    """
    a = ImmutableDict({'a': 'b'})
    b = ImmutableDict({'a': 'b'})
    c = ImmutableDict({'a': 'c'})
    assert a == b, 'ImmutableDict is not equal to itself'
    assert not a == c, 'ImmutableDict is equal to another different ImmutableDict'
    assert not a == {'a': 'b'}, 'ImmutableDict is equal to a MutableMapping'
    assert not a == MutableMapping({'a': 'b'}), 'ImmutableDict is equal to MutableMapping'

# Generated at 2022-06-11 00:47:55.632895
# Unit test for function is_iterable
def test_is_iterable():
    class Iter(object):
        @staticmethod
        def __iter__():
            return iter([])

    class NotIter(object):
        pass

    class StrIter(object):
        def __iter__(self):
            return iter([])

    str = 'hello'
    list = []
    tuple = ()
    set = set([])
    dict = {}
    iter = Iter()
    notIter = NotIter()
    strIter = StrIter()
    assert is_iterable(str) is True
    assert is_iterable(list) is True
    assert is_iterable(tuple) is True
    assert is_iterable(set) is True
    assert is_iterable(dict) is True
    assert is_iterable(iter) is True
    assert is_iterable(notIter) is False

# Generated at 2022-06-11 00:48:07.143622
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'x': 1}) == ImmutableDict({'x': 1})
    assert ImmutableDict({'x': 1}) != ImmutableDict({'x': 2})
    assert ImmutableDict({'x': 1}) != ImmutableDict({'y': 1})
    assert ImmutableDict({'x': 1}) != ImmutableDict({'x': 1, 'y': 2})
    assert ImmutableDict({'x': 1}) != {'x': 1}
    assert ImmutableDict({'x': 1}) != 1
    assert ImmutableDict({'x': 1}) != None
    assert not ImmutableDict({'x': 1}).__eq__(None)


# Generated at 2022-06-11 00:48:16.599531
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict

    Initialize two ImmutableDict objects, assert that they're equal.
    Change the value in one of ImmutableDict objects, assert they're not equal anymore.

    :returns: True if the test succeeded, False otherwise
    :rtype: bool
    """
    first_immutable_dict = ImmutableDict({'key': 'value'})
    second_immutable_dict = ImmutableDict({'key': 'value'})
    assert first_immutable_dict == second_immutable_dict
    second_immutable_dict = ImmutableDict({'key': 'another value'})
    assert not first_immutable_dict == second_immutable_dict
    return True

# Generated at 2022-06-11 00:48:24.320102
# Unit test for function is_iterable
def test_is_iterable():
    class TestIterable(object):
        def __iter__(self):
            pass

    class TestNonIterable(object):
        pass

    assert(is_iterable(u'test'))
    assert(is_iterable(b'test'))
    assert(is_iterable([1, 2]))
    assert(is_iterable({1: 2}))
    assert(is_iterable(TestIterable()))
    assert(not is_iterable(TestNonIterable()))



# Generated at 2022-06-11 00:48:33.163750
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    orig = ImmutableDict({'a': 1, 'b': 2})
    new = ImmutableDict({'a': 1, 'b': 2})
    new2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert orig.__eq__(orig)
    assert orig.__eq__(new)
    assert not orig.__eq__(new2)
    assert not orig.__eq__({'a': 1, 'b': 2})
    assert not orig.__eq__({'a': 1})


# Generated at 2022-06-11 00:48:43.285150
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    A test case for the __eq__ method of class ImmutableDict

    A test case can have one or more asserts. If the asserts are more than one the last one
    has to be the return value because it is the only one that will be evaluated and the
    autotest will pass or fail based on it.
    """
    i_dict = ImmutableDict(dict_one = 'val_one', dict_two = 'val_two')
    assert  i_dict.__eq__('val_one') is False
    assert i_dict.__eq__({'dict_one' : 'val_one', 'dict_two' : 'val_two'}) is False
    assert i_dict.__eq__(ImmutableDict(dict_one = 'val_one', dict_two = 'val_two')) is True

# Generated at 2022-06-11 00:48:48.217120
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert not is_iterable(1)
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert not is_iterable('abc', include_strings=False)
    assert not is_iterable(u'abc', include_strings=False)



# Generated at 2022-06-11 00:48:56.984442
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    id1 = ImmutableDict()
    id2 = ImmutableDict()
    assert id1 == id2

    id1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    id2 = ImmutableDict({'key2': 'value2', 'key1': 'value1'})
    assert id1 == id2

    id1 = ImmutableDict({'key1': 'value1', 'key2': ImmutableDict({'subkey1': 'subvalue1', 'subkey2': 'subvalue2'})})
    id2 = ImmutableDict({'key2': ImmutableDict({'subkey2': 'subvalue2', 'subkey1': 'subvalue1'}), 'key1': 'value1'})
    assert id1 == id2


#

# Generated at 2022-06-11 00:49:04.832708
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable({'a': 'A', 'B': 1}), 'Dictionary is an iterable'
    assert is_iterable(['a', 'B', 'c']), 'List is an iterable'
    assert is_iterable(set(['a', 'B', 'c'])), 'Set is an iterable'
    assert is_iterable('abc'), 'Strings are iterable'
    assert not is_iterable(42), 'Just a number'
    assert not is_iterable(None), 'Nothing'


# Generated at 2022-06-11 00:49:17.931590
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable(xrange(0))
    assert is_iterable(('a', 'b', 'c'))
    assert is_iterable(xrange(0, 6))
    assert is_iterable({'a': 'b', 'c': 'd'})

    assert not is_iterable(None)
    assert not is_iterable(0)
    assert not is_iterable(1)
    assert not is_iterable(0.5)
    assert not is_iterable('a')
    assert not is_iterable(True)


# Generated at 2022-06-11 00:49:21.670440
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    id1 = ImmutableDict({"a": 1, "b": 2, "c": 3})
    id2 = ImmutableDict({"a": 1, "b": 2, "c": 3})
    assert(id1 == id2)


# Generated at 2022-06-11 00:49:28.816519
# Unit test for function is_iterable
def test_is_iterable():
    # simple strings are NOT iterable
    assert not is_iterable('simple')
    assert not is_iterable(u'simple')
    assert not is_iterable(b'simple')
    # but lists are
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable((x for x in range(10)))
    assert is_iterable(set((x for x in range(10))))
    assert not is_iterable(10)
    assert not is_iterable(object())


# Generated at 2022-06-11 00:49:33.046265
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable(iter([]))
    assert is_iterable(1) is False
    assert is_iterable(None) is False



# Generated at 2022-06-11 00:49:38.164922
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 'b', 'c']) == True
    assert is_iterable('abc') == True
    assert is_iterable({'a': '1', 'b': '2'}) == True
    assert is_iterable(('a', 'b', 'c')) == True
    assert is_iterable(1) == False


# Generated at 2022-06-11 00:49:40.706820
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) == True
    assert is_iterable(set()) == True
    assert is_iterable(tuple()) == True
    assert is_iterable(dict()) == True
    assert is_iterable(2) == False


# Generated at 2022-06-11 00:49:46.229154
# Unit test for function is_iterable
def test_is_iterable():
    class AnIterable1:
        def __iter__(self):
            return iter('abcd')

    class AnIterable2:
        def __iter__(self):
            yield 'abcd'

    class AnIterable3:
        def __iter__(self):
            def generator():
                yield 'abcd'
            return generator()

    class AnIterable4:
        def __getitem__(self):
            return 'abcd'

    class AnIterable5:
        def __getitem__(self, x):
            return 'abcd'

    class AnIterable6:
        def __getitem__(self, x, y):
            return 'abcd'

    class AnIterable7:
        def __getitem__(self, x=1):
            return 'abcd'


# Generated at 2022-06-11 00:49:56.277425
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # create two ImmutableDicts that have the same keys and values
    test_dict1 = ImmutableDict([('key1', 'val1'), ('key2', 'val2')])
    test_dict2 = ImmutableDict([('key1', 'val1'), ('key2', 'val2')])
    # test if first dict is equal to itself
    assert test_dict1 == test_dict1
    # test if first dict is equal to second dict
    assert test_dict1 == test_dict2
    # test if the first dict is equal to a MutableMapping
    assert not test_dict1 == dict([('key1', 'val1'), ('key2', 'val2')])

# Generated at 2022-06-11 00:50:01.601640
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())

    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(bytearray(b'abc'))
    assert not is_iterable(3)
    assert not is_iterable(3.14)


# Generated at 2022-06-11 00:50:11.504310
# Unit test for function is_iterable
def test_is_iterable():
    seqs = [
        ['a', 'b', 'c'],
        (1, 2, 3),
        set([3, 1, 2]),
        'abc',
        b'abc',
        ImmutableDict({'a': 'b'}),
        ImmutableDict(a='b'),
    ]
    for seq in seqs:
        assert(is_iterable(seq, include_strings=False))
        assert(is_iterable(seq, include_strings=True))
    # If a non-iterable is passed to is_iterable an exception is raised.
    try:
        is_iterable(1)
        assert(False)
    except:
        pass


# Generated at 2022-06-11 00:50:29.894491
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # test equality of same class' objects
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    # test equality of different class' objects
    assert ImmutableDict() == {}


# Generated at 2022-06-11 00:50:36.437712
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    test_dict_0 = ImmutableDict({"k": "v"})
    test_dict_1 = ImmutableDict({"k": "v"})
    test_dict_2 = ImmutableDict({"k": "v", "k2": "v2"})
    test_dict_3 = {"k": "v"}

    assert(test_dict_0 == test_dict_1)
    assert(test_dict_0 != test_dict_2)
    assert(test_dict_0 != test_dict_3)



# Generated at 2022-06-11 00:50:43.416248
# Unit test for function is_iterable
def test_is_iterable():
    class AnIterable(object):
        def __iter__(self):
            return iter(range(3))

    class AString(str):
        def __iter__(self):
            return iter(range(3))

    class NotIterable(object):
        pass

    assert is_iterable('')
    assert is_iterable('abc')
    assert is_iterable(b'')
    assert is_iterable(b'abc')
    assert is_iterable(object())
    assert is_iterable(AString())
    assert not is_iterable(NotIterable())
    assert is_iterable(AnIterable())

    assert is_iterable('', include_strings=True)
    assert is_iterable('abc', include_strings=True)

# Generated at 2022-06-11 00:50:51.913237
# Unit test for method __eq__ of class ImmutableDict

# Generated at 2022-06-11 00:51:00.991861
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d = ImmutableDict({'a': 1, 'b': 2})
    assert d == d
    assert d == {'a': 1, 'b': 2}
    assert d == ImmutableDict({'b': 2, 'a': 1})
    assert d == ImmutableDict(a=1, b=2)

    assert d != {'a': 2, 'b': 2}
    assert d != ImmutableDict({'b': 2, 'a': 2})
    assert d != ImmutableDict(a=2, b=2)
    assert d != 42



# Generated at 2022-06-11 00:51:12.314104
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'1': 1, '2': 2, '3': 3}) != ImmutableDict({'1': 1, '2': 2, '3': 3, '4': 4})
    assert ImmutableDict({'1': 1, '2': 2, '3': 3}) != ImmutableDict({'1': 1, '2': 2, '4': 3})
    assert ImmutableDict({'1': 1, '2': 2, '3': 3}) == ImmutableDict({'3': 3, '1': 1, '2': 2})
    assert ImmutableDict({'1': 1, '2': 2, '3': 3}) == {'2': 2, '3': 3, '1': 1}
    assert ImmutableDict({'1': 1, '2': 2, '3': 3})

# Generated at 2022-06-11 00:51:14.291102
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)

# Generated at 2022-06-11 00:51:25.383919
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Hashable items
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2

    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'b': 2, 'a': 1})
    assert d1 == d2

    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 != d2

    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 3})
    assert d1

# Generated at 2022-06-11 00:51:28.885250
# Unit test for function is_iterable
def test_is_iterable():
    class TestClass(object):
        def __iter__(self):
            return iter(tuple())

    assert is_iterable(TestClass())
    assert is_iterable(TestClass)



# Generated at 2022-06-11 00:51:40.553746
# Unit test for function is_iterable
def test_is_iterable():
    class NotIterable:
        pass

    class Iterable(object):
        def __iter__(self):
            pass

    class SequenceSubclass(object):
        # This is not actually a sequence, just a duck type to test this is_sequence
        # implementation is not looking for the abstract Sequence class
        def __getitem__(self, key):
            pass

    assert is_iterable(None)
    assert is_iterable(NotIterable)
    assert is_iterable(Iterable())
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable(SequenceSubclass())
    assert is_iterable('abc')
    assert is_iterable(b'abc')


# Generated at 2022-06-11 00:52:02.335321
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1})
    b = ImmutableDict({'a': 1})
    c = ImmutableDict({'a': 1})
    d = ImmutableDict({'a': 2})
    assert a == a
    assert a == b
    assert a == c
    assert not a == d
    assert b == a
    assert b == b
    assert b == c
    assert not b == d
    assert c == a
    assert c == b
    assert c == c
    assert not c == d
    assert not d == a
    assert not d == b
    assert not d == c
    assert d == d

# Generated at 2022-06-11 00:52:08.552672
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # type: (str, None) -> dict
    """Unit test for method __eq__ of class ImmutableDict."""
    d1 = ImmutableDict(x=1, y=2)
    d2 = ImmutableDict(y=2, x=1)
    d3 = ImmutableDict(x=1)

    assert d1 == d2
    assert d1 != d3

# Generated at 2022-06-11 00:52:14.787729
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('')
    assert is_iterable('a')
    assert is_iterable('ab')
    assert is_iterable(u'')
    assert is_iterable(u'a')
    assert is_iterable([])
    assert is_iterable([1])
    assert is_iterable([1, 2])
    assert is_iterable((1, 2))
    assert is_iterable({})
    assert is_iterable({'a': 1})
    assert not is_iterable(())
    assert not is_iterable(0)
    assert not is_iterable(1)


# Generated at 2022-06-11 00:52:23.783241
# Unit test for function is_iterable
def test_is_iterable():
    """Test function is_iterable."""
    assert is_iterable("some string") is True
    assert is_iterable("some string", include_strings=True) is True
    assert is_iterable("some string", include_strings=False) is False
    assert is_iterable(1) is False
    assert is_iterable(1.2) is False
    assert is_iterable(None) is False
    assert is_iterable(MutableMapping()) is True
    assert is_iterable(MutableMapping().values()) is True
    assert is_iterable(set()) is True
    assert is_iterable({}) is True

# Generated at 2022-06-11 00:52:31.466809
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    dict3 = dict({'a': 1, 'b': 2})
    dict4 = dict1
    assert dict1 == dict2
    assert dict1 == dict3
    assert dict1 == dict4
    assert dict1 != dict({'a': 1, 'b': 3})
    assert dict1 != dict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-11 00:52:41.613339
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test comparison of two ImmutableDict objects
    a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    b = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    c = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    d = ImmutableDict({'c': 3, 'b': 2, 'a': 1})
    e = ImmutableDict({'a': 3, 'b': 2, 'c': 1})

    # The two ImmutableDict objects should be equal
    assert(a == b)

    # The two ImmutableDict objects should not be equal
    assert(a != c)
    assert(a != d)
    assert(a != e)

    # The

# Generated at 2022-06-11 00:52:54.173372
# Unit test for function is_iterable
def test_is_iterable():

    # Assert that strings are iterable
    assert is_iterable('string') is True
    assert is_iterable(b'string') is True

    # Assert that collections are iterable
    assert is_iterable([1, 2]) is True
    assert is_iterable(set((1, 2))) is True
    assert is_iterable(dict(a=1)) is True

    # Assert that types of basic classes are NOT iterable
    assert is_iterable(set()) is False
    assert is_iterable(dict()) is False

    # Assert that generator objects are iterable
    assert is_iterable((x for x in range(0))) is True

    # Assert that other objects are not iterable
    assert is_iterable(5) is False
    assert is_iterable(5.5) is False
   

# Generated at 2022-06-11 00:53:04.191727
# Unit test for function is_iterable
def test_is_iterable():
    # Testing iterables, should return True
    assert is_iterable(iter('test'))
    assert is_iterable([])
    assert is_iterable([1])
    assert is_iterable((1,))
    assert is_iterable({})
    assert is_iterable({'test': 'dict'})
    assert is_iterable(set())
    assert is_iterable(set([1, 2]))
    # Testing strings and bytes
    assert is_iterable('test', include_strings=True)
    assert is_iterable(b'test', include_strings=True)
    # Testing non iterables, should return False
    assert not is_iterable('test')
    assert not is_iterable(b'test')
    assert not is_iterable(1)

# Generated at 2022-06-11 00:53:11.479585
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Check for exception for non-hashable objects
    d1 = ImmutableDict(x=[1, 2, 3])
    d2 = dict(x=[1, 2, 3])
    assert (d1 != d2), "Both objects are hashable"
    assert (d1 == ImmutableDict(x=[1, 2, 3])), "Both objects are equal"
    assert (d1 != ImmutableDict(y=[1, 2, 3])), "Both objects are not equal"



# Generated at 2022-06-11 00:53:19.277677
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test ImmutableDict.__eq__ method."""
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(c=3, a=1, b=2)
    d3 = ImmutableDict(a=1, b=2, c=3)
    assert d1 == d1
    assert d1 != d2
    assert d2.union(d1) == d1
    assert d1.union(d2) == d3
    assert d1.union(d1) == d1

# Generated at 2022-06-11 00:53:54.324977
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(list())
    assert is_iterable(tuple())
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(dict().items())
    assert is_iterable([1, 2, 3])
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(2) is False
    assert is_iterable(2.0) is False
    assert is_iterable(None) is False

    # Non-index

# Generated at 2022-06-11 00:54:04.497185
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    class Foo(object):
        pass
    foo = Foo()
    foo.bar = 'baz'
    bar = {'baz': 'foo'}
    d = ImmutableDict(foo=foo, bar=bar)
    # Test truthy equality
    assert d == d
    # Test equality with different ImmutableDict instance with same keys and values
    assert d == ImmutableDict(foo=foo, bar=bar)
    # Test equality with different order of keys within ImmutableDict instance
    assert d == ImmutableDict(bar=bar, foo=foo)
    # Test equality with differently created ImmutableDict instance
    assert d == ImmutableDict({'foo': foo, 'bar': bar})
    # Test equality with regular dictionary
    assert d == {'foo': foo, 'bar': bar}
    # Test equality

# Generated at 2022-06-11 00:54:13.177230
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1, 2, 3})
    assert is_iterable({1: 1, 2: 2})
    assert is_iterable(xrange(1, 2 ** 30))

    assert not is_iterable(1)
    assert not is_iterable(object())

    assert is_iterable(text_type(''))
    assert is_iterable(binary_type(''))

    assert not is_iterable(text_type(''), include_strings=False)
    assert not is_iterable(binary_type(''), include_strings=False)

# Generated at 2022-06-11 00:54:19.706290
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable([])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(range(3))
    assert is_iterable([iter([1, 2, 3])])
    assert not is_iterable('abc')
    assert not is_iterable(b'abc')


# Generated at 2022-06-11 00:54:25.172397
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3, 4])
    assert is_iterable([])
    assert is_iterable(('a', 'b'))
    assert is_iterable(set((1, 2, 3)))
    assert is_iterable(frozenset((1, 2, 3)))
    assert is_iterable({'a': 'b'})
    assert is_iterable(1) is False



# Generated at 2022-06-11 00:54:35.119921
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    idict = ImmutableDict()
    assert idict == {}
    assert ImmutableDict() == ImmutableDict()
    assert idict != {'a': 1}
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})


# Generated at 2022-06-11 00:54:43.158520
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({"a": 1, "b": 2, "c": 3})
    d2 = ImmutableDict({"a": 1, "b": 2, "c": 3})
    d3 = ImmutableDict({"a": 1, "b": 2, "c": 5})
    d4 = ImmutableDict({"a": 2, "b": 3, "c": 4})
    assert d1 == d2
    assert d1 != d3
    assert d1 != d4
    assert d2 != d3
    assert d2 != d4
    assert d3 != d4

# Generated at 2022-06-11 00:54:54.153618
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = dict({1:'one', 2:'two'})
    dict2 = dict({1:'one', 2:'two'})
    dict3 = dict({1:'one', 3:'three'})
    dict4 = dict({4:'four', 5:'five'})
    dict5 = dict({4:'four', 6:'six'})

    immdict1 = ImmutableDict(dict1)
    immdict2 = ImmutableDict(dict2)
    immdict3 = ImmutableDict(dict3)
    immdict4 = ImmutableDict(dict4)
    immdict5 = ImmutableDict(dict5)

    assert immdict1 == immdict1
    assert immdict1 == immdict2
    assert not immdict1 == immdict3
    assert not immdict1 == immdict4

# Generated at 2022-06-11 00:55:01.776630
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({'a': 'b'})
    dict2 = ImmutableDict({'a': 'b'})
    dict3 = ImmutableDict({'a': 'b'})
    dict4 = ImmutableDict({'a': 'b', 'b': 'c'})
    dict5 = ImmutableDict({'1': '2', '2': '3'})
    dict6 = dict({'1': '2', '2': '3'})
    dict7 = dict4.union({'c' : 'd'})
    dict8 = dict4.difference('c')
    dict9 = dict4.difference('d')
    dict10 = dict4.difference(dict4.keys())
    dict11 = dict4.difference(dict4)
    dict12 = dict4.diff

# Generated at 2022-06-11 00:55:12.571061
# Unit test for function is_iterable
def test_is_iterable():
    class MyClass(object):
        pass

    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable(xrange(10))
    assert is_iterable((1, 2, 3))
    assert is_iterable({1: "1", 2: "2", 3: "3"})
    assert is_iterable({})
    assert is_iterable(MyClass())
    assert is_iterable(set([1, 2, 2, 3, 4]))
    assert is_iterable("123")
    assert is_iterable(u"123")
    assert not is_iterable(True)
    assert not is_iterable(None)
    assert not is_iterable(-1)
    assert not is_iterable(-1.0)


# Generated at 2022-06-11 00:56:11.130000
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(object()) == False
    assert is_iterable(range(5)) == True
    assert is_iterable([1, 2]) == True
    assert is_iterable(set((1, 2))) == True
    assert is_iterable(dict(a=1, b=2)) == True
    assert is_iterable(tuple([1, 2])) == True

    assert is_iterable('a string') == True
    assert is_iterable(b'a string') == True
    assert is_iterable("a string") == True

    # ImmutableDict
    assert is_iterable(ImmutableDict(a=1, b=2)) == True

    # AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-11 00:56:15.914883
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test behavior with non Hashable types
    dict_1 = ImmutableDict({'a': [], 'b': {}})
    dict_2 = ImmutableDict({'a': [], 'b': {}})

    assert dict_1 == dict_2

    # Test behavior with Hashable types
    dict_1 = ImmutableDict({'a': [1, 2, 3], 'b': {'c': 1}})
    dict_2 = ImmutableDict({'a': [1, 2, 3], 'b': {'c': 1}})

    assert dict_1 == dict_2


# Generated at 2022-06-11 00:56:27.352698
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(())
    assert is_iterable('')
    assert is_iterable('abc')
    assert is_iterable(b'abc')
    assert is_iterable({'a': 1, 'b': 2, 'c': 3})
    assert is_iterable(set([1, 2, 3]))
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(True)
    assert not is_iterable({'a': 1, 'b': 2, 'c': 3}.keys)
    assert not is_iterable({'a': 1, 'b': 2, 'c': 3}.values)

# Generated at 2022-06-11 00:56:32.770788
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(dict(a='1', b='2'))
    assert is_iterable('ola')
    assert is_iterable(b'ola')
    assert not is_iterable(None)
    assert not is_iterable(3)
    assert not is_iterable(3.0)


# Generated at 2022-06-11 00:56:43.386464
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1})
    b = ImmutableDict({'a': 1})
    c = ImmutableDict({'b': 1})
    d = {'a': 1}

    assert a == b
    assert a != c
    assert not a == c
    assert not a == d
    assert not c == d
    assert a != d
    assert a.union({'c': 1}) == ImmutableDict({'a': 1, 'c': 1})
    assert b.union({'c': 1}) == ImmutableDict({'a': 1, 'c': 1})
    assert c.union({'c': 1}) == ImmutableDict({'b': 1, 'c': 1})
    assert a.difference({'a'}) == ImmutableDict()
    assert b.difference

# Generated at 2022-06-11 00:56:51.889972
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert not ImmutableDict({'a': 1, 'b': 2}) == None
    assert not ImmutableDict({'a': 1, 'b': 2, 'c': 3}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}) == ImmutableDict({'a': 1, 'b': 2, 'c': 3})


# Generated at 2022-06-11 00:56:54.465089
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert not is_iterable(1)
    assert not is_iterable('a')



# Generated at 2022-06-11 00:57:00.806407
# Unit test for function is_iterable
def test_is_iterable():
    """Unit test for function is_iterable."""
    string = 'abcdef'
    iterable = (1, 2, 3)
    non_iterable = 1
    assert is_iterable(string)
    assert is_iterable(iterable)
    assert not is_iterable(non_iterable)
    assert is_iterable(string, include_strings=True)
    assert not is_iterable(string, include_strings=False)


# Generated at 2022-06-11 00:57:06.328604
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())

    assert is_iterable(tuple())
    assert is_iterable('abc')
    assert is_iterable(u'abc')

    assert not is_iterable(1)
    assert not is_iterable(None)



# Generated at 2022-06-11 00:57:16.169177
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    test_ImmutableDict___eq__()
    """
    # test for simple case
    imm_dict = ImmutableDict({"a":1, "b":2, "c":3, "d":4, "e":5})
    # imm_dict is equal to itself
    assert imm_dict == imm_dict
    # imm_dict is equal to a dictionary with the same key-value pairs
    assert imm_dict == {"a":1, "b":2, "c":3, "d":4, "e":5}
    # imm_dict is not equal to a dictionary with different keys
    assert imm_dict != {"x":1, "b":2, "c":3, "d":4, "e":5}
    # imm_dict is not equal to a dictionary with different values