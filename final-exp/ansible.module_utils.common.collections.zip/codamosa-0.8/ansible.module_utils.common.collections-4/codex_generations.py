

# Generated at 2022-06-11 00:47:47.996049
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Verify that equality works properly"""
    d1 = ImmutableDict({'a': 100, 'b': 200, 'c': 300})
    d2 = ImmutableDict({'a': 'same', 'b': 'same', 'c': 'different'})
    d3 = ImmutableDict({'a': 100, 'c': 300, 'b': 200})
    d4 = ImmutableDict({'a': 100, 'c': 300})
    d5 = ImmutableDict({'a': 100, 'c': 300, 'b': 400})

    # exact matches
    d1 == d1
    d1 == d3
    d1 == d4

    # supersets
    d1 == d2

    # subsets
    d4 == d1

    # other types
    d1 == d5
    d1

# Generated at 2022-06-11 00:47:55.222228
# Unit test for function is_iterable
def test_is_iterable():
    class NoIter:
        pass
    assert is_iterable('string') == False
    assert is_iterable(u'string') == False
    assert is_iterable(u'\u00E9') == False
    assert is_iterable(b'bytes') == False
    assert is_iterable([]) == True
    assert is_iterable(set()) == True
    assert is_iterable(tuple()) == True
    assert is_iterable(dict()) == True
    assert is_iterable(NoIter()) == False
    assert is_iterable(set([])) == True
    assert is_iterable(tuple([])) == True
    assert is_iterable(dict([])) == True

# Generated at 2022-06-11 00:48:07.607262
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():

    # TODO: this test shows a difference between Python 2 and Python 3.
    # In Python 3, the ImmutableDict behaves as expected, in Python 2 the ImmutableDict
    # is expected to be slightly different. The differences are:
    # 1. In Python3, the second argument can be any iterable, in Python 2 it has to be an ImmutableDict
    # 2. In Python3, a TypeError is raised if the second argument is not an ImmutableDict,
    #    in Python 2, the 'remove_keys' are set to an empty set

    original = ImmutableDict({"a": 1, "b": 2, "c": 3})
    result = original.difference(['a'])
    assert isinstance(result, ImmutableDict)

# Generated at 2022-06-11 00:48:10.032468
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d_base = ImmutableDict({'d': 'd', 'b': 'b', 'a': 'a'})
    d_expected = ImmutableDict({'b': 'b', 'a': 'a'})
    d_result = d_base.difference({'d'})
    assert d_expected == d_result



# Generated at 2022-06-11 00:48:18.927874
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    x = ImmutableDict({"a": 1, "b": 2, "c": 3, "d": 4})
    assert x.difference(("a", "c")) == ImmutableDict({"b": 2, "d": 4})
    assert x.difference("a") == ImmutableDict({"b": 2, "c": 3, "d": 4})
    assert x.difference("c") == ImmutableDict({"a": 1, "b": 2, "d": 4})
    assert x.difference("d") == ImmutableDict({"a": 1, "b": 2, "c": 3})
    assert x.difference("e") == ImmutableDict({"a": 1, "b": 2, "c": 3, "d": 4})

# Generated at 2022-06-11 00:48:25.592741
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    test_list = ['a', 'b']

    new_dict = test_dict.difference(test_list)

    assert len(new_dict) == 2
    assert new_dict['c'] == 3
    assert new_dict['d'] == 4



# Generated at 2022-06-11 00:48:37.737354
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    This test is to demonstrate equality comparison between ImmutableDicts.
    """
    # Tests for simple variation in the items of ImmutableDict instances which should be considered unequal
    assert ImmutableDict({'a':1, 'b':2}) != ImmutableDict({'a':1, 'b':3})
    assert ImmutableDict({'a':1, 'b':2}) != ImmutableDict({'a':2, 'b':2})
    assert ImmutableDict({'a':1, 'b':2}) != ImmutableDict({'a':1, 'b':2, 'c':3})

    # Test that unequal instances produce unequal hash values
    assert hash(ImmutableDict({'a':1, 'b':2})) != hash(ImmutableDict({'a':1, 'b':3}))

# Generated at 2022-06-11 00:48:40.953843
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d = ImmutableDict({'one': 1, 'two': 2, 'three': 3})
    assert d.difference(['three']) == ImmutableDict({'one': 1, 'two': 2})


# Generated at 2022-06-11 00:48:48.011842
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    assert ImmutableDict({'a': 1, 'b': 2}).difference(['a', 'b']) == ImmutableDict()
    assert ImmutableDict({'a': 1, 'b': 2}).difference(['b']) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}).difference(['c']) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}).difference(['a', 'c']) == ImmutableDict({'b': 2})

# Generated at 2022-06-11 00:48:56.946925
# Unit test for function is_iterable
def test_is_iterable():
    import builtins
    assert is_iterable(None)
    assert is_iterable([])
    assert is_iterable([1,2,3])
    assert is_iterable([1,2,builtins.set()])
    assert is_iterable(builtins.set())
    assert is_iterable(builtins.frozenset())
    assert is_iterable(builtins.tuple())
    assert is_iterable(builtins.list())
    assert is_iterable(builtins.dict())
    assert is_iterable(builtins.dict({'a':1, 'b':2}))
    assert is_iterable(builtins.range(10))
    assert is_iterable(builtins.xrange(10))

# Generated at 2022-06-11 00:49:07.412563
# Unit test for function is_iterable
def test_is_iterable():
    # positive scenarios
    assert is_iterable([]) is True
    assert is_iterable(()) is True
    assert is_iterable(set()) is True
    assert is_iterable(xrange(1)) is True
    assert is_iterable({}) is True
    assert is_iterable(dict()) is True
    # negative scenarios
    assert is_iterable(None) is False



# Generated at 2022-06-11 00:49:15.764734
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # The __eq__ method is called by the assert functions, so to test it we
    # need to use assertEqual.
    # pylint: disable=deprecated-method
    d1 = ImmutableDict({'foo': 'bar'})
    d2 = ImmutableDict({'foo': 'bar'})
    assert d1 == d2
    assert d1 != {}
    assert d1 != {'foo': 'baz'}
    assert d1 != ImmutableDict({'foo': 'baz'})
    # pylint: enable=deprecated-method



# Generated at 2022-06-11 00:49:19.214594
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({"a":1, "b":2})
    d2 = ImmutableDict({"a":1, "a":2})
    assert d1 == d2


# Generated at 2022-06-11 00:49:26.180789
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    print("Test __eq__")
    dict1 = ImmutableDict({"a": "b"})
    dict2 = ImmutableDict({"a": "b"})
    dict3 = ImmutableDict({"a": "c"})
    dict4 = dict({"a": "b"})
    dict5 = dict1.difference(["a"])
    print("dict1 == dict2 is {0}".format("True" if dict1 == dict2 else "False"))
    print("dict1 == dict3 is {0}".format("True" if dict1 == dict3 else "False"))
    print("dict1 == dict4 is {0}".format("True" if dict1 == dict4 else "False"))

# Generated at 2022-06-11 00:49:30.659222
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d = ImmutableDict(a=[1, 2], b=True)
    assert d == dict(a=[1, 2], b=True)
    assert d != dict(a=[2, 3], b=True)
    assert d == ImmutableDict(a=[2, 3], b=True)


# Generated at 2022-06-11 00:49:40.833504
# Unit test for function is_iterable
def test_is_iterable():
    """Test function is_iterable."""
    assert is_iterable([]) is True
    assert is_iterable(()) is True
    assert is_iterable({}) is True
    assert is_iterable(set()) is True
    assert is_iterable(dict()) is True
    assert is_iterable(list()) is True
    assert is_iterable(tuple()) is True
    assert is_iterable(dict()) is True
    assert is_iterable(set()) is True
    assert is_iterable('') is True
    assert is_iterable(u'') is True
    assert is_iterable(set()) is True
    assert is_iterable(dict()) is True
    assert is_iterable(set()) is True
    assert is_iterable(int()) is True
    assert is_iterable(complex())

# Generated at 2022-06-11 00:49:46.521306
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # Create the test data
    org_dict = ImmutableDict({'A': 1, 'B': 2, 'C': 3})
    iterable_keys = ['B', 'C', 'Z']
    new_dict = org_dict.difference(iterable_keys)

    expected_dict = ImmutableDict({'A': 1})

    assert new_dict == expected_dict


# Generated at 2022-06-11 00:49:52.487386
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2])
    assert is_iterable({'a': 1})
    assert is_iterable(('a', 1))
    assert not is_iterable('abc')
    assert is_iterable('abc', include_strings=True)
    assert is_iterable(ImmutableDict({'a': 1}))

# Generated at 2022-06-11 00:49:59.947742
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) == True
    assert is_iterable(()) == True
    assert is_iterable(set()) == True
    assert is_iterable({}) == True
    assert is_iterable("") == True
    assert is_iterable(bytearray()) == True
    assert is_iterable(True) == False
    assert is_iterable(1) == False
    assert is_iterable(None) == False
    assert is_iterable(open("/dev/null")) == True


# Generated at 2022-06-11 00:50:07.798350
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d = dict(a=1, b=2)
    i = ImmutableDict(d)
    assert i == d
    assert not i == dict(a=1, b=2, c=3)
    assert not i == dict(a=1, b=4)
    assert not i == dict(a=1)
    assert not i == dict(b=2)
    assert i == ImmutableDict(a=1, b=2)
    assert not i == ImmutableDict(a=1, b=2, c=3)
    assert not i == ImmutableDict(a=1, b=4)
    assert not i == ImmutableDict(a=1)
    assert not i == ImmutableDict(b=2)

# Generated at 2022-06-11 00:50:29.894457
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable([1,2,3]))
    assert(is_iterable((1,2,3)))
    assert(is_iterable(set([1,2,3])))
    assert(is_iterable({1:"a", 2:"b"}))
    assert(is_iterable(range(5)))
    assert(is_iterable(xrange(5)))
    assert(is_iterable("string"))
    assert(is_iterable(b"string"))
    assert(is_iterable(6) == False)
    assert(is_iterable([1,'a']) == True)
    assert(is_iterable(('a','b','c')) == True)
    assert(is_iterable(set(['a','b'])) == True)

# Generated at 2022-06-11 00:50:36.749764
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(['1', '2', '3'])
    assert not is_iterable(None)
    assert not is_iterable('1')
    assert not is_iterable('123')
    # Test strings
    assert is_iterable([], True)
    assert is_iterable(['1', '2', '3'], True)
    assert not is_iterable(None, True)
    assert is_iterable('1', True)
    assert is_iterable('123', True)


# Generated at 2022-06-11 00:50:43.595028
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import copy
    dict_a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict_b = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict_c = ImmutableDict({'a': 0, 'b': 2, 'c': 3})
    dict_d = ImmutableDict({'a': 1, 'b': 3, 'c': 3})
    dict_e = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    dict_f = ImmutableDict({'a': 1, 'b': 2})
    dict_g = ImmutableDict({'a': 1, 'b': 2})
    dict_g_copy = copy.copy(dict_g)

# Generated at 2022-06-11 00:50:46.477537
# Unit test for function is_iterable
def test_is_iterable():
    seq = [1, 2]
    assert is_iterable(seq)
    assert not is_iterable(1)
    assert is_iterable(set(seq))

# Generated at 2022-06-11 00:50:50.960393
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([], include_strings=True)
    assert is_iterable({}, include_strings=True)
    assert is_iterable(set(), include_strings=True)
    assert is_iterable((), include_strings=True)
    assert is_iterable('hello', include_strings=True)
    assert is_iterable(b'hi there', include_strings=True)

    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(())

    assert not is_iterable('hello')
    assert not is_iterable(b'hi there')



# Generated at 2022-06-11 00:50:58.443877
# Unit test for function is_iterable
def test_is_iterable():
    """Unit test for function is_iterable"""
    iterables = [
        'a',
        (1, 2),
        frozenset((1, 2, 3, 4)),
        ['a', 'b', 1, 2],
        range(0, 10),
        ImmutableDict({'a': 1, 'b': 2}),
        {1: 2, 3: 4},
    ]
    for check_iterable in iterables:
        assert is_iterable(check_iterable)

    non_iterables = [
        1,  # int
        1.0,  # float
        True,  # bool
        None,  # None
        [1, 2, 3],  # list
        [i for i in range(0, 10)]  # generator
    ]

# Generated at 2022-06-11 00:51:05.089089
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    This test assert if ImmutableDict__eq__ method return true when the hash of both dictionaries are equal
    """
    test_dict_one = ImmutableDict(dict(a=1, b=2, c=3))
    test_dict_two = ImmutableDict(dict(a=1, b=2, c=3))
    assert test_dict_one == test_dict_two


# Generated at 2022-06-11 00:51:10.145341
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({'a':1})
    dict2 = ImmutableDict({'a':1})
    dict3 = ImmutableDict({'a':2})
    assert dict1 == dict2
    assert dict2 == dict1
    assert dict1 != dict3
    assert dict3 != dict1


# Generated at 2022-06-11 00:51:21.943835
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Function to test the '__eq__' method of class ImmutableDict

    :return: bool - True if the tests were successful
    """
    # Simple two-item dictionary
    d = ImmutableDict(a=1, b=2)
    # Same two-item dictionary
    d2 = ImmutableDict(b=2, a=1)
    # Another two-item dictionary, with a different key.
    d3 = ImmutableDict(a=1, c=3)
    # ImmutableDict with different items
    d4 = ImmutableDict(a=1, b=4)

    if not d == d2:
        return False

    if d == d3:
        return False

    if d == d4:
        return False

    # Test with a set of ImmutableDicts
    elements

# Generated at 2022-06-11 00:51:29.489028
# Unit test for function is_iterable
def test_is_iterable():
    """Unit test for function is_iterable."""
    # Verify that non-iterable objects
    assert not is_iterable(object())
    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(bool())
    assert not is_iterable(None)
    assert not is_iterable(object())

    # Verify that iterable objects
    assert is_iterable(is_iterable)
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable((i for i in range(10)))
    # if we use the following syntax on Python 3.x,
    # the Python interpreter raises a SyntaxError with the message:
    # SyntaxError: bytes can only contain ASCII literal characters.
    #assert is_iterable(

# Generated at 2022-06-11 00:51:52.269769
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # test for None
    assert not ImmutableDict({'a':1}) == None
    # test for equal
    assert ImmutableDict({'a':1}) == ImmutableDict({'a':1})
    # test for different
    assert not ImmutableDict({'a':1}) == ImmutableDict({'a':2})
    # test for sub set
    assert not ImmutableDict({'a':1}) == ImmutableDict({'a':1, 'b':2})
    # test for superset
    assert not ImmutableDict({'a':1, 'b':2}) == ImmutableDict({'a':1})
    # test for not equal
    assert not ImmutableDict({'a':1}) == ImmutableDict({'b':1})

# Generated at 2022-06-11 00:51:59.267199
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a='a') == ImmutableDict(a='a')
    assert ImmutableDict(a='a') != ImmutableDict(a='x')
    assert ImmutableDict(a='a', b='b') != ImmutableDict(a='a', c='c')
    assert ImmutableDict(a='a', b='b') != ImmutableDict(a='a')



# Generated at 2022-06-11 00:52:10.627072
# Unit test for function is_iterable
def test_is_iterable():
    """Make sure is_iterable function behaves properly"""

    # positive tests
    from collections import Iterable
    from ansible.vars.unsafe_proxy import AnsibleVaultEncryptedUnicode
    class FakeIterable(Iterable):
        def __iter__(self):
            return iter([])

    assert is_iterable([])
    assert is_iterable(tuple())
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(AnsibleVaultEncryptedUnicode('abc'))
    assert is_iterable(FakeIterable())

    # negative tests
    assert not is_iterable(1)
    assert not is_iterable(123)
    assert not is_iterable(None)
    assert not is_iterable(False)
   

# Generated at 2022-06-11 00:52:20.256062
# Unit test for function is_iterable
def test_is_iterable():
    class Dog(object):
        def __init__(self, name, sound):
            self.name = name
            self.sound = sound

    class DogTester(object):
        def __iter__(self):
            return iter([Dog('Snoopy', 'woof'), Dog('Scooby', 'roof')])

    assert is_iterable([1, 2, 3])
    assert is_iterable((1.3, 2.5, 3.2))
    assert is_iterable(DogTester())
    assert is_iterable(range(3))
    assert is_iterable(set([42]))
    assert is_iterable(dict(a='A', b='B'))
    assert not is_iterable(42)
    assert not is_iterable(1.2)
    assert not is_iterable

# Generated at 2022-06-11 00:52:30.772938
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable(iter([])) is True
    assert is_iterable(()) is True
    assert is_iterable('') is False
    assert is_iterable(b'') is False
    assert is_iterable(0) is False
    assert is_iterable(set()) is True
    assert is_iterable(dict()) is True
    assert is_iterable(None) is False
    assert is_iterable('abc') is False
    assert is_iterable(b'abc') is False
    assert is_iterable(b'abc', include_strings=True) is True
    assert is_iterable('abc', include_strings=True) is True



# Generated at 2022-06-11 00:52:40.478106
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1, 'b':2, 'c': 3})
    d2 = ImmutableDict({'a': 1, 'b':2, 'c': 3})
    d3 = ImmutableDict({'a': 1, 'b':2, 'c': 4})
    d4 = ImmutableDict({'a': 1, 'c': 3})
    d5 = ImmutableDict({'a': 1, 'b':2})

    assert d1 == d1
    assert d1 == d2
    assert d2 == d1
    assert not d1 == d3
    assert not d1 == d4
    assert not d1 == d5
    assert not d1 == 'some string'

# Generated at 2022-06-11 00:52:48.063531
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(u'abc')
    assert is_iterable([1, 2, 3])
    assert is_iterable(('a', 'b', 'c'))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(dict())
    assert is_iterable([x for x in range(10)])

    assert not is_iterable('abc')
    assert not is_iterable(1)



# Generated at 2022-06-11 00:52:51.736083
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({1: 2, 3: 4})
    b = ImmutableDict({3: 4, 1: 2})
    c = ImmutableDict({5: 6, 7: 8})
    assert a == b
    assert a != c

# Generated at 2022-06-11 00:53:02.387889
# Unit test for function is_iterable
def test_is_iterable():
    """Unit test to check if the function is_iterable works correctly."""
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())

    assert is_iterable('1')
    assert is_iterable(u'1')
    assert is_iterable(b'1')

    assert not is_iterable(1)

    assert is_iterable([], include_strings=True)
    assert is_iterable({}, include_strings=True)
    assert is_iterable(set(), include_strings=True)

    assert is_iterable('1', include_strings=True)
    assert is_iterable(u'1', include_strings=True)
    assert is_iterable(b'1', include_strings=True)


# Generated at 2022-06-11 00:53:08.773581
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict([('a', 1), ('b', 2)]) == ImmutableDict([('a', 1), ('b', 2), ('c', 3)]) == ImmutableDict([('a', 1), ('b', 2), ('c', 3), ('a', 1), ('b', 2)]) == ImmutableDict({'a': 1, 'b': 2, 'c': 3}) == ImmutableDict(zip(['a', 'b', 'c'], [1, 2, 3]))
    assert ImmutableDict() != ImmutableDict([('a', 1)])
    assert ImmutableDict([('a', 1), ('b', 2)]) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableD

# Generated at 2022-06-11 00:53:40.161002
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 'b'}) == ImmutableDict({'a': 'b'})
    assert ImmutableDict({'a': 'b'}) != ImmutableDict({'a': 'c'})



# Generated at 2022-06-11 00:53:44.988931
# Unit test for function is_iterable
def test_is_iterable():
    from ansible.module_utils.common._collections_compat import OrderedDict, Mapping, MutableSequence

    class Foo(Mapping):
        def __getitem__(self, item):
            return item

        def __iter__(self):
            return iter(('a', 'b'))

        def __len__(self):
            return 2

    class Bar(MutableSequence):
        def __getitem__(self, item):
            return 'abc'[item]

        def __setitem__(self, key, value):
            pass

        def __delitem__(self, key):
            pass

        def __len__(self):
            return 3

        def insert(self, key, value):
            pass

    f = Foo()
    b = Bar()

    assert is_iterable(f)

# Generated at 2022-06-11 00:53:55.880679
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'k1': 'v1', 'k2': 'v2'})
    d2 = ImmutableDict({'k2': 'v2', 'k1': 'v1'})
    assert d1 == d2

    d1 = ImmutableDict({'k1': 'v1', 'k2': 'v2'})
    d2 = ImmutableDict({'k2': 'v2'})
    assert not d1 == d2

    d1 = ImmutableDict({'k1': 'v1', 'k2': 'v2'})
    d2 = ImmutableDict({'k2': 'v2', 'k1': 'v12'})
    assert not d1 == d2


# Generated at 2022-06-11 00:54:04.304655
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d = ImmutableDict({"a": ["a"], "b": ["b"]})
    assert d == d
    assert d == ImmutableDict({"a": ["a"], "b": ["b"]})
    assert d == ImmutableDict({"b": ["b"], "a": ["a"]})
    assert not d == d.union({"c": ["c"]})
    assert not d == d.difference(["a"])
    assert not d == ImmutableDict({"c": ["c"]})
    assert not d == ImmutableDict({"a": ["b"]})
    assert not d == "something else"

# Generated at 2022-06-11 00:54:09.241232
# Unit test for function is_iterable
def test_is_iterable():
    """Unit test function is_iterable"""
    assert not is_iterable('hello')
    assert is_iterable(['hello', 'world'])
    assert is_iterable(set(['hello', 'world']))
    assert is_iterable(('hello', 'world'))
    assert is_iterable({'key1': 'hello', 'key2': 'world'})



# Generated at 2022-06-11 00:54:19.178459
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Unit test for method __eq__ of class ImmutableDict
    # Test the equal __eq__ method
    d = ImmutableDict(a=1,b=2,c=3)
    e = ImmutableDict(a=1,b=2,c=3)
    assert d == e

    # Test the unequal __eq__ method
    e = ImmutableDict(a=1,b=2,c=4)
    assert d != e

    # Test the unequal __eq__ method
    e = ImmutableDict(a=1,b=2)
    assert d != e

    # Test the equal __eq__ method of an ImmutableDict with a dict
    d = ImmutableDict(a=1,b=2,c=3)

# Generated at 2022-06-11 00:54:25.425203
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict(a=1, b=1)
    b = ImmutableDict(b=1, a=1)
    assert a == b

    assert a == dict(a=1, b=1)

    assert a != dict(a=1, b=2)

    assert ImmutableDict(a=1, b=1) in [dict(a=1, b=1)]
    assert dict(a=1, b=1) in [ImmutableDict(a=1, b=1)]


# Generated at 2022-06-11 00:54:36.352806
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Create some test objects
    a = ImmutableDict(a=1, b=2)
    b = ImmutableDict(a=1, b=2)
    c = ImmutableDict(b=2, a=1)
    d = ImmutableDict(a=1, b=3)
    e = ImmutableDict(a=1)
    f = ImmutableDict(a=1, b=2, c=3)
    g = ImmutableDict(m=1, n=2)
    h = "a string"
    # Test equality
    assert a == b
    assert a == c
    assert b == c
    # Test inequality
    assert not a == d
    assert not c == d
    assert not a == e
    assert not b == e
    assert not c == e

# Generated at 2022-06-11 00:54:47.411579
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]), \
        'List should be iterable'
    assert is_iterable(set([1, 2, 3])), \
        'Set should be iterable'
    assert is_iterable((1, 2, 3)), \
        'Tuple should be iterable'
    assert is_iterable({1, 2, 3}), \
        'Frozenset should be iterable'
    assert is_iterable({'one': 1, 'two': 2}), \
        'Dict should be iterable'

    assert is_iterable(1), \
        'Integer should not be iterable'
    assert not is_iterable(1.0), \
        'Float should not be iterable'

# Generated at 2022-06-11 00:54:57.375626
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # ImmutableDict with no items
    assert ImmutableDict() == ImmutableDict()
    # ImmutableDict with items
    d = ImmutableDict({'a': True, 'b': False})
    assert d == d
    assert d == ImmutableDict({'a': True, 'b': False})
    assert d != ImmutableDict({'a': True, 'b': True})
    assert d != ImmutableDict({'a': True})
    # ImmutableDict vs dict
    assert d == {'a': True, 'b': False}
    assert dict(d) == {'a': True, 'b': False}
    # ImmutableDict vs other types
    assert d != 'a'
    assert d != 1
    assert d != (1, 0, 2)

# Generated at 2022-06-11 00:56:05.346646
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(())
    assert is_iterable(frozenset())

    assert not is_iterable(None)
    assert not is_iterable(9)



# Generated at 2022-06-11 00:56:08.925828
# Unit test for function is_iterable
def test_is_iterable():
    """Unit tests for function is_iterable"""
    assert not is_iterable(None)
    assert not is_iterable('string')
    assert is_iterable(['list', 1, 2, 3])
    assert is_iterable(('tuple', 2, 3, 4))
    assert is_iterable({'key': 'dict'})

# Generated at 2022-06-11 00:56:19.384545
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    from ansible.module_utils.common._collections_compat import Mapping

    x = ImmutableDict({"a": 1, "b": 2, "c": 3})
    y = ImmutableDict({"a": 1, "b": 2, "c": 3})

    # same dict object
    assert x == x
    # dicts with same keys and values
    assert x == y
    # dicts with same keys and different values
    assert x != y.union({'a': 2})
    # dicts with different keys and values
    assert x != y.union({'d': 4})
    # dicts with different keys and values (order of keys the same)
    assert x != y.union({'d': 4, 'e': 5, 'f': 6})
    # dicts with different keys and values (order of keys

# Generated at 2022-06-11 00:56:29.570112
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Exercise the comparison function"""
    assert not ImmutableDict() == {'a': 3}
    assert ImmutableDict() == {}
    assert ImmutableDict(a=3, b=4) == {'a': 3, 'b': 4}
    assert ImmutableDict(a=3, b=4) == ImmutableDict(b=4, a=3)
    assert ImmutableDict(a=3, b=4) == {'b': 4, 'a': 3}
    assert ImmutableDict(a=3, b=4, c=1) == {'b': 4, 'a': 3, 'c': 1}

# Generated at 2022-06-11 00:56:34.395688
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})

    assert d1 == d2
    assert not d1 == {'a': 1, 'b': 2, 'c': 3}
    assert d1 == ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert not d1 == ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})


# Generated at 2022-06-11 00:56:42.896603
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test positive
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    assert dict1 == dict2, "Test failed: dict1 and dict2 should be equal"
    # Test negative
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict3 = ImmutableDict({'a': 1, 'b': 3})
    assert dict1 != dict3, "Test failed: dict1 and dict3 should not be equal"


# Generated at 2022-06-11 00:56:51.055110
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
        assert ImmutableDict({'a': 1, 'b': 2}) \
            == ImmutableDict({'b': 2, 'a': 1})
        assert not ImmutableDict({'a': 1, 'b': 2}) \
            == ImmutableDict({'a': 1, 'b': 3})
        assert not ImmutableDict({'a': 1, 'b': 2}) \
            == ImmutableDict({'a': 1})
        assert not ImmutableDict({'a': 1, 'b': 2}) \
            == object()


# Generated at 2022-06-11 00:56:53.708168
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_mapping = {'Name1': 'Value1', 'Name2': 'Value2'}
    immutable_dict = ImmutableDict(test_mapping)
    assert immutable_dict == test_mapping

# Generated at 2022-06-11 00:56:59.779921
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(dict(a=1))
    d2 = ImmutableDict(dict(a=1))
    d3 = ImmutableDict(dict(a=1, b=2))
    d4 = dict(a=1)

    assert d1 == d2
    assert d1 != d3
    assert d1 != d4
    assert d2 != d3
    assert d2 != d4
    assert d3 != d4



# Generated at 2022-06-11 00:57:10.938798
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """ unittest for method __eq__ of class ImmutableDict """
    test_a = ImmutableDict(dict(a=1, b=2, c=3))
    test_a_1 = test_a.union(dict(c=0))  # ImmutableDict({'a': 1, 'b': 2, 'c': 0})
    test_a_2 = test_a.union(dict(c=3))  # ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    test_a_3 = test_a.difference(('a',))  # ImmutableDict({'b': 2, 'c': 3})

    test_b = ImmutableDict(dict(a=1, b=2, c=3))
    test_b_1 = ImmutableDict