

# Generated at 2022-06-11 00:47:39.541773
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Verify __eq__ of ImmutableDict"""

# Generated at 2022-06-11 00:47:47.349300
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable(set()) is True
    assert is_iterable((1, 2, 3)) is True
    assert is_iterable('abr') is True
    assert is_iterable(b'abr') is True
    assert is_iterable(u'abr') is True
    assert is_iterable(None) is False
    assert is_iterable(1) is False
    assert is_iterable(dict()) is False
    assert is_iterable(is_iterable) is False


# Generated at 2022-06-11 00:47:54.881184
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(a=5, b=9, c=7)

    d2 = ImmutableDict(a=5, b=9, c=7)
    assert d1 == d2
    assert d1.__eq__(d2)

    d3 = ImmutableDict(a=5, b=9, c=7)
    assert d1 == d3
    assert d1.__eq__(d3)

    d4 = ImmutableDict(a=5, b=9, d=7)
    assert d1 != d4
    assert not d1.__eq__(d4)

    d5 = ImmutableDict(x=5, y=9, z=7)
    assert d1 != d5
    assert not d1.__eq__(d5)

    d6

# Generated at 2022-06-11 00:48:07.301089
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    test_ImmutableDict___eq__()

    Unit test for method __eq__ of class ImmutableDict
    """
    d1 = ImmutableDict()
    d2 = ImmutableDict()
    assert d1 == d2

    d1 = ImmutableDict({"key1": 1, "key2": 2})
    d2 = ImmutableDict({"key1": 1, "key2": 2})
    assert d1 == d2

    d1 = ImmutableDict({"key1": 1, "key2": 2})
    d2 = ImmutableDict({"key2": 2, "key1": 1})
    assert d1 == d2

    d1 = ImmutableDict({"key1": 1, "key2": 2})

# Generated at 2022-06-11 00:48:10.136254
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    first = ImmutableDict({"a": 1, "b": 2})
    second = ImmutableDict({"a": 1, "b": 2})
    third = ImmutableDict({"a": 1, "b": 3})
    assert first == second
    assert first != third
    assert first != [1, 2, 3]

# Unit tests for method union of class ImmutableDict

# Generated at 2022-06-11 00:48:18.156683
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality of two ImmutableDict with the same content
    d1 = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})
    d2 = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})
    assert d1 == d2

    # Test equality considering the order of elements
    d1 = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})
    d2 = ImmutableDict({1: 'one', 3: 'three', 2: 'two'})
    assert d1 == d2

    # Test equality of two ImmutableDict with different content
    d1 = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})

# Generated at 2022-06-11 00:48:30.512592
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Two empty ImmutableDicts are equal
    a = ImmutableDict()
    b = ImmutableDict()
    assert a == b

    # Two ImmutableDicts with the same contents are equal
    a = ImmutableDict({'abc': 123, 'xyz': 456})
    b = ImmutableDict({'xyz': 456, 'abc': 123})
    assert a == b

    # Two ImmutableDicts with different contents are not equal
    a = ImmutableDict({'abc': 123, 'xyz': 456})
    b = ImmutableDict({'abc': 123, 'xyz': 789})
    assert a != b

    # A ImmutableDict is equal to a dict with the same contents
    a = ImmutableDict({'abc': 123, 'xyz': 456})
    b

# Generated at 2022-06-11 00:48:34.280381
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    tests = [dict(), {1: 2}, ImmutableDict({1: 2})]
    for test_case in tests:
        assert ImmutableDict(test_case) == test_case



# Generated at 2022-06-11 00:48:42.405194
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():  # pylint: disable=invalid-name
    """Unit test for method ``__eq__`` of class ``ImmutableDict``."""

    # Check equality with list
    assert ImmutableDict() != []
    assert ImmutableDict(a=1) != [('a', 1)]

    # Check equality with dictionary
    assert ImmutableDict() == {}
    assert ImmutableDict(a=1) == {'a': 1}

    # Check equality with ImmutableDict
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict(a=1) == ImmutableDict(a=1)

# Generated at 2022-06-11 00:48:52.280211
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import pytest

    immutable_dict1 = ImmutableDict({"key1": "value"})
    immutable_dict2 = ImmutableDict({"key1": "value"})
    immutable_dict3 = ImmutableDict({"key2": "value"})
    immutable_dict4 = ImmutableDict({"key1": "value", "key2": "value"})
    immutable_dict5 = ImmutableDict({"key2": "value", "key1": "value"})
    immutable_dict6 = ImmutableDict({"key1": "value value"})

    assert immutable_dict1 == immutable_dict1
    assert immutable_dict1 == immutable_dict2
    assert immutable_dict3 == immutable_dict3
    assert immutable_dict4 == immutable_dict4
    assert immutable_dict5 == immutable_dict5

# Generated at 2022-06-11 00:49:06.957125
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict(value=["a", "b", 123])
    b = ImmutableDict(value=["a", "b", 123])
    c = ImmutableDict(value=["a", "b", 123])
    d = ImmutableDict(value=["c", "b", 123])
    e = ImmutableDict(value=["c", "b", 124])
    f = ImmutableDict(value=["c", "b", 124], other_value="y")

    assert a == a
    assert b == b
    assert c == c
    assert d == d
    assert e == e
    assert f == f

    # a and b contain the same info. But both are different objects. So this should return false.
    assert not a == b
    # a and c contain the same info. But both are

# Generated at 2022-06-11 00:49:18.591760
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    obj1 = ImmutableDict({'k1': 'v1', 'k2': 'v2'})
    obj2 = ImmutableDict({'k1': 'v1', 'k2': 'v2'})
    obj3 = ImmutableDict({'k1': 'v1', 'k2': 'v3'})
    obj4 = ImmutableDict({'k2': 'v2', 'k1': 'v1'})
    obj5 = ImmutableDict({'k1': 'v1', 'k2': 'v2', 'k3': 'v3'})
    obj6 = ImmutableDict({'k1': 'v1', 'k2': 'v2', 'k3': 'v3', 'k4': 'v4'})

# Generated at 2022-06-11 00:49:22.334653
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import pytest
    x = ImmutableDict(a=1, b=2)
    y = ImmutableDict(b=2, a=1)
    assert x == y
    # TODO: should not we also test that x != a_list and x != another_immutable_dict?

# Generated at 2022-06-11 00:49:30.412574
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert not ImmutableDict({'a': 1}) == ImmutableDict({'a': 1, 'b': 2})
    assert not ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1})
    assert not ImmutableDict({'a': 1}) == ImmutableDict({'a': 1, 'b': 2})
    assert not ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1})



# Generated at 2022-06-11 00:49:33.458995
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 'b', 'c'])
    assert not is_iterable('abc')
    assert not is_iterable(None)

# Generated at 2022-06-11 00:49:41.678106
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    mapping1 = ImmutableDict(one='1', two='2', three='3')
    mapping2 = ImmutableDict(three='3', two='2', one='1')
    mapping3 = ImmutableDict(one='4', two='5', three='6')
    dict1 = dict(one='1', two='2', three='3')
    dict2 = dict(three='3', two='2', one='1')
    dict3 = dict(one='4', two='5', three='6')
    assert mapping1 == mapping2
    assert not mapping1 == mapping3
    assert dict1 == dict2
    assert not dict1 == dict3
    assert mapping1 != dict1


# Generated at 2022-06-11 00:49:53.399078
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(tuple())
    assert is_iterable('str')
    assert is_iterable(set('str'))
    assert is_iterable((1,))
    assert is_iterable(zip(*[(1, 2, 3), (4, 5, 6)]))

    assert is_iterable(dict(one=1))
    assert is_iterable(dict(one=1).items())
    assert is_iterable(dict(one=1).values())
    assert is_iterable(dict(one=1).keys())

    assert not is_iterable(1)
    assert not is_iterable(0)
    assert not is_iterable(object())
    assert not is_

# Generated at 2022-06-11 00:49:58.795154
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable('test')
    assert not is_iterable('test', include_strings=False)
    assert is_iterable('test', include_strings=True)
    assert is_iterable(['test'])
    assert is_iterable(('test'))
    assert is_iterable(set(['test']))
    assert is_iterable(dict())



# Generated at 2022-06-11 00:50:07.023862
# Unit test for function is_iterable
def test_is_iterable():
    temp = MutableMapping()
    result = is_iterable(temp)
    assert result == True

    temp = []
    result = is_iterable(temp)
    assert result == True

    temp = "string"
    result = is_iterable(temp)
    assert result == False

    temp = "string"
    result = is_iterable(temp, True)
    assert result == True

    temp = u"string"
    result = is_iterable(temp, True)
    assert result == True

    temp = u"string"
    result = is_iterable(temp)
    assert result == False

    temp = b"string"
    result = is_iterable(temp, True)
    assert result == True

# Generated at 2022-06-11 00:50:11.282560
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1})
    b = ImmutableDict({'a': 1})
    assert a == b
    c = ImmutableDict({'b': 1})
    assert a != c
    assert not a == c



# Generated at 2022-06-11 00:50:29.037068
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    immutable_dict_1 = ImmutableDict({'a':1, 'b':2})
    immutable_dict_2 = ImmutableDict({'a':1, 'b':3})
    immutable_dict_3 = ImmutableDict({'a':1, 'b':2})
    immutable_dict_4 = ImmutableDict({'b':2, 'a':1})

    assert immutable_dict_1 == immutable_dict_3
    assert immutable_dict_1 == immutable_dict_4
    assert immutable_dict_3 == immutable_dict_4

    assert immutable_dict_1 != immutable_dict_2
    assert immutable_dict_2 != immutable_dict_3
    assert immutable_dict_2 != immutable_dict_4

    dict_1 = {'a':1, 'b':2}

# Generated at 2022-06-11 00:50:38.149032
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 == d1
    assert d1 == ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert d1 == {'a': 1, 'b': 2, 'c': 3}
    assert d1 != {'a': 1, 'b': 2}
    assert d1 != ImmutableDict({'a': 1, 'c': 2, 'c': 3})
    assert d1 != {'a': 1, 'c': 2, 'c': 3}
    assert d1 != ImmutableDict({'b': 1, 'c': 2, 'a': 3})
    assert d1 != {'b': 1, 'c': 2, 'a': 3}

# Generated at 2022-06-11 00:50:49.594162
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable(set()) is True
    assert is_iterable(('foo1', 5)) is True
    assert is_iterable(range(4)) is True
    assert is_iterable({1: 'foo', 2: 'bar'}) is True

    assert is_iterable('foo') is False
    assert is_iterable(b'foo') is False
    assert is_iterable(('foo', 'bar')) is False
    assert is_iterable(True) is False

    assert is_iterable(('foo', 'bar'), include_strings=True) is True
    assert is_iterable('foo', include_strings=True) is True
    assert is_iterable(b'foo', include_strings=True) is True



# Generated at 2022-06-11 00:50:54.553924
# Unit test for function is_iterable
def test_is_iterable():
    """Check if the is_iterable function works as expected."""
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 'b'})
    assert is_iterable(int())
    assert not is_iterable('asd')
    assert is_iterable('asd', include_strings=True)



# Generated at 2022-06-11 00:51:06.115352
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test noneqiality: different keys
    a = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})
    b = ImmutableDict({1: 'one', 2: 'two', 4: 'four'})
    assert a != b

    # Test noneqiality: same keys, different values
    a = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})
    b = ImmutableDict({1: 'one', 2: 'two', 3: 'threee'})
    assert a != b

    # Test eqiality: same keys, same values
    a = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})

# Generated at 2022-06-11 00:51:10.249931
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    id_1 = ImmutableDict(a=1)
    assert id_1 == ImmutableDict(a=1)
    assert id_1 != ImmutableDict(a=2)
    assert id_1 != ImmutableDict(a=1, b=1)


# Generated at 2022-06-11 00:51:20.848442
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    id1 = ImmutableDict(a=3, b=4)
    id2 = ImmutableDict(a=3, b=4)
    id3 = ImmutableDict(a=3, b=5)
    id4 = ImmutableDict(a=3, b=4)

    assert id1 == id2
    assert id1 == id1
    assert id2 == id2
    assert not (id1 == id3)
    assert not (id1 == id4)
    assert not (id1 == list())
    assert not (id1 == (1, 2, 3))
    assert not (id1 == [1, 2, 3])
    assert not (id1 == 'hello')


# Generated at 2022-06-11 00:51:28.982222
# Unit test for function is_iterable
def test_is_iterable():
    class noniterable:
        pass

    class iterable:
        def __iter__(self):
            yield

    # is_iterable used as a function
    assert is_iterable([])
    assert is_iterable((1, 2))
    assert is_iterable(iterable())
    assert is_iterable({})
    assert is_iterable({'a': 1})
    assert is_iterable(set())
    assert is_iterable(set([1, 2]))

    assert not is_iterable((i for i in range(10)))
    assert not is_iterable(1)
    assert not is_iterable(noniterable())

    # is_sequence used as a function
    assert is_sequence([])
    assert is_sequence((1, 2))


# Generated at 2022-06-11 00:51:36.371746
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    one = ImmutableDict(a=1, b=2)
    two = ImmutableDict(a=1, b=2)

    assert(one == two)
    assert(one == {"a": 1, "b": 2})
    assert(one == {"b": 2, "a": 1})
    assert(one != {"a": 2, "b": 1})
    assert(one != {"a": 1, "b": 2, "c": 3})



# Generated at 2022-06-11 00:51:43.368408
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable((), include_strings=True) is True
    assert is_iterable({}) is True
    assert is_iterable(set()) is True
    assert is_iterable(object()) is True
    assert is_iterable(object) is True
    assert is_iterable('abc') is True
    assert is_iterable('abc', include_strings=False) is False
    assert is_iterable(True) is False


# Generated at 2022-06-11 00:51:58.875038
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    lhs = ImmutableDict({'foo': 'bar'})
    rhs = ImmutableDict({'foo': 'bar'})
    assert (lhs == rhs)
    assert (lhs == {'foo': 'bar'})
    assert (lhs == {'foo': 'baz'} == False)

# Generated at 2022-06-11 00:52:05.699189
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable(range(5))
    assert is_iterable(set([8, 9, 0, 1]))
    assert is_iterable({'a': 3, 'b': 2})
    assert not is_iterable(["a", "b", "c"])
    assert not is_iterable("hello")


# Generated at 2022-06-11 00:52:11.556828
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import random
    for i in range(10000):
        test_dict = {}
        for j in range(random.randint(1,10)):
            test_dict[random.randint(0,100)] = random.randint(0,100)
        test_dict = ImmutableDict(test_dict)
        assert test_dict == ImmutableDict(test_dict)
        assert test_dict == dict(test_dict)
        assert test_dict != set(test_dict)
        assert test_dict != ImmutableDict(test_dict, **{random.randint(0,100):random.randint(0,100)})
        assert test_dict != dict(test_dict, **{random.randint(0,100):random.randint(0,100)})

# Generated at 2022-06-11 00:52:21.509392
# Unit test for function is_iterable
def test_is_iterable():
    class TestIterable(object):
        def __iter__(self):
            return iter([1, 2, 3, 4])

    class TestNonIterable(object):
        pass

    assert is_iterable(['foo', 'bar'])
    assert is_iterable({'foo': 'bar'})
    assert is_iterable(('foo', 'bar'))
    assert is_iterable(('foo', 'bar'))
    assert is_iterable(xrange(5))
    assert is_iterable(TestIterable())
    assert not is_iterable(None)
    assert not is_iterable(42)
    assert not is_iterable(TestNonIterable())
    assert not is_iterable("foo")
    assert not is_iterable(u"foo")

# Generated at 2022-06-11 00:52:32.033437
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert not ImmutableDict({'a': 1}) == {'a': 1, 'b': 2}
    assert not ImmutableDict({'a': 1, 'b': 2}) == {'a': 2}
    assert not ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}
    assert not ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 3}



# Generated at 2022-06-11 00:52:37.570612
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    key_val = {'key': 'value'}
    other_dict = {'key': 'value'}
    immut_dict = ImmutableDict(key_val)

    assert immut_dict.__eq__(other_dict) == True
    assert immut_dict.__eq__([]) == False
    assert immut_dict.__eq__(None) == False

# Generated at 2022-06-11 00:52:45.081251
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Tests ``ImmutableDict.__eq__`` method."""
    test = ImmutableDict({'a': 1, 'b': 2})
    # Test that it returns True of equal dictionaries
    assert test == ImmutableDict({'a': 1, 'b': 2})
    # Test that it returns False on equal dictionaries with the same keys, but different values
    assert test != ImmutableDict({'a': 1, 'b': 3})
    # Test that it returns False on equal dictionaries with the different keys
    assert test != ImmutableDict({'a': 1, 'c': 2})
    # Test that it returns False for regular dict
    assert test != {'a': 1, 'b': 2}
    # Test that it returns False for empty dict
    assert test != {'a': 1, 'b': 2}


# Generated at 2022-06-11 00:52:56.640400
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    id1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    id2 = ImmutableDict({'key2': 'value2', 'key1': 'value1'})
    assert id1 == id2
    id3 = ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    assert id1 != id3
    assert id1 != {'key1': 'value1', 'key2': 'value2'}
    assert id1 == {'key2': 'value2', 'key1': 'value1'}
    assert id1 != {'key1': 'value1'}

# Generated at 2022-06-11 00:53:05.864819
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ function of the ImmutableDict class.
    """
    test_dict_1 = ImmutableDict({'key_1': 'value_1', 'key_2': 'value_2'})
    test_dict_2 = ImmutableDict({'key_1': 'value_1', 'key_2': 'value_2'})
    test_dict_3 = ImmutableDict({'key_1': 'value_1', 'key_2': 'value_2', 'key_3': 'value_3'})
    test_dict_4 = ImmutableDict({'key_1': 'value_1'})
    test_dict_5 = ImmutableDict({'key_1': 'value_1', 'key_2': 'value_3'})

# Generated at 2022-06-11 00:53:08.503291
# Unit test for function is_iterable
def test_is_iterable():
    class NotAnIterable(object):
        pass
    obj = NotAnIterable()

    assert is_iterable(obj)



# Generated at 2022-06-11 00:53:41.383918
# Unit test for function is_iterable
def test_is_iterable():

    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(range(10))
    assert is_iterable(xrange(10))
    assert is_iterable(iter([1,2,3]))
    assert is_iterable(x for x in [1,2,3])
    assert is_iterable('hi')
    assert is_iterable(u'hi')
    assert is_iterable(b'hi')

    assert not is_iterable(None)
    assert not is_iterable(True)
    assert not is_iterable(False)

# Generated at 2022-06-11 00:53:47.161729
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1]) == True
    assert is_iterable(['string']) == True
    assert is_iterable((1, 2, 'string')) == True
    assert is_iterable({'name': 'Bruce'}) == True
    assert is_iterable(['a', 'b', 'c'].iterkeys()) == True
    assert is_iterable(42) == False


# Generated at 2022-06-11 00:53:50.781379
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test __eq__ method with another ImmutableDict
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d2 = ImmutableDict({'c': 3, 'b': 2, 'a': 1})
    assert d1 == d2
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d2 = ImmutableDict({'a': 1, 'b': 2, 'd': 4})
    assert not d1 == d2

    # Test __eq__ method with another dictionary
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d2 = {'c': 3, 'b': 2, 'a': 1}
    assert d1 == d2
    d1

# Generated at 2022-06-11 00:53:57.344179
# Unit test for function is_iterable
def test_is_iterable():
    test_obj = {"A":1,"B":2,"C":3}
    assert is_iterable(test_obj)

    test_obj = ["A","B","C"]
    assert is_iterable(test_obj)

    test_obj = ("A","B","C")
    assert is_iterable(test_obj)

    test_obj = "ABC"
    assert not is_iterable(test_obj)

    test_obj = 123
    assert not is_iterable(test_obj)



# Generated at 2022-06-11 00:54:07.967793
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) == {'a': 1}
    assert not ImmutableDict({'a': 1}) == ImmutableDict({'a': 2})
    assert not ImmutableDict({'a': 1}) == {'a': 2}
    assert not ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert not ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1, 'c': 3})


# Generated at 2022-06-11 00:54:12.390400
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1, 'b': 2})
    a_copy = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 3})

    assert a == a_copy
    assert a != b

# Generated at 2022-06-11 00:54:21.727493
# Unit test for function is_iterable
def test_is_iterable():

    assert(is_iterable([]) == True)
    assert(is_iterable([1, 2, 3]) == True)
    assert(is_iterable(()) == True)
    assert(is_iterable((1, 2, 3)) == True)
    assert(is_iterable({}) == True)
    assert(is_iterable({'a': 'b', 'c': 'd'}) == True)
    assert(is_iterable(set()) == True)
    assert(is_iterable(set('abc')) == True)
    assert(is_iterable(set([1, 2, 3, 4, 5])) == True)
    assert(is_iterable(12345) == False)
    assert(is_iterable('abcde') == True)

# Generated at 2022-06-11 00:54:26.883004
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    one = ImmutableDict({'foo': 'bar', 'baz': 'qux'})
    two = ImmutableDict({'baz': 'qux', 'foo': 'bar'})
    assert one == two, 'Equality for ImmutableDict does not work'
    assert one.__eq__(two), 'Equality for ImmutableDict does not work'


# Generated at 2022-06-11 00:54:31.862284
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('')
    assert is_iterable(None)
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(1)
    assert is_iterable(object)
    assert not is_iterable('')



# Generated at 2022-06-11 00:54:40.284782
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable((x for x in range(10)))
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable(ImmutableDict())
    assert is_iterable(1) is False
    assert is_iterable('a') is False
    assert is_iterable(u'a') is False
    assert is_iterable(b'a') is False
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable(('a', 'b', 'c'))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(ImmutableDict({'a': 1, 'b': 2}))
    assert is_iterable(set('abc'))

# Generated at 2022-06-11 00:55:30.607699
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({}) == ImmutableDict({})
    assert ImmutableDict({}) != {}
    assert ImmutableDict({'a': 'b'}) != ImmutableDict({'a': 'c'})
    assert ImmutableDict({'a': 'b'}) == ImmutableDict({'a': 'b'})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != 1
    assert ImmutableDict({'a': 1, 'b': 2}) != []

# Generated at 2022-06-11 00:55:40.954586
# Unit test for function is_iterable
def test_is_iterable():
    class TestObject(object):
        def __getitem__(self, item):
            return item
        def __contains__(self, item):
            return item
        def __iter__(self):
            return iter(range(10))

    test_instance = TestObject()
    assert is_iterable(test_instance)
    assert is_iterable(test_instance, True)
    assert is_iterable(range(10))
    assert is_iterable(range(10), True)
    assert is_iterable(dict())
    assert is_iterable(dict(), True)
    assert is_iterable(set())
    assert is_iterable(set(), True)
    assert is_iterable(frozenset())
    assert is_iterable(frozenset(), True)

# Generated at 2022-06-11 00:55:47.922956
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({'a': 2, 'b': 2})
    dict2 = ImmutableDict({'a': 2, 'b': 2})
    dict3 = ImmutableDict({'a': 1, 'b': 2})
    dict4 = ImmutableDict({'a': 2, 'b': 2, 'c': 3})
    dict5 = [0, 1, 2]
    dict6 = None

    assert dict1 == dict2
    assert dict1 != dict3
    assert dict1 != dict4
    assert dict1 != dict5
    assert dict1 != dict6


# Generated at 2022-06-11 00:55:58.264579
# Unit test for function is_iterable
def test_is_iterable():
    # Test a None
    assert not is_iterable(None)

    # Test a string
    assert is_iterable("Test string")

    # Test a number
    assert not is_iterable(123)

    # Test a list
    assert is_iterable([])

    # Test a list of list
    assert is_iterable([[]])

    # Test an ansible module argument dictionary
    assert is_iterable({})

    # Test a tuple of lists
    assert is_iterable(({}, []))

    # Test a class
    class TestClass:
        pass
    assert is_iterable(TestClass())

    # Test a class with __iter__ method
    class TestClassIterable:
        def __iter__(self):
            pass
    assert is_iterable(TestClassIterable())

    # Test a class

# Generated at 2022-06-11 00:56:07.918142
# Unit test for method __eq__ of class ImmutableDict

# Generated at 2022-06-11 00:56:16.779940
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(a=1, b=2, c=3, d=4)
    # Same order same result
    d2 = ImmutableDict(a=1, b=2, c=3, d=4)
    assert id(d1) != id(d2)
    assert d1 == d2
    assert d2.union(d1) == d2
    # Same order different result
    d3 = ImmutableDict(a=10, b=2, c=3, d=4)
    assert d1 != d3
    assert d2 != d3
    # Same result different order
    d4 = ImmutableDict(a=1, b=2, d=4, c=3)
    assert d1 == d4
    assert d2 == d4
    assert d3 != d

# Generated at 2022-06-11 00:56:28.306125
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict
       Test whether two ImmutableDicts are equal by comparing their content.
       Test whether two ImmutableDicts with different content are not equal.
       Test whether two ImmutableDicts with same content but different type are not equal.
    """
    first_dict = ImmutableDict({1: 'one', 2: 'two'})
    second_dict = ImmutableDict({1: 'one', 2: 'two'})
    assert first_dict == second_dict, "Test whether two ImmutableDicts with same content are equal"
    third_dict = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})
    assert first_dict != third_dict, "Test whether two ImmutableDicts with different content are not equal"
    second_dict2 = dict

# Generated at 2022-06-11 00:56:34.721526
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    _dict = ImmutableDict()
    assert(_dict == _dict)

    first = ImmutableDict()
    second = ImmutableDict()
    assert(first == second)

    first = ImmutableDict({'a': 'b'})
    second = ImmutableDict({'a': 'b'})
    assert(first == second)

    first = ImmutableDict({'a': 'b'})
    second = ImmutableDict({'a': 'c'})
    assert(first != second)

    first = ImmutableDict({'a': 'b'})
    second = ImmutableDict({'a': 'b', 'c': 'd'})
    assert(first != second)

# Generated at 2022-06-11 00:56:42.249063
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable((1,2,3))
    assert is_iterable({'a': 1, 'b': 2, 'c': 3})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(xrange(10))
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert not is_iterable(object())



# Generated at 2022-06-11 00:56:48.943962
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a=ImmutableDict(a=1)
    a1=ImmutableDict(a=1)
    b=ImmutableDict(a=2)
    c=ImmutableDict(a=1,b=3)
    d=ImmutableDict()
    d1=ImmutableDict()
    
    assert a==a1
    assert a!=b
    assert a!=c
    assert d==d1