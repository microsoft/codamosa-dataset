

# Generated at 2022-06-11 00:47:43.532594
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    foo = ImmutableDict({'foo': 'bar'})
    bar = ImmutableDict({'foo': 'bar', 'baz': 'qux'})

    assert foo == bar.difference(['baz'])



# Generated at 2022-06-11 00:47:47.996002
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('abc')
    assert is_iterable([1, 2, 3])
    assert is_iterable({1, 2, 3})
    assert is_iterable({'a': 1, 'b': 2})

    assert not is_iterable(None)
    assert not is_iterable(1)



# Generated at 2022-06-11 00:47:58.195017
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # comparing with a regular dict
    fred = ImmutableDict(barney=30, lily=32, betty=37)
    wilma = {'barney': 30, 'lily': 32, 'betty': 37}
    assert fred == wilma

    # comparing with a regular list
    assert not fred == ['barney', 'lily', 'betty']

    # comparing with a regular string
    assert not fred == 'barney, lily, betty'

    # comparing with a regular tuple
    assert not fred == ('barney', 'lily', 'betty')

    # comparing with another ImmutableDict
    fred = ImmutableDict(barney=30, lily=32, betty=37)

# Generated at 2022-06-11 00:48:10.480401
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    iDict1 = ImmutableDict({'a': 1})
    assert iDict1.difference('a') == ImmutableDict()
    assert iDict1.difference(['a']) == ImmutableDict()
    assert iDict1.difference({'a': 1}) == ImmutableDict()
    assert iDict1.difference(ImmutableDict({'a': 1})) == ImmutableDict()
    iDict2 = ImmutableDict({'a': 1, 'b': 5})
    assert iDict2.difference('b') == ImmutableDict({'a': 1})
    assert iDict2.difference(['b']) == ImmutableDict({'a': 1})
    assert iDict2.difference({'b': 5}) == ImmutableDict

# Generated at 2022-06-11 00:48:19.201900
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'ansible': 'cool'}) == ImmutableDict({'ansible': 'cool'})
    assert ImmutableDict({'ansible': 'cool'}) == ImmutableDict({'ansible': 'cool', 'python': 'awesome'})
    assert ImmutableDict({'ansible': 'cool', 'python': 'awesome'}) == ImmutableDict({'ansible': 'cool'})
    assert ImmutableDict({'ansible': 'cool'}) == {'ansible': 'cool'}
    assert ImmutableDict({'ansible': 'cool'}) == ImmutableDict({'ansible': 'cool'})
    assert not ImmutableDict({'ansible': 'cool'}) == ImmutableDict({'ansible': 'not cool'})
    assert not ImmutableDict

# Generated at 2022-06-11 00:48:31.445639
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import pytest
    a = ImmutableDict({"a": "b"})
    b = ImmutableDict({"a": "b"})
    assert a == b
    a = ImmutableDict({"a": "b"})
    b = ImmutableDict({"a": "c"})
    assert a != b
    a = ImmutableDict({"a": "b"})
    b = ImmutableDict({"a": "b", "c": "d"})
    assert a != b
    a = ImmutableDict({"a": "b", "c": "d"})
    b = ImmutableDict({"a": "b"})
    assert a != b
    a = ImmutableDict({"a": "b"})
    b = ImmutableDict()
    assert a != b

# Generated at 2022-06-11 00:48:42.267950
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    from copy import deepcopy

    m = {'a': [1, 2, 3], 'b': {1, 2}, 'c': 'c'}
    im = ImmutableDict(m)

    # test that difference functions with a list
    diff_list = ['a', 'c']
    assert im.difference(diff_list) == ImmutableDict({'b': m['b']}), 'difference method of ImmutableDict failed when subtracting with a list'

    # test that difference functions with a dict
    diff_dict = {'b': m['b']}
    assert im.difference(diff_dict) == ImmutableDict({'a': m['a'], 'c': m['c']}), 'difference method of ImmutableDict failed when subtracting with a dict'

    # test that difference functions with a

# Generated at 2022-06-11 00:48:52.056894
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    b = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    c = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    d = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    e = {'a': 1, 'b': 2, 'c': 3}
    f = ['a', 'b', 'c']
    g = {'a': 1, 'b': 2, 'c': 4}
    assert a == a
    assert a == b
    assert a == d
    assert a != c
    assert a != e
    assert a != f
    assert a != g

# Generated at 2022-06-11 00:49:04.828082
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # Different objects
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({'a': 1, 'b': 2}, c=3) == ImmutableDict({'a': 1, 'b': 2}, c=3)
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2}, c=3)
    # Test for issue #7

# Generated at 2022-06-11 00:49:14.735052
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Unit test for method difference of class ImmutableDict
    """
    original = ImmutableDict(
        {
            'strawberry': 'red',
            'cherry': 'red',
            'blackberry': 'black',
            'banana': 'yellow',
            'peach': 'orange'
        }
    )
    subtracted = ImmutableDict({'cherry': 'red', 'banana': 'yellow'})

    difference = original.difference(subtracted)

    expected = ImmutableDict({'strawberry': 'red', 'blackberry': 'black', 'banana': 'yellow'})

    assert(difference == expected)


# Generated at 2022-06-11 00:49:22.081388
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('abc')
    assert is_iterable(['a'])
    assert is_iterable(set(['a']))
    assert is_iterable(('a',))
    assert is_iterable({'a': 1})
    assert is_iterable(b'abc')
    assert is_iterable(False) is False
    assert is_iterable(1) is False


# Generated at 2022-06-11 00:49:32.586602
# Unit test for function is_iterable
def test_is_iterable():

    # is_iterable('string') should return True
    assert is_iterable('string') is True

    # is_iterable('string', include_strings=False) should return False
    assert is_iterable('string', include_strings=False) is False

    # is_iterable(1) should return False
    assert is_iterable(1) is False

    # is_iterable([1]) should return True
    assert is_iterable([1]) is True

    # is_iterable(set([1])) should return True
    assert is_iterable(set([1])) is True

    # is_iterable(frozenset([1])) should return True
    assert is_iterable(frozenset([1])) is True


# Generated at 2022-06-11 00:49:38.120158
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({'a':1, 'b':2})
    dict2 = ImmutableDict({'a':1, 'b':2})
    dict3 = ImmutableDict({'a':1, 'b':3})
    dict4 = dict({'b':2, 'a':1})

    assert dict1 == dict2
    assert not dict1 == dict3
    assert not dict1 == dict4

# Generated at 2022-06-11 00:49:41.536937
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable('test')
    assert is_iterable(b'test')
    assert not is_iterable(42)
    assert not is_iterable(None)



# Generated at 2022-06-11 00:49:48.257318
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable('test')
    assert is_iterable(u'test')
    assert is_iterable((1, 2, 3))
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable(True)
    assert not is_iterable(test_is_iterable)


# Generated at 2022-06-11 00:49:56.980569
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    _dict = ImmutableDict({'a':1, 'b':2, 'c':3})
    assert _dict.__eq__({'a':1, 'b':2, 'c':3}) == True
    assert _dict.__eq__({'a':4, 'b':2, 'c':3}) == False
    assert _dict.__eq__(ImmutableDict({'a':1, 'b':2, 'c':3})) == True
    assert _dict.__eq__(ImmutableDict({'a':4, 'b':2, 'c':3})) == False


# Generated at 2022-06-11 00:50:06.240157
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # True cases
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({'x': 'y'}) == ImmutableDict({'x': 'y'})
    assert ImmutableDict({'x': 'y'}) == ImmutableDict({'x': 'y', 'a': 'b'})
    assert ImmutableDict({'x': 'y'}) == ImmutableDict({'a': 'b', 'x': 'y'})
    assert ImmutableDict({'x': 'y', 'a': 'b'}) == ImmutableDict({'a': 'b', 'x': 'y'})
    # False cases
    assert not (ImmutableDict({'x': 'y'}) == ImmutableDict({'a': 'b'}))

# Generated at 2022-06-11 00:50:16.852372
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test ImmutableDict.__eq__()
    """
    i_d1 = ImmutableDict({'name': 'Alice', 'score': 100})
    i_d2 = ImmutableDict({'name': 'Alice', 'score': 100})
    i_d3 = ImmutableDict({'name': 'Bob',   'score': 100})
    i_d4 = ImmutableDict({'name': 'Alice', 'score':  99})

    assert i_d1 == i_d1
    assert i_d1 == i_d2
    assert not i_d1 == i_d3
    assert not i_d1 == i_d4
    assert i_d1 == {'name': 'Alice', 'score': 100}

# Generated at 2022-06-11 00:50:29.374031
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    def test_case(first, second, expected):
        sut = ImmutableDict(first)
        got = (sut == second)
        assert got == expected, 'Expected: {}, got: {}'.format(expected, got)
    # Success
    first = {"a": 1, "b": 2}
    second = {"a": 1, "b": 2}
    test_case(first, second, True)
    # Success
    first = {"a": 1, "b": 2}
    second = {"a": 1, "b": 2, "c": 3}
    test_case(first, second, False)
    # Success
    first = {"a": 1, "b": 2}
    second = {"a": 2, "b": 1}
    test_case(first, second, False)

# Unit test

# Generated at 2022-06-11 00:50:37.567291
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a':1})
    # Same dictionary - should be equal
    assert a==a, "Should be equal"
    # Copy of the same dictionary - should be equal
    b = ImmutableDict({'a':1})
    assert a==b, "Should be equal"
    # A different dictionary - should not be equal
    b = ImmutableDict({'a':2})
    assert a!=b, "Should NOT be equal"
    # An immutable copy of a different dictionary - should not be equal
    b = ImmutableDict({'a':2})
    c = ImmutableDict(b)
    assert c!=b, "Should NOT be equal"



# Generated at 2022-06-11 00:50:51.024735
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Unit test for method ImmutableDict.__eq__()
    """
    # At creation
    id1 = ImmutableDict([('key1', 'value1'), ('key2', 'value2')])
    id2 = ImmutableDict([('key1', 'value1'), ('key2', 'value2')])
    id3 = ImmutableDict([('key1', 'value1')])
    result = id1 == id2
    assert result == True
    result = id1 == id3
    assert result == False
    result = id3 == id2
    assert result == False

    # After union of id1
    id2 = id1.union({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    result = id1 == id2
    assert result

# Generated at 2022-06-11 00:50:56.185968
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict()
    assert a == {}
    a = ImmutableDict({1: 1})
    assert a == {1: 1}
    b = ImmutableDict({2: 2})
    assert not (a == b)
    a = ImmutableDict({2: 2})
    assert a == b
    d = ImmutableDict({1: 1, 2: 2})
    assert d == {1: 1, 2: 2}


# Generated at 2022-06-11 00:51:06.555450
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1, 'b': 'f', 'c': 5})
    d2 = ImmutableDict({'a': 1, 'b': 'f', 'c': 5})
    d3 = ImmutableDict({'a': 1, 'b': 'f'})

    assert d1 == d2
    assert d1 != d3
    assert d2 != d3

    assert d1 != {'a': 1, 'b': 'f', 'c': 5}
    assert d2 != {'a': 1, 'b': 'f', 'c': 5}
    assert d3 != {'a': 1, 'b': 'f'}



# Generated at 2022-06-11 00:51:18.271255
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test for very basic equality for variables of different type
    dict1 = ImmutableDict({1: 'A'})
    dict2 = ImmutableDict({2: 'B'})
    dict3 = ImmutableDict({3: 'C'})
    dict4 = ImmutableDict({1: 'A'})
    dict5 = ImmutableDict({})
    dict6 = ImmutableDict({})
    dict7 = {}

    assert dict1 != dict2
    assert dict1 != dict3
    assert dict2 != dict3
    assert dict1 != dict4
    assert dict5 != dict6
    assert dict5 != dict7
    assert dict6 != dict7

    # Test basic equality
    dict1 = ImmutableDict({'A': 'B'})

# Generated at 2022-06-11 00:51:27.741736
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    with open("tests/unit/module_utils/network/common/utils/test_ImmutableDict___eq__.txt", 'w') as f:
        def print(*args, **kwargs):
            kwargs['file'] = f
            __builtins__.print(*args, **kwargs)

        assert ImmutableDict()['a'] == ImmutableDict()['a']
        assert ImmutableDict() == ImmutableDict()
        assert ImmutableDict()['a'] == {'a': 1}
        assert ImmutableDict(a=1) == {'a': 1}

        assert ImmutableDict(a=1, b=2, c=3) == ImmutableDict(a=1, b=2, c=3)

# Generated at 2022-06-11 00:51:32.827340
# Unit test for function is_iterable
def test_is_iterable():
    class NotIterable():
        pass
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable((1, 2, 3)) is True
    assert is_iterable(set((1, 2, 3))) is True
    assert is_iterable(NotIterable()) is False

# Generated at 2022-06-11 00:51:44.278186
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable('abc', include_strings=True)
    assert is_iterable('abc') is False
    assert is_iterable(())
    assert is_iterable(set())
    assert is_iterable(set('abc'))
    assert is_iterable((i for i in range(3)))
    assert is_iterable(range(3))
    assert is_iterable({'a': 1})
    assert is_iterable({'a': 1}.values())
    assert is_iterable({'a': 1}.items())
    assert is_iterable(1) is False
    assert is_iterable(None) is False
    assert not is_iterable(None, include_strings=True)


# Generated at 2022-06-11 00:51:52.296138
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    given = ImmutableDict({'foo': 1, 'bar': 2})
    test_datas = [
        (True, ImmutableDict({'foo': 1, 'bar': 2})),
        (False, ImmutableDict({'foo': 2, 'bar': 2})),
        (False, ImmutableDict({'foo': 1, 'bar': 3})),
        (True, given.union({'bar': 2})),
        (False, given.union({'bar': 3}))
    ]
    all_passed = True
    for expected_result, cmp_to in test_datas:
        result = (given == cmp_to)

# Generated at 2022-06-11 00:52:02.652993
# Unit test for function is_iterable
def test_is_iterable():
    # test class used in testing is_iterable
    class TestClass(object):
        def __init__(self):
            self.variable = 'test'
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable('string')
    assert not is_iterable(['a', 'b', 3])
    assert is_iterable(['a', 'b', 3], include_strings=True)
    assert is_iterable(set())
    assert is_iterable(dict())
    assert not is_iterable(TestClass())
    assert is_iterable(TestClass().__dict__)



# Generated at 2022-06-11 00:52:13.016593
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=2, b=4) == ImmutableDict(a=2, b=4)
    assert ImmutableDict(a=2, b=4) != ImmutableDict()
    assert ImmutableDict(a=2, b=4) != ImmutableDict(a=0, b=4)
    assert ImmutableDict(a=2, b=4) != ImmutableDict(a=2, b=0)
    assert ImmutableDict(a=2, b=4) != ImmutableDict(a=2, b=4, c=0)
    assert ImmutableDict(a=2, b=4) != ImmutableDict(a=2, c=0)

# Generated at 2022-06-11 00:52:38.066436
# Unit test for function is_iterable
def test_is_iterable():
    """Test the is_iterable function

    The test suite expects that strings, bytes, and bytesarray would not be considered iterable
    unless explicitly given include_strings=True.
    """
    string_examples = ['a string', b'string of bytes']
    bytes_examples = [b'byte string', bytearray(b'a bytesarray')]
    iterable_examples = [[], (), [1, 2, 3], (1, 2, 3), {}, {1: 2, 3: 4}, range(10), 'not a string']

    for seq in string_examples:
        assert not is_iterable(seq)
        assert is_iterable(seq, True)

    for seq in bytes_examples:
        assert not is_iterable(seq)
        assert is_iterable(seq, True)

   

# Generated at 2022-06-11 00:52:44.702833
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable((x for x in range(100))) is True
    assert is_iterable({}) is True
    assert is_iterable(ImmutableDict({})) is True
    assert is_iterable(MutableMapping({})) is True
    assert is_iterable(set()) is True

    assert is_iterable(None) is False
    assert is_iterable(1) is False
    assert is_iterable(1.2) is False

    assert is_iterable('a') is False
    assert is_iterable('abcd') is False
    assert is_iterable(b'abcd') is False



# Generated at 2022-06-11 00:52:56.390950
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import _assertCountEqual

    for _ in range(10):
        d = dict((str(i), i) for i in range(10))
        d['d'] = ImmutableDict(d)
        d[b'd'] = ImmutableDict(d)
        d['a'] = StrObj(d['a'])
        e = ImmutableDict(d)

        # equal itself
        assert e == e
        # equal to immutable version of itself
        assert e == dict(e)
        # equal to mutable version of itself
        assert e == dict(d)
        # equal to immutable version of itself with bytes keys

# Generated at 2022-06-11 00:53:05.675129
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Unit tests for method __eq__ of class ImmutableDict.
    """
    # Test different format of keys (int and string)
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({1: 'a', 2: 'b'})
    dict3 = ImmutableDict({1: 'c', 2: 'b'})
    dict4 = ImmutableDict({1: 'c', 2: 'b'})
    # Test __eq__
    assert dict1 == dict2
    assert dict1 != dict3
    assert dict3 == dict4
    # Test __hash__
    assert dict1.__hash__() == dict2.__hash__()
    assert dict3.__hash__() == dict4.__hash__()
    assert dict1.__hash

# Generated at 2022-06-11 00:53:12.254374
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({'a':'b', 'c':'d'})
    dict2 = ImmutableDict({'a':'b', 'c':'d'})
    dict3 = ImmutableDict({'a':'b', 'c':'d', 'e':'f'})
    assert hash(dict1) == hash(dict2)

    assert dict1 == dict2
    assert dict1 != dict3

# Generated at 2022-06-11 00:53:17.309601
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable('string')
    assert is_iterable(['string'])
    assert not is_iterable('string', include_strings=False)
    assert not is_iterable(None)
    assert is_iterable({})
    assert is_iterable(1)


# Generated at 2022-06-11 00:53:26.705895
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Check equality when object is same
    d1 = ImmutableDict({'k1': 'v1', 'k2': 'v2', 'k3': 'v3'})
    assert d1 == d1
    # Check equality when keys and values are same but in different order
    d2 = ImmutableDict({'k1': 'v1', 'k3': 'v3', 'k2': 'v2'})
    assert d1 == d2
    # Check equality when hashes are different
    d3 = ImmutableDict({'k4': 'v4', 'k2': 'v2'})
    assert d1 != d3


# Generated at 2022-06-11 00:53:35.964350
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(1, include_strings=False) == False
    assert is_iterable(1, include_strings=True) == False
    assert is_iterable('1', include_strings=False) == True
    assert is_iterable('1', include_strings=True) == True
    assert is_iterable(['1'], include_strings=False) == True
    assert is_iterable(['1'], include_strings=True) == True
    assert is_iterable(iter('1'), include_strings=False) == True
    assert is_iterable(iter('1'), include_strings=True) == True
    assert is_iterable(dict()) == True
    assert is_iterable(MutableMapping()) == True
    assert is_iterable(ImmutableDict()) == True


# Generated at 2022-06-11 00:53:46.496181
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 0})

# Generated at 2022-06-11 00:53:57.009754
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(range(10))
    assert is_iterable([]), 'Empty list is not iterable'
    assert not is_iterable(10), 'Number is not iterable'
    assert is_iterable(['a', 'b']), 'List is iterable'
    assert is_iterable({'a':1, 'b':2}), 'Dictionary is iterable'

    # string-like objects are not iterable
    assert not is_iterable('abc')
    assert not is_iterable(b'abc')
    assert not is_iterable('abc', include_strings=True)
    assert not is_iterable(b'abc', include_strings=True)
    assert is_iterable(u'abc')
    assert is_iterable(u'abc', include_strings=True)

# Generated at 2022-06-11 00:54:29.952490
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable([1, 2, 3])
    assert is_iterable(text_type())
    assert is_iterable(xrange(1, 10))
    assert is_iterable(binary_type())
    assert not is_iterable(1)



# Generated at 2022-06-11 00:54:37.272065
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable((x for x in range(0)))
    assert is_iterable(1) is False
    assert is_iterable('1') is False
    assert is_iterable('1', include_strings=True)
    assert is_iterable(u'1') is False
    assert is_iterable(u'1', include_strings=True)
    assert is_iterable(1, include_strings=True) is False



# Generated at 2022-06-11 00:54:48.611390
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Two empty ImmutableDict objects must be equal
    assert ImmutableDict() == ImmutableDict()

    immutable_dict1 = ImmutableDict({'a': 1, 'b': 2})
    immutable_dict2 = ImmutableDict({'b': 2, 'a': 1})
    immutable_dict3 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})

    assert immutable_dict1 == immutable_dict1
    assert immutable_dict1 == immutable_dict2
    assert immutable_dict1 != immutable_dict3
    assert immutable_dict2 != immutable_dict3

    # ImmutableDict has to return false also for non-ImmutableDict objects
    assert immutable_dict1 != {'a': 1, 'b': 2}
    assert immutable_dict1 != [1, 2]
   

# Generated at 2022-06-11 00:54:54.851121
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(1)
    assert is_iterable('test')
    assert is_iterable(u'test')
    assert is_iterable(set([1, 2]))
    assert is_iterable(set((1, 2)))
    assert is_iterable(dict(foo='bar'))
    assert is_iterable(range(0, 4))
    assert not is_iterable(None)


# Generated at 2022-06-11 00:54:59.965661
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test overriding equality method."""
    data_dict = ImmutableDict(a=1)
    assert data_dict == data_dict
    assert not (data_dict != data_dict)
    other_dict = ImmutableDict(a=1)
    assert data_dict == other_dict
    assert not (data_dict != other_dict)
    other_dict = ImmutableDict(a=2)
    assert not (data_dict == other_dict)
    assert data_dict != other_dict
    assert data_dict != list()

# Generated at 2022-06-11 00:55:10.364584
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    # Testing equality of 2 ImmutableDicts with the same content
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict(dict1)
    assert dict1 == dict2
    assert not (dict1 != dict2)

    # Testing equality of 2 ImmutableDicts with the same content, in a different order
    dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict2 = ImmutableDict({'c': 3, 'a': 1, 'b': 2})
    assert dict1 == dict2
    assert not (dict1 != dict2)

    # Testing inequality of 2 ImmutableDicts with the same content, but different keys
    dict1 = ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-11 00:55:15.474059
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable((x for x in range(2)))
    assert is_iterable({'1': 1})
    assert is_iterable('string')
    assert is_iterable(u'unicode')
    assert is_iterable(b'bytes')



# Generated at 2022-06-11 00:55:22.149776
# Unit test for function is_iterable
def test_is_iterable():
    # Test non sequence types
    assert is_iterable("something") is True
    assert is_iterable(1) is True
    assert is_iterable({1, 2, 3}) is True

    # Test non iterable types
    assert is_iterable("something", include_strings=False) is False
    assert is_iterable(1, include_strings=False) is False
    assert is_iterable({1, 2, 3}, include_strings=False) is True



# Generated at 2022-06-11 00:55:29.767150
# Unit test for function is_iterable
def test_is_iterable():
    # test for is_iterable
    test_iterable = [{}, (), [], set()]
    for test in test_iterable:
        assert is_iterable(test)
        assert isinstance(test, Iterable)

    test_iterable_string = [{}, '', [], set()]
    for test in test_iterable_string:
        assert is_iterable(test, include_strings=True)

    test_uniterable = [None, True, False, 0, 1, 1.0]
    for test in test_uniterable:
        assert not is_iterable(test)
        assert not is_iterable(test, include_strings=True)


# Generated at 2022-06-11 00:55:40.357505
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(5))
    assert is_iterable(xrange(5))
    assert is_iterable(iter(range(5)))
    assert not is_iterable(1)
    assert not is_iterable(1.1)
    assert not is_iterable('str')
    assert not is_iterable(b'bytes')
    assert not is_iterable(u'unicode')
    assert is_iterable('str', include_strings=True)
    assert is_iterable(b'bytes', include_strings=True)
    assert is_iterable(u'unicode', include_strings=True)

# Generated at 2022-06-11 00:56:51.056850
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test different type comparison
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 != 'string', 'When comparing with a string, __eq__ method should return False'
    assert not d1 == 'string', 'When comparing with a string, __eq__ method should return False'

    # Test with different keys
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'b': 2, 'a': 1})
    assert d1 == d2, 'When comparing with two dictionaries with the same keys and values, __eq__ method should return True'

    # Test with different keys and values
    d1 = ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-11 00:56:58.047509
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test method __eq__
    """
    # Creating the first ImmutableDict
    s1 = ImmutableDict(first=3, second="str", third=None)
    # Creating the second ImmutableDict
    s2 = ImmutableDict(first=3, second="str", third=None)
    # Creating the third ImmutableDict
    s3 = ImmutableDict(first=3, second="str", third="None")
    # Creating the fourth ImmutableDict
    s4 = ImmutableDict(first=3, second="str", third=None, four=4)
    assert (s1 == s2)
    assert not (s1 == s3)
    assert not (s1 == s4)
    assert not (s1 == None)

# Generated at 2022-06-11 00:57:08.755369
# Unit test for function is_iterable
def test_is_iterable():
    class NonIterable():
        pass

    class Iterable():
        def __iter__(self):
            pass

    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(Iterable())
    assert not is_iterable(NonIterable())
    assert not is_iterable(1)
    assert not is_iterable(1.1)
    assert not is_iterable(u'unicode')
    assert not is_iterable(b'bytes')
    assert is_iterable([], include_strings=True)
    assert not is_iterable({}, include_strings=True)
    assert is_iterable(Iterable(), include_strings=True)
    assert not is_iterable(NonIterable(), include_strings=True)

# Generated at 2022-06-11 00:57:17.898151
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    data1 = {1:2, 3:4, 5:6}
    data2 = {3:4, 1:2, 5:6}
    data3 = {3:4, 5:6, 1:2}
    data4 = {3:5, 1:2, 5:6}
    data5 = {3:5, 1:2, 5:6, 'hello': 'world'}
    data6 = {3:5, 1:2, 5:7, 'hello': 'world'}
    data7 = {3:5, 1:2, 5:7, 'hello': 'world1'}
    data8 = {3:5, 1:2, 5:7, 'hello': 'world1', 'hi': 'there'}

    di1 = ImmutableDict(data1)
    di2 = Immutable

# Generated at 2022-06-11 00:57:27.091218
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('abcd')
    assert not is_iterable('abcd', include_strings=False)
    assert is_iterable(u'abcd')
    assert not is_iterable(u'abcd', include_strings=False)
    assert is_iterable(b'abcd')
    assert not is_iterable(b'abcd', include_strings=False)
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable(('a', 'b', 'c'))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable(set(['a', 'b', 'c']))



# Generated at 2022-06-11 00:57:38.018054
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test the __eq__ method of ImmutableDict

    :return: True if all tests pass.
    """
    a = ImmutableDict(a=1, b=2, c=3)

    # Test equality
    assert a == a

    # Test inequality
    assert a != 1
    assert a != ImmutableDict(a=1, b=2, c=3, d=4)
    assert a != ImmutableDict(a=1, b=3, c=3)
    assert a != ImmutableDict(a=1, b=2, c=4)
    assert a != ImmutableDict(a=2, b=2, c=3)
    assert a != ImmutableDict(b=2, c=3)