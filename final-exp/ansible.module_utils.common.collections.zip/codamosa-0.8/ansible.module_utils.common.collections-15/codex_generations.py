

# Generated at 2022-06-11 00:47:48.041185
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}).difference(['a', 'b']) == ImmutableDict({'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}).difference(['a']) == ImmutableDict({'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}).difference(['f']) == ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}).difference(['a', 'e']) == ImmutableDict({'b': 2, 'c': 3})


# Generated at 2022-06-11 00:47:58.244308
# Unit test for function is_iterable
def test_is_iterable():
    class Foo(object):
        def __iter__(self):  # dummy __iter__ method doesn't actually do anything, just needs to exist
            pass

    class Bar(object):
        pass

    foo = Foo()
    bar = Bar()

    assert is_iterable(foo), "Failed to identify custom object with __iter__() as iterable."
    assert is_iterable('foo'), "Failed to identify string as iterable."
    assert not is_iterable('foo', include_strings=False), "Incorrectly identified string as iterable."
    assert is_iterable(('foo', 'bar', 'baz')), "Failed to identify tuple as iterable."
    assert not is_iterable(('foo', 'bar', 'baz'), include_strings=False), "Incorrectly identified tuple as iterable."
    assert is_

# Generated at 2022-06-11 00:48:10.525808
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():

    od = ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4'})
    assert od.difference(('key1','key3')) == ImmutableDict({'key2': 'value2', 'key4': 'value4'})

    # test that ImmutableDict works with sets
    assert od.difference({'key1', 'key3'}) == ImmutableDict({'key2': 'value2', 'key4': 'value4'})

    # test that ImmutableDict works when subtractive_iterable is empty
    assert od.difference([]) == od
    assert od.difference('') == od
    assert od.difference(set()) == od

    # test that ImmutableDict works when subtractive_

# Generated at 2022-06-11 00:48:19.229269
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Test to ensure the method returns the expected dictionary

    Return a dict with all of the items in dict1 which are not in dict2.
    """
    assert (ImmutableDict({'a': 'x', 'b': 'y', 'c': 'z'}).difference(['b', 'c'])) == ImmutableDict({'a': 'x'})
    assert (ImmutableDict({'a': 'x', 'b': 'y', 'c': 'z'}).difference([])) == ImmutableDict({'a': 'x', 'b': 'y', 'c': 'z'})

# Generated at 2022-06-11 00:48:31.445002
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test normal operation
    idict0 = ImmutableDict({'a': 0, 'b': 1})
    idict1 = ImmutableDict({'a': 0, 'b': 1})
    idict2 = ImmutableDict({'a': 0})
    assert idict0 == idict1 and idict0 != idict2
    # Allowing other type of mapping with the same content
    idict3 = {'a': 0, 'b': 1}
    assert idict0 == idict3
    # Proper handling of unhashable content
    idict4 = ImmutableDict({0:[], 1:{}})
    idict5 = ImmutableDict({0:[], 1:{}})
    assert idict4 == idict5
    # Proper handling of non-immutable-dict keys
    idict6 = ImmutableD

# Generated at 2022-06-11 00:48:36.385011
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    expected = ImmutableDict({'foo': 'bar'})
    original = ImmutableDict({'foo': 'bar', 'baz': 'qux'})
    output = original.difference(['baz'])
    assert (expected == output)


# Generated at 2022-06-11 00:48:45.076275
# Unit test for function is_iterable
def test_is_iterable():
    """Test function is_iterable"""
    # Default case
    # Input does not have __iter__
    assert is_iterable(1) is False
    assert is_iterable('a') is False
    # Input is iterable
    assert is_iterable([1, 2]) is True
    assert is_iterable({1: 2}) is True
    assert is_iterable(set([1, 2, 3])) is True
    assert is_iterable((1, 2)) is True
    # Input is string
    assert is_iterable('abc') is False
    assert is_iterable(u'abc') is False
    # Include strings case
    # Input is string
    assert is_iterable('abc', include_strings=True) is True
    assert is_iterable(u'abc', include_strings=True) is True


# Generated at 2022-06-11 00:48:54.983709
# Unit test for function is_iterable
def test_is_iterable():
    # Test cases that is_iterable should return True
    true_test_cases = (
        (list, [1]),
        (list, ('a', 1, 2)),
        (dict, {1: 'one', 2: 'two'}),
        (tuple, (1, 2, 3)),
        (set, {'a', 'b', 'c'}),
    )
    # Test cases that is_iterable should return False
    false_test_cases = (
        (str, ""),
        (str, "Hello, World!"),
        (str, "大熊猫"),
        (int, 1),
        (float, 1.1),
        (float, 1.0),
        (bool, True),
        (bool, False),
        (type(None), None)
    )

   

# Generated at 2022-06-11 00:49:07.059741
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """Create an ImmutableDict and make sure the difference method works."""

    # Create an ImmutableDict
    original = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert len(original) == 3

    # Test that it allows creation of a new ImmutableDict
    override = {'a': 5, 'd': 4}
    combined = original.union(override)
    assert len(combined) == 4
    assert combined.get('a') == 5
    assert combined.get('b') == 2
    assert combined.get('c') == 3
    assert combined.get('d') == 4

    # Test that creation of a new ImmutableDict doesn't change original
    assert len(original) == 3
    assert original.get('a') == 1

# Generated at 2022-06-11 00:49:18.692240
# Unit test for function is_iterable
def test_is_iterable():
    # This method is used to test the is_iterable function
    # example using the is_iterable function for strings
    test_string = 'test'
    assert is_iterable(test_string) == True
    assert is_iterable(test_string, include_strings=True) == True
    assert is_iterable(test_string, include_strings=False) == False
    # example using the is_iterable function for list
    test_list = [1,2,3]
    assert is_iterable(test_list) == True
    # example using the is_iterable function for tuple
    test_tuple = (1,2,3)
    assert is_iterable(test_tuple) == True
    # example using the is_iterable function for set
    test_set = {1,2,3}


# Generated at 2022-06-11 00:49:28.666179
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(((1, 2), (3, 4))).__eq__(ImmutableDict(((1, 2), (3, 4))))
    assert not ImmutableDict(((1, 2), (3, 4))).__eq__(ImmutableDict(((1, 2), (3, 5))))
    assert not ImmutableDict(((1, 2), (3, 4))).__eq__(None)


# Generated at 2022-06-11 00:49:33.355322
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict(a = 1, b = 2)
    dict2 = ImmutableDict(b = 2, a = 1)
    dict3 = ImmutableDict(a = 1, b = 2, c = 3)

    assert dict1 == dict2
    assert dict1 != dict3

# Generated at 2022-06-11 00:49:38.075539
# Unit test for function is_iterable
def test_is_iterable():
    """Test for function is_iterable"""
    assert is_iterable([])
    assert not is_iterable(1)
    assert is_iterable(xrange(10))
    assert is_iterable({'a': 2})
    assert not is_iterable('abc')
    assert not is_iterable(b'abc')



# Generated at 2022-06-11 00:49:47.168861
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dictionaries = [
        dict(a=1, b=2, c=3),
        dict(a=1, c=3, b=2),
        dict(b=2, c=3, a=1),
        dict(b=2, a=1, c=3),
        dict(c=3, b=2, a=1),
        dict(c=3, a=1, b=2),
    ]
    # convert dictionaries to ImmutableDicts
    immutable_dicts = [ImmutableDict(d) for d in dictionaries]
    # check the fact that all ImmutableDicts are equal
    # (which is expected according to the __eq__ method implementation)
    for i in immutable_dicts:
        for j in immutable_dicts:
            assert(i == j)

# Unit test

# Generated at 2022-06-11 00:49:56.328530
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(None) is False
    assert is_iterable(set()) is True
    assert is_iterable(dict()) is True
    assert is_iterable(text_type()) is True
    assert is_iterable(binary_type()) is True
    assert is_iterable(123) is False
    assert is_iterable(text_type('abc')) is True
    assert is_iterable(binary_type('abc')) is True
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable((1, 2, 3)) is True



# Generated at 2022-06-11 00:50:05.724605
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({'key':'value'}) == ImmutableDict({'key':'value'})
    assert ImmutableDict({'key':'value'}) == ImmutableDict(key='value')
    assert not (ImmutableDict() == ImmutableDict({'key':'value'}))
    assert not (ImmutableDict({'key': 'value'}) == ImmutableDict())
    assert not (ImmutableDict({'key': 'value'}) == ImmutableDict({'key': 'value1'}))
    assert not (ImmutableDict({'key': 'value'}) == ImmutableDict({'key1': 'value'}))
    assert not (ImmutableDict({'key': 'value'}) == 'value')

# Generated at 2022-06-11 00:50:16.623913
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    '''
    Ensure that ImmutableDict class behaves as expected by verifying:
    1. ImmutableDict objects are always equal to themselves
    2. ImmutableDict objects are always equal to each other, as long as they contain the same elements
    3. ImmutableDict objects are never equal to objects of other types, such as Hashable, Sequence and MutableMapping
    '''
    # test 1

# Generated at 2022-06-11 00:50:19.551388
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert not is_iterable(4)
    assert not is_iterable("this is a string")
    assert is_iterable("this is a string", include_strings=True)
    assert is_iterable(ImmutableDict())


# Generated at 2022-06-11 00:50:32.024582
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    '''
    This test will behave as following :
    test_ImmutableDict___eq__ checks for equality using __eq__ method when any of the following is true :
    1. Both ImmutableDict instances have the same hash value
    2. Both ImmutableDict instances have different hash values but the underlying dictionaries are equal
    It will fail when both ImmutableDict instances have different hash values and underlying dictionaries are unequal
    '''
    # Hashable Keys
    initial_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    other_dict = ImmutableDict({'b': 2, 'c': 3, 'a': 1})
    unequal_dict = ImmutableDict({'b': 2, 'c': 4, 'a': 1})

# Generated at 2022-06-11 00:50:39.479531
# Unit test for function is_iterable
def test_is_iterable():
    iter_string = 'asdf'
    non_iter_string = 'asdf'
    iter_list = [1, 2, 3]
    non_iter_int = 1
    iter_tuple = (1, 2, 3)
    iter_dict = dict()
    iter_dict[1] = 'a'

    assert is_iterable(iter_string) == True
    assert is_iterable(iter_list) == True
    assert is_iterable(iter_tuple) == True
    assert is_iterable(iter_dict) == True
    assert is_iterable(non_iter_int) == False
    assert is_iterable(non_iter_string) == False
    assert is_iterable(iter_string, include_strings=True) == True

# Generated at 2022-06-11 00:50:51.500461
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(set())
    assert is_iterable(range(0))
    assert is_iterable(ImmutableDict())

    assert not is_iterable(1)
    assert not is_iterable(object())

    # AnsibleVaultEncryptedUnicode will be treated as an iterable
    from ansible.parsing.vault import VaultLib
    assert is_iterable(VaultLib().encrypt(u'example'))

# Generated at 2022-06-11 00:50:58.683566
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({3: 'three', 1: 'one', 2: 'two', 5: 'five'})
    d2 = ImmutableDict({1: 'one', 3: 'three', 4: 'four', 5: 'five'})
    assert d1 != d2   # Hashes are different
    d3 = ImmutableDict({3: 'three', 1: 'one', 2: 'two', 5: 'five'})
    d4 = ImmutableDict({1: 'one', 3: 'three', 4: 'four', 5: 'five', 2: 'two'})
    assert d3 == d4
    d5 = ImmutableDict({1: 'one', 3: 'three', 'four': 4, 5: 'five', 2: 'two'})
    assert d3 != d5   # d3 has

# Generated at 2022-06-11 00:51:01.648119
# Unit test for function is_iterable
def test_is_iterable():
    def f():
        yield 1

    assert is_iterable(f())
    assert not is_iterable(None)
    assert not is_iterable(False)



# Generated at 2022-06-11 00:51:09.035912
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable(('a', 'b', 'c'))
    assert is_iterable(set(('a', 'b', 'c')))
    assert is_iterable({'a': 1, 'b': 2, 'c': 3})
    assert is_iterable('abc')
    assert not is_iterable('a')
    assert not is_iterable(100)
    assert not is_iterable(100.1)



# Generated at 2022-06-11 00:51:20.899501
# Unit test for function is_iterable
def test_is_iterable():
    class NonIterable:

        def __nonzero__(self):
            return True

    assert is_iterable(NonIterable())
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable(set(['a', 'b', 'c']))
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(iter(['a', 'b', 'c']))

    class NonIterableSequence(object):
        def __len__(self):
            return 3

    class NonIterableMapping(object):
        def __len__(self):
            return 3

        def __getitem__(self, k):
            return k


# Generated at 2022-06-11 00:51:29.007665
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import pytest
    # Test self.__hash__() == hash(other)
    id1 = ImmutableDict({'a': 'b'})
    id2 = ImmutableDict({'a': 'b'})
    id3 = ImmutableDict({'c': 'd'})
    assert id1 == id2
    assert id1 != id3
    id4 = ImmutableDict({'a': 'b', 'c': 'd'})
    assert id1 != id4
    id5 = ImmutableDict({'a': 'b', 'c': 'd', 'e': 'f'})
    assert id4 != id5
    assert id1 != 'a'

    # Test self.__hash__() != hash(other)
    id6 = id1.union({'e': 'f'})
    assert id

# Generated at 2022-06-11 00:51:31.038059
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1, b=2) == ImmutableDict(b=2, a=1)

# Generated at 2022-06-11 00:51:42.559826
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({1: 2}) == ImmutableDict({1: 2})
    assert ImmutableDict({1: 2, 2: 3}) == ImmutableDict({1: 2, 2: 3})

    assert not ImmutableDict({1: 2}) == ImmutableDict({1: 3})
    assert not ImmutableDict({1: 2, 2: 3}) == ImmutableDict({1: 2, 2: 4})

    assert not ImmutableDict({1: 2}) == ImmutableDict({1: 2, 2: 3})

    assert not ImmutableDict({1: 2}) == ImmutableDict({1: 2, 2: 3}, {1: 2, 2: 3})

    assert ImmutableDict({1: 2}) == {1: 2}

# Generated at 2022-06-11 00:51:50.579135
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(None)
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable('abc')
    assert not is_iterable(1, include_strings=True)
    assert is_iterable([], include_strings=True)
    assert is_iterable([1, 2, 3], include_strings=True)
    assert is_iterable(set(), include_strings=True)
    assert is_iterable({}, include_strings=True)
    assert is_iterable('abc', include_strings=True)


# Generated at 2022-06-11 00:51:59.500496
# Unit test for function is_iterable
def test_is_iterable():
    """Unit test for function is_iterable."""
    assert is_iterable('foobar')
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2, 'c': 3})
    assert not is_iterable(dict())
    assert not is_iterable(set())
    assert not is_iterable(3)
    assert not is_iterable(3.0)
    assert not is_iterable(None)



# Generated at 2022-06-11 00:52:19.628881
# Unit test for function is_iterable
def test_is_iterable():  # pragma: no cover
    # is_iterable detects strings as iterables
    assert is_iterable("foo")
    assert is_iterable("")

    # is_iterable detects all containers that are iterable as iterables
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(Hashable([]))
    assert is_iterable(ImmutableDict())

    # Non-container types are not iterable
    assert not is_iterable(1)
    assert not is_iterable(0.0)
    assert not is_iterable(None)



# Generated at 2022-06-11 00:52:27.382776
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    original_dict = ImmutableDict({'a': 1})
    equivalent_dict = {'a': 1}
    equivalent_dict_immutable = ImmutableDict({'a': 1})
    different_dict = {'a': 1, 'b': None}
    non_dict = (1, 2)
    assert (original_dict == equivalent_dict)
    assert (original_dict == equivalent_dict_immutable)
    assert (not original_dict == different_dict)
    assert (not original_dict == non_dict)



# Generated at 2022-06-11 00:52:38.657820
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    class Foo:
        pass

    dict_1 = ImmutableDict({'key_1': 'value_1', 'key_2': 'value_2'})
    dict_2 = ImmutableDict({'key_1': 'value_1', 'key_2': 'value_2'})
    dict_3 = ImmutableDict({'key_1': 'value_1', 'key_2': 'value_3'})
    dict_4 = ImmutableDict({'key_1': 'value_1', 'key_2': 'value_2'}, key_3='value_3')
    dict_5 = ImmutableDict({'key_1': 'value_1', 'key_2': 'value_2'})
    dict_5.__hash__ = None

    assert dict_1 == dict_1

# Generated at 2022-06-11 00:52:47.320515
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a':1})
    b = ImmutableDict({'b':2})
    c = ImmutableDict({'a':1})
    d = ImmutableDict()
    e = ImmutableDict({'c':1})
    f = ImmutableDict({'a':2})
    assert a == c
    assert a != b
    assert b != c
    assert a != d
    assert d == {}
    assert a != {}
    assert d != a
    assert c != f
    assert f != c
    assert e != f
    assert e != c
    assert e != a
    assert e != b

# Generated at 2022-06-11 00:52:57.404906
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert not is_iterable(1)
    assert not is_iterable(None)
    assert not is_iterable(object())
    assert not is_iterable(object())
    assert isinstance(object(), object)
    assert not is_iterable(tuple())
    assert not is_iterable(list())
    assert is_iterable(set())
    assert is_iterable(dict())
    assert not is_iterable(str())
    assert not is_iterable(b'')
    assert is_iterable(set('abc'))



# Generated at 2022-06-11 00:53:06.274832
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Testing the behaviour of ImmutableDict.__eq__ with two ImmutableDict objects
    d1 = ImmutableDict({'one': 1, 'two': 2})
    d2 = ImmutableDict({'one': 1, 'two': 2})
    d3 = ImmutableDict({'one': 1, 'two': 3})
    assert d1 == d2
    assert d1 != d3
    # Testing the behaviour of ImmutableDict.__eq__ with an ImmutableDict and a dict
    assert d1 == {'one': 1, 'two': 2}
    assert d1 != {'one': 1, 'two': 3}
    # Testing the behaviour of ImmutableDict.__eq__ with an ImmutableDict and anything else
    assert d1 != 'one'



# Generated at 2022-06-11 00:53:15.304962
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict(a=1, b=2, c=3)
    b = ImmutableDict(a=1, b=2, c=3)
    c = ImmutableDict(a=1, b=2, c=4)
    d = ImmutableDict(a=1, b=2)
    e = {'a': 1, 'b': 2, 'c': 3}
    assert a == b
    assert a == e
    assert a != c
    assert a != d
    assert a != e
    assert type(a) != type(e)


# Generated at 2022-06-11 00:53:26.706951
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable([1, 2, 3], include_strings=True) is True
    assert is_iterable((1, 2, 3)) is True
    assert is_iterable((1, 2, 3), include_strings=True) is True
    assert is_iterable({'a': 1, 'b': 2}) is True
    assert is_iterable({'a': 1, 'b': 2}, include_strings=True) is True
    assert is_iterable(ImmutableDict({'a': 1, 'b': 2})) is True
    assert is_iterable(ImmutableDict({'a': 1, 'b': 2}), include_strings=True) is True
    assert is_iterable("abc") is False

# Generated at 2022-06-11 00:53:36.057794
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # must use an ImmutableDict to test ImmutableDict
    test_dict = ImmutableDict({'a': 'A', 'b': 'B', 'c': 'C'})

    # test with dict
    dict_equal = {'a': 'A', 'b': 'B', 'c': 'C'}
    dict_not_equal = {'a': 'A', 'b': 'B', 'c': 'C', 'd': 'D'}
    assert test_dict.__eq__(dict_equal) is True
    assert test_dict.__eq__(dict_not_equal) is False

    # test with ImmutableDict
    immutable_dict_equal = ImmutableDict({'a': 'A', 'b': 'B', 'c': 'C'})
    immutable_dict_not_equal = Imm

# Generated at 2022-06-11 00:53:39.655305
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""

    #test 1
    test_dict = ImmutableDict({1:2, 3:4})
    eq_dict = ImmutableDict({3:4, 1:2})
    non_eq_dict = ImmutableDict({1:2, 3:5})
    non_eq_dict2 = ImmutableDict({1:2, 3:5, 5:7})
    assert test_dict == eq_dict
    assert test_dict != non_eq_dict
    assert test_dict != non_eq_dict2

    #test 2
    test_dict2 = ImmutableDict({'a':'b', 'c':'d'})
    eq_dict2 = ImmutableDict({'c':'d', 'a':'b'})
    non

# Generated at 2022-06-11 00:54:14.253864
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Same keys and values
    expected = ImmutableDict({"key0": "value0", "key1": "value1"})
    actual = ImmutableDict({"key0": "value0", "key1": "value1"})
    assert expected == actual, "Expected equal ImmutableDicts to be equal"

    # Same keys, different values
    expected = ImmutableDict({"key0": "value0", "key1": "value1"})
    actual = ImmutableDict({"key0": "value2", "key1": "value3"})
    assert expected != actual, "Expected different ImmutableDicts to be different"

    # Equal mapping and sequence
    mapping_obj = {"key0": "value0"}
    expected = ImmutableDict(mapping_obj)
    actual = ImmutableDict

# Generated at 2022-06-11 00:54:17.121674
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert not is_iterable(1)
    assert not is_iterable('string')
    assert not is_iterable(u'string')



# Generated at 2022-06-11 00:54:20.563572
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(dict())
    assert not is_iterable(None)
    assert is_iterable(count({'a': 1}))
    assert is_iterable('string')
    assert not is_iterable(u'unicode string')


# Generated at 2022-06-11 00:54:27.605332
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable({'a': 1, 'b': 2}) == True
    assert is_iterable('abc') == False
    assert is_iterable('abc', True) == True
    assert is_iterable(1) == False
    assert is_iterable(None) == False
    assert is_iterable(['1', '2', 3]) == True
    assert is_iterable([]) == True


# Generated at 2022-06-11 00:54:37.864473
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)
    assert not ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=3)  # different value
    assert not ImmutableDict(a=1, b=2) == ImmutableDict(a=1, c=2)  # different key
    assert not ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2, c=3)  # different number of elements
    assert not ImmutableDict(a=1, b=2) == ImmutableDict(a=1)  # different number of elements

# Generated at 2022-06-11 00:54:49.380302
# Unit test for function is_iterable
def test_is_iterable():
    strings = ('a', u'a')
    first_iterables = (range(0), (1, 2), set(), dict())
    second_iterables = (range(0), set())
    non_iterables = ('a', 1, 1.1, None)
    for seq in strings:
        assert not is_iterable(seq)
        assert is_iterable(seq, include_strings=True)
    for seq in first_iterables:
        assert is_iterable(seq)
        assert is_iterable(seq, include_strings=True)
    for seq in second_iterables:
        assert is_iterable(seq)
        assert is_iterable(seq, include_strings=True)
    for seq in non_iterables:
        assert not is_iterable(seq)

# Generated at 2022-06-11 00:54:58.864793
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    print('Running test_ImmutableDict___eq__')
    # Test case 1:
    # This is the most important test case that should catch most of the bugs.
    # The purpose of this test case is to verify that __eq__ is reflexive
    # i.e. x == y if and only if y == x
    # This should hold true for any two objects x and y

    t = ImmutableDict({1:1, 2:2})
    assert (t == t)

    # Test case 2:
    # Verify that __eq__ on ImmutableDicts is symmetric
    # i.e. x == y if and only if y == x
    # This should hold true for any two objects x and y
    t1 = ImmutableDict({1:1, 2:2})

# Generated at 2022-06-11 00:55:09.014405
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_in = dict(x=1, y=2, z=3)

    # Test __eq__ on ImmutableDict instances
    dict1 = ImmutableDict(dict_in)
    dict2 = ImmutableDict(dict_in)
    assert dict1 == dict2
    assert not (dict1 != dict2)

    # Make sure ImmutableDict are not equal to other types
    assert not (dict1 == dict_in)
    assert dict1 != dict_in
    assert not (dict1 == [])
    assert dict1 != []

    # Test unhashable elements
    list1 = [1]
    list2 = [2]
    dict3 = ImmutableDict(a=list1)
    dict4 = ImmutableDict(a=list2)
    assert not (dict3 == dict4)
   

# Generated at 2022-06-11 00:55:20.320784
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test that ImmutableDict's can be compared to other ImmutableDicts with no TypeError
    assert ImmutableDict({'a':1, 'b':2}) == ImmutableDict({'a':1, 'b':2})
    # Test that ImmutableDict's can be compared to Mappings and dictionaries with no TypeError
    assert ImmutableDict({'a':1, 'b':2}) == {'a':1, 'b':2}
    # Test that ImmutableDicts can be compared to other iterable types with TypeError
    try:
        ImmutableDict({'a':1, 'b':2}) == [1,2]
    except TypeError:
        pass
    else:
        assert False, 'Comparing ImmutableDict to list caused no Exception'

# Generated at 2022-06-11 00:55:29.302965
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    # Test cases for checking that ImmutableDict works with a custom class that supports hashing
    class Custom():
        def __init__(self, name):
            self.name = name
        def __eq__(self, other):
            return self.name == other.name
        def __hash__(self):
            return hash(self.name)
        def __repr__(self):
            return self.name

    class CustomWithString():
        def __init__(self, name):
            self.name = name
        def __eq__(self, other):
            return self.name == other.name
        def __hash__(self):
            return hash(self.name)
        def __repr__(self):
            return self.name
        def __str__(self):
            return self.name


# Generated at 2022-06-11 00:56:31.622096
# Unit test for function is_iterable
def test_is_iterable():
    # Try is_iterable with strings and bytes
    assert is_iterable('test') is True
    assert is_iterable(b'test') is True

    # Try is_iterable with custom objects
    class TestCls(object):
        def __iter__(self):
            pass
    test_class = TestCls()
    assert is_iterable(test_class) is True

    # Try is_iterable with sequences
    test_sequence_types = [
        [],
        (),
        set(),
        frozenset(),
        dict(),
        ImmutableDict()
    ]
    for sequence in test_sequence_types:
        assert is_iterable(sequence) is True

    # Try is_iterable with non-iterable things

# Generated at 2022-06-11 00:56:37.256648
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Unit test for method __eq__ of class ImmutableDict.
    Tests __eq__ between ImmutableDict and itself.
    """
    d1 = ImmutableDict({"a": 1, "b": 2})
    d2 = ImmutableDict({"a": 1, "b": 2})
    assert d1 == d2
    d3 = ImmutableDict({"a": 1, "b": 3})
    assert d1 != d3

# Generated at 2022-06-11 00:56:48.499288
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable(set()) is True
    assert is_iterable(()) is True
    assert is_iterable({}) is True
    assert is_iterable('abc') is False
    assert is_iterable(b'abc') is False
    assert is_iterable(range(3)) is True

    assert is_iterable(['abc']) is True
    assert is_iterable(['abc'], include_strings=True) is True

    assert is_iterable(('abc',)) is True
    assert is_iterable(('abc',), include_strings=True) is True

    assert is_iterable({'abc': '123'}) is True
    assert is_iterable({'abc': '123'}, include_strings=True) is True


# Generated at 2022-06-11 00:56:56.709248
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(xrange(10 ** 4))
    assert is_iterable(xrange(10 ** 4), include_strings=True)
    assert is_iterable(iter([]))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(tuple()))
    assert is_iterable(iter(dict()))
    assert is_iterable('random_string_sequence')

    # Valid iterables:
    for iterable in [[], (), {}, set(), xrange(10 ** 4), iter([]), iter(set()), iter(tuple()), iter(dict())]:
        assert is_iterable(iterable)

# Generated at 2022-06-11 00:57:07.414810
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict([(1, 2), (2, 3)])
    b = ImmutableDict([(1, 2), (2, 3)])
    assert a == b
    assert ImmutableDict([(1, 2), (2, 3)]) == ImmutableDict([(2, 3), (1, 2)])
    assert ImmutableDict([(1, 2), (2, 3)]) == ImmutableDict([(1, 7), (2, 3)])
    assert ImmutableDict([(1, 2), (2, 3)]) == {1: 2, 2: 3}
    assert not ImmutableDict([(1, 2), (2, 3)]) == {1: 3, 2: 3}

# Generated at 2022-06-11 00:57:14.933125
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    try:
        x = ImmutableDict({'k1': 'v1'})
        y = ImmutableDict({'k1': 'v1'})
        assert x == y
        assert not x == 'y'

        x = ImmutableDict({'k1': 'v1'})
        y = ImmutableDict({'k1': 'v1', 'k2': 'v2'})
        assert not x == y
    except AssertionError:
        print("Test for method __eq__ of class ImmutableDict failed")


# Generated at 2022-06-11 00:57:24.879199
# Unit test for function is_iterable
def test_is_iterable():
    class Custom(object):
        def __iter__(self):
            return iter([])

    class CustomSequence(object):
        def __getitem__(self, key):
            return object()

    class CustomMapping(object):
        def __getitem__(self, key):
            return object()

        def __iter__(self):
            return iter([])

    class CustomSequenceAndMapping(object):
        def __getitem__(self, key):
            return object()

        def __iter__(self):
            return iter([])

        def __len__(self):
            return 1

    assert is_iterable('str')
    assert is_iterable(u'unicode')
    assert is_iterable(b'bytes')

# Generated at 2022-06-11 00:57:31.148882
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dictA = ImmutableDict({'a': 1, 'b': 2})
    dictB = ImmutableDict({'a': 2, 'b': 1})
    dictC = dict({'a': 1, 'b': 2})
    dictD = {'a': 1, 'b': 2}
    assert dictA == dictA
    assert dictA != dictB
    assert dictA != dictC
    assert dictA != dictD

# Generated at 2022-06-11 00:57:40.343867
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # __eq__
    # 1. when __hash__ of the other object is equal to the __hash__ of the current object
    # 2. when __hash__ of the other object is not equal to the __hash__ of the current object (in which case it returns False)
    # 3. when the other object is not a hashable object(in which case it returns False)
    # 4. when the current object is not a hashable object(in which case it raises TypeError)
    # 5. when the other object is not a mapping object(in which case it returns False)

    # Test case: 1
    immutable_dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})