

# Generated at 2022-06-11 00:47:46.882502
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    assert equality for two ImmutableDict objects having same elements
    assert equality for two ImmutableDict objects having different elements
    """
    first_immutable_dict = ImmutableDict({'foo': 'bar'})
    # same as first_immutable_dict
    second_immutable_dict = ImmutableDict({'foo': 'bar'})

    # different from first_immutable_dict
    third_immutable_dict = ImmutableDict({'foo': 'bar', 'baz': 'qux'})

    assert first_immutable_dict == second_immutable_dict
    assert first_immutable_dict != third_immutable_dict


# Generated at 2022-06-11 00:47:54.604310
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    Verify that ImmutableDict.difference() returns expected result
    """
    test_cases = [
        {
            'name': '1',
            'id': 1,
            'result': {
                'name': '1',
                'id': 1
            },
            'subtractive_seq': ['id']
        },
        {
            'name': '2',
            'id': 2,
            'result': {},
            'subtractive_seq': ['name', 'id']
        },
        {
            'result': {},
            'subtractive_seq': []
        }
    ]

    for test in test_cases:
        # create dict from test data
        test_immutable_dict = ImmutableDict(test)
        # remove keys from subtractive_seq
        test_

# Generated at 2022-06-11 00:48:06.986068
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """
    >>> test_ImmutableDict_difference()
    """
    data = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert data.difference(['a']) == ImmutableDict({'b': 2, 'c': 3})
    assert data.difference(['a', 'b']) == ImmutableDict({'c': 3})
    assert data.difference(['a', 'b', 'c']) == ImmutableDict({})
    assert data.difference(['b', 'c']) == ImmutableDict({'a': 1})
    assert data.difference(['a', 'b', 'c', 'd']) == ImmutableDict({})

# Generated at 2022-06-11 00:48:13.798388
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    a = ImmutableDict(dict(a=1, b=2, c=3))
    assert a.difference(['b', 'c']) == dict(a=1)
    assert a.difference(['a', 'c']) == dict(b=2)
    assert a.difference(['a', 'b']) == dict(c=3)
    assert a.difference(['a', 'b', 'c']) == dict()


# Generated at 2022-06-11 00:48:20.845161
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Immutable Dictionaries are equal if they have the same set of keys
    # and the same values for each key
    a = ImmutableDict({"a": 1, "b": 2})
    b = ImmutableDict({"a": 1, "b": 2})
    assert a == b

    c = ImmutableDict({"a": 1, "b": 3})
    assert c != a

    d = ImmutableDict({"a": 1, "b": 2, "c": 3})
    assert d != a

# Generated at 2022-06-11 00:48:30.185001
# Unit test for function is_iterable
def test_is_iterable():
    """
    Test function to test if is_iterable works as expected
    """
    assert is_iterable('string')
    assert is_iterable(u'unicode string')
    assert is_iterable(b'byte string')
    assert is_iterable([1, 2, 3])
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable({'a': 'A', 'b': 'B'})
    assert not is_iterable(1234)
    assert not is_iterable(2.34)
    assert not is_iterable(complex(1, 2))

# Generated at 2022-06-11 00:48:41.330009
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    try:
        assert ImmutableDict() == ImmutableDict()
    except AssertionError:
        raise Exception('TEST FAILED: ImmutableDict() should be equal to ImmutableDict()')

    try:
        assert ImmutableDict() == {ImmutableDict(): 'awesome'}
    except AssertionError:
        raise Exception('TEST FAILED: ImmutableDict() should be equal to {ImmutableDict(): \'awesome\'}')

    try:
        assert ImmutableDict() == [()]
    except AssertionError:
        raise Exception('TEST FAILED: ImmutableDict() should be equal to [()]')


# Generated at 2022-06-11 00:48:50.714435
# Unit test for function is_iterable
def test_is_iterable():
    # Test if types are iterable
    assert is_iterable([])
    assert is_iterable([1])
    assert is_iterable((1, 2))
    assert is_iterable({'a': 1})
    # Test if types are string like
    assert is_string('b')
    assert is_string('a')
    assert is_string(u'a')
    assert is_string(u'b')
    # Test if types are not string like
    assert not is_string(1)
    assert not is_string({'a': 1})
    assert not is_string([1])
    assert not is_string((1,))
    assert not is_string(None)
    # Test if types are not iterable
    assert not is_iterable(None)
    assert not is_iterable('a')
   

# Generated at 2022-06-11 00:48:54.939659
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable({1, 2, 3})
    assert is_iterable({'one': 1, 'two': 2})
    assert not is_iterable(1)
    assert not is_iterable(object())
    assert is_iterable(None)


# Generated at 2022-06-11 00:49:05.515472
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():

    origin = ImmutableDict(dict(a='1', b='2', c='3'))
    assert origin.difference(dict(a=1, b=2, c=3).keys()) == dict(a='1', b='2', c='3')
    assert origin.difference(dict(a=1, b=2).keys()) == dict(c='3')
    assert origin.difference(dict(a=1).keys()) == dict(b='2', c='3')
    assert origin.difference(dict(a=1, c=3).keys()) == dict(b='2')
    assert origin.difference(dict(a=1, c=3, b=2).keys()) == dict()

# Generated at 2022-06-11 00:49:20.844769
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    x = ImmutableDict(a=1, b=2)
    y = ImmutableDict(a=1, b=2)
    z = ImmutableDict(a=1, b=2, c=3)

    assert x == y
    assert not x == z
    assert not z == x
    assert not z == y
    assert not x == object()
    assert not x == (1, 2)
    assert not x == {'a': 1, 'b': 2}
    assert not x == ImmutableDict({'a': 1, 'b': 2})
    assert not x == ImmutableDict(a=1, b=2, c=3)
    assert y == y
    assert not y == ImmutableDict(a=1, b=2)

# Generated at 2022-06-11 00:49:30.659723
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable((1, 2, 3)) == True
    assert is_iterable(set([1, 2, 3])) == True
    assert is_iterable(frozenset([1, 2, 3])) == True
    assert is_iterable(dict(a=1, b=2, c=3)) == True
    assert is_iterable(dict.fromkeys(('a', 'b', 'c'))) == True
    assert is_iterable(xrange(3)) == True
    assert is_iterable(range(3)) == True

    assert is_iterable(1) == False
    assert is_iterable(1.0) == False
    assert is_iterable(True) == False

# Generated at 2022-06-11 00:49:40.827762
# Unit test for method __eq__ of class ImmutableDict

# Generated at 2022-06-11 00:49:46.124177
# Unit test for function is_iterable
def test_is_iterable():
    '''Test that is_iterable correctly identifies iterables'''
    class NonIterable(object):
        pass

    class Iterable(object):
        def __iter__(self):
            return iter(['a', 'b', 'c'])

    assert is_iterable(Iterable())
    assert is_iterable([1, 2, 3])
    assert is_iterable({'a': 1, 'b': 2, 'c': 3})
    assert is_iterable(('a', 'b', 'c'))
    assert is_iterable(xrange(3))
    assert not is_iterable(NonIterable())
    assert not is_iterable('abc')
    assert not is_iterable(None)
    assert not is_iterable(1)



# Generated at 2022-06-11 00:49:49.020353
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert not is_iterable(1)
    assert not is_iterable((1,))

# Generated at 2022-06-11 00:49:58.794975
# Unit test for function is_iterable
def test_is_iterable():
    # Test with a string
    assert not is_iterable('Hello World!')

    # Test with a list
    assert is_iterable([1, 2, 3, 4, 5])

    # Test with a tuple
    assert is_iterable((1, 2, 3))

    # Test with a set
    assert is_iterable(set())

    # Test with a dictionary
    assert is_iterable({'foo': 'bar'})

    # Test with an integer
    assert not is_iterable(6)

    # Test with an integer and include_strings set to True
    assert not is_iterable(6, True)

    # Test with an empty string
    assert is_iterable('', True)


# Generated at 2022-06-11 00:50:07.581033
# Unit test for function is_iterable
def test_is_iterable():
    # Check is_iterable, under various circumstances
    # is_iterable should work, with:
    # - strings (AnsibleVaultEncryptedUnicode is bool(__iter__))
    # - and iterable objects
    # is_iterable should not work, with:
    # - non iterable objects
    # - strings, if the "include_strings" parameter is False
    assert is_iterable('a')
    assert is_iterable(['a'])
    assert is_iterable('abc')
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable('')
    assert is_iterable([])
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable('a', include_strings=False)

# Generated at 2022-06-11 00:50:17.721869
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""

    def run_test(a, b, expectation):
        result = (a == b) is expectation
        print('{0} == {1}: {2!r} == {3!r}'.format(repr(a), repr(b), a == b, expectation))
        return result

    a = ImmutableDict()
    b = {'a': 1}
    c = ImmutableDict(a=1)
    d = a


# Generated at 2022-06-11 00:50:27.197569
# Unit test for function is_iterable
def test_is_iterable():
    """Unit test for function is_iterable"""
    class TestClass:
        pass
    iterable_objects = (
        ["a", "b"],
        ("a", "b"),
        {"a", "b"},
        {"a": 1, "b": 2},
    )
    non_iterable_objects = (
        "a",
        1,
        [],
        {},
        TestClass()
    )

    for obj in iterable_objects:
        assert is_iterable(obj)

    for obj in non_iterable_objects:
        assert not is_iterable(obj)



# Generated at 2022-06-11 00:50:37.167461
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equivalence of ImmutableDict - ImmutableDict
    id1 = ImmutableDict(a=1, b=2, c=3)
    id2 = ImmutableDict(a=1, b=2, c=3)
    assert(id1 == id2)
    # Test equivalence of ImmutableDict - dict
    d = dict(a=1, b=2, c=3)
    assert(id1 == d)
    # Test equivalence of dict - ImmutableDict
    assert(d == id1)
    # Test non-equivalence of ImmutableDict - ImmutableDict
    id3 = ImmutableDict(a=1, b=2, c=4)
    id4 = ImmutableDict(a=1, b=2, c=3, d=3)


# Generated at 2022-06-11 00:50:49.643377
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(None) is False
    assert is_iterable(1) is False
    assert is_iterable(True) is False
    assert is_iterable('ba') is True
    assert is_iterable((1,)) is True
    assert is_iterable([1]) is True
    assert is_iterable({1: 1}) is True



# Generated at 2022-06-11 00:50:51.449438
# Unit test for function is_iterable
def test_is_iterable():
    is_iterable('nottrue')
    is_iterable(['istrue'])


# Generated at 2022-06-11 00:50:57.654089
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2])
    assert is_iterable((1, 2))
    assert is_iterable({})
    assert is_iterable({'key': 'value'})
    assert is_iterable({1, 2})
    assert is_iterable('hello')
    assert is_iterable(u'hello')
    assert is_iterable(b'hello')
    assert not is_iterable(object())
    assert not is_iterable('not an iterable')
    assert is_iterable('not an iterable', include_strings=True)



# Generated at 2022-06-11 00:51:09.238385
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Verify that the method functions as expected when two ImmutableDicts are compared by value
    a = ImmutableDict({1: 'one', 2: 'two'})
    b = ImmutableDict({1: 'one', 2: 'two'})
    assert a == b

    # Verify that the method functions as expected when two ImmutableDicts are compared by value, but with different types
    a = ImmutableDict({1: 'one', 2: 'two'})
    b = ImmutableDict({1: 'one', 2: 'two'})
    assert a == b

    # Verify that the method functions as expected when comparing an ImmutableDict with a dictionary that has the same keys and values
    a = ImmutableDict({1: 'one', 2: 'two'})
    b = {1: 'one', 2: 'two'}

# Generated at 2022-06-11 00:51:17.324666
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    from copy import deepcopy
    foo = ImmutableDict({'a': 'hello', 'b': 'world'})
    bar = ImmutableDict({'b': 'world', 'a': 'hello'})
    baz = ImmutableDict({'a': 'goodbye', 'b': 'world'})
    baz2 = ImmutableDict({'a': 'hello', 'b': 'world'})

    assert foo == bar
    assert foo != baz
    assert foo == deepcopy(foo)
    assert foo == baz2

# Generated at 2022-06-11 00:51:27.187995
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    :return: True if ImmutableDict.__eq__() works correctly, False otherwise
    """
    test_dict = ImmutableDict(key1=1, key2=2, key3=3)
    assert test_dict == ImmutableDict(key1=1, key2=2, key3=3)
    assert test_dict == ImmutableDict(key3=3, key1=1, key2=2)
    assert test_dict == ImmutableDict(key3=3, key2=2, key1=1)
    assert test_dict != ImmutableDict(key3=3, key2=2, key1=3)
    assert test_dict != ImmutableDict(key3=3, key2=1, key1=1)

# Generated at 2022-06-11 00:51:39.064881
# Unit test for function is_iterable
def test_is_iterable():
    """Perform sanity check on is_iterable()."""
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1, 2, 3})
    assert is_iterable({1: 10, 2: 20, 3: 30})
    assert is_iterable({1: 10, 2: 20, 3: 30}.keys())
    assert is_iterable({1: 10, 2: 20, 3: 30}.values())
    assert is_iterable({1: 10, 2: 20, 3: 30}.items())
    assert is_iterable(xrange(10))
    assert is_iterable(xrange(10), include_strings=True)

    assert not is_iterable(8)
    assert not is_iterable(Exception)

# Generated at 2022-06-11 00:51:49.409310
# Unit test for function is_iterable
def test_is_iterable():
    try:
        iter('abc')
    except TypeError:
        raise Exception('String should be iterable')

    try:
        iter(b'abc')
    except TypeError:
        raise Exception('Bytes should be iterable')

    if not is_iterable([1, 2, 3]):
        raise Exception('List should be iterable')

    if not is_iterable(set([1, 2, 3])):
        raise Exception('Set should be iterable')

    if not is_iterable((1, 2, 3)):
        raise Exception('Tuple should be iterable')

    if not is_iterable(range(5)):
        raise Exception('Range should be iterable')

    if not is_iterable(xrange(5)):
        raise Exception('xrange should be iterable')


# Generated at 2022-06-11 00:51:52.441914
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1) == ImmutableDict(a=1)
    assert ImmutableDict(a=1, b=2) == ImmutableDict(b=2, a=1)

# Generated at 2022-06-11 00:52:04.966263
# Unit test for function is_iterable
def test_is_iterable():
    """Unit test for function is_iterable"""
    class C(object):
        """A dummy class that doesn't define __iter__ method."""
        def __init__(self, val):
            self.val = val

        def __str__(self):
            return str(self.val)

    class I(object):
        """A dummy class that defines the __iter__ method."""
        def __init__(self, val):
            self.val = val

        def __iter__(self):
            return iter(self.val)

        def __str__(self):
            return str(self.val)

    assert is_iterable('str')
    assert is_iterable(u'unicode')
    assert is_iterable(['list'])
    assert is_iterable(('tuple',))
    assert is_

# Generated at 2022-06-11 00:52:24.565499
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(dict(a=1, b=2)) == ImmutableDict(dict(a=1, b=2))
    assert not ImmutableDict(dict(a=1, b=2)) == ImmutableDict(dict(a=1, b=2, c=3))


# Generated at 2022-06-11 00:52:35.680194
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Unit tests for ImmutableDict.__eq__

    The __eq__ method should return true if and only if two ImmutableDict instances are exactly
    the same.

    :return: True on success, False on failure
    """
    EmptyDict = ImmutableDict()
    NonEmptyDict = ImmutableDict({'test': 1, 'test2': 2})
    NonEmptyDict2 = ImmutableDict({'test': 1, 'test2': 2})
    NonEmptyDict3 = ImmutableDict({'test3': 3, 'test4': 4})

    # Compare to the same instance
    if not NonEmptyDict == NonEmptyDict:
        return False
    if not EmptyDict == EmptyDict:
        return False

    # Compare to the same dicts of different instances

# Generated at 2022-06-11 00:52:44.141749
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    from ansible.module_utils.common._collections_compat import Mapping

    def _mapping(dic):
        if isinstance(dic, Mapping):
            return dic
        return dict(dic)

    def _test_success(dic1, dic2, msg=None):
        assert ImmutableDict(_mapping(dic1)) == ImmutableDict(_mapping(dic2)), msg

    def _test_failure(dic1, dic2, msg=None):
        assert ImmutableDict(_mapping(dic1)) != ImmutableDict(_mapping(dic2)), msg

    _test_success({"a": 1}, {"a": 1})
    _test_success({"a": 1, "b": 2}, {"b": 2, "a": 1})
   

# Generated at 2022-06-11 00:52:56.100464
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    # pylint: disable=too-many-branches,too-many-statements

    # Dictionary of all kinds of objects to compare
    dict_of_objects = dict()

    # ImmutableDict with number key and value pairs
    dict_of_objects['dict_number_key_and_value_pairs'] = \
        ImmutableDict({1: 2, 3: 4})
    # ImmutableDict with string key and value pairs
    dict_of_objects['dict_string_key_and_value_pairs'] = \
        ImmutableDict({'A': 'B', 'C': 'D'})
    # ImmutableDict with string and number key and value pairs

# Generated at 2022-06-11 00:53:03.776459
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Two ImmutableDicts are equal if they have the same content
    assert ImmutableDict(a=1, b=2) == ImmutableDict(b=2, a=1)
    assert ImmutableDict(a=1, b=2) == dict(b=2, a=1)
    assert ImmutableDict(a=1) != ImmutableDict(b=2)
    assert ImmutableDict(a=1) != dict(b=2)
    # __eq__ needs a hashable argument
    assert ImmutableDict(a=1) != ['a', 'b']

# Generated at 2022-06-11 00:53:15.454055
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_ImmutableDict = ImmutableDict(test_dict)

    # Testing with ImmutableDict object
    ImmutableDict_obj = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert test_ImmutableDict == ImmutableDict_obj

    ImmutableDict_obj = ImmutableDict({'a': 5, 'b': 2, 'c': 3})
    assert test_ImmutableDict != ImmutableDict_obj

    ImmutableDict_obj = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    assert test_ImmutableDict != ImmutableDict_obj

    # Testing with dictionary object

# Generated at 2022-06-11 00:53:26.909887
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = {'k1': 'v1', 'k2': 'v2'}
    d2 = {'k2': 'v2', 'k3': 'v3'}
    d3 = {'k1': 'v1', 'k2': 'v2'}
    d4 = {'k1': 'v1', 'k3': 'v3'}
    d5 = {'k1': 'v1', 'k2': 'v2'}

    id1 = ImmutableDict(d1)
    id2 = ImmutableDict(d2)
    id3 = ImmutableDict(d3)
    id4 = ImmutableDict(d4)
    id5 = id1

    assert id1 == id1
    assert id1 == id3
    assert not id1 == id2



# Generated at 2022-06-11 00:53:34.311968
# Unit test for function is_iterable
def test_is_iterable():
    class TestIterable(object):
        def __iter__(self):
            pass

    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(TestIterable())
    assert is_iterable('str')
    assert is_iterable(b'str')

    # This is needed just for AnsibleVaultEncryptedUnicode to work
    assert is_iterable(TestIterable(), include_strings=True)

    assert not is_iterable(10)
    assert not is_iterable(10.0)
    assert not is_iterable(None)



# Generated at 2022-06-11 00:53:44.919134
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({'k1': 'v1', 'k2': 'v2'})
    dict2 = ImmutableDict({'k1': 'v1', 'k2': 'v2'})
    dict3 = ImmutableDict({'k2': 'v2', 'k1': 'v1'})
    dict4 = ImmutableDict({'k2': 'v2', 'k1': 'v1', 'k3': 'v3'})
    dict5 = ImmutableDict({'k4': 'v4', 'k5': 'v5', 'k6': 'v6'})

    assert dict1 == dict1
    assert dict1 == dict2
    assert dict2 == dict3
    assert dict3 == dict1
    assert dict1 != dict4
    assert dict1 != dict5


# Generated at 2022-06-11 00:53:55.793656
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    original = ImmutableDict({'a': 1, 'b': 2})
    positive_dict = dict({'a': 1, 'b': 2})
    positive_ImmutableDict = ImmutableDict({'a': 1, 'b': 2})
    negative_dict = dict({'a': 1, 'b': 3})
    negative_ImmutableDict = ImmutableDict({'a': 1, 'b': 3})

    if original.__eq__(positive_dict) or original.__eq__(positive_ImmutableDict):
        raise AssertionError("Dictionary comparison failed")
    if original == positive_dict or original == positive_ImmutableDict:
        raise AssertionError("Simplified comparison failed")

# Generated at 2022-06-11 00:54:33.715628
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable([1, 2, 3]) == True)
    assert(is_iterable((1, 2, 3)) == True)
    assert(is_iterable(set([1, 2, 3])) == True)
    assert(is_iterable({1: 'a', 2: 'b', 3: 'c'}) == True)
    assert(is_iterable(1) == False)
    assert(is_iterable('abc') == True)
    assert(is_iterable(u'abc') == True)
    assert(is_iterable(u'abc'.encode('utf-8')) == False)

# Generated at 2022-06-11 00:54:37.681297
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(None)
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set([]))
    assert is_iterable('str')
    assert is_iterable(1)
    assert is_iterable(object)


# Generated at 2022-06-11 00:54:47.022724
# Unit test for function is_iterable
def test_is_iterable():
    # Test Variable declaration and initialization
    test_value = 123  # non iterable integer
    assert is_iterable(test_value) is False

    test_value = 'Test String'
    assert is_iterable(test_value) is False
    assert is_iterable(test_value, include_strings=True) is True

    test_value = b'Test bytes'
    assert is_iterable(test_value) is False
    assert is_iterable(test_value, include_strings=True) is True

    test_value = []  # empty iterable
    assert is_iterable(test_value) is True



# Generated at 2022-06-11 00:54:57.063466
# Unit test for function is_iterable
def test_is_iterable():
    """Test various inputs for `is_iterable` function."""
    assert is_iterable(())
    assert is_iterable(list())
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable(range(5))
    assert is_iterable(xrange(5))
    assert is_iterable(('a', 'b', 'c'))
    assert is_iterable(set('abc'))
    assert is_iterable({'a': 1, 'b': 2, 'c': 3})

    assert not is_iterable('abc')
    assert not is_iterable(1)
    assert not is_iterable(None)

    assert is_iterable({'a': 1, 'b': 2, 'c': 3}, include_strings=True)

# Generated at 2022-06-11 00:55:07.049670
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})

    assert not is_iterable(set())
    assert not is_iterable(0)
    assert not is_iterable('str')

    assert is_iterable(set(), include_strings=True)
    assert is_iterable(0, include_strings=True)
    assert is_iterable('str', include_strings=True)

    class A:
        pass

    a = A()
    assert is_iterable(a) == False
    A.__iter__ = lambda self: iter([])
    assert is_iterable(a)
    a = A()
    A.__iter__ = lambda self: iter(['something'])
    assert is_iterable(a)
    a = A()

# Generated at 2022-06-11 00:55:12.570534
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable((1, 2, 3))
    assert is_iterable([1, 2, 3])
    assert is_iterable(set([1, 2, 3]))
    assert is_string('foo')
    assert is_iterable({'foo': 'bar'})
    assert is_iterable(u'foo')
    assert not is_iterable(123)



# Generated at 2022-06-11 00:55:19.179386
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(1, 4))
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert not is_iterable(123)


# Generated at 2022-06-11 00:55:28.478387
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3, 4])
    assert is_iterable(set())
    assert is_iterable((1, 2, 3, 4))
    assert is_iterable(dict())
    assert is_iterable(dict(a=1, b=2).keys())
    assert is_iterable(dict(a=1, b=2).values())
    assert is_iterable(dict(a=1, b=2).items())
    assert is_iterable(MutableMapping())
    assert is_iterable(MutableMapping.keys(dict(a=1, b=2)))
    assert is_iterable(MutableMapping.values(dict(a=1, b=2)))
    assert is_iterable(MutableMapping.items(dict(a=1, b=2)))

# Generated at 2022-06-11 00:55:37.006045
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable('') is False
    assert is_iterable('foo') is True
    assert is_iterable('foo', include_strings=True) is True
    assert is_iterable({}) is True
    assert is_iterable({'1': 'foo'}) is True
    assert is_iterable(set()) is True
    assert is_iterable(set([1, 2, 3])) is True
    assert is_iterable(1) is False
    assert is_iterable(1, include_strings=True) is False



# Generated at 2022-06-11 00:55:44.503566
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Tests method __eq__ of class ImmutableDict.
    """
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) == {'a': 1}
    assert not ImmutableDict({'a': 1}) != ImmutableDict({'a': 1})
    assert not ImmutableDict({'a': 1}) != {'a': 1}
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != {'a': 2}

# Generated at 2022-06-11 00:56:55.560498
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'key1': 'val1', 'key2': 'val2'}) == ImmutableDict({'key1': 'val1', 'key2': 'val2'})
    assert ImmutableDict({'key1': 'val1', 'key2': 'val2'}) != ImmutableDict({'key2': 'val2', 'key1': 'val1'})
    assert ImmutableDict({'key1': 'val1', 'key2': 'val2'}) != ImmutableDict({'key1': 'val1', 'key2': 'v'})
    assert ImmutableDict({'key1': 'val1', 'key2': 'val2'}) == {'key1': 'val1', 'key2': 'val2'}

# Generated at 2022-06-11 00:57:01.994525
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert {'a': 2} != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 2}) != {'a': 3}
    assert ImmutableDict({'a': 2}) == ImmutableDict({'a': 2})
    assert {'a': 2} != ImmutableDict({'b': 2})
    assert ImmutableDict({'b': 2}) != {'a': 2}

# Generated at 2022-06-11 00:57:07.215147
# Unit test for function is_iterable
def test_is_iterable():
    sequence = (1,2,3)
    assert is_iterable(sequence) is True
    assert is_iterable('my string') is True
    assert is_iterable('my string', include_strings=False) is False
    assert is_iterable(1) is False
    assert is_iterable(1, include_strings=False) is False



# Generated at 2022-06-11 00:57:16.916566
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    empty = ImmutableDict()
    assert empty == empty
    assert empty == {}
    assert empty == ImmutableDict({})

    assert empty != None
    assert empty != 1
    assert empty != 'a'
    assert empty != (1, 2, 3)
    assert empty != {1: 2}
    assert empty != ImmutableDict({1: 2})

    non_empty = ImmutableDict({1: 2})
    assert non_empty == non_empty
    assert non_empty == {1: 2}
    assert non_empty == ImmutableDict({1: 2})

    assert non_empty != None
    assert non_empty != 1
    assert non_empty != 'a'
    assert non_empty != (1, 2, 3)
    assert non_empty != {1: 1}

# Generated at 2022-06-11 00:57:23.564762
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())

    assert is_iterable('foobar')
    assert is_iterable(u'foobar')
    assert is_iterable(b'foobar')

    assert is_iterable(1)
    assert is_iterable(0.5)
    assert is_iterable(1j)

    assert not is_iterable(None)
    assert not is_iterable(True)



# Generated at 2022-06-11 00:57:34.172794
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable((1, 2, 3)) == True
    assert is_iterable(set([1, 2, 3])) == True
    assert is_iterable(ImmutableDict(k=1, v=2)) == True
    assert is_iterable(dict([(1, 100), (2, 200)])) == True
    assert is_iterable(hash(1)) == True
    assert is_iterable(list(range(1, 10))) == True
    assert is_iterable(x for x in range(10)) == True
    assert is_iterable(1) == False
    assert is_iterable(2.5) == False
    assert is_iterable(None) == False



# Generated at 2022-06-11 00:57:42.015592
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # These are not equal because the keys are different
    assert ImmutableDict((1, '1'), (2, '2'), (3, '3')) != ImmutableDict((4, '4'), (5, '5'), (6, '6'))
    # These are equal because the keys are the same
    assert ImmutableDict((1, '1'), (2, '2')) == ImmutableDict((2, '2'), (1, '1'))
    # These are not equal because the keys are the same, but the values are different
    assert ImmutableDict((1, '1'), (2, '2')) != ImmutableDict((2, '2'), (1, '2'))

    # These are not equal because one is a dict and the other is an ImmutableDict