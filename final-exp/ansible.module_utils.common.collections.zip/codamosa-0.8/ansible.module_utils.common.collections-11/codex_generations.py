

# Generated at 2022-06-11 00:47:47.253324
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """Test the difference method of class ImmutableDict."""
    odict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    ndict = odict.difference(['c'])
    assert(odict == ImmutableDict({'a': 1, 'b': 2, 'c': 3}))
    assert(ndict == ImmutableDict({'a': 1, 'b': 2}))
    # Should not modify the original ImmutableDict
    assert('c' in odict)
    assert('c' not in ndict)



# Generated at 2022-06-11 00:47:53.181594
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # Create a ImmutableDict
    a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    # Create a list of items to remove from the ImmutableDict
    b = ['b', 'c']
    # Call difference to create a new ImmutableDict that is a copy of
    # the original with keys from the list removed
    c = a.difference(b)
    d = ImmutableDict({'a': 1})
    # Compare the two different ImmutableDict objects
    assert c == d


# Generated at 2022-06-11 00:48:05.568634
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    def run_single_test(self, other, expected_result):
        output = self.__eq__(other)
        assert output == expected_result, "Output was %s but expected %s" % (output, expected_result)

    a1 = ImmutableDict({"os_family": "RedHat", "os_flavor": "CentOS", "os_name": "CentOS"})
    a2 = ImmutableDict({"os_family": "RedHat", "os_flavor": "CentOS", "os_name": "CentOS"})
    assert a1 == a2, "Failed to note eqaulity with identical dictionaries"
    assert a1 == "CentOS", "Failed to note ineqaulity of dictionary and string"

# Generated at 2022-06-11 00:48:11.342544
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # Set up
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'g': 4})
    remove_keys = ['b', 'g']

    # Test
    new_dict = test_dict.difference(remove_keys)

    # Assert
    assert {'a': 1, 'c': 3} == new_dict

# Generated at 2022-06-11 00:48:20.594298
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'x': 'y'}) == ImmutableDict({'x': 'y'})
    assert ImmutableDict({'x': 'y'}) == dict({'x': 'y'})
    assert not ImmutableDict({'x': 'y'}) == ImmutableDict({'x': 'z'})
    assert not ImmutableDict({'x': 'y'}) == dict({'x': 'z'})
    assert not ImmutableDict({'x': 'y'}) == ImmutableDict({'x': 'y', 'z': 'y'})
    assert not ImmutableDict({'x': 'y', 'z': 'y'}) == ImmutableDict({'x': 'y'})

# Generated at 2022-06-11 00:48:32.897539
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1, 'b': 2})
    assert not ImmutableDict({'a': 1}) == ImmutableDict({'a': 2})
    assert not ImmutableDict({'a': 1}) == 1
    assert not ImmutableDict({'a': 1}) == object()
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1, 'a': 1})
    assert not ImmutableDict({'a': 1, 'a': 1}) == ImmutableDict({'a': 1})

# Generated at 2022-06-11 00:48:43.133846
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict = ImmutableDict(key1='value1', key2='value2')
    m = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    assert immutable_dict == m
    m = {'key1': 'value1', 'key2': 'value2'}
    assert immutable_dict == m
    m = {'key1': 'value1', 'key2': 'value4'}
    assert not immutable_dict == m
    m = {'key1': 'value1', 'key2': 'value4', 'key3': 'value3'}
    assert not immutable_dict == m

    # test if hashable
    m = {immutable_dict: 5}
    assert m == {immutable_dict: 5}

# Generated at 2022-06-11 00:48:45.996660
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    d = ImmutableDict({"a": "b", "c": "d"})
    result = d.difference(["a", "c"])
    assert result == ImmutableDict()



# Generated at 2022-06-11 00:48:52.673308
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    imm_dict_1 = ImmutableDict(dict(a=1, b=2))
    imm_dict_2 = ImmutableDict(dict(b=2, a=1))
    imm_dict_3 = ImmutableDict(dict(a=1, b=2))

    assert imm_dict_1 == imm_dict_2
    assert imm_dict_1 == imm_dict_3
    assert imm_dict_1 != dict(a=1, b=2, c=3)

# Generated at 2022-06-11 00:49:04.934490
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test that method __eq__ of ImmutableDict is implemented correctly.

    1. First check that we get True if we compare ImmutableDict to another ImmutableDict with the same
       data.

    2. Next check that we get False if we compare ImmutableDict to another ImmutableDict with different
       data.

    3. Next check that we get False if we compare ImmutableDict to another ImmutableDict with the same
       data but in different order.

    4. Next check that we get False if we compare ImmutableDict to an ordinary dictionary.

    5. Next check that we get False if we compare ImmutableDict to a string.
    """
    # 1.
    d1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-11 00:49:23.187877
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({'a': 2}) == ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 2}) == ImmutableDict({'a': 2, 'b': 3})
    assert ImmutableDict({'a': 2, 'b': 3}) == ImmutableDict({'a': 2, 'b': 3})
    assert ImmutableDict({'a': 2}) != ImmutableDict({'b': 2})
    assert ImmutableDict({'a': 2}) != ImmutableDict({'b': 2, 'c': 3})
    assert ImmutableDict({'a': 2, 'b': 3}) != ImmutableDict({'a': 2, 'b': 4})

# Generated at 2022-06-11 00:49:27.666846
# Unit test for function is_iterable
def test_is_iterable():
    class Iterable(object):
        def __iter__(self):
            yield 1

    assert is_iterable([1, 2, 3]) is True
    assert is_iterable(set([1, 2, 3])) is True
    assert is_iterable(Iterable()) is True
    assert is_iterable(object) is False



# Generated at 2022-06-11 00:49:38.448701
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    class MockDict(MutableMapping):
        # Need a mutable dict that is not a dictionary
        def __init__(self, *args, **kwargs):
            self.store = dict(*args, **kwargs)

        def __getitem__(self, key):
            return self.store[key]

        def __iter__(self):
            return self.store.__iter__()

        def __len__(self):
            return self.store.__len__()

        def __setitem__(self, key, value):
            self.store[key] = value

        def __delitem__(self, key):
            del self.store[key]

    a = ImmutableDict(a=1, b=2)
    b = ImmutableDict(a=1, b=2)
    c = Imm

# Generated at 2022-06-11 00:49:41.435838
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    sample1 = ImmutableDict(a=1, b=2)
    sample2 = ImmutableDict(a=1, b=2)
    assert sample1 == sample2
    sample3 = ImmutableDict(a=1, b=2, c=3)
    assert sample1 != sample3

# Generated at 2022-06-11 00:49:53.038704
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict() == {}
    assert {} == ImmutableDict()
    assert ImmutableDict({'a' : 3}) == ImmutableDict({'a' : 3})
    assert ImmutableDict({'a' : 3}) == {'a' : 3}
    assert {'a' : 3} == ImmutableDict({'a' : 3})
    assert ImmutableDict({'a' : 3, 'b' : 4}) == ImmutableDict({'b' : 4, 'a' : 3})
    assert ImmutableDict({'a' : 3, 'b' : 4}) == {'b' : 4, 'a' : 3}

# Generated at 2022-06-11 00:50:01.916426
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({1: 1}) != 1
    assert ImmutableDict({1: 1}) == ImmutableDict({1: 1})
    assert all([ImmutableDict({1: 1, 3: 3}) == ImmutableDict({1: 1, 3: 3}),
                ImmutableDict({1: 1, 3: 3}) == ImmutableDict({3: 3, 1: 1}),
                ImmutableDict({1: 1, 2: 2}) != ImmutableDict({1: 1, 3: 3}),
                ImmutableDict({1: 1, 3: 3}) != ImmutableDict({1: 1, 2: 2}),
                ])



# Generated at 2022-06-11 00:50:13.033999
# Unit test for function is_iterable
def test_is_iterable():
    # test string type
    assert is_iterable('test', True)
    assert not is_iterable('test')
    # test bytes type
    assert is_iterable(b'test', True)
    assert not is_iterable(b'test')
    # test list type
    assert is_iterable([])
    # test tuple type
    assert is_iterable(())
    # test set type
    assert is_iterable(set())
    # test dict type
    assert is_iterable({})
    # test generator type
    assert is_iterable((i for i in range(10)))
    # test AnsibleVaultEncryptedUnicode type
    assert is_iterable(u'AnsibleVaultEncryptedUnicode', True)

# Generated at 2022-06-11 00:50:19.735153
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""

    test_dict = ImmutableDict({"test1": "test_value1"})
    test_dict2 = ImmutableDict({"test2": "test_value2"})
    test_dict3 = ImmutableDict({"test2": "test_value2"})
    test_list = [1, 2, 3]
    test_string = "test"

    assert test_dict == test_dict
    assert test_dict2 == test_dict3
    assert not test_dict == test_dict2
    assert not test_dict == test_list
    assert not test_dict == test_string

# Generated at 2022-06-11 00:50:32.167890
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({u'a': 1, u'b': 2, u'c': 3, u'd': 4})
    dict2 = ImmutableDict({u'a': 1, u'b': 2, u'c': 3, u'd': 4})
    dict3 = ImmutableDict({u'e': 5, u'f': 6, u'g': 7, u'h': 8})
    dict4 = ImmutableDict({u'a': 1, u'b': 2, u'c': 3, u'd': 4, u'e': 5})
    dict5 = ImmutableDict({u'h': 8, u'g': 7, u'f': 6, u'e': 5})

# Generated at 2022-06-11 00:50:39.760911
# Unit test for function is_iterable
def test_is_iterable():
    class TestClass(object):
        pass
    test_obj = TestClass()
    # is_iterable should return True for iterable objects
    assert is_iterable([1, 2, 3]) is True
    # is_iterable should return True for iterable objects that redefine __iter__
    test_obj.__iter__ = lambda: (i for i in range(3))
    assert is_iterable(test_obj) is True
    # is_iterable should return True for iterable objects that redefine __getitem__
    test_obj.__getitem__ = lambda i: i
    assert is_iterable(test_obj) is True
    # is_iterable should return True for iterable objects that redefine __getitem__
    #   and stop iteration with an IndexError

# Generated at 2022-06-11 00:50:57.216254
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    original = ImmutableDict({"a": 1, "b": 2})
    other = ImmutableDict({"a": 1, "b": 2})
    assert(original == other)

    other = ImmutableDict({"a": 1, "b": 3})
    assert(original != other)

    other = ImmutableDict({"a": 1, "b": 2, "c": 3})
    assert(original != other)

    other = ImmutableDict({"b": 2, "a": 1})
    assert(original == other)

    other = [("a", 1), ("b", 2)]
    assert(original != other)

    other = ImmutableDict({"a": 1, "b": 2, "c": 3})
    assert(original != other)



# Generated at 2022-06-11 00:51:07.054112
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    id_1 = ImmutableDict({'a': 1})
    id_2 = ImmutableDict({'a': 1})
    id_3 = ImmutableDict({'a': 2})
    assert id_1 == id_2
    assert not (id_1 == id_3)
    assert not (id_1 == 1)
    assert not (id_1 == '')
    assert not (id_1 == ({'a': 1},))
    assert not (id_1 == dict({'a': 1}))
    assert not (id_1 == list({'a': 1}))
    assert not (id_1 == tuple({'a': 1}))


# Generated at 2022-06-11 00:51:11.637764
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable(42)
    assert is_iterable('')
    assert is_iterable(b'')



# Generated at 2022-06-11 00:51:23.331921
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'one': 1}) == ImmutableDict({'one': 1})
    assert not ImmutableDict({'one': 1}) == ImmutableDict({'two': 3})
    assert ImmutableDict({'one': 1, 'two': 2}) == ImmutableDict({'one': 1, 'two': 2})
    assert not ImmutableDict({'one': 1, 'two': 2}) == ImmutableDict({'one': 1, 'three': 3})
    assert not ImmutableDict({'one': 1}) == {'one': 1}
    assert ImmutableDict({'one': 1}) == ImmutableDict({'one': 1})
    assert ImmutableDict({'one': 1, 'two': 2}) == ImmutableDict({'two': 2, 'one': 1})


#

# Generated at 2022-06-11 00:51:33.803913
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert not ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 2, 'b': 1})
    assert not ImmutableDict({'a': 1, 'b': 2}) == 'a'
    assert not ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert not ImmutableDict({'a': 1, 'b': 2}) == {'a': 1}
    assert not ImmutableDict({'a': 1, 'b': 2}) == {'d': 1, 'f': 2}

# Generated at 2022-06-11 00:51:42.090131
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Create two equal ImmutableDict objects
    d1 = ImmutableDict(param1='value1', param2='value2')
    d2 = ImmutableDict(param2='value2', param1='value1')
    assert d1 == d2

    # Create two unequal ImmutableDict objects
    d1 = ImmutableDict(param1='value1', param2='value2')
    d2 = ImmutableDict(param2='value2', param1='value1', param3='value3')
    assert not d1 == d2



# Generated at 2022-06-11 00:51:51.251866
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():  # noqa: E501
    # a) both sides are ImmutableDict with the same content
    mydict = ImmutableDict({"first_key": "first_value", "second_key": "second_value"})
    otherdict = ImmutableDict({"first_key": "first_value", "second_key": "second_value"})
    assert (mydict == otherdict)

    # b) both sides are ImmutableDict but not equal
    mydict = ImmutableDict({"first_key": "first_value", "second_key": "not_equal_value"})
    otherdict = ImmutableDict({"first_key": "first_value", "second_key": "second_value"})
    assert (mydict != otherdict)

    # c) both sides are ImmutableDict with the same content

# Generated at 2022-06-11 00:52:03.735009
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit tests for ImmutableDict class method __eq__."""
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict()
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1, 'c': 3})
    assert Immutable

# Generated at 2022-06-11 00:52:11.366590
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) == True
    assert is_iterable((1, 2, 3)) == True
    assert is_iterable('hello') == False  # strings are not iterable unless stated otherwise
    assert is_iterable({'a'}) == True
    assert is_iterable(set([1, 2, 3, 4])) == True
    assert is_iterable({'a': 1}) == True
    assert is_iterable(100) == False  # ints are not iterable
    assert is_iterable(1.1) == False  # floats are not iterable



# Generated at 2022-06-11 00:52:17.071680
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({1:'one', 2:'two', 3:'three'})
    assert dict1 == dict1
    assert dict1 != 'a dict'
    dict2 = ImmutableDict({1:'one', 2:'two', 3:'three'})
    assert dict1 == dict2
    dict3 = ImmutableDict({1:'one', 2:'two', 3:'three'})
    dict4 = ImmutableDict({3:'three', 1:'one', 2:'two'})
    assert dict3 == dict4
    dict5 = ImmutableDict({1:'one', 2:'two', 3:'tree', 4:'four'})
    assert dict3 != dict5


# Generated at 2022-06-11 00:52:43.748845
# Unit test for function is_iterable
def test_is_iterable():
    class NotIterable:
        def __init__(self):
            pass
        def do_something(self):
            pass

    class Iterable:
        def __init__(self):
            pass
        def do_something(self):
            pass
        def __iter__(self):
            return iter(self)

    class StringLike(object):
        def __init__(self):
            pass
        def do_something(self):
            pass
        def __ENCRYPTED__(self):
            pass

    assert is_iterable(iter(range(1, 5)))
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))

# Generated at 2022-06-11 00:52:53.523527
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable(())
    assert is_iterable(xrange(1))
    assert is_iterable(iter([]))
    assert is_iterable(iter(set()))
    assert is_iterable(iter(()))
    assert is_iterable(iter(xrange(1)))

    assert not is_iterable(None)
    assert not is_iterable('foo')
    assert not is_iterable(1)
    assert not is_iterable(True)

# Generated at 2022-06-11 00:53:03.682306
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Check ImmutableDict __eq__ logic"""
    immutable_dict = ImmutableDict()

    assert immutable_dict == ImmutableDict()

    # True: count() returns the same for both ImmutableDict instances
    immutable_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    immutable_dict_2 = ImmutableDict({'b': 2, 'a': 1})

    assert immutable_dict_1.__hash__() == immutable_dict_2.__hash__()
    assert immutable_dict_1 == immutable_dict_2

    # False: count() returns different for both ImmutableDict instances
    immutable_dict_1 = ImmutableDict({'a': 1, 'b': 2})
    immutable_dict_2 = ImmutableDict({'b': 2, 'a': 2})



# Generated at 2022-06-11 00:53:09.401216
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != None
    assert ImmutableDict({'a': 1}) != {'a': 1}


# Generated at 2022-06-11 00:53:15.158860
# Unit test for function is_iterable
def test_is_iterable():
    class NonIterable:
        """Non-iterable object."""
        pass

    class Iterable:
        """Iterable object."""
        def __iter__(self):
            pass

    iterable = Iterable()
    non_iterable = NonIterable()

    assert is_iterable(iterable)
    assert not is_iterable(non_iterable)


# Generated at 2022-06-11 00:53:21.318715
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable({}) is True
    assert is_iterable({'a': 1, 'b': 2}) is True
    assert is_iterable('abc') is True
    assert is_iterable(u'abc') is True
    assert is_iterable(5) is False
    assert is_iterable(5.5) is False
    assert is_iterable(None) is False



# Generated at 2022-06-11 00:53:31.214067
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    base_data = {'name': 'Ahmed', 'age': 24, 'city': 'Giza'}
    imm_dict = ImmutableDict(base_data)

    # Test with a regular dictionary
    extra_data = {'country': 'Egypt'}
    eq_data = dict(base_data, **extra_data)
    extra_data = ImmutableDict(extra_data)
    eq_data = ImmutableDict(eq_data)
    neq_data = ImmutableDict(dict(eq_data, gender='male'))

    assert imm_dict != neq_data
    assert eq_data == imm_dict.union(extra_data)

    # Test with Hashable object
    class Test:
        def __init__(self, data=None):
            self.data = data


# Generated at 2022-06-11 00:53:34.952795
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    with pytest.raises(NotImplementedError):
        ImmutableDict().__eq__(None)


# Generated at 2022-06-11 00:53:45.382909
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(a=1, b=2, c=3)
    d2 = ImmutableDict(a=1, b=2, c=3)
    assert d1 == d2
    d3 = ImmutableDict(d=4, a=1, b=2, c=3)
    assert d2 != d3
    assert d1 != d3
    d4 = ImmutableDict(a=1, b=2, c=3, d=4)
    assert d3 == d4
    assert d2 != d4
    assert d1 != d4
    d5 = ImmutableDict(a=1, c=3)
    assert d1 != d5
    assert d5 != d1
    d6 = ImmutableDict(a=1, b=2)
    assert d

# Generated at 2022-06-11 00:53:53.155762
# Unit test for function is_iterable
def test_is_iterable():
    # Check that strings are not iterables
    assert not is_iterable("string")
    assert not is_iterable(b"byte_string")
    assert not is_iterable(u"unicode_string")
    # Check that dicts and lists are iterable
    assert is_iterable({})
    assert is_iterable([])
    assert is_iterable(dict())
    assert is_iterable(list())
    # Check that MutableMapping are also dicts
    assert isinstance(dict(), MutableMapping)


# Generated at 2022-06-11 00:54:34.053359
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('abc')
    assert is_iterable([])
    assert is_iterable(dict())
    assert is_iterable(set())
    assert is_iterable(range(5))
    assert not is_iterable(1)
    assert not is_iterable(True)
    assert not is_iterable(None)



# Generated at 2022-06-11 00:54:40.144070
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'x': 1, 'y': 2})
    b = ImmutableDict({'y': 2, 'x': 1})
    c = ImmutableDict({'y': 3, 'x': 1})
    d = ImmutableDict({'y': 2, 'x': 1, 'z': 3})
    e = ImmutableDict({'y': 2, 'x': 1, 'z': 3})
    assert(a == b)
    assert(b == a)
    assert(a != c)
    assert(a != d)
    assert(d == e)

# Generated at 2022-06-11 00:54:51.252167
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    from ansible.module_utils.common._collections_compat import Mapping

    def _assert_equal(expected, other):
        if expected:
            assert ImmutableDict(foo='bar') == other
        else:
            assert not (ImmutableDict(foo='bar') == other)

    _assert_equal(True, ImmutableDict(foo='bar'))
    _assert_equal(False, ImmutableDict(foo='baz'))
    _assert_equal(False, ImmutableDict(foo='bar', baz='qux'))
    _assert_equal(False, ImmutableDict(foo='baz', bar='qux'))
    _assert_equal(False, ImmutableDict(bar='bar'))
    _assert_equal(False, 'foo=bar')
    _assert_equal

# Generated at 2022-06-11 00:54:58.016389
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict(a=1, b=2)
    dict2 = ImmutableDict(a=1, b=2)
    dict3 = ImmutableDict(a=1, b=3)
    dict4 = ImmutableDict(a=1)
    dict5 = dict(a=1, b=2)

    assert dict1 == dict2
    assert dict1 != dict3
    assert dict1 != dict4
    assert dict1 == dict5

    # dict4 and dict5 are not equal as dict4 has more keys
    assert dict4 != dict5

# Generated at 2022-06-11 00:55:04.082104
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable({'a': 1})
    assert is_iterable((1, 2, 3))
    assert is_iterable(xrange(0, 10))
    assert not is_iterable(set())
    assert is_iterable('hello')
    assert is_iterable(b'hello')
    assert not is_iterable(1)
    assert not is_iterable(None)



# Generated at 2022-06-11 00:55:08.451293
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_1 = ImmutableDict({'key1': 'value1'})
    dict_2 = ImmutableDict({'key1': 'value1'})
    assert dict_1 == dict_2
    assert dict_1 != {'key1': 'value1'}


# Generated at 2022-06-11 00:55:19.874609
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict3 = ImmutableDict({'a': 1, 'b': 1, 'c': 3})
    dict4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    dict5 = 1
    assert dict1 == dict2
    assert dict1 != dict3
    assert dict1 == dict4
    assert dict1 != dict5
    assert dict1 == {'a': 1, 'b': 2, 'c': 3}
    assert dict1 != {'a': 1, 'b': 1, 'c': 3}

# Generated at 2022-06-11 00:55:28.970725
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([3, 2, 1]) is True
    assert is_iterable((3, 2, 1)) is True
    assert is_iterable({'three': 3, 'two': 2, 'one': 1}) is True
    assert is_iterable({'three', 'two', 'one'}) is True
    assert is_iterable(['three', 'two', 'one']) is True
    assert is_iterable(('three', 'two', 'one')) is True
    assert is_iterable(set(['three', 'two', 'one'])) is True
    assert is_iterable(set(('three', 'two', 'one'))) is True
    assert is_iterable(set(['three', 'two', 'one'])) is True

# Generated at 2022-06-11 00:55:39.580706
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test the ImmutableDict equality method
    # Test 1: two different values but same keys
    dict_one = ImmutableDict({'a': 1})
    dict_two = ImmutableDict({'a': 1})
    assert dict_one == dict_two
    # Test 2: two different values and different keys
    dict_one = ImmutableDict({'a': 1})
    dict_two = ImmutableDict({'b': 2})
    assert dict_one != dict_two
    # Test 3: two equal values with different keys
    dict_one = ImmutableDict({'a': 1})
    dict_two = ImmutableDict({'b': 1})
    assert dict_one != dict_two
    # Test 4: dict one value is greater
    dict_one = ImmutableDict({'a': 2})

# Generated at 2022-06-11 00:55:48.419597
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Positive test with dict and ImmutableDict
    left = {'a': 1, 'b': 2}
    right = ImmutableDict({'a': 1, 'b': 2})
    assert left == right
    # Positive test with ImmutableDict only
    left = ImmutableDict({'a': 1, 'b': 2})
    right = ImmutableDict({'a': 1, 'b': 2})
    assert left == right
    # Positive test with equal instances
    left = ImmutableDict({'a': 1, 'b': 2})
    right = left
    assert left == right
    # Negative tests with different ImmutableDict
    # Different keys
    left = ImmutableDict({'a': 1, 'b': 2})
    right = ImmutableDict({'a': 1, 'c': 2})


# Generated at 2022-06-11 00:57:11.988100
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test equality when hash is the same
    assert ImmutableDict(a=1) == ImmutableDict(a=1)

    # Test equality when hash is different
    immutable_dict1 = ImmutableDict(a=1, b=2)
    immutable_dict2 = ImmutableDict(a=1, b=3)
    assert immutable_dict1 == immutable_dict2

    # Test inequality
    immutable_dict1 = ImmutableDict(a=1, b=2)
    immutable_dict2 = ImmutableDict(a=1, b=2, c=3)
    assert immutable_dict1 != immutable_dict2



# Generated at 2022-06-11 00:57:18.663237
# Unit test for function is_iterable
def test_is_iterable():
    class EmptyClass(object):  # pylint: disable=unused-variable
        pass

    assert is_iterable([1, 2, 3]) is True
    assert is_iterable((1, 2, 3)) is True
    assert is_iterable({'one': 1, 'two': 2}) is True
    assert is_iterable({'one', 'two', 'three'}) is True
    assert is_iterable('abc') is True
    assert is_iterable(b'abc') is True

    assert is_iterable(None) is False
    assert is_iterable(1) is False

    # Test classes that define __iter__ but are not iterable
    assert is_iterable(One()) is False
    assert is_iterable(Two()) is False

    # Test is_iterable with iterable classes that are not sequences

# Generated at 2022-06-11 00:57:25.948527
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(())
    assert not is_iterable(1)
    assert not is_iterable(True)
    assert is_iterable(['a'])
    assert is_iterable({'a': 'b'})
    assert is_iterable(('a',))
    assert not is_iterable('a')
    # Non-indexable things are never of a sequence type
    assert not is_iterable(set('a'))


# Generated at 2022-06-11 00:57:37.124530
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""

    d1 = ImmutableDict(a=1, b=2, c=3)

    # Test equality with a dictionary
    d2 = dict(a=1, b=2, c=3)
    assert d1 == d2

    # Test equality with an ImmutableDict
    d3 = ImmutableDict(a=1, b=2, c=3)
    assert d1 == d3

    # Test equality with a different dictionary
    d4 = dict(a=1, b=2, c=4)
    assert d1 != d4

    # Test equality with a different ImmutableDict
    d5 = ImmutableDict(a=1, b=2, c=4)
    assert d1 != d5

    # Test equality with a