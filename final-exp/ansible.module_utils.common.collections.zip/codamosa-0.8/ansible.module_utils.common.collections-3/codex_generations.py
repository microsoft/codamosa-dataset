

# Generated at 2022-06-11 00:47:49.877155
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import unittest

    class TestImmutableDict___eq__(unittest.TestCase):
        # __eq__ is called when performing issubset tests
        def test_unexpected_types(self):
            a = ImmutableDict({'a': 1})
            self.assertFalse(a == 1)
            self.assertFalse(a.__eq__(1))

            self.assertFalse(a == [1])
            self.assertFalse(a.__eq__([1]))

            self.assertFalse(a == {1})
            self.assertFalse(a.__eq__({1}))

            self.assertFalse(a == '1')
            self.assertFalse(a.__eq__('1'))

        # __eq__ is called when performing issubset tests

# Generated at 2022-06-11 00:47:54.964841
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable((x for x in range(0)))
    assert not is_iterable(5)
    assert not is_iterable('test')
    assert not is_iterable(u'test')
    assert is_iterable('test', include_strings=True)


# Generated at 2022-06-11 00:48:07.352233
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    class Foo(object):
        def __hash__(self):
            raise TypeError
    immutable_dic = ImmutableDict(dict(a=1, b=2))
    immutable_dic_clone = ImmutableDict(dict(a=1, b=2))
    immutable_dic_modified = ImmutableDict(dict(a=1, b=2, c=3))
    immutable_dic_modified_keys = ImmutableDict(dict(c=1, b=2))
    immutable_dic_modified_values = ImmutableDict(dict(a=3, b=2))
    hashable_obj = dict(a=1, b=2)
    not_hashable_obj = Foo()

    assert (immutable_dic == immutable_dic_clone)

# Generated at 2022-06-11 00:48:10.170797
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    original_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    removed_keys = ['a', 'c']
    expected_result_dict = ImmutableDict({'b': 2, 'd': 4})

    result_dict = original_dict.difference(removed_keys)

    assert result_dict == expected_result_dict



# Generated at 2022-06-11 00:48:18.200841
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1, 'b': 2})

    # Two ImmutableDicts with the same contents should be equal
    assert a == ImmutableDict({'a': 1, 'b': 2})
    assert a.__eq__(ImmutableDict({'a': 1, 'b': 2}))

    # Two ImmutableDicts with different contents should not be equal
    assert a != ImmutableDict({'b': 2})
    assert a.__eq__(ImmutableDict({'b': 2}))

    # An ImmutableDict is not equal to an equivalent dict
    assert a != {'a': 1, 'b': 2}
    assert a.__eq__({'a': 1, 'b': 2})

    # An ImmutableDict is equal to an equivalent MutableDict with the same contents

# Generated at 2022-06-11 00:48:29.710037
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_dict = ImmutableDict({1: 'a', 2: 'b', 3: 'c'})
    test_dict2 = ImmutableDict({1: 'a', 2: 'b', 3: 'd'})

    assert test_dict == ImmutableDict({1: 'a', 2: 'b', 3: 'c'})
    assert not test_dict == ImmutableDict({1: 'a', 2: 'b', 4: 'c'})
    assert not test_dict == ImmutableDict({1: 'a'})
    assert not test_dict == ImmutableDict({1: 'a', 2: 'b', 3: 'c', 4: 'd'})
    assert not test_dict == test_dict2


# Generated at 2022-06-11 00:48:40.953967
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """Test difference method of ImmutableDict"""
    from ansible.module_utils.common._collections_compat import Mapping, Iterable
    from ansible.module_utils.compat._collections_compat import OrderedDict
    from collections import MappingProxyType
    from functools import partial

    def test_mapping(mapping):
        seq = ImmutableDict(mapping)
        assert len(seq) == len(mapping)
        assert isinstance(seq, Mapping)
        assert set(seq.keys()) == set(mapping.keys())
        assert set(seq.values()) == set(mapping.values())


# Generated at 2022-06-11 00:48:44.849384
# Unit test for function is_iterable
def test_is_iterable():
    """Unit tests for function is_iterable"""
    assert is_iterable([])
    assert is_iterable(ImmutableDict())
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable(0)
    assert not is_iterable(1)
    assert is_iterable('abc')



# Generated at 2022-06-11 00:48:48.637872
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():

    immutable_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    expected_dict = ImmutableDict({'c': 3})
    assert immutable_dict.difference(['a','b'])._store == expected_dict._store

# Generated at 2022-06-11 00:48:55.022523
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) == True
    assert is_iterable(()) == True
    assert is_iterable({}) == True
    assert is_iterable(set()) == True
    assert is_iterable(xrange(10)) == True
    assert is_iterable('123') == False
    assert is_iterable(u'123') == False
    assert is_iterable(123) == False
    assert is_iterable(None) == False
    assert is_iterable(Exception) == False



# Generated at 2022-06-11 00:49:08.730718
# Unit test for function is_iterable
def test_is_iterable():
    class NotIterable(object):
        pass

    class IsIterable(object):
        def next(self):
            pass

    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(())
    assert not is_iterable(NotIterable())
    assert is_iterable(IsIterable())



# Generated at 2022-06-11 00:49:16.598242
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # This test is from a user bug.
    # The out of the box json module does not accept bytes as the keys of a dict.
    # It works for values, but not for keys.
    # So for now, a json_dict can not have bytes keys.
    d1 = ImmutableDict(a=ImmutableDict(x='foo', y='bar'), b='baz')
    d2 = ImmutableDict(a=ImmutableDict(x='foo', y='bar'), b='baz')
    assert d1 == d2

# Generated at 2022-06-11 00:49:24.345276
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(ImmutableDict())

    assert is_iterable(1)
    assert is_iterable(set([1]))

    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({1: 'one', 2: 'two', 3: 'three'})
    assert is_iterable(ImmutableDict({1: 'one', 2: 'two', 3: 'three'}))

    assert is_iterable('123')
    assert is_iterable(b'123')



# Generated at 2022-06-11 00:49:30.165149
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert not ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 3})


# Generated at 2022-06-11 00:49:39.855169
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test equality of two ImmutableDicts. Testing both the cases when ImmutableDicts are
    equal and when they are not equal."""

    # Case 1: When ImmutableDicts are equal
    a = ImmutableDict(a=1, b=2, c=3)
    b = ImmutableDict(c=3, b=2, a=1)

    if a == b:
        print("ImmutableDicts are equal.")

    # Case 2: When ImmutableDicts are not equal
    a = ImmutableDict(a=1, b=2, c=3)
    b = ImmutableDict(a=1, b=2, c=4)

    if not a == b:
        print("ImmutableDicts are not equal.")

# Generated at 2022-06-11 00:49:50.766000
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1, 1: 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 2, 2: 1}
    assert ImmutableDict({'a': 1, 'b': 2}) != Immutable

# Generated at 2022-06-11 00:50:01.511946
# Unit test for function is_iterable
def test_is_iterable():
    class NotIterable(object):
        pass

    class Iterable(object):
        def __init__(self):
            self.attr = NotIterable()

        def __iter__(self):
            return iter(self.attr)

    class IterableStr(object):
        def __iter__(self):
            return iter('foo')

    assert is_iterable('abc')
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable(('a', 'b', 'c'))
    assert is_iterable({'a': 1, 'b': 2, 'c': 3})
    assert is_iterable('abc', include_strings=True)
    assert is_iterable(NotIterable()) is False
    assert is_iterable(Iterable()) is False
    assert is_iter

# Generated at 2022-06-11 00:50:10.115451
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 'b'}) == ImmutableDict({'a': 'b'})
    assert ImmutableDict({'a': 'b'}) == ImmutableDict([('a', 'b')])
    assert ImmutableDict({'a': 'b'}) == {'a': 'b'}
    assert ImmutableDict({'a': 'b'}) == {'a': 'b', 'c': 'd'}
    assert ImmutableDict() == {}
    assert ImmutableDict({'a': 'b'}) != {'a': 'B'}

# Generated at 2022-06-11 00:50:19.083119
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict() != {}
    assert ImmutableDict() == {}
    assert ImmutableDict({'a': 1}) != {}
    assert ImmutableDict({'a': 1}) != [{'a': 1}]
    assert ImmutableDict({'a': 1}) == {'a': 1}
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) == ImmutableDict(a=1)
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})

# Generated at 2022-06-11 00:50:30.914561
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict([('a', 1), ('b', 2), ('c', 3)])
    b = ImmutableDict([('b', 2), ('a', 1), ('c', 3)])
    c = ImmutableDict([('a', 1), ('b', 2), ('c', 3)])
    d = ImmutableDict([('a', 1), ('b', 2), ('c', 4)])
    e = ImmutableDict([('a', 1), ('b', 2)])
    f = 1

    assert(a == b)
    assert(b == a)
    assert(a == c)
    assert(b == c)
    assert(a != d)
    assert(a != e)
    assert(a != f)



# Generated at 2022-06-11 00:50:50.149488
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Testing the case of the two ImmutableDicts being the same
    id1 = ImmutableDict({'a': 1, 'b': 1})
    id2 = ImmutableDict({'a': 1, 'b': 1})
    assert id1 == id2

    # Testing the case of the two ImmutableDicts having the same key-value pairs
    # but in different order
    id1 = ImmutableDict({'a': 1, 'b': 1})
    id2 = ImmutableDict({'b': 1, 'a': 1})
    assert id1 == id2

    # Testing the case of the ImmutableDict and a regular dict being the same
    id1 = ImmutableDict({'a': 1, 'b': 1})
    id2 = dict({'a': 1, 'b': 1})
    assert id1

# Generated at 2022-06-11 00:50:56.139912
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    my_dict = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    another_dict = ImmutableDict({'key1': 'value1', 'key2': 'value2'})

    assert my_dict == another_dict

    my_dict = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    another_dict = ImmutableDict({'key3': 'value3', 'key4': 'value4'})

    assert my_dict != another_dict

# Generated at 2022-06-11 00:51:07.772796
# Unit test for function is_iterable
def test_is_iterable():
    class Iterable:
        def __init__(self):
            self.items = list()

        def __iter__(self):
            return self.items.__iter__()

    class NotIterable:
        def __init__(self):
            self.items = list()

    # is_iterable should return True if it is passed an Iterable instance,
    # or False if passed a NotIterable instance
    assert is_iterable(Iterable())
    assert not is_iterable(NotIterable())
    # is_iterable should return True if it is passed a dict,
    # even if dict is an empty dict
    assert is_iterable({'key': 1, 'key2': 2})
    assert is_iterable({})
    # is_iterable should return True if it is passed a list
    # even if list is

# Generated at 2022-06-11 00:51:19.466909
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) == {'a': 1}
    assert {'a': 1} == ImmutableDict({'a': 1})

    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != {'a': 2}
    assert {'a': 2} != ImmutableDict({'a': 1})

    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != {'b': 1}
    assert {'b': 1} != ImmutableDict({'a': 1})


# Generated at 2022-06-11 00:51:25.588470
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    b = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    c = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    d = ImmutableDict({'a': 1, 'b': 2})
    assert a == b
    assert not a == c
    assert not a == d


# Generated at 2022-06-11 00:51:37.582973
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Tests for the method ImmutableDict.__eq__."""
    def assert_true(a, b):
        """Asserts that objects that should be equal indeed are, failing otherwise."""
        if a != b:
            raise AssertionError('Expected {0} and {1} to be equal'.format(a, b))

    def assert_false(a, b):
        """Asserts that objects that should not be equal aren't, failing otherwise."""
        if a == b:
            raise AssertionError('Expected {0} and {1} to be different'.format(a, b))

    # Empty dictionaries are equal
    assert_true(ImmutableDict(), ImmutableDict())
    # Dictionaries with the same keys and values are equal

# Generated at 2022-06-11 00:51:48.385076
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([], include_strings=True) == True
    assert is_iterable({}, include_strings=True) == True
    assert is_iterable((), include_strings=True) == True
    assert is_iterable('', include_strings=True) == True
    assert is_iterable(u'', include_strings=True) == True
    assert is_iterable(b'', include_strings=True) == True
    assert is_iterable(set(), include_strings=True) == True
    assert is_iterable(u'Привет', include_strings=True) == True
    assert is_iterable('Hello World!', include_strings=True) == True
    assert is_iterable(b'Hello World!', include_strings=True) == True

# Generated at 2022-06-11 00:51:54.375421
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable(list())
    assert is_iterable(tuple())
    assert is_iterable(str())
    assert is_iterable(dict())
    assert is_iterable(123) is False
    assert is_iterable(set()) is True
    assert is_iterable(set(range(0, 9))) is True


# Generated at 2022-06-11 00:52:03.790576
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'k': 'v'})
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(10))
    assert is_iterable('Hello World')
    assert is_iterable(b'Hello World')
    assert is_iterable(bytearray([1, 2, 3]))

    assert not is_iterable(1)
    assert not is_iterable(1.09)



# Generated at 2022-06-11 00:52:10.352911
# Unit test for function is_iterable
def test_is_iterable():
    # not iterable - int
    assert not is_iterable(1)
    # not iterable - dict
    assert not is_iterable({})
    # not iterable - object
    assert not is_iterable(object())
    # iterable
    assert is_iterable([])
    # string is not iterable by default
    assert not is_iterable('')
    # string is iterable when asked for it
    assert is_iterable('', include_strings=True)

# Generated at 2022-06-11 00:52:36.510101
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # isinstance(dict, Hashable) is False so we can't use dict as a comparator for ImmutableDict.__eq__
    # Use class with hash defined and instances of this class that are equal, unequal or not Hashable
    class HashableEqual:
        def __hash__(self):
            return hash(0)
        def __eq__(self, other):
            return True

    class HashableNotEqual:
        def __hash__(self):
            return hash(0)
        def __eq__(self, other):
            return False

    class NotHashable:
        pass

    # Check to see if ImmutableDict.__eq__ returns True when the two objects have the same hash and are instances of the same class
    # Note: We can't use dict here because dict is not a hashable

# Generated at 2022-06-11 00:52:40.394547
# Unit test for function is_iterable
def test_is_iterable():
    """Test is_iterable function."""
    assert is_iterable([]) == True
    assert is_iterable({}) == True
    assert is_iterable(set()) == True
    assert is_iterable(1) == False
    assert is_iterable(None) == False



# Generated at 2022-06-11 00:52:46.360765
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test to check if method __eq__ works as expected."""
    d = ImmutableDict()
    d2 = ImmutableDict()
    # Testing empty dict
    assert d == d2
    assert not d != d2

    d = ImmutableDict({1: 'one', 2: 'two'})
    d2 = ImmutableDict({1: 'one', 2: 'two'})
    assert d == d2
    assert not d != d2

    d3 = ImmutableDict({1: 'one'})
    d4 = ImmutableDict({2: 'two'})
    assert d != d3
    assert d != d4

    dict_a = dict()
    dict_b = dict({1: 'one', 2: 'two'})
    assert d != dict_a
    assert d != dict

# Generated at 2022-06-11 00:52:57.618805
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': '1', 'b': '2'}) == ImmutableDict({'a': '1', 'b': '2'})
    assert ImmutableDict({'a': '1', 'b': '2'}) == {'a': '1', 'b': '2'}
    assert ImmutableDict({'a': '1', 'b': '2'}) == frozenset({'a': '1', 'b': '2'}.items())
    assert ImmutableDict({'a': '1', 'b': '2'}) == {'b': '2', 'a': '1'}
    assert ImmutableDict({'a': '1', 'b': '2'}) != ImmutableDict({'a': '1', 'b': '2', 'c': '3'})


# Generated at 2022-06-11 00:53:04.525026
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable((1, 2)) is True
    assert is_iterable([1, 2]) is True
    assert is_iterable({1: 'a', 2: 'b'}) is True
    assert is_iterable(ImmutableDict({1: 'a', 2: 'b'})) is True

    assert is_iterable(1) is False
    assert is_iterable(type) is False
    assert is_iterable(Exception) is False
    assert is_iterable(None) is False
    assert is_iterable('abcd') is False



# Generated at 2022-06-11 00:53:15.704874
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict_b = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict_c = ImmutableDict({'a': 2, 'b': 3, 'c': 4})
    set_a = {'a': 1, 'b': 2, 'c': 3}
    set_b = {'a': 1, 'b': 2, 'c': 3}
    set_c = {'a': 2, 'b': 3, 'c': 4}
    assert dict_a == dict_b, "Expected dict_a to equal dict_b"
    assert dict_a == set_a, "Expected dict_a to equal set_a"
    assert set_a == dict_a

# Generated at 2022-06-11 00:53:23.126981
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable(('foo', 'bar')))
    assert(is_iterable([]))
    assert(not is_iterable('foo'))
    assert(not is_iterable(None))
    assert(not is_iterable(1))
    assert(is_iterable(('foo', 'bar'), include_strings=True))
    assert(not is_iterable('foo', include_strings=False))
    assert(is_iterable('foo', include_strings=True))

# Generated at 2022-06-11 00:53:29.947699
# Unit test for function is_iterable
def test_is_iterable():
    class DoNotIterate:
        pass

    class Iterate(object):
        def __iter__(self):
            return self

        def next(self):
            raise StopIteration()

    assert is_iterable(u'Foo')
    assert is_iterable(b'Bar')
    assert not is_iterable(DoNotIterate())
    assert is_iterable(Iterate())
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})


# Generated at 2022-06-11 00:53:35.222986
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_a = ImmutableDict({1: 1, 2: 2, 3: 3, 4: 4})
    dict_b = ImmutableDict({1: 1, 2: 2, 3: 3, 4: 4})
    dict_c = ImmutableDict({1: 1, 2: 2, 3: 4, 4: 4})
    dict_d = ImmutableDict({1: 1, 2: 4, 3: 3, 4: 4})
    wrong_type = set([1, 2, 3])
    assert dict_a == dict_b
    assert dict_a != dict_c
    assert dict_c != dict_d
    assert dict_a != wrong_type

# Generated at 2022-06-11 00:53:45.696741
# Unit test for function is_iterable
def test_is_iterable():
    class A(object):
        def __init__(self, a):
            self._a = a

        def __iter__(self):
            return iter(self._a)

    a = A([1, 2, 3])

    assert(is_iterable(a))
    assert(is_iterable([1, 2, 3]))
    assert(is_iterable((1, 2, 3)))
    assert(is_iterable(xrange(3)))
    assert(is_iterable(range(3)))
    assert(is_iterable(set([1, 2, 3])))
    assert(is_iterable(b'abc'))
    assert(is_iterable('abc'))

    assert(not is_iterable(1))
    assert(not is_iterable(None))


# Generated at 2022-06-11 00:54:24.605132
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable(range(3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable({'a', 'b', 'c'})
    assert is_iterable(set())
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(u'abc'.encode('utf8'))
    assert is_iterable(b'abc'.decode('utf8'))
    assert is_iterable(1)
    assert is_iterable(None)
    assert not is_iterable(is_iterable)
    assert not is_iterable(Exception)



# Generated at 2022-06-11 00:54:35.754540
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict()
    d2 = ImmutableDict()
    assert d1 == d2
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    assert d1 == d2
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'b': 2, 'a': 1})
    assert d1 == d2
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'b': 1, 'a': 2})
    assert d1 != d2
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableD

# Generated at 2022-06-11 00:54:46.972080
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(None) is False
    assert is_iterable(42) is False
    assert is_iterable(object()) is False
    assert is_iterable('single_string') is False
    assert is_iterable([]) is True
    assert is_iterable(iter([])) is True
    assert is_iterable({}) is True
    assert is_iterable(iter({})) is True
    assert is_iterable(range(5)) is True
    assert is_iterable(iter(range(5))) is True

    class CustomSequence(object):
        def __getitem__(self, value):
            return 42
    assert is_iterable(CustomSequence()) is True
    assert is_iterable(iter(CustomSequence())) is True

# Generated at 2022-06-11 00:54:55.598495
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(None) is False
    assert is_iterable(42) is False
    assert is_iterable('foo bar') is False
    assert is_iterable(b'foo bar') is False
    assert is_iterable(['foo', 'bar']) is True
    assert is_iterable((42, )) is True
    assert is_iterable({'foo': 'bar'}) is True
    assert is_iterable(set(('foo', 'bar'))) is True
    assert is_iterable(set([('foo', 'bar')])) is True
    assert is_iterable(ImmutableDict({'foo': 'bar'})) is True



# Generated at 2022-06-11 00:55:02.473507
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Verify correct ImmutableDict __eq__ method operation.

    :return: AssertionError if the `__eq__()` method of ImmutableDict
        does not behave correctly.
    """
    test_dict = ImmutableDict({'foo': 'bar'})
    assert test_dict.__eq__({'foo': 'bar'}) is True
    assert test_dict.__eq__({'foo': 'baz'}) is False
    assert test_dict.__eq__(ImmutableDict({'foo': 'bar'})) is True
    assert test_dict.__eq__(ImmutableDict({'foo': 'baz'})) is False
    # Verify that non-mappings are hashed as a different type
    assert test_dict.__eq__(set(['foo'])) is False

# Generated at 2022-06-11 00:55:13.420363
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Two ImmutableDict objects, each with the same keys and values
    a = ImmutableDict({'x': 1, 'y': 2, 'z': 3})
    b = ImmutableDict({'x': 1, 'y': 2, 'z': 3})

    # Same class, same keys and values, so equal
    assert a == b

    # A class with a different set of keys but matching values
    class C(object):
        def __init__(self, x, y, z):
            self.x = x
            self.y = y
            self.z = z

    # ImmutableDict compares keys and values using order-independent hashing
    # This should be equal to the ImmutableDict above
    c = C(1, 2, 3)
    assert a == c

    # ImmutableDict compares keys and values

# Generated at 2022-06-11 00:55:22.193087
# Unit test for function is_iterable
def test_is_iterable():
    """Unit test for function is_iterable"""

    def is_iterable_internal(obj):
        return is_iterable(obj)

    assert is_iterable_internal(1) is False
    assert is_iterable_internal(['a']) is True
    assert is_iterable_internal('a') is False
    assert is_iterable_internal('a', include_strings=True) is True
    assert is_iterable_internal(('a', 'b')) is True
    assert is_iterable_internal({'a': 'b', 'c': 'd'}) is True
    assert is_iterable_internal({}) is True


# Generated at 2022-06-11 00:55:29.029124
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    id_1 = ImmutableDict({'a': 1, 'b': 2})
    id_2 = ImmutableDict({'a': 1, 'b': 2})
    id_3 = ImmutableDict({'a': 2, 'b': 1})
    id_4 = ImmutableDict({'b': 2, 'a': 1})

    assert id_1.__eq__(id_1)
    assert id_1.__eq__(id_2)
    assert not id_1.__eq__(id_3)
    assert not id_1.__eq__(id_4)

# Generated at 2022-06-11 00:55:34.686237
# Unit test for function is_iterable
def test_is_iterable():
    class NonIterable:
        pass

    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert not is_iterable(NonIterable())
    assert not is_iterable(1)



# Generated at 2022-06-11 00:55:39.856350
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable(tuple())
    assert is_iterable(())
    assert is_iterable(range(0))

    assert not is_iterable('string')
    assert not is_iterable(1)
    assert not is_iterable(True)
    assert not is_iterable(None)



# Generated at 2022-06-11 00:56:55.024029
# Unit test for function is_iterable
def test_is_iterable():
    class Class1(object):
        pass

    class Class2(object):
        pass

    class Class3:
        def __iter__(self):
            return self

    class Class4:
        def __iter__(self):
            return iter([1, 2, 3])

    class Class5:
        pass

    class Class6:
        def __getitem__(self, key):
            return 'value'

    assert not is_iterable(1)
    assert not is_iterable(Class1())
    assert not is_iterable(Class2())

    assert is_iterable(Class3())
    assert is_iterable(Class4())

    assert is_iterable([1, 2])
    assert is_iterable(['1', '2'])
    assert is_iterable((1, 2, 3))
   

# Generated at 2022-06-11 00:57:01.748088
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Check if __eq__ method of ImmutableDict class returns correct value"""
    d1 = ImmutableDict({'a':1, 'b':2, 'c':3})
    d2 = ImmutableDict({'a':1, 'b':2, 'c':3})
    d3 = ImmutableDict({'a':1, 'b':2, 'c':4})
    assert d1 == d2 and not d2 == d3


# Generated at 2022-06-11 00:57:12.598009
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    # Covers the case when __hash__ of the argument is not an integer
    # and the method __eq__ returns False
    d1 = ImmutableDict({'a': 1, 'b': 2})
    assert d1.__eq__([]) is False

    # Covers the case when __hash__ of the argument is an integer
    # but it is not equal to the hash of this ImmutableDict
    d2 = ImmutableDict({'a': 11, 'b': 2})
    assert d1.__eq__(d2) is False

    # Covers the case when __hash__ of the argument is an integer
    # and it is equal to the hash of this ImmutableDict
    d3 = ImmutableDict({'a': 1, 'b': 2})
    assert d1.__eq__(d3) is True



# Generated at 2022-06-11 00:57:17.278581
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    equal_dict = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    different_dict = ImmutableDict({'a': 1, 'b': 2})
    assert test_dict.__eq__(equal_dict)
    assert not test_dict.__eq__(different_dict)

# Generated at 2022-06-11 00:57:22.046295
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable({}) == True
    assert is_iterable([]) == True
    assert is_iterable(set()) == True
    assert is_iterable(tuple()) == True
    assert is_iterable('') == False
    assert is_iterable(None) == False
    assert is_iterable(1) == False
    assert is_iterable(object()) == False

# Generated at 2022-06-11 00:57:25.860015
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable([1, 2]))
    assert(is_iterable(dict()))
    assert(not is_iterable(1))
    assert(not is_iterable('Hello'))


# Generated at 2022-06-11 00:57:37.029383
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    When ImmutableDict's __eq__ is called with another Mapping object, then
    it should return True if the ImmutableDict's _store and the
    other Mapping's items are equal.
    It should return False if the ImmutableDict's _store and
    the other Mapping's items are not equal.
    """
    idict = ImmutableDict(key="value", key2="value2")
    immdict = ImmutableDict(key="value", key2="value2")
    anotherdict = dict(key="value", key2="value2")
    assert idict == immdict
    assert idict == anotherdict

    idict = ImmutableDict(key="value", key2="value2")
    immdict = ImmutableDict(key="value", key2="value22")
    anotherdict = dict