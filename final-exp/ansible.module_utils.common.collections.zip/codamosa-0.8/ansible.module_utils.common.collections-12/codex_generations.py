

# Generated at 2022-06-11 00:47:40.459254
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # Set up immutable dict as dict1
    dict1_keys = {'k1', 'k2', 'k3', 'k4'}
    dict1_values = {v * 10 for v in dict1_keys}
    dict1_store = dict(zip(dict1_keys, dict1_values))
    dict1 = ImmutableDict(dict1_store)

    # Set up subtractive list as dict2
    dict2_keys = {'k2', 'k4'}

    # Returned dict should be ImmutableDict(dict1) - dict2

# Generated at 2022-06-11 00:47:42.665455
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    """Unit test for method difference of class ImmutableDict"""
    immutable_dict = ImmutableDict()
    immutable_dict.difference()

# Generated at 2022-06-11 00:47:48.355774
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'c': 3})
    c = {}
    d = ImmutableDict({'a': 1, 'b': 2})
    f = ImmutableDict([('a', 1), ('b', 2)])

    assert a == d
    assert a != b
    assert a != c
    assert a != f



# Generated at 2022-06-11 00:47:57.060877
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'one': 1, 'two': 2})
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(4) is False
    assert is_iterable(None) is False
    assert is_iterable((c for c in 'abc'))
    assert is_iterable(open(__file__))
    assert is_iterable(set('abc'))
    assert is_iterable(frozenset('abc'))

# Generated at 2022-06-11 00:48:03.891967
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    # Create immutable dict
    immutableDict = ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})

    # Remove elements from immutable dict
    immutableDict_difference = immutableDict.difference(['key2'])

    # Check results
    assert immutableDict_difference == ImmutableDict({'key1': 'value1', 'key3': 'value3'})

# Generated at 2022-06-11 00:48:15.204505
# Unit test for function is_iterable
def test_is_iterable():
    class MultipleSequence(Sequence):
        """A class that inherits from Sequence."""
        def __init__(self, *sequences):
            self.sequences = sequences

        def __getitem__(self, seq_index):
            return self.sequences[seq_index]

        def __len__(self):
            return len(self.sequences)

    assert is_iterable([]) is True
    assert is_iterable((1,)) is True
    assert is_iterable(MultipleSequence([], ()), include_strings=True) is True
    assert is_iterable(MultipleSequence([], ()), include_strings=False) is True

    # We are not including strings in the iterable definition.
    assert is_iterable("Hello World") is False
    assert is_iterable(u"Hello World") is False

# Generated at 2022-06-11 00:48:20.497333
# Unit test for method difference of class ImmutableDict
def test_ImmutableDict_difference():
    test_dict = ImmutableDict({'key1': 1, 'key2': 2, 'key3': 3})
    test_dict = test_dict.difference(['key1', 'key3'])
    assert 'key1' not in test_dict
    assert 'key2' in test_dict
    assert 'key3' not in test_dict


# Generated at 2022-06-11 00:48:28.084902
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert not is_iterable('')
    assert is_iterable([], include_strings=True)
    assert is_iterable('', include_strings=True)
    assert not is_iterable(None)
    assert not is_iterable(object())
    assert not is_iterable(u'abc')
    assert not is_iterable(b'abc')
    assert not is_iterable(1)


# Generated at 2022-06-11 00:48:36.801869
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable(set())
    # On Python 2 bytes, unicode and basestring are iterable.
    # On Python 3 only strings are iterable.
    # All those types are strings, so we treat them as such.
    assert not is_iterable('test')
    assert not is_iterable(b'test')
    assert not is_iterable(u'test')
    assert not is_iterable(iter([]))
    assert not is_iterable(1)


# Generated at 2022-06-11 00:48:44.005006
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    class TestClass(object):
        pass
    tc = TestClass()
    id1 = ImmutableDict({'a':1,'b':2,'c':3})
    assert id1 == id1
    assert id1 != {'a':1,'b':2,'c':3}
    assert id1 != ImmutableDict({'a':1,'b':2})
    assert id1 != ImmutableDict({'a':1,'b':2,'c':4})
    assert id1 != tc
    assert id1 != 'TestString123'
    assert id1 != [1, 2, 3]


__all__ = ('ImmutableDict', 'count')

# Generated at 2022-06-11 00:48:55.595109
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    i1 = ImmutableDict({1: "one", 2: "two"})
    i2 = ImmutableDict({1: "one", 2: "two"})
    i3 = ImmutableDict({1: "one", 2: "two", 3: "three"})
    i4 = ImmutableDict({1: "one", 2: "two", 3: "three", 4: "four"})
    i5 = ImmutableDict({1: "one", 2: "three"})
    i6 = ImmutableDict({2: "two", 1: "one"})

    assert i1 == i2
    assert not i1 == i3
    assert not i1 == i4
    assert not i1 == i5
    assert i1 == i6

    assert not i1 == i1._store
    assert not i

# Generated at 2022-06-11 00:49:07.513889
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(1) is False
    assert is_iterable("test") is True
    assert is_iterable("test", include_strings=True) is True
    assert is_iterable("test", include_strings=False) is False
    assert is_iterable(["test1", "test2"]) is True
    assert is_iterable(("test1", "test2")) is True
    assert is_iterable(('test1', 'test2'), include_strings=True) is True
    assert is_iterable(dict(test1='test1')) is True
    assert is_iterable(dict(test1='test1'), include_strings=True) is True
    assert is_iterable(range(0, 4)) is True
    assert is_iterable(xrange(0, 4)) is True

# Generated at 2022-06-11 00:49:19.078789
# Unit test for function is_iterable
def test_is_iterable():
    import unittest
    class TestIsIterable(unittest.TestCase):
        def test_is_iterable(self):
            self.assertFalse(is_iterable('foo'))
            self.assertFalse(is_iterable(5))
            self.assertFalse(is_iterable(5.5))
            self.assertFalse(is_iterable(object()))
            self.assertTrue(is_iterable('foo'.split()))
            self.assertTrue(is_iterable(iter('foo'.split())))
            self.assertTrue(is_iterable(['foo', 'bar']))
            self.assertTrue(is_iterable(('foo', 'bar')))
            self.assertTrue(is_iterable(set(['foo', 'bar'])))

# Generated at 2022-06-11 00:49:25.118465
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({})
    assert is_iterable({'a': 1})
    assert is_iterable(set())
    assert is_iterable(set([1, 2, 3]))

    assert is_iterable(None) is False
    assert is_iterable(1) is False
    assert is_iterable('foo bar') is False
    assert is_iterable(b'foo bar') is False
    assert is_iterable(u'foo bar') is False



# Generated at 2022-06-11 00:49:35.985003
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Verify the __eq__ method of ImmutableDict"""

    # Create two ImmutableDict with the same values
    immdict_1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    immdict_2 = ImmutableDict({'b': 2, 'c': 3, 'a': 1})

    # Verify that the two objects are equal
    assert immdict_1 == immdict_2

    # Create an ImmutableDict with different values
    immdict_3 = ImmutableDict({'a': 4, 'b': 2, 'c': 3})

    # Verify that the two ImmutableDict are not equal
    assert immdict_1 != immdict_3

    # Verify that a non ImmutableDict is not equal to a ImmutableDict

# Generated at 2022-06-11 00:49:41.678519
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    d1 = ImmutableDict({"a": 1, "b": 2})
    d2 = ImmutableDict({"b": 2, "a": 1})
    d3 = ImmutableDict({"b": 2, "a": 0})
    d4 = ImmutableDict({"b": 1, "a": 1})
    assert d1 == d2
    assert d1 != d3
    assert d1 != d4


# Generated at 2022-06-11 00:49:53.323528
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a=ImmutableDict(x = 3, y = 4)
    b=ImmutableDict(x = 3, y = 4)
    c=ImmutableDict(x = 3, y = 9)
    d=ImmutableDict(x = 3)
    e=ImmutableDict(x = 5, y = 4)
    f=ImmutableDict(x = 3, y = 4, z = 8)
    g=ImmutableDict(x = 3, y = 4, z = 8)
    h=ImmutableDict(x = 3, y = 4, z = 9)
    assert(a == b)
    assert(a != c)
    assert(a != d)
    assert(a != e)
    assert(a != f)
    assert(f == g)
    assert(f != h)

# Generated at 2022-06-11 00:50:03.519758
# Unit test for function is_iterable
def test_is_iterable():
    class NotIterable:
        pass

    class Iterable(object):
        def __iter__(self):
            yield

    class IterableWithoutIter(object):
        def __getitem__(self, x):
            yield

    assert is_iterable(NotIterable), "This shouldn't be iterable"
    assert is_iterable(Iterable()), "Should be iterable"
    assert is_iterable(IterableWithoutIter()), "Should be iterable"
    assert is_iterable(()), "Should be iterable"
    assert is_iterable([]), "Should be iterable"
    assert is_iterable({}), "Should be iterable"
    assert is_iterable(set()), "Should be iterable"
    assert is_iterable('a'), "Should be iterable"
    assert is_iter

# Generated at 2022-06-11 00:50:09.575870
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable('', include_strings=False)
    assert not is_iterable('', include_strings=True)
    assert is_iterable((1, 2), include_strings=False)
    assert not is_iterable((1, 2), include_strings=True)
    assert not is_iterable(None, include_strings=False)



# Generated at 2022-06-11 00:50:14.806665
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    m1 = ImmutableDict({1: 'a', 2: 'b', 3: 'c'})
    m2 = ImmutableDict({1: 'a', 2: 'b', 3: 'c'})
    m3 = ImmutableDict({4: 'd', 2: 'b', 3: 'c'})
    m4 = ImmutableDict({1: 'a', 2: 'b'})
    m5 = {1: 'a', 2: 'b', 3: 'c'}
    assert m1 == m2
    assert m2 == m1
    assert not m1 == m3
    assert m1 != m3
    assert not m3 == m1
    assert m3 != m1
    assert not m1 == m4
    assert m1 != m4
    assert m1 == m5
    assert m

# Generated at 2022-06-11 00:50:27.600260
# Unit test for function is_iterable
def test_is_iterable():
    # Assert True for dictionary
    d = dict()
    assert is_iterable(d)

    # Assert True for list
    l = list()
    assert is_iterable(l)

    # Assert False for integer
    i = 3
    assert not is_iterable(i)

    # Assert False for string
    s = 'ansible'
    assert not is_iterable(s)

    # Assert False for None
    n = None
    assert not is_iterable(n)

    # Assert True for empty string with include_string options set to True
    assert is_iterable(s, include_strings=True)



# Generated at 2022-06-11 00:50:37.425175
# Unit test for method __eq__ of class ImmutableDict

# Generated at 2022-06-11 00:50:39.117518
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable("String")
    assert not is_iterable(12345)
    assert is_iterable(("String1","String2"))

# Generated at 2022-06-11 00:50:46.105867
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) == {'a': 1}
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != {'a': 2}
    assert ImmutableDict({'a': 1}) != 'string'

# Generated at 2022-06-11 00:50:55.552400
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(1) == False
    assert is_iterable("Hello")
    assert is_iterable("Hello", include_strings=True)
    assert is_iterable("Hello", include_strings=False) == False
    assert is_iterable("Hello", True)
    assert is_iterable("Hello", False) == False
    class Test():
        def __iter__(self):
            yield 1
    assert is_iterable(Test()) == True
    class Test():
        def __iter__(self):
            yield 1
    assert is_iterable(Test(), True) == True
    class Test():
        def __iter__(self):
            yield 1
    assert is_iterable(Test(), False) == False

# Generated at 2022-06-11 00:51:00.336339
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert not is_iterable(1)
    assert not is_iterable('a')
    assert not is_iterable(b'a')



# Generated at 2022-06-11 00:51:09.085624
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 'b', 'c'])
    assert is_iterable({'a': 'b'})
    assert is_iterable(ImmutableDict({'a': 'b'}))
    assert is_iterable((1, 2, 3))

    assert not is_iterable('abc')
    assert not is_iterable(1)
    assert not is_iterable(None)

    assert is_iterable(['a', 'b', 'c'], include_strings=True)
    assert is_iterable('abc', include_strings=True)



# Generated at 2022-06-11 00:51:17.613242
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a':1})
    b = ImmutableDict({'a':1})
    c = ImmutableDict({'a':1, 'b':2})
    d = ImmutableDict({'a':2})
    e = ImmutableDict({'a':1, 'b':2})
    f = dict({'a':1})

    assert a == a
    assert a == b
    assert c == e
    assert not (a == c)
    assert not (a == d)
    assert not (a == f)


# Generated at 2022-06-11 00:51:27.363541
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    d = ImmutableDict({'a': 1, 'b': 2})
    # Test equals
    assert d == ImmutableDict({'b': 2, 'a': 1})
    assert not (d == {'a': 1, 'b': 2})
    assert not (d == ImmutableDict({'c': 2, 'a': 1}))
    assert not (d == ImmutableDict({'b': 3, 'a': 1}))
    assert not (d == ImmutableDict({'c': 2, 'b': 1}))
    assert d == ImmutableDict(b=2, a=1)
    assert not (d == ImmutableDict(b=1, a=1))
    assert not (d == ImmutableDict(c=2, a=1))
    assert not (d == None)
   

# Generated at 2022-06-11 00:51:35.861359
# Unit test for function is_iterable
def test_is_iterable():
    # List is an iterable
    assert is_iterable([1, 2, 3]) is True
    # String is an iterable
    assert is_iterable("hello") is True
    assert is_iterable(b"hello") is True
    # Tuple is an iterable
    assert is_iterable((1, 2, 3)) is True
    # Dictionary is an iterable
    assert is_iterable({'a': 1, 'b': 2}) is True
    # Int is not an iterable
    assert is_iterable(1) is False



# Generated at 2022-06-11 00:51:50.899218
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # positive tests
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict() != 1
    assert ImmutableDict() != ''
    assert ImmutableDict({'a': 1, 'b': 2}) != 1
    assert ImmutableDict({'a': 1, 'b': 2}) != ''

    # negative tests
    assert not (ImmutableDict() != ImmutableDict())
    assert not (ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2}))
    assert not (ImmutableDict() == 1)
    assert not (ImmutableDict() == '')

# Generated at 2022-06-11 00:51:57.957042
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) == True
    assert is_iterable(()) == True
    assert is_iterable({}) == True
    assert is_iterable(set([])) == True
    assert is_iterable('str') == False
    assert is_iterable((i for i in range(1))) == True
    assert is_iterable(10) == False
    assert is_iterable(0) == False


# Generated at 2022-06-11 00:52:05.704613
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1,2,3])
    assert is_iterable({'a':1, 'b':3})
    assert is_iterable((1,2,3))
    assert is_iterable('string') is False
    assert is_iterable(u'string') is False
    assert is_iterable(is_iterable) is False
    assert is_iterable(count) is False
    assert is_iterable(42) is False


# Generated at 2022-06-11 00:52:12.274366
# Unit test for function is_iterable
def test_is_iterable():
    assert_true(is_iterable([1, 2, 3]))
    assert_true(is_iterable({'a': 1, 'b': 2, 'c': 3}))
    assert_true(is_iterable((1, 2, 3)))
    assert_true(not is_iterable(1))
    assert_true(not is_iterable(1.1))
    assert_true(not is_iterable('string'))
    assert_true(is_iterable(set([1, 2, 3])))


# Generated at 2022-06-11 00:52:22.884091
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    from copy import deepcopy
    from random import random

    def assert_equals(original, to_compare):
        assert original == to_compare, 'Expected {0} and {1} to be equal'.format(repr(original), repr(to_compare))

    def assert_not_equals(original, to_compare):
        assert original != to_compare, 'Expected {0} and {1} not to be equal'.format(repr(original), repr(to_compare))

    def _make_random_dict(n):
        return {k: v for k, v in ((int(random() * 100), str(random())) for _ in range(n))}

    def _make_random_list(n):
        return [random() for _ in range(n)]

    # Empty ImmutableDicts

# Generated at 2022-06-11 00:52:31.411804
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a':1}) == ImmutableDict({'a':1})
    assert ImmutableDict({'a':1}) != ImmutableDict({'b':1})
    assert ImmutableDict({'a':1}) != ImmutableDict({'a':2})
    assert ImmutableDict({'a':1}) != ImmutableDict({'b':1, 'a':1})
    assert not ImmutableDict({'a':1}) == [{'a':1}]
    assert not ImmutableDict({'a':1}) != {'a':1}


# Generated at 2022-06-11 00:52:33.945716
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a':1, 'b':2}) == ImmutableDict({'b':2, 'a':1})


# Generated at 2022-06-11 00:52:43.180161
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test __eq__ method of class ImmutableDict
    """
    # Test when both inputs are ImmutableDict's
    test_dict = ImmutableDict({"a":1,"b":2,"c":3})
    test_dict1 = ImmutableDict({"a":1,"b":2,"c":3})
    test_dict2 = ImmutableDict({"a":1,"b":2,"c":4})

    assert test_dict.__eq__(test_dict1), 'Expected result: True, Actual result: False'
    assert not test_dict.__eq__(test_dict2), 'Expected result: False, Actual result: True'

    # Test when one input is ImmutableDict and other is not

# Generated at 2022-06-11 00:52:48.877258
# Unit test for function is_iterable
def test_is_iterable():
    import types
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert not is_iterable('abc')
    assert not is_iterable(1)
    assert not is_iterable(None)

# Generated at 2022-06-11 00:52:59.724387
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 2, 'b': 1})
    assert ImmutableDict({}) == ImmutableDict({})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) != {}
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-11 00:53:14.151696
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert not is_iterable(object())
    assert is_iterable((1, 2, 3))
    assert not is_iterable(1)



# Generated at 2022-06-11 00:53:25.456723
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    list_of_dict = [
        ImmutableDict({'a': 1, 'b': 2}),
        ImmutableDict({'b': 2, 'a': 1}),
        ImmutableDict({'a': 1}),
        ImmutableDict({'a': 2}),
        ImmutableDict({'a': 1, 'b': 2, 'c': 3}),
        ImmutableDict({1: 'a', 2: 'b', 3: 'c'})
    ]


# Generated at 2022-06-11 00:53:33.476169
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # ImmutableDict objects are not equal to dict objects with the same items
    d1 = ImmutableDict({'a': 1})
    d2 = dict({'a': 1})

    assert d1 != d2

    # ImmutableDict objects with the same items are equal
    d3 = ImmutableDict({'a': 1})
    d4 = ImmutableDict({'a': 1})

    assert d3 == d4

    # ImmutableDict objects with different items are not equal
    d5 = ImmutableDict({'a': 1})
    d6 = ImmutableDict({'a': 2})

    assert d5 != d6

    # ImmutableDict objects are not equal to dict objects with the same items
    d7 = ImmutableDict()
    d8 = dict()

    assert d7 == d8

# Generated at 2022-06-11 00:53:44.368552
# Unit test for function is_iterable
def test_is_iterable():
    class Foo():
        pass

    class Bar(object):
        pass

    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable({'a', 'b'})
    assert is_iterable([Foo(), Foo()])
    assert is_iterable((Bar(), Bar()))
    assert not is_iterable(Foo())
    assert not is_iterable(Bar())
    assert not is_iterable(1)
    assert not is_iterable('abc')
    assert not is_iterable(u'abc')
    assert not is_iterable(2**200)
    assert not is_iterable(Ellipsis)


# Generated at 2022-06-11 00:53:55.359281
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(range(0, 3))
    assert is_iterable(xrange(0, 3))
    assert is_iterable({'a': 1, 'b': 2, 'c': 3})
    assert not is_iterable(True)
    assert not is_iterable(1)
    assert not is_iterable('a')
    assert not is_iterable('a,b,c')

    assert is_iterable('a', include_strings=True)
    assert is_iterable('1', include_strings=True)
    assert is_iterable('True', include_strings=True)
    assert is_iterable

# Generated at 2022-06-11 00:54:01.745259
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable(iter([])) is True
    assert is_iterable(iter([1, 2, 3])) is True
    assert is_iterable(xrange(3)) is True
    assert is_iterable(set()) is True
    assert is_iterable(set([1, 2, 3])) is True
    assert is_iterable(ImmutableDict()) is True
    assert is_iterable(ImmutableDict(x=1, y=2, z=3)) is True

    assert is_iterable('') is False
    assert is_iterable(1) is False
    assert is_iterable(True) is False



# Generated at 2022-06-11 00:54:11.380600
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test equality implementation for ImmutableDict"""
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    dict3 = ImmutableDict({'a': 1, 'c': 3})
    dict4 = dict1.union({'b': 3, 'c': 3})
    dict5 = dict1.difference(('b',))

    assert dict1 == dict1
    assert dict1 == dict2
    assert dict1 != dict3
    assert dict1 != dict4
    assert dict1 != dict5


if __name__ == '__main__':
    test_ImmutableDict___eq__()

# Generated at 2022-06-11 00:54:17.271133
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(object())
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(dict())
    assert is_iterable(range(0, 3))
    assert is_iterable(u'test')
    assert is_iterable(b'test')
    assert not is_iterable(1)



# Generated at 2022-06-11 00:54:25.176835
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test method ImmutableDict.__eq__"""
    d1 = ImmutableDict([('a', 1), ('b', 2), ('c', 3)])
    d2 = ImmutableDict([('a', 1), ('b', 2), ('c', 3)])
    assert d1 == d2, 'First test failed!'

    d1 = ImmutableDict([('a', 1), ('b', 2), ('c', 3)])
    d2 = ImmutableDict([('a', 1), ('b', 2), ('c', 4)])
    assert d1 != d2, 'Second test failed!'

    d1 = ImmutableDict([('a', 1), ('b', 2), ('c', 3)])
    d2 = {'a': 1, 'b': 2, 'c': 3}
    assert d1 != d

# Generated at 2022-06-11 00:54:30.354906
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict(a=1, b=2)
    b = ImmutableDict(a=1, b=2)
    assert (a == b)

    a = ImmutableDict(a=1, b=2)
    b = ImmutableDict(a=1, b=3)
    assert (a != b)

# Generated at 2022-06-11 00:54:58.580333
# Unit test for function is_iterable
def test_is_iterable():
    seq = [1, 2, 3]
    assert(is_iterable(seq))

    seq = {'a': 1, 'b': 2}
    assert(is_iterable(seq))

    seq = 'abc'
    assert(is_iterable(seq, include_strings=True))

    seq = (1, 2, 3)
    assert(is_iterable(seq))

    seq = 1
    assert(not is_iterable(seq))

    seq = object
    assert(not is_iterable(seq))


# Generated at 2022-06-11 00:55:05.439243
# Unit test for function is_iterable
def test_is_iterable():
    # pylint: disable=redefined-outer-name
    assert not is_iterable(None)
    assert not is_iterable(5)
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable(set([]))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable(('a', 'b', 'c'))
    assert is_iterable(x for x in range(4))



# Generated at 2022-06-11 00:55:09.864620
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    from __main__ import ImmutableDict
    test_dict = {'a':1, 'b':2, 'c':3}
    test_ImmutableDict = ImmutableDict(test_dict)
    assert(test_ImmutableDict == ImmutableDict(test_dict))


# Generated at 2022-06-11 00:55:21.121901
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # The __eq__ method of class ImmutableDict returns True if and only if the hashed value of
    # the ImmutableDict equals to the hashed value of the compared object. An exception is raised
    # when trying to inspect hashed value of the compared object in case when the compared object
    # type is different from ImmutableDict BaseException is used to catch any exception as all
    # exceptions are derived from Exception Base class. This approach is similar to how the
    # __eq__ method of class ImmutableDict is implemented.
    a = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})
    b = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})
    c = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})
   

# Generated at 2022-06-11 00:55:29.795023
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable("abc") == False
    assert is_iterable("abc", include_strings=True) == True
    assert is_iterable("abcdef") == False
    assert is_iterable("abcdef", include_strings=True) == True
    assert is_iterable(u"abc") == False
    assert is_iterable(u"abc", include_strings=True) == True
    assert is_iterable(u"abcdef") == False
    assert is_iterable(u"abcdef", include_strings=True) == True
    assert is_iterable([1,2,3,4]) == True
    assert is_iterable((1,2,3,4)) == True
    assert is_iterable(ImmutableDict(a=1, b=2, c=3)) == True
    assert is_

# Generated at 2022-06-11 00:55:33.833719
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(())
    assert not is_iterable(1)
    assert not is_iterable(None)


# Generated at 2022-06-11 00:55:42.345486
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable((i for i in range(10))) is True
    assert is_iterable(set()) is True
    assert is_iterable("asdf") is True
    assert is_iterable("asdf", include_strings=False) is False
    assert is_iterable("asdf", include_strings=True) is True
    assert is_iterable(u"asdf") is True
    assert is_iterable(u"asdf", include_strings=False) is False
    assert is_iterable(u"asdf", include_strings=True) is True
    assert is_iterable(1) is False
    assert is_iterable(object()) is False


# Generated at 2022-06-11 00:55:50.329456
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    # Create ImmutableDict
    testDict = ImmutableDict({'name':'test', 'age':'10'})

    # Create a new ImmutableDict with same content
    testDict_eq = ImmutableDict({'name':'test', 'age':'10'})

    # Create a non-ImmutableDict with same content
    testDict_Dict_eq = {'name':'test', 'age':'10'}

    # Create ImmutableDict with different content
    testDict_not_eq = ImmutableDict({'name':'test2', 'age':'11'})

    # Create non-ImmutableDict with different content
    testDict_Dict_not_eq = {'test':'name', 'age':'10'}

    # Create non-dict
    test

# Generated at 2022-06-11 00:56:01.300577
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({1: 2}) == ImmutableDict({1: 2})
    assert not (ImmutableDict({1: 2}) == ImmutableDict())
    assert not (ImmutableDict() == ImmutableDict({1: 2}))
    assert not (ImmutableDict({1: 2}) == ImmutableDict({1: 3}))
    assert not (ImmutableDict({1: 2}) == ImmutableDict({1: 2, 3: 4}))
    assert not (ImmutableDict({1: 2}) == ImmutableDict({3: 4, 1: 2}))
    assert ImmutableDict({1: 2, 3: 4}) == ImmutableDict({1: 2, 3: 4})

# Generated at 2022-06-11 00:56:09.180413
# Unit test for function is_iterable
def test_is_iterable():
    """Unit test that checks that the is_iterable function behaves as expected."""
    # list is iterable
    assert is_iterable([1, 2, 3])
    # str is iterable
    assert is_iterable("abc")
    # range is iterable
    assert is_iterable(range(5))
    # int is not iterable
    assert not is_iterable(234)
    # dict is iterable
    assert is_iterable({"1": 1})
    # set is iterable
    assert is_iterable(set([1, 2, 3]))
    assert not is_iterable(1)
    # bytes is iterable
    assert is_iterable(b"abc")



# Generated at 2022-06-11 00:57:07.217278
# Unit test for function is_iterable
def test_is_iterable():
    # strings are iterable
    assert is_iterable('foo')
    assert is_iterable(b'bar')
    assert is_iterable(u'baz')

    # lists are iterable
    assert is_iterable([])
    assert is_iterable([1, 2, 3])

    # tuples are iterable
    assert is_iterable(())
    assert is_iterable((1, 2, 3))

    # sets are iterable
    assert is_iterable(set())
    assert is_iterable({1, 2, 3})

    # dicts are iterable
    assert is_iterable({})
    assert is_iterable({1: 2, 3: 4})

    # must be able to specify that strings are not iterable
    assert not is_iterable('foo', include_strings=False)
   

# Generated at 2022-06-11 00:57:16.953827
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    #Setup
    test_dict = ImmutableDict({'hello': 'world', 'foo': 'bar'})
    test_dict2 = ImmutableDict({'hello': 'world', 'foo': 'bar'})
    test_dict3 = ImmutableDict({'hello': 'world', 'foo': 'baz'})
    d1 = {'hello': 'world', 'foo': 'bar'}
    d2 = {'hello': 'world', 'foo': 'bar'}
    d3 = {'hello': 'world', 'foo': 'baz'}
    #Test
    assert test_dict == test_dict2
    assert test_dict != test_dict3
    assert test_dict != d1
    assert test_dict == d2
    assert not test_dict == d3


# Generated at 2022-06-11 00:57:23.998258
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable({'a': 100, 'b': 200})
    assert is_iterable(set(['a', 'b', 'c', 'a']))
    assert is_iterable((i for i in range(10)))
    assert is_iterable([1,3,3,4,5])
    assert not is_iterable(5)
    assert not is_iterable(None)
    assert not is_iterable('abc')
    assert is_iterable('abc', include_strings=True)


# Generated at 2022-06-11 00:57:34.255577
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(set())
    assert is_iterable(dict())
    assert is_iterable([1,2,3])
    assert is_iterable("")
    assert is_iterable("1234")
    assert is_iterable(u"")
    assert is_iterable(u"1234")
    assert is_iterable("1234")
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable({"a":1})
    assert not is_iterable({"a":1}.values())
    assert not is_iterable({"a":1}.keys())
    assert not is_iterable({"a":1}.items())
