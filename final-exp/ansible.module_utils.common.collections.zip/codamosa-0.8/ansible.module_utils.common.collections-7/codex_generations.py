

# Generated at 2022-06-11 00:47:36.785357
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'x':1,'y':2})==ImmutableDict({'y':2,'x':1})

# Generated at 2022-06-11 00:47:44.117883
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1])
    assert is_iterable((1,))
    assert is_iterable(set([1]))
    assert is_iterable((i for i in range(1)))
    assert is_iterable(iter([1]))
    assert is_iterable(range(1))
    assert is_iterable(1) is False
    assert is_iterable(dict(a='a'))
    assert is_iterable(dict())


# Generated at 2022-06-11 00:47:50.293085
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1,2,3]) == True
    assert is_iterable(['a','b','c']) == True
    assert is_iterable(('a','b','c')) == True
    assert is_iterable(set(['a','b','c'])) == True
    assert is_iterable(dict(a=1, b=2, c=3)) == True
    assert is_iterable(1) == False
    assert is_iterable('abc') == False

# Generated at 2022-06-11 00:47:59.913477
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert not ImmutableDict({'a': 1}) == ImmutableDict({'a': 2})
    assert not ImmutableDict({'a': 1}) == ImmutableDict({'b': 1})
    assert not ImmutableDict({'a': 1}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict(a=1) == ImmutableDict(a=1)
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})



# Generated at 2022-06-11 00:48:02.891104
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert not is_iterable(1)



# Generated at 2022-06-11 00:48:08.399945
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test method __eq__ of class ImmutableDict
    """
    a = ImmutableDict(foo=1, bar=2)
    b = ImmutableDict(foo=1, bar=2)
    c = dict(foo=1, bar=2)
    assert a == b
    assert a != c


# Generated at 2022-06-11 00:48:18.060016
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict = ImmutableDict({'a': 1, 'b':2})
    assert immutable_dict == ImmutableDict({'a': 1, 'b': 2})
    assert immutable_dict == ImmutableDict(a=1, b=2)
    assert immutable_dict == {'a': 1, 'b': 2}
    assert immutable_dict != ImmutableDict({'a': 1, 'c': 2})
    assert immutable_dict != ImmutableDict({'a': 1, 'b': 3})
    assert immutable_dict != ImmutableDict({'a': 1})
    assert immutable_dict != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert immutable_dict != {'a': 1, 'b': 3, 'c': 3}


# Generated at 2022-06-11 00:48:25.688912
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable(set([1, 2, 3])) is True
    assert is_iterable({'a': 1, 'b': 2}) is True
    assert is_iterable((1, 2, 3)) is True
    assert is_iterable('abc') is True
    assert is_iterable(xrange(1, 10)) is True
    assert is_iterable(123) is False


# Generated at 2022-06-11 00:48:32.688630
# Unit test for function is_iterable
def test_is_iterable():
    """Unit test function for is_iterable."""
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(())
    assert is_iterable(text_type())
    assert is_iterable(binary_type())

    assert not is_iterable(None)
    assert not is_iterable(3)
    assert not is_iterable(object())



# Generated at 2022-06-11 00:48:42.942682
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Tests equality of two ImmutableDicts.
    """
    test_dict_1 = ImmutableDict(a=1, b=2)
    test_dict_2 = ImmutableDict(a=1, b=2)
    test_dict_3 = ImmutableDict(b=2, a=1)
    test_dict_4 = ImmutableDict(a=1, b=3)
    test_dict_5 = ImmutableDict(a=2, b=2)
    test_dict_6 = ImmutableDict(a=1, b=2, c=3)
    test_dict_7 = ImmutableDict(a=1, b=3, c=3, d=4)

    assert test_dict_1 == test_dict_2
    assert test_dict_1 == test_

# Generated at 2022-06-11 00:48:55.928712
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    def test(expected, d1, d2):
        result = (d1 == d2)
        assert result is expected, \
            'Expected {0} for {1} == {2}, found {3}'.format(expected, d1, d2, result)

    def same(d1, d2):
        test(True, d1, d2)
        test(True, d2, d1)

    def different(d1, d2):
        test(False, d1, d2)
        test(False, d2, d1)

    d = {'a': 5, 'b': 3}
    same(ImmutableDict(d), ImmutableDict(d.items()))
    different(ImmutableDict(d), ImmutableDict(d.items() + [('c', 4)]))


# Generated at 2022-06-11 00:49:07.362557
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import unittest

    class TestImmutableDict(unittest.TestCase):
        def test_equal(self):
            self.assertEqual(ImmutableDict({'a': 'b'}), ImmutableDict({'a': 'b'}))

        def test_not_equal(self):
            self.assertNotEqual(ImmutableDict({'a': 'b'}), ImmutableDict({'a': 'c'}))

        def test_not_equal_order(self):
            self.assertNotEqual(ImmutableDict({'a': 'b', 'c': 'd'}), ImmutableDict({'c': 'd', 'a': 'b'}))

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-11 00:49:18.984892
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Given
    x1 = ImmutableDict({1: 2, 3: 4})
    x2 = ImmutableDict({1: 2, 3: 4})
    y1 = ImmutableDict({1: 2, 3: 4, 5: 6})
    y2 = ImmutableDict({1: 2, 3: 4, 7: 8})
    z1 = {1: 2, 3: 4}
    z2 = {'b': 2, 'a': 1}

    # Then
    assert(x1 == x1)
    assert(x1 == x2)
    assert(x2 == x1)
    assert(not (x1 == y1))
    assert(not (x1 == y2))
    assert(not (x1 == z1))
    assert(not (z1 == x1))

# Generated at 2022-06-11 00:49:20.756016
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1, b='2') == ImmutableDict(a=1, b='2')
    assert not ImmutableDict(a=1, b='2') == dict(a=1, b='2')

# Generated at 2022-06-11 00:49:25.573114
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert not is_iterable(None)
    assert not is_iterable(1)
    assert not is_iterable('abc')
    assert is_iterable(['a', 'b'], include_strings=True)
    assert not is_iterable('abc', include_strings=False)


# Generated at 2022-06-11 00:49:36.472149
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable((1, 2, 3)) == True
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable('foo') == False
    assert is_iterable({'foo':'foo'}) == True
    assert is_iterable(dict({'foo':'foo'})) == True
    assert is_iterable(dict(foo='foo')) == True
    assert is_iterable(set(['foo'])) == True

if __name__ == '__main__':
    test_is_iterable()

    # Unit test for function is_iterable
    def test_is_sequence():
        assert is_sequence((1, 2, 3)) == True
        assert is_sequence([1, 2, 3]) == True
        assert is_sequence('foo') == False

# Generated at 2022-06-11 00:49:42.994726
# Unit test for function is_iterable
def test_is_iterable():
    # Check correct types
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, 'b': 2, 'c': 3})
    assert is_iterable("abc")
    assert is_iterable(u"abc")
    assert is_iterable(b"abc")
    # Check incorrect types
    assert not is_iterable(1)
    assert not is_iterable(True)
    assert not is_iterable(5.5)
    assert not is_iterable(complex(0, 5))



# Generated at 2022-06-11 00:49:54.903164
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    test_dict = ImmutableDict({'one': 1, 'two': 2})
    test_dict2 = ImmutableDict({'one': 1, 'two': 2})
    test_dict3 = ImmutableDict({'one': 1, 'two': 2, 'three': 3})
    test_dict4 = ImmutableDict({'one': 1, 'two': 2, 'three': 3})
    test_dict5 = ImmutableDict({'two': 2, 'one': 1})
    test_dict6 = ImmutableDict()
    test_dict7 = ImmutableDict({"one": 1})
    test_dict8 = ImmutableDict({"one": 1, "two": 2})
    test_dict9 = ImmutableDict({"one": 1, "two": 2, "three": 3})

    #

# Generated at 2022-06-11 00:50:02.792766
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    # self is not other.
    assert not ImmutableDict({'a': 1}) == ImmutableDict({'b': 2})

    # self is other.
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})

    # self is equal to other in terms of hash.
    assert ImmutableDict({'a': 1}) == ImmutableDict({'b': 1})

    # self is not equal to other in terms of hash.
    assert not ImmutableDict({'a': 1}) == ImmutableDict({'b': 2})


# Generated at 2022-06-11 00:50:06.379742
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert (ImmutableDict(a=1) == ImmutableDict(a=1))
    assert (ImmutableDict(a=1) != ImmutableDict(a=2))


# Generated at 2022-06-11 00:50:15.841290
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1}) == {'a': 1}
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != {'a': 2}



# Generated at 2022-06-11 00:50:27.546139
# Unit test for function is_iterable
def test_is_iterable():
    # ImmutableDict is an iterable
    assert(is_iterable(ImmutableDict({'a': 1, 'b': 2})))

    # EmptyImmutableDict is an iterable
    assert is_iterable(ImmutableDict())

    # Empty list is an iterable
    assert is_iterable([])

    # List is an iterable
    assert is_iterable([1, 2, 3])

    # Empty set is an iterable
    assert is_iterable(set())

    # Set is an iterable
    assert is_iterable(set([1, 2, 3]))

    # Empty tuple is an iterable
    assert is_iterable(tuple())

    # Tuple is an iterable
    assert is_iterable(tuple([1, 2, 3]))

    # int is not an iter

# Generated at 2022-06-11 00:50:37.388862
# Unit test for function is_iterable
def test_is_iterable():
    # Test for strings
    assert is_iterable(u'a')
    assert is_iterable(b'a')
    assert is_iterable(u'a', include_strings=True)
    assert is_iterable(b'a', include_strings=True)
    assert not is_iterable(u'a', include_strings=False)
    assert not is_iterable(b'a', include_strings=False)

    # Test for iterables
    assert is_iterable(u'a'*1000)
    assert is_iterable(b'a'*1000)
    assert is_iterable(range(100))
    assert is_iterable([1, 2, 3])
    assert is_iterable({'a', 'b'})
    assert is_iterable((2, 3, 4))

# Generated at 2022-06-11 00:50:49.438350
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(None)
    assert not is_iterable(123)
    assert not is_iterable(is_iterable)
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable((), include_strings=True)
    # sequence is subclass of iterable, it is still iterable
    assert is_iterable(list())
    assert is_iterable(dict())
    assert is_iterable(set())
    assert is_iterable(tuple())
    assert is_iterable(dict().values())
    assert is_iterable(set().difference(set()))
    # string are subclass of sequence, but it is not iterable unless provide include_strings=True
    assert not is_iterable('123')

# Generated at 2022-06-11 00:50:58.253272
# Unit test for function is_iterable
def test_is_iterable():
    # Another test case unique to Python 2.6 would be
    # to test a class that inherits from collections.Mapping.
    class MyMapping(dict):
        pass

    class MySequence(object):
        def __getitem__(self, index):
            return index

        def __iter__(self):
            return iter(range(5))

    class MyNonSequence(object):
        pass

    # Test cases
    class1 = MyMapping()
    class2 = MySequence()
    class3 = MyNonSequence()

    assert is_iterable(class1)
    assert is_iterable(class2)
    assert not is_iterable(class3)

    assert is_iterable(range(5))
    assert is_iterable(xrange(5))

# Generated at 2022-06-11 00:51:04.207197
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'key': 'value'}) == ImmutableDict({'key': 'value'})
    assert ImmutableDict({'key': 'value'}) != ImmutableDict({'key': 'foo'})
    assert ImmutableDict({'key': 'value'}) is not ImmutableDict({'key': 'value'})


# Generated at 2022-06-11 00:51:15.304515
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(1)
    assert not is_iterable(2.0)
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable(None)
    assert is_iterable(tuple())
    assert not is_iterable(tuple(), False)
    assert is_iterable([])
    assert not is_iterable([], False)
    assert is_iterable({})
    assert not is_iterable({}, False)
    assert is_iterable(set())
    assert not is_iterable(set(), False)
    assert is_iterable(iter([]))
    assert not is_iterable(iter([]), False)
    assert is_iterable('')
    assert is_iterable('', True)
    assert is_

# Generated at 2022-06-11 00:51:24.114399
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict(one=1, two=2, three=3, four=4)
    b = ImmutableDict(four=4, three=3, two=2, one=1)
    c = ImmutableDict(four=4, three=3, two=2, one=1)
    assert a == a
    assert a != b
    assert b == c
    assert b != {}
    assert {'one': 1} != c
    assert c != ['one', 'two', 'three', 'four']
    assert ['one', 'two', 'three', 'four'] != c


# Generated at 2022-06-11 00:51:36.008432
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test ImmutableDict __eq__ method to make sure we have expected behavior"""
    assert(ImmutableDict() == ImmutableDict())
    assert(ImmutableDict(a=1) == ImmutableDict(a=1))
    assert(ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2))
    assert(ImmutableDict(a=1, b=2) == ImmutableDict(b=2, a=1))
    assert(ImmutableDict((('a', 1), ('b', 2), ('c', 3) )) == ImmutableDict(a=1, b=2, c=3))
    assert(ImmutableDict(a=1, b=2) != ImmutableDict())

# Generated at 2022-06-11 00:51:45.320356
# Unit test for function is_iterable
def test_is_iterable():
    strings = ['a', "b", u"c"]
    numbers = [1, -2, 3.3]
    booleans = [False, True]
    mixed_lists = [[], bool, is_iterable]
    mixed_tuples = (1, 'a', bool, is_iterable)
    mixed_dicts = [{}, dict, ImmutableDict]

    assert all([is_iterable(cls) for cls in [strings, numbers, booleans, mixed_lists, mixed_tuples, mixed_dicts]])
    assert not is_iterable(Exception)
    assert not is_iterable(ImmutableDict)


# Generated at 2022-06-11 00:52:02.984172
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(foo='bar')
    d2 = ImmutableDict(foo='bar')
    assert d1 == d2
    d3 = ImmutableDict(bar='foo')
    assert not d1 == d3
    assert not d1 == 'string'

# Generated at 2022-06-11 00:52:13.230647
# Unit test for function is_iterable
def test_is_iterable():
    class IteratorClass(object):
        def __init__(self, seq):
            self.index = 0
            self.seq = seq

        def __iter__(self):
            return self

        def __next__(self):
            if self.index >= len(self.seq):
                raise StopIteration()
            ret = self.seq[self.index]
            self.index += 1
            return ret

        def next(self):
            return self.__next__()

    iterable_object = IteratorClass([1, 2, 3])
    non_iterable_object = 1
    assert is_iterable(iterable_object)
    assert not is_iterable(non_iterable_object)
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))


# Generated at 2022-06-11 00:52:17.125037
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable('abc')
    assert is_iterable(set())
    assert is_iterable(1) is False
    assert is_iterable(None) is False



# Generated at 2022-06-11 00:52:27.830379
# Unit test for function is_iterable
def test_is_iterable():
    # Test dictionary
    is_iterable({})
    is_iterable({'foo': 'bar'})
    is_iterable(ImmutableDict())
    is_iterable(ImmutableDict({'foo': 'bar'}))
    # Test list
    is_iterable([])
    is_iterable([1, 2, 3])
    # Test tuple
    is_iterable(tuple())
    is_iterable((1, 2, 3))
    # Test generator
    is_iterable(xrange(3))
    # Test string
    is_iterable('abc')
    is_iterable(b'abc')
    # Test file
    with open(__file__, 'rb') as f:
        is_iterable(f)

# Generated at 2022-06-11 00:52:38.933007
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import operator

    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict(dict(a=1, b=2))
    d3 = ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    d4 = ImmutableDict({'b': 1, 'a': 2})
    d5 = ImmutableDict({'a': 1, 'b': 2})
    d6 = ImmutableDict({'a': 1, 'b': 2, 'c': 2, 'd': 4})
    e1 = {'a': 1, 'b': 2}
    e2 = {'a': 1, 'b': 2}
    e3 = {'b': 2, 'a': 1}

# Generated at 2022-06-11 00:52:43.179076
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    one = ImmutableDict({'a': 1, 'b': 2})
    two = ImmutableDict({'a': 1, 'b': 2})
    assert one == two

    three = ImmutableDict({'a': 1, 'b': 3})
    assert not one == three

    four = ImmutableDict({'a': 1})
    assert not one == four


# Generated at 2022-06-11 00:52:52.864494
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    class Other(Hashable):
        def __hash__(self):
            return hash(frozenset(['a']))

    for hashable in [ImmutableDict(), ImmutableDict({'a': 'b'}), ImmutableDict({'a': 'b'})]:
        assert hashable == hashable
        assert hashable != Other()
        assert hashable != {}
        assert hashable != ImmutableDict({'a': 'b', 'c': 'd'})
        assert hashable != ImmutableDict({'a': 'c'})



# Generated at 2022-06-11 00:53:03.197388
# Unit test for function is_iterable
def test_is_iterable():
    """Verify behaviour of is_iterable function.
    """
    # Common types expected to be iterable
    assert is_iterable(list())
    assert is_iterable(dict())
    assert is_iterable(set())
    assert is_iterable(text_type())
    assert is_iterable(binary_type())

    # Common types expected to not be iterable
    assert not is_iterable(int())
    assert not is_iterable(float())
    assert not is_iterable(None)

    # Iterable classes
    class iterable_class(object):
        def __iter__(self):
            return iter(list())

    assert is_iterable(iterable_class())

    # Non-iterable classes
    class noniterable_class(object):
        pass


# Generated at 2022-06-11 00:53:09.127810
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # The simplest case: compare with another ImmutableDict
    a = ImmutableDict(a=1, b=2)
    b = ImmutableDict(a=1, b=2)
    assert a == b
    b = ImmutableDict(b=2, a=1)
    assert a == b
    b = ImmutableDict(a=1)
    assert a != b

    # Compare with other objects that can be converted to immutable dictionary
    immutable_dict = ImmutableDict(a=1, b=2)
    mutable_dict = {'a': 1, 'b': 2,}
    assert immutable_dict == mutable_dict
    immutable_dict = ImmutableDict(a=1, b=2)
    list = [('a', 1), ('b', 2)]

# Generated at 2022-06-11 00:53:20.417107
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """tets for class ImmutableDict, method __eq__"""

    class OtherDict(ImmutableDict):
        pass

    # True
    assert ImmutableDict({}) == {}
    assert ImmutableDict({'a': 1}) == {'a': 1}
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict({'a': [1, 2, 3]}) == ImmutableDict({'a': [1, 2, 3]})

    # False
    assert ImmutableDict({}) != {'a': 1}
    assert ImmutableDict({}) != []

# Generated at 2022-06-11 00:53:57.263196
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})

# Generated at 2022-06-11 00:54:03.182698
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable(()) is True
    assert is_iterable({}) is True
    assert is_iterable(set()) is True
    assert is_iterable(ImmutableDict()) is True

    assert is_iterable('abc') is False
    assert is_iterable(5) is False

    assert is_iterable([], include_strings=True) is True
    assert is_iterable(('a', 'b', 'c'), include_strings=True) is True
    assert is_iterable({'a': 1, 'b': 2, 'c': 3}, include_strings=True) is True
    assert is_iterable(set(['a', 'b', 'c']), include_strings=True) is True

# Generated at 2022-06-11 00:54:07.191769
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test the method ImmutableDict.__eq__."""
    # Equal dictionaries
    original_dict1 = {'a': 1, 'b': 2, 'c': 3}
    immutable_dict1 = ImmutableDict(original_dict1)
    test_dict1 = {'a': 1, 'b': 2, 'c': 3}
    immutable_test_dict1 = ImmutableDict(test_dict1)
    assert immutable_dict1 == immutable_test_dict1
    assert immutable_dict1 == test_dict1
    assert immutable_dict1 == original_dict1
    assert immutable_test_dict1 == immutable_dict1
    assert immutable_test_dict1 == test_dict1
    assert immutable_test_dict1 == original_dict1

    # Equal dictionaries with different keys ordering
    original_dict2

# Generated at 2022-06-11 00:54:13.529556
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dictionary = {'name':'Joe Smith', 'age':25, 'hometown':'New York'}
    immutable = ImmutableDict(dictionary)
    assert immutable == dictionary

    dictionary = {'name':'Joe Smith', 'age':25, 'weight': 150}
    immutable = ImmutableDict(dictionary)
    assert immutable != dictionary
    assert immutable != ['name', 'Joe Smith', 'age', 25, 'hometown', 'New York']


# Generated at 2022-06-11 00:54:22.665162
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Check that ImmutableDict __eq__ works
    dict_1 = ImmutableDict(a=1, b=2, c=3)
    dict_2 = ImmutableDict(c=3, b=2, a=1)
    dict_3 = ImmutableDict(c=3, b=2, d=1)
    dict_4 = dict(c=3, b=2, a=1)
    dict_5 = ImmutableDict(b=2, c=3, a=1)
    assert dict_1 == dict_2
    assert dict_1 == dict_4
    assert dict_1 == dict_5
    assert dict_2 == dict_1
    assert not (dict_1 == dict_3)
    assert not (dict_3 == dict_1)

# Generated at 2022-06-11 00:54:33.453054
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    # Case 1: Two same empty ImmutableDict are equal
    d1 = ImmutableDict()
    d2 = ImmutableDict()
    assert d1 == d2

    d3 = ImmutableDict(a=1)
    d4 = ImmutableDict(a=1)
    assert d3 == d4

    # Case 2: Two same non-empty ImmutableDict are equal
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(a=1, b=2)
    assert d1 == d2

    d3 = ImmutableDict(a=1, b=2, c=3)
    d4 = ImmutableDict(a=1, b=2, c=3)
    assert d3 == d4

    # Case 3: Two non

# Generated at 2022-06-11 00:54:41.070757
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    id1 = ImmutableDict({'a': 1, 'b': 2})
    id2 = ImmutableDict({'a': 1, 'b': 2})

    # Test same object
    if id1.__eq__(id1):
        print('ERROR: same object comparison should return False')

    # Test different dict
    if id1.__eq__(id2):
        print('ERROR: different dict comparison should return False')

    # Test same dict
    if not id1.__eq__(id1.union(id2)):
        print('ERROR: same dict comparison should return True')

    # Test comparison with hashable object
    if id1.__eq__(frozenset(id1.items())):
        print('ERROR: comparison with sequence object should return False')

    # Test comparison with non-hashable object
   

# Generated at 2022-06-11 00:54:47.317405
# Unit test for function is_iterable
def test_is_iterable():
    from ansible.module_utils.six import string_types
    assert is_iterable((1, 2, 3))
    assert is_iterable({'1': 2})
    assert is_iterable([])
    assert is_iterable(set)
    assert is_iterable(string_types)
    assert is_iterable(1) is False
    assert is_iterable(None) is False



# Generated at 2022-06-11 00:54:53.019470
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([], include_strings=False)
    assert not is_iterable('string', include_strings=False)
    assert is_iterable(('a', 'b'), include_strings=False)
    assert is_iterable((x for x in range(5)), include_strings=False)
    assert not is_iterable(10, include_strings=False)



# Generated at 2022-06-11 00:55:01.157454
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('test') == False
    assert is_iterable(None) == False
    assert is_iterable(test_is_iterable) == False
    assert is_iterable(['test']) == True
    assert is_iterable(('test')) == True
    assert is_iterable((x for x in range(10))) == True
    assert is_iterable(range(10)) == True
    # should this be True? not iterable in the sense of list(), tuple(), etc..
    assert is_iterable(set(['test'])) == False
    assert is_iterable(frozenset(['test'])) == False
    assert is_iterable(dict({'test': 1})) == True
    assert is_iterable(ImmutableDict({'test': 1})) == True

# Generated at 2022-06-11 00:56:07.126574
# Unit test for function is_iterable
def test_is_iterable():
    class MyClass(object):
        def __iter__(self):
            pass
    class MyClassNotIterable(object):
        pass
    class MyDict(dict):
        # Inheriting from dict to make sure the class is a sequence but not an iterable
        pass
    assert is_iterable(MyClass()) == True
    assert is_iterable(MyClassNotIterable()) == False
    assert is_iterable([]) == True
    assert is_iterable(()) == True
    assert is_iterable([1,2,3]) == True
    assert is_iterable((1,2,3)) == True
    assert is_iterable(set([1,2,3])) == True
    assert is_iterable(iter(set([1,2,3]))) == True

# Generated at 2022-06-11 00:56:11.823466
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable('a')
    assert not is_iterable(u'a')
    assert not is_iterable(b'a')
    assert not is_iterable(1)
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable({'a': 'a'})
    assert is_iterable(set())



# Generated at 2022-06-11 00:56:17.703419
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test the equality method of class ImmutableDict"""

    # Test equal Mappings
    #
    # Note that equality tests are used in the process of determining
    # whether two ImmutableDicts can be considered equal,
    # so these tests also indirectly test the __hash__ method.
    dict_1 = ImmutableDict({'a': 1})
    list_1 = [{'a': 1}]
    list_2 = [{'a': 1}, {'b': 2}]
    list_3 = [{'a': 1}, {'a': 2}]
    dict_2 = ImmutableDict({'a': 1, 'b': 2})
    dict_3 = ImmutableDict({'a': 2, 'b': 2})
    assert dict_1 == dict_1
    assert dict_1 == list_1


# Generated at 2022-06-11 00:56:28.901866
# Unit test for function is_iterable
def test_is_iterable():
    import unittest

    class TestCase(unittest.TestCase):
        def test(self):
            # Make sure we can iterate over all attributes of this object,
            # instance of this class, and its class.
            self.assertTrue(is_iterable(self, include_strings=False))
            self.assertTrue(is_iterable(self.__dict__, include_strings=False))
            self.assertTrue(is_iterable(self.__class__, include_strings=False))
            self.assertTrue(is_iterable([], include_strings=False))
            self.assertTrue(is_iterable({}, include_strings=False))
            self.assertTrue(is_iterable(None, include_strings=False))
            self.assertFalse(is_iterable('foo', include_strings=False))

# Generated at 2022-06-11 00:56:34.864967
# Unit test for function is_iterable
def test_is_iterable():
    class NotIterable:
        pass

    class Iterable:
        def __iter__(self):
            pass

    assert is_iterable([]) is True
    assert is_iterable(Iterable()) is True
    assert is_iterable(NotIterable()) is False
    assert is_iterable('') is False
    assert is_iterable('abc') is True
    assert is_iterable(u'abc') is True
    assert is_iterable(b'abc') is True
    assert is_iterable(123) is False
    assert is_iterable(set()) is True
    assert is_iterable(frozenset()) is True


# Generated at 2022-06-11 00:56:42.665066
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict(a=1, b=2)
    b = ImmutableDict(a=1, b=2)
    c = ImmutableDict(a=2, b=1)

    assert a == b
    assert a != c

    # Additional test for equality comparison with non-immutable dict
    d = {'a': 1, 'b': 2}

    assert a == d
    assert a != c

    # Additional test for equality comparison with non-dict
    e = 'some string'

    assert a != e



# Generated at 2022-06-11 00:56:48.988708
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Testing ImmutableDict equality and hashing.
    """
    d = ImmutableDict(a=1, b=2, c=3)
    assert d == ImmutableDict(a=1, b=2, c=3)
    assert d == ImmutableDict(b=2, c=3, a=1)
    assert d != ImmutableDict(b=2, c=3, a=2)

# Generated at 2022-06-11 00:56:52.421829
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict(dict(a=1, b=2))
    b = ImmutableDict(dict(a=1, b=2))
    if a != b:
        raise Exception('Test failed: {} != {}'.format(a, b))


# Generated at 2022-06-11 00:57:01.636224
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = {'a': 1, 'b': 2, 'c': 3}
    d2 = {'c': 4, 'd': 5, 'e': 6}
    # ImmutableDict is immutable, once created, items in it cannot be updated,
    # so this should not alter the instance
    d1.update(d2)
    assert d1 != d2
    assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}) != ImmutableDict({'c': 4, 'd': 5, 'e': 6})
    assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}) == ImmutableDict({'c': 3, 'b': 2, 'a': 1})

# Generated at 2022-06-11 00:57:05.043823
# Unit test for function is_iterable
def test_is_iterable():
    class FakeIterable(object):
        def __iter__(self):
            pass

    assert not is_iterable(FakeIterable)
    assert is_iterable(FakeIterable())

