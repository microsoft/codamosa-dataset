

# Generated at 2022-06-11 00:47:49.625345
# Unit test for function is_iterable
def test_is_iterable():
    """Unit tests for function is_iterable."""
    from ansible.module_utils.six import string_types, bytes_type

    assert(is_iterable([1, 2, 3]))
    assert(is_iterable(set([1, 2, 3])))
    assert(is_iterable((1, 2, 3)))
    assert(is_iterable(['1', 1, u'3']))
    assert(is_iterable((u'1', 1, '3')))
    assert(is_iterable({'a': 'b', 'c': 'd'}))
    assert(is_iterable({'a': 'b', 'c': 'd'}.items()))
    assert(is_iterable({'a': 'b', 'c': 'd'}.keys()))

# Generated at 2022-06-11 00:47:58.752976
# Unit test for function is_iterable
def test_is_iterable():
    """Unit test for function is_iterable."""
    non_iterables = [3, None, True, False]
    for item in non_iterables:
        assert not is_iterable(item)

    iterables = ['4', 'hello', 'world', b'world', [1, 2], (2, 3), set([1, 2]), {'a': 1, 'b': 2},
                 ImmutableDict({'a': 1, 'c': 3})]
    for item in iterables:
        assert is_iterable(item)
        assert is_iterable(item, include_strings=True)

    assert not is_iterable('world', include_strings=False)

# Generated at 2022-06-11 00:48:08.804943
# Unit test for function is_iterable
def test_is_iterable():
    """Test the is_iterable method."""
    # sequences that should pass the test
    sequences = [
        (),
        [],
        {},
        set(),
        dict(),
    ]
    for sequence in sequences:
        assert is_iterable(sequence)

    # sequences that should fail the test
    non_iterables = [
        None,
        [][:],
        dict()[:],
        set()[:],
        42,
        'string',
        u'unicode string'
    ]
    for non_iterable in non_iterables:
        assert not is_iterable(non_iterable)



# Generated at 2022-06-11 00:48:13.943880
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable([1, 2, 3]))
    assert(is_iterable(('a', 'b')))
    assert(is_iterable({'a': 1, 'b': 2}))
    assert(not is_iterable(123))
    assert(not is_iterable('abc'))


# Generated at 2022-06-11 00:48:23.033949
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict_a = ImmutableDict(dict(a='b'))
    dict_b = ImmutableDict(dict(a='b'))
    dict_c = ImmutableDict(dict(x='y'))
    dict_d = dict(a='b')
    dict_e = 'string is not equivalent to a dict'
    assert dict_a == dict_b # same dict
    assert dict_a == dict_d # equal dict
    assert dict_b != dict_d # not the same dict
    assert dict_b != dict_c # not equal dict
    assert dict_a != dict_e # not a dict


# Generated at 2022-06-11 00:48:35.138223
# Unit test for method __eq__ of class ImmutableDict

# Generated at 2022-06-11 00:48:44.503104
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import operator
    from ntc_rosetta.rosetta import compare_dict

    # Create 2 different ImmutableDicts to test with
    x = (1, 2, (30, 40))
    d1 = ImmutableDict(a=10, b=20, c=x)
    d2 = ImmutableDict(a=10, b=25, c=x)

    # Test for dictionary equality
    compare_dict(d1, d2, {}, operator.eq)
    assert d1 == d2

    # Test the ImmutableDict.__eq__ method
    assert d1.__eq__(d2)

    # Test the ImmutableDict.__hash__ method
    d3 = ImmutableDict(a=10, b=25, c=x)
    assert d2.__hash__() == d

# Generated at 2022-06-11 00:48:49.597804
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(range(5))
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())

    assert not is_iterable(3)
    assert not is_iterable('abc')
    assert not is_iterable(b'abc')



# Generated at 2022-06-11 00:48:55.665039
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({1: 2, 3: 4})
    d2 = ImmutableDict({1: 'a'})
    d3 = {1: 'a'}
    d4 = ImmutableDict({1: 'a'})
    d5 = ImmutableDict({1: 'b'})

    assert d1 == d1
    assert d1 != d2
    assert d2 == d3
    assert d2 == d4
    assert d4 != d5



# Generated at 2022-06-11 00:49:07.561452
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3]) and not is_iterable('123')
    assert is_iterable({'a': 'b', 'c': 'd'}) and not is_iterable({1: 'a', 2: 'b'})
    assert is_iterable('123') and is_iterable('123', include_strings=True) and not is_iterable('123', include_strings=False)
    assert is_iterable({1: 'a', 2: 'b'}) and not is_iterable({'a': 'b', 'c': 'd'})
    assert is_iterable([])
    assert is_string('123') and is_string(u'123')
    # example of how to use assertRaises to test for exception
    from ansible.module_utils.basic import AnsibleModule
    module

# Generated at 2022-06-11 00:49:21.789359
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}) == ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
    assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}) == ImmutableDict({'b': 2, 'c': 3, 'a': 1})  # order is not important
    assert ImmutableDict({'a': 1, 'b': 2, 'c': 3}) != {'a': 1}

# Generated at 2022-06-11 00:49:24.989925
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    assert a == b
    assert b == a



# Generated at 2022-06-11 00:49:35.013877
# Unit test for function is_iterable
def test_is_iterable():
    """This function tests function is_iterable"""
    assert is_iterable('hello')
    assert is_iterable(u'hello')
    assert is_iterable([])
    assert is_iterable(1)
    assert not is_iterable(1, include_strings=True)
    assert not is_iterable(1, include_strings=False)
    assert is_iterable(1, include_strings=False)
    assert not is_iterable(None)
    assert not is_iterable(object())
    assert is_iterable(iter([]))
    assert not is_iterable(iter(''))
    assert not is_iterable(iter(3))
    assert not is_iterable(iter(object()))


# Generated at 2022-06-11 00:49:38.075444
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'b': 2, 'a': 1})

    assert(d1 == d2)



# Generated at 2022-06-11 00:49:45.165532
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({1:2, 3:4})
    b = ImmutableDict({3:4, 1:2})
    assert a == b

    c = ImmutableDict({1:2, 3:4})
    d = {1:2, 3:4}
    assert c == d

    e = ImmutableDict({1:2, 3:4})
    f = ImmutableDict({1:2, 3:4, 5:6})
    assert e != f

    g = ImmutableDict({1:2, 3:4})
    h = ImmutableDict({1:2, 3:7})
    assert g != h



# Generated at 2022-06-11 00:49:56.279813
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(iter([]))
    assert is_iterable(dict(a=1))
    assert is_iterable('abc')
    assert is_iterable(b'abc')
    assert not is_iterable(1)
    assert not is_iterable(10)
    assert not is_iterable(None)
    assert not is_iterable(dict())
    assert not is_iterable(dict(a=1))
    assert not is_iterable(set())
    assert not is_iterable(set([1, 2, 3]))



# Generated at 2022-06-11 00:50:04.358985
# Unit test for function is_iterable
def test_is_iterable():
    """Test the is_iterable function"""

    # test for True
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert not is_iterable(None)

    # test for False
    assert not is_iterable(1)
    assert not is_iterable('test')
    assert not is_iterable((1, 2, 3))
    assert not is_iterable(set([1, 2]))
    assert not is_iterable(dict(a=1, b=2))
    assert not is_iterable(ImmutableDict())
    assert not is_iterable(ImmutableDict(a='b'))



# Generated at 2022-06-11 00:50:15.605164
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Unit test for ImmutableDict class method __eq__

    This tests the method __eq__ which compares the ImmutableDict to another object.
    __eq__ returns True only if the ImmutableDict matches the other object in both contents and their order.
    Otherwise it returns False.
    """

    id1 = ImmutableDict(a=2, b=3, c=4)
    id2 = ImmutableDict(a=2, b=3, c=4)
    id3 = ImmutableDict(a=2, c=4, b=3)
    id4 = ImmutableDict(b=3, c=4, a=2)
    id5 = ImmutableDict(a=2, b=3, d=4)

    assert id1 == id2
    assert not id1 == id3


# Generated at 2022-06-11 00:50:23.337460
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(a=1, b=2)
    d2 = ImmutableDict(b=2, a=1)
    d3 = ImmutableDict(a=1, b=3)
    d4 = ImmutableDict(a=1, b=2)
    assert d1 == d2
    assert d2 == d1
    assert d1 == d4
    assert d4 == d1
    assert d2 == d4
    assert d4 == d2
    assert d1 == d3
    assert d3 == d1


# Generated at 2022-06-11 00:50:28.945966
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(range(10))
    assert not is_iterable(10)

# Unit tests for function is_sequence

# Generated at 2022-06-11 00:50:43.148618
# Unit test for function is_iterable
def test_is_iterable():
    """Test whether types act as expected for is_iterable"""

    assert is_iterable([2, 3, 4])
    assert not is_iterable(1)
    assert is_iterable((2, 3, 4))
    assert is_iterable(x for x in range(4))
    assert is_iterable(set([2, 3, 4]))
    assert is_iterable({x: x for x in range(4)})
    assert not is_iterable(None)
    assert not is_iterable(False)
    assert not is_iterable(b"a")
    assert not is_iterable(u"a")
    assert is_iterable(b"a", include_strings=True)
    assert is_iterable(u"a", include_strings=True)



# Generated at 2022-06-11 00:50:52.911520
# Unit test for function is_iterable
def test_is_iterable():
    class JustIterable(object):
        def __iter__(self):
            return self
    assert is_iterable(JustIterable())
    # Test for is_iterable vs is_sequence
    assert is_iterable(set())
    assert not is_sequence(set())
    assert is_sequence(tuple())
    # Strings and bytes are not iterable according to this function
    # unless include_strings is set to True
    assert not is_iterable('string', include_strings=False)
    assert not is_iterable(b'bytes', include_strings=False)
    # Test for iterable custom class
    class CustomSequence(object):
        def __iter__(self):
            return self
    assert is_iterable(CustomSequence())

# Generated at 2022-06-11 00:51:03.945886
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('') is False
    assert is_iterable(b'') is False
    assert is_iterable('abc') is False
    assert is_iterable(b'abc') is False
    assert is_iterable({}) is True
    assert is_iterable([]) is True
    assert is_iterable(set()) is True
    assert is_iterable(1) is False
    assert is_iterable(object()) is False
    assert is_iterable(u'abc') is False
    assert is_iterable(1, include_strings=True) is False
    assert is_iterable('abc', include_strings=True) is True
    assert is_iterable(u'abc', include_strings=True) is True



# Generated at 2022-06-11 00:51:11.069960
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(())
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable((1, 2, 3))
    assert is_iterable([1, 2, 3])
    assert is_iterable({'a': 1, 'b': 2})
    assert not is_iterable(1)
    assert not is_iterable('a string')
    assert not is_iterable(None)
    assert not is_iterable(Exception('foo'))


# Generated at 2022-06-11 00:51:20.101007
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'a': 1, 'b': 2})
    c = ImmutableDict({'a': 1, 'b': 3})
    d = ImmutableDict({'a': 1})
    e = {'a': 1, 'b': 2}
    assert (a == b)
    assert (a != c)
    assert (b != c)
    assert (a != d)
    assert (b != d)
    assert (c != d)
    assert (a != e)
    assert (b != e)

# Generated at 2022-06-11 00:51:26.035136
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    testDict1 = ImmutableDict({'a': 'a', 'b': 'b', 'c': 'c'})
    testDict2 = ImmutableDict({'a': 'a', 'b': 'b', 'c': 'c'})
    testDict3 = ImmutableDict({'a': 'a', 'b': 'b', 'c': 'd'})
    assert testDict1 == testDict2
    assert not testDict1 == testDict3

# Generated at 2022-06-11 00:51:36.785739
# Unit test for function is_iterable
def test_is_iterable():
    # check everything that we expect to return true
    assert is_iterable([1])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable({'a': 1}.keys())
    assert is_iterable({'a': 1}.values())
    assert is_iterable({'a': 1}.items())

    # check everything that we expect to return false
    assert not is_iterable(1)
    assert not is_iterable(None)
    assert not is_iterable("a")
    assert not is_iterable(False)

    # check that including strings treats strings as iterable
    assert is_iterable("a", include_strings=True)



# Generated at 2022-06-11 00:51:47.737573
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 1, 'b': 2})
    d2 = ImmutableDict({'a': 1, 'b': 2})
    d3 = ImmutableDict({'b': 2, 'a': 1})
    d4 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    d5 = ImmutableDict({'a': 1, 'b': 3})

    assert d1 == d2, 'd1 and d2 must be equal'
    assert d1 == d3, 'd1 and d3 must be equal'
    assert not d1 == d4, 'd1 and d4 must not be equal'
    assert not d1 == d5, 'd1 and d5 must not be equal'

# Generated at 2022-06-11 00:51:56.200449
# Unit test for function is_iterable
def test_is_iterable():
    # Strings
    assert is_iterable('x') is True
    assert is_iterable('x', include_strings=True) is True

    # Dictionaries
    assert is_iterable({'x': 'y'}) is True
    assert is_iterable({'x': 'y'}, include_strings=True) is True

    # Sequences
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable((1, 2, 3)) is True

    # Non iterable
    assert is_iterable(1) is False
    assert is_iterable(None) is False



# Generated at 2022-06-11 00:52:08.363865
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable({'a': 1, None: False})
    assert is_iterable('foobar')
    assert is_iterable(b'foobar')
    assert is_iterable(xrange(7))

    assert not is_iterable(1)
    assert not is_iterable(None)
    assert not is_iterable(NotImplemented)
    assert not is_iterable(True)

    # Custom iterables
    class CustomIterable(object):
        def __iter__(self):
            return iter([1, 2, 3, 4])
    class CustomNotIterable(object):
        def __iter__(self):
            raise TypeError()


# Generated at 2022-06-11 00:52:26.691621
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(1)
    assert is_iterable(u'test')
    assert is_iterable(b'test')
    assert is_iterable(u'test'.encode('utf8'))
    assert not is_iterable(object())


# Generated at 2022-06-11 00:52:38.021983
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable("string"))
    assert(is_iterable("") == True)
    assert(is_iterable(['a', 'b']) == True)
    assert(is_iterable([]) == True)
    assert(is_iterable(tuple(['a', 'b'])) == True)
    assert(is_iterable(()) == True)
    assert(is_iterable(set(['a', 'b'])) == True)
    assert(is_iterable({'a', 'b'}) == True)
    assert(is_iterable({'a':'b'}) == True)
    assert(is_iterable(dict()) == True)
    assert(is_iterable(five.moves.range(5)) == True)
    assert(is_iterable(5) == False)


# Generated at 2022-06-11 00:52:45.290768
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict() == {}
    assert ImmutableDict() == ImmutableDict()
    assert {'a': 'b'} == ImmutableDict(a='b')
    assert ImmutableDict(a='b') == {'a': 'b'}
    assert ImmutableDict(a='b') == ImmutableDict(a='b')
    assert {'a': 'b'} != ImmutableDict(a='c')
    assert ImmutableDict(a='b') != {'a': 'c'}
    assert ImmutableDict(a='b') != ImmutableDict(a='c')
    assert {'a': 'b', 'c': 'd'} == ImmutableDict(a='b', c='d')

# Generated at 2022-06-11 00:52:51.640385
# Unit test for function is_iterable
def test_is_iterable():
    iterable_object = [1, 2, 3, 4, 5]
    assert is_iterable(iterable_object)
    non_iterable_object = 4
    assert not is_iterable(non_iterable_object)
    iterable_string = "Ansible"
    assert is_iterable(iterable_string, True)
    assert not is_iterable(iterable_string)



# Generated at 2022-06-11 00:52:59.089934
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('string') is True
    assert is_iterable(u'unicode') is True
    assert is_iterable('string'.encode()) is True
    assert is_iterable((x for x in range(10))) is True
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable(set([1, 2, 3])) is True
    assert is_iterable({'key': 'value'}) is True
    assert is_iterable(1) is False


# Generated at 2022-06-11 00:53:07.183467
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    m1 = ImmutableDict(a=1)
    m2 = ImmutableDict(a=1)
    assert m1 == m2


    m1 = ImmutableDict(a=1)
    m2 = ImmutableDict(a=1, b=1)
    assert m1 != m2


    m1 = ImmutableDict(a=1)
    m2 = ImmutableDict(a=1, b=1, c=1)
    assert m1 != m2


    m1 = ImmutableDict(a=1)
    assert m1 == m1


    m1 = ImmutableDict(a=1)
    assert m1 != m1.union(dict(b=1))


    m1 = ImmutableDict(a=1)
    m2 = ImmutableD

# Generated at 2022-06-11 00:53:13.276586
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'x': 1, 'y': 2})
    assert d1 == ImmutableDict({'x': 1, 'y': 2})
    assert not d1 == ImmutableDict({'x': 1, 'z': 2})
    assert not d1 == object()
    assert not d1 == {'x': 1, 'y': 2}


# Generated at 2022-06-11 00:53:24.611926
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test a method to compare two ImmutableDict objects"""
    dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict3 = ImmutableDict({'a': 1, 'b': 3, 'c': 3})
    dict4 = {'a': 1, 'b': 2, 'c': 3}

    assert dict1 == dict1
    assert dict1 == dict2
    assert dict1 != dict3
    assert dict1 != dict4

    # Since dict4 is not an ImmutableDict, dict1.__eq__(dict4) returns False
    # dict4.__eq__(dict1) would raise a TypeError
    assert dict1 != dict4

# Generated at 2022-06-11 00:53:27.700168
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable('foo')
    assert is_iterable(['foo', 'bar'])
    assert not is_iterable(None)
    assert not is_iterable(123)



# Generated at 2022-06-11 00:53:33.796346
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    immutable1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    immutable2 = ImmutableDict({'key2': 'value2', 'key1': 'value1'})
    try:
        for key in immutable1:
            if immutable1[key] != immutable2[key]:
                raise Exception('Values of corresponding keys do not match.')
    except Exception:
        raise Exception('Keys do not match.')
    if immutable1 == immutable2:
        pass
    else:
        raise Exception('Immutable dictionaries are not equal.')


# Generated at 2022-06-11 00:54:08.947758
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    b = ImmutableDict({'a': 1, 'b': 2})
    c = ImmutableDict({'a': 1, 'b': 2, 'c': 0})

    assert(a == a)
    assert(a != b)
    assert(a != c)

    assert(b != a)
    assert(b == b)
    assert(b != c)

    assert(c != a)
    assert(c != b)
    assert(c == c)


# Generated at 2022-06-11 00:54:18.861578
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable('ABC') == True)
    assert(is_iterable([1, 2, 3, 4]) == True)
    assert(is_iterable((1, 2, 3, 4)) == True)
    assert(is_iterable({1: 'a', 2: 'b', 3: 'c'}) == True)
    assert(is_iterable(1) == False)
    assert(is_iterable(None) == False)
    assert(is_iterable(['a', 'b'], include_strings=True) == True)
    assert(is_iterable('abc', include_strings=True) == True)
    assert(is_iterable(['a', 'b'], include_strings=False) == True)
    assert(is_iterable('abc', include_strings=False) == False)

# Generated at 2022-06-11 00:54:28.373451
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable('')
    assert not is_iterable(u'')
    assert not is_iterable(b'')
    assert not is_iterable(42)
    assert not is_iterable(None)
    assert not is_iterable(Exception)
    assert not is_iterable(Exception())
    assert not is_iterable(Ellipsis)
    assert not is_iterable(NotImplemented)
    assert is_iterable('', include_strings=True)
    assert is_iterable(u'', include_strings=True)
    assert is_iterable(b'', include_strings=True)
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable({1})

# Generated at 2022-06-11 00:54:32.881744
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('')
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert not is_iterable(object())
    assert not is_iterable(1)



# Generated at 2022-06-11 00:54:37.347973
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test method __eq__ in class ImmutableDict
    """
    immutable_dict_1 = ImmutableDict({'key1': 'value1'})
    immutable_dict_2 = ImmutableDict({'key1': 'value1'})
    assert immutable_dict_1 == immutable_dict_2


# Generated at 2022-06-11 00:54:43.158216
# Unit test for function is_iterable
def test_is_iterable():
    import types
    assert(is_iterable([]))
    assert(is_iterable(tuple()))
    assert(is_iterable(set()))
    assert(is_iterable(types.GeneratorType(None, None, None)))

    assert(not is_iterable(1))
    assert(not is_iterable(object))
    assert(not is_iterable(True))


# Generated at 2022-06-11 00:54:54.150610
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    immutable_dict1 = ImmutableDict({'a': 'a', 'b': 1})
    immutable_dict2 = ImmutableDict({'a': 'a', 'b': 1})
    immutable_dict3 = ImmutableDict({'a': 'a', 'b': 1, 'c': 2})
    dictionary1 = {'a': 'a', 'b': 1}
    dictionary2 = {'a': 'a', 'b': 1}
    dictionary3 = {'a': 'a', 'b': 1, 'c': 2}
    list1 = ['a', 'a', 'b']
    list2 = ['a', 'a', 'b']
    list3 = ['a', 'a', 'b', 'c']
    # list of test cases

# Generated at 2022-06-11 00:55:02.046278
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Test __eq__ method of class ImmutableDict."""
    d = ImmutableDict(foo=True, bar=False)
    # Test
    assert d == d, 'Class instance doesn\'t compare to itself'

    # Test
    assert d == {'foo': True, 'bar': False}, 'Class instance doesn\'t compare to a proper dict'

    # Test
    assert d == ImmutableDict(bar=False, foo=True), 'Class instance doesn\'t compare to a proper ImmutableDict'

    # Test
    assert d != {'foo': False, 'bar': 'test'}, 'Class instance is equal to a different dict'

    # Test
    assert d != ImmutableDict(foo=1, bar=0), 'Class instance is equal to a different ImmutableDict'



# Generated at 2022-06-11 00:55:11.172759
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict(x=1, y=2)
    d2 = ImmutableDict(x=1, y=2)
    d3 = ImmutableDict(y=2, x=1)
    d4 = ImmutableDict(x=1, y=2, z=3)
    d5 = ImmutableDict(a=4, b=5)
    assert d1 == d2
    assert d1 == d3
    assert d1 != d4
    assert d1 != d5
    assert d1 != {'x': 1, 'y': 2}
    assert d1 != MutableMapping([('x', 1), ('y', 2)])

# Generated at 2022-06-11 00:55:22.146649
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'b': 2, 'a': 1}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'b': 2, 'a': 1}) == {'a': 1, 'b': 2}
    assert ImmutableDict({'b': 2, 'a': 1}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'b': 2, 'a': 1}) != ImmutableDict({'a': 1})
    assert ImmutableDict({'b': 2, 'a': 1}) != ImmutableDict({'c': 1, 'b': 2})
    assert Immutable

# Generated at 2022-06-11 00:56:24.108861
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    source = ImmutableDict([('a', 1), ('b', 2)])
    target = ImmutableDict([('a', 1), ('b', 2)])
    assert source == target

    source = ImmutableDict([('a', 1), ('b', 2)])
    target = ImmutableDict([('b', 2), ('a', 1)])
    assert source == target

    source = ImmutableDict([('a', 1), ('b', 2)])
    target = {'a': 1, 'b': 2}
    assert source == target

    source = ImmutableDict([('a', 1), ('b', 2)])
    target = ImmutableDict([('b', 2), ('a', 3)])
    assert source != target

    source = ImmutableDict([('a', 1), ('b', 2)])


# Generated at 2022-06-11 00:56:33.068808
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'c': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})

# Generated at 2022-06-11 00:56:34.491255
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(range(10))
    assert is_iterable(10) is False


# Generated at 2022-06-11 00:56:46.340713
# Unit test for function is_iterable
def test_is_iterable():
    assert(is_iterable(123) is False)
    assert(is_iterable((1, 2, 3)) is True)
    assert(is_iterable([1, 2, 3]) is True)
    assert(is_iterable(set([1, 2, 3])) is True)
    assert(is_iterable({1: 2, 3: 4}) is True)
    assert(is_iterable('hello') is True)
    assert(is_iterable(b'hello') is True)
    assert(is_iterable('hello', include_strings=True) is True)
    assert(is_iterable(b'hello', include_strings=True) is True)
    assert(is_iterable('hello', include_strings=False) is False)

# Generated at 2022-06-11 00:56:51.492336
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(True) is False
    assert is_iterable(42) is False
    assert is_iterable(None) is False
    assert is_iterable('foo') is True
    assert is_iterable({}) is True
    assert is_iterable(set()) is True
    assert is_iterable(xrange(10)) is True


# Generated at 2022-06-11 00:56:58.257025
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Test case: compare ImmutableDictionary with different dict
    dict1 = ImmutableDict({"key1": "value1", "key2": "value2", "key3": "value3"})
    dict2 = {"key1": "value1", "key2": "value2", "key3": "value3"}
    assert dict1 == dict2
    assert dict2 == dict1

    # Test case: compare ImmutableDictionary with different ImmutableDictionary
    dict1 = ImmutableDict({"key1": "value1", "key2": "value2", "key3": "value3"})
    dict2 = ImmutableDict({"key1": "value1", "key2": "value2", "key3": "value3"})
    assert dict1 == dict2
    assert dict2 == dict1

    #

# Generated at 2022-06-11 00:57:02.696419
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable((0, 1))
    assert is_iterable({})
    assert is_iterable("")
    assert is_iterable(u"")
    assert is_iterable(b"")
    assert not is_iterable(0)



# Generated at 2022-06-11 00:57:13.454327
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(dict()) == ImmutableDict(dict())
    assert ImmutableDict(dict()) != dict()
    assert ImmutableDict(dict()) != object()
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)
    assert ImmutableDict(a=1, b=2) == dict(a=1, b=2)
    assert ImmutableDict(a=1, b=2) == {'a':1, 'b':2}
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=2, c=3)
    assert ImmutableDict

# Generated at 2022-06-11 00:57:19.673707
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(())
    assert is_iterable(set())
    assert is_iterable('abc')
    assert is_iterable(u'abc')
    assert is_iterable(b'abc')
    assert is_iterable(u'\u263a')
    assert is_iterable(b'\xe2\x98\xba')
    assert is_iterable(bytearray(b'abc'))
    assert not is_iterable(None)
    assert not is_iterable(1)



# Generated at 2022-06-11 00:57:29.091005
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable({'a': 2, 'b': 3})

    assert not is_iterable({})
    assert not is_iterable(123)
    assert not is_iterable(None)

    assert is_iterable(u'hello')
    assert is_iterable(b'123')

    assert is_iterable(u'hello', include_strings=True)
    assert is_iterable(b'123', include_strings=True)

