

# Generated at 2022-06-11 00:47:49.190547
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) == True
    assert is_iterable([1, 2, 3]) == True
    assert is_iterable(set([1, 2, 3])) == True
    assert is_iterable(set()) == True
    assert is_iterable(dict()) == True
    assert is_iterable(dict([(1, 2)])) == True
    assert is_iterable((1, 2)) == True
    assert is_iterable(x for x in range(0)) == True

    assert is_iterable(1) == False
    assert is_iterable(None) == False
    assert is_iterable(object()) == False
    assert is_iterable(object) == False

# Generated at 2022-06-11 00:48:00.395407
# Unit test for function is_iterable
def test_is_iterable():
    class Iterable(object):
        def __init__(self):
            self.items = [3, 1, 4]
            self.index = 0

        def __iter__(self):
            return self

        def next(self):
            if self.index == len(self.items):
                raise StopIteration
            else:
                self.index = self.index + 1
                return self.items[self.index - 1]

    class NotIterable(object):
        pass

    assert is_iterable(Iterable()) is True
    assert is_iterable(NotIterable()) is False
    assert is_iterable([1, 2, 3]) is True
    assert is_iterable((1, 2, 3)) is True
    assert is_iterable(xrange(1, 10)) is True

# Generated at 2022-06-11 00:48:12.335948
# Unit test for function is_iterable
def test_is_iterable():
    '''
    Make sure is_iterable works correctly on various types of objects
    '''
    assert is_iterable('1234') is True
    assert is_iterable(u'1234') is True
    assert is_iterable(u'1234'.encode('utf-8')) is False
    assert is_iterable(set(u'1234')) is True
    assert is_iterable(list(u'1234')) is True
    assert is_iterable(dict(a=1, b=2, c=3)) is True
    assert is_iterable(12345) is False
    assert is_iterable(('a', 'b', 'c')) is True
    assert is_iterable(tuple(('a', 'b', 'c'))) is True


# Generated at 2022-06-11 00:48:16.133664
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable('test')
    assert is_iterable(set())
    assert is_iterable(1) == False
    assert is_iterable(u'test')



# Generated at 2022-06-11 00:48:26.027358
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'a': 1, 'b': 2, 'c': 3})

    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) != {'a': 1}

    assert ImmutableDict({'a': 1, 'b': 2}) != ImmutableDict({'b': 2, 'a': 1})



# Generated at 2022-06-11 00:48:29.659775
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1, 'b': 2})
    b = ImmutableDict({'b': 2, 'a': 1})

    assert a == b
    assert b == a



# Generated at 2022-06-11 00:48:39.862678
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(a=1) == ImmutableDict(a=1)
    assert ImmutableDict(a=1, b=2) == ImmutableDict(a=1, b=2)
    assert ImmutableDict(a=1) != ImmutableDict(a=2)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=2, b=2)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=3)
    assert ImmutableDict(a=1, b=2) != ImmutableDict(a=1, b=2, c=3)


# Generated at 2022-06-11 00:48:44.423578
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('')
    assert not is_iterable('', include_strings=False)
    assert is_iterable(())
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable({'a': 1})

    assert not is_iterable(1)
    assert not is_iterable(1.0)
    assert not is_iterable(None)
    assert not is_iterable(Exception)

# Generated at 2022-06-11 00:48:54.475403
# Unit test for function is_iterable
def test_is_iterable():
    # Test empty lists, dicts, and strings
    assert is_iterable([])
    assert is_iterable(dict())
    assert is_iterable('')

    # Test numeric types
    assert is_iterable(1)
    assert is_iterable(0.2)
    assert is_iterable(3j)
    assert not is_iterable(1.0)
    assert not is_iterable(1j)
    assert not is_iterable(0)

    # Test container types
    assert is_iterable([1, 2, 3])
    assert is_iterable(dict(a=1, b=2, c=3))
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))

    # Test object types

# Generated at 2022-06-11 00:48:58.771722
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable('test') is True
    assert is_iterable([]) is True
    assert is_iterable({}) is True
    assert is_iterable(set()) is True
    assert is_iterable(1) is False



# Generated at 2022-06-11 00:49:12.814981
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    id_A = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})
    id_B = ImmutableDict({1: 'one', 2: 'two', 3: 'three', 4: 'four'})
    id_C = ImmutableDict({1: 'one', 2: 'two', 3: 'three'})
    assert id_A != id_B
    assert id_A != id_C
    assert id_A == ImmutableDict(id_A)
    assert id_B != id_C
    assert id_B != ImmutableDict(id_B)
    assert id_C == ImmutableDict(id_C)

# Generated at 2022-06-11 00:49:23.086821
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import pytest

    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict() == {}
    assert {} == ImmutableDict()

    assert {'k': 'v'} == ImmutableDict({'k': 'v'})
    assert ImmutableDict({'k': 'v'}) == {'k': 'v'}

    assert {1: 2, 3: 4} == ImmutableDict(((1, 2), (3, 4)))
    assert ImmutableDict(((1, 2), (3, 4))) == {1: 2, 3: 4}

    assert {1: 2, 3: 4} == ImmutableDict([(1, 2), (3, 4)])

# Generated at 2022-06-11 00:49:28.767372
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit tests for ImmutableDict class"""
    test_dict = ImmutableDict({'a': 1, 'b': 2})
    test_dict2 = ImmutableDict({'a': 1, 'b': 2})
    test_dict3 = ImmutableDict({'a': 1, 'b': 3})
    assert test_dict == test_dict2
    assert test_dict != test_dict3



# Generated at 2022-06-11 00:49:39.366670
# Unit test for function is_iterable
def test_is_iterable():
    """Unit test for function is_iterable."""

    # Test for input string
    assert is_iterable('test')
    assert not is_iterable('test', include_strings=False)

    # Test for input list
    assert is_iterable(['test1', 'test2'])
    assert not is_iterable(['test1', 'test2'], include_strings=False)

    # Test for input dictionary
    assert is_iterable({'key1': 'test1', 'key2': 'test2'})
    assert not is_iterable({'key1': 'test1', 'key2': 'test2'}, include_strings=False)

    # Test for input set
    assert is_iterable(set(['test1', 'test2']))

# Generated at 2022-06-11 00:49:45.976014
# Unit test for function is_iterable
def test_is_iterable():
    class A(object):
        def __iter__(self):
            yield 1
    class B(object):
        pass

    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable(A())
    assert is_iterable(xrange(10))
    assert is_iterable(iter(xrange(10)))
    assert not is_iterable(None)
    assert not is_iterable(B())



# Generated at 2022-06-11 00:49:55.824740
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = ImmutableDict({'a': 2, 'b': 4, 'c': 6})
    d2 = ImmutableDict({'a': 2, 'b': 4, 'c': 6})
    assert(d1 == d2)
    assert(d1 == {'a': 2, 'b': 4, 'c': 6})

    d3 = ImmutableDict({'a': 6, 'b': 4, 'c': 2})
    assert(d1 != d3)
    assert(d1 != {'a': 6, 'b': 4, 'c': 2})
    assert(d1 != "This is not a dictionary, it is a string")



# Generated at 2022-06-11 00:50:05.421245
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict(key='value') == ImmutableDict({'key': 'value'})
    assert ImmutableDict(key='value', key2='value2') == ImmutableDict({'key': 'value', 'key2': 'value2'})
    assert ImmutableDict(key='value', key2='value2') != ImmutableDict({'key': 'value', 'key2': 'value22'})
    assert ImmutableDict(key='value', key2='value2') != ImmutableDict({'key2': 'value2', 'key': 'value'})
    assert ImmutableDict(key='value', key2='value2') == ImmutableDict({'key2': 'value2', 'key': 'value'})

# Generated at 2022-06-11 00:50:16.378313
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():

    class Foo:
        pass

    # Equal
    assert ImmutableDict({'key': 'value'}) == ImmutableDict({'key': 'value'})

    # Not equal
    assert not ImmutableDict({'key': 'value'}) == ImmutableDict({'key': 'different value'})
    assert not ImmutableDict({'key': 'value'}) == ImmutableDict()
    assert not ImmutableDict({'key': 'value'}) == ImmutableDict({'different key': 'value'})
    assert not ImmutableDict({'key': 'value'}) == ImmutableDict({'key': 'value', 'other_key': 'other_value'})

# Generated at 2022-06-11 00:50:27.088678
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert(ImmutableDict(a=1, b=2) == ImmutableDict(b=2, a=1))
    assert(ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=3))
    assert(ImmutableDict(a=1, b=2) != ImmutableDict(b=2, a=1, c=3))
    assert(ImmutableDict(a=1, b=2) != ImmutableDict())
    assert(ImmutableDict(a=1, b=2) != MutableMapping())
    assert(ImmutableDict(a=1, b=2) != {'a': 1, 'b': 2})

# Generated at 2022-06-11 00:50:36.478308
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """
    Test __eq__ method of ImmutableDict
    """
    original_dict = ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': True})
    assert original_dict == ImmutableDict({'key3': True, 'key1': 'value1', 'key2': 'value2'})
    assert original_dict != ImmutableDict({'key3': True, 'key1': 'value1'})
    # Check that ImmutableDict returns False if compared to something that is not a Mapping
    assert original_dict != 'abcdefghi'
    assert original_dict != [1, 2, 3, 4]
    assert original_dict != None



# Generated at 2022-06-11 00:50:50.298529
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]) is True
    assert is_iterable({}) is True
    assert is_iterable(set()) is True
    assert is_iterable('') is True
    assert is_iterable(()) is True
    assert is_iterable(True) is False
    assert is_iterable(False) is False
    assert is_iterable(None) is False



# Generated at 2022-06-11 00:50:56.729625
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}
    assert not ImmutableDict({'a': 1, 'b': 2}) == {'b': 2}
    assert not ImmutableDict({'a': 1, 'b': 2}) == {'a': 1}
    assert not ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 3}


# Generated at 2022-06-11 00:51:08.363966
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Note, this test needs to be kept very simple and not depend on any of the modules in Ansible,
    # so we can test this code on Python2.6.
    from ansible.module_utils.six import PY3
    if PY3:
        # In python3, ImmutableDict does not define __eq__, ImmutableDict.__eq__ is inherited fro
        # dict, and ImmutableDict.__hash__ is defined in terms of ImmutableDict.__eq__.
        # Therefore, ImmutableDict can only test equality in python3, not equality and hashability.
        id1 = ImmutableDict(a=1, b=2)
        id2 = ImmutableDict(a=1, b=2)
        id3 = ImmutableDict(a=1, b=3)
        assert id

# Generated at 2022-06-11 00:51:19.997543
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable(())
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable('')
    assert is_iterable(b'')
    assert is_iterable(range(0))
    assert is_iterable(xrange(0))
    assert is_iterable([1, 2, 3])
    assert is_iterable((1, 2, 3))
    assert is_iterable(set([1, 2, 3]))
    assert is_iterable((1, 2, 3))
    assert is_iterable(xrange(3))
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable('abc')
    assert is_iterable(b'abc')


# Generated at 2022-06-11 00:51:28.685369
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({'a': 1, 'b': 2})
    dict2 = ImmutableDict({'a': 1, 'b': 2})
    dict3 = ImmutableDict({'a': 1, 'b': 3})
    dict4 = ImmutableDict({'a': 1, 'b': 3, 'c': 4})
    dict5 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    dict6 = ImmutableDict({'a': 1, 'b': 2, 'c': 4, 'd': 5})
    dict7 = ImmutableDict({'a': 1})
    dict8 = ImmutableDict({'a': 1, 'c': 3})

    assert dict1 == dict2
    assert dict1 != dict3
    assert dict1 != dict4


# Generated at 2022-06-11 00:51:40.406026
# Unit test for function is_iterable
def test_is_iterable():
    from collections import Mapping
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Types with __iter__
    good_iter = ['string', u'string', [1, 2, 3], (1, 2, 3), {1: 'x', 2: 'y'},
                 set([1, 2, 3]), frozenset([1, 2, 3]), Mapping((1, 'a')), MutableMapping]
    for i in good_iter:
        assert is_iterable(i)

    # Types with __getitem__

# Generated at 2022-06-11 00:51:48.504725
# Unit test for function is_iterable
def test_is_iterable():
    # Test cases
    true_cases = [
        True,
        False,
        [],
        {},
        set(),
        (x for x in range(10)),
        u'',
        b'',
    ]
    false_cases = [
        None,
        1,
        'c',
        0.5,
        b'some_bytes',
    ]
    # Check true cases
    for case in true_cases:
        assert is_iterable(case)
    # Check false cases
    for case in false_cases:
        assert not is_iterable(case)


# Generated at 2022-06-11 00:51:52.961577
# Unit test for function is_iterable
def test_is_iterable():
    """Test function is_iterable."""
    assert is_iterable([1, 2, 3])
    assert is_iterable({'a': 1, 'b': 2})
    assert is_iterable('abcdef')
    assert is_iterable(None) is False
    assert is_iterable(1) is False



# Generated at 2022-06-11 00:52:05.684802
# Unit test for function is_iterable
def test_is_iterable():
    # A string should not be considered as iterable.
    assert not is_iterable('string')
    assert not is_iterable(u'string')
    assert not is_iterable(b'string')

    # A list is iterable, as well as a dictionary or a set.
    assert is_iterable([])
    assert is_iterable([i for i in range(10)])
    assert is_iterable({4, 5, 6})
    assert is_iterable({'key': 'value'})

    # An integer is not iterable.
    assert not is_iterable(1)

    # A generator is iterable.
    assert is_iterable((i for i in range(10)))
    assert is_iterable(xrange(10))

    # By default, a string is not iterable.

# Generated at 2022-06-11 00:52:14.496980
# Unit test for function is_iterable
def test_is_iterable():
    expected_results = {
        "that": True,  # test string
        42: True,  # test int
        (1, 2, 3): True,  # test tuple
        [1, 2, 3]: True,  # test list
        set([1, 2, 3]): True,  # test set
        dict(a=1, b=2, c=3): True,  # test dict
        frozenset([1, 2, 3]): True,  # test frozenset
        is_iterable: True,  # test method
        True: False,  # test bool
        None: False,  # test None
        b"bytes": False,  # test bytes
        complex(1, 2): False,  # test complex
        NotImplemented: False,  # test NotImplemented
    }


# Generated at 2022-06-11 00:52:39.234963
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([])
    assert is_iterable((x for x in range(4)))
    assert is_iterable(set())
    assert is_iterable({})
    assert is_iterable(is_iterable)
    assert is_iterable(3) is False
    assert is_iterable(3.14) is False
    assert is_iterable('abc')
    assert is_iterable(b'abc')
    assert is_iterable('abc', include_strings=True)
    assert is_iterable(b'abc', include_strings=True)


# Generated at 2022-06-11 00:52:41.031754
# Unit test for function is_iterable
def test_is_iterable():
    class Foo:
        def __iter__(self):
            pass

    assert is_iterable(Foo())
    assert not is_iterable(Foo)



# Generated at 2022-06-11 00:52:53.329241
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    import copy
    my_dict = {'key1': 'val1', 'key2': 'val2'}
    my_immutable_dict = ImmutableDict(my_dict)
    my_copy_dict = copy.copy(my_dict)
    my_copy_immutable_dict = copy.copy(my_immutable_dict)
    my_deepcopy_dict = copy.deepcopy(my_dict)
    my_deepcopy_immutable_dict = copy.deepcopy(my_immutable_dict)

    assert my_immutable_dict == my_immutable_dict
    assert my_immutable_dict == my_dict
    assert my_immutable_dict == my_copy_dict
    assert my_immutable_dict == my_copy_immutable_dict
    assert my_immutable_dict == my_

# Generated at 2022-06-11 00:53:03.483825
# Unit test for function is_iterable

# Generated at 2022-06-11 00:53:08.013088
# Unit test for function is_iterable
def test_is_iterable():
    """Test is_iterable function."""
    assert is_iterable([])
    assert is_iterable({})
    assert is_iterable(set())
    assert is_iterable((x for x in range(0)))
    assert is_iterable('')
    assert is_iterable('abc')
    assert not is_iterable(1)
    assert not is_iterable(2.0)
    assert not is_iterable(True)
    assert not is_iterable(False)
    assert not is_iterable(None)


# Generated at 2022-06-11 00:53:14.555244
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    d1 = {'one': 1, 'two': 2}
    d2 = {'one': 1, 'two': 2}
    id1 = ImmutableDict(d1)
    id2 = ImmutableDict(d2)
    assert id1 == id2
    d3 = {'one': 1, 'two': 3}
    id3 = ImmutableDict(d3)
    assert id1 != id3

# Generated at 2022-06-11 00:53:20.665658
# Unit test for function is_iterable
def test_is_iterable():
    assert not is_iterable(42)
    assert not is_iterable(None)
    assert is_iterable(dict())
    assert is_iterable(dict(a=2))
    assert is_iterable(list())
    assert is_iterable(list(dict(a=2)))
    assert is_iterable(tuple())
    assert is_iterable(tuple(dict(a=2)))


# Generated at 2022-06-11 00:53:27.306678
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(['a', 'b'])
    assert is_iterable(('a', 'b'))
    assert is_iterable({'a', 'b'})
    assert is_iterable({'a': 'b'})
    assert is_iterable('abc')
    assert is_iterable(b'abc')
    assert not is_iterable(0)
    assert not is_iterable(None)



# Generated at 2022-06-11 00:53:37.480204
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    testing_dict_1 = ImmutableDict({'k1': 'v1', 'k2': 'v2'})
    testing_dict_2 = ImmutableDict({'k1': 'v1', 'k2': 'v2'})
    testing_dict_3 = ImmutableDict({'k1': 'v1', 'k2': 'v3'})
    testing_dict_4 = dict({'k1': 'v1', 'k2': 'v2'})
    testing_dict_5 = 'ImmutableDict({0})'.format(repr(testing_dict_4))
    testing_dict_6 = dict({'k1': 'v1', 'k2': 'v2', 'k3': {'k31': 'v31', 'k32': 'v32'}})
    testing_dict_

# Generated at 2022-06-11 00:53:48.395476
# Unit test for function is_iterable
def test_is_iterable():
    # Test bytes like
    assert not is_iterable(b'abc')
    assert not is_iterable(b'abc', include_strings=True)

    # Test strings
    assert not is_iterable('abc')
    assert is_iterable('abc', include_strings=True)

    # Test tuples
    assert is_iterable(('abc', 'def'))
    assert is_iterable(('abc', 'def'), include_strings=True)

    # Test lists
    assert is_iterable(['abc', 'def'])
    assert is_iterable(['abc', 'def'], include_strings=True)

    # Test sets
    assert is_iterable(set(['abc', 'def']))
    assert is_iterable(set(['abc', 'def']), include_strings=True)

    #

# Generated at 2022-06-11 00:54:27.102983
# Unit test for function is_iterable
def test_is_iterable():
    import collections
    assert is_iterable('')
    assert not is_iterable('')
    assert not is_iterable(dict())
    assert not is_iterable(dict())
    assert is_iterable([])
    assert is_iterable([])
    assert is_iterable(collections.deque())
    assert is_iterable(collections.deque())


# Generated at 2022-06-11 00:54:37.536051
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY3

    x = ImmutableDict({u'unicode': u'unicode_value',
                       u'bytes': b'bytes_value',
                       u'int': 3,
                       u'list': [u'this', u'is', u'a', u'list'],
                       u'tuple': (u'this', u'is', u'a', u'tuple')})


# Generated at 2022-06-11 00:54:48.959957
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    lhs = {}
    rhs = ImmutableDict()
    assert(lhs == rhs)

    lhs = {'test': 1}
    rhs = ImmutableDict({'test': 1})
    assert(lhs == rhs)

    lhs = ImmutableDict({'test': 1})
    rhs = {'test': 1}
    assert(lhs == rhs)

    lhs = ImmutableDict({'test': 1})
    rhs = ImmutableDict({'test': 1})
    assert(lhs == rhs)

    lhs = ImmutableDict({'test': 1})
    rhs = {'test': 2}
    assert(lhs != rhs)

    lhs = ImmutableDict({'test': 1})

# Generated at 2022-06-11 00:54:56.898237
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1}) == ImmutableDict({'a': 1})
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'b': 2, 'a': 1})
    assert ImmutableDict() == ImmutableDict()
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1}) != ImmutableDict({'b': 1})


# Generated at 2022-06-11 00:55:06.039511
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([1, 2, 3])
    assert is_iterable({1: 'a', 2: 'b'})
    assert not is_iterable(None)
    assert not is_iterable(5)
    assert not is_iterable('string')
    assert not is_iterable(u'unicode_string')

    assert is_iterable([1, 2, 3], True)
    assert is_iterable({1: 'a', 2: 'b'}, True)
    assert is_iterable(None, True)
    assert is_iterable(5, True)
    assert is_iterable('string', True)
    assert is_iterable(u'unicode_string', True)


# Generated at 2022-06-11 00:55:14.571368
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""
    test_dict1 = ImmutableDict({'key': 'value'})
    test_dict2 = ImmutableDict({'key': 'value'})
    test_dict3 = ImmutableDict({'key': 'value'})
    exp_result = True
    act_result = (test_dict1.__eq__(test_dict2)) and (test_dict2.__eq__(
        test_dict3)) and (test_dict1.__eq__(test_dict3))
    assert exp_result == act_result


# Generated at 2022-06-11 00:55:25.110569
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    """Unit test for method __eq__ of class ImmutableDict"""

# Generated at 2022-06-11 00:55:29.731631
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable([]), "Empty list should be iterable"
    assert is_iterable((1,2,3)), "Tuple should be iterable"
    assert is_iterable({'key': 'val'}), "Dict should be iterable"
    assert is_iterable('abc'), "String should be iterable"
    assert is_iterable(1), "Integer should be iterable"
    assert not is_iterable(True), "Boolean should not be iterable"
    assert not is_iterable(None), "None should not be iterable"


# Generated at 2022-06-11 00:55:40.317688
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    assert ImmutableDict({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert ImmutableDict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ImmutableDict({'a': 1, 'b': 2}) == {'b': 2, 'a': 1}
    assert ImmutableDict({'a': 1, 'b': 2}) == [('a', 1), ('b', 2)]
    assert ImmutableDict({'a': 1, 'b': 2}) == [('b', 2), ('a', 1)]
    assert ImmutableDict({'a': 1, 'b': 2}) == (('a', 1), ('b', 2))

# Generated at 2022-06-11 00:55:42.690089
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    a = ImmutableDict({'a': 1})
    b = ImmutableDict({'a': 1})
    assert(a.__eq__(b))



# Generated at 2022-06-11 00:56:56.708701
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict(key1="value1", key2="value2", key3="value3")
    dict2 = ImmutableDict(key1="value1", key2="value2", key3="value3")
    dict3 = ImmutableDict(key1="value1", key2="value2")
    dict4 = ImmutableDict(key1="value2", key2="value2", key3="value3")

    assert dict1 == dict2
    assert dict1 != dict3
    assert dict1 != dict4


# Generated at 2022-06-11 00:57:07.412715
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    dict1 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict2 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict3 = ImmutableDict({'a': 1, 'b': 2, 'c': 4})
    dict4 = ImmutableDict({'a': 1, 'b': 2})
    dict5 = ImmutableDict({'a': 1, 'b': 2, 'c': 3})
    dict6 = ImmutableDict({'c': 3, 'a': 1, 'b': 2})

    assert(dict1 == dict2)
    assert(dict2 == dict1)
    assert(dict1 == dict3)
    assert(dict3 == dict1)
    assert(dict1 == dict4)

# Generated at 2022-06-11 00:57:17.045807
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    '''
    Check that ImmutableDict.__eq__ compares the content of the dicts
    '''
    dict_1 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    # Same dict
    dict_2 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    assert dict_1 == dict_2
    # Compare the dict with a dict with an additional key
    dict_3 = ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    assert dict_1 != dict_3
    # Compare the dict with a dict with one of the key missing
    dict_4 = ImmutableDict({'key1': 'value1'})
    assert dict_1 != dict

# Generated at 2022-06-11 00:57:19.439445
# Unit test for function is_iterable
def test_is_iterable():
    assert is_iterable(iter(['a', 'b', 'c']))
    assert not is_iterable('abc')
    assert not is_iterable(3)



# Generated at 2022-06-11 00:57:29.621485
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    # Given
    d1 = ImmutableDict()
    d2 = ImmutableDict()
    d3 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    d4 = ImmutableDict({'key1': 'value1', 'key2': 'value2'})
    d5 = ImmutableDict({'key2': 'value2', 'key1': 'value1'})
    d6 = ImmutableDict({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    d7 = dict()
    # Then
    assert d1 == d2
    assert d3 == d4
    assert d3 == d5
    assert d3 != d6
    assert d1 != d7

# Generated at 2022-06-11 00:57:39.699180
# Unit test for method __eq__ of class ImmutableDict
def test_ImmutableDict___eq__():
    hash_arg = {'a': 'b'}
    non_hash_arg = ['a']
    dict_arg = {'a': 'b'}
    different_dict_arg = {'a': 'c'}
    idict = ImmutableDict(dict_arg)

    if idict.__eq__(hash_arg):
        raise Exception("__eq__ should return false for unhashable argument")

    if idict.__eq__(non_hash_arg):
        raise Exception("__eq__ should return false for unhashable argument")

    if not idict.__eq__(dict_arg):
        raise Exception("__eq__ should return true when hash of arguments is equal")

    if idict.__eq__(different_dict_arg):
        raise Exception("__eq__ should return False when hash of arguments is different")