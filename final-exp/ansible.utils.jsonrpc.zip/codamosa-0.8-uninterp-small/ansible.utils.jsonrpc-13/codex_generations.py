

# Generated at 2022-06-25 13:13:55.401284
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    json_rpc_server_1.register(JsonRpcServer())
    json_rpc_server_1._identifier = '1'
    appropriate_result = {'jsonrpc': '2.0', 'id': '1', 'result': None}
    if json_rpc_server_1.response() != appropriate_result:
        print('FAIL')
    else:
        print('OK')


# Generated at 2022-06-25 13:14:02.485014
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_1 = JsonRpcServer()
    params = {'code': 'SOME CODE', 'message': 'SOME MESSAGE'}
    error = json_rpc_server_1.error(**params)
    error = json_rpc_server_1.error(code=0, message='SOME MESSAGE')
    assert error == {'jsonrpc': '2.0', 'id': 'SOME MESSAGE', 'error': {'code': 0, 'message': 'SOME MESSAGE'}}



# Generated at 2022-06-25 13:14:04.197156
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    print('Testing error...')
    json_rpc_server = JsonRpcServer()
    json_rpc_server.error(code=-32602, message='Invalid params')


# Generated at 2022-06-25 13:14:08.390283
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.response(result='string')
    if isinstance(result, dict):
        assert 'jsonrpc' in result
        assert result['id'] == '0'
        assert result['error'] == None
        assert result['result'] == 'string'


# Generated at 2022-06-25 13:14:13.027631
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    data = '''{"method": "my_method", "params": [], "id": "rpc_call"}'''
    json_rpc_server_0.handle_request(data)


# Generated at 2022-06-25 13:14:16.189201
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # On error, return will be a dict
    assert isinstance(json_rpc_server_0.handle_request(request = "a string"), dict)


# Generated at 2022-06-25 13:14:20.562628
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    response = json_rpc_server_1.response()
    assert(response == {"jsonrpc": "2.0", "id": response["id"], "result": "response"})


# Generated at 2022-06-25 13:14:25.211997
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    try:
        result = json_rpc_server_0.error(arg0)
    except Exception as exc:
        display.vvv(traceback.format_exc())
        assert False, "Can't decode the exception"

    assert result is None, "The function 'error' of JsonRpcServer class returned a wrong result"



# Generated at 2022-06-25 13:14:34.340650
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    msg_1 = '''{'jsonrpc': '2.0', 'id': '1', 'method': 'rpc.test', 'params': [[], {}]}'''
    msg_2 = '''{'jsonrpc': '2.0', 'id': '1', 'method': 'rpc.test', 'params': [[1, 2, 3], {}]}'''
    msg_3 = '''{'jsonrpc': '2.0', 'id': '1', 'method': 'rpc.test', 'params': [[1, 2, 3], {'a': 1}]}'''

# Generated at 2022-06-25 13:14:36.483568
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    jsonrpcserver = JsonRpcServer()
    assert True # TODO: implement your test here


# Generated at 2022-06-25 13:14:45.760772
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    assert json_rpc_server_0.response() == {'id': None, 'jsonrpc': '2.0'}

# Generated at 2022-06-25 13:14:49.038968
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    try:
        json_rpc_server_0.handle_request()
    except Exception as exc:
        display.vvv(traceback.format_exc())
        raise
    return


# Generated at 2022-06-25 13:14:52.862738
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_1 = JsonRpcServer()
    code = 0
    message = 'a'
    data = 'b'
    result = json_rpc_server_1.error(code, message, data)
    assert result == {'jsonrpc': '2.0', 'id': None, 'error': {'code': 0, 'message': 'a', 'data': 'b'}}


# Generated at 2022-06-25 13:15:04.075246
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    def mock_getattr(*args, **kwargs):
        call_order.append(('getattr', args, kwargs))
        return 'mock_getattr'
    def mock_json_loads(*args, **kwargs):
        call_order.append(('json_loads', args, kwargs))
        if args[2] == 'method':
            return 'mock_method'
        return 'mock_json_loads'
    def mock_invalid_request(*args, **kwargs):
        call_order.append(('invalid_request', args, kwargs))
        return 'mock_invalid_request'
    def mock_json_dumps(*args, **kwargs):
        call_order.append(('json_dumps', args, kwargs))

# Generated at 2022-06-25 13:15:05.496050
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request(None)


# Generated at 2022-06-25 13:15:07.724912
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = ""
    response = json_rpc_server_0.handle_request(request_0)


# Generated at 2022-06-25 13:15:16.924797
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    errors = [
        {'code': -32700, 'message': 'Parse error'},
        {'code': -32600, 'message': 'Invalid request'},
        {'code': -32601, 'message': 'Method not found'},
        {'code': -32602, 'message': 'Invalid params'},
        {'code': -32603, 'message': 'Internal error'}
    ]

    for e in errors:
        error = JsonRpcServer().error(e['code'], e['message'])
        assert error['jsonrpc'] == '2.0'
        assert error['id'] == None
        assert error['error']['code'] == e['code']
        assert error['error']['message'] == e['message']


# Generated at 2022-06-25 13:15:23.494929
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    params = (1, 'hello')
    request = {
        'method': 'foo',
        'params': params,
        'jsonrpc': '2.0',
        'id': '123'
    }
    request_json = json.dumps(request)
    response_json = json_rpc_server.handle_request(request_json)
    assert 'error' == json.loads(response_json).get('error')


# Generated at 2022-06-25 13:15:25.545522
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request()


# Generated at 2022-06-25 13:15:28.383784
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    for key in {'foo', 'bar', 'baz'}:
        json_rpc_server_0.objects[key] = JsonRpcServer()


# Generated at 2022-06-25 13:15:34.913873
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    request_0 = '{'
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request(request_0)
    print(var_0)


# Generated at 2022-06-25 13:15:36.978474
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.error(code=None, message=None, data=None)


# Generated at 2022-06-25 13:15:40.857684
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server = JsonRpcServer()

    result = "test"
    var_0 = json_rpc_server.response(result)

    # verify the required parameter 'result' is set
    assert var_0 is not None


# Generated at 2022-06-25 13:15:44.175439
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    item_0 = JsonRpcServer()
    # Exception thrown in case of failure
    try:
        item_0.handle_request()
    except:
        print ("Exception thrown in case of failure")


# Generated at 2022-06-25 13:15:46.357252
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:15:52.201128
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.response()
    assert var_1 == {u'jsonrpc': u'2.0', u'result': None, u'id': None}
    var_2 = json_rpc_server_0.response("")
    assert var_2 == {u'jsonrpc': u'2.0', u'result': u'', u'id': None}


# Generated at 2022-06-25 13:15:53.665257
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    assert True


# Generated at 2022-06-25 13:15:57.038284
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server = JsonRpcServer()
    setattr(json_rpc_server, '_identifier', 'id')
    result = json_rpc_server.error(0, 'bad')
    assert result.get('error')['code'] == 0


# Generated at 2022-06-25 13:16:00.246739
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0._identifier = 1
    var_1 = json_rpc_server_0.error(code = 1, message = 'test')


# Generated at 2022-06-25 13:16:04.232701
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_2 = JsonRpcServer()
    json_rpc_server_2.register(json_rpc_server_2)
    var_1 = json_rpc_server_2.handle_request(b'''{"method": "invalid_request", "params": [], "id": 0}''')

# Generated at 2022-06-25 13:16:17.449553
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    arg1 = "{'result' {'jsonrpc': '2.0'}}"
    json_rpc_server_1 = JsonRpcServer()
    var_1 = json_rpc_server_1.handle_request(arg1)


# Generated at 2022-06-25 13:16:24.836057
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)
    try:
        setattr(json_rpc_server_0, '_identifier', 41)
        result_0 = json_rpc_server_0.response()
    except (cPickle.PicklingError, json.JSONDecodeError) as exc:
        display.vvv(traceback.format_exc())
        error_0 = json_rpc_server_0.internal_error(data=to_text(exc, errors='surrogate_then_replace'))
        response_0 = json.dumps(error_0)
    else:
        if isinstance(result_0, dict) and 'jsonrpc' in result_0:
            response

# Generated at 2022-06-25 13:16:31.695502
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    setattr(json_rpc_server_0, '_objects', set())
    try:
        result = json_rpc_server_0.handle_request("P{\"method\": \"rpc.api.get_abilities\", \"params\": [], \"id\": 123}")
    except Exception as e:
        print("Test case failed")
        print(e)
        raise
    else:
        print("Test case passed")
    finally:
        json_rpc_server_0 = None


# Generated at 2022-06-25 13:16:35.359607
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    try:
        json_rpc_server_0 = JsonRpcServer()
        var_0 = json_rpc_server_0.response()
    except AttributeError as e:
        print('Exception message: %s' % e)


# Generated at 2022-06-25 13:16:40.594301
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)
    # Test with a plain string
    var_1 = json_rpc_server_0.handle_request('invalid_request')
    # Test with a dictionary
    var_2 = json_rpc_server_0.handle_request({'method': 'invalid_request'})


# Generated at 2022-06-25 13:16:42.694784
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.response()


# Generated at 2022-06-25 13:16:45.629419
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Test templates for method response of class JsonRpcServer
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:16:47.582562
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    var_1 = json_rpc_server_1.handle_request()



# Generated at 2022-06-25 13:16:52.654330
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json.load(open('invalid_request.json'))
    var_1 = to_text(var_0, errors='surrogate_then_replace')
    var_2 = json_rpc_server_0.handle_request(var_1)
    var_3 = json.loads(var_2)
    assert var_3['jsonrpc'] == "2.0"

# Generated at 2022-06-25 13:16:59.321617
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.response()
    if result['id'] != json_rpc_server_0._identifier:
        raise AssertionError("result['id'] != json_rpc_server_0._identifier")
    if result['result'] is not None:
        raise AssertionError("result['result'] is not None")
    if result['jsonrpc'] != '2.0':
        raise AssertionError("result['jsonrpc'] != '2.0'")


# Generated at 2022-06-25 13:17:11.215989
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = b'{"jsonrpc": "2.0", "method": "rpc.method", "id": 1}'
    var_2 = json_rpc_server_0.handle_request(var_1)
    var_3 = json.loads(var_2)
    var_4 = var_3['error']
    var_5 = var_4['code']
    var_6 = var_4['message']
    assert var_5 == -32600
    assert var_6 == 'Invalid request'

    json_rpc_server_1 = JsonRpcServer()
    var_7 = b'{"jsonrpc": "2.0", "method": "ssh.config", "id": 1}'
    var_8 = json

# Generated at 2022-06-25 13:17:13.213021
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    result = json_rpc_server_1.response()

# Generated at 2022-06-25 13:17:15.456729
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    var_1 = json_rpc_server_1.headers()


# Generated at 2022-06-25 13:17:18.153594
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    json_rpc_server_0 = JsonRpcServer()

    var_1 = json_rpc_server_0.handle_request('')

    assert var_1 == ''


# Generated at 2022-06-25 13:17:26.270606
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # Test JsonRpcServer.handle_request
    request = json.loads('{ "jsonrpc": "2.0", "method": "rpc.run", "params": [], "id": 0 }')
    # Verify that the error code is -32600
    assert json.loads(json_rpc_server_0.handle_request(request))['error']['code'] == -32600

    request = json.loads('{ "jsonrpc": "2.0", "method": "method.not.found", "params": [], "id": 0 }')
    # Verify that the error code is -32601
    assert json.loads(json_rpc_server_0.handle_request(request))['error']['code'] == -32601



# Generated at 2022-06-25 13:17:31.978136
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.handle_request("""
{
    "jsonrpc": "2.0",
    "method": "register",
    "params": [
        0,
        null,
        { "id": 3, "method": "pause", "params": [ "play", 20 ] },
        [ 4, 5, null ],
        true,
        false
    ]
}
"""
)


# Generated at 2022-06-25 13:17:36.318041
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request("0")
    var_1 = str(var_0)
    var_2 = var_1 == "0"
    assert var_2


# Generated at 2022-06-25 13:17:46.481485
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # set up
    json_rpc_server_0 = JsonRpcServer()

    # test case 1
    var_0 = cPickle.dumps({'jsonrpc': '2.0', 'id': 'None', 'method': 'foo', 'params': ({}, {})})
    var_0 = var_0.replace('\\x00', '')
    var_0 = var_0.replace('\\x01', '')
    var_0 = var_0.replace('\/', '/')
    var_0 = var_0.replace('\'', '"')
    var_0 = var_0.decode('string_escape')
    var_1 = json_rpc_server_0.handle_request(var_0)

    # test case 2

# Generated at 2022-06-25 13:17:48.734698
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.handle_request(request='')


# Generated at 2022-06-25 13:17:52.659857
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = '{"jsonrpc": "2.0", "method": "foobar"}'
    assert json_rpc_server_0.handle_request(request_0) == '{"jsonrpc": "2.0", "id": null, "error": {"code": -32601, "message": "Method not found"}}'

# Generated at 2022-06-25 13:17:59.201055
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    if not is_playbook:
        pytest.skip('skipping non-playbook test')

    json_rpc_server = get_object(JsonRpcServer, 'JsonRpcServer_handle_request')
    json_rpc_server.handle_request('request')

# Generated at 2022-06-25 13:18:05.862662
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    def var_1(this):
        return 'var_1'
    json_rpc_server_0.register(var_1)
    var_2 = json_rpc_server_0.handle_request('{"method":"var_1","params":[],"id":1}')
    print(str(var_2))


if __name__ == "__main__":
    # test_case_0()
    test_JsonRpcServer_response()

# Generated at 2022-06-25 13:18:06.383573
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    pass

# Generated at 2022-06-25 13:18:13.417067
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    # Testing the default value of result
    json_rpc_server_response_var_0 = json_rpc_server_0.response()
    print(json_rpc_server_response_var_0)
    # Testing the value of result as 'test_str_var'
    json_rpc_server_response_var_1 = json_rpc_server_0.response(result='test_str_var')
    print(json_rpc_server_response_var_1)
    # Testing the value of result as 'test_str_var'
    json_rpc_server_response_var_2 = json_rpc_server_0.response(result='test_str_var')

# Generated at 2022-06-25 13:18:19.223437
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    assert json_rpc_server_0.handle_request(json.dumps({"jsonrpc": "2.0", "method": "rpc.echo", "params": ["hello world"], "id": "123"})).rstrip() == '{"jsonrpc": "2.0", "result": "hello world", "id": "123"}'


# Generated at 2022-06-25 13:18:23.832398
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():

    # Arguments
    result = None

    json_rpc_server_0 = JsonRpcServer()

    # Call method
    actual = json_rpc_server_0.response(result)

    # Check call
    var_0 = {}
    var_0['result'] = None
    assert actual == var_0


# Generated at 2022-06-25 13:18:30.738649
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = to_text("""{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "rpc._cli",
  "params": ["show version", True, "text"]
}""")
    var_0 = to_text(var_0)
    var_1 = json_rpc_server_0.handle_request(var_0)
    var_1 = to_text(var_1)
    assert var_1 == to_text("""{
  "jsonrpc": "2.0",
  "id": 1,
  "error": {
    "code": -32600,
    "message": "Invalid request",
    "data": null
  }
}""")
# Unit

# Generated at 2022-06-25 13:18:39.722698
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()


# Generated at 2022-06-25 13:18:43.447948
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()
    assert var_0 == {'jsonrpc': '2.0', 'id': None, 'result': None}


# Generated at 2022-06-25 13:18:51.799203
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    json_rpc_server_1.invalid_request()
    result_0 = json_rpc_server_1.handle_request('{"jsonrpc": "2.0", "id": 1}')
    assert result_0 == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32700, "message": "Parse error"}}'
    result_1 = json_rpc_server_1.handle_request('{"jsonrpc": "2.0", "id": 2, "method": "rpc.method_not_found"}')

# Generated at 2022-06-25 13:19:03.103501
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    json_rpc_server_0 = JsonRpcServer()
    param_0 = None
    ret_0 = json_rpc_server_0.handle_request(param_0)
    local_result_0 = False
    if (ret_0 is None):
        local_result_0 = True
    test_result_0 = local_result_0
    assert test_result_0


# Generated at 2022-06-25 13:19:04.582797
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server = JsonRpcServer()
    json_rpc_server.response()


# Generated at 2022-06-25 13:19:09.963572
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "subtract", "params": [42, 23], "id": 1}'

    response = json_rpc_server.handle_request(request)


test = JsonRpcServer()
test.handle_request('{"jsonrpc": "2.0", "method": "subtract", "params": [42, 23], "id": 1}')

# Generated at 2022-06-25 13:19:14.497929
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Creating a instance of the class
    json_rpc_server_0 = JsonRpcServer()
    # Calling the method response with arguments
    result = None
    try:
        result = json_rpc_server_0.response(result)
    except Exception as e:
        print("Exception when calling JsonRpcServer.response: %s" % e)
        assert False

# Generated at 2022-06-25 13:19:23.000316
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    print("")
    print("Testing handle_request")

    json_rpc_server_0 = JsonRpcServer()
    try:
        json_rpc_server_0.handle_request("")
    except Exception:
        print('Exception raised expected')
        pass
    else:
        assert False
try:
    test_JsonRpcServer_handle_request()
except Exception as exc:
    print('Exception raised expected')
    pass

json_rpc_server_0 = JsonRpcServer()
try:
    request = json.loads(to_text('{"jsonrpc": "2.0", "method": "", "params": {}, "id": "1"}', errors='surrogate_then_replace'))
    var_3 = request.get('method')
except Exception as exc:
    print

# Generated at 2022-06-25 13:19:27.780032
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    #print "test_JsonRpcServer_handle_request"
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.invalid_request()
    var_1 = json_rpc_server_0.handle_request(var_0)

# Generated at 2022-06-25 13:19:33.336153
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0._identifier = ""
    request = b"{\n  \"id\": 1,\n  \"method\": \"initialize_network_device\",\n  \"params\": [\n    {\n      \"host\": \"localhost\",\n      \"port\": 2222\n    }\n  ]\n}"
    json_rpc_server_0.handle_request(request)


# Generated at 2022-06-25 13:19:37.117096
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    result_1 = json_rpc_server_1.response()
    assert isinstance(result_1, dict)
    assert len(result_1) == 3
    assert "jsonrpc" in result_1
    assert "id" in result_1
    assert "result" in result_1


# Generated at 2022-06-25 13:19:46.993070
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = '{"method": "rpc.method", "params": [], "id": 1}'
    var_0 = json_rpc_server_0.handle_request(request_0)
    assert type(var_0) is text_type

    request_1 = '{"method": "rpc.method", "params": []}'
    var_1 = json_rpc_server_0.handle_request(request_1)
    assert type(var_1) is text_type

    request_2 = '{"method": "method", "params": []}'
    var_2 = json_rpc_server_0.handle_request(request_2)
    assert type(var_2) is text_type


# Generated at 2022-06-25 13:19:54.393796
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Test case 0
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request(json.dumps({'jsonrpc': '2.0', 'method': 'echo', 'params': ['Test Case 0'], 'id': 0}))
    # Test case 1
    json_rpc_server_1 = JsonRpcServer()
    json_rpc_server_1.handle_request(json.dumps({'jsonrpc': '2.0', 'method': 'echo', 'params': ['Test Case 1'], 'id': 1}))
    

# Generated at 2022-06-25 13:20:03.902801
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    print("test input: {}")
    # Initialization of object
    json_rpc_server_0 = JsonRpcServer()
    # Call method
    result = json_rpc_server_0.response()


# Generated at 2022-06-25 13:20:09.988091
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    j = JsonRpcServer()
    j.register(JsonRpcServer())
    j.handle_request('')
    j.handle_request('{}')
    j.handle_request('{"method": "handle_request"}')
    j.handle_request('{"method": "handle_request", "params": [], "id": 12}')
    j.handle_request('{"method": "handle_request", "params": []}')

# Generated at 2022-06-25 13:20:12.735926
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Create an instance of JsonRpcServer
    json_rpc_server_0 = JsonRpcServer()
    # Retrieve the method response of class JsonRpcServer
    response_var_0 = json_rpc_server_0.response()

# Generated at 2022-06-25 13:20:15.052627
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    with open(os.path.join(os.path.dirname(__file__),
                            "data/request_0.json"), 'r') as file:
        test_case_0(json.load(file))


# Generated at 2022-06-25 13:20:15.947722
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    test_case_0()

# Generated at 2022-06-25 13:20:18.308844
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request()


# Generated at 2022-06-25 13:20:25.600838
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    test_case = {"method": "rpc.test", "params": [["ssh", "0", "10.1.1.1"], {}], "jsonrpc": "2.0", "id": "0"}
    test_case = json.dumps(test_case)
    json_rpc_server = JsonRpcServer()
    output = json_rpc_server.handle_request(test_case)
    print(output)
    assert(output == '{"jsonrpc": "2.0", "id": "0", "error": {"code": -32600, "message": "Invalid request"}}')


# Generated at 2022-06-25 13:20:34.377122
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

# Generated at 2022-06-25 13:20:36.114592
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Instance creation
    json_rpc_server_0 = JsonRpcServer()

    # Test method response of class JsonRpcServer
    result = json_rpc_server_0.response()


# Generated at 2022-06-25 13:20:39.637810
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.invalid_request()


# Generated at 2022-06-25 13:20:59.105548
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    request = '''
{
    "jsonrpc": "2.0",
    "method": "netconf.get",
    "params": [
        {
            "filter": {
                "config": {
                    "interfaces": {
                        "interface": [
                            {
                                "name": "Ethernet1/1",
                                "mtu": "1454"
                            }
                        ]
                    }
                }
            }
        }
    ],
    "id": "0"
}
'''
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.handle_request(request)

# Generated at 2022-06-25 13:21:01.344410
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response('result')



# Generated at 2022-06-25 13:21:03.441785
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.invalid_request()


# Generated at 2022-06-25 13:21:05.327376
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:21:11.940895
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create instance of class JsonRpcServer with default constructor test
    json_rpc_server_1 = JsonRpcServer()

    # Test method handle_request of class JsonRpcServer
    json_rpc_server_1.register(JsonRpcServer)
    void_ret_value = json_rpc_server_1.handle_request('{"jsonrpc": "2.0", "method": "invalid_request", "params": [], "id": 1}')
    assert void_ret_value == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": null}'


# Generated at 2022-06-25 13:21:18.367856
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    json_rpc_server.register(JsonRpcServer())

    result_0 = json_rpc_server.handle_request('{"id": "0", "method": "server_version", "params": [], "jsonrpc": "2.0"}')
    assert result_0 == '{"jsonrpc": "2.0", "id": "0", "result": "2.0"}'
    print("unit test for method handle_request of class JsonRpcServer: pass")

test_case_0()
test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:21:24.283742
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = '{"jsonrpc": "2.0"}'
    var_2 = json_rpc_server_0.handle_request(var_1)
    # Should be decoded
    assert isinstance(var_2, text_type)
    # Should be valid JSON
    try:
        assert var_2 == json.loads(var_2)
    except json.JSONDecodeError as e:
        fail('JSON parsing failed')

# Generated at 2022-06-25 13:21:26.753255
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.invalid_request()



# Generated at 2022-06-25 13:21:28.829976
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.response()


# Generated at 2022-06-25 13:21:37.703436
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

# Generated at 2022-06-25 13:22:22.960218
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    try:
        test_case_0()
    except Exception as err:
        print ("Caught exception: " + str(err))


# Generated at 2022-06-25 13:22:26.363417
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = None # exception: str
    try:
        var_1 = json_rpc_server_0.handle_request()
    except Exception:
        print("Failed test::test_JsonRpcServer_handle_request")


# Generated at 2022-06-25 13:22:28.954916
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a test JsonRpcServer object
    json_rpc_server_1 = JsonRpcServer()
    # Test parameter 'request'
    json_rpc_server_1.handle_request()


# Generated at 2022-06-25 13:22:32.655756
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    str_0 = json_rpc_server_0.handle_request('{"jsonrpc": "2.0", "method": "rpc.method", "params": null, "id": "1"}')


# Generated at 2022-06-25 13:22:36.905129
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    method = 'handle_request'
    response = json_rpc_server.handle_request(method)
    assert response
    output = json.loads(response)
    assert output['jsonrpc'] == '2.0'
    assert output['id'] == 1
    assert output['result'] == 'pong'


# Generated at 2022-06-25 13:22:42.176955
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = json.loads('{"jsonrpc": "2.0", "id": "an id", "method": "subtract", "params": [42, 23]}')
    # json.loads(s[, encoding[, cls[, object_hook[, parse_float[, parse_int[, parse_constant[, object_pairs_hook[, **kw]]]]]]]])
    # Deserialize s (a str or unicode instance containing a JSON document) to a Python object.
    result_0 = json_rpc_server_0.handle_request(request_0)
    if debug:
        print(result_0)

# Generated at 2022-06-25 13:22:51.587796
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()

    valid_request = b'{"method": "show", "params": [["version"]], "id": 100}'
    assert server.handle_request(valid_request)

    invalid_method = b'{"method": "run", "params": [], "id": 200}'
    assert server.handle_request(invalid_method)

    invalid_params = b'{"method": "get_facts", "params": "ansible", "id": 300}'
    assert server.handle_request(invalid_params)

    invalid_request = b'{"method": "run", "params": [], "id": 400}'
    assert server.handle_request(invalid_request)

    invalid_id = b'{"method": "run", "params": []}'
    assert server.handle_request

# Generated at 2022-06-25 13:22:55.420096
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()
    assert (var_0['id'] == None)
    assert (var_0['jsonrpc'] == '2.0')
    assert (var_0['result'] == None)


# Generated at 2022-06-25 13:23:00.103494
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request("'string_literal'")
    json_rpc_server_0.handle_request(('list_literal',))             # type: ignore
    json_rpc_server_0.handle_request({'dict_literal': 'dict_literal'})

    # Test with invalid request
    json_rpc_server_0.handle_request("'string_literal'")


# Generated at 2022-06-25 13:23:02.547886
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    json_rpc_server.handle_request(request='foo')
