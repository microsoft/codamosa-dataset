

# Generated at 2022-06-25 13:13:52.000875
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    obj_JsonRpcServer_0 = JsonRpcServer()
    # Method handle_request does not exists in class JsonRpcServer
    try:
        obj_JsonRpcServer_0.handle_request
    except AttributeError:
        print("Method handle_request does not exist in JsonRpcServer")

# Unit test with no arguments

# Generated at 2022-06-25 13:13:56.688681
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = b'{"jsonrpc": "2.0", "method": "rpc.x", "id": 1}'
    temp_1 = json_rpc_server_0.handle_request(request_0)
    return temp_1


# Generated at 2022-06-25 13:14:02.782415
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "update", "params": [1,2,3,4,5], "id": "1"}'
    assert json_rpc_server_1.handle_request(request) == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": "1"}'


# Generated at 2022-06-25 13:14:05.220757
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():

    # Setup test object
    json_rpc_server = JsonRpcServer()

    # Invoke method
    result = json_rpc_server.error(None, None)


# Generated at 2022-06-25 13:14:11.147681
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.error(code='code', message='message')
    expected = {'jsonrpc': '2.0', 'id': json_rpc_server_0._identifier,
        'error': {'code': 'code', 'message': 'message'}}
    assert result == expected


# Generated at 2022-06-25 13:14:21.279220
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0._objects.add(text_type)
    json_rpc_server_0.register(binary_type)
    json_rpc_server_0.handle_request(text_type)
    json_rpc_server_0.invalid_params(message=text_type)
    json_rpc_server_0.method_not_found(obj="obj_0")
    json_rpc_server_0.handle_request(request=binary_type)
    json_rpc_server_0.invalid_params(message="message_0")
    json_rpc_server_0.method_not_found()
    json_rpc_server_0._objects.add(binary_type)
    json_

# Generated at 2022-06-25 13:14:24.332316
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    test_instance_0 = JsonRpcServer()
    result_0 = test_instance_0.response()
    assert result_0 == {"id": None, "jsonrpc": "2.0", "result": None}


# Generated at 2022-06-25 13:14:26.554731
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    response = json_rpc_server_0.response(result)
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == '12345'


# Generated at 2022-06-25 13:14:30.029099
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_obj_0 = JsonRpcServer()
    str_0 = "{u'id': 1, u'method': u'handle_request', u'params': ({u'request': 'test_request'},)}"
    str_1 = json.dumps(str_0)
    json_rpc_server_obj_0.handle_request(str_1)



# Generated at 2022-06-25 13:14:33.782662
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    # Response with None value
    result = None
    response = json_rpc_server_0.response(result)
    assert response["result"] == result


# Generated at 2022-06-25 13:14:48.681425
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request("{'params': [1, 2], 'method': 'rpc._getInterfaces', 'jsonrpc': '2.0', 'id': 1}")
    json_rpc_server_0.handle_request("{'params': [1, 2], 'method': '_getInterfaces', 'jsonrpc': '2.0', 'id': 1}")
    json_rpc_server_0.handle_request("{'params': [1, 2], 'method': 'getInterfaces', 'jsonrpc': '2.0', 'id': 1}")


# Generated at 2022-06-25 13:14:50.511563
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    params = (('2',), ({},))
    rpc = json.dumps(dict(method='t', params=params, id=23))
    json_rpc_server_0.handle_request(rpc)


# Generated at 2022-06-25 13:14:56.194432
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    rpc_server_0 = JsonRpcServer()
    setattr(rpc_server_0, '_identifier', '0')
    result = rpc_server_0.response()
    assert result['result'] is None
    assert result['jsonrpc'] == '2.0'
    assert result['id'] == '0'


# Generated at 2022-06-25 13:15:03.754756
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    print("test_JsonRpcServer_response")
    try:
        json_rpc_server_1 = JsonRpcServer()
        id = json_rpc_server_1._identifier = "test"
        result = json_rpc_server_1.response()
        assert(result == {
            "result_type": "pickle",
            "result": "}R\n.",
            "id": id,
            "jsonrpc": "2.0"
        })
    except Exception as e:
        print(e)


# Generated at 2022-06-25 13:15:08.906537
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)

    # Testing with correct parameters
    params = {'code': -32603, 'message': 'Internal error'}
    response = json_rpc_server_0.error(**params)
    assert 'code' in response['error']
    assert 'message' in response['error']
    assert response['error']['code'] == -32603
    assert response['error']['message'] == 'Internal error'


# Generated at 2022-06-25 13:15:14.375836
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Declare the arguments
    request = ['string', 'string', 'string', 'string', 'string']

    # Try to execute the code
    # Assert the expected exception(s) type(s)
    json_rpc_server_0 = JsonRpcServer()

    # Try to execute the code
    # Verify the result
    assert json_rpc_server_0.handle_request(request) == 'string: string'



# Generated at 2022-06-25 13:15:18.771736
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    response = json_rpc_server_0.error(1, 2)
    assert response == json.loads(b'{"jsonrpc": "2.0", "id": null, "error": {"message": "Method not found", "code": -32601}}')


# Generated at 2022-06-25 13:15:23.919212
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(JsonRpcServer)
    json_rpc_server_0.handle_request(json.dumps({'jsonrpc': '2.0', 'method': 'response', 'params': ([], {}), 'id': 0}))


# Generated at 2022-06-25 13:15:30.354368
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():

    # Input parameters:
    method_input_0 = 5
    method_input_1 = 'string'
    method_input_2 = 'string'

    # Output parameters:
    method_output_0 = dict()

    method_0 = JsonRpcServer().error(method_input_0, method_input_1, method_input_2)

    method_assertion_0 = method_output_0

    try:
        assert(method_assertion_0 == method_0)
        print('Test case 0: pass')
    except:
        print('Test case 0: fail')


# Generated at 2022-06-25 13:15:37.501413
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
  # Test case 0
  json_rpc_server_0 = JsonRpcServer()
  request_0 = '{"jsonrpc": "2.0", "method": "rpc.test", "id": "1"}'
  response = json.loads(json_rpc_server_0.handle_request(request_0))
  assert response == {"id": "1", "jsonrpc": "2.0", "error": {"message": "Method not found", "code": -32601}}
  request_1 = '{"jsonrpc": "2.0", "method": "test", "params": [1, 2], "id": "1"}'
  response = json.loads(json_rpc_server_0.handle_request(request_1))

# Generated at 2022-06-25 13:15:49.839403
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    args = []
    kwargs = {}

    # Test with result as int
    json_rpc_server = JsonRpcServer()
    json_rpc_server._identifier = 0
    result = json_rpc_server.response(10)

    assert result['jsonrpc'] == '2.0'
    assert result['id'] == 0
    assert result['result'] == '10'

    # Test with result as dict
    json_rpc_server = JsonRpcServer()
    json_rpc_server._identifier = 0
    result = json_rpc_server.response({'test': 'test'})

    assert result['jsonrpc'] == '2.0'
    assert result['id'] == 0
    assert result['result'] == "{'test': 'test'}"

    # Test with result

# Generated at 2022-06-25 13:15:53.194998
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_string_0 = '{}'
    # Call handle_request with appropriate arguments
    json_rpc_server_0.handle_request(json_string_0)
    

# Generated at 2022-06-25 13:15:54.690177
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # No code was generated for this test method
    # See instructions at the top of the file
    pass


# Generated at 2022-06-25 13:16:01.873315
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = {'jsonrpc': '2.0', 'id': 1, 'method': 'rpc.run', 'params': (['conf t'], {'text': 'show version'}), }
    response_0 = json_rpc_server_0.handle_request(request_0, )
    assert response_0 == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request", "data": null}, "id": 1}'

test_case_0()
test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:16:04.402842
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    request_0 = {}
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request(request_0)


# Generated at 2022-06-25 13:16:10.858521
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    args = []
    kwargs = {}
    json_rpc_server_0 = JsonRpcServer()
    request = '''{
        "jsonrpc": "2.0",
        "method": "echo",
        "params": ["Hello, world!"],
        "id": 1
    }'''
    expected = '''{
        "id": 1,
        "jsonrpc": "2.0",
        "result": "Hello, world!"
    }'''
    actual = json_rpc_server_0.handle_request(request)
    assert expected == actual



# Generated at 2022-06-25 13:16:20.078869
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():

    obj = JsonRpcServer()
    result = obj.response(result='Default result')
    assert result == {'jsonrpc': '2.0', 'id': None, 'result': 'Default result'}

    result = obj.response(result=b'test')
    assert result == {'jsonrpc': '2.0', 'id': None, 'result': 'test'}

    result = obj.response(result=b'test\xff')
    assert result == {'jsonrpc': '2.0', 'id': None, 'result': 'test\ufffd', 'result_type': 'pickle'}

    result = obj.response(result={'result': 'result'})

# Generated at 2022-06-25 13:16:21.601883
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request('{"jsonrpc": "2.0", "method": "echo", "params": ["Hello, World!"], "id": 1}')

# Generated at 2022-06-25 13:16:25.216380
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    result = dict(result = dict(a = 1, b = True, c = "ansible"))
    expected = dict(jsonrpc = "2.0", id = getattr(json_rpc_server_1, '_identifier'),
                    result = dict(a = 1, b = True, c = "ansible"))
    assert json_rpc_server_1.response(result) == expected


# Generated at 2022-06-25 13:16:26.487451
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()



# Generated at 2022-06-25 13:16:30.411242
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    for idx in range(10):
        yield (test_case_0)



# Generated at 2022-06-25 13:16:35.480216
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    request = '{"method":"rpc.echo","id":"1","jsonrpc":"2.0","params":["hello"]}'
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.handle_request(request)
    assert result == '{"jsonrpc": "2.0", "id": "1", "result": "hello"}'


# Generated at 2022-06-25 13:16:37.726024
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request('{"method":"ping"}')


# Generated at 2022-06-25 13:16:47.349020
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0._identifier = 28
    # Test case with no parameters
    response = json_rpc_server_0.response()
    assert response == {'jsonrpc': '2.0', 'id': 28, 'result': None}
    # Test case with parameter
    response = json_rpc_server_0.response("String without special characters")
    assert response == {'jsonrpc': '2.0', 'id': 28, 'result': 'String without special characters'}
    response = json_rpc_server_0.response("String with special characters:  !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")

# Generated at 2022-06-25 13:16:52.143368
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

    var_0 = json_rpc_server_0.header()
    var_1 = json_rpc_server_0.header()
    var_2 = json_rpc_server_0.header()
    var_3 = json_rpc_server_0.header()
    var_4 = json_rpc_server_0.header()
    var_5 = json_rpc_server_0.header()
    var_6 = json_rpc_server_0.header()
    var_7 = json_rpc_server_0.header()
    var_8 = json_rpc_server_0.header()
    var_9 = json_rpc_server_0.header()


# Generated at 2022-06-25 13:16:56.690594
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # <class '__main__.JsonRpcServer'>
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()
    assert type(var_0) == dict
    assert var_0 == {'jsonrpc': '2.0', 'id': None, 'result': None}


# Generated at 2022-06-25 13:16:58.850924
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.handle_request(request)


# Generated at 2022-06-25 13:17:00.763694
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    var_1 = json_rpc_server_1.response(result=None)

# Generated at 2022-06-25 13:17:04.036161
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result_0 = json_rpc_server_0.response()
    assert isinstance(result_0, dict)


# Generated at 2022-06-25 13:17:10.201036
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    data = {
        'jsonrpc': '2.0',
        'id': '6da5a8e8-1f67-4b10-92e5-e8a7fcf0a918',
        'method': 'run_command',
        'params': [
            'show version'
        ]
    }

    request = json.dumps(data)
    response = json_rpc_server_0.handle_request(request)

# Generated at 2022-06-25 13:17:20.901564
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Setup mock
    class MockConnection(object):
        def __init__(self, data=''):
            self.data = data

    connection = MockConnection()

    # Instantiate class
    json_rpc_server_0 = JsonRpcServer()

    # Initialize argument value
    result = 'sfrtTjfI'

    # Set instance attribute
    json_rpc_server_0._identifier = 'trfTjfI'

    # Execute function
    response = json_rpc_server_0.response(result)

    # Verify member variables
    assert response['id'] == 'trfTjfI'
    assert response['result'] == 'sfrtTjfI'


# Generated at 2022-06-25 13:17:25.439504
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    str_0 = json_rpc_server_0.handle_request(b'{"id":1470477827,"method":"test","params":[[],[]]}')
    # '{"jsonrpc": "2.0", "id": {}}'
    assert str_0 == '{"jsonrpc": "2.0", "id": {}}'



# Generated at 2022-06-25 13:17:30.979872
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = to_text(b'{"params": [5], "method": "factorial", "jsonrpc": "2.0", "id": "1"}')
    var_2 = json_rpc_server_0.handle_request(var_1)
    assert var_2 == u'{"jsonrpc": "2.0", "id": "1", "result": "120"}'


# Generated at 2022-06-25 13:17:41.504713
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()

    # Test for response without parameter
    response = json_rpc_server_0.response()
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == 'ansible-test-identifier'
    assert 'result' not in response
    assert 'error' not in response

    # Test for response with result parameter
    response = json_rpc_server_0.response(result=["test"])
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == 'ansible-test-identifier'
    assert response['result'] == "[\"test\"]"
    assert 'error' not in response
    assert 'result_type' not in response

    # Test for response with result parameter as pickle object
   

# Generated at 2022-06-25 13:17:46.917588
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    test_0 = json_rpc_server_0.response()
    assert test_0['id'] == None
    assert test_0['jsonrpc'] == '2.0'
    assert test_0['result'] == None
    test_1 = json_rpc_server_0.response(result='{}')
    assert test_1['id'] == None
    assert test_1['jsonrpc'] == '2.0'
    assert test_1['result'] == '{}'
    test_2 = json_rpc_server_0.response(result={})
    assert test_2['result_type'] == 'pickle'
    test_3 = json_rpc_server_0.response(result=b'{}')

# Generated at 2022-06-25 13:17:50.097520
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.header()
    var_1 = json_rpc_server_0.response()
    assert var_0 == var_1


# Generated at 2022-06-25 13:17:54.537475
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Calling the method
    json_rpc_server_1 = JsonRpcServer()
    json_rpc_server_1._identifier = 0
    var_1 = json_rpc_server_1.response(result=0)
    print(var_1)


# Generated at 2022-06-25 13:17:58.625494
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    request = '{"id": 1, "method": "run", "params": [{"two": "something", "one": "something else"}]}'
    json_rpc_server_0 = JsonRpcServer()

    json_rpc_server_0.handle_request(request)


# Generated at 2022-06-25 13:18:07.799610
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Declare object and data
    json_rpc_server_0 = JsonRpcServer()
    var_0 = b'{"jsonrpc": "2.0", "method": "test", "params": [], "id": 2}'

    # Create test function
    def test_function(a, b, c='test'):
        return c

    json_rpc_server_0.register(test_function)

    # Try/catch block for capturing exceptions

# Generated at 2022-06-25 13:18:14.410777
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    jsonrpc_server = JsonRpcServer()
    jsonrpc_server._identifier = 1
    result = jsonrpc_server.response(result='test')
    assert json.loads(result) == {u'jsonrpc': u'2.0', u'id': 1, u'result': u'test'}
    result = jsonrpc_server.response(result=u'test')
    assert json.loads(result) == {u'jsonrpc': u'2.0', u'id': 1, u'result': u'test'}
    result = jsonrpc_server.response(result=None)
    assert json.loads(result) == {u'jsonrpc': u'2.0', u'id': 1, u'result': None}

# Generated at 2022-06-25 13:18:24.087658
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_1 = JsonRpcServer()
    result_0 = json_rpc_server_0.response()
    result_1 = json_rpc_server_0.response()
    result_2 = json_rpc_server_1.response()


if __name__ == "__main__":
    # Unit tests for method response of class JsonRpcServer
    test_JsonRpcServer_response()

# Generated at 2022-06-25 13:18:27.825890
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    data = "''"
    result = json_rpc_server_0.handle_request(data)
    print(result)


if __name__ == "__main__":
    test_case_0()
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:18:30.742505
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    request_0 = '{"jsonrpc": "2.0", "method": "run", "params": ["test command"], "id": "r0"}'
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request(request_0)


# Generated at 2022-06-25 13:18:35.056400
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Arrange
    json_rpc_server_0 = JsonRpcServer()

    # Act
    var_0 = json_rpc_server_0.response()

    # Assert
    assert var_0 == {'id': None, 'jsonrpc': '2.0', 'result': None}


# Generated at 2022-06-25 13:18:37.987223
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result_0 = json_rpc_server_0.response("Python")
    result_1 = json_rpc_server_0.response("Python")


# Generated at 2022-06-25 13:18:47.260014
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    setattr(json_rpc_server_0, '_identifier', 1)
    json_rpc_server_0.handle_request('{"jsonrpc": "2.0", "method": "rpc.get(\" |# -32768,-32767-32000|\"))", "params": [[], {}], "id": 1}')
    json_rpc_server_0.handle_request('{"jsonrpc": "2.0", "method": "rpc.get(\" |# -32768-32767,-32000|\"))", "params": [[], {}], "id": 1}')

# Generated at 2022-06-25 13:18:52.575022
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    serializer = json.JSONEncoder()
    serializer.encode = lambda obj: obj
    server = JsonRpcServer()
    server.serialize = serializer

    def echo(*args, **kwargs):
        return args, kwargs

    server.register(echo)

    def test():
        request = json.dumps({'jsonrpc': '2.0', 'method': 'echo', 'params': [], 'id': '1'})
        expected = json.dumps({'jsonrpc': '2.0', 'id': '1', 'result': {'result_type': 'pickle', 'result': '\x80\x02]q\x00.'}})
        result = server.handle_request(request)
        assert result == expected

    test()

# Generated at 2022-06-25 13:18:53.418427
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    test_case_0()

# Generated at 2022-06-25 13:18:56.034869
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server = JsonRpcServer()
    b = [1, 2, 3, 4]
    result = json_rpc_server.response(b)
    assert result.get('result') == str(b)


# Generated at 2022-06-25 13:18:58.963852
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    var_1 = json_rpc_server_1.handle_request('"1"')


# Generated at 2022-06-25 13:19:05.784290
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Create an instance for testing
    json_rpc_server_0 = JsonRpcServer()

    # Send test input data and get generated output
    var_0 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:19:10.478592
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    dict_0 = {}
    dict_0['jsonrpc'] = '2.0'
    dict_0['id'] = None
    dict_0['result'] = None
    dict_0['result_type'] = 'pickle'
    assert json_rpc_server_0.response() == dict_0


# Generated at 2022-06-25 13:19:15.042983
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    # Setting the new attribute
    setattr(json_rpc_server_0, "_identifier", "abcdef")
    # Testing the first use case with all required parameters
    json_rpc_server_0.response()
    # Testing the use case with extra / optional parameter
    json_rpc_server_0.response("abcdef")

# Generated at 2022-06-25 13:19:16.840359
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    try:
        json_rpc_server_0.response("result")
    except AttributeError:
        display.display("Failed")
    finally:
        display.display("Passed")


# Generated at 2022-06-25 13:19:18.617197
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    #target = JsonRpcServer()
    #result = target.response()
    #assert isinstance(result, )
    pass


# Generated at 2022-06-25 13:19:22.224255
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Create instance of class
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.response()
    assert 'jsonrpc' in result
    assert 'id' in result
    assert 'result' in result


# Generated at 2022-06-25 13:19:26.449696
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.response()
    # try:
    #     print(var_1)
    # except UnicodeDecodeError as exc:
    #     print("Exception: {}".format(exc))


# Generated at 2022-06-25 13:19:30.130129
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = to_text(json_rpc_server_0.response(result=None))
    assert result == '{"id": 0, "jsonrpc": "2.0", "result": null}'


# Generated at 2022-06-25 13:19:37.530513
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json.dumps({'params': (None, None), 'id': 1, 'jsonrpc': '2.0', 'method': '_handle_request'})
    var_2 = json_rpc_server_0.handle_request(var_1)
    print(var_2)
    var_3 = json.dumps({'params': (None, None), 'id': 1, 'jsonrpc': '2.0', 'method': '_handle_request1'})
    var_4 = json_rpc_server_0.handle_request(var_3)
    print(var_4)


# Generated at 2022-06-25 13:19:42.814249
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    json_rpc_server_1._identifier = "test"
    var_1 = json_rpc_server_1.response()
    json_rpc_server_1._identifier = "test"
    var_2 = json_rpc_server_1.response(result="test")


# Generated at 2022-06-25 13:19:49.789251
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    print("#####")
    json_rpc_server_0 = JsonRpcServer()
    print("####")
    var_0 = json_rpc_server_0.response(result=None)
    print("#####")


# Generated at 2022-06-25 13:19:57.435539
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Cleanup previous instances
    JsonRpcServer._objects.clear()

    # Create new instance
    json_rpc_server_0 = JsonRpcServer()

    # Register object
    json_rpc_server_0.register(json_rpc_server_0)

    # Invoke method
    var_0 = json_rpc_server_0.handle_request('{"jsonrpc": "2.0", "method": "header", "id": "id"}')

    # Check result
    assert var_0 == r'{"jsonrpc": "2.0", "result": "{}", "id": "id"}'

# Generated at 2022-06-25 13:19:59.974375
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server = JsonRpcServer()
    assert (json_rpc_server.response('str') == {'jsonrpc': '2.0', 'id': 'str', 'result': 'str'})


# Generated at 2022-06-25 13:20:02.477157
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request('{}')


# Generated at 2022-06-25 13:20:10.648043
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)
    text_0 = json_rpc_server_0.handle_request("""{"jsonrpc": "2.0", "method": "response", "params": [], "id": 1196343681}""")
    var_0 = JsonRpcServer()
    var_0._identifier = 1196343681
    text_1 = json.dumps({'jsonrpc': '2.0', 'id': 1196343681})
    assert text_0 == text_1


# Generated at 2022-06-25 13:20:13.353871
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.header()
    var_1 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:20:21.943230
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    str_0 = 'jzdkl'
    jsonrpc_1 = '2.0'
    method_2 = 'get_config'
    params_3 = [{  }]
    id_4 = '2'

    json_str = '{"jsonrpc":"' + jsonrpc_1 + '","method":"' + method_2 + '","params":' + str(params_3) + ',"id":"' + id_4 + '"}'
    result_5 = json_rpc_server_0.handle_request(json_str)
    print(result_5)


if __name__ == '__main__':
    test_case_0()
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:20:26.088860
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server = JsonRpcServer()

    expected = { 'jsonrpc': '2.0', "result": "TEST CASE 0"}
    expected['id'] = getattr(json_rpc_server, '_identifier')

    assert json_rpc_server.response("TEST CASE 0") == expected


# Generated at 2022-06-25 13:20:27.965697
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:20:34.193460
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # test case 1
    json_rpc_server_1 = JsonRpcServer()
    json_rpc_server_1._objects = [0]
    var_1 = json_rpc_server_1.handle_request(b'{"jsonrpc": "2.0", "method": "execute", "params": [], "id": "1"}')
    assert text_type(var_1) == '{"result": "", "id": "1", "jsonrpc": "2.0"}'


# Generated at 2022-06-25 13:20:44.322655
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result_0 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:20:46.402857
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    requests.get("http://localhost:8080/test_case_1?args={}&kwargs={}")


# Generated at 2022-06-25 13:20:50.330493
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request('{"jsonrpc": "2.0", "method": "update", "params": [1,2,3,4,5], "id": 10}')
    print(var_0)


# Generated at 2022-06-25 13:20:55.995838
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = """{
			"id": 1,
			"jsonrpc": "2.0",
			"method": "rpc.test",
			"params": {}
		}"""
    var_0 = json_rpc_server_0.handle_request(var_0)


# Generated at 2022-06-25 13:20:58.132117
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.handle_request(var_0)


# Generated at 2022-06-25 13:21:04.723797
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Ran 8 tests in 0.000s
    #
    # OK
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.header()
    var_2 = 'jsonrpc'
    var_3 = var_1[var_2]
    assert var_3 == '2.0'
    var_4 = 'id'
    var_5 = var_1[var_4]
    assert var_5 == '<property object at 0x1087cadd0>'


# Generated at 2022-06-25 13:21:11.939541
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.error(code=-32600, message='Invalid request', data=None)
    var_1 = json_rpc_server_0.handle_request('[{\"jsonrpc\":\"2.0\",\"method\":\"_\",\"id\":\"2\"}]')
    assert var_1 == var_0
    var_2 = json_rpc_server_0.handle_request('invalid')
    assert var_2 == '[{"jsonrpc": "2.0", "id": null, "error": {"code": -32700, "message": "Parse error", "data": null}}]'


# Generated at 2022-06-25 13:21:15.083701
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    ro_json_rpc_server_0 = JsonRpcServer()
    var_1 = ro_json_rpc_server_0.response()
    assert var_1 == {'jsonrpc': '2.0', 'id': None, 'result': None}


# Generated at 2022-06-25 13:21:19.702044
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    first_param = {'jsonrpc': '2.0', 'method': 'rpc.login', 'params': ["admin", "admin"], 'id': 0}
    first_param = json.dumps(first_param)
    second_param = None
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request(first_param, second_param)


# Generated at 2022-06-25 13:21:22.013252
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request('{}')


# Generated at 2022-06-25 13:21:45.457667
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    setattr(json_rpc_server_0, '_identifier', "36zS")
    var_0 = json_rpc_server_0.response("   ")
    assert type(var_0) is dict
    assert var_0['id'] is "36zS"
    assert var_0['jsonrpc'] is "2.0"
    assert var_0['result'] is "   "


# Generated at 2022-06-25 13:21:50.168608
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_2 = JsonRpcServer()
    var_2 = json.dumps({"id":"id_2","method":"method_2","params":[{"args_3": "args_3"}]})
    var_3 = json_rpc_server_2.handle_request(var_2)
    #print(var_2)
    #print(var_3)

if __name__ == '__main__':
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:21:56.666922
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0._objects
    json_rpc_server_0.register(None)
    var_1 = json_rpc_server_0._objects
    var_2 = json_rpc_server_0._identifier
    delattr(json_rpc_server_0, '_identifier')
    var_3 = json_rpc_server_0._identifier
    # Try to call non-existant method
    json_rpc_server_0.handle_request(None)
    # Call an existant method
    json_rpc_server_0.handle_request(None)


# Generated at 2022-06-25 13:22:00.274852
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server__handle_request_jrpc_request = {'method': 'ping'}
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request(json_rpc_server__handle_request_jrpc_request)


# Generated at 2022-06-25 13:22:05.516740
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.header()
    json_rpc_server_0._identifier = var_1
    var_2 = json_rpc_server_0.response()
    assert var_2 == {'jsonrpc': '2.0', 'id': var_1.get('id'), 'result': None}


# Generated at 2022-06-25 13:22:09.151450
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    json_rpc_server_1.register(json_rpc_server_1)
    request_0 = '{"jsonrpc": "2.0", "method": "header", "params": [], "id": 1}'
    var_0 = json_rpc_server_1.handle_request(request_0)
    assert var_0 == '{"jsonrpc": "2.0", "id": 1, "result": "{\\"jsonrpc\\": \\"2.0\\", \\"id\\": 1}"}'
    request_1 = '{"jsonrpc": "2.0", "method": "response", "params": [], "id": 3}'

# Generated at 2022-06-25 13:22:13.186705
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server = JsonRpcServer()
    obj =  {'jsonrpc': '2.0', 'id': '', 'result': 'test'}
    assert json_rpc_server.response('test') == obj


if __name__ == '__main__':
    test_case_0()
    test_JsonRpcServer_response()

# Generated at 2022-06-25 13:22:17.196947
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request("{\"jsonrpc\": \"2.0\", \"method\": \"foobar\", \"params\": [[\"arg1\", 2, 3], {\"key\": \"value\"}], \"id\": 2}")


# Generated at 2022-06-25 13:22:18.263714
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    sys.exit(json_rpc_server_0.handle_request())

# Generated at 2022-06-25 13:22:26.626432
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    # set attribute
    json_rpc_server_0._identifier = "test"
    assert json_rpc_server_0._identifier == "test"
    # test method
    var_0 = json_rpc_server_0.response()
    assert var_0 == {"id": "test", "jsonrpc": "2.0", "result": None}
    # delete attribute
    del json_rpc_server_0._identifier
    # test method
    var_0 = json_rpc_server_0.response(result="test")
    assert var_0 == {"id": None, "jsonrpc": "2.0", "result": "test"}
    # test method

# Generated at 2022-06-25 13:22:50.037262
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request('')


# Generated at 2022-06-25 13:22:51.811039
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request()

# Generated at 2022-06-25 13:22:53.134093
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    jsonRpcServer = JsonRpcServer()
    jsonRpcServer.handle_request()

# Generated at 2022-06-25 13:22:56.415607
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = '{"method": "test.test", "params": [], "id": 1}'
    var_1 = json_rpc_server_0.handle_request(var_0)


# Generated at 2022-06-25 13:22:58.020825
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    var_1 = json_rpc_server_1.handle_request()

# Generated at 2022-06-25 13:23:00.735814
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.header()
    var_2 = json_rpc_server_0.response(result=var_1)
    # Make sure the result contains the correct data
    assert var_2[0] == var_1


# Generated at 2022-06-25 13:23:03.372115
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.handle_request("foo")


# Generated at 2022-06-25 13:23:11.821987
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # Test case 1
    request = json.dumps({'method': 'rpc.method', 'params': [[], {}], 'id': '1'})
    response = json_rpc_server_0.handle_request(request)
    assert response == (
        '{"id": "1", "jsonrpc": "2.0", "error": {"message": "Method not found", "code": -32601}}'
    )
    # Test case 2
    request = json.dumps({'method': 'system.method', 'params': [[], {}], 'id': '1'})
    response = json_rpc_server_0.handle_request(request)

# Generated at 2022-06-25 13:23:19.756593
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = json.loads(to_text(request, errors='surrogate_then_replace'))
    method_0 = request_0.get('method')
    if method_0.startswith('rpc.') or method_0.startswith('_'):
        error_0 = json_rpc_server_0.invalid_request()
        response_0 = json.dumps(error_0)
    args_0, kwargs_0 = request_0.get('params')
    setattr(json_rpc_server_0, '_identifier', request_0.get('id'))
    rpc_method_0 = None
    for obj in json_rpc_server_0._objects:
        rpc_method

# Generated at 2022-06-25 13:23:25.048801
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = '{}'
    var_0 = json_rpc_server_0.handle_request(request_0)
    var_1 = json_rpc_server_0.header()
    var_2 = json_rpc_server_0.invalid_request()
    var_3 = json_rpc_server_0.error('-32600', 'Invalid request')
    var_4 = json_rpc_server_0.handle_request(request_0)
