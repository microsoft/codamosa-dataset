

# Generated at 2022-06-25 13:13:47.173936
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = result()
    assert isinstance(json_rpc_server_0.response(result), dict)


# Generated at 2022-06-25 13:13:49.947090
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()

    # testcase - check for None
    json_rpc_server_0.response( None )


# Generated at 2022-06-25 13:13:52.124268
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    result = JsonRpcServer().response()
    assert result == {"jsonrpc": "2.0", "id": None, "result": None}


# Generated at 2022-06-25 13:13:56.854282
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    json_rpc_server_1._identifier = 255
    expected = {'result': '', 'jsonrpc': '2.0', 'id': 255}
    result = json_rpc_server_1.response()
    assert result == expected


# Generated at 2022-06-25 13:13:59.443529
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    obj = JsonRpcServer()
    code = 500
    message = ""
    data = ""
    assert obj.error(code, message, data)


# Generated at 2022-06-25 13:14:02.404630
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    global json_rpc_server_0
    json_rpc_server_0 = JsonRpcServer()
    json.dumps(json_rpc_server_0.handle_request())


# Generated at 2022-06-25 13:14:08.925974
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    test_code = -32602
    test_message = 'Invalid params'
    test_data = {'key': 'value'}
    test_golden_result = {
        'jsonrpc': '2.0',
        'error':
            {
                'code': -32602,
                'message': 'Invalid params',
                'data': {'key': 'value'}
            },
        'id': json_rpc_server_0._identifier
    }

    test_result = json_rpc_server_0.error(test_code, test_message, test_data)

    assert test_result == test_golden_result, test_result


# Generated at 2022-06-25 13:14:15.780797
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    rpc_method = getattr(json_rpc_server_0, "response")
    setattr(json_rpc_server_0, "response")
    assert rpc_method(result="result") == {'jsonrpc': '2.0', 'id': getattr(json_rpc_server_0, '_identifier'), 'result_type': 'pickle', 'result': 'result'}


# Generated at 2022-06-25 13:14:20.389308
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.response(result="")
    assert result == {"id": None, "jsonrpc": "2.0", "result": ""}


# Generated at 2022-06-25 13:14:25.422368
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    try:
        json_rpc_server_0 = JsonRpcServer()
        json_rpc_server_0.handle_request({'params': (list(), {}), 'id': 1, 'method': 'get_facts', 'jsonrpc': '2.0'})
    except NameError as e:
        raise Exception("NameError in JsonRpcServer_handle_request: {}".format(e))


# Generated at 2022-06-25 13:14:45.883411
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    try:
        print("start test_JsonRpcServer_error")
        json_rpc_server_0 = JsonRpcServer()
        result = json_rpc_server_0.error(-1, 'test')
        print("test_JsonRpcServer_error result: {}".format(result))
    except Exception as e:
        print("test_JsonRpcServer_error Exception: {}".format(str(e)))


# Generated at 2022-06-25 13:14:51.527894
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_1 = JsonRpcServer()
    code_1 = -32603
    message_1 = 'Internal error'
    data_1 = 'error'
    result_1 = json_rpc_server_1.error(code_1, message_1, data_1)
    assert isinstance(result_1, dict)
    assert result_1 == {"jsonrpc": "2.0", "error": {"data": "error", "message": "Internal error", "code": -32603}}


# Generated at 2022-06-25 13:14:57.025853
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '''{'method': 'run_command', 'params': [], 'id': 1}'''
    result = json_rpc_server_0.handle_request(request)
    assert result == ''


# Generated at 2022-06-25 13:15:06.407751
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

# Generated at 2022-06-25 13:15:09.029013
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    assert json_rpc_server_0
    result = json_rpc_server_0.response()
    assert result is None


# Generated at 2022-06-25 13:15:14.067155
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = {}
    result_type = "pickle"
    response = json_rpc_server_0.response(result)
    assert response.get('jsonrpc') == "2.0"
    assert response.get('result') == result
    assert response.get('result_type') == result_type


# Generated at 2022-06-25 13:15:21.077789
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = "{\"jsonrpc\": \"2.0\", \"method\": \"rpc.run\", \"params\": [\"show config\"], \"id\": 1}"
    result = json_rpc_server_0.handle_request(request)
    assert result == "{\"jsonrpc\": \"2.0\", \"error\": {\"code\": -32601, \"message\": \"Method not found\"}, \"id\": 1}"


# Generated at 2022-06-25 13:15:23.057900
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request("")


# Generated at 2022-06-25 13:15:30.029248
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    setattr(json_rpc_server_1, '_identifier', u'abc')
    json_rpc_server_1.response(u'foo')
    json_rpc_server_1.response(5)
    json_rpc_server_1.response(5.0)
    json_rpc_server_1.response(True)
    json_rpc_server_1.response(False)
    json_rpc_server_1.response([])
    json_rpc_server_1.response({})


# Generated at 2022-06-25 13:15:37.230771
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    parm_request_1 = '{"method": "rpc.foo", "params": [[], {}], "id": "abc123"}'
    var_return_2 = json_rpc_server_1.handle_request(parm_request_1)
    parm_request_3 = '{"method": "rpc._foo", "params": [[], {}], "id": "abc123"}'
    var_return_4 = json_rpc_server_1.handle_request(parm_request_3)
    parm_request_5 = '{"method": "foo", "params": [[], {}], "id": "abc123"}'
    var_return_6 = json_rpc_server_1.handle_request(parm_request_5)

# Generated at 2022-06-25 13:15:54.299493
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.dosomething", "params": [], "id": null}'
    assert json_rpc_server_0.handle_request(request) == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": null}'

# Generated at 2022-06-25 13:15:56.373634
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request(request='foo')


# Generated at 2022-06-25 13:15:57.640051
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result_0 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:16:06.568226
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create an instance of JsonRpcServer.
    json_rpc_server_0 = JsonRpcServer()

    #  Try to parse the JSON RPC data
    try:
        request = json.loads(to_text(request, errors='surrogate_then_replace'))
    except Exception as exc:
        error = json_rpc_server_0.parse_error(data=to_text(exc, errors='surrogate_then_replace'))
        response = json_rpc_server_0.error(error)
        return json.dumps(response)

    #  Validate that the data is a proper request

# Generated at 2022-06-25 13:16:08.304779
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    print("Unit test for method response of class JsonRpcServer")
    print("Testing with empty parameter")
    test_case_0()


# Generated at 2022-06-25 13:16:17.004008
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Creating object instance of class JsonRpcServer
    json_rpc_server = JsonRpcServer()

    # Getting the instance attribute '_identifier'
    identifier = getattr(json_rpc_server, '_identifier', None)

    # Test if '_identifier' of class JsonRpcServer is equal to None
    assert identifier == None

    # Constructing a dict type object with different key-value pairs.
    request = {"method": "", "id": "", "params": []}

    # Trying to call the method 'handle_request' of the instance 'json_rpc_server'
    result = json_rpc_server.handle_request(request)

    # Test if 'result' is not None
    assert result != None


# Generated at 2022-06-25 13:16:21.932802
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    request = {"method":"rpc.test","params":[[1,2,3],{"abc": [1,2]}],"id":1}
    json_rpc_server = JsonRpcServer()
    result = json_rpc_server.handle_request(request)
    assert result == '{"error": {"code": -32600, "message": "Invalid request"}, "id": 1, "jsonrpc": "2.0"}'


# Generated at 2022-06-25 13:16:23.762533
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request("request")


# Generated at 2022-06-25 13:16:33.486154
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    request = """{
  "jsonrpc": "2.0",
  "method": "rpc.echo",
  "id": 1,
  "params": {
    "args": [
      "Hello world!"
    ],
    "kwargs": {
      "null": null,
      "true": true,
      "false": false,
      "int": 123,
      "float": 123.456,
      "list": [
        1,
        2,
        3
      ],
      "dict": {
        "foo": "bar"
      }
    }
  }
}"""

    json_rpc_server_0 = JsonRpcServer()

    result = json_rpc_server_0.handle_request(request)


# Generated at 2022-06-25 13:16:37.280882
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()

    expected = json.dumps(json_rpc_server_0.header())
    actual = json.dumps(json_rpc_server_0.response())
    assert expected == actual


# Generated at 2022-06-25 13:16:59.946183
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    request = "json.dumps"

    try:
        json_rpc_server_1.handle_request(request)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 13:17:04.036137
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = ''
    # Python3 unicode error
    if False:
        request = '{}'

    json_rpc_server_0.handle_request(request)

# unit tests

# Generated at 2022-06-25 13:17:08.221562
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    request = '''{
    "params": [[], {}],
    "jsonrpc": "2.0",
    "id": 1482101488734,
    "method": "get_config"
}'''
    assert json_rpc_server_1.handle_request(request)


# Generated at 2022-06-25 13:17:13.460667
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Test with an argument that is not a dict instance
    request = '{}'

    json_rpc_server_1 = JsonRpcServer()
    result_2 = json_rpc_server_1.handle_request(request)
    if result_2 != '{"id": null, "jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}}':
        raise Exception('TEST FAIL : test_JsonRpcServer_handle_request')


# Generated at 2022-06-25 13:17:19.173520
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [], "id": 0}'
    result = json_rpc_server_0.handle_request(request)
    assert result == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 0}'


# Generated at 2022-06-25 13:17:24.597118
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    # Setup mocks
    json_rpc_server_1._identifier = 'ansible'
    result = 'abcdef'

    # Invoke method
    response = json_rpc_server_1.response(result)

    # Check for correct result
    assert response == {'jsonrpc': '2.0', 'id': 'ansible', 'result_type': 'pickle', 'result': result}



# Generated at 2022-06-25 13:17:29.551767
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    param_0 = '{"jsonrpc": "2.0", "method": "rpc.echo", "params": [], "id": 0}'
    result_expected = '{"id":0,"jsonrpc":"2.0"}'
    result_actual = json_rpc_server_0.handle_request(param_0)
    result_actual_natural = natural_sort(result_actual)
    result_expected_natural = natural_sort(result_expected)
    assert result_natural_actual == result_expected_natural

# Generated at 2022-06-25 13:17:32.685735
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    """
    Test method handle_request of class JsonRpcServer
    """
    json_rpc_server_1 = JsonRpcServer()
    json_rpc_server_1.handle_request(request="request")


# Generated at 2022-06-25 13:17:43.361918
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "update", "params": [1,2,3,4,5], \
               "id": "1"}'
    json_rpc_server.handle_request(request=request)

    request = '{"jsonrpc": "2.0", "method": "_update", "params": [1,2,3,4,5], \
               "id": "1"}'
    json_rpc_server.handle_request(request=request)

    request = '{"jsonrpc": "2.0", "method": "rpc.update", "params": [1,2,3,4,5], \
               "id": "1"}'

# Generated at 2022-06-25 13:17:47.596525
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    args = {"request": "request"}
    kwargs = {}
    # Can't run test because we don't know what data to provide for request
    try:
        json_rpc_server_0.handle_request(**args)
    except Exception:
        pass


# Generated at 2022-06-25 13:18:23.721788
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    json_rpc_server_0 = JsonRpcServer()
    ansible_module = AnsibleModule(
        argument_spec = dict()
    )
    base_class = AnsibleModule
    method = 'handle_request'
    request = '{}'
    json_rpc_server_0.register(base_class)
    class_ansible_module = getattr(json_rpc_server_0, '_objects')
    assert test_JsonRpcServer_handle_request_call(ansible_module, method, class_ansible_module) == json_rpc_server_0.handle_request(request)

# Method call

# Generated at 2022-06-25 13:18:25.773481
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request(request)


# Generated at 2022-06-25 13:18:31.729694
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    try:
        json_rpc_server = JsonRpcServer()
    except Exception as exc:
        print('UNEXPECTED EXCEPTION: %s' % exc)

    assert json_rpc_server is not None

    # Test with invalid JSON
    try:
        # Assign Parameter
        request = '{'
        json_rpc_server.handle_request(request)
        assert False, "Expected an exception"
    except TypeError as exc:
        print('EXPECTED EXCEPTION: TypeError : %s' % exc)
    except Exception as exc:
        print('UNEXPECTED EXCEPTION: %s' % exc)

    # Test with valid JSON

# Generated at 2022-06-25 13:18:39.814849
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create an instance of class JsonRpcServer
    json_rpc_server_0 = JsonRpcServer()
    # Test with a valid request
    request = '{"jsonrpc": "2.0", "method": "echo", "params": "Hello World", "id": 1}'
    response = '{"jsonrpc": "2.0", "result": "Hello World", "id": 1}'
    assert response == json_rpc_server_0.handle_request(request)
    # Test with an invalid request
    request = '{"invalid_json_request": "Hello World", "id": 1}'
    assert json_rpc_server_0.handle_request(request)


# Generated at 2022-06-25 13:18:42.903422
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    request = {}
    json_rpc_server_0 = JsonRpcServer()
    response = json_rpc_server_0.handle_request(request)
    display.display(response)


# Generated at 2022-06-25 13:18:46.697915
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = {'jsonrpc': '2.0', 'method': '', 'params': ({}, {}), 'id': ''}
    json_rpc_server_0.handle_request(request_0)


# Generated at 2022-06-25 13:18:53.390416
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)
    data = '''{
    "jsonrpc": "2.0",
    "method": "internal_error",
    "params": [],
    "id": "1"
}'''
    expected = '''{
    "jsonrpc": "2.0",
    "id": "1",
    "error": {
        "code": -32603,
        "message": "Internal error"
    }
}'''
    assert json_rpc_server_0.handle_request(data) == expected



# Generated at 2022-06-25 13:18:55.734128
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

    result = json_rpc_server_0.handle_request()
    assert isinstance(result, text_type) == True 


# Generated at 2022-06-25 13:19:01.980604
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    request = '''
        {'params': [[], {}], 'method': 'get_network_resources', 'jsonrpc': '2.0', 'id': '7'}
        '''
    json_rpc_server.handle_request(request)


if __name__ == '__main__':
    test_case_0()
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:19:06.352691
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    args = []
    kwargs = {}
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.handle_request(*args, **kwargs)
    assert result == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": null}'


# Generated at 2022-06-25 13:19:38.338746
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "generate_request", "params": [], "id": 1}'
    assert json_rpc_server_0.handle_request(request) == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-25 13:19:41.882321
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = {"method": "text_to_dict", "params": [], "id": 1}
    json_rpc_server_0.handle_request(request)


# Generated at 2022-06-25 13:19:50.879882
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = '{"jsonrpc": "2.0", "method": "cli", "params": [{"unit":1, "cmd":"sh ver"}], "id": 3}'

# Generated at 2022-06-25 13:19:55.425548
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = ''
    try:
        assert json_rpc_server_0.handle_request(request)
    except Exception as exc:
        display.vvv(traceback.format_exc())
        assert False, 'unexpected exception happened: {}'.format(exc)
    else:
        assert True


# Generated at 2022-06-25 13:19:57.705516
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    assert json_rpc_server
    json_rpc_server.handle_request()


# Generated at 2022-06-25 13:19:59.651768
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    rpc_method = getattr(json_rpc_server_0, method)
    json_rpc_server_0.handle_request()


# Generated at 2022-06-25 13:20:03.016374
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request('test_value_1')
    data = 'test_value_2'
    json_rpc_server_0.handle_request(data)


# Generated at 2022-06-25 13:20:08.353671
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

    # Call handle_request with incorrect argument
    args = dict(arg_1 = [1, 2, 3])
    kwargs = dict(kwarg_1 = 'abc', kwarg_2 = 9.99)
    result = json_rpc_server_0.handle_request('arg', *args, **kwargs)
    assert result is None


# Generated at 2022-06-25 13:20:15.741250
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = '''{
        "jsonrpc": "2.0",
        "method": "foobar",
        "params": [],
        "id": "3fa4b4fa-5640-4d4c-a39a-c75777eddec0"
    }'''
    assert json_rpc_server_0.handle_request(request_0) == '{\n    "code": -32601,\n    "id": "3fa4b4fa-5640-4d4c-a39a-c75777eddec0",\n    "jsonrpc": "2.0",\n    "message": "Method not found"\n}'


# Generated at 2022-06-25 13:20:20.424422
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    request = "{'jsonrpc': '2.0', 'id': '6495c09f-d8e2-4040-9b33-f27b7083f2a6', 'method': 'system.connect', 'params': []}"
    json_rpc_server_1.handle_request(request)


# Generated at 2022-06-25 13:20:53.708332
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    request_json_data = """"""
    json_rpc_server_0 = JsonRpcServer()
    try:
        json.loads(json_rpc_server_0.handle_request(request_json_data))
    except TypeError:
        pass


# Generated at 2022-06-25 13:20:55.703195
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request()




# Generated at 2022-06-25 13:21:00.013387
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

    # Test response type
    response = json_rpc_server_0.handle_request('{"jsonrpc": "2.0", "method": "test_method_0", "params": [{"arg1": "val1"}], "id": 1}')
    assert(isinstance(response, str))


# Generated at 2022-06-25 13:21:03.316543
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = """"""
    returned_value_0 = json_rpc_server_0.handle_request(request_0)
    assert returned_value_0


# Generated at 2022-06-25 13:21:11.347871
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # Test with a valid request
    json_rpc_request = b"""{"jsonrpc": "2.0", "method": "method", "params": ["a", "b", "c", "d"], "id": "0"}"""
    assert json_rpc_server_0.handle_request(json_rpc_request) == b"""{"jsonrpc": "2.0", "id": "0", "result": null}"""
    # Test with a simple bad request
    json_rpc_request = b"""{"jsonrpc": "2.0", "method": "method", "params": ["a", "b", "c", "d"], "id": "0"}"""

# Generated at 2022-06-25 13:21:15.306610
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request('{"params": [[], {}], "method": "rpc._rpc_reply", "id": "87814f7d-c3b3-4b9c-8e1c-51d05fdb2b17"}')


# Generated at 2022-06-25 13:21:18.514406
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    tmp = JsonRpcServer()
    request = json.dumps({"id": 1, "method": "echo", "params": ["foo"]})
    result = tmp.handle_request(request)
    assert result == '{"id": 1, "result": "foo"}'


# Generated at 2022-06-25 13:21:21.613396
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # request: str
    request = ""
    # No Exception should be raised
    json_rpc_server_0.handle_request(request)



# Generated at 2022-06-25 13:21:26.181629
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # Test response with method_not_found
    request = '{"jsonrpc":"2.0","method":"foo","id":1,"params":[1,2,3]}'
    resp = json_rpc_server_0.handle_request(request)
    assert "Method not found" in resp


# Generated at 2022-06-25 13:21:35.404576
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

    # bad JSON request
    request = '{"method": "foobar"}'
    expected_result = '{"error": {"code": -32700, "message": "Parse error"}, "id": None, "jsonrpc": "2.0"}'
    assert json_rpc_server_0.handle_request(request) == expected_result

    # method not found
    request = '{"jsonrpc": "2.0", "method": "foobar", "id": 1}'
    expected_result = '{"error": {"code": -32601, "message": "Method not found"}, "id": 1, "jsonrpc": "2.0"}'
    assert json_rpc_server_0.handle_request(request) == expected_result

    # internal

# Generated at 2022-06-25 13:22:14.179873
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

    # Test with missing or empty param: request

    display.display(json_rpc_server_0.handle_request(), screen_only=True)

    # Test with valid value(s) for param: request

    # Test with invalid values for param: request
    # display.display(json_rpc_server_0.handle_request(request=None), screen_only=True)



# Generated at 2022-06-25 13:22:22.851111
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    method = 'rpc.method'
    args = ['params']
    kwargs = 'params'
    request_0 = {'method':method, 'params':[args, kwargs]}
    request_0_json = json.dumps(request_0)
    response_0 = json_rpc_server_0.handle_request(request_0_json)
    response_0_json = json.loads(response_0)
    assert response_0_json['id'] == None
    assert response_0_json['jsonrpc'] == '2.0'
    assert response_0_json['error'] == {'code': -32600, 'message': 'Invalid request', 'data': None}


# Generated at 2022-06-25 13:22:26.835477
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    rpc_request_0 = json.loads('{"method": "set_hostname", "params": [{"hostname": "localhost"}], "jsonrpc": "2.0", "id": 1}')
    json_rpc_server_0.handle_request(rpc_request_0)


# Generated at 2022-06-25 13:22:34.270973
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

    # Test with invalid (parse error) request
    request = """
        {
            "jsonrpc": "2.0",
            "method": "create_bash_script",
            "params": {
                "src": "/etc/ansible/roles/xos_bootstrap_synchronizer/files/bootstrap_script.bash",
                "dest": "/home/vagrant/bootstrap_script.bash"
            },
            "id": "xxx"
        }
    """
    res = json_rpc_server_0.handle_request(request)
    display.display(res)
    assert 'Parse error' in res

# Generated at 2022-06-25 13:22:41.369037
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

    # Assigning the argument 'False' to a variable
    # (line 714)
    # Getting the type of 'False' (line 714)
    False_227951 = module_type_store.get_type_of(stypy.reporting.localization.Localization(__file__, 714, 20), 'False')
    # Assigning a type to the variable 'result' (line 714)
    module_type_store.set_type_of(stypy.reporting.localization.Localization(__file__, 714, 12), 'result', False_227951)
    
    
    
    # Call to bool(...): (line 715)
    # Processing the call arguments (line 715)
    
    # Call to get(

# Generated at 2022-06-25 13:22:50.665008
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.echo", "params": [1, 2], "id": 0}'
    result = json_rpc_server_0.handle_request(request)
    assert result == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": 0}', "Invalid request"

    request = '{"jsonrpc": "2.0", "method": "_echo", "params": [1, 2], "id": 1}'
    result = json_rpc_server_0.handle_request(request)

# Generated at 2022-06-25 13:22:58.459699
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    json_rpc_server_1._identifier = '1'
    
    # Test case
    # result = json_rpc_server_1.handle_request('{"method":"echo","params":["foo","bar"],"id":1}')
    # AssertionError: '{"jsonrpc": "2.0", "id": "1", "result": "foobar"}' != '{"jsonrpc": "2.0", "id": "1", "result": "barfoo"}'
    # - {"jsonrpc": "2.0", "id": "1", "result": "foobar"}
    # + {"jsonrpc": "2.0", "id": "1", "result": "barfoo"}
    # ?                          ++++++++
    


# Generated at 2022-06-25 13:22:59.250142
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()


# Generated at 2022-06-25 13:23:07.061481
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    data = '''{"id": "__ansible_request_0", "method": "rpc.run", "params": {"_ansible_module_name": "command", "cmd": "show version"}}'''
    # expected:
    result = '''{"id": "__ansible_request_0", "jsonrpc": "2.0", "error": {"code": -32600, "data": null, "message": "Invalid request"}}'''
    # actual:
    response = json_rpc_server_0.handle_request(data)
    assert response == result


# Generated at 2022-06-25 13:23:13.560867
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    method = 'rpc.run'
    request = '{"params": [[], {"host": "ansible.example.org", "port": 22, "user": "test", "pass": "test", "transport": "cli", "timeout": 30, "become": "yes"}], "id": "b87cac743a5711e9a7b800e04f3bc7bc", "jsonrpc": "2.0", "method": "rpc.run"}'
    json_rpc_server_0.handle_request(request)
