

# Generated at 2022-06-25 13:13:56.732110
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()

    # set up parameters used in the test
    code = -32001
    message = 'TestString'
    data = 'TestString'

    # run the test
    JsonRpcServer_error_retval = json_rpc_server_0.error( code,  message, data)

    # assert return code
    assert JsonRpcServer_error_retval is not None

    # assert return type
    assert isinstance(JsonRpcServer_error_retval, dict)


# Generated at 2022-06-25 13:14:00.245223
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()

    # Call method error of object json_rpc_server_0

# Generated at 2022-06-25 13:14:08.094292
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Create a new instance of the 'JsonRpcServer' class
    json_rpc_server_0 = JsonRpcServer()
    # Create a new instance of the 'JsonRpcServer' class
    json_rpc_server_1 = JsonRpcServer()
    # Create a new instance of the 'JsonRpcServer' class
    json_rpc_server_2 = JsonRpcServer()
    # Create a new instance of the 'JsonRpcServer' class
    json_rpc_server_3 = JsonRpcServer()
    # Create a new instance of the 'JsonRpcServer' class
    json_rpc_server_4 = JsonRpcServer()
    # Create a new instance of the 'JsonRpcServer' class
    json_rpc_server_5 = Json

# Generated at 2022-06-25 13:14:09.408398
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    test_case_0()

# Generated at 2022-06-25 13:14:11.147406
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    assert 1


# Generated at 2022-06-25 13:14:21.279286
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    request = {"jsonrpc": "2.0", "id": "1", "method": "hello", "params": [2, 3]}
    expected = '{"error": {"code": -32600, "message": "Invalid request"}, "id": "1", "jsonrpc": "2.0"}'
    actual = json_rpc_server.handle_request(json.dumps(request))
    assert actual == expected
    request = {"jsonrpc": "2.0", "id": "2", "method": "_hello", "params": [2, 3]}
    expected = '{"error": {"code": -32600, "message": "Invalid request"}, "id": "2", "jsonrpc": "2.0"}'

# Generated at 2022-06-25 13:14:26.452518
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = '{"jsonrpc": "2.0", "method": "echo", "params": []}'
    response_0 = json_rpc_server_0.handle_request(request_0)
    #assert response_0 == '{"id": null, "jsonrpc": "2.0", "result": ""}'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:14:30.758551
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server = JsonRpcServer()
    assert json_rpc_server.error(1, 'test_message') == {
        'jsonrpc': '2.0', 'id': None,
        'error': {'code': 1, 'message': 'test_message'}
    }


# Generated at 2022-06-25 13:14:33.686874
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.error(2.0, 'message')


# Generated at 2022-06-25 13:14:38.215260
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    try:
        assert True
    except AssertionError as exc:
        display.vvv(repr(exc))
    json_rpc_server_0.error(code=-32700, message='Parse error', data=None)


# Generated at 2022-06-25 13:14:51.358963
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # Test case 0
    setattr(json_rpc_server_0, '_identifier', 'var_0')
    var_0 = json_rpc_server_0.handle_request('{"id":"var_0","params":[],"method":"rpc.ping"}')
    assert var_0 == '{"jsonrpc": "2.0", "id": "var_0", "result": "{\\\\"jsonrpc\\\\": \\\\"2.0\\\\", \\\\"result\\\\": \\\\"pong\\\\", \\\\"id\\\\": \\\\"var_0\\\\"}"}'
    # Test case 1
    setattr(json_rpc_server_0, '_identifier', 'var_0')
    var_0 = json_rpc_server

# Generated at 2022-06-25 13:14:52.720092
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    print("TEST CASE 0")
    test_case_0()


# Generated at 2022-06-25 13:14:55.307426
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Test case 0 is calling the method with 'method'='__new__'
    test_case_0()


# Generated at 2022-06-25 13:14:58.176542
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.internal_error()

# Generated at 2022-06-25 13:15:02.116303
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    error = server.error(-32603, 'Internal error')

    assert error == {'jsonrpc': '2.0', 'id': server._identifier, 'error': {'code': -32603, 'message': 'Internal error'}}


# Generated at 2022-06-25 13:15:06.622960
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    var_1 = {'method': 'method_not_found'}
    var_2 = to_text(json.dumps(var_1), errors='surrogate_then_replace')
    var_3 = json_rpc_server_0.handle_request(var_2)
    var_4 = to_text(var_3, errors='surrogate_then_replace')

# Generated at 2022-06-25 13:15:08.039257
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    test_case_1()
    test_case_2()

# Generated at 2022-06-25 13:15:14.416467
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Initialize JsonRpcServer object
    json_rpc_server_1 = JsonRpcServer()
    # Declare parameter result
    test_result = None
    # setattr(_identifier, self._identifier)
    json_rpc_server_1._identifier = None
    # Test default value
    assert(json_rpc_server_1._identifier == None)
    # Execute method response
    test_result = json_rpc_server_1.response(result=None)


# Generated at 2022-06-25 13:15:22.706244
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    arg_0 = {"result_type": "pickle", "id": 1, "result": "aW1wb3J0IGNoYW5nZXI\n", "jsonrpc": "2.0"}
    arg_1 = {"result_type": "pickle", "id": 1, "result": "aW1wb3J0IGNoYW5nZXI=\n", "jsonrpc": "2.0"}

    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.response(result=arg_1)
    assert arg_0 == test_case_0()


# Generated at 2022-06-25 13:15:29.117074
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    try:
        json_rpc_server_1 = JsonRpcServer()
        var_1 = json_rpc_server_1.handle_request("{'jsonrpc': '2.0', 'method': '', 'params': {}, 'id': '0'}")
    except Exception as exc:
        display.vvv(traceback.format_exc())
        error = json_rpc_server_1.internal_error(data=to_text(exc, errors='surrogate_then_replace'))
        var_1 = json.dumps(error)


# Generated at 2022-06-25 13:15:38.742589
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.error(code=-32603,message='Internal error')
    assert len(var_0) == 3
    assert var_0['id'] == None
    assert var_0['jsonrpc'] == '2.0'
    assert len(var_0['error']) == 2
    assert var_0['error']['code'] == -32603
    assert var_0['error']['message'] == 'Internal error'


# Generated at 2022-06-25 13:15:44.832096
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    request = {'params': [['ansible-test'], {}], 'jsonrpc': '2.0'}

    reply = server.handle_request(json.dumps(request))
    assert json.loads(reply) == {'error': {'code': -32603, 'message': 'Internal error'}, 'jsonrpc': '2.0', 'id': None}


# Generated at 2022-06-25 13:15:48.386514
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request('{"method": "get_config_defaults", "id": null, "params": []}')
    print(var_0)


# Generated at 2022-06-25 13:15:50.348588
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:15:53.730583
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # Test for a dummy return value
    var_1 = json_rpc_server_0.handle_request('{"id": 0, "jsonrpc": "2.0", "params": [[1], {}], "method": "test"}')
    if var_1 != '{"id": 0, "jsonrpc": "2.0"}':
        raise Exception("Unexpected return value for method handle_request")


# Generated at 2022-06-25 13:15:57.721114
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Set up test environment
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.internal_error()

    # Perform the test
    var_0 = json_rpc_server_0.handle_request(var_0)

    # Check test results
    assert var_0 == 'internal error'


# Generated at 2022-06-25 13:15:59.750698
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.error()


# Generated at 2022-06-25 13:16:04.606247
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0._identifier = "test"
    var_0 = json_rpc_server_0.response()
    var_1 = json_rpc_server_0.response("test")
    var_2 = json_rpc_server_0.response((2, 3))


# Generated at 2022-06-25 13:16:12.954926
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Test default value for attribute 'result_type' is ''
    json_rpc_server_1 = JsonRpcServer()
    assert json_rpc_server_1.header()['result_type'] == ''
    # Test value of attribute 'result_type' is 'pickle' if 'result' object is not string
    json_rpc_server_2 = JsonRpcServer()
    json_rpc_server_2.response('abc')
    assert json_rpc_server_2.header()['result_type'] == ''
    json_rpc_server_3 = JsonRpcServer()
    json_rpc_server_3.response({'a':'b'})
    assert json_rpc_server_3.header()['result_type'] == 'pickle'


# Generated at 2022-06-25 13:16:19.637950
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)

    text_0 = json.dumps({'method': 'internal_error', 'id': 1, 'jsonrpc': '2.0'})
    text_1 = json_rpc_server_0.handle_request(text_0)
    assert type(text_1) is str
    var_1 = json.loads(text_1)
    print(var_1)


# Generated at 2022-06-25 13:16:25.994206
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = binary_type()
    json_rpc_server_0.handle_request(var_1)

# Generated at 2022-06-25 13:16:29.357850
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = {'params':[], 'method': 'handle_request', 'id': 1}
    json_rpc_server_0.handle_request(request)


# Generated at 2022-06-25 13:16:31.664078
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.internal_error()

# Generated at 2022-06-25 13:16:36.431619
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.response()
    assert type(var_1) == dict
    assert var_1 == {'jsonrpc': '2.0', 'id': json_rpc_server_0._identifier, 'result': ''}


# Generated at 2022-06-25 13:16:38.715534
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    with pytest.raises(KeyError):
        json_rpc_server_0 = JsonRpcServer()
        var_0 = json_rpc_server_0.response()

# Generated at 2022-06-25 13:16:40.834610
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.response()


# Generated at 2022-06-25 13:16:45.671863
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.error(code=-32603, message='Internal error', data=None)
    assert var_0 == {'jsonrpc': '2.0', 'error': {'code': -32603, 'message': 'Internal error'}, 'id': None}


# Generated at 2022-06-25 13:16:50.767100
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    request = '{"params": [["hello_world"], {}], "method": "run", "jsonrpc": "2.0", "id": 0}'
    var_1 = json_rpc_server_1.handle_request(request)
    assert var_1 == '{"jsonrpc": "2.0", "result": "hello_world", "id": 0}'


# Generated at 2022-06-25 13:16:53.433466
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    rpc_server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'id': '0', 'method': '_test', 'params': [1,2]})
    response = rpc_server.handle_request(request)
    assert json.loads(response)['error']['code'] == -32601


# Generated at 2022-06-25 13:16:56.922234
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    result = server.error(code=0, message='foo')

    assert result == {"jsonrpc": "2.0", "id": None, "error": {'code': 0, 'message': 'foo'}}


# Generated at 2022-06-25 13:17:10.279598
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    json_rpc_server_0 = JsonRpcServer()
    request_0 = '{"jsonrpc":"2.0","method":"'
    request_1 = '","id":0,"params":["foo"]}'
    request_0 = request_0 + request_1
    json_rpc_server_0.handle_request(request_0)

    request_0 = '{"jsonrpc":"2.0","method":"a_method_does_not_exist","id":1,"params":["foo"]}'
    json_rpc_server_0.handle_request(request_0)

    request_0 = '{"jsonrpc":"2.0","method":"a_method_does_not_exist","id":1,"params":[]}'
    json_rpc_server_0.handle_request(request_0)

   

# Generated at 2022-06-25 13:17:11.968867
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:17:15.422404
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.header()
    with pytest.raises(AttributeError):
        json_rpc_server_0.response(result=None)


# Generated at 2022-06-25 13:17:17.435577
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:17:18.625864
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # TODO: Auto-generated testing stub.
    pass


# Generated at 2022-06-25 13:17:26.627504
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Create an instance of JsonRpcServer class
    json_rpc_server_2 = JsonRpcServer()

    # set the id attribute of json_rpc_server_2 to var_0
    var_0 = None
    setattr(json_rpc_server_2, '_identifier', var_0)

    # Try to call json_rpc_server_2.response with arg_0 as argument
    var_1 = "return value"
    try:
        var_2 = json_rpc_server_2.response(var_1)
        assert False
    except AssertionError as var_3:
        assert var_3.args == ("The id attribute of JsonRpcServer class must be set in order to call response() method.",)

    var_0 = "id"

# Generated at 2022-06-25 13:17:31.337534
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.internal_error()
    var_1 = json_rpc_server_0.handle_request("")
    var_2 = json_rpc_server_0.handle_request("")
    var_3 = json_rpc_server_0.handle_request("")

# Generated at 2022-06-25 13:17:35.877906
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    var_1 = json_rpc_server_1.register(json_rpc_server_1)
    var_2 = json_rpc_server_1.handle_request("{'method': 'internal_error', 'id': 'var_1', 'params': []}")

# Generated at 2022-06-25 13:17:38.597126
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()

# Generated at 2022-06-25 13:17:41.075043
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request()


# Generated at 2022-06-25 13:17:47.719898
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_2 = JsonRpcServer()
    var_1 = json_rpc_server_2.response()
    assert var_1 == {'jsonrpc': '2.0', 'id': None, 'result': None}


# Generated at 2022-06-25 13:17:49.622762
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:17:52.073741
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Testing with a mocked object
    test_objects = list()
    test_server = JsonRpcServer()
    for test_obj in test_objects:
        test_server.register(test_obj)


# Generated at 2022-06-25 13:17:57.241444
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    params_0 = {'method': 'rpc.test_0', 'params': [{}], 'id': 1}
    var_0 = to_text(json.dumps(params_0))
    var_1 = json_rpc_server_0.handle_request(var_0)


# Generated at 2022-06-25 13:18:02.060615
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Return a dictionary in the same format as AnsibleModule.fail_json
    # or AnsibleModule.exit_json
    # The values of the keys will be checked by an external test script
    return dict(failed=False,
                changed=False,
                msg="The JsonRpcServer_handle_request method has been called",
                meta='test_result')


# Generated at 2022-06-25 13:18:09.449087
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = '{'
    request_0 += '"jsonrpc": "2.0",'
    request_0 += '"id": "1",'
    request_0 += '"method": "a.b.c.do_it",'
    request_0 += '"params": {'
    request_0 += '"x": "value_1",'
    request_0 += '"y": "value_2"'
    request_0 += '}'
    request_0 += '}'
    response_0 = json_rpc_server_0.handle_request(request_0)


# Generated at 2022-06-25 13:18:12.029055
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    var_1 = json_rpc_server_1.internal_error()
    var_2 = json_rpc_server_1.handle_request(var_1)


# Generated at 2022-06-25 13:18:14.038718
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    obj_1 = None
    request_1 = None
    var_0 = json_rpc_server_1.handle_request(request_1, obj_1)


# Generated at 2022-06-25 13:18:15.382581
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.json_rpc_server import JsonRpcServer
    obj = JsonRpcServer()
    obj.handle_request()


# Generated at 2022-06-25 13:18:20.390172
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # No parameters.
    # Testing "request.get('id')"
    # Testing "json.loads"
    json_rpc_server_0.handle_request("{'method': 'test_method', 'id': 'test_id', 'params': []}")


# Generated at 2022-06-25 13:18:28.997160
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request({})
    assert var_0 is not None


# Generated at 2022-06-25 13:18:30.678569
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.error(code=-1, message='error')


# Generated at 2022-06-25 13:18:32.750883
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.internal_error()


# Generated at 2022-06-25 13:18:37.205328
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request('')
    assert var_0 == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": null}'


# Generated at 2022-06-25 13:18:39.261626
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request(request='string')


# Generated at 2022-06-25 13:18:44.345292
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json = '{"jsonrpc": "2.0", "method": "rpc.echo", "params": ["Hello World"], "id": 1}'
    json_rpc_server_0 = JsonRpcServer()
    assert json_rpc_server_0.handle_request(json) == '{"jsonrpc": "2.0", "id": 1, "result": "Hello World"}'



# Generated at 2022-06-25 13:18:46.612283
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:18:54.048493
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    #
    # Test for positive integer result
    #
    json_rpc_server_1 = JsonRpcServer()
    var_1 = json_rpc_server_1.response(12345)
    assert isinstance(var_1, dict)

    #
    # Test for negative integer result
    #
    json_rpc_server_2 = JsonRpcServer()
    var_2 = json_rpc_server_2.response(-12345)
    assert isinstance(var_2, dict)

    #
    # Test for floating point result
    #
    json_rpc_server_3 = JsonRpcServer()
    var_3 = json_rpc_server_3.response(12345.12345)
    assert isinstance(var_3, dict)

    #
    # Test for

# Generated at 2022-06-25 13:18:56.829939
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:19:01.122354
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.error(100, "kJybW0ak5Mfzt2QZGX9J")


# Generated at 2022-06-25 13:19:23.854554
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    test_case_0()

# Generated at 2022-06-25 13:19:28.804235
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json

    JsonRpcServer_inst = JsonRpcServer()
    request = json.dumps({
        'jsonrpc': '2.0',
        'id': '1234',
        'method': 'show version'
    })

    result = JsonRpcServer_inst.handle_request(request)



# Generated at 2022-06-25 13:19:35.943580
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    assert '_handle_request' in dir(JsonRpcServer)
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json.dumps({'id': 'foo', 'method': 'bar', 'params': [], 'jsonrpc': '2.0'})
    var_2 = json_rpc_server_0.handle_request(var_1)
    var_3 = json.loads(var_2)
    assert var_3 == json.loads('{"id": "foo", "error": {"code": -32600, "message": "Invalid request"}, "jsonrpc": "2.0"}')


# Generated at 2022-06-25 13:19:37.587290
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:19:47.630422
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()

# Generated at 2022-06-25 13:19:56.694225
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(JsonRpcServer())
    var_0 = json_rpc_server_0.handle_request("{""jsonrpc"":""2.0"",""method"":null,""params"":{""args"":"""",""kwargs"":""""},""id"":""jsonrpc-server_0""}")
    assert var_0 == "{\"error\": {\"code\": -32600, \"message\": \"Invalid request\"}, \"id\": \"jsonrpc-server_0\", \"jsonrpc\": \"2.0\"}"

# Generated at 2022-06-25 13:20:05.014299
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()

    # JsonRpcServer.internal_error()
    case1 = '''
    {
    "method": "internal_error()",
    "params": [
        "data"
    ],
    "jsonrpc": "2.0",
    "id": 1
}
'''

    # JsonRpcServer.invalid_request()
    case2 = '''
    {
    "method": "invalid_request()",
    "params": [
        "data"
    ],
    "jsonrpc": "2.0",
    "id": 1
}
'''

    # JsonRpcServer.error()

# Generated at 2022-06-25 13:20:09.870101
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    data_0 = '''{"jsonrpc": "2.0", "method": "test", "id": 1}'''
    var_0 = json_rpc_server_0.handle_request(data_0)
    assert var_0


# Generated at 2022-06-25 13:20:14.257393
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request({'id': 'str', 'params': [], 'jsonrpc': 'str', 'method': 'str'})
    assert var_0 == "b'{\\n    \"id\": \"str\",\\n    \"jsonrpc\": \"str\",\\n    \"result\": null\\n}'"


# Generated at 2022-06-25 13:20:17.584928
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Initialize a instance of class JsonRpcServer
    json_rpc_server_0 = JsonRpcServer()
    # Assertion if method response from class JsonRpcServer exist
    assert json_rpc_server_0.response


# Generated at 2022-06-25 13:21:16.251409
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request({'method': 'invalid_request', 'params': ({}, {}), 'id': 'some_id'})


# Generated at 2022-06-25 13:21:24.632403
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    var = json_rpc_server.handle_request('{"id":1,"method":"internal_error","params":[1]}')
    var = json_rpc_server.handle_request('{"id":1,"method":"internal_error","params":[{}]}')
    var = json_rpc_server.handle_request('{"id":1,"method":"internal_error","params":[{}, null]}')
    var = json_rpc_server.handle_request('{"id":1,"method":"internal_error","params":[{}]}')
    var = json_rpc_server.handle_request('{"id":1,"method":"internal_error","params":[["hello"]]}')
    return var


# Generated at 2022-06-25 13:21:34.110342
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    var_1 = JsonRpcServer()

# Generated at 2022-06-25 13:21:42.065522
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    request_0 = {'jsonrpc': '2.0', 'method': 'empty', 'params': ([], {}), 'id': 'random_id'}
    request_0 = json.dumps(request_0)
    var_0 = json_rpc_server_1.handle_request(request_0)

    request_1 = {'jsonrpc': '2.0', 'method': '_empty', 'params': ([], {}), 'id': 'random_id'}
    request_1 = json.dumps(request_1)
    var_1 = json_rpc_server_1.handle_request(request_1)


# Generated at 2022-06-25 13:21:45.226048
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request({"id": "1", "params": [[], {}], "method": "close"})


# Generated at 2022-06-25 13:21:49.457050
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    var_3 = json_rpc_server_1.internal_error()
    var_4 = {'id': var_3.id, 'method': 'rpc.test', 'params': []}
    var_5 = json.dumps(var_4)
    var_6 = json_rpc_server_1.handle_request(var_5)

# Generated at 2022-06-25 13:21:51.733151
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.internal_error()

# Generated at 2022-06-25 13:21:53.519082
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request("{'method': 'foo', 'params': {}}")


# Generated at 2022-06-25 13:21:57.349026
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()

    # Test cases
    request = {'id': 1, 'params': [], 'method': 'test_method'}
    result = json_rpc_server.handle_request(request)
    assert result != None
    assert json.loads(result)['error']['code'] == -32601


# Generated at 2022-06-25 13:21:59.965879
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Input parameters initialization
    request = 'p'

    # JsonRpcServer() instance creation
    obj = JsonRpcServer()

    # Call method
    r = obj.handle_request(request)


# Generated at 2022-06-25 13:23:08.150241
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'foo'})
    server.handle_request(request)

# Generated at 2022-06-25 13:23:16.111201
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request(request={"method": "rpc.test", "params": [{}, {}], "id": 1})
    var_1 = json_rpc_server_0.handle_request(request={"method": "rpc.test", "params": [{}, {"foo": "bar"}], "id": 2})
    var_2 = json_rpc_server_0.handle_request(request={"method": "rpc.test_required", "params": [{}, {}], "id": 3})

# Generated at 2022-06-25 13:23:21.079320
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    input = {'id': '0', 'method': 'method', 'params': [[], {}]}
    input = json.dumps(input)
    output = json_rpc_server_0.handle_request(input)
    var_0 = output
    assert(var_0 == '{"error": {"code": -32603, "message": "Internal error"}, "id": "0", "jsonrpc": "2.0"}')


# Generated at 2022-06-25 13:23:22.567131
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request()

# Generated at 2022-06-25 13:23:30.097079
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    # Module setup
    json_rpc_server_0 = JsonRpcServer()

    # Operation-1
    result = json_rpc_server_0.handle_request("{\"jsonrpc\":\"2.0\",\"method\":\"rpc.list\",\"params\":{},\"id\":\"test\"}")
    assert result == "{\"jsonrpc\":\"2.0\",\"result\":null,\"id\":\"test\"}"
    # Operation-1
    result = json_rpc_server_0.handle_request("{\"jsonrpc\":\"2.0\",\"method\":\"shell.run\",\"params\":[\"echo hello\"],\"id\":\"test\"}")

# Generated at 2022-06-25 13:23:32.767626
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Creates an instance of the class
    json_rpc_server_1 = JsonRpcServer()
    # Calls method handle_request
    json_rpc_server_0 = json_rpc_server_1.handle_request()


# Generated at 2022-06-25 13:23:35.025164
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # Result used in test case 0
    method = 'rpc_connect'
    var_0 = json_rpc_server_0.handle_request(method)



# Generated at 2022-06-25 13:23:40.092451
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    request = {
        'jsonrpc': '2.0',
        'id': 'id',
        'method': 'method',
        'params': {'name': 'value'},
    }
    response = json_rpc_server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": "id", "error": {"code": -32601, "message": "Method not found"}}'