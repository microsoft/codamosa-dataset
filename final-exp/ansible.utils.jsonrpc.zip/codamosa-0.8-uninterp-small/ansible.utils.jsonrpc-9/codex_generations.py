

# Generated at 2022-06-25 13:13:55.379083
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server = JsonRpcServer()
    result = b'\x80\x02]q\x00.'
    assert json_rpc_server.response(result=result) is not None


# Generated at 2022-06-25 13:14:01.810826
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    print('Testing method error of class JsonRpcServer')
    json_rpc_server_1 = JsonRpcServer()
    code = 0
    message = 'JsonRpcServer message'
    data = 'JsonRpcServer data'
    try:
        result = json_rpc_server_1.error(code, message, data)
        print("result: {}".format(result))
    except Exception as exc:
        print("Exception: {}".format(exc))


# Generated at 2022-06-25 13:14:05.259104
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    assert json_rpc_server_0.error(code = 1, message = '', data = None) == {'jsonrpc': '2.0', 'id': None, 'error': {'code': 1, 'message': ''}}


# Generated at 2022-06-25 13:14:08.928946
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    code = 0
    message = 'error'
    data=None
    dict_0 = json_rpc_server_0.error(code, message, data)
    assert dict_0['error']['code'] == -32700


# Generated at 2022-06-25 13:14:14.003380
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    print("Test: test_JsonRpcServer_error")
    #pass
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)
    error = json_rpc_server_0.error
    return True


# Generated at 2022-06-25 13:14:17.172808
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    assert isinstance(json_rpc_server_0.error(code=0, message=''), dict)


# Generated at 2022-06-25 13:14:24.111364
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '''{}'''
    try:
        result = json_rpc_server_0.handle_request(request)
        assert result == '{}', 'Unexpected value for result, expected "{}", got "{}"'.format("{}", result)
    except Exception as exc:
        display.error('ERROR: {0}'.format(exc))
        display.traceback()
        raise
    else:
        display.display("OK")


# Generated at 2022-06-25 13:14:25.896242
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.response()


# Generated at 2022-06-25 13:14:31.559775
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)
    json_rpc_server_0.handle_request("{\"method\": \"invalid_request\", \"params\": [], \"id\": 1}")
    json_rpc_server_0.handle_request("{\"method\": \"method_not_found\", \"params\": [], \"id\": 1}")
    json_rpc_server_0.handle_request("{\"method\": \"invalid_params\", \"params\": [], \"id\": 1}")
    json_rpc_server_0.handle_request("{\"method\": \"internal_error\", \"params\": [], \"id\": 1}")

# Generated at 2022-06-25 13:14:36.526041
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
#    assert json_rpc_server_0.response() == {'jsonrpc': '2.0', 'id': 'None', 'result': None}
    print(json_rpc_server_0.response())



# Generated at 2022-06-25 13:14:47.197837
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    data = json.dumps({'id': 'test_id', 'method': 'test_method', 'params': []})
    try:
        json_rpc_server_0.handle_request(data)
    except Exception:
        pass


# Generated at 2022-06-25 13:14:52.401675
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Test with literal inputs
    json_rpc_server_1 = JsonRpcServer()
    params = {'a': 'foo', 'b': 'bar'}
    setattr(json_rpc_server_1, '_identifier', '1')
    request = {'jsonrpc': '2.0', 'method': 'run', 'params': params, 'id': '1'}
    result = json_rpc_server_1.handle_request(request)
    assert result is not None


# Generated at 2022-06-25 13:15:00.242018
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    try:
        json_rpc_server = JsonRpcServer()
    except NameError:
        json_rpc_server = JsonRpcServer()

    # Test with a valid string. 
    # Assertion that the json object returned is not empty.

    request = json.loads('{"jsonrpc": "2.0","method": "foobar","id": "1"}')
    result = json.loads(json_rpc_server.handle_request(request))
    assert(result)


# Generated at 2022-06-25 13:15:06.915237
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    test_obj = JsonRpcServer()
    assert test_obj.response() == {'jsonrpc': '2.0', 'id': test_obj._identifier, 'result': None}
    assert test_obj.response('abc') == {'jsonrpc': '2.0', 'id': test_obj._identifier, 'result': u'abc'}
    assert test_obj.response(123) == {'jsonrpc': '2.0', 'id': test_obj._identifier, 'result': u'I3\n.'}



# Generated at 2022-06-25 13:15:11.486480
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server = JsonRpcServer()
    result = json_rpc_server.response("result")

    assert result == {u'id': None, u'result_type': u'pickle', u'jsonrpc': u'2.0', u'result': u"S'result'\np0\n."}


# Generated at 2022-06-25 13:15:16.221723
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.header = MagicMock(return_value={'jsonrpc': '2.0', 'id': json_rpc_server_0._identifier})
    json_rpc_server_0.response(1)



# Generated at 2022-06-25 13:15:22.794396
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0._identifier = '_identifier'
    data = 'data'
    assert json_rpc_server_0.error(code='code', message='message', data=data) == {'jsonrpc': '2.0', 'id': '_identifier', 'error': {'code': 'code', 'message': 'message', 'data': 'data'}}, "'code' 'message' 'data'"


# Generated at 2022-06-25 13:15:25.209911
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Instantiate the class
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.response()


# Generated at 2022-06-25 13:15:27.755864
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    str_0 = 'test'
    str_1 = json_rpc_server_0.handle_request(str_0)


# Generated at 2022-06-25 13:15:32.838157
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '{"id": 976299578, "method": "get_connection", "params": [{"host": "10.10.10.10", "port": 22, "network_os": "ios", "username": "arista_user", "password": "arista_pass", "timeout": 10, "transport": "cli"}]}'
    response = json_rpc_server_0.handle_request(request)
    print(response)


# Generated at 2022-06-25 13:15:45.332748
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)
    request = '{"jsonrpc": "2.0", "method": "invalid_request", "params": [], "id": 0}'
    result = json.loads(json_rpc_server_0.handle_request(request))
    assert result['error']['code'] == -32600


# Generated at 2022-06-25 13:15:52.043184
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()

    # Test with invalid input
    # str input
    try:
        json_rpc_server_1.response("invalid input")
    except TypeError as err:
        assert type(err) == TypeError

    # Test with valid input
    # dict input
    output = json_rpc_server_1.response({'result': 'test'})
    assert output == {'jsonrpc': '2.0', 'id': -1, 'result': 'test'}


# Generated at 2022-06-25 13:15:54.807065
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register("")
    result = json_rpc_server_0.response("")
    assert result is None


# Generated at 2022-06-25 13:15:58.177472
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    obj = JsonRpcServer()
    json_rpc_server = obj.handle_request(request = None)
    assert json_rpc_server is not None
    json_rpc_server = obj.handle_request(request = 'abc')
    assert json_rpc_server is not None


# Generated at 2022-06-25 13:16:00.481526
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request({})


# Generated at 2022-06-25 13:16:02.679899
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    obj = JsonRpcServer()
    method = JsonRpcServer.handle_request
    # TODO: test json
    obj.handle_request()


# Generated at 2022-06-25 13:16:11.139744
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create object of class JsonRpcServer
    json_rpc_server_0 = JsonRpcServer()

    # Variable id with value '15' assigned
    id_0 = '15'

    # Variable method with value '_meta' assigned
    method_0 = '_meta'

    # Variable params with value ['null', 'null'] assigned
    params_0 = ['null', 'null']

    # Variable json_rpc with value '2.0' assigned
    json_rpc_0 = '2.0'

    # Variable json_rpc_1 assigned as copy of variable json_rpc_0
    json_rpc_1 = json_rpc_0

    # Variable json_rpc_2 assigned as copy of variable json_rpc_0
    json_rpc_2 = json_rpc_0



# Generated at 2022-06-25 13:16:12.915307
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.response(result=None)

# Generated at 2022-06-25 13:16:20.838925
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()

    request = '{"method": "add", "id": "ID-123", "params": [1, 2, 3], "jsonrpc": "2.0"}'
    response = json_rpc_server_0.handle_request(request)
    response = json.loads(response)

    assert response == {u'error': {u'code': -32603,
                                   u'message': u'Internal error',
                                   u'data': u'name \'add\' is not defined'},
                        u'id': u'ID-123',
                        u'jsonrpc': u'2.0'}


# Generated at 2022-06-25 13:16:27.791747
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    obj = JsonRpcServer()
    obj._identifier = "abc"
    response = obj.response()
    if response["id"] != "abc":
        raise Exception("'id' field in response does not match with the identifier")
    elif response.get('error') is not None:
        raise Exception("'error' field in response is not null")
    elif response.get('result') is not None:
        raise Exception("'result' field in response is null")
    elif response.get('result_type') is not None:
        raise Exception("'result_type' field in response is not null")


# Generated at 2022-06-25 13:16:48.324530
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({}, {})
    json_rpc_server_0 = JsonRpcServer()

    json_rpc_server_0.register(module)

    import os
    import json
    import tempfile


    request_data = json.dumps({'method': 'ping'})

    with tempfile.TemporaryFile(mode='w+b') as request_file:
        request_file.write(request_data)
        request_file.seek(0)
        response = json_rpc_server_0.handle_request(request_file)

    parsed_response = json.loads(response)
    assert parsed_response.get('jsonrpc') == '2.0'
    assert parsed_response.get('id') == ''
   

# Generated at 2022-06-25 13:16:55.739111
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Setup mock object for JsonRpcServer class
    json_rpc_server_0_obj = JsonRpcServer()
    json_rpc_server_0_obj.handle_request = Mock()

    # Set up parameter value for method response of JsonRpcServer
    # result is used for method response
    result_value = (True)
    result = result_value
    json_rpc_server_0_obj.handle_request.return_value = None

    # Invoke method response of JsonRpcServer
    response_result = json_rpc_server_0_obj.response(result)

    # Check the result
    assert(response_result == None)



# Generated at 2022-06-25 13:16:59.387238
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server = JsonRpcServer()

    # Default values for parameters 'code', 'message'

    # Default value for parameter 'data'
  
    # Call method
    result = json_rpc_server.error(code)
    assert result is None 


# Generated at 2022-06-25 13:17:04.767596
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    from ansible.module_utils.connection import Connection, ConnectionError
    json_rpc_server_0 = JsonRpcServer()
    obj = Connection()
    method = getattr(obj, "send", None)
    if method:
        print(method(*[obj], **{}))
    else:
        raise Exception('Method "send" not implemented in class "Connection"')


# Generated at 2022-06-25 13:17:11.686098
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    exception_occurred = False
    try:
        # This test case is only valid for python2
        if six.PY2:
            json_rpc_server_0 = JsonRpcServer()
            result = json_rpc_server_0.response(result=dict())
            assert result == {'jsonrpc': '2.0', 'id': None, 'result_type': 'pickle', 'result': u'c__builtin__\ndict\np0\n.'}
        else:
            assert True
    except Exception:
        exception_occurred = True
    assert exception_occurred == False


# Generated at 2022-06-25 13:17:16.775451
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = {"method": "", "params": [[""], {}]}
    print(json_rpc_server_0.handle_request(request))
    print(json_rpc_server_0.handle_request(request).__class__)

if __name__ == '__main__':
    test_case_0()
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:17:19.758623
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    request = "{\"params\": null, \"method\": \"run\", \"id\": \"foo\"}"
    json_rpc_server.handle_request(request)


# Generated at 2022-06-25 13:17:21.686149
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
  params = {"params": [], "method": "handle_request", "id": "str"}
  test_case_0(**params)


# Generated at 2022-06-25 13:17:28.785113
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    # Creating an object
    json_rpc_server_0 = JsonRpcServer()
    # Assigning a Str to a Name (line 219)
    # Getting the type of 'json_rpc_server_0' (line 219)
    json_rpc_server_0_type = module_type_store.get_type_of(stypy.reporting.localization.Localization(__file__, 219, 15), 'json_rpc_server_0')
    # Setting the type of the member '_identifier' of a type (line 219)
    module_type_store.set_type_of_member(stypy.reporting.localization.Localization(__file__, 219, 15), json_rpc_server_0_type, '_identifier', str_0)
    
    # Call to error(...

# Generated at 2022-06-25 13:17:33.505451
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()

# Generated at 2022-06-25 13:17:46.953829
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = {"jsonrpc": "2.0"}
    result = json_rpc_server_0.response(result)


# Generated at 2022-06-25 13:17:57.048300
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    # method error(json_rpc_server_0, code - 32602, message - 'Invalid params', data - None) of class JsonRpcServer has no tests
    try:
        json_rpc_server_0.error(-32602, 'Invalid params')
        raise Exception(
            'ExpectedException not thrown for invalid parameters in call to method error of class JsonRpcServer')
    except TypeError as exc:
        if str(exc) != "integer argument expected, got str":
            raise Exception('Unexpected Exception was thrown for invalid parameters in call to method error of class JsonRpcServer')
    except Exception as exc:
        raise Exception('Unexpected Exception was thrown for invalid parameters in call to method error of class JsonRpcServer')


# Generated at 2022-06-25 13:18:00.460313
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    # WARNING: This will fail if you add arguments to the call
    results = json_rpc_server_0.response()
    assert 'jsonrpc' in results


# Generated at 2022-06-25 13:18:03.778802
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    _request = '{"method":"get_capabilities","params":[],"id":1}'
    json_rpc_server_0.handle_request(_request)


# Generated at 2022-06-25 13:18:11.529193
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    string_0 = 'Get network interface information on a remote device.'
    result_mock_0 = sb_utils.mock.MagicMock(
        __class__=to_text,
        return_value=string_0
    )

# Generated at 2022-06-25 13:18:13.912694
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.error(code=-32603,message='Internal error',data=None)


# Generated at 2022-06-25 13:18:24.196817
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    object_0 = object()
    object_1 = object()
    json_rpc_server_0.register(object_0)
    json_rpc_server_0.register(object_1)
    string_0 = json.dumps({"method": "foo", "params": [[], {}], "id": "0"})
    string_1 = json.dumps({"jsonrpc": "2.0", "result": "None", "id": "0"})
    string_2 = json.dumps({"jsonrpc": "2.0", "result": "None", "id": "0"})
    str_0 = json_rpc_server_0.handle_request(string_0)
    assert str_0 == string_1


# Generated at 2022-06-25 13:18:30.808059
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()

    rpc_method_args_1 = {'code': -32603, 'message': 'Internal error', 'data': 'None'}
    rpc_method_kwargs_1 = {'data': None}

    try:
        result = json_rpc_server_0.error(**rpc_method_kwargs_1)
    except SystemExit:
        print('repr(Exception):\n{!r}'.format(Exception()))
        raise
    else:
        if result != rpc_method_args_1:
            print('Expected: {!r}, Received: {!r}'.format(rpc_method_args_1, result))
            raise Exception()


# Generated at 2022-06-25 13:18:34.778926
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "hello", "params": ["world"]}'
    result = json_rpc_server_0.handle_request(request)
    assert result


# Generated at 2022-06-25 13:18:39.288691
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
  try:
    json_rpc_server_1 = JsonRpcServer()
    json_rpc_server_1.handle_request()
  except SystemExit as e:
    if e.code == 0:
      print("\nTest passed successfully\n")
    else:
      print("\nTest failed\n")
  except:
    print("\nTest failed\n")


# Generated at 2022-06-25 13:18:51.970450
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "ping", "params": [], "id": 1}'
    with pytest.raises(Exception) as excinfo:
        json_rpc_server_0.handle_request(request)


# Generated at 2022-06-25 13:18:53.329205
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    obj = JsonRpcServer()
    obj.handle_request(request='')


# Generated at 2022-06-25 13:19:01.252549
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Initialize test case 0
    json_rpc_server_0 = JsonRpcServer()

    # Initialize the test data
    request_0 = {'method': 'get', 'params': [], 'id': 1}
    request_0 = json.dumps(request_0)

    # Call the method under test
    response_0 = json_rpc_server_0.handle_request(request_0)

    # Test assertions

# Generated at 2022-06-25 13:19:03.149136
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    response = json_rpc_server_0.response(result)


# Generated at 2022-06-25 13:19:07.201833
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    q = test_case_0()
    if len(q) != 0:
        print("FAILED")
        print("testcase_0: len(q) != 0")
        return
    t = json.loads(q.handle_request(b'{"jsonrpc": "2.0", "method": "echo", "params": ["Hello World"], "id": 0}'))
    if t != {"jsonrpc": "2.0", "result": "Hello World", "id": 0}:
        print("FAILED")
        print("testcase_0: t != {'jsonrpc': '2.0', 'result': 'Hello World', 'id': 0}")
        return
    print("PASSED")

if __name__ == "__main__":
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:19:10.329991
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result_0 = json_rpc_server_0.response()
    assert result_0 == {'jsonrpc': '2.0', 'id': None}


# Generated at 2022-06-25 13:19:13.194912
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    assert json_rpc_server_0.response() == {'jsonrpc': '2.0', 'id': None, 'result': None}



# Generated at 2022-06-25 13:19:15.299685
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.error(1, 2, 3)


# Generated at 2022-06-25 13:19:19.498968
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "subtract", "params": [42, 23], "id": 1}'
    assert json_rpc_server_0.handle_request(request) == '{"jsonrpc": "2.0", "result": 19, "id": 1}'


# Generated at 2022-06-25 13:19:23.812557
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = {}
    # Don't validate response data
    #line 50
    # Don't validate response data
    #line 51
    # Don't validate response data
    #line 52
    # Don't validate response data
    #line 53
    return result


# Generated at 2022-06-25 13:19:36.017114
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    json_rpc_server_0 = JsonRpcServer()
    # TODO: test JsonRpcServer.handle_request

    print("\n")


# Generated at 2022-06-25 13:19:42.337369
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = {'jsonrpc': '2.0', 'result': 'pickle', 'id': getattr(json_rpc_server_0, '_identifier')}
    assert result == json_rpc_server_0.response(result={'jsonrpc': '2.0', 'result': 'pickle', 'id': getattr(json_rpc_server_0, '_identifier')})


# Generated at 2022-06-25 13:19:45.723828
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    result = json_rpc_server_1.response()
    assert result == {'jsonrpc': '2.0', 'id': None, 'result': None}


# Generated at 2022-06-25 13:19:51.952660
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()

    request = "{\"jsonrpc\": \"2.0\", \"method\": \"rpc._ping\", \"params\": [], \"id\": 0}"

    # TODO: Remove this and mock the response
    response = b'{"jsonrpc": "2.0", "result": "pong", "id": 0}'

    response_test = json_rpc_server.handle_request(request)
    assert cmp(response_test, response) == 0


# Generated at 2022-06-25 13:19:53.155108
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    assert True == True

# Generated at 2022-06-25 13:19:57.666899
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = b"""{'method': 'run_command', 'params': [{'cmd': 'show version'}, {'encoding': 'text'}], 'id': b'0'}"""
    result = json_rpc_server_0.handle_request(request)
    assert result == "b''"


# Generated at 2022-06-25 13:20:06.389688
# Unit test for method response of class JsonRpcServer

# Generated at 2022-06-25 13:20:14.923397
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = "json_rpc_server_0"

    test_data = {
        "test_data_1": "value_1",
        "test_data_2": "value_2"
    }
    result = server.response(test_data)

# Generated at 2022-06-25 13:20:18.310406
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)
    request = ''
    json_rpc_server_0.handle_request(request)


# Generated at 2022-06-25 13:20:19.625225
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    params = []
    raise NotImplementedError


# Generated at 2022-06-25 13:20:35.332329
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    result_2 = json_rpc_server_1.response()
    assert result_2 == {u'jsonrpc': u'2.0', u'id': None, u'result': None}
    result_3 = json_rpc_server_1.response(result='test str')
    assert result_3 == {u'jsonrpc': u'2.0', u'id': None, u'result': u'test str'}


# Generated at 2022-06-25 13:20:39.713857
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    rpc_server = JsonRpcServer()
    setattr(rpc_server, '_identifier', '123')
    result = rpc_server.response()
    result.get('jsonrpc').should.equal('2.0')
    result.get('id').should.equal('123')



# Generated at 2022-06-25 13:20:48.484136
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Test with invalid type for request
    json_rpc_server_1 = JsonRpcServer()
    try:
        json_rpc_server_1.handle_request(request=int())
    except TypeError:
        pass

    # Test with missing method
    json_rpc_server_2 = JsonRpcServer()
    data = json.dumps({'jsonrpc': '2.0', 'id': 0})
    try:
        json_rpc_server_2.handle_request(request=data)
    except ConnectionError:
        pass

    # Test with invalid method
    json_rpc_server_3 = JsonRpcServer()
    data = json.dumps({'jsonrpc': '2.0', 'id': 0, 'method': 'invalid'})

# Generated at 2022-06-25 13:20:57.716391
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server = JsonRpcServer()
    json_rpc_server.register(json_rpc_server)
    # Test with set 0
    output = json_rpc_server.handle_request('{"jsonrpc": "2.0", "method": "error", "params": [0], "id": 0}')
    assert output == '{"jsonrpc": "2.0", "id": 0, "error": {"code": -32603, "message": "Internal error"}}'
    # Test with set 1
    output = json_rpc_server.handle_request('{"jsonrpc": "2.0", "method": "error", "params": [1], "id": 1}')

# Generated at 2022-06-25 13:21:04.934846
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = {
        'jsonrpc': '2.0',
        'id': '2',
        'result': {
            'result_type': 'pickle',
            'result': ('\x80\x03}q\x01(U\x0bjsonrpcq\x02U\x02"0q\x03U\x01idq\x04U\x02"2q\x05'
                       'u.')
        }
    }
    assert json_rpc_server_0.response(result) == result


# Generated at 2022-06-25 13:21:08.200042
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    try:
        assert type(json_rpc_server_0.handle_request()) is str, "Wrong argument type in handle_request function"
    except Exception as e:
        display.error(e)


# Generated at 2022-06-25 13:21:09.962142
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    method = json_rpc_server_0.handle_request()


# Generated at 2022-06-25 13:21:11.095472
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()


# Generated at 2022-06-25 13:21:18.921009
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(None)
    json_rpc_server_0.register(display)

    assert json_rpc_server_0.handle_request({})
    assert json_rpc_server_0.handle_request({'method': '', 'params': []})
    assert json_rpc_server_0.handle_request({'method': 'rpc.test', 'params': []})
    assert json_rpc_server_0.handle_request({'method': '_test', 'params': []})
    assert json_rpc_server_0.handle_request({'method': 'test', 'params': []})


# Generated at 2022-06-25 13:21:21.785728
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    getattr(json_rpc_server_1, '_identifier', '_identifier')
    assert True


# Generated at 2022-06-25 13:21:39.699063
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Initialize test variables
    expected_result = '{"jsonrpc": "2.0", "id": -2147418111}'
    request = {"method": "nay", "params": [[], {}], "id": -2147418111}

    # Create an instance of the class for the test
    json_rpc_server_0 = JsonRpcServer()

    # Perform the test
    actual_result = json_rpc_server_0.handle_request(request)

    # Compare expected result against actual result
    assert actual_result == expected_result, 'Test failed: expected_result: ' + str(expected_result) + ' actual_result: ' + str(actual_result)


# Generated at 2022-06-25 13:21:41.987040
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server = JsonRpcServer()
    result = "TEST STRING"
    expected = json.loads('{"id": null, "jsonrpc": "2.0", "result": "TEST STRING"}')
    assert json_rpc_server.response(result) == expected


# Generated at 2022-06-25 13:21:44.247455
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    json_rpc_server.handle_request()



# Generated at 2022-06-25 13:21:47.404149
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.method_not_found()
    json_rpc_server_0.invalid_request()
    json_rpc_server_0.parse_error()
    json_rpc_server_0.invalid_params()
    json_rpc_server_0.internal_error()
    json_rpc_server_0.error(1, 2)



# Generated at 2022-06-25 13:21:54.503269
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = b'{"method":"rpc.echo","params":[],"id":1}'
    response_0 = json_rpc_server_0.handle_request(request_0)
    assert response_0 == b'{"error":{"code":-32601,"message":"Method not found"},"id":1,"jsonrpc":"2.0"}'
    request_1 = b'{"method":"_echo","params":[],"id":2}'
    response_1 = json_rpc_server_0.handle_request(request_1)
    assert response_1 == b'{"error":{"code":-32601,"message":"Method not found"},"id":2,"jsonrpc":"2.0"}'

# Generated at 2022-06-25 13:21:56.239293
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    rpc_0 = JsonRpcServer()
    rpc_0.error(-32000, 'Internal error')


# Generated at 2022-06-25 13:22:02.113223
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc._handle_request", "params": ["{\"jsonrpc\": \"2.0\", \"method\": \"_handle_request\", \"params\": [[null], {}], \"id\": 0}"], "id": 0}'
    result = json_rpc_server_0.handle_request(request)
    assert result == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": 0}'


# Generated at 2022-06-25 13:22:09.619801
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

    with open('test/unit/json_rpc/data/handle_request.json', 'rb') as infile:
        request = infile.read()

    response = json_rpc_server_0.handle_request(request)

    assert response == b'{"jsonrpc": "2.0", "result": "{\\n    \\"jsonrpc\\": \\"2.0\\", \\"result\\": \\"hello world\\", \\"id\\": \\"test_identifier\\"\\n}\\n", "id": "test_identifier"}'


# Generated at 2022-06-25 13:22:14.565575
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)
    result = json_rpc_server_0.error(code=-32602, message='Invalid params')
    assert result == {'jsonrpc': '2.0', 'id': json_rpc_server_0._identifier, 'error': {'code': -32602, 'message': 'Invalid params'}}


# Generated at 2022-06-25 13:22:17.708434
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_1 = JsonRpcServer()
    code = -32602
    message = 'Invalid params'
    data = None
    result = json_rpc_server_1.error(code, message, data)


# Generated at 2022-06-25 13:22:43.564959
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    setattr(json_rpc_server_0, '_identifier', '{coord}')
    result = json_rpc_server_0.handle_request('{string_0}')


# Generated at 2022-06-25 13:22:50.743740
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.connection import Connection
    json_rpc_server_0 = JsonRpcServer()
    connection_0 = Connection("")
    json_rpc_server_0.register(connection_0)
    request = {"method": "send",
               "params": [[{"dest_file": "/etc/user_backup/group"}],
                          {}],
               "jsonrpc": "2.0",
               "id": "2"}
    json_rpc_server_0.handle_request(request)

# Generated at 2022-06-25 13:22:52.163213
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    obj = JsonRpcServer()
    assert "result_type" not in obj.response()


# Generated at 2022-06-25 13:22:54.478451
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.handle_request(request="request_0")
    print(result)


# Generated at 2022-06-25 13:22:58.204434
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0._identifier = "c85e6d69-9562-11e8-b6c3-6cf049a8e0e1"
    result = "test string"
    tmp_json_result = json_rpc_server_0.response(result)

    assert tmp_json_result['jsonrpc'] == "2.0"
    assert tmp_json_result['id'] == "c85e6d69-9562-11e8-b6c3-6cf049a8e0e1"
    assert tmp_json_result['result'] == "test string"
    assert (not tmp_json_result.has_key('error'))


# Generated at 2022-06-25 13:23:03.583089
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0._identifier = 'hello'
    expected = {'jsonrpc': '2.0', 'id': 'hello', 'error': {'code': 5, 'message': 'Test', 'data': 'boom!'}}
    actual = json_rpc_server_0.error(5, 'Test', 'boom!')
    assert actual == expected


# Generated at 2022-06-25 13:23:07.339125
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)
    result = json_rpc_server_0.response()
    assert isinstance(result, dict)
    assert "result" in result and result["result"] == None


# Generated at 2022-06-25 13:23:13.826113
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Make instance of JsonRpcServer and assign to json_rpc_server_0
    json_rpc_server_0 = JsonRpcServer()

    # Set request of json_rpc_server_0
    request = '''{"params": [1, 2], "id": 1, "jsonrpc": "2.0", "method": "add"}'''

    # Call method handle_request of json_rpc_server_0
    result = json_rpc_server_0.handle_request(request)
    assert result == '{"jsonrpc": "2.0", "id": 1, "result": "3"}'



# Generated at 2022-06-25 13:23:14.943697
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()


# Generated at 2022-06-25 13:23:19.338361
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    setattr(json_rpc_server_1, '_identifier', 1)
    result = '{"jsonrpc": "2.0", "id": "1", "result": "result"}'
    assert json_rpc_server_1.response("result") == result
