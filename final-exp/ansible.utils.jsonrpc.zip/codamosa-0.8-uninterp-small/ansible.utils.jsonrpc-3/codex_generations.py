

# Generated at 2022-06-25 13:14:00.020382
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    JsonRpcServer._objects = set()
    json_rpc_server_0.register(json_rpc_server_0)

# Generated at 2022-06-25 13:14:07.966047
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    setattr(json_rpc_server_1, '_identifier', 'A')


# Generated at 2022-06-25 13:14:13.920313
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = dict()
    expected = dict()
    expected['id'] = json_rpc_server_0._identifier
    expected['result'] = result
    expected['jsonrpc'] = '2.0'
    assert expected == json_rpc_server_0.response(**{'result':result})


# Generated at 2022-06-25 13:14:16.718374
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server = JsonRpcServer()
    json_rpc_server.error(-32602, 'Invalid params', None)


# Generated at 2022-06-25 13:14:21.576076
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    # Test with valid argument
    try:
        result = json_rpc_server_0.response()
        print("\nCall build_response method with 'result_type' as None")
    except Exception as exc:
        print(exc)


# Generated at 2022-06-25 13:14:26.415190
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result_1 = json_rpc_server_0.response("string with spaces")
    assert result_1 == {"jsonrpc": "2.0",
        "id": None,
        "result_type": "pickle",
        "result": b'(X\x15\x00\x00\x00string with spacesq\x01.'}


# Generated at 2022-06-25 13:14:31.855876
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import cPickle
    json_rpc_server_0 = JsonRpcServer()

    # Assigning argument 'request' to a raw_input
    request = '{"jsonrpc":"2.0","method":"test","params":[1,2,3],"id":12345}'

    # Call method
    method_result = json_rpc_server_0.handle_request(request)
    expected = {'jsonrpc': '2.0', 'id': 12345, 'result': u'PickleRPC_Response', 'result_type': 'pickle'}
    assert (cPickle.loads(method_result) == expected)



# Generated at 2022-06-25 13:14:34.246160
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request(request)


# Generated at 2022-06-25 13:14:39.306540
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    data = '{"jsonrpc": "2.0", "method": "rpc.echo", "id": 2, "params": ["foo"]}'
    assert json_rpc_server_0.handle_request(data) == '{"jsonrpc": "2.0", "id": 2, "result": "foo"}'


# Generated at 2022-06-25 13:14:45.516180
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)
    output = json_rpc_server_0.handle_request("""{"jsonrpc": "2.0", "method": "response", "id": 1}""")
    assert json.loads(output) == {"id": 1, "jsonrpc": "2.0", "result": "None"}


# Generated at 2022-06-25 13:14:52.242213
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request((request))


# Generated at 2022-06-25 13:15:01.937367
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    obj = JsonRpcServer()
    obj._identifier = "JsonRpcServer._identifier"
    code = 32603
    message = "JsonRpcServer.message"
    data = "JsonRpcServer.data"
    rpc_error = obj.error(code, message, data)
    assert rpc_error['id'] == obj._identifier
    assert rpc_error['jsonrpc'] == "2.0"
    assert rpc_error['error']['code'] == code
    assert rpc_error['error']['message'] == message
    assert rpc_error['error']['data'] == data


# Generated at 2022-06-25 13:15:09.749689
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_1 = JsonRpcServer()
    # Test for bad 'code' type
    try:
        json_rpc_server_1.register(json_rpc_server_0)
        json_rpc_server_0.error(code='string', message='error')
    except Exception as e:
        pass
    # Test for bad 'message' type
    try:
        json_rpc_server_1.register(json_rpc_server_0)
        json_rpc_server_0.error(code=0, message=list())
    except Exception as e:
        pass


# Generated at 2022-06-25 13:15:17.096700
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Create an instance of the JsonRpcServer class
    json_rpc_server_1 = JsonRpcServer()

    # Test the method response of the JsonRpcServer class
    json_rpc_server_1.response()


if __name__ == '__main__':
    # Create an instance of the JsonRpcServer class
    json_rpc_server_0 = JsonRpcServer()

    # Test the method response of the JsonRpcServer class
    json_rpc_server_0.response()

    test_case_0()

# Generated at 2022-06-25 13:15:25.166254
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    obj = JsonRpcServer()
    # Default return value
    assert obj.response() == {
        'jsonrpc': '2.0',
        'id': '_identifier',
    }
    # Return value with args
    assert obj.response('result') == {
        'jsonrpc': '2.0',
        'id': '_identifier',
        'result': 'result',
    }
    # Return value with args
    assert obj.response(result='result') == {
        'jsonrpc': '2.0',
        'id': '_identifier',
        'result': 'result',
    }


# Generated at 2022-06-25 13:15:28.029788
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    params = {}
    request = json.dumps(params)
    result = json_rpc_server_0.handle_request(request)


# Generated at 2022-06-25 13:15:30.979253
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request(request = {
        "method": "system.test",
        "params": [],
        "id": "1"
    })


# Generated at 2022-06-25 13:15:34.320712
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server = JsonRpcServer()
    expected = {"jsonrpc": "2.0", "id": str(json_rpc_server._identifier), "error": {"code": -32603, "message": "Internal error", "data": "test"}}
    result = json_rpc_server.error(-32603, "Internal error", data="test")
    assert expected == result


# Generated at 2022-06-25 13:15:37.501486
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    payload = {"jsonrpc": "2.0", "params": {"args": [{"pass": true, "port": "22", "host": "localhost", "username": "example", "password": "example", "timeout": 10}], "kwargs": {}}, "method": "get_connection"}
    result = json_rpc_server_1.handle_request(payload)
    print(result)


# Generated at 2022-06-25 13:15:45.957681
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)
    request = json.dumps({'jsonrpc': '2.0', 'method': 'handle_request', 'params': [], 'id': 0})
    json_rpc_server_0_result = json_rpc_server_0.handle_request(request)
    assert json_rpc_server_0_result == "{\"jsonrpc\": \"2.0\", \"error\": {\"message\": \"Method not found\"}, \"id\": 0}"


# Generated at 2022-06-25 13:16:04.360642
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    obj = {
        key: value
        for key, value in json_rpc_server_0.__dict__.items()
        if key in ('header', 'response')
    }
    result = json_rpc_server_0.response()
    assert str(result) == str(obj)


# Generated at 2022-06-25 13:16:06.487743
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Assigning value to variable 'json_rpc_server_0'
    json_rpc_server_0 = JsonRpcServer()
    
    
    

# Generated at 2022-06-25 13:16:08.858205
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.response()
    print(result)
    #assert result == "result"


# Generated at 2022-06-25 13:16:10.350795
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    test_case_0()


# Generated at 2022-06-25 13:16:13.835400
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    with open("test_data.json") as f:
        json_data = json.load(f)
    for data in json_data:
        json_rpc_server_0.handle_request(data)

# Generated at 2022-06-25 13:16:20.310144
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    error = False
    passed = True
    # Try to call the method
    try:
        test_case_0()
    except Exception as e:
        error = True
        # Check if exception raised is the expected one
        if e.__class__.__name__ != 'AttributeError':
            passed = False
            display.display("Expected AttributeError and got " + e.__class__.__name__)
    else:
        if error:
            passed = False
            display.display("Expected Exception not raised")

    return passed


# Generated at 2022-06-25 13:16:23.920443
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)
    result = json_rpc_server_0.response()
    assert(result['id'] == None)
    assert(result['jsonrpc'] == '2.0')
    assert(result['result'] == "")
    

# Generated at 2022-06-25 13:16:33.639584
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Needs to mock the JsonRpcServer._identifier attribute
    json_rpc_server_0 = JsonRpcServer()
    setattr(json_rpc_server_0, '_identifier', '111111')

    # Test case for string result
    result = "string test"
    response = json_rpc_server_0.response(result)

# Generated at 2022-06-25 13:16:42.366319
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = json.loads('{"jsonrpc": "2.0", "id": "1", "method": "send_command", "params": ["show version"]}')
    response_0 = json.loads('{"jsonrpc": "2.0", "id": "1", "result": {"version": "v1.2.3", "platform": "eos"}}')

    # `handle_request` should return a json string matching the reference
    # response
    result_0 = json.loads(json_rpc_server_0.handle_request(request_0))
    assert result_0 == response_0



# Generated at 2022-06-25 13:16:49.317269
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():

    # From test_case_0
    json_rpc_server_0 = JsonRpcServer()

    # set up parameters used in the test
    result = 'foo'
    json_rpc_server_0._identifier = 7
    response = {'id': 7, 'jsonrpc': '2.0', 'result': result}

    # Test case with above set up
    response_0 = json_rpc_server_0.response(result)
    if response_0 != response:
        raise AssertionError("expected %s, got %s" % (response, response_0))


# Generated at 2022-06-25 13:17:05.755421
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(JsonRpcServer())
    data_0 = None

# Generated at 2022-06-25 13:17:08.152529
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    data = {"result": "null"}
    result = json_rpc_server_0.response(data)
    assert result == data


# Generated at 2022-06-25 13:17:13.036332
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = '{"jsonrpc": "2.0", "method": "foobar", "id": "1"}'
    result_0 = '{"jsonrpc": "2.0", "id": "1", "error": {"message": "Method not found", "code": -32601}}'
    assert json_rpc_server_0.handle_request(request_0) == result_0


# Generated at 2022-06-25 13:17:16.942672
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    if(not (json_rpc_server_0.handle_request(request_0) == response_0)):
        raise RuntimeError("Test Case test_JsonRpcServer_handle_request FAILED!")


# Generated at 2022-06-25 13:17:21.320496
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    str_0 = '''{
        "jsonrpc": "2.0",
        "id": "1",
        "method": "test",
        "params": {}
    }'''
    str_1 = json_rpc_server_0.handle_request(str_0)


# Generated at 2022-06-25 13:17:28.539377
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    obj = JsonRpcServer()
    request = json.loads(u'{"params": [[], {}], "jsonrpc": "2.0", "method": "run_command", "id": 3}')
    result = json_rpc_server_0.handle_request(request)

# Generated at 2022-06-25 13:17:33.548443
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    if True:
        print('Testing function handle_request')
        json_rpc_server_0 = JsonRpcServer()
        request = '{"id": 1, "jsonrpc": "2.0", "method": "method_name", "params": {}}'
        result = json_rpc_server_0.handle_request(request)
        print('\tPassed: ' + repr(result))


# Generated at 2022-06-25 13:17:40.792346
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_1 = JsonRpcServer()
    test_code = 1
    test_message = 'test message'
    test_data = 'test data'
    test_result = {'jsonrpc': '2.0', 'id': None, 'error': {'code': test_code, 'message': test_message, 'data': test_data}}

    test_error = json_rpc_server_1.error(test_code, test_message, test_data)

    assert test_error == test_result


# Generated at 2022-06-25 13:17:46.437561
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    request = b'{"jsonrpc": "2.0", "method": "foobar", "id": "1"}'
    json_rpc_server = JsonRpcServer()
    response = json_rpc_server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": "1"}'


# Generated at 2022-06-25 13:17:48.369928
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request()



# Generated at 2022-06-25 13:18:05.101292
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_2 = JsonRpcServer()

# Generated at 2022-06-25 13:18:10.996378
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)
    # Known issue:  Requests with multiple method calls are not supported.
    # See https://github.com/ansible/ansible/issues/35064
    with open('test_cases/json_rpc_server/test_case_0.pkl', 'rb') as f:
        test_case_0 = cPickle.load(f)
    json_rpc_server_0.handle_request(test_case_0)

# Generated at 2022-06-25 13:18:19.829807
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    json_rpc_server_1_result = json_rpc_server_1.response()
    assert json_rpc_server_1_result == {
        "jsonrpc": "2.0",
        "id": None,
        "result": None
    }

    json_rpc_server_2 = JsonRpcServer()
    json_rpc_server_2_result = json_rpc_server_2.response(result="test")
    assert json_rpc_server_2_result == {
        "jsonrpc": "2.0",
        "id": None,
        "result": "test"
    }

# Generated at 2022-06-25 13:18:24.087461
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    code = 0
    message = "test string"
    data = None
    expected_result = None
    result = json_rpc_server_0.error(code, message, data)
    assert result == expected_result


# Generated at 2022-06-25 13:18:30.919296
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    jsonrpc_server = JsonRpcServer()
    request = {
        'id': u'86d65ade-eda7-457a-a8e8-ecb89cf9a9c1',
        'jsonrpc': u'2.0',
        'method': u'rpc.run',
        'params': [u'show version', u'show version']}
    if sys.version_info[0] >= 3:
        request = json.dumps(request).encode('utf-8')
    else:
        request = json.dumps(request)
    try:
        jsonrpc_server.handle_request(request)
    except Exception as exc:
        display.vvv(traceback.format_exc())
        assert isinstance(exc, ConnectionError)



# Generated at 2022-06-25 13:18:36.352394
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '''{
      "id": "1",
      "jsonrpc": "2.0",
      "params": [
        "param1",
        "param2"
      ],
      "method": "some_method"
    }'''
    assert json_rpc_server_0.handle_request(request) == request


# Generated at 2022-06-25 13:18:37.910346
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    # BEGIN
    json_rpc_server_0 = JsonRpcServer()
    # END


# Generated at 2022-06-25 13:18:47.219288
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register('')
    json_rpc_server_0.register('')
    json_rpc_server_0.register('')
    json_rpc_server_0.register('')
    json_rpc_server_0.register('')
    json_rpc_server_0.register('')
    json_rpc_server_0.register('')
    json_rpc_server_0.register('')
    json_rpc_server_0.register('')
    json_rpc_server_0.register('')
    json_rpc_server_0.register('')
    json_rpc_server_0.register('')

# Generated at 2022-06-25 13:18:49.639346
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    params = set()
    params.add('request')
    json_rpc_server_0.handle_request(params)



# Generated at 2022-06-25 13:18:51.295735
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
# Test for the error method of JsonRpcServer

# Generated at 2022-06-25 13:19:04.276252
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()

    assert server.error(1, 'message') == {'jsonrpc': '2.0', 'id': None, 'error': {'code': 1, 'message': 'message'}}

    assert server.error(1, 'message', 'data') == {'jsonrpc': '2.0', 'id': None, 'error': {'code': 1, 'message': 'message', 'data': 'data'}}


# Generated at 2022-06-25 13:19:12.749641
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)

# Generated at 2022-06-25 13:19:16.499015
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    print('In subtest 1')
    # Create a new instance of JsonRpcServer
    json_rpc_server_0 = JsonRpcServer()
    # Test for errors raised in calling handle_request
    json_rpc_server_0.handle_request()
    print('Subtest 2 passed')


# Generated at 2022-06-25 13:19:21.283664
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = {"params": [
        [], {}], "jsonrpc": "2.0", "method": "parse_error", "id": "id"}
    request = json.dumps(request)
    response = json_rpc_server_0.handle_request(request)
    for res in response:
        print(res)


# Generated at 2022-06-25 13:19:30.981498
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = "{"
    request_1 = '  "jsonrpc": "2.0",'
    request_2 = '  "method": "rpc.echo",'
    request_3 = '  "params": ["hello world"],,'
    request_4 = '  "id": "1"'
    request_5 = '}'
    request_6 = request_0 + request_1 + request_2 + request_3 + request_4 + request_5
    response_0 = json_rpc_server_0.handle_request(request=request_6)

    # Test cases for exceptions raised in method handle_request of class JsonRpcServer
    request_7 = "{"

# Generated at 2022-06-25 13:19:32.038811
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    test_case_0()

# Generated at 2022-06-25 13:19:32.865381
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    test_case_0()


# Generated at 2022-06-25 13:19:36.441660
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_3 = JsonRpcServer()
    request = '{}'
    assert json_rpc_server_3.handle_request(request) == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": None}'


# Generated at 2022-06-25 13:19:41.272388
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    request = '{\"jsonrpc\": \"1.0\", \"method\": \"rpc.hello\", \"params\": [\"world\"], \"id\": 1}'
    try:
        json_rpc_server_1.handle_request(request)
    except AttributeError:
        pass


# Generated at 2022-06-25 13:19:44.178992
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.error(code=-32300, message='error_message')


# Generated at 2022-06-25 13:19:56.809008
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.module_utils.json_rpc_server import JsonRpcServer

    try:
        conn = Connection()
    except Exception:
        conn = None

    obj = {"method": "configure", "params": [[{"name": "hostname", "value": "test"}]]}
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register((Connection(),))
    json_rpc_server_0.handle_request(obj)

# Generated at 2022-06-25 13:20:04.724744
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # @responses.activate
    # def test_case_0():
    json_rpc_server_0 = JsonRpcServer()

    request = """{
        "jsonrpc": "2.0",
        "method": "foo.bar",
        "id": "123",
        "params": [
            "value1",
            "value2"
        ]
    }"""
    expected = """{
        "jsonrpc": "2.0",
        "id": "123",
        "error": {
            "code": -32601,
            "message": "Method not found",
            "data": null
        }
    }"""
    actual = json_rpc_server_0.handle_request(request)
    assert actual == expected


# Generated at 2022-06-25 13:20:13.935990
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    print("Testing handle_request")

    json_rpc_server_0 = JsonRpcServer()

    # Test case 0
    request = json.loads(to_text(request, errors='surrogate_then_replace'))

    if __debug__: print("[DEBUG] request: %s" % request)
    method = request.get('method')

    if method.startswith('rpc.') or method.startswith('_'):
        error = self.invalid_request()
        return json.dumps(error)

    args, kwargs = request.get('params')
    setattr(self, '_identifier', request.get('id'))

    rpc_method = None
    for obj in self._objects:
        rpc_method = getattr(obj, method, None)

# Generated at 2022-06-25 13:20:16.485394
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    obj = jsonrpcobject.JsonRpcServer()
    request = 'json string'
    response = obj.handle_request(request)
    assert response == obj.response()


# Generated at 2022-06-25 13:20:25.564224
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({
        'jsonrpc': '2.0',
        'method': 'run_command',
        'params': [['/sbin/ip', 'address', 'show'], 200],
        'id': 42
    })
    response = json.loads(server.handle_request(request))

    response_jsonrpc = response['jsonrpc']
    response_id = response['id']
    response_result = response['result']
    response_result_type = response['result_type']
    response_result_stdout = response_result.split('\n')[0]

    assert response_jsonrpc == '2.0'
    assert response_id == 42
    assert response_result_type == 'pickle'
    assert response_result_stdout

# Generated at 2022-06-25 13:20:27.731055
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.response()
    #print result


# Generated at 2022-06-25 13:20:34.548173
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    obj_JsonRpcServer = JsonRpcServer()
    obj_JsonRpcServer._identifier = 0
    assert obj_JsonRpcServer.response('foo') == {"jsonrpc": "2.0", "id": 0, "result": "foo"}
    assert obj_JsonRpcServer.response('foo') == {"jsonrpc": "2.0", "id": 0, "result": "foo"}
    assert obj_JsonRpcServer.response(u'foo') == {"jsonrpc": "2.0", "id": 0, "result": "foo"}


# Generated at 2022-06-25 13:20:40.045836
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Test case 0
    json_rpc_server_0 = JsonRpcServer()
    assert json_rpc_server_0.handle_request({"method":"_test_case_0","params":{"test_data":"test_data"},"id":None}) == '{"jsonrpc": "2.0", "error": {"code": -32603, "message": "Internal error", "data": "Invalid test case value"}, "id": None}'
    assert json_rpc_server_0.handle_request({"method":"_test_case_0","params":{"test_data":0},"id":None}) == '{"jsonrpc": "2.0", "error": {"code": -32603, "message": "Internal error", "data": "Invalid test case value"}, "id": None}'
    assert json_rpc_server_0

# Generated at 2022-06-25 13:20:43.721604
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["arg1", "arg2"], "id": "3"}'
    json_rpc_server_1.handle_request(request)


# Generated at 2022-06-25 13:20:44.584372
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    test_case_0()


# Generated at 2022-06-25 13:20:54.705856
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = {}
    result = json_rpc_server_0.handle_request(request_0)
    assert result == '{"jsonrpc": "2.0", "id": null, "error": {"code": -32600, "message": "Invalid request"}}'


# Generated at 2022-06-25 13:20:58.277072
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # create an instance of the class
    json_rpc_server_1 = JsonRpcServer()

    # TODO: check that handle_request() throws an error when no arguments are provided

    # TODO: check that handle_request() throws a TypeError when the argument is of the wrong type

    # TODO: verify that handle_request() returns the correct value


# Generated at 2022-06-25 13:21:06.873538
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    rqst = b'\x80\x03}q\x00(X\x05\x00\x00\x00_identq\x01X\x07\x00\x00\x00is_textq\x02\x88q\x03X\x06\x00\x00\x00paramsq\x04X\x00\x00\x00\x00\x86q\x05X\x04\x00\x00\x00textq\x06\x89q\x07X\x03\x00\x00\x00ABCq\x08X\x05\x00\x00\x00_typeq\tX\x03\x00\x00\x00strq\nub.'

# Generated at 2022-06-25 13:21:14.966419
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = "{\"jsonrpc\": \"2.0\", \"id\": 1, \"method\": \"correct\", \"params\": [1, 2, 3]}"
    response = json_rpc_server_0.handle_request(request)
    assert response is not None

    request = "{\"jsonrpc\": \"2.0\", \"id\": 1, \"method\": \"empty\", \"params\": [1, 2, 3]}"
    response = json_rpc_server_0.handle_request(request)
    assert response is not None

    request = "{\"jsonrpc\": \"2.0\", \"id\": 1, \"method\": \"pickle\", \"params\": [1, 2, 3]}"
    response = json_rpc_server_0.handle_request(request)

# Generated at 2022-06-25 13:21:17.520135
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Initialize JsonRpcServer
    json_rpc_server_0 = JsonRpcServer()

    # Call function handle_request of class JsonRpcServer
    json_rpc_server_0.handle_request()



# Generated at 2022-06-25 13:21:22.560476
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Setup test
    json_rpc_server_0 = JsonRpcServer()
    result_0 = 'RAH'
    # Exercise function
    response_0 = json_rpc_server_0.response(result_0)
    # Verify results
    expected_0 = {'jsonrpc': '2.0', 'id': '', 'result': result_0}
    assert response_0 == expected_0


# Generated at 2022-06-25 13:21:28.150146
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test_method"}'
    actual = json_rpc_server_0.handle_request(request)
    assert actual == '{"id": null, "jsonrpc": "2.0", "error": {"code": -32601, "data": null, "message": "Method not found"}}'


# Generated at 2022-06-25 13:21:33.784482
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    try:
        json_rpc_server_0 = JsonRpcServer()
        method = __new__(str)
        request = __new__(str)
        request = '{method: "init", params: [], id: 1}'
    except NameError:
        display.info('NameError exception')
    finally:
        if 'json_rpc_server_0' in locals():
            json_rpc_server_0.handle_request(method, request)


# Generated at 2022-06-25 13:21:40.034647
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    test_request0 = b'{"id": 1, "jsonrpc": "2.0", "method": "foo"}'
    expect_result0 = {
        'error': {
            'code': -32600,
            'message': 'Invalid request'
        },
        'id': 1,
        'jsonrpc': '2.0'}
    result0 = json_rpc_server_0.handle_request(test_request0)
    assert expect_result0 == json.loads(result0)


# Generated at 2022-06-25 13:21:42.527869
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = {"foo": "bar"}
    response = json_rpc_server_0.response(result=result)
    assert response == {
        "result": result,
        "result_type": None,
        "jsonrpc": "2.0",
        "id": None
    }


# Generated at 2022-06-25 13:21:52.284035
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Initialize class
    json_rpc_server_0 = JsonRpcServer()
    request = '{ "jsonrpc": "2.0", "method": "subtract", "params": [42, 23], "id": 1 }'

    # Invoke method
    result = json_rpc_server_0.handle_request(request)
    assert(result == '{ "jsonrpc": "2.0", "id": 1, "result": 19 }')


# Generated at 2022-06-25 13:21:58.166535
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    setattr(json_rpc_server_0, '_identifier', 'BJt_5eL96')

# Generated at 2022-06-25 13:22:02.397634
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    rpc_server = JsonRpcServer()
    req = {'id': 'a', 'method': 'b', 'params': [[], {}]}
    req = json.dumps(req)

    try:
        res = json.loads(rpc_server.handle_request(req))
    except Exception as exc:
        print(exc)

    assert res is not None


# Generated at 2022-06-25 13:22:05.444430
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = ""
    result = json_rpc_server_0.handle_request(request)
    assert result == None


# Generated at 2022-06-25 13:22:06.551752
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # TODO: pass proper test input
    json_rpc_server_0.handle_request(request)

# Generated at 2022-06-25 13:22:10.948339
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '''{
    "jsonrpc": "2.0",
    "method": "rpc.foo",
    "id": "2f9fd9f3-3a45-4055-b371-dc1f0aa36b05",
    "params": [
        [],
        {}
    ]
}'''


# Generated at 2022-06-25 13:22:13.891681
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = "request"

    # Call method
    result = json_rpc_server_0.handle_request(request)

    # Check result
    assert True



# Generated at 2022-06-25 13:22:16.038260
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.response()


# Generated at 2022-06-25 13:22:19.856656
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    str_arg = b' { "jsonrpc": "2.0", "method":"test", "params": [ "1.0" ], "id": 97 } '
    ret = json_rpc_server_0.handle_request(str_arg)
    print(ret)


# Generated at 2022-06-25 13:22:26.430488
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Test response() method
    json_rpc_server_0 = JsonRpcServer()
    result_dict_1 = {"a": "b"}
    result_dict_2 = {"b": "_"}
    assert json_rpc_server_0.response(result_dict_1) == {"jsonrpc": "2.0", "id": None, "result": '{"a": "b"}'}
    assert json_rpc_server_0.response(result_dict_2) == {"jsonrpc": "2.0", "id": None, "result": '{"b": "_"}'}



# Generated at 2022-06-25 13:22:35.155191
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    jsonrpc_server_0 = JsonRpcServer()
    # Case 0
    try:
        test_case_0()
    except Exception as exc:
        display.error("Exception: " + str(exc))
    finally:
        pass


# Generated at 2022-06-25 13:22:40.468998
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    request = {
        "method":"handle_request",
        "params":[
            {
                "message": "received command"
            }
        ],
        "jsonrpc":"2.0",
        "id":0
    }
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.handle_request(request)
    assert result == {
        "jsonrpc": "2.0",
        "result": "received command",
        "id": 0
    }


# Generated at 2022-06-25 13:22:42.483733
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

    with pytest.raises(Exception):
        json_rpc_server_0.handle_request(request=None)


# Generated at 2022-06-25 13:22:51.916954
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    str_0 = "{""jsonrpc"": ""2.0"", ""method"": ""rpc.test"", ""params"": [1, 2, 3]}";
    str_1 = json_rpc_server_0.handle_request(str_0)
    assert str_1 == "{\"error\": {\"code\": -32600, \"message\": \"Invalid request\"}, \"jsonrpc\": \"2.0\", \"id\": \"1\"}", "Incorrect return: %s" % str_1
    str_0 = "{""jsonrpc"": ""2.0"", ""method"": ""rpc.test"", ""params"": [1, 2, 3], ""id"": 1}";
    str_1 = json_rpc_

# Generated at 2022-06-25 13:22:57.433170
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    params_0 = ["result_0"]
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)
    try:
        result_0 = json_rpc_server_0.response(params_0)
        assert result_0["id"] == "'result_0"
    except AttributeError:
        pass

if __name__ == '__main__':
    test_case_0()
    test_JsonRpcServer_response()

# Generated at 2022-06-25 13:22:58.686427
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    # Test response method
    result = json_rpc_server_0.response()


# Generated at 2022-06-25 13:23:03.830871
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    arg_request_1 = None

    # Call handle_request method of JsonRpcServer
    try:
        print('Testing handle_request in class JsonRpcServer')
        json_rpc_server_1.handle_request(arg_request_1)
    except Exception:
        print('Caught exception: ' + traceback.format_exc())


# Generated at 2022-06-25 13:23:12.205940
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    handle_request = json_rpc_server.handle_request
    # Cleanup JsonRpcServer._objects()
    JsonRpcServer._objects.clear()

    # Add response object
    response_obj_0 = dict()
    response_obj_0["method"] = "connect"
    response_obj_0["params"] = ()
    response_obj_0["id"] = "123"
    response_0 = json.dumps(response_obj_0)
    assert isinstance(handle_request(response_0), str)

    # Add response object
    response_obj_1 = dict()
    response_obj_1["method"] = "get_diff"
    response_obj_1["params"] = ()

# Generated at 2022-06-25 13:23:19.610771
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    test_cases = [
        [{'method': 'foo_0', 'params': [[], {}], 'id': 'foo_id'}, '{"id": "foo_id", "jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}}']
    ]
    for (value_0, expected_value) in test_cases:
        actual_value = json_rpc_server_0.handle_request(value_0)
        if (actual_value != expected_value):
            print('actual_value: ' + actual_value)
            print('expected_value: ' + expected_value)
            assert False


# Generated at 2022-06-25 13:23:26.744976
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create instance of class JsonRpcServer
    json_rpc_server_0 = JsonRpcServer()
    # Create an object of class DummyClass
    dummy_class_1 = DummyClass()
    # Create an object of class DummyClass
    dummy_class_2 = DummyClass()
    # Add objects to the JsonRpcServer object json_rpc_server_0
    json_rpc_server_0.register(dummy_class_1)
    json_rpc_server_0.register(dummy_class_2)
    # Create two inputs for the method handle_request
    jsonrpc_request_3 = '{"jsonrpc": "2.0", "method": "return_str", "params": ["str_arg"], "id": 0}'

# Generated at 2022-06-25 13:23:42.933568
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '\"method\": \"rpc.run\", \"params\":'
    assert json_rpc_server_0.handle_request(request) == '{\"jsonrpc\": \"2.0\", \"id\": 1, \"error\": {\"code\": -32600, \"message\": \"Invalid request\", \"data\": null}}'