

# Generated at 2022-06-25 13:13:51.478580
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    setattr(json_rpc_server_1, '_identifier', "id_1")
    with pytest.raises(Exception):
        result_1 = json_rpc_server_1.response(None)


# Generated at 2022-06-25 13:13:55.819334
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    assert json_rpc_server_0.error(code=1, message="2") == {"jsonrpc": "2.0", "id": "_identifier", "error": {"code": 1, "message": "2"}}


# Generated at 2022-06-25 13:14:05.147081
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)
    value_1 = {}
    value_1['result_type'] = 'pickle'
    value_1['id'] = '0'

# Generated at 2022-06-25 13:14:08.647891
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "foo", "params": {"args": [], "kwargs": {}}, "id": 0}'
    json_rpc_server_0.handle_request(request)


# Generated at 2022-06-25 13:14:11.882297
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request()


# Generated at 2022-06-25 13:14:14.829324
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request({"method": "", "params": "{'args': [], 'kwargs': {}}", "id": 1})


# Generated at 2022-06-25 13:14:18.366128
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    print('>>> unit test: [response] <<<')
    json_rpc_server_1 = JsonRpcServer()
    print(json_rpc_server_1.response())


# Generated at 2022-06-25 13:14:27.071250
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(None)
    setattr(json_rpc_server_0, '_identifier', 'id')
    request='request'
    
    # Test normal case

# Generated at 2022-06-25 13:14:33.967142
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    exc = None
    try:
        json_rpc_server_0 = JsonRpcServer()
        method_ret_val_0 = json_rpc_server_0.error(code=1, message="message")
    except Exception as e:
        exc = e
    assert exc is None
    assert method_ret_val_0 == {
        "jsonrpc": "2.0",
        "id": None,
        "error": {
            "code": 1,
            "message": "message"
        }
    }


# Generated at 2022-06-25 13:14:37.198517
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    assert isinstance(json_rpc_server_0.error(code=99, message='', data=None), dict)


# Generated at 2022-06-25 13:14:50.486079
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

    # Test with a bad request
    bad_request = u'{"foo": "bar"}'
    response = json_rpc_server_0.handle_request(bad_request)
    expected = u'{"id": null, "error": {"code": -32700, "message": "Parse error"}, "jsonrpc": "2.0"}'
    assert response == expected, 'expected: {}, actual: {}'.format(expected, response)

    # Test with Unicode
    request = u'{"params": [["\u5b57\u7b26\u5206\u968a"]], "method": "rpc.run", "jsonrpc": "2.0", "id": 0}'
    response = json_rpc_server_0.handle_

# Generated at 2022-06-25 13:14:53.379357
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    # Call method
    result = json_rpc_server_0.response()
    assert result is not None


# Generated at 2022-06-25 13:15:04.519368
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 0)
    result = server.response()
    assert result['id'] == 0
    assert result['jsonrpc'] == '2.0'
    assert result['result'] == ''
    result = server.response(result='test')
    assert result['result'] == 'test'
    result = server.response(result=b'test')
    assert result['result'] == 'test'
    result = server.response(result=True)
    assert result['result'] == True
    assert result['result_type'] == 'pickle'
    result = server.response(result={'test': 'test'})
    assert result['result'] == {'test': 'test'}
    assert result['result_type'] == 'pickle'

# Unit test

# Generated at 2022-06-25 13:15:06.400131
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request('{"method": "foo", "params": [], "id": ""}')


# Generated at 2022-06-25 13:15:12.552532
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    request = """{"jsonrpc": "2.0","method": "foo","params": [1,2,3,4,5],"id": 1}"""

    assert '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32603, "message": "Internal error", "data": "method object \'foo\' is not callable"}}' == json_rpc_server_1.handle_request(request)


# Generated at 2022-06-25 13:15:13.892843
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # There is no test case for this method at the moment.
    pass


# Generated at 2022-06-25 13:15:15.213302
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    JsonRpcServer.handle_request()

# Generated at 2022-06-25 13:15:18.990803
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # This is just a sample test.
    # Change this to your need.
    json_rpc_server_0 = JsonRpcServer()
    assert json_rpc_server_0.response() == {'jsonrpc': '2.0', 'id': '_identifier', 'result': None}

# Generated at 2022-06-25 13:15:20.981711
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0.response()


# Generated at 2022-06-25 13:15:22.968862
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    if False:
        raise Exception('Assertion failed')


# Generated at 2022-06-25 13:15:29.919058
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = u'{"method": "rpc.method", "params": [], "id": "1.2.3.4"}'
    var_1 = to_text(var_1)
    var_2 = json_rpc_server_0.handle_request(var_1)


# Generated at 2022-06-25 13:15:34.708778
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    class_0 = JsonRpcServer()
    json_rpc_server_0 = JsonRpcServer()
    assert (json_rpc_server_0.handle_request('{"jsonrpc": "2.0", "method": "rpc.method", "params": [1, 2], "id": 1}') == ('{"jsonrpc": "2.0", "error": {"code": -32700, "message": "Parse error"}, "id": 1}') )



# Generated at 2022-06-25 13:15:38.234545
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    a = JsonRpcServer()
    a.handle_request('{"jsonrpc": "2.0", "method": "foobar", "params": [1, 2, 3, 4], "id": "1"}')
    a.handle_request('{"id": "1"}')


# Generated at 2022-06-25 13:15:48.256428
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

    # From docs
    json_rpc_server_0.handle_request(request='{"jsonrpc": "2.0", "method": "sum", "params": [1,2,4], "id": "1"}')

    # Valid request with no params
    json_rpc_server_0.handle_request(request='{"jsonrpc": "2.0", "method": "sum", "id": "1"}')

    # Valid request with missing version
    json_rpc_server_0.handle_request(request='{"method": "sum", "params": [1,2,4], "id": "1"}')

    # Invalid request with missing method

# Generated at 2022-06-25 13:15:56.808462
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = '''{
    "jsonrpc": "2.1",
    "id": "r20",
    "method": "rpc.test_JsonRpcServer_handle_request",
    "params": {
        "args": [
            "Hello World!"
        ],
        "kwargs": {}
    }
}'''

    with mock.patch('ansible.module_utils.network.common.jsonrpc.JsonRpcServer.__init__') as patched_init_0:
        patched_init_0.return_value = None
        var_2 = json_rpc_server_0.handle_request(var_1)
        assert 'invalid_request' in var_2
        assert 'request' in var_

# Generated at 2022-06-25 13:15:58.665417
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request({"id": "1", "params": [["", 0, 0], []], "method": "do_something"})


# Generated at 2022-06-25 13:16:07.456847
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a new instance of JsonRpcServer
    json_rpc_server_0 = JsonRpcServer()
    # Assign a string value to variable request_0
    request_0 = """{"jsonrpc": "2.0", "id": "123", "method": "not_a_valid_method", "params": []}"""
    # Get the handle_request of json_rpc_server_0
    handle_request_0 = json_rpc_server_0.handle_request(request_0)
    # Check the value of handle_request_0
    assert handle_request_0 == """{"jsonrpc": "2.0", "id": "123", "error": {"code": -32601, "message": "Method not found"}}""", "The value of handle_request_0 is not the expected value"

# Generated at 2022-06-25 13:16:12.329047
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = dict()
    request_0['method'] = '_invalid_params'
    request_0['id'] = '0'
    request_0['params'] = [[], {}]
    var_0 = json.dumps(request_0)
    var_1 = json_rpc_server_0.handle_request(var_0)

# Generated at 2022-06-25 13:16:16.643450
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    setattr(JsonRpcServer, '_objects', set())
    setattr(JsonRpcServer, '_objects', {JsonRpcServer()})
    setattr(JsonRpcServer, '_identifier', None)
    setattr(JsonRpcServer, '_identifier', 'JsonRpcServer')


# Generated at 2022-06-25 13:16:20.461702
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = None
    try:
        json_rpc_server_0.handle_request(request)
    except Exception as exc:
        assert False, "Incorrect exception raised: " + type(exc).__name__


# Generated at 2022-06-25 13:16:31.423734
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(JsonRpcServer())
    str_0 = u'{"jsonrpc": "2.0", "method": "invalid_params", "params": [[], {}], "id": 3}'
    str_0 = to_text(str_0)
    str_0 = to_text(str_0)
    var_0 = json_rpc_server_0.handle_request(str_0)
    assert 'error' in var_0


# Generated at 2022-06-25 13:16:40.835800
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # json_rpc_server is an object of JsonRpcServer class
    json_rpc_server = JsonRpcServer()

    # request is an argument of JsonRpcServer class handle_request method
    # request is an instance of unicode
    unicode = '{"method":"db_connect", "params":[], "id":15643212}'
    request = unicode

    # connection is an argument of JsonRpcServer class handle_request method
    # connection is an instance of Connection
    connection = '{"method":"db_connect", "params":[], "id":15643212}'

    # AnsibleModule is an argument of JsonRpcServer class handle_request method
    # AnsibleModule is an instance of AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-25 13:16:49.980029
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    setattr(JsonRpcServer, '_identifier', None)
    json_rpc_server_0 = JsonRpcServer()

    try:
        json.loads("{{ module_args }}")
    except Exception:
        display.display('Unable to decode "{{ module_args }}". Assuming it is already a Python object')
        var_0 = json.loads("{{ module_args }}")
    else:
        var_0 = json.loads("{{ module_args }}")
    if var_0['method'].startswith("rpc.") or var_0['method'].startswith("_"):
        var_1 = json_rpc_server_0.invalid_request()
    else:
        var_2, var_3 = getattr(var_0, 'params')

# Generated at 2022-06-25 13:16:58.646703
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    json = json.loads(server.handle_request(''))
    assert json['jsonrpc'] == '2.0'
    assert json['id'] is None
    assert json['error']['code'] == -32600
    assert json['error']['message'] == 'Invalid request'

    json = json.loads(server.handle_request('{"jsonrpc": "2.0", "method": "foobar"}'))
    assert json['error']['code'] == -32600

    json = json.loads(server.handle_request('{"jsonrpc": "2.0", "method": "rpc.foobar", "params": ["bar", 1]}'))
    assert json['error']['code'] == -32600


# Generated at 2022-06-25 13:17:06.794169
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    try:
        # Setup a test case
        json_rpc_server_0 = JsonRpcServer()
        var_0 = json_rpc_server_0.invalid_params()

        # Perform action
        var_1 = json_rpc_server_0.handle_request(var_0)

        # Verify
        assert var_1 is not None, "Failed: JsonRpcServer.handle_request"

    except Exception as e:
        print (e)
        return False
    else:
        return True

if __name__ == '__main__':
    print(test_case_0())
    print(test_JsonRpcServer_handle_request())

# Generated at 2022-06-25 13:17:14.062202
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    str_0 = json_rpc_server_0.handle_request("""{"jsonrpc": "2.0", "method": "rpc.get", "params": [{"test_string"}], "id": 0}""")
    assert str_0[0:1] == "["
    json_rpc_server_1 = JsonRpcServer()
    str_1 = json_rpc_server_1.handle_request("""{"id": 1, "jsonrpc": "2.0", "method": "rpc._error_code", "params": [{"test_string"}]}""")
    assert str_1[0:1] != "["
    json_rpc_server_2 = JsonRpcServer()
    str_2 = json

# Generated at 2022-06-25 13:17:18.193671
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.invalid_params()
    var_1 = json_rpc_server_0.invalid_request()
    var_2 = json_rpc_server_0.response()

# Generated at 2022-06-25 13:17:21.154946
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

    # TypeError: 
    with pytest.raises(TypeError):
        assert json_rpc_server_0.handle_request()


# Generated at 2022-06-25 13:17:25.931859
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    var_1 = json_rpc_server_1.handle_request(json.dumps({'jsonrpc': '2.0', 'method': 'invalid_params', 'params': [], 'id': 1}))
    assert var_1 == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32602, "message": "Invalid params"}}'


# Generated at 2022-06-25 13:17:28.136975
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
  print('Test JsonRpcServer_handle_request')
  json_rpc_server = JsonRpcServer()
  json_rpc_server.handle_request("{\"method\": \"error\"}")


# Generated at 2022-06-25 13:17:37.372591
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Initialize json_rpc_server_1_obj with default values
    json_rpc_server_1_obj = JsonRpcServer()

    # Use test_data_0 for the test
    test_data_0 = json.dumps({'params': [], 'method': 'run', 'id': 30})
    # Make the call to handle_request()
    json_rpc_server_1_obj.handle_request(test_data_0)

# Generated at 2022-06-25 13:17:42.420911
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    text_0 = json.dumps({'jsonrpc': '2.0', 'method': 'rpc.echo', 'params': [''], 'id': '1'})
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request(text_0)



# Generated at 2022-06-25 13:17:47.387112
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = '["foo"]'
    response_0 = json_rpc_server_0.handle_request(request_0)
    assert response_0 == '{"jsonrpc": "2.0", "id": null, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-25 13:17:48.944146
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

    # Test case 0
    test_case_0()

# Generated at 2022-06-25 13:17:52.800541
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Generate data
    jsonrpc = '2.0'
    method = 'get_capabilities'
    params = dict()
    id = 0

    # Create object
    json_rpc_server_1 = JsonRpcServer()

    # Invoke method
    result_1 = json_rpc_server_1.handle_request(jsonrpc, method, params, id)


# Generated at 2022-06-25 13:17:57.241421
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    params = { "method": "shell", "id": 7, "params": [ "" ] }
    result = json_rpc_server_0.handle_request(params)
    assert result == "{\"jsonrpc\": \"2.0\", \"id\": 7}"


# Generated at 2022-06-25 13:18:01.588748
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request(request={'params': ({'method': '_identifier'}, {'message': 'Method not found'}), 'method': 'invalid_params', 'id': '-32700'})



# Generated at 2022-06-25 13:18:10.100142
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    var_1 = '{"id": "123", "method": "rpc.connection.get", "params": []}'
    var_2 = json.loads(var_1)
    var_2 = json.loads(var_1)
    var_3 = var_2.get('method')

    if var_3.startswith('rpc.') or var_3.startswith('_'):
        test_case_0()

    var_4, var_5 = var_2.get('params')
    setattr(json_rpc_server_0, '_identifier', var_2.get('id'))

    var_6 = None
    for var_7 in json_rpc_server_0._objects:
        var_6 = getattr(var_7, var_3, None)

# Generated at 2022-06-25 13:18:19.379514
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Initialize the class
    json_rpc_server = JsonRpcServer()

    request = '''{"jsonrpc": "2.0", "method": "foo", "params": [], "id": 1}'''
    response = json_rpc_server.handle_request(request)

    # Create the expected result
    expected_response = '''{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'''

    # Compare result with expected_result
    assert response == expected_response


if __name__ == "__main__":
    test_case_0()

    # Unit test for method handle_request of class JsonRpcServer
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:18:23.977608
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Input param 'request':
    request = {"jsonrpc": "2.0", "params": [[], {}], "method": "m0", "id": "0"}

    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request(request)


# Generated at 2022-06-25 13:18:38.986419
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    var_1 = JsonRpcServer()
    var_2 = '{ "jsonrpc": "2.0", "method": "rpc.foo", "params": [ [], {} ]}'
    var_3 = var_1.handle_request(var_2)
    var_4 = {'jsonrpc': '2.0', 'id': 2, 'error': {'code': -32600, 'message': 'Invalid request', 'data': None}}
    assert var_3 == var_4

    var_5 = '{ "jsonrpc": "2.0", "method": "_foo", "params": [ [], {} ]}'
    var_6 = var_1.handle_request(var_5)

# Generated at 2022-06-25 13:18:41.309776
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Instantiate JsonRpcServer object
    json_rpc_server = JsonRpcServer()

    assert True is True

# Generated at 2022-06-25 13:18:43.639138
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    var = json_rpc_server.handle_request({"method":"_","params":[]})


# Generated at 2022-06-25 13:18:51.970034
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-25 13:18:55.997611
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = '{"jsonrpc": "2.0", "method": "_", "params": [], "id": 1}'
    try:
        var_2 = json_rpc_server_0.handle_request(var_1)
    except Exception as exc:
        display.vvv(traceback.format_exc())


# Generated at 2022-06-25 13:19:05.091900
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = "\"params\": [[\"a\", \"b\"]]"
    var_2 = "\"method\": \"test_case_0\""
    var_3 = "\"jsonrpc\": \"2.0\""
    var_4 = "@handle_request of class JsonRpcServer test case 0"
    var_5 = "\"id\": 1"
    var_6 = ", ".join((var_3, var_5, var_2, var_1))
    var_7 = "{" + var_6 + "}"
    var_8 = json_rpc_server_0.handle_request(var_7.encode("UTF-8"))


# Generated at 2022-06-25 13:19:09.021583
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc = JsonRpcServer()

    x = json_rpc.handle_request('{"method": "foo", "params": [], "id": 1}')

    assert 'error' in json.loads(x)
    assert 'code' in json.loads(x)["error"]
    assert 'message' in json.loads(x)["error"]


# Generated at 2022-06-25 13:19:12.469772
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.invalid_params()
    var_2 = json_rpc_server_0.handle_request(var_1)


# Generated at 2022-06-25 13:19:14.815962
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    result_0 = json_rpc_server_0.handle_request('request_0')


# Generated at 2022-06-25 13:19:15.841868
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.invalid_params()

# Generated at 2022-06-25 13:19:31.604633
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = '{"jsonrpc": "2.0", "method": "rpc.get_connection", "params": [], "id": "someid"}'
    var_0 = json_rpc_server_0.handle_request(request_0)
    assert var_0 == '{"jsonrpc": "2.0", "id": "someid", "error": {"code": -32601, "message": "Method not found"}}'
    request_1 = '{"jsonrpc": "2.0", "method": "run", "params": [], "id": "someid"}'
    var_1 = json_rpc_server_0.handle_request(request_1)

# Generated at 2022-06-25 13:19:33.375175
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    var = json_rpc_server.invalid_params()


# Generated at 2022-06-25 13:19:36.091896
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    res = to_text(JsonRpcServer().handle_request(to_text({'method': 'rpc.test', 'params': [], 'id': 0})))
    assert '"code": -32600' in res


# Generated at 2022-06-25 13:19:37.982866
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    assert isinstance(json_rpc_server_0.handle_request("{}"), str)


# Generated at 2022-06-25 13:19:44.454229
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    TEST_CASES = [
        {
            "code": "var_0 = json_rpc_server_0.invalid_params()"
        }
    ]

    TEST_RESULTS = [
        {
            "code": "var_0 = json_rpc_server_0.invalid_params()"
        }
    ]

    test_runner(TEST_CASES, TEST_RESULTS)

# Generated at 2022-06-25 13:19:47.953155
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request('{"jsonrpc": "2.0", "method": "foobar", "id": 1}')
    print(var_0)


# Generated at 2022-06-25 13:19:53.362197
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Prepare input args
    request = '{"jsonrpc": "2.0", "method": "hello", "params": [42, 23], "id": 1}'

    # Execute the run function
    response = JsonRpcServer.handle_request(request)

    # Verify the results
    assert (response == '{"jsonrpc": "2.0", "method": "hello", "params": [42, 23], "id": 1}')

# Generated at 2022-06-25 13:19:58.154993
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    # JsonRpcServer object is created.
    json_rpc_server_0 = JsonRpcServer()

    # JSON request is created
    json_reqest_0 = "{\"jsonrpc\":\"2.0\", \"method\":\"rpc.method\", \"params\":[[],{}], \"id\":2}"

    # call handle_request method
    json_rpc_server_0.handle_request(json_reqest_0)

# Generated at 2022-06-25 13:20:01.407574
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request('{"jsonrpc": "2.0", "method": "run", "params": null, "id": "1"}')
    assert var_0 is not None


# Generated at 2022-06-25 13:20:11.088796
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = u'{"jsonrpc": "2.0", "result": {"foobar": "baz"}, "id": null}'
    var_2 = json_rpc_server_0.handle_request(var_1)
    var_3 = u'{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request", "data": "Unknown JSON-RPC method: foobar"}, "id": null}'
    assert var_2 == var_3
    var_4 = u'{"jsonrpc": "2.0", "id": null}'
    var_5 = json_rpc_server_0.handle_request(var_4)

# Generated at 2022-06-25 13:20:26.061053
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = """{"params": [], "id": "1", "method": "get_config"}"""
    var_1 = json_rpc_server_0.handle_request(var_0)


# Generated at 2022-06-25 13:20:34.819146
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    rpc_server = JsonRpcServer()

    class TestModule(object):

        def test_method(self):
            return dict(method='_test_method', params=dict(bar='baz'))

    rpc_server.register(TestModule())
    request = '{"jsonrpc": "2.0", "method": "test_method", "params": ["foo", "bar"], "id": "baz"}'

    response = rpc_server.handle_request(request)

    expected_response = '{"jsonrpc": "2.0", "id": "baz", "result_type": "pickle", "result": " \\u0005\\u0006U\\u0012_test_method\\n}U\\u0004barV\\u0004bazub."}'

    assert response == expected_

# Generated at 2022-06-25 13:20:36.525399
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = var_0
    json_rpc_server_0.handle_request(request_0)

# Generated at 2022-06-25 13:20:41.543918
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    try:
        print("Test #0 - " + "handle_request")
        test_case_0()
        print("Test #0 passed\n")
    except AssertionError as e:
        print("Test #0 failed\n")
        raise

test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:20:45.195326
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    request_2 = str('')
    var_2 = json_rpc_server_1.handle_request(request_2)
    assert isinstance(var_2, str)
    assert var_2 == str('')

# Generated at 2022-06-25 13:20:50.359485
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    if (json_rpc_server_0.handle_request('{"jsonrpc": "2.0", "method": "say_hello"}') == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": null}'):
        return "Pass"
    else:
        return "Fail"


# Generated at 2022-06-25 13:20:53.543996
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request(var_0)


# Generated at 2022-06-25 13:20:56.804849
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.invalid_params()
    var_1 = json_rpc_server_0.handle_request(var_0)


# Generated at 2022-06-25 13:21:05.397251
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '{"jsonrpc":"2.0", "id": "123", "method": "echo", "params": ["Hello"]}'
    json_rpc_server_0.handle_request(request)
    request = '{"jsonrpc":"2.0", "id": "123", "method": "echo", "params": []}'
    json_rpc_server_0.handle_request(request)
    request = '{"jsonrpc":"2.0", "id": "123", "method": "echo"}'
    json_rpc_server_0.handle_request(request)
    request = '{"jsonrpc":"2.0", "id": "123", "method": "rpc.echo"}'
    json_rpc_server_

# Generated at 2022-06-25 13:21:08.987210
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # Test appropriate exception throw if the method handle_request is called with invalid types of arguments
    try:
        json_rpc_server_0.handle_request()
    except TypeError as err:
        assert "wrong number of arguments" in str(err)


# Generated at 2022-06-25 13:21:38.304306
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    var_1 = b'{"method":"echo","params":[{"args":[],"kwargs":{}}],"jsonrpc":"2.0","id":0}'
    var_2 = json_rpc_server_1.handle_request(var_1)


# Generated at 2022-06-25 13:21:42.353934
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.something", "params": [], "id": "123"}'
    result = server.handle_request(request)
    assert result == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": "123"}'


# Generated at 2022-06-25 13:21:48.424872
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = b'{"id": null, "jsonrpc": "2.0", "error": {"code": -32603, "message": "Internal error", "data": "unicode error: \'utf-8\' codec can\'t decode byte 0x8c in position 0: invalid start byte\n"}, "result": null}'
    var_2 = json_rpc_server_0.handle_request()

    test_case_0()
    assert var_1 == var_2



# Generated at 2022-06-25 13:21:51.864022
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    json_rpc_server_1.register(json_rpc_server_1)
    var_1 = json_rpc_server_1.handle_request('')


# Generated at 2022-06-25 13:21:57.017986
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    str_0 = u'{"jsonrpc": "2.0", "method": "rpc._page", "params": {"page": "aa", "page_size": "bb"}, "id": "123"}'
    # AssertionError: <Response> is not JSON serializable
    #
    # json_rpc_server_0.handle_request(str_0)

if __name__ == '__main__':
    test_case_0()
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:21:58.844360
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request(request_0)

# Generated at 2022-06-25 13:22:00.554447
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    str_0 = json_rpc_server_0.handle_request()

# Generated at 2022-06-25 13:22:03.253507
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    try:
        request = '{}'
        expected = False
        actual = json_rpc_server.handle_request(request)
    except Exception:
        assert False


# Generated at 2022-06-25 13:22:12.189846
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    rpc_module = MockJsonRpcModule()
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(rpc_module)
    var_1 = json_rpc_server_0.handle_request({"method": "jsonrpc_version", "params": [], "id": "fb8f5738-edb0-11e6-8a63-071b9d83dea0"})
    var_2 = json_rpc_server_0.handle_request({"method": "run_command", "params": [[],[],[]], "id": "fb8f5738-edb0-11e6-8a63-071b9d83dea0"})
    var_3 = json_rpc_server_0.handle

# Generated at 2022-06-25 13:22:18.809914
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    m_0 = JsonRpcServer()
    m_0.register(m_0)
    m_1 = '''{
  "jsonrpc": "2.0",
  "method": "Ansible.set_options",
  "params": {
    "connection": "network_cli",
    "auth_pass": "",
    "host": "",
    "network_os": "ios",
    "timeout": 10,
    "port": 0,
    "remote_port": 22,
    "username": ""
  },
  "id": 0
}'''


# Generated at 2022-06-25 13:23:18.306343
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json.load(to_text(var_0))
    var_2 = {'jsonrpc': '2.0', 'id': var_0}
    var_3 = json.dumps(var_2)
    return var_3


# Generated at 2022-06-25 13:23:19.057215
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # TODO: mock not implemented
    pass



# Generated at 2022-06-25 13:23:24.458445
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()

    # Handle invalid request
    response = server.handle_request('{"method": "invalid"}')
    assert response == b'{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": null}'

    # Handle method not found
    response = server.handle_request('{"method": "frobnicate"}')
    assert response == b'{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": null}'



# Generated at 2022-06-25 13:23:31.714477
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import pickle
    # Example usage
    json_rpc_server = JsonRpcServer()

    # Assigning text value to a pickleable object.
    pickleable_object = pickle.Pickler()

    # Assigning text value to a text object.
    text_object = 'This is a text object'

    # Calling method handle_request of json_rpc_server using positional arguments.
    # print(json_rpc_server.handle_request({"method": 'pickleable_object', "params": [], "id": 10}))
    response = json_rpc_server.handle_request({"method": 'pickleable_object', "params": [], "id": 10})
    result_pkg = json.loads(response)
    print(result_pkg)
    # This will print a python object if the

# Generated at 2022-06-25 13:23:34.062054
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    json_rpc_server.handle_request(b'{"jsonrpc": "2.0", "method": "foobar", "params": [1, 2, 3], "id": 1}')