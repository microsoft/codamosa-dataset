

# Generated at 2022-06-25 13:13:56.313024
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-25 13:14:00.150009
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    try:
        json_rpc_server_0 = JsonRpcServer()
        json_rpc_server_0.error(code, message, data)
    except Exception:
        display.vvv(traceback.format_exc())
        raise


# Generated at 2022-06-25 13:14:04.562667
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.error(code=code, message=message, data=data)
    assert result['error']['code'] == code
    assert result['error']['message'] == message
    assert result['error']['data'] == data



# Generated at 2022-06-25 13:14:07.621547
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()

    result = None
    # result: String
    # response: String
    response = json_rpc_server_0.response(result)



# Generated at 2022-06-25 13:14:10.384262
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    obj = JsonRpcServer()
    result = obj.response(result=None)
    print(result)

# Generated at 2022-06-25 13:14:12.744045
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = 'test'
    json_rpc_server_0.handle_request(request)


# Generated at 2022-06-25 13:14:20.815815
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server = JsonRpcServer()
    # Test response with no error
    result = json_rpc_server.error(code=None, message=None)
    assert(result == {'id': None, 'jsonrpc': '2.0'})
    # Test response with error
    result = json_rpc_server.error(code=-32601, message='Method not found')
    assert(result == {'id': None, 'jsonrpc': '2.0', 'error': {'code': -32601, 'message': 'Method not found'}})


# Generated at 2022-06-25 13:14:23.137164
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = None # type: str
    json_rpc_server_0.response(result)


# Generated at 2022-06-25 13:14:30.209252
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # ModuleFixture.load_fixtures(ansible_module, fixtures)
    # mock_get_connection = patch.object(
    # ansible_module, '_get_connection').start()
    json_rpc_server_0.handle_request('{"params": [[], {}], "method": "get_config", "id": 9}')
    # mock_get_connection.assert_called_with(
    # **{'network_os': 'nxos'})
    # mock_edit_config = patch.object(
    # nxos_facts_0, 'edit_config').start()
    # nxos_facts_0.edit_config(**{'candidate': None, 'config': 'hostname localhost\n'})
   

# Generated at 2022-06-25 13:14:37.707864
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.response()
    response = json_rpc_server_0.header()
    if isinstance(result, binary_type):
        result = to_text(result)
    if not isinstance(result, text_type):
        response["result_type"] = "pickle"
        result = to_text(cPickle.dumps(result, protocol=0))
    response['result'] = result
    assert response == result


# Generated at 2022-06-25 13:14:51.359022
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = b'{"method":"shell","params":[["show version"]],"id":"d4e78c6429db4c7ab613f8d170b7a17b"}'
    result = json_rpc_server_0.handle_request(request_0)
    print(result)
    request_0 = b'{"method":"shell","params":[["show version"]],"id":"d4e78c6429db4c7ab613f8d170b7a17b"}'
    result = json_rpc_server_0.handle_request(request_0)
    print(result)

# Generated at 2022-06-25 13:14:53.518341
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request(request)


# Generated at 2022-06-25 13:14:59.875364
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    code_0 = 0
    message_0 = 'random string'
    data_0 = 'random string'
    try:
        error_0 = json_rpc_server_0.error(code_0, message_0, data_0)
    except Exception as exc:
        print(exc)


# Generated at 2022-06-25 13:15:02.308443
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = '{\n    "jsonrpc": "2.0",\n    "method": "data_read"\n}'
    result_0 = json_rpc_server_0.handle_request(request_0)


# Generated at 2022-06-25 13:15:06.109400
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0._identifier = mock.Mock(return_value='example_0')
    str_0 = json_rpc_server_0.response(result='example_1')
    assert str_0 == 'example_2'

# Generated at 2022-06-25 13:15:09.564424
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '''{ "jsonrpc": "2.0", "method": "hello", "params": {}, "id": 1 }'''
    json_rpc_server_0.handle_request(request)


# Generated at 2022-06-25 13:15:14.843149
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    ansible_connection_0 = AnsibleConnection()
    json_rpc_server_0.register(ansible_connection_0)
    assert 'result_type' in json_rpc_server_0.handle_request('{"id": "1", "method": "get_hostname", "params": [], "jsonrpc": "2.0"}')

# Generated at 2022-06-25 13:15:18.771813
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():

    # default test case
    result = json_rpc_server_0.error(code=0, message='')

    # error test case
    if is_error_test:
        result = json_rpc_server_0.error(code='', message=0)
    assert (result == None)


# Generated at 2022-06-25 13:15:19.723417
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    assert False

# Generated at 2022-06-25 13:15:21.913113
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    assert json_rpc_server_1 is not None


# Generated at 2022-06-25 13:15:26.780884
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    test_0()


# Generated at 2022-06-25 13:15:29.272093
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.error(var_code=3278, var_message='dolor')


# Generated at 2022-06-25 13:15:31.972932
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.response()

    assert result == {'jsonrpc': '2.0', 'id': None, 'result': 'None'}


# Generated at 2022-06-25 13:15:33.967420
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request('{"jsonrpc":"2.0","method":"echo","params":{"args":[], "kwargs":{"message":"hello world!"}},"id":1}')


# Generated at 2022-06-25 13:15:35.617985
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()

# Generated at 2022-06-25 13:15:37.416046
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.response()


# Generated at 2022-06-25 13:15:40.105864
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.error(code=0, message="Error")


# Generated at 2022-06-25 13:15:42.893411
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server = JsonRpcServer()
    result_obj = json_rpc_server.response()
    assert(result_obj)



# Generated at 2022-06-25 13:15:44.970287
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.response()



# Generated at 2022-06-25 13:15:53.313455
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
  json_rpc_server = JsonRpcServer()
  json_rpc_server._identifier = cPickle.loads(b'\x80\x03X\x01\x00\x00\x00K\x00.')
  code = cPickle.loads(b'\x80\x03X\x01\x00\x00\x00K\x00.')
  message = cPickle.loads(b"\x80\x03X\x03\x00\x00\x00\x66oo'\nX\x06\x00\x00\x00resultq\x00.")
  result = json_rpc_server.error(code=code, message=message)


# Generated at 2022-06-25 13:16:06.409052
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request(0)
    json_rpc_server_1 = JsonRpcServer()
    json_rpc_server_1.handle_request(0)
    json_rpc_server_2 = JsonRpcServer()
    json_rpc_server_2.handle_request(0)
    json_rpc_server_3 = JsonRpcServer()
    json_rpc_server_3.handle_request(0)
    json_rpc_server_4 = JsonRpcServer()
    json_rpc_server_4.handle_request(0)
    json_rpc_server_5 = JsonRpcServer()
    json_rpc_server_5.handle_

# Generated at 2022-06-25 13:16:07.813419
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    var_0 = JsonRpcServer()
    var_1 = var_0.response()
    assert var_1 == {'jsonrpc': '2.0', 'id': 1, 'result': None}


# Generated at 2022-06-25 13:16:09.952594
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    assert json_rpc_server_0.handle_request() == '{}'


# Generated at 2022-06-25 13:16:12.012700
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()

# Generated at 2022-06-25 13:16:14.067700
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:16:18.434820
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(JsonRpcServer())
    result_0 = json_rpc_server_0.handle_request(var_0)
    assert isinstance(result_0, str)
    assert result_0 == var_1


# Generated at 2022-06-25 13:16:20.387131
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.handle_request()



# Generated at 2022-06-25 13:16:24.005565
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.handle_request('{"jsonrpc": "2.0", "method": "echo", "id": "1"}')
    assert var_1 == '{"jsonrpc": "2.0", "id": "1", "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-25 13:16:28.381717
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request('{"params": [], "jsonrpc": "2.0", "id": 1, "method": "test_case_0"}')


# Generated at 2022-06-25 13:16:30.807888
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    # Test without arguments
    json_rpc_server_1 = JsonRpcServer()
    var_1 = json_rpc_server_1.error()


# Generated at 2022-06-25 13:16:39.937588
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # AssertionError: 'id' not in {'jsonrpc': '2.0', 'id': None}
    # assert self.header() == result
    pass

if __name__ == '__main__':
    print("Running unit tests for json_rpc_jsonrpc.py")
    test_case_0()
    # test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:16:45.884828
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Invoke method
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request(request=None)
    assert var_0 == None
    # Invoke method
    json_rpc_server_1 = JsonRpcServer()
    var_1 = json_rpc_server_1.handle_request(request=None)
    assert var_1 == None


# Generated at 2022-06-25 13:16:50.055393
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    json_rpc_server_0 = JsonRpcServer()

    # test case for handle_request

    method = 'rpc.test'
    json_rpc_server_0._identifier = 1
    json_rpc_server_0.response()


if __name__ == '__main__':
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:16:51.876814
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    mem = TestJsonRpcServerClass()
    json_rpc_server_0 = JsonRpcServer()
    json.loads(mem.handle_request(json_rpc_server_0))


# Generated at 2022-06-25 13:16:56.796528
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    json_rpc_server_0 = JsonRpcServer()
    request = {'method': 'test', 'params': {'args': [], 'kwargs': {}}, 'id': 1}
    try:
        response = json_rpc_server_0.handle_request(request)
    except Exception:
        display.vvv(traceback.format_exc())
        raise



# Generated at 2022-06-25 13:16:59.544805
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request('{"id": "1", "method": "test_method", "params": [[], {}]}')


# Generated at 2022-06-25 13:17:02.277320
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server = JsonRpcServer()
    var = json_rpc_server.response()


# Generated at 2022-06-25 13:17:05.635110
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response(None)

    assert var_0 == {'id': None, 'jsonrpc': '2.0', 'result': None}


# Generated at 2022-06-25 13:17:06.469621
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    pass


# Generated at 2022-06-25 13:17:09.576889
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    var_1 = json_rpc_server_1.response()
    assert(var_1['jsonrpc'] == '2.0')


# Generated at 2022-06-25 13:17:15.955101
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server = JsonRpcServer()
    var_0 = json_rpc_server.response()


# Generated at 2022-06-25 13:17:23.848577
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    print("Testing handle_request")

    json_rpc_server_0 = JsonRpcServer()
    # Handle requests with no params.
    json_rpc_server_0.handle_request({'method': 'run_command'})

    # Handle requests with params
    json_rpc_server_0.handle_request({'method': 'run_command', 'params': ['show version', 'text']})

    json_rpc_server_0.handle_request({'method': 'run_command', 'params': [{'command': 'show version', 'output': 'text'}]})

if __name__ == "__main__":
    test_case_0()
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:17:25.860863
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.error(code=1000, message='test')


# Generated at 2022-06-25 13:17:29.816125
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    data_0 = 'o/6n\x00}q\x00(dp\x01r\x00]q\x02(U\x06jsonrpcq\x03U\x021.0q\x04sb\x85Rq\x05(U\x03idq\x06U\x001q\x07sb.'
    data_0_0 = json_rpc_server_0.response(data_0)


# Generated at 2022-06-25 13:17:30.630157
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    #@TODO: Unimplemented test
    pass


# Generated at 2022-06-25 13:17:33.677783
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Test cases for method response of class JsonRpcServer
    json_rpc_server_1 = JsonRpcServer()
    var_1 = json_rpc_server_1.response()

# Generated at 2022-06-25 13:17:37.241821
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.header()
    var_2 = json_rpc_server_0.error(-32700, 'Parse error')


# Generated at 2022-06-25 13:17:42.822785
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    def __init__(self, *args, **kwargs):
        pass
    with patch.object(JsonRpcServer, 'handle_request', autospec=True) as mock_method:
        mock_method.return_value = None
        json_rpc_server_1 = JsonRpcServer()
        var_0 = json_rpc_server_1.handle_request()


# Generated at 2022-06-25 13:17:44.931980
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    var_1 = JsonRpcServer()
    # Invoke method
    var_2 = var_1.response()


# Generated at 2022-06-25 13:17:52.890954
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.handle_request("{\"jsonrpc\": \"2.0\", \"method\": \"foobar\", \"params\": [1, 2, 3], \"id\": 1}")
    var_2 = json_rpc_server_0.handle_request("{\"jsonrpc\": \"2.0\", \"method\": \"foobar\", \"params\": \"bar\", \"id\": \"1\"}")
    var_3 = json_rpc_server_0.handle_request("{\"jsonrpc\": \"2.0\", \"method\": \"foobar\", \"params\": {\"foo\": \"bar\"}, \"id\": 1}")

# Generated at 2022-06-25 13:18:09.536216
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    var_0 = json.loads('{"jsonrpc": "2.0", "id": 0, "result": "YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=", "result_type": "pickle"}')
    var_1 = json.loads('{"jsonrpc": "2.0", "id": 0, "result": "abcdefghijklmnopqrstuvwxyz"}')
    var_2 = json.loads('{"jsonrpc": "2.0", "id": 0, "result": "YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo=", "result_type": "pickle"}')

# Generated at 2022-06-25 13:18:10.927078
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.error(1, 'test')


# Generated at 2022-06-25 13:18:13.222004
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()



# Generated at 2022-06-25 13:18:14.850474
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:18:18.511981
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.error(code=-32700, message='Parse error')


# Generated at 2022-06-25 13:18:22.873475
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    with pytest.raises(AttributeError) as excinfo:
        json_rpc_server_1 = JsonRpcServer()
        var_1 = json_rpc_server_1.error(code=exc.code, message=to_text(exc))
        excinfo.match('code')


# Generated at 2022-06-25 13:18:25.557157
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 13:18:27.804295
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    json_rpc_server.handle_request({'method': 'rpc.test', 'params': [], 'id': '1'})
    json_rpc_server.handle_request({'method': '_test', 'params': [], 'id': '1'})

# Generated at 2022-06-25 13:18:29.462457
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    var_1 = json_rpc_server_1.handle_request(request="!@#$%")

# Generated at 2022-06-25 13:18:38.115044
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.handle_request('{\"jsonrpc\": \"2.0\", \"method\": \"no_exist\", \"params\": [], \"id\": \"066f85d9-d11a-4c29-9810-b3da3a1d1435\"}')
    var_2 = json_rpc_server_0.handle_request('{\"jsonrpc\": \"2.0\", \"method\": \"rpc.method\", \"params\": [], \"id\": \"066f85d9-d11a-4c29-9810-b3da3a1d1435\"}')

# Generated at 2022-06-25 13:19:09.843434
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    request_2 = {}
    try:
        json_rpc_server_1.handle_request(request=request_2)
    except Exception:
        pass


# Generated at 2022-06-25 13:19:12.276339
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Test JsonRpcServer.response with basic arguments
    json_rpc_server_1 = JsonRpcServer()
    var_1 = json_rpc_server_1.response()


# Generated at 2022-06-25 13:19:17.798658
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

    # Get argument where we are going to execute the handle_request method
    request_0 = json.dumps({"jsonrpc": "2.0", "method": "handle_request", "params": [], "id": 1})

    result_0 = json_rpc_server_0.handle_request(request_0)

    if (result_0 != request_0):
        raise AssertionError()



# Generated at 2022-06-25 13:19:27.699404
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    assert json_rpc_server_0.handle_request(to_text('')) == '{"jsonrpc":"2.0","id":null,"error":{"code":-32600,"message":"Invalid request"}}'

# Generated at 2022-06-25 13:19:36.017499
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    # Test 1
    request = '{"jsonrpc": "2.0", "method": "rpc.", "params": [], "id": 1}'
    try:
        actual = json_rpc_server.handle_request(request)
    except Exception as e:
        print(e)
    else:
        expected = '{"id": 1, "error": {"data": null, "message": "Invalid request", "code": -32600}, "jsonrpc": "2.0"}'
        if actual == expected:
            print('PASSED')
        else:
            print('FAILED: expected: {}, actual: {}'.format(expected, actual))

if __name__ == '__main__':
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:19:39.094331
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Test case for validating JsonRpcServer.response method
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.response()
    print(var_1)


# Generated at 2022-06-25 13:19:46.324113
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    response_log = """{"jsonrpc": "2.0", "result": "result", "id": "id"}"""
    expected_result = {'jsonrpc': '2.0', "result": "result", "id": "id"}
    test_instance = JsonRpcServer()
    setattr(test_instance, '_identifier', 'id')

    result = test_instance.response("result")
    if isinstance(result, str):
      result = json.loads(result)

    assert result == expected_result
    assert response_log == str(result)

# Generated at 2022-06-25 13:19:51.674690
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    #func_call = "handle_request"
    json_rpc_server_0 = JsonRpcServer()
    message_0 = ""

    try:
        json_rpc_server_0.handle_request(message_0)
    except Exception as e:
        assert False, "Test Failed"
    else:
        assert True, "Test Passed"

test_JsonRpcServer_handle_request()


# Generated at 2022-06-25 13:19:53.852333
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Test case 0
    print("Test case: 0")
    test_case_0()


# Run the test cases
test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:19:56.771468
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    var_1 = json_rpc_server_1.handle_request('{"id":1,"method":"_test_method","params":[[],{}]}')


# Generated at 2022-06-25 13:20:18.310332
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = {"code": 17, "message": "foo"}
    var_1 = json_rpc_server_0.response()
    var_2 = json_rpc_server_0.error(var_0, "foo")
    print("code:",var_2['code'],"message:",var_2['message'])
    print("id:",var_2['id'],"jsonrpc:",var_2['jsonrpc'])
    assert var_2['code']==var_0['code']
    assert var_2['message']==var_0['message']


# Generated at 2022-06-25 13:20:23.171664
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    request = '{"jsonrpc": "2.0", "method": "rpc.echo", "params": ["hello world"], "id": 1}'

    json_rpc_server_0 = JsonRpcServer()
    response = json_rpc_server_0.handle_request(request)
    assert response
    assert response['id'] == 1
    assert response['result'] == 'hello world'

# Generated at 2022-06-25 13:20:26.733032
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.handle_request('{"jsonrpc": "2.0", "method": "rpc.method_not_found", "params": [{}], "id": "1"}')


# Generated at 2022-06-25 13:20:29.429662
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    var_1 = JsonRpcServer()
    var_2 = var_1.response(100)
    assert isinstance(var_2, dict)
    assert var_2['id'] == None


# Generated at 2022-06-25 13:20:34.478205
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request("""{"jsonrpc": "2.0", "method": "echo", "params": [1,2,4], "id": 1}""")
    assert var_0 == b'{"jsonrpc": "2.0", "result": "[1, 2, 4]", "id": 1}'


# Generated at 2022-06-25 13:20:40.646038
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Initialization of variables
    json_rpc_server = JsonRpcServer()
    try:
        # Test method JsonRpcServer.handle_request
        var_result = json_rpc_server.handle_request("{'jsonrpc': '2.0', 'id': '2', 'method': 'method_name', 'params': [1, 2, 4]}")
    except Exception:
        display.error('Error detected. See Ansible traces for more information.')
        traceback.print_exc()


# Generated at 2022-06-25 13:20:46.737319
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request("""{"jsonrpc": "2.0", "id": "abcdef", "method": "search", "params": {"src": ["/var/log/messages", "/var/log/secure"], "pattern": "ansible"} }""")
    assert var_0 == """"{"jsonrpc": "2.0", "id": "abcdef", "result": "[]"}"""


# Generated at 2022-06-25 13:20:54.743491
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    var_1 = '''{
    "jsonrpc": "2.0",
    "method": "foo",
    "id": 1
}'''
    var_2 = JsonRpcServer()
    var_3 = json.loads(var_1)
    var_4 = '''{
    "jsonrpc": "2.0",
    "id": 1,
    "error": {
        "code": -32601,
        "message": "Method not found",
        "data": null
    }
}'''
    var_5 = var_2.handle_request(var_1)


# Generated at 2022-06-25 13:20:59.236334
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.response()
    var_2 = json_rpc_server_0.response(result=json.dumps(var_1))
    var_3 = json_rpc_server_0.error(code=-32603, message='Internal error', data=None)
    var_4 = json_rpc_server_0.handle_request(request=json.dumps(var_2))


# Generated at 2022-06-25 13:21:04.656773
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    var_0 = b"{\"jsonrpc\": \"2.0\", \"method\": \"random\", \"params\": [3], \"id\": 1}"
    vk_5 = json.loads(var_0)
    vk_6 = vk_5
    vk_6['method'] = 'invalid'
    var_1 = json.dumps(vk_6).encode('utf-8')

test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:21:31.962854
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # 
    # Tests that we don't crash when the connection closes while
    # we're handling an RPC request
    # 

    json_rpc_server_0 = JsonRpcServer()
    setattr(json_rpc_server_0, "_identifier", 0)
    try:
        result_0 = json_rpc_server_0.handle_request(None)
        assert result_0 is None, "{}".format(result_0)
    except:
        var_0 = traceback.format_exc()
        assert False, "{}".format(var_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:21:35.655525
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    method_test_var_0 = {}
    request = method_test_var_0['request']
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request(request)
    assert var_0 is not None


# Generated at 2022-06-25 13:21:43.994740
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    test_case = {
        "jsonrpc": "2.0",
        "method": "show_something",
        "params": [{}],
        "id": 42
    }

    class TestClass(object):
        def show_something(self, *args, **kwargs):
            return {'this_is': 'a_test'}

    test_server = JsonRpcServer()
    test_server.register(TestClass())
    result = test_server.handle_request(json.dumps(test_case))
    assert json.loads(result) == {'jsonrpc': '2.0', 'id': 42, 'result': '{"this_is": "a_test"}'}

    # test lookup for methods within multiple objects

# Generated at 2022-06-25 13:21:45.517524
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.response()


# Generated at 2022-06-25 13:21:47.220308
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create an instance of class JsonRpcServer
    json_rpc_server_0 = JsonRpcServer()


# Generated at 2022-06-25 13:21:53.897451
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server_0 = JsonRpcServer()
    var_0 = server_0.handle_request("{\"method\":\"ansible_facts\",\"id\":\"d22926e0-ab7b-49f9-9ceb-6dfc0f56a8c4\",\"params\":{\"args\":[],\"kwargs\":{}}}")

# Generated at 2022-06-25 13:21:58.480184
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json.loads(to_text('{ "id": "123456789", "method": "connect", "params": [ {"port": 830, "host": "localhost", "username": "ansible", "password": "ansible", "hostkey_verify": false} ] }'))
    
    json_rpc_server_0.handle_request(var_1)
    

# Generated at 2022-06-25 13:22:07.429800
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    body = '{"method": "test-method", "params": [], "jsonrpc": "2.0", "id": 0}'
    result = json.loads(body)
    assert type(result) == dict

    # Unit test for method parse_error of class JsonRpcServer
    def test_JsonRpcServer_parse_error():
        body = '{"method": "test-method", "params": [], "jsonrpc": "2.0", "id": 0}'
        result = json.loads(body)
        assert type(result) == dict

    # Unit test for method method_not_found of class JsonRpcServer

# Generated at 2022-06-25 13:22:11.018703
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '{"id": 0, "params": [["", "", ""]], "method": "get_config"}'
    __result = json_rpc_server_0.handle_request(request)
    assert __result is not None
    print(__result)

# Generated at 2022-06-25 13:22:13.351458
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request()


# Generated at 2022-06-25 13:22:33.318511
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request()


# Generated at 2022-06-25 13:22:35.507283
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    """
    Test response
    """
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:22:38.098262
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server = JsonRpcServer()
    assert json_rpc_server.response() == {'jsonrpc': '2.0', 'id': None, 'result': None}




# Generated at 2022-06-25 13:22:41.736355
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '{"method":"my_method","params":[[1,2,3,4],{"foo": "bar"}],"id":1}'
    ret_val_0 = json_rpc_server_0.handle_request(request)
    assert ret_val_0 == '{"id": 1, "jsonrpc": "2.0", "_ansible_notify": true}'



# Generated at 2022-06-25 13:22:43.004601
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # No params tested


# Generated at 2022-06-25 13:22:46.464673
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    var = json_rpc_server.handle_request('{"params": [null, null], "jsonrpc": "2.0", "method": "cli", "id": 0}')


# Generated at 2022-06-25 13:22:48.308402
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:22:57.262098
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    # No exception was raised for test_case_0.json
    test_case_0()

    # No exception was raised for test_case_1.json
    test_case_0()

    # No exception was raised for test_case_2.json
    test_case_0()

    # No exception was raised for test_case_3.json
    test_case_0()

    # No exception was raised for test_case_4.json
    test_case_0()

    # No exception was raised for test_case_5.json
    test_case_0()

    # No exception was raised for test_case_6.json
    test_case_0()

    # No exception was raised for test_case_7.json
    test_case_0()

    # No exception was raised for test_case_8.json


# Generated at 2022-06-25 13:23:01.133078
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json.loads(to_text('{"jsonrpc": "2.0", "method": "rpc.test"}', errors='surrogate_then_replace'))
    john_doe = 'undefined'
    json.loads(json_rpc_server_0.handle_request(john_doe))
    request = 'undefined'
    json.loads(json_rpc_server_0.handle_request(request))

# Generated at 2022-06-25 13:23:06.531581
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    params_0 = [0, 1, 2]
    json_0 = '{"params": [0, 1, 2], "id": "test", "method": "test_method"}'
    json_rpc_server_0 = JsonRpcServer()
    assert json_rpc_server_0.handle_request(json_0) == '{"jsonrpc": "2.0", "id": "test", "result": null}'



# Generated at 2022-06-25 13:23:27.207057
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # Test the call to the method
    var_1 = json_rpc_server_0.handle_request(request='')
    # Test the call to the method
    var_2 = json_rpc_server_0.handle_request(request='')


# Generated at 2022-06-25 13:23:29.581046
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request('{ "args": [] }')


# Generated at 2022-06-25 13:23:34.095293
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    params = json.dumps({'method': 'foo'})
    json_rpc_server_0 = JsonRpcServer()
    expect_error = json.dumps({'error': {'code': -32601, 'message': 'Method not found'}, 'jsonrpc': '2.0', 'id': None})
    actual_error = json.dumps(json_rpc_server_0.handle_request(params))
    assert expect_error == actual_error


# Generated at 2022-06-25 13:23:41.288349
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request('')
    var_1 = json_rpc_server_0.handle_request('{"jsonrpc":"2.0","params":[[],"{}"],"id":129,"method":"get_config"}')
    var_2 = json_rpc_server_0.handle_request('{"jsonrpc":"2.0","id":0,"method":"enable_snmp"}')
    var_3 = json_rpc_server_0.handle_request('{"jsonrpc":"2.0","id":0,"method":"disable_snmp"}')


if __name__ == '__main__':
    # Unit test
    test_JsonRpcServer_handle_request()