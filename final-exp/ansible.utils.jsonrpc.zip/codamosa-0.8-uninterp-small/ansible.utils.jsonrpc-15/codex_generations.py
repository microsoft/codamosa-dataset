

# Generated at 2022-06-25 13:13:58.920280
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    request = '{"jsonrpc": "2.0", "method": "update", "params": [1,2,3,4,5], "id": "1"}'
    json_rpc_server_0 = JsonRpcServer()

# Generated at 2022-06-25 13:14:02.322514
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.response()
    assert result == {'jsonrpc': '2.0', 'id': '<string>'}


# Generated at 2022-06-25 13:14:04.167705
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
  json_rpc_server_0 = JsonRpcServer()
  result_0 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:14:07.226671
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = 'Hello, World!'
    response = json_rpc_server_0.response(result)
    assert response == {'jsonrpc': '2.0', 'id': None, 'result': 'Hello, World!'}


# Generated at 2022-06-25 13:14:11.148177
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    error = json_rpc_server_0.error(code=code, message=message)
    assert error == 'error'




# Generated at 2022-06-25 13:14:15.157877
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()

    result = {"jsonrpc": "2.0", "id": "ansible"}

    response = json_rpc_server_0.response(result)

    assert response["jsonrpc"] == "2.0"
    assert response["id"] == "ansible"


# Generated at 2022-06-25 13:14:20.478007
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # NOTE: this does not actually test the handle_request method *functionality*,
    # it only ensures that it does not raise an exception
    # maybe write a test that verifies the return value
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.handle_request("testing123")
    assert result

# Generated at 2022-06-25 13:14:22.460377
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.response()


# Generated at 2022-06-25 13:14:25.328288
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
  code = 0
  message = "String"
  data = "String"

  json_rpc_server_0 = JsonRpcServer()
  json_rpc_server_0.error(code, message, data)


# Generated at 2022-06-25 13:14:30.048945
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():

    # Constructing a mock object for JsonRpcServer
    json_rpc_server_1 = JsonRpcServer()

    # Constructing a mock object for the method response of JsonRpcServer
    bool_value_1 = True
    try:
        if (json_rpc_server_1.response() is not None):
            bool_value_1 = True
    except Exception:
        bool_value_1 = False



# Generated at 2022-06-25 13:14:48.234100
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "run",
        "params": [
            "true",
            "foo bar"
        ],
        "id": 1
    }
    response = json_rpc_server_1.handle_request(request)
    assert "jsonrpc" in response
    assert "id" in response
    assert "result" in response
    assert "result_type" not in response
    assert json.loads(request) == response


# Generated at 2022-06-25 13:14:49.416806
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    msg = "AnsibleTestcase with id 0 failed"
    error = json_rpc_server_0.error(code = 1, message = msg)


# Generated at 2022-06-25 13:14:55.781183
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    # Make sure we can create an object
    json_rpc_server_0 = JsonRpcServer()

    data = None

    # Call method error with a basic argument
    result = json_rpc_server_0.error(code=0, message="string", data=data)
    assert result == {'error': {'code': 0, 'message': 'string'}, 'id': 'None', 'jsonrpc': '2.0'}



# Generated at 2022-06-25 13:14:59.359222
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    jsonrpc_method_0 = json_rpc_server_1.handle_request
    assert True == True


# Generated at 2022-06-25 13:15:02.392754
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()

    rpc_method = lambda: None
    try:
        rpc_method()
    except Exception as e:
        error = json_rpc_server_0.error(code=e.code, message=to_text(e))
    else:
        error = {}

    error = json_rpc_server_0.response(result=error)


# Generated at 2022-06-25 13:15:06.194793
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = str()
    if (request == ""):
        request = None
    expect = str()
    actual = json_rpc_server_0.handle_request(request)
    assert actual == expect


# Generated at 2022-06-25 13:15:08.152899
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    response = json_rpc_server_0.response()


# Generated at 2022-06-25 13:15:12.154332
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)
    response = {"jsonrpc": "2.0", "id": "_identifier", "result": "result"}
    assert response == json_rpc_server_0.response()


# Generated at 2022-06-25 13:15:17.225481
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    assert json_rpc_server_0.error(code=100, message='message') == {
        'jsonrpc': '2.0',
        'id': 'None',
        'error': {
            'code': 100,
            'message': 'message'
        }
    }


# Generated at 2022-06-25 13:15:24.262509
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_1 = JsonRpcServer()
    setattr(json_rpc_server_1, '_identifier', 'json_rpc_server_1._identifier')
    result = 'json_rpc_server_1.result'
    assert json_rpc_server_1.response(result) ==  {'id': 'json_rpc_server_1._identifier', 'jsonrpc': '2.0', 'result': 'json_rpc_server_1.result'}


# Generated at 2022-06-25 13:15:46.400029
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # simple test
    json_rpc_server_0 = JsonRpcServer()
    request_0 = json.loads('{"params": [1, 2], "method": "foo", "id": "bar"}')
    response = json_rpc_server_0.handle_request(request_0)
    assert response == '{"id": "bar", "jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}}'

# Generated at 2022-06-25 13:15:49.699092
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = json.dumps(get_valid_request())
    res = json_rpc_server_0.handle_request(request)
    assert res == json.dumps(valid_response())


# Generated at 2022-06-25 13:15:54.018615
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create an instance of class JsonRpcServer
    json_rpc_server_0 = JsonRpcServer()

    # Assign values for all parameters.
    request_0 = None

    # Call handle_request to prepare a request
    result = json_rpc_server_0.handle_request(request_0)

    # Return the result
    return result


# Generated at 2022-06-25 13:16:02.803174
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-25 13:16:07.222983
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    method = "handle_request"
    request = {}

    # Testing exception raise of method handle_request
    with pytest.raises(ConnectionError) as excinfo:
        json_rpc_server_1.handle_request(request)
    assert excinfo.value.args[0] == "Method not found"


# Generated at 2022-06-25 13:16:11.257630
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Setup
    json_rpc_server_0 = JsonRpcServer()
    class Test(object):
        def foo(self, x):
            return {'result': 'foo'}
        def bar(self, x, y):
            return {'result': 'bar'}
        def baz(self, x, y, z=1):
            return {'result': 'baz'}
    test_0 = Test()
    json_rpc_server_0.register(test_0)
    request_0 = {"method": "bar", "params": [[1, 2], {}], "id": "foobar"}

    # Exercise
    result = json_rpc_server_0.handle_request(request_0)

    # Verify

# Generated at 2022-06-25 13:16:14.246634
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = {"id": "", "method": ""}
    with pytest.raises(TypeError):
        json_rpc_server_0.handle_request(request)

# Generated at 2022-06-25 13:16:17.043362
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    request_2 = '['
    json_rpc_server_1.handle_request(request_2)


# Generated at 2022-06-25 13:16:24.591851
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

# Generated at 2022-06-25 13:16:29.399801
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    try:
        request = '''{"jsonrpc": "2.0", "method": "rpc.foo", "params": [[], {}], "id": 1}'''
        json_rpc_server_0.handle_request(request)
    except:
        pass


# Generated at 2022-06-25 13:16:40.464523
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()


# Generated at 2022-06-25 13:16:43.735310
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Argument spec for the method handle_request
    json_rpc_server_0 = JsonRpcServer()
    assert_equal(json_rpc_server_0.handle_request(request=None), "Argument should be defined")

# Generated at 2022-06-25 13:16:48.205739
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = json.loads('{"jsonrpc": "2.0", "method": "message", "params": ["some_string", 4, 7], "id": 1}')

    try:
        json_rpc_server_0.handle_request(request)
    except Exception:
        pass


# Generated at 2022-06-25 13:16:53.230501
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Initialize the arguments to be sent to the unit test method
    request = None
    expected_result = {'id': None, 'jsonrpc': '2.0', 'result': None}

    # Initialize JsonRpcServer object
    json_rpc_server = JsonRpcServer()

    # Run the unit test
    result = json_rpc_server.handle_request(request)

    # Check the results
    assert result == expected_result



# Generated at 2022-06-25 13:17:02.780239
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    req = {"method": "some_method", "params": [[], {}], "id": "1"}
    resp = json_rpc_server_0.handle_request(req)
    req = {"method": "some_method", "params": [[], {}], "id": "1"}
    req["params"][0].append("foo")
    resp = json_rpc_server_0.handle_request(req)
    req = {"method": "some_method", "params": [[], {}], "id": "1"}
    req["params"][1]["bar"] = "baz"
    resp = json_rpc_server_0.handle_request(req)

# Generated at 2022-06-25 13:17:06.746114
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    assert json_rpc_server_0.handle_request('{"method": "greet", "params": ["World"], "id": 0}') == '{"jsonrpc": "2.0", "id": 0, "result": "Hello, World"}'


# Generated at 2022-06-25 13:17:11.360707
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '''{"jsonrpc": "2.0", "method": "system.listMethods", "params": [], "id": 1}'''
    result = json_rpc_server_0.handle_request(request)
    assert isinstance(result, to_text(None))
    assert result is None


# Generated at 2022-06-25 13:17:16.984082
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = b''
    try:
        result = json_rpc_server_0.handle_request(request)
    except Exception as e:
        # print
        print(e)
        # console.error
        traceback.print_exc()


if __name__ == '__main__':
    test_case_0()
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:17:21.375804
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    request_arg_0 = b'{"method": "method_name", "params": [], "id": 1}'
    rpc_method_arg_0 = None  # default
    json_rpc_server_1.register(rpc_method_arg_0)
    assert True


# Generated at 2022-06-25 13:17:25.103116
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '{\n  "jsonrpc": "2.0",\n  "method": "run",\n  "params": [\n    [\n      "show version"\n    ],\n    {\n      "text": true\n    }\n  ],\n  "id": 0\n}'
    exception = None
    try:
        test_case_0(json_rpc_server_0, request)
    except Exception as e:
        print(e)
        exception = e

# Generated at 2022-06-25 13:17:47.926150
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    message = "Ansible provider is missing.  Unable to detect device type."
    code = "missing provider"

    try:
        json_rpc_server_0 = JsonRpcServer()
        display.vvvv('json_rpc_server_0')
        result = json_rpc_server_0.handle_request(message)
        display.vvvv('result')
        display.vvvv(result)
        error = json_rpc_server_0.error(code=code, message=message)
        display.vvvv('error')
        display.vvvv(error)
        response = json_rpc_server_0.response()
        display.vvvv('response')
        display.vvvv(response)

    except Exception as exc:
        display.vvv(traceback.format_exc())

# Generated at 2022-06-25 13:17:54.135532
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    dict_0 = dict()
    dict_1 = dict()
    json_rpc_server_0 = JsonRpcServer()
    params_1 = (dict_0, dict_1)
    json_rpc_server_0.register(json_rpc_server_0)
    json_rpc_server_0.register(json_rpc_server_0)
    json_rpc_server_0.handle_request(dict_1)


# Generated at 2022-06-25 13:17:58.555148
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [1, 2]})
    response_0 = json_rpc_server_0.handle_request(request_0)


# Generated at 2022-06-25 13:18:01.193000
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # initialize variable
    json_rpc_server_0 = JsonRpcServer()

    json_rpc_server_0.handle_request(request)


# Generated at 2022-06-25 13:18:03.473360
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    json_rpc_server_1.handle_request()


# Generated at 2022-06-25 13:18:06.612946
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    assert isinstance(json_rpc_server_0.handle_request("{\"id\": 541264599, \"method\": \"list\", \"params\": []}"), text_type) == True


# Generated at 2022-06-25 13:18:10.654529
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    # Creating JsonRpcServer object
    json_rpc_server_0 = JsonRpcServer()

    # Creating input variable for method 'handle_request' of class JsonRpcServer
    request = 'junk'

    # Testing the method
    try:
        json_rpc_server_0.handle_request(request)
        assert False
    except:
        assert True


# Generated at 2022-06-25 13:18:13.635170
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request(u'{"id": "1", "method": "echo", "params": ["hello world"]}')


# Generated at 2022-06-25 13:18:20.787777
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    json_rpc_server_0 = JsonRpcServer()

    # From test case 0
    request_0 = text_type('{"jsonrpc": "2.0", "method": "mycmd", "params": [42, 23], "id": 1}')
    expected_0 = text_type('{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}')
    actual_0 = json_rpc_server_0.handle_request(request_0)
    assert expected_0 == actual_0

# Generated at 2022-06-25 13:18:26.825654
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    try:
        json_rpc_server_0 = JsonRpcServer()
        assert json_rpc_server_0.handle_request() == \
               '{"jsonrpc": "2.0", "id": null, "error": {"code": -32600, ' \
               '"message": "Invalid request"}}'
    except (NameError, SyntaxError):
        display.important("Skipping TestCase due to syntax error")



# Generated at 2022-06-25 13:18:44.064266
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    request = ""
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.handle_request(request)
    assert isinstance(result, str)


# Generated at 2022-06-25 13:18:49.489553
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

    try:
        # Test case for invalid method name
        json_rpc_server_0.handle_request(b"{\"method\":\"rpc.bump\",\"params\":[],\"id\":1}")
        assert 0, 'Should have thrown an exception'

    except Exception as exc:
        display.display("Unit test for method handle_request of class JsonRpcServer is successful")


# Generated at 2022-06-25 13:18:54.313584
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '''{"jsonrpc": "2.0", "method": "foobar", "params": [1, 2, 3], "id": 1}'''
    expected = '''{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'''
    result = json_rpc_server_0.handle_request(request)
    assert result == expected


# Generated at 2022-06-25 13:18:59.594712
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # This test case is used to test method "handle_request".

    json_rpc_server_0 = JsonRpcServer()

    # This text case will raise a "TypeError" exception, because the method
    # handle_request() needs a request parameter.
    try:
        json_rpc_server_0.handle_request()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 13:19:02.794561
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # @TODO: implement test for handle_request
    json_rpc_server_0.handle_request()


# Generated at 2022-06-25 13:19:06.161078
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Setup test case data
    json_rpc_server = JsonRpcServer()
    input = ""
    expected = ""
    # Execute the tested method
    actual = json_rpc_server.handle_request(input)
    # Verify the results
    assert actual == expected


# Generated at 2022-06-25 13:19:11.511278
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    print("Testing handle_request...")
    json_rpc_server_0 = JsonRpcServer()
    try:
        request = "123"
        resp = json_rpc_server_0.handle_request(request)
        assert json.loads(resp)['error']['code'] == -32700
        print("Test Passed")
    except AssertionError as e:
        print("Test Failed: {}".format(e))



# Generated at 2022-06-25 13:19:14.200885
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = ''
    response_0 = json_rpc_server_0.handle_request(request_0)


# Generated at 2022-06-25 13:19:18.405439
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()

    class TestModule(object):
        def __init__(self):
            self.display = Display()

        def ping(self, msg=None):
            self.display.display('PING: %s' % msg)
            return msg

    module = TestModule()
    server.register(module)

    request = json.dumps({
        'jsonrpc': '2.0',
        'method': 'ping',
        'params': ['hello world'],
        'id': '123'
    })

    response = server.handle_request(request)
    response = json.loads(response)

    expected = {
        'jsonrpc': '2.0',
        'id': '123',
        'result': 'hello world'
    }
    assert response == expected

# Generated at 2022-06-25 13:19:21.490251
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = "my request"
    with pytest.raises(KeyError):
        json_rpc_server_0.handle_request(request_0)


# Generated at 2022-06-25 13:19:54.948569
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)
    request_0 = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [], "id": 0}'
    result = json_rpc_server_0.handle_request(request_0)
    assert result == '{"id": 0, "jsonrpc": "2.0", "result": {}}'


# Generated at 2022-06-25 13:19:56.887134
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request()



# Generated at 2022-06-25 13:20:00.043056
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    json_rpc_server_1.handle_request("{'id': '1', 'jsonrpc': '2.0', 'method': 'rpc.test', 'params': [[1, 2]]}")


# Generated at 2022-06-25 13:20:09.870690
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    # test_0
    try:
        json_rpc_server.handle_request("{\"method\": \"folders.get\", \"params\": {\"path\": \"/home/hr/Desktop\"}, \"jsonrpc\": \"2.0\", \"id\": 0}")
        pass
    except Exception as exc:
        display.vvv(traceback.format_exc())
        assert False
    # test_1
    try:
        json_rpc_server.handle_request("{\"method\": \"None\", \"params\": {\"path\": \"/home/hr/Desktop\"}, \"jsonrpc\": \"2.0\", \"id\": 0}")
        pass
    except Exception as exc:
        display.vvv(traceback.format_exc())
        assert False
   

# Generated at 2022-06-25 13:20:12.267584
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = {}
    result_0 = json_rpc_server_0.handle_request(request_0)


# Generated at 2022-06-25 13:20:13.646546
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    json_rpc_server_1.handle_request(request=None)


# Generated at 2022-06-25 13:20:15.861907
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    with pytest.raises(Exception):
        json_rpc_server_0.handle_request(request)

# Generated at 2022-06-25 13:20:17.309579
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()


# Generated at 2022-06-25 13:20:26.089963
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    # Test with tests/module_utils/test_data/test_JsonRpcServer.json

    json_rpc_server_0 = JsonRpcServer()
    response = json_rpc_server_0.handle_request('{"jsonrpc": "2.0", "method": "ip_interface", "id": "test", "params": [["Ethernet0/0"], "set"]}')

# Generated at 2022-06-25 13:20:29.392336
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_6 = JsonRpcServer()
    args_6 = {}
    kwargs_6 = {}
    # No exception should be raised
    json_rpc_server_6.handle_request(*args_6, **kwargs_6)


# Generated at 2022-06-25 13:21:03.100285
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    data = {}
    for attr in ('', '', '', '', '', '', '', '', '', ''):
        if hasattr(json_rpc_server_1, attr):
            data[attr] = getattr(json_rpc_server_1, attr)
    json_rpc_server_1.handle_request(data)


# Generated at 2022-06-25 13:21:03.951529
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    test_case_0()


# Generated at 2022-06-25 13:21:06.391909
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_2 = JsonRpcServer()
    # TODO: Implement test_JsonRpcServer_handle_request
    raise NotImplementedError()


# Generated at 2022-06-25 13:21:14.317977
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    # Test a simple request
    json_rpc_server_0 = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'method': 'shell', 'params': [], 'id': 'ID-1'}
    expected = {'jsonrpc': '2.0', 'id': 'ID-1', 'result': '', 'error': {'message': 'Method not found', 'code': -32601}}
    result = json_rpc_server_0.handle_request(json.dumps(request))
    assert result == json.dumps(expected)

    # Test a simple request with a complex type

# Generated at 2022-06-25 13:21:16.166871
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # stub
    json_rpc_server_0.handle_request(request)

# Generated at 2022-06-25 13:21:24.897771
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

    # Test normal operation
    assert json_rpc_server_0.handle_request(b'{\"jsonrpc\":\"2.0\",\"method\":\"foo\",\"params\":[\"bar\",\"baz\"],'
                                            b'\"id\":1}') == '{"jsonrpc": "2.0", "error": {"code": -32601,' \
                                                             ' "message": "Method not found"}, "id": 1}'

    # Test with a boundary condition

# Generated at 2022-06-25 13:21:29.860889
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    request_1 = {}
    json_rpc_server_1.handle_request(request_1)
    request_2 = {}
    json_rpc_server_1.handle_request(request_2)
    request_3 = {}
    json_rpc_server_1.handle_request(request_3)


# Generated at 2022-06-25 13:21:31.318204
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # test_case_0
    json_rpc_server_0 = JsonRpcServer()

# Generated at 2022-06-25 13:21:37.261385
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = b'{"jsonrpc": "2.0", "method": "rpc.method", "params": "[]", "id": 0}'
    assert json_rpc_server_0.handle_request(request_0) == b'{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request", "data": null}, "id": 0}'


# Generated at 2022-06-25 13:21:41.996848
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '{}' #invalid json
    json_rpc_server_0.handle_request(request)


if __name__ == '__main__':
    import logging
    from ansible.module_utils import basic
    logging.basicConfig(level=logging.DEBUG)
    basic.AnsibleModule(argument_spec={})
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:22:23.683855
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

    # Test with valid parameters
    json_request_0 = '{ "jsonrpc": "2.0", "method": "echo", "id": 1, "params": [ "Hello, World!" ] }'
    expected_result_0 = b'{"jsonrpc": "2.0", "result": "Hello, World!", "id": 1}'
    result_0 = json_rpc_server_0.handle_request(json_request_0)
    assert result_0 == expected_result_0

    # Test without data field
    json_request_1 = '{ "jsonrpc": "2.0", "method": "echo", "id": 1 }'

# Generated at 2022-06-25 13:22:28.241464
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    rpc_server = JsonRpcServer()
    request = {'method': 'rpc.foo', 'params': [], 'id': 123}
    assert rpc_server.handle_request(request) == {
        'jsonrpc': '2.0',
        'id': 123,
        'error': {'code': -32601, 'message': 'Method not found'}
    }

# Generated at 2022-06-25 13:22:29.976221
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request


# Generated at 2022-06-25 13:22:38.134379
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    obj_JsonRpcServer_0 = JsonRpcServer()
    test_obj_0 = {
        'method': "method",
        'params': "[]",
        'id': "0"
    }
    obj_JsonRpcServer_0.register(test_obj_0)
    JsonRpcServer.register(obj_JsonRpcServer_0, test_obj_0)
    assert obj_JsonRpcServer_0.handle_request(obj_JsonRpcServer_0) == json.dumps(obj_JsonRpcServer_0.header())
    assert obj_JsonRpcServer_0.handle_request(obj_JsonRpcServer_0) == json.dumps(obj_JsonRpcServer_0.header())


# Generated at 2022-06-25 13:22:41.918092
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer.JsonRpcServer()
    json_rpc_server_1.register(object())
    args_0, kwargs_0 = {}, {'request': b''}
    assert json_rpc_server_1.handle_request(**args_0, **kwargs_0) == '{"jsonrpc": "2.0", "error": {"code": -32700, "message": "Parse error"}}'


# Generated at 2022-06-25 13:22:42.641626
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    test_case_0()

# Generated at 2022-06-25 13:22:47.706921
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    request = '{"id": "RPC.Automatic", "jsonrpc": "2.0", "result": "string"}'
    response = json_rpc_server_1.handle_request(request)
    assert response == '{"id": "RPC.Automatic", "jsonrpc": "2.0", "result": "string"}'


# Generated at 2022-06-25 13:22:51.438957
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    print("\n***** In test_JsonRpcServer_handle_request *****")
    json_rpc_server_0 = JsonRpcServer()
    print("\nTest case 0")
    test_case_0()


# Generated at 2022-06-25 13:22:52.773333
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    try:
        test_case_0()
    except Exception:
        raise AssertionError


# Generated at 2022-06-25 13:22:56.910066
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    str_0 = json.dumps({"jsonrpc": "2.0", "method": "x", "id": 0, "params": [[], {}]})
    str_1 = json_rpc_server_0.handle_request(str_0)
    print(str_1)
