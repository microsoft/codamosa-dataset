

# Generated at 2022-06-25 13:13:50.221552
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    assert json_rpc_server_0.response() == {'jsonrpc': '2.0', 'id': None, 'result': ''}


# Generated at 2022-06-25 13:13:54.866070
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = set(dir(json_rpc_server_0))
#   print(request)
    json_rpc_server_0.handle_request(request)
#   print('test_JsonRpcServer_handle_request pass')


# Generated at 2022-06-25 13:13:57.541602
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    print(json_rpc_server.handle_request({"method":"find", "params":["a", "b"], "id":1}))


# Generated at 2022-06-25 13:14:00.277334
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # buffer = StringIO.StringIO(data)
    # resp = json_rpc_server_0.handle_request(buffer)
    pass


# Generated at 2022-06-25 13:14:02.739588
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_1 = JsonRpcServer()
    result = json_rpc_server_1.error()
    assert True


# Generated at 2022-06-25 13:14:08.240324
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    # Instantiate class
    json_rpc_server = JsonRpcServer()

    # Call method
    result = json_rpc_server.error(
        code=1,
        message='string',
        data='string',
    )
    assert isinstance(result, dict)
    assert result['id'] == 'string'
    assert result['jsonrpc'] == '2.0'
    assert result['error']['code'] == 1
    assert result['error']['message'] == 'string'
    assert result['error']['data'] == 'string'


# Generated at 2022-06-25 13:14:19.386493
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    text = '{"jsonrpc": "2.0", "method": "echo", "params": {"arg1": "foo", "arg2": "bar"}, "id": "0"}'
    text = to_text(text)
    try:
        result = json_rpc_server_0.handle_request(text)
    except Exception as err:
       display.vvv('traceback: %s' % traceback.format_exc())
       raise AssertionError('handle_request with exception')
    if result != '{"jsonrpc": "2.0", "result": "foo", "id": "0"}':
        raise AssertionError('result of handle_request wrong')


# Generated at 2022-06-25 13:14:27.667587
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    code = -32700
    message = ""
    data = None
    result = json_rpc_server_0.error(code, message, data)
    assert result['jsonrpc'] == '2.0', "The jsonrpc server is not responding as expected"
    assert result['id'] != None, "The jsonrpc server is not responding as expected"
    assert result['error'] != None, "The jsonrpc server is not responding as expected"
    assert result['error']['code'] == -32700, "The jsonrpc server is not responding as expected"
    assert result['error']['message'] == 'Parse error', "The jsonrpc server is not responding as expected"

# Generated at 2022-06-25 13:14:37.314612
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    assert hasattr(json_rpc_server_0, '_identifier')
    f = (lambda: 0 + 'a')
    f()
    try:
        json_rpc_server_0.handle_request(request=('-32700',))
        json_rpc_server_0.handle_request(request=('-32601',))
        json_rpc_server_0.handle_request(request=('-32600',))
        json_rpc_server_0.handle_request(request=('-32602',))
        json_rpc_server_0.handle_request(request=('-32603',))
    finally:
        delattr(json_rpc_server_0, '_identifier')

# Unit test

# Generated at 2022-06-25 13:14:40.809929
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.response()
    assert(result == {'jsonrpc': '2.0', 'id': None, 'result': None})


# Generated at 2022-06-25 13:14:47.197518
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    obj = JsonRpcServer()
    obj._identifier = 1
    result = obj.response()
    assert result == {'id': 1, 'jsonrpc': '2.0'}

# Generated at 2022-06-25 13:14:49.085995
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = '{"error": {"code": -32603, "message": "Internal error"}, "id": 1, "jsonrpc": "2.0"}'
    output = json_rpc_server_0.handle_request(var_0)
    print (output)

# Generated at 2022-06-25 13:14:51.593857
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()

if __name__ == '__main__':
    test_JsonRpcServer_response()

# Generated at 2022-06-25 13:15:02.763897
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    rpc = JsonRpcServer()
    rpc.register(rpc)
    setattr(rpc, '_identifier', '1')
    result = {'foo': 'bar'}
    assert rpc.response(result) == {
        'jsonrpc': '2.0',
        'result': {'foo': 'bar'},
        'id': '1'
    }
    result = 'string'
    assert rpc.response(result) == {
        'jsonrpc': '2.0',
        'result': 'string',
        'id': '1'
    }
    result = b'unicode-escape'

# Generated at 2022-06-25 13:15:04.821069
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    var = json_rpc_server.handle_request()


# Generated at 2022-06-25 13:15:06.222862
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:15:10.332125
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response(result=None)
    assert var_0['result'] is None
    var_1 = json_rpc_server_0.response(result=123)
    assert var_1['result'] == '123'


# Generated at 2022-06-25 13:15:20.894750
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

    setattr(json_rpc_server_0, '_objects', set())
    request_0 ={'params': [[], {}], 'method': 'rpc.debug', 'id': '0'}
    request_0 = json.dumps(request_0)
    var_0 = json_rpc_server_0.handle_request(request=request_0)

# Generated at 2022-06-25 13:15:24.734684
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = '{"jsonrpc": "2.0", "method": "foo", "params": [], "id": 0}'
    var_0 = json_rpc_server_0.handle_request(request_0)

# Generated at 2022-06-25 13:15:26.997844
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.error(13, 'essage', 'data')


# Generated at 2022-06-25 13:15:31.970773
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.internal_error()


# Generated at 2022-06-25 13:15:34.923552
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.error(-32768, 'Parse error', None)
    assert var_1 == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32768, 'message': 'Parse error'}}


# Generated at 2022-06-25 13:15:39.717155
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.error(2, "Hello, World!")
    assert var_1 == {u'error': {u'message': u'Hello, World!', u'code': 2},
                     u'id': None, u'jsonrpc': u'2.0'}



# Generated at 2022-06-25 13:15:41.702792
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.response()


# Generated at 2022-06-25 13:15:46.357515
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    payload = '{"method":"rpc.get_capabilities", "params": [ { } ], "id": "rpc.get_capabilities"}'
    json_rpc_server_0 = JsonRpcServer()
    assert json_rpc_server_0.handle_request(payload)


# Generated at 2022-06-25 13:15:50.396043
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "testkd", "params": [], "id": 200}'
    response = json_rpc_server_0.handle_request(request)
    print(response)


# Generated at 2022-06-25 13:15:53.274913
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request()
    print(var_0)
    del var_0
    del json_rpc_server_0

# Generated at 2022-06-25 13:15:55.397939
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_1 = JsonRpcServer()
    var_1 = json_rpc_server_1.error(code=1, message="")


# Generated at 2022-06-25 13:15:58.139444
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = None
    var_1 = json_rpc_server_0.handle_request(var_0)
    print(var_1)


# Generated at 2022-06-25 13:16:00.821664
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request(0)



# Generated at 2022-06-25 13:16:12.678620
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Initialize the class instance
    json_rpc_server = JsonRpcServer()
    # Initialize the method parameter
    request = {
        "jsonrpc": "2.0",
        "method": "dummy",
        "params": [],
        "id": 0
    }
    # Call the method
    response = json_rpc_server.handle_request(request)
    # Assert for desired behavior
    return response


# Generated at 2022-06-25 13:16:19.214040
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    request_0 = '{'
    __result_1 = json_rpc_server_1.handle_request(request_0)
    assert __result_1 == '{\'version\': \'1.0\', \'result_type\': \'dict\', \'result\': {\'jsonrpc\': \'2.0\', \'id\': None, \'error\': {\'code\': -32700, \'message\': \'Parse error\'}}}'


# Generated at 2022-06-25 13:16:22.993405
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    print("Testing 'error' method of class JsonRpcServer")
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.error(code=36974, message="[Data type '[Data type 'var' is not defined.]' is not defined.]")
    print("PASS")


# Generated at 2022-06-25 13:16:27.838997
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = {"jsonrpc": "2.0", "id": 0, "error": {"message": "Internal error", "code": -32603}}
    assert var_1 == json.loads(json_rpc_server_0.handle_request('{}'))

# Generated at 2022-06-25 13:16:35.560319
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    assert json_rpc_server_0.response({'jsonrpc': '2.0', 'id': 2}, ) == {'jsonrpc': '2.0', 'id': 2, 'result': {'jsonrpc': '2.0', 'id': 2}}
    assert json_rpc_server_0.response({'jsonrpc': '2.0', 'id': 1}, ) == {'jsonrpc': '2.0', 'id': 1, 'result': {'jsonrpc': '2.0', 'id': 1}}


# Generated at 2022-06-25 13:16:40.078720
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server = JsonRpcServer()
    code = -32001
    message = u'Test message'
    result = json_rpc_server.error(code, message)
    assert result == {'jsonrpc': '2.0', 'id': None, 'error': {'code': code, 'message': message}}


# Generated at 2022-06-25 13:16:43.400304
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.response()
    assert result == {'jsonrpc': '2.0', 'id': None, 'result': None}


# Generated at 2022-06-25 13:16:47.309681
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server_0 = JsonRpcServer()
    assert json_rpc_server_0.error(code=0, message="") == {"jsonrpc": "2.0", "id": None, "error": {"code": 0, "message": ""}}


# Generated at 2022-06-25 13:16:55.738444
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # AssertionError: 'method' not in request
    try:
        var_1 = json_rpc_server_0.handle_request('')
    except AssertionError as exc:
        if 'method' not in str(exc):
            raise

    # AssertionError: 'method' not in request
    # AssertionError: 'params' not in request
    try:
        var_2 = json_rpc_server_0.handle_request('{}')
    except AssertionError as exc:
        if 'method' not in str(exc):
            raise

    # AssertionError: 'method' not in request
    # AssertionError: 'params' not in request
    # AssertionError: 'id' not

# Generated at 2022-06-25 13:16:58.093709
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request(request=None)


# Generated at 2022-06-25 13:17:19.252363
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    print("Testing handle_request")
    print("TEST PASSED")


# Generated at 2022-06-25 13:17:27.153232
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from copy import copy

    json_rpc_server_0 = JsonRpcServer()

    # Test verification with these parameters:
    #   request: {'jsonrpc': '2.0', 'method': 'method', 'id': 0, 'params': {}}
    #   request: {'id': 0, 'method': 'method', 'params': {}, 'jsonrpc': '2.0'}
    #   request: {'jsonrpc': '2.0', 'method': 'method', 'id': 0}
    #   request: {'method': 'method', 'id': 0, 'jsonrpc': '2.0'}
    #   request: {'id': 0, 'method': 'method', 'jsonrpc': '2.0'}
    #   request: {'jsonrpc': '2.

# Generated at 2022-06-25 13:17:30.537162
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = 'method.startswith(\'rpc.\') or method.startswith(\'_\')'
    var_1 = json_rpc_server_0.handle_request(var_0)


# Generated at 2022-06-25 13:17:32.483090
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    var = json_rpc_server.handle_request("")
    assert var == '{"jsonrpc": "2.0", "id": null, "error": {"code": -32603, "message": "Internal error"}}'


# Generated at 2022-06-25 13:17:36.975318
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # Assertion of var_0 caused the exception TypeError
    try:
        var_0 = json_rpc_server_0.handle_request()
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-25 13:17:43.675388
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Test 1: Create the JsonRpcServer object and call the handle_request method
    json_rpc_server_0 = JsonRpcServer()
    # *************************************************************************************************
    # Test 1: Call the handle_request method. This test uses a StringIO object as a mock object
    # *************************************************************************************************
    var_0 = json_rpc_server_0.handle_request("This is a mock request")
    var_0 = json_rpc_server_0.handle_request("This is a mock request")

# Generated at 2022-06-25 13:17:46.173048
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.internal_error()


# Generated at 2022-06-25 13:17:56.915669
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = dict()
    request_0['params'] = ({}, dict())
    request_0['id'] = 'aa'
    request_0['method'] = '_internal_error'
    request_0['jsonrpc'] = '2.0'
    json_rpc_server_0.handle_request(request_0)
    var_0 = json_rpc_server_0._identifier
    var_1 = json_rpc_server_0.handle_request(request_0)
    request_1 = dict()
    request_1['params'] = ({}, dict())
    request_1['id'] = 'aa'
    request_1['method'] = '_internal_error'

# Generated at 2022-06-25 13:18:01.627869
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    for method in dir(server):
        if not method.startswith('handle_'):
            continue

        func = getattr(server, method)
        if callable(func):
            func.__call__()

if __name__ == "__main__":
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:18:03.936992
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    assert type(json_rpc_server_0) == JsonRpcServer

# Generated at 2022-06-25 13:18:34.178438
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request(var_0)
    return var_0


# Generated at 2022-06-25 13:18:41.478487
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    try:
        var_0 = json_rpc_server_0.handle_request(None)
    except TypeError:
        var_0 = json_rpc_server_0.handle_request('{"params": [null, {"host": "localhost", "port": 8080}], "method": "connect", "jsonrpc": "2.0", "id": "1"}')
    except Exception as e:
        print(f'Exception in test_JsonRpcServer_handle_request: {e}')


# Generated at 2022-06-25 13:18:43.793336
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.internal_error()


# Generated at 2022-06-25 13:18:49.182644
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
   json_rpc_server = JsonRpcServer()
   request = "{\"jsonrpc\": \"2.0\", \"method\": \"run_command\", \"params\": [[\"show running-config\", \"text\"], 10], \"id\": 0}"
   try:
       json_rpc_server.handle_request(request)
   except:
       pass
   else:
       raise Exception("Unable to invoke method handle_request on JsonRpcServer")


# Generated at 2022-06-25 13:18:50.501715
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.handle_request('')


# Generated at 2022-06-25 13:18:52.408303
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    test0 = '{"method":"rpc.echo", "params":[[],{}], "id":1}'
    raise Exception("TODO: Auto-generated test not implemented")

# Generated at 2022-06-25 13:18:54.055559
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    jsonrpc_server_0 = JsonRpcServer()
    str_0 = jsonrpc_server_0.handle_request()

# Generated at 2022-06-25 13:18:59.583520
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # Test with an exception. Probably not a good test case. Be prepared to
    # replace it with something better.
    try:
        json_rpc_server_0.handle_request('')
        raise Exception('Expected Exception was not raised')
    except Exception as e:
        pass


test_case_0()
test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:19:05.943830
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_0 = JsonRpcServer()
    # These do not currently check for return value
    # assert json_rpc_server_0.response() is None
    # assert json_rpc_server_0.response(arg_0) is None
    # assert json_rpc_server_0.response(arg_1) is None
    # assert json_rpc_server_0.response(arg_2) is None
    # assert json_rpc_server_0.response(arg_3) is None


# Generated at 2022-06-25 13:19:10.947802
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    obj = JsonRpcServer()
    # Empty dict is created with the keys:
    # [u'jsonrpc', u'method', u'params', u'id']
    request = {}
    result = obj.handle_request(request)
    print(type(result))
    print(result)


if __name__ == '__main__':
    test_case_0()
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-25 13:20:10.491921
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_0 = json_rpc_server_0.handle_request("")


# Generated at 2022-06-25 13:20:13.451173
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    assert json_rpc_server_0.handle_request('{}') == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": null}'

# Generated at 2022-06-25 13:20:14.926009
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    json_rpc_server.handle_request(request)

# Generated at 2022-06-25 13:20:17.382256
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    arg0 = object()

    # Test with valid values
    obj = JsonRpcServer()
    assert obj.handle_request(arg0)


# Generated at 2022-06-25 13:20:18.198186
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    test_case_0()

# Generated at 2022-06-25 13:20:24.836314
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    request_0 = {u'id': u'1', u'method': u'rpc.test_method', u'params': [u'first arg'], u'jsonrpc': u'2.0'}
    var_0 = json_rpc_server_0.handle_request(request_0)
    assert var_0 == u'{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": "1"}'


# Generated at 2022-06-25 13:20:27.471571
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # AssertionError: not raised
    with pytest.raises(AssertionError):
        json_rpc_server_0.handle_request()


# Generated at 2022-06-25 13:20:30.319080
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.handle_request()
    print(var_1)


# Generated at 2022-06-25 13:20:32.310971
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    result = json_rpc_server_0.handle_request()


# Generated at 2022-06-25 13:20:34.751910
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    args_dict = {}
    try:
        test_case_0(**args_dict)
    except Exception as exc:
        display.error(to_text(exc))



# Generated at 2022-06-25 13:22:56.488708
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.handle_request(json.loads('{"params": [], "jsonrpc": "2.0", "method": "internal_error", "id": 155}'))
    var_2 = json_rpc_server_0.handle_request(json.loads('{"params": [], "jsonrpc": "2.0", "method": "internal_error", "id": 155}'))
    var_3 = json_rpc_server_0.handle_request(json.loads('{"params": [], "jsonrpc": "2.0", "method": "internal_error", "id": 155}'))

# Generated at 2022-06-25 13:22:57.762935
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.internal_error()
    json_rpc_server_0.handle_request(var_1)

# Generated at 2022-06-25 13:22:59.529407
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    json_rpc_server_0.register(json_rpc_server_0)
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 13:23:03.205079
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    """
    Unit test for method handle_request of class JsonRpcServer
    """
    json_rpc_server_0 = JsonRpcServer()
    var_1 = json_rpc_server_0.handle_request()


# Generated at 2022-06-25 13:23:05.564169
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    var_1 = json_rpc_server_1.handle_request()


# Generated at 2022-06-25 13:23:08.631101
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    data = '{"params": [["version"]], "method": "get_version", "jsonrpc": "2.0", "id": "3"}'
    var_1 = json_rpc_server_1.handle_request(data)



# Generated at 2022-06-25 13:23:10.862787
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_1 = JsonRpcServer()
    json_rpc_server_1.handle_request(request)


# Generated at 2022-06-25 13:23:13.622340
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()
    # Parameter 'request' should be a mapping, but we are passing a str
    with pytest.raises(TypeError):
        json_rpc_server_0.handle_request('str')


# Generated at 2022-06-25 13:23:17.763274
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server_0 = JsonRpcServer()

    # Test with the correct args
    response = json_rpc_server_0.handle_request()
    assert type(response) == str

    # Test with the wrong args
    # response = json_rpc_server_0.handle_request(request)
    # assert type(response) == str



# Generated at 2022-06-25 13:23:22.667108
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    print('Testing method ', 'handle_request', ' of class ', 'JsonRpcServer', sep='')
    # Testing for JsonRpcServer.handle_request

    print('+ Testing normal case:')
    test_case_0()

    # Set up test cases from yaml file
    test_cases = load_test_cases('test_cases/JsonRpcServer.yml', 'JsonRpcServer_handle_request')
    print('+ Testing cases with parameters:')
    # Loop through test cases and check if returns expected output
    for test_case in test_cases:
        test_JsonRpcServer_handle_request(test_case)
