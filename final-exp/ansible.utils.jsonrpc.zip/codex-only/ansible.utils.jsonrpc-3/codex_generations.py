

# Generated at 2022-06-23 14:07:03.808805
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    foo = Foo()
    bar = Bar()
    server = JsonRpcServer()
    server.register(foo)
    server.register(bar)
    assert server._objects == set([foo, bar])


# Generated at 2022-06-23 14:07:10.015047
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
  # Module argument `data`
  data = "string"
  # Expected return value
  return_val = {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32602, 'message': 'Invalid params', 'data': data}}
  # Call method
  result = JsonRpcServer.invalid_params(JsonRpcServer, data)
  # Test
  assert result == return_val

# Generated at 2022-06-23 14:07:13.727026
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    j = JsonRpcServer()
    j._identifier = 'test'
    result = j.header()
    assert result == {'jsonrpc': '2.0', 'id': 'test'}


# Generated at 2022-06-23 14:07:16.761365
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    obj = vars()
    server.register(obj)
    # Server object gets registered, and obj is kept in the memory
    assert server._objects == set(obj)


# Generated at 2022-06-23 14:07:21.162841
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    jsonrpcServer = JsonRpcServer()
    jsonrpcServer.register(jsonrpcServer)
    error = jsonrpcServer.error(-32600, 'Invalid request', 'Error message')
    assert error == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32600, 'message': 'Invalid request', 'data': 'Error message'}}

# Generated at 2022-06-23 14:07:24.978440
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    mock_obj = MockAnsibleModule()
    server.register(mock_obj)
    assert server._objects == {mock_obj}



# Generated at 2022-06-23 14:07:26.986966
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    test_obj = JsonRpcServer()
    result = test_obj.internal_error()
    return result

# Generated at 2022-06-23 14:07:29.990660
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    
    # Unit test for method error of class JsonRpcServer
    assert False # remove if method error of class JsonRpcServer is implemented

# Generated at 2022-06-23 14:07:32.135245
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    server._identifier = 1
    assert server.header() == {"jsonrpc": "2.0", "id": 1}


# Generated at 2022-06-23 14:07:36.092295
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    # test for method method_not_found of class JsonRpcServer
    server = JsonRpcServer()
    response = server.method_not_found()
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == None
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'


# Generated at 2022-06-23 14:07:38.471286
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    json_rpc_server = JsonRpcServer()
    return json_rpc_server

if __name__ == '__main__':
    json_rpc_server = test_JsonRpcServer()


# Generated at 2022-06-23 14:07:40.605656
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    obj = JsonRpcServer()
    assert obj is not None

# Generated at 2022-06-23 14:07:43.119748
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    jsonrpc = JsonRpcServer()
    assert jsonrpc
    assert isinstance(jsonrpc, JsonRpcServer)


# Generated at 2022-06-23 14:07:47.040801
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    # Assured that error returns the value
    mock_obj = JsonRpcServer()
    code = -32603
    message = 'Internal error'
    data = 'Error message'
    result = mock_obj.error(code, message, data)
    assert result == {'jsonrpc': '2.0', 'error': {'code': -32603, 'message': 'Internal error', 'data': 'Error message'}, 'id': None}

# Generated at 2022-06-23 14:07:56.729807
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    assert server.error(code=-32700, message='Parse error') == {"jsonrpc": "2.0", "error": {"code": -32700, "message": "Parse error"}, "id": None}
    assert server.error(code=-32601, message='Method not found') == {"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": None}
    assert server.error(code=-32600, message='Invalid request') == {"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": None}

# Generated at 2022-06-23 14:07:58.063461
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():

    server = JsonRpcServer()

    assert server is not None

# Generated at 2022-06-23 14:08:01.200477
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    result = server.invalid_request()
    assert result['error']['code'] == -32600
    assert result['error']['message'] == 'Invalid request'
    assert result['error']['data'] is None


# Generated at 2022-06-23 14:08:05.524641
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    json_rpc_server = JsonRpcServer()
    error = json_rpc_server.method_not_found()
    assert error == {"jsonrpc": "2.0", "id": None, "error": {"code": -32601, "message": "Method not found"}}

# Test for method method_not_found of class JsonRpcServer

# Generated at 2022-06-23 14:08:08.039726
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    result = server.error(code=0, message='hi')
    assert result == {
        'jsonrpc': '2.0',
        'error': {
            'code': 0,
            'message': 'hi'
        }
    }


# Generated at 2022-06-23 14:08:14.631360
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jsonRpcServer = JsonRpcServer()
    result = jsonRpcServer.invalid_params("error data")
    assert result == {
        'error': {
            'code': -32602,
            'message': 'Invalid params',
            'data': 'error data',
        },
        'id': None,
        'jsonrpc': '2.0',
    }

# Generated at 2022-06-23 14:08:20.599496
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    # pylint: disable=unused-argument

    # arguments
    dummy_data = "dummy"

    # create instance of JsonRpcServer
    dummy_instance = JsonRpcServer()
    # Mock attributes of instance
    dummy_instance.method = "dummy"
    dummy_instance.value = "dummy"
    # call method
    result = dummy_instance.internal_error(dummy_data)

    # verify the result
    assert result is not None
    assert result == {'error': {'message': 'Internal error', 'code': -32603},
                      'id': 'dummy', 'jsonrpc': '2.0'}



# Generated at 2022-06-23 14:08:30.940570
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    import inspect
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible_collections.cisco.nxos.plugins.module_utils.network.nxos.facts.facts import Facts
    server = JsonRpcServer()
    server.register(Facts())
    #Test JsonRpcServer.parse_error
    signature = inspect.signature(server.parse_error)
    assert len(signature.parameters) == 1
    assert signature.parameters['data'].default == None
    assert signature.parameters['data'].kind == inspect._ParameterKind.POSITIONAL_OR_KEYWORD
    #Call JsonRpcServer.parse_error

# Generated at 2022-06-23 14:08:32.560923
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    test = JsonRpcServer()
    assert test
    assert isinstance(test, JsonRpcServer)


# Generated at 2022-06-23 14:08:35.142638
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    jsonrpc = JsonRpcServer()
    test_class = TestClass()

    jsonrpc.register(test_class)

    assert test_class in jsonrpc._objects


# Generated at 2022-06-23 14:08:36.980162
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    obj = JsonRpcServer()
    result = obj.method_not_found()
    assert result['error']['code'] == -32601
    assert result['error']['message'] == 'Method not found'


# Generated at 2022-06-23 14:08:41.742261
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    json_rpc_server_obj = JsonRpcServer()
    result = json_rpc_server_obj.invalid_request()
    assert result == {'jsonrpc': '2.0', 'error': {'code': -32600, 'message': 'Invalid request'}, 'id': None}
    print("test_JsonRpcServer_invalid_request: Success")


# Generated at 2022-06-23 14:08:47.832818
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    # Create object of class JsonRpcServer
    jrpc_server = JsonRpcServer()

    # call method method_not_found of class JsonRpcServer
    response = jrpc_server.method_not_found()
    # check if response is correct
    assert response == {"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": None}


# Generated at 2022-06-23 14:08:52.227881
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    json_server = JsonRpcServer()
    setattr(json_server, '_identifier', '1')
    assert json_server.internal_error('test') == {'jsonrpc': '2.0', 'error': {'code': -32603, 'message': 'Internal error', 'data': 'test'}, 'id': '1'}

# Generated at 2022-06-23 14:08:55.844524
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jsonrpc = JsonRpcServer()
    error = jsonrpc.invalid_params("err")
    assert error['error']['code'] == -32602, "error code is incorrect"
    assert error['error']['message'] == "Invalid params", "error message is incorrect"
    assert error['error']['data'] == "err", "error data is incorrect"

# Generated at 2022-06-23 14:08:58.969494
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 1)
    expected = {u'jsonrpc': u'2.0', u'id': 1}

    result = server.header()

    assert result == expected




# Generated at 2022-06-23 14:09:04.120226
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    req = {'jsonrpc': '2.0', 'id': 2, 'method': 'nonexistent_method'}
    response = server.handle_request(json.dumps(req))
    error = json.loads(response)
    assert error.get('method') == 'nonexistent_method'
    assert error.get('code') == -32601
    assert error.get('error').get('message') == 'Method not found'
    display.display('test_JsonRpcServer_method_not_found ok')


# Generated at 2022-06-23 14:09:09.011639
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    assert json.loads(server.parse_error().decode('utf-8')) == {'id': 0, 'error': {'code': -32700, 'data': None, 'message': 'Parse error'}, 'jsonrpc': '2.0'}


# Generated at 2022-06-23 14:09:14.655367
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    hello_rpc_server = HelloRpcServer()
    server = JsonRpcServer()
    server.register(hello_rpc_server)
    request = {"id": "test_JsonRpcServer_handle_request", "params": ["abc", {"name": "def"}], "method": "hello"}
    expected_result = "{\"jsonrpc\": \"2.0\", \"id\": \"test_JsonRpcServer_handle_request\", \"result\": \"Hello abc!\", \"result_type\": \"pickle\"}"
    assert server.handle_request(request) == expected_result

# Generated at 2022-06-23 14:09:16.127871
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    a = JsonRpcServer()


# Generated at 2022-06-23 14:09:20.593559
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jsonRpcServer = JsonRpcServer()
    jsonRpcServer._identifier = 1
    result = jsonRpcServer.header()
    assert result == {'jsonrpc': '2.0', 'id': 1}


# Generated at 2022-06-23 14:09:24.576888
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    result = server.internal_error()
    assert(result["error"]["code"] == -32603)
    assert(result["error"]["message"] == 'Internal error')
    assert(result["id"] == None)


# Generated at 2022-06-23 14:09:28.082072
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    error = server.invalid_request()
    assert error['jsonrpc'] == '2.0'
    assert error['error']['code'] == -32600
    assert error['error']['message'] == 'Invalid request'

# Generated at 2022-06-23 14:09:33.323470
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    jrs =  JsonRpcServer()
    resp = jrs.parse_error()
    assert resp['jsonrpc'] == '2.0'
    assert resp['id'] == None
    assert resp['error']['code'] == -32700
    assert resp['error']['message'] == 'Parse error'


# Generated at 2022-06-23 14:09:40.715955
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    # Evaluate expected result:
    header = '{"jsonrpc": "2.0", "id": "_identifier"}'
    error = '{"code": -32602, "message": "Invalid params", "data": "data"}'
    expected = '{' + header + ', "error": ' + error + '}'

    # Create object
    rpc_server = JsonRpcServer()

    # Set attr identifier
    rpc_server._identifier = '_identifier'

    # Evaluate method output
    actual = rpc_server.invalid_params('data')

    # Compare output
    assert actual == expected

# Generated at 2022-06-23 14:09:48.602184
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', "1")
    expected_result = {"jsonrpc": "2.0", "id": 1,
                       "result_type": "pickle", "result": b'\x80\x03}q\x00.'}
    result = server.response({})
    print("test_JsonRpcServer_response: %s" % result)
    assert result == expected_result

# Generated at 2022-06-23 14:09:51.863373
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    assert isinstance(server.header(), dict)
    assert server.header()['jsonrpc'] == '2.0'
    assert server.header()['id'] == server._identifier

# Generated at 2022-06-23 14:09:54.659713
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    from ansible.module_utils.connection import Connection
    conn = Connection(None)
    conn._server = JsonRpcServer()
    conn._server.invalid_request()
    assert True

# Generated at 2022-06-23 14:09:57.692072
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'identifier')
    result = server.header()
    assert result == {'jsonrpc': '2.0', 'id': 'identifier'}
    delattr(server, '_identifier')


# Generated at 2022-06-23 14:10:01.879273
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    import pytest
    rpc_server = JsonRpcServer()
    with pytest.raises(Exception) as excinfo:
        rpc_server.invalid_params()
    assert str(excinfo.value) == "[-32602] Invalid params: {'code': -32602, 'message': 'Invalid params'}"


# Generated at 2022-06-23 14:10:06.853500
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    result = server.internal_error()
    assert result == {'id': None, 'jsonrpc': '2.0',
                      'error': {'code': -32603,
                                'message': 'Internal error', 'data': None}}


# Generated at 2022-06-23 14:10:11.668912
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    # Initialize JsonRpcServer object
    obj = JsonRpcServer()

    # Run the method
    response = obj.header()

    # Verify the result
    assert response == {'jsonrpc': '2.0', 'id': None}


# Generated at 2022-06-23 14:10:15.869025
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():

    # JsonRpcServer object
    agent = JsonRpcServer()

    setattr(agent, '_identifier', '123')

    response = agent.header()
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == '123'


# Generated at 2022-06-23 14:10:20.504057
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    jsonRpcServer = JsonRpcServer()
    assert json.loads(jsonRpcServer.parse_error()) == {'error': {'code': -32700, 'message': 'Parse error'}, 'id': None, 'jsonrpc': '2.0'}
    assert json.loads(jsonRpcServer.parse_error("Some data to specify")) == {'error': {'code': -32700, 'data': 'Some data to specify', 'message': 'Parse error'}, 'id': None, 'jsonrpc': '2.0'}


# Generated at 2022-06-23 14:10:26.753059
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    assert len(server._objects) == 0
    server.register(1)
    assert len(server._objects) == 1
    server.register(2)
    assert len(server._objects) == 2
    server.register(1)
    assert len(server._objects) == 2
    server.register(2)
    assert len(server._objects) == 2


# Generated at 2022-06-23 14:10:30.855861
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    error = server.parse_error()
    assert error["id"] == None
    assert error["jsonrpc"] == "2.0"
    assert error["error"]["code"] == -32700
    assert error["error"]["message"] == "Parse error"
    assert error["error"]["data"] == None


# Generated at 2022-06-23 14:10:38.967793
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Test for calling a method which does not exist
    rpc_obj = JsonRpcServer()
    request = json.dumps({
        'jsonrpc': '2.0',
        'method': 'test_method',
        'params': [],
        'id': '1'
    })
    response = rpc_obj.handle_request(request)
    json_data = json.loads(response)
    assert json_data['jsonrpc'] == "2.0"
    assert json_data['id'] == "1"
    assert json_data['error']['code'] == -32601
    assert json_data['error']['message'] == "Method not found"

# Generated at 2022-06-23 14:10:41.125706
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    json_rpc_server = JsonRpcServer()
    class Test():
        def foo(self):
            return True
    test = Test()
    json_rpc_server.register(test)
    assert json_rpc_server._objects == set([test])


# Generated at 2022-06-23 14:10:51.634737
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)

    message = {'method': 'error',
               'params': [[], {}],
               'id': 'test_JsonRpcServer_handle_request'}

    server = JsonRpcServer()
    server.register(server)

    response = server.handle_request(json.dumps(message))
    assert json.loads(response) == {"jsonrpc": "2.0",
                                    "id": "test_JsonRpcServer_handle_request",
                                    "error": {"code": -32601,
                                              "message": "Method not found"}}

    message = {'method': 'handle_request',
               'params': [[], {}],
               'id': 'test_JsonRpcServer_handle_request'}

   

# Generated at 2022-06-23 14:10:56.999602
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    assert JsonRpcServer().method_not_found() == {
        'id': None,
        'jsonrpc': '2.0',
        'error': {
            'code': -32601,
            'message': 'Method not found',
            'data': None
        }
    }

# Generated at 2022-06-23 14:11:00.630363
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    identifier = '123'
    obj = JsonRpcServer()
    setattr(obj, '_identifier', identifier)
    response = obj.header()
    assert response == {'jsonrpc': '2.0', 'id': identifier}


# Generated at 2022-06-23 14:11:04.458042
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server.register(server)
    result = server.handle_request(b'{"jsonrpc": "2.0", "method": "response", "params": [null], "id": "id"}')
    assert result == '{"jsonrpc": "2.0", "id": "id", "result": null}'



# Generated at 2022-06-23 14:11:08.878403
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    response = server.internal_error("test")
    assert response == {'id': 'test', 'jsonrpc': '2.0', 'error': {'code': -32603, 'message': 'Internal error', 'data': 'test'}}

# Generated at 2022-06-23 14:11:14.792181
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', '123')
    assert server.error(1, 'foo') == {'jsonrpc':'2.0','id':'123','error':{'code':1,'message':'foo'}}
    assert server.error(1, 'foo', data='bar') == {'jsonrpc':'2.0','id':'123','error':{'code':1,'message':'foo','data':'bar'}}


# Generated at 2022-06-23 14:11:20.477609
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    JsonRpcServer_obj = JsonRpcServer()
    JsonRpcServer_obj.register(JsonRpcServer())
    print("Internal error test")
    print(JsonRpcServer_obj.handle_request(json.dumps({
        "id": 1,
        "method": "internal_error",
        "params": [],
    })))


# Generated at 2022-06-23 14:11:24.077052
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    result = json.loads(server.handle_request(json.dumps({'jsonrpc': '2.0'})))
    assert result['error']['code'] == -32600

# Generated at 2022-06-23 14:11:29.156924
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    object_instance = JsonRpcServer()
    object_instance._identifier = "ABCD"
    assert object_instance.parse_error() == {'id': "ABCD", 'error': {'code': -32700, 'message': 'Parse error'}, 'jsonrpc': '2.0'}

# Generated at 2022-06-23 14:11:34.618120
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    # Test JsonRpcServer class header method which is used to create header of JSON RPC request
    header = JsonRpcServer().header()
    assert header['jsonrpc'] == '2.0', "JsonRpcServer header method returns incorrect jsonrpc version in header."
    assert header.get('id'), "JsonRpcServer header method returns incorrect id in header"


# Generated at 2022-06-23 14:11:37.087702
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
  jr = JsonRpcServer()
  result = jr.method_not_found()
  assert result == {'id': None, 'jsonrpc': '2.0', 'error': {'message': 'Method not found', 'code': -32601}}

# Generated at 2022-06-23 14:11:42.330612
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    json_str = '{"jsonrpc": "2.0", "method": "add", "params": [1, 2], "id": 1}'
    result = server.handle_request(json_str)
    assert(result == '{"jsonrpc": "2.0", "result": 3, "id": 1}');

    server = JsonRpcServer()
    json_str = '{"jsonrpc": "2.0", "method": "add", "params": {"arg1": 1, "arg2": 2}, "id": 1}'
    result = server.handle_request(json_str)
    assert(result == '{"jsonrpc": "2.0", "result": 3, "id": 1}');

    server = JsonRpcServer()
    json_str

# Generated at 2022-06-23 14:11:47.373534
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    error = JsonRpcServer().error(400, 'Test exception')
    assert error['jsonrpc'] == '2.0'
    assert error['error']['code'] == 400
    assert error['error']['message'] == 'Test exception'


# Generated at 2022-06-23 14:11:56.800668
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    assert server.parse_error() == {'jsonrpc': '2.0', 'id': None, 
               'error': {'code': -32700, 'message': 'Parse error'}}
    assert server.parse_error({"err": "wrong"}) == {'jsonrpc': '2.0', 'id': None, 
               'error': {'code': -32700, 'message': 'Parse error', 
                         'data': {'err': 'wrong'}}}


# Generated at 2022-06-23 14:11:58.383124
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    js = JsonRpcServer()
    print(js)

# Generated at 2022-06-23 14:12:03.980019
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    jsonRpcServer = JsonRpcServer()
    setattr(jsonRpcServer, '_identifier', '1234')
    response = jsonRpcServer.response()
    assert response.get('id') == '1234'
    assert response.get('result') == None


# Generated at 2022-06-23 14:12:04.955320
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()


# Generated at 2022-06-23 14:12:08.726360
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    ret1 = {"id": None, "jsonrpc": "2.0", "error": {"message": "Invalid request", "code": -32600}}
    ret2 = server.invalid_request()
    assert ret1 == ret2


# Generated at 2022-06-23 14:12:14.910411
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    JsonRpcServer = JsonRpcServer()
    JsonRpcServer.invalid_params
    assertJsonRpcServerTestResultIs(JsonRpcServer.invalid_params,
                                    {"jsonrpc": "2.0",
                                     "id": JsonRpcServer._identifier,
                                     "error": {"code": -32602, "message": "Invalid params",
                                               "data": None}})


# Generated at 2022-06-23 14:12:26.587713
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json

    # Test the case where method is a local method
    # Input parameters
    rpc = JsonRpcServer()
    rpc.register(rpc)
    request = {
        "method": "internal_error",
        "params": [[], {}],
        "id": 0
    }
    request = json.dumps(request)

    # Output expected
    output_expected = {"id": 0,
                        "jsonrpc": "2.0",
                        "error": {"code": -32603,
                            "message": "Internal error"
                        }
                    }
    output_expected = json.dumps(output_expected)

    # Output returned
    output_returned = rpc.handle_request(request)

# Generated at 2022-06-23 14:12:35.552641
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    # create instance of JsonRpcServer class
    jsonrpcserver = JsonRpcServer()

    # create the request to call the invalid_params method
    jsonrequest = json.dumps({
        'jsonrpc': '2.0',
        'method': 'rpc.invalid_params',
        'params': '[]',
        'id': '1'
    })
    # call handle_request method and get the response
    jsonresponse = jsonrpcserver.handle_request(jsonrequest)

    # get the result from the response
    jsonresponse = json.loads(jsonresponse)
    result = jsonresponse['result']

    # get the expected result
    expected_result = jsonrpcserver.invalid_params().get('result')

    # compare the actual result and expected result

# Generated at 2022-06-23 14:12:37.360064
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    server.register(server)
    assert server in server._objects


# Generated at 2022-06-23 14:12:41.996120
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    jsonrpc = JsonRpcServer()

    assert isinstance(jsonrpc, JsonRpcServer)
    assert hasattr(jsonrpc, 'handle_request')
    assert hasattr(jsonrpc, 'register')
    assert hasattr(jsonrpc, 'header')
    assert hasattr(jsonrpc, 'response')
    assert hasattr(jsonrpc, 'error')
    assert hasattr(jsonrpc, 'parse_error')
    assert hasattr(jsonrpc, 'method_not_found')
    assert hasattr(jsonrpc, 'invalid_request')
    assert hasattr(jsonrpc, 'invalid_params')
    assert hasattr(jsonrpc, 'internal_error')




# Generated at 2022-06-23 14:12:44.743455
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    JRS = JsonRpcServer()
    result = JRS.invalid_params()
    assert result == {'id': None, 'jsonrpc': '2.0', 'error': {'code': -32602, 'message': 'Invalid params', 'data': None}}


# Generated at 2022-06-23 14:12:49.740630
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    try:
        server = JsonRpcServer()
        internal_error = server.internal_error(data=None)
        assert internal_error == {'error': {'code': -32603, 'message': 'Internal error'}, 'id': None, 'jsonrpc': '2.0'}
    except Exception as err:
        print(err)
        assert False


# Generated at 2022-06-23 14:12:54.832262
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    method = "method-not-found"
    expected = {"error": {"code": -32601, "message": "Method not found"},
                "id": "", "jsonrpc": "2.0"}
    instance = JsonRpcServer()
    result = instance.method_not_found()

    assert result == expected


# Generated at 2022-06-23 14:12:58.174300
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    assert server.parse_error() == {'id': None, 'jsonrpc': '2.0', 'error': {'code': -32700, 'message': 'Parse error'}}


# Generated at 2022-06-23 14:13:04.647071
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    cli_args = dict(
        connection='network_cli',
        host='10.24.48.213',
        username='admin',
        password='C1sco12345',
    )
    jsonRpcServer = JsonRpcServer()
    jsnrpclib = JsonRpc(**cli_args)
    jsonRpcServer.register(jsnrpclib)
    assert 'JsonRpc' in jsonRpcServer._objects


# Generated at 2022-06-23 14:13:08.012362
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_id')
    result = server.response()
    assert result['jsonrpc'] == '2.0'
    assert result['id'] == 'test_id'
    assert result['result'] is None


# Generated at 2022-06-23 14:13:16.889445
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Test for invalid response
    response = JsonRpcServer().response("Invalid_Response")
    assert response is None

    # Test for valid response
    response = JsonRpcServer().response("Valid_Response")
    assert response["jsonrpc"] == '2.0'
    assert response["id"] == '1'
    assert response["result"] == "Valid_Response"
    assert response["result_type"] == None

    response = JsonRpcServer().response(["Item1", "Item2", "Item3"])
    assert response["jsonrpc"] == '2.0'
    assert response["id"] == '1'

# Generated at 2022-06-23 14:13:19.112086
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    result = JsonRpcServer().method_not_found('data_value')
    assert result['error']['code'] == -32601

# Generated at 2022-06-23 14:13:23.246312
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    server._identifier = 1234
    response = server.header()
    assert response.get('jsonrpc') == '2.0'
    assert response.get('id') == 1234

# Generated at 2022-06-23 14:13:27.255516
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    test_instance = JsonRpcServer()
    assert(test_instance.invalid_request() == {'id': None, 'jsonrpc': '2.0', 'error': {'message': 'Invalid request', 'code': -32600}})


# Generated at 2022-06-23 14:13:37.337890
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from unit_test.varmgr_utils import FakeModule
    from unit_test.varmgr_utils import FakeConnection
    from ansible.module_utils.connection import Connection

    conn = Connection(module=FakeModule())
    jserver = JsonRpcServer()
    jserver.register(FakeConnection(conn))
    method = jserver.handle_request('{"jsonrpc": "2.0", "method": "get_config", "params": ["running", {"format": "json"}], "id": 1}')
    method = json.loads(method)
    assert method["error"]["code"] == -32700


# Generated at 2022-06-23 14:13:38.904308
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    j = JsonRpcServer()
    j.method_not_found()


# Generated at 2022-06-23 14:13:47.609457
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jsonrpc = JsonRpcServer()
    jsonrpc.register(jsonrpc)
    request = json.dumps({
        "jsonrpc": "2.0",
        "id": 1,
        "method": "invalid_params",
        "params": [],
    })
    response = json.loads(jsonrpc.handle_request(request))
    assert response["jsonrpc"] == "2.0"
    assert response["id"] == 1
    assert response["error"]["code"] == -32602
    assert response["error"]["message"] == "Invalid params"
    assert response["error"]["data"] == None



# Generated at 2022-06-23 14:13:59.141577
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    try:
        id = 'test_JsonRpcServer_invalid_params'
        request = {'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': id}
        request = json.dumps(request)
        jrpc = JsonRpcServer()
        response = jrpc.handle_request(request)
        response = json.loads(response)
        assert response.get('id') == id
        assert response.get('error') is not None
        assert response.get('error').get('code') == -32602
        assert response.get('error').get('message') == 'Invalid params'
        assert response.get('error').get('data') is None
    except AssertionError as e:
        print('assertion error raised: %s' % e)
   

# Generated at 2022-06-23 14:14:03.542021
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    my_JsonRpcServer = JsonRpcServer()
    request_str = '{"params":[],"jsonrpc":"2.0","method":"hello","id":1}'
    response_str = my_JsonRpcServer.handle_request(request_str)
    assert isinstance(response_str, str)


# Generated at 2022-06-23 14:14:09.613665
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    jrs = JsonRpcServer()
    jrs._identifier = 'test_identifier'
    res = jrs.parse_error()
    assert res == '{"jsonrpc": "2.0", "error": {"code": -32700, "message": "Parse error"}, "id": "test_identifier"}'

# Generated at 2022-06-23 14:14:12.109081
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    response = server.error(1, 'test', ['data'])
    assert response == {'jsonrpc': '2.0', 'id': 'ansible', 'error': {'code': 1, 'message': 'test', 'data': ['data']}}


# Generated at 2022-06-23 14:14:17.764803
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    rpc_server = JsonRpcServer()
    rpc_server._identifier = 1
    print(rpc_server.invalid_params())
    assert rpc_server.invalid_params() == {'jsonrpc': '2.0', 'id': 1, 'error': {'code': -32602, 'message': 'Invalid params'}}

test_JsonRpcServer_invalid_params() # Calling the above function


# Generated at 2022-06-23 14:14:24.858460
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():

    # Constructing JsonRpcServer obj
    obj = JsonRpcServer()

    # Test method internal_error
    # Test case 1
    try:
        obj.internal_error()
        assert True
    except Exception:
        assert False

    # Test case 2
    try:
        obj.internal_error(data = "test")
        assert True
    except Exception:
        assert False

# Generated at 2022-06-23 14:14:29.686690
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 4)
    result = server.header()

    assert type(result) is dict, "JsonRpcServer.header() should return a dict"
    assert result == {'jsonrpc': '2.0', 'id': 4}, "JsonRpcServer.header() should return the dict {'jsonrpc': '2.0', 'id': 4}"


# Generated at 2022-06-23 14:14:33.178155
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    error = JsonRpcServer().invalid_request()
    assert 'error' in error
    assert error['error']['message'] == 'Invalid request'


# Generated at 2022-06-23 14:14:40.799995
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    srv = JsonRpcServer()

    assert srv.handle_request(request=b'{"jsonrpc": "2.0", "method": "echo", "id": 1}') == b'{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

    class Echo(object):
        def echo(self, msg):
            return msg

    srv.register(Echo())

    assert srv.handle_request(request=b'{"jsonrpc": "2.0", "method": "echo", "id": 1}') == b'{"jsonrpc": "2.0", "error": {"code": -32602, "message": "Invalid params"}, "id": 1}'

# Generated at 2022-06-23 14:14:44.941962
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    JsonRpcServerInst = JsonRpcServer()
    test_data = "test_data"
    JsonRpcServerInst.register(test_data)
    assert test_data in JsonRpcServerInst._objects

# Generated at 2022-06-23 14:14:48.944480
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    # create instance of class with named paramters
    # values are provided as arguments to constructor
    obj = JsonRpcServer()
    obj.internal_error(data='123' )
    # test default values of attributes

test_JsonRpcServer_internal_error()

# Generated at 2022-06-23 14:14:56.613587
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    server.register(server)
    request = {
        "jsonrpc": "2.0",
        "method": "internal_error",
        "id": 1,
        "params": [
            {},
            {}
        ]
    }
    request = json.dumps(request)
    result = server.handle_request(request)
    result = json.loads(result)
    assert result['id'] == 1
    assert result['result'] is None
    assert result['error']['code'] == -32603
    assert type(result) is dict

# Generated at 2022-06-23 14:15:03.900867
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    j = JsonRpcServer()
    j._identifier = 'ansible_1'
    result = j.parse_error()
    expected = json.dumps({'id': 'ansible_1', 'jsonrpc': '2.0', 'error': {'code': -32700, 'message': 'Parse error'}})
    assert result == expected
    result = j.parse_error('unparsable')
    expected = json.dumps({'id': 'ansible_1', 'jsonrpc': '2.0', 'error': {'code': -32700, 'message': 'Parse error',
                                                                          'data': 'unparsable'}})
    assert result == expected


# Generated at 2022-06-23 14:15:10.187029
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    jrs = JsonRpcServer()
    jrs.register(jrs)
    request = "This is a parse error"
    result = jrs.handle_request(request)
    expected = {
        "jsonrpc": "2.0",
        "id": None,
        "error": {
            "code": -32700,
            "message": "Parse error"
        }
    }
    assert result == json.dumps(expected)
    

# Generated at 2022-06-23 14:15:14.711716
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    a = JsonRpcServer()
    a._identifier = 1
    assert a.error(1, 'test') == {"jsonrpc": "2.0", "id": 1, "error": {"code": 1, "message": "test"}}

# Generated at 2022-06-23 14:15:23.942042
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    class Foo(object):

        def multiply(self, x, y):
            return x * y

        def subtract(self, x, y):
            return x - y

    server = JsonRpcServer()

    server.register(Foo())

    server.connect()

    multiply = dict(method='multiply', params=([3,2],{}), id=1)
    subtract = dict(method='subtract', params=([3,2],{}), id=2)
    invalid = dict(method='invalid', params=([3,2],{}), id=2)

    # test handle_request with valid method
    response = server.handle_request(multiply)

# Generated at 2022-06-23 14:15:27.653789
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    test = JsonRpcServer()
    setattr(test, '_identifier', 'jsonrpc')
    exp_result = {'jsonrpc': '2.0', 'id': 'jsonrpc'}
    result = test.header()
    assert result == exp_result


# Generated at 2022-06-23 14:15:32.752397
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server = JsonRpcServer()
    res = json_rpc_server.error(code=1, message="this is a test")
    assert res['error']['code'] == 1
    assert res['error']['message'] == "this is a test"


# Generated at 2022-06-23 14:15:35.487504
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    def verify_return(expected, actual):
        assert actual['jsonrpc'] == '2.0'
        assert actual['id'] == expected
        assert actual['error']['code'] == -32700
        assert actual['error']['message'] == 'Parse error'
        assert actual['error']['data'] == 'foo'

    _id = 1
    expected = _id
    response = JsonRpcServer().error(-32700, 'Parse error', 'foo')
    actual = json.loads(response)
    verify_return(expected, actual)

# Generated at 2022-06-23 14:15:47.395420
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    # json-rpc standard errors (-32768 .. -32000)
    j = JsonRpcServer()
    assert j.error(code=-32700, message='Parse error') == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Parse error'}}
    assert j.error(code=-32600, message='Invalid request') == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32600, 'message': 'Invalid request'}}
    assert j.error(code=-32601, message='Method not found') == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32601, 'message': 'Method not found'}}

# Generated at 2022-06-23 14:15:51.772393
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    assert server.internal_error() == {'jsonrpc': '2.0', 'id': None, 'error':{'code': -32603, 'message': 'Internal error'}}


# Generated at 2022-06-23 14:16:01.199389
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    import json
    server = JsonRpcServer()
    # get response when the result is a text type
    result = server.response('test')
    assert json.loads(result) == {"jsonrpc": "2.0", "id": None, "result": "test"}
    # get response when the result is not a text type
    result = server.response([1, 2, 3])
    assert json.loads(result)["result_type"] == "pickle"
    assert json.loads(result)["result"] == "((lp0\nI1\naI2\naI3\na."


if __name__ == '__main__':
    test_JsonRpcServer_response()

# Generated at 2022-06-23 14:16:06.106079
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    js = JsonRpcServer()
    js._identifier = 'test'
    res = js.method_not_found('test')
    assert res['error']['code'] == -32601
    assert res['error']['message'] == 'Method not found'
    assert res['id'] == 'test'

# Generated at 2022-06-23 14:16:15.068673
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    test_obj = JsonRpcServer()

    # Test case with jsonrpc,id,error code and message
    test_obj._identifier = 1234567
    response = test_obj.error(code=4, message="Some error")
    assert response == {'jsonrpc': '2.0', 'id': 1234567, 'error': {'code': 4, 'message': "Some error"}}

    # Test case with jsonrpc,id,error,extra data
    test_obj._identifier = 1234567
    response = test_obj.error(code=4, message="Some error", data={"Key":"value"})

# Generated at 2022-06-23 14:16:18.619812
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 1)
    assert server.header() == {'jsonrpc': '2.0', 'id': 1}
    delattr(server, '_identifier')


# Generated at 2022-06-23 14:16:28.223113
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    jrs = JsonRpcServer()
    assert jrs
    assert jrs._objects == set()
    assert hasattr(jrs, 'handle_request')
    assert hasattr(jrs, 'register')
    assert hasattr(jrs, 'header')
    assert hasattr(jrs, 'response')
    assert hasattr(jrs, 'error')
    assert hasattr(jrs, 'parse_error')
    assert hasattr(jrs, 'method_not_found')
    assert hasattr(jrs, 'invalid_request')
    assert hasattr(jrs, 'invalid_params')
    assert hasattr(jrs, 'internal_error')

# Generated at 2022-06-23 14:16:37.251331
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # response without result
    response = JsonRpcServer().response()
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == 0
    assert 'result' not in response
    assert 'result_type' not in response
    assert 'error' not in response

    # response with result
    response = JsonRpcServer().response(result='test')
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == 0
    assert response['result'] == 'test'
    assert response['result_type'] == 'str'
    assert 'error' not in response

    # response with result (bytes)
    response = JsonRpcServer().response(result=b'test')
    assert response['jsonrpc'] == '2.0'

# Generated at 2022-06-23 14:16:44.081304
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    json_rpc_server = JsonRpcServer()
    json_rpc_server.register(json_rpc_server)
    setattr(json_rpc_server,'_identifier','1')
    response = json_rpc_server.parse_error()
    assert response == {'jsonrpc': '2.0', 'id': '1', 'error': {'code': -32700, 'message': 'Parse error'}}


# Generated at 2022-06-23 14:16:49.470623
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
  error = JsonRpcServer().invalid_params("Testing invalid_params error")
  assert error['error']['message'] == 'Invalid params'
  assert error['error']['code'] == -32602
  assert error['error']['data'] == 'Testing invalid_params error'


# Generated at 2022-06-23 14:16:51.202580
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    print(JsonRpcServer.internal_error(JsonRpcServer()))

# Generated at 2022-06-23 14:16:53.570387
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    c = JsonRpcServer()
    c._identifier=1
    assert c.header() == {'jsonrpc': '2.0', 'id': 1}


# Generated at 2022-06-23 14:16:59.572393
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test'
    assert server.response() == {'jsonrpc': '2.0', 'id': 'test', 'result': None}
    assert server.response('test') == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}


# Generated at 2022-06-23 14:17:02.583608
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    class NewClass:
        pass
    server.register(NewClass())

    #object is added to the _objects list
    assert len(server._objects) == 1

